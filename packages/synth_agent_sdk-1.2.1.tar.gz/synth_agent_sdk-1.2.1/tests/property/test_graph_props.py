"""Property-based tests for Graph orchestration.

**Property 16: Graph conditional edge routing**
**Validates: Requirements 7.1, 7.2**

**Property 17: Graph raises GraphRoutingError on dead end**
**Validates: Requirements 7.3**

**Property 18: Checkpoint persistence per step**
**Validates: Requirements 7.4, 13.1**

**Property 19: Graph termination at Graph.END**
**Validates: Requirements 7.5**

**Property 20: Graph visualise contains all nodes and edges**
**Validates: Requirements 7.7**

**Property 34: Checkpoint resume continues correctly**
**Validates: Requirements 13.2**

**Property 35: RunNotFoundError for missing checkpoint**
**Validates: Requirements 13.3**

**Property 37: GraphLoopError on max iterations**
**Validates: Requirements 15.3**
"""

from __future__ import annotations

import asyncio
import uuid

from hypothesis import given, settings
from hypothesis import strategies as st


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

from synth.checkpointing.local import LocalCheckpointStore
from synth.errors import GraphLoopError, GraphRoutingError, RunNotFoundError
from synth.orchestration.graph import Graph
from synth.types import RunResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _linear_graph(n_nodes: int) -> Graph:
    """Build a linear graph with *n_nodes* nodes ending at Graph.END."""
    graph = Graph()
    names = [f"node_{i}" for i in range(n_nodes)]
    for i, name in enumerate(names):
        graph.add_node(name, lambda s, idx=i: {**s, f"step_{idx}": True})
    for i in range(len(names) - 1):
        graph.add_edge(names[i], names[i + 1])
    graph.add_edge(names[-1], Graph.END)
    graph.set_entry(names[0])
    return graph


# ---------------------------------------------------------------------------
# Property 16: Graph conditional edge routing
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    route_value=st.booleans(),
)
def test_graph_conditional_edge_routing(route_value: bool):
    """Property 16: Graph conditional edge routing.

    For any Graph with conditional edges, the engine should traverse an
    edge only when its when condition evaluates to True.

    **Validates: Requirements 7.1, 7.2**
    """
    graph = Graph()
    graph.add_node("start", lambda s: {**s, "flag": route_value})
    graph.add_node("true_path", lambda s: {**s, "path": "true"})
    graph.add_node("false_path", lambda s: {**s, "path": "false"})
    graph.add_edge("start", "true_path", when=lambda s: s.get("flag") is True)
    graph.add_edge("start", "false_path", when=lambda s: s.get("flag") is False)
    graph.add_edge("true_path", Graph.END)
    graph.add_edge("false_path", Graph.END)
    graph.set_entry("start")

    result = _run_async(graph.arun({}))
    expected_path = "true" if route_value else "false"
    assert result.output["path"] == expected_path


# ---------------------------------------------------------------------------
# Property 17: Graph raises GraphRoutingError on dead end
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_nodes=st.integers(min_value=1, max_value=5),
)
def test_graph_raises_routing_error_on_dead_end(n_nodes: int):
    """Property 17: Graph raises GraphRoutingError on dead end.

    For any Graph node where all outbound edge conditions evaluate to
    False, the Graph should raise a GraphRoutingError.

    **Validates: Requirements 7.3**
    """
    graph = Graph()
    names = [f"n_{i}" for i in range(n_nodes)]
    for name in names:
        graph.add_node(name, lambda s: s)
    # Chain nodes but leave the last one with only a False condition
    for i in range(len(names) - 1):
        graph.add_edge(names[i], names[i + 1])
    # Last node has only a conditional edge that's always False
    graph.add_edge(names[-1], Graph.END, when=lambda s: False)
    graph.set_entry(names[0])

    try:
        _run_async(graph.arun({}))
        assert False, "Should have raised GraphRoutingError"
    except GraphRoutingError as err:
        assert err.node_name == names[-1]


# ---------------------------------------------------------------------------
# Property 18: Checkpoint persistence per step
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    n_nodes=st.integers(min_value=1, max_value=5),
)
def test_checkpoint_persistence_per_step(n_nodes: int, tmp_path_factory):
    """Property 18: Checkpoint persistence per step.

    For any checkpointed Graph execution, the number of persisted
    checkpoints should equal the number of completed steps.

    **Validates: Requirements 7.4, 13.1**
    """
    tmp_path = tmp_path_factory.mktemp("checkpoints")
    store = LocalCheckpointStore(base_dir=str(tmp_path))
    graph = _linear_graph(n_nodes)
    graph.with_checkpointing(store)

    run_id = f"run-{uuid.uuid4().hex[:8]}"
    _run_async(graph.arun({}, run_id=run_id))

    # The latest checkpoint should have step == n_nodes
    cp = _run_async(store.load(run_id))
    assert cp is not None
    assert cp.step == n_nodes


# ---------------------------------------------------------------------------
# Property 19: Graph termination at Graph.END
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_nodes=st.integers(min_value=1, max_value=6),
)
def test_graph_termination_at_end(n_nodes: int):
    """Property 19: Graph termination at Graph.END.

    For any Graph execution that reaches Graph.END, the execution should
    terminate and return the final state as the RunResult.

    **Validates: Requirements 7.5**
    """
    graph = _linear_graph(n_nodes)
    result = _run_async(graph.arun({}))

    assert isinstance(result, RunResult)
    # All steps should have been executed
    for i in range(n_nodes):
        assert result.output.get(f"step_{i}") is True


# ---------------------------------------------------------------------------
# Property 20: Graph visualise contains all nodes and edges
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_nodes=st.integers(min_value=1, max_value=6),
)
def test_graph_visualise_contains_all_nodes_and_edges(n_nodes: int):
    """Property 20: Graph visualise contains all nodes and edges.

    For any Graph with N nodes and M edges, graph.visualise() should
    return a Mermaid diagram containing all N node names and all M edges.

    **Validates: Requirements 7.7**
    """
    graph = _linear_graph(n_nodes)
    mermaid = graph.visualise()

    for i in range(n_nodes):
        assert f"node_{i}" in mermaid

    # Should contain "END" since the last node connects to Graph.END
    assert "END" in mermaid


# ---------------------------------------------------------------------------
# Property 34: Checkpoint resume continues correctly
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    human_value=st.text(min_size=1, max_size=20),
)
def test_checkpoint_resume_continues_correctly(
    human_value: str, tmp_path_factory,
):
    """Property 34: Checkpoint resume continues correctly.

    For any checkpointed Graph run that is paused and resumed, execution
    should continue from the last completed step.

    **Validates: Requirements 13.2**
    """
    tmp_path = tmp_path_factory.mktemp("resume")
    store = LocalCheckpointStore(base_dir=str(tmp_path))

    graph = Graph()
    graph.add_node("step1", lambda s: {**s, "step1": True})
    graph.add_node("step2", lambda s: {**s, "step2": True})
    graph.add_edge("step1", "step2")
    graph.add_edge("step2", Graph.END)
    graph.set_entry("step1")
    graph.with_checkpointing(store)
    graph.with_human_in_the_loop(pause_at=["step1"])

    run_id = f"run-{uuid.uuid4().hex[:8]}"

    # First run should pause at step1
    paused = _run_async(graph.arun({}, run_id=run_id))
    from synth.types import PausedRun
    assert isinstance(paused, PausedRun)
    assert paused.paused_at_node == "step1"

    # Resume should continue and complete
    result = _run_async(graph.aresume(run_id, human_input=human_value))
    assert isinstance(result, RunResult)
    assert result.output.get("step2") is True


# ---------------------------------------------------------------------------
# Property 35: RunNotFoundError for missing checkpoint
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    run_id=st.text(
        alphabet=st.characters(whitelist_categories=("L", "N")),
        min_size=1, max_size=30,
    ),
)
def test_run_not_found_error_for_missing_checkpoint(
    run_id: str, tmp_path_factory,
):
    """Property 35: RunNotFoundError for missing checkpoint.

    For any run_id that has no corresponding checkpoint, calling
    graph.resume(run_id) should raise a RunNotFoundError.

    **Validates: Requirements 13.3**
    """
    tmp_path = tmp_path_factory.mktemp("missing")
    store = LocalCheckpointStore(base_dir=str(tmp_path))

    graph = Graph()
    graph.add_node("a", lambda s: s)
    graph.add_edge("a", Graph.END)
    graph.set_entry("a")
    graph.with_checkpointing(store)

    try:
        _run_async(graph.aresume(run_id))
        assert False, "Should have raised RunNotFoundError"
    except RunNotFoundError as err:
        assert err.run_id == run_id


# ---------------------------------------------------------------------------
# Property 37: GraphLoopError on max iterations
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    max_iter=st.integers(min_value=1, max_value=20),
)
def test_graph_loop_error_on_max_iterations(max_iter: int):
    """Property 37: GraphLoopError on max iterations.

    For any Graph execution that exceeds max_iterations, the Graph should
    raise a GraphLoopError with node_history length == max_iterations.

    **Validates: Requirements 15.3**
    """
    graph = Graph()
    graph.add_node("loop", lambda s: s)
    graph.add_edge("loop", "loop")
    graph.set_entry("loop")

    try:
        _run_async(graph.arun({}, max_iterations=max_iter))
        assert False, "Should have raised GraphLoopError"
    except GraphLoopError as err:
        assert err.max_iterations == max_iter
        assert len(err.node_history) == max_iter
