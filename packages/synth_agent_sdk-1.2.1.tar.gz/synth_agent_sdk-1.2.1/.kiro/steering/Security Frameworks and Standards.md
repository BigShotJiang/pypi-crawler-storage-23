---
inclusion: always
---

# Security Frameworks and Standards for Agentic SDK Development

These rules apply to all code written within the Synth SDK. They address the unique security
surface of agentic systems where LLM outputs drive code execution, tool invocation, and
multi-step workflows.

## 1. Tool Execution Sandboxing

- Never pass LLM-generated arguments directly to `eval()`, `exec()`, `subprocess`, `os.system`,
  or any shell-invoking function.
- All tool arguments received from the model MUST be validated against the tool's declared
  JSON schema before execution. Reject unexpected keys and types.
- Tool functions MUST NOT have access to the SDK's internal state, provider credentials, or
  other tools' execution contexts. Use isolated invocation boundaries.
- Enforce a configurable per-tool execution timeout to prevent runaway tool calls from blocking
  the agent loop.

## 2. Credential and Secret Management

- NEVER log, trace, serialize, or include API keys, tokens, or connection strings in
  `RunResult`, `Trace`, `Checkpoint`, error messages, or any user-facing output.
- Scrub `Authorization` headers and credential fields from all provider request/response data
  before writing to traces or exporting to OTEL endpoints.
- When raising `SynthConfigError` for missing credentials, reference the environment variable
  name only — never echo back partial key values or credential contents.
- Provider credentials MUST be resolved at call time from environment variables or credential
  providers (e.g., AWS IAM roles), never stored as instance attributes in serializable objects.

## 3. Input and Output Sanitization

- All user-supplied prompts and model outputs that flow into tool arguments, graph state,
  or checkpoint data MUST be treated as untrusted input.
- Guard implementations (PII, custom, tool filter) MUST run before any side-effecting
  operation. Never defer guard checks to after tool execution or response delivery.
- The `Guard.no_pii_output()` guard MUST scan the full response text, not just a truncated
  preview. PII patterns include but are not limited to: email, phone, SSN, credit card, and
  address formats.
- Custom guard functions (`Guard.custom(fn)`) MUST be wrapped in try/except. A guard that
  throws an unhandled exception MUST be treated as a violation, not silently skipped.

## 4. Prompt Injection Defense

- System instructions and user prompts MUST be clearly delineated in the message array sent
  to providers. Never concatenate system instructions with user input into a single message.
- Tool results fed back into the conversation MUST be wrapped in a clearly delimited tool
  result message role, not injected as raw assistant or user text.
- When using `Memory.semantic()` or `Memory.persistent()`, retrieved context MUST be inserted
  as system-level context, not as fabricated user messages that could override instructions.
- AgentTeam handoff context MUST NOT allow the delegated agent to override the orchestrator's
  system instructions.

## 5. Serialization and Checkpoint Security

- Checkpoint data MUST be serialized using JSON only. Never use `pickle`, `marshal`, or any
  deserialization format that allows arbitrary code execution.
- When loading checkpoints from external stores (Redis, disk), validate the schema and data
  types before restoring execution state. Reject malformed checkpoints with a clear error.
- Checkpoint files on disk MUST be written with restrictive permissions (owner read/write only).
- Redis checkpoint connections MUST support TLS and authentication. Document that unencrypted
  Redis connections are not recommended for production.

## 6. Network and Provider Security

- All provider HTTP calls MUST use HTTPS. Reject `http://` base URLs unless explicitly
  opted in via a `allow_insecure=True` flag (for local development with Ollama, etc.).
- Implement request timeouts on all provider calls. Default to a reasonable timeout (e.g., 120s)
  and make it configurable. Never allow unbounded waits.
- When forwarding traces to `SYNTH_TRACE_ENDPOINT`, validate that the endpoint uses HTTPS
  and set a reasonable payload size limit to prevent exfiltration of large context windows.
- Rate-limit retry logic MUST include a maximum total retry duration cap, not just a retry
  count, to prevent indefinite retry loops on persistent failures.

## 7. Dependency and Supply Chain Security

- Keep core runtime dependencies minimal (< 5 as per NFR). Each dependency increases the
  attack surface.
- Provider-specific SDKs MUST be isolated in optional extras. Never import a provider SDK
  at module load time — use lazy imports guarded by try/except with clear error messages.
- Pin minimum versions of security-sensitive dependencies (e.g., `httpx`, `cryptography`,
  `boto3`) and document the rationale.
- The `synth deploy` packager MUST NOT bundle `.env` files, credential files, or
  `.synth/checkpoints/` directories into deployment artifacts.

## 8. Logging and Observability Security

- Log at INFO level or above by default. DEBUG-level logs that may contain prompt content,
  model responses, or tool arguments MUST be gated behind an explicit opt-in.
- Trace spans MUST NOT store full prompt text or model responses by default. Provide an
  opt-in `trace_content=True` flag for development use only.
- When integrating with third-party observability platforms (Langfuse, Datadog, Honeycomb),
  document that trace data may contain sensitive content and recommend enabling PII scrubbing
  on the receiving platform.

## 9. Graph and Orchestration Safety

- Enforce `max_iterations` on all graph executions with a sensible default (100). This
  prevents infinite loops caused by adversarial or malformed state transitions.
- Human-in-the-loop timeouts MUST be enforced server-side, not just client-side. A paused
  run that exceeds its timeout MUST be aborted or routed to the fallback node automatically.
- Concurrent node execution in graphs MUST use isolated state copies. Nodes running in
  parallel MUST NOT share mutable state references.
- `PausedRun.resume()` MUST validate that the caller is authorized to resume the run.
  In multi-tenant deployments, run IDs alone are insufficient for authorization.

## 10. AgentCore Deployment Security

- When deployed to AgentCore, ALWAYS use the runtime-provided IAM credentials. Never accept
  or bundle static AWS credentials in the deployment artifact.
- The generated agent manifest MUST declare least-privilege IAM permissions. Only request
  permissions that the agent's tools actually require.
- AgentCore memory integration MUST NOT fall back to unauthenticated local storage in
  production. If AgentCore memory is unavailable, fail explicitly rather than silently
  degrading to an insecure backend.
- Validate all AgentCore invocation payloads against an expected schema before processing.
  Reject malformed payloads with a 400-level error, not an unhandled exception.

## 11. Error Handling Security

- Error messages MUST be informative for developers but MUST NOT leak internal state,
  file paths, stack traces of dependencies, or credential fragments to end users.
- `ToolExecutionError` MUST include the tool name and sanitized arguments (redact values
  that look like secrets or tokens) but MUST NOT include the full stack trace of the
  underlying function in production mode.
- All custom exception classes MUST inherit from `SynthError` to ensure consistent
  error handling and prevent leaking raw Python exceptions to callers.

## 12. Structured Output Security

- When parsing model output into Pydantic models, use `model_validate_json()` with strict
  mode. Never use `eval()` or `ast.literal_eval()` to parse model output.
- Retry prompts for structured output MUST NOT echo back the full invalid output to the
  model, as it may contain injected instructions. Include only the validation error message.
- Pydantic models used as `output_schema` SHOULD use constrained types (max length, regex
  patterns, value ranges) to limit the attack surface of model-generated data.
