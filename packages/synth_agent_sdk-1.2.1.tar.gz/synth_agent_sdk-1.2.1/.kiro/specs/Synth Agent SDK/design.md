# Design Document: Synth Agent SDK

## Overview

Synth is a layered Python SDK for building production-grade AI agents and multi-agent systems. The architecture follows a composable, bottom-up design: a minimal core (Agent, Tool, RunResult) that works standalone, with orchestration layers (Pipeline, Graph, AgentTeam) composed on top. Provider adapters abstract LLM backends behind a unified interface. Cross-cutting concerns (Memory, Guards, Tracing, Checkpointing) are pluggable middleware that attach to any layer.

The SDK targets Python 3.10+ and provides both sync and async APIs. The package uses optional extras (`synth-agent-sdk[openai]`, `synth-agent-sdk[anthropic]`, `synth-agent-sdk[agentcore]`, etc.) to keep the core install minimal.

## Architecture

```mermaid
graph TB
    subgraph "Public API Layer"
        Agent["Agent"]
        Pipeline["Pipeline"]
        Graph["Graph"]
        AgentTeam["AgentTeam"]
        Eval["Eval"]
        CLI["CLI (synth)"]
    end

    subgraph "Middleware Layer"
        Guards["Guards"]
        Memory["Memory"]
        Tracing["Tracing"]
        Checkpointing["Checkpointing"]
        StructuredOutput["Structured Output"]
    end

    subgraph "Provider Layer"
        Router["ProviderRouter"]
        Anthropic["AnthropicProvider"]
        OpenAI["OpenAIProvider"]
        Google["GoogleProvider"]
        Ollama["OllamaProvider"]
        Bedrock["BedrockProvider"]
        Custom["CustomProvider (base_url)"]
    end

    subgraph "Tool System"
        ToolDecorator["@tool decorator"]
        ToolKit["ToolKit"]
        SchemaGen["JSON Schema Generator"]
        ToolExecutor["ToolExecutor"]
    end

    subgraph "Deployment Layer"
        AgentCoreAdapter["AgentCore Adapter"]
        AgentCoreHandler["@agentcore_handler"]
        Deployer["Deployer (synth deploy)"]
    end

    Agent --> Guards
    Agent --> Memory
    Agent --> Tracing
    Agent --> Router
    Agent --> ToolExecutor
    Agent --> StructuredOutput

    Pipeline --> Agent
    Graph --> Agent
    Graph --> Checkpointing
    AgentTeam --> Agent

    ToolDecorator --> SchemaGen
    ToolKit --> ToolDecorator
    ToolExecutor --> ToolDecorator

    Router --> Anthropic
    Router --> OpenAI
    Router --> Google
    Router --> Ollama
    Router --> Bedrock
    Router --> Custom

    AgentCoreAdapter --> Agent
    AgentCoreAdapter --> Graph
    AgentCoreHandler --> AgentCoreAdapter
    Deployer --> AgentCoreAdapter

    CLI --> Agent
    CLI --> Eval
    CLI --> Deployer
```

### Package Structure

```
synth/
├── __init__.py              # Public API exports: Agent, tool, Graph, Pipeline, etc.
├── agent.py                 # Agent class (sync/async run, stream)
├── types.py                 # RunResult, event types, error types, config types
├── errors.py                # SynthConfigError, ToolExecutionError, etc.
├── tools/
│   ├── __init__.py
│   ├── decorator.py         # @tool decorator and schema generation
│   ├── toolkit.py           # ToolKit class
│   └── executor.py          # ToolExecutor (invocation + error handling)
├── providers/
│   ├── __init__.py
│   ├── router.py            # ProviderRouter (model string → provider)
│   ├── base.py              # BaseProvider ABC
│   ├── anthropic.py         # AnthropicProvider
│   ├── openai.py            # OpenAIProvider
│   ├── google.py            # GoogleProvider
│   ├── ollama.py            # OllamaProvider
│   ├── bedrock.py           # BedrockProvider (AWS Bedrock Runtime)
│   └── retry.py             # Retry logic with exponential backoff
├── memory/
│   ├── __init__.py
│   ├── base.py              # BaseMemory ABC
│   ├── thread.py            # ThreadMemory (in-process)
│   ├── persistent.py        # PersistentMemory (Redis)
│   └── semantic.py          # SemanticMemory (vector embeddings)
├── orchestration/
│   ├── __init__.py
│   ├── pipeline.py          # Pipeline class
│   ├── graph.py             # Graph class, @node decorator, edge routing
│   ├── team.py              # AgentTeam class
│   └── human_in_loop.py     # PausedRun, human-in-the-loop logic
├── guards/
│   ├── __init__.py
│   ├── base.py              # BaseGuard ABC
│   ├── pii.py               # PII detection guard
│   ├── cost.py              # Cost limit guard
│   ├── tool_filter.py       # Tool call filter guard
│   └── custom.py            # Custom guard wrapper
├── tracing/
│   ├── __init__.py
│   ├── trace.py             # Trace class, span collection
│   ├── exporter.py          # OTEL JSON export, endpoint forwarding
│   └── integrations.py      # Langfuse, Datadog, Honeycomb adapters
├── checkpointing/
│   ├── __init__.py
│   ├── base.py              # BaseCheckpointStore ABC
│   ├── local.py             # LocalCheckpointStore (disk)
│   └── redis.py             # RedisCheckpointStore
├── eval/
│   ├── __init__.py
│   ├── eval.py              # Eval class, case management
│   ├── scorers.py           # ExactMatch, SemanticSimilarity scorers
│   └── report.py            # EvalReport, comparison logic
├── structured/
│   ├── __init__.py
│   └── output.py            # Pydantic schema enforcement, retry parsing
├── deploy/
│   ├── __init__.py
│   ├── agentcore/
│   │   ├── __init__.py
│   │   ├── adapter.py       # AgentCore payload translation
│   │   ├── credentials.py   # CredentialResolver, ResolvedCredentials
│   │   ├── handler.py       # @agentcore_handler decorator
│   │   ├── manifest.py      # Agent descriptor generation
│   │   └── memory.py        # AgentCore memory integration
│   └── packager.py          # Deployment artifact packaging
├── cli/
│   ├── __init__.py
│   ├── main.py              # CLI entry point (click-based)
│   ├── dev.py               # synth dev entry point (dispatches to TUI or basic REPL)
│   ├── _tui.py              # Rich terminal UI for synth dev (requires rich + prompt_toolkit)
│   ├── run_cmd.py           # synth run
│   ├── eval_cmd.py          # synth eval
│   ├── trace_cmd.py         # synth trace
│   ├── deploy_cmd.py        # synth deploy
│   ├── doctor.py            # synth doctor
│   └── banner.py            # Boot sequence / terminal branding
└── _compat.py               # Sync/async compatibility utilities
```

## Components and Interfaces

### Core Agent

The `Agent` class is the central abstraction. It composes a provider, optional tools, memory, guards, and structured output into a single callable unit.

```python
class Agent:
    def __init__(
        self,
        model: str | None = None,
        instructions: str = "",
        tools: list[Callable | ToolKit] | None = None,
        memory: BaseMemory | None = None,
        guards: list[BaseGuard] | None = None,
        output_schema: type[BaseModel] | None = None,
        base_url: str | None = None,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ): ...

    def run(self, prompt: str, *, thread_id: str | None = None, run_id: str | None = None) -> RunResult: ...
    async def arun(self, prompt: str, *, thread_id: str | None = None, run_id: str | None = None) -> RunResult: ...
    def stream(self, prompt: str, *, thread_id: str | None = None) -> Generator[StreamEvent, None, None]: ...
    async def astream(self, prompt: str, *, thread_id: str | None = None) -> AsyncGenerator[StreamEvent, None]: ...
```

Internally, `run()` delegates to `arun()` via the `_compat` module which manages event loop detection and bridging. The execution flow is:

1. Memory retrieval (if configured) → prepend context messages
2. Input guard evaluation (in declaration order)
3. Provider call (via `ProviderRouter`) with tool schemas
4. Tool execution loop (if model requests tool calls)
5. Output guard evaluation
6. Structured output parsing (if `output_schema` set)
7. Trace finalization and attachment to `RunResult`

### Tool System

```python
def tool(fn: Callable) -> ToolFunction:
    """Decorator that validates annotations/docstring and generates JSON schema."""
    ...

class ToolKit:
    def __init__(self, tools: list[ToolFunction]): ...
    def get_schemas(self) -> list[dict]: ...
    def get_tools(self) -> dict[str, ToolFunction]: ...

class ToolExecutor:
    def __init__(self, tools: dict[str, ToolFunction]): ...
    async def execute(self, name: str, args: dict) -> Any: ...
```

The `@tool` decorator inspects the function at decoration time:
- Validates that all parameters have type annotations (raises `ToolDefinitionError` if not)
- Validates that a docstring is present (raises `ToolDefinitionError` if not)
- Generates a JSON schema from `inspect.signature()` and type hints using a mapping of Python types to JSON Schema types
- Stores the schema as `fn._tool_schema` on the function object

### Provider System

```python
class BaseProvider(ABC):
    @abstractmethod
    async def complete(self, messages: list[Message], tools: list[dict] | None = None, **kwargs) -> ProviderResponse: ...

    @abstractmethod
    async def stream(self, messages: list[Message], tools: list[dict] | None = None, **kwargs) -> AsyncGenerator[ProviderEvent, None]: ...

class ProviderRouter:
    """Routes model strings to provider instances."""
    PROVIDER_MAP: dict[str, type[BaseProvider]] = {
        "claude-": AnthropicProvider,
        "gpt-": OpenAIProvider,
        "gemini-": GoogleProvider,
        "ollama/": OllamaProvider,
        "bedrock/": BedrockProvider,
    }

    def resolve(self, model: str, base_url: str | None = None) -> BaseProvider: ...
```

The router uses prefix matching on the model string. If no prefix matches and no `base_url` is provided, it raises `SynthConfigError`. If a provider's SDK package is not importable, it raises `SynthConfigError` with the exact `pip install` command.

The `BedrockProvider` uses the AWS Bedrock Runtime API (`boto3` client for `bedrock-runtime`). It accepts model strings like `"bedrock/claude-sonnet-4-5"` (which it maps to the Bedrock model ID) or full Bedrock ARN-style identifiers like `"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"`. It uses AWS credentials from the environment (IAM role, env vars, or AWS config) rather than provider-specific API keys. This is the natural choice for agents deployed to AgentCore, where the runtime provides IAM credentials automatically.

**Streaming tool call accumulation** — The Bedrock Converse API delivers tool calls across three event phases: `contentBlockStart` (carries `toolUseId` and `name`), one or more `contentBlockDelta` events (each carrying a partial JSON input chunk), and `contentBlockStop` (signals the block is complete). The `stream()` method accumulates these phases using local state (`_current_tool_id`, `_current_tool_name`, `_current_tool_input_chunks`). On `contentBlockStart`, it captures the tool ID and name and resets the chunk list. On each `contentBlockDelta` with a `toolUse` key, it appends the partial input string. On `contentBlockStop`, it joins all accumulated chunks, parses the assembled JSON into a dict (falling back to `{}` on `JSONDecodeError`), emits a single `ToolCallChunkEvent` with the complete tool call, and resets the accumulator. Text deltas are yielded immediately as `TextChunkEvent` without accumulation.

**Tool config requirement for tool-bearing messages** — The Bedrock Converse API requires a `toolConfig` parameter whenever the message history contains `toolUse` or `toolResult` content blocks, even if no tools are passed for the current call. Both `complete()` and `stream()` use a `_has_tool_blocks(api_messages)` static method to detect this condition. When `tools` is `None` or empty but the messages contain tool blocks (e.g. from memory replay), the provider calls `_strip_tool_blocks(api_messages)` to remove `toolUse` and `toolResult` content blocks from the message history rather than sending an empty `toolConfig`. Messages that become empty after stripping are dropped entirely. This avoids the `ValidationException` while keeping the conversation history coherent for the model.

Retry logic wraps each provider call. The `RetryHandler` catches HTTP 429 and 5xx responses and retries with exponential backoff (`base * 2^attempt` with jitter), up to `max_retries`.

### Memory System

```python
class BaseMemory(ABC):
    @abstractmethod
    async def get_messages(self, thread_id: str) -> list[Message]: ...
    @abstractmethod
    async def add_messages(self, thread_id: str, messages: list[Message]) -> None: ...

class Memory:
    @staticmethod
    def thread() -> ThreadMemory: ...
    @staticmethod
    def persistent(url: str) -> PersistentMemory: ...
    @staticmethod
    def semantic(embedder: Callable) -> SemanticMemory: ...
```

`ThreadMemory` stores messages in an in-process dictionary keyed by `thread_id`. `PersistentMemory` uses Redis lists. `SemanticMemory` stores embeddings and uses cosine similarity for retrieval.

When token count approaches the model's context limit (checked via a token counter utility), the memory backend automatically summarises older messages using a lightweight LLM call and emits a `ContextTruncationWarning`.

### Guard System

```python
class BaseGuard(ABC):
    name: str
    @abstractmethod
    async def check(self, content: str, context: GuardContext) -> GuardResult: ...

class Guard:
    @staticmethod
    def no_pii_output() -> PIIGuard: ...
    @staticmethod
    def max_cost(dollars: float) -> CostGuard: ...
    @staticmethod
    def no_tool_calls(patterns: list[str]) -> ToolFilterGuard: ...
    @staticmethod
    def custom(fn: Callable) -> CustomGuard: ...
```

Guards are evaluated in declaration order. The first violation halts evaluation and raises `GuardViolationError` with the guard name, violating content snippet, and suggested remediation.

`CostGuard` tracks cumulative cost across the run via the `GuardContext` which accumulates token costs from each provider call. `ToolFilterGuard` uses `fnmatch` glob matching against tool call names.

### Orchestration: Pipeline

```python
class Pipeline:
    def __init__(self, stages: list[Agent | ParallelGroup]): ...
    def run(self, input: str, *, output_schema: type[BaseModel] | None = None) -> RunResult: ...
    async def arun(self, input: str, *, output_schema: type[BaseModel] | None = None) -> RunResult: ...
    def stream(self, input: str) -> Generator[StageEvent, None, None]: ...
    async def astream(self, input: str) -> AsyncGenerator[StageEvent, None]: ...

class ParallelGroup:
    """Wraps agents to be executed concurrently within a pipeline."""
    def __init__(self, agents: list[Agent]): ...
```

Pipeline execution is sequential by default. Each stage receives the previous stage's `result.text` as its prompt. `ParallelGroup` stages run concurrently via `asyncio.gather()` and merge outputs (concatenation by default, configurable via a merge function).

On error, the pipeline captures partial results from completed stages and raises a `PipelineError` with the failed step index, agent name, and partial results.

Streaming wraps each event in a `StageEvent(stage_name: str, event: StreamEvent)`.

### Orchestration: Graph

```python
class Graph:
    END = sentinel("END")

    def __init__(self, state_schema: type[BaseModel] | None = None): ...
    def add_node(self, name: str, fn: Callable) -> None: ...
    def add_edge(self, source: str, target: str, when: Callable[[Any], bool] | None = None) -> None: ...
    def set_entry(self, name: str) -> None: ...
    def with_checkpointing(self, store: BaseCheckpointStore | None = None) -> Graph: ...
    def with_human_in_the_loop(self, pause_at: list[str], timeout: float | None = None, fallback: str | None = None) -> Graph: ...
    def run(self, input: Any, *, run_id: str | None = None, max_iterations: int = 100) -> RunResult: ...
    async def arun(self, input: Any, *, run_id: str | None = None, max_iterations: int = 100) -> RunResult | PausedRun: ...
    def resume(self, run_id: str, human_input: Any = None) -> RunResult | PausedRun: ...
    def visualise(self) -> str: ...
```

Graph execution engine:
1. Start at entry node
2. Execute current node(s) — if multiple independent nodes exist at the same level, execute concurrently via `asyncio.gather()`
3. Evaluate outbound edge conditions against returned state
4. If no condition matches, raise `GraphRoutingError`
5. If target is `Graph.END`, return final state
6. If node is in `pause_at` list, persist checkpoint and return `PausedRun`
7. If iteration count exceeds `max_iterations`, raise `GraphLoopError`
8. Repeat from step 2

The `@node` decorator is syntactic sugar for `graph.add_node()`:

```python
def node(graph: Graph, name: str | None = None):
    def decorator(fn):
        graph.add_node(name or fn.__name__, fn)
        return fn
    return decorator
```

`visualise()` builds a Mermaid diagram string by traversing the node/edge definitions.

### Orchestration: AgentTeam

```python
class AgentTeam:
    def __init__(
        self,
        orchestrator: str,  # model string for the coordinator
        agents: list[Agent],
        strategy: Literal["auto", "parallel"] = "auto",
    ): ...
    def run(self, task: str) -> TeamResult: ...
    async def arun(self, task: str) -> TeamResult: ...
```

In `"auto"` mode, the orchestrator agent receives the task plus a description of each available agent (name, instructions, tools). It decides which agent to delegate to by returning a structured routing decision. The team executor dispatches to the chosen agent, collects the result, and feeds it back to the orchestrator for synthesis or further delegation.

In `"parallel"` mode, all agents receive the task concurrently. Results are aggregated into a `TeamResult`.

`handoff(target_agent, context)` is a special tool automatically injected into each team agent. When called, it signals the executor to transfer control.

### Tracing

```python
@dataclass
class TraceSpan:
    name: str
    type: Literal["llm_call", "tool_call", "guard_check", "node_execution"]
    start_time: datetime
    end_time: datetime
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class Trace:
    spans: list[TraceSpan] = field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    total_latency_ms: float = 0.0

    def show(self) -> None: ...       # Opens browser with HTML timeline
    def export(self, path: str | None = None) -> str: ...  # Writes OTEL JSON

class TraceCollector:
    def start(self) -> None: ...
    def finalise(self) -> Trace: ...
    def record_span(self, span: TraceSpan) -> None: ...
    async def span(self, name: str, span_type: Literal[...], **extra_metadata: Any) -> AsyncGenerator[dict[str, Any], None]: ...
```

Tracing is automatic. The `Agent` creates a `TraceCollector` at the start of each run. The collector exposes two span-recording APIs: `record_span()` for pre-built spans, and an async `span()` context manager that times a block and yields a mutable metadata dict so callers can attach results (token counts, cost, etc.) discovered during execution. Every provider call, tool execution, and guard check creates a `TraceSpan`. At run completion, `collector.finalise()` aggregates token counts and cost from all `llm_call` spans, computes wall-clock latency, and returns a `Trace` object attached to `RunResult`.

If `SYNTH_TRACE_ENDPOINT` is set, the exporter sends traces via HTTP POST in OTEL format. Integration adapters (Langfuse, Datadog, Honeycomb) transform the trace into provider-specific formats.

### Checkpointing

```python
class BaseCheckpointStore(ABC):
    @abstractmethod
    async def save(self, run_id: str, state: Any, step: int) -> None: ...
    @abstractmethod
    async def load(self, run_id: str) -> Checkpoint | None: ...

class Checkpoint:
    run_id: str
    state: Any
    step: int
    node_name: str
    timestamp: datetime
```

`LocalCheckpointStore` writes JSON files to `.synth/checkpoints/{run_id}/`. `RedisCheckpointStore` uses Redis hashes. Both use atomic write patterns (write-to-temp-then-rename for local, Redis transactions for Redis).

### Evaluation

```python
class Eval:
    def __init__(self, agent: Agent): ...
    def add_case(self, input: str, expected: str | Any, checker: Callable | None = None) -> None: ...
    def run(self) -> EvalReport: ...
    async def arun(self) -> EvalReport: ...

class EvalReport:
    cases: list[EvalCaseResult]
    overall_score: float
    total_cost: float
    total_latency_ms: float

    def compare(self, baseline: EvalReport) -> EvalComparison: ...
```

#### Scorer System

Scorers implement a `BaseScorer` ABC with a single `score(output, expected) -> float` method:

```python
class BaseScorer(ABC):
    @abstractmethod
    def score(self, output: str, expected: Any) -> float: ...

class ExactMatchScorer(BaseScorer):
    """Binary 1.0 if stripped strings match, 0.0 otherwise."""
    def score(self, output: str, expected: Any) -> float: ...

class SemanticSimilarityScorer(BaseScorer):
    """Cosine similarity of embeddings via a user-provided embedder callable."""
    def __init__(self, embedder: Callable[[str], list[float]]) -> None: ...
    def score(self, output: str, expected: Any) -> float: ...

class CustomScorer(BaseScorer):
    """Wraps a user-provided checker(output, expected) -> float."""
    def __init__(self, checker: Callable[[str, Any], float]) -> None: ...
    def score(self, output: str, expected: Any) -> float: ...
```

Default scoring uses `ExactMatchScorer` (binary) and `SemanticSimilarityScorer` (cosine of embeddings). When a custom `checker` function is provided, it is wrapped in a `CustomScorer`. All scorers return a float between 0.0 and 1.0.

### Structured Output

```python
class StructuredOutputHandler:
    def __init__(self, schema: type[BaseModel], max_retries: int = 3): ...
    async def parse_and_validate(self, raw_output: str, provider: BaseProvider, messages: list[Message]) -> BaseModel: ...
```

The handler adds a system message instructing the model to output JSON conforming to the Pydantic schema's `model_json_schema()`. On parse failure, it appends a corrective message with the validation error and retries. After `max_retries`, it raises `SynthParseError`.

### AWS AgentCore Deployment

```python
@dataclass
class ResolvedCredentials:
    """Resolved AWS credential metadata (source + masked account ID only — no key values)."""
    source: str          # "env" | "aws_file" | "aws_toolkit" | "profile:<name>"
    account_id: str      # raw account ID (use mask_account_id() before display)
    profile_name: str | None = None

class CredentialResolver:
    """Detects AWS credentials from env vars, ~/.aws/credentials, and AWS Toolkit profiles.

    Credential values are NEVER stored as instance attributes. boto3 is imported lazily.
    """
    def resolve(self) -> ResolvedCredentials | None: ...
    def resolve_profile(self, profile_name: str) -> ResolvedCredentials | None: ...
    def mask_account_id(self, account_id: str) -> str: ...       # returns "****" + last 4
    def redact_credentials(self, text: str) -> str: ...          # replaces AKIA/ASIA + 40-char secrets

def agentcore_handler(agent_or_graph: Any) -> BedrockAgentCoreApp:
    """Wrap an Agent or Graph into an AgentCore-compatible handler using BedrockAgentCoreApp."""
    ...

class AgentCoreAdapter:
    def __init__(self, agent_or_graph: Any) -> None: ...
    def handle_invocation(self, payload: dict[str, Any]) -> dict[str, Any]: ...
    async def ahandle_invocation(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    @staticmethod
    def _extract_prompt(payload: dict[str, Any]) -> str: ...
```

`CredentialResolver.resolve()` checks sources in priority order: (1) `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` env vars, (2) `AWS_PROFILE` environment variable (set by IDE toolkits and shells), (3) `~/.aws/credentials` default profile, (4) `~/.aws/credentials` and `~/.aws/config` named profiles, (5) Active IDE toolkit (Kiro IdC token exchange via AWS SSO API), (6) AWS Toolkit VS Code extension profiles (`~/.aws/sso/cache/`). Each source is wrapped in `try/except`; exceptions are logged at `DEBUG` only and resolution continues to the next source. Credential key values are never stored — only the source label and account ID are retained in `ResolvedCredentials`. `redact_credentials()` replaces strings matching `(AKIA|ASIA)[A-Z0-9]{16}` and 40-character base64-like strings with `[REDACTED]`.

`agentcore_handler()` creates a `BedrockAgentCoreApp` instance and registers the Synth agent as an entrypoint using the `@app.entrypoint` decorator pattern required by the AgentCore runtime. This replaces the previous approach of returning a plain function. The function:
1. Imports `BedrockAgentCoreApp` from the `bedrock-agentcore` package (raises `SynthConfigError` if not installed)
2. Creates an app instance
3. Creates an `AgentCoreAdapter` for payload translation
4. Registers a handler function as the app's entrypoint
5. Stores references to the adapter and handler on the app for testing/debugging
6. Returns the configured `BedrockAgentCoreApp` instance

`AgentCoreAdapter` is the bridge between the AgentCore runtime and Synth agents/graphs. The sync `handle_invocation()` delegates to `ahandle_invocation()` via `_compat.run_sync()`. Payload extraction supports two shapes: `{"input": "text"}` / `{"input": {"text": "..."}}` and `{"prompt": "text"}`. Malformed payloads raise `SynthConfigError`.

The response format returned by `ahandle_invocation()` is:
```python
{
    "output": {"text": result.text},
    "metadata": {
        "tokens": {"input": ..., "output": ..., "total": ...},
        "cost": ...,
        "latency_ms": ...,
    },
}
```

Manifest generation lives in a separate `AgentCoreManifest` class in `deploy/agentcore/manifest.py` rather than on the adapter itself, keeping the adapter focused on payload translation.

The AgentCore deployment integration provides:
1. Payload translation between AgentCore invocation format and Synth's `run()` input format
2. Agent/graph execution
3. Response translation from `RunResult` back to AgentCore's response format
4. Integration with AgentCore's credential provider for AWS service access
5. Memory operations routing to AgentCore's managed memory when available
6. Trace forwarding to AgentCore's observability infrastructure

The `synth deploy --target agentcore` CLI command is implemented as a **Deploy_Wizard** — a sequential stage runner in `synth/cli/deploy_cmd.py`. It reads `agentcore.yaml` for `aws_profile`, `aws_region`, and `model_id`, then executes six stages in order, halting on the first failure:

```python
@dataclass
class StageResult:
    success: bool
    message: str
    suggestion: str | None = None
    data: Any = field(default=None, repr=False)

def _print_stage_result(stage_name: str, result: StageResult, *, dry_run: bool = False) -> None:
    """Prints [  OK  ] or [FAIL] with optional [DRY RUN] prefix."""
    ...

def run_deploy(target: str, dry_run: bool, file: str | None) -> None:
    """Orchestrates the six-stage Deploy_Wizard."""
    ...
```

Before stages run, `run_deploy()` performs two environment setup steps:
1. Injects `AWS_PROFILE` and `AWS_DEFAULT_REGION` into `os.environ` (via `setdefault`) from `agentcore.yaml` so boto3 sessions created during agent loading pick up the right profile and region.
2. Loads the project `.env` file (if present, at `<agent_dir>/.env`) via `_load_dotenv()` so API keys (e.g. `TAVILY_API_KEY`) are visible to readiness checks. The `.env` is never bundled in the deployment artifact — sensitive values must be set in the container environment separately (e.g. via `agentcore.yaml` `env_vars` or AWS Secrets Manager). `_load_dotenv()` is a minimal built-in parser that only sets variables not already present in the environment (`override=False` semantics), skips blank lines and comments, and never raises on parse errors.

Stage execution order:
1. `_stage_credentials(profile)` — validates AWS credentials via `CredentialResolver`; displays masked account ID and source
2. `_stage_dependencies()` — checks `synth[agentcore]` is importable
3. `_stage_validate_file(file)` — loads the agent from the specified Python file (looks for `module.agent` first, then falls back to the first `Agent` instance in the module)
4. `_stage_manifest(agent)` — generates the AgentCore manifest via `generate_manifest()`
4b. `_stage_dockerfile_validation(agent_name, file)` — validates the agent name matches a folder under `.bedrock_agentcore/`; skipped when the directory does not exist
5. `_stage_package(agent, dry_run)` — packages the deployment artifact (skipped in dry-run)
6. `_stage_readiness(agent, region, profile)` — reports on auth method, memory, guards, tools, search API keys, and target region/model with warnings for missing components
7. `_stage_submit(manifest, region, model_id, dry_run)` — submits to the AgentCore API via boto3 (skipped in dry-run)

In `--dry-run` mode, only stages 1–4 run and all output is prefixed with `[DRY RUN]`. On full success, the wizard prints a summary with the agent ARN, deployed region, and model ID.

`_read_agentcore_yaml(file)` reads `agentcore.yaml` from the same directory as the agent file. It uses PyYAML if available, falling back to a minimal `_parse_yaml_minimal()` line-by-line parser for environments without PyYAML installed.

The deployment configuration file (`agentcore.yaml`) provides a declarative specification for:
- Agent metadata (name, description)
- AWS region
- IAM permissions (least-privilege list)
- Runtime configuration (memory, timeout)
- Environment variables (non-sensitive values only; sensitive values use AWS Secrets Manager)

This structured approach replaces environment variable templates and makes deployment requirements explicit, auditable, and version-controllable.

### Deployment Packager

The `package()` function in `synth/deploy/packager.py` bundles agent source code, dependencies, and the generated manifest into a deployment artifact directory under `output_dir`.

```python
def package(
    agent_or_graph: Any,
    *,
    source_dir: str = ".",
    output_dir: str = "dist",
    dry_run: bool = False,
    name: str | None = None,
    description: str | None = None,
    permissions: list[str] | None = None,
) -> dict[str, Any]: ...
```

**Credential security scan** — before copying any files, the packager reads `agentcore.yaml` (if present) and scans it for AWS credential patterns using two compiled regexes:

```python
_AWS_ACCESS_KEY_RE = re.compile(r"(?:AKIA|ASIA)[A-Z0-9]{16}")
_AWS_SECRET_KEY_RE = re.compile(r"[A-Za-z0-9+/]{40}")
```

If either pattern matches, the packager raises `SynthConfigError(component="Packager")` with a suggestion to remove the credential values and use `aws_profile` instead. This check is implemented in the private helper `_scan_for_credentials(text: str) -> bool`.

**Excluded paths** — the following directories and files are never copied into the artifact, regardless of their presence in `source_dir`:

```python
_EXCLUDED = {
    ".env", ".synth", ".hypothesis", ".pytest_cache",
    "__pycache__", ".git", ".venv", "venv",
}
```

`.env` files are excluded unconditionally to prevent accidental credential leakage. The output directory itself is also excluded to prevent recursive self-copy.

In `--dry-run` mode, the packager generates and returns the manifest but skips all file I/O and the credential scan (validation only).

### CLI

The CLI uses `click` for command parsing. Commands:

| Command | Description |
|---------|-------------|
| `synth dev <file>` | Start rich TUI (falls back to basic REPL) |
| `synth run <file> "prompt"` | Execute agent, print result |
| `synth eval <file> --dataset <json>` | Run evaluation suite |
| `synth trace <run_id>` | Open trace in browser |
| `synth deploy --target agentcore` | Deploy to AgentCore |
| `synth doctor` | Check env, credentials, deps |
| `synth create agent <name>` | Scaffold agent project with provider selection |
| `synth create tool <name>` | Create standalone tools file |
| `synth create mcp <name>` | Scaffold MCP server project |
| `synth create team <name>` | Create multi-agent team project |
| `synth create ui <name>` | Scaffold local testing UI |

#### Agent Loading (`_load_agent`)

The `_load_agent(file)` function in `run_cmd.py` is the shared agent loader used by `synth run`, `synth dev` (via `_tui.py`), `synth deploy`, and the UI server. It imports a Python file and returns an `Agent` instance using the following lookup order:

1. Prepend the agent file's parent directory to `sys.path` (guarded by `if agent_dir not in sys.path`) so sibling imports (e.g. `from tools import ...`) resolve correctly.
2. Execute the module via `importlib.util`.
3. Return `module.agent` if the module defines an `agent` variable.
4. Fall back to scanning `dir(module)` for the first `Agent` instance — this supports multi-agent projects where the variable is named after the agent (e.g. `molly_mikes = Agent(...)`).
5. Exit with an error if neither an `agent` variable nor any `Agent` instance is found.

```python
def _load_agent(file: str) -> Agent:
    """Import a Python file and return the agent instance.

    Lookup order:
    1. module.agent (conventional name)
    2. First Agent instance found in module (multi-agent support)
    """
```

#### Doctor Command Implementation

The `synth doctor` command performs comprehensive environment diagnostics:

1. **Python version check**: Validates Python 3.10+ requirement
2. **Core dependencies**: Verifies `pydantic`, `httpx`, `click` are installed with version info
3. **Provider credentials**: Checks for `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GOOGLE_API_KEY` environment variables
4. **Trace endpoint validation**: If `SYNTH_TRACE_ENDPOINT` is set, validates HTTPS usage
5. **Optional provider packages**: Detects which provider extras are installed (`anthropic`, `openai`, `google.genai`, `boto3`)
6. **AWS credentials**: Checks for AWS credentials via environment variables or `~/.aws/credentials` file

The command uses color-coded status indicators:
- `[  OK  ]` (green) for passing checks
- `[FAIL]` (red) for critical issues that need fixing
- `[INFO]` (yellow) for optional/informational items

When missing provider packages are detected, the command provides actionable installation suggestions:
- Quick install all: `pip install synth-agent-sdk[all]`
- Individual installs: Lists specific extras like `synth[anthropic]`, `synth[openai]`, etc.

Exit behavior: Returns exit code 0 if no critical issues found, otherwise reports the issue count.

#### Create Command Implementation

The `synth create` command group provides interactive project scaffolding:

**`synth create agent <name> --provider <provider>`**

Scaffolds a complete agent project with provider-specific configuration. Supported providers:
- `anthropic` — Claude models (default)
- `openai` — GPT models
- `llama` — Local Llama via Ollama
- `gemini` — Google Gemini models
- `agentcore` — AWS AgentCore deployment-ready project

For standard providers, generates:
- `agent.py` — Agent implementation with sample tools
- `README.md` — Setup and usage instructions

For AgentCore provider, generates:
- `agent.py` — Agent with `agentcore_handler()` wrapper that returns a `BedrockAgentCoreApp` instance
- `requirements.txt` — Python dependencies including `synth-agent-sdk[agentcore]>=0.6.0`
- `agentcore.yaml` — Deployment configuration with:
  - Agent metadata (name, description)
  - AWS configuration (region, model ID, CRIS flag, optional profile name)
  - IAM permissions (least-privilege, commented examples)
  - Runtime settings (memory, timeout)
  - Environment variables (non-sensitive only)
- `README.md` — Comprehensive deployment guide

The AgentCore configuration file (`agentcore.yaml`) replaces the previous `.env` template approach, providing a structured, declarative way to specify deployment requirements. This aligns with infrastructure-as-code best practices and makes IAM permissions explicit and auditable.

**`synth create tool <name>`**

Creates a standalone tools file with example sync and async tool implementations.

**`synth create mcp <name>`**

Scaffolds an MCP (Model Context Protocol) server using FastMCP, with sample tools and resources.

**`synth create team <name>`**

Creates a multi-agent system with both team orchestration (`team.py`) and sequential pipeline (`pipeline.py`) examples.

**`synth create ui <name>`**

Scaffolds a local testing UI with FastAPI backend and web dashboard for interactive agent testing.

#### Multi-Agent Init Flow

The `synth init` command supports a multi-agent project mode. The wizard uses two result dataclasses to carry output from the tool and MCP sub-wizards:

```python
@dataclass
class ToolWizardResult:
    """Result from the tool creation wizard."""
    tools_code: str = ""
    agent_imports: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)
    env_vars: dict[str, str] = field(default_factory=dict)

@dataclass
class McpWizardResult:
    """Result from the MCP server creation wizard."""
    server_dir: str = ""
    server_code: str = ""
    agent_mcp_registration: str = ""
    files_created: list[str] = field(default_factory=list)
```

`ToolWizardResult.env_vars` collects environment variables discovered during the wizard (e.g. API keys for web search providers). These are written to `.env` in the generated project directory.

When the user selects "Multiple agents" at the project type fork, the wizard collects per-agent configuration and orchestration settings using the following dataclasses defined in `synth/cli/init_cmd.py`:

```python
@dataclass
class AgentConfig:
    """Configuration for a single agent in a multi-agent project."""
    name: str
    description: str
    provider: str
    provider_cfg: dict[str, str]
    model: str
    instructions: str
    tool_result: ToolWizardResult
    mcp_result: McpWizardResult
    is_agentcore: bool = False
    agentcore_state: dict[str, Any] = field(default_factory=dict)

@dataclass
class PipelineConfig:
    """Pipeline-specific orchestration configuration."""
    agent_order: list[str] = field(default_factory=list)

@dataclass
class EdgeConfig:
    """A single edge in a Graph configuration."""
    source: str
    target: str  # Agent name or "END"
    condition: str | None = None

@dataclass
class GraphConfig:
    """Graph-specific orchestration configuration."""
    entry_node: str = ""
    edges: list[EdgeConfig] = field(default_factory=list)

@dataclass
class AgentTeamConfig:
    """AgentTeam-specific orchestration configuration."""
    strategy: str = "auto"  # "auto" or "parallel"
    orchestrator_model: str = ""

@dataclass
class HumanInLoopConfig:
    """Human-in-the-Loop configuration (extends GraphConfig)."""
    graph: GraphConfig = field(default_factory=GraphConfig)
    pause_nodes: list[str] = field(default_factory=list)
    timeout: float | None = None
    fallback_node: str | None = None

@dataclass
class OrchestrationConfig:
    """Top-level orchestration configuration."""
    pattern: str = ""  # "pipeline", "graph", "agent_team", "human_in_loop"
    pipeline: PipelineConfig | None = None
    graph: GraphConfig | None = None
    agent_team: AgentTeamConfig | None = None
    human_in_loop: HumanInLoopConfig | None = None
```

When the user opts to share provider/model/tools across all agents, the wizard captures those values in a `SharedMultiAgentConfig` and forwards them to each agent during the configuration loop, skipping redundant prompts:

```python
@dataclass
class SharedMultiAgentConfig:
    """Shared configuration applied to all agents in a multi-agent project."""
    share_provider: bool = False
    provider: str = ""
    provider_cfg: dict[str, str] = field(default_factory=dict)
    model: str = ""
    is_agentcore: bool = False
    agentcore_state: dict[str, Any] = field(default_factory=dict)

    share_tools: bool = False
    tool_result: ToolWizardResult = field(default_factory=ToolWizardResult)
    mcp_result: McpWizardResult = field(default_factory=McpWizardResult)
```

These are internal CLI data models used only during the init wizard flow. They mirror the orchestration patterns from `synth/orchestration/` but are scoped to project scaffolding configuration, not runtime execution. `AgentConfig` holds per-agent wizard results including references to `ToolWizardResult` and `McpWizardResult` from the existing tool/MCP wizards. `OrchestrationConfig` uses a tagged-union style where `pattern` selects which sub-config is populated.

#### Orchestration Configuration Functions

Each orchestration pattern has a dedicated configuration function called during the multi-agent init flow:

- `_configure_pipeline(agents)` — prompts for agent execution order
- `_configure_graph(agents)` — prompts for entry node and edge definitions with conditions
- `_configure_agent_team(agents, shared=None)` — prompts for strategy ("auto" or "parallel") and orchestrator model. When a `SharedMultiAgentConfig` is provided and `share_provider` is `True`, the function offers to reuse the shared model for the orchestrator, returning an `AgentTeamConfig` with the shared model without prompting for full provider/model selection. If the user declines or no shared config is available, the full orchestrator model selection flow runs.
- `_configure_human_in_loop(agents)` — prompts for graph edges, pause nodes, timeout, and fallback

### Dev Command Architecture

The `synth dev` command uses a two-tier architecture:

1. `dev.py` is the entry point. It attempts to import `_tui.launch_tui` and delegates to the rich TUI. If the import fails, it falls back to `_run_basic_repl()`.
2. `_tui.py` implements a Fallout-inspired terminal interface using `rich` and `prompt_toolkit`. Features include streaming token-by-token rendering, slash commands (`/tools`, `/reload`, `/trace`, `/clear`, `/export`, `/help`), tool call visualisation with spinners, a persistent status bar (model, tokens, cost, latency), Markdown rendering, command history, and multi-line input via backslash continuation.
3. The basic REPL fallback (`_run_basic_repl` in `dev.py`) provides a minimal `click.prompt` loop with agent loading, prompt execution, and error display.

The TUI dependencies (`rich`, `prompt_toolkit`) are included in the core package dependencies.

### Terminal Branding (Boot Sequence)

The boot sequence is implemented in `cli/banner.py`. It uses a state machine:

1. Check `SYNTH_NO_BANNER` env var → skip if set
2. Check if already displayed this session (module-level flag) → skip if true
3. Detect terminal capabilities: width (`shutil.get_terminal_size()`, default 80), colour support (`NO_COLOR` env var, `sys.stdout.isatty()`)
4. Render elements in order with randomised delays (40–120ms via `random.uniform()` + `time.sleep()`)
5. Apply flicker effect on the ERROR line (3 rapid bold toggles using ANSI escape codes)
6. Set session flag to prevent re-display

The displayed version string is resolved dynamically at runtime via `importlib.metadata.version("synth-agent-sdk")`, wrapped in a `try/except` that falls back to `"unknown"` if the package metadata is unavailable (e.g., in editable installs without metadata). This replaces the previous hardcoded version literal.

### Sync/Async Compatibility

The `_compat` module provides:

```python
def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine from a sync context, handling existing event loops."""
    ...
```

This detects whether an event loop is already running (e.g., in Jupyter notebooks) and uses `nest_asyncio` or creates a new loop accordingly. All sync methods (`run`, `stream`) delegate to their async counterparts through this bridge.

## Data Models

### Core Types

```python
@dataclass
class RunResult:
    text: str                          # Model's text response
    output: BaseModel | None           # Parsed structured output (if schema set)
    tokens: TokenUsage                 # Input/output/total token counts
    cost: float                        # Estimated cost in USD
    latency_ms: float                  # Total wall-clock time
    trace: Trace                       # Full execution trace
    tool_calls: list[ToolCallRecord]   # Record of all tool invocations

@dataclass
class TokenUsage:
    input_tokens: int
    output_tokens: int
    total_tokens: int

@dataclass
class ToolCallRecord:
    name: str
    args: dict
    result: Any
    latency_ms: float
```

### Stream Event Types

```python
@dataclass
class TokenEvent:
    text: str

@dataclass
class ToolCallEvent:
    name: str
    args: dict

@dataclass
class ToolResultEvent:
    name: str
    result: Any

@dataclass
class ThinkingEvent:
    text: str

@dataclass
class DoneEvent:
    result: RunResult

@dataclass
class ErrorEvent:
    error: Exception

StreamEvent = TokenEvent | ToolCallEvent | ToolResultEvent | ThinkingEvent | DoneEvent | ErrorEvent

@dataclass
class StageEvent:
    stage_name: str
    event: StreamEvent
```

### Error Types

```python
class SynthError(Exception):
    """Base error for all Synth SDK errors."""
    component: str
    suggestion: str

class SynthConfigError(SynthError): ...
class ToolDefinitionError(SynthError): ...
class ToolExecutionError(SynthError):
    tool_name: str
    tool_args: dict
    original_error: Exception

class GuardViolationError(SynthError):
    guard_name: str
    violating_content: str
    remediation: str

class CostLimitError(GuardViolationError): ...
class SynthParseError(SynthError): ...
class GraphRoutingError(SynthError):
    node_name: str
    current_state: Any

class GraphLoopError(SynthError):
    node_history: list[str]
    max_iterations: int

class RunNotFoundError(SynthError):
    run_id: str

class PipelineError(SynthError):
    failed_step: int
    agent_name: str
    partial_results: list[RunResult]
```

### Orchestration Types

```python
@dataclass
class TeamResult:
    answer: str                        # Final synthesised answer
    contributions: list[AgentContribution]
    message_trace: list[Message]
    total_cost: float
    total_latency_ms: float

@dataclass
class AgentContribution:
    agent_name: str
    result: RunResult

@dataclass
class PausedRun:
    run_id: str
    paused_at_node: str
    state: Any
    checkpoint: Checkpoint

    def resume(self, human_input: Any = None) -> RunResult | PausedRun: ...
    async def aresume(self, human_input: Any = None) -> RunResult | PausedRun: ...

@dataclass
class Checkpoint:
    run_id: str
    state: Any
    step: int
    node_name: str
    timestamp: datetime
```

### Guard Types

```python
@dataclass
class GuardContext:
    cumulative_cost: float
    tool_calls: list[str]
    run_id: str | None

@dataclass
class GuardResult:
    passed: bool
    violation_message: str | None = None
```

### Evaluation Types

```python
@dataclass
class EvalCaseResult:
    input: str
    expected: Any
    actual: Any
    score: float
    passed: bool
    latency_ms: float
    cost: float

@dataclass
class EvalComparison:
    regressions: list[EvalCaseResult]
    improvements: list[EvalCaseResult]
    unchanged: list[EvalCaseResult]
    baseline_score: float
    current_score: float
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Tool schema generation round-trip

*For any* Python function with complete type annotations and a docstring, applying the `@tool` decorator and extracting the generated JSON schema should produce a schema whose parameter names, types, and descriptions match the original function signature.

**Validates: Requirements 2.1**

### Property 2: Tool registration completeness

*For any* collection of `@tool` functions and `ToolKit` instances passed to `Agent(tools=[...])`, every individual tool should be registered and available for invocation during a run, with the total registered tool count equal to the sum of all individual tools and all tools within each ToolKit.

**Validates: Requirements 2.2, 2.6**

### Property 3: Tool execution feeds result back into conversation

*For any* tool call requested by the model with valid arguments, the Agent should execute the corresponding function, and the return value should appear in the conversation messages sent back to the model.

**Validates: Requirements 2.3**

### Property 4: Tool execution error structure

*For any* tool function that raises an exception during execution, the resulting `ToolExecutionError` should contain the tool name, the exact arguments passed, and the original exception message.

**Validates: Requirements 2.4**

### Property 5: Tool definition validation at decoration time

*For any* Python function that is missing type annotations on any parameter or is missing a docstring, applying the `@tool` decorator should immediately raise a `ToolDefinitionError` without waiting for runtime invocation.

**Validates: Requirements 2.5**

### Property 6: Stream event type mapping

*For any* provider event during a streaming run, the Agent should yield the corresponding typed SDK event: text tokens produce `TokenEvent`, tool invocations produce `ToolCallEvent` followed by `ToolResultEvent`, and thinking tokens produce `ThinkingEvent`.

**Validates: Requirements 3.2, 3.3, 3.4**

### Property 7: DoneEvent is always the final stream event

*For any* successfully completed streaming run, the last event yielded by the generator should be a `DoneEvent` containing a complete `RunResult`.

**Validates: Requirements 3.5**

### Property 8: ErrorEvent on stream interruption

*For any* streaming run that encounters an exception, the Agent should yield an `ErrorEvent` containing the exception and then close the generator without hanging.

**Validates: Requirements 3.6**

### Property 9: Provider routing correctness

*For any* model string with a known provider prefix, the `ProviderRouter` should return an instance of the correct provider class corresponding to that prefix.

**Validates: Requirements 4.1**

### Property 10: Retry with exponential backoff

*For any* provider call that returns a transient error (HTTP 429 or 5xx), the system should retry up to `max_retries` times, with each retry delay being greater than the previous delay.

**Validates: Requirements 4.5**

### Property 11: Thread memory round-trip

*For any* sequence of messages added to a thread via `Memory.thread()`, retrieving messages for that `thread_id` should return all messages in the order they were added.

**Validates: Requirements 5.1, 5.2**

### Property 12: Memory truncation on context limit

*For any* thread whose total token count exceeds the model's context limit, the Memory should truncate or summarise older messages such that the resulting token count fits within the limit, and a `ContextTruncationWarning` should be emitted.

**Validates: Requirements 5.6**

### Property 13: Pipeline sequential data flow

*For any* Pipeline of N agents, calling `pipeline.run(input)` should result in agent[0] receiving the original input, and each subsequent agent[i] receiving agent[i-1]'s output text as its prompt.

**Validates: Requirements 6.1**

### Property 14: Pipeline error halts with partial results

*For any* Pipeline where the agent at step k raises an error, the Pipeline should return partial results from steps 0 through k-1, and the error should identify step k and the failing agent's name.

**Validates: Requirements 6.2**

### Property 15: Pipeline streaming labels events with stage name

*For any* streamed Pipeline run, every yielded event should be wrapped in a `StageEvent` containing the stage name of the agent that produced it.

**Validates: Requirements 6.3**

### Property 16: Graph conditional edge routing

*For any* Graph with conditional edges, the engine should traverse an edge only when its `when` condition evaluates to `True` for the current state, and should follow the correct path from entry node to termination.

**Validates: Requirements 7.1, 7.2**

### Property 17: Graph raises GraphRoutingError on dead end

*For any* Graph node where all outbound edge conditions evaluate to `False`, the Graph should raise a `GraphRoutingError` identifying the stuck node and the current state.

**Validates: Requirements 7.3**

### Property 18: Checkpoint persistence per step

*For any* checkpointed Graph or Pipeline execution, the number of persisted checkpoints should equal the number of completed steps, and each checkpoint should contain the correct state and step index.

**Validates: Requirements 7.4, 13.1**

### Property 19: Graph termination at Graph.END

*For any* Graph execution that reaches an edge targeting `Graph.END`, the execution should terminate and return the final state as the `RunResult`.

**Validates: Requirements 7.5**

### Property 20: Graph visualise contains all nodes and edges

*For any* Graph with N nodes and M edges, `graph.visualise()` should return a Mermaid diagram string that contains all N node names and represents all M edges.

**Validates: Requirements 7.7**

### Property 21: Pause/resume round-trip

*For any* Graph with human-in-the-loop configured at a node, pausing at that node and then resuming with input should produce a final result equivalent to what an uninterrupted execution with the same input at that decision point would produce.

**Validates: Requirements 8.2, 8.4**

### Property 22: Parallel team executes all agents

*For any* `AgentTeam` with `strategy="parallel"` and N agents, calling `team.run(task)` should invoke all N agents with the task and aggregate all N results.

**Validates: Requirements 9.3**

### Property 23: TeamResult contains all contributions

*For any* completed `AgentTeam` run, the `TeamResult` should contain one `AgentContribution` for each agent that participated, a non-empty message trace, and a synthesised answer.

**Validates: Requirements 9.6**

### Property 24: Trace completeness

*For any* completed `run()` or `stream()` call, the `RunResult.trace` should contain one span for each LLM call and one span for each tool call made during the run, with each span having valid timestamps, token counts, and cost values.

**Validates: Requirements 10.1**

### Property 25: Trace export produces valid OTEL JSON

*For any* Trace object, calling `trace.export()` should produce a JSON file that conforms to the OpenTelemetry trace data model, with all spans correctly represented.

**Validates: Requirements 10.3**

### Property 26: Eval scoring correctness

*For any* set of eval cases with string expected values, exact matches should score 1.0, and when a custom `checker` function is provided, the eval should use that function's return value as the score instead of the default scorer.

**Validates: Requirements 11.2, 11.3, 11.4**

### Property 27: Eval comparison identifies regressions and improvements

*For any* two `EvalReport` objects, `eval.compare(baseline)` should correctly classify each case as a regression (score decreased), improvement (score increased), or unchanged, and the counts should sum to the total number of cases.

**Validates: Requirements 11.5**

### Property 28: Eval CLI exit code reflects pass rate

*For any* evaluation run via the CLI, the exit code should be non-zero when the pass rate falls below the configured threshold and zero when it meets or exceeds the threshold.

**Validates: Requirements 11.6**

### Property 29: PII guard detects PII patterns

*For any* output string containing PII patterns (email addresses, phone numbers, SSNs), the `Guard.no_pii_output()` guard should raise a `GuardViolationError`, and for any output string without PII patterns, it should pass.

**Validates: Requirements 12.1**

### Property 30: Cost guard enforces limit

*For any* run where the cumulative cost exceeds the configured `max_cost` dollar amount, the `Guard.max_cost()` guard should raise a `CostLimitError`, and for any run under the limit, it should pass.

**Validates: Requirements 12.2**

### Property 31: Tool filter guard matches glob patterns

*For any* tool call name and any list of glob patterns, the `Guard.no_tool_calls()` guard should block the call if and only if the name matches at least one pattern via `fnmatch`.

**Validates: Requirements 12.3**

### Property 32: Custom guard invocation

*For any* custom guard function, the guard should raise `GuardViolationError` when the function returns `False` or raises an exception, and should pass when the function returns `True`.

**Validates: Requirements 12.4**

### Property 33: Guard evaluation order and short-circuit

*For any* ordered list of guards where the guard at index k fails, all guards at indices 0 through k should have been evaluated, no guard at index k+1 or beyond should have been evaluated, and the raised error should be from guard k.

**Validates: Requirements 12.6**

### Property 34: Checkpoint resume continues correctly

*For any* checkpointed Graph run that is interrupted and resumed via `graph.resume(run_id)`, execution should continue from the last completed step and the final result should be equivalent to an uninterrupted run.

**Validates: Requirements 13.2**

### Property 35: RunNotFoundError for missing checkpoint

*For any* `run_id` string that has no corresponding checkpoint in the store, calling `graph.resume(run_id)` should raise a `RunNotFoundError` containing that `run_id`.

**Validates: Requirements 13.3**

### Property 36: Error message structure

*For any* `SynthError` subclass instance, the error should contain non-empty values for: what went wrong (message), which component raised it (component field), and a suggested fix (suggestion field).

**Validates: Requirements 15.1**

### Property 37: GraphLoopError on max iterations

*For any* Graph execution that exceeds `max_iterations`, the Graph should raise a `GraphLoopError` containing the node execution history with length equal to `max_iterations`.

**Validates: Requirements 15.3**

### Property 38: Type mismatch warning for tool return values

*For any* tool whose return value type does not match its declared return annotation, the Agent should emit a warning containing the tool name, the expected type, and the actual type.

**Validates: Requirements 15.4**

### Property 39: Structured output Pydantic parsing

*For any* valid Pydantic model and any model output that is valid JSON conforming to that schema, the Agent should parse it into an instance of the Pydantic model, and `result.output` should be an instance of that model (not a raw string).

**Validates: Requirements 17.1**

### Property 40: Structured output retry on parse failure

*For any* model output that cannot be parsed into the specified Pydantic schema, the Agent should retry up to `max_retries` times with a corrective prompt. If all retries fail, a `SynthParseError` should be raised.

**Validates: Requirements 17.2**

### Property 41: Invalid model string raises SynthConfigError

*For any* model string that does not match any known provider prefix and has no `base_url` configured, the Agent should raise a `SynthConfigError` containing the invalid model string.

**Validates: Requirements 1.3**

### Property 42: RunResult contains all required fields

*For any* completed `agent.run()` call, the returned `RunResult` should have non-null values for `text`, `tokens` (with input_tokens, output_tokens, total_tokens), `cost`, `latency_ms`, and `trace`.

**Validates: Requirements 1.2**

### Property 43: Boot sequence monochrome in no-color mode

*For any* boot sequence rendered when `NO_COLOR` is set or stdout is not a TTY, the output should contain zero ANSI escape code sequences.

**Validates: Requirements 19.9**

### Property 44: Boot sequence display idempotence

*For any* process, calling the boot sequence display function twice should produce output only on the first call; the second call should produce no output.

**Validates: Requirements 19.10**

### Property 45: AgentCore manifest generation

*For any* Agent or Graph with a name, description, and tools, the generated AgentCore manifest should contain the agent's name, description, all declared tool/action names, and required IAM permissions.

**Validates: Requirements 20.3**

### Property 46: AgentCore payload translation round-trip

*For any* valid AgentCore invocation payload, translating it to Synth's `run()` input format and then translating the resulting `RunResult` back to AgentCore response format should preserve the essential content (prompt text in, response text out).

**Validates: Requirements 20.4**

## Error Handling

### Error Hierarchy

All SDK errors inherit from `SynthError`, which enforces the structure required by Requirement 15.1:

```
SynthError (base)
├── SynthConfigError          # Invalid config, missing keys, missing packages
├── ToolDefinitionError       # @tool decorator validation failures
├── ToolExecutionError        # Tool function runtime exceptions
├── GuardViolationError       # Guard constraint violations
│   └── CostLimitError        # Cost guard exceeded
├── SynthParseError           # Structured output parse failures
├── GraphRoutingError         # No matching edge condition
├── GraphLoopError            # Max iterations exceeded
├── RunNotFoundError          # Missing checkpoint for resume
└── PipelineError             # Pipeline step failure with partial results
```

### Error Construction Pattern

Every `SynthError` subclass must be constructed with:
- `message`: Human-readable description of what went wrong
- `component`: The SDK component that raised it (e.g., "ProviderRouter", "ToolExecutor", "CostGuard")
- `suggestion`: Actionable fix instruction

Example:
```python
raise SynthConfigError(
    message=f"Model string '{model}' does not match any known provider",
    component="ProviderRouter",
    suggestion=f"Use one of: {', '.join(KNOWN_PREFIXES)}. Or pass base_url for custom endpoints."
)
```

### Error Handling Strategy by Layer

| Layer | Error Type | Behavior |
|-------|-----------|----------|
| Provider | Transient (429, 5xx) | Retry with exponential backoff up to `max_retries` |
| Provider | Auth (401, 403) | Raise `SynthConfigError` immediately with env var name |
| Provider | Other | Raise `SynthConfigError` with provider-specific details |
| Tool Executor | Any exception | Wrap in `ToolExecutionError` with tool name + args |
| Tool Decorator | Missing annotations/docstring | Raise `ToolDefinitionError` at decoration time |
| Guards | Violation | Raise `GuardViolationError` with guard name + content |
| Graph | No matching edge | Raise `GraphRoutingError` with node + state |
| Graph | Loop detected | Raise `GraphLoopError` with node history |
| Pipeline | Step failure | Raise `PipelineError` with step index + partial results |
| Structured Output | Parse failure after retries | Raise `SynthParseError` with schema + raw output |
| Checkpoint | Missing run_id | Raise `RunNotFoundError` with the ID |

### Warning System

Non-fatal issues emit Python `warnings.warn()`:
- `ContextTruncationWarning`: Memory truncated older messages
- `TypeMismatchWarning`: Tool return type doesn't match annotation
- `DeprecationWarning`: For deprecated API usage

## Testing Strategy

### Testing Framework

- **Test runner**: `pytest` with `pytest-asyncio` for async tests
- **Property-based testing**: `hypothesis` library (Python's standard PBT library)
- **Mocking**: `unittest.mock` + custom `MockProvider` for provider isolation
- **Coverage**: `pytest-cov` targeting ≥90% line coverage on core + orchestration modules

### Dual Testing Approach

The test suite uses both unit tests and property-based tests:

- **Unit tests**: Verify specific examples, edge cases, integration points, and error conditions
- **Property tests**: Verify universal properties across randomly generated inputs using Hypothesis

### Property-Based Test Configuration

- Each property test runs a minimum of 100 examples (`@settings(max_examples=100)`)
- Each test is tagged with a comment referencing the design property:
  ```python
  # Feature: synth-agent-sdk, Property 1: Tool schema generation round-trip
  ```
- Each correctness property maps to a single `@given` test function
- Hypothesis strategies generate random function signatures, model strings, tool names, graph structures, etc.

### Mock Provider

A `MockProvider` class implements `BaseProvider` and returns configurable responses without making live API calls. This enables:
- Full CI without API keys (NFR-3.2)
- Deterministic testing of agent behavior
- Simulation of error conditions (rate limits, auth failures, malformed responses)

### Test Organization

```
tests/
├── unit/
│   ├── test_agent.py
│   ├── test_tools.py
│   ├── test_providers.py
│   ├── test_memory.py
│   ├── test_guards.py
│   ├── test_pipeline.py
│   ├── test_graph.py
│   ├── test_team.py
│   ├── test_tracing.py
│   ├── test_eval.py
│   ├── test_structured_output.py
│   ├── test_checkpointing.py
│   ├── test_errors.py
│   ├── test_banner.py
│   └── test_agentcore.py
├── property/
│   ├── test_tool_schema_props.py        # Properties 1-5
│   ├── test_streaming_props.py          # Properties 6-8
│   ├── test_provider_props.py           # Properties 9-10, 41-42
│   ├── test_memory_props.py             # Properties 11-12
│   ├── test_pipeline_props.py           # Properties 13-15
│   ├── test_graph_props.py              # Properties 16-21, 34-35, 37
│   ├── test_team_props.py               # Properties 22-23
│   ├── test_tracing_props.py            # Properties 24-25
│   ├── test_eval_props.py               # Properties 26-28
│   ├── test_guard_props.py              # Properties 29-33
│   ├── test_error_props.py              # Property 36
│   ├── test_structured_output_props.py  # Properties 39-40
│   ├── test_banner_props.py             # Properties 43-44
│   ├── test_tool_warnings_props.py      # Property 38
│   └── test_agentcore_props.py          # Properties 45-46
└── conftest.py                          # Shared fixtures, MockProvider, Hypothesis strategies
```

### Key Hypothesis Strategies

Custom strategies needed for property tests:
- `tool_functions()`: Generates random Python functions with type annotations and docstrings
- `model_strings()`: Generates valid and invalid model string prefixes
- `message_sequences()`: Generates random conversation message lists
- `graph_structures()`: Generates random DAGs with nodes and conditional edges
- `pydantic_models()`: Generates random Pydantic model classes
- `pii_strings()` / `non_pii_strings()`: Generates strings with/without PII patterns
- `glob_patterns()` / `tool_names()`: Generates glob patterns and tool names for guard testing
- `eval_reports()`: Generates random EvalReport pairs for comparison testing
- `agentcore_payloads()`: Generates random AgentCore invocation payloads
