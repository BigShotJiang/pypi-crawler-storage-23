# Implementation Plan: AgentCore Evaluations Integration

## Overview

Add AgentCore Evaluations configuration generation to the `synth init` flow and evaluation result display to the Dashboard's AgentCore observability tab. This builds on the existing `_build_agentcore_yaml` and `_generate_project` functions in `init_cmd.py`, and the existing server endpoints in `server.py`.

## Tasks

- [x] 1. Implement eval config generation functions in init_cmd.py
  - [x] 1.1 Add `_build_eval_config()` function to `synth/cli/init_cmd.py`
    - Generate JSON string with `config_name`, `sampling_rate` (default 1.0), and three default evaluators (Builtin.Helpfulness, Builtin.Correctness, Builtin.GoalSuccessRate) each with id, arn, and level
    - Return valid JSON string
    - _Requirements: 13.1_

  - [x] 1.2 Add `_validate_evaluator_arns()` function to `synth/cli/init_cmd.py`
    - Accept list of ARN strings, return list of warning messages for ARNs not matching `arn:aws:bedrock-agentcore:::evaluator/Builtin.*`
    - Return empty list when all ARNs are valid
    - _Requirements: 13.7_

  - [x] 1.3 Write property test for eval config generation
    - **Property 1: eval_config.json contains required default evaluators**
    - **Validates: Requirements 13.1**

  - [x] 1.4 Write property test for evaluator ARN validation
    - **Property 5: Evaluator ARN validation detects invalid patterns**
    - **Validates: Requirements 13.7**

- [x] 2. Extend `_build_agentcore_yaml()` to support evaluations
  - [x] 2.1 Add optional `features` parameter to `_build_agentcore_yaml()` in `synth/cli/init_cmd.py`
    - When `"eval"` is in features, append an `evaluations:` section with `config_name`, `sampling_rate`, and `evaluators` list
    - When `"eval"` is in features, add evaluation IAM permissions: `bedrock-agentcore:CreateEvaluationConfig`, `bedrock-agentcore:RunEvaluation`, `bedrock-agentcore:GetEvaluationResults`, `logs:CreateLogGroup`, `logs:PutLogEvents`
    - Maintain backward compatibility — existing callers without `features` produce unchanged output
    - _Requirements: 13.2, 13.3_

  - [x] 2.2 Write property test for agentcore.yaml eval section and permissions
    - **Property 2: agentcore.yaml includes evaluations section and IAM permissions when eval enabled**
    - **Validates: Requirements 13.2, 13.3**

- [x] 3. Wire eval config into project generation
  - [x] 3.1 Update `_generate_project()` in `synth/cli/init_cmd.py`
    - When provider is "agentcore" and "eval" in features: write `eval_config.json` via `_build_eval_config()`, pass `features` to `_build_agentcore_yaml()`, and call `_validate_evaluator_arns()` on the generated config
    - Continue writing `eval_dataset.json` for all providers when "eval" in features
    - Pass `features` list to `_build_agentcore_yaml()` call
    - _Requirements: 13.1, 13.5, 13.6_

  - [x] 3.2 Update `_generate_multi_agent_project()` in `synth/cli/init_cmd.py`
    - Apply same eval config generation logic as single-agent flow
    - Pass `features` list to `_build_agentcore_yaml()` call
    - _Requirements: 13.1, 13.5, 13.6_

  - [x] 3.3 Update `_build_agent_code()` (or equivalent code template) to add eval comment
    - When provider is "agentcore" and "eval" in features, add a comment block referencing `eval_config.json` and explaining AgentCore Evaluations is configured
    - _Requirements: 13.4_

  - [x] 3.4 Write property test for agent code eval comment
    - **Property 3: Agent code references eval_config.json when agentcore + eval enabled**
    - **Validates: Requirements 13.4**

  - [x] 3.5 Write property test for non-agentcore eval behavior
    - **Property 4: Non-agentcore providers produce no AgentCore evaluation config**
    - **Validates: Requirements 13.6**

- [x] 4. Checkpoint - Ensure all init flow tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Add evaluation data models and config parser to server
  - [x] 5.1 Add `EvaluationResult` and `EvaluationConfigStatus` dataclasses to `synth/cli/_ui_assets/server.py`
    - `EvaluationResult`: evaluator_name (str), score (float), level (str), timestamp (str)
    - `EvaluationConfigStatus`: config_name (str), active (bool), sampling_rate (float), evaluators (list[str])
    - _Requirements: 14.2, 14.5_

  - [x] 5.2 Add `_parse_eval_config()` function to `synth/cli/_ui_assets/server.py`
    - Read and parse `eval_config.json` from the agent file directory
    - Return parsed dict or None if file missing/invalid
    - Follow same pattern as existing `_parse_agentcore_yaml()`
    - _Requirements: 14.6_

- [x] 6. Add evaluation API endpoints to server
  - [x] 6.1 Add `GET /api/agentcore/evaluations` endpoint
    - Return evaluation scores from AgentCore Evaluations API via AgentCore_Client
    - Each result contains evaluator_name, score, level, timestamp
    - Apply credential scrubbing to all response data
    - Return empty list with appropriate message when not configured
    - _Requirements: 14.2, 14.6, 14.7_

  - [x] 6.2 Add `POST /api/agentcore/evaluations/run` endpoint
    - Accept evaluator selection in request body
    - Call AgentCore Evaluations API for on-demand evaluation against most recent session
    - Return results in same format as GET endpoint
    - Apply credential scrubbing
    - _Requirements: 14.4, 14.7_

  - [x] 6.3 Add `GET /api/agentcore/evaluations/config` endpoint
    - Return current online evaluation config status: config_name, active, sampling_rate, evaluators
    - Return null/not-configured response when eval_config.json is absent
    - Apply credential scrubbing
    - _Requirements: 14.5, 14.6, 14.7_

  - [x] 6.4 Write property test for evaluation results response shape
    - **Property 6: Evaluation results response contains all required fields**
    - **Validates: Requirements 14.2**

  - [x] 6.5 Write property test for evaluation config status response shape
    - **Property 7: Evaluation config status contains all required fields**
    - **Validates: Requirements 14.5**

  - [x] 6.6 Write property test for credential scrubbing on evaluation data
    - **Property 8: Credential scrubbing removes all credential patterns from evaluation data**
    - **Validates: Requirements 14.7**

- [x] 7. Checkpoint - Ensure all server tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Add Evaluations sub-section to Dashboard UI
  - [x] 8.1 Update `_parse_agentcore_yaml()` to include evaluations config detection
    - Extend the returned dict to include `evaluations_configured: bool` based on presence of evaluations section in agentcore.yaml or eval_config.json
    - _Requirements: 14.1, 14.6_

  - [x] 8.2 Update Requirement 8 sub-section list in AgentCore tab HTML
    - Add "Evaluations" sub-section to the AgentCore tab, conditionally shown when evaluations are configured
    - Render summary table for most recent evaluator scores with visual indicators for scores below 0.5 threshold
    - Show online evaluation config status (active/disabled, sampling rate, evaluator list)
    - Add "Run Evaluation" button wired to `POST /api/agentcore/evaluations/run`
    - Use existing green-on-dark CRT terminal theme
    - _Requirements: 14.1, 14.3, 14.5_

  - [x] 8.3 Write unit tests for Evaluations UI integration
    - Test that evaluations sub-section is hidden when not configured
    - Test that config endpoint returns correct shape
    - _Requirements: 14.1, 14.6_

- [x] 9. Update existing tests for backward compatibility
  - [x] 9.1 Update `TestBuildAgentcoreYaml` in `tests/unit/test_init_wizard.py`
    - Add tests verifying existing behavior unchanged when `features` param is omitted or empty
    - Add tests verifying evaluations section present when `features=["eval"]`
    - _Requirements: 13.2, 13.3_

  - [x] 9.2 Update `test_prop13_agentcore_yaml_round_trip` in `tests/property/test_prop_model_catalog.py`
    - Extend existing property test to cover the new `features` parameter
    - Verify round-trip still holds with evaluations section present
    - _Requirements: 13.2_

- [x] 10. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests use Hypothesis with minimum 100 iterations
- The `_build_agentcore_yaml` extension is backward-compatible — existing callers without `features` produce unchanged output
- Dashboard UI follows the existing green-on-dark CRT terminal theme
