# Design Document: Synth CLI Reliability Fixes

## Overview

This design addresses six reliability issues across the Synth CLI, UI server, Bedrock provider, and AgentCore deployment pipeline. The fixes are scoped to existing modules — no new packages or major architectural changes are introduced. Each fix targets a specific failure mode observed in real developer workflows.

The changes touch four areas of the codebase:
1. **Agent loading** (`run_cmd.py`, `_tui.py`) — centralize sys.path injection
2. **CLI commands** (`main.py`, `init_cmd.py`) — add `synth ui` command and venv-aware init launch
3. **UI server** (`server.py`) — pass thread_id for memory, true streaming, isinstance checks
4. **Provider / deploy** (`agent.py`, `bedrock.py`, `deploy_cmd.py`) — sanitize content blocks, validate Dockerfile folder names

## Architecture

```mermaid
graph TD
    subgraph CLI Layer
        A[synth dev] --> L[Agent_Loader]
        B[synth run] --> L
        C[synth ui] --> S[UI_Server subprocess]
        D[synth init] --> S
    end

    subgraph Agent Loading
        L --> P[sys.path injection]
        P --> M[importlib module load]
    end

    subgraph UI Server
        S --> AG[Agent.run / Agent.stream]
        S -->|thread_id| MEM[Memory backend]
    end

    subgraph Provider Layer
        AG --> BP[BedrockProvider]
        BP --> SAN[_sanitize_text]
        AG --> SAN2[Tool result sanitization]
    end

    subgraph Deploy Layer
        E[synth deploy] --> DW[Deploy_Wizard]
        DW --> MAN[Manifest generation]
        DW --> DFV[Dockerfile folder validation]
    end
```

All changes are backward-compatible. Existing agent files, UI configurations, and deployment workflows continue to work without modification.

## Components and Interfaces

### Component 1: Centralized Agent Loader (`synth/cli/run_cmd.py`)

The `_load_agent` function in `run_cmd.py` is already used by `synth run` and imported by `deploy_cmd.py`. It will be updated to prepend the agent file's parent directory to `sys.path` before executing the module, matching the pattern already used in `server.py` and `deploy_cmd.py`.

**Changes:**
- `_load_agent(file: str)` — add sys.path injection before `spec.loader.exec_module(module)`
- Guard against duplicate entries with an `if agent_dir not in sys.path` check

The TUI's `_load_agent_module` in `_tui.py` will also be updated with the same pattern for consistency.

**Interface (unchanged signature, updated lookup):**
```python
def _load_agent(file: str) -> Agent:
    """Import a Python file and return the agent instance.
    
    Prepends the agent file's parent directory to sys.path
    so sibling imports resolve correctly.

    Lookup order:
    1. Return ``module.agent`` if it exists.
    2. Fall back to the first ``Agent`` instance found via
       ``dir(module)`` — supports multi-agent projects where
       the variable is named after the agent (e.g.
       ``molly_mikes = Agent(...)``).
    3. Exit with an error if neither is found.
    """
```

### Component 2: `synth ui` CLI Command (`synth/cli/main.py`)

A new `synth ui` command that launches the UI server as a subprocess using `sys.executable`.

**Interface:**
```python
@cli.command("ui")
@click.argument("file", required=False, default=None)
def ui_cmd(file: str | None) -> None:
    """Launch the browser-based testing UI."""
```

**Behavior:**
1. If `file` is omitted, use the same discovery logic as `synth dev`
2. Set the `SYNTH_AGENT_FILE` environment variable for the subprocess
3. Launch: `subprocess.run([sys.executable, server_path], env=sub_env)`
4. Print the URL `http://localhost:8420` before launching
5. Catch `ImportError` for missing fastapi/uvicorn and print install instructions

The UI server's `AGENT_FILE` constant will be updated to read from `os.environ.get("SYNTH_AGENT_FILE", "../agent.py")` so the CLI can pass the agent path.

### Component 3: Venv-Aware Init Flow (`synth/cli/init_cmd.py`)

The `_prompt_testing_mode` function already uses `sys.executable` when launching the server subprocess (`subprocess.run([sys.executable, server_path])`). The current implementation is already venv-aware for the subprocess launch itself. The fix ensures the agent file path is passed via the `SYNTH_AGENT_FILE` environment variable so the server loads the correct agent, and adds a `_is_in_venv()` helper for clarity.

**Helper function:**
```python
def _is_in_venv() -> bool:
    """Return True if running inside a virtual environment."""
    return (
        sys.prefix != sys.base_prefix
        or os.environ.get("VIRTUAL_ENV") is not None
        or os.environ.get("CONDA_DEFAULT_ENV") is not None
    )
```

**Changes to `_prompt_testing_mode`:**
- Pass `SYNTH_AGENT_FILE` in the subprocess environment
- Use `sys.executable` consistently (already done, but ensure the env var is set)

### Component 4: UI Server Memory and Streaming Fixes (`synth/cli/_ui_assets/server.py`)

**4a. Memory — pass thread_id to agent:**

The streaming endpoint (`/api/chat/stream`) and non-streaming endpoint (`/api/chat`) currently call `_agent.run(prompt)` and `_agent.stream(prompt)` without a `thread_id`. The fix passes `thread_id=conv_id` so the agent's configured memory backend (including AgentCore Memory) handles history.

```python
# Before
result = _agent.run(prompt)
# After
result = _agent.run(prompt, thread_id=conv_id)
```

**4b. True streaming — use async generator instead of list():**

The current streaming path collects all events into a list before yielding:
```python
def _stream():
    return list(_agent.stream(prompt))
events = await loop.run_in_executor(None, _stream)
```

This defeats the purpose of streaming. The fix uses a queue-based approach (similar to `Agent.stream()`) to yield events as they arrive:

```python
import queue
import threading

def _stream_to_queue(q: queue.Queue) -> None:
    try:
        for event in _agent.stream(prompt, thread_id=conv_id):
            q.put(event)
    except Exception as exc:
        q.put(exc)
    finally:
        q.put(None)

q: queue.Queue = queue.Queue()
thread = threading.Thread(target=_stream_to_queue, args=(q,), daemon=True)
thread.start()

while True:
    item = q.get()
    if item is None:
        break
    if isinstance(item, Exception):
        raise item
    # yield SSE event for item
```

**4c. isinstance checks for event types:**

Replace string-based type checking:
```python
# Before
etype = type(event).__name__
if etype == "ThinkingEvent": ...
# After
from synth.types import ThinkingEvent, TokenEvent, ToolCallEvent, DoneEvent, ErrorEvent, ToolResultEvent
if isinstance(event, ThinkingEvent): ...
```

**4d. Tool initialization error surfacing:**

In `_load_agent()`, wrap tool registration in a try/except and store errors:
```python
_agent_status["tool_errors"] = []
# During load, catch tool init failures and append to tool_errors
```

Expose in `/api/info`:
```python
"tool_errors": _agent_status.get("tool_errors", [])
```

**4e. Agent file from environment:**

```python
AGENT_FILE = os.environ.get("SYNTH_AGENT_FILE", "../agent.py")
```

### Component 5: Content Block Sanitization (`synth/agent.py`, `synth/providers/bedrock.py`)

The `BedrockProvider._sanitize_text` method already exists and handles empty/None/whitespace text. The gap is in `agent.py` where tool results are appended to the message list as raw `str(result)` — if a tool returns an empty string, this becomes a blank content block.

**Fix in `agent.py` (both `arun` and `astream`):**

Add a module-level helper:
```python
def _sanitize_content(text: str) -> str:
    """Ensure message content is non-empty for provider APIs."""
    if not text or not text.strip():
        return "(no content)"
    return text
```

Apply it when appending tool results:
```python
# In arun tool loop
messages.append({
    "role": "tool",
    "content": _sanitize_content(str(result)),
    "tool_name": tc.name,
})

# In astream tool loop
messages.append(
    {"role": "tool", "content": _sanitize_content(str(result))},
)
```

This provides defense-in-depth: the agent layer sanitizes before the message reaches any provider, and the Bedrock provider's `_sanitize_text` provides a second safety net.

### Component 6: Dockerfile Folder Validation (`synth/cli/deploy_cmd.py`)

Add a new validation stage between manifest generation (Stage 4) and artifact packaging (Stage 5).

**New function:**
```python
def _stage_dockerfile_validation(
    agent_name: str,
    file: str,
) -> StageResult:
    """Validate that the agent name matches a .bedrock_agentcore/ folder."""
```

**Logic:**
1. Resolve `.bedrock_agentcore/` relative to the agent file's parent directory
2. If the directory doesn't exist, return success (skip validation)
3. List subdirectories in `.bedrock_agentcore/`
4. Check if any folder name matches the agent name (case-sensitive)
5. If no match, return failure with the available folder names as suggestions

## Data Models

No new data models are introduced. The existing `StageResult` dataclass is reused for the new Dockerfile validation stage. The `_agent_status` dict in `server.py` gains an optional `tool_errors` key (list of strings).

**Modified state in server.py:**
```python
_agent_status: dict[str, Any] = {
    "loaded": False,
    "error": None,
    "file": AGENT_FILE,
    "tool_errors": [],  # NEW: list of tool init error strings
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: sys.path injection ensures parent directory is present

*For any* valid agent file path, after the Agent_Loader processes the file, `sys.path` shall contain the agent file's parent directory.

**Validates: Requirements 1.1, 1.3**

### Property 2: sys.path injection is idempotent

*For any* agent file path, calling the sys.path injection logic multiple times shall not produce duplicate entries of the parent directory in `sys.path`. Formally: `count(sys.path, parent_dir)` after N calls equals `max(1, count_before_first_call)`.

**Validates: Requirements 1.2**

### Property 3: Venv detection correctness

*For any* combination of `sys.prefix`, `sys.base_prefix`, and `VIRTUAL_ENV` environment variable, the `_is_in_venv()` function shall return `True` if and only if `sys.prefix != sys.base_prefix` or `VIRTUAL_ENV` is set or `CONDA_DEFAULT_ENV` is set.

**Validates: Requirements 3.1**

### Property 4: Thread ID consistency across conversation turns

*For any* conversation ID passed to the UI server's chat endpoints, the `thread_id` passed to the agent's `run` or `stream` method shall equal the conversation ID, ensuring the same memory context is used across all turns of a conversation.

**Validates: Requirements 4.1, 4.2**

### Property 5: Tool result serialization completeness

*For any* `ToolCallRecord` with a name, args dict, result string, and latency value, the serialized output dict shall contain keys `name`, `args`, `result`, and `latency_ms` with values matching the input record.

**Validates: Requirements 4.6**

### Property 6: Content block sanitization

*For any* string that is empty, `None`, or composed entirely of whitespace characters, the `_sanitize_content` function shall return a non-empty string that contains at least one non-whitespace character.

**Validates: Requirements 5.1, 5.2, 5.3**

### Property 7: Agent name validation accepts only valid names

*For any* string, the AgentCore name validation regex `^[a-zA-Z][a-zA-Z0-9_]{0,47}$` shall accept the string if and only if it starts with a letter, contains only letters/numbers/underscores, and is 1–48 characters long.

**Validates: Requirements 6.1**

### Property 8: Dockerfile folder mismatch error includes all available folders

*For any* set of folder names in `.bedrock_agentcore/` and any agent name that does not match any folder, the error message shall contain every folder name from the set.

**Validates: Requirements 6.3**

### Property 9: Agent name sanitization produces valid names

*For any* non-empty input string, the `_sanitize_for_path` function shall return a string that matches the AgentCore naming pattern `^[a-zA-Z][a-zA-Z0-9_]{0,47}$`.

**Validates: Requirements 6.4**

## Error Handling

| Scenario | Component | Error Type | User-Facing Message |
|---|---|---|---|
| Agent file not found | Agent_Loader | `SystemExit(1)` | "Cannot load '{file}'." |
| Agent file missing `agent` variable or Agent instance | Agent_Loader | `SystemExit(1)` | "File '{file}' must define an 'agent' variable (or an Agent instance)." |
| Missing FastAPI/uvicorn for `synth ui` | CLI | `click.echo` + `sys.exit(1)` | "Missing dependencies. Install: pip install uvicorn fastapi" |
| Tool returns empty string to Bedrock | Agent / BedrockProvider | Sanitized silently | Content replaced with "(no content)" — no error raised |
| Agent name invalid for AgentCore | Deploy_Wizard | `StageResult(success=False)` | "Agent name '{name}' is invalid for AgentCore." with naming rules |
| Dockerfile folder mismatch | Deploy_Wizard | `StageResult(success=False)` | "Agent name '{name}' does not match any folder in .bedrock_agentcore/. Available: {folders}" |
| Tool init failure in UI server | UI_Server | Logged + surfaced in `/api/info` | Tool error details in `tool_errors` array |

All errors follow the SDK convention: `SynthError` subclasses for SDK-level errors, `click.echo` + `sys.exit(1)` for CLI-level errors, and `StageResult` for deploy wizard stages.

## Testing Strategy

### Unit Tests

Unit tests verify specific examples, edge cases, and integration points:

- **Agent Loader**: Test that `_load_agent` adds parent dir to sys.path; test with non-existent file; test duplicate prevention
- **`synth ui` command**: Test subprocess call uses `sys.executable`; test env var `SYNTH_AGENT_FILE` is set; test missing dependency error
- **Init flow**: Test `_prompt_testing_mode` passes `SYNTH_AGENT_FILE` in subprocess env
- **UI server memory**: Mock agent and verify `thread_id` is passed to `run()` and `stream()`
- **UI server streaming**: Verify events are yielded incrementally (not buffered)
- **UI server isinstance**: Test with actual `ThinkingEvent`, `TokenEvent` instances
- **Content sanitization**: Test empty string, None, whitespace, and normal strings
- **Dockerfile validation**: Test with matching folder, non-matching folder, missing directory
- **Agent name sanitization**: Test with special characters, provider prefixes, long strings

### Property-Based Tests

Property tests use Hypothesis to verify universal properties across generated inputs. Each property test runs a minimum of 100 iterations.

| Property | Test File | Generator Strategy |
|---|---|---|
| Property 1: sys.path injection | `tests/property/test_cli_reliability_props.py` | `st.text()` for file path segments |
| Property 2: sys.path idempotence | `tests/property/test_cli_reliability_props.py` | `st.integers(min_value=1, max_value=10)` for repeat count |
| Property 3: Venv detection | `tests/property/test_cli_reliability_props.py` | `st.booleans()` for prefix match, env var presence |
| Property 4: Thread ID consistency | `tests/property/test_cli_reliability_props.py` | `st.text(min_size=1)` for conversation IDs |
| Property 5: Tool result serialization | `tests/property/test_cli_reliability_props.py` | `st.text()` for name/result, `st.dictionaries()` for args, `st.floats()` for latency |
| Property 6: Content sanitization | `tests/property/test_cli_reliability_props.py` | `st.from_regex(r'^\s*$')` for whitespace, `st.text()` for general |
| Property 7: Agent name validation | `tests/property/test_cli_reliability_props.py` | `st.from_regex(r'^[a-zA-Z][a-zA-Z0-9_]{0,47}$')` for valid, `st.text()` for general |
| Property 8: Folder mismatch error | `tests/property/test_cli_reliability_props.py` | `st.lists(st.text(min_size=1))` for folder names |
| Property 9: Name sanitization | `tests/property/test_cli_reliability_props.py` | `st.text(min_size=1)` for input strings |

Each property test is tagged with: `# Feature: synth-cli-reliability-fixes, Property N: <title>`

The property-based testing library is **Hypothesis** (already used in the project via `tests/property/`). Each test runs with `@settings(max_examples=100)`.
