__version__ = "5.8.0"
dependencies = ["restnavigator==1.0.1",
                "requests[socks]==2.32.5",
                "configparser==5.3.0",
                "certifi==2026.1.4",
                "portalocker==2.10.1",
                "keyring==25.7.0"]
