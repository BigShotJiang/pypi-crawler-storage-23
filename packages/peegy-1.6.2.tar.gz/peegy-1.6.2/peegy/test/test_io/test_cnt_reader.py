import peegy.io.readers.cnt_reader as cntr
import matplotlib.pyplot as plt
import numpy as np
__author__ = 'jundurraga'

f_name = '/mnt/90720477720463F6/Measurements/Kristin_Uhler_MMN/MMN001HL/anmmnA_I70.cnt'
header = cntr.read_cnt_header(file_name=f_name)
ch = np.array([0, 1])
data, events, *_ = cntr.get_data(header=header, ini_time=0, end_time=None)
_events = events.get_events()
fs = header['fs']
x = np.arange(0, data.shape[0]) / fs
fig = plt.figure()
plt.plot(x, data - np.mean(data, axis=0))
plt.plot([_ev.time_pos.value for _ev in _events], [0 for _ev in _events], 'ro')
plt.show(block=True)
