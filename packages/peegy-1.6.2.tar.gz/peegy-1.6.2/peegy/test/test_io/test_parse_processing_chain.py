from peegy.io.external_tools.file_tools import parse_processing_chain
a = parse_processing_chain('/home/jundurraga/Documents/source_code/peegy/eeg_processing_tools/template.json')
