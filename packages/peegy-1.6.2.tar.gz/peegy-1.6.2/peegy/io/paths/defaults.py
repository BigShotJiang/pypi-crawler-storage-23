import pathlib
default_path = pathlib.Path.home().joinpath('peegy').joinpath('test')
