"""Entry point wrapper for early logging configuration and startup safety checks."""

from __future__ import annotations

import importlib
import sys
from collections.abc import Callable

from glaip_sdk.runner.logging_config import setup_cli_logging


def _load_cli_main() -> Callable[[], int | None]:
    """Load and return the click entrypoint callable."""
    cli_main = importlib.import_module("glaip_sdk.cli.main").main
    return cli_main


def _is_missing_tcss_asset(error: FileNotFoundError) -> bool:
    """Return True when startup failed because a packaged TCSS file is missing."""
    filename = error.filename or ""
    message = str(error)
    return (
        filename.endswith(".tcss")
        and "glaip_sdk" in filename
        and "cli" in filename
        and "slash" in filename
        and "tui" in filename
    ) or (".tcss" in message and "glaip_sdk" in message)


def _print_missing_tcss_guidance(error: FileNotFoundError) -> None:
    """Print user guidance for incomplete wheel installations."""
    missing_file = error.filename or str(error)
    message = (
        "glaip-sdk CLI startup failed because a bundled .tcss asset is missing.\n"
        f"Missing file: {missing_file}\n"
        "This usually means the installed package is incomplete.\n"
        "Try reinstalling:\n"
        "  uv tool install --force glaip-sdk\n"
        "  python -m pip install --upgrade --force-reinstall glaip-sdk\n"
        "If this version is broken, install the previous known-good release.\n"
    )
    sys.stderr.write(message)


def main() -> int:
    """Run the CLI entrypoint with startup diagnostics for packaging regressions."""
    setup_cli_logging()

    try:
        cli_main = _load_cli_main()
    except FileNotFoundError as error:
        if _is_missing_tcss_asset(error):
            _print_missing_tcss_guidance(error)
            return 1
        raise

    result = cli_main()
    return 0 if result is None else int(result)


if __name__ == "__main__":
    sys.exit(main())
