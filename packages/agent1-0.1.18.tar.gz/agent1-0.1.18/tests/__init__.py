"""Tests for log11."""
