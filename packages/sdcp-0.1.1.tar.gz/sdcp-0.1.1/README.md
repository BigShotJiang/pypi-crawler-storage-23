# SDCP

A simple Python framework for building SDCP (Secure Data Communication Protocol) servers, inspired by Flask.

## Installation

```bash
pip install sdcp
```

## Requirements

You need a running SDCP main authentication server that will be used by both the client and the server. The default server is mineflare.app:300. Please email `contact@mineflare.app` to create a server key.

## Quick Start

```python
from sdcp import SDCP, Request, Response, html

app = SDCP(
    server_id="YOUR-SERVER-ID",
    server_key="YOUR-SERVER-KEY",
    main_server_host="mineflare.app",
    main_server_port=300,
)

@app.route("/")
def index(request: Request) -> Response:
    return html("<head><title>Home</title></head><body><h1>Hello!</h1></body>")

@app.route("/about")
def about(request: Request) -> Response:
    return html("<head><title>About</title></head><body><h1>About</h1></body>")

@app.not_found
def not_found(request: Request) -> Response:
    return html(f"<h1>404 - {request.path} not found</h1>")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=299, debug=True)
```

## API Reference

### `SDCP(server_id, server_key, main_server_host, main_server_port)`

Creates an SDCP app instance.

| Parameter | Default | Description |
|---|---|---|
| `server_id` | `""` | This server's ID |
| `server_key` | `""` | This server's encryption key |
| `main_server_host` | `"127.0.0.1"` | Hostname of the main auth server |
| `main_server_port` | `300` | Port of the main auth server |

### `@app.route(path)`

Registers a handler for a given path. Use `*` at the end for wildcard matching.

```python
@app.route("/blog/*")
def blog(request: Request) -> Response:
    return html(f"<h1>Blog post: {request.path}</h1>")
```

### `@app.not_found`

Registers a custom 404 handler.

### `Request`

| Attribute | Description |
|---|---|
| `request.path` | The path requested by the client |
| `request.client_id` | The authenticated client's ID |

### `html(content)`

Helper to return an HTML response.

### `app.run(host, port, debug)`

Starts the server.

| Parameter | Default | Description |
|---|---|---|
| `host` | `"0.0.0.0"` | Interface to bind to |
| `port` | `299` | Port to listen on |
| `debug` | `False` | Print connection logs |
