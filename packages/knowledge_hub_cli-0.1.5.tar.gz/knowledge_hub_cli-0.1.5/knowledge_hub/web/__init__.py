from knowledge_hub.web.crawler import WebCrawler
