"""
knowledge-hub: AI paper discovery, translation, summarization & knowledge linking pipeline
"""

__version__ = "0.1.0"
__author__ = "knowledge-hub contributors"
