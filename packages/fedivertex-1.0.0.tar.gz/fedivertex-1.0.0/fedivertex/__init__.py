from .main import GraphLoader
from importlib.metadata import version

__version__ = version("fedivertex")
__license__ = "GPLv3"
