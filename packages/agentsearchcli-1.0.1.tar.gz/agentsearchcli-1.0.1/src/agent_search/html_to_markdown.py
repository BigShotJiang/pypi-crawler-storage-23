"""Compatibility shim — re-exports from agent_search.core.html_to_markdown."""
from agent_search.core.html_to_markdown import *  # noqa: F401,F403
from agent_search.core.html_to_markdown import HTMLToMarkdown, MarkdownCleaner, ConversionOptions, html_to_markdown  # noqa: F401
