"""Compatibility shim — re-exports from agent_search.core.nordvpn_proxy."""
from agent_search.core.nordvpn_proxy import *  # noqa: F401,F403
from agent_search.core.nordvpn_proxy import NordVpnProxy  # noqa: F401
