"""Compatibility shim — re-exports from agent_search.core.proxy_chain."""
from agent_search.core.proxy_chain import *  # noqa: F401,F403
from agent_search.core.proxy_chain import ProxyChain  # noqa: F401
