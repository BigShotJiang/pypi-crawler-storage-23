"""Compatibility shim — re-exports from agent_search.core.user_agents."""
from agent_search.core.user_agents import *  # noqa: F401,F403
from agent_search.core.user_agents import UserAgentRotator, get_user_agent_rotator, get_random_user_agent  # noqa: F401
