"""Compatibility shim — re-exports from agent_search.core.change_detector."""
from agent_search.core.change_detector import *  # noqa: F401,F403
from agent_search.core.change_detector import ChangeDetector, ChangeMonitor, ChangeResult, check_for_changes  # noqa: F401
