"""Agent Search core modules."""
