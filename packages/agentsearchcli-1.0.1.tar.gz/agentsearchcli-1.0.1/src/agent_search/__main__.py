"""
CLI entry point for Agent Search.
"""

import sys
from agent_search.cli.main import main

if __name__ == "__main__":
    sys.exit(main())
