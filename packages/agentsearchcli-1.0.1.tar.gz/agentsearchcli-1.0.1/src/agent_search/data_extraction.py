"""Compatibility shim — re-exports from agent_search.core.data_extraction."""
from agent_search.core.data_extraction import *  # noqa: F401,F403
from agent_search.core.data_extraction import StructuredExtractor, CSSExtractionStrategy, CSSFieldConfig, extract_with_css  # noqa: F401
