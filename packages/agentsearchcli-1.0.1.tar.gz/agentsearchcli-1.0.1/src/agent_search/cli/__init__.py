"""Agent Search CLI commands."""
