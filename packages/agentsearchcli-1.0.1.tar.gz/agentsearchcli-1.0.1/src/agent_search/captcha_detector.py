"""Compatibility shim — re-exports from agent_search.core.captcha_detector."""
from agent_search.core.captcha_detector import *  # noqa: F401,F403
from agent_search.core.captcha_detector import CaptchaDetector  # noqa: F401
