from django.db.models import Q

from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action
from rest_framework import permissions

from ichec_django_core.views import ObjectFileUploadView
from ichec_django_core.views.core import SearchableModelViewSet
from ichec_django_core.views.files import DEFAULT_IMAGE_FORMATS
from ichec_django_core.views.permissions import (
    PublicViewMemberEditOrDjangoModelPermissions,
    MemberEditOrDjangoModelPermissions,
)

from marinerg_facility.models import Facility, FacilityTag
from marinerg_facility.serializers import (
    FacilityListSerializer,
    FacilityDetailSerializer,
    FacilityPublicDetailSerializer,
    FacilityTagSerializer,
)


class FacilityViewSet(SearchableModelViewSet):

    model = Facility
    queryset = Facility.objects.filter(active=True)
    serializer_class = FacilityListSerializer
    permission_classes = [
        PublicViewMemberEditOrDjangoModelPermissions,
    ]
    ordering_fields = SearchableModelViewSet.ordering_fields + ("name",)
    ordering: tuple[str, ...] = ("name",)
    search_fields = ["name", "address__line1", "address__country", "address__region"]

    serializers = {
        "retrieve": FacilityDetailSerializer,
        "public_retrieve": FacilityPublicDetailSerializer,
        "list": FacilityListSerializer,
        "create": FacilityDetailSerializer,
        "update": FacilityDetailSerializer,
        "partial_update": FacilityDetailSerializer,
    }

    filterset_fields = ("members__id",)

    @action(detail=True, url_path="image", url_name="image")
    def image(self, request, pk=None):
        return self.download(request, "image")

    @action(detail=True, url_path="thumbnail", url_name="thumbnail")
    def thumbnail(self, request, pk=None):
        return self.download(request, "thumbnail")

    def get_queryset(self):
        """
        Public users can only see public Facilities
        Registered users can see pubic Facilities or ones they are members of
        Users with view permission can see all Facilities
        """

        queryset = ModelViewSet.get_queryset(self)

        if not self.request.user.is_authenticated:
            queryset = queryset.filter(public=True)
        elif not self.has_model_view_permission():
            queryset = queryset.filter(
                Q(public=True) | Q(members__id=self.request.user.id)
            ).distinct()

        return queryset


class FacilityTagViewSet(SearchableModelViewSet):
    queryset = FacilityTag.objects.all()
    serializer_class = FacilityTagSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]
    ordering_fields = ("value",)
    ordering: tuple[str, ...] = ("value",)
    search_fields = ["value"]
    filterset_fields = ("facilities__id",)


class FacilityImageUploadView(ObjectFileUploadView):
    model = Facility
    queryset = Facility.objects.all()
    file_field = "image"
    extensions = DEFAULT_IMAGE_FORMATS
    permission_classes = [
        permissions.IsAuthenticated,
        MemberEditOrDjangoModelPermissions,
    ]
