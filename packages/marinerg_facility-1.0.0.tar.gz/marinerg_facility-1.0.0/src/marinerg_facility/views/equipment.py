from django.db.models import Q

from rest_framework import permissions
from rest_framework.exceptions import PermissionDenied
from rest_framework.decorators import action
from rest_framework.viewsets import ModelViewSet

from ichec_django_core.views.files import ObjectFileUploadView, DEFAULT_IMAGE_FORMATS
from ichec_django_core.views.core import SearchableModelViewSet
from ichec_django_core.views.permissions import (
    get_permission,
    EditOrDjangoModelPermissions,
)

from marinerg_facility.models import EquipmentTag, Facility, Equipment
from marinerg_facility.serializers import EquipmentSerializer


class OrgMemberEditOrDjangoModelPermissions(EditOrDjangoModelPermissions):

    def object_perm_check(self, obj, request) -> bool:
        return request.user.id in [m.id for m in obj.factility.members.all()]


class PublicViewOrgMemberEditOrDjangoModelPermissions(EditOrDjangoModelPermissions):

    safe_methods: list = ["HEAD", "OPTIONS", "GET"]

    def has_permission(self, request, view):

        if request.method in self.safe_methods:
            return True
        else:
            if not self.has_authenticated_user(request):
                return False

        # Fall through to allow permission checks to happen at object level
        if self.method_handled_by_object(request.method):
            return True

        return super().has_permission(request, view)

    def object_perm_check(self, obj, request) -> bool:
        return request.user.id in [m.id for m in obj.factility.members.all()]


class EquipmentViewSet(SearchableModelViewSet):
    model = Equipment
    queryset = Equipment.objects.all()
    serializer_class = EquipmentSerializer
    permission_classes = [
        PublicViewOrgMemberEditOrDjangoModelPermissions,
    ]
    ordering_fields = SearchableModelViewSet.ordering_fields + ("name",)
    ordering: tuple[str, ...] = ("name",)
    search_fields = ["name"]
    filterset_fields = ("facility__id",)

    @action(detail=True, url_path="image", url_name="image")
    def image(self, request, pk=None):
        return self.download(request, "image")

    @action(detail=True, url_path="thumbnail", url_name="thumbnail")
    def thumbnail(self, request, pk=None):
        return self.download(request, "thumbnail")

    def check_field_permissions(self, request, serializer):
        is_facility_member = self._is_facility_member(
            serializer.validated_data["facility"], request.user.id
        )
        can_edit_facility = get_permission(Facility, "edit")

        if not (is_facility_member or can_edit_facility):
            raise PermissionDenied(
                detail="Permission to add Equipment to this Facility denied."
            )

    def _is_facility_member(self, facility: Facility, user_id: int) -> bool:
        return user_id in [m.id for m in facility.members.all()]

    def get_queryset(self):
        """
        Public users can only see public Facilities' Equipment
        Registered users can see public Equipment or ones for
        facilities they are members of
        Users with view permission can see all Equipment
        """

        queryset = ModelViewSet.get_queryset(self)

        if not self.request.user.is_authenticated:
            queryset = queryset.filter(facility__public=True)
        elif not self.has_model_view_permission():
            queryset = queryset.filter(
                Q(facility__public=True) | Q(facility__members__id=self.request.user.id)
            ).distinct()
        return queryset


class EquipmentTagViewSet(SearchableModelViewSet):
    queryset = EquipmentTag.objects.all()
    serializer_class = EquipmentSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]
    ordering_fields = ("value",)
    ordering: tuple[str, ...] = ("value",)
    search_fields = ["value"]
    filterset_fields = ("equipment__id",)


class EquipmentImageUploadView(ObjectFileUploadView):
    model = Equipment
    queryset = Equipment.objects.all()
    file_field = "image"
    extensions = DEFAULT_IMAGE_FORMATS
    permission_classes = [
        OrgMemberEditOrDjangoModelPermissions,
    ]
