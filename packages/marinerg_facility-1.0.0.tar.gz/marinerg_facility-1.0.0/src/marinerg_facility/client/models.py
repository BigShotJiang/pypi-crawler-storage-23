from pydantic import BaseModel, Extra

from ichec_django_core.client import (
    Timestamped,
    Resource,
    Identifiable,
    register_types,
    AddressCreate,
    AddressDetail,
)


class FacilityTagBase(BaseModel, frozen=True):
    value: str


class FacilityTagCreate(FacilityTagBase, frozen=True):
    pass


class FacilityTagDetail(Identifiable, FacilityTagBase, frozen=True):
    pass


class FacillityIdentifierBase(BaseModel, frozen=True):
    id_type: str
    value: str


class FacilityIdentifierCreate(FacilityTagBase, frozen=True):
    class Config:
        extra = Extra.forbid


class FacilityIdentifierDetail(FacillityIdentifierBase, Resource, frozen=True):
    class Config:
        extra = Extra.forbid


class FacilityBase(BaseModel, frozen=True):
    name: str
    acronym: str | None = None
    description: str | None = None
    website: str | None = None
    profile: str = ""
    tags: list[str] = []


class FacilityCreate(FacilityBase, frozen=True):
    address: AddressCreate
    identifiers: list[FacilityIdentifierCreate] = []
    public: bool = False
    members: list[str] = []
    equipment: list[str] = []

    class Config:
        extra = Extra.forbid


class FacilityDetailPublic(Timestamped, FacilityBase, frozen=True):
    address: AddressDetail
    identifiers: list[FacilityIdentifierDetail] = []
    image: str | None
    thumbnail: str | None

    class Config:
        extra = Extra.forbid


class FacilityDetail(FacilityDetailPublic, frozen=True):
    members: list[str] = []
    equipment: list[str] = []

    class Config:
        extra = Extra.forbid


class EquipmentBase(BaseModel, frozen=True):
    name: str
    description: str | None = None
    image: str | None = None
    facility: str
    tags: list[str]


class EquipmentCreate(EquipmentBase, frozen=True):
    class Config:
        extra = Extra.forbid


class EquipmentDetail(Timestamped, EquipmentBase, frozen=True):
    thumbnail: str | None

    class Config:
        extra = Extra.forbid


register_types(
    "facilities",
    {
        "create": FacilityCreate,
        "detail": FacilityDetail,
        "list": FacilityDetailPublic,
        "detail-public": FacilityDetailPublic,
    },
)
register_types("equipment", {"create": EquipmentCreate, "detail": EquipmentDetail})
