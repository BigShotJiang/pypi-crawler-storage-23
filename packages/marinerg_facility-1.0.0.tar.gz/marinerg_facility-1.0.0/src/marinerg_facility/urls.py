from django.urls import path

from .views import (
    FacilityViewSet,
    EquipmentViewSet,
    EquipmentTagViewSet,
    EquipmentImageUploadView,
    FacilityImageUploadView,
    FacilityTagViewSet,
)


def register_drf_views(router):
    router.register(r"facilities", FacilityViewSet)
    router.register(r"facility_tags", FacilityTagViewSet)
    router.register(r"equipment", EquipmentViewSet)
    router.register(r"equipment_tags", EquipmentTagViewSet)


urlpatterns = [
    path(
        r"facilities/<int:pk>/image/upload",
        FacilityImageUploadView.as_view(),
        name="facility_images_upload",
    ),
    path(
        r"eqiupment/<int:pk>/image/upload",
        EquipmentImageUploadView.as_view(),
        name="equipment_images_upload",
    ),
]
