from ichec_django_core.test import setup_default_address

from marinerg_facility.models import Facility, Equipment


def setup_default_facilities(member):

    internal = Facility.objects.create(
        name="Test Org 1",
        acronym="TO1",
        email="email@testorg.com",
        description="description of org",
        address=setup_default_address(),
        website="www.org.org",
        public=False,
    )
    internal.members.add(member)

    Equipment.objects.create(name="Org1 Eq1", description="desc", facility=internal)
    Equipment.objects.create(name="Org1 Eq2", description="desc", facility=internal)

    public = Facility.objects.create(
        name="Test Org 2",
        acronym="TO2",
        email="email@testorg.com",
        description="description of org",
        address=setup_default_address(),
        website="www.org.org",
        public=True,
    )
    public.members.add(member)

    Equipment.objects.create(name="Org2 Eq1", description="desc", facility=public)
    Equipment.objects.create(name="Org2 Eq2", description="desc", facility=public)

    inactive = Facility.objects.create(
        name="Test Org 3",
        acronym="TO3",
        email="email@testorg.com",
        description="description of org",
        address=setup_default_address(),
        website="www.org.org",
        public=True,
        active=False,
    )

    return internal, public, inactive
