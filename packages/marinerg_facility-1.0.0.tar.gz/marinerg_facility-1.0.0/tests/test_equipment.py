from pathlib import Path

from ichec_django_core.models import Member
from ichec_django_core.test import (
    AuthAPITestCase,
    setup_default_users_and_groups,
    add_group_permissions,
)

from marinerg_facility.models import Equipment
from marinerg_facility.client.resources import create_facilities
from marinerg_facility.test import setup_default_facilities


class TestEquipmentView(AuthAPITestCase):

    template = create_facilities(1)[0]

    def setUp(self):
        self.url = "/api/equipment/"
        setup_default_users_and_groups()

        add_group_permissions(
            "admins",
            Equipment,
            ["change_equipment", "add_equipment", "delete_equipment"],
        )

        add_group_permissions(
            "members",
            Equipment,
            ["view_equipment"],
        )

        items = setup_default_facilities(Member.objects.get(username="other_user"))
        self.internal, self.public, self.inactive = items

    def test_list_access(self):

        scenarios = (
            ["", 2, 200, "Public can list public items"],
            ["regular_user", 2, 200, "Registered can list public items"],
            ["member", 4, 200, "Member can list all items"],
            ["other_user", 4, 200, "Item member can list items"],
        )
        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            self.assertEqual(response.body.count, count, msg)

    def test_detail_access(self):

        public = self.public.equipment.all()[0].id
        internal = self.internal.equipment.all()[0].id
        scenarios = (
            ["", public, 200, "Public can view public item"],
            ["", internal, 404, "Public can't view internal item"],
            ["regular_user", public, 200, "Registered can view public item"],
            ["regular_user", internal, 404, "Registered can't view internal item"],
            ["member", public, 200, "Member can view public item"],
            ["member", internal, 200, "Item Member can view internal item"],
            ["other_user", internal, 200, "Item member can view item"],
        )

        for user, item, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item), status, msg)
            else:
                self.assert_status(self.detail(item), status, msg)
