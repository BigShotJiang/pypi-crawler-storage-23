import tempfile
import json
from pathlib import Path

from ichec_django_core.models import Member, Address
from ichec_django_core.test import (
    AuthAPITestCase,
    setup_default_users_and_groups,
    add_group_permissions,
    generate_image,
)

from marinerg_facility.models import Facility
from marinerg_facility.client.resources import create_facilities
from marinerg_facility.test import setup_default_facilities


class TestFacilityView(AuthAPITestCase):

    template = create_facilities(1)[0]
    update_template = {"name": "My Facility Edited"}

    def setUp(self):
        self.url = "/api/facilities/"
        setup_default_users_and_groups()

        add_group_permissions(
            "admins",
            Facility,
            ["change_facility", "add_facility", "delete_facility"],
        )

        add_group_permissions(
            "members",
            Facility,
            ["view_facility"],
        )

        items = setup_default_facilities(Member.objects.get(username="other_user"))
        self.internal, self.public, self.inactive = items

    def test_list_access(self):

        scenarios = (
            ["", 1, 200, "Public can list public items"],
            ["regular_user", 1, 200, "Registered can list public items"],
            ["member", 2, 200, "Member can list all items"],
            ["other_user", 2, 200, "Item member can list item"],
        )
        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            self.assertEqual(response.body.count, count, msg)

    def test_detail_access(self):

        public = self.public.id
        internal = self.internal.id
        scenarios = (
            ["", public, "public", 200, "Public can view public item"],
            ["", internal, "public", 404, "Public can't view internal item"],
            ["regular_user", public, "public", 200, "Registered can view public item"],
            [
                "regular_user",
                internal,
                "public",
                404,
                "Registered can't view internal item",
            ],
            ["member", public, "", 200, "Member can view public item"],
            ["member", internal, "", 200, "Item Member can view internal item"],
            ["other_user", internal, "", 200, "Item member can view item"],
        )

        for user, item, role, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item, role), status, msg)
            else:
                self.assert_status(self.detail(item, role), status, msg)

    def test_create_permissions(self):

        scenarios = (
            ["", 401, "Public can't create, no auth"],
            ["regular_user", 403, "Registered can't create, no perm"],
            ["admin_user", 201, "Admin can create"],
        )

        for user, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_create(user, self.template), status, msg)
            else:
                self.assert_status(self.create(self.template), status, msg)

    def _create_for_update(
        self,
        creator,
        members: list | None = None,
        member_key: str = "members",
        public=False,
    ):

        if members:
            template = self.template.model_copy(
                update={"members": [self.get_member_url(m) for m in members]}
            )
        else:
            template = self.template
        template = template.model_copy(update={"public": public})

        created = self.assert_201(self.auth_create(creator, template)).body
        return created.model_copy(
            update={"address": created.address.model_copy(update={"country": "FR"})}
        )

    def _verify_update(self, updated):
        self.assertEqual(updated.body.address.country, "FR")

    def test_update_permissions(self):

        scenarios = (
            ["", 401, False, "Public can't update, no auth"],
            ["regular_user", 404, False, "Registered can't update, no list"],
            ["other_user", 200, True, "Item member can update"],
            ["admin_user", 200, False, "Admin can update"],
        )

        for user, status, member, msg in scenarios:
            if member:
                created = self._create_for_update("admin_user", [user])
            else:
                created = self._create_for_update("admin_user")

            updated = None
            if user:
                updated = self.assert_status(
                    self.auth_update(user, created.id, created), status, msg
                )
            else:
                self.assert_status(self.update(created.id, created), status, msg)

            if updated:
                self._verify_update(updated)

    def test_delete_permissions(self):

        scenarios = (
            ["", 401, False, "Public can't delete, no auth"],
            ["regular_user", 403, False, "Registered can't delete"],
            ["other_user", 403, True, "Item member can't delete"],
            ["admin_user", 204, False, "Admin can delete"],
        )

        for user, status, member, msg in scenarios:
            if member:
                created = self._create_for_update("admin_user", [user])
            else:
                created = self._create_for_update("admin_user")

            if user:
                self.assert_status(self.auth_delete(user, created.id), status, msg)
            else:
                self.assert_status(self.delete(created.id), status, msg)

    def test_filters(self):
        pass

    def test_fields(self):
        pass

    def test_image_upload_permissions(self):

        created = self._create_for_update("admin_user", ["regular_user"])

        scenarios = (
            ["", 401, "profile.png", "Public can't upload image"],
            ["other_user", 403, "profile.png", "Other user can't upload image"],
            ["member", 403, "profile.png", "Member can't upload image"],
            ["regular_user", 204, "profile.png", "Member can upload PNG"],
            ["regular_user", 204, "profile.jpg", "Member can upload JPG"],
            [
                "regular_user",
                400,
                "profile.svg",
                "Member can't upload with unsupported extension",
            ],
            [
                "regular_user",
                400,
                "bad_profile.png",
                "Member can't upload with invalid content",
            ],
            ["admin_user", 20, "profile.png", "Admin can upload"],
        )

        for user, status, path, msg in scenarios:
            full_path = Path(__file__).parent / "data" / path
            with open(full_path, "rb") as f:
                content = f.read()

            if user:
                self.assert_status(
                    self.auth_put_file(
                        user, created.id, "image", content, full_path.name
                    ),
                    status,
                    msg,
                )
            else:
                self.assert_status(
                    self.put_file(created.id, "image", content, full_path.name),
                    status,
                    msg,
                )

    def _upload_image(self, resource):
        full_path = Path(__file__).parent / "data/profile.png"
        with open(full_path, "rb") as f:
            content = f.read()
        self.assert_204(
            self.auth_put_file("other_user", resource, "image", content, full_path.name)
        )

    def test_image_download_permissions(self):

        scenarios = (
            ["", self.public.id, 200, "Public user can download public image"],
            ["", self.internal.id, 404, "Public user can't download internal image"],
            ["other_user", self.public.id, 200, "Member can download public image"],
            ["other_user", self.internal.id, 200, "Meber can download internal image"],
            [
                "regular_user",
                self.public.id,
                200,
                "Registered can download public image",
            ],
            [
                "regular_user",
                self.internal.id,
                404,
                "Registered can't download internal image",
            ],
            ["member", self.public.id, 200, "Member can download public"],
            ["member", self.internal.id, 200, "Member can download internal"],
        )

        self._upload_image(self.public.id)
        self._upload_image(self.internal.id)

        for user, resource, status, msg in scenarios:
            if user:
                response = self.assert_status(
                    self.auth_get(user, resource, "image"), status, msg
                )
            else:
                self.assert_status(self.get(resource, "image"), status, msg)

        if status < 400:
            self.assertTrue(response.body["basename"] == "image.png")
