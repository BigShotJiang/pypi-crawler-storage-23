# API Reference

## Package

::: macenko_pca

## Deconvolution Module

::: macenko_pca.deconvolution
    options:
      show_source: true
      heading_level: 3