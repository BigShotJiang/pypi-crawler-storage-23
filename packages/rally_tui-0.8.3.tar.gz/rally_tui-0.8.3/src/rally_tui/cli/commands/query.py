"""Query command for fetching tickets from Rally.

This module implements the 'tickets' command for querying Rally work items.
"""

import asyncio
import sys

import click

from rally_tui.cli.formatters.base import CLIResult
from rally_tui.cli.main import CLIContext, cli, pass_context
from rally_tui.config import RallyConfig
from rally_tui.models import Ticket
from rally_tui.services.async_rally_client import AsyncRallyClient


def _sanitize_query_value(value: str) -> str:
    """Sanitize user input for Rally WSAPI query.

    Escapes quotes and backslashes to prevent query injection.

    Args:
        value: User-provided value to sanitize.

    Returns:
        Sanitized value safe for use in WSAPI query.
    """
    return value.replace("\\", "\\\\").replace('"', '\\"')


# Map CLI type names to Rally entity types
CREATE_TYPE_MAP = {
    "userstory": "HierarchicalRequirement",
    "defect": "Defect",
}


@click.group("tickets", invoke_without_command=True)
@click.option(
    "--current-iteration",
    is_flag=True,
    default=False,
    help="Show only tickets in current iteration.",
)
@click.option(
    "--my-tickets",
    is_flag=True,
    default=False,
    help="Show only tickets assigned to current user.",
)
@click.option(
    "--iteration",
    default=None,
    help="Filter by specific iteration name.",
)
@click.option(
    "--owner",
    default=None,
    help="Filter by owner display name.",
)
@click.option(
    "--state",
    default=None,
    help="Filter by workflow state.",
)
@click.option(
    "--ticket-type",
    type=click.Choice(["UserStory", "Defect", "Task", "TestCase"], case_sensitive=False),
    default=None,
    help="Filter by ticket type.",
)
@click.option(
    "--query",
    "custom_query",
    default=None,
    help="Custom Rally WSAPI query string.",
)
@click.option(
    "--fields",
    default=None,
    help="Comma-separated fields to display.",
)
@click.option(
    "--sort-by",
    default="formatted_id",
    help="Sort by field.",
)
@click.pass_context
def tickets(
    click_ctx: click.Context,
    current_iteration: bool,
    my_tickets: bool,
    iteration: str | None,
    owner: str | None,
    state: str | None,
    ticket_type: str | None,
    custom_query: str | None,
    fields: str | None,
    sort_by: str,
) -> None:
    """Query and display tickets from Rally.

    Without flags, returns all tickets in the project (excluding Jira Migration items).
    Use --current-iteration and --my-tickets for the most common use case.
    Use 'tickets create' to create a new ticket.

    Examples:

    \b
        # Show my tickets in current iteration
        rally-cli tickets --current-iteration --my-tickets

    \b
        # Show all tickets in a specific iteration
        rally-cli tickets --iteration "Sprint 2024.01"

    \b
        # Create a new ticket
        rally-cli tickets create "My Story" --description "Brief description" --points 1

    \b
        # Custom query with JSON output
        rally-cli tickets --query '(State = "In-Progress")' --format json
    """
    if click_ctx.invoked_subcommand is not None:
        return
    ctx = click_ctx.obj
    _tickets_list(
        ctx=ctx,
        current_iteration=current_iteration,
        my_tickets=my_tickets,
        iteration=iteration,
        owner=owner,
        state=state,
        ticket_type=ticket_type,
        custom_query=custom_query,
        fields=fields,
        sort_by=sort_by,
    )


def _tickets_list(
    ctx: CLIContext,
    current_iteration: bool,
    my_tickets: bool,
    iteration: str | None,
    owner: str | None,
    state: str | None,
    ticket_type: str | None,
    custom_query: str | None,
    fields: str | None,
    sort_by: str,
) -> None:
    """Run the list-tickets flow (default when no subcommand)."""
    if not ctx.apikey:
        result = CLIResult(
            success=False,
            data=None,
            error="RALLY_APIKEY environment variable not set. "
            "Set RALLY_APIKEY or use --apikey flag.",
        )
        click.echo(ctx.formatter.format_error(result), err=True)
        sys.exit(4)

    field_list = None
    if fields:
        field_list = [f.strip() for f in fields.split(",")]

    result = asyncio.run(
        _fetch_tickets(
            ctx=ctx,
            current_iteration=current_iteration,
            my_tickets=my_tickets,
            iteration=iteration,
            owner=owner,
            state=state,
            ticket_type=ticket_type,
            custom_query=custom_query,
            sort_by=sort_by,
        )
    )

    if result.success:
        output = ctx.formatter.format_tickets(result, field_list)
        click.echo(output)
        sys.exit(0)
    else:
        click.echo(ctx.formatter.format_error(result), err=True)
        sys.exit(1)


@tickets.command("create")
@click.argument("name")
@click.option(
    "--description",
    default="",
    help="Ticket description.",
)
@click.option(
    "--points",
    type=float,
    default=None,
    help="Story points to set on the ticket.",
)
@click.option(
    "--type",
    "ticket_type",
    type=click.Choice(["UserStory", "Defect"], case_sensitive=False),
    default="UserStory",
    help="Ticket type (default: UserStory).",
)
@click.option(
    "--backlog",
    is_flag=True,
    default=False,
    help="Put the ticket in the backlog (do not assign to current iteration).",
)
@pass_context
def tickets_create(
    ctx: CLIContext,
    name: str,
    description: str,
    points: float | None,
    ticket_type: str,
    backlog: bool,
) -> None:
    """Create a new ticket in Rally.

    Creates a User Story or Defect with the current user as owner and
    current iteration, if available. Use --backlog to leave the ticket
    in the backlog for planning.

    Examples:

    \b
        rally-cli tickets create "Ticket Name" --description "Brief description" --points 1
        rally-cli tickets create "Bug in login" --type Defect --description "Repro steps..."
        rally-cli tickets create "Future idea" --backlog
    """
    if not ctx.apikey:
        result = CLIResult(
            success=False,
            data=None,
            error="RALLY_APIKEY environment variable not set. "
            "Set RALLY_APIKEY or use --apikey flag.",
        )
        click.echo(ctx.formatter.format_error(result), err=True)
        sys.exit(4)

    entity_type = CREATE_TYPE_MAP.get(ticket_type.lower(), "HierarchicalRequirement")
    config = RallyConfig(
        server=ctx.server,
        apikey=ctx.apikey,
        workspace=ctx.workspace,
        project=ctx.project,
    )

    async def _do_create() -> Ticket | None:
        async with AsyncRallyClient(config) as client:
            return await client.create_ticket(
                title=name,
                ticket_type=entity_type,
                description=description,
                points=points,
                backlog=backlog,
            )

    created = asyncio.run(_do_create())
    if created:
        result = CLIResult(success=True, data=[created])
        click.echo(ctx.formatter.format_tickets(result))
        sys.exit(0)
    else:
        result = CLIResult(
            success=False,
            data=None,
            error="Failed to create ticket.",
        )
        click.echo(ctx.formatter.format_error(result), err=True)
        sys.exit(1)


async def _fetch_tickets(
    ctx: CLIContext,
    current_iteration: bool,
    my_tickets: bool,
    iteration: str | None,
    owner: str | None,
    state: str | None,
    ticket_type: str | None,
    custom_query: str | None,
    sort_by: str,
) -> CLIResult:
    """Fetch tickets from Rally asynchronously.

    Args:
        ctx: CLI context with configuration.
        current_iteration: Filter by current iteration.
        my_tickets: Filter by current user.
        iteration: Specific iteration name.
        owner: Owner display name filter.
        state: State filter.
        ticket_type: Ticket type filter.
        custom_query: Custom WSAPI query.
        sort_by: Field to sort by.

    Returns:
        CLIResult with ticket data or error.
    """
    config = RallyConfig(
        server=ctx.server,
        apikey=ctx.apikey,
        workspace=ctx.workspace,
        project=ctx.project,
    )

    try:
        async with AsyncRallyClient(config) as client:
            # Build query based on options
            query = _build_query(
                client=client,
                current_iteration=current_iteration,
                my_tickets=my_tickets,
                iteration=iteration,
                owner=owner,
                state=state,
                ticket_type=ticket_type,
                custom_query=custom_query,
            )

            # Fetch tickets
            tickets = await client.get_tickets(query)

            # Filter by ticket type if specified (post-filter since we fetch all types)
            if ticket_type:
                type_map = {
                    "userstory": "UserStory",
                    "defect": "Defect",
                    "task": "Task",
                    "testcase": "TestCase",
                }
                normalized_type = type_map.get(ticket_type.lower(), ticket_type)
                tickets = [t for t in tickets if t.ticket_type == normalized_type]

            # Sort tickets
            reverse = False
            if sort_by.startswith("-"):
                reverse = True
                sort_by = sort_by[1:]

            def sort_key(t):
                value = getattr(t, sort_by, None)
                if value is None:
                    return ""
                return str(value) if not isinstance(value, (str, int, float)) else value

            tickets.sort(key=sort_key, reverse=reverse)

            return CLIResult(success=True, data=tickets)

    except Exception as e:
        error_msg = str(e)
        if "401" in error_msg or "unauthorized" in error_msg.lower():
            return CLIResult(
                success=False,
                data=None,
                error="Authentication failed: Invalid API key",
            )
        return CLIResult(
            success=False,
            data=None,
            error=f"Failed to fetch tickets: {error_msg}",
        )


def _build_query(
    client: AsyncRallyClient,
    current_iteration: bool,
    my_tickets: bool,
    iteration: str | None,
    owner: str | None,
    state: str | None,
    ticket_type: str | None,
    custom_query: str | None,
) -> str | None:
    """Build Rally WSAPI query from options.

    Args:
        client: AsyncRallyClient for accessing current user/iteration.
        current_iteration: Use current iteration.
        my_tickets: Filter by current user.
        iteration: Specific iteration name.
        owner: Owner display name.
        state: State filter.
        ticket_type: Ticket type filter (not used in query, filtered post-fetch).
        custom_query: Custom query string.

    Returns:
        Rally WSAPI query string or None.
    """
    if custom_query:
        return custom_query

    conditions = []

    # Project scoping
    if client.project:
        conditions.append(f'(Project.Name = "{client.project}")')

    # Exclude Jira Migration
    conditions.append('(Owner.DisplayName != "Jira Migration")')

    # Iteration filter
    if iteration:
        sanitized_iteration = _sanitize_query_value(iteration)
        conditions.append(f'(Iteration.Name = "{sanitized_iteration}")')
    elif current_iteration and client.current_iteration:
        sanitized_iteration = _sanitize_query_value(client.current_iteration)
        conditions.append(f'(Iteration.Name = "{sanitized_iteration}")')

    # Owner filter
    if owner:
        sanitized_owner = _sanitize_query_value(owner)
        conditions.append(f'(Owner.DisplayName = "{sanitized_owner}")')
    elif my_tickets and client.current_user:
        sanitized_user = _sanitize_query_value(client.current_user)
        conditions.append(f'(Owner.DisplayName = "{sanitized_user}")')

    # State filter
    if state:
        sanitized_state = _sanitize_query_value(state)
        conditions.append(f'(FlowState.Name = "{sanitized_state}")')

    if not conditions:
        return None

    # Build nested AND query
    if len(conditions) == 1:
        return conditions[0]

    result = conditions[0]
    for condition in conditions[1:]:
        result = f"({result} AND {condition})"

    return result


# Register command with CLI
cli.add_command(tickets)
