"""CLI module for Rally command-line interface."""

from rally_tui.cli.main import cli

__all__ = ["cli"]
