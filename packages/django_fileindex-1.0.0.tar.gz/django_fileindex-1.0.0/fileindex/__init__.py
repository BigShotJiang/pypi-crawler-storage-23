"""
Django FileIndex - A Django app for file deduplication and indexing using SHA hashes.
"""

__version__ = "1.0.0"
