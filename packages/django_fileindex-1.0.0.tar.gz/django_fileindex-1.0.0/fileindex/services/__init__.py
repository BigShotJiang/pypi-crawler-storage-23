"""Service functions for fileindex operations."""

from fileindex.services import metadata

__all__ = [
    "metadata",
]
