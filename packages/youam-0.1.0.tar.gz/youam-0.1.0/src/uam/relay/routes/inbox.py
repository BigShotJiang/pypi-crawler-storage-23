"""GET /inbox/{address} -- message inbox endpoint (RELAY-02)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from uam.relay.auth import verify_api_key_http
from uam.relay.database import (
    get_stored_messages,
    mark_messages_delivered,
)
from uam.relay.models import InboxResponse

router = APIRouter()


@router.get("/inbox/{address}", response_model=InboxResponse)
async def get_inbox(
    address: str,
    request: Request,
    agent: dict = Depends(verify_api_key_http),
    limit: int = Query(default=50, ge=1, le=500),
) -> InboxResponse:
    """Retrieve stored messages for an agent.

    Bearer token auth via ``verify_api_key_http`` dependency.
    Agent can only read their own inbox.
    """
    db = request.app.state.db

    # Agent can only read their own inbox
    if address != agent["address"]:
        raise HTTPException(
            status_code=403,
            detail="Cannot read another agent's inbox",
        )

    # Fetch undelivered messages (already parsed by get_stored_messages)
    stored = await get_stored_messages(db, address, limit)

    messages: list[dict] = []
    ids: list[int] = []
    for msg in stored:
        messages.append(msg["envelope"])
        ids.append(msg["id"])

    # Mark as delivered
    if ids:
        await mark_messages_delivered(db, ids)

    return InboxResponse(address=address, messages=messages, count=len(messages))
