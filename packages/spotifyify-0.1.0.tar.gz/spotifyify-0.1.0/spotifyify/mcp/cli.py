from spotifyify.mcp.server import mcp


def main():
    mcp.run()
