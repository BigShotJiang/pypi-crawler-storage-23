"""
Eye2byte Interact — Mouse and keyboard automation for agents.

Uses pyautogui for cross-platform input simulation.
Install: pip install eye2byte[interact]
"""

import time


def click_at(x: int, y: int, button: str = "left", clicks: int = 1) -> dict:
    """Click at absolute screen coordinates.

    Args:
        x: X pixel coordinate.
        y: Y pixel coordinate.
        button: Mouse button — "left", "right", or "middle".
        clicks: Number of clicks (1=single, 2=double).

    Returns:
        Dict with action details and success status.
    """
    import pyautogui
    pyautogui.FAILSAFE = True  # move mouse to corner to abort

    pyautogui.click(x=x, y=y, button=button, clicks=clicks)

    return {
        "action": "click",
        "x": x,
        "y": y,
        "button": button,
        "clicks": clicks,
    }


def type_text(text: str, interval: float = 0.02) -> dict:
    """Type text at current cursor position.

    Args:
        text: Text to type.
        interval: Seconds between keystrokes (default 0.02).

    Returns:
        Dict with action details.
    """
    import pyautogui

    pyautogui.typewrite(text, interval=interval) if text.isascii() else pyautogui.write(text)

    return {
        "action": "type",
        "length": len(text),
    }


def press_key(key: str) -> dict:
    """Press a keyboard key or key combination.

    Args:
        key: Key name (e.g. "enter", "tab", "escape", "ctrl+a", "alt+f4").
             For combos, use "+" separator.

    Returns:
        Dict with action details.
    """
    import pyautogui

    if "+" in key:
        parts = [k.strip() for k in key.split("+")]
        pyautogui.hotkey(*parts)
    else:
        pyautogui.press(key)

    return {
        "action": "press",
        "key": key,
    }


def scroll_at(x: int, y: int, clicks: int = 3) -> dict:
    """Scroll at a screen position.

    Args:
        x: X pixel coordinate.
        y: Y pixel coordinate.
        clicks: Scroll amount. Positive=up, negative=down.

    Returns:
        Dict with action details.
    """
    import pyautogui

    pyautogui.scroll(clicks, x=x, y=y)

    return {
        "action": "scroll",
        "x": x,
        "y": y,
        "clicks": clicks,
    }
