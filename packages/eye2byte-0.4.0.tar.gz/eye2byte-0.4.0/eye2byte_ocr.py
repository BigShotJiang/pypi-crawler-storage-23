"""
Eye2byte OCR — Extract text elements with screen coordinates.

Uses easyocr for text detection with bounding boxes.
Install: pip install eye2byte[ocr]
"""

_reader_cache: dict = {}


def _get_reader(languages: list[str]):
    """Lazy-initialize and cache easyocr Reader by language set."""
    key = tuple(sorted(languages))
    if key not in _reader_cache:
        import easyocr
        _reader_cache[key] = easyocr.Reader(list(languages), gpu=True)
    return _reader_cache[key]


def _bbox_to_rect(bbox) -> dict:
    """Convert easyocr 4-corner bbox to {x, y, w, h} dict.

    easyocr returns [[x1,y1],[x2,y2],[x3,y3],[x4,y4]] as corner points.
    We take the bounding rectangle (min/max of all corners).
    """
    xs = [p[0] for p in bbox]
    ys = [p[1] for p in bbox]
    x = int(min(xs))
    y = int(min(ys))
    w = int(max(xs)) - x
    h = int(max(ys)) - y
    return {"x": x, "y": y, "w": w, "h": h}


def extract_elements(
    image_path: str,
    languages: list[str] | None = None,
    min_confidence: float = 0.3,
) -> list[dict]:
    """Extract text elements with bounding boxes from an image.

    Args:
        image_path: Path to a screenshot (PNG/JPEG).
        languages: Language codes for easyocr (default: ["en"]).
        min_confidence: Minimum confidence threshold (0.0-1.0).

    Returns:
        List of dicts: {text, x, y, w, h, confidence}
        sorted in reading order (top-to-bottom, left-to-right).

    Raises:
        ImportError: If easyocr is not installed.
    """
    if languages is None:
        languages = ["en"]

    reader = _get_reader(languages)
    results = reader.readtext(image_path)

    elements = []
    for bbox, text, confidence in results:
        if confidence < min_confidence:
            continue
        rect = _bbox_to_rect(bbox)
        elements.append({
            "text": text,
            "x": rect["x"],
            "y": rect["y"],
            "w": rect["w"],
            "h": rect["h"],
            "confidence": round(confidence, 3),
        })

    # Sort reading order: top-to-bottom (y), then left-to-right (x)
    elements.sort(key=lambda e: (e["y"], e["x"]))

    return elements
