#!/usr/bin/env python3
"""
Eye2byte MCP Server — Exposes screen context to coding agents.

This lets coding agents (Claude Code, etc.) directly query your screen
context via the Model Context Protocol. The agent can ask:

  - "What's on my screen right now?"
  - "Show me the last error I saw"
  - "Get context from this screenshot"

Start with:
    python eye2byte_mcp.py                             # stdio transport (default)
    python eye2byte_mcp.py --sse                       # SSE transport on port 8808
    python eye2byte_mcp.py --sse --port 9000           # SSE on custom port
    python eye2byte_mcp.py --sse --token mysecret123   # SSE with bearer token auth

Then add to your MCP client config:
    {
      "mcpServers": {
        "eye2byte": {
          "command": "python",
          "args": ["/path/to/eye2byte_mcp.py"]
        }
      }
    }
"""

import io
import os
import sys
from pathlib import Path
import json
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Ensure eye2byte module is importable
# ---------------------------------------------------------------------------
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

from fastmcp import FastMCP
from fastmcp.server.middleware import Middleware, MiddlewareContext
from fastmcp.utilities.types import Image as McpImage

from eye2byte import (
    load_config,
    ensure_dirs,
    capture_screen,
    capture_all_monitors,
    summarize_image,
    save_summary,
    record_voice,
    record_clip,
    transcribe_voice,
    extract_keyframes,
    extract_audio_from_clip,
)

# ---------------------------------------------------------------------------
# Bearer token auth middleware (used when --token is passed with --sse)
# ---------------------------------------------------------------------------

class BearerTokenMiddleware(Middleware):
    """Reject requests that don't carry the expected Authorization: Bearer token."""

    def __init__(self, token: str):
        self._expected = f"Bearer {token}"

    async def __call__(self, context: MiddlewareContext, call_next):
        try:
            from fastmcp.server.dependencies import get_http_request
            request = get_http_request()
            auth = request.headers.get("Authorization", "")
            if auth != self._expected:
                raise PermissionError("Invalid or missing bearer token")
        except RuntimeError:
            pass  # No HTTP request (stdio transport) — skip auth
        return await call_next(context)


# ---------------------------------------------------------------------------
# FastMCP server instance
# ---------------------------------------------------------------------------

mcp = FastMCP("eye2byte", version="0.4.0")


# ---------------------------------------------------------------------------
# Image helper — compress to JPEG Q60 in memory for MCP responses
# ---------------------------------------------------------------------------

def _optimize_for_mcp(image_path: str) -> bytes:
    """Compress an image to JPEG Q60 in memory, return raw bytes.

    Uses BytesIO to avoid temp files. Quality 60 keeps text readable
    while staying well under Claude's ~1MB image limit.
    Returns empty bytes on failure.
    """
    try:
        from PIL import Image
        img = Image.open(image_path)

        # Resize if too large (1280px max for MCP — speed over quality)
        w, h = img.size
        max_size = 1280
        if max(w, h) > max_size:
            if w > h:
                new_w, new_h = max_size, int(h * max_size / w)
            else:
                new_h, new_w = max_size, int(w * max_size / h)
            img = img.resize((new_w, new_h), Image.LANCZOS)

        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")

        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=60, optimize=True)
        img.close()
        return buf.getvalue()
    except ImportError:
        pass  # No Pillow — fall back to file-based
    except Exception:
        pass
    return b""


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool
def capture_and_summarize(
    mode: str = "full",
    delay: float = 0,
    window_name: str = "",
    monitor: int = 0,
) -> list:
    """Capture a screenshot of the user's screen and generate a structured
    Context Pack summary. Returns environment info, visible errors,
    file paths, and suggested next steps. Captures the monitor where
    the active window is located.

    Args:
        mode: Capture mode: full screen (active monitor), active window, or interactive region
        delay: Seconds to wait before capturing (useful for menus/tooltips). Default 0.
        window_name: Capture a specific app window by name (e.g. 'chrome', 'code', 'firefox'). Only used when mode is 'window'.
        monitor: Monitor to capture: 0 = active monitor (default), 1/2/3 = specific monitor by index, -1 = all monitors.
    """
    config = load_config()
    ensure_dirs(config)
    try:
        if monitor == -1:
            # Capture ALL monitors
            paths = capture_all_monitors(config, delay=delay)
            if not paths:
                return "Error: could not capture any monitors."
            content = []
            for i, path in enumerate(paths, 1):
                summary = summarize_image(path, config)
                save_summary(path, summary, config)
                img_bytes = _optimize_for_mcp(path)
                if img_bytes:
                    content.append(McpImage(data=img_bytes, format="jpeg"))
                content.append(f"**Monitor {i}:** `{path}`\n\n{summary}")
            return content
        else:
            path = capture_screen(config, mode=mode, delay=delay,
                                  window_name=window_name, monitor=monitor)
            summary = summarize_image(path, config)
            save_summary(path, summary, config)

            content = []
            img_bytes = _optimize_for_mcp(path)
            if img_bytes:
                content.append(McpImage(data=img_bytes, format="jpeg"))
            content.append(f"**Screenshot:** `{path}`\n\n{summary}")
            return content
    except Exception as e:
        return f"Error capturing screen: {e}"


@mcp.tool
def summarize_screenshot(path: str) -> list:
    """Analyze an existing screenshot file and generate a Context Pack.
    Use this when the user already has a screenshot they want analyzed.

    Args:
        path: Absolute path to the screenshot image file
    """
    config = load_config()
    ensure_dirs(config)
    if not os.path.exists(path):
        return f"File not found: {path}"
    try:
        summary = summarize_image(path, config)
        save_summary(path, summary, config)

        content = []
        img_bytes = _optimize_for_mcp(path)
        if img_bytes:
            content.append(McpImage(data=img_bytes, format="jpeg"))
        content.append(summary)
        return content
    except Exception as e:
        return f"Error summarizing image: {e}"


@mcp.tool
def get_recent_context(count: int = 3) -> str:
    """Get the most recent screen context summaries. Useful for understanding
    what the user has been looking at recently.

    Args:
        count: Number of recent summaries to return (default 3)
    """
    config = load_config()
    ensure_dirs(config)
    summary_dir = config["summary_dir"]
    if not os.path.exists(summary_dir):
        return "No summaries found yet. Use capture_and_summarize first."

    files = sorted(Path(summary_dir).glob("*.md"), key=os.path.getmtime, reverse=True)
    if not files:
        return "No summaries found yet."

    results = []
    for f in files[:count]:
        results.append(f.read_text(encoding="utf-8", errors="replace"))

    return "\n---\n\n".join(results)


@mcp.tool
def capture_with_voice(
    mode: str = "full",
    voice_duration: int = 15,
    delay: float = 0,
    window_name: str = "",
    monitor: int = 0,
) -> list:
    """Capture a screenshot AND record the user's voice narration.
    The user speaks to explain what they're looking at or what they need help with.
    Voice is transcribed locally and combined with the visual context.

    Args:
        mode: Capture mode: full screen, active window, or interactive region
        voice_duration: Max voice recording duration in seconds (default 15)
        delay: Seconds to wait before capturing (useful for menus/tooltips). Default 0.
        window_name: Capture a specific app window by name. Only for 'window' mode.
        monitor: Monitor to capture: 0 = active (default), 1/2/3 = specific, -1 = all.
    """
    config = load_config()
    ensure_dirs(config)
    try:
        path = capture_screen(config, mode=mode, delay=delay,
                              window_name=window_name, monitor=monitor)
        duration = min(voice_duration, 60)
        voice_path = record_voice(config, duration=duration)
        voice_text = ""
        if voice_path:
            voice_text = transcribe_voice(voice_path, config)
        summary = summarize_image(path, config, voice_transcript=voice_text)
        save_summary(path, summary, config, voice_transcript=voice_text)

        content = []
        img_bytes = _optimize_for_mcp(path)
        if img_bytes:
            content.append(McpImage(data=img_bytes, format="jpeg"))
        result_text = f"**Screenshot:** `{path}`\n"
        if voice_text:
            result_text += f"**Voice transcript:** {voice_text}\n"
        result_text += f"\n{summary}"
        content.append(result_text)
        return content
    except Exception as e:
        return f"Error: {e}"


@mcp.tool
def record_clip_and_summarize(
    duration: int = 10,
    keyframes: int = 5,
) -> str:
    """Record a short screen clip (video), extract keyframes, and generate a
    Context Pack from the sequence. Use this to capture multi-step actions
    like reproducing a bug, running a build, or navigating UI flows.

    Args:
        duration: Clip duration in seconds (default 10, max 60)
        keyframes: Number of keyframes to extract (default 5)
    """
    config = load_config()
    ensure_dirs(config)
    config["clip_keyframes"] = keyframes
    try:
        clip_duration = min(duration, 60)
        clip_path = record_clip(config, duration=clip_duration)
        if not clip_path:
            return "Error: Clip recording failed. Is ffmpeg installed?"

        frames = extract_keyframes(clip_path, config)
        voice_text = ""
        audio = extract_audio_from_clip(clip_path, config)
        if audio:
            voice_text = transcribe_voice(audio, config)

        if not frames:
            return "Error: Could not extract keyframes from clip."

        summary = summarize_image(
            frames[0], config,
            voice_transcript=voice_text,
            extra_images=frames[1:],
        )
        save_summary(clip_path, summary, config, voice_transcript=voice_text)

        result = f"**Clip:** `{clip_path}` ({clip_duration}s, {len(frames)} keyframes)\n"
        if voice_text:
            result += f"**Audio transcript:** {voice_text}\n"
        result += f"\n{summary}"
        return result
    except Exception as e:
        return f"Error: {e}"


@mcp.tool
def transcribe_audio(path: str) -> str:
    """Transcribe an audio file to text using a local Whisper model.
    Useful when the user has a voice memo or audio recording to process.

    Args:
        path: Absolute path to the audio file (wav, mp3, ogg, etc.)
    """
    config = load_config()
    ensure_dirs(config)
    if not os.path.exists(path):
        return f"File not found: {path}"
    try:
        text = transcribe_voice(path, config)
        return text if text else "Transcription failed or returned empty."
    except Exception as e:
        return f"Error: {e}"


@mcp.tool
def get_screen_elements(
    monitor: int = 0,
    languages: list[str] | None = None,
    min_confidence: float = 0.3,
) -> str:
    """Extract text elements with screen coordinates from current display.
    Returns JSON with {text, x, y, w, h, confidence} for each element,
    sorted in reading order. Coordinates are absolute screen pixels,
    directly usable for mouse automation.

    Requires: pip install eye2byte[ocr]

    Args:
        monitor: Monitor to capture: 0 = active (default), 1/2/3 = specific.
        languages: Language codes for OCR (default: ["en"]).
        min_confidence: Minimum confidence threshold 0.0-1.0 (default 0.3).
    """
    try:
        from eye2byte_ocr import extract_elements
    except ImportError:
        return json.dumps({
            "error": "easyocr not installed. Run: pip install eye2byte[ocr]"
        })

    if languages is None:
        languages = ["en"]

    config = load_config()
    ensure_dirs(config)

    try:
        path = capture_screen(config, mode="full", monitor=monitor)
    except Exception as e:
        return json.dumps({"error": f"Screenshot failed: {e}"})

    # Get resolution from the captured image
    try:
        from PIL import Image
        with Image.open(path) as img:
            resolution = list(img.size)
    except Exception:
        resolution = [0, 0]

    try:
        elements = extract_elements(path, languages=languages, min_confidence=min_confidence)
    except Exception as e:
        return json.dumps({"error": f"OCR failed: {e}"})

    return json.dumps({
        "monitor": monitor,
        "resolution": resolution,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "screenshot": path,
        "element_count": len(elements),
        "elements": elements,
    })


@mcp.tool
def search_context_history(
    query: str,
    limit: int = 5,
) -> str:
    """Search past screen context observations using full-text search.
    Find previous errors, patterns, or situations the agent has seen before.
    Supports FTS5 syntax: AND, OR, NOT, "exact phrases".

    Examples:
        "TypeError"          — find past type errors
        "login AND failed"   — login failures
        "docker build"       — docker-related observations

    Args:
        query: Search query (FTS5 syntax supported).
        limit: Max results to return (default 5).
    """
    from eye2byte_history import search_history

    config = load_config()
    ensure_dirs(config)

    try:
        results = search_history(query, config, limit=limit)
        if not results:
            return json.dumps({"results": [], "message": "No matching context packs found."})
        return json.dumps({"results": results, "count": len(results)})
    except Exception as e:
        return json.dumps({"error": f"Search failed: {e}"})


@mcp.tool
def click_element(
    x: int,
    y: int,
    button: str = "left",
    clicks: int = 1,
) -> str:
    """Click at absolute screen coordinates. Use with get_screen_elements()
    to find element positions first, then click them.

    Requires: pip install eye2byte[interact]

    Args:
        x: X pixel coordinate on screen.
        y: Y pixel coordinate on screen.
        button: Mouse button — "left", "right", or "middle".
        clicks: Number of clicks (1=single, 2=double).
    """
    try:
        from eye2byte_interact import click_at
    except ImportError:
        return json.dumps({
            "error": "pyautogui not installed. Run: pip install eye2byte[interact]"
        })

    try:
        result = click_at(x=x, y=y, button=button, clicks=clicks)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"error": f"Click failed: {e}"})


@mcp.tool
def type_text(
    text: str,
    interval: float = 0.02,
) -> str:
    """Type text at the current cursor position. Click an element first
    to focus it, then use this to type into it.

    Requires: pip install eye2byte[interact]

    Args:
        text: The text to type.
        interval: Seconds between keystrokes (default 0.02).
    """
    try:
        from eye2byte_interact import type_text as _type_text
    except ImportError:
        return json.dumps({
            "error": "pyautogui not installed. Run: pip install eye2byte[interact]"
        })

    try:
        result = _type_text(text=text, interval=interval)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"error": f"Type failed: {e}"})


@mcp.tool
def press_key(key: str) -> str:
    """Press a keyboard key or key combination. Useful for shortcuts,
    navigation (Tab, Enter, Escape), and hotkeys (ctrl+a, alt+f4).

    Requires: pip install eye2byte[interact]

    Args:
        key: Key name (e.g. "enter", "tab", "escape", "ctrl+a", "alt+f4").
             For combos use "+" separator.
    """
    try:
        from eye2byte_interact import press_key as _press_key
    except ImportError:
        return json.dumps({
            "error": "pyautogui not installed. Run: pip install eye2byte[interact]"
        })

    try:
        result = _press_key(key=key)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"error": f"Key press failed: {e}"})


@mcp.tool
def scroll_screen(
    x: int,
    y: int,
    clicks: int = 3,
) -> str:
    """Scroll at a screen position. Positive clicks = scroll up,
    negative = scroll down.

    Requires: pip install eye2byte[interact]

    Args:
        x: X pixel coordinate on screen.
        y: Y pixel coordinate on screen.
        clicks: Scroll amount. Positive=up, negative=down (default 3).
    """
    try:
        from eye2byte_interact import scroll_at
    except ImportError:
        return json.dumps({
            "error": "pyautogui not installed. Run: pip install eye2byte[interact]"
        })

    try:
        result = scroll_at(x=x, y=y, clicks=clicks)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"error": f"Scroll failed: {e}"})


# ---------------------------------------------------------------------------
# Entry point — stdio (default) or SSE transport
# ---------------------------------------------------------------------------

def main():
    if "--sse" in sys.argv:
        port = 8808
        token = None
        try:
            idx = sys.argv.index("--port")
            port = int(sys.argv[idx + 1])
        except (ValueError, IndexError):
            pass
        try:
            idx = sys.argv.index("--token")
            token = sys.argv[idx + 1]
        except (ValueError, IndexError):
            pass

        if token:
            mcp.add_middleware(BearerTokenMiddleware(token))
            print(f"[eye2byte] Starting SSE server on 0.0.0.0:{port} (token auth enabled)")
        else:
            print(f"[eye2byte] Starting SSE server on 0.0.0.0:{port} (no auth)")
        mcp.run(transport="sse", host="0.0.0.0", port=port)
    else:
        mcp.run()


if __name__ == "__main__":
    main()
