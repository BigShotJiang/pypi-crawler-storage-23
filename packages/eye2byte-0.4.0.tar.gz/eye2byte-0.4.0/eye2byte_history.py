"""
Eye2byte History — Searchable context history via SQLite FTS5.

Indexes Context Pack summaries for full-text search, enabling agents
to find past observations like "last time I saw this error".

DB location: ~/.eye2byte/history.db
"""

import os
import re
import sqlite3
from datetime import datetime
from pathlib import Path

_db_conn: sqlite3.Connection | None = None


def _get_db(config: dict) -> sqlite3.Connection:
    """Get or create the SQLite connection (singleton)."""
    global _db_conn
    if _db_conn is not None:
        return _db_conn

    db_path = os.path.join(config.get("summary_dir", "~/.eye2byte/summaries"), "..", "history.db")
    db_path = str(Path(db_path).resolve())

    _db_conn = sqlite3.connect(db_path)
    _db_conn.row_factory = sqlite3.Row
    _init_db(_db_conn)
    return _db_conn


def _init_db(conn: sqlite3.Connection):
    """Create tables if they don't exist."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS context_packs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            summary_path TEXT UNIQUE,
            image_source TEXT,
            generated_at TEXT,
            goal TEXT,
            environment TEXT,
            screen_state TEXT,
            signals TEXT,
            situation TEXT,
            voice_transcript TEXT,
            full_text TEXT,
            indexed_at TEXT
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS context_fts USING fts5(
            goal, environment, screen_state, signals, situation,
            voice_transcript, full_text,
            content=context_packs,
            content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS context_packs_ai AFTER INSERT ON context_packs BEGIN
            INSERT INTO context_fts(rowid, goal, environment, screen_state, signals,
                                    situation, voice_transcript, full_text)
            VALUES (new.id, new.goal, new.environment, new.screen_state, new.signals,
                    new.situation, new.voice_transcript, new.full_text);
        END;
    """)
    conn.commit()


def _parse_section(text: str, header: str) -> str:
    """Extract content under a markdown ## header."""
    pattern = rf"##\s+{re.escape(header)}\s*\n(.*?)(?=\n##\s|\Z)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else ""


def _parse_metadata(text: str, key: str) -> str:
    """Extract **Key:** value from metadata lines."""
    pattern = rf"\*\*{re.escape(key)}:\*\*\s*`?([^`\n]+)`?"
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


def index_summary(summary_path: str, config: dict) -> bool:
    """Index a Context Pack summary file into the database.

    Args:
        summary_path: Absolute path to a .md summary file.
        config: Eye2byte config dict.

    Returns:
        True if indexed successfully, False if already indexed or failed.
    """
    db = _get_db(config)

    # Check if already indexed
    existing = db.execute(
        "SELECT id FROM context_packs WHERE summary_path = ?",
        (summary_path,)
    ).fetchone()
    if existing:
        return False

    try:
        text = Path(summary_path).read_text(encoding="utf-8", errors="replace")
    except (FileNotFoundError, OSError):
        return False

    image_source = _parse_metadata(text, "Source")
    generated_at = _parse_metadata(text, "Generated")
    voice = _parse_metadata(text, "Voice narration")
    goal = _parse_section(text, "Goal")
    environment = _parse_section(text, "Environment")
    screen_state = _parse_section(text, "Screen State")
    signals = _parse_section(text, "Signals")
    situation = _parse_section(text, "Likely Situation")

    db.execute(
        """INSERT INTO context_packs
           (summary_path, image_source, generated_at, goal, environment,
            screen_state, signals, situation, voice_transcript, full_text, indexed_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (summary_path, image_source, generated_at, goal, environment,
         screen_state, signals, situation, voice, text,
         datetime.utcnow().isoformat())
    )
    db.commit()
    return True


def reindex_all(config: dict) -> int:
    """Index all existing summary files that aren't already in the database.

    Returns:
        Number of newly indexed files.
    """
    summary_dir = config.get("summary_dir", "")
    if not os.path.isdir(summary_dir):
        return 0

    count = 0
    for f in Path(summary_dir).glob("*.md"):
        if index_summary(str(f), config):
            count += 1
    return count


def search_history(query: str, config: dict, limit: int = 5) -> list[dict]:
    """Search context history using full-text search.

    Args:
        query: Search query (supports FTS5 syntax: AND, OR, NOT, "phrases").
        config: Eye2byte config dict.
        limit: Max results to return.

    Returns:
        List of dicts with matching context packs, ranked by relevance.
    """
    db = _get_db(config)

    # First reindex any new summaries
    reindex_all(config)

    rows = db.execute(
        """SELECT cp.*, rank
           FROM context_fts fts
           JOIN context_packs cp ON cp.id = fts.rowid
           WHERE context_fts MATCH ?
           ORDER BY rank
           LIMIT ?""",
        (query, limit)
    ).fetchall()

    results = []
    for row in rows:
        results.append({
            "summary_path": row["summary_path"],
            "image_source": row["image_source"],
            "generated_at": row["generated_at"],
            "goal": row["goal"],
            "signals": row["signals"],
            "situation": row["situation"],
            "voice_transcript": row["voice_transcript"],
        })
    return results


def get_history_stats(config: dict) -> dict:
    """Get statistics about the context history database."""
    db = _get_db(config)
    reindex_all(config)

    total = db.execute("SELECT COUNT(*) FROM context_packs").fetchone()[0]
    latest = db.execute(
        "SELECT generated_at FROM context_packs ORDER BY id DESC LIMIT 1"
    ).fetchone()

    return {
        "total_packs": total,
        "latest": latest["generated_at"] if latest else None,
    }
