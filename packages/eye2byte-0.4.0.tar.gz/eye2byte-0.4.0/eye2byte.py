#!/usr/bin/env python3
"""
Eye2byte — Screen-context sidecar for coding agents.

Captures screenshots, screen clips, and voice narration, sends them to
a local Ollama vision model, and produces structured "Context Packs"
your coding agent can act on.

Usage:
    # One-shot: capture active window and summarize
    python eye2byte.py capture

    # Capture with voice narration (speak while it records)
    python eye2byte.py capture --voice

    # Record a short screen clip (default 10s) and summarize keyframes
    python eye2byte.py clip --duration 15

    # Clip + voice narration together
    python eye2byte.py clip --voice --duration 10

    # Summarize an existing screenshot or clip
    python eye2byte.py summarize /path/to/screenshot.png
    python eye2byte.py summarize /path/to/clip.mp4

    # Watch a folder for new screenshots/clips
    python eye2byte.py watch

    # Capture a region interactively
    python eye2byte.py region
"""

__version__ = "0.4.0"

import argparse
import base64
import json
import math
import os
import shutil
import signal
import sys
import subprocess
import tempfile
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Fix Windows console encoding — prevents crashes on emoji/unicode in LLM output
# ---------------------------------------------------------------------------
if sys.platform == "win32":
    for _stream in (sys.stdout, sys.stderr):
        if hasattr(_stream, "reconfigure"):
            _stream.reconfigure(errors="replace")


# ---------------------------------------------------------------------------
# .env loader (zero deps — reads OPENROUTER_API_KEY etc.)
# ---------------------------------------------------------------------------

def _load_dotenv():
    """Load .env file from the project directory into os.environ."""
    # Search: script dir, cwd, ~/.eye2byte/
    candidates = [
        Path(__file__).resolve().parent / ".env",
        Path.cwd() / ".env",
        Path("~/.eye2byte/.env").expanduser(),
    ]
    for env_path in candidates:
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, val = line.partition("=")
                    key = key.strip()
                    val = val.strip().strip("'\"")
                    if key and val:
                        os.environ.setdefault(key, val)
            return

_load_dotenv()


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def _is_android() -> bool:
    """Detect if running on Android (Termux)."""
    return (
        os.path.isdir("/data/data/com.termux")
        or "TERMUX_VERSION" in os.environ
        or "com.termux" in os.environ.get("PREFIX", "")
    )


def _is_termux_api_available() -> bool:
    """Check if the Termux:API add-on is usable."""
    if not _is_android():
        return False
    try:
        subprocess.run(
            ["which", "termux-microphone-record"],
            capture_output=True, check=True,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _is_adb_available() -> bool:
    """Check if ADB is connected (wireless ADB from Termux, or host ADB)."""
    try:
        result = subprocess.run(
            ["adb", "devices"], capture_output=True, text=True, timeout=5,
        )
        # Look for at least one connected device (not just the header line)
        lines = result.stdout.strip().splitlines()
        return any("device" in line and "List" not in line for line in lines)
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return False

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "ollama_url": "http://localhost:11434",
    "model": "auto",
    "provider": "ollama",  # "ollama", "openrouter", "hyperbolic", or "gemini"
    "openrouter_model": "qwen/qwen2.5-vl-72b-instruct:free",
    "hyperbolic_model": "Qwen/Qwen2.5-VL-72B-Instruct",
    "gemini_model": "gemini-2.5-flash-lite",
    "whisper_model": "whisper",
    "capture_dir": "~/.eye2byte/captures",
    "summary_dir": "~/.eye2byte/summaries",
    "output_dir": "~/.eye2byte/output",
    "watch_interval": 1.0,
    "auto_copy_to_clipboard": True,
    "show_ui": True,
    "clip_duration": 10,
    "clip_fps": 1,
    "clip_keyframes": 5,
    "voice_duration": 30,
    "voice_clean": True,
    "auto_cleanup_days": 7,
    "image_max_size": 1920,
    "image_quality": 90,
    "hotkeys": {
        "capture": "ctrl+shift+1",
        "annotate": "ctrl+shift+2",
        "voice_toggle": "ctrl+shift+3",
        "clipboard": "ctrl+shift+5",
        "tool_arrow": "x",
        "tool_circle": "c",
        "tool_rect": "v",
        "tool_freehand": "b",
        "tool_text": "t",
        "ptt": "space",
    },
}


def load_config() -> dict:
    """Load config from ~/.eye2byte/config.json, falling back to defaults."""
    config_path = Path("~/.eye2byte/config.json").expanduser()
    config = dict(DEFAULT_CONFIG)
    if config_path.exists():
        with open(config_path) as f:
            config.update(json.load(f))
    # Expand paths
    config["capture_dir"] = str(Path(config["capture_dir"]).expanduser())
    config["summary_dir"] = str(Path(config["summary_dir"]).expanduser())
    config["output_dir"] = str(Path(config["output_dir"]).expanduser())
    return config


def ensure_dirs(config: dict):
    os.makedirs(config["capture_dir"], exist_ok=True)
    os.makedirs(config["summary_dir"], exist_ok=True)


def run_auto_cleanup(config: dict):
    """Delete files in captures/ and summaries/ older than auto_cleanup_days."""
    days = config.get("auto_cleanup_days", 0)
    if days <= 0:
        return
    cutoff = time.time() - (days * 86400)
    cleaned = 0
    for dirkey in ("capture_dir", "summary_dir"):
        dirpath = config.get(dirkey, "")
        if not dirpath or not os.path.isdir(dirpath):
            continue
        for fname in os.listdir(dirpath):
            fpath = os.path.join(dirpath, fname)
            if os.path.isfile(fpath):
                try:
                    if os.path.getmtime(fpath) < cutoff:
                        os.remove(fpath)
                        cleaned += 1
                except OSError:
                    pass
    if cleaned:
        print(f"[eye2byte] Auto-cleanup: removed {cleaned} file(s) older than {days} day(s)")


def save_config(config: dict):
    """Save current config back to ~/.eye2byte/config.json."""
    config_path = Path("~/.eye2byte/config.json").expanduser()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    # Only save known config keys (avoid saving transient state)
    save_data = {}
    for key in DEFAULT_CONFIG:
        if key in config:
            save_data[key] = config[key]
    # Collapse expanded home paths back to ~ for portability
    home = str(Path.home())
    for key in ["capture_dir", "summary_dir", "output_dir"]:
        val = str(save_data.get(key, ""))
        # Normalize separators on Windows for comparison
        val_norm = val.replace("\\", "/")
        home_norm = home.replace("\\", "/")
        if val_norm.startswith(home_norm):
            save_data[key] = "~" + val_norm[len(home_norm):]
    with open(config_path, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"[eye2byte] Config saved: {config_path}")


def get_hotkeys(config: dict) -> dict:
    """Return hotkeys config merged with defaults."""
    defaults = DEFAULT_CONFIG["hotkeys"]
    user = config.get("hotkeys", {})
    return {**defaults, **user}


def fetch_ollama_models(config: dict) -> list:
    """Fetch list of installed models from Ollama API. Returns list of model name strings."""
    try:
        import urllib.request
        url = f"{config['ollama_url']}/api/tags"
        req = urllib.request.Request(url, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []


def resolve_model(config: dict) -> str:
    """
    Resolve the model to use. If config says 'auto', pick the best
    vision-capable model from Ollama (prefers larger variants).
    """
    model = config.get("model", "auto")
    if model != "auto":
        return model

    models = fetch_ollama_models(config)
    # Look for vision models
    vision_keywords = ["vision", "vl", "llava", "bakllava", "moondream"]
    vision_models = []
    for m in models:
        lower = m.lower()
        if any(kw in lower for kw in vision_keywords):
            vision_models.append(m)

    if vision_models:
        # Sort to prefer larger param counts: extract number before 'b' if present
        # e.g. "qwen3-vl:8b" → 8, "qwen3-vl:2b" → 2, "llava:13b" → 13
        def _param_size(name):
            import re
            match = re.search(r'(\d+)b', name.lower())
            return int(match.group(1)) if match else 0

        vision_models.sort(key=_param_size, reverse=True)
        best = vision_models[0]
        print(f"[eye2byte] Auto-selected vision model: {best}")
        return best

    # Fallback to first model if nothing matches
    if models:
        print(f"[eye2byte] No vision model detected, using: {models[0]}")
        return models[0]

    return "llama3.2-vision"  # last resort default


def _get_windows_audio_device() -> str:
    """Auto-detect the default audio input device name on Windows via ffmpeg."""
    if not _command_exists("ffmpeg"):
        return ""
    try:
        result = subprocess.run(
            ["ffmpeg", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True, text=True, timeout=10,
        )
        # ffmpeg prints device list to stderr
        lines = result.stderr.splitlines()
        
        # Strategy 1: Look for "(audio)" suffix (newer ffmpeg)
        for line in lines:
            if "(audio)" in line and '"' in line:
                start = line.index('"') + 1
                end = line.index('"', start)
                device_name = line[start:end]
                if device_name and "none" not in device_name.lower():
                    return device_name
        
        # Strategy 2: Look for "audio devices" section header (older ffmpeg)
        audio_section = False
        for line in lines:
            if "audio devices" in line.lower():
                audio_section = True
                continue
            if audio_section and '"' in line:
                # Extract device name between quotes
                start = line.index('"') + 1
                end = line.index('"', start)
                device_name = line[start:end]
                if device_name and "none" not in device_name.lower():
                    return device_name
    except Exception:
        pass
    return ""


def _get_audio_duration(audio_path: str) -> float:
    """Get audio duration in seconds via ffprobe. Returns 0.0 on failure."""
    if not _command_exists("ffprobe"):
        return 0.0
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=nokey=1:noprint_wrappers=1", audio_path],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except (subprocess.TimeoutExpired, ValueError, OSError):
        pass
    return 0.0


def clean_voice(audio_path: str, config: dict) -> str:
    """
    Post-process a voice recording: remove background noise, trim pauses,
    normalize volume.  Uses ffmpeg audio filters (zero extra dependencies).

    Pipeline:
        1. highpass  @ 80 Hz  — kills low rumble (chair bumps, breathing, AC hum)
        2. lowpass   @ 8 kHz  — cuts high-freq hiss (not needed for speech)
        3. afftdn    nr=20    — FFT denoiser, removes constant background noise
        4. silenceremove       — trims leading/trailing silence and compresses
                                 internal pauses longer than 0.5 s
        5. compand             — soft-knee dynamic range compression so quiet
                                 words are still audible

    Returns the path to the cleaned file (replaces original).
    If cleaning fails, the original is left untouched and its path is returned.
    """
    if not config.get("voice_clean", True):
        return audio_path
    if not audio_path or not os.path.exists(audio_path):
        return audio_path
    if not _command_exists("ffmpeg"):
        return audio_path

    # Build the ffmpeg audio filter chain
    # For very short recordings, skip cleaning entirely — filters destroy them
    duration = _get_audio_duration(audio_path)
    file_kb = os.path.getsize(audio_path) / 1024

    if duration > 0 and duration < 1.0:
        print(f"[eye2byte] Voice cleaning skipped ({duration:.1f}s too short, {file_kb:.0f}KB kept)")
        return audio_path
    if duration == 0 and file_kb < 5:
        print(f"[eye2byte] Voice cleaning skipped ({file_kb:.0f}KB too small)")
        return audio_path

    # For short recordings (<3s), skip silenceremove — it destroys them
    use_light_chain = duration > 0 and duration < 3.0

    if use_light_chain:
        filters = ",".join([
            "highpass=f=80",
            "lowpass=f=8000",
            "afftdn=nr=12:nf=-25:tn=1",
            "compand=attacks=0.02:decays=0.2:points=-80/-80|-45/-25|-27/-15|0/-7:gain=5",
        ])
    else:
        filters = ",".join([
            # 1. Band-pass: keep 80 Hz – 8 kHz (speech range)
            "highpass=f=80",
            "lowpass=f=8000",
            # 2. FFT denoiser — nr controls strength (0-97, 20 = moderate)
            "afftdn=nr=20:nf=-25:tn=1",
            # 3. Silence removal:
            #    - stop_periods=-1  = process entire file (not just start/end)
            #    - stop_duration=0.5 = anything shorter than 0.5s silence is kept
            #    - stop_threshold=-35dB = what counts as "silence"
            "silenceremove="
            "start_periods=1:start_duration=0:start_threshold=-35dB:"
            "stop_periods=-1:stop_duration=0.5:stop_threshold=-35dB",
            # 4. Normalize volume via compand (soft-knee compression)
            #    attack=0.02s, decay=0.2s, soft-knee
            "compand=attacks=0.02:decays=0.2:points=-80/-80|-45/-25|-27/-15|0/-7:gain=5",
        ])

    ext = Path(audio_path).suffix  # .ogg or .wav
    cleaned_path = audio_path.rsplit(".", 1)[0] + "_clean" + ext

    # Choose codec based on output format
    if ext == ".ogg":
        codec_args = ["-c:a", "libopus", "-b:a", "24k"]
    else:
        codec_args = []

    cmd = [
        "ffmpeg", "-y", "-i", audio_path,
        "-af", filters,
        "-ar", "16000", "-ac", "1",
    ] + codec_args + [cleaned_path]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if (
            result.returncode == 0
            and os.path.exists(cleaned_path)
            and os.path.getsize(cleaned_path) > 100
        ):
            # Replace original with cleaned version
            orig_size = os.path.getsize(audio_path) / 1024
            clean_size = os.path.getsize(cleaned_path) / 1024
            os.replace(cleaned_path, audio_path)
            print(
                f"[eye2byte] Voice cleaned: {orig_size:.0f}KB → {clean_size:.0f}KB "
                f"(noise removed, pauses trimmed)"
            )
            return audio_path
        else:
            # Cleanup failed temp file
            if os.path.exists(cleaned_path):
                os.remove(cleaned_path)
            print("[eye2byte] Voice cleaning skipped (filter failed, using raw audio)")
    except (subprocess.TimeoutExpired, OSError) as e:
        if os.path.exists(cleaned_path):
            os.remove(cleaned_path)
        print(f"[eye2byte] Voice cleaning skipped: {e}")

    return audio_path


# ---------------------------------------------------------------------------
# Context Pack prompt — the core of what makes this useful
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are ScreenScribe, a visual assistant for a software developer.
You are analyzing a screenshot of their screen to help a coding agent understand context.

RULES:
- READ ALL VISIBLE TEXT CAREFULLY. Do not guess or hallucinate text that is not there.
- Only describe what you can ACTUALLY SEE in the image. Never invent filenames, error codes, or commands.
- Prioritize: errors, stack traces, file paths, commands, outputs, UI state.
- Quote error text VERBATIM when visible — copy exactly what is on screen.
- If text is too small or blurry to read, say "[unreadable]" — do NOT make up content.
- Identify the actual applications visible (browser, IDE, terminal, chat app, etc.) by their UI.
- Be concise. No filler. Every line should carry information.

OUTPUT FORMAT (use exactly these headings):

## Goal
One line: what the user appears to be doing.

## Environment
OS, editor/tool, repo/project, branch, language — whatever is visible.

## Screen State
Bullet list of what's visible: panels, files open, terminal output, UI elements.
Read and transcribe visible text accurately.

## Signals
Verbatim error lines, stack traces, HTTP codes, command output, warnings.
If none visible, write "No errors/warnings visible."

## Likely Situation
1-3 bullets on what's probably happening (bug, config issue, build failure, etc.)

## Suggested Next Info
2-5 bullets: the minimal extra info a coding agent would need to help.
"""


# ---------------------------------------------------------------------------
# Screenshot capture
# ---------------------------------------------------------------------------

def capture_screen(config: dict, mode: str = "full", delay: float = 0,
                   window_name: str = "", monitor: int = 0) -> str:
    """
    Capture a screenshot and return the file path.

    Modes:
        full    — entire screen (of the monitor with the active window)
        window  — active window only (or specific window if window_name given)
        region  — interactive region selection

    Args:
        delay: seconds to wait before capturing (useful for menus/tooltips)
        window_name: capture a specific app by name (e.g. "Chrome", "Code")
        monitor: 0 = active monitor (default), 1/2/3 = specific monitor index,
                 -1 = capture ALL monitors (returns first; use capture_all_monitors
                 for the list version)
    """
    ensure_dirs(config)
    if delay > 0:
        print(f"[eye2byte] Waiting {delay:.1f}s before capture...")
        time.sleep(delay)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(config["capture_dir"], f"capture_{timestamp}.png")

    # Android: special capture path
    if _is_android():
        android_path = _capture_android(filepath, config)
        if android_path:
            return android_path
        print("[eye2byte] ERROR: Screenshot failed on Android.", file=sys.stderr)
        print("  Option 1: Enable Wireless Debugging + connect ADB", file=sys.stderr)
        print("           pkg install android-tools && adb connect localhost:<port>", file=sys.stderr)
        print("  Option 2: Install Tasker and create a 'CaptureScreen' task", file=sys.stderr)
        sys.exit(1)

    # Windows: use PowerShell .NET screenshot (zero dependencies)
    if _is_windows():
        win_path = _capture_windows(filepath, mode, window_name=window_name,
                                    monitor=monitor)
        if win_path:
            return win_path
        print("[eye2byte] ERROR: Screenshot failed on Windows.", file=sys.stderr)
        print("  PowerShell with .NET System.Windows.Forms is required (built-in).", file=sys.stderr)
        sys.exit(1)

    # Desktop (Linux/macOS): try multiple capture tools in order of preference
    tools = _get_capture_command(mode, filepath, monitor=monitor)

    for tool_name, cmd in tools:
        if _command_exists(tool_name):
            try:
                subprocess.run(cmd, check=True, timeout=15)
                if os.path.exists(filepath):
                    print(f"[eye2byte] Captured via {tool_name}: {filepath}")
                    return filepath
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                continue

    print("[eye2byte] ERROR: No screenshot tool found.", file=sys.stderr)
    print("  Linux:   Install one of: scrot, gnome-screenshot, maim, spectacle, flameshot", file=sys.stderr)
    print("  macOS:   screencapture is built-in.", file=sys.stderr)
    print("  Windows: PowerShell is built-in.", file=sys.stderr)
    print("  Android: Run from Termux with ADB connected.", file=sys.stderr)
    sys.exit(1)


def capture_all_monitors(config: dict, delay: float = 0) -> list:
    """Capture every monitor separately. Returns list of file paths."""
    ensure_dirs(config)
    if delay > 0:
        print(f"[eye2byte] Waiting {delay:.1f}s before capture...")
        time.sleep(delay)

    paths = []
    # Get monitor count
    count = _get_monitor_count()
    for i in range(1, count + 1):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(config["capture_dir"],
                                f"capture_{timestamp}_mon{i}.png")
        if _is_windows():
            result = _capture_windows(filepath, "full", monitor=i)
            if result:
                paths.append(result)
        elif sys.platform == "darwin":
            try:
                subprocess.run(
                    ["screencapture", "-D", str(i), filepath],
                    check=True, timeout=15,
                )
                if os.path.exists(filepath):
                    paths.append(filepath)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                pass
        else:
            # Linux: xrandr-based geometry capture
            geom = _get_linux_monitor_geometry(i)
            if geom and _command_exists("maim"):
                try:
                    subprocess.run(
                        ["maim", "-g", geom, filepath],
                        check=True, timeout=15,
                    )
                    if os.path.exists(filepath):
                        paths.append(filepath)
                except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                    pass
        time.sleep(0.1)  # Brief pause between captures

    if not paths:
        print("[eye2byte] ERROR: Could not capture any monitors.", file=sys.stderr)
    return paths


def _get_monitor_count() -> int:
    """Get number of connected monitors."""
    if _is_windows():
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Add-Type -AssemblyName System.Windows.Forms; "
                 "[System.Windows.Forms.Screen]::AllScreens.Count"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return int(result.stdout.strip())
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            result = subprocess.run(
                ["system_profiler", "SPDisplaysDataType"],
                capture_output=True, text=True, timeout=10,
            )
            return result.stdout.count("Resolution:")
        except Exception:
            pass
    else:
        try:
            result = subprocess.run(
                ["xrandr", "--listmonitors"],
                capture_output=True, text=True, timeout=10,
            )
            # First line is "Monitors: N"
            first = result.stdout.strip().split("\n")[0]
            return int(first.split(":")[1].strip())
        except Exception:
            pass
    return 1


def _get_linux_monitor_geometry(monitor_idx: int) -> str:
    """Get geometry string (WxH+X+Y) for a specific Linux monitor via xrandr."""
    try:
        result = subprocess.run(
            ["xrandr", "--listmonitors"],
            capture_output=True, text=True, timeout=10,
        )
        lines = result.stdout.strip().split("\n")[1:]  # Skip header
        if 0 < monitor_idx <= len(lines):
            # Format: " 0: +*HDMI-1 1920/530x1080/300+0+0  HDMI-1"
            parts = lines[monitor_idx - 1].split()
            for p in parts:
                if "x" in p and "+" in p and "/" in p:
                    # Extract WxH+X+Y from "1920/530x1080/300+0+0"
                    w_part, rest = p.split("x")
                    w = w_part.split("/")[0]
                    h_rest = rest.split("+")
                    h = h_rest[0].split("/")[0]
                    x, y = h_rest[1], h_rest[2]
                    return f"{w}x{h}+{x}+{y}"
    except Exception:
        pass
    return ""


def _capture_android(filepath: str, config: dict) -> str:
    """Capture screenshot on Android via ADB or Tasker."""
    # Strategy 1: ADB screencap (most reliable)
    if _is_adb_available():
        tmp_device = "/sdcard/eye2byte_tmp_capture.png"
        try:
            subprocess.run(
                ["adb", "shell", "screencap", "-p", tmp_device],
                check=True, timeout=10,
            )
            subprocess.run(
                ["adb", "pull", tmp_device, filepath],
                check=True, timeout=10,
            )
            subprocess.run(
                ["adb", "shell", "rm", tmp_device],
                capture_output=True, timeout=5,
            )
            if os.path.exists(filepath):
                print(f"[eye2byte] Captured via adb screencap: {filepath}")
                return filepath
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            pass

    # Strategy 2: Trigger Tasker task via am broadcast
    if _command_exists("am"):
        try:
            subprocess.run(
                ["am", "broadcast",
                 "-a", "net.dinglisch.android.taskerm.ACTION_TASK",
                 "--es", "task_name", "CaptureScreen"],
                capture_output=True, timeout=5,
            )
            # Wait for Tasker to save the file
            time.sleep(3)
            # Check common Tasker screenshot locations
            for candidate in [
                "/sdcard/Eye2byte/captures/screenshot.png",
                "/sdcard/Pictures/Screenshots/screenshot.png",
                "/sdcard/DCIM/Screenshots/screenshot.png",
            ]:
                if os.path.exists(candidate):
                    import shutil
                    shutil.copy2(candidate, filepath)
                    if os.path.exists(filepath):
                        print(f"[eye2byte] Captured via Tasker: {filepath}")
                        return filepath
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            pass

    return ""


def _capture_windows(filepath: str, mode: str = "full",
                     window_name: str = "", monitor: int = 0) -> str:
    """Capture screenshot on Windows using PowerShell with .NET.

    Args:
        window_name: If provided, find and capture this app's window by process
                     name (e.g. "chrome", "code", "firefox"). Only for window mode.
        monitor: 0 = active monitor, 1/2/3 = specific monitor by index.
    """
    # PowerShell script to capture screen using System.Windows.Forms and Drawing
    if mode == "region":
        # Region mode: use snippingtool or fall back to full capture
        if _command_exists("snippingtool"):
            try:
                subprocess.run(["snippingtool", "/clip"], timeout=30)
                # SnippingTool puts the image on the clipboard; save it
                ps_save_clip = f'''
Add-Type -AssemblyName System.Windows.Forms
$img = [System.Windows.Forms.Clipboard]::GetImage()
if ($img) {{
    $img.Save("{filepath}", [System.Drawing.Imaging.ImageFormat]::Png)
}}
'''
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command", ps_save_clip],
                    check=True, timeout=15,
                )
                if os.path.exists(filepath):
                    print(f"[eye2byte] Captured via SnippingTool: {filepath}")
                    return filepath
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                pass
        # Fall through to full capture if region fails
        print("[eye2byte] Region capture not available, falling back to full screen.")

    if mode == "window":
        # Capture a specific window (by name or foreground)
        if window_name:
            # Find window by process name and capture it
            safe_name = window_name.replace("'", "''").replace('"', '`"')
            ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Named {{
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);
}}
[StructLayout(LayoutKind.Sequential)]
public struct RECT {{
    public int Left, Top, Right, Bottom;
}}
"@
$procs = Get-Process -ErrorAction SilentlyContinue | Where-Object {{
    $_.MainWindowHandle -ne [IntPtr]::Zero -and
    [Win32Named]::IsWindowVisible($_.MainWindowHandle) -and
    ($_.ProcessName -like "*{safe_name}*" -or $_.MainWindowTitle -like "*{safe_name}*")
}} | Select-Object -First 1
if (-not $procs) {{
    Write-Error "No visible window matching '{safe_name}'"
    exit 1
}}
$hwnd = $procs.MainWindowHandle
$rect = New-Object RECT
[Win32Named]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
$w = $rect.Right - $rect.Left
$h = $rect.Bottom - $rect.Top
if ($w -le 0 -or $h -le 0) {{ Write-Error "Invalid window size"; exit 1 }}
$bmp = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object System.Drawing.Size($w, $h)))
$g.Dispose()
$bmp.Save("{filepath}", [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "Captured: $($procs.ProcessName) - $($procs.MainWindowTitle)"
'''
        else:
            # Capture the active/foreground window
            ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32 {{
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
}}
[StructLayout(LayoutKind.Sequential)]
public struct RECT {{
    public int Left, Top, Right, Bottom;
}}
"@
$hwnd = [Win32]::GetForegroundWindow()
$rect = New-Object RECT
[Win32]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
$w = $rect.Right - $rect.Left
$h = $rect.Bottom - $rect.Top
$bmp = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object System.Drawing.Size($w, $h)))
$g.Dispose()
$bmp.Save("{filepath}", [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
'''
    else:
        # Full screen capture
        if monitor > 0:
            # Specific monitor by index (1-based)
            idx = monitor - 1
            ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$screens = [System.Windows.Forms.Screen]::AllScreens
if ({idx} -ge $screens.Count) {{
    Write-Error "Monitor {monitor} not found (only $($screens.Count) monitor(s) connected)"
    exit 1
}}
$bounds = $screens[{idx}].Bounds
$bmp = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
$g.Dispose()
$bmp.Save("{filepath}", [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "Captured monitor {monitor}: $($bounds.Width)x$($bounds.Height)"
'''
        else:
            # monitor=0: capture the monitor with the active window
            ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Full {{
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}}
"@
$hwnd = [Win32Full]::GetForegroundWindow()
$screen = [System.Windows.Forms.Screen]::FromHandle($hwnd)
$bounds = $screen.Bounds
$bmp = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
$g.Dispose()
$bmp.Save("{filepath}", [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
'''

    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_script],
            check=True, timeout=15,
        )
        if os.path.exists(filepath):
            print(f"[eye2byte] Captured via PowerShell: {filepath}")
            return filepath
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return ""


def _get_capture_command(mode: str, filepath: str, monitor: int = 0) -> list:
    """Return list of (tool_name, command) tuples for the given capture mode."""
    if sys.platform == "darwin":
        if mode == "full" and monitor > 0:
            # macOS: -D flag selects display by index (1-based)
            cmd = ["screencapture", "-D", str(monitor), filepath]
        else:
            flag = {"full": "", "window": "-w", "region": "-s"}.get(mode, "")
            cmd = ["screencapture"] + ([flag] if flag else []) + [filepath]
        return [("screencapture", cmd)]

    # Linux tools
    tools = []
    if mode == "full" and monitor > 0:
        # Specific monitor via geometry
        geom = _get_linux_monitor_geometry(monitor)
        if geom:
            tools = [
                ("maim", ["maim", "-g", geom, filepath]),
                ("scrot", ["scrot", filepath]),  # fallback: full desktop
            ]
        else:
            tools = [("scrot", ["scrot", filepath])]
    elif mode == "full":
        tools = [
            ("scrot", ["scrot", filepath]),
            ("maim", ["maim", filepath]),
            ("gnome-screenshot", ["gnome-screenshot", "-f", filepath]),
            ("spectacle", ["spectacle", "-b", "-n", "-o", filepath]),
            ("flameshot", ["flameshot", "full", "-p", os.path.dirname(filepath)]),
        ]
    elif mode == "window":
        tools = [
            ("scrot", ["scrot", "-u", filepath]),
            ("maim", ["maim", "-i", "$(xdotool getactivewindow)", filepath]),
            ("gnome-screenshot", ["gnome-screenshot", "-w", "-f", filepath]),
            ("spectacle", ["spectacle", "-a", "-b", "-n", "-o", filepath]),
            ("flameshot", ["flameshot", "full", "-p", os.path.dirname(filepath)]),
        ]
    elif mode == "region":
        tools = [
            ("scrot", ["scrot", "-s", filepath]),
            ("maim", ["maim", "-s", filepath]),
            ("gnome-screenshot", ["gnome-screenshot", "-a", "-f", filepath]),
            ("flameshot", ["flameshot", "gui"]),
        ]
    return tools


def _is_windows() -> bool:
    """Detect if running on Windows."""
    return sys.platform == "win32"


def _command_exists(name: str) -> bool:
    return shutil.which(name) is not None


# ---------------------------------------------------------------------------
# Image optimization — resize + compress for fast LLM processing
# ---------------------------------------------------------------------------

def optimize_image(image_path: str, config: dict) -> str:
    """
    Resize and compress a screenshot for optimal LLM vision processing.

    Vision models (Qwen-VL, LLaVA, etc.) internally tile images at ~448px
    patches. Sending a full 1920x1080 PNG (~700KB+) is wasteful — the model
    downscales it anyway. Resizing to 1280px longest side + JPEG Q85 gives
    ~80-150KB with zero perceptible quality loss for text/UI recognition.

    Saves the optimized image alongside the original (as *_opt.jpg) and
    returns its path. Falls back to the original if optimization fails.
    """
    max_size = config.get("image_max_size", 1280)
    quality = config.get("image_quality", 85)

    if not image_path or not os.path.exists(image_path):
        return image_path

    # Try PIL first (best quality control), fall back to ffmpeg
    optimized_path = image_path.rsplit(".", 1)[0] + "_opt.jpg"

    # Strategy 1: Pillow (if available)
    try:
        from PIL import Image
        img = Image.open(image_path)
        w, h = img.size

        # Only resize if larger than max_size
        if max(w, h) > max_size:
            if w > h:
                new_w = max_size
                new_h = int(h * max_size / w)
            else:
                new_h = max_size
                new_w = int(w * max_size / h)
            img = img.resize((new_w, new_h), Image.LANCZOS)

        # Convert RGBA to RGB for JPEG
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")

        img.save(optimized_path, "JPEG", quality=quality, optimize=True)
        img.close()

        if os.path.exists(optimized_path) and os.path.getsize(optimized_path) > 100:
            orig_kb = os.path.getsize(image_path) / 1024
            opt_kb = os.path.getsize(optimized_path) / 1024
            print(f"[eye2byte] Image optimized: {orig_kb:.0f}KB → {opt_kb:.0f}KB "
                  f"({max_size}px, Q{quality})")
            return optimized_path
    except ImportError:
        pass  # Pillow not installed, try ffmpeg
    except Exception:
        pass

    # Strategy 2: ffmpeg (always available)
    if _command_exists("ffmpeg"):
        try:
            scale_filter = (
                f"scale='min({max_size},iw)':'min({max_size},ih)'"
                f":force_original_aspect_ratio=decrease"
            )
            q_val = max(1, min(10, (100 - quality) // 5))
            cmd = [
                "ffmpeg", "-y", "-i", image_path,
                "-vf", scale_filter,
                "-q:v", str(q_val),
                optimized_path,
            ]
            subprocess.run(cmd, capture_output=True, timeout=15)
            if os.path.exists(optimized_path) and os.path.getsize(optimized_path) > 100:
                orig_kb = os.path.getsize(image_path) / 1024
                opt_kb = os.path.getsize(optimized_path) / 1024
                print(f"[eye2byte] Image optimized via ffmpeg: {orig_kb:.0f}KB → {opt_kb:.0f}KB")
                return optimized_path
        except Exception:
            pass

    return image_path


# ---------------------------------------------------------------------------
# Voice recording + transcription
# ---------------------------------------------------------------------------

def record_voice(config: dict, duration: int = None) -> str:
    """
    Record audio from the microphone and return the file path.
    Prefers Opus codec (crystal clear, ~3KB/sec) via ffmpeg, falls back to WAV.
    """
    ensure_dirs(config)
    duration = duration or config.get("voice_duration", 30)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath_wav = os.path.join(config["capture_dir"], f"voice_{timestamp}.wav")
    filepath_opus = os.path.join(config["capture_dir"], f"voice_{timestamp}.ogg")

    # Android: use Termux:API microphone (outputs m4a, we convert to wav after)
    if _is_android() and _is_termux_api_available():
        return _record_voice_android(filepath_wav, duration, config)

    # Build recorder list: (tool_name, command, output_path)
    # Opus via ffmpeg first (24kbps = ~90KB for 30s, crystal clear speech)
    # Then WAV fallbacks
    recorders = []

    if _is_windows():
        # Auto-detect the microphone device name
        mic = _get_windows_audio_device()
        if not mic:
            mic = "Microphone"  # fallback guess
        audio_input = f"audio={mic}"

        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "dshow", "-i", audio_input,
                "-t", str(duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "dshow", "-i", audio_input,
                "-t", str(duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
            ("sox", [
                "sox", "-t", "waveaudio", "default", "-r", "16000", "-c", "1", "-b", "16",
                filepath_wav, "trim", "0", str(duration),
            ], filepath_wav),
        ]
    elif sys.platform == "darwin":
        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "avfoundation", "-i", ":0",
                "-t", str(duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("sox", [
                "sox", "-d", "-r", "16000", "-c", "1", "-b", "16",
                filepath_wav, "trim", "0", str(duration),
            ], filepath_wav),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "avfoundation", "-i", ":0",
                "-t", str(duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
        ]
    else:
        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "pulse", "-i", "default",
                "-t", str(duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("arecord", [
                "arecord", "-f", "cd", "-t", "wav", "-d", str(duration), filepath_wav
            ], filepath_wav),
            ("sox", [
                "sox", "-d", "-r", "16000", "-c", "1", "-b", "16",
                filepath_wav, "trim", "0", str(duration),
            ], filepath_wav),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "pulse", "-i", "default",
                "-t", str(duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
        ]

    for tool_name, cmd, outpath in recorders:
        if _command_exists(tool_name):
            try:
                print(f"[eye2byte] Recording voice via {tool_name} (max {duration}s, Ctrl+C to stop)...")
                proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                try:
                    proc.wait(timeout=duration + 2)
                except subprocess.TimeoutExpired:
                    proc.terminate()
                    proc.wait(timeout=5)

                if os.path.exists(outpath) and os.path.getsize(outpath) > 100:
                    fmt = "Opus" if outpath.endswith(".ogg") else "WAV"
                    size_kb = os.path.getsize(outpath) / 1024
                    print(f"[eye2byte] Voice recorded ({fmt}, {size_kb:.0f}KB): {outpath}")
                    return clean_voice(outpath, config)
            except KeyboardInterrupt:
                proc.terminate()
                proc.wait(timeout=5)
                if os.path.exists(outpath) and os.path.getsize(outpath) > 100:
                    print(f"\n[eye2byte] Voice recorded (stopped early): {outpath}")
                    return clean_voice(outpath, config)
            except (subprocess.CalledProcessError, OSError):
                continue

    print("[eye2byte] ERROR: No audio recorder found.", file=sys.stderr)
    if _is_android():
        print("  Install Termux:API app + pkg install termux-api", file=sys.stderr)
    elif _is_windows():
        print("  Install ffmpeg: winget install ffmpeg  (or download from ffmpeg.org)", file=sys.stderr)
        print("  Or install sox: choco install sox", file=sys.stderr)
    else:
        print("  Install one of: arecord (alsa-utils), sox, ffmpeg", file=sys.stderr)
    return ""


# ---------------------------------------------------------------------------
# Push-to-Talk (PTT) voice recording — start/stop on demand
# ---------------------------------------------------------------------------

def start_voice_recording(config: dict) -> dict:
    """
    Start voice recording in PTT mode (no fixed duration).
    Returns a handle dict: {"proc": Popen, "path": str, "tool": str}
    Call stop_voice_recording(handle, config) to finish.
    Returns empty dict if no recorder is available.
    """
    ensure_dirs(config)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath_opus = os.path.join(config["capture_dir"], f"voice_{timestamp}.ogg")
    filepath_wav = os.path.join(config["capture_dir"], f"voice_{timestamp}.wav")

    # Safety max: 5 minutes (prevents runaway recordings)
    max_duration = 300

    recorders = []
    if _is_windows():
        mic = _get_windows_audio_device()
        if not mic:
            mic = "Microphone"
        audio_input = f"audio={mic}"
        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "dshow", "-i", audio_input,
                "-t", str(max_duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "dshow", "-i", audio_input,
                "-t", str(max_duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
        ]
    elif sys.platform == "darwin":
        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "avfoundation", "-i", ":0",
                "-t", str(max_duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "avfoundation", "-i", ":0",
                "-t", str(max_duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
        ]
    else:
        recorders = [
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "pulse", "-i", "default",
                "-t", str(max_duration), "-c:a", "libopus", "-b:a", "24k",
                "-ar", "16000", "-ac", "1", filepath_opus,
            ], filepath_opus),
            ("ffmpeg", [
                "ffmpeg", "-y", "-f", "pulse", "-i", "default",
                "-t", str(max_duration), "-ar", "16000", "-ac", "1", filepath_wav,
            ], filepath_wav),
        ]

    for tool_name, cmd, outpath in recorders:
        if _command_exists(tool_name):
            try:
                proc = subprocess.Popen(
                    cmd, stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                )
                print(f"[eye2byte] PTT recording started via {tool_name}")
                return {"proc": proc, "path": outpath, "tool": tool_name}
            except (OSError, subprocess.SubprocessError):
                continue

    print("[eye2byte] ERROR: No audio recorder found for PTT.", file=sys.stderr)
    return {}


def stop_voice_recording(handle: dict, config: dict) -> str:
    """
    Stop a PTT recording started by start_voice_recording().
    Sends 'q' to ffmpeg for a clean file finalization, then cleans audio.
    Returns the cleaned audio file path, or empty string on failure.
    """
    if not handle or "proc" not in handle:
        return ""

    proc = handle["proc"]
    outpath = handle["path"]

    # Send 'q' to ffmpeg stdin for graceful stop (proper file finalization)
    try:
        if proc.stdin and not proc.stdin.closed:
            proc.stdin.write(b"q")
            proc.stdin.flush()
            proc.stdin.close()
    except (BrokenPipeError, OSError):
        pass

    # Wait for ffmpeg to finalize the file
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()

    if os.path.exists(outpath) and os.path.getsize(outpath) > 100:
        fmt = "Opus" if outpath.endswith(".ogg") else "WAV"
        size_kb = os.path.getsize(outpath) / 1024
        print(f"[eye2byte] PTT voice recorded ({fmt}, {size_kb:.0f}KB): {outpath}")
        return clean_voice(outpath, config)

    print("[eye2byte] PTT recording produced no usable audio.", file=sys.stderr)
    return ""


def _record_voice_android(filepath: str, duration: int, config: dict) -> str:
    """Record voice on Android using termux-microphone-record."""
    m4a_path = filepath.rsplit(".", 1)[0] + ".m4a"

    try:
        print(f"[eye2byte] Recording voice via termux-microphone-record (max {duration}s, Ctrl+C to stop)...")
        subprocess.run(
            ["termux-microphone-record", "-f", m4a_path,
             "-l", str(duration), "-e", "aac", "-r", "44100", "-c", "1"],
            timeout=duration + 5,
        )
    except subprocess.TimeoutExpired:
        # Stop recording
        subprocess.run(["termux-microphone-record", "-q"], capture_output=True, timeout=5)
    except KeyboardInterrupt:
        subprocess.run(["termux-microphone-record", "-q"], capture_output=True, timeout=5)
        print("\n[eye2byte] Voice recording stopped early.")

    if not os.path.exists(m4a_path) or os.path.getsize(m4a_path) < 100:
        return ""

    # Convert m4a to wav for whisper compatibility (if ffmpeg available)
    if _command_exists("ffmpeg"):
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-i", m4a_path, "-ar", "16000", "-ac", "1", filepath],
                capture_output=True, check=True, timeout=30,
            )
            if os.path.exists(filepath) and os.path.getsize(filepath) > 100:
                print(f"[eye2byte] Voice recorded: {filepath}")
                return clean_voice(filepath, config)
        except Exception:
            pass

    # Fallback: use the m4a directly (some whisper builds handle it)
    print(f"[eye2byte] Voice recorded: {m4a_path}")
    return clean_voice(m4a_path, config)


def transcribe_voice(audio_path: str, config: dict) -> str:
    """
    Transcribe audio to text using a local Whisper model via Ollama,
    or fall back to whisper.cpp / openai-whisper CLI.
    """
    if not audio_path or not os.path.exists(audio_path):
        return ""

    # Strategy 1: whisper.cpp CLI (fastest local option)
    if _command_exists("whisper-cpp") or _command_exists("main"):
        whisper_bin = "whisper-cpp" if _command_exists("whisper-cpp") else "main"
        try:
            result = subprocess.run(
                [whisper_bin, "-f", audio_path, "--no-timestamps", "-nt"],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0 and result.stdout.strip():
                print("[eye2byte] Transcribed via whisper.cpp")
                return result.stdout.strip()
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            pass

    # Strategy 2: openai-whisper Python CLI
    if _command_exists("whisper"):
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                env = dict(os.environ, PYTHONIOENCODING="utf-8")
                result = subprocess.run(
                    ["whisper", audio_path, "--model", "base", "--output_format", "txt",
                     "--output_dir", tmpdir],
                    capture_output=True, text=True, timeout=120,
                    env=env, encoding="utf-8", errors="replace",
                )
                if result.returncode == 0:
                    txt_files = list(Path(tmpdir).glob("*.txt"))
                    if txt_files:
                        text = txt_files[0].read_text(encoding="utf-8").strip()
                        if text:
                            print("[eye2byte] Transcribed via openai-whisper")
                            return text
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            pass

    # Strategy 3: Ollama with a whisper-compatible model (if available)
    # Some Ollama setups support audio models — try it
    try:
        with open(audio_path, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode("utf-8")

        payload = {
            "model": config.get("whisper_model", "whisper"),
            "prompt": "Transcribe this audio exactly as spoken.",
            "images": [audio_b64],  # Ollama uses 'images' field for binary data
            "stream": False,
        }
        import urllib.request
        req = urllib.request.Request(
            f"{config['ollama_url']}/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            text = result.get("response", "").strip()
            if not text and result.get("thinking"):
                text = result["thinking"].strip()
            if text and "error" not in text.lower()[:20]:
                print("[eye2byte] Transcribed via Ollama")
                return text
    except Exception:
        pass

    print("[eye2byte] WARNING: Could not transcribe audio.", file=sys.stderr)
    print("  Install one of: whisper.cpp, openai-whisper (pip install openai-whisper)", file=sys.stderr)
    return "[voice recording attached but transcription unavailable]"


def record_voice_async(config: dict, duration: int = None) -> threading.Thread:
    """Start voice recording in a background thread. Returns (thread, result_holder)."""
    result = {"path": "", "text": ""}

    def _record():
        path = record_voice(config, duration)
        result["path"] = path

    t = threading.Thread(target=_record, daemon=True)
    t.start()
    return t, result


# ---------------------------------------------------------------------------
# Screen clip recording + keyframe extraction
# ---------------------------------------------------------------------------

def record_clip(config: dict, duration: int = None, with_audio: bool = False) -> str:
    """
    Record a short screen clip and return the file path.
    Uses adb screenrecord (Android), ffmpeg x11grab (Linux), or avfoundation (macOS).
    """
    ensure_dirs(config)
    duration = duration or config.get("clip_duration", 10)
    fps = config.get("clip_fps", 1)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(config["capture_dir"], f"clip_{timestamp}.mp4")

    # Android: use ADB screenrecord (max 180s, no audio)
    if _is_android():
        return _record_clip_android(filepath, duration, config)

    if not _command_exists("ffmpeg"):
        print("[eye2byte] ERROR: ffmpeg is required for clip recording.", file=sys.stderr)
        print("  Ubuntu/Debian: sudo apt install ffmpeg", file=sys.stderr)
        print("  macOS:         brew install ffmpeg", file=sys.stderr)
        print("  Windows:       winget install ffmpeg", file=sys.stderr)
        return ""

    if _is_windows():
        # Windows: gdigrab (built into ffmpeg on Windows)
        cmd = ["ffmpeg", "-y", "-f", "gdigrab", "-framerate", str(max(fps, 5))]
        cmd += ["-i", "desktop"]

        if with_audio:
            mic = _get_windows_audio_device() or "Microphone"
            cmd += ["-f", "dshow", "-i", f"audio={mic}"]

        cmd += [
            "-t", str(duration),
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
            filepath,
        ]
    elif sys.platform == "darwin":
        # macOS: avfoundation
        cmd = [
            "ffmpeg", "-y",
            "-f", "avfoundation", "-framerate", str(fps),
            "-i", "1:none" if not with_audio else "1:0",
            "-t", str(duration),
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
            filepath,
        ]
    else:
        # Linux: x11grab
        # Get screen resolution
        resolution = "1920x1080"
        try:
            xdp = subprocess.run(
                ["xdpyinfo"], capture_output=True, text=True, timeout=5,
            )
            for line in xdp.stdout.splitlines():
                if "dimensions:" in line:
                    resolution = line.split()[1]
                    break
        except Exception:
            pass

        cmd = ["ffmpeg", "-y", "-video_size", resolution]
        cmd += ["-framerate", str(max(fps, 5))]  # ffmpeg x11grab needs >= 5 for smooth capture
        cmd += ["-f", "x11grab", "-i", os.environ.get("DISPLAY", ":0")]

        if with_audio:
            cmd += ["-f", "pulse", "-i", "default"]

        cmd += [
            "-t", str(duration),
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
            filepath,
        ]

    try:
        print(f"[eye2byte] Recording clip ({duration}s, Ctrl+C to stop)...")
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            proc.wait(timeout=duration + 5)
        except subprocess.TimeoutExpired:
            if _is_windows():
                proc.terminate()
            else:
                proc.send_signal(signal.SIGINT)
            proc.wait(timeout=5)
        except KeyboardInterrupt:
            if _is_windows():
                proc.terminate()
            else:
                proc.send_signal(signal.SIGINT)
            proc.wait(timeout=5)

        if os.path.exists(filepath) and os.path.getsize(filepath) > 100:
            print(f"[eye2byte] Clip recorded: {filepath}")
            return filepath
    except Exception as e:
        print(f"[eye2byte] Clip recording failed: {e}", file=sys.stderr)

    return ""


def _record_clip_android(filepath: str, duration: int, config: dict) -> str:
    """Record a screen clip on Android via ADB screenrecord."""
    if not _is_adb_available():
        print("[eye2byte] ERROR: ADB not connected. Screen clips require wireless ADB.", file=sys.stderr)
        print("  1. Enable Developer Options > Wireless Debugging on your device", file=sys.stderr)
        print("  2. pkg install android-tools", file=sys.stderr)
        print("  3. adb pair localhost:<pairing-port>", file=sys.stderr)
        print("  4. adb connect localhost:<port>", file=sys.stderr)
        return ""

    # ADB screenrecord has a hard 180s limit
    duration = min(duration, 180)
    tmp_device = "/sdcard/eye2byte_tmp_clip.mp4"

    try:
        print(f"[eye2byte] Recording clip via adb screenrecord ({duration}s, Ctrl+C to stop)...")
        proc = subprocess.Popen(
            ["adb", "shell", "screenrecord", "--time-limit", str(duration), tmp_device],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        try:
            proc.wait(timeout=duration + 5)
        except subprocess.TimeoutExpired:
            # Send Ctrl+C to adb shell
            subprocess.run(["adb", "shell", "kill", "-2",
                           f"$(adb shell pidof screenrecord)"],
                          capture_output=True, timeout=5)
            proc.wait(timeout=5)
        except KeyboardInterrupt:
            subprocess.run(["adb", "shell", "kill", "-2",
                           f"$(adb shell pidof screenrecord)"],
                          capture_output=True, timeout=5)
            proc.wait(timeout=5)
            print("\n[eye2byte] Clip recording stopped early.")

        # Small delay for file to finalize on device
        time.sleep(1)

        subprocess.run(
            ["adb", "pull", tmp_device, filepath],
            check=True, timeout=30,
        )
        subprocess.run(
            ["adb", "shell", "rm", tmp_device],
            capture_output=True, timeout=5,
        )

        if os.path.exists(filepath) and os.path.getsize(filepath) > 100:
            print(f"[eye2byte] Clip recorded via adb: {filepath}")
            return filepath
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        print(f"[eye2byte] ADB clip recording failed: {e}", file=sys.stderr)

    return ""


def extract_keyframes(clip_path: str, config: dict) -> list:
    """
    Extract evenly-spaced keyframes from a clip as PNG files.
    Returns list of image file paths.
    """
    if not clip_path or not os.path.exists(clip_path):
        return []

    if not _command_exists("ffmpeg"):
        return []

    num_frames = config.get("clip_keyframes", 5)
    clip_dir = os.path.dirname(clip_path)
    stem = Path(clip_path).stem

    # Get clip duration
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", clip_path],
            capture_output=True, text=True, timeout=10,
        )
        total_duration = float(probe.stdout.strip())
    except Exception:
        total_duration = config.get("clip_duration", 10)

    # Extract frames at evenly spaced intervals
    frames = []
    interval = total_duration / (num_frames + 1)

    for i in range(1, num_frames + 1):
        timestamp = interval * i
        frame_path = os.path.join(clip_dir, f"{stem}_frame{i:02d}.png")
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-ss", str(timestamp), "-i", clip_path,
                 "-frames:v", "1", "-q:v", "2", frame_path],
                capture_output=True, check=True, timeout=15,
            )
            if os.path.exists(frame_path):
                frames.append(frame_path)
        except Exception:
            continue

    print(f"[eye2byte] Extracted {len(frames)} keyframes from clip")
    return frames


def extract_audio_from_clip(clip_path: str, config: dict) -> str:
    """Extract audio track from a video clip for transcription."""
    if not clip_path or not _command_exists("ffmpeg"):
        return ""

    audio_path = clip_path.rsplit(".", 1)[0] + "_audio.wav"
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", clip_path, "-vn",
             "-ar", "16000", "-ac", "1", "-ab", "128k", audio_path],
            capture_output=True, check=True, timeout=30,
        )
        if os.path.exists(audio_path) and os.path.getsize(audio_path) > 100:
            return audio_path
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Ollama vision API
# ---------------------------------------------------------------------------

def summarize_image(image_path: str, config: dict, voice_transcript: str = "",
                    extra_images: list = None) -> str:
    """
    Send image(s) to Ollama vision model and return the Context Pack.

    Args:
        image_path: Primary image to analyze.
        config: Eye2byte config dict.
        voice_transcript: Optional voice narration transcript to include.
        extra_images: Optional list of additional image paths (e.g. keyframes).
    """
    images_b64 = []

    # Optimize primary image for LLM processing
    t_opt = time.time()
    opt_path = optimize_image(image_path, config)
    with open(opt_path, "rb") as f:
        images_b64.append(base64.b64encode(f.read()).decode("utf-8"))
    opt_kb = len(images_b64[0]) * 3 / 4 / 1024  # approximate decoded size
    print(f"[eye2byte] Image prepared: {opt_kb:.0f}KB base64 ({time.time() - t_opt:.1f}s)")

    # Additional images (keyframes from clips) — optimize each
    for img in (extra_images or []):
        if os.path.exists(img):
            opt_img = optimize_image(img, config)
            with open(opt_img, "rb") as f:
                images_b64.append(base64.b64encode(f.read()).decode("utf-8"))

    # Build the prompt
    prompt_parts = []
    if extra_images:
        prompt_parts.append(
            f"Analyze these {len(images_b64)} sequential frames from a screen recording "
            "and produce a Context Pack for a coding agent. The frames are in chronological order."
        )
    else:
        prompt_parts.append("Analyze this screenshot and produce a Context Pack for a coding agent.")

    if voice_transcript:
        prompt_parts.append(
            f"\n\nThe user also provided this voice narration while capturing:\n"
            f'"""\n{voice_transcript}\n"""\n\n'
            "Incorporate the user's spoken intent and any details they mentioned into the Context Pack."
        )

    prompt_text = "\n".join(prompt_parts)

    provider = config.get("provider", "ollama")
    if provider == "openrouter":
        return _call_openrouter(prompt_text, images_b64, config)
    elif provider == "hyperbolic":
        return _call_hyperbolic(prompt_text, images_b64, config)
    elif provider == "gemini":
        return _call_gemini(prompt_text, images_b64, config)
    else:
        return _call_ollama(prompt_text, images_b64, config)


def _call_ollama(prompt_text: str, images_b64: list, config: dict) -> str:
    """Send images + prompt to local Ollama and return the response text."""
    payload = {
        "model": resolve_model(config),
        "prompt": prompt_text,
        "system": SYSTEM_PROMPT,
        "images": images_b64,
        "stream": False,
        "think": False,
        "options": {
            "temperature": 0.2,
            "num_predict": 1536,
        },
    }

    url = f"{config['ollama_url']}/api/generate"

    try:
        import urllib.request

        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=180) as resp:
            raw = resp.read().decode("utf-8")
            result = json.loads(raw)
            response_text = result.get("response", "").strip()
            if not response_text and result.get("thinking"):
                response_text = result["thinking"].strip()

            if not response_text:
                model_used = payload.get("model", "unknown")
                print(f"[eye2byte] WARNING: Ollama returned empty response "
                      f"(model={model_used})", file=sys.stderr)
                print(f"[eye2byte] Raw response keys: {list(result.keys())}", file=sys.stderr)
                if result.get("error"):
                    print(f"[eye2byte] Ollama error: {result['error']}", file=sys.stderr)
                return f"[eye2byte] Model '{model_used}' returned no analysis. Try a larger model."

            return response_text
    except Exception as e:
        return f"[eye2byte] ERROR calling Ollama: {e}\n\nIs Ollama running? Try: ollama serve"


def _call_openrouter(prompt_text: str, images_b64: list, config: dict) -> str:
    """Send images + prompt to OpenRouter API and return the response text."""
    import urllib.request

    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        return (
            "[eye2byte] ERROR: OPENROUTER_API_KEY not set.\n"
            "Set it in your .env file (project dir or ~/.eye2byte/.env):\n"
            "  OPENROUTER_API_KEY=sk-or-v1-..."
        )

    model = config.get("openrouter_model", "qwen/qwen2.5-vl-72b-instruct:free")
    print(f"[eye2byte] Using OpenRouter model: {model}")

    # Build OpenAI-compatible messages with vision content
    content_parts = []
    for i, img_b64 in enumerate(images_b64):
        content_parts.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{img_b64}",
                "detail": "high",  # Use high-res tiling for text readability
            },
        })
    content_parts.append({"type": "text", "text": prompt_text})

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content_parts},
        ],
        "temperature": 0.2,
        "max_tokens": 1536,
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            "https://openrouter.ai/api/v1/chat/completions",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
                "HTTP-Referer": "https://github.com/wolverin0/Eye2byte",
                "X-Title": "Eye2byte",
            },
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        # Extract response
        choices = result.get("choices", [])
        if choices:
            text = choices[0].get("message", {}).get("content", "").strip()
            if text:
                # Log usage if available
                usage = result.get("usage", {})
                if usage:
                    prompt_tok = usage.get("prompt_tokens", "?")
                    comp_tok = usage.get("completion_tokens", "?")
                    print(f"[eye2byte] OpenRouter tokens: {prompt_tok} prompt + {comp_tok} completion")
                return text

        # Error handling
        if result.get("error"):
            err = result["error"]
            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
            return f"[eye2byte] OpenRouter error: {msg}"

        return f"[eye2byte] OpenRouter returned no content. Response keys: {list(result.keys())}"

    except Exception as e:
        return f"[eye2byte] ERROR calling OpenRouter: {e}"


def _call_hyperbolic(prompt_text: str, images_b64: list, config: dict) -> str:
    """Send images + prompt to Hyperbolic API and return the response text."""
    import urllib.request

    api_key = os.environ.get("HYPERBOLIC_API_KEY", "").strip()
    if not api_key:
        return (
            "[eye2byte] ERROR: HYPERBOLIC_API_KEY not set.\n"
            "Set it in your .env file (project dir or ~/.eye2byte/.env):\n"
            "  HYPERBOLIC_API_KEY=your-key-here"
        )

    model = config.get("hyperbolic_model", "Qwen/Qwen2.5-VL-72B-Instruct")
    print(f"[eye2byte] Using Hyperbolic model: {model}")

    # Hyperbolic supports 1 image per request — use the last (most recent) frame
    img_b64 = images_b64[-1] if images_b64 else None
    if not img_b64:
        return "[eye2byte] ERROR: No image data to send to Hyperbolic."

    if len(images_b64) > 1:
        print(f"[eye2byte] Hyperbolic: 1-image limit, using last of {len(images_b64)} frames")

    content_parts = [
        {"type": "text", "text": SYSTEM_PROMPT + "\n\n" + prompt_text},
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{img_b64}"},
        },
    ]

    payload = {
        "model": model,
        "messages": [
            {"role": "user", "content": content_parts},
        ],
        "max_tokens": 512,
        "temperature": 0.1,
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            "https://api.hyperbolic.xyz/v1/chat/completions",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
                "User-Agent": "Eye2byte/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as http_err:
            body = http_err.read().decode("utf-8", errors="replace")[:500]
            return f"[eye2byte] Hyperbolic HTTP {http_err.code}: {body}"

        choices = result.get("choices", [])
        if choices:
            text = choices[0].get("message", {}).get("content", "").strip()
            if text:
                usage = result.get("usage", {})
                if usage:
                    prompt_tok = usage.get("prompt_tokens", "?")
                    comp_tok = usage.get("completion_tokens", "?")
                    print(f"[eye2byte] Hyperbolic tokens: {prompt_tok} prompt + {comp_tok} completion")
                return text

        if result.get("error"):
            err = result["error"]
            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
            return f"[eye2byte] Hyperbolic error: {msg}"

        return f"[eye2byte] Hyperbolic returned no content. Response keys: {list(result.keys())}"

    except Exception as e:
        return f"[eye2byte] ERROR calling Hyperbolic: {e}"


def _call_gemini(prompt_text: str, images_b64: list, config: dict) -> str:
    """Send images + prompt to Google Gemini API and return the response text."""
    import urllib.request
    import urllib.error

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        return (
            "[eye2byte] ERROR: GEMINI_API_KEY not set.\n"
            "Set it in your .env file (project dir or ~/.eye2byte/.env):\n"
            "  GEMINI_API_KEY=your-key-here\n\n"
            "Get a free key at https://aistudio.google.com/apikey"
        )

    model = config.get("gemini_model", "gemini-2.5-flash-lite")
    print(f"[eye2byte] Using Gemini model: {model}")

    # Build Gemini-native multimodal content parts
    parts = []

    # System instruction goes as first text part
    parts.append({"text": SYSTEM_PROMPT + "\n\n" + prompt_text})

    # Add images as inline base64 data
    for img_b64 in images_b64:
        parts.append({
            "inline_data": {
                "mime_type": "image/jpeg",
                "data": img_b64,
            },
        })

    payload = {
        "contents": [
            {"role": "user", "parts": parts},
        ],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": 1536,
        },
    }

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/"
        f"models/{model}:generateContent?key={api_key}"
    )

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as http_err:
            body = http_err.read().decode("utf-8", errors="replace")[:500]
            return f"[eye2byte] Gemini HTTP {http_err.code}: {body}"

        # Extract response from Gemini format
        candidates = result.get("candidates", [])
        if candidates:
            content = candidates[0].get("content", {})
            parts_out = content.get("parts", [])
            text_parts = [p.get("text", "") for p in parts_out if "text" in p]
            text = "\n".join(text_parts).strip()
            if text:
                # Log usage if available
                usage = result.get("usageMetadata", {})
                if usage:
                    prompt_tok = usage.get("promptTokenCount", "?")
                    comp_tok = usage.get("candidatesTokenCount", "?")
                    print(f"[eye2byte] Gemini tokens: {prompt_tok} prompt + {comp_tok} completion")
                return text

        # Check for blocked or error responses
        if result.get("promptFeedback", {}).get("blockReason"):
            reason = result["promptFeedback"]["blockReason"]
            return f"[eye2byte] Gemini blocked the request: {reason}"

        if result.get("error"):
            err = result["error"]
            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
            return f"[eye2byte] Gemini error: {msg}"

        return f"[eye2byte] Gemini returned no content. Response keys: {list(result.keys())}"

    except Exception as e:
        return f"[eye2byte] ERROR calling Gemini: {e}"


def save_summary(image_path: str, summary: str, config: dict,
                 voice_transcript: str = "") -> str:
    """Save the summary next to the image and in the summaries folder."""
    ensure_dirs(config)
    stem = Path(image_path).stem
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary_path = os.path.join(config["summary_dir"], f"{stem}_{timestamp}.md")

    parts = [
        f"# Context Pack\n",
        f"**Source:** `{image_path}`",
        f"**Generated:** {datetime.now().isoformat()}",
    ]
    if voice_transcript:
        parts.append(f"**Voice narration:** {voice_transcript}")
    parts.append(f"\n{summary}\n")
    content = "\n".join(parts)

    with open(summary_path, "w") as f:
        f.write(content)

    print(f"[eye2byte] Summary saved: {summary_path}")
    return summary_path


def copy_to_clipboard(text: str):
    """Best-effort copy to clipboard."""
    # Windows: clip.exe (built-in)
    if _is_windows():
        try:
            proc = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-16-le"))
            print("[eye2byte] Summary copied to clipboard.")
            return
        except Exception:
            pass

    # Android: termux-clipboard-set
    if _is_android() and _command_exists("termux-clipboard-set"):
        try:
            proc = subprocess.Popen(["termux-clipboard-set"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"))
            print("[eye2byte] Summary copied to clipboard.")
            return
        except Exception:
            pass

    for cmd in [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard"], ["pbcopy"]]:
        if _command_exists(cmd[0]):
            try:
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                proc.communicate(text.encode("utf-8"))
                print("[eye2byte] Summary copied to clipboard.")
                return
            except Exception:
                continue


# ---------------------------------------------------------------------------
# Session system — UUID output folders with all artifacts
# ---------------------------------------------------------------------------

def create_session(config: dict) -> dict:
    """
    Create a new capture session with a short UUID folder.

    Returns a session dict with:
        id      — 8-char UUID
        dir     — absolute path to the session folder
        created — ISO timestamp
    """
    session_id = uuid.uuid4().hex[:8]
    output_dir = config["output_dir"]
    session_dir = os.path.join(output_dir, session_id)
    os.makedirs(session_dir, exist_ok=True)

    return {
        "id": session_id,
        "dir": session_dir,
        "created": datetime.now().isoformat(),
        "capture": None,
        "voice": None,
        "transcript": None,
        "context_pack": None,
        "keyframes": [],
        "keyframes_grid": None,
        "description": "",
    }


def stitch_keyframes(frame_paths: list, output_path: str, config: dict) -> str:
    """
    Stitch keyframes into a single horizontal strip or grid image.
    This is better than a GIF for LLMs — they see the full timeline in one shot.
    Uses ffmpeg (already a dependency for clips).
    """
    if not frame_paths or not _command_exists("ffmpeg"):
        return ""

    n = len(frame_paths)

    if n == 1:
        # Just copy the single frame
        shutil.copy2(frame_paths[0], output_path)
        return output_path if os.path.exists(output_path) else ""

    # Build ffmpeg filter: scale all frames to same height, then hstack
    # For <= 4 frames: horizontal strip
    # For > 4 frames: 2-row grid
    inputs = []
    filter_parts = []

    for i, fp in enumerate(frame_paths):
        inputs += ["-i", fp]
        filter_parts.append(f"[{i}:v]scale=-1:360[s{i}]")

    if n <= 4:
        # Single row horizontal strip
        stack_inputs = "".join(f"[s{i}]" for i in range(n))
        filter_parts.append(f"{stack_inputs}hstack=inputs={n}[out]")
    else:
        # Two rows: split evenly
        top_n = math.ceil(n / 2)
        bot_n = n - top_n

        top_inputs = "".join(f"[s{i}]" for i in range(top_n))
        filter_parts.append(f"{top_inputs}hstack=inputs={top_n}[top]")

        bot_inputs = "".join(f"[s{i}]" for i in range(top_n, n))
        if bot_n > 1:
            filter_parts.append(f"{bot_inputs}hstack=inputs={bot_n}[bot_raw]")
            # Pad bottom row to match top width
            filter_parts.append("[bot_raw]pad=iw:ih:0:0:color=black[bot]")
        else:
            filter_parts.append(f"{bot_inputs}pad=iw*{top_n}:ih:0:0:color=black[bot]")

        filter_parts.append("[top][bot]vstack[out]")

    filter_str = ";".join(filter_parts)

    try:
        cmd = ["ffmpeg", "-y"] + inputs + [
            "-filter_complex", filter_str,
            "-map", "[out]", "-q:v", "2", output_path,
        ]
        subprocess.run(cmd, capture_output=True, check=True, timeout=30)
        if os.path.exists(output_path):
            print(f"[eye2byte] Keyframes stitched: {output_path}")
            return output_path
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        print(f"[eye2byte] Keyframe stitching failed: {e}", file=sys.stderr)

    return ""


def save_session(session: dict, config: dict) -> str:
    """
    Write all artifacts to the session folder and create manifest.json.
    Returns the session directory path.
    """
    session_dir = session["dir"]

    # Write transcript as plain text
    if session.get("transcript"):
        transcript_path = os.path.join(session_dir, "transcript.txt")
        with open(transcript_path, "w", encoding="utf-8") as f:
            f.write(session["transcript"])

    # Write context pack as markdown (always write it, even if summary is empty/error)
    pack_path = os.path.join(session_dir, "context_pack.md")
    context_pack = session.get("context_pack") or ""
    parts = [
        f"# Context Pack — {session['id']}\n",
        f"**Session:** `{session['id']}`",
        f"**Created:** {session['created']}",
    ]
    if session.get("capture"):
        parts.append(f"**Capture:** `{os.path.basename(session['capture'])}`")
    if session.get("transcript"):
        parts.append(f"\n**Voice transcript:**\n> {session['transcript']}")
    if context_pack:
        parts.append(f"\n---\n\n{context_pack}\n")
    else:
        parts.append("\n---\n\n*No analysis generated. Check Ollama connection.*\n")
    with open(pack_path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))

    # Write description if provided
    if session.get("description"):
        desc_path = os.path.join(session_dir, "description.txt")
        with open(desc_path, "w", encoding="utf-8") as f:
            f.write(session["description"])

    # Build manifest
    manifest = {
        "id": session["id"],
        "created": session["created"],
        "artifacts": {},
    }

    for key in ["capture", "voice", "keyframes_grid"]:
        if session.get(key):
            manifest["artifacts"][key] = os.path.basename(session[key])

    if session.get("transcript"):
        manifest["artifacts"]["transcript"] = "transcript.txt"
    manifest["artifacts"]["context_pack"] = "context_pack.md"
    if session.get("description"):
        manifest["artifacts"]["description"] = "description.txt"
    if session.get("keyframes"):
        manifest["artifacts"]["keyframes"] = [
            os.path.basename(f) for f in session["keyframes"]
        ]

    manifest_path = os.path.join(session_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    print(f"[eye2byte] Session saved: {session_dir}")
    return session_dir


def finalize_session(session: dict, config: dict):
    """Save session, copy @path to clipboard, and optionally show floating UI."""
    save_session(session, config)

    at_path = f"@{session['dir']}"
    print(f"\n[eye2byte] Ready to paste: {at_path}")

    if config.get("auto_copy_to_clipboard", True):
        copy_to_clipboard(at_path)

    if config.get("show_ui", True):
        _launch_floating_ui(session["dir"])


def _launch_floating_ui(session_dir: str):
    """Launch the floating UI as a detached subprocess."""
    ui_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "eye2byte_ui.py")
    if not os.path.exists(ui_script):
        return

    try:
        if _is_windows():
            # On Windows, use pythonw to avoid console window, or fall back to python
            python = shutil.which("pythonw") or shutil.which("python") or "python"
            subprocess.Popen(
                [python, ui_script, session_dir],
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW,
            )
        else:
            python = shutil.which("python3") or shutil.which("python") or "python3"
            subprocess.Popen(
                [python, ui_script, session_dir],
                start_new_session=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass  # UI is optional, don't fail the whole session


# ---------------------------------------------------------------------------
# Folder watcher
# ---------------------------------------------------------------------------

def watch_folder(config: dict):
    """
    Watch capture_dir for new images and auto-summarize them.
    Pair this with ShareX, Flameshot, or any tool that saves to a folder.
    """
    ensure_dirs(config)
    watch_dir = config["capture_dir"]
    seen = set(os.listdir(watch_dir))
    interval = config["watch_interval"]

    print(f"[eye2byte] Watching {watch_dir} for new screenshots...")
    print("[eye2byte] Press Ctrl+C to stop.\n")

    IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".webp")
    VIDEO_EXTS = (".mp4", ".mkv", ".webm", ".avi", ".mov")

    try:
        while True:
            current = set(os.listdir(watch_dir))
            new_files = current - seen
            for fname in sorted(new_files):
                fpath = os.path.join(watch_dir, fname)
                lower = fname.lower()

                if lower.endswith(IMAGE_EXTS):
                    time.sleep(0.5)
                    print(f"\n[eye2byte] New screenshot detected: {fname}")
                    print("[eye2byte] Generating Context Pack...")
                    summary = summarize_image(fpath, config)
                    print("\n" + summary + "\n")
                    save_summary(fpath, summary, config)
                    if config["auto_copy_to_clipboard"]:
                        copy_to_clipboard(summary)

                elif lower.endswith(VIDEO_EXTS):
                    time.sleep(1.0)  # Clips may take longer to finish writing
                    print(f"\n[eye2byte] New clip detected: {fname}")
                    frames = extract_keyframes(fpath, config)
                    voice_text = ""
                    audio = extract_audio_from_clip(fpath, config)
                    if audio:
                        print("[eye2byte] Transcribing clip audio...")
                        voice_text = transcribe_voice(audio, config)
                    if frames:
                        print("[eye2byte] Generating Context Pack from keyframes...")
                        summary = summarize_image(
                            frames[0], config,
                            voice_transcript=voice_text,
                            extra_images=frames[1:],
                        )
                    else:
                        summary = "[eye2byte] Could not extract frames from clip."
                    print("\n" + summary + "\n")
                    save_summary(fpath, summary, config, voice_transcript=voice_text)
                    if config["auto_copy_to_clipboard"]:
                        copy_to_clipboard(summary)

            seen = current
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n[eye2byte] Watcher stopped.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _run_capture_session(config, mode="full", with_voice=False, description=""):
    """
    Full capture pipeline: screenshot (+ optional voice) → Ollama → session folder.
    Everything goes into a UUID output folder.
    """
    timings = {}
    pipeline_start = time.time()

    session = create_session(config)

    # Start voice recording in parallel if requested
    voice_thread = None
    voice_result = None
    if with_voice:
        voice_thread, voice_result = record_voice_async(config)

    # Capture screenshot directly into session folder
    t0 = time.time()
    capture_path = os.path.join(session["dir"], "capture.png")
    orig_capture_dir = config["capture_dir"]
    config["capture_dir"] = session["dir"]
    raw_path = capture_screen(config, mode=mode)
    config["capture_dir"] = orig_capture_dir
    timings["screenshot"] = time.time() - t0

    # Rename to standard name if needed
    if raw_path != capture_path and os.path.exists(raw_path):
        shutil.move(raw_path, capture_path)
    session["capture"] = capture_path

    # Log capture size
    if os.path.exists(capture_path):
        cap_kb = os.path.getsize(capture_path) / 1024
        timings["capture_size_kb"] = round(cap_kb)

    # Wait for voice and transcribe
    voice_text = ""
    if voice_thread:
        print("[eye2byte] Waiting for voice recording to finish (Ctrl+C to stop early)...")
        voice_thread.join()
        if voice_result["path"]:
            # Move voice file into session folder
            voice_dest = os.path.join(session["dir"], "voice.wav")
            shutil.move(voice_result["path"], voice_dest)
            session["voice"] = voice_dest

            t0 = time.time()
            print("[eye2byte] Transcribing voice...")
            voice_text = transcribe_voice(voice_dest, config)
            timings["transcription"] = time.time() - t0
            if voice_text:
                session["transcript"] = voice_text
                print(f"[eye2byte] You said: \"{voice_text[:100]}{'...' if len(voice_text) > 100 else ''}\"")

    if description:
        session["description"] = description

    # Send to Ollama
    t0 = time.time()
    print("[eye2byte] Generating Context Pack...")
    summary = summarize_image(capture_path, config, voice_transcript=voice_text)
    timings["ollama_analysis"] = time.time() - t0
    session["context_pack"] = summary

    # Print summary with clear separators so it's visible in console output
    print("\n" + "=" * 60)
    print("  CONTEXT PACK")
    print("=" * 60)
    if summary:
        print(summary)
    else:
        print("[eye2byte] WARNING: Ollama returned an empty response.")
        print("  Check that your vision model is working: ollama run " +
              resolve_model(config))
    print("=" * 60 + "\n")

    # Also save legacy summary
    save_summary(capture_path, summary, config, voice_transcript=voice_text)

    # Finalize: save manifest, copy @path, show UI
    t0 = time.time()
    finalize_session(session, config)
    timings["save_and_finalize"] = time.time() - t0

    timings["total"] = time.time() - pipeline_start

    # Print timing breakdown
    print("-" * 60)
    print("  TIMING BREAKDOWN")
    print("-" * 60)
    if "capture_size_kb" in timings:
        print(f"  Capture size:     {timings['capture_size_kb']} KB")
    print(f"  Screenshot:       {timings.get('screenshot', 0):.1f}s")
    if "transcription" in timings:
        print(f"  Transcription:    {timings['transcription']:.1f}s")
    print(f"  Ollama analysis:  {timings.get('ollama_analysis', 0):.1f}s")
    print(f"  Save & finalize:  {timings.get('save_and_finalize', 0):.1f}s")
    print(f"  ─────────────────────────")
    print(f"  Total:            {timings['total']:.1f}s")
    print("-" * 60)

    # Save timings to session
    timings_path = os.path.join(session["dir"], "timings.json")
    with open(timings_path, "w") as f:
        json.dump(timings, f, indent=2)

    return session


def _run_clip_session(config, duration=None, with_voice=False, keyframes=None):
    """
    Full clip pipeline: record → extract keyframes → stitch grid → Ollama → session folder.
    """
    session = create_session(config)

    duration = duration or config.get("clip_duration", 10)
    if keyframes:
        config["clip_keyframes"] = keyframes

    # Start voice recording in parallel if requested
    voice_thread = None
    voice_result = None
    voice_text = ""
    if with_voice:
        voice_thread, voice_result = record_voice_async(config, duration=duration)

    # Record clip
    clip_path = record_clip(config, duration=duration, with_audio=with_voice)

    # Wait for voice
    if voice_thread:
        voice_thread.join()
        if voice_result["path"]:
            voice_dest = os.path.join(session["dir"], "voice.wav")
            shutil.move(voice_result["path"], voice_dest)
            session["voice"] = voice_dest
            print("[eye2byte] Transcribing voice...")
            voice_text = transcribe_voice(voice_dest, config)
            if voice_text:
                session["transcript"] = voice_text
                print(f'[eye2byte] You said: "{voice_text[:100]}{"..." if len(voice_text) > 100 else ""}"')

    if not clip_path:
        print("[eye2byte] Clip recording failed.", file=sys.stderr)
        sys.exit(1)

    # Move clip to session folder
    clip_dest = os.path.join(session["dir"], "clip.mp4")
    shutil.move(clip_path, clip_dest)

    # If no voice, try extracting audio from clip
    if not voice_text and not with_voice:
        audio = extract_audio_from_clip(clip_dest, config)
        if audio:
            voice_text = transcribe_voice(audio, config)
            if voice_text:
                session["transcript"] = voice_text

    # Extract keyframes
    frames = extract_keyframes(clip_dest, config)
    if frames:
        # Move frames into session folder
        session_frames = []
        for i, fp in enumerate(frames):
            dest = os.path.join(session["dir"], f"frame_{i + 1:02d}.png")
            shutil.move(fp, dest)
            session_frames.append(dest)
        session["keyframes"] = session_frames

        # Stitch into grid image
        grid_path = os.path.join(session["dir"], "keyframes_grid.png")
        stitched = stitch_keyframes(session_frames, grid_path, config)
        if stitched:
            session["keyframes_grid"] = stitched
            session["capture"] = stitched  # Use grid as primary image for manifest

        # Summarize
        print("[eye2byte] Generating Context Pack from keyframes...")
        summary = summarize_image(
            session_frames[0], config,
            voice_transcript=voice_text,
            extra_images=session_frames[1:],
        )
        session["context_pack"] = summary
        print("\n" + "=" * 60)
        print("  CONTEXT PACK")
        print("=" * 60)
        print(summary if summary else "[eye2byte] WARNING: Empty response from Ollama.")
        print("=" * 60 + "\n")
        save_summary(clip_dest, summary, config, voice_transcript=voice_text)
    else:
        print("[eye2byte] Could not extract keyframes from clip.", file=sys.stderr)

    finalize_session(session, config)
    return session


def main():
    parser = argparse.ArgumentParser(
        description="Eye2byte — Screen-context sidecar for coding agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command")

    # capture
    cap = sub.add_parser("capture", help="Capture full screen and summarize")
    cap.add_argument("--mode", choices=["full", "window", "region"], default="full")
    cap.add_argument("--no-summary", action="store_true", help="Capture only, skip summarization")
    cap.add_argument("--voice", "-v", action="store_true",
                     help="Record voice narration while capturing (adds your spoken context)")
    cap.add_argument("--describe", type=str, default="",
                     help="Short text description of what you're capturing")

    # region (shortcut)
    reg = sub.add_parser("region", help="Capture a screen region and summarize")
    reg.add_argument("--voice", "-v", action="store_true", help="Record voice narration")

    # clip
    cl = sub.add_parser("clip", help="Record a short screen clip and summarize keyframes")
    cl.add_argument("--duration", "-d", type=int, default=None,
                    help="Clip duration in seconds (default: 10)")
    cl.add_argument("--voice", "-v", action="store_true",
                    help="Also record voice narration during the clip")
    cl.add_argument("--keyframes", "-k", type=int, default=None,
                    help="Number of keyframes to extract (default: 5)")

    # voice (standalone — just record and transcribe)
    vo = sub.add_parser("voice", help="Record voice note and transcribe it")
    vo.add_argument("--duration", "-d", type=int, default=None,
                    help="Max recording duration in seconds (default: 30)")

    # summarize
    s = sub.add_parser("summarize", help="Summarize an existing screenshot or clip")
    s.add_argument("image", help="Path to screenshot image or video clip")

    # watch
    sub.add_parser("watch", help="Watch capture folder for new screenshots and clips")

    # config
    sub.add_parser("init", help="Create default config file")

    args = parser.parse_args()
    config = load_config()

    if args.command == "capture":
        if args.no_summary:
            # Raw capture only, no session
            path = capture_screen(config, mode=args.mode)
            print(f"[eye2byte] Saved: {path}")
        else:
            desc = getattr(args, "describe", "") or ""
            _run_capture_session(
                config, mode=args.mode, with_voice=args.voice, description=desc,
            )

    elif args.command == "region":
        _run_capture_session(config, mode="region", with_voice=args.voice)

    elif args.command == "clip":
        _run_clip_session(
            config,
            duration=args.duration,
            with_voice=args.voice,
            keyframes=args.keyframes,
        )

    elif args.command == "voice":
        # Standalone voice — creates a minimal session
        session = create_session(config)
        duration = args.duration or config.get("voice_duration", 30)
        path = record_voice(config, duration=duration)
        if path:
            voice_dest = os.path.join(session["dir"], "voice.wav")
            shutil.move(path, voice_dest)
            session["voice"] = voice_dest

            print("[eye2byte] Transcribing...")
            text = transcribe_voice(voice_dest, config)
            if text:
                session["transcript"] = text
                print(f"\n--- Voice Transcript ---\n{text}\n")
            else:
                print("[eye2byte] Transcription failed.")

            finalize_session(session, config)

    elif args.command == "summarize":
        if not os.path.exists(args.image):
            print(f"[eye2byte] File not found: {args.image}", file=sys.stderr)
            sys.exit(1)

        session = create_session(config)
        lower = args.image.lower()

        if lower.endswith((".mp4", ".mkv", ".webm", ".avi", ".mov")):
            print("[eye2byte] Processing clip...")
            frames = extract_keyframes(args.image, config)
            voice_text = ""
            audio = extract_audio_from_clip(args.image, config)
            if audio:
                print("[eye2byte] Transcribing clip audio...")
                voice_text = transcribe_voice(audio, config)
                if voice_text:
                    session["transcript"] = voice_text

            if frames:
                # Move frames to session
                session_frames = []
                for i, fp in enumerate(frames):
                    dest = os.path.join(session["dir"], f"frame_{i + 1:02d}.png")
                    shutil.copy2(fp, dest)
                    session_frames.append(dest)
                session["keyframes"] = session_frames

                grid_path = os.path.join(session["dir"], "keyframes_grid.png")
                stitched = stitch_keyframes(session_frames, grid_path, config)
                if stitched:
                    session["keyframes_grid"] = stitched

                summary = summarize_image(
                    session_frames[0], config,
                    voice_transcript=voice_text,
                    extra_images=session_frames[1:],
                )
                session["context_pack"] = summary
                print("\n" + "=" * 60)
                print("  CONTEXT PACK")
                print("=" * 60)
                print(summary if summary else "[eye2byte] WARNING: Empty response.")
                print("=" * 60 + "\n")
            else:
                print("[eye2byte] Could not extract frames.", file=sys.stderr)
                sys.exit(1)
        else:
            # Copy image into session folder
            capture_dest = os.path.join(session["dir"], "capture.png")
            shutil.copy2(args.image, capture_dest)
            session["capture"] = capture_dest

            print("[eye2byte] Generating Context Pack...")
            summary = summarize_image(capture_dest, config)
            session["context_pack"] = summary
            print("\n" + "=" * 60)
            print("  CONTEXT PACK")
            print("=" * 60)
            print(summary if summary else "[eye2byte] WARNING: Empty response.")
            print("=" * 60 + "\n")

        finalize_session(session, config)

    elif args.command == "watch":
        watch_folder(config)

    elif args.command == "init":
        config_path = Path("~/.eye2byte/config.json").expanduser()
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        print(f"[eye2byte] Config created: {config_path}")
        print("[eye2byte] Edit it to change model, output_dir, etc.")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
