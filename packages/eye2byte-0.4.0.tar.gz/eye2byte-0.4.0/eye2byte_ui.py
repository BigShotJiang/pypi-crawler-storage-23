#!/usr/bin/env python3
"""
Eye2byte Control Panel — persistent floating UI with global hotkeys.

Runs as an always-on-top control panel for capturing screen context.

Modes:
    python eye2byte_ui.py                  # Launch persistent panel
    python eye2byte_ui.py <session_dir>    # Show popup for existing session

Hotkeys (Windows):
    Ctrl+Shift+1  —  Capture screenshot
    Ctrl+Shift+2  —  Annotate (draw on frozen screen)
    Ctrl+Shift+3  —  Voice recording (toggle: press to start, press to stop)
    Ctrl+Shift+5  —  Grab clipboard image

Voice recording is an independent toggle. While recording, captures taken
via Ctrl+Shift+1 or Ctrl+Shift+2 are automatically bundled with the voice.
"""

import json
import os
import shutil
import subprocess
import sys
import threading
import time

# Hide the console window on Windows (no black terminal behind the UI)
if sys.platform == "win32":
    import ctypes
    _hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if _hwnd:
        ctypes.windll.user32.ShowWindow(_hwnd, 0)  # SW_HIDE

# Fix Windows console encoding — prevents crashes on emoji/unicode in LLM output
if sys.platform == "win32":
    for _stream in (sys.stdout, sys.stderr):
        if hasattr(_stream, "reconfigure"):
            _stream.reconfigure(errors="replace")

# ---------------------------------------------------------------------------
# Ensure eye2byte module is importable
# ---------------------------------------------------------------------------
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

# ---------------------------------------------------------------------------
# UI framework — CustomTkinter for modern look, fallback to tkinter
# ---------------------------------------------------------------------------
import tkinter as tk  # Always needed for Canvas (annotations)

try:
    import customtkinter as ctk
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    _HAS_CTK = True
except ImportError:
    _HAS_CTK = False
    print("[eye2byte] For modern UI: pip install customtkinter")

# System tray support (optional — graceful fallback to just hiding the window)
try:
    import pystray
    from PIL import Image as _PilImage
    _HAS_TRAY = True
except ImportError:
    _HAS_TRAY = False

# ---------------------------------------------------------------------------
# Clipboard helper
# ---------------------------------------------------------------------------

def copy_to_clipboard(text: str):
    """Cross-platform clipboard copy."""
    if sys.platform == "win32":
        try:
            proc = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-16-le"))
            return True
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"))
            return True
        except Exception:
            pass
    else:
        for cmd in [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard"]]:
            if shutil.which(cmd[0]):
                try:
                    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    proc.communicate(text.encode("utf-8"))
                    return True
                except Exception:
                    continue
    return False


def get_clipboard_image(output_path: str) -> bool:
    """Save clipboard image to file. Returns True on success."""
    if sys.platform == "win32":
        ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$img = [System.Windows.Forms.Clipboard]::GetImage()
if ($img) {{
    $img.Save("{output_path}", [System.Drawing.Imaging.ImageFormat]::Png)
    Write-Output "ok"
}} else {{
    Write-Output "no_image"
}}
'''
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                capture_output=True, text=True, timeout=10,
            )
            return "ok" in result.stdout and os.path.exists(output_path)
        except Exception:
            return False
    return False


# ---------------------------------------------------------------------------
# Colors / Theme
# ---------------------------------------------------------------------------
BG = "#1a1a2e"
BG_DARK = "#12122a"
BG_CARD = "#1e1e3a"
FG = "#e0e0e0"
ACCENT = "#4f6df5"
GREEN = "#16c784"
GREEN_HOVER = "#1de996"
RED = "#e74c3c"
RED_HOVER = "#c0392b"
ORANGE = "#f39c12"
BLUE = "#3498db"
BLUE_HOVER = "#2980b9"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
MUTED = "#555555"
MUTED_HOVER = "#666666"
MUTED_LIGHT = "#888888"
BORDER = "#2a2a4e"

# Annotation colors (used by Canvas overlay)
ANNO_RED = "#ff3333"
ANNO_LINE_WIDTH = 3

# Icon path — shipped alongside the .py files
_ICON_PATH = os.path.join(_script_dir, "eye2byte.ico")


def _load_tray_icon():
    """Load the app icon as a PIL Image for pystray. Generates a fallback if file missing."""
    if os.path.exists(_ICON_PATH):
        return _PilImage.open(_ICON_PATH)
    # Fallback: solid blue circle
    img = _PilImage.new("RGBA", (64, 64), (0, 0, 0, 0))
    from PIL import ImageDraw
    ImageDraw.Draw(img).ellipse([4, 4, 60, 60], fill="#4f6df5")
    return img


# ---------------------------------------------------------------------------
# Annotation Overlay — fullscreen canvas for drawing on a frozen screenshot
# ---------------------------------------------------------------------------
class AnnotationOverlay:
    """
    Fullscreen overlay for drawing arrows, circles, and rectangles on a
    frozen screenshot. Press Enter to save, Escape to cancel.
    """

    def __init__(self, screenshot_path: str, callback, hotkey_config: dict = None):
        """
        Args:
            screenshot_path: Path to the screenshot PNG to annotate.
            callback: Called with (annotated_image_path, annotations_list) on save.
            hotkey_config: Optional hotkey configuration dict for tool shortcuts.
        """
        self.screenshot_path = screenshot_path
        self.callback = callback
        self.annotations = []  # List of annotation dicts
        self.current_item = None
        self.start_x = 0
        self.start_y = 0
        self.tool = "arrow"  # arrow, circle, rect, freehand, text
        self._hotkey_config = hotkey_config or {}
        self._pil_available = False

        try:
            from PIL import Image, ImageTk, ImageDraw
            self._pil_available = True
        except ImportError:
            pass

        if not self._pil_available:
            print("[eye2byte] Pillow required for annotation: pip install Pillow")
            return

        from PIL import Image, ImageTk

        self.root = tk.Toplevel() if tk._default_root else tk.Tk()
        self.root.attributes("-topmost", True)
        self.root.attributes("-fullscreen", True)
        self.root.configure(bg="black")

        # Load screenshot
        self.pil_image = Image.open(screenshot_path)
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()

        # Resize image to fill screen
        self.pil_image = self.pil_image.resize((screen_w, screen_h), Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(self.pil_image)

        # Canvas
        self.canvas = tk.Canvas(
            self.root, width=screen_w, height=screen_h,
            highlightthickness=0, cursor="crosshair",
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, image=self.tk_image, anchor="nw")

        # Toolbar at top
        self._build_toolbar()

        # Instructions at bottom
        self.canvas.create_text(
            screen_w // 2, screen_h - 30,
            text="Left-drag: draw  |  Middle-click: add text  |  Right-click: remove nearest  |  Enter: save  |  Esc: cancel",
            font=("Consolas", 11), fill="#ffffff",
            tags="instructions",
        )
        # Dim background behind text
        bbox = self.canvas.bbox("instructions")
        if bbox:
            self.canvas.create_rectangle(
                bbox[0] - 8, bbox[1] - 4, bbox[2] + 8, bbox[3] + 4,
                fill="#000000", stipple="gray50", outline="",
            )
            self.canvas.tag_raise("instructions")

        # Bind events
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<ButtonPress-2>", self._on_middle_click)  # Middle click = text
        self.canvas.bind("<ButtonPress-3>", self._on_undo)
        self.root.bind("<Return>", self._on_save)
        self.root.bind("<Escape>", self._on_cancel)

        # Tool shortcuts (single key) — ignored when a Text widget has focus
        def _tool_key(tool_id):
            def handler(e):
                if isinstance(e.widget, tk.Text):
                    return  # Don't hijack text input
                self._select_tool(tool_id)
            return handler

        tool_keys = {
            "arrow": self._hotkey_config.get("tool_arrow", "x"),
            "circle": self._hotkey_config.get("tool_circle", "c"),
            "rect": self._hotkey_config.get("tool_rect", "v"),
            "freehand": self._hotkey_config.get("tool_freehand", "b"),
            "text": self._hotkey_config.get("tool_text", "t"),
        }
        for tool_id, key_str in tool_keys.items():
            tk_key = parse_tk_key(key_str)
            self.root.bind(tk_key, _tool_key(tool_id))

    def _build_toolbar(self):
        """Draw tool selection buttons at bottom-center of the canvas."""
        hk = self._hotkey_config
        tools = [
            ("Arrow", "arrow", hk.get("tool_arrow", "x").upper()),
            ("Circle", "circle", hk.get("tool_circle", "c").upper()),
            ("Rect", "rect", hk.get("tool_rect", "v").upper()),
            ("Free", "freehand", hk.get("tool_freehand", "b").upper()),
            ("Text", "text", hk.get("tool_text", "t").upper()),
        ]
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        btn_w, btn_h, gap = 80, 34, 6
        total_w = len(tools) * btn_w + (len(tools) - 1) * gap
        start_x = (screen_w - total_w) // 2
        y_top = screen_h - 80  # Above the instruction text

        # Background pill behind all buttons
        pill_pad = 10
        self.canvas.create_rectangle(
            start_x - pill_pad, y_top - pill_pad,
            start_x + total_w + pill_pad, y_top + btn_h + pill_pad,
            fill="#000000", stipple="gray50", outline="#333333",
            width=1, tags="toolbar_bg",
        )

        x_offset = start_x
        for label, tool_id, shortcut in tools:
            is_active = tool_id == self.tool
            fill = GREEN if is_active else ACCENT
            tag = f"tool_{tool_id}"

            self.canvas.create_rectangle(
                x_offset, y_top, x_offset + btn_w, y_top + btn_h,
                fill=fill, outline="#ffffff", width=1, tags=tag,
            )
            self.canvas.create_text(
                x_offset + btn_w // 2, y_top + btn_h // 2,
                text=f"{label} [{shortcut}]",
                font=("Segoe UI", 10, "bold"), fill="#ffffff", tags=tag,
            )
            self.canvas.tag_bind(tag, "<Button-1>",
                                 lambda e, t=tool_id: self._select_tool(t))
            x_offset += btn_w + gap

    def _select_tool(self, tool_id):
        self.tool = tool_id
        # Rebuild toolbar to update highlight
        self.canvas.delete("toolbar_bg", "tool_arrow", "tool_circle",
                           "tool_rect", "tool_freehand", "tool_text")
        self._build_toolbar()

    def _on_middle_click(self, event):
        """Middle click always opens text entry regardless of current tool."""
        self._place_text(event.x, event.y)

    def _place_text(self, x, y):
        """Open a multi-line text entry at the given position."""
        text_widget = tk.Text(
            self.root, font=("Segoe UI", 14, "bold"),
            bg="#000000", fg=ANNO_RED, insertbackground=ANNO_RED,
            relief="flat", width=30, height=1,
            wrap="word", undo=True,
        )
        entry_window = self.canvas.create_window(x, y, window=text_widget, anchor="nw")
        text_widget.focus_set()

        def _auto_grow(e=None):
            line_count = int(text_widget.index("end-1c").split(".")[0])
            new_h = min(max(line_count, 1), 6)
            text_widget.configure(height=new_h)

        def _commit(e=None):
            content = text_widget.get("1.0", "end-1c").strip()
            self.canvas.delete(entry_window)
            text_widget.destroy()
            if content:
                item = self.canvas.create_text(
                    x, y, text=content, font=("Segoe UI", 16, "bold"),
                    fill=ANNO_RED, anchor="nw", width=400,
                )
                self.annotations.append({
                    "type": "text", "from": [x, y], "to": [x, y],
                    "label": content, "canvas_item": item,
                })
            return "break"

        def _on_key(e):
            if e.keysym == "Return" and not (e.state & 0x1):  # Enter without Shift
                _commit()
                return "break"
            if e.keysym == "Return" and (e.state & 0x1):  # Shift+Enter = newline
                text_widget.after(10, _auto_grow)
                return
            text_widget.after(10, _auto_grow)

        def _cancel_text(e=None):
            self.canvas.delete(entry_window)
            text_widget.destroy()
            return "break"

        text_widget.bind("<Key>", _on_key)
        text_widget.bind("<Escape>", _cancel_text)

    def _on_press(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.current_item = None
        if self.tool == "text":
            self._place_text(event.x, event.y)
            return
        if self.tool == "freehand":
            self._freehand_points = [(event.x, event.y)]

    def _on_drag(self, event):
        if self.current_item:
            self.canvas.delete(self.current_item)

        if self.tool == "arrow":
            self.current_item = self.canvas.create_line(
                self.start_x, self.start_y, event.x, event.y,
                fill=ANNO_RED, width=ANNO_LINE_WIDTH, arrow="last",
                arrowshape=(16, 20, 6),
            )
        elif self.tool == "circle":
            self.current_item = self.canvas.create_oval(
                self.start_x, self.start_y, event.x, event.y,
                outline=ANNO_RED, width=ANNO_LINE_WIDTH,
            )
        elif self.tool == "rect":
            self.current_item = self.canvas.create_rectangle(
                self.start_x, self.start_y, event.x, event.y,
                outline=ANNO_RED, width=ANNO_LINE_WIDTH,
            )
        elif self.tool == "freehand":
            self._freehand_points.append((event.x, event.y))
            if len(self._freehand_points) >= 2:
                if self.current_item:
                    self.canvas.delete(self.current_item)
                self.current_item = self.canvas.create_line(
                    *[c for p in self._freehand_points for c in p],
                    fill=ANNO_RED, width=ANNO_LINE_WIDTH, smooth=True,
                )

    def _on_release(self, event):
        if self.current_item:
            annotation = {
                "type": self.tool,
                "from": [self.start_x, self.start_y],
                "to": [event.x, event.y],
                "canvas_item": self.current_item,
            }
            if self.tool == "freehand" and hasattr(self, "_freehand_points"):
                annotation["points"] = list(self._freehand_points)
            self.annotations.append(annotation)
            self.current_item = None

    def _on_undo(self, event):
        """Right-click removes the closest annotation to the click point."""
        if not self.annotations:
            return
        import math

        click_x, click_y = event.x, event.y
        best_idx = -1
        best_dist = float("inf")

        for i, a in enumerate(self.annotations):
            x1, y1 = a["from"]
            x2, y2 = a["to"]
            # Distance to annotation center
            cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
            d = math.hypot(click_x - cx, click_y - cy)
            # Also check distance to endpoints (better for arrows/lines)
            d = min(d, math.hypot(click_x - x1, click_y - y1))
            d = min(d, math.hypot(click_x - x2, click_y - y2))
            if d < best_dist:
                best_dist = d
                best_idx = i

        if best_idx >= 0:
            removed = self.annotations.pop(best_idx)
            if removed.get("canvas_item"):
                self.canvas.delete(removed["canvas_item"])

    def _on_save(self, event):
        """Save the annotated image using PIL."""
        # Don't save if a text entry is currently focused
        if isinstance(event.widget, tk.Text):
            return
        from PIL import Image, ImageDraw

        img = self.pil_image.copy()
        draw = ImageDraw.Draw(img)

        for a in self.annotations:
            x1, y1 = a["from"]
            x2, y2 = a["to"]

            if a["type"] == "arrow":
                draw.line([(x1, y1), (x2, y2)], fill=ANNO_RED, width=ANNO_LINE_WIDTH)
                # Draw arrowhead (~25° spread, pointing backward from tip)
                import math
                angle = math.atan2(y2 - y1, x2 - x1)
                arrow_len = 20
                for offset in [math.pi - 0.45, math.pi + 0.45]:
                    ax = x2 + arrow_len * math.cos(angle + offset)
                    ay = y2 + arrow_len * math.sin(angle + offset)
                    draw.line([(x2, y2), (int(ax), int(ay))],
                              fill=ANNO_RED, width=ANNO_LINE_WIDTH)

            elif a["type"] == "circle":
                draw.ellipse([(min(x1, x2), min(y1, y2)),
                              (max(x1, x2), max(y1, y2))],
                             outline=ANNO_RED, width=ANNO_LINE_WIDTH)

            elif a["type"] == "rect":
                draw.rectangle([(min(x1, x2), min(y1, y2)),
                                (max(x1, x2), max(y1, y2))],
                               outline=ANNO_RED, width=ANNO_LINE_WIDTH)

            elif a["type"] == "freehand" and a.get("points"):
                pts = [(p[0], p[1]) for p in a["points"]]
                if len(pts) >= 2:
                    draw.line(pts, fill=ANNO_RED, width=ANNO_LINE_WIDTH)

            elif a["type"] == "text" and a.get("label"):
                try:
                    from PIL import ImageFont
                    font = ImageFont.truetype("arial.ttf", 24)
                except Exception:
                    font = ImageDraw.Draw(img).getfont()
                draw.text((x1, y1), a["label"], fill=ANNO_RED, font=font)

        # Save annotated image
        annotated_path = self.screenshot_path.replace(".png", "_annotated.png")
        img.save(annotated_path, "PNG")

        # Build annotations list (without canvas_item references)
        clean_annotations = []
        for a in self.annotations:
            entry = {"type": a["type"], "from": a["from"], "to": a["to"]}
            if a.get("points"):
                entry["points"] = a["points"]
            if a.get("label"):
                entry["label"] = a["label"]
            clean_annotations.append(entry)

        self.root.destroy()
        self.callback(annotated_path, clean_annotations)

    def _on_cancel(self, event):
        self.root.destroy()
        self.callback(None, [])


# ---------------------------------------------------------------------------
# Hotkey string parsing
# ---------------------------------------------------------------------------

# Maps string tokens to Windows virtual key codes
_VK_MAP = {
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
    "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,
    "a": 0x41, "b": 0x42, "c": 0x43, "d": 0x44, "e": 0x45,
    "f": 0x46, "g": 0x47, "h": 0x48, "i": 0x49, "j": 0x4A,
    "k": 0x4B, "l": 0x4C, "m": 0x4D, "n": 0x4E, "o": 0x4F,
    "p": 0x50, "q": 0x51, "r": 0x52, "s": 0x53, "t": 0x54,
    "u": 0x55, "v": 0x56, "w": 0x57, "x": 0x58, "y": 0x59,
    "z": 0x5A,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73,
    "f5": 0x74, "f6": 0x75, "f7": 0x76, "f8": 0x77,
    "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    "space": 0x20, "enter": 0x0D, "tab": 0x09, "escape": 0x1B,
    "backspace": 0x08, "delete": 0x2E, "insert": 0x2D,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "comma": 0xBC, "period": 0xBE, "semicolon": 0xBA,
    "slash": 0xBF, "backslash": 0xDC, "minus": 0xBD, "equal": 0xBB,
    "bracketleft": 0xDB, "bracketright": 0xDD,
}

_MOD_CTRL = 0x0002
_MOD_SHIFT = 0x0004
_MOD_ALT = 0x0001

def parse_hotkey_string(hotkey_str: str) -> tuple:
    """Parse a hotkey string like 'ctrl+shift+1' into (modifiers, vk_code).

    Returns (modifiers_bitmask, virtual_key_code) for Windows RegisterHotKey.
    Returns (0, 0) if parsing fails.
    """
    parts = [p.strip().lower() for p in hotkey_str.split("+")]
    mods = 0
    vk = 0
    for part in parts:
        if part == "ctrl":
            mods |= _MOD_CTRL
        elif part == "shift":
            mods |= _MOD_SHIFT
        elif part == "alt":
            mods |= _MOD_ALT
        elif part in _VK_MAP:
            vk = _VK_MAP[part]
        else:
            return (0, 0)
    return (mods, vk)


def hotkey_to_display(hotkey_str: str) -> str:
    """Convert a hotkey string to display format: 'ctrl+shift+1' -> 'Ctrl+Shift+1'."""
    return "+".join(p.strip().capitalize() for p in hotkey_str.split("+"))


def parse_tk_key(hotkey_str: str) -> str:
    """Convert a single-key hotkey string to a Tkinter keysym.

    'x' -> 'x', 'space' -> 'space', 'f1' -> 'F1'
    """
    key = hotkey_str.strip().lower()
    if key.startswith("f") and key[1:].isdigit():
        return key.upper()  # F1, F2, etc.
    return key


# ---------------------------------------------------------------------------
# Global Hotkey Listener (Windows via ctypes, graceful fallback)
# ---------------------------------------------------------------------------
class HotkeyListener:
    """Register global hotkeys on Windows using ctypes.

    Accepts action-named callbacks and a hotkey_config dict that maps
    action names to hotkey strings (e.g. ``{"capture": "ctrl+shift+1"}``).
    """

    # Actions that get registered as Windows global hotkeys
    GLOBAL_ACTIONS = ["capture", "annotate", "voice_toggle", "clipboard"]

    def __init__(self, callbacks: dict, hotkey_config: dict):
        """
        Args:
            callbacks: {action_name: callable} e.g.
                       {"capture": on_capture, "annotate": on_annotate, ...}
            hotkey_config: {action_name: hotkey_string} e.g.
                          {"capture": "ctrl+shift+1", ...}
        """
        self.callbacks = callbacks
        self.hotkey_config = hotkey_config
        self._registrations: dict[int, str] = {}  # {idx: action_name}
        self._running = False
        self._thread = None

    def start(self):
        if sys.platform != "win32":
            return False

        try:
            import ctypes
            self._user32 = ctypes.windll.user32
        except Exception:
            return False

        self._running = True
        self._thread = threading.Thread(target=self._listen, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._running = False
        if sys.platform == "win32":
            try:
                for idx in self._registrations:
                    self._user32.UnregisterHotKey(None, idx)
            except Exception:
                pass

    def _listen(self):
        """Run the Windows message pump for hotkey events."""
        import ctypes
        import ctypes.wintypes

        for idx, action in enumerate(self.GLOBAL_ACTIONS):
            combo = self.hotkey_config.get(action, "")
            if not combo:
                continue
            mods, vk = parse_hotkey_string(combo)
            if vk == 0:
                print(f"[eye2byte] Warning: Invalid hotkey '{combo}' for {action}")
                continue
            if not self._user32.RegisterHotKey(None, idx, mods, vk):
                print(f"[eye2byte] Warning: Could not register {combo} for {action}")
                continue
            self._registrations[idx] = action

        msg = ctypes.wintypes.MSG()
        while self._running:
            result = self._user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if result == -1 or not self._running:
                break
            if msg.message == 0x0312:  # WM_HOTKEY
                hk_id = msg.wParam
                action = self._registrations.get(hk_id)
                if action and action in self.callbacks:
                    # Run callback in a separate thread to not block message pump
                    threading.Thread(
                        target=self.callbacks[action], daemon=True
                    ).start()


# ---------------------------------------------------------------------------
# Eye2byte Control Panel — Modern UI with CustomTkinter
# ---------------------------------------------------------------------------
class Eye2bytePanel:
    """Persistent floating control panel with capture buttons and hotkeys."""

    def __init__(self):
        # Load eye2byte config and functions
        import eye2byte
        self.e2b = eye2byte
        self.config = eye2byte.load_config()
        eye2byte.run_auto_cleanup(self.config)

        # State
        self.current_session = None
        self._voice_state = "idle"       # "idle" | "recording" | "processing"
        self._voice_handle = None        # from start_voice_recording()
        self._voice_start_time = 0.0
        self._voice_captures = []        # sessions captured during recording
        self._voice_lock = threading.Lock()
        self._action_lock = threading.Lock()
        self._ptt_mouse_active = False
        self._timer_after_id = None
        self._capture_modes = ["full", "window", "region"]
        self._capture_mode_idx = 0
        self._tray_icon = None  # pystray.Icon instance (created on first minimize)

        # Build the window
        if _HAS_CTK:
            self.root = ctk.CTk()
        else:
            self.root = tk.Tk()
        self.root.title("Eye2byte")
        self.root.attributes("-topmost", True)
        self.root.resizable(False, False)

        # Set window icon (visible in Alt+Tab and taskbar)
        if os.path.exists(_ICON_PATH):
            try:
                self.root.iconbitmap(_ICON_PATH)
            except Exception:
                pass

        # Remove title bar for cleaner look
        self.root.overrideredirect(True)
        if _HAS_CTK:
            self.root.configure(fg_color=BG)
        else:
            self.root.configure(bg=BG)

        self._build_ui()
        self._position_window()
        self._make_draggable()

        # Start global hotkey listener
        from eye2byte import get_hotkeys
        hotkey_cfg = get_hotkeys(self.config)
        self.hotkeys = HotkeyListener(
            callbacks={
                "capture": self.do_capture,
                "annotate": self.do_annotate,
                "voice_toggle": self.do_voice_toggle,
                "clipboard": self.do_clipboard,
            },
            hotkey_config=hotkey_cfg,
        )
        hotkeys_active = self.hotkeys.start()

        if hotkeys_active:
            self._set_status("Hotkeys active", MUTED_LIGHT)
        else:
            self._set_status("Buttons ready (hotkeys: Windows only)", MUTED_LIGHT)

        # Push-to-talk (hold = record, release = stop) — key from config
        self._space_held = False
        ptt_key = hotkey_cfg.get("ptt", "space")
        ptt_tk = parse_tk_key(ptt_key)
        self.root.bind(f"<KeyPress-{ptt_tk}>", self._space_press)
        self.root.bind(f"<KeyRelease-{ptt_tk}>", self._space_release)

    def _build_ui(self):
        if not _HAS_CTK:
            self._build_ui_legacy()
            return

        # Outer frame with border for polished edge
        self.outer = ctk.CTkFrame(
            self.root, fg_color=BG, corner_radius=14,
            border_width=1, border_color=BORDER,
        )
        self.outer.pack(fill="both", expand=True, padx=1, pady=1)

        # Main content frame
        self.frame = ctk.CTkFrame(self.outer, fg_color="transparent")
        self.frame.pack(fill="both", expand=True, padx=14, pady=10)

        # ── Header row (title + minimize + close) ──
        header = ctk.CTkFrame(self.frame, fg_color="transparent")
        header.pack(fill="x")

        ctk.CTkLabel(
            header, text="Eye2byte", font=("Segoe UI", 14, "bold"),
            text_color=ACCENT,
        ).pack(side="left")

        ctk.CTkButton(
            header, text="X", width=28, height=28, corner_radius=8,
            fg_color="#3a2020", hover_color=RED, text_color="#ff6b6b",
            font=("Segoe UI", 11, "bold"), command=self._on_close,
        ).pack(side="right")

        ctk.CTkButton(
            header, text="\u2014", width=28, height=28, corner_radius=8,
            fg_color="#2a2a40", hover_color="#3a3a55", text_color=MUTED_LIGHT,
            font=("Segoe UI", 11), command=self._on_minimize,
        ).pack(side="right", padx=(0, 4))

        # ── Separator ──
        ctk.CTkFrame(
            self.frame, height=1, fg_color=BORDER, corner_radius=0,
        ).pack(fill="x", pady=(8, 10))

        # ── Recording indicator (hidden by default) ──
        self._rec_bar = ctk.CTkFrame(
            self.frame, fg_color=RED, corner_radius=8, height=28,
        )
        # Not packed yet — shown when recording starts
        self._rec_dot = ctk.CTkLabel(
            self._rec_bar, text="\u25cf", font=("Segoe UI", 14),
            text_color="#ffffff", width=20,
        )
        self._rec_dot.pack(side="left", padx=(8, 4))
        self._rec_timer_label = ctk.CTkLabel(
            self._rec_bar, text="REC 0:00", font=("Consolas", 11, "bold"),
            text_color="#ffffff",
        )
        self._rec_timer_label.pack(side="left", padx=(0, 8))

        # ── Action buttons ──
        # Row 1: Capture + Annotate
        row1 = ctk.CTkFrame(self.frame, fg_color="transparent")
        row1.pack(fill="x", pady=(0, 6))
        self._make_btn(row1, "Capture", "Ctrl+Shift+1",
                       self.do_capture, GREEN, GREEN_HOVER)
        self._make_btn(row1, "Annotate", "Ctrl+Shift+2",
                       self.do_annotate, BLUE, BLUE_HOVER)

        # Row 2: Record/Stop + Clipboard
        row2 = ctk.CTkFrame(self.frame, fg_color="transparent")
        row2.pack(fill="x", pady=(0, 8))
        self.voice_btn = ctk.CTkButton(
            row2,
            text="Record\nCtrl+Shift+3",
            font=("Segoe UI", 11),
            fg_color=ORANGE,
            hover_color="#e67e22",
            text_color="#ffffff",
            corner_radius=10,
            height=48,
        )
        self.voice_btn.pack(side="left", fill="x", expand=True, padx=3)
        # Mouse PTT: hold to record, release to stop
        self.voice_btn.bind("<ButtonPress-1>", self._ptt_press)
        self.voice_btn.bind("<ButtonRelease-1>", self._ptt_release)
        self._make_btn(row2, "Clipboard", "Ctrl+Shift+5",
                       self.do_clipboard, MUTED, MUTED_HOVER)

        # ── Capture mode + Settings row ──
        ctrl_row = ctk.CTkFrame(self.frame, fg_color="transparent")
        ctrl_row.pack(fill="x", pady=(0, 6))

        self._mode_seg = ctk.CTkSegmentedButton(
            ctrl_row, values=["Full", "Window", "Region"],
            font=("Segoe UI", 11), height=30,
            fg_color=BG_DARK, selected_color=ACCENT,
            selected_hover_color="#6380f7", unselected_color=BG_DARK,
            unselected_hover_color="#2a2a48",
            command=self._on_mode_select,
        )
        self._mode_seg.set("Full")
        self._mode_seg.pack(side="left", fill="x", expand=True, padx=(0, 6))

        ctk.CTkButton(
            ctrl_row, text="Settings", font=("Segoe UI", 11),
            fg_color=BG_DARK, hover_color="#2a2a48", text_color=MUTED_LIGHT,
            corner_radius=8, height=30, width=80,
            command=self._open_settings,
        ).pack(side="right")

        # ── Separator ──
        ctk.CTkFrame(
            self.frame, height=1, fg_color=BORDER, corner_radius=0,
        ).pack(fill="x", pady=(2, 8))

        # ── Session info ──
        self.session_var = tk.StringVar(value="No active session")
        ctk.CTkLabel(
            self.frame, textvariable=self.session_var,
            font=("Consolas", 10), text_color=FG, anchor="w",
        ).pack(fill="x")

        # ── Status ──
        self.status_var = tk.StringVar(value="")
        self.status_label = ctk.CTkLabel(
            self.frame, textvariable=self.status_var,
            font=("Segoe UI", 10), text_color=MUTED_LIGHT, anchor="w",
        )
        self.status_label.pack(fill="x", pady=(2, 4))

        # ── Log panel (collapsible) ──
        self._log_visible = False
        self._log_toggle_btn = ctk.CTkButton(
            self.frame, text="Log \u25bc", width=50, height=18,
            corner_radius=6, font=("Segoe UI", 9),
            fg_color="transparent", hover_color="#2a2a48",
            text_color=MUTED_LIGHT, anchor="e",
            command=self._toggle_log,
        )
        self._log_toggle_btn.pack(anchor="e", pady=(0, 2))

        self._log_frame = ctk.CTkFrame(self.frame, fg_color=BG_DARK,
                                        corner_radius=8, height=0)
        self._log_text = ctk.CTkTextbox(
            self._log_frame, font=("Consolas", 9), fg_color=BG_DARK,
            text_color=MUTED_LIGHT, height=100, width=260,
            activate_scrollbars=True, wrap="word",
        )
        self._log_text.pack(fill="both", expand=True, padx=4, pady=4)
        self._log_text.configure(state="disabled")
        # _log_frame is NOT packed yet — shown when user clicks "Log"

        # ── Copy @path + Open ──
        self.copy_frame = ctk.CTkFrame(self.frame, fg_color="transparent")
        self.copy_frame.pack(fill="x")

        self.copy_btn = ctk.CTkButton(
            self.copy_frame, text="Copy @path",
            font=("Segoe UI", 12, "bold"), height=36,
            fg_color=GREEN, hover_color=GREEN_HOVER, text_color="#000",
            corner_radius=10, state="disabled",
            command=self._copy_at_path,
        )
        self.copy_btn.pack(side="left", fill="x", expand=True, padx=(0, 6))

        self.open_btn = ctk.CTkButton(
            self.copy_frame, text="Open",
            font=("Segoe UI", 11), height=36, width=60,
            fg_color="#2a2a48", hover_color=ACCENT, text_color=FG,
            corner_radius=10, state="disabled",
            command=self._open_folder,
        )
        self.open_btn.pack(side="right")

    def _build_ui_legacy(self):
        """Fallback tkinter UI when customtkinter is not installed."""
        self.frame = tk.Frame(self.root, bg=BG, padx=12, pady=8)
        self.frame.pack(fill="both", expand=True)

        header = tk.Frame(self.frame, bg=BG)
        header.pack(fill="x")
        tk.Label(header, text="Eye2byte", font=("Segoe UI", 11, "bold"),
                 bg=BG, fg=ACCENT).pack(side="left")
        tk.Button(header, text="X", font=("Segoe UI", 8, "bold"),
                  bg=RED, fg="#fff", activebackground=RED_HOVER,
                  relief="flat", padx=6, pady=1,
                  command=self._on_close).pack(side="right")
        tk.Button(header, text="_", font=("Segoe UI", 8, "bold"),
                  bg=MUTED, fg="#fff", relief="flat", padx=6, pady=1,
                  command=self._on_minimize).pack(side="right", padx=(0, 4))

        tk.Frame(self.frame, bg=ACCENT, height=1).pack(fill="x", pady=(6, 6))

        # Recording indicator (hidden by default)
        self._rec_bar = tk.Frame(self.frame, bg=RED, height=24)
        self._rec_dot = tk.Label(
            self._rec_bar, text="\u25cf", font=("Segoe UI", 12),
            bg=RED, fg="#ffffff",
        )
        self._rec_dot.pack(side="left", padx=(6, 4))
        self._rec_timer_label = tk.Label(
            self._rec_bar, text="REC 0:00", font=("Consolas", 10, "bold"),
            bg=RED, fg="#ffffff",
        )
        self._rec_timer_label.pack(side="left", padx=(0, 6))
        # Not packed yet — shown when recording starts

        row1 = tk.Frame(self.frame, bg=BG)
        row1.pack(fill="x", pady=(0, 4))
        self._make_btn_legacy(row1, "Capture", "Ctrl+Shift+1",
                              self.do_capture, GREEN, GREEN_HOVER)
        self._make_btn_legacy(row1, "Annotate", "Ctrl+Shift+2",
                              self.do_annotate, BLUE, BLUE_HOVER)

        row2 = tk.Frame(self.frame, bg=BG)
        row2.pack(fill="x", pady=(0, 4))
        frame_v = tk.Frame(row2, bg=BG)
        frame_v.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.voice_btn = tk.Button(
            frame_v, text="Record\nCtrl+Shift+3",
            font=("Segoe UI", 8), bg=ORANGE, fg="#ffffff",
            activebackground="#e67e22", relief="flat",
            cursor="hand2", padx=4, pady=4, width=12,
        )
        self.voice_btn.pack(fill="x")
        self.voice_btn.bind("<ButtonPress-1>", self._ptt_press)
        self.voice_btn.bind("<ButtonRelease-1>", self._ptt_release)
        self._make_btn_legacy(row2, "Clipboard", "Ctrl+Shift+5",
                              self.do_clipboard, MUTED, MUTED_HOVER)

        row4 = tk.Frame(self.frame, bg=BG)
        row4.pack(fill="x", pady=(0, 4))

        self._mode_var = tk.StringVar(value="Mode: Full Screen")
        mode_btn = tk.Button(
            row4, textvariable=self._mode_var, font=("Segoe UI", 8),
            bg=BG_DARK, fg=MUTED_LIGHT, activebackground=ACCENT,
            relief="flat", cursor="hand2", padx=8, pady=3,
            command=self._cycle_capture_mode,
        )
        mode_btn.pack(side="left", fill="x", expand=True, padx=(0, 4))

        tk.Button(
            row4, text="Settings", font=("Segoe UI", 8),
            bg=BG_DARK, fg=MUTED_LIGHT, activebackground=ACCENT,
            relief="flat", cursor="hand2", padx=8, pady=3,
            command=self._open_settings,
        ).pack(side="left")

        tk.Frame(self.frame, bg=ACCENT, height=1).pack(fill="x", pady=(4, 6))

        self.session_var = tk.StringVar(value="No active session")
        tk.Label(self.frame, textvariable=self.session_var,
                 font=("Consolas", 9), bg=BG, fg=FG, anchor="w").pack(fill="x")

        self.status_var = tk.StringVar(value="")
        self.status_label = tk.Label(
            self.frame, textvariable=self.status_var,
            font=("Segoe UI", 8), bg=BG, fg=MUTED_LIGHT, anchor="w",
        )
        self.status_label.pack(fill="x", pady=(2, 4))

        self.copy_frame = tk.Frame(self.frame, bg=BG)
        self.copy_frame.pack(fill="x")
        self.copy_btn = tk.Button(
            self.copy_frame, text="Copy @path", font=("Segoe UI", 10, "bold"),
            bg=GREEN, fg="#000", activebackground=GREEN_HOVER,
            relief="flat", cursor="hand2", padx=12, pady=4,
            command=self._copy_at_path, state="disabled",
        )
        self.copy_btn.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.open_btn = tk.Button(
            self.copy_frame, text="Open", font=("Segoe UI", 9),
            bg=ACCENT, fg=FG, activebackground="#1a5276",
            relief="flat", cursor="hand2", padx=8, pady=4,
            command=self._open_folder, state="disabled",
        )
        self.open_btn.pack(side="left")

    def _make_btn(self, parent, label, hotkey_text, command, bg_color, hover_color):
        """Create a modern rounded action button."""
        btn = ctk.CTkButton(
            parent,
            text=f"{label}\n{hotkey_text}",
            font=("Segoe UI", 11),
            fg_color=bg_color,
            hover_color=hover_color,
            text_color="#ffffff",
            corner_radius=10,
            height=48,
            command=lambda: threading.Thread(target=command, daemon=True).start(),
        )
        btn.pack(side="left", fill="x", expand=True, padx=3)
        return btn

    def _make_btn_legacy(self, parent, label, hotkey_text, command, bg_color, hover_color):
        """Legacy tkinter button fallback."""
        frame = tk.Frame(parent, bg=BG)
        frame.pack(side="left", fill="x", expand=True, padx=(0, 4))
        btn = tk.Button(
            frame, text=f"{label}\n{hotkey_text}",
            font=("Segoe UI", 8), bg=bg_color, fg="#ffffff",
            activebackground=hover_color, relief="flat",
            cursor="hand2", padx=4, pady=4, width=12,
            command=lambda: threading.Thread(target=command, daemon=True).start(),
        )
        btn.pack(fill="x")
        btn.bind("<Enter>", lambda e: btn.configure(bg=hover_color))
        btn.bind("<Leave>", lambda e: btn.configure(bg=bg_color))
        return btn

    def _position_window(self):
        self.root.update_idletasks()
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        win_w = self.root.winfo_reqwidth()
        win_h = self.root.winfo_reqheight()
        x = screen_w - win_w - 16
        y = screen_h - win_h - 60
        self.root.geometry(f"+{x}+{y}")

    def _make_draggable(self):
        """Allow dragging the window by clicking anywhere on the frame."""
        self._drag_x = 0
        self._drag_y = 0

        def start_drag(e):
            self._drag_x = e.x
            self._drag_y = e.y

        def do_drag(e):
            x = self.root.winfo_x() + e.x - self._drag_x
            y = self.root.winfo_y() + e.y - self._drag_y
            self.root.geometry(f"+{x}+{y}")

        # Bind on the frame and the outer container
        self.frame.bind("<ButtonPress-1>", start_drag)
        self.frame.bind("<B1-Motion>", do_drag)
        if _HAS_CTK and hasattr(self, 'outer'):
            self.outer.bind("<ButtonPress-1>", start_drag)
            self.outer.bind("<B1-Motion>", do_drag)

    # --- Status helpers ---

    def _toggle_log(self):
        """Show/hide the log panel, shifting the window up/down to stay on-screen."""
        old_h = self.root.winfo_height()
        if self._log_visible:
            self._log_frame.pack_forget()
            self._log_toggle_btn.configure(text="Log \u25bc")
            self._log_visible = False
        else:
            self._log_frame.pack(fill="x", pady=(0, 4),
                                 before=self.copy_frame)
            self._log_toggle_btn.configure(text="Log \u25b2")
            self._log_visible = True

        # Let layout recompute, then shift window so it doesn't go off-screen
        self.root.update_idletasks()
        new_h = self.root.winfo_height()
        dy = new_h - old_h
        if dy != 0:
            cur_y = self.root.winfo_y()
            new_y = max(0, cur_y - dy)
            self.root.geometry(f"+{self.root.winfo_x()}+{new_y}")

    def _append_log(self, text):
        """Append a timestamped line to the log panel."""
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        def _update():
            self._log_text.configure(state="normal")
            self._log_text.insert("end", f"[{ts}] {text}\n")
            self._log_text.see("end")
            self._log_text.configure(state="disabled")
        self.root.after(0, _update)

    def _set_status(self, text, color=MUTED_LIGHT):
        def _update():
            self.status_var.set(text)
            if _HAS_CTK:
                self.status_label.configure(text_color=color)
            else:
                self.status_label.configure(fg=color)
        self.root.after(0, _update)
        # Also append to log panel
        if hasattr(self, '_log_text'):
            self._append_log(text)

    def _set_session(self, session):
        self.current_session = session
        def _update():
            if session:
                self.session_var.set(f"Session: {session['id']}")
                self.copy_btn.configure(state="normal")
                self.open_btn.configure(state="normal")
            else:
                self.session_var.set("No active session")
                self.copy_btn.configure(state="disabled")
                self.open_btn.configure(state="disabled")
        self.root.after(0, _update)

    # --- Capture mode ---

    def _on_mode_select(self, value):
        """Handle segmented button selection for capture mode."""
        mode_map = {"Full": 0, "Window": 1, "Region": 2}
        self._capture_mode_idx = mode_map.get(value, 0)

    def _cycle_capture_mode(self):
        """Cycle capture mode (legacy fallback)."""
        self._capture_mode_idx = (self._capture_mode_idx + 1) % len(self._capture_modes)
        mode = self._capture_modes[self._capture_mode_idx]
        labels = {"full": "Full Screen", "window": "Window", "region": "Region"}
        if hasattr(self, '_mode_var'):
            self._mode_var.set(f"Mode: {labels[mode]}")
        if _HAS_CTK and hasattr(self, '_mode_seg'):
            seg_labels = {"full": "Full", "window": "Window", "region": "Region"}
            self._mode_seg.set(seg_labels[mode])

    @property
    def capture_mode(self):
        return self._capture_modes[self._capture_mode_idx]

    # --- Recording indicator ---

    def _show_rec_indicator(self):
        """Show the recording indicator bar with pulsing dot and timer."""
        def _show():
            self._rec_bar.pack(fill="x", pady=(0, 6), before=self.frame.winfo_children()[3])
            self._update_rec_timer()
        self.root.after(0, _show)

    def _hide_rec_indicator(self):
        """Hide the recording indicator bar and cancel timer."""
        def _hide():
            if self._timer_after_id:
                self.root.after_cancel(self._timer_after_id)
                self._timer_after_id = None
            self._rec_bar.pack_forget()
        self.root.after(0, _hide)

    def _update_rec_timer(self):
        """Update the recording timer display every 500ms."""
        if self._voice_state != "recording":
            return
        elapsed = time.time() - self._voice_start_time
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60

        # Pulse the dot between red and white
        dot_color = "#ffffff" if int(elapsed * 2) % 2 == 0 else RED
        if _HAS_CTK:
            self._rec_timer_label.configure(text=f"REC {mins}:{secs:02d}")
            self._rec_dot.configure(text_color=dot_color)
        else:
            self._rec_timer_label.configure(text=f"REC {mins}:{secs:02d}")
            self._rec_dot.configure(fg=dot_color)

        self._timer_after_id = self.root.after(500, self._update_rec_timer)

    # --- Voice toggle (replaces PTT) ---

    def do_voice_toggle(self):
        """Hotkey Ctrl+Shift+3: toggle voice recording on/off."""
        if self._ptt_mouse_active:
            return  # Mouse PTT in progress, don't interfere
        with self._voice_lock:
            if self._voice_state == "idle":
                self._voice_start()
            elif self._voice_state == "recording":
                threading.Thread(target=self._voice_stop, daemon=True).start()
            # If "processing", ignore the keypress

    def _voice_start(self):
        """Start voice recording."""
        if self._voice_state != "idle":
            return
        self._voice_state = "recording"
        self._voice_start_time = time.time()
        self._voice_captures = []

        self.root.after(0, lambda: self.voice_btn.configure(
            text="Stop\nCtrl+Shift+3",
            **({
                "fg_color": RED, "hover_color": RED_HOVER,
            } if _HAS_CTK else {
                "bg": RED, "activebackground": RED_HOVER,
            }),
        ))
        self._set_status("Recording... press Ctrl+Shift+3 to stop", RED)
        self._show_rec_indicator()

        try:
            self._voice_handle = self.e2b.start_voice_recording(self.config)
            if not self._voice_handle:
                self._set_status("No audio recorder available", RED)
                self._voice_reset()
        except Exception as e:
            self._set_status(f"Error starting recording: {e}", RED)
            self._voice_reset()

    def _voice_stop(self):
        """Stop voice recording and process the audio."""
        with self._voice_lock:
            if self._voice_state != "recording" or not self._voice_handle:
                self._voice_reset()
                return
            self._voice_state = "processing"

        elapsed = time.time() - self._voice_start_time
        self._hide_rec_indicator()

        self.root.after(0, lambda: self.voice_btn.configure(
            text="Processing...",
            **({
                "fg_color": ORANGE, "hover_color": "#e67e22",
            } if _HAS_CTK else {
                "bg": ORANGE, "activebackground": "#e67e22",
            }),
        ))

        # Minimum recording: 0.5s (avoid accidental taps)
        if elapsed < 0.5:
            self._set_status("Too short -- hold longer to record", ORANGE)
            handle = self._voice_handle
            self._voice_handle = None
            try:
                if handle and handle.get("proc"):
                    handle["proc"].terminate()
            except Exception:
                pass
            self._voice_reset()
            return

        handle = self._voice_handle
        self._voice_handle = None
        captures = list(self._voice_captures)

        try:
            self._set_status("Stopping recording...", ORANGE)
            voice_path = self.e2b.stop_voice_recording(handle, self.config)

            if voice_path:
                if captures:
                    # Bundle voice with last capture session
                    last_session = captures[-1]
                    voice_dest = os.path.join(
                        last_session["dir"], os.path.basename(voice_path))
                    shutil.move(voice_path, voice_dest)
                    last_session["voice"] = voice_dest

                    self._set_status("Transcribing...", ORANGE)
                    text = self.e2b.transcribe_voice(voice_dest, self.config)
                    if text:
                        last_session["transcript"] = text

                    self.e2b.finalize_session(last_session, self.config)
                    self._set_session(last_session)
                    self._set_status(
                        f"Voice ({elapsed:.1f}s) bundled with capture! @path copied",
                        GREEN)
                else:
                    # Voice-only session
                    session = self.e2b.create_session(self.config)
                    voice_dest = os.path.join(
                        session["dir"], os.path.basename(voice_path))
                    shutil.move(voice_path, voice_dest)
                    session["voice"] = voice_dest

                    self._set_status("Transcribing...", ORANGE)
                    text = self.e2b.transcribe_voice(voice_dest, self.config)
                    if text:
                        session["transcript"] = text

                    self.e2b.finalize_session(session, self.config)
                    self._set_session(session)
                    self._set_status(
                        f"Voice recorded ({elapsed:.1f}s)! @path copied",
                        GREEN)
            else:
                self._set_status("No audio captured", MUTED_LIGHT)
        except Exception as e:
            self._set_status(f"Error: {e}", RED)
        finally:
            self._voice_reset()

    def _voice_reset(self):
        """Reset voice state and button appearance."""
        self._voice_state = "idle"
        self._voice_handle = None
        self._voice_captures = []
        self._ptt_mouse_active = False
        self._hide_rec_indicator()
        self.root.after(0, lambda: self.voice_btn.configure(
            text="Record\nCtrl+Shift+3",
            **({
                "fg_color": ORANGE, "hover_color": "#e67e22",
            } if _HAS_CTK else {
                "bg": ORANGE, "activebackground": "#e67e22",
            }),
        ))

    def _ptt_press(self, event=None):
        """Mouse button pressed on Voice button — start recording."""
        if self._voice_state == "recording":
            return  # Already recording, press will be handled by release
        self._ptt_mouse_active = True
        with self._voice_lock:
            self._voice_start()

    def _ptt_release(self, event=None):
        """Mouse button released on Voice button — stop recording."""
        if self._ptt_mouse_active and self._voice_state == "recording":
            threading.Thread(target=self._voice_stop, daemon=True).start()

    def _space_press(self, event=None):
        """Spacebar held — start PTT recording (guards against key repeat)."""
        if self._space_held:
            return
        self._space_held = True
        self._ptt_press()

    def _space_release(self, event=None):
        """Spacebar released — stop PTT recording."""
        self._space_held = False
        self._ptt_release()

    # --- Capture actions ---

    def do_capture(self):
        """Screenshot -> vision model -> session."""
        if not self._action_lock.acquire(blocking=False):
            return
        mode = self.capture_mode
        self._set_status(f"Capturing ({mode})...", GREEN)

        try:
            session = self.e2b._run_capture_session(self.config, mode=mode)
            self._set_session(session)

            # If voice is recording, bundle this capture
            if self._voice_state == "recording":
                self._voice_captures.append(session)
                self._set_status("Captured! Voice will bundle when stopped.", GREEN)
            else:
                self._set_status("Done! @path copied to clipboard", GREEN)
        except Exception as e:
            self._set_status(f"Error: {e}", RED)
        finally:
            self._action_lock.release()

    def do_annotate(self):
        """Screenshot -> annotation overlay -> vision model -> session."""
        if not self._action_lock.acquire(blocking=False):
            return
        self._set_status("Taking screenshot for annotation...", BLUE)

        try:
            # Take a raw screenshot first
            session = self.e2b.create_session(self.config)
            capture_path = os.path.join(session["dir"], "capture.png")

            orig_dir = self.config["capture_dir"]
            self.config["capture_dir"] = session["dir"]
            raw_path = self.e2b.capture_screen(self.config, mode=self.capture_mode)
            self.config["capture_dir"] = orig_dir

            if raw_path != capture_path and os.path.exists(raw_path):
                shutil.move(raw_path, capture_path)
            session["capture"] = capture_path

            self._set_status("Draw annotations, press Enter to save", BLUE)

            # Open annotation overlay (runs in main thread via after)
            def _open_overlay():
                def _on_done(annotated_path, annotations):
                    if annotated_path:
                        threading.Thread(
                            target=self._finish_annotate,
                            args=(session, annotated_path, annotations),
                            daemon=True,
                        ).start()
                    else:
                        self._set_status("Annotation cancelled", MUTED_LIGHT)
                        self._action_lock.release()

                from eye2byte import get_hotkeys
                AnnotationOverlay(capture_path, _on_done, get_hotkeys(self.config))

            self.root.after(100, _open_overlay)

        except Exception as e:
            self._set_status(f"Error: {e}", RED)
            self._action_lock.release()

    def _finish_annotate(self, session, annotated_path, annotations):
        """Complete the annotation session: send to vision model and save."""
        try:
            # Save annotations JSON
            anno_json_path = os.path.join(session["dir"], "annotations.json")
            with open(anno_json_path, "w") as f:
                json.dump(annotations, f, indent=2)

            # Build annotation text for LLM
            anno_text = ""
            if annotations:
                parts = []
                for a in annotations:
                    x1, y1 = a["from"]
                    x2, y2 = a["to"]
                    if a["type"] == "arrow":
                        parts.append(f"- Arrow pointing from ({x1},{y1}) to ({x2},{y2})")
                    elif a["type"] == "circle":
                        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                        parts.append(f"- Circle highlight around ({cx},{cy})")
                    elif a["type"] == "rect":
                        parts.append(f"- Rectangle highlight at ({x1},{y1})-({x2},{y2})")
                    elif a["type"] == "freehand":
                        parts.append(f"- Freehand drawing from ({x1},{y1}) to ({x2},{y2})")
                    elif a["type"] == "text":
                        label = a.get("label", "")
                        parts.append(f"- Text label at ({x1},{y1}): \"{label}\"")
                anno_text = "User annotations on screenshot:\n" + "\n".join(parts)

            self._set_status("Sending annotated screenshot to vision model...", BLUE)

            # Send annotated image to vision model
            summary = self.e2b.summarize_image(
                annotated_path, self.config, voice_transcript=anno_text,
            )
            session["context_pack"] = summary
            session["description"] = anno_text

            self.e2b.finalize_session(session, self.config)
            self._set_session(session)

            # If voice is recording, bundle this capture
            if self._voice_state == "recording":
                self._voice_captures.append(session)
                self._set_status("Annotated! Voice will bundle when stopped.", GREEN)
            else:
                self._set_status("Annotated capture done! @path copied", GREEN)

        except Exception as e:
            self._set_status(f"Error: {e}", RED)
        finally:
            self._action_lock.release()

    def do_clipboard(self):
        """Grab image from clipboard -> vision model -> session."""
        if not self._action_lock.acquire(blocking=False):
            return
        self._set_status("Grabbing clipboard image...", MUTED_LIGHT)

        try:
            session = self.e2b.create_session(self.config)
            capture_path = os.path.join(session["dir"], "capture.png")

            if get_clipboard_image(capture_path):
                session["capture"] = capture_path

                self._set_status("Sending clipboard image to vision model...", MUTED_LIGHT)
                summary = self.e2b.summarize_image(capture_path, self.config)
                session["context_pack"] = summary
                print("\n" + summary)

                self.e2b.finalize_session(session, self.config)
                self._set_session(session)
                self._set_status("Clipboard capture done! @path copied", GREEN)
            else:
                self._set_status("No image on clipboard", ORANGE)

        except Exception as e:
            self._set_status(f"Error: {e}", RED)
        finally:
            self._action_lock.release()

    # --- Settings window ---

    def _open_settings(self):
        """Open a modern settings window."""
        if not _HAS_CTK:
            self._open_settings_legacy()
            return

        win = ctk.CTkToplevel(self.root)
        win.title("Eye2byte Settings")
        win.attributes("-topmost", True)
        win.resizable(False, False)
        win.geometry("440x720")
        win.configure(fg_color=BG)

        # Wait a moment then grab focus
        win.after(100, win.focus_force)

        # Tab view
        tabview = ctk.CTkTabview(
            win, fg_color=BG,
            segmented_button_fg_color=BG_DARK,
            segmented_button_selected_color=ACCENT,
            segmented_button_unselected_color=BG_DARK,
        )

        provider_tab = tabview.add("Provider")
        media_tab = tabview.add("Media")
        shortcuts_tab = tabview.add("Shortcuts")
        maint_tab = tabview.add("Maintenance")

        # Scrollable frames for longer tabs
        p_scroll = ctk.CTkScrollableFrame(
            provider_tab, fg_color="transparent",
            scrollbar_button_color="#2a2a48",
            scrollbar_button_hover_color=ACCENT,
        )
        p_scroll.pack(fill="both", expand=True)

        s_scroll = ctk.CTkScrollableFrame(
            shortcuts_tab, fg_color="transparent",
            scrollbar_button_color="#2a2a48",
            scrollbar_button_hover_color=ACCENT,
        )
        s_scroll.pack(fill="both", expand=True)

        # ══════════════════════════════════════════════
        # PROVIDER SECTION
        # ══════════════════════════════════════════════
        ctk.CTkLabel(
            p_scroll, text="Provider",
            font=("Segoe UI", 13, "bold"), text_color=ACCENT,
        ).pack(anchor="w", pady=(0, 8))

        provider_var = tk.StringVar(value=self.config.get("provider", "ollama"))

        provider_seg = ctk.CTkSegmentedButton(
            p_scroll,
            values=["ollama", "openrouter", "hyperbolic", "gemini"],
            variable=provider_var, height=32,
            font=("Segoe UI", 11),
            fg_color=BG_DARK, selected_color=ACCENT,
            selected_hover_color="#6380f7",
            unselected_color=BG_DARK, unselected_hover_color="#2a2a48",
        )
        provider_seg.pack(fill="x", pady=(0, 16))

        # ── Ollama URL ──
        ctk.CTkLabel(
            p_scroll, text="Ollama URL",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(0, 4))

        url_var = tk.StringVar(
            value=self.config.get("ollama_url", "http://localhost:11434"))
        ctk.CTkEntry(
            p_scroll, textvariable=url_var, font=("Consolas", 11),
            fg_color=BG_DARK, text_color=FG, border_color=BORDER,
            corner_radius=8, height=34,
        ).pack(fill="x", pady=(0, 12))

        # ── Ollama Model ──
        ctk.CTkLabel(
            p_scroll, text="Ollama Vision Model",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(0, 4))

        model_row = ctk.CTkFrame(p_scroll, fg_color="transparent")
        model_row.pack(fill="x", pady=(0, 4))

        model_var = tk.StringVar(value=self.config.get("model", "auto"))
        self._model_options = ["auto"]
        model_menu = ctk.CTkOptionMenu(
            model_row, variable=model_var, values=self._model_options,
            font=("Consolas", 11), height=34,
            fg_color=BG_DARK, button_color=ACCENT,
            button_hover_color="#6380f7", dropdown_fg_color=BG_DARK,
            dropdown_hover_color=ACCENT, corner_radius=8,
        )
        model_menu.pack(side="left", fill="x", expand=True, padx=(0, 8))

        status_lbl = ctk.CTkLabel(
            p_scroll, text="", font=("Segoe UI", 10), text_color=MUTED_LIGHT,
        )
        status_lbl.pack(anchor="w", pady=(0, 4))

        def _fetch_models():
            status_lbl.configure(text="Fetching models...", text_color=ORANGE)
            tmp_config = dict(self.config)
            tmp_config["ollama_url"] = url_var.get().strip().rstrip("/")
            models = self.e2b.fetch_ollama_models(tmp_config)

            if models:
                self._model_options = ["auto"] + list(models)
                model_menu.configure(values=self._model_options)
                status_lbl.configure(
                    text=f"Found {len(models)} model(s)", text_color=GREEN)
            else:
                status_lbl.configure(
                    text="No models found (is Ollama running?)", text_color=RED)

        ctk.CTkButton(
            model_row, text="Refresh", font=("Segoe UI", 11),
            fg_color=ACCENT, hover_color="#6380f7", text_color="#fff",
            corner_radius=8, height=34, width=80,
            command=lambda: threading.Thread(
                target=_fetch_models, daemon=True).start(),
        ).pack(side="right")

        # ── OpenRouter model ──
        ctk.CTkLabel(
            p_scroll, text="OpenRouter Model",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(8, 4))

        or_model_var = tk.StringVar(
            value=self.config.get("openrouter_model",
                                  "qwen/qwen2.5-vl-72b-instruct:free"))
        ctk.CTkEntry(
            p_scroll, textvariable=or_model_var, font=("Consolas", 11),
            fg_color=BG_DARK, text_color=FG, border_color=BORDER,
            corner_radius=8, height=34,
        ).pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            p_scroll, text="API key: set OPENROUTER_API_KEY in .env",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 8))

        # ── Hyperbolic model ──
        ctk.CTkLabel(
            p_scroll, text="Hyperbolic Model",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(0, 4))

        hyp_model_var = tk.StringVar(
            value=self.config.get("hyperbolic_model",
                                  "Qwen/Qwen2.5-VL-72B-Instruct"))
        ctk.CTkEntry(
            p_scroll, textvariable=hyp_model_var, font=("Consolas", 11),
            fg_color=BG_DARK, text_color=FG, border_color=BORDER,
            corner_radius=8, height=34,
        ).pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            p_scroll, text="API key: set HYPERBOLIC_API_KEY in .env",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 8))

        # ── Gemini model ──
        ctk.CTkLabel(
            p_scroll, text="Gemini Model",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(0, 4))

        gem_model_var = tk.StringVar(
            value=self.config.get("gemini_model", "gemini-2.5-flash-lite"))
        ctk.CTkEntry(
            p_scroll, textvariable=gem_model_var, font=("Consolas", 11),
            fg_color=BG_DARK, text_color=FG, border_color=BORDER,
            corner_radius=8, height=34,
        ).pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            p_scroll, text="API key: set GEMINI_API_KEY in .env (free at aistudio.google.com)",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 8))

        # ── Output directory ──
        ctk.CTkLabel(
            p_scroll, text="Output Directory",
            font=("Segoe UI", 11), text_color=MUTED_LIGHT,
        ).pack(anchor="w", pady=(0, 4))

        outdir_var = tk.StringVar(value=self.config.get("output_dir", ""))
        ctk.CTkEntry(
            p_scroll, textvariable=outdir_var, font=("Consolas", 11),
            fg_color=BG_DARK, text_color=FG, border_color=BORDER,
            corner_radius=8, height=34,
            placeholder_text="~/.eye2byte/output",
        ).pack(fill="x", pady=(0, 16))

        # ══════════════════════════════════════════════
        # IMAGE OPTIMIZATION SECTION
        # ══════════════════════════════════════════════
        ctk.CTkLabel(
            media_tab, text="Image Optimization",
            font=("Segoe UI", 13, "bold"), text_color=ACCENT,
        ).pack(anchor="w", pady=(0, 10))

        # Max resolution slider
        res_val = self.config.get("image_max_size", 1920)
        res_label = ctk.CTkLabel(
            media_tab, text=f"Max Resolution: {res_val}px",
            font=("Segoe UI", 11), text_color=FG,
        )
        res_label.pack(anchor="w", pady=(0, 4))

        res_var = tk.IntVar(value=res_val)
        res_slider = ctk.CTkSlider(
            media_tab, from_=640, to=3840, number_of_steps=50,
            progress_color=ACCENT, button_color=ACCENT,
            button_hover_color="#6380f7", fg_color=BG_DARK,
            command=lambda v: (
                res_var.set(int(v)),
                res_label.configure(text=f"Max Resolution: {int(v)}px"),
            ),
        )
        res_slider.set(res_val)
        res_slider.pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            media_tab,
            text="Lower = smaller file, faster LLM. 1280 usually optimal.",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 10))

        # JPEG quality slider
        qual_val = self.config.get("image_quality", 90)
        qual_label = ctk.CTkLabel(
            media_tab, text=f"JPEG Quality: {qual_val}",
            font=("Segoe UI", 11), text_color=FG,
        )
        qual_label.pack(anchor="w", pady=(0, 4))

        qual_var = tk.IntVar(value=qual_val)
        qual_slider = ctk.CTkSlider(
            media_tab, from_=30, to=100, number_of_steps=70,
            progress_color=ACCENT, button_color=ACCENT,
            button_hover_color="#6380f7", fg_color=BG_DARK,
            command=lambda v: (
                qual_var.set(int(v)),
                qual_label.configure(text=f"JPEG Quality: {int(v)}"),
            ),
        )
        qual_slider.set(qual_val)
        qual_slider.pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            media_tab,
            text="Lower = smaller file. 85 keeps text crisp. Try 70 for speed.",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 16))

        # ══════════════════════════════════════════════
        # VOICE & CLIP SECTION
        # ══════════════════════════════════════════════
        ctk.CTkLabel(
            media_tab, text="Voice & Clip",
            font=("Segoe UI", 13, "bold"), text_color=ACCENT,
        ).pack(anchor="w", pady=(0, 10))

        # Voice duration slider
        vdur_val = self.config.get("voice_duration", 30)
        vdur_label = ctk.CTkLabel(
            media_tab, text=f"Voice Duration: {vdur_val}s",
            font=("Segoe UI", 11), text_color=FG,
        )
        vdur_label.pack(anchor="w", pady=(0, 4))

        vdur_var = tk.IntVar(value=vdur_val)
        vdur_slider = ctk.CTkSlider(
            media_tab, from_=5, to=300, number_of_steps=59,
            progress_color=ORANGE, button_color=ORANGE,
            button_hover_color="#e67e22", fg_color=BG_DARK,
            command=lambda v: (
                vdur_var.set(int(v)),
                vdur_label.configure(text=f"Voice Duration: {int(v)}s"),
            ),
        )
        vdur_slider.set(vdur_val)
        vdur_slider.pack(fill="x", pady=(0, 10))

        # Clip duration slider
        cdur_val = self.config.get("clip_duration", 10)
        cdur_label = ctk.CTkLabel(
            media_tab, text=f"Clip Duration: {cdur_val}s",
            font=("Segoe UI", 11), text_color=FG,
        )
        cdur_label.pack(anchor="w", pady=(0, 4))

        cdur_var = tk.IntVar(value=cdur_val)
        cdur_slider = ctk.CTkSlider(
            media_tab, from_=3, to=180, number_of_steps=59,
            progress_color=ORANGE, button_color=ORANGE,
            button_hover_color="#e67e22", fg_color=BG_DARK,
            command=lambda v: (
                cdur_var.set(int(v)),
                cdur_label.configure(text=f"Clip Duration: {int(v)}s"),
            ),
        )
        cdur_slider.set(cdur_val)
        cdur_slider.pack(fill="x", pady=(0, 12))

        # Voice clean switch
        clean_var = tk.BooleanVar(value=self.config.get("voice_clean", True))
        clean_switch = ctk.CTkSwitch(
            media_tab, text="Clean voice (remove noise + trim pauses)",
            variable=clean_var, font=("Segoe UI", 11),
            text_color=FG, progress_color=GREEN,
            button_color="#fff", button_hover_color="#ddd",
            fg_color=BG_DARK,
        )
        clean_switch.pack(anchor="w", pady=(0, 20))

        # ══════════════════════════════════════════════
        # MAINTENANCE SECTION
        # ══════════════════════════════════════════════
        ctk.CTkLabel(
            maint_tab, text="Maintenance",
            font=("Segoe UI", 13, "bold"), text_color=ACCENT,
        ).pack(anchor="w", pady=(0, 10))

        cleanup_val = self.config.get("auto_cleanup_days", 7)
        cleanup_label = ctk.CTkLabel(
            maint_tab,
            text=(f"Auto-cleanup: {cleanup_val} day(s)"
                  if cleanup_val > 0 else "Auto-cleanup: disabled"),
            font=("Segoe UI", 11), text_color=FG,
        )
        cleanup_label.pack(anchor="w", pady=(0, 4))

        cleanup_var = tk.IntVar(value=cleanup_val)
        cleanup_slider = ctk.CTkSlider(
            maint_tab, from_=0, to=90, number_of_steps=90,
            progress_color=PURPLE, button_color=PURPLE,
            button_hover_color=PURPLE_HOVER, fg_color=BG_DARK,
            command=lambda v: (
                cleanup_var.set(int(v)),
                cleanup_label.configure(
                    text=(f"Auto-cleanup: {int(v)} day(s)"
                          if int(v) > 0 else "Auto-cleanup: disabled")
                ),
            ),
        )
        cleanup_slider.set(cleanup_val)
        cleanup_slider.pack(fill="x", pady=(0, 2))
        ctk.CTkLabel(
            maint_tab,
            text="Delete captures/summaries older than N days on startup. 0 = disabled.",
            font=("Segoe UI", 9), text_color=MUTED,
        ).pack(anchor="w", pady=(0, 20))

        # ══════════════════════════════════════════════
        # KEYBOARD SHORTCUTS SECTION
        # ══════════════════════════════════════════════
        ctk.CTkLabel(
            s_scroll, text="Keyboard Shortcuts",
            font=("Segoe UI", 13, "bold"), text_color=ACCENT,
        ).pack(anchor="w", pady=(0, 10))

        from eye2byte import get_hotkeys, DEFAULT_CONFIG
        current_hotkeys = get_hotkeys(self.config)
        hotkey_vars = {}  # {action_name: tk.StringVar}

        # Groups: (section_label, [(action_name, display_label), ...])
        hotkey_groups = [
            ("Global Hotkeys", [
                ("capture", "Capture"),
                ("annotate", "Annotate"),
                ("voice_toggle", "Voice Toggle"),
                ("clipboard", "Clipboard"),
            ]),
            ("Annotation Tools", [
                ("tool_arrow", "Arrow"),
                ("tool_circle", "Circle"),
                ("tool_rect", "Rectangle"),
                ("tool_freehand", "Freehand"),
                ("tool_text", "Text"),
            ]),
            ("Voice", [
                ("ptt", "Push-to-Talk"),
            ]),
        ]

        conflict_label = [None]  # Use list for mutable nonlocal

        def _check_conflicts():
            if conflict_label[0]:
                conflict_label[0].destroy()
                conflict_label[0] = None

            seen = {}
            for action, var in hotkey_vars.items():
                val = var.get()
                if val and val in seen:
                    conflict_label[0] = ctk.CTkLabel(
                        s_scroll,
                        text=f"Conflict: '{hotkey_to_display(val)}' used by both {seen[val]} and {action}",
                        font=("Segoe UI", 10), text_color=RED,
                    )
                    conflict_label[0].pack(anchor="w", pady=(0, 4))
                    return
                if val:
                    seen[val] = action

        def _start_capture(action, entry_widget, var):
            """Put entry into key-capture mode."""
            entry_widget.configure(state="normal")
            var.set("")
            entry_widget.configure(placeholder_text="Press keys...")
            entry_widget.focus_set()

            def _on_key(event):
                key = event.keysym.lower()
                # Build combo string
                parts = []
                if event.state & 0x4:  # Control
                    parts.append("ctrl")
                if event.state & 0x1:  # Shift
                    parts.append("shift")
                if event.state & 0x20000:  # Alt
                    parts.append("alt")

                # Skip bare modifier keys
                if key in ("control_l", "control_r", "shift_l", "shift_r",
                           "alt_l", "alt_r", "caps_lock"):
                    return "break"

                parts.append(key)
                combo = "+".join(parts)
                var.set(combo)
                entry_widget.configure(state="readonly")
                entry_widget.unbind("<Key>")
                s_scroll.focus_set()
                _check_conflicts()
                return "break"

            entry_widget.bind("<Key>", _on_key)

        for group_label, actions in hotkey_groups:
            ctk.CTkLabel(
                s_scroll, text=group_label,
                font=("Segoe UI", 11), text_color=MUTED_LIGHT,
            ).pack(anchor="w", pady=(4, 2))

            for action_name, display_name in actions:
                row = ctk.CTkFrame(s_scroll, fg_color="transparent")
                row.pack(fill="x", pady=2)

                ctk.CTkLabel(
                    row, text=display_name, font=("Segoe UI", 11),
                    text_color=FG, width=120, anchor="w",
                ).pack(side="left")

                var = tk.StringVar(value=current_hotkeys.get(action_name, ""))
                hotkey_vars[action_name] = var

                entry = ctk.CTkEntry(
                    row, textvariable=var, font=("Consolas", 11),
                    width=180, height=30, state="readonly",
                    fg_color=BG_DARK, text_color=FG, border_color="#333333",
                )
                entry.pack(side="left", padx=(4, 4))

                ctk.CTkButton(
                    row, text="Set", width=40, height=28, corner_radius=6,
                    fg_color=ACCENT, hover_color=BLUE,
                    font=("Segoe UI", 10), text_color="#fff",
                    command=lambda a=action_name, e=entry, v=var: _start_capture(a, e, v),
                ).pack(side="left")

        # Reset to defaults button
        def _reset_hotkeys():
            defaults = DEFAULT_CONFIG["hotkeys"]
            for action, var in hotkey_vars.items():
                var.set(defaults.get(action, ""))
            _check_conflicts()

        ctk.CTkButton(
            s_scroll, text="Reset to Defaults", width=140, height=30,
            corner_radius=8, fg_color="#2a2a48", hover_color="#3a3a55",
            text_color=MUTED_LIGHT, font=("Segoe UI", 10),
            command=_reset_hotkeys,
        ).pack(anchor="w", pady=(8, 20))

        # ══════════════════════════════════════════════
        # SAVE / CANCEL
        # ══════════════════════════════════════════════
        btn_row = ctk.CTkFrame(win, fg_color="transparent")

        def _save():
            self.config["provider"] = provider_var.get()
            self.config["ollama_url"] = url_var.get().strip().rstrip("/")
            self.config["model"] = model_var.get()
            self.config["openrouter_model"] = or_model_var.get().strip()
            self.config["hyperbolic_model"] = hyp_model_var.get().strip()
            self.config["gemini_model"] = gem_model_var.get().strip()
            self.config["output_dir"] = outdir_var.get().strip()
            self.config["image_max_size"] = res_var.get()
            self.config["image_quality"] = qual_var.get()
            self.config["voice_duration"] = vdur_var.get()
            self.config["clip_duration"] = cdur_var.get()
            self.config["voice_clean"] = clean_var.get()
            self.config["auto_cleanup_days"] = cleanup_var.get()
            self.config["hotkeys"] = {
                action: var.get() for action, var in hotkey_vars.items()
            }
            self.e2b.save_config(self.config)
            self._set_status("Settings saved!", GREEN)
            win.destroy()

        ctk.CTkButton(
            btn_row, text="Save", font=("Segoe UI", 13, "bold"),
            fg_color=GREEN, hover_color=GREEN_HOVER, text_color="#000",
            corner_radius=10, height=40,
            command=_save,
        ).pack(side="left", fill="x", expand=True, padx=(0, 8))

        ctk.CTkButton(
            btn_row, text="Cancel", font=("Segoe UI", 12),
            fg_color="#2a2a48", hover_color="#3a3a55", text_color=MUTED_LIGHT,
            corner_radius=10, height=40, width=90,
            command=win.destroy,
        ).pack(side="right")

        # Pack button row at bottom first to guarantee space
        btn_row.pack(side="bottom", fill="x", padx=16, pady=(8, 16))
        # NOW pack tabview to fill remaining space
        tabview.pack(fill="both", expand=True, padx=16, pady=(16, 0))

    def _open_settings_legacy(self):
        """Fallback settings window with plain tkinter."""
        win = tk.Toplevel(self.root)
        win.title("Eye2byte Settings")
        win.attributes("-topmost", True)
        win.resizable(False, False)
        win.configure(bg=BG)
        win.geometry("400x680")

        canvas = tk.Canvas(win, bg=BG, highlightthickness=0)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(win, orient="vertical", command=canvas.yview)
        scrollbar.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scrollbar.set)

        frame = tk.Frame(canvas, bg=BG, padx=16, pady=12)
        canvas.create_window((0, 0), window=frame, anchor="nw")
        frame.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        tk.Label(frame, text="Settings", font=("Segoe UI", 12, "bold"),
                 bg=BG, fg=FG).pack(anchor="w", pady=(0, 10))

        tk.Label(frame, text="Provider", font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=ACCENT).pack(anchor="w", pady=(0, 4))

        provider_var = tk.StringVar(value=self.config.get("provider", "ollama"))
        prov_frame = tk.Frame(frame, bg=BG)
        prov_frame.pack(fill="x", pady=(0, 8))
        for prov in ["ollama", "openrouter", "hyperbolic", "gemini"]:
            tk.Radiobutton(
                prov_frame, text=prov.capitalize(), variable=provider_var,
                value=prov, font=("Segoe UI", 9),
                bg=BG, fg=MUTED_LIGHT, selectcolor=BG_DARK,
                activebackground=BG, activeforeground=FG,
            ).pack(side="left", padx=(0, 8))

        tk.Label(frame, text="Ollama URL:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w")
        url_var = tk.StringVar(
            value=self.config.get("ollama_url", "http://localhost:11434"))
        tk.Entry(frame, textvariable=url_var, font=("Consolas", 10),
                 bg=BG_DARK, fg=FG, insertbackground=FG, relief="flat",
                 width=40).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Ollama Vision Model:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w")
        model_frame = tk.Frame(frame, bg=BG)
        model_frame.pack(fill="x", pady=(2, 8))
        model_var = tk.StringVar(value=self.config.get("model", "auto"))
        model_combo = tk.OptionMenu(model_frame, model_var, "auto")
        model_combo.configure(
            font=("Consolas", 10), bg=BG_DARK, fg=FG,
            activebackground=ACCENT, highlightthickness=0, relief="flat",
            width=25,
        )
        model_combo.pack(side="left", fill="x", expand=True)

        status_lbl = tk.Label(frame, text="", font=("Segoe UI", 8),
                              bg=BG, fg=MUTED_LIGHT)
        status_lbl.pack(anchor="w")

        def _fetch_models():
            status_lbl.configure(text="Fetching models from Ollama...",
                                 fg=ORANGE)
            win.update()
            tmp_config = dict(self.config)
            tmp_config["ollama_url"] = url_var.get().strip().rstrip("/")
            models = self.e2b.fetch_ollama_models(tmp_config)
            menu = model_combo["menu"]
            menu.delete(0, "end")
            menu.add_command(label="auto",
                             command=lambda: model_var.set("auto"))
            if models:
                for m in models:
                    menu.add_command(label=m,
                                     command=lambda v=m: model_var.set(v))
                status_lbl.configure(
                    text=f"Found {len(models)} model(s)", fg=GREEN)
            else:
                status_lbl.configure(
                    text="No models found (is Ollama running?)", fg=RED)

        tk.Button(
            model_frame, text="Refresh", font=("Segoe UI", 8),
            bg=ACCENT, fg=FG, activebackground="#1a5276",
            relief="flat", cursor="hand2", padx=6,
            command=lambda: threading.Thread(
                target=_fetch_models, daemon=True).start(),
        ).pack(side="left", padx=(6, 0))

        tk.Label(frame, text="OpenRouter Model:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        or_model_var = tk.StringVar(
            value=self.config.get("openrouter_model",
                                  "qwen/qwen2.5-vl-72b-instruct:free"))
        tk.Entry(frame, textvariable=or_model_var, font=("Consolas", 10),
                 bg=BG_DARK, fg=FG, insertbackground=FG, relief="flat",
                 width=40).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Hyperbolic Model:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        hyp_model_var = tk.StringVar(
            value=self.config.get("hyperbolic_model",
                                  "Qwen/Qwen2.5-VL-72B-Instruct"))
        tk.Entry(frame, textvariable=hyp_model_var, font=("Consolas", 10),
                 bg=BG_DARK, fg=FG, insertbackground=FG, relief="flat",
                 width=40).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Gemini Model:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        gem_model_var = tk.StringVar(
            value=self.config.get("gemini_model", "gemini-2.5-flash-lite"))
        tk.Entry(frame, textvariable=gem_model_var, font=("Consolas", 10),
                 bg=BG_DARK, fg=FG, insertbackground=FG, relief="flat",
                 width=40).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Output Directory:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        outdir_var = tk.StringVar(value=self.config.get("output_dir", ""))
        tk.Entry(frame, textvariable=outdir_var, font=("Consolas", 10),
                 bg=BG_DARK, fg=FG, insertbackground=FG, relief="flat",
                 width=40).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Image Optimization",
                 font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=ACCENT).pack(anchor="w", pady=(8, 4))

        tk.Label(frame, text="Max Resolution (longest side, px):",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w")
        res_var = tk.IntVar(value=self.config.get("image_max_size", 1920))
        tk.Scale(
            frame, from_=640, to=3840, variable=res_var,
            orient="horizontal", font=("Consolas", 9),
            bg=BG, fg=FG, troughcolor=BG_DARK, highlightthickness=0,
            activebackground=ACCENT, length=280, resolution=64,
        ).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="JPEG Quality:", font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w")
        qual_var = tk.IntVar(value=self.config.get("image_quality", 90))
        tk.Scale(
            frame, from_=30, to=100, variable=qual_var,
            orient="horizontal", font=("Consolas", 9),
            bg=BG, fg=FG, troughcolor=BG_DARK, highlightthickness=0,
            activebackground=ACCENT, length=280,
        ).pack(fill="x", pady=(2, 8))

        tk.Label(frame, text="Voice & Clip", font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=ACCENT).pack(anchor="w", pady=(8, 4))

        tk.Label(frame, text="Voice Duration (seconds):",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        vdur_var = tk.IntVar(value=self.config.get("voice_duration", 30))
        tk.Spinbox(frame, from_=5, to=300, textvariable=vdur_var,
                   font=("Consolas", 10), bg=BG_DARK, fg=FG,
                   buttonbackground=ACCENT, relief="flat",
                   width=10).pack(anchor="w", pady=(2, 8))

        tk.Label(frame, text="Clip Duration (seconds):",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED_LIGHT).pack(anchor="w", pady=(4, 0))
        cdur_var = tk.IntVar(value=self.config.get("clip_duration", 10))
        tk.Spinbox(frame, from_=3, to=180, textvariable=cdur_var,
                   font=("Consolas", 10), bg=BG_DARK, fg=FG,
                   buttonbackground=ACCENT, relief="flat",
                   width=10).pack(anchor="w", pady=(2, 8))

        clean_var = tk.BooleanVar(value=self.config.get("voice_clean", True))
        tk.Checkbutton(
            frame, text="Clean voice (remove noise + trim pauses)",
            variable=clean_var, font=("Segoe UI", 9),
            bg=BG, fg=MUTED_LIGHT, selectcolor=BG_DARK,
            activebackground=BG, activeforeground=FG,
        ).pack(anchor="w", pady=(0, 12))

        btn_frame = tk.Frame(frame, bg=BG)
        btn_frame.pack(fill="x")

        def _save():
            self.config["provider"] = provider_var.get()
            self.config["ollama_url"] = url_var.get().strip().rstrip("/")
            self.config["model"] = model_var.get()
            self.config["openrouter_model"] = or_model_var.get().strip()
            self.config["hyperbolic_model"] = hyp_model_var.get().strip()
            self.config["gemini_model"] = gem_model_var.get().strip()
            self.config["output_dir"] = outdir_var.get().strip()
            self.config["image_max_size"] = res_var.get()
            self.config["image_quality"] = qual_var.get()
            self.config["voice_duration"] = vdur_var.get()
            self.config["clip_duration"] = cdur_var.get()
            self.config["voice_clean"] = clean_var.get()
            self.e2b.save_config(self.config)
            self._set_status("Settings saved!", GREEN)
            win.destroy()

        tk.Button(btn_frame, text="Save", font=("Segoe UI", 10, "bold"),
                  bg=GREEN, fg="#000", activebackground=GREEN_HOVER,
                  relief="flat", cursor="hand2", padx=16, pady=4,
                  command=_save).pack(side="left", fill="x", expand=True,
                                      padx=(0, 6))
        tk.Button(btn_frame, text="Cancel", font=("Segoe UI", 9),
                  bg=MUTED, fg="#fff", relief="flat", cursor="hand2",
                  padx=12, pady=4,
                  command=win.destroy).pack(side="left")

    # --- UI helpers ---

    def _copy_at_path(self):
        if self.current_session:
            at_path = f"@{self.current_session['dir']}"
            copy_to_clipboard(at_path)
            self._set_status("Copied to clipboard!", GREEN)
            self.copy_btn.configure(text="Copied!")
            self.root.after(1500, lambda: self.copy_btn.configure(
                text="Copy @path"))

    def _open_folder(self):
        if self.current_session:
            d = self.current_session["dir"]
            if sys.platform == "win32":
                os.startfile(d)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d])

    # ------------------------------------------------------------------
    # System tray
    # ------------------------------------------------------------------

    def _on_minimize(self):
        """Send window to system tray (pystray) or just hide if unavailable."""
        self.root.withdraw()
        if _HAS_TRAY:
            self._show_tray_icon()
        # Without pystray the window is simply hidden; global hotkeys still work.
        # The user can bring it back by running eye2byte_ui.py again.

    def _show_tray_icon(self):
        """Create and display a system-tray icon with a context menu."""
        if self._tray_icon is not None:
            return  # already showing
        menu = pystray.Menu(
            pystray.MenuItem("Show Eye2byte", self._tray_restore, default=True),
            pystray.MenuItem("Quit", self._tray_quit),
        )
        self._tray_icon = pystray.Icon(
            "eye2byte", _load_tray_icon(), "Eye2byte", menu,
        )
        threading.Thread(target=self._tray_icon.run, daemon=True).start()

    def _tray_restore(self, icon=None, item=None):
        """Restore window from tray."""
        if self._tray_icon:
            self._tray_icon.stop()
            self._tray_icon = None
        self.root.after(0, self._restore_window)

    def _restore_window(self):
        self.root.deiconify()
        self.root.attributes("-topmost", True)
        self.root.focus_force()

    def _tray_quit(self, icon=None, item=None):
        """Quit from tray menu."""
        if self._tray_icon:
            self._tray_icon.stop()
            self._tray_icon = None
        self.root.after(0, self._on_close)

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------

    def _on_close(self):
        # Stop tray icon if running
        if self._tray_icon:
            try:
                self._tray_icon.stop()
            except Exception:
                pass
            self._tray_icon = None
        # Stop any active recording cleanly
        if self._voice_state == "recording" and self._voice_handle:
            try:
                proc = self._voice_handle.get("proc")
                if proc:
                    if proc.stdin and not proc.stdin.closed:
                        proc.stdin.write(b"q")
                        proc.stdin.flush()
                        proc.stdin.close()
                    proc.terminate()
            except Exception:
                pass
            self._voice_state = "idle"
        if self._timer_after_id:
            self.root.after_cancel(self._timer_after_id)
        self.hotkeys.stop()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


# ---------------------------------------------------------------------------
# Popup mode (backward compat — launched by eye2byte.py after a session)
# ---------------------------------------------------------------------------
def show_popup(session_dir: str):
    """Show a popup for a completed session."""
    session_id = os.path.basename(session_dir)
    at_path = f"@{session_dir}"

    manifest_path = os.path.join(session_dir, "manifest.json")
    artifacts = []
    if os.path.exists(manifest_path):
        with open(manifest_path) as f:
            manifest = json.load(f)
            artifacts = list(manifest.get("artifacts", {}).keys())

    if _HAS_CTK:
        _show_popup_modern(session_dir, session_id, at_path, artifacts)
    else:
        _show_popup_legacy(session_dir, session_id, at_path, artifacts)


def _show_popup_modern(session_dir, session_id, at_path, artifacts):
    """Modern popup with CustomTkinter."""
    root = ctk.CTk()
    root.title("Eye2byte")
    root.attributes("-topmost", True)
    root.resizable(False, False)
    root.overrideredirect(True)
    root.configure(fg_color=BG)

    outer = ctk.CTkFrame(
        root, fg_color=BG, corner_radius=14,
        border_width=1, border_color=BORDER,
    )
    outer.pack(fill="both", expand=True, padx=1, pady=1)

    frame = ctk.CTkFrame(outer, fg_color="transparent")
    frame.pack(fill="both", expand=True, padx=16, pady=14)

    ctk.CTkLabel(
        frame, text="Eye2byte",
        font=("Segoe UI", 14, "bold"), text_color=ACCENT,
    ).pack(anchor="w")

    ctk.CTkLabel(
        frame, text=f"Session: {session_id}",
        font=("Consolas", 11), text_color=FG,
    ).pack(anchor="w", pady=(6, 0))

    if artifacts:
        ctk.CTkLabel(
            frame, text=" + ".join(artifacts),
            font=("Segoe UI", 10), text_color=MUTED_LIGHT,
            wraplength=280,
        ).pack(anchor="w", pady=(2, 0))

    ctk.CTkLabel(
        frame, text=at_path,
        font=("Consolas", 9), text_color=MUTED_LIGHT,
        wraplength=280,
    ).pack(anchor="w", pady=(4, 10))

    status_var = tk.StringVar(value="")
    ctk.CTkLabel(
        frame, textvariable=status_var,
        font=("Segoe UI", 10), text_color=GREEN,
    ).pack(fill="x")

    btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
    btn_frame.pack(fill="x", pady=(6, 0))

    def on_copy():
        copy_to_clipboard(at_path)
        status_var.set("Copied to clipboard!")

    ctk.CTkButton(
        btn_frame, text="Copy @path",
        font=("Segoe UI", 12, "bold"), height=38,
        fg_color=GREEN, hover_color=GREEN_HOVER, text_color="#000",
        corner_radius=10, command=on_copy,
    ).pack(side="left", fill="x", expand=True, padx=(0, 6))

    def on_open():
        if sys.platform == "win32":
            os.startfile(session_dir)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", session_dir])
        else:
            subprocess.Popen(["xdg-open", session_dir])

    ctk.CTkButton(
        btn_frame, text="Open",
        font=("Segoe UI", 11), height=38, width=60,
        fg_color="#2a2a48", hover_color=ACCENT, text_color=FG,
        corner_radius=10, command=on_open,
    ).pack(side="left", padx=(0, 6))

    ctk.CTkButton(
        btn_frame, text="X",
        font=("Segoe UI", 11, "bold"), height=38, width=38,
        fg_color="#3a2020", hover_color=RED, text_color="#ff6b6b",
        corner_radius=10, command=root.destroy,
    ).pack(side="right")

    # Position bottom-right
    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    ww = root.winfo_reqwidth()
    wh = root.winfo_reqheight()
    root.geometry(f"+{sw - ww - 20}+{sh - wh - 60}")

    root.after(30000, root.destroy)
    root.mainloop()


def _show_popup_legacy(session_dir, session_id, at_path, artifacts):
    """Fallback popup with plain tkinter."""
    root = tk.Tk()
    root.title("Eye2byte")
    root.attributes("-topmost", True)
    root.resizable(False, False)
    root.configure(bg=BG)
    root.overrideredirect(True)

    frame = tk.Frame(root, bg=BG, padx=16, pady=12)
    frame.pack(fill="both", expand=True)

    tk.Label(frame, text="Eye2byte", font=("Segoe UI", 11, "bold"),
             bg=BG, fg=ACCENT).pack(anchor="w")
    tk.Label(frame, text=f"Session: {session_id}", font=("Consolas", 10),
             bg=BG, fg=FG).pack(anchor="w", pady=(4, 0))

    if artifacts:
        tk.Label(frame, text=" + ".join(artifacts), font=("Segoe UI", 8),
                 bg=BG, fg=MUTED_LIGHT, wraplength=280).pack(anchor="w",
                                                               pady=(2, 0))
    tk.Label(frame, text=at_path, font=("Consolas", 8),
             bg=BG, fg=MUTED_LIGHT, wraplength=280).pack(anchor="w",
                                                           pady=(4, 8))

    status_var = tk.StringVar(value="")
    tk.Label(frame, textvariable=status_var, font=("Segoe UI", 8),
             bg=BG, fg=GREEN).pack(fill="x")

    btn_frame = tk.Frame(frame, bg=BG)
    btn_frame.pack(fill="x", pady=(4, 0))

    def on_copy():
        copy_to_clipboard(at_path)
        status_var.set("Copied to clipboard!")

    tk.Button(btn_frame, text="Copy @path", font=("Segoe UI", 10, "bold"),
              bg=GREEN, fg="#000", activebackground=GREEN_HOVER,
              relief="flat", cursor="hand2", padx=16, pady=6,
              command=on_copy).pack(side="left", fill="x", expand=True,
                                    padx=(0, 4))

    def on_open():
        if sys.platform == "win32":
            os.startfile(session_dir)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", session_dir])
        else:
            subprocess.Popen(["xdg-open", session_dir])

    tk.Button(btn_frame, text="Open", font=("Segoe UI", 9),
              bg=ACCENT, fg=FG, relief="flat", cursor="hand2",
              padx=10, pady=6, command=on_open).pack(side="left", padx=(0, 4))
    tk.Button(btn_frame, text="X", font=("Segoe UI", 9, "bold"),
              bg=RED, fg="#fff", relief="flat", cursor="hand2",
              padx=8, pady=6, command=root.destroy).pack(side="left")

    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    ww = root.winfo_reqwidth()
    wh = root.winfo_reqheight()
    root.geometry(f"+{sw - ww - 20}+{sh - wh - 60}")

    root.after(30000, root.destroy)
    root.mainloop()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    # When launched via pythonw / gui_scripts, there's no console —
    # redirect stdout/stderr to devnull so print() doesn't crash.
    if sys.platform == "win32" and sys.stdout is None:
        sys.stdout = open(os.devnull, "w")
        sys.stderr = open(os.devnull, "w")

    if len(sys.argv) >= 2 and os.path.isdir(sys.argv[1]):
        # Popup mode: show result for existing session
        show_popup(sys.argv[1])
    else:
        # Panel mode: persistent control panel
        try:
            panel = Eye2bytePanel()
            panel.run()
        except ImportError as e:
            print(f"[eye2byte] UI requires tkinter: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
