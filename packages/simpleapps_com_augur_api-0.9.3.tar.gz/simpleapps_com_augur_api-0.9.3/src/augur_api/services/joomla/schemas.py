"""Schemas for the Joomla service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Users
class UserListParams(EdgeCacheParams):
    """Parameters for listing users."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    access_level_list: str | None = None
    customer_id: int | None = None


class UserDocParams(EdgeCacheParams):
    """Parameters for getting user document."""

    include_ship_to: str | None = None


class User(CamelCaseModel):
    """User entity."""

    id: int | None = None
    name: str | None = None
    username: str | None = None
    email: str | None = None
    block: int | None = None
    register_date: str | None = None
    last_visit_date: str | None = None
    send_email: int | None = None


class UserCreateParams(BaseModel):
    """Parameters for creating a user."""

    name: str
    username: str
    email: str
    password: str | None = None


class UserUpdateParams(BaseModel):
    """Parameters for updating a user."""

    name: str | None = None
    email: str | None = None
    block: int | None = None


# Content
class ContentListParams(EdgeCacheParams):
    """Parameters for listing content."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    category_id_list: str | None = None
    tags_list: str | None = None


class Content(CamelCaseModel):
    """Content article entity."""

    id: int | None = None
    title: str | None = None
    alias: str | None = None
    introtext: str | None = None
    fulltext: str | None = None
    state: int | None = None
    catid: int | None = None
    created: str | None = None
    modified: str | None = None
    publish_up: str | None = None
    publish_down: str | None = None
    hits: int | None = None
    featured: int | None = None


class ContentCreateParams(BaseModel):
    """Parameters for creating content."""

    title: str
    catid: int
    introtext: str | None = None
    fulltext: str | None = None
    state: int | None = None


class ContentUpdateParams(BaseModel):
    """Parameters for updating content."""

    title: str | None = None
    introtext: str | None = None
    fulltext: str | None = None
    state: int | None = None
    catid: int | None = None


# Content by ID (single item)
class ContentIdParams(EdgeCacheParams):
    """Parameters for getting content by ID."""

    alias: str | None = None
    catid: int | None = None


# Categories
class CategoryListParams(EdgeCacheParams):
    """Parameters for listing categories."""

    limit: int | None = None
    offset: int | None = None
    extension: str | None = None


class Category(CamelCaseModel):
    """Category entity."""

    id: int | None = None
    parent_id: int | None = None
    title: str | None = None
    alias: str | None = None
    description: str | None = None
    published: int | None = None
    extension: str | None = None
    level: int | None = None
    path: str | None = None


class CategoryCreateParams(BaseModel):
    """Parameters for creating a category."""

    title: str
    parent_id: int | None = None
    extension: str | None = None
    description: str | None = None


# Extensions
class ExtensionListParams(EdgeCacheParams):
    """Parameters for listing extensions."""

    limit: int | None = None
    offset: int | None = None
    type: str | None = None


class Extension(CamelCaseModel):
    """Extension entity."""

    extension_id: int | None = None
    name: str | None = None
    type: str | None = None
    element: str | None = None
    enabled: int | None = None
    access: int | None = None
    manifest_cache: str | None = None


# Tags
class TagListParams(EdgeCacheParams):
    """Parameters for listing tags."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    cat_id: int | None = None
    parent_id: int | None = None


class Tag(CamelCaseModel):
    """Tag entity."""

    id: int | None = None
    title: str | None = None
    alias: str | None = None
    description: str | None = None
    published: int | None = None
    hits: int | None = None


# Menu
class MenuListParams(EdgeCacheParams):
    """Parameters for listing menu items."""

    limit: int | None = None
    offset: int | None = None
    menutype: str | None = None


class Menu(CamelCaseModel):
    """Menu item entity."""

    id: int | None = None
    menutype: str | None = None
    title: str | None = None
    alias: str | None = None
    link: str | None = None
    type: str | None = None
    published: int | None = None
    level: int | None = None
    parent_id: int | None = None


# Usergroups
class UsergroupsListParams(EdgeCacheParams):
    """Parameters for listing usergroups."""

    order_by: str | None = None
    parent_id_list: str | None = None


class Usergroup(CamelCaseModel):
    """Usergroup entity."""

    id: int | None = None
    parent_id: int | None = None
    title: str | None = None


# User verify password
class VerifyPasswordParams(CamelCaseModel):
    """Parameters for verifying user password."""

    username: str
    password: str
    site_id: str | None = None


class VerifyPasswordResult(CamelCaseModel):
    """Result of password verification."""

    id: int | None = None
    is_verified: bool | None = None
    username: str | None = None
    token: str | bool | None = None
    email: str | None = None


# User groups (user_group_map)
class UserGroupListParams(EdgeCacheParams):
    """Parameters for listing user groups."""

    limit: int | None = None
    offset: int | None = None


class UserGroup(CamelCaseModel):
    """User group mapping entity."""

    user_id: int | None = None
    group_id: int | None = None
    group_title: str | None = None


class UserGroupCreateParams(BaseModel):
    """Parameters for creating/updating user group mapping."""

    group_id: int


# Trinity user
class TrinityUser(CamelCaseModel):
    """Trinity user document entity."""

    id: int | None = None
    name: str | None = None
    username: str | None = None
    email: str | None = None
    customer_id: int | None = None
    contact_id: int | None = None
