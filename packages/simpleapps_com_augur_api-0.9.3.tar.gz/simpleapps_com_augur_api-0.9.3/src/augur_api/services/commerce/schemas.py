"""Schemas for the Commerce service."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Cart Header
class CartHdrListParams(EdgeCacheParams):
    """Parameters for listing cart headers."""

    user_id: int


class CartHdrLookupParams(EdgeCacheParams):
    """Parameters for cart lookup."""

    user_id: int
    customer_id: int
    contact_id: int
    cart_token: str | None = None
    user_cart_no: str | None = None


class CartHdr(CamelCaseModel):
    """Cart header entity."""

    cart_hdr_uid: int | None = None
    user_id: int | None = None
    customer_id: int | None = None
    contact_id: int | None = None
    cart_token: str | None = None
    user_cart_no: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class AlsoBoughtParams(EdgeCacheParams):
    """Parameters for also-bought recommendations."""

    limit: int | None = None
    offset: int | None = None


class AlsoBoughtItem(CamelCaseModel):
    """Also-bought recommendation item."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None
    score: float | None = None


# Cart Line
class CartLine(CamelCaseModel):
    """Cart line entity."""

    cart_line_uid: int | None = None
    cart_hdr_uid: int | None = None
    line_no: int | None = None
    inv_mast_uid: int | None = None
    item_id: str | None = None
    quantity: float | None = None
    unit_price: float | None = None
    extended_price: float | None = None
    unit_of_measure: str | None = None


class CartLineAddItem(BaseModel):
    """Item to add to cart."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    quantity: float
    unit_of_measure: str | None = None


class CartLineUpdateItem(BaseModel):
    """Item to update in cart."""

    line_no: int
    quantity: float | None = None
    unit_of_measure: str | None = None


class CartLineDeleteResponse(CamelCaseModel):
    """Response for cart line deletion."""

    success: bool | None = None
    message: str | None = None


# Checkout
class CheckoutCreateParams(BaseModel):
    """Parameters for creating checkout."""

    cart_hdr_uid: int | None = None
    customer_id: int | None = None
    contact_id: int | None = None
    ship_to_id: int | None = None
    po_no: str | None = None
    notes: str | None = None


class Checkout(CamelCaseModel):
    """Checkout entity."""

    checkout_uid: int | None = None
    cart_hdr_uid: int | None = None
    customer_id: int | None = None
    contact_id: int | None = None
    ship_to_id: int | None = None
    status_cd: int | None = None
    po_no: str | None = None
    order_no: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CheckoutDocParams(EdgeCacheParams):
    """Parameters for checkout document."""

    cart_hdr_uid: int | None = None
    limit: int | None = None
    offset: int | None = None


class CheckoutDoc(CamelCaseModel):
    """Checkout document."""

    checkout_uid: int | None = None
    order_no: int | None = None
    customer_id: int | None = None
    contact_id: int | None = None
    lines: list[Any] | None = None


class Prophet21Hdr(CamelCaseModel):
    """Prophet21 header entity."""

    prophet21_hdr_uid: int | None = None
    checkout_uid: int | None = None
    order_no: int | None = None
    status_cd: int | None = None


class Prophet21Line(CamelCaseModel):
    """Prophet21 line entity."""

    prophet21_line_uid: int | None = None
    prophet21_hdr_uid: int | None = None
    line_no: int | None = None
    inv_mast_uid: int | None = None
    quantity: float | None = None
