"""Customers service client for customer management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.customers.schemas import (
    Address,
    AddressParams,
    Contact,
    ContactDoc,
    ContactListParams,
    ContactUd,
    Customer,
    CustomerDoc,
    CustomerListParams,
    CustomerLookupParams,
    Invoice,
    InvoiceListParams,
    Order,
    OrderListParams,
    PurchasedItem,
    PurchasedItemsParams,
    Quote,
    QuoteListParams,
    ShipTo,
    ShipToListParams,
    WebAllowance,
)
from augur_api.services.resource import BaseResource


class CustomerResource(BaseResource):
    """Resource for /customer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/customer")

    def list(self, params: CustomerListParams | None = None) -> BaseResponse[List[Customer]]:
        """List customers.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Customer items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Customer]].model_validate(response)

    def lookup(self, params: CustomerLookupParams) -> BaseResponse[List[Customer]]:
        """Lookup customers by query.

        Args:
            params: Lookup parameters including query string.

        Returns:
            BaseResponse containing matching Customer items.
        """
        response = self._get("/lookup", params=params)
        return BaseResponse[List[Customer]].model_validate(response)

    def get(self, customer_id: int) -> BaseResponse[Customer]:
        """Get customer by ID.

        Args:
            customer_id: The customer ID.

        Returns:
            BaseResponse containing the Customer.
        """
        response = self._get(f"/{customer_id}")
        return BaseResponse[Customer].model_validate(response)

    def get_doc(self, customer_id: int) -> BaseResponse[CustomerDoc]:
        """Get full customer document.

        Args:
            customer_id: The customer ID.

        Returns:
            BaseResponse containing the CustomerDoc.
        """
        response = self._get(f"/{customer_id}/doc")
        return BaseResponse[CustomerDoc].model_validate(response)

    def get_address(
        self, customer_id: int, params: AddressParams | None = None
    ) -> BaseResponse[List[Address]]:
        """Get customer addresses.

        Args:
            customer_id: The customer ID.
            params: Optional filtering parameters.

        Returns:
            BaseResponse containing a list of Address items.
        """
        response = self._get(f"/{customer_id}/address", params=params)
        return BaseResponse[List[Address]].model_validate(response)

    def list_contacts(
        self, customer_id: int, params: ContactListParams | None = None
    ) -> BaseResponse[List[Contact]]:
        """List customer contacts.

        Args:
            customer_id: The customer ID.
            params: Optional filtering and pagination parameters.

        Returns:
            BaseResponse containing a list of Contact items.
        """
        response = self._get(f"/{customer_id}/contacts", params=params)
        return BaseResponse[List[Contact]].model_validate(response)

    def create_contact(self, customer_id: int, data: Any) -> BaseResponse[Contact]:
        """Create a contact for a customer.

        Args:
            customer_id: The customer ID.
            data: Contact creation parameters.

        Returns:
            BaseResponse containing the created Contact.
        """
        response = self._post(f"/{customer_id}/contacts", data=data)
        return BaseResponse[Contact].model_validate(response)

    def list_ship_to(
        self, customer_id: int, params: ShipToListParams | None = None
    ) -> BaseResponse[List[ShipTo]]:
        """List customer ship-to addresses.

        Args:
            customer_id: The customer ID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of ShipTo items.
        """
        response = self._get(f"/{customer_id}/ship-to", params=params)
        return BaseResponse[List[ShipTo]].model_validate(response)

    def create_ship_to(self, customer_id: int, data: Any) -> BaseResponse[ShipTo]:
        """Create a ship-to address for a customer.

        Args:
            customer_id: The customer ID.
            data: Ship-to creation parameters.

        Returns:
            BaseResponse containing the created ShipTo.
        """
        response = self._post(f"/{customer_id}/ship-to", data=data)
        return BaseResponse[ShipTo].model_validate(response)

    def list_orders(
        self, customer_id: int, params: OrderListParams | None = None
    ) -> BaseResponse[List[Order]]:
        """List customer orders.

        Args:
            customer_id: The customer ID.
            params: Optional query parameters.

        Returns:
            BaseResponse containing a list of Order items.
        """
        response = self._get(f"/{customer_id}/orders", params=params)
        return BaseResponse[List[Order]].model_validate(response)

    def get_order(self, customer_id: int, order_no: int) -> BaseResponse[Order]:
        """Get a specific customer order.

        Args:
            customer_id: The customer ID.
            order_no: The order number.

        Returns:
            BaseResponse containing the Order.
        """
        response = self._get(f"/{customer_id}/orders/{order_no}")
        return BaseResponse[Order].model_validate(response)

    def list_invoices(
        self, customer_id: int, params: InvoiceListParams | None = None
    ) -> BaseResponse[List[Invoice]]:
        """List customer invoices.

        Args:
            customer_id: The customer ID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of Invoice items.
        """
        response = self._get(f"/{customer_id}/invoices", params=params)
        return BaseResponse[List[Invoice]].model_validate(response)

    def get_invoice(self, customer_id: int, invoice_no: int) -> BaseResponse[Invoice]:
        """Get a specific customer invoice.

        Args:
            customer_id: The customer ID.
            invoice_no: The invoice number.

        Returns:
            BaseResponse containing the Invoice.
        """
        response = self._get(f"/{customer_id}/invoices/{invoice_no}")
        return BaseResponse[Invoice].model_validate(response)

    def list_quotes(
        self, customer_id: int, params: QuoteListParams | None = None
    ) -> BaseResponse[List[Quote]]:
        """List customer quotes.

        Args:
            customer_id: The customer ID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of Quote items.
        """
        response = self._get(f"/{customer_id}/quotes", params=params)
        return BaseResponse[List[Quote]].model_validate(response)

    def get_quote(self, customer_id: int, quote_no: int) -> BaseResponse[Quote]:
        """Get a specific customer quote.

        Args:
            customer_id: The customer ID.
            quote_no: The quote number.

        Returns:
            BaseResponse containing the Quote.
        """
        response = self._get(f"/{customer_id}/quotes/{quote_no}")
        return BaseResponse[Quote].model_validate(response)

    def list_purchased_items(
        self, customer_id: int, params: PurchasedItemsParams | None = None
    ) -> BaseResponse[List[PurchasedItem]]:
        """List customer purchased items.

        Args:
            customer_id: The customer ID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of PurchasedItem items.
        """
        response = self._get(f"/{customer_id}/purchased-items", params=params)
        return BaseResponse[List[PurchasedItem]].model_validate(response)


class ContactsResource(BaseResource):
    """Resource for /contacts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contacts")

    def get_doc(self, contact_id: int) -> BaseResponse[ContactDoc]:
        """Get full contact document.

        Args:
            contact_id: The contact ID.

        Returns:
            BaseResponse containing the ContactDoc.
        """
        response = self._get(f"/{contact_id}/doc")
        return BaseResponse[ContactDoc].model_validate(response)

    def get_web_allowance(self, contact_id: int) -> BaseResponse[WebAllowance]:
        """Get contact web permissions.

        Args:
            contact_id: The contact ID.

        Returns:
            BaseResponse containing the WebAllowance.
        """
        response = self._get(f"/{contact_id}/web-allowance")
        return BaseResponse[WebAllowance].model_validate(response)

    def list_customers(
        self, contact_id: int, params: CustomerListParams | None = None
    ) -> BaseResponse[List[Customer]]:
        """List customers for a contact.

        Args:
            contact_id: The contact ID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of Customer items.
        """
        response = self._get(f"/{contact_id}/customers", params=params)
        return BaseResponse[List[Customer]].model_validate(response)

    def refresh(self) -> BaseResponse[bool]:
        """Refresh contact data.

        Returns:
            BaseResponse containing refresh status.
        """
        response = self._get("/refresh")
        return BaseResponse[bool].model_validate(response)


class ContactsUdResource(BaseResource):
    """Resource for /contacts-ud endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contacts-ud")

    def get(self, contact_id: int) -> BaseResponse[ContactUd]:
        """Get contact user-defined data.

        Args:
            contact_id: The contact ID.

        Returns:
            BaseResponse containing the ContactUd.
        """
        response = self._get(f"/{contact_id}")
        return BaseResponse[ContactUd].model_validate(response)


class ShipToResource(BaseResource):
    """Resource for /ship-to endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ship-to")

    def refresh(self) -> BaseResponse[bool]:
        """Refresh ship-to data.

        Returns:
            BaseResponse containing refresh status.
        """
        response = self._get("/refresh")
        return BaseResponse[bool].model_validate(response)


class OeContactsCustomerResource(BaseResource):
    """Resource for /oe-contacts-customer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-contacts-customer")

    def refresh(self) -> BaseResponse[bool]:
        """Refresh OE contacts customer data.

        Returns:
            BaseResponse containing refresh status.
        """
        response = self._get("/refresh")
        return BaseResponse[bool].model_validate(response)


class CustomersClient(BaseServiceClient):
    """Client for the Customers service.

    Provides access to customer management endpoints including:
    - Health check (health_check)
    - Customers (customer)
    - Contacts (contacts, contacts_ud)
    - Ship-to addresses (ship_to)
    - OE contacts customer (oe_contacts_customer)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> customers = api.customers.customer.list(CustomerListParams(limit=10))
        >>> for cust in customers.data:
        ...     print(cust.customer_name)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Customers client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._customer: CustomerResource | None = None
        self._contacts: ContactsResource | None = None
        self._contacts_ud: ContactsUdResource | None = None
        self._ship_to: ShipToResource | None = None
        self._oe_contacts_customer: OeContactsCustomerResource | None = None

    @property
    def customer(self) -> CustomerResource:
        """Access customer endpoints."""
        if self._customer is None:
            self._customer = CustomerResource(self._http)
        return self._customer

    @property
    def contacts(self) -> ContactsResource:
        """Access contacts endpoints."""
        if self._contacts is None:
            self._contacts = ContactsResource(self._http)
        return self._contacts

    @property
    def contacts_ud(self) -> ContactsUdResource:
        """Access contacts user-defined data endpoints."""
        if self._contacts_ud is None:
            self._contacts_ud = ContactsUdResource(self._http)
        return self._contacts_ud

    @property
    def ship_to(self) -> ShipToResource:
        """Access ship-to endpoints."""
        if self._ship_to is None:
            self._ship_to = ShipToResource(self._http)
        return self._ship_to

    @property
    def oe_contacts_customer(self) -> OeContactsCustomerResource:
        """Access OE contacts customer endpoints."""
        if self._oe_contacts_customer is None:
            self._oe_contacts_customer = OeContactsCustomerResource(self._http)
        return self._oe_contacts_customer
