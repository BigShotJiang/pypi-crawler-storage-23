"""Logistics service client for shipping and carrier operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.logistics.schemas import (
    ShipviaLtlRate,
    ShipviaLtlRatesParams,
    ShipviaRate,
    ShipviaRatesParams,
    SpeedshipFreight,
    SpeedshipFreightParams,
)
from augur_api.services.resource import BaseResource


class ShipviaResource(BaseResource):
    """Resource for /shipvia endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/shipvia")

    def rates(self, params: ShipviaRatesParams | None = None) -> BaseResponse[list[ShipviaRate]]:
        """Get ShipVia shipping rates from multiple carriers.

        Args:
            params: Optional query parameters for rate lookup.

        Returns:
            BaseResponse containing a list of ShipviaRate items.
        """
        response = self._get("/rates", params=params)
        return BaseResponse[list[ShipviaRate]].model_validate(response)

    def rates_ltl(
        self, params: ShipviaLtlRatesParams | None = None
    ) -> BaseResponse[list[ShipviaLtlRate]]:
        """Get ShipVia LTL (Less-Than-Truckload) freight rates.

        Args:
            params: Optional query parameters for LTL rate lookup.

        Returns:
            BaseResponse containing a list of ShipviaLtlRate items.
        """
        response = self._get("/rates/ltl", params=params)
        return BaseResponse[list[ShipviaLtlRate]].model_validate(response)


class SpeedshipResource(BaseResource):
    """Resource for /speedship endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/speedship")

    def freight(
        self, params: SpeedshipFreightParams | None = None
    ) -> BaseResponse[SpeedshipFreight]:
        """Get Speedship freight rates.

        Args:
            params: Optional parameters for freight rate lookup.

        Returns:
            BaseResponse containing the SpeedshipFreight.
        """
        response = self._get("/freight", params=params)
        return BaseResponse[SpeedshipFreight].model_validate(response)


class LogisticsClient(BaseServiceClient):
    """Client for the Logistics service.

    Provides access to shipping and logistics endpoints including:
    - Health check (health_check)
    - Shipvia options (shipvia)
    - Speedship rates (speedship)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> shipvias = api.logistics.shipvia.list()
        >>> for sv in shipvias.data:
        ...     print(sv.description)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Logistics client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._shipvia: ShipviaResource | None = None
        self._speedship: SpeedshipResource | None = None

    @property
    def shipvia(self) -> ShipviaResource:
        """Access shipvia endpoints."""
        if self._shipvia is None:
            self._shipvia = ShipviaResource(self._http)
        return self._shipvia

    @property
    def speedship(self) -> SpeedshipResource:
        """Access speedship endpoints."""
        if self._speedship is None:
            self._speedship = SpeedshipResource(self._http)
        return self._speedship
