"""JSON Story Runner - Executes language-agnostic JSON story definitions.

Features:
- Loads stories from shared/stories/definitions/*.json
- Uses snake_case natively (matches JSON format)
- Template syntax: {{captured.X}}, {{params.X}}, {{X|default:Y}}

Example:
    >>> from augur_api import AugurAPI
    >>> from tests.e2e.stories.story_runner import run_json_story, load_json_story
    >>> api = AugurAPI(token="...", site_id="...")
    >>> story = load_json_story("health-check")
    >>> result = run_json_story(api, site_config, story)
    >>> print(result["success"])
"""

import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from augur_api import AugurAPI


@dataclass
class SiteCredentials:
    """Site configuration for running stories."""

    site_id: str
    jwt: str
    name: str
    story_params: dict[str, Any] = field(default_factory=dict)


@dataclass
class StepResult:
    """Result of executing a single step."""

    step_id: str
    description: str
    service: str
    method: str
    params: Any
    success: bool
    response_time_ms: int
    response: Any = None
    response_fields: list[str] | None = None
    error: str | None = None
    captured: dict[str, Any] | None = None


@dataclass
class StoryResult:
    """Result of executing a complete story."""

    site_id: str
    site_name: str
    story_name: str
    story_description: str
    start_time: str
    end_time: str
    total_time_ms: int
    success: bool
    steps: list[StepResult]
    captured_data: dict[str, Any]
    verifications: list[dict[str, Any]] | None = None


def get_stories_dir() -> Path:
    """Get the path to the shared stories definitions directory."""
    # Navigate from tests/e2e/stories to shared/stories/definitions
    current = Path(__file__).parent
    return current.parent.parent.parent.parent.parent / "shared" / "stories" / "definitions"


def load_json_story(story_name: str) -> dict[str, Any]:
    """Load a JSON story definition by name.

    Args:
        story_name: Name of the story (without .json extension)

    Returns:
        Parsed JSON story definition

    Raises:
        FileNotFoundError: If story file doesn't exist
    """
    stories_dir = get_stories_dir()
    story_path = stories_dir / f"{story_name}.json"

    if not story_path.exists():
        raise FileNotFoundError(f"Story not found: {story_path}")

    with open(story_path, encoding="utf-8") as f:
        result: dict[str, Any] = json.load(f)
        return result


def load_all_json_stories() -> dict[str, dict[str, Any]]:
    """Load all JSON story definitions.

    Returns:
        Dictionary mapping story names to their definitions
    """
    stories_dir = get_stories_dir()
    stories: dict[str, dict[str, Any]] = {}

    if not stories_dir.exists():
        return stories

    for story_file in stories_dir.glob("*.json"):
        name = story_file.stem
        with open(story_file, encoding="utf-8") as f:
            stories[name] = json.load(f)

    return stories


def process_template(
    template: str,
    captured: dict[str, Any],
    params: dict[str, Any],
) -> str:
    """Process template string with variable substitution.

    Supports: {{captured.X}}, {{params.X}}, {{X|default:Y}}

    Args:
        template: Template string with placeholders
        captured: Values captured from previous steps
        params: Runtime parameters

    Returns:
        Processed string with substitutions applied
    """

    def replace_var(match: re.Match[str]) -> str:
        expr = match.group(1)

        # Handle default values: {{var|default:value}}
        parts = expr.split("|")
        var_path = parts[0].strip()
        default_value: str | None = None
        if len(parts) > 1 and parts[1].startswith("default:"):
            default_value = parts[1][len("default:") :]

        # Split path and get value
        path_parts = var_path.split(".")
        value: Any = None

        if path_parts[0] == "captured":
            value = get_nested_value(captured, path_parts[1:])
        elif path_parts[0] == "params":
            value = get_nested_value(params, path_parts[1:])
        else:
            # Try captured first, then params
            value = get_nested_value(captured, path_parts)
            if value is None:
                value = get_nested_value(params, path_parts)

        if value is None:
            return default_value if default_value is not None else ""

        return str(value) if isinstance(value, str) else json.dumps(value)

    return re.sub(r"\{\{([^}]+)\}\}", replace_var, template)


def get_nested_value(obj: dict[str, Any], parts: list[str]) -> Any:
    """Get nested value from dict using path parts.

    Args:
        obj: Dictionary to navigate
        parts: List of keys/indices to follow

    Returns:
        Value at path or None if not found
    """
    current: Any = obj

    for part in parts:
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                idx = int(part)
                current = current[idx] if 0 <= idx < len(current) else None
            except (ValueError, IndexError):
                return None
        else:
            return None

    return current


def get_value_by_path(obj: Any, json_path: str) -> Any:
    """Extract value from object using dot-notation path.

    Supports array indexing like 'data.0.invMastUid'

    Args:
        obj: Object to navigate
        json_path: Dot-separated path

    Returns:
        Value at path or None if not found
    """
    parts = json_path.split(".")
    current: Any = obj

    for part in parts:
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                idx = int(part)
                current = current[idx] if 0 <= idx < len(current) else None
            except (ValueError, IndexError):
                return None
        elif hasattr(current, part):
            current = getattr(current, part)
        elif hasattr(current, "__dict__"):
            current = current.__dict__.get(part)
        else:
            return None

    return current


def get_field_paths(obj: Any, prefix: str = "") -> list[str]:
    """Get all field paths from an object.

    Args:
        obj: Object to traverse
        prefix: Current path prefix

    Returns:
        List of dot-notation paths to all leaf values
    """
    paths: list[str] = []

    if obj is None:
        return paths

    if isinstance(obj, list):
        if obj:
            paths.extend(get_field_paths(obj[0], f"{prefix}[0]" if prefix else "[0]"))
    elif isinstance(obj, dict):
        for key, value in obj.items():
            new_prefix = f"{prefix}.{key}" if prefix else key
            if value is not None and isinstance(value, (dict, list)):
                paths.extend(get_field_paths(value, new_prefix))
            else:
                paths.append(new_prefix)
    elif hasattr(obj, "__dict__"):
        return get_field_paths(obj.__dict__, prefix)

    return paths


def navigate_to_method(
    api: AugurAPI,
    service: str,
    method: str,
    factory_args: list[Any] | None = None,
) -> tuple[Any, str]:
    """Navigate API object to find the target method.

    Args:
        api: AugurAPI instance
        service: Service name (snake_case)
        method: Method path (dot-separated)
        factory_args: Arguments for factory functions

    Returns:
        Tuple of (callable, method_name)

    Raises:
        AttributeError: If path doesn't exist
    """
    factory_args = factory_args or []

    # Get service
    target: Any = getattr(api, service, None)
    if target is None:
        raise AttributeError(f"Service '{service}' not found on API")

    # Navigate method path
    method_parts = method.split(".")
    factory_applied = False

    # Standard method names that may be implicit in Python
    # (e.g., TypeScript uses healthCheck.get() but Python uses health_check())
    implicit_methods = {"get", "list", "create", "update", "delete"}

    for i, part in enumerate(method_parts):
        # Try direct attribute access
        next_target = getattr(target, part, None)

        if next_target is not None:
            target = next_target
        elif callable(target) and part in implicit_methods:
            # If target is already callable and we're looking for get/list/etc,
            # the Python client may have this as a direct method without the suffix
            # Skip this part and use the current callable
            continue
        elif callable(target) and not factory_applied and factory_args:
            # Try applying factory
            result = target(*factory_args)
            next_after_factory = getattr(result, part, None)
            if next_after_factory is not None:
                target = next_after_factory
                factory_applied = True
            else:
                raise AttributeError(f"Cannot access '{part}' on {service}.{method}")
        else:
            raise AttributeError(f"Cannot access '{part}' on {service}.{method}")

        # Check if we need to apply factory for next part
        if callable(target) and not factory_applied and factory_args and i < len(method_parts) - 1:
            next_part = method_parts[i + 1]
            if getattr(target, next_part, None) is None:
                target = target(*factory_args)
                factory_applied = True

    return target, method_parts[-1]


def resolve_params(
    step: dict[str, Any],
    captured: dict[str, Any],
    runtime_params: dict[str, Any],
) -> Any:
    """Resolve parameters for a step.

    Args:
        step: Step definition
        captured: Captured values from previous steps
        runtime_params: Runtime parameters

    Returns:
        Resolved parameters
    """
    if "params_template" in step:
        processed = process_template(step["params_template"], captured, runtime_params)
        try:
            return json.loads(processed)
        except json.JSONDecodeError:
            # Try as number
            try:
                return float(processed) if "." in processed else int(processed)
            except ValueError:
                return processed

    return step.get("params", {})


def resolve_factory_args(
    step: dict[str, Any],
    captured: dict[str, Any],
    runtime_params: dict[str, Any],
) -> list[Any]:
    """Resolve factory arguments for a step.

    Args:
        step: Step definition
        captured: Captured values from previous steps
        runtime_params: Runtime parameters

    Returns:
        List of factory arguments
    """
    if "factory_args_template" not in step:
        return []

    processed = process_template(step["factory_args_template"], captured, runtime_params)
    try:
        result = json.loads(processed)
        return result if isinstance(result, list) else []
    except json.JSONDecodeError:
        return []


def execute_step(
    api: AugurAPI,
    step: dict[str, Any],
    captured: dict[str, Any],
    runtime_params: dict[str, Any],
) -> StepResult:
    """Execute a single step.

    Args:
        api: AugurAPI instance
        step: Step definition
        captured: Captured values from previous steps
        runtime_params: Runtime parameters

    Returns:
        StepResult with execution outcome
    """
    start_time = time.time()
    params = resolve_params(step, captured, runtime_params)
    factory_args = resolve_factory_args(step, captured, runtime_params)

    try:
        target, _ = navigate_to_method(api, step["service"], step["method"], factory_args)
    except Exception as e:
        return StepResult(
            step_id=step["id"],
            description=step["description"],
            service=step["service"],
            method=step["method"],
            params=params,
            success=False,
            response_time_ms=int((time.time() - start_time) * 1000),
            error=str(e),
        )

    if not callable(target):
        return StepResult(
            step_id=step["id"],
            description=step["description"],
            service=step["service"],
            method=step["method"],
            params=params,
            success=False,
            response_time_ms=int((time.time() - start_time) * 1000),
            error=f"{step['service']}.{step['method']} is not callable",
        )

    try:
        response = target(params) if params else target()
        response_time = int((time.time() - start_time) * 1000)

        # Capture values
        captured_values: dict[str, Any] = {}
        if "capture" in step:
            for var_name, json_path in step["capture"].items():
                # Try to get from response object or dict
                value = get_value_by_path(response, json_path)
                if value is not None:
                    captured_values[var_name] = value
                    captured[var_name] = value

        # Convert response to dict for serialization
        response_dict: Any = response
        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        elif hasattr(response, "__dict__"):
            response_dict = response.__dict__

        return StepResult(
            step_id=step["id"],
            description=step["description"],
            service=step["service"],
            method=step["method"],
            params=params,
            success=True,
            response_time_ms=response_time,
            response=response_dict,
            response_fields=get_field_paths(response_dict),
            captured=captured_values if captured_values else None,
        )

    except Exception as e:
        return StepResult(
            step_id=step["id"],
            description=step["description"],
            service=step["service"],
            method=step["method"],
            params=params,
            success=False,
            response_time_ms=int((time.time() - start_time) * 1000),
            error=str(e),
        )


def evaluate_expression(expression: str, captured: dict[str, Any]) -> bool:
    """Evaluate verification expression.

    Supports: !=, ==, >, <, >=, <=, is not None, is None, and, or

    Args:
        expression: Expression to evaluate
        captured: Captured values

    Returns:
        Boolean result of evaluation
    """
    # Create evaluation context with captured values
    context = {"captured": type("captured", (), captured)()}

    # Handle Python-style None checks
    expr = expression.replace("is not None", "is not None")
    expr = expr.replace("is None", "is None")

    try:
        # Replace captured.X with context access
        def replace_captured(match: re.Match[str]) -> str:
            var_name = match.group(1)
            return f"captured.{var_name}"

        expr = re.sub(r"captured\.(\w+)", replace_captured, expr)

        return bool(eval(expr, {"captured": context["captured"], "len": len}))  # noqa: S307
    except Exception:
        return False


def run_json_story(
    api: AugurAPI,
    site: SiteCredentials,
    story: dict[str, Any],
    runtime_params: dict[str, Any] | None = None,
) -> StoryResult:
    """Run a JSON story.

    Args:
        api: AugurAPI instance
        site: Site configuration
        story: Story definition
        runtime_params: Optional runtime parameters

    Returns:
        StoryResult with execution outcome
    """
    runtime_params = runtime_params or {}
    start_time = datetime.now(timezone.utc)
    captured: dict[str, Any] = {}
    steps: list[StepResult] = []
    overall_success = True

    print(f"\n📖 Running JSON story: {story['name']}")
    print(f"🏢 Site: {site.name} ({site.site_id})")
    print(f"📝 {story['description']}\n")

    for step in story["steps"]:
        print(f"  ⏳ {step['description']}...", end="", flush=True)

        result = execute_step(api, step, captured, runtime_params)
        steps.append(result)

        if result.success:
            print(f" ✅ ({result.response_time_ms}ms)")
            if result.captured:
                for key, value in result.captured.items():
                    print(f"     📦 Captured {key}: {json.dumps(value)}")
        else:
            print(f" ❌ {result.error}")
            if not step.get("optional", False):
                overall_success = False
                print("     ⚠️  Stopping story due to required step failure")
                break

    # Run verifications
    verifications: list[dict[str, Any]] = []
    if "verify" in story and overall_success:
        print("\n🔍 Running verifications...")
        for verification in story["verify"]:
            print(f"  ⏳ {verification['description']}...", end="", flush=True)
            passed = evaluate_expression(verification["expression"], captured)
            verifications.append({"description": verification["description"], "passed": passed})
            if passed:
                print(" ✅")
            else:
                print(" ❌")
                overall_success = False

    end_time = datetime.now(timezone.utc)

    return StoryResult(
        site_id=site.site_id,
        site_name=site.name,
        story_name=story["name"],
        story_description=story["description"],
        start_time=start_time.isoformat(),
        end_time=end_time.isoformat(),
        total_time_ms=int((end_time - start_time).total_seconds() * 1000),
        success=overall_success,
        steps=steps,
        captured_data=captured,
        verifications=verifications if verifications else None,
    )


def list_available_stories() -> list[str]:
    """List all available story names.

    Returns:
        List of story names (without .json extension)
    """
    stories_dir = get_stories_dir()
    if not stories_dir.exists():
        return []

    return [f.stem for f in stories_dir.glob("*.json")]
