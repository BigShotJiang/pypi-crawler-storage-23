"""Tests for the Joomla service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.joomla.schemas import (
    Category,
    CategoryCreateParams,
    CategoryListParams,
    Content,
    ContentCreateParams,
    ContentListParams,
    ContentUpdateParams,
    Extension,
    ExtensionListParams,
    HealthCheckData,
    Menu,
    MenuListParams,
    Tag,
    TagListParams,
    User,
    UserCreateParams,
    UserDocParams,
    Usergroup,
    UserGroupCreateParams,
    UsergroupsListParams,
    UserListParams,
    UserUpdateParams,
)


class TestJoomlaSchemas:
    """Tests for Joomla schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_user_list_params(self) -> None:
        """Should create user list params."""
        params = UserListParams(limit=10, offset=5, q="john")
        assert params.limit == 10
        assert params.q == "john"

    def test_user_model(self) -> None:
        """Should parse user data."""
        data = {"id": 1, "name": "John Doe", "username": "johnd", "email": "john@test.com"}
        result = User.model_validate(data)
        assert result.id == 1
        assert result.name == "John Doe"

    def test_user_create_params(self) -> None:
        """Should create user create params."""
        params = UserCreateParams(name="John", username="johnd", email="john@test.com")
        assert params.name == "John"
        assert params.username == "johnd"

    def test_user_update_params(self) -> None:
        """Should create user update params."""
        params = UserUpdateParams(name="John Updated", block=0)
        assert params.name == "John Updated"

    def test_content_list_params(self) -> None:
        """Should create content list params."""
        params = ContentListParams(limit=10, q="search", category_id_list="1,2,3")
        assert params.q == "search"
        assert params.category_id_list == "1,2,3"

    def test_content_model(self) -> None:
        """Should parse content data."""
        data = {"id": 1, "title": "Test Article", "alias": "test-article", "state": 1}
        result = Content.model_validate(data)
        assert result.id == 1
        assert result.title == "Test Article"

    def test_content_create_params(self) -> None:
        """Should create content create params."""
        params = ContentCreateParams(title="Test", catid=1, introtext="Intro")
        assert params.title == "Test"
        assert params.catid == 1

    def test_content_update_params(self) -> None:
        """Should create content update params."""
        params = ContentUpdateParams(title="Updated", state=0)
        assert params.title == "Updated"

    def test_category_list_params(self) -> None:
        """Should create category list params."""
        params = CategoryListParams(limit=10, extension="com_content")
        assert params.extension == "com_content"

    def test_category_model(self) -> None:
        """Should parse category data."""
        data = {"id": 1, "title": "Test Category", "alias": "test-cat", "published": 1}
        result = Category.model_validate(data)
        assert result.id == 1
        assert result.title == "Test Category"

    def test_category_create_params(self) -> None:
        """Should create category create params."""
        params = CategoryCreateParams(title="New Category", parent_id=1)
        assert params.title == "New Category"

    def test_extension_list_params(self) -> None:
        """Should create extension list params."""
        params = ExtensionListParams(limit=10, type="component")
        assert params.type == "component"

    def test_extension_model(self) -> None:
        """Should parse extension data."""
        data = {"extensionId": 1, "name": "Test Extension", "type": "component", "enabled": 1}
        result = Extension.model_validate(data)
        assert result.extension_id == 1
        assert result.type == "component"

    def test_tag_list_params(self) -> None:
        """Should create tag list params."""
        params = TagListParams(limit=10)
        assert params.limit == 10

    def test_tag_model(self) -> None:
        """Should parse tag data."""
        data = {"id": 1, "title": "Test Tag", "alias": "test-tag", "published": 1}
        result = Tag.model_validate(data)
        assert result.id == 1

    def test_menu_list_params(self) -> None:
        """Should create menu list params."""
        params = MenuListParams(limit=10, menutype="mainmenu")
        assert params.menutype == "mainmenu"

    def test_menu_model(self) -> None:
        """Should parse menu data."""
        data = {"id": 1, "title": "Home", "link": "index.php", "menutype": "mainmenu"}
        result = Menu.model_validate(data)
        assert result.id == 1
        assert result.title == "Home"

    def test_user_doc_params(self) -> None:
        """Should create user doc params."""
        params = UserDocParams(include_ship_to="true")
        assert params.include_ship_to == "true"

    def test_usergroups_list_params(self) -> None:
        """Should create usergroups list params."""
        params = UsergroupsListParams(order_by="title", parent_id_list="1,2,3")
        assert params.order_by == "title"
        assert params.parent_id_list == "1,2,3"

    def test_usergroup_model(self) -> None:
        """Should parse usergroup data."""
        data = {"id": 1, "parentId": 0, "title": "Administrators"}
        result = Usergroup.model_validate(data)
        assert result.id == 1
        assert result.parent_id == 0
        assert result.title == "Administrators"

    def test_user_list_params_all_fields(self) -> None:
        """Should create user list params with all fields."""
        params = UserListParams(
            limit=10,
            offset=5,
            order_by="name",
            q="john",
            access_level_list="1,2",
            customer_id=123,
        )
        assert params.access_level_list == "1,2"
        assert params.customer_id == 123

    def test_content_list_params_all_fields(self) -> None:
        """Should create content list params with all fields."""
        params = ContentListParams(
            limit=10,
            offset=5,
            order_by="title",
            q="search",
            category_id_list="1,2,3",
            tags_list="4,5,6",
        )
        assert params.q == "search"
        assert params.category_id_list == "1,2,3"
        assert params.tags_list == "4,5,6"

    def test_tag_list_params_all_fields(self) -> None:
        """Should create tag list params with all fields."""
        params = TagListParams(
            limit=10,
            offset=5,
            q="tag",
            cat_id=1,
            parent_id=2,
        )
        assert params.q == "tag"
        assert params.cat_id == 1
        assert params.parent_id == 2


class TestJoomlaClient:
    """Tests for JoomlaClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.joomla.health_check()
        assert response.data.site_id == "test-site"

    def test_users_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list users."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "name": "John", "username": "johnd"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users",
            json=mock_response,
        )
        response = api.joomla.users.list()
        assert len(response.data) == 1

    def test_users_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get user by ID."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1",
            json=mock_response,
        )
        response = api.joomla.users.get(1)
        assert response.data.id == 1

    def test_users_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create user."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users",
            json=mock_response,
            method="POST",
        )
        response = api.joomla.users.create(
            UserCreateParams(name="John", username="johnd", email="john@test.com")
        )
        assert response.data.id == 1

    def test_users_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update user."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1",
            json=mock_response,
            method="PUT",
        )
        response = api.joomla.users.update(1, UserUpdateParams(name="John Updated"))
        assert response.data.name == "John Updated"

    def test_users_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete user."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.joomla.users.delete(1)
        assert response.data is True

    def test_content_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list content."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "title": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/content",
            json=mock_response,
        )
        response = api.joomla.content.list()
        assert len(response.data) == 1

    def test_content_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get content by ID."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/content/1",
            json=mock_response,
        )
        response = api.joomla.content.get(1)
        assert response.data.id == 1

    def test_content_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create content."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "New Article"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/content",
            json=mock_response,
            method="POST",
        )
        response = api.joomla.content.create(ContentCreateParams(title="New Article", catid=1))
        assert response.data.title == "New Article"

    def test_content_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update content."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/content/1",
            json=mock_response,
            method="PUT",
        )
        response = api.joomla.content.update(1, ContentUpdateParams(title="Updated"))
        assert response.data.title == "Updated"

    def test_content_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete content."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/content/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.joomla.content.delete(1)
        assert response.data is True

    def test_categories_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list categories."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "title": "Test Category"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/categories",
            json=mock_response,
        )
        response = api.joomla.categories.list()
        assert len(response.data) == 1

    def test_categories_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get category by ID."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "Test Category"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/categories/1",
            json=mock_response,
        )
        response = api.joomla.categories.get(1)
        assert response.data.id == 1

    def test_categories_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create category."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "New Category"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/categories",
            json=mock_response,
            method="POST",
        )
        response = api.joomla.categories.create(CategoryCreateParams(title="New Category"))
        assert response.data.title == "New Category"

    def test_extensions_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list extensions."""
        mock_response = {
            "count": 1,
            "data": [{"extensionId": 1, "name": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/extensions",
            json=mock_response,
        )
        response = api.joomla.extensions.list()
        assert len(response.data) == 1

    def test_extensions_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get extension by ID."""
        mock_response = {
            "count": 1,
            "data": {"extensionId": 1, "name": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/extensions/1",
            json=mock_response,
        )
        response = api.joomla.extensions.get(1)
        assert response.data.extension_id == 1

    def test_tags_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list tags."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "title": "Test Tag"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/tags",
            json=mock_response,
        )
        response = api.joomla.tags.list()
        assert len(response.data) == 1

    def test_tags_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get tag by ID."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "Test Tag"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/tags/1",
            json=mock_response,
        )
        response = api.joomla.tags.get(1)
        assert response.data.id == 1

    def test_menu_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list menu items."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "title": "Home"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/menu",
            json=mock_response,
        )
        response = api.joomla.menu.list()
        assert len(response.data) == 1

    def test_menu_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get menu item by ID."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "title": "Home"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/menu/1",
            json=mock_response,
        )
        response = api.joomla.menu.get(1)
        assert response.data.id == 1

    def test_users_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get user document."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John", "username": "johnd"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/doc",
            json=mock_response,
        )
        response = api.joomla.users.get_doc(1)
        assert response.data.id == 1

    def test_users_get_doc_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get user document with params."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John", "username": "johnd"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/doc?include_ship_to=true",
            json=mock_response,
        )
        response = api.joomla.users.get_doc(1, UserDocParams(include_ship_to="true"))
        assert response.data.id == 1

    def test_usergroups_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list usergroups."""
        mock_response = {
            "count": 1,
            "data": [{"id": 1, "title": "Administrators"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/usergroups",
            json=mock_response,
        )
        response = api.joomla.usergroups.list()
        assert len(response.data) == 1
        assert response.data[0].title == "Administrators"

    def test_users_verify_password(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should verify user password."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "isVerified": True, "username": "johnd"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/verify-password",
            json=mock_response,
            method="POST",
        )
        response = api.joomla.users.verify_password(
            {"username": "johnd", "password": "test-password"}
        )
        assert response.data.is_verified is True

    def test_users_get_trinity(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get Trinity user document."""
        mock_response = {
            "count": 1,
            "data": {"id": 1, "name": "John Doe", "username": "johnd"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/trinity",
            json=mock_response,
        )
        response = api.joomla.users.get_trinity(1)
        assert response.data.id == 1

    def test_users_list_groups(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list user groups."""
        mock_response = {
            "count": 1,
            "data": [{"userId": 1, "groupId": 2, "groupTitle": "Admins"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/groups",
            json=mock_response,
        )
        response = api.joomla.users.list_groups(1)
        assert len(response.data) == 1

    def test_users_create_group(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create user group mapping."""
        mock_response = {
            "count": 1,
            "data": {"userId": 1, "groupId": 3, "groupTitle": "Editors"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/groups",
            json=mock_response,
            method="POST",
        )
        response = api.joomla.users.create_group(1, UserGroupCreateParams(group_id=3))
        assert response.data.group_id == 3

    def test_users_get_group(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get user group."""
        mock_response = {
            "count": 1,
            "data": {"userId": 1, "groupId": 2, "groupTitle": "Admins"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://joomla.augur-api.com/users/1/groups/2",
            json=mock_response,
        )
        response = api.joomla.users.get_group(1, 2)
        assert response.data.group_id == 2

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.joomla
        assert client.users is client.users
        assert client.content is client.content
        assert client.categories is client.categories
        assert client.extensions is client.extensions
        assert client.tags is client.tags
        assert client.menu is client.menu
        assert client.usergroups is client.usergroups
