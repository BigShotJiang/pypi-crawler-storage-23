"""Tests for the AGR Info service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.agr_info import (
    AkashaGenerateParams,
    AkashaGenerateResponse,
    JoomlaGenerateParams,
    JoomlaGenerateResponse,
    Microservice,
    MicroserviceCreateParams,
    MicroservicesListParams,
    MicroserviceUpdateParams,
    OllamaTag,
    Rubric,
    RubricCreateParams,
    RubricsListParams,
    RubricUpdateParams,
)
from augur_api.services.agr_info.schemas import ContextGetParams, ContextResponse, HealthCheckData


class TestAgrInfoSchemas:
    """Tests for AGR Info schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_microservices_list_params(self) -> None:
        """Should create microservices list params."""
        params = MicroservicesListParams(limit=10, offset=5, status_cd=1)
        assert params.limit == 10
        assert params.offset == 5
        assert params.status_cd == 1

    def test_microservices_list_params_defaults(self) -> None:
        """Should have None defaults."""
        params = MicroservicesListParams()
        assert params.limit is None
        assert params.offset is None
        assert params.status_cd is None

    def test_microservice_model(self) -> None:
        """Should parse microservice data."""
        data = {
            "microservicesUid": 1,
            "name": "Test Service",
            "statusCd": 1,
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-02T00:00:00Z",
        }
        result = Microservice.model_validate(data)
        assert result.microservices_uid == 1
        assert result.name == "Test Service"
        assert result.status_cd == 1

    def test_microservice_create_params(self) -> None:
        """Should create microservice create params."""
        params = MicroserviceCreateParams(name="Test", status_cd=1)
        assert params.name == "Test"
        assert params.status_cd == 1

    def test_microservice_update_params(self) -> None:
        """Should create microservice update params."""
        params = MicroserviceUpdateParams(name="Updated", status_cd=2)
        assert params.name == "Updated"
        assert params.status_cd == 2

    def test_rubrics_list_params(self) -> None:
        """Should create rubrics list params."""
        params = RubricsListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_rubric_model(self) -> None:
        """Should parse rubric data."""
        data = {
            "rubricsUid": 1,
            "name": "Test Rubric",
            "description": "A test rubric",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-02T00:00:00Z",
        }
        result = Rubric.model_validate(data)
        assert result.rubrics_uid == 1
        assert result.name == "Test Rubric"
        assert result.description == "A test rubric"

    def test_rubric_create_params(self) -> None:
        """Should create rubric create params."""
        params = RubricCreateParams(name="Test", description="Description")
        assert params.name == "Test"
        assert params.description == "Description"

    def test_rubric_update_params(self) -> None:
        """Should create rubric update params."""
        params = RubricUpdateParams(name="Updated", description="New description")
        assert params.name == "Updated"
        assert params.description == "New description"

    def test_akasha_generate_params(self) -> None:
        """Should create akasha generate params."""
        params = AkashaGenerateParams(prompt="Generate something")
        assert params.prompt == "Generate something"

    def test_akasha_generate_response(self) -> None:
        """Should parse akasha generate response."""
        data = {"result": "Generated content"}
        result = AkashaGenerateResponse.model_validate(data)
        assert result.result == "Generated content"

    def test_joomla_generate_params(self) -> None:
        """Should create joomla generate params."""
        params = JoomlaGenerateParams(prompt="Generate content")
        assert params.prompt == "Generate content"

    def test_joomla_generate_response(self) -> None:
        """Should parse joomla generate response."""
        data = {"result": "Generated content"}
        result = JoomlaGenerateResponse.model_validate(data)
        assert result.result == "Generated content"

    def test_ollama_tag_model(self) -> None:
        """Should parse ollama tag data."""
        data = {
            "name": "llama2",
            "model": "llama2:latest",
            "modifiedAt": "2024-01-01T00:00:00Z",
            "size": 1000000,
        }
        result = OllamaTag.model_validate(data)
        assert result.name == "llama2"
        assert result.model == "llama2:latest"
        assert result.size == 1000000

    def test_context_get_params(self) -> None:
        """Should create context get params with edge_cache."""
        params = ContextGetParams(edge_cache="5m")
        assert params.edge_cache == "5m"

    def test_context_get_params_defaults(self) -> None:
        """Should have None defaults."""
        params = ContextGetParams()
        assert params.edge_cache is None

    def test_context_response(self) -> None:
        """Should parse context response."""
        result = ContextResponse.model_validate({})
        assert result is not None


class TestAgrInfoClient:
    """Tests for AgrInfoClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.agr_info.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.agr_info.ping()
        assert response.data == "pong"

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        mock_response = {
            "count": 1,
            "data": {"user_id": "test-user", "email": "test@example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/whoami",
            json=mock_response,
        )
        response = api.agr_info.whoami()
        assert response.data["user_id"] == "test-user"

    def test_microservices_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list microservices."""
        mock_response = {
            "count": 1,
            "data": [{"microservicesUid": 1, "name": "Test Service"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices",
            json=mock_response,
        )
        response = api.agr_info.microservices.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Test Service"

    def test_microservices_list_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list microservices with params."""
        mock_response = {
            "count": 1,
            "data": [{"microservicesUid": 1, "name": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices?limit=10",
            json=mock_response,
        )
        params = MicroservicesListParams(limit=10)
        response = api.agr_info.microservices.list(params)
        assert len(response.data) == 1

    def test_microservices_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get microservice by UID."""
        mock_response = {
            "count": 1,
            "data": {"microservicesUid": 1, "name": "Test Service"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices/1",
            json=mock_response,
        )
        response = api.agr_info.microservices.get(1)
        assert response.data.microservices_uid == 1

    def test_microservices_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create microservice."""
        mock_response = {
            "count": 1,
            "data": {"microservicesUid": 1, "name": "New Service"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices",
            json=mock_response,
            method="POST",
        )
        data = MicroserviceCreateParams(name="New Service", status_cd=1)
        response = api.agr_info.microservices.create(data)
        assert response.data.name == "New Service"

    def test_microservices_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update microservice."""
        mock_response = {
            "count": 1,
            "data": {"microservicesUid": 1, "name": "Updated Service"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices/1",
            json=mock_response,
            method="PUT",
        )
        data = MicroserviceUpdateParams(name="Updated Service")
        response = api.agr_info.microservices.update(1, data)
        assert response.data.name == "Updated Service"

    def test_microservices_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete microservice."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/microservices/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_info.microservices.delete(1)
        assert response.data is True

    def test_rubrics_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list rubrics."""
        mock_response = {
            "count": 1,
            "data": [{"rubricsUid": 1, "name": "Test Rubric"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/rubrics",
            json=mock_response,
        )
        response = api.agr_info.rubrics.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Test Rubric"

    def test_rubrics_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get rubric by UID."""
        mock_response = {
            "count": 1,
            "data": {"rubricsUid": 1, "name": "Test Rubric"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/rubrics/1",
            json=mock_response,
        )
        response = api.agr_info.rubrics.get(1)
        assert response.data.rubrics_uid == 1

    def test_rubrics_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create rubric."""
        mock_response = {
            "count": 1,
            "data": {"rubricsUid": 1, "name": "New Rubric"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/rubrics",
            json=mock_response,
            method="POST",
        )
        data = RubricCreateParams(name="New Rubric", description="Test description")
        response = api.agr_info.rubrics.create(data)
        assert response.data.name == "New Rubric"

    def test_rubrics_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update rubric."""
        mock_response = {
            "count": 1,
            "data": {"rubricsUid": 1, "name": "Updated Rubric"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/rubrics/1",
            json=mock_response,
            method="PUT",
        )
        data = RubricUpdateParams(name="Updated Rubric")
        response = api.agr_info.rubrics.update(1, data)
        assert response.data.name == "Updated Rubric"

    def test_rubrics_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete rubric."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/rubrics/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_info.rubrics.delete(1)
        assert response.data is True

    def test_akasha_generate(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should generate content with Akasha."""
        mock_response = {
            "count": 1,
            "data": {"result": "Generated content"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/akasha/generate",
            json=mock_response,
            method="POST",
        )
        params = AkashaGenerateParams(prompt="Generate something")
        response = api.agr_info.akasha.generate(params)
        assert response.data.result == "Generated content"

    def test_joomla_generate(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should generate content with Joomla."""
        mock_response = {
            "count": 1,
            "data": {"result": "Generated content"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/joomla/generate",
            json=mock_response,
            method="POST",
        )
        params = JoomlaGenerateParams(prompt="Generate content")
        response = api.agr_info.joomla.generate(params)
        assert response.data.result == "Generated content"

    def test_ollama_list_tags(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list Ollama tags."""
        mock_response = {
            "count": 1,
            "data": [{"name": "llama2", "model": "llama2:latest", "size": 1000000}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/ollama/tags",
            json=mock_response,
        )
        response = api.agr_info.ollama.list_tags()
        assert len(response.data) == 1
        assert response.data[0].name == "llama2"

    def test_context_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get context for a site."""
        mock_response = {
            "count": 1,
            "data": {"key": "value"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/context/target-site",
            json=mock_response,
        )
        response = api.agr_info.context.get("target-site")
        assert response.data is not None

    def test_context_get_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get context with edge cache params."""
        mock_response = {
            "count": 1,
            "data": {"key": "value"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-info.augur-api.com/context/target-site?cacheSiteId5m=test-site",
            json=mock_response,
        )
        params = ContextGetParams(edge_cache="5m")
        response = api.agr_info.context.get("target-site", params)
        assert response.data is not None

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.agr_info
        assert client.context is client.context
        assert client.microservices is client.microservices
        assert client.rubrics is client.rubrics
        assert client.akasha is client.akasha
        assert client.joomla is client.joomla
        assert client.ollama is client.ollama
