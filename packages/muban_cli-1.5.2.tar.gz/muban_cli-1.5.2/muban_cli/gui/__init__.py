"""
Muban CLI GUI module.

This module provides a graphical user interface for muban-cli.
Requires PyQt6: pip install muban-cli[gui]
"""

__all__ = ["main"]
