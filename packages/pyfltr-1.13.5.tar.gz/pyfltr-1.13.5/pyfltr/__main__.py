#!/usr/bin/env python3
"""pyfltr entry point."""

if __name__ == "__main__":
    import pyfltr.main

    pyfltr.main.main()
