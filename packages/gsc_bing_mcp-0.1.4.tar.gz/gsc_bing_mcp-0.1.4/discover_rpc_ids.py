#!/usr/bin/env python3
"""
discover_rpc_ids.py — Intercept live GSC batchexecute requests via Playwright.

Injects real Chrome cookies into a headless Chromium session, navigates to
Google Search Console performance page, and captures all batchexecute RPC
call IDs + their request/response payloads.

Results are saved to discovered_rpcs.json
"""

import atexit
import json
import re
import sys
import time
import urllib.parse
from pathlib import Path

try:
    import rookiepy
except ImportError:
    sys.exit("rookiepy not installed. Run: pip install rookiepy")

try:
    from playwright.sync_api import sync_playwright, Route, Request
except ImportError:
    sys.exit("playwright not installed. Run: pip install playwright && python3 -m playwright install chromium")


GSC_URL = "https://search.google.com/search-console/performance/search-analytics"
BE_PATTERN = "**/batchexecute**"

discovered = {}  # rpc_id -> {args, response}


def get_cookies():
    """Try multiple browsers/profiles to get google.com cookies."""
    browsers = [
        ("chrome", rookiepy.chrome),
        ("brave", rookiepy.brave),
        ("edge", rookiepy.edge),
    ]
    for name, fn in browsers:
        try:
            cookies = fn(["google.com"])
            if cookies:
                print(f"[cookies] Got {len(cookies)} cookies from {name}")
                return cookies
        except Exception as e:
            print(f"[cookies] {name} failed: {e}")
    sys.exit("[cookies] No browser cookies found. Make sure Chrome/Brave/Edge is installed and you're logged into Google.")


# rookiepy same_site int → Playwright string mapping
# Chrome: -1=UNSPECIFIED, 0=NO_RESTRICTION(None), 1=LAX_MODE, 2=STRICT_MODE
_SAME_SITE_MAP = {"-1": "None", "0": "None", "1": "Lax", "2": "Strict",
                   -1: "None",   0: "None",   1: "Lax",   2: "Strict"}


def cookies_to_playwright(raw_cookies):
    """Convert rookiepy cookies to Playwright format.

    rookiepy field names: domain, path, secure, http_only, same_site, expires, name, value
    Playwright required: name, value, domain (starts with '.') or url, path,
                         httpOnly, secure, sameSite ('Strict'|'Lax'|'None'), expires (int epoch)
    """
    pw_cookies = []
    for c in raw_cookies:
        name = c.get("name", "")
        value = c.get("value", "")
        if not name or value is None:
            continue
        value = str(value)

        domain = c.get("domain", "") or ".google.com"

        # Only keep cookies relevant to google.com (not google.com.bd etc.)
        domain_clean = domain.lstrip(".")
        if not (domain_clean == "google.com" or domain_clean.endswith(".google.com")):
            continue

        # Playwright requires domain to start with '.'
        if not domain.startswith("."):
            domain = f".{domain}"

        path = c.get("path", "/") or "/"

        # same_site: rookiepy returns int or string int
        ss_raw = c.get("same_site", -1)
        same_site = _SAME_SITE_MAP.get(ss_raw, _SAME_SITE_MAP.get(str(ss_raw), "None"))

        # expires: rookiepy returns string epoch seconds
        expires_raw = c.get("expires")
        cookie = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
            "httpOnly": bool(c.get("http_only", False)),
            "secure": bool(c.get("secure", False)),
            "sameSite": same_site,
        }
        try:
            exp = int(expires_raw)
            if exp > 0:
                cookie["expires"] = exp
        except (TypeError, ValueError):
            pass

        pw_cookies.append(cookie)
    return pw_cookies


def parse_freq(body: str):
    """Parse f.req POST body → list of [rpc_id, args_json, ...] tuples."""
    try:
        decoded = urllib.parse.unquote_plus(body)
        # f.req=[[["rpcId","argsJson",null,"1"],...]]
        match = re.search(r'f\.req=(\[.*)', decoded)
        if not match:
            return []
        freq_str = match.group(1)
        # Strip trailing query params if any
        # f.req is the whole value; find balanced brackets
        depth = 0
        end = 0
        for i, ch in enumerate(freq_str):
            if ch == '[':
                depth += 1
            elif ch == ']':
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        freq_str = freq_str[:end]
        outer = json.loads(freq_str)
        # outer is [[["rpcId","args",null,"seq"],...],...]
        # Typically: [[ ["id","args",null,"1"], ["id2","args",null,"2"] ]]
        results = []
        for batch in outer:
            if isinstance(batch, list):
                for item in batch:
                    if isinstance(item, list) and len(item) >= 2:
                        rpc_id = item[0]
                        args = item[1]
                        results.append((rpc_id, args))
        return results
    except Exception as e:
        print(f"  [parse_freq] error: {e}")
        return []


def main():
    print("[*] Getting Chrome cookies...")
    raw_cookies = get_cookies()
    pw_cookies = cookies_to_playwright(raw_cookies)
    print(f"[*] Converted {len(pw_cookies)} cookies for Playwright")

    output_path = Path("discovered_rpcs.json")

    with sync_playwright() as p:
        print("[*] Launching Chromium (headful so GSC SPA loads properly)...")
        browser = p.chromium.launch(
            headless=False,  # headful = JS lazy modules load properly
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
            ]
        )
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/121.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 900},
        )

        # Inject cookies — try batch first, fall back to one-by-one
        print(f"[*] Injecting {len(pw_cookies)} cookies...")
        try:
            context.add_cookies(pw_cookies)
            print(f"[*] All {len(pw_cookies)} cookies injected successfully")
        except Exception as batch_err:
            print(f"[!] Batch cookie injection failed ({batch_err}), trying one-by-one...")
            ok = 0
            for cookie in pw_cookies:
                try:
                    context.add_cookies([cookie])
                    ok += 1
                except Exception as e:
                    print(f"  [skip] {cookie.get('name','?')} @ {cookie.get('domain','?')}: {e}")
            print(f"[*] Injected {ok}/{len(pw_cookies)} cookies individually")

        page = context.new_page()

        # Intercept batchexecute POST requests
        intercepted_count = [0]

        def handle_route(route: Route, request: Request):
            if "batchexecute" in request.url:
                body = ""
                try:
                    body = request.post_data or ""
                except Exception:
                    pass

                rpcs = parse_freq(body)
                if rpcs:
                    for rpc_id, args in rpcs:
                        if rpc_id not in discovered:
                            print(f"  [RPC] NEW: {rpc_id!r}  args_preview={str(args)[:120]}")
                            discovered[rpc_id] = {"args_example": args, "response": None}
                        else:
                            print(f"  [RPC] seen: {rpc_id!r}")
                    intercepted_count[0] += 1
                else:
                    # Still print the raw body for analysis
                    print(f"  [batchexecute] no f.req parsed — body[:200]: {body[:200]}")

            route.continue_()

        page.route(BE_PATTERN, handle_route)

        # Also capture responses for discovered RPCs
        def on_response(response):
            if "batchexecute" not in response.url:
                return
            try:
                body = response.text()
                # Strip anti-XSSI prefix
                body = re.sub(r"^\)\]\}'\n", "", body)
                # Try to correlate with the last known RPCs
                # Each envelope response looks like: [[["rpcId","dataJson",null,null],...]]
                outer = json.loads(body)
                for batch in outer:
                    if isinstance(batch, list):
                        for item in batch:
                            if isinstance(item, list) and len(item) >= 2:
                                rpc_id = item[0]
                                data = item[1]
                                if rpc_id in discovered:
                                    discovered[rpc_id]["response"] = data
                                    print(f"  [RESP] {rpc_id!r} → {str(data)[:120]}")
            except Exception:
                pass

        page.on("response", on_response)

        # Register atexit to always save even if we crash
        def save_results():
            if discovered:
                output_path.write_text(json.dumps(discovered, indent=2, ensure_ascii=False))
                print(f"\n[atexit] Saved {len(discovered)} RPCs to {output_path.absolute()}")
        atexit.register(save_results)

        print(f"\n[*] Navigating to GSC: {GSC_URL}")
        print("[*] Waiting 90 seconds for GSC SPA to fully load (data RPCs fire ~60s in)...")
        print("[*] (You can interact with the page to trigger more requests)\n")

        try:
            page.goto(GSC_URL, timeout=90000, wait_until="domcontentloaded")
        except Exception as e:
            print(f"[!] Navigation error (non-fatal): {e}")

        # Phase 1: wait 90s for page to fully render and fire data RPCs
        for i in range(90):
            time.sleep(1)
            if i % 10 == 9:
                print(f"  [{i+1}s] discovered RPCs: {list(discovered.keys())}")

        # Phase 2: try clicking around to trigger more RPC variants
        print("\n[*] Phase 2: Clicking to trigger more RPCs (Pages, Countries, Devices tabs)...")
        try:
            # Try clicking "Pages" tab if visible
            pages_tab = page.get_by_text("Pages", exact=True).first
            if pages_tab:
                pages_tab.click()
                time.sleep(5)
                print(f"  [click] Pages tab — RPCs: {list(discovered.keys())}")
        except Exception:
            pass
        try:
            # Try clicking "Countries" tab
            countries_tab = page.get_by_text("Countries", exact=True).first
            if countries_tab:
                countries_tab.click()
                time.sleep(5)
                print(f"  [click] Countries tab — RPCs: {list(discovered.keys())}")
        except Exception:
            pass
        try:
            # Try clicking "Devices" tab
            devices_tab = page.get_by_text("Devices", exact=True).first
            if devices_tab:
                devices_tab.click()
                time.sleep(5)
        except Exception:
            pass

        # Phase 3: wait another 20 seconds
        for i in range(20):
            time.sleep(1)
            if i % 5 == 4:
                print(f"  [+{i+1}s] discovered RPCs: {list(discovered.keys())}")

        print(f"\n[*] Done. Discovered {len(discovered)} unique RPC IDs:")
        for rid, info in discovered.items():
            print(f"  - {rid!r}")
            print(f"      args:  {str(info['args_example'])[:200]}")
            print(f"      resp:  {str(info['response'])[:200]}")

        # Save results (also saved by atexit handler as fallback)
        output_path.write_text(json.dumps(discovered, indent=2, ensure_ascii=False))
        print(f"\n[*] Saved to {output_path.absolute()}")

        browser.close()


if __name__ == "__main__":
    main()
