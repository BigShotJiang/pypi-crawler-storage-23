# Active Context

## Current Work Focus
v0.1.2 published to PyPI. GSC batchexecute integration fully working.

## Session Summary (2026-02-18 — Session 2)

### Major Rewrite: GSC Client
Completely rewrote `gsc_bing_mcp/clients/gsc_client.py` to use Google's internal
`batchexecute` RPC protocol instead of the defunct public Search Console API.

**Key discovery:** Used Playwright to intercept live GSC dashboard network traffic,
capturing actual RPC IDs, request formats, and response structures.

### What Changed
- `gsc_client.py` — Full rewrite using batchexecute RPCs (no OAuth, no GCP)
- `extractors/sapisidhash.py` — Fixed origin (`search.google.com`) and headers
- `extractors/chrome_cookies.py` — Added multi-browser support + `get_all_cookies_header()`
- `server.py` — New tools: `gsc_performance_trend`, `gsc_site_summary`, updated analytics tools
- `pyproject.toml` — Bumped to 0.1.2

### Verified Working ✅
- OLiH4d RPC: returns 17 days of real daily data (clicks, impressions, CTR, position)
- gydQ5d RPC: site summary / coverage counts
- XSRF token extraction: auto-fetched from 400 error response
- Cookie injection: all Google cookies sent correctly
- batchexecute response parsing: chunked streaming + wrb.fr envelope

## Key Technical Discoveries

### batchexecute Endpoint
```
https://search.google.com/_/SearchConsoleAggReportUi/data/batchexecute
POST f.req=[[["rpcId","argsJsonString",null,"1"]]]&at=XSRF_TOKEN
```

### Response Format (chunked streaming — NOT standard JSON)
```
DECIMAL_BYTECOUNT\n
[["wrb.fr", "RPC_ID", "data_json_str", null, null, null, "seq"]]\n
DECIMAL_BYTECOUNT\n
...
```

### RPC IDs Discovered
| RPC ID | Purpose | Status |
|--------|---------|--------|
| `OLiH4d` | Date time series (17 days) | ✅ Working |
| `gydQ5d` | Site summary / coverage | ✅ Working |
| `nDAfwb` | Dimension breakdown (query/page/country/device) | ✅ Structural |
| `czrWJf` | Coverage stats | ✅ Structural |
| `SM7Bqb` | List sites (returns [] — browser localStorage dependent) | ⚠️ Partial |
| `pPDvCb` | Init RPC | Used as fallback |
| `oGVhvf` | Init RPC | Used as fallback |
| `B2IOAd` | Stats panel | Available |
| `mKtLlc` | Property summary | Available |

### OLiH4d Args (date time series)
```python
["site_url", 27, null, null, null,
 [[1], null, [[null,null,null,3]], [[6,["WEB"]]], null,null,null,null,null,null, 1, null, null, 2],
 null, null, [null, 2]]
# dim=[1] is ALWAYS used for date (not DIMENSIONS["date"]=[8])
```

### nDAfwb Args (dimension breakdown)
```python
["site_url", 32, null, null, null,
 [[dim_code], null, [[null,null,null,3]], [[6,["WEB"]]], null,null,null,null,null,null, 1, null, null, 2]]
# NO trailing [null, null, [null, 2]]
```

## Current Tool Inventory (server.py)

### GSC Tools
- `gsc_list_sites` — graceful fallback with instructions
- `gsc_site_summary` — gydQ5d RPC, coverage counts
- `gsc_performance_trend` — OLiH4d RPC, daily data ✅
- `gsc_search_analytics` — nDAfwb RPC, multi-dim breakdown
- `gsc_top_queries` — nDAfwb with dim=query
- `gsc_top_pages` — nDAfwb with dim=page

### Bing Tools (unchanged from v0.1.0)
- `bing_get_site_info`
- `bing_top_pages`
- `bing_top_queries`
- `bing_crawl_stats`

### Utility
- `refresh_google_session` — clears cookie cache + XSRF cache

## Next Steps / Future Work
- Verify `nDAfwb` parsing on high-traffic sites (low-traffic sites return only aggregates)
- Improve `gsc_list_sites` — possibly scrape GSC property list from HTML
- Add `gsc_index_coverage` tool using czrWJf RPC
- Add Firefox cookie support as fallback
- Consider v0.2.0 with sitemaps + URL inspection RPCs
