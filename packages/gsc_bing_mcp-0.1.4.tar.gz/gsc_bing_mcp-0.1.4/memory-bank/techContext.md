# Tech Context

## Technology Stack

### Runtime
- **Python 3.11+** (required for modern type hints and FastMCP)
- **uv / uvx** — package manager for distribution (users need this)

### Core Dependencies (3 packages only)
| Package | Version | Purpose |
|---------|---------|---------|
| `mcp` | >=1.0.0 | FastMCP framework for MCP server (stdio transport) |
| `rookiepy` | >=0.5.0 | Rust-based Chrome cookie extractor (cross-platform, AES-GCM) |
| `httpx` | >=0.27.0 | Async HTTP client for batchexecute + Bing API calls |

---

## Google Search Console Authentication (v0.1.2+)

### Overview
GSC uses Google's internal `batchexecute` RPC protocol. Authentication requires:
1. Chrome session cookies (extracted by `rookiepy`)
2. SAPISIDHASH header (computed from `SAPISID` cookie)
3. XSRF token (auto-fetched from a probe request)

### SAPISIDHASH
```python
import hashlib, time
unix_ts = int(time.time())
sha1 = hashlib.sha1(f"{unix_ts} {SAPISID} https://search.google.com".encode()).hexdigest()
header = f"SAPISIDHASH {unix_ts}_{sha1}"
# Cookie to use: SAPISID (or __Secure-3PAPISID if SAPISID absent)
```

### XSRF Token
- Make a POST to the batchexecute endpoint WITHOUT `&at=` — get a 400 response
- Parse the 400 body for `"xsrf","TOKEN"` pattern
- Cache for 5 minutes; re-fetch on next 400

### batchexecute Endpoint
```
POST https://search.google.com/_/SearchConsoleAggReportUi/data/batchexecute
Content-Type: application/x-www-form-urlencoded;charset=UTF-8
Origin: https://search.google.com
Referer: https://search.google.com/search-console/performance/search-analytics
X-Same-Domain: 1
Authorization: SAPISIDHASH {ts}_{sha1}

Body: f.req=[[["rpcId","argsJsonString",null,"1"]]]&at=XSRF_TOKEN
```

### Response Format
Google uses a chunked streaming format (NOT standard HTTP chunked transfer):
```
DECIMAL_BYTECOUNT\n
[JSON_ARRAY]\n
DECIMAL_BYTECOUNT\n
[JSON_ARRAY]\n
```
Each JSON array is a `wrb.fr` envelope:
```json
["wrb.fr", "RPC_ID", "data_json_string", null, null, null, "sequence_id"]
```
Parse: split on lines matching `^\d+$`, collect the next line as JSON, extract `[2]` (data string), then `json.loads()` that.

### RPC IDs
| ID | Purpose | Args Pattern |
|----|---------|-------------|
| `OLiH4d` | Date time series | `["url", 27, null, null, null, [[1], null, [[null,null,null,3]], [[6,["WEB"]]], null,null,null,null,null,null, 1, null, null, 2], null, null, [null, 2]]` |
| `gydQ5d` | Site summary/coverage | `["url"]` |
| `nDAfwb` | Dimension breakdown | `["url", 32, null, null, null, [[dim], null, [[null,null,null,3]], [[6,["WEB"]]], null,null,null,null,null,null, 1, null, null, 2]]` |
| `czrWJf` | Coverage stats | `["url", 9]` |
| `SM7Bqb` | List sites | `[[1, []]]` (returns [] without localStorage) |
| `B2IOAd` | Stats panel | `["url", [[7]]]` |
| `mKtLlc` | Property summary | `["url"]` |

### Dimension Codes (nDAfwb)
```python
DIMENSIONS = {
    "query": 2,
    "page": 3,
    "country": 4,
    "device": 5,
    "date": 8,  # note: OLiH4d always uses [1] for date, not [8]
}
```

### OLiH4d Response Parsing
```python
# raw = json.loads(data_string)
# raw[1][0] = list of date entries
# Each entry: [timestamp_ms, [clicks, impressions, ctr_float, position_float], ...]
date = datetime.utcfromtimestamp(ts_ms / 1000).strftime("%Y-%m-%d")
```

---

## rookiepy Cookie Extraction

### Field Names (different from browser-cookie3!)
```python
# rookiepy returns dict with these EXACT field names:
{
    "name": str,
    "value": str,
    "domain": str,
    "path": str,
    "secure": bool,
    "http_only": bool,          # NOT "httpOnly"
    "same_site": int,           # -1/0=None, 1=Lax, 2=Strict (NOT string)
    "expires": str,             # epoch seconds as STRING (not int)
}
```

### Multi-Browser Auto-Detection
```python
# Priority order: Chrome → Brave → Edge
# Env var overrides: BROWSER=chrome/brave/edge, CHROME_PROFILE=/path/to/profile
import rookiepy
cookies = rookiepy.chrome(["google.com"])   # Chrome
cookies = rookiepy.brave(["google.com"])    # Brave
cookies = rookiepy.edge(["google.com"])     # Edge
```

### Auth Cookie Priority (for SAPISID)
```
__Secure-3PAPISID → SAPISID → __Secure-1PAPISID
```

### All Cookies Header (for batchexecute)
Use `get_all_cookies_header()` which sends ALL `.google.com` cookies (not just auth cookies).
Skip cookies whose name starts with `__Host-` (can't be set cross-origin).

---

## Bing Webmaster API

### Authentication
- Official free API key from `bing.com/webmasters` → Settings → API Access
- Query param: `?apikey={key}`
- Env var: `BING_API_KEY`

### Endpoints
```
Base: https://ssl.bing.com/webmaster/api.svc/json/
- GetSiteInfo?apikey=&siteUrl=
- GetPageStats?apikey=&siteUrl=&page=0&pageSize=10
- GetKeywordStats?apikey=&siteUrl=&page=0&pageSize=10
- GetCrawlStats?apikey=&siteUrl=
```

---

## Distribution

### Package Structure
```
gsc_bing_mcp/
├── __init__.py
├── server.py              # FastMCP server — 11 tools
├── clients/
│   ├── __init__.py
│   ├── gsc_client.py      # batchexecute RPC client
│   └── bing_client.py     # Bing API client
└── extractors/
    ├── __init__.py
    ├── chrome_cookies.py  # rookiepy wrapper + multi-browser
    └── sapisidhash.py     # SAPISIDHASH generator
```

### User Install & MCP Config
```bash
# Install: users need uv
uvx gsc-bing-mcp   # or: pip install gsc-bing-mcp && gsc-bing-mcp
```

```json
{
  "mcpServers": {
    "gsc-bing-mcp": {
      "command": "uvx",
      "args": ["gsc-bing-mcp"],
      "env": {
        "BING_API_KEY": "your-bing-api-key-here"
      }
    }
  }
}
```

### Optional Env Vars
```bash
BROWSER=brave           # override browser (chrome/brave/edge)
CHROME_PROFILE=/path    # override profile path
BING_API_KEY=xxx        # Bing API key
```

---

## Development Setup
```bash
cd "/Users/mdmillathosen/Desktop/GSC - MCP"
python -m venv .venv
source .venv/bin/activate
pip install mcp rookiepy httpx build twine

# Run tests
python test_gsc_client.py

# Build + publish
python -m build
python -m twine upload dist/gsc_bing_mcp-0.1.x*
```

## Platform Notes

### macOS
- Chrome: `~/Library/Application Support/Google/Chrome/`
- rookiepy reads macOS Keychain for AES decryption key automatically

### Windows
- Chrome: `%LOCALAPPDATA%\Google\Chrome\User Data\`
- rookiepy uses Windows DPAPI

### Linux
- Chrome: `~/.config/google-chrome/`
- rookiepy uses Gnome Keyring or kwallet

## Files of Interest (not shipped)
| File | Purpose |
|------|---------|
| `discover_rpc_ids.py` | Playwright script: inject cookies, intercept batchexecute RPCs live |
| `test_gsc_client.py` | End-to-end test of all GSC client functions |
| `discovered_rpcs.json` | Saved RPC IDs from Playwright interception session |
| `probe_gsc_rpc.py` | Low-level RPC probing script |
