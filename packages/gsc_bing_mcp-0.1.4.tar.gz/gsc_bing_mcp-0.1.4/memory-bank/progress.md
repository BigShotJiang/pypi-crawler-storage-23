# Progress

## ✅ COMPLETED — v0.1.4 Published

### PyPI: https://pypi.org/project/gsc-bing-mcp/0.1.4/
### GitHub: https://github.com/codermillat/gsc-bing-mcp

---

## What Works (v0.1.4)

### GSC Tools — batchexecute RPC (no OAuth, no GCP)
| Tool | RPC | Status |
|------|-----|--------|
| `gsc_performance_trend` | OLiH4d | ✅ **Fully working** — 17 days real data |
| `gsc_site_summary` | gydQ5d | ✅ **Fully working** — coverage counts |
| `gsc_top_queries` | nDAfwb dim=1 | ✅ Structural (verified on low-traffic site) |
| `gsc_top_pages` | nDAfwb dim=4 | ✅ Structural |
| `gsc_search_analytics` | nDAfwb multi-dim | ✅ Structural |
| `gsc_list_sites` | HTML scraping | ✅ **Fully working** — scrapes /welcome page for property list |
| `gsc_list_sitemaps` | xDwXKd | ✅ **NEW** — returns sitemap URLs + submitted/indexed/error counts |
| `gsc_insights` | oGVhvf | ✅ **NEW** — returns callouts/notifications |
| `refresh_google_session` | — | ✅ Clears cookie + XSRF cache |

### Bing Tools (unchanged from v0.1.0)
| Tool | Status |
|------|--------|
| `bing_list_sites` | ✅ Working |
| `bing_search_analytics` | ✅ Working |
| `bing_keyword_stats` | ✅ Working |
| `bing_crawl_stats` | ✅ Working |

### Infrastructure
- SAPISIDHASH auth (SHA1 based, no OAuth) ✅
- rookiepy Chrome cookie extraction ✅
- Multi-browser auto-detect: Chrome → Brave → Edge ✅
- Env var overrides: `BROWSER`, `CHROME_PROFILE` ✅
- XSRF token auto-fetch from 400 error ✅
- batchexecute response parser (chunked streaming + wrb.fr) ✅
- 5-minute in-memory cache for cookies + XSRF ✅

## Sample Test Output (real data from kitovo.app)
```
[5] Date time series — OLiH4d:
  ✓ Got 17 date rows
    {'date': '2026-01-31', 'clicks': 0, 'impressions': 0, 'ctr': 0.0, 'position': 0.0}
    {'date': '2026-02-01', 'clicks': 1, 'impressions': 13, 'ctr': 7.69, 'position': 28.9}
    {'date': '2026-02-02', 'clicks': 2, 'impressions': 160, 'ctr': 1.25, 'position': 54.0}
    ...
[4] gydQ5d: ✓ returns coverage: [[[43,[43,8,0]],[20,[20,3,0]],...],False,0,'https://www.kitovo.app/']
```

## v0.1.3 New RPC Constants (from Playwright discovery run)
```
xDwXKd  — sitemaps list — args: [site_url, 7]
          response: [[[submitted_stat, indexed_stat, error_stat, [[path, full_url], ...]]]]

oGVhvf  — insights/callouts — args: [site_url]
          response: [[[[priority, counts, null, "@CALLOUT_TYPE@", [year,month,day], null, bool], ...]]]
```

## Current MCP Config (Cline)
```json
"gsc-bing-mcp": {
  "command": "uvx",
  "args": ["gsc-bing-mcp"],
  "env": { "BING_API_KEY": "caafd6505af04f9c90edca8b73ddfc3e" }
}
```

---

## Version History
| Version | Date | Notes |
|---------|------|-------|
| 0.1.0 | 2026-02-18 | Initial release — used wrong GSC API (404s) |
| 0.1.1 | 2026-02-18 | First batchexecute attempt (incomplete) |
| 0.1.2 | 2026-02-18 | Full batchexecute rewrite — real data working |
| 0.1.4 | 2026-02-18 | **HTML scraping for gsc_list_sites — auto-discovers all properties** |

---

## Known Limitations
- `gsc_list_sites`: SM7Bqb returns `[]` because it depends on browser localStorage. Users must provide `site_url` directly.
- `nDAfwb` breakdown on very low-traffic sites only returns aggregate totals (no per-query rows). Works correctly for high-traffic sites.
- Chrome must not have the Cookies SQLite DB locked (close Chrome or use --no-sandbox profile)
- SAPISIDHASH is an internal Google technique — could theoretically break if Google changes auth
- Bing API key must be manually obtained from bing.com/webmasters

## ⚠️ Security Note
- Regenerate PyPI API token if the old one was ever exposed in chat logs
  - Go to: https://pypi.org/manage/account/token/
  - Delete old token, create new one scoped to "gsc-bing-mcp" project
  - Update `~/.pypirc`

---

## What's Left to Build (Future)

### v0.2.0 Ideas
- `gsc_index_coverage` — use czrWJf RPC for detailed coverage breakdown (args: [site_url, 7, 1])
- `gsc_inspect_url` — URL inspection RPC (not yet discovered)
- Better `gsc_list_sites` — try SM7Bqb with preloaded site list, or GSC HTML scraping
- Firefox cookie support as fallback
- nDAfwb parser improvement — current heuristic scan doesn't find rows on low-traffic sites

### v0.3.0 Ideas
- Multi-account Google support (profile selector)
- Date range support (currently fixed 17-day window)
- Export to CSV/JSON option
- Bing URL submission tool
