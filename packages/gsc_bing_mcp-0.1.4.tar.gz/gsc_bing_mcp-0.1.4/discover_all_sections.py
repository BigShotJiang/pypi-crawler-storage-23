#!/usr/bin/env python3
"""
discover_all_sections.py — Comprehensive GSC RPC discovery across ALL sections.

Injects real Chrome cookies into Playwright Chromium, then systematically
navigates to EVERY Google Search Console section and captures all batchexecute
RPC call IDs, request args, and response data.

Results saved to: discovered_all_sections.json
"""

import atexit
import json
import re
import sys
import time
import urllib.parse
from pathlib import Path

try:
    import rookiepy
except ImportError:
    sys.exit("rookiepy not installed. Run: pip install rookiepy")

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit("playwright not installed. Run: pip install playwright && python3 -m playwright install chromium")


# ─── Target site — change this to your highest-traffic GSC property ───────────
TARGET_SITE = "https://www.nextgenlearning.dev/"
RESOURCE_ID = urllib.parse.quote(TARGET_SITE, safe="")

# ─── GSC Section URLs ──────────────────────────────────────────────────────────
# Each entry: (section_name, url_path, wait_seconds)
# resource_id is appended automatically

def section_url(path: str) -> str:
    sep = "&" if "?" in path else "?"
    return path + sep + f"resource_id={RESOURCE_ID}"

GSC_SECTIONS = [
    # Performance
    ("performance_web",     section_url("/search-console/performance/search-analytics"),            25),
    ("performance_img",     section_url("/search-console/performance/search-analytics?type=image"), 12),
    ("performance_video",   section_url("/search-console/performance/search-analytics?type=video"), 12),
    ("performance_news",    section_url("/search-console/performance/search-analytics?type=news"),  12),
    # Index
    ("index_coverage",      section_url("/search-console/index"),                                   20),
    ("sitemaps",            section_url("/search-console/sitemaps"),                                15),
    ("removals",            section_url("/search-console/removals"),                                12),
    # Experience
    ("page_experience",     section_url("/search-console/page-experience"),                         15),
    ("core_web_vitals",     section_url("/search-console/core-web-vitals"),                         20),
    ("mobile_usability",    section_url("/search-console/mobile"),                                  15),
    # Enhancements / Rich Results
    ("rich_results",        section_url("/search-console/rich-results"),                            15),
    ("breadcrumbs",         section_url("/search-console/rich-results?type=Breadcrumb"),            15),
    ("faq",                 section_url("/search-console/rich-results?type=FAQPage"),               12),
    ("review_snippets",     section_url("/search-console/rich-results?type=Review"),                12),
    ("product",             section_url("/search-console/rich-results?type=Product"),               12),
    ("how_to",              section_url("/search-console/rich-results?type=HowTo"),                 12),
    ("article",             section_url("/search-console/rich-results?type=Article"),               12),
    # Links
    ("links",               section_url("/search-console/links"),                                   20),
    # Manual actions & Security
    ("manual_actions",      section_url("/search-console/manual-actions"),                          12),
    ("security_issues",     section_url("/search-console/security-issues"),                         12),
    # AMP
    ("amp",                 section_url("/search-console/amp"),                                     12),
    # URL Inspection (no resource_id needed)
    ("url_inspection",      "/search-console/url-inspection",                                       12),
]

BASE_URL = "https://search.google.com"
BE_PATTERN = "**/batchexecute**"
OUTPUT_PATH = Path("discovered_all_sections.json")

# ─── Storage ───────────────────────────────────────────────────────────────────

# rpc_id → {"section": str, "args_example": str, "response": any}
discovered: dict = {}

# ─── Cookie helpers ────────────────────────────────────────────────────────────

def get_cookies():
    browsers = [
        ("chrome", rookiepy.chrome),
        ("brave",  rookiepy.brave),
        ("edge",   rookiepy.edge),
    ]
    for name, fn in browsers:
        try:
            cookies = fn(["google.com"])
            if cookies:
                print(f"[cookies] Got {len(cookies)} cookies from {name}")
                return cookies
        except Exception as e:
            print(f"[cookies] {name} failed: {e}")
    sys.exit("[cookies] No browser cookies found.")


_SAME_SITE_MAP = {
    -1: "None", 0: "None", 1: "Lax", 2: "Strict",
    "-1": "None", "0": "None", "1": "Lax", "2": "Strict",
}


def cookies_to_playwright(raw_cookies):
    pw = []
    for c in raw_cookies:
        name  = c.get("name", "")
        value = str(c.get("value", "") or "")
        if not name:
            continue
        # Skip __Host- prefixed cookies (can't set cross-origin)
        if name.startswith("__Host-"):
            continue

        domain = c.get("domain", "") or ".google.com"
        domain_clean = domain.lstrip(".")
        if not (domain_clean == "google.com" or domain_clean.endswith(".google.com")):
            continue
        if not domain.startswith("."):
            domain = f".{domain}"

        path = c.get("path", "/") or "/"
        ss   = _SAME_SITE_MAP.get(c.get("same_site", -1), "None")

        cookie = {
            "name": name, "value": value,
            "domain": domain, "path": path,
            "httpOnly": bool(c.get("http_only", False)),
            "secure":   bool(c.get("secure", False)),
            "sameSite": ss,
        }
        try:
            exp = int(c.get("expires") or 0)
            if exp > 0:
                cookie["expires"] = exp
        except (TypeError, ValueError):
            pass
        pw.append(cookie)
    return pw


# ─── Request parsing ────────────────────────────────────────────────────────────

def parse_freq(body: str):
    """Parse f.req POST body → list of (rpc_id, args_json) tuples."""
    try:
        decoded = urllib.parse.unquote_plus(body)
        match = re.search(r'f\.req=(\[.*)', decoded)
        if not match:
            return []
        freq_str = match.group(1)
        # Find balanced brackets
        depth, end = 0, 0
        for i, ch in enumerate(freq_str):
            if ch == '[':   depth += 1
            elif ch == ']': depth -= 1
            if depth == 0:  end = i + 1; break
        outer = json.loads(freq_str[:end])
        results = []
        for batch in outer:
            if isinstance(batch, list):
                for item in batch:
                    if isinstance(item, list) and len(item) >= 2:
                        results.append((item[0], item[1]))
        return results
    except Exception:
        return []


def parse_batchexecute_response(text: str) -> list:
    """Parse chunked batchexecute response → list of (rpc_id, data) tuples."""
    text = re.sub(r"^\)\]\}'\n?", "", text.strip())
    results = []
    chunks = re.split(r"(?m)^\d+\s*$", text)
    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            outer = json.loads(chunk)
        except Exception:
            continue
        if not isinstance(outer, list):
            continue
        for item in outer:
            if isinstance(item, list) and len(item) >= 3 and item[0] == "wrb.fr":
                rpc_id = item[1]
                raw    = item[2]
                data   = None
                if isinstance(raw, str):
                    try:
                        data = json.loads(raw)
                    except Exception:
                        data = raw
                elif raw is not None:
                    data = raw
                results.append((rpc_id, data))
    return results


# ─── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("[*] Getting Chrome cookies...")
    raw_cookies  = get_cookies()
    pw_cookies   = cookies_to_playwright(raw_cookies)
    print(f"[*] Converted {len(pw_cookies)} cookies for Playwright")

    # Save on exit
    def save():
        OUTPUT_PATH.write_text(json.dumps(discovered, indent=2, ensure_ascii=False))
        print(f"\n[atexit] Saved {len(discovered)} RPCs → {OUTPUT_PATH.absolute()}")
    atexit.register(save)

    with sync_playwright() as p:
        print("[*] Launching Chromium (headful)...")
        browser = p.chromium.launch(
            headless=False,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"],
        )
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/121.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1400, "height": 900},
        )

        # Inject cookies
        print(f"[*] Injecting {len(pw_cookies)} cookies...")
        ok = 0
        for cookie in pw_cookies:
            try:
                context.add_cookies([cookie])
                ok += 1
            except Exception as e:
                pass
        print(f"[*] Injected {ok}/{len(pw_cookies)} cookies")

        page = context.new_page()

        # ── Intercept batchexecute requests ──────────────────────────────────

        current_section = ["unknown"]

        def handle_route(route, request):
            if "batchexecute" in request.url:
                try:
                    body = request.post_data or ""
                    rpcs = parse_freq(body)
                    for rpc_id, args_json in rpcs:
                        if rpc_id not in discovered:
                            print(f"  [NEW RPC] {rpc_id!r}  section={current_section[0]}  args={str(args_json)[:100]}")
                            discovered[rpc_id] = {
                                "section": current_section[0],
                                "args_example": args_json,
                                "response": None,
                            }
                        else:
                            print(f"  [seen]    {rpc_id!r}  section={current_section[0]}")
                except Exception:
                    pass
            route.continue_()

        page.route(BE_PATTERN, handle_route)

        # Capture responses
        def on_response(response):
            if "batchexecute" not in response.url:
                return
            try:
                body = response.text()
                pairs = parse_batchexecute_response(body)
                for rpc_id, data in pairs:
                    if rpc_id in discovered and discovered[rpc_id]["response"] is None:
                        discovered[rpc_id]["response"] = data
                        preview = str(data)[:200]
                        print(f"  [RESP]    {rpc_id!r} → {preview}")
            except Exception:
                pass

        page.on("response", on_response)

        # ── Navigate to each section ──────────────────────────────────────────

        print("\n" + "="*70)
        print("NAVIGATING ALL GSC SECTIONS")
        print("="*70)

        for section_name, url_path, wait_secs in GSC_SECTIONS:
            full_url = BASE_URL + url_path
            current_section[0] = section_name

            print(f"\n{'─'*60}")
            print(f"  SECTION: {section_name}")
            print(f"  URL:     {full_url}")
            print(f"  Wait:    {wait_secs}s")
            print(f"{'─'*60}")

            try:
                page.goto(full_url, timeout=30000, wait_until="domcontentloaded")
            except Exception as e:
                print(f"  [nav error] {e}")

            # Wait for data RPCs to fire
            for i in range(wait_secs):
                time.sleep(1)
                if (i + 1) % 5 == 0:
                    print(f"  [{i+1}s] total RPCs discovered: {len(discovered)}")

            # Try clicking dimension tabs if on Performance page
            if section_name == "performance_web":
                print("  [click] Trying dimension tabs...")
                tabs = [("Queries", 5), ("Pages", 5), ("Countries", 5), ("Devices", 5), ("Search appearance", 5)]
                for tab_text, wait in tabs:
                    try:
                        tab = page.get_by_text(tab_text, exact=True).first
                        if tab:
                            tab.click(timeout=3000)
                            time.sleep(wait)
                            print(f"    Clicked '{tab_text}' — RPCs: {list(discovered.keys())}")
                    except Exception:
                        pass

            # For Rich Results, try clicking result type cards
            if section_name == "rich_results":
                print("  [click] Trying rich result type cards...")
                for card_text in ["Breadcrumb", "FAQ", "Review", "Product", "HowTo", "Article", "Sitelinks searchbox"]:
                    try:
                        card = page.get_by_text(card_text, exact=False).first
                        if card:
                            card.click(timeout=3000)
                            time.sleep(5)
                            print(f"    Clicked '{card_text}' — RPCs: {list(discovered.keys())}")
                            page.go_back()
                            time.sleep(3)
                    except Exception:
                        pass

            # For Links, try clicking sections
            if section_name == "links":
                print("  [click] Trying links sub-sections...")
                for link_text in ["Top linked pages", "Top linking sites", "Top linking text"]:
                    try:
                        el = page.get_by_text(link_text, exact=False).first
                        if el:
                            el.click(timeout=3000)
                            time.sleep(5)
                            print(f"    Clicked '{link_text}'")
                    except Exception:
                        pass

        # ── Extra wait for any stragglers ──────────────────────────────────────
        print("\n[*] Extra wait 10s for any late RPCs...")
        for i in range(10):
            time.sleep(1)

        # ── Summary ───────────────────────────────────────────────────────────
        print("\n" + "="*70)
        print(f"DISCOVERY COMPLETE — {len(discovered)} unique RPC IDs found")
        print("="*70)

        for rpc_id, info in sorted(discovered.items(), key=lambda x: x[1]["section"]):
            print(f"\n  RPC: {rpc_id!r}")
            print(f"    Section:  {info['section']}")
            print(f"    Args:     {str(info['args_example'])[:120]}")
            resp_preview = str(info['response'])[:200] if info['response'] is not None else "None"
            print(f"    Response: {resp_preview}")

        # Save final results
        OUTPUT_PATH.write_text(json.dumps(discovered, indent=2, ensure_ascii=False))
        print(f"\n[*] Saved to {OUTPUT_PATH.absolute()}")

        print("\n[*] Browser will stay open for 15 seconds so you can inspect...")
        time.sleep(15)
        browser.close()


if __name__ == "__main__":
    main()
