"""
GSC & Bing Webmaster MCP Server
---------------------------------
An MCP server that pulls search performance data from:
  - Google Search Console (using your existing Chrome browser session — no API key needed)
  - Bing Webmaster Tools (using a free API key from bing.com/webmasters)

Authentication:
  Google: Reads SAPISID cookie from Chrome → generates SAPISIDHASH (same as yt-dlp)
          Uses batchexecute (Google's internal RPC protocol — no GCP project needed!)
  Bing:   Uses BING_API_KEY environment variable

Transport: stdio (runs locally on user's machine, launched by Cline/Claude Desktop)

Tools (13 total):
  GSC:  gsc_list_sites, gsc_performance_trend, gsc_top_queries,
        gsc_top_pages, gsc_search_analytics, gsc_site_summary,
        gsc_list_sitemaps, gsc_insights
  Bing: bing_list_sites, bing_search_analytics, bing_crawl_stats,
        bing_keyword_stats
  Util: refresh_google_session
"""

import json
import logging
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .clients import gsc_client, bing_client
from .extractors.chrome_cookies import clear_cookie_cache

# Configure logging (stderr so it doesn't interfere with stdio MCP protocol)
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger(__name__)

# Create the FastMCP server
mcp = FastMCP(
    name="GSC & Bing Webmaster",
    instructions=(
        "Access Google Search Console and Bing Webmaster Tools data. "
        "Google auth uses your Chrome browser session — just be logged in to Google in Chrome "
        "(Chrome, Brave, or Edge). No API key or GCP setup required. "
        "Bing auth uses the BING_API_KEY environment variable. "
        "Site URLs must match exactly as they appear in each tool "
        "(e.g., 'https://example.com/' with trailing slash, or 'sc-domain:example.com' for GSC domain properties). "
        "Note: GSC data has a ~2-3 day lag. For best results use gsc_performance_trend "
        "which returns daily data, or gsc_top_queries/gsc_top_pages for dimension breakdowns."
    ),
)


# ─── GSC Tools ────────────────────────────────────────────────────────────────

@mcp.tool()
async def gsc_list_sites() -> str:
    """
    List all verified properties/sites in your Google Search Console account.

    Uses your Chrome browser session (no API key required).
    If auto-detection fails, use site URLs you know are verified in GSC.

    No parameters required.
    """
    try:
        sites = await gsc_client.list_sites()
        if not sites:
            return "No verified sites found. Try providing the site_url directly in other tools."

        result = []
        for site in sites:
            result.append({
                "siteUrl": site.get("siteUrl", ""),
                "permissionLevel": site.get("permissionLevel", "siteOwner"),
            })
        return json.dumps(result, indent=2)

    except RuntimeError as e:
        return (
            f"❌ {e}\n\n"
            "Tip: You can still use other GSC tools by providing the site_url directly. "
            "Check your verified properties at search.google.com/search-console"
        )
    except Exception as e:
        logger.exception("Unexpected error in gsc_list_sites")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_performance_trend(
    site_url: str,
    search_type: str = "WEB",
) -> str:
    """
    Get daily performance trend data for a GSC property.

    Returns clicks, impressions, CTR, and average position for each day
    over the recent period (~last 17 days based on GSC data availability).

    This is the most reliable GSC tool — returns clean, structured daily data.

    Args:
        site_url: The verified property URL exactly as it appears in GSC
                  (e.g., "https://example.com/" or "sc-domain:example.com")
        search_type: Search type filter — "WEB" (default), "IMAGE", "VIDEO", "NEWS"
    """
    try:
        result = await gsc_client.query_search_analytics(
            site_url=site_url,
            dimensions=["date"],
            search_type=search_type,
        )

        rows = result.get("rows", [])
        if not rows:
            note = result.get("note", "")
            return (
                f"No performance data found for {site_url}. {note}\n"
                "Ensure the site is verified in Google Search Console and has received traffic."
            )

        # Calculate totals
        total_clicks = sum(r.get("clicks", 0) for r in rows)
        total_impressions = sum(r.get("impressions", 0) for r in rows)
        avg_ctr = round(total_clicks / total_impressions * 100, 2) if total_impressions > 0 else 0.0
        avg_position = round(
            sum(r.get("position", 0) * r.get("impressions", 0) for r in rows) /
            max(total_impressions, 1), 1
        )

        return json.dumps({
            "site": site_url,
            "search_type": search_type,
            "summary": {
                "total_clicks": total_clicks,
                "total_impressions": total_impressions,
                "avg_ctr_pct": avg_ctr,
                "avg_position": avg_position,
                "days_with_data": len(rows),
            },
            "daily_data": rows,
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_performance_trend")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_top_queries(
    site_url: str,
    limit: int = 25,
    search_type: str = "WEB",
) -> str:
    """
    Get the top search queries driving traffic to your site in Google Search Console.

    Returns queries with clicks, impressions, CTR, and average position.
    Note: Sites with very low traffic may return no individual queries
    (GSC filters out queries below a minimum threshold).

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
        limit: Number of top queries to return (default 25)
        search_type: "WEB" (default), "IMAGE", "VIDEO", "NEWS"
    """
    try:
        result = await gsc_client.query_search_analytics(
            site_url=site_url,
            dimensions=["query"],
            search_type=search_type,
        )

        rows = result.get("rows", [])
        if not rows:
            note = result.get("note", "")
            return (
                f"No query data found for {site_url}. {note}\n"
                "Note: GSC only shows queries when a site has enough traffic. "
                "Low-traffic sites may show aggregate totals only. "
                "Use gsc_performance_trend to see daily aggregate data."
            )

        # Sort by clicks and limit
        rows_sorted = sorted(rows, key=lambda r: r.get("clicks", 0), reverse=True)[:limit]

        return json.dumps({
            "site": site_url,
            "search_type": search_type,
            "top_queries": rows_sorted,
            "total_shown": len(rows_sorted),
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_top_queries")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_top_pages(
    site_url: str,
    limit: int = 25,
    search_type: str = "WEB",
) -> str:
    """
    Get the top pages driving organic search traffic from Google Search Console.

    Returns pages with clicks, impressions, CTR, and average position.
    Note: Sites with very low traffic may return aggregate totals rather than
    individual page breakdowns.

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
        limit: Number of top pages to return (default 25)
        search_type: "WEB" (default), "IMAGE", "VIDEO", "NEWS"
    """
    try:
        result = await gsc_client.query_search_analytics(
            site_url=site_url,
            dimensions=["page"],
            search_type=search_type,
        )

        rows = result.get("rows", [])
        if not rows:
            note = result.get("note", "")
            return (
                f"No page data found for {site_url}. {note}\n"
                "Note: GSC only shows page breakdowns when a site has enough traffic. "
                "Use gsc_performance_trend to see daily aggregate data."
            )

        rows_sorted = sorted(rows, key=lambda r: r.get("clicks", 0), reverse=True)[:limit]

        return json.dumps({
            "site": site_url,
            "search_type": search_type,
            "top_pages": rows_sorted,
            "total_shown": len(rows_sorted),
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_top_pages")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_search_analytics(
    site_url: str,
    dimension: str = "query",
    search_type: str = "WEB",
) -> str:
    """
    Get search analytics data from Google Search Console with dimension grouping.

    Returns performance data grouped by the specified dimension.
    For daily trends, use gsc_performance_trend instead.

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
        dimension: Grouping dimension — one of:
                   "query" (default) — top search queries
                   "page"   — top landing pages
                   "country" — traffic by country
                   "device"  — traffic by device (desktop/mobile/tablet)
        search_type: "WEB" (default), "IMAGE", "VIDEO", "NEWS"
    """
    valid_dims = ["query", "page", "country", "device"]
    dim = dimension.lower().strip()
    if dim not in valid_dims:
        return f"❌ Invalid dimension '{dimension}'. Valid options: {valid_dims}"

    try:
        result = await gsc_client.query_search_analytics(
            site_url=site_url,
            dimensions=[dim],
            search_type=search_type,
        )

        rows = result.get("rows", [])
        if not rows:
            note = result.get("note", "")
            return (
                f"No data found for {site_url} with dimension={dim}. {note}\n"
                "Use gsc_performance_trend to see daily aggregate traffic data."
            )

        rows_sorted = sorted(rows, key=lambda r: r.get("clicks", 0), reverse=True)[:100]

        return json.dumps({
            "site": site_url,
            "dimension": dim,
            "search_type": search_type,
            "data": rows_sorted,
            "total_rows": len(rows_sorted),
        }, indent=2)

    except (ValueError, RuntimeError) as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_search_analytics")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_site_summary(site_url: str) -> str:
    """
    Get a coverage and indexing summary for a GSC property.

    Returns counts of indexed pages, pages with errors, warnings,
    and other coverage statistics from Google Search Console.

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
    """
    try:
        summary = await gsc_client.get_site_summary(site_url)
        raw = summary.get("data")

        if raw is None:
            return f"No summary data available for {site_url}."

        # Parse the gydQ5d response structure:
        # [[[count, [count, warnings, errors]], ...], False, 0, "site_url"]
        coverage_items = []
        if isinstance(raw, list) and len(raw) >= 1 and isinstance(raw[0], list):
            for item in raw[0]:
                if isinstance(item, list) and len(item) >= 2:
                    total = item[0]
                    details = item[1] if isinstance(item[1], list) else [item[1]]
                    valid = details[0] if len(details) > 0 else 0
                    warnings = details[1] if len(details) > 1 else 0
                    errors = details[2] if len(details) > 2 else 0
                    coverage_items.append({
                        "total_urls": total,
                        "valid": valid,
                        "warnings": warnings,
                        "errors": errors,
                    })

        if coverage_items:
            # Summarize across all coverage categories
            total_valid = sum(c["valid"] for c in coverage_items)
            total_warnings = sum(c["warnings"] for c in coverage_items)
            total_errors = sum(c["errors"] for c in coverage_items)

            return json.dumps({
                "site": site_url,
                "coverage_summary": {
                    "total_valid_pages": total_valid,
                    "total_warnings": total_warnings,
                    "total_errors": total_errors,
                    "coverage_categories": len(coverage_items),
                },
                "coverage_breakdown": coverage_items,
                "raw_data": str(raw)[:500],
            }, indent=2)

        return json.dumps({
            "site": site_url,
            "data": str(raw)[:800],
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_site_summary")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_list_sitemaps(site_url: str) -> str:
    """
    List all submitted sitemaps for a GSC property.

    Returns submitted sitemap URLs along with submitted, indexed, and error counts.

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
    """
    try:
        result = await gsc_client.get_sitemaps(site_url)

        sitemaps = result.get("sitemaps", [])
        submitted = result.get("submitted")
        indexed = result.get("indexed")
        errors = result.get("errors")

        return json.dumps({
            "site": site_url,
            "stats": {
                "submitted": submitted,
                "indexed": indexed,
                "errors": errors,
            },
            "sitemaps": sitemaps,
            "total": len(sitemaps),
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_list_sitemaps")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def gsc_insights(site_url: str) -> str:
    """
    Get Search Console Insights and notifications for a GSC property.

    Returns callouts/notifications such as branded query trends, filter alerts,
    and other Search Console insights surfaced by Google.

    Args:
        site_url: The verified property URL (e.g., "https://example.com/")
    """
    try:
        result = await gsc_client.get_insights(site_url)

        callouts = result.get("callouts", [])

        if not callouts:
            return json.dumps({
                "site": site_url,
                "message": "No insights or notifications found for this property.",
                "callouts": [],
            }, indent=2)

        # Make callout types human-readable
        type_labels = {
            "@BRANDED-CALLOUT@": "Branded query trend",
            "@INSIGHTS-SAN-FILTERED-BY-PAGE-CALLOUT@": "Data filtered by page",
            "@INSIGHTS-SAN-FILTERED-BY-QUERY-CALLOUT@": "Data filtered by query",
            "@INSIGHTS-SAN-FILTERED-BY-COUNTRY-CALLOUT@": "Data filtered by country",
            "@INSIGHTS-SAN-FILTERED-BY-SEARCH-TYPE-CALLOUT@": "Data filtered by search type",
        }

        formatted = []
        for c in callouts:
            callout_type = c.get("type", "")
            formatted.append({
                "type": callout_type,
                "label": type_labels.get(callout_type, callout_type),
                "priority": c.get("priority"),
                "date": c.get("date"),
                "counts": c.get("counts"),
            })

        return json.dumps({
            "site": site_url,
            "insights_count": len(formatted),
            "insights": formatted,
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in gsc_insights")
        return f"❌ Unexpected error: {e}"


# ─── Bing Tools ───────────────────────────────────────────────────────────────

@mcp.tool()
async def bing_list_sites() -> str:
    """
    List all sites/properties in your Bing Webmaster Tools account.

    Returns a list of sites with their URLs.
    Requires BING_API_KEY environment variable.

    No parameters required.
    """
    try:
        sites = await bing_client.get_user_sites()

        if not sites:
            return (
                "No sites found in your Bing Webmaster Tools account. "
                "Add and verify sites at bing.com/webmasters"
            )

        result = [
            {"url": site.get("Url") or site.get("url", "")}
            for site in sites
        ]
        return json.dumps(result, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in bing_list_sites")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def bing_search_analytics(
    site_url: str,
    start_date: str,
    end_date: str,
    limit: int = 100,
) -> str:
    """
    Get search performance data from Bing Webmaster Tools for a site.

    Returns impressions, clicks, and average click position by date.

    Args:
        site_url: The site URL as it appears in Bing Webmaster Tools
                  (e.g., "https://example.com/")
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
        limit: Maximum number of rows to return (default 100)
    """
    try:
        rows = await bing_client.get_search_analytics(
            site_url=site_url,
            start_date=start_date,
            end_date=end_date,
            max_count=min(limit, 500),
        )

        if not rows:
            return f"No Bing search analytics found for {site_url} in the selected date range."

        formatted = []
        for row in rows:
            formatted.append({
                "date": row.get("Date", row.get("date", "")),
                "impressions": row.get("Impressions", row.get("impressions", 0)),
                "clicks": row.get("Clicks", row.get("clicks", 0)),
                "avgClickPosition": row.get("AvgClickPosition", row.get("avgClickPosition", 0)),
            })

        return json.dumps({
            "site": site_url,
            "period": f"{start_date} to {end_date}",
            "data": formatted,
            "total_rows": len(formatted),
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in bing_search_analytics")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def bing_crawl_stats(site_url: str) -> str:
    """
    Get crawl statistics for a site in Bing Webmaster Tools.

    Returns information about how many pages Bing has crawled,
    crawl errors, blocked URLs, and DNS/connection issues.

    Args:
        site_url: The site URL as it appears in Bing Webmaster Tools
                  (e.g., "https://example.com/")
    """
    try:
        stats = await bing_client.get_crawl_stats(site_url)

        if not stats:
            return f"No crawl stats found for {site_url}."

        result = {
            "site": site_url,
            "crawledPages": stats.get("CrawledPages", stats.get("crawledPages", 0)),
            "inIndex": stats.get("InIndex", stats.get("inIndex", 0)),
            "crawlErrors": stats.get("CrawlErrors", stats.get("crawlErrors", 0)),
            "dnsErrors": stats.get("DnsErrors", stats.get("dnsErrors", 0)),
            "connectionTimeouts": stats.get("ConnectionTimeouts", stats.get("connectionTimeouts", 0)),
            "robotsExcluded": stats.get("RobotsExcluded", stats.get("robotsExcluded", 0)),
            "httpErrors": stats.get("HttpErrors", stats.get("httpErrors", 0)),
        }

        return json.dumps(result, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in bing_crawl_stats")
        return f"❌ Unexpected error: {e}"


@mcp.tool()
async def bing_keyword_stats(
    site_url: str,
    start_date: str,
    end_date: str,
    limit: int = 100,
) -> str:
    """
    Get keyword/query performance statistics from Bing Webmaster Tools.

    Returns the top keywords driving traffic from Bing with impressions,
    clicks, and average click position.

    Args:
        site_url: The site URL as it appears in Bing Webmaster Tools
                  (e.g., "https://example.com/")
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
        limit: Maximum number of keywords to return (default 100)
    """
    try:
        rows = await bing_client.get_keyword_stats(
            site_url=site_url,
            start_date=start_date,
            end_date=end_date,
            max_count=min(limit, 500),
        )

        if not rows:
            return f"No keyword data found for {site_url} in the selected date range."

        formatted = []
        for row in rows:
            formatted.append({
                "query": row.get("Query", row.get("query", "")),
                "impressions": row.get("Impressions", row.get("impressions", 0)),
                "clicks": row.get("Clicks", row.get("clicks", 0)),
                "avgClickPosition": row.get("AvgClickPosition", row.get("avgClickPosition", 0)),
            })

        formatted.sort(key=lambda x: x.get("clicks", 0), reverse=True)

        return json.dumps({
            "site": site_url,
            "period": f"{start_date} to {end_date}",
            "keywords": formatted,
            "total": len(formatted),
        }, indent=2)

    except RuntimeError as e:
        return f"❌ Error: {e}"
    except Exception as e:
        logger.exception("Unexpected error in bing_keyword_stats")
        return f"❌ Unexpected error: {e}"


# ─── Utility Tools ────────────────────────────────────────────────────────────

@mcp.tool()
async def refresh_google_session() -> str:
    """
    Force refresh the cached Google Chrome cookies.

    Use this if you've recently logged back in to Google in Chrome
    and GSC tools are still showing authentication errors.
    Also clears the cached XSRF token.

    No parameters required.
    """
    try:
        clear_cookie_cache()
        # Clear XSRF cache too
        from .clients.gsc_client import _xsrf_cache
        _xsrf_cache["token"] = None
        _xsrf_cache["expires"] = 0.0

        from .extractors.chrome_cookies import get_google_cookies
        cookies = get_google_cookies(force_refresh=True)
        return (
            f"✅ Google session refreshed. "
            f"Found {len(cookies)} cookies from Chrome. "
            "GSC tools are ready to use."
        )
    except RuntimeError as e:
        return f"❌ Could not refresh session: {e}"
    except Exception as e:
        return f"❌ Unexpected error: {e}"


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main() -> None:
    """Entry point for uvx / pip installation."""
    mcp.run()


if __name__ == "__main__":
    main()
