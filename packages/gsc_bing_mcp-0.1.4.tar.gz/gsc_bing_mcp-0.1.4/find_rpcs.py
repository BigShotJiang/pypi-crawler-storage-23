#!/usr/bin/env python3
"""Find GSC batchexecute RPC IDs using multiple strategies."""
import re, json, time, hashlib, subprocess, sys

try:
    import rookiepy
except ImportError:
    sys.exit("pip install rookiepy")

# --- Auth setup ---
raw = rookiepy.chrome(["google.com"])
cookies = {c["name"]: c["value"] for c in raw if c.get("name") and c.get("value")}
sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""

NAMES = {
    "SAPISID","__Secure-1PAPISID","__Secure-3PAPISID","__Secure-1PSID","__Secure-3PSID",
    "SID","HSID","SSID","APISID","OSID","NID","SIDCC",
    "__Secure-1PSIDCC","__Secure-3PSIDCC","__Secure-1PSIDTS","__Secure-3PSIDTS",
}
cookie_str = "; ".join([f"{n}={cookies[n]}" for n in NAMES if n in cookies])
ts = int(time.time())
auth = f"SAPISIDHASH {ts}_" + hashlib.sha1(f"{ts} {sapisid} https://search.google.com".encode()).hexdigest()

ORIGIN = "https://search.google.com"

BASE_HEADERS = [
    "-H", f"Cookie: {cookie_str}",
    "-H", f"Authorization: {auth}",
    "-H", f"X-Origin: {ORIGIN}",
    "-H", f"Origin: {ORIGIN}",
    "-H", f"Referer: {ORIGIN}/",
    "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "-H", "Accept-Language: en-US,en;q=0.9",
    "-H", "X-Goog-Authuser: 0",
]


def curl_get(url):
    cmd = ["curl", "-s", "-L", "--max-time", "20"] + BASE_HEADERS + [url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout


def curl_post(url, data, ct="application/x-www-form-urlencoded"):
    cmd = ["curl", "-s", "--max-time", "15", "-X", "POST",
           "-H", f"Content-Type: {ct}"] + BASE_HEADERS + ["--data-raw", data, url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout


print("=" * 60)
print("Strategy 1: Try /init endpoint (BOQ service manifest)")
print("=" * 60)
for suffix in ["", "SearchConsoleAggReportUi"]:
    url = f"{ORIGIN}/_/SearchConsoleAggReportUi/init"
    body = curl_get(url)
    print(f"  /init response ({len(body)} bytes): {body[:300]!r}")

print("\n" + "=" * 60)
print("Strategy 2: Fetch performance page JS modules")
print("=" * 60)
perf_html = curl_get(f"{ORIGIN}/search-console/performance/search-analytics")
print(f"  Performance page: {len(perf_html)} bytes, first 200: {perf_html[:200]!r}")
with open("/tmp/gsc_perf.html", "w") as f:
    f.write(perf_html)
print("  Saved to /tmp/gsc_perf.html")

# Find JS URLs on performance page
js_hrefs = re.findall(r'href="(/_/scs/mss-static/_/js/[^"]+)"', perf_html)
print(f"  JS hrefs on perf page: {len(js_hrefs)}")
for h in js_hrefs[:3]:
    print(f"    {h[:150]}")
    # Extract the module name from m= param
    m_param = re.search(r'm=([^&"]+)', h)
    if m_param:
        print(f"    modules: {m_param.group(1)}")

print("\n" + "=" * 60)
print("Strategy 3: Try batchexecute with more realistic arg formats")
print("=" * 60)
BE_URL = f"{ORIGIN}/_/SearchConsoleAggReportUi/data/batchexecute"

# Try different arg formats for GetSitesList
test_cases = [
    ("GetSitesList", "null"),
    ("GetSitesList", '"null"'),
    ("GetSitesList", '""'),
    ("GetSitesList", '"[]"'),
    ("GetSitesList", '"[[]]"'),
    # Try alternative RPC IDs that might be the actual ones
    ("SQOsUb", '"[]"'),  # guessed
    ("VHnV6b", '"[]"'),
    ("bjXljf", '"[]"'),
    ("nGNc3f", '"[]"'),
]
for rpc_id, args in test_cases:
    payload = "f.req=" + json.dumps([[[rpc_id, args, None, "1"]]])
    body = curl_post(BE_URL, payload)
    anti = ")]}\'"
    ok = anti in body[:10]
    status_hint = "200-batchexecute" if ok else "error"
    print(f"  [{rpc_id}] args={args}: {status_hint} len={len(body)} {body[:80]!r}")

print("\n" + "=" * 60)
print("Strategy 4: Look at BOQ JS bundle for the analytics module")
print("=" * 60)
# From performance page, find JS with analytics module
if js_hrefs:
    for href in js_hrefs[:3]:
        url = f"{ORIGIN}{href}"
        print(f"  Fetching: {url[:100]}")
        js = curl_get(url)
        print(f"  Size: {len(js)}")
        if len(js) > 5000:
            # Search for RPC IDs
            patterns = [
                r'"([A-Za-z0-9]{4,12})"\s*,\s*JSON\.stringify',
                r'rpcId\s*[=:]\s*"([A-Za-z0-9]{4,20})"',
                r'"([A-Za-z0-9]{4,12})"\s*,\s*null\s*,\s*"generic"',
            ]
            for p in patterns:
                found = sorted(set(re.findall(p, js)))
                if found:
                    print(f"    [{p[:40]}]: {found[:20]}")
            with open("/tmp/gsc_analytics.js", "w") as f:
                f.write(js)
            print("  Saved to /tmp/gsc_analytics.js")
            break
else:
    print("  No JS hrefs found on performance page")

print("\nDone.")
