#!/usr/bin/env python3
"""Debug script to examine GSC HTML and find where property list is stored."""

import asyncio
import re
import json
from gsc_bing_mcp.extractors.chrome_cookies import get_google_cookies
from gsc_bing_mcp.clients.gsc_client import _build_headers
import httpx

async def main():
    cookies = get_google_cookies()
    headers = _build_headers(cookies)
    
    urls_to_try = [
        "https://search.google.com/search-console/welcome",
        "https://search.google.com/search-console/properties",
        "https://search.google.com/search-console",
    ]
    
    for url in urls_to_try:
        print(f"\n{'='*60}")
        print(f"Trying: {url}")
        print('='*60)
        
        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
                resp = await client.get(url, headers=headers)
            
            print(f"Status: {resp.status_code}")
            print(f"Final URL: {resp.url}")
            print(f"HTML length: {len(resp.text)}")
            
            # Save HTML for inspection
            filename = f"gsc_page_{url.split('/')[-1] or 'root'}.html"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(resp.text)
            print(f"Saved HTML to {filename}")
            
            # Look for AF_initDataCallback patterns
            pattern = re.compile(r'AF_initDataCallback\(\{[^}]*key:\s*[\'"]([^\'"]+)[\'"][^}]*data:([^\n]+)\}\);', re.MULTILINE)
            matches = pattern.findall(resp.text)
            print(f"Found {len(matches)} AF_initDataCallback blocks")
            
            # Look for property URLs
            url_pattern = re.compile(r'(?:"|\')((?:https?://[a-zA-Z0-9\-\.]+/)|(?:sc-domain:[a-zA-Z0-9\-\.]+))(?:"|\')')
            url_matches = url_pattern.findall(resp.text)
            unique_urls = list(set(url_matches))
            print(f"Found {len(unique_urls)} unique URL patterns")
            
            # Filter out Google domains
            exclude_domains = {'google.com', 'gstatic.com', 'googleapis.com', 'googleusercontent.com',
                             'youtube.com', 'googleblog.com', 'googletagmanager.com'}
            filtered_urls = [u for u in unique_urls if not any(ex in u for ex in exclude_domains)]
            print(f"After filtering: {len(filtered_urls)} URLs")
            for u in filtered_urls[:10]:
                print(f"  {u}")
                
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
