#
# functions defining parameter distributions
#
# e.g. [inelastic mean free path weighted-] depth-dependent distribution
# of an amplitude of a peak in XPS (X-ray photoelectron spectroscopy)
