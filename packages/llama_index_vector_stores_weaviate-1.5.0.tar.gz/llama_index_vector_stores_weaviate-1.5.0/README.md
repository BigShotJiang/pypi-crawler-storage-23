# LlamaIndex Vector_Stores Integration: Weaviate
