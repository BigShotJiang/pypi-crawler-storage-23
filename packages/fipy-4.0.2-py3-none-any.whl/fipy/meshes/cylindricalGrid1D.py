from fipy.meshes.cylindricalNonUniformGrid1D import CylindricalNonUniformGrid1D
import warnings
warnings.warn("CylindricalGrid1D has been deprecated use CylindricalNonUniformGrid1D instead.", stacklevel=3)
