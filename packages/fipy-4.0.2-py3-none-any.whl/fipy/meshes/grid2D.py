from fipy.meshes.nonUniformGrid2D import NonUniformGrid2D as Grid2D
import warnings
warnings.warn("Grid2D has been deprecated use NonUniformGrid2D instead.", stacklevel=3)
