"""Sparse matrices
"""
__docformat__ = 'restructuredtext'
