"""
Macro analysis: correlations, economic indicators, sentiment.
"""

# SDK Manager interface
from .manager import MacroManager

from quantlib_pro.macro.correlation import (
    CorrelationMetrics,
    rolling_correlation,
    correlation_regime,
    compute_correlation_metrics,
    detect_correlation_breakdowns,
    correlation_contagion_score,
    eigenvalue_concentration,
    make_psd,
    simulate_correlation_shock,
    cross_asset_correlation,
    correlation_heatmap_data,
)
from quantlib_pro.macro.economic import (
    MacroRegime,
    EconomicIndicator,
    MacroSnapshot,
    detect_macro_regime,
    growth_momentum,
    inflation_gap,
    real_interest_rate,
    yield_curve_slope,
    sahm_rule_indicator,
    leading_economic_index,
    diffusion_index,
    taylor_rule_rate,
    recession_probability,
    normalize_indicator,
)
from quantlib_pro.macro.sentiment import (
    SentimentRegime,
    SentimentSnapshot,
    vix_sentiment_level,
    put_call_ratio_sentiment,
    aaii_sentiment_score,
    fear_greed_index,
    contrarian_signal,
    advance_decline_line,
    mcclellan_oscillator,
    new_high_low_ratio,
    skew_sentiment,
    vix_term_structure_slope,
    sentiment_divergence,
    aggregate_sentiment_score,
)

__all__ = [
    # Correlation
    "CorrelationMetrics",
    "rolling_correlation",
    "correlation_regime",
    "compute_correlation_metrics",
    "detect_correlation_breakdowns",
    "correlation_contagion_score",
    "eigenvalue_concentration",
    "make_psd",
    "simulate_correlation_shock",
    "cross_asset_correlation",
    "correlation_heatmap_data",
    # Economic
    "MacroRegime",
    "EconomicIndicator",
    "MacroSnapshot",
    "detect_macro_regime",
    "growth_momentum",
    "inflation_gap",
    "real_interest_rate",
    "yield_curve_slope",
    "sahm_rule_indicator",
    "leading_economic_index",
    "diffusion_index",
    "taylor_rule_rate",
    "recession_probability",
    "normalize_indicator",
    # Sentiment
    "SentimentRegime",
    "SentimentSnapshot",
    "vix_sentiment_level",
    "put_call_ratio_sentiment",
    "aaii_sentiment_score",
    "fear_greed_index",
    "contrarian_signal",
    "advance_decline_line",
    "mcclellan_oscillator",
    "new_high_low_ratio",
    "skew_sentiment",
    "vix_term_structure_slope",
    "sentiment_divergence",
    "aggregate_sentiment_score",
]
