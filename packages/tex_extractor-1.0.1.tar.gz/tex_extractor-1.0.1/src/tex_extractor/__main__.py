if __name__ == "__main__":
    from tex_extractor.cli import app
    app()