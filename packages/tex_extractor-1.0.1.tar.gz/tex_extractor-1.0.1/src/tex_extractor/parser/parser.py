from TexSoup import TexSoup
from pathlib import Path


class Parser():
    def __init__(self) -> None:
        pass

    def parse(self, input_path: str, strict_mode: bool):
        path = self._get_input_path(input_path)
        code = self._read(path)
        return TexSoup(code, tolerance=int(not strict_mode))

    def _read(self, path: Path) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _get_input_path(self, input_path) -> Path:
        path = Path(input_path)
        if not path.exists():
            raise FileNotFoundError("Input path does not exist.")
        elif path.is_file():
            if path.suffix == '.tex':
                return path
            else:
                raise ValueError("Input file should be .tex")
        elif path.is_dir():
            return self._get_path_from_dir(path)
        else:
            raise ValueError("Invalid input")

    def _get_path_from_dir(self, folder: Path) -> Path:
        def valid_tex(path): return path.is_file() and path.suffix == '.tex'
        files = [f for f in folder.iterdir() if valid_tex(f)]
        if not files:
            raise ValueError(
                "Could not find a valid .tex file within the directory.")
        elif len(files) > 1:
            names = [f.name for f in files]
            raise ValueError(
                f"Multiple .tex files detected {names}. Specify which to use.")
        else:
            return files[0]
