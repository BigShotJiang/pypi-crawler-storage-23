from TexSoup import TexNode


class Filter():
    def __init__(self) -> None:
        self._soup: TexNode

    def filter(self, soup: TexNode, title: str, author: str, sections: list[str]):
        self._soup = soup
        self._process_preamble(title, author)
        self._pick_sections(sections)

    def _get_document(self) -> TexNode:
        docclass = self._soup.find("documentclass")
        if docclass is None:
            self._soup.insert(0, r"\documentclass{article}")
        else:
            docclass.string = 'article'

        doc = self._soup.find("document")
        if doc is None:
            raise ValueError("Could not find document within .tex file.")

        return doc

    def _pick_sections(self, sections: list[str]) -> None:
        if not sections:
            raise ValueError("No sections provided.")
        doc = self._get_document()
        picked = self._soup.find_all(sections)

        # Clear
        doc.contents = []

        # Rebuild
        doc.append("\n\\maketitle\n\n")
        for sec in picked:
            doc.append(sec)
            doc.append("\n\n")

    def _process_preamble(self, title, author: str):
        if author:
            self._replace_author(author)
        if title:
            self._replace_title(title)

    def _replace_author(self, author: str):
        if self._soup.author:
            self._soup.author.string = author
        else:
            self._soup.insert(1, f"\n\\author{{{author}}}")

    def _replace_title(self, title):
        if self._soup.title:
            self._soup.title.string = title
        else:
            self._soup.insert(1, f"\n\\title{{{title}}}")
