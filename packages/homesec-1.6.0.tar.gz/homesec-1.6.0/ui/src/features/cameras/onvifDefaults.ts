export const ONVIF_DEFAULT_PORT = 80
export const ONVIF_DEFAULT_PROBE_TIMEOUT_S = 15

export const ONVIF_DEFAULT_DISCOVER_REQUEST = {
  timeout_s: 8.0,
  attempts: 2,
  ttl: 4,
} as const
