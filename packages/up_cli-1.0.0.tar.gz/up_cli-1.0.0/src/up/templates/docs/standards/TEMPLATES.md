# Document Templates

## Feature Template

```markdown
# Feature: [Name]

**Created**: YYYY-MM-DD
**Status**: 📋 Planned

---

## Overview
Brief description.

## Requirements
- Requirement 1
- Requirement 2
```
