# Folder Structure

```
docs/
├── README.md
├── roadmap/
│   ├── vision/
│   ├── phases/
│   └── sales/
├── architecture/
├── features/
├── changelog/
├── guides/
├── operations/
├── development/
├── research/
└── todo/
```
