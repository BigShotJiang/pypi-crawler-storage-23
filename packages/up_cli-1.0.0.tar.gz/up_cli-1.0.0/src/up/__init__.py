"""up - AI-powered project scaffolding CLI."""

__version__ = "1.0.0"
