# Decisions

**Purpose**: Architecture Decision Records

**Format**: `ADR-NNN-title.md`
