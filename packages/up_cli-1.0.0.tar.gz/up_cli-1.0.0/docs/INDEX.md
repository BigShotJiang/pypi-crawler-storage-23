# Documentation Index

**Updated**: 2026-02-21

> AI: Use this index to quickly find relevant documentation.

---

## Quick Reference

| Topic | File | Description |
|-------|------|-------------|
| Project State | CONTEXT.md | Current status, blockers, next steps |
| Recent Work | handoff/LATEST.md | Last session summary |
| Vision | roadmap/vision/PRODUCT_VISION.md | Product goals and target users |
| Phase 1 | roadmap/phases/PHASE_1_FOUNDATION.md | Current phase deliverables |
| Improvement Plan | roadmap/IMPROVEMENT_PLAN.md | Development roadmap |

## By Category

### Architecture
| Topic | File |
|-------|------|
| SESRC Design | architecture/SESRC_DESIGN.md |
| Integrated Lifecycle | architecture/INTEGRATED_LIFECYCLE.md |
| Multi-Worktree Execution | architecture/MULTI_WORKTREE_EXECUTION.md |

### Guides
| Topic | File |
|-------|------|
| Cursor + Claude Integration | guides/CURSOR_CLAUDE_INTEGRATION.md |

### Research & Analysis
| Topic | File |
|-------|------|
| AI Vibing Coding Approach | AI_VIBING_CODING_APPROACH.md |
| AI Programming Behavioral Analysis | AI_PROGRAMMING_BEHAVIORAL_ANALYSIS.md |
| Multi-Agent Skills Design | MULTI_AGENT_SKILLS_DESIGN.md |

---

## How to Update

When adding new docs, update this index:
1. Add entry to relevant category table
2. Keep descriptions brief (5-10 words)
3. Use relative paths
