# Research

**Purpose**: Research notes
