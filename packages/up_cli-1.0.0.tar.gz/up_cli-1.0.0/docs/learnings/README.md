# Learnings

**Purpose**: Patterns and anti-patterns discovered

**Format**: `YYYY-MM-DD-topic.md`
