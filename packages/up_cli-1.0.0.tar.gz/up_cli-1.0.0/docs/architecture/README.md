# Architecture

**Purpose**: System design docs
