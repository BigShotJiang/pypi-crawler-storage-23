# Handoff

**Purpose**: Session continuity for AI agents

**Format**: `LATEST.md`
