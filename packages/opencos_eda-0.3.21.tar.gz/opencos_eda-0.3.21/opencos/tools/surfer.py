'''Handler for: eda waves --tool=surfer'''

import os

from opencos.commands.waves import CommandWaves
from opencos.tools.vaporview import ToolVaporview

class ToolSurfer(ToolVaporview):
    '''Run Surfer the same way we'd run Vaporview - via VsCode extension

    Using ToolVaporview to reconfigure it, the extesion is selected from
    eda's CONFIG-YML config.tools.surfer (has extension name)
    '''

    _TOOL = 'surfer'
    _EXE = 'code'
    _URL = 'https://surfer-project.org/'


class CommandWavesSurfer(CommandWaves, ToolSurfer):
    '''Command handler for: eda waves --tool=surfer

    This is registerd in eda's CONFIG-YML config.tools.surfer.handlers.waves
    '''

    def __init__(self, config: dict):
        CommandWaves.__init__(self, config=config)
        ToolSurfer.__init__(self, config=self.config)

    def do_it(self) -> None:
        command_list = [
            self.waveviewer_exe, '--disable-workspace-trust', '-r', self.wave_file
        ]
        self.exec(os.path.dirname(self.wave_file), command_list)
