'''Handler for: eda waves --tool=vaporview'''

import os

from opencos.commands.waves import CommandWaves
from opencos.eda_base import Tool
from opencos.utils import vscode_helper

class ToolVaporview(Tool):
    '''Vaporview - via VsCode extension'''

    _TOOL = 'vaporview'
    _EXE = 'code'
    _URL = 'https://github.com/Lramseyer/vaporview'

    waveviewer_exe = ''

    def __init__(self, config: dict):
        super().__init__(config=config)

    def get_versions(self, **kwargs) -> str:
        if self._VERSION:
            return self._VERSION

        self._VERSION = ''

        entry = self.config.get('tools', {}).get(self._TOOL, {})
        if not entry:
            return self._VERSION

        vscode_helper.init()

        # Vaporview is via vscode, so we need to check the configuration for
        # 'requires-vscode-extension':
        if not vscode_helper.vscode_path:
            return self._VERSION

        self._EXE = vscode_helper.vscode_path
        self.waveviewer_exe = self._EXE

        if 'requires-vscode-extension' in entry:
            vscode_ext_name = entry.get('requires-vscode-extension', [''])[0]
            self._VERSION = vscode_helper.EXTENSIONS.get(vscode_ext_name)

        return self._VERSION


class CommandWavesVaporview(CommandWaves, ToolVaporview):
    '''Handling class for: eda waves --tool=vaporview

    This is registerd in eda's CONFIG-YML config.tools.vaporview.handlers.waves
    '''

    def __init__(self, config: dict):
        CommandWaves.__init__(self, config=config)
        ToolVaporview.__init__(self, config=self.config)

    def do_it(self) -> None:
        command_list = [
            self.waveviewer_exe, '--disable-workspace-trust', '-r', self.wave_file
        ]
        self.exec(os.path.dirname(self.wave_file), command_list)
