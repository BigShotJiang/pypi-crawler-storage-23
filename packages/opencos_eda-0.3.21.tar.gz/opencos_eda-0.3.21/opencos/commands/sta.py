'''opencos.commands.sta - Base class command handler for: eda sta ...

Intended to be overriden by Tool based classes
'''

import os

from opencos import util
from opencos.eda_base import CommandDesign, Tool


class CommandSta(CommandDesign):
    '''Base class command handler for: eda sta ...'''

    CHECK_REQUIRES = [Tool]
    error_on_no_files_or_targets = True
    error_on_missing_top = True

    command_name = 'sta'

    def __init__(self, config: dict):
        CommandDesign.__init__(self, config=config)
        self.args.update({
            'sta-blackbox': [],
        })
        self.defines['SYNTHESIS'] = None

    def do_it(self) -> None:
        '''Common do_it() method that child classes can use prior to customization'''

        # set_tool_defines() is from class Tool. Since that is not inherited yet, but
        # should be by any handlers like CommandSynthSlang, etc, check on the existence
        # of set_tool_defines, and error if not present.
        if not all(isinstance(self, x) for x in self.CHECK_REQUIRES):
            self.error('CommandSta.do_it() requires a Tool to be in parent classes, but none is.',
                       f'{self.CHECK_REQUIRES=}')
            return

        # add defines for this job from Tool class if present
        self.command_safe_set_tool_defines() # (Command.command_safe_set_tool_defines)

        # dump our config to work-dir for debug
        self.write_eda_config_and_args()

        # optionally export
        if self.is_export_enabled():
            self.do_export()

        # Derived classes can do the rest, can call CommandSynth.do_it(self) as a first step.

    def process_tokens(self, tokens: list, process_all: bool = True,
                       pwd: str = os.getcwd()) -> list:
        unparsed = CommandDesign.process_tokens(
            self, tokens=tokens, process_all=process_all, pwd=pwd
        )

        if self.stop_process_tokens_before_do_it():
            return unparsed

        if self.args['top']:
            # create our work dir (from self.args['top'])
            self.create_work_dir()
            self.run_dep_commands()
            self.do_it()
            self.run_post_tool_dep_commands()
        else:
            util.warning(f'CommandSta: {self.command_name=} not run due to lack of',
                         f'{self.args["top"]=} value')
        return unparsed


    def do_export(self, **kwargs) -> None:
        '''Override from Command for args in exported DEPS.yml'''
        super().do_export(
            deps_file_args=[
                '--synth',
                '--sta'
            ],
            support_export_run=False
        )
