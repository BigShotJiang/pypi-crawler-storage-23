'''
Provides class CoverageAddOn, NOT intended to be a base class, instead
as a class object that can supply additional methods to assist in coverage to Tool
or CommanDesign objects
'''

import tempfile

from opencos.eda_base import Command, Tool

class CoverageAddOn:
    '''
    Add-on class for Tool(s), adds methods and other features
    for "eda coverage" and "eda sim --tool=TOOL --coverage
    '''

    REQUIRED_HANDLER_INSTANCES: tuple = (Command, Tool)
    REQUIRED_HANDLER_METHODS: list = ['exec', 'error']
    REQUIRED_HANDLER_MEMBERS: list = ['args']

    handler_obj: object = None


    def __init__(self, handler_obj: object, **kwargs): # pylint: disable=unused-argument

        self.handler_obj = handler_obj

        assert isinstance(handler_obj, self.REQUIRED_HANDLER_INSTANCES), (
            f'{type(handler_obj)=} on CoverageAddOn constructor must be in'
            f' {self.REQUIRED_HANDLER_INSTANCES}'
        )

        for x in self.REQUIRED_HANDLER_METHODS:
            assert(hasattr(self.handler_obj, x)), \
                f'{type(self.handler_obj)=} must have method defined for "{x}"'

        for x in self.REQUIRED_HANDLER_MEMBERS:
            assert(hasattr(self.handler_obj, x)), \
                f'{type(self.handler_obj)=} must have member/varialble for "{x}"'


    def calculate_coverage_delta(self, baseline_metrics: dict, current_metrics: dict) -> dict:
        """Calculate coverage deltas between baseline and current metrics."""
        raise NotImplementedError


    def check_delta_thresholds(self, delta_metrics: dict) -> bool:
        """Calculate coverage deltas between baseline and current metrics."""


    def display_coverage_summary(self, metrics: dict) -> None:
        """Display formatted coverage summary table."""
        raise NotImplementedError

    def display_coverage_delta(self, delta_metrics: dict) -> None:
        """Display coverage delta summary in terminal with color coding."""
        raise NotImplementedError


    def find_auto_baseline(self) -> str:
        """Find the most recent baseline ACDB for auto-comparison."""
        raise NotImplementedError


    def parse_coverage_metrics(self, cov_txt_path: str) -> dict:
        """
        Parse cov.txt and return coverage metrics dict.

        Required for self._generate_coverage_json(..)
        """
        raise NotImplementedError


    def generate_baseline_report(self, acdb_path: str) -> (tempfile.TemporaryDirectory, str):
        """Generate temporary text report from ACDB file for comparison."""
        raise NotImplementedError


    def generate_coverage_json(
            self, cov_txt_path: str, json_output: str, target_name: str = ''
    ) -> None:
        """Generate structured JSON coverage report from a text coverage report."""
        raise NotImplementedError


    def generate_delta_json(
            self, delta_metrics: dict, baseline_path: str, json_output: str
    ) -> None:
        """Generate JSON report with coverage delta information."""
        raise NotImplementedError


    def save_baseline(self, acdb_path: str) -> None:
        """Save current ACDB as baseline for future comparisons."""
        raise NotImplementedError
