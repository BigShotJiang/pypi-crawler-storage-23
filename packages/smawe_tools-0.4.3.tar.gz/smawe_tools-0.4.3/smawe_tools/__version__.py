VERSION = (0, 4, 3)

version = __version__ = ".".join(map(str, VERSION))
