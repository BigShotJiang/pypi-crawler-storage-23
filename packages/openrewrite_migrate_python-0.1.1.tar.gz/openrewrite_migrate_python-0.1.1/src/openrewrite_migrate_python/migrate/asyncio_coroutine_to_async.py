"""
Recipe to migrate @asyncio.coroutine + yield from to async/await syntax.

The @asyncio.coroutine decorator was deprecated in Python 3.8 and removed in
Python 3.11. This recipe transforms:

    @asyncio.coroutine
    def my_func():
        result = yield from something()
        return result

to:

    async def my_func():
        result = await something()
        return result

See: https://docs.python.org/3/library/asyncio-task.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import Await, YieldFrom
from rewrite.java.tree import (
    Annotation,
    FieldAccess,
    Identifier,
    MethodDeclaration,
    Modifier,
    Space,
    Yield,
)
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _is_asyncio_coroutine_annotation(annotation: Annotation) -> bool:
    """Check if an annotation is @asyncio.coroutine."""
    ann_type = annotation.annotation_type
    if isinstance(ann_type, FieldAccess):
        name = ann_type.name
        target = ann_type.target
        if (isinstance(name, Identifier) and name.simple_name == "coroutine" and
            isinstance(target, Identifier) and target.simple_name == "asyncio"):
            return True
    return False


def _has_asyncio_coroutine_decorator(method: MethodDeclaration) -> bool:
    """Check if a method has the @asyncio.coroutine decorator."""
    for annotation in method.leading_annotations:
        if _is_asyncio_coroutine_annotation(annotation):
            return True
    return False


def _remove_asyncio_coroutine_decorator(method: MethodDeclaration) -> MethodDeclaration:
    """Remove the @asyncio.coroutine decorator from leading annotations."""
    new_annotations = [
        ann for ann in method.leading_annotations
        if not _is_asyncio_coroutine_annotation(ann)
    ]
    return method.replace(_leading_annotations=new_annotations)


def _add_async_modifier(method: MethodDeclaration, has_remaining_decorators: bool) -> MethodDeclaration:
    """Add the async modifier before the def modifier.

    Args:
        method: The method declaration to modify
        has_remaining_decorators: Whether the method still has decorators after removal
    """
    modifiers = list(method.modifiers)

    # Find the def modifier and get its prefix (space before 'def')
    def_index = None
    for i, mod in enumerate(modifiers):
        if mod.type == Modifier.Type.Default and mod.keyword == "def":
            def_index = i
            break

    if def_index is None:
        # No def modifier found, shouldn't happen for a valid method
        return method

    def_modifier = modifiers[def_index]

    # Determine the prefix for the async modifier:
    # - If there are remaining decorators, keep the def modifier's prefix
    #   (which has the newline after the last decorator)
    # - If no remaining decorators, use empty prefix
    #   (method prefix already has proper spacing from removed decorator)
    if has_remaining_decorators:
        async_prefix = def_modifier.prefix
    else:
        async_prefix = Space.EMPTY

    async_modifier = Modifier(
        _id=random_id(),
        _prefix=async_prefix,
        _markers=Markers.EMPTY,
        _keyword="async",
        _type=Modifier.Type.Async,
        _annotations=[],
    )

    # Update def modifier to have single space prefix
    new_def_modifier = def_modifier.replace(_prefix=Space.SINGLE_SPACE)

    # Insert async before def
    new_modifiers = modifiers[:def_index] + [async_modifier, new_def_modifier] + modifiers[def_index + 1:]

    return method.replace(_modifiers=new_modifiers)


class _YieldFromToAwaitVisitor(PythonVisitor[ExecutionContext]):
    """Visitor that transforms yield from expressions to await expressions.

    In Python's AST, 'yield from expr' is represented as:
        J.Yield(value=Py.YieldFrom(expression=expr))

    We need to replace the entire Yield with just Await(expression).
    """

    def visit_yield(
        self, yield_stmt: Yield, p: ExecutionContext
    ) -> Optional[Any]:
        yield_stmt = super().visit_yield(yield_stmt, p)

        # Check if this is a 'yield from' (Yield containing YieldFrom)
        if isinstance(yield_stmt.value, YieldFrom):
            yield_from = yield_stmt.value
            # Transform yield from expr -> await expr
            # The Await takes the Yield's prefix (space before 'yield')
            return Await(
                _id=random_id(),
                _prefix=yield_stmt.prefix,
                _markers=yield_stmt.markers,
                _expression=yield_from.expression,
                _type=yield_from.type,
            )

        return yield_stmt


@categorize(_Python311)
class MigrateAsyncioCoroutine(Recipe):
    """
    Migrate `@asyncio.coroutine` decorator to `async def` syntax.

    Transforms functions using the deprecated `@asyncio.coroutine` decorator
    and `yield from` expressions to use modern `async def` and `await` syntax.

    The `@asyncio.coroutine` decorator was deprecated in Python 3.8 and
    removed in Python 3.11.

    Example:
        Before:
            @asyncio.coroutine
            def fetch_data():
                result = yield from get_data()
                return result

        After:
            async def fetch_data():
                result = await get_data()
                return result
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.MigrateAsyncioCoroutine"

    @property
    def display_name(self) -> str:
        return "Migrate `@asyncio.coroutine` to `async def`"

    @property
    def description(self) -> str:
        return (
            "Migrate functions using the deprecated `@asyncio.coroutine` decorator "
            "to use `async def` syntax. Also transforms `yield from` to `await`. "
            "The decorator was removed in Python 3.11."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        yield_from_visitor = _YieldFromToAwaitVisitor()

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_declaration(
                self, method: MethodDeclaration, p: ExecutionContext
            ) -> Optional[MethodDeclaration]:
                method = super().visit_method_declaration(method, p)

                if not _has_asyncio_coroutine_decorator(method):
                    return method

                # Step 1: Remove the @asyncio.coroutine decorator
                method = _remove_asyncio_coroutine_decorator(method)

                # Step 2: Add async modifier to create async def
                # Check if there are remaining decorators after removal
                has_remaining_decorators = len(method.leading_annotations) > 0
                method = _add_async_modifier(method, has_remaining_decorators)

                # Step 3: Transform yield from -> await in the method body
                if method.body:
                    new_body = yield_from_visitor.visit(method.body, p)
                    method = method.replace(_body=new_body)

                return method

        return Visitor()
