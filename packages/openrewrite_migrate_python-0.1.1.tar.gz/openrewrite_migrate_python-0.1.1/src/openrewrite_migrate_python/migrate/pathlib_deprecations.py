"""
Recipes for migrating deprecated pathlib methods.

Path.link_to() was deprecated in Python 3.10 and removed in Python 3.12.
Use Path.hardlink_to() instead (note the reversed argument order).

See: https://docs.python.org/3/library/pathlib.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python312)
class FindPathlibLinkTo(Recipe):
    """
    Find usage of `Path.link_to()`.

    The `link_to()` method was deprecated in Python 3.10 and removed in
    Python 3.12. Use `hardlink_to()` instead.

    IMPORTANT: The argument order is reversed!
    - `path.link_to(target)` creates a link at target pointing to path
    - `path.hardlink_to(target)` creates a link at path pointing to target

    Example:
        Before:
            path.link_to(target)  # creates hardlink at 'target' to 'path'

        After:
            target.hardlink_to(path)  # creates hardlink at 'target' to 'path'

    Note: This recipe only detects usage because the migration requires
    swapping the caller and argument, which cannot be done automatically.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindPathlibLinkTo"

    @property
    def display_name(self) -> str:
        return "Find deprecated `Path.link_to()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `Path.link_to()` which was deprecated in Python 3.10 "
            "and removed in 3.12. Use `hardlink_to()` instead (note: argument order is reversed)."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12", "pathlib"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "link_to":
                    return method

                return _mark_deprecated(
                    method,
                    "Path.link_to() was removed in Python 3.12. "
                    "Use hardlink_to() instead (note: argument order is reversed)."
                )

        return Visitor()
