"""
Recipes for migrating deprecated array module methods.

The following methods were deprecated in Python 3.2 and removed in Python 3.14:
- array.tostring() -> array.tobytes()
- array.fromstring() -> array.frombytes()

See: https://docs.python.org/3/library/array.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.14
_Python314 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.14"),
]


@categorize(_Python314)
class ReplaceArrayTostring(Recipe):
    """
    Replace `array.tostring()` with `array.tobytes()`.

    The `tostring()` method was deprecated in Python 3.2 and removed in
    Python 3.14. Use `tobytes()` instead - they are functionally identical.

    Example:
        Before:
            data = my_array.tostring()

        After:
            data = my_array.tobytes()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceArrayTostring"

    @property
    def display_name(self) -> str:
        return "Replace `array.tostring()` with `array.tobytes()`"

    @property
    def description(self) -> str:
        return (
            "Replace `tostring()` with `tobytes()` on array objects. "
            "The tostring() method was deprecated in Python 3.2 and removed in 3.14."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14", "array"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "tostring":
                    return method

                # Replace tostring with tobytes
                new_name = method.name.replace(_simple_name="tobytes")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python314)
class ReplaceArrayFromstring(Recipe):
    """
    Replace `array.fromstring()` with `array.frombytes()`.

    The `fromstring()` method was deprecated in Python 3.2 and removed in
    Python 3.14. Use `frombytes()` instead - they are functionally identical.

    Example:
        Before:
            my_array.fromstring(data)

        After:
            my_array.frombytes(data)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceArrayFromstring"

    @property
    def display_name(self) -> str:
        return "Replace `array.fromstring()` with `array.frombytes()`"

    @property
    def description(self) -> str:
        return (
            "Replace `fromstring()` with `frombytes()` on array objects. "
            "The fromstring() method was deprecated in Python 3.2 and removed in 3.14."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14", "array"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "fromstring":
                    return method

                # Replace fromstring with frombytes
                new_name = method.name.replace(_simple_name="frombytes")
                return method.replace(_name=new_name)

        return Visitor()
