"""
Recipes for migrating langchain imports to langchain_community.

In LangChain v0.2, third-party integrations were moved from the `langchain`
package to `langchain_community`. This recipe rewrites imports like:

    from langchain.chat_models import ChatOpenAI
    from langchain.llms import OpenAI
    from langchain.embeddings import OpenAIEmbeddings

to:

    from langchain_community.chat_models import ChatOpenAI
    from langchain_community.llms import OpenAI
    from langchain_community.embeddings import OpenAIEmbeddings

See: https://python.langchain.com/v0.2/docs/versions/v0_2/
"""

from typing import Any, List, Optional, Set

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.tree import FieldAccess, Identifier

_LangChain02 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="LangChain 0.2"),
]

# Submodules that moved from langchain to langchain_community in v0.2
COMMUNITY_SUBMODULES: Set[str] = {
    "adapters",
    "agent_toolkits",
    "cache",
    "callbacks",
    "chat_loaders",
    "chat_message_histories",
    "chat_models",
    "cross_encoders",
    "docstore",
    "document_compressors",
    "document_loaders",
    "document_transformers",
    "embeddings",
    "example_selectors",
    "graph_vectorstores",
    "graphs",
    "llms",
    "retrievers",
    "storage",
    "tools",
    "utilities",
    "vectorstores",
}


def _get_root_and_first_submodule(from_part: Any) -> tuple:
    """Extract root module name and first submodule from a FieldAccess chain.

    For 'langchain.chat_models': returns ('langchain', 'chat_models')
    For 'langchain.chat_models.openai': returns ('langchain', 'chat_models')
    """
    if not isinstance(from_part, FieldAccess):
        return None, None

    current = from_part
    while isinstance(current.target, FieldAccess):
        current = current.target

    if isinstance(current.target, Identifier):
        return current.target.simple_name, current.name.simple_name
    return None, None


def _replace_root_module(from_part: Any, new_root_name: str) -> Any:
    """Replace the root module name in a FieldAccess chain."""
    if isinstance(from_part, Identifier):
        return from_part.replace(_simple_name=new_root_name)
    if isinstance(from_part, FieldAccess):
        new_target = _replace_root_module(from_part.target, new_root_name)
        return from_part.replace(_target=new_target)
    return from_part


@categorize(_LangChain02)
class ReplaceLangchainCommunityImports(Recipe):
    """
    Replace `langchain` integration imports with `langchain_community`.

    In LangChain v0.2, third-party integrations were split out of the main
    `langchain` package into `langchain_community`. This recipe rewrites
    imports like `from langchain.chat_models import X` to
    `from langchain_community.chat_models import X`.

    Example:
        Before:
            from langchain.chat_models import ChatOpenAI

        After:
            from langchain_community.chat_models import ChatOpenAI
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.ReplaceLangchainCommunityImports"

    @property
    def display_name(self) -> str:
        return "Replace `langchain` imports with `langchain_community`"

    @property
    def description(self) -> str:
        return (
            "Migrate third-party integration imports from `langchain` to "
            "`langchain_community`. These integrations were moved in "
            "LangChain v0.2."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "0.2"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is None:
                    return multi

                root_name, first_sub = _get_root_and_first_submodule(from_part)
                if root_name != "langchain":
                    return multi

                if first_sub not in COMMUNITY_SUBMODULES:
                    return multi

                new_from = _replace_root_module(from_part, "langchain_community")
                old_padded_from = multi.padding.from_
                if old_padded_from is None:
                    return multi
                new_padded_from = old_padded_from.replace(_element=new_from)
                return multi.padding.replace(_from=new_padded_from)

        return Visitor()
