"""Composite recipe for upgrading to LangChain 1.0."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToLangChain1(Recipe):
    """
    Migrate to LangChain 1.0.

    This composite recipe applies all necessary migrations for code using
    earlier versions of LangChain to be compatible with LangChain 1.0.

    Key changes in LangChain 1.0:
    - Legacy chains, retrievers, and indexes moved to `langchain_classic`
    - `create_react_agent` renamed to `create_agent`
    - `initialize_agent`, `AgentExecutor`, `LLMChain` deprecated
    - `hub` module moved to `langchain_classic`

    See: https://docs.langchain.com/oss/python/migrate/langchain-v1
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.UpgradeToLangChain1"

    @property
    def display_name(self) -> str:
        return "Upgrade to LangChain 1.0"

    @property
    def description(self) -> str:
        return (
            "Migrate to LangChain 1.0 by applying all v0.2 migrations and "
            "then moving legacy functionality to `langchain_classic`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "1.0"]

    def recipe_list(self) -> List[Recipe]:
        from .langchain_classic_imports import (
            FindDeprecatedLangchainAgents,
            ReplaceLangchainClassicImports,
            FindLangchainCreateReactAgent,
        )
        from .upgrade_to_langchain02 import UpgradeToLangChain02

        return [
            # First apply all v0.2 migrations
            UpgradeToLangChain02(),
            # Move legacy modules to langchain_classic
            ReplaceLangchainClassicImports(),
            # Rename create_react_agent to create_agent
            FindLangchainCreateReactAgent(),
            # Flag deprecated agent patterns
            FindDeprecatedLangchainAgents(),
        ]
