"""
Recipes for migrating deprecated cgi module parse functions.

The following functions were deprecated in Python 3.2 and removed in Python 3.8:
- cgi.parse_qs() -> urllib.parse.parse_qs()
- cgi.parse_qsl() -> urllib.parse.parse_qsl()

Note: cgi.escape() -> html.escape() is handled in cgi_migrations.py.

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python38)
class FindCgiParseQs(Recipe):
    """
    Find usages of removed `cgi.parse_qs()`.

    `cgi.parse_qs()` was deprecated in Python 3.2 and removed in Python 3.8.
    Use `urllib.parse.parse_qs()` instead.

    Example:
        Before:
            import cgi
            params = cgi.parse_qs(query_string)

        After:
            from urllib.parse import parse_qs
            params = parse_qs(query_string)

    Note: This is a search recipe because the import change is non-trivial.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindCgiParseQs"

    @property
    def display_name(self) -> str:
        return "Find removed `cgi.parse_qs()` usage"

    @property
    def description(self) -> str:
        return (
            "`cgi.parse_qs()` was removed in Python 3.8. "
            "Use `urllib.parse.parse_qs()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "cgi"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "parse_qs":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "cgi":
                    return method

                return _mark_deprecated(
                    method,
                    "cgi.parse_qs() was removed in Python 3.8. "
                    "Use urllib.parse.parse_qs() instead."
                )

        return Visitor()


@categorize(_Python38)
class FindCgiParseQsl(Recipe):
    """
    Find usages of removed `cgi.parse_qsl()`.

    `cgi.parse_qsl()` was deprecated in Python 3.2 and removed in Python 3.8.
    Use `urllib.parse.parse_qsl()` instead.

    Example:
        Before:
            import cgi
            params = cgi.parse_qsl(query_string)

        After:
            from urllib.parse import parse_qsl
            params = parse_qsl(query_string)

    Note: This is a search recipe because the import change is non-trivial.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindCgiParseQsl"

    @property
    def display_name(self) -> str:
        return "Find removed `cgi.parse_qsl()` usage"

    @property
    def description(self) -> str:
        return (
            "`cgi.parse_qsl()` was removed in Python 3.8. "
            "Use `urllib.parse.parse_qsl()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "cgi"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "parse_qsl":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "cgi":
                    return method

                return _mark_deprecated(
                    method,
                    "cgi.parse_qsl() was removed in Python 3.8. "
                    "Use urllib.parse.parse_qsl() instead."
                )

        return Visitor()
