"""
Recipes for migrating deprecated configparser module features.

configparser.SafeConfigParser was deprecated in Python 3.2 and removed in Python 3.12.
The replacement is configparser.ConfigParser.

configparser.readfp() was deprecated in Python 3.2 and removed in Python 3.13.
The replacement is configparser.read_file().

See: https://docs.python.org/3/library/configparser.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, FieldAccess, MethodInvocation

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _is_configparser_attribute(field_access: FieldAccess, attr_name: str) -> bool:
    """
    Check if this is a configparser.attr_name access.

    Matches patterns like:
    - configparser.SafeConfigParser
    - configparser.ConfigParser
    """
    if not isinstance(field_access.name, Identifier):
        return False
    if field_access.name.simple_name != attr_name:
        return False

    # Check if the target is 'configparser'
    target = field_access.target
    if isinstance(target, Identifier) and target.simple_name == "configparser":
        return True

    return False


def _replace_configparser_attribute(field_access: FieldAccess, new_name: str) -> FieldAccess:
    """
    Replace the attribute name in a configparser.X field access.

    Changes configparser.SafeConfigParser to configparser.ConfigParser, etc.
    """
    old_name = field_access.name
    if not isinstance(old_name, Identifier):
        return field_access

    new_identifier = old_name.replace(_simple_name=new_name)
    return field_access.padding.replace(
        name=field_access.padding.name.replace(element=new_identifier)
    )


def _is_configparser_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is a method call on a ConfigParser instance.

    Since we can't always determine the type of the receiver, we check:
    1. Method name matches
    2. Type attribution if available
    3. Common variable names like 'config', 'parser', 'cfg', 'cp'
    """
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    # Check if type info confirms this is a configparser method
    if method.method_type and method.method_type.declaring_type:
        dt = method.method_type.declaring_type
        if hasattr(dt, '_fully_qualified_name'):
            fqn = str(dt._fully_qualified_name)
            if 'configparser' in fqn.lower() or 'ConfigParser' in fqn:
                return True

    # Fallback: Check for common ConfigParser variable names
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier):
        name = select.simple_name.lower()
        # Common names for ConfigParser instances
        if name in ('config', 'parser', 'cfg', 'cp', 'conf', 'configparser', 'safe_parser'):
            return True

    return False


def _rename_method(method: MethodInvocation, new_name: str) -> MethodInvocation:
    """Rename a method invocation."""
    old_name = method.name
    if not isinstance(old_name, Identifier):
        return method

    new_identifier = old_name.replace(_simple_name=new_name)
    return method.replace(_name=new_identifier)


def _is_configparser_constructor(method: MethodInvocation, class_name: str) -> bool:
    """
    Check if this is a configparser.ClassName() constructor call.

    Matches patterns like:
    - configparser.SafeConfigParser()
    - configparser.ConfigParser()
    """
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != class_name:
        return False

    # Check if the select is 'configparser'
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "configparser":
        return True

    return False


@categorize(_Python312)
class ReplaceConfigparserSafeConfigParser(Recipe):
    """
    Replace `configparser.SafeConfigParser` with `configparser.ConfigParser`.

    The `SafeConfigParser` class was deprecated in Python 3.2 (it was renamed to
    `ConfigParser`) and removed in Python 3.12. The `ConfigParser` class now
    includes all the safety features that were previously only in `SafeConfigParser`.

    Example:
        Before:
            import configparser
            config = configparser.SafeConfigParser()

        After:
            import configparser
            config = configparser.ConfigParser()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceConfigparserSafeConfigParser"

    @property
    def display_name(self) -> str:
        return "Replace `configparser.SafeConfigParser` with `ConfigParser`"

    @property
    def description(self) -> str:
        return (
            "The `configparser.SafeConfigParser` class was deprecated in Python 3.2 and "
            "removed in Python 3.12. Replace with `configparser.ConfigParser`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Handle configparser.SafeConfigParser() constructor calls
                if _is_configparser_constructor(method, "SafeConfigParser"):
                    return _rename_method(method, "ConfigParser")

                return method

            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                # Handle configparser.SafeConfigParser as a value (without calling)
                if _is_configparser_attribute(field_access, "SafeConfigParser"):
                    return _replace_configparser_attribute(field_access, "ConfigParser")

                return field_access

        return Visitor()


@categorize(_Python313)
class ReplaceConfigparserReadfp(Recipe):
    """
    Replace `ConfigParser.readfp()` with `ConfigParser.read_file()`.

    The `readfp()` method was deprecated in Python 3.2 and removed in Python 3.13.
    The replacement `read_file()` has the same signature and behavior.

    Example:
        Before:
            import configparser
            config = configparser.ConfigParser()
            with open('config.ini') as f:
                config.readfp(f)

        After:
            import configparser
            config = configparser.ConfigParser()
            with open('config.ini') as f:
                config.read_file(f)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceConfigparserReadfp"

    @property
    def display_name(self) -> str:
        return "Replace `ConfigParser.readfp()` with `read_file()`"

    @property
    def description(self) -> str:
        return (
            "The `ConfigParser.readfp()` method was deprecated in Python 3.2 and "
            "removed in Python 3.13. Replace with `read_file()`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_configparser_method(method, "readfp"):
                    return _rename_method(method, "read_file")

                return method

        return Visitor()
