"""
Recipes for migrating deprecated socket module functions.

socket.create_connection() with no timeout is deprecated since Python 3.10
when passed a server_hostname argument without an ssl context.

socket.setdefaulttimeout() affects all new sockets which can cause issues.

See: https://docs.python.org/3/library/socket.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python311)
class FindSocketGetFQDN(Recipe):
    """
    Find usage of `socket.getfqdn()`.

    The `socket.getfqdn()` function can be slow and unreliable, especially
    on systems without proper DNS configuration. Consider using
    `socket.gethostname()` if you only need the local hostname.

    Note: This is more of a code quality check than a deprecation warning.
    The function is not deprecated but can cause issues.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSocketGetFQDN"

    @property
    def display_name(self) -> str:
        return "Find `socket.getfqdn()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `socket.getfqdn()` which can be slow and "
            "unreliable. Consider using `socket.gethostname()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "socket"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getfqdn":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "socket":
                    return method

                return _mark_deprecated(
                    method,
                    "socket.getfqdn() can be slow and unreliable. "
                    "Consider using socket.gethostname() instead."
                )

        return Visitor()
