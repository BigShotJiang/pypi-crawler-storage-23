"""
Recipe for migrating typing.Callable to collections.abc.Callable.

PEP 585 (Python 3.9+) deprecated typing.Callable in favor of
collections.abc.Callable:

- typing.Callable[[int], str] -> collections.abc.Callable[[int], str]

See: https://peps.python.org/pep-0585/
"""

from typing import Any, Optional, Set

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.tree import FieldAccess, Identifier, Import

# Define category path
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python39)
class ReplaceTypingCallableWithCollectionsAbcCallable(Recipe):
    """
    Find and migrate `typing.Callable` to `collections.abc.Callable`.

    PEP 585 deprecated `typing.Callable` in Python 3.9. Use
    `collections.abc.Callable` instead for type annotations.

    Example:
        Before:
            from typing import Callable
            handler: Callable[[int], str] = lambda x: str(x)

        After:
            from collections.abc import Callable
            handler: Callable[[int], str] = lambda x: str(x)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingCallableWithCollectionsAbcCallable"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Callable` with `collections.abc.Callable`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Callable` in Python 3.9. "
            "Replace with `collections.abc.Callable` for type annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def __init__(self):
                super().__init__()
                self._has_typing_callable_import = False
                self._has_typing_star_import = False

            def visit_multi_import(self, multi_import: MultiImport, p: ExecutionContext):
                """Track 'from typing import Callable' imports."""
                from_ = multi_import.from_
                if isinstance(from_, Identifier) and from_.simple_name == "typing":
                    for imp in multi_import.names:
                        qualid = imp.qualid
                        if isinstance(qualid, FieldAccess):
                            name = qualid.name
                            if isinstance(name, Identifier) and name.simple_name == "Callable":
                                self._has_typing_callable_import = True
                        elif isinstance(qualid, Identifier) and qualid.simple_name == "Callable":
                            self._has_typing_callable_import = True
                return super().visit_multi_import(multi_import, p)

            def visit_import(self, import_node: Import, p: ExecutionContext):
                """Track 'import typing' imports."""
                qualid = import_node.qualid
                if isinstance(qualid, Identifier) and qualid.simple_name == "typing":
                    self._has_typing_star_import = True
                elif isinstance(qualid, FieldAccess):
                    name = qualid.name
                    if isinstance(name, Identifier) and name.simple_name == "typing":
                        self._has_typing_star_import = True
                return super().visit_import(import_node, p)

            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "Callable" and self._has_typing_callable_import:
                    # Skip identifiers that are part of import statements
                    if not self._is_in_import(identifier):
                        return _mark_deprecated(
                            identifier,
                            "typing.Callable is deprecated",
                            "Replace with collections.abc.Callable (PEP 585)"
                        )

                return identifier

            def visit_field_access(self, field_access: FieldAccess, p: ExecutionContext):
                """Handle typing.Callable qualified access."""
                field_access = super().visit_field_access(field_access, p)

                if self._has_typing_star_import:
                    name = field_access.name
                    target = field_access.target
                    if (isinstance(name, Identifier) and name.simple_name == "Callable" and
                            isinstance(target, Identifier) and target.simple_name == "typing"):
                        marked_name = _mark_deprecated(
                            name,
                            "typing.Callable is deprecated",
                            "Replace with collections.abc.Callable (PEP 585)"
                        )
                        return field_access.replace(
                            _name=field_access.padding.name.replace(_element=marked_name)
                        )

                return field_access

            def _is_in_import(self, identifier: Identifier) -> bool:
                """Check if the identifier is inside an import statement."""
                cursor = self.cursor
                while cursor is not None:
                    value = cursor.value
                    if isinstance(value, (Import, MultiImport)):
                        return True
                    cursor = cursor.parent
                return False

        return Visitor()
