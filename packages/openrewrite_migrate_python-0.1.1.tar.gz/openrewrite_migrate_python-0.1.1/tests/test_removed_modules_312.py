"""Tests for finding modules removed in Python 3.12."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.removed_modules_312 import (
    FindRemovedModules312,
)


class TestFindRemovedModules312:
    """Tests for the FindRemovedModules312 recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_asynchat(self):
        """Test that 'import asynchat' is found and marked."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                import asynchat
                """,
                """
                /*~~(Module 'asynchat' was removed in Python 3.12. Use `asyncio` instead.)~~>*/import asynchat
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_asyncore(self):
        """Test that 'import asyncore' is found and marked."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                import asyncore
                """,
                """
                /*~~(Module 'asyncore' was removed in Python 3.12. Use `asyncio` instead.)~~>*/import asyncore
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_smtpd(self):
        """Test that 'import smtpd' is found and marked."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                import smtpd
                """,
                """
                /*~~(Module 'smtpd' was removed in Python 3.12. Use `aiosmtpd` instead.)~~>*/import smtpd
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_from_asyncore_import(self):
        """Test that 'from asyncore import dispatcher' is found and marked."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                from asyncore import dispatcher
                """,
                """
                /*~~(Module 'asyncore' was removed in Python 3.12. Use `asyncio` instead.)~~>*/from asyncore import dispatcher
                """,
            )
        )

    def test_no_change_for_standard_modules(self):
        """Test that standard library modules like os and sys are not marked."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                import os
                import sys
                from collections import defaultdict
                """
            )
        )

    def test_no_change_for_pep594_modules(self):
        """Test that PEP 594 modules (removed in 3.13, not 3.12) are NOT matched."""
        spec = RecipeSpec(recipe=FindRemovedModules312())
        spec.rewrite_run(
            python(
                """
                import cgi
                import telnetlib
                import aifc
                """
            )
        )
