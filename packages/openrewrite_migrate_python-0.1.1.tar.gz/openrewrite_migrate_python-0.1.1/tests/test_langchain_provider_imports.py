"""Tests for LangChain provider package import migration recipe."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.langchain_provider_imports import (
    ReplaceLangchainProviderImports,
)


class TestReplaceLangchainProviderImports:
    """Tests for the ReplaceLangchainProviderImports recipe."""

    # --- OpenAI provider ---

    def test_replaces_chat_openai(self):
        """Test that ChatOpenAI import is migrated to langchain_openai."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatOpenAI
                """,
                """
                from langchain_openai import ChatOpenAI
                """,
            )
        )

    def test_replaces_openai_llm(self):
        """Test that OpenAI LLM import is migrated to langchain_openai."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.llms import OpenAI
                """,
                """
                from langchain_openai import OpenAI
                """,
            )
        )

    def test_replaces_openai_embeddings(self):
        """Test that OpenAIEmbeddings import is migrated to langchain_openai."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.embeddings import OpenAIEmbeddings
                """,
                """
                from langchain_openai import OpenAIEmbeddings
                """,
            )
        )

    def test_replaces_multiple_openai_imports(self):
        """Test that multiple OpenAI imports from same module are migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatOpenAI, AzureChatOpenAI
                """,
                """
                from langchain_openai import ChatOpenAI, AzureChatOpenAI
                """,
            )
        )

    # --- Anthropic provider ---

    def test_replaces_chat_anthropic(self):
        """Test that ChatAnthropic import is migrated to langchain_anthropic."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatAnthropic
                """,
                """
                from langchain_anthropic import ChatAnthropic
                """,
            )
        )

    # --- Pinecone provider ---

    def test_replaces_pinecone(self):
        """Test that Pinecone vectorstore is migrated to langchain_pinecone."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.vectorstores import Pinecone
                """,
                """
                from langchain_pinecone import Pinecone
                """,
            )
        )

    # --- Chroma provider ---

    def test_replaces_chroma(self):
        """Test that Chroma vectorstore is migrated to langchain_chroma."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.vectorstores import Chroma
                """,
                """
                from langchain_chroma import Chroma
                """,
            )
        )

    # --- HuggingFace provider ---

    def test_replaces_huggingface_embeddings(self):
        """Test that HuggingFaceEmbeddings is migrated to langchain_huggingface."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.embeddings import HuggingFaceEmbeddings
                """,
                """
                from langchain_huggingface import HuggingFaceEmbeddings
                """,
            )
        )

    # --- Ollama provider ---

    def test_replaces_chat_ollama(self):
        """Test that ChatOllama import is migrated to langchain_ollama."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatOllama
                """,
                """
                from langchain_ollama import ChatOllama
                """,
            )
        )

    # --- AWS provider ---

    def test_replaces_chat_bedrock(self):
        """Test that ChatBedrock import is migrated to langchain_aws."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatBedrock
                """,
                """
                from langchain_aws import ChatBedrock
                """,
            )
        )

    # --- Groq provider ---

    def test_replaces_chat_groq(self):
        """Test that ChatGroq import is migrated to langchain_groq."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatGroq
                """,
                """
                from langchain_groq import ChatGroq
                """,
            )
        )

    # --- Negative cases ---

    def test_no_change_for_unknown_class(self):
        """Test that unknown classes in langchain_community are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatCustomProvider
                """
            )
        )

    def test_no_change_for_non_community_import(self):
        """Test that non-community imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_core.messages import HumanMessage
                """
            )
        )

    def test_no_change_for_already_provider(self):
        """Test that provider package imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_openai import ChatOpenAI
                """
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_flags_mixed_provider_imports(self):
        """Test that mixed-provider imports are flagged for manual migration."""
        spec = RecipeSpec(recipe=ReplaceLangchainProviderImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatOpenAI, ChatAnthropic
                """,
                """
                /*~~(Split this import across provider packages: langchain_anthropic, langchain_openai)~~>*/from langchain_community.chat_models import ChatOpenAI, ChatAnthropic
                """,
            )
        )
