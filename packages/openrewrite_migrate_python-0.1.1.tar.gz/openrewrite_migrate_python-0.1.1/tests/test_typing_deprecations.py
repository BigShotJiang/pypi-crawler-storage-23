"""Tests for typing deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.typing_deprecations import (
    ReplaceTypingText,
)


class TestReplaceTypingText:
    """Tests for the ReplaceTypingText recipe."""

    def test_replaces_typing_text(self):
        """Test that typing.Text is replaced with str."""
        spec = RecipeSpec(recipe=ReplaceTypingText())
        spec.rewrite_run(
            python(
                """
                from typing import Text
                name: Text = "hello"
                """,
                """
                from typing import Text
                name: str = "hello"
                """,
            )
        )

    def test_no_change_when_str(self):
        """Test that str is not changed."""
        spec = RecipeSpec(recipe=ReplaceTypingText())
        spec.rewrite_run(
            python(
                """
                name: str = "hello"
                """
            )
        )
