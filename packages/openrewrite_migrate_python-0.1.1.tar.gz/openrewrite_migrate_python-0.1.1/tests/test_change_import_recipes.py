"""Tests for ChangeImport-based recipes in upgrade recipes.

These test the 'from X import Y' pattern handled by ChangeImport,
ensuring that import statement rewrites work correctly for the
specific configurations used in the composite upgrade recipes.
"""

from rewrite.python.recipes import ChangeImport
from rewrite.test import RecipeSpec, python


class TestChangeImportCrossModule:
    """Tests for 'from X import Y' where the module changes but name stays the same.

    These patterns are fully handled by ChangeImport.
    """

    def test_replaces_from_cgi_import_escape(self):
        """Python 3.8: from cgi import escape -> from html import escape."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="cgi", old_name="escape", new_module="html")
        )
        spec.rewrite_run(
            python(
                "from cgi import escape\nescape(user_input)",
                "from html import escape\nescape(user_input)",
            )
        )

    def test_replaces_from_fractions_import_gcd(self):
        """Python 3.9: from fractions import gcd -> from math import gcd."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="fractions", old_name="gcd", new_module="math")
        )
        spec.rewrite_run(
            python(
                "from fractions import gcd\ngcd(12, 8)",
                "from math import gcd\ngcd(12, 8)",
            )
        )

    def test_replaces_from_imp_import_reload(self):
        """Python 3.12: from imp import reload -> from importlib import reload."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="imp", old_name="reload", new_module="importlib")
        )
        spec.rewrite_run(
            python(
                "from imp import reload\nreload(my_module)",
                "from importlib import reload\nreload(my_module)",
            )
        )


class TestChangeImportSameModuleRename:
    """Tests for 'from X import Y' where the module stays the same but name changes."""

    def test_replaces_from_time_import_clock(self):
        """Python 3.8: from time import clock -> from time import perf_counter."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="time", old_name="clock", new_module="time", new_name="perf_counter")
        )
        spec.rewrite_run(
            python(
                "from time import clock\nclock()",
                "from time import perf_counter\nperf_counter()",
            )
        )

    def test_replaces_from_base64_import_encodestring(self):
        """Python 3.9: from base64 import encodestring -> from base64 import encodebytes."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="base64", old_name="encodestring", new_module="base64", new_name="encodebytes")
        )
        spec.rewrite_run(
            python(
                "from base64 import encodestring\nencodestring(data)",
                "from base64 import encodebytes\nencodebytes(data)",
            )
        )

    def test_replaces_from_base64_import_decodestring(self):
        """Python 3.9: from base64 import decodestring -> from base64 import decodebytes."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="base64", old_name="decodestring", new_module="base64", new_name="decodebytes")
        )
        spec.rewrite_run(
            python(
                "from base64 import decodestring\ndecodestring(data)",
                "from base64 import decodebytes\ndecodebytes(data)",
            )
        )

    def test_replaces_from_sys_import_getcheckinterval(self):
        """Python 3.9: from sys import getcheckinterval -> from sys import getswitchinterval."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="sys", old_name="getcheckinterval", new_module="sys", new_name="getswitchinterval")
        )
        spec.rewrite_run(
            python(
                "from sys import getcheckinterval\ngetcheckinterval()",
                "from sys import getswitchinterval\ngetswitchinterval()",
            )
        )

    def test_replaces_from_sys_import_setcheckinterval(self):
        """Python 3.9: from sys import setcheckinterval -> from sys import setswitchinterval."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="sys", old_name="setcheckinterval", new_module="sys", new_name="setswitchinterval")
        )
        spec.rewrite_run(
            python(
                "from sys import setcheckinterval\nsetcheckinterval(100)",
                "from sys import setswitchinterval\nsetswitchinterval(100)",
            )
        )

    def test_replaces_from_inspect_import_getargspec(self):
        """Python 3.11: from inspect import getargspec -> from inspect import getfullargspec."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="inspect", old_name="getargspec", new_module="inspect", new_name="getfullargspec")
        )
        spec.rewrite_run(
            python(
                "from inspect import getargspec\ngetargspec(my_func)",
                "from inspect import getfullargspec\ngetfullargspec(my_func)",
            )
        )

    def test_replaces_from_logging_import_warn(self):
        """Python 3.11: from logging import warn -> from logging import warning."""
        spec = RecipeSpec(
            recipe=ChangeImport(old_module="logging", old_name="warn", new_module="logging", new_name="warning")
        )
        spec.rewrite_run(
            python(
                "from logging import warn\nwarn('Something happened')",
                "from logging import warning\nwarning('Something happened')",
            )
        )
