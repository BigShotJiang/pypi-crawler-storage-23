"""Tests for Thread.isAlive() deprecation migration recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.threading_is_alive_deprecation import (
    ReplaceThreadIsAlive,
)


class TestReplaceThreadIsAlive:
    """Tests for ReplaceThreadIsAlive recipe."""

    def test_replaces_isAlive(self):
        spec = RecipeSpec(recipe=ReplaceThreadIsAlive())
        spec.rewrite_run(
            python(
                "alive = thread.isAlive()",
                "alive = thread.is_alive()",
            )
        )

    def test_no_change_when_already_is_alive(self):
        spec = RecipeSpec(recipe=ReplaceThreadIsAlive())
        spec.rewrite_run(
            python("alive = thread.is_alive()")
        )

    def test_no_change_when_different_method(self):
        spec = RecipeSpec(recipe=ReplaceThreadIsAlive())
        spec.rewrite_run(
            python("thread.start()")
        )
