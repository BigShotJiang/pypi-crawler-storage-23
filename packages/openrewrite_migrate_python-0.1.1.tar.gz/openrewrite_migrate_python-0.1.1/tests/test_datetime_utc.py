"""Tests for datetime UTC migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.datetime_utc import (
    ReplaceDatetimeUtcNow,
    ReplaceDatetimeUtcFromTimestamp,
)


class TestReplaceDatetimeUtcNow:
    """Tests for the ReplaceDatetimeUtcNow recipe."""

    def test_replaces_datetime_utcnow(self):
        """Test that datetime.utcnow() is replaced with datetime.now(datetime.UTC)."""
        spec = RecipeSpec(recipe=ReplaceDatetimeUtcNow())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                now = datetime.utcnow()
                """,
                """
                from datetime import datetime
                now = datetime.now(datetime.UTC)
                """,
            )
        )

    def test_no_change_when_regular_now(self):
        """Test that datetime.now() is not marked."""
        spec = RecipeSpec(recipe=ReplaceDatetimeUtcNow())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                now = datetime.now()
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that utcnow on a different object is not marked."""
        spec = RecipeSpec(recipe=ReplaceDatetimeUtcNow())
        spec.rewrite_run(
            python(
                """
                class MyClass:
                    def utcnow(self):
                        return "not datetime"

                obj = MyClass()
                result = obj.utcnow()
                """
            )
        )


class TestReplaceDatetimeUtcFromTimestamp:
    """Tests for the ReplaceDatetimeUtcFromTimestamp recipe."""

    def test_replaces_datetime_utcfromtimestamp(self):
        """Test that datetime.utcfromtimestamp() is replaced with datetime.fromtimestamp(ts, datetime.UTC)."""
        spec = RecipeSpec(recipe=ReplaceDatetimeUtcFromTimestamp())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                dt = datetime.utcfromtimestamp(1234567890)
                """,
                """
                from datetime import datetime
                dt = datetime.fromtimestamp(1234567890, datetime.UTC)
                """,
            )
        )

    def test_no_change_when_regular_fromtimestamp(self):
        """Test that datetime.fromtimestamp() is not marked."""
        spec = RecipeSpec(recipe=ReplaceDatetimeUtcFromTimestamp())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                dt = datetime.fromtimestamp(1234567890)
                """
            )
        )
