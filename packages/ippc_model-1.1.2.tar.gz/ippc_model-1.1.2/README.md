# IPPC Data Model

[![PyPI version](https://img.shields.io/pypi/v/ippc-model.svg)](https://pypi.org/project/ippc-model/)
[![Python](https://img.shields.io/pypi/pyversions/ippc-model.svg)](https://pypi.org/project/ippc-model/)
[![License: AGPL v3](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)

Pydantic v2 datový model pro systém **Integrovaného povolení a kontroly znečišťování (IPPC)**
dle zákona č. 76/2002 Sb. a směrnice IED (2010/75/EU).

Vyvinuto společností [SYSNET s.r.o.](https://www.sysnet.cz)

---

## Co projekt řeší

**IPPC Data Model** je Python knihovna poskytující typovaný, validovaný datový model
pro informační systém IPPC. Pokrývá celý životní cyklus řízení – od žádosti o integrované
povolení přes kontroly a zprávy o plnění až po ukončení provozu nebo sloučení zařízení.

Slouží jako sdílená datová vrstva pro aplikace (FastAPI, ETL pipeline, CLI nástroje)
komunikující s registrem IPPC.

---

## Instalace

```bash
pip install ippc-model
```

---

## Rychlý start

```python
from ippc_model import (
    ContainerType, EquipmentType, DocumentType, ActivityType, ExpertType,
    IppcDocCodeEnum, IppcStatusEnum,
)
from sysnet_pyutils.models.general import MetadataType

# Vytvoření kontejneru řízení s primárním identifikátorem
container = ContainerType(
    name="Výroba obuvnických podešví (PUR-PLASTICS s.r.o.)",
    metadata=MetadataType(uuid="550e8400-e29b-41d4-a716-446655440000"),
)
print(container.metadata.uuid)   # → '550e8400-e29b-41d4-a716-446655440000'

# Kódy typů dokumentů
print(IppcDocCodeEnum.REQUEST.value)    # → 'request'
print(IppcDocCodeEnum.DECISION.value)   # → 'decision'
print(IppcDocCodeEnum.MERGED.value)     # → 'merged'

# Serializace / deserializace (Pydantic v2)
data = container.model_dump()
container2 = ContainerType.model_validate(data)
```

---

## Závislosti

| Balíček | Verze | Účel |
|---|---|---|
| `pydantic` | `~2.11.7` | Validace dat, typový systém |
| `sysnet-pyutils` | `>=1.7.2` | Sdílené základní typy SYSNET |

---

## Přehled modulů

| Modul | Hlavní třídy | Popis |
|---|---|---|
| `ippc_common` | `IppcDocCodeEnum`, `IppcStatusEnum`, `PermittingType`, `InspectionType`, … | Výčty, sdílené typy, konstanty, helper funkce |
| `ippc_activity` | `ActivityType`, `ActivityListType`, `ActivityViewItemType` | Kategorie zařízení (příloha č. 1 zák. 76/2002) |
| `ippc_equipment` | `EquipmentType`, `EquipmentMigration`, `EquipmentReporting` | Zařízení podléhající režimu IPPC |
| `ippc_container` | `ContainerType`, `ContainerTypeLight`, `ContainerListType` | Kontejnery dokumentů – jedno řízení |
| `ippc_document` | `DocumentType`, `DocumentEntryType`, `DocumentListType` | Dokumenty řízení |
| `ippc_expert` | `ExpertType`, `ExpertTypeBase`, `ExpertListType` | Odborně způsobilé osoby (OZO) |

Všechny veřejné symboly jsou dostupné přímo z balíčku:

```python
from ippc_model import ContainerType, IppcDocCodeEnum, PROCEEDING_TRANSITION
```

---

## Konvence identifikátorů

Každý hlavní datový objekt ukládá primární identifikátor do `metadata.uuid`:

```python
obj.metadata.uuid  # str (UUID4) – platí pro všechny hlavní typy
```

---

## Životní cyklus řízení

Knihovna pokrývá všechny fáze IPPC řízení:

| Fáze | Kódy dokumentů (`IppcDocCodeEnum`) |
|---|---|
| Zahájení | `request` |
| Průběh | `summarize`, `statement`, `statement-cenia`, `decision`, `re-decision` |
| Odvolání | `appeal`, `appdec`, `appeal-result` |
| Změny IP | `change`, `minorchange`, `exceptions`, `exemption` |
| Kontroly a zprávy | `report-check`, `report-review`, `report-conditions` |
| Provoz | `validate`, `interrupted`, `resumed`, `additional` |
| Ukončení | `terminated`, `closed`, `canceled`, `merged`, `xchg-company` |

---

## Instalace pro vývoj

```bash
git clone https://github.com/SYSNET-CZ/models.git
cd models/ippc

python -m venv .venv
.venv\Scripts\activate       # Windows
# source .venv/bin/activate  # Linux / macOS

pip install -e ".[dev]"
```

Spuštění testů:

```bash
# Windows
.venv\Scripts\python.exe -m pytest tests/ -v

# Linux / macOS
.venv/bin/python -m pytest tests/ -v
```

---

## Licence

GNU Affero General Public License v3 – viz [LICENSE](LICENSE).

© SYSNET s.r.o. | [https://www.sysnet.cz](https://www.sysnet.cz)
