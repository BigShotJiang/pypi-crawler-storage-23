#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testy pro ippc_model.ippc_common:
- get_dict_value_rtf
- get_dict_value_uuid
- get_dict_value_regional
- PROCEEDING_TRANSITION vs DOC_PROCEEDING
- instantiace společných datových typů
"""
import uuid

import pytest

from ippc_model.ippc_common import (
    get_dict_value_rtf,
    get_dict_value_uuid,
    get_dict_value_regional,
    DOC_PROCEEDING,
    PROCEEDING_TRANSITION,
    IppcDocCodeEnum,
    IppcStatusEnum,
    IppcWorkflowType,
    PermittingType,
    PermittingItemType,
    InspectionType,
    InspectionItemType,
    ReportType,
    ReportItemType,
    ValidationType,
    ValidationItemType,
    ChangeOperator,
    MergeEquipment,
)


# ---------------------------------------------------------------------------
# get_dict_value_rtf
# ---------------------------------------------------------------------------

class TestGetDictValueRtf:

    def test_string_returned_as_is(self):
        """Řetězec nesmí být obalený extra uvozovkami (BUG-002)."""
        result = get_dict_value_rtf({'k': 'hello'}, 'k')
        assert result == 'hello'

    def test_dict_serialized_to_json(self):
        result = get_dict_value_rtf({'k': {'a': 1}}, 'k')
        assert result == '{"a": 1}'

    def test_none_returns_none(self):
        assert get_dict_value_rtf({'k': None}, 'k') is None

    def test_missing_key_returns_none(self):
        assert get_dict_value_rtf({}, 'k') is None

    def test_zero_not_treated_as_none(self):
        """Hodnota 0 je platná – nesmí vrátit None (BUG-003)."""
        result = get_dict_value_rtf({'k': 0}, 'k')
        assert result == '0'

    def test_false_not_treated_as_none(self):
        """Hodnota False je platná – nesmí vrátit None (BUG-003)."""
        result = get_dict_value_rtf({'k': False}, 'k')
        assert result == 'false'

    def test_empty_string_not_treated_as_none(self):
        """Prázdný řetězec je platná hodnota – nesmí vrátit None (BUG-003)."""
        result = get_dict_value_rtf({'k': ''}, 'k')
        assert result == ''

    def test_list_serialized_to_json(self):
        result = get_dict_value_rtf({'k': [1, 2, 3]}, 'k')
        assert result == '[1, 2, 3]'


# ---------------------------------------------------------------------------
# get_dict_value_uuid
# ---------------------------------------------------------------------------

class TestGetDictValueUuid:

    def test_valid_uuid_returned_normalized(self):
        uid = str(uuid.uuid4())
        result = get_dict_value_uuid({'k': uid}, 'k')
        assert result == uid

    def test_valid_uuid_uppercase_normalized(self):
        uid = str(uuid.uuid4()).upper()
        result = get_dict_value_uuid({'k': uid}, 'k')
        assert result == uid.lower()

    def test_invalid_uuid_returns_none(self):
        assert get_dict_value_uuid({'k': 'not-a-uuid'}, 'k') is None

    def test_none_returns_none(self):
        assert get_dict_value_uuid({'k': None}, 'k') is None

    def test_missing_key_returns_none(self):
        assert get_dict_value_uuid({}, 'k') is None


# ---------------------------------------------------------------------------
# get_dict_value_regional
# ---------------------------------------------------------------------------

class TestGetDictValueRegional:

    def test_list_of_strings_converted(self):
        # get_dict_value_list vrací seznam jako jednoprvkový seznam
        # se stringovou reprezentací – chování sysnet_pyutils
        result = get_dict_value_regional({'k': ['a', 'b']}, 'k')
        assert result is not None
        assert len(result) >= 1

    def test_none_returns_none(self):
        assert get_dict_value_regional({'k': None}, 'k') is None

    def test_missing_key_returns_none(self):
        assert get_dict_value_regional({}, 'k') is None

    def test_empty_list_returns_none(self):
        # get_dict_value_list vrací [] pro prázdný seznam → not [] je True → None
        assert get_dict_value_regional({'k': []}, 'k') is None


# ---------------------------------------------------------------------------
# PROCEEDING_TRANSITION vs DOC_PROCEEDING (BUG-006)
# ---------------------------------------------------------------------------

class TestProceedingTransition:

    def test_all_doc_proceeding_in_transition(self):
        """Každý kód z DOC_PROCEEDING musí mít záznam v PROCEEDING_TRANSITION."""
        missing = [d for d in DOC_PROCEEDING if d not in PROCEEDING_TRANSITION]
        assert missing == [], f'Chybí v PROCEEDING_TRANSITION: {missing}'

    def test_merged_in_transition(self):
        """IppcDocCodeEnum.MERGED musí být v PROCEEDING_TRANSITION (BUG-006)."""
        assert IppcDocCodeEnum.MERGED in PROCEEDING_TRANSITION

    def test_transition_values_have_required_keys(self):
        """Každý záznam přechodu musí mít klíče node_name a status_to."""
        for code, val in PROCEEDING_TRANSITION.items():
            assert 'node_name' in val, f'{code}: chybí node_name'
            assert 'status_to' in val, f'{code}: chybí status_to'


# ---------------------------------------------------------------------------
# Instantiace a serializace společných typů
# ---------------------------------------------------------------------------

class TestPermittingType:

    def test_default_instantiation(self):
        p = PermittingType()
        assert p.published is False
        assert p.date_executed is None

    def test_model_dump_round_trip(self):
        p = PermittingType(published=True, bat_id='BAT-123')
        d = p.model_dump()
        p2 = PermittingType.model_validate(d)
        assert p2.published is True
        assert p2.bat_id == 'BAT-123'

    def test_alias_fields_are_independent(self):
        """Aliasová pole (date_decided atd.) jsou nezávislá na date_executed."""
        from datetime import datetime
        dt = datetime(2024, 1, 1)
        p = PermittingType(date_decided=dt)
        assert p.date_decided == dt
        assert p.date_executed is None

    def test_valid_date_order(self):
        """date_legal >= date_initiated je validní."""
        from datetime import datetime
        p = PermittingType(
            date_initiated=datetime(2023, 1, 1),
            date_legal=datetime(2024, 6, 1),
        )
        assert p.date_legal > p.date_initiated

    def test_invalid_date_order_raises(self):
        """date_legal < date_initiated musí vyvolat ValidationError."""
        from datetime import datetime
        import pytest
        from pydantic import ValidationError
        with pytest.raises(ValidationError, match='date_legal'):
            PermittingType(
                date_initiated=datetime(2024, 6, 1),
                date_legal=datetime(2023, 1, 1),
            )

    def test_invalid_date_executed_raises(self):
        """date_executed < date_initiated musí vyvolat ValidationError."""
        from datetime import datetime
        import pytest
        from pydantic import ValidationError
        with pytest.raises(ValidationError, match='date_executed'):
            PermittingType(
                date_initiated=datetime(2024, 6, 1),
                date_executed=datetime(2023, 1, 1),
            )

    def test_none_dates_skip_validation(self):
        """Chybějící data nemají být validována."""
        p = PermittingType(date_initiated=None, date_legal=None)
        assert p.date_initiated is None


class TestPermittingItemType:

    def test_documents_field(self):
        from sysnet_pyutils.models.general import LinkedType
        p = PermittingItemType(documents=[LinkedType(title='Doc1')])
        assert len(p.documents) == 1
        assert p.documents[0].title == 'Doc1'


class TestInspectionType:

    def test_default_instantiation(self):
        i = InspectionType()
        assert i.finished is None
        assert i.check_type is None

    def test_review_type_enum(self):
        from ippc_model.ippc_common import ReviewTypeEnum
        i = InspectionType(check_type=ReviewTypeEnum.PLANNED)
        assert i.check_type == ReviewTypeEnum.PLANNED

    def test_valid_date_order(self):
        """date_check_end >= date_check_start je validní."""
        from datetime import datetime
        i = InspectionType(
            date_check_start=datetime(2024, 1, 1),
            date_check_end=datetime(2024, 3, 31),
        )
        assert i.date_check_end > i.date_check_start

    def test_same_day_ok(self):
        """Jednodenní kontrola (start == end) je validní."""
        from datetime import datetime
        dt = datetime(2024, 6, 15)
        i = InspectionType(date_check_start=dt, date_check_end=dt)
        assert i.date_check_start == i.date_check_end

    def test_invalid_date_order_raises(self):
        """date_check_end < date_check_start musí vyvolat ValidationError."""
        from datetime import datetime
        from pydantic import ValidationError
        with pytest.raises(ValidationError, match='date_check_end'):
            InspectionType(
                date_check_start=datetime(2024, 6, 1),
                date_check_end=datetime(2024, 1, 1),
            )

    def test_none_dates_skip_validation(self):
        """Chybějící data nemají být validována."""
        i = InspectionType(date_check_start=None, date_check_end=None)
        assert i.date_check_start is None


class TestReportType:

    def test_complied_field(self):
        r = ReportType(complied=True)
        assert r.complied is True


class TestValidationType:

    def test_default_instantiation(self):
        v = ValidationType()
        assert v.delivered is None


class TestChangeOperator:

    def test_default_instantiation(self):
        c = ChangeOperator()
        assert c.operator_from is None
        assert c.operator_to is None


class TestMergeEquipment:

    def test_default_instantiation(self):
        m = MergeEquipment()
        assert m.equipment_source is None
        assert m.equipment_merged is None


class TestIppcWorkflowType:

    def test_status_enum_fields(self):
        wf = IppcWorkflowType(
            status_from=IppcStatusEnum.STATUS_1,
            status_to=IppcStatusEnum.STATUS_2,
        )
        assert wf.status_from == IppcStatusEnum.STATUS_1
        assert wf.status_to == IppcStatusEnum.STATUS_2

    def test_default_instantiation(self):
        wf = IppcWorkflowType()
        assert wf.status_from is None
        assert wf.status_to is None
