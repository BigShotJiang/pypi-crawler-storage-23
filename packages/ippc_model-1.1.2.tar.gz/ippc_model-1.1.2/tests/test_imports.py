#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testy veřejného API balíčku ippc_model:
- přímé importy ze všech podmodulů
- re-exporty z __init__.py (BUG-009)
- __all__ kompletnost
"""
import pytest


class TestDirectImports:
    """Všechny veřejné třídy musí být importovatelné přímo z podmodulů."""

    def test_import_activity(self):
        from ippc_model.ippc_activity import (
            ActivityTypeBase, ActivityType, ActivityListType, ActivityViewItemType,
        )

    def test_import_container(self):
        from ippc_model.ippc_container import (
            ContainerTypeSuperBase, ContainerTypeBase, ContainerTypeListItem,
            ContainerTypeLight, ContainerListType, ContainerType,
        )

    def test_import_document(self):
        from ippc_model.ippc_document import (
            DocumentTypeBase, DocumentType, DocumentEntryType, DocumentListType,
        )

    def test_import_equipment(self):
        from ippc_model.ippc_equipment import (
            EquipmentOtherInfo, EquipmentReportingBase, EquipmentReporting,
            EquipmentMigration, EquipmentTypeBase, EquipmentType, EquipmentListType,
        )

    def test_import_expert(self):
        from ippc_model.ippc_expert import (
            ExpertMigration, ExpertTypeBase, ExpertType, ExpertListType,
        )

    def test_import_common_enums(self):
        from ippc_model.ippc_common import (
            IppcDocCodeEnum, IppcAdditionalTypeEnum, IppcStatusEnum, IppcContainerEnum,
            ActivityStatusEnum, EquipmentStatusEnum, ReviewTypeEnum,
            DataObjectsEnum, DataFormatEnum,
        )

    def test_import_common_types(self):
        from ippc_model.ippc_common import (
            IppcWorkflowType,
            PermittingType, PermittingItemType,
            InspectionType, InspectionItemType,
            ReportType, ReportItemType,
            ValidationType, ValidationItemType,
            ChangeOperator, MergeEquipment,
        )

    def test_import_common_constants(self):
        from ippc_model.ippc_common import (
            DOC_CREATES_CONTAINER, DOC_PROCEEDING, DOC_DOCUMENTATION,
            CONTAINER_TITLES, PROCEEDING_TRANSITION,
        )

    def test_import_common_functions(self):
        from ippc_model.ippc_common import (
            get_dict_value_regional, get_dict_value_uuid, get_dict_value_rtf,
        )


class TestPackageImports:
    """Všechny symboly musí být dostupné přímo z ippc_model (BUG-009)."""

    def test_activity_classes(self):
        from ippc_model import ActivityTypeBase, ActivityType, ActivityListType, ActivityViewItemType

    def test_container_classes(self):
        from ippc_model import (
            ContainerTypeSuperBase, ContainerTypeBase, ContainerTypeListItem,
            ContainerTypeLight, ContainerListType, ContainerType,
        )

    def test_document_classes(self):
        from ippc_model import DocumentTypeBase, DocumentType, DocumentEntryType, DocumentListType

    def test_equipment_classes(self):
        from ippc_model import (
            EquipmentOtherInfo, EquipmentReportingBase, EquipmentReporting,
            EquipmentMigration, EquipmentTypeBase, EquipmentType, EquipmentListType,
        )

    def test_expert_classes(self):
        from ippc_model import ExpertMigration, ExpertTypeBase, ExpertType, ExpertListType

    def test_common_enums(self):
        from ippc_model import (
            IppcDocCodeEnum, IppcAdditionalTypeEnum, IppcStatusEnum, IppcContainerEnum,
            ActivityStatusEnum, EquipmentStatusEnum, ReviewTypeEnum,
            DataObjectsEnum, DataFormatEnum,
        )

    def test_common_types(self):
        from ippc_model import (
            IppcWorkflowType,
            PermittingType, PermittingItemType,
            InspectionType, InspectionItemType,
            ReportType, ReportItemType,
            ValidationType, ValidationItemType,
            ChangeOperator, MergeEquipment,
        )

    def test_common_constants(self):
        from ippc_model import (
            DOC_CREATES_CONTAINER, DOC_PROCEEDING, DOC_DOCUMENTATION,
            CONTAINER_TITLES, PROCEEDING_TRANSITION,
        )

    def test_common_functions(self):
        from ippc_model import get_dict_value_regional, get_dict_value_uuid, get_dict_value_rtf


class TestAllCompleteness:
    """__all__ musí obsahovat všechny re-exportované symboly."""

    def test_all_defined(self):
        import ippc_model
        assert hasattr(ippc_model, '__all__')
        assert len(ippc_model.__all__) > 0

    def test_all_symbols_importable(self):
        """Každý symbol v __all__ musí být skutečně dostupný v balíčku."""
        import ippc_model
        for name in ippc_model.__all__:
            assert hasattr(ippc_model, name), f'__all__ obsahuje {name}, ale symbol není dostupný'

    def test_key_classes_in_all(self):
        import ippc_model
        for name in [
            'ContainerType', 'EquipmentType', 'DocumentType', 'ActivityType', 'ExpertType',
            'IppcDocCodeEnum', 'IppcStatusEnum', 'PROCEEDING_TRANSITION',
            'get_dict_value_rtf', 'get_dict_value_uuid',
        ]:
            assert name in ippc_model.__all__, f'{name} chybí v __all__'
