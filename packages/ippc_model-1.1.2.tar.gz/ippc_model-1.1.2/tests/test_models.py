#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testy instantiace, serializace a dědičnosti datových modelů:
- ActivityType, ActivityTypeBase, ActivityListType
- ContainerType a hierarchie
- DocumentType, DocumentEntryType
- EquipmentType a hierarchie
- ExpertType a hierarchie
"""
import uuid

import pytest
from sysnet_pyutils.models.general import MetadataType, MetadataTypeBase, LinkedType


# ---------------------------------------------------------------------------
# ActivityType
# ---------------------------------------------------------------------------

class TestActivityType:

    def test_default_instantiation(self):
        from ippc_model.ippc_activity import ActivityType
        from ippc_model.ippc_common import ActivityStatusEnum
        a = ActivityType()
        assert a.status == ActivityStatusEnum.AC_NEW
        assert a.metadata is None

    def test_metadata_uuid_accessible(self):
        from ippc_model.ippc_activity import ActivityType
        uid = str(uuid.uuid4())
        a = ActivityType(metadata=MetadataType(uuid=uid))
        assert a.metadata.uuid == uid

    def test_model_dump_round_trip(self):
        from ippc_model.ippc_activity import ActivityType
        a = ActivityType(code='1.1', value_cz='Spalování')
        d = a.model_dump()
        a2 = ActivityType.model_validate(d)
        assert a2.code == '1.1'
        assert a2.value_cz == 'Spalování'

    def test_hidden_default_false(self):
        from ippc_model.ippc_activity import ActivityType
        a = ActivityType()
        assert a.hidden is False


class TestActivityListType:

    def test_empty_list(self):
        from ippc_model.ippc_activity import ActivityListType
        al = ActivityListType()
        assert al.hits == 0
        assert al.entries is None

    def test_with_entries(self):
        from ippc_model.ippc_activity import ActivityListType, ActivityType
        al = ActivityListType(hits=1, entries=[ActivityType(code='1.1')])
        assert al.hits == 1
        assert len(al.entries) == 1

    def test_entries_description_not_empty(self):
        from ippc_model.ippc_activity import ActivityListType
        desc = ActivityListType.model_fields['entries'].description
        assert desc and len(desc) > 0


class TestActivityViewItemType:

    def test_default_counts(self):
        from ippc_model.ippc_activity import ActivityViewItemType
        av = ActivityViewItemType()
        assert av.count_container == 0
        assert av.count_equipment == 0
        assert av.count_expert == 0


# ---------------------------------------------------------------------------
# ContainerType hierarchie
# ---------------------------------------------------------------------------

class TestContainerHierarchy:

    def test_container_type_has_metadata(self):
        from ippc_model.ippc_container import ContainerType
        assert 'metadata' in ContainerType.model_fields

    def test_container_type_metadata_uuid(self):
        """ContainerType.metadata.uuid musí být dostupné (BUG-001)."""
        from ippc_model.ippc_container import ContainerType
        uid = str(uuid.uuid4())
        c = ContainerType(metadata=MetadataType(uuid=uid))
        assert c.metadata.uuid == uid

    def test_container_list_item_metadata_uuid(self):
        """ContainerTypeListItem.metadata.uuid dostupné přes MetadataTypeBase."""
        from ippc_model.ippc_container import ContainerTypeListItem
        uid = str(uuid.uuid4())
        cli = ContainerTypeListItem(metadata=MetadataTypeBase(uuid=uid))
        assert cli.metadata.uuid == uid

    def test_container_type_default_instantiation(self):
        from ippc_model.ippc_container import ContainerType
        from ippc_model.ippc_common import IppcContainerEnum
        c = ContainerType()
        assert c.content_type == IppcContainerEnum.PROCEEDING
        assert c.international is False
        assert c.metadata is None

    def test_container_type_model_dump(self):
        from ippc_model.ippc_container import ContainerType
        uid = str(uuid.uuid4())
        c = ContainerType(
            name='Test kontejner',
            metadata=MetadataType(uuid=uid),
        )
        d = c.model_dump()
        assert d['name'] == 'Test kontejner'
        assert d['metadata']['uuid'] == uid

    def test_container_list_type_entries_description(self):
        from ippc_model.ippc_container import ContainerListType
        desc = ContainerListType.model_fields['entries'].description
        assert desc and len(desc) > 0

    def test_container_type_no_commented_metadata_lines(self):
        """Zakomentované řádky # MetadataType / # MetadataTypeBase nesmí být v souboru."""
        import pathlib
        src = pathlib.Path(
            r'D:\development\git\models\ippc\ippc_model\ippc_container.py'
        ).read_text(encoding='utf-8')
        assert '# MetadataType\n' not in src
        assert '# MetadataTypeBase\n' not in src


class TestContainerListType:

    def test_empty(self):
        from ippc_model.ippc_container import ContainerListType
        cl = ContainerListType()
        assert cl.hits == 0
        assert cl.entries is None


# ---------------------------------------------------------------------------
# DocumentType
# ---------------------------------------------------------------------------

class TestDocumentType:

    def test_default_instantiation(self):
        from ippc_model.ippc_document import DocumentType
        d = DocumentType()
        assert d.metadata is None
        assert d.doc_code is None

    def test_metadata_uuid(self):
        from ippc_model.ippc_document import DocumentType
        uid = str(uuid.uuid4())
        d = DocumentType(metadata=MetadataType(uuid=uid))
        assert d.metadata.uuid == uid

    def test_model_dump_round_trip(self):
        from ippc_model.ippc_document import DocumentType
        from ippc_model.ippc_common import IppcDocCodeEnum
        d = DocumentType(doc_code=IppcDocCodeEnum.REQUEST, title='Žádost o IP')
        d2 = DocumentType.model_validate(d.model_dump())
        assert d2.doc_code == IppcDocCodeEnum.REQUEST
        assert d2.title == 'Žádost o IP'


class TestDocumentEntryType:

    def test_alias_field(self):
        """doc_code má alias 'data-code' – model_validate musí fungovat."""
        from ippc_model.ippc_document import DocumentEntryType
        de = DocumentEntryType.model_validate({'data-code': 'request', 'title': 'Test'})
        assert de.doc_code.value == 'request'
        assert de.title == 'Test'

    def test_populate_by_name(self):
        """doc_code musí jít načíst i přes název pole (populate_by_name=True)."""
        from ippc_model.ippc_document import DocumentEntryType
        from ippc_model.ippc_common import IppcDocCodeEnum
        de = DocumentEntryType.model_validate({'doc_code': 'decision', 'title': 'Rozhodnutí'})
        assert de.doc_code == IppcDocCodeEnum.DECISION

    def test_model_dump_by_alias(self):
        from ippc_model.ippc_document import DocumentEntryType
        de = DocumentEntryType.model_validate({'data-code': 'request'})
        d = de.model_dump(by_alias=True)
        assert 'data-code' in d

    def test_model_dump_by_name(self):
        """model_dump bez aliasu musí vrátit klíč doc_code."""
        from ippc_model.ippc_document import DocumentEntryType
        de = DocumentEntryType.model_validate({'data-code': 'request'})
        d = de.model_dump(by_alias=False)
        assert 'doc_code' in d

    def test_default_instantiation(self):
        from ippc_model.ippc_document import DocumentEntryType
        de = DocumentEntryType()
        assert de.doc_code is None


class TestDocumentListType:

    def test_entries_description(self):
        from ippc_model.ippc_document import DocumentListType
        desc = DocumentListType.model_fields['entries'].description
        assert desc and len(desc) > 0


# ---------------------------------------------------------------------------
# EquipmentType
# ---------------------------------------------------------------------------

class TestEquipmentMigrationStatus:

    def test_default_status_new(self):
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration()
        assert m.status == EquipmentStatusEnum.EQ_NEW

    def test_authorized_gives_active(self):
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration(is_authorized=True)
        assert m.status == EquipmentStatusEnum.EQ_ACTIVE

    def test_merged_overrides_authorized(self):
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration(is_authorized=True, is_merged=True)
        assert m.status == EquipmentStatusEnum.EQ_MERGED

    def test_closed_overrides_merged(self):
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration(is_merged=True, is_closed=True)
        assert m.status == EquipmentStatusEnum.EQ_CLOSED

    def test_exempted_overrides_closed(self):
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration(is_closed=True, is_exempted=True)
        assert m.status == EquipmentStatusEnum.EQ_EXCLUDED

    def test_from_user_id_description(self):
        """from_user_id nesmí mít popis From_userEmail (BUG-004)."""
        from ippc_model.ippc_equipment import EquipmentMigration
        desc = EquipmentMigration.model_fields['from_user_id'].description
        assert desc == 'From_userId'
        assert desc != 'From_userEmail'

    def test_status_in_model_dump(self):
        """computed_field status musí být součástí model_dump()."""
        from ippc_model.ippc_equipment import EquipmentMigration
        from ippc_model.ippc_common import EquipmentStatusEnum
        m = EquipmentMigration(is_authorized=True)
        d = m.model_dump()
        assert 'status' in d
        assert d['status'] == EquipmentStatusEnum.EQ_ACTIVE


class TestEquipmentType:

    def test_default_instantiation(self):
        from ippc_model.ippc_equipment import EquipmentType
        e = EquipmentType()
        assert e.metadata is None
        assert e.merged is False
        assert e.authorized is False

    def test_metadata_uuid(self):
        from ippc_model.ippc_equipment import EquipmentType
        uid = str(uuid.uuid4())
        e = EquipmentType(metadata=MetadataType(uuid=uid))
        assert e.metadata.uuid == uid

    def test_model_dump_round_trip(self):
        from ippc_model.ippc_equipment import EquipmentType
        e = EquipmentType(title='Testovací zařízení', name='Test')
        e2 = EquipmentType.model_validate(e.model_dump())
        assert e2.title == 'Testovací zařízení'

    def test_entries_description(self):
        from ippc_model.ippc_equipment import EquipmentListType
        desc = EquipmentListType.model_fields['entries'].description
        assert desc and len(desc) > 0


# ---------------------------------------------------------------------------
# ExpertType
# ---------------------------------------------------------------------------

class TestExpertMigration:

    def test_files_is_list(self):
        """files musí být Optional[List[str]], ne str (BUG-005)."""
        from ippc_model.ippc_expert import ExpertMigration
        import typing
        ann = ExpertMigration.model_fields['files'].annotation
        # annotation je Optional[List[str]]
        args = typing.get_args(ann)
        assert list in args or any(
            typing.get_origin(a) is list for a in args
        )

    def test_files_description(self):
        """files nesmí mít popis Body (BUG-005)."""
        from ippc_model.ippc_expert import ExpertMigration
        desc = ExpertMigration.model_fields['files'].description
        assert desc == 'Přílohy'
        assert desc != 'Body'

    def test_files_accepts_list(self):
        from ippc_model.ippc_expert import ExpertMigration
        m = ExpertMigration(files=['priloha1.pdf', 'priloha2.pdf'])
        assert len(m.files) == 2

    def test_annotation_and_files_have_different_descriptions(self):
        from ippc_model.ippc_expert import ExpertMigration
        desc_ann = ExpertMigration.model_fields['annotation'].description
        desc_files = ExpertMigration.model_fields['files'].description
        assert desc_ann != desc_files


class TestExpertTypeBase:

    def test_emails_field_exists(self):
        """emails (List[EmailStr]) musí existovat (BUG-007)."""
        from ippc_model.ippc_expert import ExpertTypeBase
        assert 'emails' in ExpertTypeBase.model_fields

    def test_email_field_not_overridden(self):
        """email z PersonCoreType musí zůstat jako EmailStr, ne List (BUG-007)."""
        from ippc_model.ippc_expert import ExpertTypeBase
        from sysnet_pyutils.models.general import PersonCoreType
        ann_base = PersonCoreType.model_fields['email'].annotation
        ann_expert = ExpertTypeBase.model_fields['email'].annotation
        assert ann_base == ann_expert

    def test_emails_accepts_list(self):
        from ippc_model.ippc_expert import ExpertTypeBase
        e = ExpertTypeBase(emails=['test@example.com', 'other@example.com'])
        assert len(e.emails) == 2

    def test_date_validity_future_ok(self):
        """Budoucí datum platnosti je validní bez varování."""
        from ippc_model.ippc_expert import ExpertTypeBase
        from datetime import date, timedelta
        import warnings
        future = date.today() + timedelta(days=365)
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            e = ExpertTypeBase(date_validity=future)
        assert e.date_validity == future

    def test_date_validity_past_warns(self):
        """Datum platnosti v minulosti vyvolá UserWarning (ne chybu)."""
        from ippc_model.ippc_expert import ExpertTypeBase
        from datetime import date, timedelta
        import warnings
        past = date.today() - timedelta(days=1)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            e = ExpertTypeBase(date_validity=past)
        assert e.date_validity == past
        assert any(issubclass(w.category, UserWarning) for w in caught)

    def test_date_validity_past_record_accepted(self):
        """Historický záznam OZO musí být přijat i přes varování."""
        from ippc_model.ippc_expert import ExpertTypeBase
        from datetime import date
        import warnings
        old = date(2010, 1, 1)
        with warnings.catch_warnings(record=True):
            warnings.simplefilter('always')
            e = ExpertTypeBase(date_validity=old)
        assert e.date_validity == old


class TestExpertType:

    def test_default_instantiation(self):
        from ippc_model.ippc_expert import ExpertType
        e = ExpertType()
        assert e.metadata is None
        assert e.migration is None

    def test_metadata_uuid(self):
        from ippc_model.ippc_expert import ExpertType
        uid = str(uuid.uuid4())
        e = ExpertType(metadata=MetadataType(uuid=uid))
        assert e.metadata.uuid == uid

    def test_model_dump_round_trip(self):
        from ippc_model.ippc_expert import ExpertType
        e = ExpertType(name='Jan Novák')
        e2 = ExpertType.model_validate(e.model_dump())
        assert e2.name == 'Jan Novák'

    def test_entries_description(self):
        from ippc_model.ippc_expert import ExpertListType
        desc = ExpertListType.model_fields['entries'].description
        assert desc and len(desc) > 0
