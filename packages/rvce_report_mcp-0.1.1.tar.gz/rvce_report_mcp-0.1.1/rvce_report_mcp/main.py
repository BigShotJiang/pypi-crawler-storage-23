"""
Main entry point for the RVCE Report MCP Server.
Mirrors the architecture of word_document_server/main.py exactly.
Supports stdio, sse, and streamable-http transports via FastMCP.
"""

import os
import sys
from dotenv import load_dotenv

load_dotenv()
os.environ.setdefault("FASTMCP_LOG_LEVEL", "INFO")

from fastmcp import FastMCP
from mcp.types import ToolAnnotations

from rvce_report_mcp.tools import template_tools, report_tools, section_tools


def get_transport_config() -> dict:
    config = {
        "transport": "stdio",
        "host": "0.0.0.0",
        "port": 8001,
        "path": "/mcp",
        "sse_path": "/sse",
    }
    transport = os.getenv("RVCE_MCP_TRANSPORT", os.getenv("MCP_TRANSPORT", "stdio")).lower()
    valid_transports = ["stdio", "streamable-http", "sse"]
    if transport not in valid_transports:
        print(f"Warning: Invalid transport '{transport}'. Falling back to 'stdio'.")
        transport = "stdio"
    config["transport"] = transport
    config["host"] = os.getenv("RVCE_MCP_HOST", os.getenv("MCP_HOST", config["host"]))
    config["port"] = int(os.getenv("PORT", os.getenv("RVCE_MCP_PORT", os.getenv("MCP_PORT", config["port"]))))
    config["path"] = os.getenv("RVCE_MCP_PATH", os.getenv("MCP_PATH", config["path"]))
    config["sse_path"] = os.getenv("RVCE_MCP_SSE_PATH", os.getenv("MCP_SSE_PATH", config["sse_path"]))
    return config


def setup_logging(debug_mode: bool) -> None:
    import logging
    if debug_mode:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )
    else:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )


# Initialise FastMCP server
mcp = FastMCP(
    name="rvce-report-generator",
    instructions=(
        "Generates RVCE Experiential Learning reports as two docx files. "
        "Workflow: inspect_pretoc_template → generate_pretoc_pages → create_rvce_report. "
        "User attaches project folder, pastes desired TOC, and the LLM extracts "
        "content from project files to build the report automatically."
    )
)

_tools_registered = False


def register_tools() -> None:
    global _tools_registered
    if _tools_registered:
        return
    _tools_registered = True

    """Register all tools with the MCP server."""

    # -----------------------------------------------------------------------
    # Template tools
    # -----------------------------------------------------------------------

    @mcp.tool(annotations=ToolAnnotations(title="Read Template", readOnlyHint=True))
    def read_template(template_path: str, report_type: str = "el_report"):
        """
        Read a sample RVCE DOCX and extract its FormatProfile (heading styles,
        body font, header/footer structure, page margins). The profile is cached
        and used by create_rvce_report when template_path is provided.

        Args:
            template_path: Absolute path to the sample DOCX file.
            report_type: "el_report" (default) or "project_report".
        """
        return template_tools.read_template(template_path, report_type)

    @mcp.tool(annotations=ToolAnnotations(title="Inspect Template", readOnlyHint=True))
    def inspect_template(template_path: str):
        """
        Return a paragraph-by-paragraph dump of a DOCX file showing style name,
        font, size, bold, alignment, and text preview for every paragraph.
        Use to verify what read_template will detect.

        Args:
            template_path: Absolute path to the DOCX file.
        """
        return template_tools.inspect_template(template_path)

    # -----------------------------------------------------------------------
    # Report tools
    # -----------------------------------------------------------------------

    @mcp.tool(annotations=ToolAnnotations(title="Inspect Pre-TOC Template", readOnlyHint=True))
    def inspect_pretoc_template(template_path: str = None):
        """
        Check which [token] placeholders exist in the pre-TOC template.

        Call this FIRST before generate_pretoc_pages. If status is "error",
        the template file is missing from assets/ and the user must place
        pre_toc_template.docx there before proceeding.

        Args:
            template_path: Optional path to the pre-TOC template .docx.
                           Defaults to rvce_report_mcp/assets/pre_toc_template.docx.
        """
        return report_tools.inspect_pretoc_template(template_path)

    @mcp.tool(annotations=ToolAnnotations(title="Generate Pre-TOC Pages", destructiveHint=True))
    def generate_pretoc_pages(
        output_path: str,
        project_context: str,
        template_path: str = None,
    ):
        """
        Fill the pre-TOC template (cover, certificate, declaration pages)
        with project details and save as a separate docx file.

        Call ORDER: inspect_pretoc_template → generate_pretoc_pages → create_rvce_report

        Required project_context fields:
          project_title, sdg_theme, academic_year, faculty_mentor.name,
          faculty_mentor.designation, faculty_mentor.department,
          team (list of {name, usn, dept, email}, max 5 members)

        Output: output/report_pretoc.docx — pages 1-3 of the final report.
        Never modifies the template file.

        Args:
            output_path: Path for the output .docx (relative or absolute, e.g. "output/report_pretoc.docx").
            project_context: JSON string with the required fields listed above.
            template_path: Optional path to custom pre-TOC template. Defaults to
                           rvce_report_mcp/assets/pre_toc_template.docx.
        """
        return report_tools.generate_pretoc_pages(output_path, project_context, template_path)

    @mcp.tool(annotations=ToolAnnotations(title="Get RVCE Format Profile", readOnlyHint=True))
    def get_rvce_format_profile(report_type: str = "el_report"):
        """
        Return the built-in RVCE formatting defaults as JSON.
        No template file required. Inspect this before calling create_rvce_report
        to understand what styling will be applied.

        Args:
            report_type: "el_report" (default) or "project_report".
        """
        return report_tools.get_rvce_format_profile(report_type)

    @mcp.tool(annotations=ToolAnnotations(title="Create RVCE Report", destructiveHint=True))
    def create_rvce_report(
        output_path: str,
        project_context: str,
        template_path: str = None,
    ):
        """
        Generate the main RVCE EL report (abstract through references) as a docx.

        Call ORDER: inspect_pretoc_template → generate_pretoc_pages → create_rvce_report

        HOW TO USE:
        1. User attaches project folder and pastes desired TOC structure
        2. Read project files (README, docs/, report/, src/) to extract content
        3. Build project_context JSON following the schema below
        4. Call this tool — it validates, builds, and returns figure/table labels
        5. Tell user to press Ctrl+A then F9 in Word to update page numbers

        PROJECT_CONTEXT SCHEMA:
        {
          "report_type": "el_report",
          "project_title": "string — required",
          "sdg_theme": "string — required, e.g. SDG 9 - Industry, Innovation and Infrastructure",
          "college_name": "RV College of Engineering",
          "academic_year": "string — required, e.g. 2025-26",
          "semester": "string — e.g. V",
          "faculty_mentor": {
            "name": "string — required",
            "designation": "string",
            "department": "string"
          },
          "abstract": "string — 150-250 words",
          "team": [
            {"name": "string", "usn": "string", "dept": "string", "email": "string"}
          ],
          "chapters": [
            {
              "number": 1,
              "title": "string",
              "sections": [
                {
                  "heading": "1.1 string",
                  "paragraphs": [
                    {"type": "body", "text": "string — min 40 words"},
                    {"type": "bullet_list", "items": ["string"]},
                    {"type": "numbered_list", "items": ["string"]},
                    {"type": "figure", "id": "fig_unique", "caption": "string", "source": "screenshot"},
                    {"type": "table", "id": "tbl_unique", "caption": "string",
                     "headers": ["col1", "col2"], "rows": [["val", "val"]]}
                  ]
                }
              ]
            }
          ],
          "appendix": {
            "title": "Visuals",
            "paragraphs": [
              {"type": "figure", "id": "fig_unique", "caption": "string", "source": "screenshot"}
            ]
          },
          "references": ["1. IEEE format reference string"]
        }

        PARAGRAPH RULES:
        - Map user's pasted TOC exactly — do not add or remove sections
        - Every section needs min 2 body paragraphs (min 40 words each)
        - First and last paragraph of each section must be type body
        - figure and table IDs must be unique across the entire document
        - Table column count must match across headers and all rows
        - Never invent metadata (names, USNs, emails) — extract from project files only
        - Ask user if faculty_mentor or team details are missing
        - Appendix figures = visual outputs not already used in chapters
        - References in IEEE format, numbered from 1

        OUTPUT: output/report_main.docx — abstract through references.
        Pages 1-2 are blank placeholders (certificate, declaration).
        Page 3 onwards is abstract, TOC, chapters.

        Args:
            output_path: Path for the output .docx file (relative or absolute).
            project_context: JSON string matching the project_context schema above.
            template_path: Optional path to a sample RVCE DOCX for style extraction.

        Returns:
            JSON with {status, output_path, warnings, figures, tables}
            or {status: "error", errors: [...]} on failure.
        """
        return report_tools.create_rvce_report(output_path, project_context, template_path)

    @mcp.tool(annotations=ToolAnnotations(title="Inspect Report", readOnlyHint=True))
    def inspect_report(filename: str):
        """
        Return a paragraph-by-paragraph dump of a generated report .docx.
        Use after create_rvce_report to verify the output before presenting
        to the user.

        Args:
            filename: Path to the generated .docx file.
        """
        return report_tools.inspect_report(filename)

    # -----------------------------------------------------------------------
    # Section tools
    # -----------------------------------------------------------------------

    @mcp.tool(annotations=ToolAnnotations(title="Add Report Section", destructiveHint=True))
    def add_report_section(
        filename: str,
        section_type: str,
        content_json: str,
        template_path: str = None,
    ):
        """
        Replace or add a named section in an existing RVCE report .docx.

        Valid section_type values:
          abstract        — {\"text\": \"...\"}
          acknowledgement — {\"text\": \"...\"}
          chapter_N       — single chapter object (same schema as project_context.chapters[i])
          references      — {\"references\": [\"1. ...\", \"2. ...\"]}
          appendix        — {\"title\": \"...\", \"paragraphs\": [...]}

        Args:
            filename: Path to the existing .docx file.
            section_type: Section identifier (see above).
            content_json: JSON string with the section content.
            template_path: Optional path to sample DOCX for format extraction.
        """
        return section_tools.add_report_section(
            filename, section_type, content_json, template_path
        )


# Register tools at module level so they are visible at import time
# (MCP clients introspect tools before calling run_server)
register_tools()


def run_server():
    """Main entry point — configure transport and start the MCP server."""
    config = get_transport_config()
    debug_mode = os.getenv("RVCE_MCP_DEBUG", "false").lower() == "true"
    setup_logging(debug_mode)
    register_tools()

    transport_type = config["transport"]
    print(f"Starting RVCE Report MCP Server with {transport_type} transport...")

    try:
        if transport_type == "stdio":
            print("Server running on stdio transport")
            mcp.run(transport="stdio")
        elif transport_type == "streamable-http":
            print(f"Server running on streamable-http at http://{config['host']}:{config['port']}{config['path']}")
            mcp.run(
                transport="streamable-http",
                host=config["host"],
                port=config["port"],
                path=config["path"],
            )
        elif transport_type == "sse":
            print(f"Server running on SSE at http://{config['host']}:{config['port']}{config['sse_path']}")
            mcp.run(
                transport="sse",
                host=config["host"],
                port=config["port"],
                path=config["sse_path"],
            )
    except KeyboardInterrupt:
        print("\nShutting down RVCE Report MCP Server...")
    except Exception as e:
        print(f"Error starting server: {e}")
        if debug_mode:
            import traceback
            traceback.print_exc()
        sys.exit(1)

    return mcp


def main():
    run_server()


if __name__ == "__main__":
    main()
