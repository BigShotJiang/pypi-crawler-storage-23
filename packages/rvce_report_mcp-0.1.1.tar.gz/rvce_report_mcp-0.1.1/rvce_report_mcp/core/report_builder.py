"""
Report builder for RVCE Report MCP Server.
Orchestrates the full document build in correct section order.
"""
from __future__ import annotations

import os
import re
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from rvce_report_mcp.core import FormatProfile
from rvce_report_mcp.core.cross_reference import FigureRegistry, TableRegistry
from rvce_report_mcp.core.placeholder import add_figure
from rvce_report_mcp.core.page_setup import apply_page_setup, apply_header_footer, setup_page_numbering
from rvce_report_mcp.utils.style_utils import (
    apply_paragraph_format, apply_run_highlight_yellow,
    set_keep_together, _ALIGN_ENUM, compute_column_widths
)
from rvce_report_mcp.utils.toc_utils import build_toc, build_lof, build_lot


# ---------------------------------------------------------------------------
# Heading helpers
# ---------------------------------------------------------------------------

def _add_heading(doc: Document, text: str, level: int, profile: FormatProfile) -> object:
    """Add a heading paragraph with FormatProfile styling.

    Also sets <w:outlineLvl> in pPr so that a { TOC \\u } field can detect this
    paragraph as a heading entry when the user presses Ctrl+A then F9 in Word.
    """
    para = doc.add_paragraph()
    level_profile = {1: profile.h1, 2: profile.h2, 3: profile.h3}.get(level, profile.h2)
    run = para.add_run(text)
    apply_paragraph_format(para, level_profile)

    # Set outline level (0-based: H1→0, H2→1, H3→2) so Word TOC field can pick it up
    outline_val = max(0, level - 1)
    pPr = para._p.get_or_add_pPr()
    # Remove any existing outlineLvl first
    for old in pPr.findall(qn("w:outlineLvl")):
        pPr.remove(old)
    outline_el = OxmlElement("w:outlineLvl")
    outline_el.set(qn("w:val"), str(outline_val))
    pPr.append(outline_el)

    return para


_FILENAME_RE = re.compile(r'\b\w[\w_\-]*\.[a-zA-Z]{1,6}\b')


def _add_tokenized_runs(para, text: str, profile: FormatProfile,
                        highlight: bool = False) -> None:
    """
    Append tokenized runs to *para*.
    - Bolds occurrences of profile.bold_keywords (case-insensitive).
    - Italicises file-name tokens (e.g. main.py, config.json).
    - Applies the correct body font/size/bold/italic to *every* run.
    Shared by _add_body_para and _add_list so both get identical formatting.
    """
    keywords = [k for k in (profile.bold_keywords or []) if k]

    if keywords:
        kw_part = '|'.join(re.escape(k) for k in keywords)
        combined = re.compile(
            r'(?P<kw>' + kw_part + r')|(?P<fn>\b\w[\w_\-]*\.[a-zA-Z]{1,6}\b)',
            re.IGNORECASE,
        )
    else:
        combined = _FILENAME_RE  # only italicise filenames

    def _emit(txt: str, bold: bool = False, italic: bool = False) -> None:
        if not txt:
            return
        r = para.add_run(txt)
        r.font.name = profile.body.font_name
        r.font.size = Pt(profile.body.font_size_pt)
        r.font.bold = True if bold else (profile.body.bold or False)
        r.font.italic = True if italic else (profile.body.italic or False)
        if highlight:
            apply_run_highlight_yellow(r)

    last = 0
    for m in combined.finditer(text):
        _emit(text[last:m.start()])
        if keywords and m.lastgroup == 'kw':
            _emit(m.group(0), bold=True)
        else:
            _emit(m.group(0), italic=True)
        last = m.end()
    _emit(text[last:])


def _add_body_para(doc: Document, text: str, profile: FormatProfile,
                   alignment: str = None, highlight: bool = False) -> object:
    """Add a body paragraph with keyword-bold and filename-italic tokenisation."""
    para = doc.add_paragraph()
    apply_paragraph_format(para, profile.body)  # sets spacing / alignment

    if alignment and alignment.upper() in _ALIGN_ENUM:
        para.paragraph_format.alignment = _ALIGN_ENUM[alignment.upper()]

    _add_tokenized_runs(para, text, profile, highlight=highlight)
    return para


def _add_centered_heading(doc: Document, text: str, level: int,
                          profile: FormatProfile) -> object:
    """Add a heading forced to CENTER alignment (used for pre-TOC section titles)."""
    para = _add_heading(doc, text, level, profile)
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return para


def _add_list(doc: Document, items: list[str], ordered: bool,
              profile: FormatProfile) -> None:
    """Add a bullet or numbered list.

    Each item receives the same keyword-bold / filename-italic tokenisation
    as body paragraphs so that formatting is consistent across the document.
    """
    style_names = [s.name for s in doc.styles]
    for item in items:
        para = doc.add_paragraph()
        if ordered:
            para.style = doc.styles["List Number"] if "List Number" in style_names else doc.styles["Normal"]
        else:
            para.style = doc.styles["List Bullet"] if "List Bullet" in style_names else doc.styles["Normal"]
        para.paragraph_format.left_indent = Cm(1.0)
        # Use the shared tokeniser so bold_keywords are bold and filenames are italic
        _add_tokenized_runs(para, item, profile)


def _add_personal_reflection(doc: Document, entries: list[dict],
                              profile: FormatProfile) -> None:
    """
    Add personal reflection entries.
    Each entry: bold name run + italic text run, indented.
    """
    for entry in entries:
        name = entry.get("name", "")
        text = entry.get("text", "")
        para = doc.add_paragraph()
        para.paragraph_format.left_indent = Inches(0.5)
        para.paragraph_format.space_after = Pt(6)

        name_run = para.add_run(f"{name}: ")
        name_run.font.name = profile.body.font_name
        name_run.font.size = Pt(profile.body.font_size_pt)
        name_run.font.bold = True

        text_run = para.add_run(text)
        text_run.font.name = profile.body.font_name
        text_run.font.size = Pt(profile.body.font_size_pt)
        text_run.font.italic = True


def _add_table(doc: Document, tbl_data: dict, label: str,
               profile: FormatProfile) -> None:
    """Add a formatted table with caption."""
    headers = tbl_data.get("headers", [])
    rows = tbl_data.get("rows", [])
    col_widths_pct = tbl_data.get("col_widths")
    caption = tbl_data.get("caption", "")

    n_cols = len(headers) if headers else 1
    n_rows = len(rows) + 1  # +1 for header row

    table = doc.add_table(rows=n_rows, cols=n_cols)
    table.style = "Table Grid"

    # Compute and set column widths
    col_widths_cm = compute_column_widths(headers, rows, profile.usable_width_cm, col_widths_pct)
    _apply_column_widths(table, col_widths_cm)
    _set_table_full_width(table, profile.usable_width_cm)

    # Header row
    for j, header_text in enumerate(headers):
        cell = table.cell(0, j)
        para = cell.paragraphs[0]
        para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run(header_text)
        run.font.name = profile.body.font_name
        run.font.size = Pt(profile.body.font_size_pt)
        run.font.bold = True

    # Data rows
    for i, row in enumerate(rows):
        for j, cell_text in enumerate(row):
            if j < n_cols:
                cell = table.cell(i + 1, j)
                para = cell.paragraphs[0]
                run = para.add_run(str(cell_text))
                run.font.name = profile.body.font_name
                run.font.size = Pt(profile.body.font_size_pt)

    # Caption below table
    cap_para = doc.add_paragraph()
    cap_para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap_para.paragraph_format.space_before = Pt(4)
    cap_para.paragraph_format.space_after = Pt(8)
    cap_run = cap_para.add_run(f"{label}: {caption}")
    cap_run.font.name = profile.caption.font_name
    cap_run.font.size = Pt(profile.caption.font_size_pt)
    cap_run.font.bold = True


def _apply_column_widths(table, widths_cm: list[float]) -> None:
    """Set column widths on a table."""
    for col_idx, width in enumerate(widths_cm):
        if col_idx < len(table.columns):
            for cell in table.columns[col_idx].cells:
                cell.width = Cm(width)


def _set_table_full_width(table, usable_width_cm: float) -> None:
    """Force table to fill the usable page width."""
    from rvce_report_mcp.core.placeholder import _set_table_width
    _set_table_width(table, Cm(usable_width_cm))


def build_placeholder_pretoc(doc: Document, profile: FormatProfile) -> None:
    """
    Insert 2 blank placeholder pages at the start of report_main.docx.
    Certificate = page 1 (decimal start=1), Declaration = page 2 (continues).
    Abstract starts on page 3 after these.
    Both pages carry inline section breaks so each occupies exactly one page.
    """
    labels = [
        "[Certificate — see _pretoc.docx]",
        "[Declaration — see _pretoc.docx]",
    ]
    for i, label in enumerate(labels):
        p = doc.add_paragraph()
        run = p.add_run(label)
        run.italic = True
        run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)
        run.font.size = Pt(11)
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Embed a next-page section break inside this paragraph's pPr
        pPr = p._p.get_or_add_pPr()
        sectPr = OxmlElement("w:sectPr")
        typ = OxmlElement("w:type")
        typ.set(qn("w:val"), "nextPage")
        sectPr.insert(0, typ)
        if i == 0:
            # Certificate placeholder = page 1 of main report, decimal numbering
            pgNumType = OxmlElement("w:pgNumType")
            pgNumType.set(qn("w:fmt"), "decimal")
            pgNumType.set(qn("w:start"), "1")
            sectPr.append(pgNumType)
        pPr.append(sectPr)


def build_cover_placeholder(doc: Document, profile: FormatProfile) -> None:
    """Insert a placeholder for the cover page (distinct section, no header/footer)."""
    para = doc.add_paragraph()
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run(
        "[COVER PAGE – use set_title_page() to fill with college name, "
        "logo, project title, faculty mentor, and academic year]"
    )
    run.font.name = profile.body.font_name
    run.font.size = Pt(14)
    run.font.italic = True
    run.font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    doc.add_page_break()


def build_student_details(doc: Document, team: list[dict], profile: FormatProfile) -> None:
    """Build the Student Details page with a 5-column table."""
    # Icon placeholder + heading
    icon_para = doc.add_paragraph()
    icon_para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    icon_run = icon_para.add_run("[icon]  Student Details")
    icon_run.font.name = profile.h1.font_name
    icon_run.font.size = Pt(profile.h1.font_size_pt)
    icon_run.font.bold = True

    doc.add_paragraph()  # spacer

    headers = ["Name", "USN", "Dept.", "Email"]
    rows = []
    for member in team:
        rows.append([
            member.get("name", ""),
            member.get("usn", ""),
            member.get("dept", ""),
            member.get("email", ""),
        ])

    n_cols = len(headers)
    n_rows = len(rows) + 1

    table = doc.add_table(rows=n_rows, cols=n_cols)
    table.style = "Table Grid"
    _set_table_full_width(table, profile.usable_width_cm)

    col_widths_cm = compute_column_widths(headers, rows, profile.usable_width_cm)
    _apply_column_widths(table, col_widths_cm)

    # Header row
    for j, h in enumerate(headers):
        cell = table.cell(0, j)
        para = cell.paragraphs[0]
        para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run(h)
        run.font.name = profile.body.font_name
        run.font.size = Pt(profile.body.font_size_pt)
        run.font.bold = True

    # Data rows
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = table.cell(i + 1, j)
            para = cell.paragraphs[0]
            run = para.add_run(str(val))
            run.font.name = profile.body.font_name
            run.font.size = Pt(profile.body.font_size_pt)

    doc.add_page_break()


def build_certificate_placeholder(doc: Document, profile: FormatProfile) -> None:
    """Insert RVCE Bonafide Certificate boilerplate with name/guide placeholders."""
    _add_centered_heading(doc, "BONAFIDE CERTIFICATE", 1, profile)
    doc.add_paragraph()

    cert_text = (
        "This is to certify that the project work entitled [PROJECT TITLE] "
        "is a bonafide work carried out by:\n"
    )
    para = doc.add_paragraph(cert_text)
    apply_paragraph_format(para, profile.body)

    # Placeholder for student names/USNs
    placeholder_para = doc.add_paragraph(
        "[Student Name / USN – use set_certificate() to fill team details]"
    )
    apply_paragraph_format(placeholder_para, profile.body)
    placeholder_para.runs[0].font.italic = True
    placeholder_para.runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    continuation = doc.add_paragraph(
        "in partial fulfilment of the requirements for the award of the degree of "
        "Bachelor of Engineering in [DEPARTMENT], RV College of Engineering, Bengaluru, "
        "during the academic year [YEAR]."
    )
    apply_paragraph_format(continuation, profile.body)

    doc.add_paragraph()
    sig_para = doc.add_paragraph(
        "[Guide Name / Designation – use set_certificate() to fill]"
    )
    apply_paragraph_format(sig_para, profile.body)
    sig_para.runs[0].font.italic = True
    sig_para.runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    doc.add_page_break()


def build_acknowledgement_placeholder(doc: Document, profile: FormatProfile) -> None:
    """Insert acknowledgement placeholder."""
    _add_centered_heading(doc, "ACKNOWLEDGEMENT", 1, profile)
    placeholder_para = doc.add_paragraph(
        "[ACKNOWLEDGEMENT – use set_acknowledgement() to fill with your acknowledgement text]"
    )
    apply_paragraph_format(placeholder_para, profile.body)
    placeholder_para.runs[0].font.italic = True
    placeholder_para.runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    doc.add_page_break()


def build_abstract(doc: Document, profile: FormatProfile,
                   abstract_text: str = "") -> None:
    """Insert the ABSTRACT section.

    If *abstract_text* is supplied and non-empty, it is written as a normal
    body paragraph.  Otherwise a grey italic placeholder is written so the
    document is still structurally complete.
    """
    _add_centered_heading(doc, "ABSTRACT", 1, profile)
    if abstract_text and abstract_text.strip():
        _add_body_para(doc, abstract_text.strip(), profile)
    else:
        placeholder_para = doc.add_paragraph(
            "[ABSTRACT \u2013 use set_abstract() to fill with your project abstract]"
        )
        apply_paragraph_format(placeholder_para, profile.body)
        placeholder_para.runs[0].font.italic = True
        placeholder_para.runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    doc.add_page_break()


# ---------------------------------------------------------------------------
# Chapter / section content builders
# ---------------------------------------------------------------------------

def build_paragraph_object(doc: Document, para_obj: dict, chapter_num: int,
                            profile: FormatProfile,
                            fig_registry: FigureRegistry,
                            tbl_registry: TableRegistry,
                            last_body_para=None) -> object:
    """
    Build a single paragraph object from the content JSON.
    Returns the paragraph if it's a body paragraph (used for cross-ref appending).
    """
    ptype = para_obj.get("type", "body")

    if ptype == "body":
        text = para_obj.get("text", "")
        alignment = para_obj.get("alignment")
        highlight = para_obj.get("highlight", False)
        para = _add_body_para(doc, text, profile, alignment, highlight)
        return para

    elif ptype in ("bullet_list", "numbered_list"):
        items = para_obj.get("items", [])
        _add_list(doc, items, ordered=(ptype == "numbered_list"), profile=profile)
        return None

    elif ptype == "figure":
        fig_id = para_obj.get("id", "fig")
        caption = para_obj.get("caption", "")
        source = para_obj.get("source", "image_file")
        file_path = para_obj.get("file_path", "")
        width_cm = para_obj.get("width_cm", 0.0)

        entry = fig_registry.register(fig_id, caption, chapter_num)
        label = entry.label

        # Append cross-reference to the preceding body paragraph
        if last_body_para is not None:
            try:
                existing_text = last_body_para.text
                if f"see {label}" not in existing_text:
                    cross_run = last_body_para.add_run(f" (see {label})")
                    cross_run.font.name = profile.body.font_name
                    cross_run.font.size = Pt(profile.body.font_size_pt)
            except Exception:
                pass

        add_figure(doc, fig_id, caption, source, label, profile, file_path, width_cm)
        return None

    elif ptype == "table":
        tbl_id = para_obj.get("id", "tbl")
        caption = para_obj.get("caption", "")
        entry = tbl_registry.register(tbl_id, caption, chapter_num)
        label = entry.label

        # Cross-reference in preceding body paragraph
        if last_body_para is not None:
            try:
                existing_text = last_body_para.text
                if f"see {label}" not in existing_text:
                    cross_run = last_body_para.add_run(f" (see {label})")
                    cross_run.font.name = profile.body.font_name
                    cross_run.font.size = Pt(profile.body.font_size_pt)
            except Exception:
                pass

        _add_table(doc, para_obj, label, profile)
        return None

    elif ptype == "personal_reflection":
        entries = para_obj.get("entries", [])
        _add_personal_reflection(doc, entries, profile)
        return None

    return None


def build_section(doc: Document, section: dict, chapter_num: int,
                  heading_level: int, profile: FormatProfile,
                  fig_registry: FigureRegistry,
                  tbl_registry: TableRegistry) -> None:
    """Build a section (H2) and its subsections."""
    heading_text = section.get("heading", "")
    _add_heading(doc, heading_text, heading_level, profile)

    last_body_para = None
    for para_obj in section.get("paragraphs", []):
        result = build_paragraph_object(
            doc, para_obj, chapter_num, profile,
            fig_registry, tbl_registry, last_body_para
        )
        if result is not None:
            last_body_para = result

    # Subsections (H3)
    for sub in section.get("subsections", []):
        build_section(doc, sub, chapter_num, heading_level + 1, profile,
                      fig_registry, tbl_registry)


def build_chapter(doc: Document, chapter: dict, profile: FormatProfile,
                  fig_registry: FigureRegistry,
                  tbl_registry: TableRegistry) -> None:
    """Build a single chapter with all sections."""
    num = chapter.get("number", 1)
    title = chapter.get("title", "")

    if profile.report_type == "project_report":
        heading_text = f"CHAPTER {num}: {title.upper()}"
    else:
        heading_text = f"{num}. {title}"

    _add_heading(doc, heading_text, 1, profile)

    for section in chapter.get("sections", []):
        build_section(doc, section, num, 2, profile, fig_registry, tbl_registry)

    doc.add_page_break()


def build_appendix(doc: Document, appendix: dict, profile: FormatProfile,
                   fig_registry: FigureRegistry,
                   tbl_registry: TableRegistry) -> None:
    """Build the optional appendix section."""
    title = appendix.get("title", "Appendix")
    _add_heading(doc, title, 1, profile)

    last_body_para = None
    for para_obj in appendix.get("paragraphs", []):
        result = build_paragraph_object(
            doc, para_obj, "appendix", profile, fig_registry, tbl_registry, last_body_para
        )
        if result is not None:
            last_body_para = result

    doc.add_page_break()


def build_references(doc: Document, references: list[str], profile: FormatProfile) -> None:
    """Build the references section with IEEE hanging indent style."""
    _add_heading(doc, "REFERENCES", 1, profile)

    for ref in references:
        para = doc.add_paragraph()
        # IEEE hanging indent
        para.paragraph_format.left_indent = Inches(0.5)
        para.paragraph_format.first_line_indent = Inches(-0.5)
        para.paragraph_format.space_after = Pt(4)
        run = para.add_run(ref)
        run.font.name = profile.reference.font_name
        run.font.size = Pt(profile.reference.font_size_pt)


# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------

def build_full_report(output_path: str, project_context: dict, profile: FormatProfile) -> dict:
    """
    Build the complete RVCE report document.

    Returns:
        dict with keys: status, output_path, warnings
    """
    doc = Document()
    warnings: list[str] = []

    fig_registry = FigureRegistry()
    tbl_registry = TableRegistry()

    chapters = project_context.get("chapters", [])
    team = project_context.get("team", [])
    references = project_context.get("references", [])
    appendix = project_context.get("appendix")

    # Apply base page setup to the default first section
    apply_page_setup(doc.sections[0], profile)

    # -----------------------------------------------------------------------
    # Pages 1–2: Certificate and Declaration blank placeholders
    # (inline section breaks inside each paragraph's pPr)
    # -----------------------------------------------------------------------
    build_placeholder_pretoc(doc, profile)

    # Apply page setup to the front-matter section (abstract → LoT)
    apply_page_setup(doc.sections[-1], profile)

    # -----------------------------------------------------------------------
    # FRONT MATTER: Abstract → TOC → LoF → LoT  (pages 3–6)
    # -----------------------------------------------------------------------
    abstract_text = project_context.get("abstract", "")
    build_abstract(doc, profile, abstract_text)
    build_toc(doc, chapters, profile)
    build_lof(doc, [], profile)
    build_lot(doc, [], profile)

    # -----------------------------------------------------------------------
    # CHAPTERS SECTION: Arabic numerals, restart at 1
    # -----------------------------------------------------------------------
    _add_section_break(doc, WD_SECTION.NEW_PAGE)
    apply_page_setup(doc.sections[-1], profile)

    for chapter in chapters:
        build_chapter(doc, chapter, profile, fig_registry, tbl_registry)

    # Appendix (optional)
    if appendix:
        build_appendix(doc, appendix, profile, fig_registry, tbl_registry)

    # References
    build_references(doc, references, profile)

    # -----------------------------------------------------------------------
    # Apply header/footer to all sections (no cover page to skip in main report)
    # -----------------------------------------------------------------------
    apply_header_footer(doc, profile, cover_section_index=None)

    # -----------------------------------------------------------------------
    # Setup page numbering per section
    # -----------------------------------------------------------------------
    setup_page_numbering(doc)

    # -----------------------------------------------------------------------
    # Rebuild LoF and LoT with actual registry data
    # (We do a post-build pass: walk paragraphs and replace placeholder LOF/LOT blocks)
    # For simplicity, we log a warning that the LoF/LoT are pre-built placeholders.
    # -----------------------------------------------------------------------
    warnings.append(
        "List of Figures and List of Tables are pre-built with placeholder page numbers [pg]. "
        "Open the document in Word and press Ctrl+A then F9 to update all fields."
    )

    # Rebuild LoF/LoT by appending to end of front-matter section is not feasible
    # post-build without section tracking. The registries are available for inspection.
    fig_list = fig_registry.as_list_of_dicts()
    tbl_list = tbl_registry.as_list_of_dicts()
    if fig_list:
        warnings.append(
            f"Figures registered: {', '.join(e['label'] for e in fig_list)}. "
            f"Update List of Figures manually if needed."
        )
    if tbl_list:
        warnings.append(
            f"Tables registered: {', '.join(e['label'] for e in tbl_list)}. "
            f"Update List of Tables manually if needed."
        )

    # Save
    try:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    except Exception:
        pass
    doc.save(output_path)

    return {
        "status": "success",
        "output_path": output_path,
        "warnings": warnings,
        "figures": fig_list,
        "tables": tbl_list,
    }


def _add_section_break(doc: Document, break_type) -> None:
    """Add a section break of the given type to the document."""
    new_section = doc.add_section(break_type)
    return new_section
