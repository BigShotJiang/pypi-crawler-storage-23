"""
Page setup for RVCE Report MCP Server.
Applies A4 page dimensions, margins, header/footer, and page numbering sections.
"""
from __future__ import annotations

from docx import Document
from docx.shared import Cm, Pt, Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.enum.section import WD_SECTION

from rvce_report_mcp.core import FormatProfile, HeaderProfile, FooterProfile
from rvce_report_mcp.utils.style_utils import (
    add_bottom_border_to_para, add_top_border_to_para, insert_page_number_field
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _add_footer_borders(para, top: bool = True, bottom: bool = False,
                        top_val: str = "double", top_sz: str = "8",
                        bottom_val: str = "single", bottom_sz: str = "4") -> None:
    """Add top and/or bottom paragraph borders for the footer rule."""
    pPr = para._element.get_or_add_pPr()
    for old in pPr.findall(qn("w:pBdr")):
        pPr.remove(old)
    if not top and not bottom:
        return
    pBdr = OxmlElement("w:pBdr")
    if top:
        t = OxmlElement("w:top")
        t.set(qn("w:val"), top_val)
        t.set(qn("w:sz"), top_sz)
        t.set(qn("w:space"), "1")
        t.set(qn("w:color"), "auto")
        pBdr.append(t)
    if bottom:
        b = OxmlElement("w:bottom")
        b.set(qn("w:val"), bottom_val)
        b.set(qn("w:sz"), bottom_sz)
        b.set(qn("w:space"), "1")
        b.set(qn("w:color"), "auto")
        pBdr.append(b)
    pPr.append(pBdr)


def _append_page_number_runs(para) -> None:
    """Append a PAGE field as three runs (begin/instrText/end) to an existing paragraph."""
    run_begin = para.add_run()
    fc_begin = OxmlElement("w:fldChar")
    fc_begin.set(qn("w:fldCharType"), "begin")
    run_begin._r.append(fc_begin)

    run_instr = para.add_run()
    instr = OxmlElement("w:instrText")
    instr.text = " PAGE "
    instr.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    run_instr._r.append(instr)

    run_end = para.add_run()
    fc_end = OxmlElement("w:fldChar")
    fc_end.set(qn("w:fldCharType"), "end")
    run_end._r.append(fc_end)


def apply_page_setup(section, profile: FormatProfile) -> None:
    """Apply A4 dimensions and margins from profile to a document section."""
    section.page_width = Cm(profile.page_width_cm)
    section.page_height = Cm(profile.page_height_cm)
    section.left_margin = Cm(profile.margin_left_cm)
    section.right_margin = Cm(profile.margin_right_cm)
    section.top_margin = Cm(profile.margin_top_cm)
    section.bottom_margin = Cm(profile.margin_bottom_cm)
    section.header_distance = Cm(profile.header_distance_cm)
    section.footer_distance = Cm(profile.footer_distance_cm)
    if profile.different_first_page:
        section.different_first_page_header_footer = True


def _set_section_page_number(section, start: int, fmt: str = "decimal") -> None:
    """
    Set page number restart on a section via XML.
    fmt: 'decimal' for Arabic, 'lowerRoman' for roman, 'upperRoman', etc.
    """
    sectPr = section._sectPr
    # Remove existing pgNumType
    for old in sectPr.findall(qn("w:pgNumType")):
        sectPr.remove(old)
    pgNumType = OxmlElement("w:pgNumType")
    pgNumType.set(qn("w:start"), str(start))
    pgNumType.set(qn("w:fmt"), fmt)
    sectPr.append(pgNumType)


def _remove_cover_header_footer_refs(section) -> None:
    """
    Remove all w:headerReference and w:footerReference elements from a section's
    sectPr WITHOUT accessing section.header or section.footer (which would create
    new relationship entries). Also remove pgNumType — cover page has no page number.
    """
    sectPr = section._sectPr
    for tag in (qn("w:headerReference"), qn("w:footerReference"), qn("w:pgNumType")):
        for el in sectPr.findall(tag):
            sectPr.remove(el)


def _build_header(section, header_profile: HeaderProfile, profile: FormatProfile) -> None:
    """Write header content from profile into a section's header."""
    from docx.shared import RGBColor as RGBColorH
    from rvce_report_mcp.utils.style_utils import _ALIGN_ENUM
    from rvce_report_mcp.utils.toc_utils import _add_tab_stop

    header = section.header
    # Clear existing paragraphs
    for para in header.paragraphs:
        para.clear()

    if not header_profile.paragraphs:
        # No header defined — leave blank (do not add any runs)
        return

    for idx, php in enumerate(header_profile.paragraphs):
        if idx == 0 and header.paragraphs:
            para = header.paragraphs[0]
        else:
            para = header.add_paragraph()

        if php.alignment in _ALIGN_ENUM:
            para.paragraph_format.alignment = _ALIGN_ENUM[php.alignment]

        # Restore tab stops from profile
        for ts in php.tab_stops:
            _add_tab_stop(para, Cm(ts.position_cm),
                          ts.alignment, "dot" if ts.leader == "dots" else "none")

        if header_profile.has_image:
            run = para.add_run("[HEADER IMAGE – replace with logo]")
            run.font.italic = True
        elif php.has_page_number_field:
            insert_page_number_field(para, php.alignment)
        else:
            text = php.text or ""
            run = para.add_run(text)
            run.font.name = php.font_name
            run.font.size = Pt(php.font_size_pt)
            run.font.bold = php.bold
            run.font.italic = php.italic
            # Apply color if specified (e.g. red for RVCE EL header)
            if php.color_hex and len(php.color_hex) == 6:
                try:
                    run.font.color.rgb = RGBColorH(
                        int(php.color_hex[0:2], 16),
                        int(php.color_hex[2:4], 16),
                        int(php.color_hex[4:6], 16),
                    )
                except Exception:
                    pass

        # Bottom rule on the last header paragraph
        if idx == len(header_profile.paragraphs) - 1 and header_profile.has_rule:
            add_bottom_border_to_para(para,
                                      val=header_profile.rule_val,
                                      sz=header_profile.rule_sz)


def _build_footer(section, footer_profile: FooterProfile, profile: FormatProfile) -> None:
    """Write footer content from profile into a section's footer."""
    if footer_profile.three_part:
        _build_footer_three_part(section, footer_profile, profile)
        return

    footer = section.footer
    for para in footer.paragraphs:
        para.clear()

    if not footer_profile.paragraphs and footer_profile.page_number_position != "none":
        # Default: centre page number
        para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        if footer_profile.has_rule:
            add_top_border_to_para(para)
        insert_page_number_field(para, footer_profile.page_number_position.upper())
        return

    for idx, php in enumerate(footer_profile.paragraphs):
        if idx == 0 and footer.paragraphs:
            para = footer.paragraphs[0]
        else:
            para = footer.add_paragraph()

        from rvce_report_mcp.utils.style_utils import _ALIGN_ENUM
        if php.alignment in _ALIGN_ENUM:
            para.paragraph_format.alignment = _ALIGN_ENUM[php.alignment]

        if idx == 0 and footer_profile.has_rule:
            add_top_border_to_para(para)

        if php.has_page_number_field:
            insert_page_number_field(para, php.alignment)
        else:
            run = para.add_run(php.text or "")
            run.font.name = php.font_name
            run.font.size = Pt(php.font_size_pt)


def _build_footer_three_part(section, footer_profile: FooterProfile,
                              profile: FormatProfile) -> None:
    """
    Render the RVCE three-part footer:
        [left_text]  \t  [center_text]  \t  [right_text_prefix][PAGE]
    with a double top-rule and a thin bottom-rule, font 10pt Times New Roman.
    Tab stops: CENTER at usable_width/2, RIGHT at usable_width.
    """
    from docx.shared import Cm
    from rvce_report_mcp.utils.toc_utils import _add_tab_stop

    footer = section.footer
    for para in footer.paragraphs:
        para.clear()
    para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()

    # Borders: double on top, thin single on bottom
    _add_footer_borders(para,
                        top=footer_profile.has_rule,
                        bottom=footer_profile.has_bottom_rule)

    # Tab stops — no leader
    usable = profile.usable_width_cm
    _add_tab_stop(para, Cm(usable / 2), "CENTER", "none")
    _add_tab_stop(para, Cm(usable), "RIGHT", "none")

    font_name = profile.body.font_name
    font_size = Pt(10)

    def _run(text):
        r = para.add_run(text)
        r.font.name = font_name
        r.font.size = font_size
        return r

    _run(footer_profile.left_text)
    _run("\t")
    _run(footer_profile.center_text)
    _run("\t")
    _run(footer_profile.right_text_prefix)
    _append_page_number_runs(para)


def apply_header_footer(doc: Document, profile: FormatProfile,
                        cover_section_index: int = None) -> None:
    """
    Apply header and footer to all sections in the document.
    When cover_section_index is not None, that section gets its header/footer
    refs stripped (used for old-style cover-page builds).
    Pass cover_section_index=None (default) to apply header/footer to ALL sections.
    """
    for i, section in enumerate(doc.sections):
        if cover_section_index is not None and i == cover_section_index:
            # Cover page: strip header/footer XML refs entirely
            _remove_cover_header_footer_refs(section)
            continue

        _build_header(section, profile.header, profile)
        _build_footer(section, profile.footer, profile)

        if profile.different_first_page and profile.first_page_header:
            section.different_first_page_header_footer = True
            _build_header(section.first_page_header, profile.first_page_header, profile)
        if profile.different_first_page and profile.first_page_footer:
            _build_footer(section.first_page_footer, profile.first_page_footer, profile)


def setup_page_numbering(doc: Document) -> None:
    """
    Configure page numbering for report_main.docx.

    New build structure (no cover page in main report):
      - sections[0–1]: inline-sectPr pages (certificate, declaration placeholders)
        sections[0] already has decimal/start=1 set by build_placeholder_pretoc.
      - sections[2]: front matter (abstract → LoT) — continues decimal numbering.
      - sections[-1]: chapters — explicit decimal restart at 1 so header shows
        correct page numbers (user updates cross-refs with Ctrl+A → F9).
    """
    sections = doc.sections
    if not sections:
        return

    # Chapters section (last explicit section): decimal restart at 1
    _set_section_page_number(sections[-1], 1, "decimal")


def _suppress_page_number(section) -> None:
    """Suppress page number display in footer for a section (legacy, kept for safety)."""
    try:
        sectPr = section._sectPr
        for el in sectPr.findall(qn("w:pgNumType")):
            sectPr.remove(el)
    except Exception:
        pass


def _dummy_profile_from_section(section) -> FormatProfile:
    """Extract basic dimensions from an existing section for apply_page_setup."""
    from rvce_report_mcp.core import FormatProfile
    p = FormatProfile()
    try:
        p.page_width_cm = section.page_width.cm
        p.page_height_cm = section.page_height.cm
        p.margin_left_cm = section.left_margin.cm
        p.margin_right_cm = section.right_margin.cm
        p.margin_top_cm = section.top_margin.cm
        p.margin_bottom_cm = section.bottom_margin.cm
    except Exception:
        pass
    return p
