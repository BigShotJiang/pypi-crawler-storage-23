"""
Cross-reference registry for RVCE Report MCP Server.
Tracks figures and tables as they are added, generating chapter.sequence labels.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union


@dataclass
class FigureEntry:
    fig_id: str
    label: str          # e.g. "Figure 2.3" or "Figure A.1"
    caption: str
    chapter: Union[int, str]   # int for chapters, "appendix" for appendix
    sequence: int


@dataclass
class TableEntry:
    tbl_id: str
    label: str          # e.g. "Table 2.1" or "Table A.1"
    caption: str
    chapter: Union[int, str]
    sequence: int


class FigureRegistry:
    """
    Accumulates figure entries across the entire document build.
    Uses a per-chapter counter so labels are Figure {chapter_num}.{sequence},
    e.g. Figure 1.1, Figure 1.2, Figure 2.1, Figure 2.2.
    """

    def __init__(self):
        self._entries: list[FigureEntry] = []
        # Per-chapter counter dict — key: chapter_num, value: last used sequence number
        self._chapter_counters: dict[int, int] = {}

    def register(self, fig_id: str, caption: str, chapter: Union[int, str]) -> FigureEntry:
        seq = self._chapter_counters.get(chapter, 0) + 1
        self._chapter_counters[chapter] = seq
        prefix = "A" if chapter == "appendix" else str(chapter)
        label = f"Figure {prefix}.{seq}"
        entry = FigureEntry(fig_id=fig_id, label=label, caption=caption,
                            chapter=chapter, sequence=seq)
        self._entries.append(entry)
        return entry

    def get_label(self, fig_id: str) -> str:
        for e in self._entries:
            if e.fig_id == fig_id:
                return e.label
        return f"Figure ?.?"

    def all_entries(self) -> list[FigureEntry]:
        return list(self._entries)

    def as_list_of_dicts(self) -> list[dict]:
        return [{"label": e.label, "caption": e.caption} for e in self._entries]


class TableRegistry:
    """
    Accumulates table entries across the entire document build.
    Uses a per-chapter counter so labels are Table {chapter_num}.{sequence},
    e.g. Table 1.1, Table 2.1, Table 2.2.
    """

    def __init__(self):
        self._entries: list[TableEntry] = []
        # Per-chapter counter dict — key: chapter_num, value: last used sequence number
        self._chapter_counters: dict[int, int] = {}

    def register(self, tbl_id: str, caption: str, chapter: Union[int, str]) -> TableEntry:
        seq = self._chapter_counters.get(chapter, 0) + 1
        self._chapter_counters[chapter] = seq
        prefix = "A" if chapter == "appendix" else str(chapter)
        label = f"Table {prefix}.{seq}"
        entry = TableEntry(tbl_id=tbl_id, label=label, caption=caption,
                           chapter=chapter, sequence=seq)
        self._entries.append(entry)
        return entry

    def get_label(self, tbl_id: str) -> str:
        for e in self._entries:
            if e.tbl_id == tbl_id:
                return e.label
        return f"Table ?.?"

    def all_entries(self) -> list[TableEntry]:
        return list(self._entries)

    def as_list_of_dicts(self) -> list[dict]:
        return [{"label": e.label, "caption": e.caption} for e in self._entries]
