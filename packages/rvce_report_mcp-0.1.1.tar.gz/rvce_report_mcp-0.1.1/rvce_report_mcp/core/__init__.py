"""
Core dataclasses for RVCE Report MCP Server.
FormatProfile holds all extracted/default styling information used throughout the build.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ParagraphStyleProfile:
    """Stores formatting for a single paragraph style (heading level, body, caption, etc.)."""
    font_name: str = "Times New Roman"
    font_size_pt: float = 12.0
    bold: bool = False
    italic: bool = False
    alignment: str = "LEFT"          # LEFT | CENTER | RIGHT | JUSTIFY
    space_before_pt: float = 6.0
    space_after_pt: float = 6.0
    line_spacing: Optional[float] = 1.5   # multiple; None = single


@dataclass
class TabStopProfile:
    position_cm: float = 0.0
    alignment: str = "LEFT"           # LEFT | CENTER | RIGHT
    leader: str = "none"              # none | dots | dashes


@dataclass
class HeaderFooterParaProfile:
    text: str = ""
    font_name: str = "Times New Roman"
    font_size_pt: float = 10.0
    bold: bool = False
    italic: bool = False
    alignment: str = "CENTER"
    tab_stops: list[TabStopProfile] = field(default_factory=list)
    has_page_number_field: bool = False   # True if a PAGE field was detected in this paragraph
    color_hex: str = ""                   # e.g. "FF0000" for red; empty = default (black)


@dataclass
class HeaderProfile:
    paragraphs: list[HeaderFooterParaProfile] = field(default_factory=list)
    has_rule: bool = False             # horizontal border rule below header
    has_image: bool = False            # image detected in header
    rule_val: str = "single"           # border style: single | double | thick
    rule_sz: str = "4"                 # border width in eighths of a point


@dataclass
class FooterProfile:
    paragraphs: list[HeaderFooterParaProfile] = field(default_factory=list)
    has_rule: bool = False             # horizontal border rule above footer (top)
    has_bottom_rule: bool = False      # horizontal border rule below footer (bottom)
    page_number_position: str = "center"   # left | center | right | none
    # Three-part footer (left text | center text | right "Page No. N")
    three_part: bool = False
    left_text: str = ""
    center_text: str = ""
    right_text_prefix: str = "Page No. "


@dataclass
class FormatProfile:
    """Complete formatting profile for an RVCE report document."""
    report_type: str = "el_report"     # el_report | project_report

    # Paragraph styles
    h1: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=14.0, bold=True, alignment="LEFT",
        space_before_pt=12.0, space_after_pt=6.0
    ))
    h2: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=12.0, bold=True, alignment="LEFT",
        space_before_pt=10.0, space_after_pt=4.0
    ))
    h3: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=12.0, bold=True, italic=True, alignment="LEFT",
        space_before_pt=8.0, space_after_pt=4.0
    ))
    body: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=12.0, bold=False, alignment="JUSTIFY",
        space_before_pt=0.0, space_after_pt=6.0, line_spacing=1.5
    ))
    caption: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=10.0, bold=False, alignment="CENTER",
        space_before_pt=4.0, space_after_pt=6.0
    ))
    toc_entry: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=12.0, bold=False, alignment="LEFT"
    ))
    reference: ParagraphStyleProfile = field(default_factory=lambda: ParagraphStyleProfile(
        font_name="Times New Roman", font_size_pt=10.0, bold=False, alignment="LEFT",
        space_before_pt=0.0, space_after_pt=4.0
    ))

    # Page setup (in cm)
    page_width_cm: float = 21.0        # A4
    page_height_cm: float = 29.7       # A4
    margin_left_cm: float = 3.17       # ~1.25 inches
    margin_right_cm: float = 2.54      # ~1 inch
    margin_top_cm: float = 2.54
    margin_bottom_cm: float = 2.54
    header_distance_cm: float = 1.25
    footer_distance_cm: float = 1.25
    different_first_page: bool = False

    # Institution branding (used in three-part footer)
    institution_name: str = "RV College of Engineering"
    academic_year: str = "2025-26"

    # Header / Footer
    header: HeaderProfile = field(default_factory=HeaderProfile)
    footer: FooterProfile = field(default_factory=FooterProfile)
    first_page_header: Optional[HeaderProfile] = None
    first_page_footer: Optional[FooterProfile] = None

    # Content aids
    bold_keywords: list = field(default_factory=list)  # words to auto-bold in body text

    @property
    def usable_width_cm(self) -> float:
        return self.page_width_cm - self.margin_left_cm - self.margin_right_cm


# Built-in default profiles

def el_report_defaults() -> FormatProfile:
    """EL (Experiential Learning) report defaults — flat numbered, H1 left-aligned."""
    p = FormatProfile(report_type="el_report")
    # H1 left-aligned for EL reports
    p.h1.alignment = "LEFT"
    p.h1.font_size_pt = 14.0
    p.reference.font_size_pt = 10.0
    # EL report: all margins 1 inch (2.54 cm)
    p.margin_left_cm = 2.54
    p.margin_right_cm = 2.54
    p.margin_top_cm = 2.54
    p.margin_bottom_cm = 2.54
    # Header: centered red "EL Topic: <title>" with double bottom rule
    # text is a placeholder — patched at build time from project_context["el_topic"]
    p.header = HeaderProfile(
        has_rule=True,
        rule_val="double",
        rule_sz="8",
        paragraphs=[
            HeaderFooterParaProfile(
                text="",        # filled in by report_tools from el_topic / title
                alignment="CENTER",
                font_name="Times New Roman",
                font_size_pt=11.0,
                bold=False,
                color_hex="C00000",   # dark red, matches RVCE style
            )
        ],
    )
    # Three-part footer: "RV College of Engineering | 2025-26 | Page No. N"
    p.footer = FooterProfile(
        three_part=True,
        has_rule=True,          # double-rule on top
        has_bottom_rule=True,   # thin rule on bottom
        left_text=p.institution_name,
        center_text=p.academic_year,
        right_text_prefix="Page No. ",
    )
    return p


def project_report_defaults() -> FormatProfile:
    """VTU thesis/project report defaults — CHAPTER prefix, H1 centered."""
    p = FormatProfile(report_type="project_report")
    p.h1.alignment = "CENTER"
    p.h1.font_size_pt = 14.0
    p.reference.font_size_pt = 11.0
    return p


def get_default_profile(report_type: str = "el_report") -> FormatProfile:
    if report_type == "project_report":
        return project_report_defaults()
    return el_report_defaults()
