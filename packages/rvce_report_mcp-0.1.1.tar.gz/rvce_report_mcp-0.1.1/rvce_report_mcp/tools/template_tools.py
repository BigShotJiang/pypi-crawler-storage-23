"""
Template tools — read_template and inspect_template.
"""
from __future__ import annotations

import json
import os

from rvce_report_mcp.core.format_extractor import (
    extract_format_profile, profile_to_dict, inspect_template_paragraphs
)


async def read_template(template_path: str, report_type: str = "el_report") -> str:
    """
    Read a sample RVCE DOCX and extract the FormatProfile.

    Parses TOC entries to establish heading hierarchy, then reads body
    Heading N paragraphs for exact font/size/alignment. Extracts header
    and footer structure including tab stops, border rules, and page
    number field positions.

    Args:
        template_path: Absolute path to the sample DOCX file.
        report_type: "el_report" (default) or "project_report".
                     Used as fallback for any missing styles.

    Returns:
        JSON string with the full FormatProfile plus a summary line.
    """
    if not os.path.exists(template_path):
        return json.dumps({"error": f"File not found: {template_path}"})

    try:
        profile = extract_format_profile(template_path, report_type)
        result = profile_to_dict(profile)
        result["summary"] = (
            f"Detected: H1 ({profile.h1.font_size_pt}pt {'Bold' if profile.h1.bold else ''} "
            f"{profile.h1.font_name} {profile.h1.alignment}), "
            f"H2 ({profile.h2.font_size_pt}pt {'Bold' if profile.h2.bold else ''} "
            f"{profile.h2.font_name} {profile.h2.alignment}), "
            f"H3 ({profile.h3.font_size_pt}pt {'Bold Italic' if profile.h3.italic else 'Bold'} "
            f"{profile.h3.font_name}), "
            f"Body ({profile.body.font_size_pt}pt {profile.body.font_name} "
            f"{profile.body.alignment} {profile.body.line_spacing}x spacing), "
            f"Page: {profile.page_width_cm:.1f}x{profile.page_height_cm:.1f}cm, "
            f"Usable width: {profile.usable_width_cm:.2f}cm"
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps({"error": f"Failed to read template: {str(e)}"})


async def inspect_template(template_path: str) -> str:
    """
    Return a paragraph-by-paragraph dump of a DOCX file.

    Each entry includes: index, style_name, font_name, font_size_pt,
    bold, alignment, and a text preview (first 80 characters).
    Use this to verify what the format extractor detects.

    Args:
        template_path: Absolute path to the DOCX file.

    Returns:
        JSON array of paragraph descriptors.
    """
    if not os.path.exists(template_path):
        return json.dumps({"error": f"File not found: {template_path}"})

    try:
        paragraphs = inspect_template_paragraphs(template_path)
        return json.dumps(paragraphs, indent=2)
    except Exception as e:
        return json.dumps({"error": f"Failed to inspect template: {str(e)}"})
