# assets/

Place your RVCE pre-TOC Word template here:

    pre_toc_template.docx

This file must be the original RVCE `.docx` that contains:
- Cover page (with logo, page border, college name)
- Bonafide Certificate page
- Declaration page

The file is used by `generate_pretoc_pages()` via `zipfile` only — it is NEVER
modified. All token substitution happens on a temp copy.

## Tokens the template must contain

| Token | Replaced with |
|---|---|
| `[Team_member_name_1]` … `[Team_member_name_5]` | team member names |
| `[Usn_1]` … `[Usn_5]` | USNs |
| `[title from project_context]` | `project_context.project_title` |
| `[Theme from project_context]` | `project_context.sdg_theme` |
| `[mentor_name from project_context.mentor_details.name]` | faculty mentor name |
| `[project_context.mentor_details.designation]` | faculty designation |
| `[project_context.mentor_details.mentor_dept` | faculty department |
| `[today's date]` | current date (dd Month YYYY) |
| `2025-26` | `academic_year` short form |
| `2025-2026` | `academic_year` long form |
