"""
TOC (Table of Contents) utilities for RVCE Report MCP Server.
Generates a manual TOC from the chapter outline in project_context.
"""
from __future__ import annotations

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from rvce_report_mcp.core import FormatProfile


def _add_toc_entry(doc: Document, text: str, level: int, profile: FormatProfile) -> None:
    """
    Add a single TOC entry paragraph.
    level 0 = chapter heading, 1 = section, 2 = subsection
    Format: text + dot leader tab + [pg] page placeholder
    """
    para = doc.add_paragraph()
    pf = para.paragraph_format

    # Indentation by level
    indent_map = {0: 0.0, 1: 0.5, 2: 1.0}
    left_indent = Cm(indent_map.get(level, 0.0))
    pf.left_indent = left_indent

    pf.space_before = Pt(2)
    pf.space_after = Pt(2)

    # Font
    font_size = 12.0 if level == 0 else 11.0
    bold = level == 0

    # Text run
    run_text = para.add_run(text)
    run_text.font.name = profile.toc_entry.font_name
    run_text.font.size = Pt(font_size)
    run_text.font.bold = bold

    # Tab to right margin with dot leader then page placeholder
    # Add a right-aligned tab stop at the end of the usable line
    tab_stop_pos = Cm(profile.usable_width_cm - 0.5)
    _add_tab_stop(para, tab_stop_pos, "RIGHT", "dot")

    run_tab = para.add_run("\t[pg]")
    run_tab.font.name = profile.toc_entry.font_name
    run_tab.font.size = Pt(font_size)
    run_tab.font.bold = False


def _add_tab_stop(para, position, alignment: str, leader: str) -> None:
    """Add a tab stop to a paragraph via XML."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    pPr = para._element.get_or_add_pPr()
    tabs = pPr.find(qn("w:tabs"))
    if tabs is None:
        tabs = OxmlElement("w:tabs")
        pPr.append(tabs)

    tab = OxmlElement("w:tab")
    align_map = {"LEFT": "left", "CENTER": "center", "RIGHT": "right"}
    leader_map = {"dot": "dot", "none": "none", "dash": "hyphen"}
    tab.set(qn("w:val"), align_map.get(alignment, "right"))
    tab.set(qn("w:leader"), leader_map.get(leader, "none"))
    # Position in twentieths of a point (twips). 1cm = 567 twips
    twips = int(position.cm * 567)
    tab.set(qn("w:pos"), str(twips))
    tabs.append(tab)


def _insert_toc_field(doc: Document, profile: FormatProfile) -> None:
    """
    Insert a Word { TOC } auto-field into the document.

    Uses outline levels (\\u) set by _add_heading so the field automatically
    collects all headings.  The \\h flag adds hyperlinks; \\z suppresses tab/
    page-numbers in Web Layout.  The field is marked dirty so Word refreshes it
    immediately when the user presses Ctrl+A → F9.
    """
    para = doc.add_paragraph()
    para.paragraph_format.space_before = Pt(0)
    para.paragraph_format.space_after = Pt(0)

    # Run 1: fldChar begin (dirty=true so Word knows it needs updating)
    r1 = para.add_run()
    fc_begin = OxmlElement("w:fldChar")
    fc_begin.set(qn("w:fldCharType"), "begin")
    fc_begin.set(qn("w:dirty"), "true")
    r1._r.append(fc_begin)

    # Run 2: instruction text
    r2 = para.add_run()
    instr = OxmlElement("w:instrText")
    instr.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    # \\u  – use outline levels (set via <w:outlineLvl> in each heading's pPr)
    # \\o "1-3" – include outline levels 1-3
    # \\h  – hyperlinks
    # \\z  – suppress tab/page numbers in web layout
    instr.text = ' TOC \\u \\o "1-3" \\h \\z '
    r2._r.append(instr)

    # Run 3: fldChar separate (separates instruction from cached/display content)
    r3 = para.add_run()
    fc_sep = OxmlElement("w:fldChar")
    fc_sep.set(qn("w:fldCharType"), "separate")
    r3._r.append(fc_sep)

    # Run 4: placeholder text shown before first update
    r4 = para.add_run()
    r4.text = "[Press Ctrl+A then F9 to populate the Table of Contents]"
    r4.font.name = profile.body.font_name
    r4.font.size = Pt(profile.body.font_size_pt)
    r4.font.italic = True

    # Run 5: fldChar end
    r5 = para.add_run()
    fc_end = OxmlElement("w:fldChar")
    fc_end.set(qn("w:fldCharType"), "end")
    r5._r.append(fc_end)


def build_toc(doc: Document, chapters: list[dict], profile: FormatProfile) -> None:
    """
    Insert a TABLE OF CONTENTS page backed by a real Word { TOC } field.

    Pressing Ctrl+A → F9 (or right-clicking the field and choosing
    "Update Field") in Word will populate/refresh the page numbers.
    The field reads <w:outlineLvl> values written by _add_heading, so no
    built-in heading styles are required.
    """
    # TOC heading
    toc_heading = doc.add_paragraph("TABLE OF CONTENTS")
    toc_heading.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    toc_heading.paragraph_format.space_after = Pt(12)
    run = toc_heading.runs[0]
    run.font.name = profile.h1.font_name
    run.font.size = Pt(profile.h1.font_size_pt)
    run.font.bold = True

    doc.add_paragraph()  # spacer

    # Insert the auto-updating Word TOC field
    _insert_toc_field(doc, profile)

    doc.add_page_break()


def build_lof(doc: Document, figure_registry: list[dict], profile: FormatProfile) -> None:
    """Build List of Figures page."""
    if not figure_registry:
        return

    heading = doc.add_paragraph("LIST OF FIGURES")
    heading.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    heading.paragraph_format.space_after = Pt(12)
    run = heading.runs[0]
    run.font.name = profile.h1.font_name
    run.font.size = Pt(profile.h1.font_size_pt)
    run.font.bold = True

    doc.add_paragraph()  # spacer

    for entry in figure_registry:
        label = entry["label"]
        caption = entry["caption"]
        _add_toc_entry(doc, f"{label} – {caption}", 1, profile)

    doc.add_page_break()


def build_lot(doc: Document, table_registry: list[dict], profile: FormatProfile) -> None:
    """Build List of Tables page."""
    if not table_registry:
        return

    heading = doc.add_paragraph("LIST OF TABLES")
    heading.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    heading.paragraph_format.space_after = Pt(12)
    run = heading.runs[0]
    run.font.name = profile.h1.font_name
    run.font.size = Pt(profile.h1.font_size_pt)
    run.font.bold = True

    doc.add_paragraph()  # spacer

    for entry in table_registry:
        label = entry["label"]
        caption = entry["caption"]
        _add_toc_entry(doc, f"{label} – {caption}", 1, profile)

    doc.add_page_break()
