"""
Validator for RVCE Report MCP Server.

Validates project_context JSON before any document build begins.
Returns (is_valid: bool, errors: list[str], warnings: list[str]).

Hard errors prevent document creation.
Warnings are returned alongside a successfully-created document.
"""
from __future__ import annotations

import os
import re
import unicodedata


# Unicode emoji detection pattern
_EMOJI_PATTERN = re.compile(
    "["
    "\U0001F300-\U0001F9FF"   # Misc symbols, emoticons, transport, etc.
    "\U0001FA00-\U0001FAFF"   # Extended symbols
    "\u2600-\u27BF"           # Misc symbols and dingbats
    "\uFE00-\uFE0F"           # Variation selectors
    "\u200D"                  # Zero-width joiner
    "]+",
    flags=re.UNICODE,
)

# Paragraph types that are exempt from "no body paragraphs" check
_BODY_EXEMPT_TYPES = {"personal_reflection", "figure", "table",
                       "bullet_list", "numbered_list"}
# Section types where all-non-body is acceptable
_PROSE_EXEMPT_SECTION_TYPES = {"appendix"}


def _contains_emoji(text: str) -> bool:
    return bool(_EMOJI_PATTERN.search(text))


def _word_count(text: str) -> int:
    return len(text.split())


def _check_text_field(path: str, text: str, errors: list, warnings: list) -> None:
    """Check a text field for emoji."""
    if _contains_emoji(text):
        errors.append(f"{path} contains emoji characters. Remove them before generating.")


def validate_project_context(data: dict) -> tuple[bool, list[str], list[str]]:
    """
    Validate the project_context dict.

    Returns:
        (is_valid, errors, warnings)
    """
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(data, dict):
        return False, ["project_context must be a JSON object."], []

    # --- required pretoc fields ---
    if not data.get("project_title", "").strip():
        errors.append("project_title is required (used on the cover and certificate pages).")
    if not data.get("sdg_theme", "").strip():
        errors.append("sdg_theme is required (SDG theme label for the cover page).")
    if not data.get("academic_year", "").strip():
        errors.append("academic_year is required (e.g. '2025-26').")
    mentor = data.get("faculty_mentor")
    if not mentor or not str(mentor.get("name", "")).strip():
        errors.append("faculty_mentor.name is required.")

    # --- team ---
    team = data.get("team")
    if not team:
        errors.append("project_context.team is required and must be non-empty.")
    else:
        if len(team) > 5:
            warnings.append(
                f"team has {len(team)} members. The pre-TOC template supports max 5. "
                f"Members beyond 5 will be ignored in the _pretoc.docx file."
            )
        for i, member in enumerate(team):
            for field in ("name", "usn", "dept", "email"):
                val = member.get(field, "")
                _check_text_field(f"team[{i}].{field}", val, errors, warnings)

    # --- report_type ---
    report_type = data.get("report_type", "el_report")
    if report_type not in ("el_report", "project_report"):
        errors.append(f"report_type must be 'el_report' or 'project_report', got '{report_type}'.")

    # --- chapters ---
    chapters = data.get("chapters")
    if not chapters:
        errors.append("project_context.chapters is required and must be non-empty.")
    else:
        for chapter in chapters:
            _validate_chapter(chapter, errors, warnings)

    # --- appendix ---
    appendix = data.get("appendix")
    if appendix is not None:
        _validate_appendix(appendix, errors, warnings)

    # --- references ---
    refs = data.get("references", [])
    if len(refs) < 5:
        errors.append(f"Only {len(refs)} references provided. Minimum 5 required for a technical report.")
    for i, ref in enumerate(refs):
        _check_text_field(f"references[{i}]", ref, errors, warnings)
        if len(ref.strip()) < 20:
            warnings.append(f"Reference {i + 1} appears malformed (under 20 characters): '{ref}'.")

    is_valid = len(errors) == 0
    return is_valid, errors, warnings


def _validate_chapter(chapter: dict, errors: list, warnings: list) -> None:
    num = chapter.get("number", "?")
    prefix = f"Chapter {num}"

    sections = chapter.get("sections", [])
    if len(sections) < 2:
        errors.append(f"{prefix} has only {len(sections)} section(s). Minimum 2 required.")

    for section in sections:
        _validate_section(section, prefix, errors, warnings, is_appendix=False)


def _validate_appendix(appendix: dict, errors: list, warnings: list) -> None:
    """Appendix validation — allows figures/tables only, no prose requirement."""
    paragraphs = appendix.get("paragraphs", [])
    _check_text_field("appendix.title", appendix.get("title", ""), errors, warnings)
    for i, para in enumerate(paragraphs):
        ptype = para.get("type", "body")
        path = f"appendix / paragraph {i + 1}"
        if ptype == "body":
            _check_text_field(path, para.get("text", ""), errors, warnings)
        if ptype == "figure":
            _validate_figure(para, path, errors, warnings)
        if ptype == "table":
            _validate_table(para, path, errors, warnings)


def _validate_section(section: dict, chapter_prefix: str, errors: list,
                       warnings: list, is_appendix: bool = False) -> None:
    heading = section.get("heading", "?")
    path = f"{chapter_prefix} / section '{heading}'"

    paragraphs = section.get("paragraphs", [])
    subsections = section.get("subsections", [])

    # Total paragraph object count (all types count)
    total_objects = len(paragraphs)
    if total_objects < 3:
        errors.append(
            f"{path} has only {total_objects} paragraph object(s). Minimum 3 required "
            f"(body, list, figure, table all count toward the minimum)."
        )

    body_paras = [p for p in paragraphs if p.get("type") == "body"]
    reflection_paras = [p for p in paragraphs if p.get("type") == "personal_reflection"]
    list_paras = [p for p in paragraphs if p.get("type") in ("bullet_list", "numbered_list")]
    has_any_non_body = len(paragraphs) > len(body_paras)

    # Check for sections with no body prose and no personal_reflection (hard error unless appendix)
    if not is_appendix and len(body_paras) == 0 and len(reflection_paras) == 0:
        errors.append(f"{path} has no body paragraphs and no personal_reflection entries.")

    # Warning: all body, no lists (5+ paragraphs)
    if len(body_paras) >= 5 and len(list_paras) == 0:
        warnings.append(
            f"{path} has no lists. Consider adding a bullet or numbered list for enumerations."
        )

    # Validate individual paragraph objects
    is_first_para = True
    for i, para in enumerate(paragraphs):
        ptype = para.get("type", "body")
        para_path = f"{path} / paragraph {i + 1}"

        if ptype == "body":
            text = para.get("text", "")
            _check_text_field(para_path, text, errors, warnings)
            wc = _word_count(text)

            # Lead-in exemption: first paragraph in section if next is a list
            is_lead_in = (
                is_first_para
                and i + 1 < len(paragraphs)
                and paragraphs[i + 1].get("type") in ("bullet_list", "numbered_list")
            )

            if not is_lead_in:
                # n_body_paras_in_section used for contextual threshold
                if wc < 15 and len(body_paras) < 3:
                    errors.append(
                        f"{para_path} has only {wc} words and the section has fewer than "
                        f"3 body paragraphs. Expand it."
                    )
                elif 15 <= wc < 40:
                    warnings.append(
                        f"{para_path} has only {wc} words. Consider expanding to improve report quality."
                    )

        elif ptype == "figure":
            _validate_figure(para, para_path, errors, warnings)

        elif ptype == "table":
            _validate_table(para, para_path, errors, warnings)

        elif ptype in ("bullet_list", "numbered_list"):
            items = para.get("items", [])
            for j, item in enumerate(items):
                _check_text_field(f"{para_path} / item {j + 1}", item, errors, warnings)

        elif ptype == "personal_reflection":
            entries = para.get("entries", [])
            for j, entry in enumerate(entries):
                _check_text_field(
                    f"{para_path} / entry {j + 1} name", entry.get("name", ""), errors, warnings
                )
                _check_text_field(
                    f"{para_path} / entry {j + 1} text", entry.get("text", ""), errors, warnings
                )

        if ptype == "body":
            is_first_para = False

    # Validate subsections recursively
    for sub in subsections:
        _validate_section(sub, path, errors, warnings, is_appendix=False)


def _validate_figure(para: dict, path: str, errors: list, warnings: list) -> None:
    fig_id = para.get("id", "")
    if not para.get("caption"):
        errors.append(f"Figure '{fig_id}' at {path} has no caption.")
    if para.get("source") == "embed":
        fp = para.get("file_path", "")
        if not fp:
            errors.append(f"Figure '{fig_id}' at {path} has source 'embed' but file_path is missing.")
        elif not os.path.exists(fp):
            errors.append(
                f"Figure '{fig_id}' at {path} has source 'embed' but file does not exist: '{fp}'."
            )


def _validate_table(para: dict, path: str, errors: list, warnings: list) -> None:
    tbl_id = para.get("id", "")
    headers = para.get("headers", [])
    rows = para.get("rows", [])

    if not headers:
        errors.append(f"Table '{tbl_id}' at {path} has no headers.")
    if not rows:
        errors.append(f"Table '{tbl_id}' at {path} has no rows.")
    if not para.get("caption"):
        warnings.append(f"Table '{tbl_id}' at {path} has no caption.")

    col_widths = para.get("col_widths")
    if col_widths is not None:
        total = sum(col_widths)
        if abs(total - 100) > 0.5:
            errors.append(
                f"Table '{tbl_id}' at {path}: col_widths sum to {total:.1f}, must equal 100."
            )

    n_cols = len(headers)
    if n_cols > 8:
        warnings.append(
            f"Table '{tbl_id}' at {path} has {n_cols} columns. "
            f"This will produce very narrow columns on A4."
        )

    # Check for emoji in cells
    for i, row in enumerate(rows):
        for j, cell in enumerate(row):
            _check_text_field(f"{path} / row {i + 1} col {j + 1}", str(cell), errors, warnings)
