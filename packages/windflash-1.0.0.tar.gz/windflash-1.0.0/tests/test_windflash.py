"""Comprehensive WindFlash test suite — all code paths, all versions.

Tests every code path in windflash.py and windflash_train.py:
  • Forward: inference (cached / short-seq fast-path / autotuner)
  • Forward: MHA, GQA, MQA across bf16 & fp16
  • Forward: short seq (N≤128), medium (N=256), long (N=1024,2048)
  • Forward: D=64 and D=128
  • Forward: causal and non-causal
  • Backward: MHA, GQA, causal & non-causal, bf16 & fp16
  • Backward: D=64 and D=128
  • Config cache: save / load / pre-seed Triton autotuner
  • Monkey-patch: enable / disable round-trip
  • Mode switching: inference / training / tts
  • CUDA C++ short-seq path (if available)
"""
import gc
import json
import os
import sys
import math
import tempfile

sys.path.insert(0, "src")

import torch
import triton

# Reproducibility
torch.manual_seed(42)

# ── Import WindFlash ──
import windflash as wf
from windflash import (
    flash_attention,
    enable_windflash,
    disable_windflash,
    set_mode,
    get_mode,
    load_cache,
    optimize,
    _fwd_kernel,
    _fwd_inference,
    _config_cache,
    _patched_sdpa,
    _original_sdpa,
    _CUDA_SHORT_THRESH,
    _SHORT_SEQ_THRESHOLD,
    _SHORT_TILE,
)

# ── Test infrastructure ──
_results = []
_all_ok = True
_section = ""


def section(name):
    global _section
    _section = name
    print(f"\n{'=' * 70}")
    print(f"  {name}")
    print(f"{'=' * 70}")


def check(name, diff, thresh=0.05):
    global _all_ok
    ok = diff < thresh
    status = "PASS" if ok else "FAIL"
    if not ok:
        _all_ok = False
    _results.append((_section, name, diff, thresh, ok))
    print(f"  {'PASS' if ok else 'FAIL'} {name}: max_diff={diff:.6f} (thresh={thresh})")
    return ok


def check_bool(name, condition, msg=""):
    global _all_ok
    ok = bool(condition)
    if not ok:
        _all_ok = False
    _results.append((_section, name, 0 if ok else 1, 0, ok))
    extra = f" ({msg})" if msg else ""
    print(f"  {'PASS' if ok else 'FAIL'} {name}{extra}")
    return ok


def ref_sdpa(q, k, v, causal=False):
    """Reference SDPA with GQA expansion."""
    H_q, H_k = q.shape[1], k.shape[1]
    if H_q != H_k:
        k = k.repeat_interleave(H_q // H_k, dim=1)
        v = v.repeat_interleave(H_q // H_k, dim=1)
    return _original_sdpa(q, k, v, is_causal=causal)


# ===================================================================
# 1. Forward — MHA (basic correctness)
# ===================================================================

section("1. Forward -- MHA basic (B=2, H=8, N=128, D=64)")

B, H, N, D = 2, 8, 128, 64
for dtype, dtype_name, thresh in [
    (torch.bfloat16, "bf16", 0.01),
    (torch.float16, "fp16", 0.005),
]:
    q = torch.randn(B, H, N, D, device="cuda", dtype=dtype)
    k = torch.randn(B, H, N, D, device="cuda", dtype=dtype)
    v = torch.randn(B, H, N, D, device="cuda", dtype=dtype)

    out = flash_attention(q, k, v, causal=False)
    ref = ref_sdpa(q, k, v, causal=False)
    check(f"{dtype_name} non-causal", (out.float() - ref.float()).abs().max().item(), thresh)

    out_c = flash_attention(q, k, v, causal=True)
    ref_c = ref_sdpa(q, k, v, causal=True)
    check(f"{dtype_name} causal", (out_c.float() - ref_c.float()).abs().max().item(), thresh)

# ===================================================================
# 2. Forward — GQA and MQA
# ===================================================================

section("2. Forward -- GQA/MQA")

for H_q, H_k, label in [(8, 2, "GQA 8:2"), (8, 1, "MQA 8:1"), (16, 4, "GQA 16:4"), (16, 8, "GQA 16:8")]:
    q = torch.randn(2, H_q, 128, 64, device="cuda", dtype=torch.bfloat16)
    k = torch.randn(2, H_k, 128, 64, device="cuda", dtype=torch.bfloat16)
    v = torch.randn(2, H_k, 128, 64, device="cuda", dtype=torch.bfloat16)

    out = flash_attention(q, k, v, causal=False)
    ref = ref_sdpa(q, k, v, causal=False)
    check(f"{label} non-causal", (out.float() - ref.float()).abs().max().item(), 0.01)

    out_c = flash_attention(q, k, v, causal=True)
    ref_c = ref_sdpa(q, k, v, causal=True)
    check(f"{label} causal", (out_c.float() - ref_c.float()).abs().max().item(), 0.01)


# ===================================================================
# 3. Forward — Different sequence lengths (tests dispatch tiers)
# ===================================================================

section("3. Forward -- Sequence lengths (dispatch paths)")

for N, path_label in [
    (16,   "very short (CUDA C++ candidate)"),
    (64,   "short (<=128 CUDA C++ thresh)"),
    (128,  "short-seq fast-path boundary"),
    (256,  "short-seq fast-path (<=256)"),
    (512,  "medium"),
    (1024, "long (autotuner)"),
    (2048, "very long"),
]:
    q = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)
    k = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)
    v = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)

    out = flash_attention(q, k, v, causal=True)
    ref = ref_sdpa(q, k, v, causal=True)
    diff = (out.float() - ref.float()).abs().max().item()
    check(f"N={N} ({path_label})", diff, 0.02)


# ===================================================================
# 4. Forward — D=128 (different tile configs)
# ===================================================================

section("4. Forward -- D=128")

for N in [64, 256, 1024]:
    q = torch.randn(1, 8, N, 128, device="cuda", dtype=torch.bfloat16)
    k = torch.randn(1, 8, N, 128, device="cuda", dtype=torch.bfloat16)
    v = torch.randn(1, 8, N, 128, device="cuda", dtype=torch.bfloat16)

    out = flash_attention(q, k, v, causal=True)
    ref = ref_sdpa(q, k, v, causal=True)
    check(f"D=128 N={N}", (out.float() - ref.float()).abs().max().item(), 0.02)


# ===================================================================
# 5. Forward — 3D input (B*H, N, D) squeeze/unsqueeze
# ===================================================================

section("5. Forward -- 3D input (B*H, N, D)")

B, H, N, D = 1, 4, 128, 64
q4 = torch.randn(B, H, N, D, device="cuda", dtype=torch.bfloat16)
k4 = torch.randn(B, H, N, D, device="cuda", dtype=torch.bfloat16)
v4 = torch.randn(B, H, N, D, device="cuda", dtype=torch.bfloat16)

# 4D reference
ref4 = flash_attention(q4, k4, v4, causal=False)

# 3D: reshape to (B*H, N, D)
q3 = q4.reshape(B * H, N, D)
k3 = k4.reshape(B * H, N, D)
v3 = v4.reshape(B * H, N, D)
out3 = flash_attention(q3, k3, v3, causal=False)

check("3D matches 4D", (out3.float() - ref4.reshape(B * H, N, D).float()).abs().max().item(), 0.001)
check_bool("3D output shape", out3.shape == (B * H, N, D), f"got {out3.shape}")


# ===================================================================
# 6. Backward — MHA (correctness of dQ, dK, dV)
# ===================================================================

section("6. Backward -- MHA")

GRAD_THRESH = 0.1  # generous for fp16/bf16 gradients

for dtype, dtype_name in [(torch.float16, "fp16"), (torch.bfloat16, "bf16")]:
    for causal, causal_name in [(False, "non-causal"), (True, "causal")]:
        B2, H2, N2, D2 = 2, 4, 64, 64
        q = torch.randn(B2, H2, N2, D2, device="cuda", dtype=dtype, requires_grad=True)
        k = torch.randn(B2, H2, N2, D2, device="cuda", dtype=dtype, requires_grad=True)
        v = torch.randn(B2, H2, N2, D2, device="cuda", dtype=dtype, requires_grad=True)

        out = flash_attention(q, k, v, causal=causal)
        out.sum().backward()
        dq, dk, dv = q.grad.clone(), k.grad.clone(), v.grad.clone()

        q.grad = k.grad = v.grad = None
        ref = _original_sdpa(q, k, v, is_causal=causal)
        ref.sum().backward()

        check(f"{dtype_name} {causal_name} dQ", (dq.float() - q.grad.float()).abs().max().item(), GRAD_THRESH)
        check(f"{dtype_name} {causal_name} dK", (dk.float() - k.grad.float()).abs().max().item(), GRAD_THRESH)
        check(f"{dtype_name} {causal_name} dV", (dv.float() - v.grad.float()).abs().max().item(), GRAD_THRESH)


# ===================================================================
# 7. Backward — GQA
# ===================================================================

section("7. Backward -- GQA")

for H_q, H_k, label in [(8, 2, "8:2"), (8, 4, "8:4")]:
    B, N, D = 2, 64, 64
    q = torch.randn(B, H_q, N, D, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    k = torch.randn(B, H_k, N, D, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    v = torch.randn(B, H_k, N, D, device="cuda", dtype=torch.bfloat16, requires_grad=True)

    out = flash_attention(q, k, v, causal=False)
    out.sum().backward()
    dq_wf, dk_wf, dv_wf = q.grad.clone(), k.grad.clone(), v.grad.clone()

    # Reference: expand KV, compute grads, then reduce
    q.grad = k.grad = v.grad = None
    q2 = q.detach().requires_grad_(True)
    k_exp = k.detach().repeat_interleave(H_q // H_k, dim=1).requires_grad_(True)
    v_exp = v.detach().repeat_interleave(H_q // H_k, dim=1).requires_grad_(True)
    ref = _original_sdpa(q2, k_exp, v_exp, is_causal=False)
    ref.sum().backward()

    dk_ref = k_exp.grad.view(B, H_k, H_q // H_k, N, D).sum(dim=2)
    dv_ref = v_exp.grad.view(B, H_k, H_q // H_k, N, D).sum(dim=2)

    check(f"GQA {label} dQ", (dq_wf.float() - q2.grad.float()).abs().max().item(), GRAD_THRESH)
    check(f"GQA {label} dK", (dk_wf.float() - dk_ref.float()).abs().max().item(), GRAD_THRESH)
    check(f"GQA {label} dV", (dv_wf.float() - dv_ref.float()).abs().max().item(), GRAD_THRESH)


# ===================================================================
# 8. Backward — D=128
# ===================================================================

section("8. Backward -- D=128")

B2, H2, N2, D2 = 1, 4, 64, 128
q = torch.randn(B2, H2, N2, D2, device="cuda", dtype=torch.bfloat16, requires_grad=True)
k = torch.randn(B2, H2, N2, D2, device="cuda", dtype=torch.bfloat16, requires_grad=True)
v = torch.randn(B2, H2, N2, D2, device="cuda", dtype=torch.bfloat16, requires_grad=True)

out = flash_attention(q, k, v, causal=True)
out.sum().backward()
dq, dk, dv = q.grad.clone(), k.grad.clone(), v.grad.clone()

q.grad = k.grad = v.grad = None
ref = _original_sdpa(q, k, v, is_causal=True)
ref.sum().backward()

check("D=128 dQ", (dq.float() - q.grad.float()).abs().max().item(), GRAD_THRESH)
check("D=128 dK", (dk.float() - k.grad.float()).abs().max().item(), GRAD_THRESH)
check("D=128 dV", (dv.float() - v.grad.float()).abs().max().item(), GRAD_THRESH)


# ===================================================================
# 9. Config cache — save / load / pre-seed
# ===================================================================

section("9. Config cache")

# Save the current cache somewhere temp and test load
with tempfile.TemporaryDirectory() as tmpdir:
    test_cache = wf._ConfigCache()
    test_cache._dir = __import__("pathlib").Path(tmpdir)

    # Populate with known values
    test_cache.put(128, 128, 64, 8, 8, "bf16", True, {
        "BLOCK_M": 64, "BLOCK_N": 64, "num_warps": 4, "num_stages": 3
    })
    test_cache.put(256, 256, 64, 8, 8, "bf16", False, {
        "BLOCK_M": 128, "BLOCK_N": 64, "num_warps": 8, "num_stages": 2
    })

    check_bool("cache put", len(test_cache) == 2, f"len={len(test_cache)}")

    # Save
    test_cache._file = test_cache._dir / "test.json"
    test_cache.save()
    check_bool("cache file created", test_cache._file.exists())

    # Verify JSON content
    data = json.loads(test_cache._file.read_text())
    check_bool("cache JSON valid", len(data) == 2, f"keys={list(data.keys())}")

    # Load into new cache
    test_cache2 = wf._ConfigCache()
    test_cache2._dir = test_cache._dir
    test_cache2._file = test_cache._file
    test_cache2._cache = json.loads(test_cache._file.read_text())
    check_bool("cache reload", len(test_cache2) == 2)

    # Verify lookup
    cfg = test_cache2.get(128, 128, 64, 8, 8, "bf16", True)
    check_bool("cache lookup hit", cfg is not None and cfg["BLOCK_M"] == 64)

    miss = test_cache2.get(512, 512, 64, 8, 8, "bf16", True)
    check_bool("cache lookup miss", miss is None)


# ===================================================================
# 10. Mode switching
# ===================================================================

section("10. Mode switching")

orig_mode = get_mode()

for mode in ["inference", "training", "tts"]:
    set_mode(mode)
    check_bool(f"set_mode({mode!r})", get_mode() == mode)

# Invalid mode
try:
    set_mode("bogus")
    check_bool("invalid mode raises", False, "no exception raised")
except ValueError:
    check_bool("invalid mode raises ValueError", True)

# Training mode forces backward path even without requires_grad
set_mode("training")
q_t = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
k_t = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
v_t = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
out_t = flash_attention(q_t, k_t, v_t)
ref_t = ref_sdpa(q_t, k_t, v_t)
check("training mode forward", (out_t.float() - ref_t.float()).abs().max().item(), 0.01)

# TTS mode: higher short-seq threshold
set_mode("tts")
q_tts = torch.randn(1, 8, 400, 64, device="cuda", dtype=torch.bfloat16)
k_tts = torch.randn(1, 8, 400, 64, device="cuda", dtype=torch.bfloat16)
v_tts = torch.randn(1, 8, 400, 64, device="cuda", dtype=torch.bfloat16)
out_tts = flash_attention(q_tts, k_tts, v_tts, causal=True)
ref_tts = ref_sdpa(q_tts, k_tts, v_tts, causal=True)
check("tts mode forward (N=400)", (out_tts.float() - ref_tts.float()).abs().max().item(), 0.02)

set_mode(orig_mode)


# ===================================================================
# 11. Monkey-patch round-trip
# ===================================================================

section("11. Monkey-patch (enable/disable)")

# Ensure we start clean
disable_windflash()
check_bool("native SDPA restored",
           torch.nn.functional.scaled_dot_product_attention is _original_sdpa)

enable_windflash()
check_bool("SDPA patched",
           torch.nn.functional.scaled_dot_product_attention is _patched_sdpa)

# Quick test through monkey-patched SDPA
q_mp = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
k_mp = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
v_mp = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)

out_mp = torch.nn.functional.scaled_dot_product_attention(q_mp, k_mp, v_mp, is_causal=True)
disable_windflash()
ref_mp = torch.nn.functional.scaled_dot_product_attention(q_mp, k_mp, v_mp, is_causal=True)
check("monkey-patch round-trip", (out_mp.float() - ref_mp.float()).abs().max().item(), 0.01)

check_bool("SDPA fully restored",
           torch.nn.functional.scaled_dot_product_attention is _original_sdpa)


# ===================================================================
# 12. Patched SDPA fallback (unsupported cases)
# ===================================================================

section("12. Patched SDPA -- fallback path")

# These should fall through to native SDPA:
# - CPU tensors
q_cpu = torch.randn(1, 4, 64, 64, dtype=torch.bfloat16)
k_cpu = torch.randn(1, 4, 64, 64, dtype=torch.bfloat16)
v_cpu = torch.randn(1, 4, 64, 64, dtype=torch.bfloat16)
out_cpu = _patched_sdpa(q_cpu, k_cpu, v_cpu)
ref_cpu = _original_sdpa(q_cpu, k_cpu, v_cpu)
check("CPU fallback", (out_cpu.float() - ref_cpu.float()).abs().max().item(), 1e-6)

# - fp32 tensors (not supported by WindFlash)
q32 = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.float32)
k32 = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.float32)
v32 = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.float32)
out32 = _patched_sdpa(q32, k32, v32)
ref32 = _original_sdpa(q32, k32, v32)
check("fp32 fallback", (out32.float() - ref32.float()).abs().max().item(), 1e-5)

# - With attention mask (not supported)
mask = torch.zeros(64, 64, device="cuda", dtype=torch.bfloat16)
q_m = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
k_m = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
v_m = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
out_mask = _patched_sdpa(q_m, k_m, v_m, attn_mask=mask)
ref_mask = _original_sdpa(q_m, k_m, v_m, attn_mask=mask)
check("attn_mask fallback", (out_mask.float() - ref_mask.float()).abs().max().item(), 1e-5)


# ===================================================================
# 13. CUDA C++ short-seq kernel (if available)
# ===================================================================

section("13. CUDA C++ short-seq kernel")

if wf._wf_cuda is not None:
    print("  CUDA C++ extension available -- testing...")
    for N in [16, 32, 64, 128]:
        q = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)
        k = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)
        v = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)

        # Force CUDA C++ path through _fwd_inference
        set_mode("inference")
        out = _fwd_inference(q, k, v, causal=True, sm_scale=1.0 / math.sqrt(64))
        ref = ref_sdpa(q, k, v, causal=True)
        check(f"CUDA C++ N={N}", (out.float() - ref.float()).abs().max().item(), 0.02)
    set_mode(orig_mode)
else:
    print("  CUDA C++ extension not available -- skipping (expected on Windows)")
    check_bool("CUDA C++ graceful skip", True, "windflash_cuda not loaded")


# ===================================================================
# 14. Custom sm_scale
# ===================================================================

section("14. Custom sm_scale")

q = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
k = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)
v = torch.randn(1, 4, 64, 64, device="cuda", dtype=torch.bfloat16)

for scale in [0.05, 0.5, 2.0]:
    out = flash_attention(q, k, v, sm_scale=scale)
    ref = _original_sdpa(q, k, v, scale=scale)
    check(f"sm_scale={scale}", (out.float() - ref.float()).abs().max().item(), 0.02)


# ===================================================================
# 15. TTS-realistic shapes (Qwen3-TTS: H_q=16, H_k=8, D=64)
# ===================================================================

section("15. TTS-realistic shapes (Qwen3-TTS GQA 16:8)")

for N in [1, 32, 128, 512]:
    q = torch.randn(1, 16, N, 64, device="cuda", dtype=torch.bfloat16)
    k = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)
    v = torch.randn(1, 8, N, 64, device="cuda", dtype=torch.bfloat16)

    out = flash_attention(q, k, v, causal=True)
    ref = ref_sdpa(q, k, v, causal=True)
    check(f"TTS GQA 16:8 N={N}", (out.float() - ref.float()).abs().max().item(), 0.02)


# ===================================================================
# Summary
# ===================================================================

print(f"\n\n{'=' * 70}")
print(f"  TEST SUMMARY")
print(f"{'=' * 70}")

passed = sum(1 for r in _results if r[4])
failed = sum(1 for r in _results if not r[4])
total = len(_results)

# Group by section
from collections import defaultdict
by_section = defaultdict(list)
for sec, name, diff, thresh, ok in _results:
    by_section[sec].append((name, ok))

for sec, tests in by_section.items():
    sec_ok = all(ok for _, ok in tests)
    mark = "PASS" if sec_ok else "FAIL"
    n_pass = sum(1 for _, ok in tests if ok)
    print(f"  {mark} {sec}: {n_pass}/{len(tests)}")
    if not sec_ok:
        for name, ok in tests:
            if not ok:
                print(f"      FAIL {name}")

print(f"\n  Total: {passed}/{total} passed, {failed} failed")
print(f"{'=' * 70}")

if _all_ok:
    print("\n  ALL TESTS PASSED!\n")
else:
    print(f"\n  {failed} TEST(S) FAILED\n")
    sys.exit(1)
