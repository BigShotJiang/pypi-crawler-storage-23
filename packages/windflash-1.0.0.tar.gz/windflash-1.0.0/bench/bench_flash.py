#!/usr/bin/env python3
"""
Comprehensive Attention Benchmark
==================================
Compares WindFlash (Triton) against every available PyTorch SDPA
backend, plus a naive manual implementation.

Measures:  latency (ms) | throughput (TFLOP/s) | peak VRAM (MB) | correctness

Usage:
    python bench_flash.py                 # both GPUs, default configs
    python bench_flash.py --gpu 0         # RTX 4090 only
    python bench_flash.py --gpu 1         # RTX 3080 Ti only
    python bench_flash.py --causal        # causal masking
    python bench_flash.py --save          # write results to bench_results.csv
    python bench_flash.py --quick         # fewer configs for a fast run
"""

from __future__ import annotations
import argparse, csv, gc, math, os, sys, time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Callable

import torch
import torch.nn.functional as F

sys.path.insert(0, "src")
from windflash import flash_attention

torch.backends.cuda.matmul.allow_tf32 = True

# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

@dataclass
class BenchResult:
    backend: str
    B: int
    H: int
    N: int
    D: int
    dtype: str
    causal: bool
    gpu: str
    latency_ms: float
    tflops: float
    peak_mem_mb: float
    max_diff: float          # vs reference (PyTorch math backend)
    correct: bool

    def row(self) -> list:
        return [
            self.backend, self.gpu,
            f"{self.B}x{self.H}x{self.N}x{self.D}", self.dtype,
            "causal" if self.causal else "full",
            f"{self.latency_ms:.3f}", f"{self.tflops:.2f}",
            f"{self.peak_mem_mb:.1f}",
            f"{self.max_diff:.6f}", "Y" if self.correct else "N",
        ]


def attention_flops(B: int, H: int, N: int, D: int, causal: bool) -> float:
    """FLOPs for attention: 2 matmuls.  Q@K^T + attn@V = 4*B*H*N*N*D."""
    flops = 4 * B * H * N * N * D
    if causal:
        flops = flops // 2
    return flops


def warm_and_bench(
    fn: Callable,
    device: torch.device,
    warmup: int = 15,
    iters: int = 100,
) -> tuple[float, float]:
    """Returns (latency_ms, peak_mem_mb).

    If fn has a ``_sdpa_ctx`` attribute (a context manager), it is entered
    once around the entire warmup+bench region so that forced-backend SDPA
    calls don't pay context-manager overhead on every iteration.
    """
    backend = getattr(fn, "_sdpa_backend", None)
    ctx = torch.nn.attention.sdpa_kernel(backend) if backend else None
    if ctx:
        ctx.__enter__()

    try:
        # Warmup
        for _ in range(warmup):
            fn()
        torch.cuda.synchronize(device)

        # Memory tracking run
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
        mem_before = torch.cuda.max_memory_allocated(device)
        fn()
        torch.cuda.synchronize(device)
        peak_mem_mb = (torch.cuda.max_memory_allocated(device) - mem_before) / (1024 ** 2)

        # Timing with CUDA events (most accurate)
        start_events = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
        end_events   = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]

        torch.cuda.synchronize(device)
        for i in range(iters):
            start_events[i].record(torch.cuda.current_stream(device))
            fn()
            end_events[i].record(torch.cuda.current_stream(device))
        torch.cuda.synchronize(device)

        times = [s.elapsed_time(e) for s, e in zip(start_events, end_events)]
        # Drop top/bottom 10% outliers
        times.sort()
        trim = max(1, len(times) // 10)
        latency_ms = sum(times[trim:-trim]) / len(times[trim:-trim])
        return latency_ms, peak_mem_mb
    finally:
        if ctx:
            ctx.__exit__(None, None, None)


# ──────────────────────────────────────────────────────────────────────
# Backend definitions
# ──────────────────────────────────────────────────────────────────────

def make_naive_attention(q, k, v, causal: bool, sm_scale: float):
    """Textbook matmul attention -- no fusion, full materialisation."""
    def fn():
        attn = torch.matmul(q, k.transpose(-2, -1)) * sm_scale
        if causal:
            N = q.shape[-2]
            mask = torch.triu(torch.ones(N, N, device=q.device, dtype=torch.bool), diagonal=1)
            attn.masked_fill_(mask, float("-inf"))
        attn = attn.softmax(dim=-1)
        return torch.matmul(attn, v)
    return fn


# ---------- helpers for forced-backend SDPA (no per-call context manager) -----

_SDPA_BACKENDS = {
    "MATH":               torch.nn.attention.SDPBackend.MATH,
    "EFFICIENT_ATTENTION": torch.nn.attention.SDPBackend.EFFICIENT_ATTENTION,
    "CUDNN_ATTENTION":     torch.nn.attention.SDPBackend.CUDNN_ATTENTION,
}
try:
    _SDPA_BACKENDS["FLASH_ATTENTION"] = torch.nn.attention.SDPBackend.FLASH_ATTENTION
except AttributeError:
    pass

_original_sdpa = F.scaled_dot_product_attention


def _make_sdpa_forced(backend_enum):
    """Create a maker that pins a single SDPA backend via the context manager
    applied OUTSIDE the hot loop (see `warm_and_bench`)."""
    def maker(q, k, v, causal: bool):
        def fn():
            return _original_sdpa(q, k, v, is_causal=causal)
        fn._sdpa_backend = backend_enum  # store enum, not a CM instance
        return fn
    return maker


def make_sdpa_auto(q, k, v, causal: bool):
    """PyTorch SDPA with automatic backend selection."""
    def fn():
        return _original_sdpa(q, k, v, is_causal=causal)
    return fn


def make_windflash(q, k, v, causal: bool):
    """WindFlash full dispatch (CUDA C++ short -> Triton tiled)."""
    def fn():
        return flash_attention(q, k, v, causal=causal)
    return fn


# WindFlash sub-kernel benchmarks
try:
    from windflash_cuda import short_attn_fwd as _cuda_short, tiled_attn_fwd as _cuda_tiled
except ImportError:
    _cuda_short = _cuda_tiled = None


def make_wf_triton(q, k, v, causal: bool):
    """WindFlash Triton-only path (bypass CUDA C++ dispatch)."""
    from windflash import _fwd_inference, _wf_cuda
    # Temporarily disable CUDA path to force Triton
    import windflash as _wf_mod
    def fn():
        saved = _wf_mod._wf_cuda
        _wf_mod._wf_cuda = None
        try:
            return flash_attention(q, k, v, causal=causal)
        finally:
            _wf_mod._wf_cuda = saved
    return fn


def make_wf_cuda_short(q, k, v, causal: bool):
    """WindFlash CUDA C++ short-seq kernel directly."""
    if _cuda_short is None:
        return None
    sm_scale = 1.0 / math.sqrt(q.shape[-1])
    qc, kc, vc = q.contiguous(), k.contiguous(), v.contiguous()
    def fn():
        return _cuda_short(qc, kc, vc, sm_scale, causal)
    return fn


def make_wf_cuda_tiled(q, k, v, causal: bool):
    """WindFlash CUDA C++ tiled kernel directly."""
    if _cuda_tiled is None:
        return None
    sm_scale = 1.0 / math.sqrt(q.shape[-1])
    qc, kc, vc = q.contiguous(), k.contiguous(), v.contiguous()
    def fn():
        return _cuda_tiled(qc, kc, vc, sm_scale, causal)
    return fn


# Try to import flash-attn package if available
try:
    from flash_attn import flash_attn_func as _flash_attn_func
    def make_flash_attn_pkg(q, k, v, causal: bool):
        """flash-attn package (Dao AI Lab)."""
        # flash-attn expects (B, N, H, D) layout
        qt = q.transpose(1, 2).contiguous()
        kt = k.transpose(1, 2).contiguous()
        vt = v.transpose(1, 2).contiguous()
        def fn():
            return _flash_attn_func(qt, kt, vt, causal=causal).transpose(1, 2)
        return fn
except ImportError:
    make_flash_attn_pkg = None

# Try FlexAttention (PyTorch 2.10+)
try:
    from torch.nn.attention.flex_attention import flex_attention as _flex_attn, create_block_mask
    def make_flex_attention(q, k, v, causal: bool):
        """PyTorch FlexAttention."""
        B, H, N, D = q.shape
        if causal:
            def causal_mask(b, h, q_idx, kv_idx):
                return q_idx >= kv_idx
            block_mask = create_block_mask(causal_mask, B=B, H=H, Q_LEN=N, KV_LEN=N)
            compiled_flex = torch.compile(_flex_attn)
            # warmup compile
            for _ in range(3):
                compiled_flex(q, k, v, block_mask=block_mask)
            torch.cuda.synchronize()
            def fn():
                return compiled_flex(q, k, v, block_mask=block_mask)
        else:
            compiled_flex = torch.compile(_flex_attn)
            for _ in range(3):
                compiled_flex(q, k, v)
            torch.cuda.synchronize()
            def fn():
                return compiled_flex(q, k, v)
        return fn
except (ImportError, Exception):
    make_flex_attention = None


BACKENDS: dict[str, Callable] = {
    "Naive (matmul)":    make_naive_attention,
    "SDPA math":         _make_sdpa_forced(_SDPA_BACKENDS["MATH"]),
    "SDPA efficient":    _make_sdpa_forced(_SDPA_BACKENDS["EFFICIENT_ATTENTION"]),
    "SDPA cuDNN":        _make_sdpa_forced(_SDPA_BACKENDS["CUDNN_ATTENTION"]),
    "SDPA auto":         make_sdpa_auto,
    "WindFlash":         make_windflash,
    "WF Triton-only":    make_wf_triton,
    "WF CUDA short":     make_wf_cuda_short,
    "WF CUDA tiled":     make_wf_cuda_tiled,
}

# Add flash-attn package if available
if make_flash_attn_pkg is not None:
    BACKENDS["flash-attn pkg"] = make_flash_attn_pkg

# Add FlexAttention if available
if make_flex_attention is not None:
    BACKENDS["FlexAttention"] = make_flex_attention

# Add Flash Attention backend if present in PyTorch
if "FLASH_ATTENTION" in _SDPA_BACKENDS:
    BACKENDS["SDPA flash"] = _make_sdpa_forced(_SDPA_BACKENDS["FLASH_ATTENTION"])


# ──────────────────────────────────────────────────────────────────────
# Configs:  (B, H, N, D) spanning TTS, LLM, and stress-test workloads
# ──────────────────────────────────────────────────────────────────────

FULL_CONFIGS = [
    # Small TTS-like (Qwen3-TTS 12Hz)
    (1,  14,   64,  64),
    (1,  14,  128,  64),
    (1,  14,  256,  64),
    (1,  14,  512,  64),
    # Medium sequences
    (1,  14, 1024,  64),
    (1,  14, 2048,  64),
    # Larger / LLM-like
    (1,  32,  512, 128),
    (1,  32, 1024, 128),
    (1,  32, 2048, 128),
    (1,  32, 4096, 128),
    # Batch
    (4,  14,  512,  64),
    (8,  14,  256,  64),
]

QUICK_CONFIGS = [
    (1, 14,  128, 64),
    (1, 14,  512, 64),
    (1, 14, 2048, 64),
    (1, 32, 1024, 128),
    (4, 14,  512, 64),
]


# ──────────────────────────────────────────────────────────────────────
# Core runner
# ──────────────────────────────────────────────────────────────────────

def get_reference(q, k, v, causal: bool) -> torch.Tensor:
    """Math backend as ground truth."""
    with torch.nn.attention.sdpa_kernel(torch.nn.attention.SDPBackend.MATH):
        return F.scaled_dot_product_attention(q, k, v, is_causal=causal).float()


def run_single(
    backend_name: str,
    make_fn: Callable,
    B: int, H: int, N: int, D: int,
    dtype: torch.dtype,
    causal: bool,
    device: torch.device,
    warmup: int,
    iters: int,
) -> BenchResult | None:
    """Benchmark one backend on one config.  Returns None on skip/failure."""
    dtype_name = "bf16" if dtype == torch.bfloat16 else "fp16"
    sm_scale = 1.0 / math.sqrt(D)

    q = torch.randn(B, H, N, D, device=device, dtype=dtype)
    k = torch.randn(B, H, N, D, device=device, dtype=dtype)
    v = torch.randn(B, H, N, D, device=device, dtype=dtype)

    # Reference for correctness check
    with torch.no_grad():
        ref = get_reference(q, k, v, causal)

    try:
        if backend_name == "Naive (matmul)":
            fn = make_fn(q, k, v, causal, sm_scale)
        else:
            fn = make_fn(q, k, v, causal)

        if fn is None:
            return None

        # Quick correctness check — enter forced-backend ctx if present
        backend = getattr(fn, "_sdpa_backend", None)
        with torch.no_grad():
            if backend:
                with torch.nn.attention.sdpa_kernel(backend):
                    test_out = fn()
            else:
                test_out = fn()
        if test_out is None:
            return None
        max_diff = (test_out.float() - ref).abs().max().item()

        # Benchmark
        with torch.no_grad():
            latency_ms, peak_mem = warm_and_bench(fn, device, warmup=warmup, iters=iters)

        flops = attention_flops(B, H, N, D, causal)
        tflops = flops / (latency_ms / 1000) / 1e12

        return BenchResult(
            backend=backend_name, B=B, H=H, N=N, D=D,
            dtype=dtype_name, causal=causal,
            gpu=torch.cuda.get_device_name(device),
            latency_ms=latency_ms, tflops=tflops,
            peak_mem_mb=peak_mem, max_diff=max_diff,
            correct=max_diff < 0.05,
        )
    except Exception as e:
        return BenchResult(
            backend=backend_name, B=B, H=H, N=N, D=D,
            dtype=dtype_name, causal=causal,
            gpu=torch.cuda.get_device_name(device),
            latency_ms=float("nan"), tflops=0.0,
            peak_mem_mb=0.0, max_diff=float("nan"),
            correct=False,
        )


# ──────────────────────────────────────────────────────────────────────
# Output formatting
# ──────────────────────────────────────────────────────────────────────

def print_header():
    hdr = (
        f"{'Backend':<22} {'GPU':<16} {'Shape':<18} {'Dtype':<5} {'Mode':<7}"
        f" {'Latency':>9} {'TFLOP/s':>8} {'Mem MB':>8} {'MaxDiff':>10} {'OK':>3}"
    )
    print(hdr)
    print("-" * len(hdr))


def print_result(r: BenchResult):
    lat = f"{r.latency_ms:.3f}" if not math.isnan(r.latency_ms) else "SKIP"
    tfl = f"{r.tflops:.2f}" if r.tflops > 0 else "-"
    mem = f"{r.peak_mem_mb:.1f}" if r.peak_mem_mb > 0 else "-"
    diff = f"{r.max_diff:.6f}" if not math.isnan(r.max_diff) else "-"
    ok = "Y" if r.correct else ("SKIP" if math.isnan(r.latency_ms) else "N")
    gpu_short = r.gpu.replace("NVIDIA GeForce ", "")
    shape = f"{r.B}x{r.H}x{r.N}x{r.D}"
    mode = "causal" if r.causal else "full"
    print(
        f"{r.backend:<22} {gpu_short:<16} {shape:<18} {r.dtype:<5} {mode:<7}"
        f" {lat:>9} {tfl:>8} {mem:>8} {diff:>10} {ok:>3}"
    )


def print_summary(results: list[BenchResult]):
    """Compact comparison table grouped by config."""
    print("\n")
    print("=" * 80)
    print("  SUMMARY - Speedup vs Naive (matmul) baseline")
    print("=" * 80)

    from collections import defaultdict
    groups: dict[tuple, list[BenchResult]] = defaultdict(list)
    for r in results:
        key = (r.gpu, r.B, r.H, r.N, r.D, r.dtype, r.causal)
        groups[key].append(r)

    for key, group in groups.items():
        gpu, B, H, N, D, dtype, causal = key
        gpu_short = gpu.replace("NVIDIA GeForce ", "")
        mode = "causal" if causal else "full"
        print(f"\n  {gpu_short}  |  {B}x{H}x{N}x{D}  {dtype}  {mode}")
        print(f"  {'-' * 60}")

        naive = next((r for r in group if "Naive" in r.backend), None)
        baseline_ms = naive.latency_ms if naive and not math.isnan(naive.latency_ms) else None

        ranked = sorted(group, key=lambda r: r.latency_ms if not math.isnan(r.latency_ms) else 1e9)
        best_ms = ranked[0].latency_ms if ranked and not math.isnan(ranked[0].latency_ms) else None

        for i, r in enumerate(ranked):
            if math.isnan(r.latency_ms):
                medal = "   "
                print(f"  {medal} {r.backend:<22}  SKIPPED")
                continue
            medals = ["#1", "#2", "#3"]
            medal = medals[i] if i < 3 else "  "
            speedup_naive = f"{baseline_ms / r.latency_ms:.1f}x" if baseline_ms else "-"
            bar_len = int(40 * (best_ms / r.latency_ms)) if best_ms else 0
            bar = "#" * bar_len + "." * (40 - bar_len)
            print(
                f"  {medal:>3} {r.backend:<22} {r.latency_ms:>8.3f} ms  "
                f"{speedup_naive:>6} vs naive  {bar}"
            )


# ──────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Attention Backend Benchmark")
    parser.add_argument("--gpu", type=int, nargs="*", default=None,
                        help="GPU indices to test (default: all)")
    parser.add_argument("--causal", action="store_true", help="Test causal masking")
    parser.add_argument("--both-modes", action="store_true",
                        help="Test both causal and non-causal")
    parser.add_argument("--dtype", choices=["bf16", "fp16", "both"], default="bf16",
                        help="Data type(s) to test")
    parser.add_argument("--save", action="store_true", help="Save results to CSV")
    parser.add_argument("--quick", action="store_true", help="Fewer configs")
    parser.add_argument("--warmup", type=int, default=15, help="Warmup iterations")
    parser.add_argument("--iters", type=int, default=100, help="Benchmark iterations")
    args = parser.parse_args()

    # Resolve GPUs
    gpu_ids = args.gpu if args.gpu is not None else list(range(torch.cuda.device_count()))
    devices = [torch.device(f"cuda:{i}") for i in gpu_ids]

    # Resolve dtypes
    dtypes: list[torch.dtype] = []
    if args.dtype in ("bf16", "both"):
        dtypes.append(torch.bfloat16)
    if args.dtype in ("fp16", "both"):
        dtypes.append(torch.float16)

    # Resolve causal modes
    if args.both_modes:
        causal_modes = [False, True]
    else:
        causal_modes = [args.causal]

    configs = QUICK_CONFIGS if args.quick else FULL_CONFIGS

    # -- System info --
    print("+" + "=" * 62 + "+")
    print("|        ATTENTION BACKEND BENCHMARK" + " " * 28 + "|")
    print("+" + "=" * 62 + "+")
    pt_ver = torch.__version__
    cuda_ver = torch.version.cuda
    try:
        import triton
        tri_ver = triton.__version__
    except ImportError:
        tri_ver = "N/A"
    print(f"|  PyTorch {pt_ver:<12}  CUDA {cuda_ver:<8}  Triton {tri_ver:<8}  |")
    for dev in devices:
        name = torch.cuda.get_device_name(dev)
        mem = torch.cuda.get_device_properties(dev).total_memory / (1024**3)
        cc = torch.cuda.get_device_capability(dev)
        print(f"|  {name:<35} {mem:.0f} GB   SM {cc[0]}.{cc[1]:<3} |")
    print(f"|  Configs: {len(configs):<3}  Backends: {len(BACKENDS):<3}  "
          f"Warmup: {args.warmup:<4}  Iters: {args.iters:<5}    |")
    print("+" + "=" * 62 + "+")
    print()

    print()

    # -- Run benchmarks --
    all_results: list[BenchResult] = []
    # We test all backends per-GPU since Triton compiles per compute capability
    total = len(devices) * len(configs) * len(dtypes) * len(causal_modes) * len(BACKENDS)
    print(f"Running up to {total} benchmarks...\n")
    print_header()

    prev_cc = None
    for dev in devices:
        # Set current device so Triton compiles kernels for correct SM
        torch.cuda.set_device(dev)
        cc = torch.cuda.get_device_capability(dev)

        # If compute capability changed, clear Triton JIT cache so it recompiles
        if cc != prev_cc:
            try:
                import triton
                triton.runtime.jit.JITFunction.cache_hook = None
                # Clear all cached kernels
                for attr in dir(triton):
                    obj = getattr(triton, attr, None)
                    if hasattr(obj, "cache"):
                        try:
                            obj.cache.clear()
                        except Exception:
                            pass
            except Exception:
                pass
            prev_cc = cc

        # Check which backends work on THIS GPU
        gpu_backends: dict[str, Callable] = {}
        test_q = torch.randn(1, 1, 64, 64, device=dev, dtype=torch.bfloat16)
        test_k = test_q.clone()
        test_v = test_q.clone()
        for name, make_fn in BACKENDS.items():
            try:
                if name == "Naive (matmul)":
                    fn = make_fn(test_q, test_k, test_v, False, 0.125)
                else:
                    fn = make_fn(test_q, test_k, test_v, False)
                if fn is None:
                    continue
                backend = getattr(fn, "_sdpa_backend", None)
                with torch.no_grad():
                    if backend:
                        with torch.nn.attention.sdpa_kernel(backend):
                            fn()
                    else:
                        fn()
                gpu_backends[name] = make_fn
            except Exception:
                pass
        del test_q, test_k, test_v
        torch.cuda.empty_cache()

        gpu_name = torch.cuda.get_device_name(dev).replace("NVIDIA GeForce ", "")
        print(f"--- {gpu_name} ({len(gpu_backends)}/{len(BACKENDS)} backends) ---\n")

        for dtype in dtypes:
            for causal in causal_modes:
                for B, H, N, D in configs:
                    for backend_name, make_fn in gpu_backends.items():
                        # Skip naive for N >= 4096 (too slow / OOM)
                        if "Naive" in backend_name and N >= 4096:
                            continue

                        r = run_single(
                            backend_name, make_fn,
                            B, H, N, D, dtype, causal, dev,
                            warmup=args.warmup, iters=args.iters,
                        )
                        if r is not None:
                            all_results.append(r)
                            print_result(r)

                    torch.cuda.empty_cache()
                    gc.collect()
                    print()  # blank line between configs

    # -- Summary --
    print_summary(all_results)

    # -- Save CSV --
    if args.save:
        csv_path = "bench_results.csv"
        with open(csv_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow([
                "backend", "gpu", "shape", "dtype", "mode",
                "latency_ms", "tflops", "peak_mem_mb", "max_diff", "correct"
            ])
            for r in all_results:
                w.writerow(r.row())
        print(f"\nResults saved to {csv_path}")

    print("\nDone.")


if __name__ == "__main__":
    main()
