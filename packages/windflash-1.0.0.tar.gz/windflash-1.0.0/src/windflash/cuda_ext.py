"""WindFlash CUDA C++ extension -- native nvcc short-seq attention kernel.

Dimension-parallel design: one thread per head-dim element, dot products
via warp shuffle + shared-memory cross-warp reduction.
Fully coalesced K/V loads.  Grid = N_q * B * H_q blocks for max SM util.

Requires: CUDA Toolkit 13.1+, MSVC 2022 (Windows) or g++ (Linux).
Falls back to NVRTC runtime compilation if nvcc is unavailable.
"""

from __future__ import annotations

import logging
import os
import platform
from pathlib import Path

import torch

_log = logging.getLogger(__name__)

_ext = None  # compiled module, or False if failed

# ---- CUDA kernel source ----------------------------------------------

_CUDA_SRC = r'''
// PyTorch injects -D__CUDA_NO_BFLOAT16_CONVERSIONS__ which blocks
// __float2bfloat16 / __bfloat162float.  Undo that.
#undef __CUDA_NO_BFLOAT16_CONVERSIONS__
#undef __CUDA_NO_BFLOAT16_OPERATORS__

#include <cuda_bf16.h>
#include <cuda_runtime.h>

// NOTE: We do NOT include <torch/extension.h> here to avoid PyTorch's
// dynamo headers exploding under nvcc + MSVC.  All torch logic is in
// the C++ source below.  This file only contains the kernel + a
// C-linkage launcher.

/*  Grid : (N_q * total_heads, 1, 1)   -- one block per (head, query-row)
    Block: (D,              1, 1)       -- one thread per head-dim element
    Layout: blockIdx = qi * total_heads + head_q   (qi-major for causal balance)
*/
__launch_bounds__(128)
__global__ void windflash_short_fwd_kernel(
    const __nv_bfloat16* __restrict__ Q,
    const __nv_bfloat16* __restrict__ K,
    const __nv_bfloat16* __restrict__ V,
    __nv_bfloat16*       __restrict__ O,
    int N_q, int N_k, int D,
    int H_q, int H_k,
    float sm_scale,
    int is_causal,
    int total_heads)
{
    const int flat   = blockIdx.x;
    const int qi     = flat / total_heads;
    const int head_q = flat % total_heads;
    const int tid    = threadIdx.x;

    /* GQA mapping */
    const int batch   = head_q / H_q;
    const int lhq     = head_q % H_q;
    const int gsize   = H_q / H_k;
    const int lhk     = lhq / gsize;
    const int head_kv = batch * H_k + lhk;

    const long long q_off   = (long long)head_q  * N_q * D + (long long)qi * D;
    const long long kv_base = (long long)head_kv * N_k * D;

    float q_val = __bfloat162float(Q[q_off + tid]);

    float m_val = -1e38f, l_val = 0.0f, o_acc = 0.0f;

    const int num_warps = (D + 31) >> 5;
    const int warp_id   = tid >> 5;
    const int lane      = tid & 31;
    __shared__ float s_partial[4];

    const int kend = is_causal ? (qi + 1 < N_k ? qi + 1 : N_k) : N_k;

    for (int ki = 0; ki < kend; ki++) {
        const long long kv_off = kv_base + (long long)ki * D;

        /* coalesced K load + partial dot product */
        float prod = q_val * __bfloat162float(K[kv_off + tid]);

        /* intra-warp shuffle reduction */
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 16);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 8);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 4);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 2);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 1);

        /* cross-warp reduce via smem */
        if (lane == 0) s_partial[warp_id] = prod;
        __syncthreads();

        float score = s_partial[0];
        if (num_warps > 1) score += s_partial[1];
        if (num_warps > 2) score += s_partial[2];
        if (num_warps > 3) score += s_partial[3];
        score *= sm_scale;

        __syncthreads();

        /* online softmax */
        float m_new = fmaxf(m_val, score);
        float eo = __expf(m_val - m_new);
        float en = __expf(score - m_new);
        l_val = l_val * eo + en;

        /* coalesced V load + accumulate */
        o_acc = o_acc * eo + en * __bfloat162float(V[kv_off + tid]);
        m_val = m_new;
    }

    O[q_off + tid] = __float2bfloat16(o_acc * __fdividef(1.0f, l_val));
}

// C-linkage launcher so the C++ wrapper can call it without nvcc
extern "C" void launch_windflash_short_fwd(
    const void* Q, const void* K, const void* V, void* O,
    int N_q, int N_k, int D, int H_q, int H_k,
    float sm_scale, int is_causal, int total_heads,
    cudaStream_t stream)
{
    int grid   = N_q * total_heads;
    int block_t = D;
    windflash_short_fwd_kernel<<<grid, block_t, 0, stream>>>(
        (const __nv_bfloat16*)Q, (const __nv_bfloat16*)K,
        (const __nv_bfloat16*)V, (__nv_bfloat16*)O,
        N_q, N_k, D, H_q, H_k, sm_scale, is_causal, total_heads
    );
}

// ====================================================================
// Kernel 2: Tiled Flash Attention for medium sequences (N = 64..1024)
// Grid:  (ceil(N_q / BM), B * H_q)
// Block: 128 threads
// Each block processes BM rows of Q and iterates over K/V in BN-row tiles.
// Online softmax across K-tiles.  GQA supported.
//
// Thread mapping: tid = d-column index (0..HD-1).
//   For HD=64, threads 64..127 only help with smem loads.
//   Each thread maintains BM independent per-row accumulators.
//   Dot products: warp shuffle + cross-warp smem reduce.
// ====================================================================

template <int BM, int BN, int HD>
__launch_bounds__(128)
__global__ void windflash_tiled_fwd_kernel(
    const __nv_bfloat16* __restrict__ Q,
    const __nv_bfloat16* __restrict__ K,
    const __nv_bfloat16* __restrict__ V,
    __nv_bfloat16*       __restrict__ O,
    int N_q, int N_k,
    int H_q, int H_k,
    float sm_scale,
    int is_causal,
    int stride_qh, int stride_kh)
{
    const int q_tile = blockIdx.x;
    const int bh_q   = blockIdx.y;
    const int tid    = threadIdx.x;

    const int gsize  = H_q / H_k;
    const int bh_kv  = (bh_q / H_q) * H_k + (bh_q % H_q) / gsize;

    const __nv_bfloat16* Qh = Q + (long long)bh_q  * stride_qh;
    const __nv_bfloat16* Kh = K + (long long)bh_kv * stride_kh;
    const __nv_bfloat16* Vh = V + (long long)bh_kv * stride_kh;
    __nv_bfloat16*       Oh = O + (long long)bh_q  * stride_qh;

    const int q_start = q_tile * BM;
    const int d_col   = tid % HD;
    const bool active = (tid < HD);

    extern __shared__ float smem[];
    float* sq = smem;
    float* sk = smem + BM * HD;

    // Load Q-tile into shared memory
    for (int i = tid; i < BM * HD; i += 128) {
        int row = i / HD, col = i % HD;
        int gq = q_start + row;
        sq[i] = (gq < N_q) ? __bfloat162float(Qh[gq * HD + col]) : 0.0f;
    }
    __syncthreads();

    float m_row[BM], l_row[BM], o_row[BM];
    #pragma unroll
    for (int r = 0; r < BM; r++) {
        m_row[r] = -1e38f;
        l_row[r] = 0.0f;
        o_row[r] = 0.0f;
    }

    const int n_warps_d = (HD + 31) / 32;
    const int warp_id = tid / 32;
    const int lane_id = tid % 32;

    __shared__ float s_reduce[BM * 4];  // max BM * n_warps_d

    const int k_tiles = (N_k + BN - 1) / BN;
    for (int kt = 0; kt < k_tiles; kt++) {
        const int k_start = kt * BN;
        if (is_causal && k_start >= q_start + BM) break;

        // Load K-tile
        for (int i = tid; i < BN * HD; i += 128) {
            int row = i / HD, col = i % HD;
            int gk = k_start + row;
            sk[i] = (gk < N_k) ? __bfloat162float(Kh[gk * HD + col]) : 0.0f;
        }
        __syncthreads();

        for (int ki_l = 0; ki_l < BN; ki_l++) {
            int ki_g = k_start + ki_l;
            if (ki_g >= N_k) break;

            float k_val = sk[ki_l * HD + d_col];

            #pragma unroll
            for (int qi_l = 0; qi_l < BM; qi_l++) {
                int qi_g = q_start + qi_l;
                if (qi_g >= N_q) continue;
                if (is_causal && ki_g > qi_g) continue;

                float prod = sq[qi_l * HD + d_col] * k_val;
                prod += __shfl_down_sync(0xFFFFFFFF, prod, 16);
                prod += __shfl_down_sync(0xFFFFFFFF, prod, 8);
                prod += __shfl_down_sync(0xFFFFFFFF, prod, 4);
                prod += __shfl_down_sync(0xFFFFFFFF, prod, 2);
                prod += __shfl_down_sync(0xFFFFFFFF, prod, 1);

                if (lane_id == 0 && warp_id < n_warps_d)
                    s_reduce[qi_l * n_warps_d + warp_id] = prod;
            }
            __syncthreads();

            float v_val = (ki_g < N_k) ? __bfloat162float(Vh[ki_g * HD + d_col]) : 0.0f;

            #pragma unroll
            for (int qi_l = 0; qi_l < BM; qi_l++) {
                int qi_g = q_start + qi_l;
                if (qi_g >= N_q) continue;
                if (is_causal && ki_g > qi_g) continue;

                float score = s_reduce[qi_l * n_warps_d];
                for (int w = 1; w < n_warps_d; w++)
                    score += s_reduce[qi_l * n_warps_d + w];
                score *= sm_scale;

                float m_new = fmaxf(m_row[qi_l], score);
                float eo = __expf(m_row[qi_l] - m_new);
                float en = __expf(score - m_new);
                l_row[qi_l] = l_row[qi_l] * eo + en;
                o_row[qi_l] = o_row[qi_l] * eo + en * v_val;
                m_row[qi_l] = m_new;
            }
            __syncthreads();
        }
        __syncthreads();
    }

    if (active) {
        #pragma unroll
        for (int qi_l = 0; qi_l < BM; qi_l++) {
            int qi_g = q_start + qi_l;
            if (qi_g < N_q) {
                float val = o_row[qi_l] * __fdividef(1.0f, l_row[qi_l]);
                Oh[qi_g * HD + d_col] = __float2bfloat16(val);
            }
        }
    }
}

// ====================================================================
// Tiled launcher (C-linkage)
// ====================================================================

template <int BM, int BN, int HD>
static void launch_tiled(
    const void* Q, const void* K, const void* V, void* O,
    int N_q, int N_k, int H_q, int H_k, int B,
    float sm_scale, int is_causal, cudaStream_t stream)
{
    int total_q_tiles = (N_q + BM - 1) / BM;
    dim3 grid(total_q_tiles, B * H_q);
    int smem = (BM + BN) * HD * (int)sizeof(float);
    windflash_tiled_fwd_kernel<BM, BN, HD><<<grid, 128, smem, stream>>>(
        (const __nv_bfloat16*)Q, (const __nv_bfloat16*)K,
        (const __nv_bfloat16*)V, (__nv_bfloat16*)O,
        N_q, N_k, H_q, H_k, sm_scale, is_causal,
        N_q * HD, N_k * HD
    );
}

extern "C" void launch_windflash_tiled_fwd(
    const void* Q, const void* K, const void* V, void* O,
    int N_q, int N_k, int D, int H_q, int H_k, int B,
    float sm_scale, int is_causal, cudaStream_t stream)
{
    if (D == 64) {
        launch_tiled<32, 32, 64>(Q, K, V, O, N_q, N_k, H_q, H_k, B,
                                  sm_scale, is_causal, stream);
    } else {
        launch_tiled<32, 32, 128>(Q, K, V, O, N_q, N_k, H_q, H_k, B,
                                   sm_scale, is_causal, stream);
    }
}
'''

_CPP_SRC = r'''
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>

// Defined in the CUDA source compiled by nvcc
extern "C" void launch_windflash_short_fwd(
    const void* Q, const void* K, const void* V, void* O,
    int N_q, int N_k, int D, int H_q, int H_k,
    float sm_scale, int is_causal, int total_heads,
    void* stream);

extern "C" void launch_windflash_tiled_fwd(
    const void* Q, const void* K, const void* V, void* O,
    int N_q, int N_k, int D, int H_q, int H_k, int B,
    float sm_scale, int is_causal, void* stream);

torch::Tensor short_attn_fwd(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    double sm_scale, bool is_causal)
{
    TORCH_CHECK(q.dtype() == torch::kBFloat16, "q must be bf16");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "q/k/v must be contiguous");
    TORCH_CHECK(q.is_cuda(), "tensors must be on CUDA");

    int B = q.size(0), H_q = q.size(1), N_q = q.size(2), D = q.size(3);
    int H_k = k.size(1), N_k = k.size(2);
    TORCH_CHECK(D == 64 || D == 128, "D must be 64 or 128, got ", D);

    auto out = torch::empty_like(q);

    int total_heads = B * H_q;
    float scale_f   = (float)sm_scale;
    int   causal_i  = is_causal ? 1 : 0;

    auto stream = at::cuda::getCurrentCUDAStream().stream();
    launch_windflash_short_fwd(
        q.data_ptr(), k.data_ptr(), v.data_ptr(), out.data_ptr(),
        N_q, N_k, D, H_q, H_k, scale_f, causal_i, total_heads,
        (void*)stream);
    return out;
}

torch::Tensor tiled_attn_fwd(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    double sm_scale, bool is_causal)
{
    TORCH_CHECK(q.dtype() == torch::kBFloat16, "q must be bf16");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "q/k/v must be contiguous");
    TORCH_CHECK(q.is_cuda(), "tensors must be on CUDA");

    int B = q.size(0), H_q = q.size(1), N_q = q.size(2), D = q.size(3);
    int H_k = k.size(1), N_k = k.size(2);
    TORCH_CHECK(D == 64 || D == 128, "D must be 64 or 128, got ", D);

    auto out = torch::empty_like(q);
    float scale_f  = (float)sm_scale;
    int   causal_i = is_causal ? 1 : 0;

    auto stream = at::cuda::getCurrentCUDAStream().stream();
    launch_windflash_tiled_fwd(
        q.data_ptr(), k.data_ptr(), v.data_ptr(), out.data_ptr(),
        N_q, N_k, D, H_q, H_k, B, scale_f, causal_i,
        (void*)stream);
    return out;
}
'''

# ---- NVRTC fallback kernel (for systems without nvcc 13.1+) ----------

_NVRTC_KERNEL = r"""
__device__ __forceinline__ float bf16_to_f32(unsigned short x) {
    return __uint_as_float(((unsigned int)x) << 16);
}
__device__ __forceinline__ unsigned short f32_to_bf16(float f) {
    unsigned int u = __float_as_uint(f);
    u += (((u >> 16) & 1) + 0x7FFF);
    return (unsigned short)(u >> 16);
}
extern "C" __launch_bounds__(128)
__global__ void windflash_short_fwd(
    const unsigned short* __restrict__ Q,
    const unsigned short* __restrict__ K,
    const unsigned short* __restrict__ V,
    unsigned short*       __restrict__ O,
    int N_q, int N_k, int D,
    int H_q, int H_k,
    float sm_scale,
    int is_causal,
    int total_heads)
{
    const int flat   = blockIdx.x;
    const int qi     = flat / total_heads;
    const int head_q = flat % total_heads;
    const int tid    = threadIdx.x;
    const int batch   = head_q / H_q;
    const int lhq     = head_q % H_q;
    const int gsize   = H_q / H_k;
    const int lhk     = lhq / gsize;
    const int head_kv = batch * H_k + lhk;
    const long long q_off   = (long long)head_q  * N_q * D + (long long)qi * D;
    const long long kv_base = (long long)head_kv * N_k * D;
    float q_val = bf16_to_f32(Q[q_off + tid]);
    float m_val = -1e38f, l_val = 0.0f, o_acc = 0.0f;
    const int num_warps = (D + 31) >> 5;
    const int warp_id   = tid >> 5;
    const int lane      = tid & 31;
    __shared__ float s_partial[4];
    const int kend = is_causal ? (qi + 1 < N_k ? qi + 1 : N_k) : N_k;
    for (int ki = 0; ki < kend; ki++) {
        const long long kv_off = kv_base + (long long)ki * D;
        float prod = q_val * bf16_to_f32(K[kv_off + tid]);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 16);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 8);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 4);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 2);
        prod += __shfl_down_sync(0xFFFFFFFF, prod, 1);
        if (lane == 0) s_partial[warp_id] = prod;
        __syncthreads();
        float score = s_partial[0];
        if (num_warps > 1) score += s_partial[1];
        if (num_warps > 2) score += s_partial[2];
        if (num_warps > 3) score += s_partial[3];
        score *= sm_scale;
        __syncthreads();
        float m_new = fmaxf(m_val, score);
        float eo = __expf(m_val - m_new);
        float en = __expf(score - m_new);
        l_val = l_val * eo + en;
        o_acc = o_acc * eo + en * bf16_to_f32(V[kv_off + tid]);
        m_val = m_new;
    }
    O[q_off + tid] = f32_to_bf16(o_acc * __fdividef(1.0f, l_val));
}
"""


def _make_nvrtc_cpp() -> str:
    """C++ wrapper for NVRTC fallback (no nvcc needed)."""
    return (
        r'''
#include <torch/extension.h>
#include <cuda.h>
#include <nvrtc.h>
#include <mutex>
#include <string>
#include <stdexcept>
#include <unordered_map>

static void nvrtc_chk(nvrtcResult r, const char* msg) {
    if (r != NVRTC_SUCCESS)
        throw std::runtime_error(std::string(msg) + ": " + nvrtcGetErrorString(r));
}
static void cu_chk(CUresult r, const char* msg) {
    if (r != CUDA_SUCCESS) {
        const char* e = nullptr; cuGetErrorString(r, &e);
        throw std::runtime_error(std::string(msg) + ": " + (e ? e : "?"));
    }
}

struct KInfo { CUmodule mod = nullptr; CUfunction fn = nullptr; };
static std::mutex g_mtx;
static std::unordered_map<int, KInfo> g_cache;

static const char* KERN_SRC = R"KERN(
''' + _NVRTC_KERNEL + r'''
)KERN";

static KInfo& ensure_kernel(int device) {
    std::lock_guard<std::mutex> lk(g_mtx);
    auto it = g_cache.find(device);
    if (it != g_cache.end()) return it->second;
    CUdevice dev;
    cu_chk(cuDeviceGet(&dev, device), "cuDeviceGet");
    int maj = 0, mn = 0;
    cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, dev);
    cuDeviceGetAttribute(&mn, CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, dev);
    std::string sm = "--gpu-architecture=sm_" + std::to_string(maj * 10 + mn);
    nvrtcProgram prog;
    nvrtc_chk(nvrtcCreateProgram(&prog, KERN_SRC, "wf.cu", 0, nullptr, nullptr), "nvrtcCreate");
    const char* opts[] = {sm.c_str(), "--use_fast_math"};
    nvrtcResult r = nvrtcCompileProgram(prog, 2, opts);
    if (r != NVRTC_SUCCESS) {
        size_t sz; nvrtcGetProgramLogSize(prog, &sz);
        std::string log(sz, '\0'); nvrtcGetProgramLog(prog, &log[0]);
        nvrtcDestroyProgram(&prog);
        throw std::runtime_error("NVRTC: " + log);
    }
    size_t ptxSz; nvrtcGetPTXSize(prog, &ptxSz);
    std::string ptx(ptxSz, '\0'); nvrtcGetPTX(prog, &ptx[0]);
    nvrtcDestroyProgram(&prog);
    KInfo info;
    cu_chk(cuModuleLoadDataEx(&info.mod, ptx.c_str(), 0, nullptr, nullptr), "cuModLoad");
    cu_chk(cuModuleGetFunction(&info.fn, info.mod, "windflash_short_fwd"), "cuModGetFn");
    g_cache[device] = info;
    return g_cache[device];
}

torch::Tensor short_attn_fwd(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    double sm_scale, bool is_causal)
{
    TORCH_CHECK(q.dtype() == torch::kBFloat16, "q must be bf16");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "q/k/v must be contiguous");
    TORCH_CHECK(q.is_cuda(), "tensors must be on CUDA");
    int B = q.size(0), H_q = q.size(1), N_q = q.size(2), D = q.size(3);
    int H_k = k.size(1), N_k = k.size(2);
    TORCH_CHECK(D == 64 || D == 128, "D must be 64 or 128, got ", D);
    int device = q.device().index();
    auto& info = ensure_kernel(device);
    auto out = torch::empty_like(q);
    int total_heads = B * H_q;
    int grid = N_q * total_heads;
    int block_t = D;
    float scale_f = (float)sm_scale;
    int causal_i = is_causal ? 1 : 0;
    auto qp = (const unsigned short*)q.data_ptr();
    auto kp = (const unsigned short*)k.data_ptr();
    auto vp = (const unsigned short*)v.data_ptr();
    auto op = (unsigned short*)out.data_ptr();
    void* args[] = {
        (void*)&qp, (void*)&kp, (void*)&vp, (void*)&op,
        (void*)&N_q, (void*)&N_k, (void*)&D,
        (void*)&H_q, (void*)&H_k,
        (void*)&scale_f, (void*)&causal_i, (void*)&total_heads
    };
    CUstream stream = nullptr;
    cu_chk(cuLaunchKernel(info.fn, grid,1,1, block_t,1,1, 0, stream, args, nullptr),
           "cuLaunchKernel");
    return out;
}
''')


# ---- build helpers ---------------------------------------------------

def _find_msvc_linker() -> str | None:
    if platform.system() != "Windows":
        return None
    for root in (
        Path(r"C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC"),
        Path(r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC"),
        Path(r"C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Tools\MSVC"),
    ):
        if not root.exists():
            continue
        for ver in sorted(root.iterdir(), reverse=True):
            ld = ver / "bin" / "Hostx64" / "x64"
            if (ld / "link.exe").exists():
                return str(ld)
    return None


def _find_cuda_toolkit() -> Path | None:
    """Find a CUDA toolkit root with nvcc (prefer newest)."""
    # Explicit env vars first
    for var in ("CUDA_HOME", "CUDA_PATH"):
        p = Path(os.environ.get(var, ""))
        if (p / "bin" / "nvcc.exe").exists() or (p / "bin" / "nvcc").exists():
            return p
    # Standard install locations (Windows)
    base = Path(r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA")
    if base.exists():
        for ver in sorted(base.iterdir(), reverse=True):
            if (ver / "bin" / "nvcc.exe").exists():
                return ver
    # Linux
    p = Path("/usr/local/cuda")
    if (p / "bin" / "nvcc").exists():
        return p
    return None


def _find_cuda_libs() -> tuple[str | None, str | None]:
    """Return (include_dir, lib_dir) for CUDA headers (for NVRTC fallback)."""
    for base in (
        Path(os.environ.get("CUDA_HOME", "")),
        Path(os.environ.get("CUDA_PATH", "")),
        Path(r"C:\ProgramData\miniconda3\Library"),
        Path("/usr/local/cuda"),
    ):
        inc = base / "include"
        # CUDA 13+ on Windows puts libs under lib/x64
        lib = base / "lib" / "x64" if platform.system() == "Windows" else base / "lib"
        if not lib.exists():
            lib = base / "lib"  # fallback for older layouts
        if base.exists() and (inc / "cuda.h").exists() and lib.exists():
            return str(inc), str(lib)
    return None, None


def _try_nvcc_build() -> bool:
    """Attempt native nvcc build. Returns True on success."""
    global _ext
    toolkit = _find_cuda_toolkit()
    if toolkit is None:
        return False

    try:
        from torch.utils.cpp_extension import load_inline
    except ImportError:
        return False

    # Set CUDA_HOME so PyTorch finds the right nvcc
    os.environ["CUDA_HOME"] = str(toolkit)
    os.environ["CUDA_PATH"] = str(toolkit)

    # Ensure modern MSVC linker is on PATH
    ld = _find_msvc_linker()
    if ld:
        nvcc_bin = str(toolkit / "bin")
        os.environ["PATH"] = ld + ";" + nvcc_bin + ";" + os.environ.get("PATH", "")

    try:
        _ext = load_inline(
            name="windflash_cuda_nvcc",
            cpp_sources=[_CPP_SRC],
            cuda_sources=[_CUDA_SRC],
            functions=["short_attn_fwd", "tiled_attn_fwd"],
            extra_cuda_cflags=["--use_fast_math", "-O3"],
            verbose=False,
        )
        _log.info("windflash_cuda: nvcc build OK (toolkit: %s)", toolkit)
        return True
    except Exception as exc:
        _log.debug("windflash_cuda: nvcc build failed: %s", exc)
        return False


def _try_nvrtc_build() -> bool:
    """Fallback: NVRTC build (cl.exe only, no nvcc needed)."""
    global _ext
    try:
        from torch.utils.cpp_extension import load_inline
    except ImportError:
        return False

    cuda_inc, cuda_lib = _find_cuda_libs()
    if cuda_inc is None:
        return False

    # Ensure CUDA runtime DLLs (nvrtc64_*.dll etc.) are findable
    cuda_bin = str(Path(cuda_inc).parent / "bin")
    if os.path.isdir(cuda_bin):
        os.environ["PATH"] = cuda_bin + ";" + os.environ.get("PATH", "")
        try:
            os.add_dll_directory(cuda_bin)
        except (OSError, AttributeError):
            pass

    ld = _find_msvc_linker()
    if ld:
        os.environ["PATH"] = ld + ";" + os.environ.get("PATH", "")

    if platform.system() == "Windows":
        ldflags = [os.path.join(cuda_lib, "cuda.lib"),
                    os.path.join(cuda_lib, "nvrtc.lib")]
    else:
        ldflags = ["-lcuda", "-lnvrtc"]

    try:
        _ext = load_inline(
            name="windflash_cuda_nvrtc",
            cpp_sources=[_make_nvrtc_cpp()],
            extra_include_paths=[cuda_inc],
            extra_ldflags=ldflags,
            functions=["short_attn_fwd"],
            verbose=False,
        )
        _log.info("windflash_cuda: NVRTC fallback build OK")
        return True
    except Exception as exc:
        _log.debug("windflash_cuda: NVRTC build failed: %s", exc)
        return False


def _build() -> None:
    """Build the extension: try nvcc first, fall back to NVRTC."""
    global _ext
    if _ext is not None:
        return

    if _try_nvcc_build():
        return
    if _try_nvrtc_build():
        return

    _log.warning("windflash_cuda: all build paths failed")
    _ext = False


# ---- public API ------------------------------------------------------

def available() -> bool:
    """Return True if the CUDA C++ extension is usable."""
    _build()
    return _ext is not None and _ext is not False


def short_attn_fwd(
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
    sm_scale: float, causal: bool,
) -> torch.Tensor | None:
    """Fused short-seq attention (bf16, D in {64, 128}).

    Returns the output tensor, or None if unavailable / unsupported shape.
    """
    _build()
    if not _ext:
        return None
    if q.shape[-1] not in (64, 128) or q.dtype != torch.bfloat16:
        return None
    try:
        return _ext.short_attn_fwd(q, k, v, float(sm_scale), bool(causal))
    except Exception:
        return None


def tiled_attn_fwd(
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
    sm_scale: float, causal: bool,
) -> torch.Tensor | None:
    """Tiled flash attention for medium sequences (bf16, D in {64, 128}).

    Uses shared-memory tiling to avoid the serial K-loop bottleneck.
    Only available when built with nvcc (not NVRTC fallback).

    Returns the output tensor, or None if unavailable / unsupported.
    """
    _build()
    if not _ext:
        return None
    if q.shape[-1] not in (64, 128) or q.dtype != torch.bfloat16:
        return None
    if not hasattr(_ext, "tiled_attn_fwd"):
        return None  # only available in nvcc build
    try:
        return _ext.tiled_attn_fwd(q, k, v, float(sm_scale), bool(causal))
    except Exception:
        return None
