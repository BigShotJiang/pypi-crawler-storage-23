"""WindFlash — Triton-based Flash Attention v2.

Pure-Triton implementation of Flash Attention with autotuning, GQA/MQA
support, and a backward pass for training.  No C++ compilation needed.

Usage::

    from windflash import flash_attention, enable_windflash

    # Direct call  (supports GQA: K/V can have fewer heads than Q)
    out = flash_attention(q, k, v)             # (B, H_q, N, D)

    # Or monkey-patch torch SDPA globally
    enable_windflash()

Features:
    - Autotuned tile sizes per (head_dim, seq_len, GPU)
    - bf16 / fp16 inputs
    - Causal masking
    - Grouped-Query / Multi-Query Attention (GQA/MQA)
    - Backward pass (dQ, dK, dV) for training
    - RTX 30xx / 40xx GPUs (SM >= 8.0)

Reference:
    Dao et al., "FlashAttention-2: Faster Attention with Better Parallelism
    and Work Partitioning", 2023.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import torch
import triton
import triton.language as tl

# Optional CUDA C++ extension for sub-15us short-seq dispatch
try:
    from . import windflash_cuda as _wf_cuda
except Exception:
    try:
        import windflash_cuda as _wf_cuda          # standalone import
    except Exception:
        _wf_cuda = None                             # unavailable

# Threshold: use C++ kernel only when N is small enough that the serial
# K-loop completes faster than Triton's tiled approach.
_CUDA_SHORT_THRESH = 128

# ═══════════════════════════════════════════════════════════════════════
# Config cache — persist autotuner winners across runs
# ═══════════════════════════════════════════════════════════════════════

_SEQ_BUCKETS = [32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]


def _bucket_seq(n: int) -> int:
    """Round *n* up to the nearest standard bucket."""
    for b in _SEQ_BUCKETS:
        if n <= b:
            return b
    return n  # beyond largest bucket — use exact


def _gpu_fingerprint(device: torch.device | int = 0) -> str:
    """Deterministic short hash identifying GPU + software versions."""
    props = torch.cuda.get_device_properties(device)
    key = f"{props.name}|sm{props.major}.{props.minor}|triton{triton.__version__}"
    return hashlib.sha1(key.encode()).hexdigest()[:12]


class _ConfigCache:
    """Load/save the best (BLOCK_M, BLOCK_N, num_warps, num_stages) per shape."""

    def __init__(self):
        self._cache: dict[str, dict] = {}  # key → config dict
        self._dir = Path.home() / ".windflash"
        self._file: Path | None = None

    # ── key helpers ──

    @staticmethod
    def _make_key(
        seqlen_q: int, seqlen_k: int, d: int,
        h_q: int, h_k: int, dtype: str, causal: bool,
    ) -> str:
        sq = _bucket_seq(seqlen_q)
        sk = _bucket_seq(seqlen_k)
        return f"{sq}x{sk}x{d}x{h_q}:{h_k}x{dtype}x{'c' if causal else 'n'}"

    # ── lookup / store ──

    def get(
        self, seqlen_q: int, seqlen_k: int, d: int,
        h_q: int, h_k: int, dtype: str, causal: bool,
    ) -> dict | None:
        key = self._make_key(seqlen_q, seqlen_k, d, h_q, h_k, dtype, causal)
        return self._cache.get(key)

    def put(
        self, seqlen_q: int, seqlen_k: int, d: int,
        h_q: int, h_k: int, dtype: str, causal: bool,
        config: dict,
    ) -> None:
        key = self._make_key(seqlen_q, seqlen_k, d, h_q, h_k, dtype, causal)
        self._cache[key] = config

    # ── persistence ──

    def load(self, device: torch.device | int = 0) -> bool:
        """Load cached configs from disk.  Returns True if cache file existed."""
        fp = _gpu_fingerprint(device)
        self._file = self._dir / f"{fp}.json"
        if self._file.exists():
            try:
                self._cache = json.loads(self._file.read_text())
                return True
            except (json.JSONDecodeError, OSError):
                pass
        return False

    def save(self) -> None:
        """Write current cache to disk."""
        if self._file is None:
            return
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file.write_text(json.dumps(self._cache, indent=2))

    def __len__(self) -> int:
        return len(self._cache)

    def __bool__(self) -> bool:
        return bool(self._cache)


# Global cache instance
_config_cache = _ConfigCache()

# ═══════════════════════════════════════════════════════════════════════
# Mode selection
# ═══════════════════════════════════════════════════════════════════════

_VALID_MODES = {"inference", "training", "tts"}
_mode: str = "inference"


def set_mode(mode: str) -> None:
    """Set the operational mode: ``"inference"``, ``"training"``, or ``"tts"``.

    * **inference** — skips LSE storage when gradients aren't needed,
      uses cached / short-seq fast path.
    * **training** — always stores LSE for backward pass.
    * **tts** — like inference, plus more aggressive short-seq threshold (512).
    """
    global _mode
    if mode not in _VALID_MODES:
        raise ValueError(f"Unknown mode {mode!r}; choose from {_VALID_MODES}")
    _mode = mode


def get_mode() -> str:
    """Return the current operational mode."""
    return _mode


# Triton autotuner cache-key dtype suffixes  (Q, K, V, Out, Lse)
_DTYPES_BF16 = ('torch.bfloat16',) * 4 + ('torch.float32',)
_DTYPES_FP16 = ('torch.float16',) * 4 + ('torch.float32',)


def _triton_cache_key(seqlen_q, seqlen_k, block_d, causal, dtype_str):
    """Build the exact tuple key Triton's Autotuner uses internally."""
    dtypes = _DTYPES_BF16 if dtype_str == 'bf16' else _DTYPES_FP16
    return (seqlen_q, seqlen_k, block_d, causal) + dtypes


# Default shapes calibrated for TTS and standard transformer inference
_DEFAULT_OPT_SHAPES: list[tuple[int, int, int, int, int]] = [
    # (B, H_q, H_k, N, D)
    (1, 14, 14,   64, 64), (1, 14, 14,  128, 64), (1, 14, 14,  256, 64),
    (1, 14, 14,  512, 64), (1, 14, 14, 1024, 64), (1, 14, 14, 2048, 64),
    (1, 32, 32,  128, 128), (1, 32, 32,  512, 128), (1, 32, 32, 1024, 128),
    (1, 32, 32, 2048, 128), (1, 32, 32, 4096, 128),
]

# Short-sequence fast path: bypass autotuner when N_q * N_k is small
_SHORT_SEQ_THRESHOLD = 256  # max(N_q, N_k) to use fast path
_SHORT_TILE = {"BLOCK_M": 32, "BLOCK_N": 64, "num_warps": 4, "num_stages": 3}


# ═══════════════════════════════════════════════════════════════════════
# Forward-pass autotuning configs
# ═══════════════════════════════════════════════════════════════════════

_FWD_CONFIGS = [
    # ── D=64 sweet-spot configs ──
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 64},  num_warps=4, num_stages=3),
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 32},  num_warps=4, num_stages=3),
    triton.Config({"BLOCK_M": 64,  "BLOCK_N": 64},  num_warps=4, num_stages=3),
    triton.Config({"BLOCK_M": 64,  "BLOCK_N": 32},  num_warps=4, num_stages=3),
    # ── Short-seq / TTS (small M, big N to consume KV in one shot) ──
    triton.Config({"BLOCK_M": 32,  "BLOCK_N": 64},  num_warps=4, num_stages=3),
    triton.Config({"BLOCK_M": 16,  "BLOCK_N": 64},  num_warps=4, num_stages=3),
    # ── D=128 configs (need smaller tiles for register pressure) ──
    triton.Config({"BLOCK_M": 64,  "BLOCK_N": 32},  num_warps=8, num_stages=3),
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 32},  num_warps=8, num_stages=3),
    triton.Config({"BLOCK_M": 32,  "BLOCK_N": 32},  num_warps=4, num_stages=3),
    # ── High-warp configs for long sequences ──
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 64},  num_warps=8, num_stages=2),
    triton.Config({"BLOCK_M": 64,  "BLOCK_N": 64},  num_warps=8, num_stages=2),
    # ── Large-tile configs for N≥2048 (fewer blocks, better occupancy) ──
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 128}, num_warps=8, num_stages=3),
    triton.Config({"BLOCK_M": 128, "BLOCK_N": 128}, num_warps=8, num_stages=2),
]


# ═══════════════════════════════════════════════════════════════════════
# Forward kernel (autotuned)
# ═══════════════════════════════════════════════════════════════════════

@triton.autotune(configs=_FWD_CONFIGS, key=["seqlen_q", "seqlen_k", "BLOCK_D", "IS_CAUSAL"])
@triton.jit
def _fwd_kernel(
    Q, K, V, Out,
    Lse,                      # logsumexp for backward [B, H_q, N_q]
    sm_scale,
    stride_qb, stride_qh, stride_qm, stride_qk,
    stride_kb, stride_kh, stride_kn, stride_kk,
    stride_vb, stride_vh, stride_vn, stride_vk,
    stride_ob, stride_oh, stride_om, stride_ok,
    stride_lse_b, stride_lse_h, stride_lse_m,
    num_heads_q, num_heads_k,
    seqlen_q, seqlen_k,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
    HAS_LSE: tl.constexpr,
):
    start_m = tl.program_id(0)
    off_bh = tl.program_id(1)

    off_b = off_bh // num_heads_q
    off_h_q = off_bh % num_heads_q
    # GQA head mapping
    off_h_k = off_h_q // (num_heads_q // num_heads_k)

    q_off = off_b.to(tl.int64) * stride_qb + off_h_q.to(tl.int64) * stride_qh
    k_off = off_b.to(tl.int64) * stride_kb + off_h_k.to(tl.int64) * stride_kh
    v_off = off_b.to(tl.int64) * stride_vb + off_h_k.to(tl.int64) * stride_vh
    o_off = off_b.to(tl.int64) * stride_ob + off_h_q.to(tl.int64) * stride_oh

    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, BLOCK_D)
    offs_n = tl.arange(0, BLOCK_N)

    # Load Q [BLOCK_M, BLOCK_D] and pre-scale (saves one mul per score per K-block)
    q_ptrs = Q + q_off + offs_m[:, None] * stride_qm + offs_d[None, :] * stride_qk
    q = tl.load(q_ptrs, mask=offs_m[:, None] < seqlen_q, other=0.0)
    q = (q * sm_scale).to(q.dtype)

    m_i = tl.full([BLOCK_M], float("-inf"), dtype=tl.float32)
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32)
    acc = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)

    if IS_CAUSAL:
        hi = tl.minimum(seqlen_k, (start_m + 1) * BLOCK_M)
    else:
        hi = seqlen_k

    for start_n in range(0, hi, BLOCK_N):
        cur_n = start_n + offs_n
        mask_n = cur_n < seqlen_k

        k_ptrs = K + k_off + cur_n[:, None] * stride_kn + offs_d[None, :] * stride_kk
        k = tl.load(k_ptrs, mask=mask_n[:, None], other=0.0)

        s = tl.dot(q, tl.trans(k))  # Q already pre-scaled

        if IS_CAUSAL:
            s += tl.where(offs_m[:, None] >= cur_n[None, :], 0.0, float("-inf"))
        s += tl.where(mask_n[None, :], 0.0, float("-inf"))

        m_ij = tl.max(s, axis=1)
        m_new = tl.maximum(m_i, m_ij)
        alpha = tl.exp(m_i - m_new)
        alpha = tl.where(m_i > float("-inf"), alpha, 0.0)
        p = tl.exp(s - m_new[:, None])

        l_i = l_i * alpha + tl.sum(p, axis=1)
        acc = acc * alpha[:, None]

        v_ptrs = V + v_off + cur_n[:, None] * stride_vn + offs_d[None, :] * stride_vk
        v = tl.load(v_ptrs, mask=mask_n[:, None], other=0.0)
        acc += tl.dot(p.to(v.dtype), v)
        m_i = m_new

    l_safe = tl.where(l_i > 0.0, l_i, 1.0)
    acc = acc / l_safe[:, None]

    o_ptrs = Out + o_off + offs_m[:, None] * stride_om + offs_d[None, :] * stride_ok
    tl.store(o_ptrs, acc.to(q.dtype), mask=offs_m[:, None] < seqlen_q)

    if HAS_LSE:
        lse = m_i + tl.log(l_safe)
        lse_ptrs = (Lse
                    + off_b.to(tl.int64) * stride_lse_b
                    + off_h_q.to(tl.int64) * stride_lse_h
                    + offs_m * stride_lse_m)
        tl.store(lse_ptrs, lse, mask=offs_m < seqlen_q)


# ═══════════════════════════════════════════════════════════════════════
# Backward kernels  (split dKV / dQ — no atomics, FlashAttention-2 style)
# ═══════════════════════════════════════════════════════════════════════

def _bwd_blocks(D: int):
    """Choose backward block sizes that fit in shared memory."""
    if D <= 64:
        return 64, 64, 1     # (BM, BN, num_stages)
    else:
        return 64, 32, 1     # D=128: halve BN to stay under 99KB shmem


@triton.jit
def _bwd_preprocess(
    Out, dOut, Delta,
    stride_ob, stride_oh, stride_om, stride_ok,
    stride_db, stride_dh, stride_dm,
    num_heads_q, seqlen_q,
    BLOCK_M: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """Fused delta = rowsum(Out * dOut) — avoids materialising full fp32 temp."""
    start_m = tl.program_id(0)
    off_bh = tl.program_id(1)
    off_b = off_bh // num_heads_q
    off_h = off_bh % num_heads_q

    o_base = off_b.to(tl.int64) * stride_ob + off_h.to(tl.int64) * stride_oh
    d_base = off_b.to(tl.int64) * stride_db + off_h.to(tl.int64) * stride_dh

    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, BLOCK_D)
    mask_m = offs_m < seqlen_q

    o = tl.load(Out + o_base + offs_m[:, None] * stride_om + offs_d[None, :] * stride_ok,
                mask=mask_m[:, None], other=0.0).to(tl.float32)
    do = tl.load(dOut + o_base + offs_m[:, None] * stride_om + offs_d[None, :] * stride_ok,
                 mask=mask_m[:, None], other=0.0).to(tl.float32)

    delta = tl.sum(o * do, axis=1)
    tl.store(Delta + d_base + offs_m * stride_dm, delta, mask=mask_m)


@triton.jit
def _bwd_dkv_kernel(
    Q, K, V, dOut, dK, dV,
    Lse, Delta,
    sm_scale,
    stride_qb, stride_qh, stride_qm, stride_qk,
    stride_kb, stride_kh, stride_kn, stride_kk,
    stride_vb, stride_vh, stride_vn, stride_vk,
    stride_ob, stride_oh, stride_om, stride_ok,
    stride_dkb, stride_dkh, stride_dkn, stride_dkk,
    stride_dvb, stride_dvh, stride_dvn, stride_dvk,
    stride_lse_b, stride_lse_h, stride_lse_m,
    stride_delta_b, stride_delta_h, stride_delta_m,
    num_heads_q, num_heads_k,
    seqlen_q, seqlen_k,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
):
    """One program per K-block × (batch, head).
    Iterate over Q-blocks → accumulate dK, dV.  No atomics."""
    start_n = tl.program_id(0)
    off_bh = tl.program_id(1)

    off_b = off_bh // num_heads_q
    off_h_q = off_bh % num_heads_q
    off_h_k = off_h_q // (num_heads_q // num_heads_k)

    q_off  = off_b.to(tl.int64) * stride_qb  + off_h_q.to(tl.int64) * stride_qh
    k_off  = off_b.to(tl.int64) * stride_kb  + off_h_k.to(tl.int64) * stride_kh
    v_off  = off_b.to(tl.int64) * stride_vb  + off_h_k.to(tl.int64) * stride_vh
    o_off  = off_b.to(tl.int64) * stride_ob  + off_h_q.to(tl.int64) * stride_oh
    dk_off = off_b.to(tl.int64) * stride_dkb + off_h_q.to(tl.int64) * stride_dkh
    dv_off = off_b.to(tl.int64) * stride_dvb + off_h_q.to(tl.int64) * stride_dvh

    offs_n = start_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_D)
    mask_n = offs_n < seqlen_k

    k = tl.load(K + k_off + offs_n[:, None] * stride_kn + offs_d[None, :] * stride_kk,
                mask=mask_n[:, None], other=0.0)
    v = tl.load(V + v_off + offs_n[:, None] * stride_vn + offs_d[None, :] * stride_vk,
                mask=mask_n[:, None], other=0.0)

    dk_acc = tl.zeros([BLOCK_N, BLOCK_D], dtype=tl.float32)
    dv_acc = tl.zeros([BLOCK_N, BLOCK_D], dtype=tl.float32)

    lo = start_n * BLOCK_N if IS_CAUSAL else 0

    for start_m in range(lo, seqlen_q, BLOCK_M):
        offs_m = start_m + tl.arange(0, BLOCK_M)
        mask_m = offs_m < seqlen_q

        q = tl.load(Q + q_off + offs_m[:, None] * stride_qm + offs_d[None, :] * stride_qk,
                     mask=mask_m[:, None], other=0.0)

        s = tl.dot(q, tl.trans(k)) * sm_scale
        if IS_CAUSAL:
            s += tl.where(offs_m[:, None] >= offs_n[None, :], 0.0, float("-inf"))
        s += tl.where(mask_n[None, :], 0.0, float("-inf"))

        lse = tl.load(Lse + off_b.to(tl.int64) * stride_lse_b
                       + off_h_q.to(tl.int64) * stride_lse_h
                       + offs_m * stride_lse_m,
                       mask=mask_m, other=0.0)
        p = tl.exp(s - lse[:, None])

        do = tl.load(dOut + o_off + offs_m[:, None] * stride_om + offs_d[None, :] * stride_ok,
                      mask=mask_m[:, None], other=0.0)

        dv_acc += tl.dot(tl.trans(p.to(do.dtype)), do)

        dp = tl.dot(do, tl.trans(v))
        delta = tl.load(Delta + off_b.to(tl.int64) * stride_delta_b
                         + off_h_q.to(tl.int64) * stride_delta_h
                         + offs_m * stride_delta_m,
                         mask=mask_m, other=0.0)
        ds = p * (dp - delta[:, None]) * sm_scale

        dk_acc += tl.dot(tl.trans(ds.to(q.dtype)), q)

    tl.store(dK + dk_off + offs_n[:, None] * stride_dkn + offs_d[None, :] * stride_dkk,
             dk_acc.to(k.dtype), mask=mask_n[:, None])
    tl.store(dV + dv_off + offs_n[:, None] * stride_dvn + offs_d[None, :] * stride_dvk,
             dv_acc.to(v.dtype), mask=mask_n[:, None])


@triton.jit
def _bwd_dq_kernel(
    Q, K, V, dOut, dQ,
    Lse, Delta,
    sm_scale,
    stride_qb, stride_qh, stride_qm, stride_qk,
    stride_kb, stride_kh, stride_kn, stride_kk,
    stride_vb, stride_vh, stride_vn, stride_vk,
    stride_ob, stride_oh, stride_om, stride_ok,
    stride_dqb, stride_dqh, stride_dqm, stride_dqk,
    stride_lse_b, stride_lse_h, stride_lse_m,
    stride_delta_b, stride_delta_h, stride_delta_m,
    num_heads_q, num_heads_k,
    seqlen_q, seqlen_k,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
):
    """One program per Q-block × (batch, head).
    Iterate over K-blocks → accumulate dQ.  No atomics."""
    start_m = tl.program_id(0)
    off_bh = tl.program_id(1)

    off_b = off_bh // num_heads_q
    off_h_q = off_bh % num_heads_q
    off_h_k = off_h_q // (num_heads_q // num_heads_k)

    q_off  = off_b.to(tl.int64) * stride_qb  + off_h_q.to(tl.int64) * stride_qh
    k_off  = off_b.to(tl.int64) * stride_kb  + off_h_k.to(tl.int64) * stride_kh
    v_off  = off_b.to(tl.int64) * stride_vb  + off_h_k.to(tl.int64) * stride_vh
    o_off  = off_b.to(tl.int64) * stride_ob  + off_h_q.to(tl.int64) * stride_oh
    dq_off = off_b.to(tl.int64) * stride_dqb + off_h_q.to(tl.int64) * stride_dqh

    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, BLOCK_D)
    mask_m = offs_m < seqlen_q

    # Load Q, dOut, LSE, Delta for this Q-block (reused across all K-blocks)
    q = tl.load(Q + q_off + offs_m[:, None] * stride_qm + offs_d[None, :] * stride_qk,
                mask=mask_m[:, None], other=0.0)
    do = tl.load(dOut + o_off + offs_m[:, None] * stride_om + offs_d[None, :] * stride_ok,
                 mask=mask_m[:, None], other=0.0)
    lse = tl.load(Lse + off_b.to(tl.int64) * stride_lse_b
                   + off_h_q.to(tl.int64) * stride_lse_h
                   + offs_m * stride_lse_m,
                   mask=mask_m, other=0.0)
    delta = tl.load(Delta + off_b.to(tl.int64) * stride_delta_b
                     + off_h_q.to(tl.int64) * stride_delta_h
                     + offs_m * stride_delta_m,
                     mask=mask_m, other=0.0)

    dq_acc = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)

    if IS_CAUSAL:
        hi = tl.minimum(seqlen_k, (start_m + 1) * BLOCK_M)
    else:
        hi = seqlen_k

    for start_n in range(0, hi, BLOCK_N):
        offs_n = start_n + tl.arange(0, BLOCK_N)
        mask_n = offs_n < seqlen_k

        k = tl.load(K + k_off + offs_n[:, None] * stride_kn + offs_d[None, :] * stride_kk,
                     mask=mask_n[:, None], other=0.0)
        v = tl.load(V + v_off + offs_n[:, None] * stride_vn + offs_d[None, :] * stride_vk,
                     mask=mask_n[:, None], other=0.0)

        s = tl.dot(q, tl.trans(k)) * sm_scale
        if IS_CAUSAL:
            s += tl.where(offs_m[:, None] >= offs_n[None, :], 0.0, float("-inf"))
        s += tl.where(mask_n[None, :], 0.0, float("-inf"))

        p = tl.exp(s - lse[:, None])

        dp = tl.dot(do, tl.trans(v))
        ds = p * (dp - delta[:, None]) * sm_scale

        dq_acc += tl.dot(ds.to(k.dtype), k)

    # Store dQ (no atomics!)
    dq_ptrs = dQ + dq_off + offs_m[:, None] * stride_dqm + offs_d[None, :] * stride_dqk
    tl.store(dq_ptrs, dq_acc.to(q.dtype), mask=mask_m[:, None])


# ═══════════════════════════════════════════════════════════════════════
# Autograd Function
# ═══════════════════════════════════════════════════════════════════════

class _FlashAttentionFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, q, k, v, causal, sm_scale):
        B, H_q, N_q, D = q.shape
        _, H_k, N_k, _ = k.shape
        assert H_q % H_k == 0, f"Q heads ({H_q}) must be divisible by KV heads ({H_k})"

        BLOCK_D = triton.next_power_of_2(D)
        q, k, v = q.contiguous(), k.contiguous(), v.contiguous()
        out = torch.empty_like(q)

        needs_grad = q.requires_grad or k.requires_grad or v.requires_grad
        if needs_grad:
            lse = torch.empty(B, H_q, N_q, device=q.device, dtype=torch.float32)
        else:
            lse = torch.empty(0, device=q.device, dtype=torch.float32)

        # ── Dispatch: cache hit → short-seq fast path → autotuner ──
        short_thresh = 512 if _mode == "tts" else _SHORT_SEQ_THRESHOLD
        use_short = max(N_q, N_k) <= short_thresh

        # Check persistent config cache (preseeded into Triton autotuner)
        dtype_str = "bf16" if q.dtype == torch.bfloat16 else "fp16"
        cached = _config_cache.get(N_q, N_k, D, H_q, H_k, dtype_str, causal)

        if cached or use_short:
            # Direct JIT call — zero autotuner overhead
            tile = cached if cached else _SHORT_TILE
            bm = tile["BLOCK_M"]
            grid = (triton.cdiv(N_q, bm), B * H_q)
            _fwd_kernel.fn[grid](
                q, k, v, out, lse, sm_scale,
                q.stride(0), q.stride(1), q.stride(2), q.stride(3),
                k.stride(0), k.stride(1), k.stride(2), k.stride(3),
                v.stride(0), v.stride(1), v.stride(2), v.stride(3),
                out.stride(0), out.stride(1), out.stride(2), out.stride(3),
                lse.stride(0) if needs_grad else 0,
                lse.stride(1) if needs_grad else 0,
                lse.stride(2) if needs_grad else 0,
                H_q, H_k, N_q, N_k,
                BLOCK_M=bm,
                BLOCK_N=tile["BLOCK_N"],
                BLOCK_D=BLOCK_D,
                IS_CAUSAL=causal,
                HAS_LSE=needs_grad,
                num_warps=tile.get("num_warps", 4),
                num_stages=tile.get("num_stages", 3),
            )
        else:
            # Full autotuned path for uncached shapes
            grid = lambda META: (triton.cdiv(N_q, META["BLOCK_M"]), B * H_q)
            _fwd_kernel[grid](
                q, k, v, out, lse, sm_scale,
                q.stride(0), q.stride(1), q.stride(2), q.stride(3),
                k.stride(0), k.stride(1), k.stride(2), k.stride(3),
                v.stride(0), v.stride(1), v.stride(2), v.stride(3),
                out.stride(0), out.stride(1), out.stride(2), out.stride(3),
                lse.stride(0) if needs_grad else 0,
                lse.stride(1) if needs_grad else 0,
                lse.stride(2) if needs_grad else 0,
                H_q, H_k, N_q, N_k,
                BLOCK_D=BLOCK_D,
                IS_CAUSAL=causal,
                HAS_LSE=needs_grad,
            )

        ctx.save_for_backward(q, k, v, out, lse)
        ctx.sm_scale = sm_scale
        ctx.causal = causal
        ctx.BLOCK_D = BLOCK_D
        return out

    @staticmethod
    def backward(ctx, dout):
        q, k, v, out, lse = ctx.saved_tensors
        B, H_q, N_q, D = q.shape
        _, H_k, N_k, _ = k.shape
        BLOCK_D = ctx.BLOCK_D
        sm_scale = ctx.sm_scale
        causal = ctx.causal

        dout = dout.contiguous()

        # ── Step 1: fused delta = rowsum(Out ⊙ dOut) ──
        delta = torch.empty(B, H_q, N_q, device=q.device, dtype=torch.float32)
        BLOCK_M_PRE = 128
        grid_pre = (triton.cdiv(N_q, BLOCK_M_PRE), B * H_q)
        _bwd_preprocess[grid_pre](
            out, dout, delta,
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            delta.stride(0), delta.stride(1), delta.stride(2),
            H_q, N_q,
            BLOCK_M=BLOCK_M_PRE, BLOCK_D=BLOCK_D,
        )

        # ── Step 2: dK, dV  (one program per K-block, no atomics) ──
        # When GQA, we need dk/dv per Q-head then reduce
        if H_q > H_k:
            dk_full = torch.empty(B, H_q, N_k, D, device=k.device, dtype=k.dtype)
            dv_full = torch.empty(B, H_q, N_k, D, device=v.device, dtype=v.dtype)
        else:
            dk_full = torch.empty_like(k)
            dv_full = torch.empty_like(v)

        bwd_bm, bwd_bn, bwd_ns = _bwd_blocks(D)

        grid_dkv = (triton.cdiv(N_k, bwd_bn), B * H_q)
        _bwd_dkv_kernel[grid_dkv](
            q, k, v, dout, dk_full, dv_full,
            lse, delta, sm_scale,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            dk_full.stride(0), dk_full.stride(1), dk_full.stride(2), dk_full.stride(3),
            dv_full.stride(0), dv_full.stride(1), dv_full.stride(2), dv_full.stride(3),
            lse.stride(0), lse.stride(1), lse.stride(2),
            delta.stride(0), delta.stride(1), delta.stride(2),
            H_q, H_k, N_q, N_k,
            BLOCK_M=bwd_bm, BLOCK_N=bwd_bn,
            BLOCK_D=BLOCK_D, IS_CAUSAL=causal,
            num_stages=bwd_ns,
        )

        # ── Step 3: dQ  (one program per Q-block, no atomics) ──
        dq = torch.empty_like(q)
        grid_dq = (triton.cdiv(N_q, bwd_bm), B * H_q)
        _bwd_dq_kernel[grid_dq](
            q, k, v, dout, dq,
            lse, delta, sm_scale,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            dq.stride(0), dq.stride(1), dq.stride(2), dq.stride(3),
            lse.stride(0), lse.stride(1), lse.stride(2),
            delta.stride(0), delta.stride(1), delta.stride(2),
            H_q, H_k, N_q, N_k,
            BLOCK_M=bwd_bm, BLOCK_N=bwd_bn,
            BLOCK_D=BLOCK_D, IS_CAUSAL=causal,
            num_stages=bwd_ns,
        )

        if H_q > H_k:
            gsize = H_q // H_k
            dk = dk_full.view(B, H_k, gsize, N_k, D).sum(dim=2)
            dv = dv_full.view(B, H_k, gsize, N_k, D).sum(dim=2)
        else:
            dk = dk_full
            dv = dv_full

        return dq, dk, dv, None, None


# ═══════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════

def flash_attention(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    causal: bool = False,
    sm_scale: float | None = None,
) -> torch.Tensor:
    """Flash Attention v2 via Triton (autotuned, GQA-aware).

    Args:
        q: Query   (B, H_q, N_q, D)  or  (B*H, N_q, D)
        k: Key     (B, H_k, N_k, D)  or  (B*H, N_k, D)
        v: Value   (B, H_k, N_k, D)  or  (B*H, N_k, D)
        causal:  Apply causal masking.
        sm_scale: Softmax scale (default 1/sqrt(D)).

    Returns:
        Output tensor, same shape as *q*.
    """
    squeeze = False
    if q.ndim == 3:
        q = q.unsqueeze(0)
        k = k.unsqueeze(0)
        v = v.unsqueeze(0)
        squeeze = True

    B, H_q, N_q, D = q.shape
    _, H_k, N_k, _ = k.shape

    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(D)

    needs_grad = q.requires_grad or k.requires_grad or v.requires_grad

    if needs_grad or _mode == "training":
        # Full autograd path — stores LSE for backward
        out = _FlashAttentionFn.apply(q, k, v, causal, sm_scale)
    else:
        # Lightweight inference path — skip autograd wrapper entirely
        out = _fwd_inference(q, k, v, causal, sm_scale)

    return out.squeeze(0) if squeeze else out


def _fwd_inference(q, k, v, causal, sm_scale):
    """Direct kernel call for inference — no autograd overhead."""
    B, H_q, N_q, D = q.shape
    _, H_k, N_k, _ = k.shape

    # ── Tier 0: CUDA C++ kernel for very short sequences ──
    # Matches SDPA speed (~12us) and avoids Triton's Python dispatch (~34us).
    if (
        _wf_cuda is not None
        and max(N_q, N_k) <= _CUDA_SHORT_THRESH
        and D in (64, 128)
        and q.dtype == torch.bfloat16
    ):
        q_c, k_c, v_c = q.contiguous(), k.contiguous(), v.contiguous()
        out = _wf_cuda.short_attn_fwd(q_c, k_c, v_c, sm_scale, causal)
        if out is not None:
            return out

    # ── Tier 1-3: Triton paths (cache / short-seq fast / autotuner) ──
    BLOCK_D = triton.next_power_of_2(D)
    q, k, v = q.contiguous(), k.contiguous(), v.contiguous()
    out = torch.empty_like(q)
    lse = torch.empty(0, device=q.device, dtype=torch.float32)

    # Check cache → short-seq → autotuner
    short_thresh = 512 if _mode == "tts" else _SHORT_SEQ_THRESHOLD
    dtype_str = "bf16" if q.dtype == torch.bfloat16 else "fp16"
    cached = _config_cache.get(N_q, N_k, D, H_q, H_k, dtype_str, causal)

    if cached or max(N_q, N_k) <= short_thresh:
        tile = cached if cached else _SHORT_TILE
        bm = tile["BLOCK_M"]
        grid = (triton.cdiv(N_q, bm), B * H_q)
        _fwd_kernel.fn[grid](
            q, k, v, out, lse, sm_scale,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            0, 0, 0,
            H_q, H_k, N_q, N_k,
            BLOCK_M=bm, BLOCK_N=tile["BLOCK_N"], BLOCK_D=BLOCK_D,
            IS_CAUSAL=causal, HAS_LSE=False,
            num_warps=tile.get("num_warps", 4),
            num_stages=tile.get("num_stages", 3),
        )
    else:
        grid = lambda META: (triton.cdiv(N_q, META["BLOCK_M"]), B * H_q)
        _fwd_kernel[grid](
            q, k, v, out, lse, sm_scale,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            0, 0, 0,
            H_q, H_k, N_q, N_k,
            BLOCK_D=BLOCK_D, IS_CAUSAL=causal, HAS_LSE=False,
        )
        # Capture the autotuner winner and persist it so future process
        # starts skip benchmarking entirely (pre-seeded via load_cache()).
        try:
            triton_key = _triton_cache_key(N_q, N_k, BLOCK_D, causal, dtype_str)
            cfg = getattr(_fwd_kernel, 'cache', {}).get(triton_key)
            if cfg is not None:
                _config_cache.put(N_q, N_k, D, H_q, H_k, dtype_str, causal, {
                    "BLOCK_M": cfg.kwargs["BLOCK_M"],
                    "BLOCK_N": cfg.kwargs["BLOCK_N"],
                    "num_warps": cfg.num_warps,
                    "num_stages": cfg.num_stages,
                })
                _config_cache.save()
        except Exception:
            pass

    return out


# ═══════════════════════════════════════════════════════════════════════
# Optimize / cache API
# ═══════════════════════════════════════════════════════════════════════

def optimize(
    shapes: list[tuple[int, int, int, int, int]] | None = None,
    device: torch.device | int = 0,
    causal_modes: tuple[bool, ...] = (False, True),
    dtypes: tuple[torch.dtype, ...] = (torch.bfloat16,),
) -> int:
    """Benchmark all autotune configs for *shapes* and persist the winners.

    Each shape is ``(B, H_q, H_k, N, D)``.  After this call, subsequent
    ``flash_attention`` invocations matching a cached shape skip the
    autotuner entirely (zero Python overhead).

    Returns the number of configs cached.
    """
    if shapes is None:
        shapes = _DEFAULT_OPT_SHAPES

    _config_cache.load(device)
    count = 0
    total = len(shapes) * len(dtypes) * len(causal_modes)

    for i, (B, H_q, H_k, N, D) in enumerate(shapes):
        BLOCK_D = triton.next_power_of_2(D)
        for dtype in dtypes:
            dtype_str = "bf16" if dtype == torch.bfloat16 else "fp16"
            for causal in causal_modes:
                q = torch.randn(B, H_q, N, D, device=device, dtype=dtype)
                k = torch.randn(B, H_k, N, D, device=device, dtype=dtype)
                v = torch.randn(B, H_k, N, D, device=device, dtype=dtype)
                out = torch.empty_like(q)
                lse = torch.empty(0, device=device, dtype=torch.float32)
                sm_scale = 1.0 / math.sqrt(D)

                # Force the AUTOTUNED path (not fast-path) so Triton picks best config
                grid = lambda META: (triton.cdiv(N, META["BLOCK_M"]), B * H_q)
                _fwd_kernel[grid](
                    q, k, v, out, lse, sm_scale,
                    q.stride(0), q.stride(1), q.stride(2), q.stride(3),
                    k.stride(0), k.stride(1), k.stride(2), k.stride(3),
                    v.stride(0), v.stride(1), v.stride(2), v.stride(3),
                    out.stride(0), out.stride(1), out.stride(2), out.stride(3),
                    0, 0, 0,
                    H_q, H_k, N, N,
                    BLOCK_D=BLOCK_D, IS_CAUSAL=causal, HAS_LSE=False,
                )
                # Run again for stable timing
                _fwd_kernel[grid](
                    q, k, v, out, lse, sm_scale,
                    q.stride(0), q.stride(1), q.stride(2), q.stride(3),
                    k.stride(0), k.stride(1), k.stride(2), k.stride(3),
                    v.stride(0), v.stride(1), v.stride(2), v.stride(3),
                    out.stride(0), out.stride(1), out.stride(2), out.stride(3),
                    0, 0, 0,
                    H_q, H_k, N, N,
                    BLOCK_D=BLOCK_D, IS_CAUSAL=causal, HAS_LSE=False,
                )
                torch.cuda.synchronize(device)

                # Extract winning config from Triton autotuner
                triton_key = _triton_cache_key(N, N, BLOCK_D, causal, dtype_str)
                cfg = getattr(_fwd_kernel, 'cache', {}).get(triton_key)
                if cfg is not None:
                    _config_cache.put(N, N, D, H_q, H_k, dtype_str, causal, {
                        "BLOCK_M": cfg.kwargs["BLOCK_M"],
                        "BLOCK_N": cfg.kwargs["BLOCK_N"],
                        "num_warps": cfg.num_warps,
                        "num_stages": cfg.num_stages,
                    })
                    count += 1

                del q, k, v

    torch.cuda.empty_cache()
    _config_cache.save()
    return count


def load_cache(device: torch.device | int = 0) -> int:
    """Load cached configs from disk and pre-seed the Triton autotuner.

    Call this once at startup to eliminate autotuner overhead for all
    previously-optimized shapes.  Returns the number of configs loaded.
    """
    if not _config_cache.load(device):
        return 0

    cache = getattr(_fwd_kernel, 'cache', None)
    if cache is None:
        return 0

    seeded = 0
    for key_str, cfg_dict in _config_cache._cache.items():
        parts = key_str.split('x')
        # key format: "128x128x64x8:8xbf16xn"
        sq, sk, d = int(parts[0]), int(parts[1]), int(parts[2])
        dtype_str = parts[4]
        causal = parts[5] == 'c'

        BLOCK_D = triton.next_power_of_2(d)
        triton_key = _triton_cache_key(sq, sk, BLOCK_D, causal, dtype_str)

        if triton_key not in cache:
            triton_cfg = triton.Config(
                {"BLOCK_M": cfg_dict["BLOCK_M"], "BLOCK_N": cfg_dict["BLOCK_N"]},
                num_warps=cfg_dict["num_warps"],
                num_stages=cfg_dict["num_stages"],
            )
            cache[triton_key] = triton_cfg
            seeded += 1

    return seeded


# ═══════════════════════════════════════════════════════════════════════
# Monkey-patch helpers
# ═══════════════════════════════════════════════════════════════════════

_original_sdpa = torch.nn.functional.scaled_dot_product_attention


def _patched_sdpa(
    query, key, value,
    attn_mask=None,
    dropout_p=0.0,
    is_causal=False,
    scale=None,
    enable_gqa=False,
):
    """Drop-in SDPA replacement.  Falls back to PyTorch when unsupported."""
    can_use = (
        attn_mask is None
        and dropout_p == 0.0
        and query.is_cuda
        and query.shape[-1] <= 256
        and query.dtype in (torch.float16, torch.bfloat16)
    )

    if can_use:
        try:
            return flash_attention(query, key, value, causal=is_causal, sm_scale=scale)
        except Exception:
            pass

    return _original_sdpa(
        query, key, value,
        attn_mask=attn_mask,
        dropout_p=dropout_p,
        is_causal=is_causal,
        scale=scale,
        enable_gqa=enable_gqa,
    )


def enable_windflash() -> bool:
    """Monkey-patch ``torch.nn.functional.scaled_dot_product_attention``
    to route eligible calls through the WindFlash Triton kernel.

    Also pre-seeds the Triton autotuner with previously discovered best
    tile configs so that startup autotuning (the 300s+ first-run cost)
    is skipped on subsequent process starts.
    """
    torch.nn.functional.scaled_dot_product_attention = _patched_sdpa
    # Load cached tile configs → pre-seed Triton's autotuner dict.
    # Shapes that haven't been seen before will still autotune once;
    # results are saved automatically by _fwd_inference after that.
    try:
        import logging as _logging
        device = torch.cuda.current_device() if torch.cuda.is_available() else 0
        n = load_cache(device)
        _logging.getLogger(__name__).debug(
            "windflash: pre-seeded %d autotune configs from cache", n
        )
    except Exception:
        pass
    return True


def disable_windflash() -> None:
    """Restore the original PyTorch SDPA."""
    torch.nn.functional.scaled_dot_product_attention = _original_sdpa


# Backward-compat aliases
enable_triton_flash_attention = enable_windflash
disable_triton_flash_attention = disable_windflash
