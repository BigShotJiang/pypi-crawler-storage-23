"""Reusable test validators for E2E testing."""
