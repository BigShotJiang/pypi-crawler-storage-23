"""Integration tests for the C-CDA to FHIR converter."""
