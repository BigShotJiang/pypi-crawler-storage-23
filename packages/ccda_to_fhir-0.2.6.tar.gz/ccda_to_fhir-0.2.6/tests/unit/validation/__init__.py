"""Validation tests for C-CDA conformance."""
