use uv, when you run code and tests.
