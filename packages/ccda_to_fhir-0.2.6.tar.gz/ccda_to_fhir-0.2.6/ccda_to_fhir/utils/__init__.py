"""Utility functions for C-CDA to FHIR conversion."""

from __future__ import annotations
