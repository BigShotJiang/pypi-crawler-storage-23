"""C-CDA parsing and models."""

from __future__ import annotations
