"""FHIR R4B resource models."""

from __future__ import annotations
