Project Info
============

.. automodule:: jenkinsapi
   :members:
   :undoc-members:
   :show-inheritance:
