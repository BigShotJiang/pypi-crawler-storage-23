Custom\_exceptions
------------------

.. automodule:: jenkinsapi.custom_exceptions
   :members:
   :undoc-members:
   :show-inheritance:
