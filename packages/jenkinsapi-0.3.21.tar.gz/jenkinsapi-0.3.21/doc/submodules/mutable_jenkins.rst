Mutable_jenkins_thing
---------------------

.. automodule:: jenkinsapi.mutable_jenkins_thing
   :members:
   :undoc-members:
   :show-inheritance:
