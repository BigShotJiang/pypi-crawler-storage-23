Nodes and node
==============

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

nodes
-----

.. automodule:: jenkinsapi.nodes
   :members:
   :undoc-members:
   :show-inheritance:

node
----

.. automodule:: jenkinsapi.node
   :members:
   :undoc-members:
   :show-inheritance:
