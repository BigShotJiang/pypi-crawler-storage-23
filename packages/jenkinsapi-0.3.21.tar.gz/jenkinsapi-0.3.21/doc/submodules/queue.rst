Queue
-----

.. automodule:: jenkinsapi.queue
   :members:
   :undoc-members:
   :show-inheritance:
