User API
========

.. automodule:: jenkinsapi.api
   :members:
   :undoc-members:
   :show-inheritance:
