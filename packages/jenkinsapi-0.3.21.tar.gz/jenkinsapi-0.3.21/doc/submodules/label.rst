Label
-----

.. automodule:: jenkinsapi.label
   :members:
   :undoc-members:
   :show-inheritance:
