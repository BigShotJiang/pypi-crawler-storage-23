class OMMXPythonMIPAdapterError(Exception):
    pass
