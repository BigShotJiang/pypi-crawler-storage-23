"""Agent module for HDSP Agent.

All imports are lazy to avoid pulling in deepagents/langgraph at module load time.
This prevents ImportError when deepagents is missing or has breaking changes.
"""

import importlib as _importlib

# Backward compatibility alias
DeepAgentRunner = None  # populated on first access

__all__ = [
    "AgentConfig",
    "AgentEvent",
    "AgentFactory",
    "AgentRunner",
    "DSMemoryMiddleware",
    "DSSkillsMiddleware",
    "DeepAgentRunner",
    "MemoryEntry",
    "MemoryStore",
    "SKILLS_REGISTRY",
    "config_from_dict",
]

_FACTORY_NAMES = {
    "AgentConfig",
    "AgentEvent",
    "AgentFactory",
    "AgentRunner",
    "config_from_dict",
}

_MIDDLEWARE_NAMES = {
    "DSMemoryMiddleware",
    "DSSkillsMiddleware",
    "MemoryEntry",
    "MemoryStore",
}


def __getattr__(name: str):
    if name in _FACTORY_NAMES:
        mod = _importlib.import_module(".agent_factory", __name__)
        return getattr(mod, name)
    if name in _MIDDLEWARE_NAMES:
        mod = _importlib.import_module(".middleware", __name__)
        return getattr(mod, name)
    if name == "SKILLS_REGISTRY":
        mod = _importlib.import_module(".skills_registry", __name__)
        return mod.SKILLS_REGISTRY
    if name == "DeepAgentRunner":
        mod = _importlib.import_module(".agent_factory", __name__)
        return mod.AgentRunner
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
