from __future__ import annotations

import asyncio
import os
import time
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from loguru import logger
from redis.asyncio import Redis
from redis.exceptions import ResponseError

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_core.utils.aggregators import EventTreeAggregator, EnhancedJSONEncoder
from turbo_agent_core.store import BaseExecutionStore


# 事件流常量（从 store 模块独立出来，避免循环依赖）
GLOBAL_LIFECYCLE_STREAM_KEY = "ta.result.lifecycle"


def trace_lifecycle_stream_key(trace_id: str) -> str:
    return f"ta.result.lifecycle.{trace_id}"


def _trace_lock_key(trace_id: str) -> str:
    return f"ta.store.lock.trace.{trace_id}"


_LOCK_RENEW_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('PEXPIRE', KEYS[1], ARGV[2])
else
    return 0
end
"""


_LOCK_RELEASE_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
"""


def _parse_event(fields: Dict[Any, Any]) -> Optional[BaseEvent]:
    """从 Redis Stream fields 解析事件。

    约定：写入字段为 {"event": json_string}
    """
    raw = fields.get("event")
    if raw is None:
        raw = fields.get(b"event")
    if raw is None:
        return None

    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="ignore")

    try:
        data = json.loads(raw)
    except Exception as e:
        logger.warning(f"事件 JSON 解析失败：{e}")
        return None

    try:
        # v2：run.lifecycle.* 为分裂事件；统一使用 BaseEvent 作为入口做校验与分派。
        return BaseEvent.model_validate(data)
    except Exception as e:
        logger.warning(f"事件 schema 校验失败：{e}")
        return None


async def _ensure_consumer_group(redis: Redis, stream: str, group: str) -> None:
    await _ensure_consumer_group_from(redis=redis, stream=stream, group=group, start_id="0")


async def _ensure_consumer_group_from(*, redis: Redis, stream: str, group: str, start_id: str) -> None:
    try:
        await redis.xgroup_create(name=stream, groupname=group, id=start_id, mkstream=True)
        logger.info(f"已创建消费者组：stream={stream}, group={group}")
    except ResponseError as e:
        # BUSYGROUP: group already exists
        if "BUSYGROUP" in str(e):
            return
        raise


@dataclass
class ConsumerConfig:
    group: str = "ta.store.archive"
    consumer: str = ""
    block_ms: int = 1000
    count: int = 100
    flush_interval_s: float = 2.0
    trace_lock_ttl_ms: int = 5 * 60 * 1000
    trace_lock_renew_s: float = 10.0


class EventStreamConsumer:
    """主消费者：监听全局发现流，发现 trace_id 后拉起 DataStreamConsumer 子消费者。"""

    def __init__(
        self,
        redis: Redis,
        execution_store: BaseExecutionStore,
        config: Optional[ConsumerConfig] = None,
    ):
        self.redis = redis
        self.execution_store = execution_store
        self.config = config or ConsumerConfig()
        if not self.config.consumer:
            self.config.consumer = os.getenv("TA_STORE_CONSUMER", f"consumer-{os.getpid()}")

        self._running = False
        self._trace_tasks: Dict[str, asyncio.Task[None]] = {}
        self._known_traces: Set[str] = set()
        self._trace_locks: Dict[str, str] = {}
        self._trace_created_message_ids: Dict[str, str] = {}

    async def run(self) -> None:
        self._running = True
        stream = GLOBAL_LIFECYCLE_STREAM_KEY
        await _ensure_consumer_group(self.redis, stream, self.config.group)

        await self.execution_store.connect()

        logger.info(
            f"EventStreamConsumer 启动：stream={stream}, group={self.config.group}, consumer={self.config.consumer}"
        )

        await self._drain_pending(stream)

        while self._running:
            try:
                items = await self.redis.xreadgroup(
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    streams={stream: ">"},
                    count=self.config.count,
                    block=self.config.block_ms,
                )
                if not items:
                    await self._drain_pending(stream)
                    continue
                
                logger.info(f"[EventStreamConsumer] xreadgroup 收到 {len(items)} 个流的数据")

                for _stream_name, messages in items:
                    for message_id, fields in messages:
                        should_ack = True
                        event = _parse_event(fields)
                        if event is None:
                            logger.warning(f"[EventStreamConsumer] 无法解析事件: msg_id={message_id}")
                            await self.redis.xack(stream, self.config.group, message_id)
                            continue

                        logger.info(f"[EventStreamConsumer] 处理事件: type={event.type} trace_id={event.trace_id}")

                        # 只用 run.lifecycle.created 来发现新 trace
                        if event.type == "run.lifecycle.created":
                            lifecycle = event
                            try:
                                # ⚠️ 重要：只为 Root Trace 拉起子消费者
                                if getattr(lifecycle, "trace_path", None):
                                    await self.redis.xack(stream, self.config.group, message_id)
                                    continue

                                start_id = None
                                try:
                                    if isinstance(message_id, (bytes, bytearray)):
                                        start_id = message_id.decode("utf-8", errors="ignore")
                                    elif isinstance(message_id, str):
                                        start_id = message_id
                                except Exception:
                                    start_id = None

                                lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
                                if not lock_value:
                                    logger.info(f"trace 正在被其他实例处理，稍后重试：trace_id={lifecycle.trace_id}")
                                    should_ack = False
                                    continue

                                await self._start_trace_consumer(
                                    trace_id=lifecycle.trace_id,
                                    initial_created=lifecycle,
                                    start_stream_id=start_id,
                                    lock_value=lock_value,
                                    global_created_message_id=(
                                        message_id.decode("utf-8", errors="ignore")
                                        if isinstance(message_id, (bytes, bytearray))
                                        else str(message_id)
                                    ),
                                )
                                # 不 ACK：等子消费者正常结束后再 ACK
                                should_ack = False
                            except Exception as e:
                                logger.error(f"处理 created 事件失败，保留 Pending：trace_id={lifecycle.trace_id}, 错误={e}")
                                should_ack = False
                                continue

                        if should_ack:
                            await self.redis.xack(stream, self.config.group, message_id)
            except Exception as e:
                logger.error(f"EventStreamConsumer 循环异常: {e}")
                await asyncio.sleep(1)

    async def stop(self) -> None:
        self._running = False
        for task in list(self._trace_tasks.values()):
            task.cancel()
        await asyncio.gather(*self._trace_tasks.values(), return_exceptions=True)
        self._trace_tasks.clear()
        for trace_id, lock_value in list(self._trace_locks.items()):
            try:
                await self._release_trace_lock(trace_id=trace_id, lock_value=lock_value)
            except Exception:
                pass
        self._trace_locks.clear()
        await self.execution_store.disconnect()

    async def _start_trace_consumer(
        self,
        *,
        trace_id: str,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str,
        global_created_message_id: str,
    ) -> None:
        if trace_id in self._known_traces:
            return
        self._known_traces.add(trace_id)

        self._trace_locks[trace_id] = lock_value
        self._trace_created_message_ids[trace_id] = global_created_message_id

        consumer = DataStreamConsumer(
            redis=self.redis,
            trace_id=trace_id,
            execution_store=self.execution_store,
            initial_created=initial_created,
            start_stream_id=start_stream_id,
            lock_value=lock_value,
            config=self.config,
            parent=self, # Pass reference
        )
        task = asyncio.create_task(consumer.run(), name=f"data-consumer-{trace_id}")

        def _cleanup(_t: asyncio.Task[None]) -> None:
            async def _finalize() -> None:
                final_status = "completed"
                try:
                    if _t.cancelled():
                        final_status = "suspended"
                        logger.warning(f"Trace {trace_id} consumer task cancelled (suspended).")
                    elif _t.exception():
                        final_status = "failed"
                        logger.error(f"Trace {trace_id} consumer task failed: {_t.exception()}")
                    
                    # ACK creation message if completed
                    if final_status == "completed":
                        created_mid = self._trace_created_message_ids.get(trace_id)
                        if created_mid:
                            await self.redis.xack(GLOBAL_LIFECYCLE_STREAM_KEY, self.config.group, created_mid)
                except Exception as e:
                    logger.error(f"Error during trace cleanup: {e}")
                finally:
                    # Update lock status instead of releasing (deleting)
                    await self._update_trace_lock_status(trace_id=trace_id, status=final_status)
                    
                    # Cleanup local state
                    self._trace_created_message_ids.pop(trace_id, None)
                    self._trace_locks.pop(trace_id, None)
                    if self._trace_tasks.get(trace_id) == _t:
                        self._trace_tasks.pop(trace_id, None)
                    
                    if final_status == "suspended":
                        self._known_traces.discard(trace_id)

            asyncio.create_task(_finalize())

        task.add_done_callback(_cleanup)
        self._trace_tasks[trace_id] = task
        logger.info(f"已拉起 DataStreamConsumer：trace_id={trace_id}")

    async def _try_acquire_trace_lock(self, *, trace_id: str) -> str:
        """尝试获取 trace 锁。
        
        锁的值为 JSON 格式：
        {
            "consumer": "consumer-xxx",
            "pid": 12345,
            "timestamp": 1234567890,
            "status": "processing" | "suspended" | "failed" | "completed"
        }
        
        获取规则：
        - 锁不存在 → 可以获取
        - 锁状态为 suspended → 可以重新获取（流程挂起，等待恢复）
        - 锁状态为 processing/failed/completed → 不可获取
        """
        lock_key = _trace_lock_key(trace_id)
        
        # 检查现有锁状态
        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_status = lock_data.get("status", "processing")
                
                # 如果是 suspended，可以重新获取锁
                if lock_status == "suspended":
                    logger.info(f"[锁状态] Trace {trace_id} 状态为 suspended，允许重新获取锁")
                    # 删除旧锁，准备获取新锁
                    await self.redis.delete(lock_key)
                else:
                    # processing/failed/completed 状态不允许获取
                    logger.debug(f"[锁状态] Trace {trace_id} 状态为 {lock_status}，拒绝获取锁")
                    return ""
            except (json.JSONDecodeError, Exception) as e:
                # 旧格式或损坏的锁，尝试删除
                logger.warning(f"[锁状态] 锁格式错误，删除重试: {e}")
                await self.redis.delete(lock_key)
        
        # 创建新锁（状态为 processing）
        lock_data = {
            "consumer": self.config.consumer,
            "pid": os.getpid(),
            "timestamp": int(time.time() * 1000),
            "status": "processing"
        }
        lock_value = json.dumps(lock_data)
        ttl_ms = int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000))
        
        ok = await self.redis.set(lock_key, lock_value, nx=True, px=ttl_ms)
        return lock_value if ok else ""

    async def _update_trace_lock_status(self, *, trace_id: str, status: str) -> None:
        """更新 trace 锁的状态。
        
        Args:
            trace_id: Trace ID
            status: 新状态 - "processing" | "suspended" | "failed" | "completed"
        """
        lock_key = _trace_lock_key(trace_id)
        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_data["status"] = status
                lock_data["updated_at"] = int(time.time() * 1000)
                # 根据状态决定 TTL：completed/suspended 延长到 24 小时，其他保持原有 TTL
                if status in ("completed", "suspended"):
                    ttl_ms = 24 * 60 * 60 * 1000  # 24 小时
                else:
                    ttl_ms = await self.redis.pttl(lock_key)
                    if ttl_ms <= 0:
                        ttl_ms = 5 * 60 * 1000  # 默认 5 分钟
                await self.redis.set(lock_key, json.dumps(lock_data), px=ttl_ms)
                logger.info(f"[锁状态] 更新 Trace {trace_id} 锁状态为: {status}, TTL: {ttl_ms}ms")
            except Exception as e:
                logger.warning(f"[锁状态] 更新锁状态失败: {e}")

    async def _release_trace_lock(self, *, trace_id: str, lock_value: str) -> None:
        """释放锁（完全删除）。"""
        lock_key = _trace_lock_key(trace_id)
        try:
            await self.redis.eval(_LOCK_RELEASE_LUA, 1, lock_key, lock_value)
        finally:
            if self._trace_locks.get(trace_id) == lock_value:
                self._trace_locks.pop(trace_id, None)

    async def _drain_pending(self, stream: str) -> None:
        # 1. 首先读取自己拥有的 Pending 消息 (无论 idle 时间)
        try:
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=None # Non-blocking
            )
            for _stream_name, messages in items or []:
                 for message_id, fields in messages:
                     await self._process_pending_msg(stream, message_id, fields)
        except Exception as e:
            logger.warning(f"Drain pending (self) failed: {e}")

        # 2. 尝试 Claim 超过 idle 时间的消息 (从其他消费者或已废弃的消费者抢救)
        start_id = "0-0"
        while True:
            try:
                # DEBUG: min_idle_time reduced to 100ms
                res = await self.redis.xautoclaim(
                    name=stream,
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    min_idle_time=60000,
                    start_id=start_id,
                    count=self.config.count,
                )
                if not isinstance(res, (list, tuple)) or len(res) < 2:
                    break
                
                next_start_id = res[0]
                raw_messages = res[1] or []

                if raw_messages:
                     logger.info(f"[_drain_pending] xautoclaim claimed {len(raw_messages)} messages")
                
                for mid, fields in raw_messages:
                    await self._process_pending_msg(stream, mid, fields)

                if next_start_id == "0-0":
                    break
                start_id = next_start_id
            except Exception as e:
                logger.warning(f"Drain pending (autoclaim) failed: {e}")
                break
        
        # 针对 DataStreamConsumer force flush
        if hasattr(self, "_maybe_flush"): 
            await self._maybe_flush(force=True)

    async def _process_pending_msg(self, stream: str, message_id: Any, fields: Dict[Any, Any]) -> None:
        """处理 EventStreamConsumer 的 pending 消息。仅处理 run.lifecycle.created 事件。"""
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return

        # 仅处理 run.lifecycle.created
        if event.type != "run.lifecycle.created":
            await self.redis.xack(stream, self.config.group, message_id)
            return

        lifecycle = event
        # 只为 Root Trace 拉起子消费者
        if getattr(lifecycle, "trace_path", None):
            await self.redis.xack(stream, self.config.group, message_id)
            return

        # 如果本地任务中已存在该 Trace 且未完成，认为是重复的 Start 消息，直接 ACK
        if lifecycle.trace_id in self._trace_tasks and not self._trace_tasks[lifecycle.trace_id].done():
            logger.info(f"[EventStreamConsumer] Trace {lifecycle.trace_id} 正在处理中 (local)，视为重复消息并 ACK: {message_id}")
            await self.redis.xack(stream, self.config.group, message_id)
            return

        # 尝试获取锁（锁内部会检查状态）
        lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
        if not lock_value:
            # 无法获取锁，说明：
            # 1. 正在被其他消费者处理 (status=processing)
            # 2. 已失败 (status=failed)
            # 3. 已完成 (status=completed)
            # 这些情况下都应该 ACK 消息，避免重复处理
            logger.debug(f"[EventStreamConsumer] 无法获取锁，ACK 消息: trace_id={lifecycle.trace_id}")
            await self.redis.xack(stream, self.config.group, message_id)
            return


class DataStreamConsumer:
    """子消费者：消费单 Trace 的事件流，使用 EventTreeAggregator 聚合，并落库。"""

    def __init__(
        self,
        redis: Redis,
        trace_id: str,
        execution_store: BaseExecutionStore,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str,
        config: Optional[ConsumerConfig] = None,
        parent: Optional[EventStreamConsumer] = None
    ):
        self.redis = redis
        self.trace_id = trace_id
        self.execution_store = execution_store
        self.config = config or ConsumerConfig()
        self.parent = parent
        if not self.config.consumer:
            self.config.consumer = os.getenv("TA_STORE_CONSUMER", f"consumer-{os.getpid()}")

        self._running = False
        self._start_stream_id = start_stream_id
        self._initial_created = initial_created
        self._lock_key = _trace_lock_key(trace_id)
        self._lock_value = lock_value
        self._lock_renew_task: Optional[asyncio.Task[None]] = None

        self._last_flush_mono: float = time.monotonic()
        self._dirty: bool = False

        # 使用 EventTreeAggregator
        self.aggregator = EventTreeAggregator(root_trace_id=trace_id)

        self._stream_name: Optional[str] = None
        self._pending_ack_ids: list[Any] = []

    async def run(self) -> None:
        self._running = True
        stream = trace_lifecycle_stream_key(self.trace_id)
        self._stream_name = stream

        self._lock_renew_task = asyncio.create_task(self._renew_lock_loop(), name=f"trace-lock-renew-{self.trace_id}")
        
        start_id = "0"
        if self._start_stream_id:
            try:
                ms = str(self._start_stream_id).split("-", 1)[0]
                start_id = f"{ms}-0"
            except Exception:
                start_id = "0"

        await _ensure_consumer_group_from(redis=self.redis, stream=stream, group=self.config.group, start_id=start_id)

        try:
            await self.handle_event(self._initial_created)
        except Exception as e:
            logger.error(f"initial_created 处理失败：trace_id={self.trace_id}, 错误={e}")

        # Pending check
        await self._drain_pending(stream)

        try:
            while self._running:
                try:
                    items = await self.redis.xreadgroup(
                        groupname=self.config.group,
                        consumername=self.config.consumer,
                        streams={stream: ">"},
                        count=self.config.count,
                        block=self.config.block_ms,
                    )
                    if not items:
                        continue

                    for _stream_name, messages in items:
                        for message_id, fields in messages:
                            logger.info(f"DataStreamConsumer 收到事件: trace_id={self.trace_id}, message_id={fields}")
                            trace_completed = await self._process_message(
                                stream, message_id, fields, check_completion=True
                            )
                            if trace_completed:
                                self._running = False
                                break
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.error(f"Trace loop error: {e}")
                    # 出错时标记为 failed
                    try:
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                    except:
                        pass
                    await asyncio.sleep(1)
        finally:
            logger.info(f"DataStreamConsumer flushing on exit: trace_id={self.trace_id}")
            await self._maybe_flush(force=True)

            # 注意：这里不再释放锁，而是保持锁的最终状态标记
            # 锁会在 TTL 过期后自动清理
            # try:
            #     await self.redis.eval(_LOCK_RELEASE_LUA, 1, self._lock_key, self._lock_value)
            # except Exception:
            #     pass

            if self._lock_renew_task:
                self._lock_renew_task.cancel()
                pass

            if self._lock_renew_task:
                self._lock_renew_task.cancel()
                await asyncio.gather(self._lock_renew_task, return_exceptions=True)

    async def _process_message(self, stream: str, message_id: Any, fields: Dict[str, Any], *, check_completion: bool = False) -> bool:
        """处理单条消息。

        Args:
            stream: Redis stream 名称
            message_id: 消息 ID
            fields: 消息字段
            check_completion: 是否检查 Trace 完成状态

        Returns:
            如果 Trace 已结束返回 True，否则返回 False
        """
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return False

        try:
            logger.info(f"Processing event: trace_id={self.trace_id}, type={event.type}, event={event}")
            await self.handle_event(event)
        except Exception as e:
            logger.error(f"事件 handle 失败：trace_id={self.trace_id}, type={event.type}, 错误={e}")

        self._pending_ack_ids.append(message_id)
        await self._maybe_flush(force=False)

        # 检查是否 Trace 结束
        if check_completion:
            root_snapshot = self.aggregator.snapshot_root()
            if root_snapshot and root_snapshot.is_closed:
                logger.info(f"Trace Completed: trace_id={self.trace_id}")
                await self._maybe_flush(force=True)

                # 根据最终状态更新锁
                final_status = getattr(root_snapshot, "status", "completed")
                if str(final_status) == "suspended":
                    await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="suspended")
                elif str(final_status) in ["failed", "error"]:
                    await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                else:
                    await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="completed")

                return True
        return False

    async def _drain_pending(self, stream: str) -> None:
        try:
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=1,
            )
        except Exception:
            return

        for _stream_name, messages in items or []:
            for message_id, fields in messages:
                await self._process_message(stream, message_id, fields, check_completion=False)

        await self._maybe_flush(force=True)

    async def handle_event(self, event: BaseEvent) -> None:
        self.aggregator.on_event(event)
        for node in self.aggregator.iter_nodes_post_order():
            logger.debug(f"事件处理结束 handled: trace_id={self.trace_id}, type={event.type} node_id={node.trace_id} snapshot={node.snapshot()}")
        self._dirty = True

    async def _maybe_flush(self, *, force: bool) -> None:
        if not self._dirty and not force:
            return

        now = time.monotonic()
        interval = float(getattr(self.config, "flush_interval_s", 2.0))
        if not force and (now - self._last_flush_mono) < interval:
            return

        await self._flush()

    async def _flush(self) -> None:
        # Pass the aggregator tree to the store
        # snapshots = self.aggregator.snapshot_all()
        created_resources = {} 
        await self.execution_store.save_trace_snapshot(self.aggregator, created_resources)

        if self._pending_ack_ids and self._stream_name:
            try:
                await self.redis.xack(self._stream_name, self.config.group, *self._pending_ack_ids)
            finally:
                self._pending_ack_ids.clear()

        self._dirty = False
        self._last_flush_mono = time.monotonic()

    async def _renew_lock_loop(self) -> None:
        interval = float(getattr(self.config, "trace_lock_renew_s", 10.0))
        ttl_ms = str(int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000)))
        while self._running:
            try:
                await self.redis.eval(_LOCK_RENEW_LUA, 1, self._lock_key, self._lock_value, ttl_ms)
            except Exception:
                pass
            await asyncio.sleep(interval)
