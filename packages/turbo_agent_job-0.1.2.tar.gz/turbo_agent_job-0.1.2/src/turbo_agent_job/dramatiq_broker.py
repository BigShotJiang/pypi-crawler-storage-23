import dramatiq
from dramatiq.brokers.redis import RedisBroker
from turbo_agent_job.settings import settings

# Configure Redis Broker
REDIS_URL = settings.REDIS_URL

broker = RedisBroker(url=REDIS_URL)

# Configure Dramatiq globally to use this broker
dramatiq.set_broker(broker)
