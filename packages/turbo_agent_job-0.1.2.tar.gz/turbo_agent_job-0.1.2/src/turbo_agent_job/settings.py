import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file
# Try to load from backend root first (5 levels up), then package root
# __file__ is backend/packages/turbo-agent-job/src/turbo_agent_job/settings.py
current_dir = Path(__file__).resolve().parent

# 1. Backend root .env: backend/.env
# current -> src/turbo_agent_job -> src -> turbo-agent-job -> packages -> backend
backend_env_path = current_dir.parent.parent.parent.parent / ".env"

# 2. Package root .env: backend/packages/turbo-agent-job/.env
package_env_path = current_dir.parent.parent / ".env"

if backend_env_path.exists():
    load_dotenv(dotenv_path=backend_env_path)
elif package_env_path.exists():
    load_dotenv(dotenv_path=package_env_path)
else:
    # Try loading from CWD (useful for debugging)
    load_dotenv()

class Settings:
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_CACHE_URL = os.getenv("REDIS_CACHE_URL", "redis://localhost:6379/1")
    REDIS_RESULT_URL = os.getenv("REDIS_RESULT_URL", "redis://localhost:6379/2")

settings = Settings()
