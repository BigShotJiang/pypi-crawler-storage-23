from turbo_agent_core.schema.jobs import TaskSpec
from turbo_agent_job.worker import execute_task
from turbo_agent_job.dramatiq_broker import broker
from turbo_agent_job.settings import settings
from loguru import logger
import uuid
import dramatiq

class TaskDispatcher:
    """
    统一任务分发器
    负责将 TaskSpec 分发到正确的 Dramatiq 队列
    """
    
    @staticmethod
    def submit_task(task_spec: TaskSpec) -> str:
        """
        提交任务到 Job 队列
        
        Args:
            task_spec: 任务规格说明书
        Returns:
            task_id: 任务ID
        """
        # 1. 确保 task_id 存在
        if not task_spec.task_id:
            task_spec.task_id = str(uuid.uuid4())

        # 2. 自动路由：根据 source + origin 决定队列
        queue_name = f"ta_job_{task_spec.task_source.value}_{task_spec.task_origin.value}"
        
        masked_redis_url = settings.REDIS_URL.replace(settings.REDIS_URL.split(":")[2].split("@")[0], "***") if "@" in settings.REDIS_URL else settings.REDIS_URL
        logger.info(f"Client connecting to Redis: {masked_redis_url}")
        logger.info(f"正在将任务 {task_spec.task_id} 分发到队列: {queue_name}")
        
        # 3. 发送任务到 Dramatiq
        message_args = [task_spec.model_dump(mode="json")]
        
        base_msg = execute_task.message_with_options(
            args=message_args,
            queue_name=queue_name
        )
        
        final_msg = dramatiq.Message(
            queue_name=queue_name,
            actor_name=base_msg.actor_name,
            args=base_msg.args,
            kwargs=base_msg.kwargs,
            options=base_msg.options,
            message_id=base_msg.message_id,
            message_timestamp=base_msg.message_timestamp,
        )
        
        broker.enqueue(final_msg)
        return task_spec.task_id
