import asyncio
import uuid
from typing import List
from datetime import datetime, timezone
from loguru import logger
from turbo_agent_core.schema.states import JobTask
from turbo_agent_core.store.config import BaseConfigStore
from turbo_agent_core.schema.enums import JobTaskStatus, TaskSource, TaskOrigin, TaskAction, AgentMode
from turbo_agent_core.schema.jobs import TaskSpec
from turbo_agent_job.client import TaskDispatcher

class JobMaster:
    def __init__(self, config_store: BaseConfigStore):
        """
        Args:
            config_store: 配置存储实例，由调用者提供（如 PrismaConfigStore）
        """
        self.store = config_store
        self.is_running = False

    async def start(self):
        logger.info("正在启动 Job Master...")
        await self.store.connect()
        self.is_running = True
        
        # 启动循环
        await asyncio.gather(
            self.planner_loop(),
            self.dispatcher_loop()
        )

    async def stop(self):
        logger.info("正在停止 Job Master...")
        self.is_running = False
        await self.store.disconnect()

    async def planner_loop(self):
        """
        定期检查活跃 Job 并创建未来的 JobTasks。
        """
        logger.info("Planner 循环已启动")
        while self.is_running:
            try:
                await self.plan_jobs()
            except Exception as e:
                logger.error(f"Planner 循环出错: {e}")
            
            await asyncio.sleep(60) # 每分钟检查一次

    async def dispatcher_loop(self):
        """
        定期检查已调度且到期的 JobTasks 并分发到 Celery。
        """
        logger.info("Dispatcher 循环已启动")
        while self.is_running:
            try:
                await self.dispatch_tasks()
            except Exception as e:
                logger.error(f"Dispatcher 循环出错: {e}")
            
            await asyncio.sleep(10) # 每10秒检查一次

    async def plan_jobs(self):
        logger.debug("正在规划 Jobs...")
        # TODO: 在 Store 中添加状态过滤器，仅获取活跃的 jobs
        jobs = await self.store.list_jobs(limit=1000) 
        
        for job in jobs:
            if not job.is_active:
                continue
                
            # next_start_times 由 Core 模型自动计算
            for start_time in job.next_start_times:
                # 确保 start_time 是时区感知的或 naive 的。
                # Prisma 通常返回感知的 datetimes。
                
                # 检查任务是否已存在
                existing = await self.store.find_job_task(job.id, start_time)
                if existing:
                    continue
                
                # 创建新任务
                task = JobTask(
                    id=str(uuid.uuid4()),
                    job_id=job.id,
                    expected_start_time=start_time,
                    status=JobTaskStatus.SCHEDULED,
                    # 初始化其他必填字段（如果有）
                    trace_id="", # 将在运行时生成？还是现在生成？
                    retry_count=0
                )
                # 注意: save_job_task 如果未提供 ID 会处理 ID 生成
                await self.store.save_job_task(task)
                logger.info(f"已为 Job {job.name} 调度任务，时间: {start_time}")

    async def dispatch_tasks(self):
        """
        分发到期任务到 Celery 队列
        
        流程：
        1. 查找到期的 JobTask（状态为 SCHEDULED，且 expectedStartTime <= now）
        2. 加载 Job 配置
        3. 基于 store 拼装完整的 TaskSpec（包含完整 Agent/Character）
        4. 序列化 TaskSpec 并发送到 Celery 队列（基于 task_source + task_origin 路由）
        """
        logger.debug("正在分发任务...")
        
        # 查找状态为 SCHEDULED 且 expectedStartTime <= now 的任务
        # 使用 Store 接口获取到期任务
        due_tasks = await self.store.list_due_job_tasks(limit=50)
        
        logger.debug(f"发现 {len(due_tasks)} 个到期任务")
        
        for task in due_tasks:
            try:
                logger.info(f"正在分发任务 {task.id} (预期时间: {task.expected_start_time})")
                
                # 1. 更新状态为 PENDING (入队中)
                await self.store.update_job_task_status(task.id, JobTaskStatus.PENDING)
                
                # 2. 加载 Job 配置
                job = await self.store.get_job(task.job_id)
                if not job:
                    logger.error(f"未找到 Job {task.job_id}，跳过任务 {task.id}")
                    continue
                
                # 3. 拼装 TaskSpecs (支持多执行者并行)
                task_specs = await self._build_task_specs(task, job)
                
                # 4. 基于 TaskDispatcher 发送（TaskDispatcher 自动处理路由）
                for spec in task_specs:
                    TaskDispatcher.submit_task(spec)
                    # 获取执行者名称用于日志
                    # executor_name = getattr(spec.executor, 'name', 'Unknown')
                    logger.info(f"任务 {task.id} 已发送调度")
                
            except Exception as e:
                logger.error(f"分发任务 {task.id} 失败: {e}", exc_info=True)
    
    async def _build_task_specs(self, task: JobTask, job) -> List[TaskSpec]:
        """
        基于 JobTask 和 Job 构造完整的 TaskSpec 列表
        
        关键设计：
        - 支持多执行者并行：为 job.executors 中的每个执行者创建一个 TaskSpec
        - 共享 conversation_id 和 input_data
        - 每个 TaskSpec 拥有独立的 trace_id
        - 确定 task_source 和 task_origin（离线任务默认为 OFFLINE + INTERNAL）
        """
        specs = []
        
        # 1. 基础数据准备
        conversation_id = task.conversation_id or str(uuid.uuid4())
        task_source = TaskSource.OFFLINE  # 由 Master 调度触发
        # TODO: 后续实现分析方法来区分 EXTERNAL / INTERNAL
        task_origin = TaskOrigin.INTERNAL
        
        # 2. 校验执行者
        if not job.executors or len(job.executors) == 0:
            raise ValueError(f"Job {job.id} 没有配置执行者")
        
        # 3. 为每个执行者构建 TaskSpec
        for executor in job.executors:
            trace_id = str(uuid.uuid4())
            
            # TODO: 从 store 加载完整的 Agent/Character（包含关联的 tools、model 等）
            # 目前假设 job.executors 已经包含了必要信息
            
            task_spec = TaskSpec(
                task_id=task.id,
                conversation_id=conversation_id,
                trace_id=trace_id,
                action=TaskAction.START,
                task_source=task_source,
                task_origin=task_origin,
                executor=executor,
                agent_mode=job.executorMode or AgentMode.ASSISTANT_MODE,
                input_data=task.input_payload
            )
            specs.append(task_spec)
        
        return specs
    
    def _get_queue_name(self, task_source: TaskSource, task_origin: TaskOrigin) -> str:
        """
        根据任务标签生成队列名称
        
        队列命名规范：ta.job.{source}.{origin}
        例如：
        - ta.job.online.external
        - ta.job.online.internal
        - ta.job.offline.external
        - ta.job.offline.internal
        """
        return f"ta.job.{task_source.value}.{task_origin.value}"

if __name__ == "__main__":
    # 简单的测试入口
    pass
