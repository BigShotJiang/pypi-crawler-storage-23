import typer
import asyncio
import sys
import subprocess
from loguru import logger
from turbo_agent_job.master import JobMaster

app = typer.Typer(help="Turbo Agent Job 模块 CLI")

@app.command()
def master():
    """
    启动 Job Master 服务 (Planner & Dispatcher)。
    """
    logger.info("正在启动 Job Master CLI...")
    
    master_service = JobMaster()
    
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        loop.run_until_complete(master_service.start())
        # 保持运行
        loop.run_forever()
    except KeyboardInterrupt:
        logger.info("接收到停止信号")
    finally:
        loop.run_until_complete(master_service.stop())
        loop.close()

@app.command()
def worker(
    source: str = typer.Option(
        "all",
        help="任务来源过滤 (online/offline/all)"
    ),
    origin: str = typer.Option(
        "all",
        help="请求归属过滤 (external/internal/all)"
    ),
    processes: int = typer.Option(1, help="并发 Worker 进程数量 (threads=processes)"),
    threads: int = typer.Option(1, help="每个进程的线程数 (Dramatiq defaults to 8, but we default to 1 for safety)"),
    loglevel: str = typer.Option("INFO", help="日志级别")
):
    """
    启动 Job Worker 服务 (Dramatiq Worker)。
    
    队列监听策略：
    - 默认监听所有队列（source=all, origin=all）
    - 可通过 --source 和 --origin 参数指定监听特定标签的队列
    """
    logger.info(f"正在启动 Job Worker CLI (来源: {source}, 归属: {origin}, 进程: {processes}, 线程: {threads}, 日志: {loglevel})...")
    
    # 根据过滤条件构建监听队列列表
    queues = _build_queue_list(source, origin)
    logger.info(f"Worker 将监听以下队列: {', '.join(queues)}")
    
    # 构建 Dramatiq CLI 参数
    # dramatiq turbo_agent_job.worker [OPTIONS]
    cmd = [
        "uv", "run", "dramatiq", "turbo_agent_job.worker",
        "--processes", str(processes),
        "--threads", str(threads),
        "--queues", *queues,
    ]
    
    if loglevel == "DEBUG":
        cmd.append("--verbose")
        
    logger.info(f"执行命令: {' '.join(cmd)}")
    
    # 传递日志级别给子进程 loguru
    import os
    env = os.environ.copy()
    env["LOGURU_LEVEL"] = loglevel.upper()

    try:
        subprocess.run(cmd, check=True, env=env)
    except KeyboardInterrupt:
        logger.info("Worker 停止")
    except subprocess.CalledProcessError as e:
        logger.error(f"Worker 异常退出: {e}")
        sys.exit(e.returncode)

def _build_queue_list(source: str, origin: str) -> list:
    """
    根据过滤条件构建队列列表
    
    Args:
        source: 任务来源 (online/offline/all)
        origin: 请求归属 (external/internal/all)
    
    Returns:
        队列名称列表
    """
    sources = ["online", "offline"] if source == "all" else [source]
    origins = ["external", "internal"] if origin == "all" else [origin]
    
    queues = []
    for s in sources:
        for o in origins:
            queues.append(f"ta_job_{s}_{o}")
    
    return queues


if __name__ == "__main__":
    app()

