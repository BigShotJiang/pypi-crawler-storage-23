from __future__ import annotations

import asyncio
import functools
import inspect
import json
import uuid
from datetime import datetime
from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Awaitable, Callable, Optional, Type, TypeVar, Dict, Union
from dataclasses import dataclass

from loguru import logger
from redis.asyncio import Redis

from turbo_agent_core.schema.events import BaseEvent, UserInfo
from turbo_agent_core.utils.aggregators import EventTreeAggregator
from turbo_agent_core.store import BaseExecutionStore, BaseRuntimeMonitor


T = TypeVar("T")


# 默认常量值
DEFAULT_GLOBAL_LIFECYCLE_STREAM_KEY = "ta.result.lifecycle"


def _default_trace_lifecycle_stream_key(trace_id: str) -> str:
    return f"ta.result.lifecycle.{trace_id}"


@dataclass
class MonitorConfig:
    """RuntimeMonitor 配置"""
    global_lifecycle_stream_key: str = DEFAULT_GLOBAL_LIFECYCLE_STREAM_KEY
    trace_lifecycle_stream_key_fn: Callable[[str], str] = _default_trace_lifecycle_stream_key


@dataclass
class _PendingWrite:
    stream: str
    event_json: str


class RedisRuntimeMonitor(BaseRuntimeMonitor):
    """基于 Redis Stream 的 Runtime 事件监控器。

    设计目标：
    - 不阻塞 runtime 的事件 yield（旁路写入）
    - 统一写入规则：
      - 所有事件写入 ta.result.lifecycle.{trace_id}
      - run.lifecycle 额外镜像写入 ta.result.lifecycle
    """

    def __init__(self, redis_client: Redis, queue_maxsize: int = 5000, config: Optional[MonitorConfig] = None):
        self._redis = redis_client
        self._queue: asyncio.Queue[_PendingWrite] = asyncio.Queue(maxsize=queue_maxsize)
        self._writer_task: Optional[asyncio.Task[None]] = None
        self._config = config or MonitorConfig()

    def start(self) -> None:
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def close(self) -> None:
        if self._writer_task is None:
            return
            
        # 等待队列排空（最多等待 5 秒）
        try:
            await asyncio.wait_for(self._queue.join(), timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            logger.warning("RedisRuntimeMonitor close timeout, some events might be lost")

        self._writer_task.cancel()
        try:
            await self._writer_task
        except asyncio.CancelledError:
            pass

    async def _writer_loop(self) -> None:
        while True:
            item = await self._queue.get()
            try:
                msg_id = await self._redis.xadd(item.stream, {"event": item.event_json})
                logger.info(f"[RedisRuntimeMonitor] 成功写入事件 to Redis: stream={item.stream} msg_id={msg_id} event_json={item.event_json}")
            except Exception as e:
                logger.warning("RuntimeMonitor 写入 Redis Stream 失败：stream={}, 错误={}", item.stream, e)
            finally:
                self._queue.task_done()

    def _enqueue(self, stream: str, event: BaseEvent) -> None:
        try:
            payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
            self._queue.put_nowait(_PendingWrite(stream=stream, event_json=payload))
            logger.info(f"[RedisRuntimeMonitor] Enqueued event: type={event.type} trace_id={event.trace_id} stream={stream}")
        except asyncio.QueueFull:
            logger.warning("RuntimeMonitor 写入队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)

    def write(self, event: BaseEvent) -> None:
        """旁路写入（同步接口，非阻塞）。"""
        self.start()
        self._enqueue(self._config.trace_lifecycle_stream_key_fn(event.trace_id), event)
        if str(event.type).startswith("run.lifecycle"):
            # 仅当 trace_path 为空（即根节点）时，才通知全局流，避免子任务状态干扰
            if not event.trace_path:
                self._enqueue(self._config.global_lifecycle_stream_key, event)


class DirectRuntimeMonitor(BaseRuntimeMonitor):
    """直接写入 Store 的 Runtime 事件监控器（不依赖 Redis）。
    
    适用于：
    - 本地开发/调试
    - 不使用 Redis 的轻量级部署
    """

    def __init__(self, store: BaseExecutionStore, queue_maxsize: int = 5000):
        self._store = store
        self._queue: asyncio.Queue[BaseEvent] = asyncio.Queue(maxsize=queue_maxsize)
        self._writer_task: Optional[asyncio.Task[None]] = None
        # 维护每个 trace 的聚合器
        self._aggregators: Dict[str, EventTreeAggregator] = {}

    def start(self) -> None:
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def close(self) -> None:
        if self._writer_task is None:
            return
        self._writer_task.cancel()
        try:
            await self._writer_task
        except asyncio.CancelledError:
            pass

    async def _writer_loop(self) -> None:
        while True:
            event = await self._queue.get()
            try:
                # Resolve root trace id
                trace_id = event.trace_path[0] if event.trace_path else event.trace_id
                
                if trace_id not in self._aggregators:
                    self._aggregators[trace_id] = EventTreeAggregator(root_trace_id=trace_id)
                
                aggregator = self._aggregators[trace_id]
                aggregator.on_event(event)
                
                # 每次事件都尝试保存快照（可能会有性能问题，但在 Direct 模式下通常并发不高）
                # 优化：可以考虑只在关键事件或定期保存
                await self._store.save_trace_snapshot(aggregator, {})
                
                # 如果是 trace 结束，可以清理 aggregator? 
                # 暂时保留，避免复杂化
            except Exception as e:
                logger.warning("DirectRuntimeMonitor 写入 Store 失败：trace_id={}, 错误={}", event.trace_id, e)
            finally:
                self._queue.task_done()

    def write(self, event: BaseEvent) -> None:
        self.start()
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning("DirectRuntimeMonitor 写入队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)


from contextvars import ContextVar

_monitor_global: Optional[BaseRuntimeMonitor] = None
_monitor_ctx: ContextVar[Optional[BaseRuntimeMonitor]] = ContextVar("runtime_monitor", default=None)


def init_runtime_monitor(redis_url: str, config: Optional[MonitorConfig] = None) -> None:
    """在 Job Worker 启动时调用；初始化全局监控器 (Redis 模式)。"""
    global _monitor_global
    redis_client = Redis.from_url(redis_url, decode_responses=False)
    _monitor_global = RedisRuntimeMonitor(redis_client, config=config)
    _monitor_global.start()


def init_direct_monitor(store: BaseExecutionStore) -> None:
    """初始化全局监控器 (Direct 模式)。"""
    global _monitor_global
    _monitor_global = DirectRuntimeMonitor(store)
    _monitor_global.start()


def set_monitor_context(monitor: BaseRuntimeMonitor) -> None:
    """设置当前上下文的 Monitor (覆盖全局)。"""
    _monitor_ctx.set(monitor)


def get_monitor() -> BaseRuntimeMonitor:
    m = _monitor_ctx.get()
    if m is not None:
        return m
    if _monitor_global is not None:
        return _monitor_global
    raise RuntimeError("RuntimeMonitor 未初始化，请先调用 init_runtime_monitor 或 init_direct_monitor")


def monitor_execution(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """监控一个协程函数的执行。

    说明：当前实现仅保留 run_id/耗时采集骨架；真正的事件级归档请使用 RuntimeMonitor。
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        run_id = str(uuid.uuid4())
        start_time = datetime.now()
        try:
            result = await func(*args, **kwargs)
            _ = (run_id, start_time)
            return result
        except Exception:
            _ = (run_id, start_time)
            raise

    return wrapper


def monitor_class(cls: Optional[Type] = None, *, user_info: Optional[Union[UserInfo, Dict[str, Any]]] = None) -> Any:
    """类装饰器：自动监控 TurboEntity 的 stream/a_stream 方法。
    
    支持参数：
    - user_info: 绑定默认用户信息（可选）
    
    用法：
    @monitor_class
    class MyAgent: ...
    
    @monitor_class(user_info={"id": "..."})
    class MySystemAgent: ...
    """
    def _process(inner_cls: Type) -> Type:
        # 解析 user_info
        parsed_user = None
        if user_info:
            if isinstance(user_info, UserInfo):
                parsed_user = user_info
            elif isinstance(user_info, dict):
                try:
                    parsed_user = UserInfo.model_validate(user_info)
                except Exception:
                    pass

        for name, method in inspect.getmembers(inner_cls):
            if name in {"stream", "a_stream"} and (
                inspect.isfunction(method) or inspect.iscoroutinefunction(method)
            ):
                # 使用延迟获取 monitor 的包装器
                setattr(inner_cls, name, _monitor_stream_wrapper(method, bound_user_info=parsed_user))
        return inner_cls

    if cls is None:
        return _process
    return _process(cls)


def monitor_object(
    obj: Any, 
    user_info: Optional[Union[UserInfo, Dict[str, Any]]] = None,
    override_trace_id: Optional[str] = None
) -> Any:
    """对象装饰器：在运行时动态监控已创建对象的 stream/a_stream 方法。
    
    支持参数：
    - user_info: 绑定默认用户信息（可选）
    - override_trace_id: 强制覆盖所有事件的 trace_id（可选）
    
    适用于：
    - 对象已实例化，无法修改类定义。
    - 需要针对特定实例开启监控。
    """
    # 解析 user_info
    parsed_user = None
    if user_info:
        if isinstance(user_info, UserInfo):
            parsed_user = user_info
        elif isinstance(user_info, dict):
            try:
                parsed_user = UserInfo.model_validate(user_info)
            except Exception:
                pass

    for name in {"stream", "a_stream"}:
        if hasattr(obj, name):
            method = getattr(obj, name)
            # 仅包装方法或协程函数
            if inspect.ismethod(method) or inspect.isfunction(method) or inspect.iscoroutinefunction(method):
                # 包装绑定方法
                wrapped = _monitor_stream_wrapper(
                    method, 
                    bound_user_info=parsed_user,
                    override_trace_id=override_trace_id
                )
                # 动态替换实例方法
                # 注意：对于 Pydantic 模型，直接 setattr 会触发字段验证导致 ValueError
                # 因此使用 object.__setattr__ 绕过 Pydantic 检查
                object.__setattr__(obj, name, wrapped)
    return obj


def _monitor_stream_wrapper(
    func: Callable[..., AsyncIterator[BaseEvent]], 
    bound_user_info: Optional[UserInfo] = None,
    override_trace_id: Optional[str] = None
) -> Callable[..., AsyncIterator[BaseEvent]]:
    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> AsyncIterator[BaseEvent]:
        # 尝试获取全局 monitor，如果未初始化则为 None
        monitor = None
        try:
            monitor = get_monitor()
        except RuntimeError:
            pass

        logger.info(f"[_monitor_stream_wrapper] START wrapper for {func.__name__}, monitor={monitor}")

        # 尝试从 kwargs 或 config 中提取 user_info
        # 约定：调用方（如 Job Worker）应将 user_info 放入 kwargs["user_info"] 或 kwargs["config"]["user_info"]
        user_info_obj: Optional[UserInfo] = None
        try:
            # 1. 优先使用 kwargs 中的
            raw_user = kwargs.get("user_info")
            if not raw_user:
                config = kwargs.get("config")
                if config and isinstance(config, dict):
                    raw_user = config.get("user_info")
            
            if raw_user:
                if isinstance(raw_user, UserInfo):
                    user_info_obj = raw_user
                elif isinstance(raw_user, dict):
                    user_info_obj = UserInfo.model_validate(raw_user)
            
            # 2. 如果没有，使用绑定的
            if not user_info_obj and bound_user_info:
                user_info_obj = bound_user_info
        except Exception:
            pass

        async for event in func(*args, **kwargs):
            # 支持 trace_id 强行覆盖 (Job Worker 场景)
            if override_trace_id:
                object.__setattr__(event, "trace_id", override_trace_id)

            if monitor:
                try:
                    # 注入 user_info (如果提供了 user_info_obj，则强制覆盖，保证 Worker 传入的认证信息优先)
                    if user_info_obj and str(event.type).startswith("run.lifecycle"):
                        # v2 字段名为 user_metadata；历史字段为 user_info。
                        if hasattr(event, "user_metadata"):
                            setattr(event, "user_metadata", user_info_obj)
                        elif hasattr(event, "user_info"):
                            setattr(event, "user_info", user_info_obj)
                    
                    logger.info(f"[_monitor_stream_wrapper] Writing event to monitor: {event.type}")
                    monitor.write(event)
                except Exception as e:
                    logger.warning(f"RuntimeMonitor write failed: {e}")
            yield event
    return wrapper
