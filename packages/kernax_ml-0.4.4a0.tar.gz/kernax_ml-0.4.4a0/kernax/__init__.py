"""
kernax-ml: A JAX-based kernel library for Gaussian Processes.

kernax-ml provides a collection of kernel functions (covariance functions) for
Gaussian Process models, with support for automatic differentiation, JIT
compilation, and composable kernel operations.
"""

__version__ = "0.4.4-alpha"
__author__ = "S. Lejoly"
__email__ = "simon.lejoly@unamur.be"
__license__ = "MIT"

# Import transformation utilities
from . import transforms
from .AbstractKernel import AbstractKernel, StaticAbstractKernel

# Import configuration system
from .config import config

# Import dot-product kernels
from .dotproduct import (
	LinearKernel,
	PolynomialKernel,
	SigmoidKernel,
	StaticLinearKernel,
	StaticPolynomialKernel,
	StaticSigmoidKernel,
)

# Import operator kernels
from .operators import (
	OperatorKernel,
	ProductKernel,
	SumKernel,
)

# Import other kernels
from .other import (
	ConstantKernel,
	StaticConstantKernel,
	VarianceKernel,
	WhiteNoiseKernel,
)

# Import stationary kernels
from .stationary import (
	Matern12Kernel,
	Matern32Kernel,
	Matern52Kernel,
	PeriodicKernel,
	RationalQuadraticKernel,
	RBFKernel,
	SEKernel,
	FeatureKernel,
	StaticMatern12Kernel,
	StaticMatern32Kernel,
	StaticMatern52Kernel,
	StaticPeriodicKernel,
	StaticRationalQuadraticKernel,
	StaticSEKernel,
	StaticFeatureKernel,
)

# Import wrapper kernels
from .wrappers import (
	ActiveDimsKernel,
	ARDKernel,
	BatchKernel,
	BlockDiagKernel,
	BlockKernel,
	ExpKernel,
	LogKernel,
	NegKernel,
	WrapperKernel,
)

__all__ = [
	# Package metadata
	"__version__",
	"__author__",
	"__email__",
	"__license__",
	# Configuration
	"config",
	# Transformations
	"transforms",
	# Base classes
	"StaticAbstractKernel",
	"AbstractKernel",
	# Base kernels
	"StaticSEKernel",
	"SEKernel",
	"RBFKernel",
	"StaticConstantKernel",
	"ConstantKernel",
	"StaticLinearKernel",
	"LinearKernel",
	"StaticPeriodicKernel",
	"PeriodicKernel",
	"StaticRationalQuadraticKernel",
	"RationalQuadraticKernel",
	"StaticPolynomialKernel",
	"PolynomialKernel",
	"StaticSigmoidKernel",
	"SigmoidKernel",
	"VarianceKernel",
	"WhiteNoiseKernel",
	"StaticFeatureKernel",
	"FeatureKernel",
	# Matern family
	"StaticMatern12Kernel",
	"Matern12Kernel",
	"StaticMatern32Kernel",
	"Matern32Kernel",
	"StaticMatern52Kernel",
	"Matern52Kernel",
	# Composite kernels
	"OperatorKernel",
	"SumKernel",
	"ProductKernel",
	# Wrapper kernels
	"WrapperKernel",
	"NegKernel",
	"ExpKernel",
	"LogKernel",
	"BatchKernel",
	"ActiveDimsKernel",
	"ARDKernel",
	"BlockKernel",
	"BlockDiagKernel",
]
