# Unit tests for visualization modules
