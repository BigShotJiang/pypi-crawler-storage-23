"""Unit tests for information theory components."""
