"""Unit tests for DRIADA components."""
