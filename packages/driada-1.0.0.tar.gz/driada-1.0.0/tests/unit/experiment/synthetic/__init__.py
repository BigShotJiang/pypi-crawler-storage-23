# Tests for synthetic manifold generation
