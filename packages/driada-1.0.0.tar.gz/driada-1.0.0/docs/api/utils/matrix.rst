Matrix Utilities
================

.. automodule:: driada.utils.matrix
   :members:
   :undoc-members:
   :show-inheritance:

Matrix operations and utilities for numerical computations.