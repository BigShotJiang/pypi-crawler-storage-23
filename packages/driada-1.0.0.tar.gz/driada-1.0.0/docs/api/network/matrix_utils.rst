Matrix Utilities
================

.. automodule:: driada.network.matrix_utils
   :members:
   :undoc-members:
   :show-inheritance:

This module provides utilities for working with adjacency matrices and other matrix operations in network analysis.