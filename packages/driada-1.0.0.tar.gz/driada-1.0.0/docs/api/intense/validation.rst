Input Validation
================

.. automodule:: driada.intense.validation

Functions for validating INTENSE input parameters.

Functions
---------

.. autofunction:: validate_time_series_bunches
.. autofunction:: validate_metric
.. autofunction:: validate_common_parameters
