FFT Dispatch and Caching
=========================

.. automodule:: driada.intense.fft

FFT type classification, data extraction, and pre-computed MI caching
for INTENSE analysis.

Functions
---------

.. autofunction:: get_fft_type
