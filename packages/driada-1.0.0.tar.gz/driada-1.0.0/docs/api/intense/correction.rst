Multiple Comparison Correction
==============================

.. automodule:: driada.intense.correction

P-value threshold calculation for multiple hypothesis testing.

Functions
---------

.. autofunction:: get_multicomp_correction_thr
