## Summary

<!-- What does this PR do? 1-3 sentences. -->

## Changes

<!-- Bulleted list of key changes. -->

-

## Testing

<!-- How was this tested? -->

- [ ] Existing tests pass (`pytest tests/ -x -q`)
- [ ] New tests added (if applicable)

## Checklist

- [ ] No breaking API changes (or documented in CHANGELOG)
- [ ] Docstrings updated for modified public functions
