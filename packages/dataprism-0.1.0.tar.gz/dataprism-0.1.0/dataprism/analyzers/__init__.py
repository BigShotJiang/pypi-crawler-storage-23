"""Analyzers for different data types."""

from dataprism.analyzers.basic import BasicStatsAnalyzer

__all__ = ["BasicStatsAnalyzer"]
