"""Output formatting utilities."""

from dataprism.output.formatter import JSONFormatter

__all__ = ["JSONFormatter"]
