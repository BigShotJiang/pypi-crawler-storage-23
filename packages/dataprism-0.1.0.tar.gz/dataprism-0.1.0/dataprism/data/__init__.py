"""Data I/O utilities for DataPrism."""

from dataprism.data.loader import DataLoader

__all__ = ["DataLoader"]
