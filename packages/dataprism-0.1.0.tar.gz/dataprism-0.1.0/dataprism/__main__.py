"""Allow running dataprism as a module: python -m dataprism."""

from dataprism.cli import main

main()
