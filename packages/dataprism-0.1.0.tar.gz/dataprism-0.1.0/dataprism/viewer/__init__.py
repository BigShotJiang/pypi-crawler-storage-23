"""DataPrism results viewer — serves an interactive browser dashboard."""

from dataprism.viewer.server import serve_results

__all__ = ["serve_results"]
