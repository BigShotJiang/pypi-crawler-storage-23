"""Infrastructure utilities for DataPrism."""

from dataprism.utils.logger import get_logger

__all__ = ["get_logger"]
