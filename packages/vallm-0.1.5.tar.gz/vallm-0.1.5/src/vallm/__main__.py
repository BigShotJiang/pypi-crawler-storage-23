"""Allow running vallm as: python -m vallm"""

from vallm.cli import app

app()
