## [0.1.5] - 2026-03-01

### Summary

feat(examples): CLI interface improvements

### Core

- update src/vallm/cli.py
- update src/vallm/core/gitignore.py
- update src/vallm/core/languages.py

### Docs

- docs: update README
- docs: update README
- docs: update README
- docs: update README
- docs: update README

### Test

- update tests/test_gitignore.py
- update tests/test_languages.py

### Other

- update examples/08_code2llm_integration/main.py
- update examples/09_code2logic_integration/main.py
- scripts: update run.sh


# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Refactor 5 critical-CC functions (target max-CC ≤7)
- Wire pluggy plugin manager for entry_point-based validator discovery
- Add LogicalErrorValidator (pyflakes), LintValidator (ruff), TypeCheckValidator (mypy)
- Add RegressionValidator (Tier 4) with pytest-json-report
- Integrate apted/zss for AST edit distance scoring
- Add CodeBERTScore embedding similarity to SemanticValidator
- NetworkX graph analysis (cycle detection, centrality)
- TOML config loading, `[tool.vallm]` support
- Pre-commit hook integration
- GitHub Actions CI/CD pipeline
- CONTRIBUTING.md

### Added (Multi-Language Support)
- **Language enum** — 30+ programming languages with metadata (compiled/scripting/web)
- **Auto-detection** — detect language from file path, extension, or name
- **`vallm.core.languages`** — centralized language definitions and utilities
- **CLI auto-detection** — `vallm validate --file script.py` auto-detects Python
- **`vallm batch`** command — validate multiple files with mixed languages
- **Lizard integration** — complexity analysis for 16+ languages (Go, Rust, Java, C/C++, etc.)
- **Tree-sitter for all** — syntax validation for 165+ languages
- **Example 07** — comprehensive multi-language demo with 8 languages

## [0.1.3] - 2026-03-01

### Added
- **Full package implementation** — 4-tier validation pipeline
- **SyntaxValidator** (Tier 1) — ast.parse + tree-sitter for 165+ languages
- **ImportValidator** (Tier 1) — module resolution with stdlib awareness
- **ComplexityValidator** (Tier 2) — radon (Python CC, MI) + lizard (16 languages)
- **SecurityValidator** (Tier 2) — regex patterns + AST-based eval/exec detection + optional bandit
- **SemanticValidator** (Tier 3) — LLM-as-judge via Ollama, litellm, or direct HTTP
- **Scoring engine** — weighted scores, confidence, hard gates, PASS/REVIEW/FAIL verdict
- **CLI** — `vallm validate`, `vallm check`, `vallm info` with rich/json/text output
- **Config** — pydantic-settings with `VALLM_*` env vars
- **Pluggy hookspecs** — extension points for custom validators
- **Sandbox** — subprocess and Docker backends for safe code execution
- **Code graph analysis** — import/call graph building and structural diffing
- **AST comparison** — tree-sitter node counting, Python AST normalization and similarity
- **6 examples** — basic validation, AST comparison, security, graph analysis, LLM review, multi-language
- **45 unit tests** — all passing
- **Published to PyPI** as `vallm` v0.1.3

### Tested
- Validated with local Ollama + Qwen 2.5 Coder 7B
- LLM correctly identified off-by-one bugs in binary search
- Multi-language validation (Python, JavaScript, C) working

## [0.1.1] - 2026-03-01

### Added
- Initial project scaffolding — pyproject.toml, src layout, hookspecs, config
- Core data models: Proposal, ValidationResult, PipelineResult
- AST comparison utilities (tree-sitter + Python ast)
- Graph builder and diff modules
- Base validator interface

---

Last updated: 2026-03-01