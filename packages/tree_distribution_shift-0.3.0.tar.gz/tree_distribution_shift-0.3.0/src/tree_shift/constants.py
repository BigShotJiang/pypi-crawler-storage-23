HF_REPO_ID = "aadityabuilds/tree-distribution-shift"

DEFAULT_SPLITS = ["train", "id_test", "ood_test"]

METADATA_FIELDS = ["country", "state", "zone", "region", "biome"]

_BASE_CONFIGS = [
    "intl_train_IN__ood_US",
    "intl_train_US__ood_IN",
    "biome_Rajasthan_train_WET__ood_DRY",
    "biome_Rajasthan_train_DRY__ood_WET",
    "elev_Karnataka_train_HIGH__ood_LOW",
    "elev_Karnataka_train_LOW__ood_HIGH",
    "region_train_North__ood_South",
    "region_train_South__ood_North",
]

_FEW_SHOT_SUFFIXES = ["__fs1", "__fs10", "__fs100", "__fsall"]

AVAILABLE_CONFIGS = _BASE_CONFIGS + [
    base + suffix
    for base in _BASE_CONFIGS
    for suffix in _FEW_SHOT_SUFFIXES
]

SPLIT_DESCRIPTIONS = {
    "train": "90% of the in-distribution pool (training)",
    "id_test": "10% held-out from the in-distribution pool (ID test)",
    "ood_test": "Full out-of-distribution pool (OOD test)",
}
