from __future__ import annotations

from typing import Any, Dict, List, Tuple

import torch
from torch.utils.data import DataLoader


def _detection_collate_fn(
    batch: List[Tuple[Any, Dict[str, Any], torch.Tensor]],
) -> Tuple[torch.Tensor, List[Dict[str, Any]], torch.Tensor]:
    """Collate function for object-detection batches.

    * Images are stacked into a single ``[B, C, H, W]`` tensor
      (all tiles are the same size so this is safe).
    * Targets stay as a list-of-dicts because each image can have a
      different number of boxes.
    * Metadata tensors are stacked into ``[B, M]``.
    """
    images, targets, metadata = zip(*batch)
    images = torch.stack(list(images), dim=0)
    metadata = torch.stack(list(metadata), dim=0)
    return images, list(targets), metadata


def get_train_loader(
    loader_type: str,
    dataset,
    batch_size: int = 16,
    num_workers: int = 4,
    pin_memory: bool = torch.cuda.is_available(),
    **kwargs,
) -> DataLoader:
    """Return a training :class:`~torch.utils.data.DataLoader`.

    Parameters
    ----------
    loader_type : str
        ``"standard"`` — shuffles the dataset each epoch.
    dataset : TreeShiftSubset
        A subset returned by :meth:`TreeShiftDataset.get_subset`.
    batch_size : int
        Mini-batch size.
    num_workers : int
        Number of data-loading worker processes.
    pin_memory : bool
        Pin memory for faster GPU transfer.
    **kwargs
        Forwarded to :class:`~torch.utils.data.DataLoader`.
    """
    if loader_type != "standard":
        raise ValueError(
            f"Unsupported loader_type '{loader_type}'. Currently only 'standard' is supported."
        )

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=_detection_collate_fn,
        **kwargs,
    )


def get_eval_loader(
    loader_type: str,
    dataset,
    batch_size: int = 16,
    num_workers: int = 4,
    pin_memory: bool = torch.cuda.is_available(),
    **kwargs,
) -> DataLoader:
    """Return an evaluation :class:`~torch.utils.data.DataLoader`.

    Parameters
    ----------
    loader_type : str
        ``"standard"`` — iterates without shuffling.
    dataset : TreeShiftSubset
        A subset returned by :meth:`TreeShiftDataset.get_subset`.
    batch_size : int
        Mini-batch size.
    num_workers : int
        Number of data-loading worker processes.
    pin_memory : bool
        Pin memory for faster GPU transfer.
    **kwargs
        Forwarded to :class:`~torch.utils.data.DataLoader`.
    """
    if loader_type != "standard":
        raise ValueError(
            f"Unsupported loader_type '{loader_type}'. Currently only 'standard' is supported."
        )

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=_detection_collate_fn,
        **kwargs,
    )
