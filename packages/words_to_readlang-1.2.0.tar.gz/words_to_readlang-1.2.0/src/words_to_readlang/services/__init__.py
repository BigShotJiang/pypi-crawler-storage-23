"""Services for words-to-readlang."""

from .fetcher import ExampleFetcher

__all__ = ["ExampleFetcher"]
