"""Version information for words-to-readlang."""

__version__ = "1.0.0"
