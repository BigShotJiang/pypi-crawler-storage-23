"""Utility functions for words-to-readlang."""

from .encoding import detect_encoding
from .normalization import normalize_translation

__all__ = ["detect_encoding", "normalize_translation"]
