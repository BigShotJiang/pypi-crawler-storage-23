> **Navigation**: [Home](../index.md) > [Architecture](README.md) > Node Registration Orchestrator Protocols

# Node Registration Orchestrator Protocol Architecture

## Overview

The Node Registration Orchestrator uses a **domain-grouped protocol pattern** where multiple cohesive protocols are defined in a single `protocols.py` file. This is an intentional architectural pattern documented in CLAUDE.md, not a code smell.

**Location**: `src/omnibase_infra/nodes/node_registration_orchestrator/protocols.py`

**Protocols Defined**:
- `ProtocolReducer`: Pure function that computes intents from events
- `ProtocolEffect`: Side-effectful executor that performs infrastructure operations

## Architectural Pattern: Reducer-Effect Workflow

The registration orchestrator implements a **reducer-effect separation pattern**, a functional architecture that cleanly separates pure computation from side effects:

```
                 ┌─────────────────────────────────────────────────┐
                 │         Node Registration Orchestrator          │
                 │                                                 │
  Event ────────►│  ┌──────────┐   intents   ┌──────────┐        │
                 │  │ Reducer  │────────────►│  Effect  │────────►│── Side Effects
                 │  │  (Pure)  │             │  (I/O)   │        │   (Consul, DB)
                 │  └──────────┘             └──────────┘        │
                 │       │                                        │
                 │       └─── state ──►                          │
                 └─────────────────────────────────────────────────┘
```

### ProtocolReducer

**Responsibility**: Deterministic computation of intents from events

**Contract**:
- MUST be deterministic (same inputs produce same outputs)
- MUST NOT perform I/O operations
- MUST return valid intents that the effect node can execute
- MUST sanitize any data included in error messages
- MAY filter duplicate or invalid events

**Method Signature**:
```python
async def reduce(
    self,
    state: ModelReducerState,
    event: ModelNodeIntrospectionEvent,
) -> ModelReducerExecutionResult:
    ...
```

**Note**: The return type was changed from `tuple[ModelReducerState, list[ModelRegistrationIntent]]`
to `ModelReducerExecutionResult` as part of OMN-1007 tuple-to-model conversion. The new model
provides factory methods (`no_change()`, `with_intents()`, `empty()`) for common patterns.

### ProtocolEffect

**Responsibility**: Execute side-effectful infrastructure operations

**Contract**:
- MUST execute exactly the operation specified by the intent
- MUST propagate correlation_id for distributed tracing
- MUST return a result even on failure (with success=False)
- MUST sanitize error messages before storing in result
- MAY implement retry logic internally

**Method Signature**:
```python
async def execute_intent(
    self,
    intent: ModelRegistrationIntent,
    correlation_id: UUID,
) -> ModelIntentExecutionResult:
    ...
```

## Why Domain-Grouped Protocols?

Per CLAUDE.md "Protocol File Naming" section:

> "Domain-grouped protocols: Use `protocols.py` when multiple cohesive protocols belong to a specific domain or node module"

Domain grouping is preferred when:
1. **Protocols are tightly coupled** - `ProtocolReducer` produces intents that `ProtocolEffect` consumes
2. **Protocols define the complete interface** - Together they define the full registration workflow contract
3. **Protocols share common type dependencies** - Both use `ModelRegistrationIntent`, `ModelReducerState`, and related models

Separating these into individual files would:
- Create unnecessary file fragmentation
- Obscure the relationship between reducer and effect
- Add import complexity without benefit

## Thread Safety Requirements

Both protocols require thread-safe implementations for concurrent async operations.

### ProtocolReducer Thread Safety

```python
# Thread Safety Guidelines:
# - Same reducer instance may process multiple events concurrently
# - Treat ModelReducerState as immutable (return new instances)
# - Avoid instance-level caches that could cause race conditions
```

### ProtocolEffect Thread Safety

```python
# Thread Safety Guidelines:
# - Multiple async tasks may invoke execute_intent() simultaneously
# - Use asyncio.Lock for any shared mutable state
# - Ensure underlying clients (Consul, PostgreSQL) are async-safe
```

## Error Sanitization Guidelines

All implementations MUST follow ONEX error sanitization guidelines from CLAUDE.md.

### NEVER Include in Error Messages

- Passwords, API keys, tokens, secrets
- Full connection strings with credentials
- PII (names, emails, SSNs, phone numbers)
- Internal IP addresses (in production)
- Private keys or certificates
- Raw event payload content (may contain secrets)

### SAFE to Include in Error Messages

- Service names (e.g., "consul", "postgres")
- Operation names (e.g., "register", "upsert")
- Correlation IDs (always include for tracing)
- Error codes (e.g., EnumCoreErrorCode values)
- Sanitized hostnames (e.g., "db.example.com")
- Port numbers, retry counts, timeout values
- Field names that are invalid or missing
- node_id (UUID, not PII)

## Validation Exemption

The `protocols.py` file triggers a validation warning for having multiple protocols in one file. This is an intentional pattern with a documented exemption.

**Exemption Location**: `src/omnibase_infra/validation/validation_exemptions.yaml`

**Exemption Reason**:
- Domain-grouped protocols for registration orchestrator workflow
- Protocols define the complete interface for the reducer-effect pattern
- Per CLAUDE.md "Protocol File Naming" convention

**Ticket**: OMN-888

## Review Criteria

This exemption should be reviewed if:

1. **Protocol count increases significantly** - If more than 4-5 protocols are added, consider whether the file should be split
2. **Protocols become decoupled** - If reducer and effect evolve to have independent lifecycles
3. **New patterns emerge** - If the codebase develops a different convention for workflow protocols

## Related Documentation

- **Node Architecture**: `docs/architecture/REGISTRATION_ORCHESTRATOR_ARCHITECTURE.md` - Complete architectural design
- **Implementation**: `src/omnibase_infra/nodes/node_registration_orchestrator/protocols.py`
- **Models**: `src/omnibase_infra/nodes/node_registration_orchestrator/models/`
- **Orchestrator Node**: `src/omnibase_infra/nodes/node_registration_orchestrator/node.py`
- **Node README**: `src/omnibase_infra/nodes/node_registration_orchestrator/README.md` - Usage and diagrams
- **CLAUDE.md**: "Protocol File Naming" section
- **Ticket**: OMN-888 (Node Registration Orchestrator Workflow)

## Implementation Status

| Component | Status | Location | Ticket |
|-----------|--------|----------|--------|
| Protocols | **Complete** | `protocols.py` | OMN-888 |
| Models | **Complete** | `models/` | OMN-888 |
| Orchestrator Node | **Complete** | `node.py` | OMN-888 |
| Reducer Implementation | **Pending** | N/A | OMN-889 |
| Effect Implementation | **Complete** | `nodes/effects/registry_effect.py` | OMN-890 |
| Intent Models (Core) | **Pending** | N/A | OMN-912 |
| Projection Reader | **Pending** | N/A | OMN-930 |
| Time Injection Wiring | **Pending** | N/A | OMN-973 |

### Effect Node Status (OMN-890)

The `NodeRegistryEffect` implementation is **complete** at `src/omnibase_infra/nodes/effects/registry_effect.py`.

**Architecture Note**: The effect node follows a domain-organized pattern where multiple effect nodes
are grouped under the `effects/` directory. The `node_registry_effect/` module serves as an alias
that re-exports from the canonical implementation location.

**Import Paths** (both work identically):
```python
from omnibase_infra.nodes.node_registry_effect import NodeRegistryEffect
from omnibase_infra.nodes.effects import NodeRegistryEffect
```

**Implementation Features**:
- Dual-backend registration (Consul + PostgreSQL)
- Partial failure handling with targeted retries
- Idempotency store for retry safety (bounded LRU cache, configurable TTL)
- Error sanitization for security (no secrets in error messages)
- Protocol-based dependency injection (ProtocolConsulClient, ProtocolPostgresAdapter)

**Contract**: `src/omnibase_infra/nodes/effects/contract.yaml`
