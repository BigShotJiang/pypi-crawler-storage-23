-- =============================================================================
-- MIGRATION: Add Capability Fields for Fast Discovery Queries
-- =============================================================================
-- Ticket: OMN-1134 (Registry Projection Extensions for Capabilities)
-- Version: 1.0.0
--
-- This migration adds denormalized capability fields to the registration
-- projections table to enable fast capability-based queries with GIN indexes.
--
-- NEW COLUMNS:
--   - contract_type: Node contract type (effect, compute, reducer, orchestrator, unknown)
--   - intent_types: Array of intent types this node handles
--   - protocols: Array of protocols this node implements
--   - capability_tags: Array of capability tags for discovery
--   - contract_version: Contract version string
--
-- NEW INDEXES:
--   - idx_registration_capability_tags: GIN index for capability_tags array
--   - idx_registration_intent_types: GIN index for intent_types array
--   - idx_registration_protocols: GIN index for protocols array
--   - idx_registration_contract_type_state: B-tree for contract_type + state
--
-- DESIGN NOTES:
--   - Fields are denormalized from the capabilities JSONB column for fast queries
--   - GIN indexes enable efficient @> (contains) array queries
--   - Existing registrations will have NULL/empty values until backfill
--
-- QUERY PATTERNS:
--   -- Find all effect nodes with postgres storage capability
--   SELECT * FROM registration_projections
--   WHERE contract_type = 'effect'
--     AND capability_tags @> ARRAY['postgres.storage'];
--
--   -- Find all nodes that handle postgres.upsert intent
--   SELECT * FROM registration_projections
--   WHERE intent_types @> ARRAY['postgres.upsert'];
--
-- PRODUCTION DATABASE SAFETY:
--   1. BACKUP your database before running this migration
--   2. TEST this migration on a staging environment first
--   3. MONITOR the migration - adding columns and indexes may take time on large tables
--
-- CONCURRENT INDEX CREATION (for large production tables):
-- -------------------------------------------------------------------------------------
-- This migration uses standard CREATE INDEX which briefly locks the table.
-- For production databases with >100K rows or zero-downtime requirements,
-- use the companion script: 004_capability_fields_concurrent.sql
--
-- WHEN TO USE STANDARD INDEXES (this script):
--   - Development/staging environments
--   - Tables with < 100,000 rows
--   - CI/CD pipelines requiring transaction blocks
--   - Brief locks (seconds) are acceptable
--
-- WHEN TO USE CONCURRENT INDEXES (004_capability_fields_concurrent.sql):
--   - Production with live traffic
--   - Tables with > 100,000 rows (strongly recommended for > 1M rows)
--   - Zero-downtime deployments required
--
-- PRODUCTION DEPLOYMENT STEPS (using concurrent indexes):
--   1. Run this script (003_capability_fields.sql) for column creation only,
--      commenting out the CREATE INDEX statements
--   2. Run 004_capability_fields_concurrent.sql outside any transaction block
--   3. Monitor progress: SELECT * FROM pg_stat_progress_create_index;
--
-- IMPORTANT: CONCURRENTLY indexes CANNOT run inside a transaction block.
-- See 004_capability_fields_concurrent.sql for full production deployment guide.
-- -------------------------------------------------------------------------------------
--
-- Rollback: See rollback/rollback_003_capability_fields.sql
--
-- =============================================================================

-- =============================================================================
-- ADD CAPABILITY COLUMNS
-- =============================================================================
-- Add new columns to registration_projections table
--
-- contract_type: Node archetype (effect, compute, reducer, orchestrator, unknown)
--   - Valid values for NEW registrations: effect, compute, reducer, orchestrator
--   - 'unknown': Backfill idempotency marker ONLY - indicates the backfill script
--     processed this record but could not determine the contract type from the
--     capabilities JSONB data. This is NOT an error state - it marks the record
--     as processed while preserving that the type was undeterminable.
--   - NULL: Record has not been processed/backfilled yet
--   - See scripts/backfill_capabilities.py for the backfill logic
--
-- Array columns use empty array defaults so queries don't need NULL handling.
-- These will be populated by:
--   1. ProjectorRegistration.persist_state_transition() for new registrations
--   2. scripts/backfill_capabilities.py for existing records
--
ALTER TABLE registration_projections
    ADD COLUMN IF NOT EXISTS contract_type TEXT,
    ADD COLUMN IF NOT EXISTS intent_types TEXT[] DEFAULT ARRAY[]::TEXT[],
    ADD COLUMN IF NOT EXISTS protocols TEXT[] DEFAULT ARRAY[]::TEXT[],
    ADD COLUMN IF NOT EXISTS capability_tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    ADD COLUMN IF NOT EXISTS contract_version TEXT;

-- =============================================================================
-- GIN INDEXES FOR CAPABILITY ARRAY QUERIES
-- =============================================================================
-- GIN (Generalized Inverted Index) indexes are optimized for array containment
-- queries. Unlike B-tree indexes which work on single scalar values, GIN indexes
-- the individual elements of arrays, enabling efficient @> (contains) queries.
--
-- WHY GIN FOR ARRAYS:
--   - B-tree indexes cannot efficiently search within arrays
--   - GIN indexes each array element separately, like a search engine
--   - Enables queries like: WHERE capability_tags @> ARRAY['postgres.storage']
--     which finds rows where capability_tags contains 'postgres.storage'
--
-- GIN INDEX TRADEOFFS:
--   - Slower INSERT/UPDATE than B-tree (must index each array element)
--   - Faster array containment queries than sequential scan
--   - Index size scales with total array elements, not just row count
--
-- For tables with >100K rows or high write traffic, consider using
-- 004_capability_fields_concurrent.sql which creates indexes CONCURRENTLY
-- to avoid blocking table writes during creation.
-- =============================================================================

-- GIN index for capability_tags array queries
-- Query pattern: SELECT * FROM registration_projections
--                WHERE capability_tags @> ARRAY['postgres.storage']
-- Use case: Find nodes with specific capabilities (storage, messaging, etc.)
CREATE INDEX IF NOT EXISTS idx_registration_capability_tags
    ON registration_projections USING GIN (capability_tags);

-- GIN index for intent_types array queries
-- Query pattern: SELECT * FROM registration_projections
--                WHERE intent_types @> ARRAY['postgres.upsert']
-- Use case: Find nodes that can handle specific intent types for routing
CREATE INDEX IF NOT EXISTS idx_registration_intent_types
    ON registration_projections USING GIN (intent_types);

-- GIN index for protocols array queries
-- Query pattern: SELECT * FROM registration_projections
--                WHERE protocols @> ARRAY['ProtocolDatabaseAdapter']
-- Use case: Protocol-based service discovery (find implementers)
CREATE INDEX IF NOT EXISTS idx_registration_protocols
    ON registration_projections USING GIN (protocols);

-- B-tree index for contract_type + state queries
-- Query pattern: SELECT * FROM registration_projections
--                WHERE contract_type = 'effect' AND current_state = 'active'
CREATE INDEX IF NOT EXISTS idx_registration_contract_type_state
    ON registration_projections (contract_type, current_state);

-- =============================================================================
-- CHECK CONSTRAINT FOR CONTRACT_TYPE
-- =============================================================================
-- Ensures contract_type values match valid ONEX node archetypes.
--
-- VALID VALUES:
--   - effect, compute, reducer, orchestrator: Standard ONEX node archetypes
--   - unknown: IDEMPOTENCY MARKER ONLY (see below)
--   - NULL: Record has not been processed/backfilled yet
--
-- =============================================================================
-- IMPORTANT: 'unknown' USAGE DISTINCTION
-- =============================================================================
-- The 'unknown' value is an IDEMPOTENCY MARKER for legacy records processed
-- by the backfill script (scripts/backfill_capabilities.py) where the
-- contract_type could NOT be determined from the capabilities JSONB.
--
-- It is NOT a valid contract type for new registrations:
--   - New registrations via ProjectorRegistration.persist_state_transition()
--     should ALWAYS use a valid type (effect/compute/reducer/orchestrator)
--   - 'unknown' should ONLY appear in legacy records migrated by backfill
--   - Application code should treat 'unknown' as "type not determined"
--
-- BACKFILL BEHAVIOR (scripts/backfill_capabilities.py):
-- -----------------------------------------------------
-- The backfill script uses contract_type IS NULL to identify unprocessed records:
--   - NULL    = Record has not been processed by backfill script
--   - value   = Record has been processed (including 'unknown' for legacy)
--
-- This allows the backfill script to be safely re-run (idempotent) without
-- reprocessing already-handled records. The script sets 'unknown' ONLY when
-- it cannot reliably determine the contract type from existing capabilities data.
--
-- RUNTIME BEHAVIOR (ProjectorRegistration):
-- -----------------------------------------
-- New registrations created AFTER this migration will have the correct
-- contract type set by the projector based on the node's contract.yaml.
-- These should NEVER use 'unknown' - they should always have a proper type.
--
-- QUERY PATTERNS:
-- ---------------
--   -- Exclude legacy records with unknown type:
--   WHERE contract_type IS NOT NULL AND contract_type != 'unknown'
--
--   -- Find all records needing type resolution:
--   WHERE contract_type = 'unknown'
--
-- This separation ensures:
--   1. Backfill idempotency: NULL -> 'unknown' marks record as processed
--   2. Clean data model: New records always have proper types
--   3. Query clarity: Easy to distinguish legacy vs properly-typed records
--
-- Note: Using DO block to handle constraint already existing (idempotent)

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'valid_contract_type'
        AND conrelid = 'registration_projections'::regclass
    ) THEN
        ALTER TABLE registration_projections
            ADD CONSTRAINT valid_contract_type CHECK (
                contract_type IS NULL
                OR contract_type IN ('effect', 'compute', 'reducer', 'orchestrator', 'unknown')
            );
    END IF;
END$$;

-- =============================================================================
-- VERIFICATION QUERY
-- =============================================================================
-- After running this migration, verify with:
--   SELECT column_name, data_type
--   FROM information_schema.columns
--   WHERE table_name = 'registration_projections'
--     AND column_name IN ('contract_type', 'intent_types', 'protocols', 'capability_tags', 'contract_version');
--
--   SELECT indexname FROM pg_indexes
--   WHERE tablename = 'registration_projections'
--     AND indexname LIKE 'idx_registration_%';
--
--   SELECT conname FROM pg_constraint
--   WHERE conrelid = 'registration_projections'::regclass
--     AND conname = 'valid_contract_type';
-- =============================================================================
