import json
from abc import ABC
from typing import Any, Dict, List, Optional, Type, TypeVar, Union

import requests
from loguru import logger
from pybreaker import CircuitBreaker, CircuitBreakerError
from pydantic import BaseModel, Field, ValidationError
from pyrate_limiter import Duration, Limiter, Rate
from tenacity import Retrying, retry_if_exception_type, stop_after_attempt, wait_exponential

T = TypeVar("T", bound=BaseModel)


class APIConfig(BaseModel):
    """
    Configuration model for API client requests and connection settings.

    This model serves as both:

    1. Base configuration for APIClient instances
    2. Per-request configuration when making individual API calls

    It handles network parameters (timeout, retries), API behavior settings
    (rate limiting, circuit breaking), and request-specific data (headers,
    params, etc.)

    Args:
        method (str): HTTP method to use (GET, POST, PUT, DELETE, etc.)
        url (str): Base URL for the API endpoint
        headers (Dict[str, str]): HTTP headers to include with every request
        params (Optional[Dict[str, Any]]): Query parameters to append to the URL
        data (Optional[Union[Dict[str, Any], str]]): Request body data (will be JSON-encoded unless already a string)
        timeout (int): Request timeout in seconds
        max_retries (int): Maximum number of retry attempts for failed requests
        retry_backoff_multiplier (int): Multiplier for exponential backoff between retries
        retry_wait_min (int): Minimum wait time in seconds between retries
        retry_wait_max (int): Maximum wait time in seconds between retries
        rate_limit_count (int): Maximum number of requests allowed in the rate limit period
        rate_limit_period (Duration): Time period for the rate limit in milliseconds
        circuit_breaker_fail_max (int): Number of consecutive failures before the circuit breaker opens
        circuit_breaker_reset_timeout (int): Time in seconds before an open circuit breaker transitions to half-open

    Example:
        ```python
        # Base configuration for client
        base_config = APIConfig(
            method="GET",
            url="https://api.example.com/base",
            rate_limit_count=100,
            timeout=45
        )

        # Per-request override
        override_params = {
            "url": "https://api.example.com/endpoint",
            "timeout": 60,
            "max_retries": 5
        }
        ```
    """
    method: str = Field(description="HTTP method to use (GET, POST, PUT, DELETE, etc.)")
    url: str = Field(description="Base URL for the API endpoint")
    headers: Dict[str, str] = Field(
        default={"Content-Type": "application/json"},
        description="HTTP headers to include with every request",
    )

    params: Optional[Dict[str, Any]] = Field(default={}, description="Query parameters to append to the URL")
    data: Optional[Union[Dict[str, Any], str]] = Field(
        default={},
        description="Request body data (will be JSON-encoded unless already a string)",
    )

    timeout: int = Field(default=30, description="Request timeout in seconds")
    max_retries: int = Field(default=3, description="Maximum number of retry attempts for failed requests")
    retry_backoff_multiplier: int = Field(default=1, description="Multiplier for exponential backoff between retries")
    retry_wait_min: int = Field(default=2, description="Minimum wait time in seconds between retries")
    retry_wait_max: int = Field(default=10, description="Maximum wait time in seconds between retries")

    rate_limit_count: int = Field(
        default=100,
        description="Maximum number of requests allowed in the rate limit period",
    )
    rate_limit_period: Duration = Field(
        default=Duration.MINUTE,
        description="Time period for the rate limit in milliseconds",
    )

    circuit_breaker_fail_max: int = Field(
        default=3,
        description="Number of consecutive failures before the circuit breaker opens",
    )
    circuit_breaker_reset_timeout: int = Field(
        default=60,
        description="Time in seconds before an open circuit breaker transitions to half-open",
    )


class APIClient(ABC):
    """
    Abstract base API client with common functionality for resilient API communication.

    Key resilience features:

    1. Rate limiting - Prevents overwhelming APIs with too many requests
    2. Circuit breaking - Detects consistently failing endpoints and fails fast
       to prevent cascading failures and unnecessary load
    3. Automatic retries - Handles transient network issues with configurable
       retry policies and exponential backoff

    These mechanisms work together to provide resilient communication:

    - Rate limiting ensures you stay within API quotas
    - Circuit breaking prevents sending requests to failing services
    - Retries handle temporary glitches without manual intervention

    Configuration for all these mechanisms is set during client initialization,
    while retry behavior and timeouts can be overridden per individual request.
    """

    def __init__(self, config: APIConfig):
        """
        Initialize the API client with configuration.

        Sets up:

        - HTTP session with base headers
        - Rate limiter based on configured limits
        - Circuit breaker based on configured thresholds

        Args:
            config: Configuration for this API client instance
        """
        self.base_config = config
        self.session = requests.Session()
        self.session.headers.update(self.base_config.headers)

        self.rate = Rate(self.base_config.rate_limit_count, self.base_config.rate_limit_period)
        self.limiter = Limiter(self.rate)
        self.breaker = CircuitBreaker(
            fail_max=self.base_config.circuit_breaker_fail_max,
            reset_timeout=self.base_config.circuit_breaker_reset_timeout,
        )

    @property
    def _safe_call(self):
        """
        Property that returns the _rate_limited_breaker_call method.
        This provides a clean interface for methods that need to make
        rate-limited and circuit-protected API calls.
        """
        return self._rate_limited_breaker_call

    def _rate_limited_breaker_call(self, current_config: APIConfig, model: Optional[Type[T]] = None):
        """
        Apply rate limiting and circuit breaking in a single call.

        This internal method called by request() implements the core request flow:
        1. Apply rate limiting with configurable delay tolerance (500ms)
        2. If rate limit is exceeded and not using delay, raise a ValueError
        3. Apply circuit breaking to prevent cascading failures:
           - Tracks consecutive failures to an endpoint
           - "Opens" the circuit (fails fast) after threshold of failures is reached
           - Prevents sending requests to consistently failing endpoints

        4. Execute the request with retry behavior (for transient failures)

        All exceptions are allowed to propagate up to the request() method.

        Args:
            current_config: Configuration for this specific request
            model: Optional Pydantic model for response validation

        Returns:
            The response from the API, optionally validated with the model

        Raises:
            ValueError: If rate limit is exceeded (try_acquire returns False)
            CircuitBreakerError: If circuit breaker is open due to consistent failures
        """
        # try_acquire returns False when rate limit is exceeded (non-blocking)
        # With blocking=True, it will wait, but we use blocking=False to fail fast
        if not self.limiter.try_acquire("api_requests", blocking=False):
            logger.error("Rate limit hit, request rejected")
            raise ValueError("Rate limit exceeded")

        return self.breaker(self._execute_request_with_retries)(current_config, model)

    def _execute_request_with_retries(
        self, current_config: APIConfig, model: Optional[Type[T]] = None
    ) -> Union[T, Dict[str, Any], List[Dict[str, Any]]]:
        """
        Execute the HTTP request with automatic retries for transient errors.

        This is an internal method called by _rate_limited_breaker_call() after
        rate limiting and circuit breaking have been applied.

        It handles:
            1. Setting up the retry logic with exponential backoff
                - First attempt plus configured retries
                - Exponential backoff with configured multiplier, min and max waits
                - Only retries on network/request exceptions, not validation or HTTP errors
            2. Making the actual HTTP request with configured parameters
            3. Processing the response (status checking, JSON parsing)
                - Raises HTTPError for 4xx and 5xx responses
                - Returns empty dict for empty responses
            4. Validating the response with the provided model (if any)
                - Supports both single objects and lists of objects

        All errors are converted to ValueError to provide a consistent error interface at the APIClient level.
        CircuitBreakerError and rate limit errors (ValueError) are handled at the request level.

        Args:
            current_config: The configuration for this specific request
            model: Optional Pydantic model to validate the response against

        Returns:
            Parsed and optionally validated response

        Raises:
            ValueError: For request failures or validation errors
        """
        retryer = Retrying(
            stop=stop_after_attempt(current_config.max_retries + 1),
            wait=wait_exponential(
                multiplier=current_config.retry_backoff_multiplier,
                min=current_config.retry_wait_min,
                max=current_config.retry_wait_max,
            ),
            retry=retry_if_exception_type(requests.exceptions.RequestException),
            reraise=True,
        )

        try:
            request_data = current_config.data
            if isinstance(request_data, dict) and request_data:
                request_data = json.dumps(request_data)

            response = retryer(
                self.session.request,
                method=current_config.method,
                url=current_config.url,
                params=current_config.params,
                data=request_data,
                headers=current_config.headers,
                timeout=current_config.timeout,
            )
            response.raise_for_status()

            if not response.content:
                return {}

            result = response.json()

            if model:
                if isinstance(result, list):
                    return [model.model_validate(item) for item in result]  # type: ignore
                return model.model_validate(result)
            return result

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed after retries: {current_config.method} {current_config.url} - {e}")
            raise ValueError(f"API request failed: {e}") from e
        except ValidationError as e:
            logger.error(f"Response validation failed: {current_config.method} {current_config.url} - {e}")
            raise ValueError(f"Response validation failed: {e}") from e

    def request(
        self,
        override_config_params: Optional[Dict[str, Any]] = None,
        model: Optional[Type[T]] = None,
    ) -> Union[T, Dict[str, Any], List[Dict[str, Any]]]:
        """
        Base request method with dynamic retries, rate limiting, and circuit breaking.
        This is the main entry point for making API requests.

        The method follows this execution flow:

        1. Create a configuration for this specific request by merging base config with any override parameters
        2. Apply rate limiting (may delay or reject requests if limits exceeded)
        3. Apply circuit breaking protection:

            - Prevents sending requests to endpoints that are consistently failing
            - Fails fast with CircuitBreakerError if the circuit is open
            - Protects both the client and server from excessive load

        4. Execute the request with automatic retries for transient errors
        5. Parse and optionally validate the response using the provided model

        All errors from various stages are caught and normalized to ValueErrors with appropriate context messages.

        Args:
            override_config_params (Optional[Dict[str, Any]]): Dictionary with parameters to override
                                    from the client's base configuration for this specific request.
                                    Example: {"timeout": 45, "max_retries": 5}
            model (Optional[Type[T]]): Pydantic model for response validation.

        Returns:
            Union[T, Dict[str, Any], List[Dict[str, Any]]]: Parsed response (dict, list, or Pydantic model).

        Raises:
            ValueError: For any error during the request process, including:

                - Configuration errors
                - Rate limiting errors
                - Circuit breaker open (endpoint consistently failing)
                - Network/HTTP errors after retries
                - Response validation errors

        Note on pagination:
            This method handles a single request. For paginated APIs,
            the implementing class should provide a pagination method that
            calls this method iteratively, managing pagination tokens/parameters.
        """
        current_config_data = self.base_config.model_dump()
        if override_config_params:
            current_config_data.update(override_config_params)

        try:
            current_config = APIConfig(**current_config_data)
        except ValidationError as e:
            logger.error(f"Invalid request configuration: {e}")
            raise ValueError(f"Invalid request configuration: {e}") from e

        logger.info(
            f"Making {current_config.method} request to {current_config.url} "
            f"with timeout {current_config.timeout}s, retries {current_config.max_retries}"
        )

        try:
            return self._rate_limited_breaker_call(current_config=current_config, model=model)
        except CircuitBreakerError as e:
            logger.error(f"Circuit breaker open for {current_config.url}: {e}")
            raise ValueError(f"Circuit breaker is open: {e}") from e
        except ValueError as e:
            # Pass through ValueError from rate limiting or other methods
            if "Rate limit" in str(e) or "rate limit" in str(e):
                logger.error(f"Rate limit exceeded for {current_config.url}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error during request to {current_config.url}: {e}")
