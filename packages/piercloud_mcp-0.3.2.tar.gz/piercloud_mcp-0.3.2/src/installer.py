"""Claude Desktop installer."""

import json
import os
import sys
import shutil
from pathlib import Path


def get_claude_config_path():
    """Get Claude Desktop config path based on OS."""
    if sys.platform == "darwin":
        return (
            Path.home()
            / "Library/Application Support/Claude/claude_desktop_config.json"
        )
    elif sys.platform == "win32":
        return Path(os.getenv("APPDATA")) / "Claude/claude_desktop_config.json"
    else:  # Linux
        return Path.home() / ".config/Claude/claude_desktop_config.json"


def install_claude():
    """Interactive installer for Claude Desktop."""
    print("🚀 Pier Cloud MCP - Claude Desktop Setup\n")

    # Get credentials
    client_id = input("Enter your PIERCLOUD_CLIENT_ID: ").strip()
    client_secret = input("Enter your PIERCLOUD_CLIENT_SECRET: ").strip()

    if not client_id or not client_secret:
        print("❌ Client ID and Secret are required!")
        sys.exit(1)

    # Find piercloud-mcp path
    mcp_path = shutil.which("piercloud-mcp")
    if not mcp_path:
        print("❌ piercloud-mcp not found in PATH!")
        sys.exit(1)

    # Get config path
    config_path = get_claude_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load or create config
    if config_path.exists():
        with open(config_path, "r") as f:
            config = json.load(f)
    else:
        config = {}

    # Ensure mcpServers exists
    if "mcpServers" not in config:
        config["mcpServers"] = {}

    # Add piercloud server
    config["mcpServers"]["piercloud"] = {
        "command": mcp_path,
        "env": {
            "PIERCLOUD_CLIENT_ID": client_id,
            "PIERCLOUD_CLIENT_SECRET": client_secret,
        },
    }

    # Save config
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n✅ Configuration saved to: {config_path}")
    print(f"✅ Command: {mcp_path}")
    print("\n🔄 Please restart Claude Desktop to apply changes.")
