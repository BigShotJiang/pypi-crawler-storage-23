"""Entry point."""

import asyncio
import sys
import uvicorn
from src.servers.mcp import MCPServer
from src.servers.http import create_http_server
from src.tools.rebilling import register_rebilling_tools
from src.tools.cca import register_cca_tools
from src.tools.rightsizing import register_rightsizing_tools
from src import __version__


mcp = MCPServer("piercloud-mcp-server", __version__)
register_rebilling_tools(mcp)
register_cca_tools(mcp)
register_rightsizing_tools(mcp)


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        print(
            """Pier Cloud MCP Server

Usage:
  piercloud-mcp                    Run in stdio mode (for Claude Desktop)
  piercloud-mcp --sse              Run HTTP/SSE server (production)
  piercloud-mcp --sse --port 8000  Run on custom port
  piercloud-mcp --install-claude   Configure Claude Desktop
  piercloud-mcp --help             Show this help

Environment variables:
  PIERCLOUD_CLIENT_ID        Your Pier Cloud client ID
  PIERCLOUD_CLIENT_SECRET    Your Pier Cloud client secret
"""
        )
        return

    if "--install-claude" in sys.argv:
        from src.installer import install_claude

        install_claude()
        return

    if "--sse" in sys.argv:
        port = 8000
        if "--port" in sys.argv:
            port = int(sys.argv[sys.argv.index("--port") + 1])
        app = create_http_server(mcp)
        uvicorn.run(app, host="0.0.0.0", port=port)
    else:
        asyncio.run(mcp.run())


if __name__ == "__main__":
    main()
