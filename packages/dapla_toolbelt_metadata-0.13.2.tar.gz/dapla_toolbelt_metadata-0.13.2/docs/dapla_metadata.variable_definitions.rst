dapla\_metadata.variable\_definitions package
=============================================


dapla\_metadata.variable\_definitions.exceptions module
-------------------------------------------------------

.. automodule:: dapla_metadata.variable_definitions.exceptions
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.variable\_definitions.vardef module
---------------------------------------------------

.. automodule:: dapla_metadata.variable_definitions.vardef
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.variable\_definitions.vardok\_id module
-------------------------------------------------------

.. automodule:: dapla_metadata.variable_definitions.vardok_id
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.variable\_definitions.vardok\_vardef\_id\_pair module
---------------------------------------------------------------------

.. automodule:: dapla_metadata.variable_definitions.vardok_vardef_id_pair
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.variable\_definitions.variable\_definition module
-----------------------------------------------------------------

.. automodule:: dapla_metadata.variable_definitions.variable_definition
   :members:
   :show-inheritance:
   :undoc-members:
