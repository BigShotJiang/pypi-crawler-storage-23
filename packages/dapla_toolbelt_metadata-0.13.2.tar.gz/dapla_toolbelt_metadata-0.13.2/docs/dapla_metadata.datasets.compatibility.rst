dapla\_metadata.datasets.compatibility package
==============================================


dapla\_metadata.datasets.compatibility.model\_backwards\_compatibility module
-----------------------------------------------------------------------------

.. automodule:: dapla_metadata.datasets.compatibility.model_backwards_compatibility
   :members:
   :show-inheritance:
   :undoc-members:
