"""
Empty setup.py for python-psutil
Target: HackerOne Bug Bounty - doordash
"""
from setuptools import setup

setup(
    name="python-psutil",
    version="0.0.0",
    description="Empty placeholder package - reserved for doordash",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
