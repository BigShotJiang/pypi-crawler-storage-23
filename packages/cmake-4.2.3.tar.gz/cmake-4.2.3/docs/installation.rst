============
Installation
============

Install package with pip
------------------------

To install with pip::

    $ pip install cmake

Install from source
-------------------

See :doc:`building`
