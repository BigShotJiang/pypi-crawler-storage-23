"""STOFS MCP Server — NOAA Storm Tide Operational Forecast System for AI Assistants."""
