"""STOFS MCP tool modules."""
