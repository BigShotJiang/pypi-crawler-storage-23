"""Worker functions for multiprocessing-based execution."""
