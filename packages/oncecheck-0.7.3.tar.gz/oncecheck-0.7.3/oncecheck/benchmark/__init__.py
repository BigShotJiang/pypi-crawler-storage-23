"""Benchmark utilities for evaluating scanner quality."""

