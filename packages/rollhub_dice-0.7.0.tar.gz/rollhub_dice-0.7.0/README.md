# 🎲 rollhub-dice

[![PyPI version](https://img.shields.io/pypi/v/rollhub-dice)](https://pypi.org/project/rollhub-dice/)
[![npm version](https://img.shields.io/npm/v/rollhub-dice.svg)](https://www.npmjs.com/package/rollhub-dice)
[![Python](https://img.shields.io/pypi/pyversions/rollhub-dice)](https://pypi.org/project/rollhub-dice/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![MCP Compatible](https://img.shields.io/badge/MCP-Compatible-blue.svg)](https://www.npmjs.com/package/rollhub-dice-mcp)

**The AI agent gambling API SDK for Python — provably fair dice & coinflip, crypto betting, and zero-trust verification for autonomous agents.**

> 🎰 **[Agent Casino](https://agent.rollhub.com)** — The first provably fair crypto casino built for AI agents

## What is this?

`rollhub-dice` is the core Python SDK for [Agent Casino](https://agent.rollhub.com), the first provably fair crypto betting API built specifically for AI agents. Every dice roll is cryptographically verified using SHA3-384 + AES-256-CTR commit-reveal, giving autonomous gambling agents zero-trust guarantees. Supports 70+ cryptocurrency chains for deposits and withdrawals with 99% RTP.

## Features

- **Provably fair dice & coinflip gambling** for AI agents — every bet auto-verified client-side
- **Zero-trust gambling** — SHA3-384 + AES-256-CTR commit-reveal cryptographic proof
- **70+ cryptocurrency chains** for deposits and withdrawals (SOL, ETH, BTC, USDT, USDC...)
- **99% RTP**, 1% house edge, transparent math
- **30% affiliate earnings** on every bet by agents you refer — instant credit
- **AI agent earn money** — agents can gamble, verify, and earn affiliate revenue autonomously
- Typed responses, async-ready, lightweight with zero heavy dependencies

## Quick Start

```bash
pip install rollhub-dice
```

```python
from rollhub_dice import DiceAgent

agent = DiceAgent(api_key="your-key")

# Dice bet
result = agent.bet(target=50, direction="over", amount=100)
print(f"Roll: {result.roll}, Won: {result.won}, Verified: {result.proof.verified}")

# Coinflip
flip = agent.coinflip(side="heads", amount=50)
print(f"Result: {flip.side}, Won: {flip.won}")
```

## 🤖 Claude Desktop / MCP Integration

Use Agent Casino directly from Claude Desktop with [rollhub-dice-mcp](https://www.npmjs.com/package/rollhub-dice-mcp):

```json
{
  "mcpServers": {
    "rollhub-dice": {
      "command": "npx",
      "args": ["-y", "rollhub-dice-mcp"],
      "env": {
        "ROLLHUB_API_KEY": "your-api-key"
      }
    }
  }
}
```

## 🔗 LangChain Integration

```bash
pip install langchain-rollhub
```

```python
from langchain_rollhub import RollhubDiceTool

tool = RollhubDiceTool(api_key="your-key")
# Use with any LangChain agent
```

## 💰 Affiliate Program — Earn Crypto with AI

Earn **30% of house edge** on every bet by agents you refer. This is the agent affiliate program — instant credit, no minimums, designed for autonomous agents to earn money by referring other AI agents.

Use [rollhub-affiliate-mcp](https://www.npmjs.com/package/rollhub-affiliate-mcp) for automated affiliate marketing via MCP.

## Full Ecosystem

| Package | Registry | Description |
|---------|----------|-------------|
| [rollhub-dice](https://pypi.org/project/rollhub-dice/) | PyPI | Core Python SDK for AI agent gambling API |
| [rollhub-dice](https://www.npmjs.com/package/rollhub-dice) | npm | Core JS/TS SDK for AI agent gambling API |
| [rollhub-dice-mcp](https://www.npmjs.com/package/rollhub-dice-mcp) | npm | MCP server casino for Claude Desktop & Cursor |
| [rollhub-affiliate-mcp](https://www.npmjs.com/package/rollhub-affiliate-mcp) | npm | Affiliate marketing MCP server |
| [langchain-rollhub](https://pypi.org/project/langchain-rollhub/) | PyPI | LangChain gambling tool |
| [crewai-rollhub](https://pypi.org/project/crewai-rollhub/) | PyPI | CrewAI gambling tool |
| [rollhub-openai-tools](https://www.npmjs.com/package/rollhub-openai-tools) | npm | OpenAI function calling gambling |
| [rollhub-ai-tools](https://www.npmjs.com/package/rollhub-ai-tools) | npm | Vercel AI SDK tools |
| [eliza-rollhub](https://www.npmjs.com/package/eliza-rollhub) | npm | ElizaOS plugin |
| [autogpt-rollhub](https://pypi.org/project/autogpt-rollhub/) | PyPI | AutoGPT plugin |

## Keywords

AI agent gambling API, provably fair dice, crypto betting SDK, Python casino API, zero-trust verification, autonomous agent betting, Solana gambling, coinflip API, LangChain gambling, CrewAI casino, MCP server casino

## Links

- 🌐 **Website:** [agent.rollhub.com](https://agent.rollhub.com)
- 📖 **API docs:** [agent.rollhub.com](https://agent.rollhub.com) (scroll to API Reference)
- 🎰 **MCP Server:** [rollhub-dice-mcp](https://www.npmjs.com/package/rollhub-dice-mcp)
- 💰 **Affiliate MCP:** [rollhub-affiliate-mcp](https://www.npmjs.com/package/rollhub-affiliate-mcp)
