"""Data models for the Rollhub Dice SDK."""

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Balance:
    """Account balance."""
    balance_usd: str
    balance_cents: int
    currency: str

    def __str__(self) -> str:
        return f"{self.balance_usd} {self.currency}"


@dataclass(frozen=True)
class Proof:
    """Provably fair proof for a bet."""
    server_secret: str
    client_secret: str
    nonce: int
    server_seed_hash: str


@dataclass(frozen=True)
class BetResult:
    """Result of a dice bet."""
    bet_id: int
    roll: float
    win: bool
    payout: int
    multiplier: float
    balance: int
    proof: Proof
    verification: Optional[dict] = None

    def __str__(self) -> str:
        outcome = "WIN" if self.win else "LOSS"
        verified = ""
        if self.verification:
            verified = " ✓" if self.verification.get("verified") else " ✗"
        return f"Bet #{self.bet_id}: rolled {self.roll:.4f} → {outcome} (payout: {self.payout}){verified}"


@dataclass(frozen=True)
class Bet:
    """A historical bet record."""
    bet_id: int
    roll: float
    win: bool
    payout: int
    multiplier: float
    target: float
    direction: str
    amount: int
    client_secret: str
    nonce: int
    created_at: Optional[str] = None


@dataclass(frozen=True)
class VerifyResult:
    """Result of bet verification."""
    bet_id: int
    verified: bool
    roll: Optional[float] = None
    server_secret: Optional[str] = None
    client_secret: Optional[str] = None
    nonce: Optional[int] = None
    server_seed_hash: Optional[str] = None

    def __str__(self) -> str:
        status = "✓ VERIFIED" if self.verified else "✗ FAILED"
        return f"Bet #{self.bet_id}: {status}"


@dataclass(frozen=True)
class CoinflipResult:
    """Result of a coinflip bet."""
    bet_id: int
    side: str
    result: str
    win: bool
    payout: int
    multiplier: float
    balance: int
    proof: Optional[Proof] = None
    verification: Optional[dict] = None

    def __str__(self) -> str:
        outcome = "WIN" if self.win else "LOSS"
        verified = ""
        if self.verification:
            verified = " ✓" if self.verification.get("verified") else " ✗"
        return f"Coinflip #{self.bet_id}: {self.side}→{self.result} → {outcome} (payout: {self.payout}){verified}"


@dataclass(frozen=True)
class RouletteResult:
    """Result of a roulette bet."""
    bet_id: int
    number: int
    color: str
    won: bool
    payout: int
    balance: int
    bet_type: str
    bet_value: object
    proof: Optional[Proof] = None
    verification: Optional[dict] = None

    def __str__(self) -> str:
        outcome = "WIN" if self.won else "LOSS"
        verified = ""
        if self.verification:
            verified = " ✓" if self.verification.get("verified") else " ✗"
        return f"Roulette #{self.bet_id}: {self.number} ({self.color}) → {outcome} (payout: {self.payout}){verified}"


@dataclass(frozen=True)
class Registration:
    """Registration result."""
    api_key: str
    server_seed_hash: str
