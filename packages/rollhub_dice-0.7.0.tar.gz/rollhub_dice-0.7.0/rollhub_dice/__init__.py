"""Rollhub Dice — Python SDK for the Rollhub Dice Agent API."""

from .client import DiceAgent
from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    InvalidBetError,
    RateLimitError,
    RollhubError,
    ServerError,
    VerificationError,
)
from .models import Balance, Bet, BetResult, CoinflipResult, Proof, Registration, RouletteResult, VerifyResult
from .verify import compute_roll, verify_bet, verify_server_seed

__version__ = "0.7.0"

__all__ = [
    "DiceAgent",
    "Balance",
    "Bet",
    "BetResult",
    "CoinflipResult",
    "RouletteResult",
    "Proof",
    "Registration",
    "VerifyResult",
    "RollhubError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "InvalidBetError",
    "RateLimitError",
    "ServerError",
    "VerificationError",
    "compute_roll",
    "verify_bet",
    "verify_server_seed",
    "__version__",
]
