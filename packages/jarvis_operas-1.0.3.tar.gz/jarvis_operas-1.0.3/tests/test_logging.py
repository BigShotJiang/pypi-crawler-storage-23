from __future__ import annotations

import pytest

import jarvis_operas.logging as jl
from jarvis_operas.logging import _stream_filter, get_log_mode, get_logger, set_log_mode


def test_log_mode_defaults_to_warning() -> None:
    set_log_mode("warning")
    assert get_log_mode() == "warning"


def test_set_log_mode_info_and_debug() -> None:
    set_log_mode("info")
    assert get_log_mode() == "info"

    set_log_mode("debug")
    assert get_log_mode() == "debug"

    # restore default for other tests
    set_log_mode("warning")


def test_invalid_log_mode_raises() -> None:
    with pytest.raises(ValueError):
        set_log_mode("verbose")


def test_get_logger_accepts_mode_override() -> None:
    previous_mode = get_log_mode()
    previous_initialized = jl._INITIALIZED
    logger = get_logger(mode="info", module="UnitTest")
    assert logger is not None
    # Library get_logger must never initialize a sink.
    assert get_log_mode() == previous_mode
    assert jl._INITIALIZED == previous_initialized


def test_stream_filter_isolated_to_operas_records() -> None:
    assert _stream_filter({"extra": {"_log_domain": "jarvis_operas"}}) is True
    assert _stream_filter({"extra": {"_log_domain": "jarvis_hep", "_jarvis_operas": True}}) is False
    assert _stream_filter({"extra": {"module": "Jarvis-Operas"}}) is True
    assert _stream_filter({"extra": {"_jarvis_operas": True}}) is True
    assert _stream_filter({"extra": {"module": "Jarvis-HEP", "to_console": True}}) is False
