ResolverContext
================

.. autoclass:: diwire.ResolverContext
   :members: resolve, aresolve, enter_scope, inject
   :member-order: bysource
