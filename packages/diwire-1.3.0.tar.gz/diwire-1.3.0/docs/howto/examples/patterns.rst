:orphan:

Patterns (deprecated)
=====================

Patterns now live under :doc:`../patterns/index`.
