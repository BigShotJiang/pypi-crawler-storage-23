# Feature: synth-agent-sdk, Property 1 & 5: Tool schema generation and validation
"""Property-based tests for tool schema generation and definition validation.

**Property 1: Tool schema generation round-trip**
**Validates: Requirements 2.1**

For any Python function with complete type annotations and a docstring,
applying the @tool decorator and extracting the generated JSON schema should
produce a schema whose parameter names, types, and descriptions match the
original function signature.

**Property 5: Tool definition validation at decoration time**
**Validates: Requirements 2.5**

For any Python function that is missing type annotations on any parameter or
is missing a docstring, applying the @tool decorator should immediately raise
a ToolDefinitionError without waiting for runtime invocation.
"""

from __future__ import annotations

import types
from typing import Optional

from hypothesis import given, settings, assume
from hypothesis import strategies as st

from synth.errors import ToolDefinitionError
from synth.tools.decorator import tool, _PYTHON_TO_JSON_SCHEMA

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# Valid Python identifiers that won't collide with builtins or keywords
_VALID_IDENTS = st.from_regex(r"[a-z][a-z0-9_]{0,15}", fullmatch=True).filter(
    lambda s: s not in {"self", "cls", "return", "lambda", "def", "class", "import",
                         "from", "if", "else", "elif", "for", "while", "try", "except",
                         "with", "as", "pass", "break", "continue", "raise", "yield",
                         "and", "or", "not", "in", "is", "None", "True", "False",
                         "global", "nonlocal", "del", "assert", "finally"}
)

# Supported types and their expected JSON schema type strings
SUPPORTED_TYPES = [str, int, float, bool, list, dict]
EXPECTED_JSON_TYPE = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}

_type_strategy = st.sampled_from(SUPPORTED_TYPES)

# Non-empty docstrings
_docstring_strategy = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N", "Z"), whitelist_characters=" .,!?-"),
    min_size=1,
    max_size=80,
).filter(lambda s: s.strip())

# Generate a list of (param_name, param_type) pairs with unique names
_param_list_strategy = st.lists(
    st.tuples(_VALID_IDENTS, _type_strategy),
    min_size=1,
    max_size=6,
).filter(lambda pairs: len({name for name, _ in pairs}) == len(pairs))


def _make_function(name: str, params: list[tuple[str, type]], docstring: str):
    """Dynamically create a function with the given name, typed params, and docstring."""
    param_names = [p[0] for p in params]
    annotations = {p[0]: p[1] for p in params}
    annotations["return"] = str

    sig_str = ", ".join(param_names)
    func_code = f"def {name}({sig_str}):\n    \"\"\"{docstring}\"\"\"\n    return ''"
    local_ns: dict = {}
    exec(func_code, {}, local_ns)
    fn = local_ns[name]
    fn.__annotations__ = annotations
    return fn


# ---------------------------------------------------------------------------
# Property 1: Tool schema generation round-trip
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    params=_param_list_strategy,
    docstring=_docstring_strategy,
)
def test_tool_schema_round_trip(func_name, params, docstring):
    """Property 1: For any function with complete type annotations and a
    docstring, the @tool decorator produces a schema whose parameter names,
    types, and description match the original signature.

    **Validates: Requirements 2.1**
    """
    fn = _make_function(func_name, params, docstring)
    decorated = tool(fn)

    schema = decorated._tool_schema

    # Schema name matches function name
    assert schema["name"] == func_name

    # Schema description matches docstring
    assert schema["description"] == docstring.strip()

    # All parameter names are present in the schema properties
    schema_props = schema["parameters"]["properties"]
    expected_names = {p[0] for p in params}
    assert set(schema_props.keys()) == expected_names

    # Each parameter's JSON schema type matches the expected mapping
    for param_name, param_type in params:
        expected_type = EXPECTED_JSON_TYPE[param_type]
        assert schema_props[param_name]["type"] == expected_type, (
            f"Parameter '{param_name}': expected JSON type '{expected_type}', "
            f"got '{schema_props[param_name]['type']}'"
        )

    # All params without defaults should be required
    assert set(schema["parameters"]["required"]) == expected_names


# ---------------------------------------------------------------------------
# Property 5: Tool definition validation at decoration time
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    params=st.lists(
        st.tuples(_VALID_IDENTS, _type_strategy),
        min_size=1,
        max_size=6,
    ).filter(lambda pairs: len({name for name, _ in pairs}) == len(pairs)),
    missing_idx=st.integers(min_value=0),
    docstring=_docstring_strategy,
)
def test_missing_annotation_raises_tool_definition_error(func_name, params, missing_idx, docstring):
    """Property 5: For any function missing a type annotation on at least one
    parameter, @tool raises ToolDefinitionError at decoration time.

    **Validates: Requirements 2.5**
    """
    # Pick which parameter to strip the annotation from
    idx = missing_idx % len(params)
    param_names = [p[0] for p in params]
    annotations = {p[0]: p[1] for p in params}
    annotations["return"] = str

    # Remove annotation for the chosen parameter
    stripped_param = param_names[idx]
    del annotations[stripped_param]

    sig_str = ", ".join(param_names)
    func_code = f"def {func_name}({sig_str}):\n    \"\"\"{docstring}\"\"\"\n    return ''"
    local_ns: dict = {}
    exec(func_code, {}, local_ns)
    fn = local_ns[func_name]
    fn.__annotations__ = annotations

    try:
        tool(fn)
        raise AssertionError(
            f"Expected ToolDefinitionError for missing annotation on '{stripped_param}'"
        )
    except ToolDefinitionError:
        pass  # Expected


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    params=st.lists(
        st.tuples(_VALID_IDENTS, _type_strategy),
        min_size=1,
        max_size=6,
    ).filter(lambda pairs: len({name for name, _ in pairs}) == len(pairs)),
)
def test_missing_docstring_raises_tool_definition_error(func_name, params):
    """Property 5: For any function missing a docstring, @tool raises
    ToolDefinitionError at decoration time.

    **Validates: Requirements 2.5**
    """
    param_names = [p[0] for p in params]
    annotations = {p[0]: p[1] for p in params}
    annotations["return"] = str

    sig_str = ", ".join(param_names)
    # No docstring in the function body
    func_code = f"def {func_name}({sig_str}):\n    return ''"
    local_ns: dict = {}
    exec(func_code, {}, local_ns)
    fn = local_ns[func_name]
    fn.__annotations__ = annotations

    try:
        tool(fn)
        raise AssertionError("Expected ToolDefinitionError for missing docstring")
    except ToolDefinitionError:
        pass  # Expected
