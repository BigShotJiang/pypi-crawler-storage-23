"""Tests for ``synth.cli.dev`` — TUI launcher."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


# ===================================================================
# run_dev — delegates to launch_tui
# ===================================================================


class TestRunDev:
    """Tests for ``run_dev`` — delegates to the TUI launcher."""

    def test_delegates_to_launch_tui(self):
        """run_dev calls launch_tui with the file path."""
        mock_tui = MagicMock()
        with patch.dict(
            "sys.modules",
            {"synth.cli._tui": mock_tui},
        ):
            from synth.cli.dev import run_dev

            run_dev("my_agent.py")
            mock_tui.launch_tui.assert_called_once_with("my_agent.py")

    def test_passes_file_argument_through(self):
        """The file argument is forwarded unchanged."""
        mock_tui = MagicMock()
        with patch.dict(
            "sys.modules",
            {"synth.cli._tui": mock_tui},
        ):
            from synth.cli.dev import run_dev

            run_dev("path/to/agent.py")
            mock_tui.launch_tui.assert_called_once_with("path/to/agent.py")
