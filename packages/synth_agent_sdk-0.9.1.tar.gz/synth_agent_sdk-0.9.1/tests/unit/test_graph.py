"""Unit tests for the Graph orchestration module.

Covers graph construction, execution, conditional edges, loop detection,
checkpointing, resume, and Mermaid visualisation.
"""

from __future__ import annotations

import asyncio

import pytest

from synth.checkpointing.local import LocalCheckpointStore
from synth.errors import GraphLoopError, GraphRoutingError, RunNotFoundError
from synth.orchestration.graph import Graph, node
from synth.types import PausedRun, RunResult


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------


class TestGraphExecution:
    """Tests for basic graph execution."""

    @pytest.mark.asyncio
    async def test_simple_linear_graph(self):
        """Linear graph A -> B -> END returns final state."""
        graph = Graph()
        graph.add_node("a", lambda s: {**s, "a": True})
        graph.add_node("b", lambda s: {**s, "b": True})
        graph.add_edge("a", "b")
        graph.add_edge("b", Graph.END)
        graph.set_entry("a")

        result = await graph.arun({})
        assert isinstance(result, RunResult)
        assert result.output["a"] is True
        assert result.output["b"] is True

    @pytest.mark.asyncio
    async def test_single_node_to_end(self):
        """Single node -> END works."""
        graph = Graph()
        graph.add_node("only", lambda s: {"done": True})
        graph.add_edge("only", Graph.END)
        graph.set_entry("only")

        result = await graph.arun({})
        assert result.output["done"] is True

    def test_sync_run(self):
        """graph.run() works synchronously."""
        graph = Graph()
        graph.add_node("x", lambda s: {"val": 42})
        graph.add_edge("x", Graph.END)
        graph.set_entry("x")

        result = graph.run({})
        assert result.output["val"] == 42


# ---------------------------------------------------------------------------
# Conditional edges
# ---------------------------------------------------------------------------


class TestConditionalEdges:
    """Tests for conditional edge routing."""

    @pytest.mark.asyncio
    async def test_conditional_edge_true(self):
        """Edge with when=True is followed."""
        graph = Graph()
        graph.add_node("start", lambda s: {**s, "route": "yes"})
        graph.add_node("yes_node", lambda s: {**s, "path": "yes"})
        graph.add_edge(
            "start", "yes_node",
            when=lambda s: s.get("route") == "yes",
        )
        graph.add_edge("yes_node", Graph.END)
        graph.set_entry("start")

        result = await graph.arun({})
        assert result.output["path"] == "yes"

    @pytest.mark.asyncio
    async def test_conditional_edge_false_falls_through(self):
        """When conditional edge is False, unconditional edge is taken."""
        graph = Graph()
        graph.add_node("start", lambda s: {**s, "route": "no"})
        graph.add_node("yes_node", lambda s: {**s, "path": "yes"})
        graph.add_node("default_node", lambda s: {**s, "path": "default"})
        graph.add_edge(
            "start", "yes_node",
            when=lambda s: s.get("route") == "yes",
        )
        graph.add_edge("start", "default_node")  # unconditional fallback
        graph.add_edge("yes_node", Graph.END)
        graph.add_edge("default_node", Graph.END)
        graph.set_entry("start")

        result = await graph.arun({})
        assert result.output["path"] == "default"


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


class TestGraphErrors:
    """Tests for graph error conditions."""

    @pytest.mark.asyncio
    async def test_no_entry_raises(self):
        """Running without set_entry raises GraphRoutingError."""
        graph = Graph()
        graph.add_node("a", lambda s: s)

        with pytest.raises(GraphRoutingError, match="No entry node"):
            await graph.arun({})

    @pytest.mark.asyncio
    async def test_dead_end_raises(self):
        """Node with no outbound edges raises GraphRoutingError."""
        graph = Graph()
        graph.add_node("a", lambda s: s)
        graph.set_entry("a")

        with pytest.raises(GraphRoutingError, match="no outbound edges"):
            await graph.arun({})

    @pytest.mark.asyncio
    async def test_no_matching_condition_raises(self):
        """All conditional edges False with no default raises."""
        graph = Graph()
        graph.add_node("a", lambda s: s)
        graph.add_edge("a", "b", when=lambda s: False)
        graph.set_entry("a")

        with pytest.raises(GraphRoutingError, match="No outbound edge"):
            await graph.arun({})

    @pytest.mark.asyncio
    async def test_loop_detection(self):
        """Exceeding max_iterations raises GraphLoopError."""
        graph = Graph()
        graph.add_node("loop", lambda s: s)
        graph.add_edge("loop", "loop")
        graph.set_entry("loop")

        with pytest.raises(GraphLoopError) as exc_info:
            await graph.arun({}, max_iterations=5)

        assert exc_info.value.max_iterations == 5
        assert len(exc_info.value.node_history) == 5


# ---------------------------------------------------------------------------
# Checkpointing
# ---------------------------------------------------------------------------


class TestGraphCheckpointing:
    """Tests for graph checkpointing integration."""

    @pytest.mark.asyncio
    async def test_checkpoint_saved_per_step(self, tmp_path):
        """Checkpoints are saved after each node execution."""
        store = LocalCheckpointStore(base_dir=str(tmp_path))
        graph = Graph()
        graph.with_checkpointing(store)
        graph.add_node("a", lambda s: {**s, "a": True})
        graph.add_node("b", lambda s: {**s, "b": True})
        graph.add_edge("a", "b")
        graph.add_edge("b", Graph.END)
        graph.set_entry("a")

        await graph.arun({}, run_id="test-run")

        cp = await store.load("test-run")
        assert cp is not None
        assert cp.step == 2
        assert cp.node_name == "b"

    @pytest.mark.asyncio
    async def test_resume_missing_run_raises(self, tmp_path):
        """Resuming a non-existent run raises RunNotFoundError."""
        store = LocalCheckpointStore(base_dir=str(tmp_path))
        graph = Graph()
        graph.with_checkpointing(store)
        graph.add_node("a", lambda s: s)
        graph.add_edge("a", Graph.END)
        graph.set_entry("a")

        with pytest.raises(RunNotFoundError, match="no-such-run"):
            await graph.aresume("no-such-run")


# ---------------------------------------------------------------------------
# @node decorator
# ---------------------------------------------------------------------------


class TestNodeDecorator:
    """Tests for the @node decorator."""

    def test_node_decorator_registers(self):
        """@node registers the function on the graph."""
        graph = Graph()

        @node(graph)
        def my_step(state):
            return state

        assert "my_step" in graph._nodes

    def test_node_decorator_custom_name(self):
        """@node with explicit name uses that name."""
        graph = Graph()

        @node(graph, name="custom")
        def my_step(state):
            return state

        assert "custom" in graph._nodes
        assert "my_step" not in graph._nodes


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------


class TestGraphVisualise:
    """Tests for Mermaid diagram generation."""

    def test_visualise_contains_nodes(self):
        """visualise() output contains all node names."""
        graph = Graph()
        graph.add_node("a", lambda s: s)
        graph.add_node("b", lambda s: s)
        graph.add_edge("a", "b")
        graph.add_edge("b", Graph.END)

        mermaid = graph.visualise()
        assert "a" in mermaid
        assert "b" in mermaid
        assert "END" in mermaid

    def test_visualise_contains_edges(self):
        """visualise() output contains edge arrows."""
        graph = Graph()
        graph.add_node("x", lambda s: s)
        graph.add_node("y", lambda s: s)
        graph.add_edge("x", "y")
        graph.add_edge("y", Graph.END)

        mermaid = graph.visualise()
        assert "x -->" in mermaid
        assert "y -->" in mermaid
