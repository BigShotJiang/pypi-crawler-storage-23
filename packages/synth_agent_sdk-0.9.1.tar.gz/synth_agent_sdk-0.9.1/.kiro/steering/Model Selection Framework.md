---
inclusion: always
---

# Model Selection Framework

Use this framework to select the appropriate model for the current task based on its
complexity and nature. The goal is to match model capability to task demands — use the
most capable model where reasoning depth matters, and faster models where throughput
and speed are the priority.

## Task-to-Model Mapping

| Task Category | Model | Rationale |
|---|---|---|
| Requirements & Specifications | Claude Opus 4.6 | Deep reasoning for ambiguity resolution, edge case identification, and completeness analysis |
| Architecture & Design | Claude Opus 4.6 | Complex trade-off evaluation, system-level thinking, cross-cutting concern analysis |
| Feature Implementation | Claude Sonnet 4 | Strong coding ability with good speed for iterative development cycles |
| Bug Fixes & Refactoring | Claude Sonnet 4 | Sufficient reasoning for root cause analysis with fast turnaround |
| Unit & Integration Tests | Claude Haiku | Fast generation of repetitive test patterns, assertions, and fixtures |
| Documentation & Docstrings | Claude Haiku | Straightforward content generation from existing code context |
| Code Review & Linting Fixes | Claude Haiku | Pattern matching and mechanical corrections |

## When to Escalate

Move up one tier from the default recommendation when:

- The task involves security-sensitive logic (credential handling, guard implementation,
  input sanitization) — escalate to at least Sonnet 4.
- The test requires complex property-based testing with Hypothesis or intricate mocking
  strategies — escalate from Haiku to Sonnet 4.
- A bug fix spans multiple modules or involves subtle concurrency/async issues — escalate
  from Sonnet 4 to Opus 4.6.
- Design decisions have irreversible downstream consequences (public API surface, data
  serialization formats) — use Opus 4.6 regardless of task size.

## When to Downgrade

Move down one tier when:

- The implementation is boilerplate or follows an established pattern already in the
  codebase (e.g., adding a new provider that mirrors an existing one) — Haiku is fine.
- The change is a single-line fix with obvious intent — Haiku.
- Generating test cases from a well-defined parametrize matrix — Haiku.

## Applying This Framework

1. Before starting a task, classify it using the table above.
2. If the task spans multiple categories (e.g., "design and implement a new guard"),
   use the model for the highest-complexity phase first, then switch for implementation.
3. For spec-driven workflows, use Opus 4.6 for the requirements and design documents,
   Sonnet 4 for task implementation, and Haiku for test generation.
