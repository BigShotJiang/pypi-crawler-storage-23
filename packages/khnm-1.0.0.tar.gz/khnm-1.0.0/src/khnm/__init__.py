from khnm.pipelines import make_pipeline

__all__ = [
    "make_pipeline",
]
