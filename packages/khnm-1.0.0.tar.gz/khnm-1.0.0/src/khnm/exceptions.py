class UpstreamPipeUnavailable(Exception):
    pass


class NodeKwargsInvalid(Exception):
    pass


class PipelineDefinitionInvalid(Exception):
    pass
