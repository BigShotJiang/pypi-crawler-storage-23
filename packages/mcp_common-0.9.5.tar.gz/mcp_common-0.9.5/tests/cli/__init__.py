"""Tests for CLI factory module."""
