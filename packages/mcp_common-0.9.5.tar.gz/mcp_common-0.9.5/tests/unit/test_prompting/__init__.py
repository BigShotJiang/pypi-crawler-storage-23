"""Tests for prompting adapter."""
