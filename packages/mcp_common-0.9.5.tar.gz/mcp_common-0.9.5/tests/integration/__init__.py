"""Integration tests for mcp-common."""
