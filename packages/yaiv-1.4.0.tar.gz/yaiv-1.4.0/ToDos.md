List of ToDos...

- Tutorial for phonon.py.
- Tutorial for convergence.py.
- Recover the convergence module.
    - [x] Self-consistent
    - [ ] Phonons
    - [ ] Wannierizations
- Unify Density and get_DOS sintax...
- Create a general strip_units function for consistency...
- Check finite difference phonons with BOES (units).
