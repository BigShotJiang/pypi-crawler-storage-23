function result = malformed(x
% This is a malformed function with syntax error
% Missing closing parenthesis
result = x + 1;
