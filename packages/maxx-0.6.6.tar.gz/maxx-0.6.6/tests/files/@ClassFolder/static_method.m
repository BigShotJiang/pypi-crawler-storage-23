function static_method()
% This is a static method, not requiring the class object itself
end
