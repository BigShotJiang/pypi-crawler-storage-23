function private_method(obj)
% This is a private method to the class folder object
end
