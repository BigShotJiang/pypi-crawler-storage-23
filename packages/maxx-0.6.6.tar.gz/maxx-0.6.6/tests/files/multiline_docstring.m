function result = multiline_docstring(x)
% First line of docstring
% Second line of docstring
% Third line of docstring
%
% Arguments:
%   x (double) - Input value
%
% Returns:
%   result (double) - Output value

result = x * 2;
end
