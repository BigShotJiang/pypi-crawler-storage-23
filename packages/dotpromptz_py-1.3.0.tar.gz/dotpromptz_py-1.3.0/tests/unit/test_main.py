"""Tests for __main__.py module entry point."""

from __future__ import annotations

import subprocess
import sys


class TestMainModule:
    """Test that python -m dotpromptz works."""

    def test_main_help(self) -> None:
        """Running ``python -m dotpromptz --help`` should succeed."""
        result = subprocess.run(
            [sys.executable, '-m', 'dotpromptz', '--help'],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0
        assert 'PROMPT_FILE' in result.stdout
        assert 'INPUT_FILE' in result.stdout
        # Old subcommands/flags should NOT appear
        assert '--input' not in result.stdout
        assert '--input-file' not in result.stdout
        # Verify no 'run' as standalone subcommand (would be in Usage line)
        assert 'run [OPTIONS]' not in result.stdout

    def test_main_version(self) -> None:
        """Running ``python -m dotpromptz --version`` should succeed."""
        result = subprocess.run(
            [sys.executable, '-m', 'dotpromptz', '--version'],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0

    def test_main_module_invokes_cli(self) -> None:
        """The __main__.py module should call cli() when run."""
        import runpy
        from unittest.mock import patch

        with patch('dotpromptz.cli.cli') as mock_cli:
            mock_cli.side_effect = SystemExit(0)
            try:
                runpy.run_module('dotpromptz', run_name='__main__')
            except SystemExit:
                pass
            mock_cli.assert_called_once()
