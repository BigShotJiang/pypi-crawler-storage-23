"""Smoke tests – verify basic connectivity to the Anthropic endpoint."""

from __future__ import annotations

import pytest

from dotpromptz.typing import Message, RenderedPrompt, Role, TextPart

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_simple_chat_completion(anthropic_adapter) -> None:
    """Send one user message and verify we get a non-empty response."""
    rendered = RenderedPrompt(
        config={'model': 'claude-haiku-4-5-20251001'},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='Say hello in one word.')]),
        ],
    )

    response = await anthropic_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    assert response.usage is not None
    assert response.usage.total_tokens > 0
    assert response.finish_reason == 'end_turn'
    print(f'\n[smoke] response: {response.text!r}')
    print(f'[smoke] tokens:   {response.usage.total_tokens}')


@pytest.mark.asyncio
async def test_system_and_user_message(anthropic_adapter) -> None:
    """Verify system + user messages work together."""
    rendered = RenderedPrompt(
        config={'model': 'claude-haiku-4-5-20251001'},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Reply in exactly one word.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='What color is the sky on a clear day?')],
            ),
        ],
    )

    response = await anthropic_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    print(f'\n[smoke] response: {response.text!r}')
