# Guardrails Blindfold

A [Guardrails AI](https://guardrailsai.com) validator that detects and protects PII in LLM outputs using the [Blindfold](https://blindfold.dev) API.

| | |
|---|---|
| Developed by | [Blindfold](https://blindfold.dev) |
| License | MIT |
| Input/Output | String |
| Hub | `blindfold/pii_protection` |

## Installation

```bash
pip install guardrails-blindfold
```

Set your Blindfold API key:

```bash
export BLINDFOLD_API_KEY=your-api-key
```

Get a free API key at [app.blindfold.dev](https://app.blindfold.dev).

## Quick Start

```python
from guardrails import Guard
from guardrails_blindfold import BlindfoldPII

guard = Guard().use(BlindfoldPII(on_fail="fix"))

result = guard.validate("Contact John Doe at john@example.com")
print(result.validated_output)
# → "Contact <Person_1> at <Email Address_1>"
```

## Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `policy` | `str` | `"basic"` | Detection policy — see table below |
| `pii_method` | `str` | `"tokenize"` | How to fix detected PII |
| `region` | `str` | `None` | `"eu"` or `"us"` for data residency |
| `entities` | `list` | `None` | Specific entity types to detect |
| `score_threshold` | `float` | `None` | Confidence threshold (0.0–1.0) |
| `api_key` | `str` | `None` | Falls back to `BLINDFOLD_API_KEY` env var |
| `on_fail` | `str` | `None` | Guardrails failure action |

### Policies

| Policy | Entities | Use Case |
|---|---|---|
| `basic` | Names, emails, phones, locations | General PII protection |
| `gdpr_eu` | EU-specific: IBANs, addresses, dates of birth | GDPR compliance |
| `hipaa_us` | PHI: SSNs, MRNs, medical terms | HIPAA compliance |
| `pci_dss` | Card numbers, CVVs, expiry dates | PCI DSS compliance |
| `strict` | All entity types, lower threshold | Maximum detection |

### PII Methods

| Method | Description | Reversible |
|---|---|---|
| `tokenize` | Replace with tokens (`<Person_1>`) | Yes |
| `redact` | Remove permanently (`[REDACTED]`) | No |
| `mask` | Partially hide (`J****oe`) | No |
| `hash` | Deterministic hash (`HASH_abc123`) | No |
| `synthesize` | Replace with fake data (`Jane Smith`) | No |
| `encrypt` | AES-256 encryption | Yes (with key) |

## Examples

### GDPR Compliance (EU Region)

```python
guard = Guard().use(
    BlindfoldPII(
        policy="gdpr_eu",
        region="eu",
        on_fail="fix",
    )
)

result = guard.validate("Email hans.mueller@example.de about the meeting")
# → "Email <Email Address_1> about the meeting"
```

### HIPAA — Redact PHI

```python
guard = Guard().use(
    BlindfoldPII(
        policy="hipaa_us",
        pii_method="redact",
        region="us",
        on_fail="fix",
    )
)

result = guard.validate("Patient John Smith, SSN 123-45-6789")
# → "Patient [REDACTED], SSN [REDACTED]"
```

### Block Output if PII Detected

```python
guard = Guard().use(
    BlindfoldPII(policy="strict", on_fail="exception")
)

# Raises ValidationError if PII is found
result = guard.validate("No PII here")  # passes
result = guard.validate("Email john@example.com")  # raises
```

### Chain with Other Validators

```python
from guardrails_blindfold import BlindfoldPII

guard = Guard().use(
    BlindfoldPII(policy="strict", on_fail="fix"),
).use(
    AnotherValidator(on_fail="exception"),
)
```

### Detect Specific Entity Types

```python
guard = Guard().use(
    BlindfoldPII(
        entities=["Email Address", "Phone Number"],
        on_fail="fix",
    )
)
```

## Data Residency

Use the `region` parameter to ensure PII is processed in a specific jurisdiction:

- `region="eu"` — processed in Frankfurt, Germany
- `region="us"` — processed in Virginia, US

```python
# EU data stays in the EU
guard = Guard().use(
    BlindfoldPII(policy="gdpr_eu", region="eu", on_fail="fix")
)
```

## Links

- [Blindfold Documentation](https://docs.blindfold.dev)
- [Blindfold Dashboard](https://app.blindfold.dev)
- [Guardrails AI Documentation](https://docs.guardrailsai.com)
- [GitHub](https://github.com/blindfold-dev/guardrails-blindfold)
