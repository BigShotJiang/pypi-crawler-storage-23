'''
Author: Ceoifung
Date: 2026-02-04 18:57:36
LastEditors: Ceoifung
LastEditTime: 2026-02-09 14:37:26
Description: XiaoRGEEK All Rights Reserved. Powered By Ceoifung
'''
import inspect
import json
import enum
from typing import get_type_hints, get_origin, get_args, Any, Callable

def mcp_tool(func: Callable = None, *, name: str = None, description: str = None):
    """
    Decorator to mark a function as an MCP tool.
    Usage:
        @mcp_tool
        def my_tool(arg1: str): ...
        
        @mcp_tool(name="custom_name", description="Custom description")
        def my_tool(arg1: str): ...
    """
    def decorator(f):
        f._is_mcp_tool = True
        f._mcp_name = name or f.__name__
        f._mcp_description = description or (f.__doc__.strip() if f.__doc__ else "")
        return f

    if func is None:
        return decorator
    return decorator(func)

def event_tool(func: Callable = None, *, name: str = None, description: str = None):
    """
    Decorator to mark a function as an MCP Event definition.
    Usage:
        @event_tool
        def my_event(arg1: str): ...
    """
    def decorator(f):
        f._is_mcp_event = True
        f._mcp_name = name or f.__name__
        f._mcp_description = description or (f.__doc__.strip() if f.__doc__ else "")
        return f

    if func is None:
        return decorator
    return decorator(func)

def python_type_to_json_type(py_type: Any) -> dict:
    if py_type == str:
        return {"type": "string"}
    if py_type == int:
        return {"type": "integer"}
    if py_type == float:
        return {"type": "number"}
    if py_type == bool:
        return {"type": "boolean"}
    if py_type == list:
        return {"type": "array"}
    if py_type == dict:
        return {"type": "object"}
    
    # Handle typing.Literal (Python 3.8+)
    # origin = get_origin(py_type)
    # if str(origin) == "typing.Literal": # Hacky check if get_origin returns Literal
    #    args = get_args(py_type)
    #    return {"type": "string", "enum": list(args)}

    return {"type": "string"}

def get_function_schema(func: Callable) -> dict:
    sig = inspect.signature(func)
    try:
        type_hints = get_type_hints(func)
    except Exception:
        type_hints = {}
    
    properties = {}
    required = []
    
    for param_name, param in sig.parameters.items():
        if param_name == "self" or param_name == "cls":
            continue
            
        # Get type hint or default to string
        param_type = type_hints.get(param_name, str)
        
        # Check for Enum
        if inspect.isclass(param_type) and issubclass(param_type, enum.Enum):
             prop_schema = {
                 "type": "string",
                 "enum": [e.value for e in param_type]
             }
        else:
            # Check for Literal (basic support)
            origin = get_origin(param_type)
            if origin is not None and "Literal" in str(origin):
                args = get_args(param_type)
                # Assume literal of strings/ints
                prop_schema = {
                    "type": "string", # Simplification
                    "enum": list(args)
                }
            else:
                prop_schema = python_type_to_json_type(param_type)
            
        properties[param_name] = prop_schema
        
        if param.default == inspect.Parameter.empty:
            required.append(param_name)
            
    return {
        "type": "object",
        "properties": properties,
        "required": required
    }

def get_tool_definition(func: Callable) -> dict:
    name = getattr(func, "_mcp_name", func.__name__)
    description = getattr(func, "_mcp_description", (func.__doc__ or "").strip())
    
    return {
        "name": name,
        "description": description,
        "input_schema": get_function_schema(func)
    }

def get_event_definition(func: Callable) -> dict:
    name = getattr(func, "_mcp_name", func.__name__)
    description = getattr(func, "_mcp_description", (func.__doc__ or "").strip())
    
    return {
        "name": name,
        "description": description,
        "payload_schema": get_function_schema(func)
    }
