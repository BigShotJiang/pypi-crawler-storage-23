"""
.. include:: ../../README.md
"""

from .NLinearRegularGridInterpolator import *
