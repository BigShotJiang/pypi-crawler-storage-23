# stock-gen

Language: English (canonical) | [한국어 landing](README.ko.md)

`stock-gen` is an event-driven single-asset CLOB simulator for virtual stock experiments.
It models limit, market, cancel, replace, and synthetic maintenance events with deterministic replay under fixed config + seed.

## Requirements

- Python >= 3.11

## Install

```bash
python -m pip install stock-gen
```

For local development:

```bash
python -m pip install -e '.[dev]'
```

## Quickstart

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## v2.0 Highlights

- Default structural gap policy is strict (`book_constraints.allow_locked_book=False`), so locked/crossed resting inserts are rejected unless explicitly enabled.
- Step accounting now documents cap-governed loop counts (`events_user`, alias `events_processed`) separately from total and synthetic step output (`events_total`, `events_synthetic`).
- Joint-flow adaptation knobs are fully documented:
  - `adaptation_warmup_events`
  - `lambda_prior_weight`
  - `dominant_shortcut_threshold`
  - `stale_trade_boost`
  - market/cancel share floors and ceilings
  - `adaptation_strength`
  - `max_adaptation_shift`
- Step rollback checkpoints now include full simulation state plus RNG state for deterministic replay after exceptions.

## Documentation

- Docs index: [docs/index.md](docs/index.md)
- API reference: [docs/api.md](docs/api.md)
- Config reference: [docs/config-reference.md](docs/config-reference.md)
- Data contract: [docs/data-contract.md](docs/data-contract.md)
- Joint order-flow model: [docs/joint-order-flow.md](docs/joint-order-flow.md)
- Architecture: [docs/architecture.md](docs/architecture.md)
- Release flow: [docs/release.md](docs/release.md)
- Migration guide (v2.0): [docs/archive/migration-v2.0.md](docs/archive/migration-v2.0.md)
- Changelog: [CHANGELOG.md](CHANGELOG.md)

## Examples

- [examples/basic_run.py](examples/basic_run.py)
- [examples/plot_demo.py](examples/plot_demo.py)
