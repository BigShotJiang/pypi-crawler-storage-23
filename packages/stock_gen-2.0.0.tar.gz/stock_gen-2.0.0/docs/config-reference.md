# Config Reference

`StockGeneratorConfig` is the entry point for simulator configuration.

## Import Paths

```python
from stock_gen import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    DepthMaintenancePolicy,
    JointFlowConfig,
    SpreadControlConfig,
    StockGeneratorConfig,
)
```

Explicit module paths:

```python
from stock_gen.config import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    JointFlowConfig,
    SpreadControlConfig,
    StockGeneratorConfig,
)
from stock_gen.types import DepthMaintenancePolicy
```

## Top-Level Fields (`StockGeneratorConfig`)

| Field | Default | Validation |
| --- | --- | --- |
| `tick_size` | `1.0` | `> 0` |
| `dt` | `1.0` | `> 0` |
| `end_time` | `600.0` | `>= 0` |
| `depth_levels` | `10` | `> 0` |
| `flow_kernel` | `"joint_v1"` | one of `{"joint_v1", "legacy_factorized"}` |
| `seed` | `123` | forwarded to `np.random.default_rng(seed)` (no explicit type guard in config) |
| `initial_mid_price` | `None` | `None` or `> 0` |
| `initial_spread_ticks` | `1` | `> 0` |
| `init_levels_per_side` | `50` | `> 0` |
| `init_orders_per_level` | `3` | `> 0` |
| `max_events_per_step` | `50000` | `> 0` |
| `flow_half_life` | `10.0` | `>= 0` |
| `liquidity_policy` | `LiquidityPolicy.REPAIR` | must be `LiquidityPolicy` |
| `event_cap_policy` | `EventCapPolicy.RAISE` | must be `EventCapPolicy` |
| `intensity` | `ExpLinearIntensityConfig.default()` | must be `ExpLinearIntensityConfig` |
| `placement` | `PlacementConfig()` | must be `PlacementConfig` |
| `size` | `SizeConfig()` | must be `SizeConfig` |
| `cancel` | `CancelConfig()` | must be `CancelConfig` |
| `regime` | `RegimeConfig()` | must be `RegimeConfig` |
| `depth_maintenance` | `DepthMaintenanceConfig()` | must be `DepthMaintenanceConfig` |
| `joint_flow` | `JointFlowConfig()` | must be `JointFlowConfig` |
| `spread_control` | `SpreadControlConfig()` | must be `SpreadControlConfig` |
| `book_constraints` | `BookConstraintConfig()` | must be `BookConstraintConfig` |

Validation note:
- Nested config/policy objects are type-checked.
- Primitive fields are mainly range/domain-checked; most are not strict `isinstance(..., bool/int)` checks.

## `ExpLinearIntensityConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `theta` | default per-event vectors | keys must be `EventType`, vector shape `(6,)` |
| `min_lambda` | `1e-12` | `> 0` |
| `exp_clip` | `50.0` | `> 0` |

Feature vector order:
`[1, log1p(spread_ticks), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow]`

## `PlacementConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `W` | `3x3` matrix | shape `(3, 3)` |
| `p_deep` | `0.40` | `(0, 1]` |
| `deep_max_ticks` | `200` | `> 0` |

## `SizeConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `market_mu` | `0.95` | - |
| `market_sigma` | `0.85` | `>= 0` |
| `improve_mu` | `1.35` | - |
| `improve_sigma` | `0.8` | `>= 0` |
| `join_mu` | `1.25` | - |
| `join_sigma` | `0.85` | `>= 0` |
| `deep_mu` | `1.15` | - |
| `deep_sigma` | `0.9` | `>= 0` |
| `max_order_qty` | `1000` | `> 0` |

## `CancelConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `beta_a` | `4.6` | `> 0` |
| `beta_b` | `2.3` | `> 0` |
| `partial_cancel_prob` | `0.30` | `[0, 1]` |
| `partial_min_ratio` | `0.2` | `(0, 1]` |

## `RegimeConfig`

`RegimeConfig.segments` is a tuple of `RegimeSegment(start_time, end_time, multiplier)`.

Rules:
- segments must be sorted by `start_time`
- segments must not overlap
- `multiplier > 0`

The active multiplier is applied to event intensities at current simulation time.

## `DepthMaintenanceConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `policy` | `DepthMaintenancePolicy.SOFT_TARGET` | must be `DepthMaintenancePolicy` |
| `target_levels` | `10` | `> 0` |
| `min_level_qty` | `2` | `> 0` |
| `target_level_qty` | `7` | `> 0` and `>= min_level_qty` |
| `level_decay` | `0.30` | `>= 0` |
| `max_synthetic_orders_per_step` | `8` | `>= 0` |
| `warmup_frames` | `0` | `>= 0` |

Policy values:
- `OFF`: disable synthetic depth maintenance.
- `SOFT_TARGET`: maintain minimum per-level depth.
- `STRICT_TARGET`: maintain target per-level depth.

## `JointFlowConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `action_logits` | baseline matrix | shape `(12, 9)` |
| `adaptation_enabled` | `True` | truthy/falsy check at runtime (no strict bool type guard) |
| `adaptation_warmup_events` | `0` | `>= 0` (numeric; cast with `int(...)` when used) |
| `market_share_floor` | `0.20` | `[0, 1]` |
| `market_share_ceiling` | `0.55` | `[0, 1]` and `>= floor` |
| `cancel_share_floor` | `0.10` | `[0, 1]` |
| `cancel_share_ceiling` | `0.48` | `[0, 1]` and `>= floor` |
| `adaptation_strength` | `18.0` | `>= 0` |
| `max_adaptation_shift` | `6.0` | `>= 0` |
| `lambda_prior_weight` | `0.15` | `>= 0` |
| `dominant_shortcut_threshold` | `0.90` | `[0, 1]` |
| `stale_trade_boost` | `0.50` | `>= 0` |

Notes:
- Rows in `action_logits` correspond to 12 joint action categories.
- Columns correspond to 9 joint features.
- Adaptive shifts target market/cancel share bounds over rolling event counters.
- `adaptation_warmup_events` delays adaptation until enough rolling events are observed.
- `adaptation_strength` controls response slope; `max_adaptation_shift` clips per-step logit shifts.
- `lambda_prior_weight` controls how much base intensity (`lambdas`) tilts joint-action logits.
- `dominant_shortcut_threshold` controls direct-dispatch shortcut activation in frame loop.
- `stale_trade_boost` scales stale-flow bonus in market-share adaptation.

## `SpreadControlConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `enabled` | `True` | truthy/falsy check at runtime (no strict bool type guard) |
| `target_spread_ticks` | `1` | `>= 0` (numeric; cast with `int(...)` when used) |
| `enforce_at_snapshot` | `True` | truthy/falsy check at runtime (no strict bool type guard) |
| `max_repair_orders_per_step` | `2` | `>= 0` (numeric; cast with `int(...)` when used) |

Notes:
- Spread control inserts synthetic `improve` limits before snapshot export.
- If locked books are disallowed, non-positive targets are clamped to `1` tick.

## `BookConstraintConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `min_price_ticks` | `0` | `>= 0` (numeric; cast with `int(...)` when order book is built) |
| `allow_locked_book` | `False` | coerced with `bool(...)` (no strict bool type guard) |
| `target_gap_ticks` | `1` | `>= 0` |
| `gap_enforcement` | `"event_hard"` | one of `{"none","snapshot_soft","event_hard"}` |

Notes:
- `min_price_ticks` is enforced on resting inserts and replace targets.
- `allow_locked_book=False` disallows resting inserts that would lock/cross the book.
- `target_gap_ticks` is the enforcement target used by gap policy.
- `gap_enforcement` controls when gap policy runs: disabled, snapshot-only, or event-time hard enforcement.
- `allow_locked_book=True` cannot be combined with `gap_enforcement="event_hard"` and `target_gap_ticks >= 1`.

## Gap Enforcement Defaults (v2.0)

- The default `book_constraints.gap_enforcement="event_hard"` with `target_gap_ticks=1` maintains one-tick inside gap during frame-loop execution.
- `book_constraints.allow_locked_book=False` also enforces a strictly positive resting spread (`best_bid < best_ask`) at order-book level.
- `spread_control.target_spread_ticks <= 0` is auto-raised to `1` when locked books are disallowed.
- To permit locked books (`spread == 0`), opt in with for example:
  - `BookConstraintConfig(allow_locked_book=True, target_gap_ticks=0, gap_enforcement="none")`
