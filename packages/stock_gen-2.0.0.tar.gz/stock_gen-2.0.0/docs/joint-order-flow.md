# Joint Order-Flow Model

This page documents the v2.0 joint event-flow kernel and related controls.

## Kernel Modes

`StockGeneratorConfig.flow_kernel` supports:

- `"joint_v1"` (default)
- `"legacy_factorized"`

`joint_v1` samples a joint action over event type, side, and execution style.
`legacy_factorized` keeps the older factorized event-type sampling path.

## `joint_v1` Execution Path

Inside the frame loop:

1. Build event-loop features and per-event intensities (`lambdas`).
2. If one event type dominates intensity share (`>= dominant_shortcut_threshold`, default `0.90`), dispatch that event directly.
3. Else, if replace intensity is active, sample replace with replace-proportional probability.
4. Else, sample a joint action category from `JointFlowConfig.action_logits` and dispatch it.

The joint action sampler:
- uses a 12-category action space
- masks infeasible actions (for example no market buy when no ask book)
- applies adaptive market/cancel shifts based on rolling event shares
- keeps improve actions feasible only when the current spread is strictly greater than 1 tick

## Joint Features

`JointFlowConfig.action_logits` multiplies a 9-element feature vector:

`[1, log1p(spread), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow, no_trade_streak_norm, market_share, cancel_share]`

Shape contract:
- `action_logits`: `(12, 9)`

## `JointFlowConfig` Defaults

- `adaptation_enabled=True`
- `adaptation_warmup_events=0`
- `market_share_floor=0.20`
- `market_share_ceiling=0.55`
- `cancel_share_floor=0.10`
- `cancel_share_ceiling=0.48`
- `adaptation_strength=18.0`
- `max_adaptation_shift=6.0`
- `lambda_prior_weight=0.15`
- `dominant_shortcut_threshold=0.90`
- `stale_trade_boost=0.50`

Adaptation raises/lowers market and cancel category logits to keep rolling shares in-range.

Knob intent:
- `adaptation_warmup_events`: do not adapt before enough rolling events accumulate.
- `market_share_*` and `cancel_share_*`: lower/upper share targets.
- `adaptation_strength`: gain for out-of-band correction.
- `max_adaptation_shift`: hard clip on per-step shift magnitude.
- `lambda_prior_weight`: prior blend strength from base event intensities.
- `dominant_shortcut_threshold`: direct-dispatch threshold for dominant intensity share.
- `stale_trade_boost`: no-trade streak bonus scale in market-share adaptation.

## Rolling Share Counters and Cap Behavior

- Adaptation uses `rolling_total_events`, `rolling_market_events`, and `rolling_cancel_events`.
- When `rolling_total_events > 1_000_000`, all three counters are halved to keep values bounded while preserving approximate shares.
- `max_events_per_step` gates frame-loop dispatch count (`StepResult.events_user` / `events_processed`), not post-loop maintenance injections.

## Spread and Book Constraints

`SpreadControlConfig` (default enabled) can add synthetic improve orders before snapshot export:
- `target_spread_ticks=1`
- `enforce_at_snapshot=True`
- `max_repair_orders_per_step=2`

`BookConstraintConfig` constrains order-book structure:
- `min_price_ticks=0`
- `allow_locked_book=False`

Gap enforcement defaults:
- `allow_locked_book=False` enforces `best_bid < best_ask` for resting book state.
- If locked books are disallowed, spread-control targets `<= 0` are clamped to `1` tick.
- These constraints apply to normal and synthetic order insertion paths.

## Event Quantity Fields

For downstream accounting, event records expose:
- `requested_qty`
- `executed_qty`
- `resting_qty`
- `canceled_qty`

This allows per-event reconciliation without re-deriving from trade/book diffs.

## Reproducing Pre-v2.0 Flow Behavior

If you need closer legacy flow behavior:

```python
from stock_gen import BookConstraintConfig, SpreadControlConfig, StockGeneratorConfig

cfg = StockGeneratorConfig(
    flow_kernel="legacy_factorized",
    spread_control=SpreadControlConfig(enabled=False),
    # optional: permit locked spread if your old pipeline assumed spread==0 states
    book_constraints=BookConstraintConfig(
        allow_locked_book=True,
        target_gap_ticks=0,
        gap_enforcement="none",
    ),
)
```

Also pin any other defaults your pipeline previously assumed.
