# API Reference

## Public Imports (Preferred)

```python
from stock_gen import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    DepthMaintenancePolicy,
    EventCapExceededError,
    EventCapPolicy,
    JointFlowConfig,
    LiquidityPolicy,
    SimulationResult,
    SpreadControlConfig,
    StepResult,
    StockGenerator,
    StockGeneratorConfig,
)
```

## Explicit Module Paths

```python
from stock_gen.config import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    JointFlowConfig,
    SpreadControlConfig,
    StockGeneratorConfig,
)
from stock_gen.types import DepthMaintenancePolicy, EventCapPolicy, LiquidityPolicy
from stock_gen.sim_policies import EventCapExceededError
```

Additional return types:

```python
from stock_gen.types import Event, FrameSnapshot, L2Snapshot, MarketHistory, Trade
```

## Core Objects

- `StockGeneratorConfig`: immutable simulator configuration.
- `JointFlowConfig`: joint event/side/style sampling controls.
- `SpreadControlConfig`: synthetic spread-tightening controls.
- `BookConstraintConfig`: order-book structural limits (default strict gap enforcement).
- `DepthMaintenanceConfig`: synthetic depth replenishment settings.
- `StockGenerator`: stateful simulator.
- `StepResult`: per-step output.
- `SimulationResult`: cumulative output.

## `StockGenerator`

- `StockGenerator(config: StockGeneratorConfig | None = None)`
- `step(dt: float | None = None) -> StepResult`
- `gen(until_time: float | None = None) -> SimulationResult`
- `reset(seed: int | None = None) -> None`
- `get_history() -> MarketHistory`
- `get_step_results() -> tuple[StepResult, ...]`
- `get_events() -> tuple[Event, ...]`
- `get_trades() -> tuple[Trade, ...]`
- `get_l2(levels: int | None = None, *, as_ticks: bool = False) -> L2Snapshot`
- `get_time() -> float`
- `get_price() -> float`
- `get_best_bid_ask() -> tuple[tuple[float, int], tuple[float, int]]`

Notes:
- `gen()` is stateful and continues from current simulator time.
- Returned history/event/trade/step containers are immutable tuples.
- `get_price()` returns `NaN` when either side of the book is missing.
- `get_best_bid_ask()` returns `(price, qty)` per side; when a side is missing the price is `NaN` and quantity is `0`.

## `StockGeneratorConfig` Flow and Gap Controls

- `flow_kernel="joint_v1"` (default): joint action sampler for event type + side + execution style.
- `flow_kernel="legacy_factorized"`: factorized event-type sampling path.

Joint-flow adaptation knobs (`JointFlowConfig`):
- `adaptation_warmup_events`: delay adaptive shifts until this many rolling events.
- `market_share_floor/ceiling`: target market-event share band.
- `cancel_share_floor/ceiling`: target cancel-event share band.
- `adaptation_strength` + `max_adaptation_shift`: adaptation gain and clip.
- `lambda_prior_weight`: intensity prior blending weight in joint sampler.
- `dominant_shortcut_threshold`: direct-dispatch cutoff for dominant event type.
- `stale_trade_boost`: no-trade streak bonus scale for market-event shift.

Gap/locking behavior (`BookConstraintConfig` + `SpreadControlConfig`):
- `allow_locked_book=False` (default) enforces strictly positive resting spread.
- `target_gap_ticks=1` (default) and `gap_enforcement="event_hard"` (default) enforce one-tick target gap during loop-time dispatch.
- With locked books disallowed, spread-control targets `<= 0` are clamped to `1` tick.
- Locked-book scenarios require compatible constraints (for example `BookConstraintConfig(allow_locked_book=True, target_gap_ticks=0, gap_enforcement="none")`).

## `StepResult`

- `frame: FrameSnapshot`
- `truncated: bool`
- `events_user: int` (cap-governed loop count)
- `events_synthetic: int` (count of emitted events where `synthetic=True`)
- `events_total: int` (all emitted events in the step)
- `t_last_event: float | None` (time of last cap-governed loop event)
- `events_processed: int` (property alias of `events_user`)

## `SimulationResult`

- `history: MarketHistory`
- `steps: tuple[StepResult, ...]`
- `frames`, `events`, `trades`: convenience aliases to `history`.

## `Event`

Stable fields:
- `seq`, `frame_index`, `t`, `event_type`, `side`
- `price_ticks`, `qty`, `order_id`
- `synthetic`, `reason`, `placement_mode`, `deep_distance`, `replaced_order_id`
- `requested_qty`, `executed_qty`, `resting_qty`, `canceled_qty`

Quantity field intent:
- `requested_qty`: sampled request size for the operation.
- `executed_qty`: quantity matched immediately into trades.
- `resting_qty`: quantity left resting on the book after the event.
- `canceled_qty`: quantity removed from resting liquidity.

## `L2Snapshot`

- `bid_px`, `ask_px`: prices (`int64` when `as_ticks=True`, `float64` when `as_ticks=False`)
- `bid_qty`, `ask_qty`: quantities (`int64`)
- `bid_px_valid`, `ask_px_valid`: validity masks (`bool`)

Contract:
- `as_ticks=True`: missing levels use tick sentinel `-1`.
- `as_ticks=False`: missing levels use `NaN`.

## Visualization API

```python
from stock_gen import viz
```

- `viz.plot_mid(obj, *, ax=None)`
- `viz.plot_spread(obj, *, ax=None, in_ticks=True)`
- `viz.plot_l2_heatmap(obj, *, side="both", space="price", price_window_ticks="auto", y_range="auto", cmap="viridis", mask_invalid=True, normalize="log1p", vmax_quantile=0.99)`

## Policy Enums

### `LiquidityPolicy`

- `REPAIR` (default): inserts synthetic liquidity for one-sided states.
- `ALLOW_EMPTY`: allows one-sided states.
- `HALT_ON_EMPTY`: raises `RuntimeError` on one-sided states.

### `EventCapPolicy`

- `RAISE` (default): raises `EventCapExceededError` and rolls back the step atomically.
- `TRUNCATE_AND_FLAG`: truncates step and sets `StepResult.truncated=True`.

Cap semantics:
- `max_events_per_step` gates cap-governed loop events (`events_user` / `events_processed`).
- Post-loop synthetic maintenance events (for example depth/spread controls) are not cap-gated.

### `DepthMaintenancePolicy`

- `OFF`: disable synthetic depth replenishment.
- `SOFT_TARGET` (default): replenish toward minimum per-level depth.
- `STRICT_TARGET`: replenish toward target per-level depth.

## Error Behavior

Common exceptions:
- `StockGeneratorConfig(...)`: `ValueError` / `TypeError` for invalid ranges or types.
- `step(dt=...)`: `ValueError` if `dt <= 0`.
- `gen(until_time=...)`: `ValueError` if `until_time < current time`.
- `get_l2(levels=...)`: `ValueError` if `levels <= 0`.
- `LiquidityPolicy.HALT_ON_EMPTY`: `RuntimeError`.
- `EventCapPolicy.RAISE`: `stock_gen.sim_policies.EventCapExceededError`.

Step transaction guarantee:
- `step()` restores simulator state/history on any raised exception before re-raising.
