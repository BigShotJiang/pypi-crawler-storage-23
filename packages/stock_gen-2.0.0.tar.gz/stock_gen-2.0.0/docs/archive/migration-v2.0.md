# Migration Guide: v1.x -> v2.0

v2.0 introduces stricter structural defaults and clarifies event accounting/determinism contracts for downstream consumers.

## Breaking Changes

1. Gap enforcement is strict by default.
   - `BookConstraintConfig.allow_locked_book=False` remains the default and enforces `best_bid < best_ask` for resting state.
   - If locked books are disallowed, `SpreadControlConfig.target_spread_ticks <= 0` is clamped to `1` tick during spread repair.
2. Step counter and cap semantics are explicit.
   - `max_events_per_step` gates cap-governed frame-loop dispatch count (`StepResult.events_user`, alias `events_processed`).
   - `events_synthetic` counts emitted events where `synthetic=True`.
   - `events_total` is the full emitted in-step event count (synthetic + non-synthetic).
3. Checkpoint determinism scope is expanded.
   - Rollback checkpoints include full simulation state (pattern state, rolling joint-flow counters, no-trade streak, sequence counters), RNG bit-generator state, plus history lengths.
   - After an exception-triggered rollback, resumed execution is deterministic under fixed config + seed.
4. Joint-flow adaptation controls should be pinned for calibrated pipelines.
   - `adaptation_warmup_events`
   - `market_share_floor`, `market_share_ceiling`
   - `cancel_share_floor`, `cancel_share_ceiling`
   - `adaptation_strength`
   - `max_adaptation_shift`

## Migration Steps

1. If your old workflow expected locked spread states (`spread_ticks == 0`), opt in explicitly:

```python
from stock_gen import BookConstraintConfig, StockGeneratorConfig

cfg = StockGeneratorConfig(
    book_constraints=BookConstraintConfig(
        allow_locked_book=True,
        target_gap_ticks=0,
        gap_enforcement="none",
    ),
)
```

2. Recheck step-level analytics/alerts:
   - treat `events_user` / `events_processed` as cap-governed loop count
   - use `events_total` for total emitted volume
   - use `events_synthetic` for synthetic share reporting

3. Pin joint-flow knobs in production configs instead of inheriting defaults:

```python
from stock_gen import JointFlowConfig, StockGeneratorConfig

cfg = StockGeneratorConfig(
    joint_flow=JointFlowConfig(
        adaptation_warmup_events=200,
        market_share_floor=0.20,
        market_share_ceiling=0.55,
        cancel_share_floor=0.10,
        cancel_share_ceiling=0.48,
        adaptation_strength=18.0,
        max_adaptation_shift=6.0,
    )
)
```

4. Rebaseline deterministic fixtures that involve rollback/error paths, because full-state checkpoints now restore additional counters/state.

## Quick Verification Checklist

- Run fixed-seed replay and compare `history.to_numpy(as_ticks=True)` outputs.
- Trigger one rollback path (for example `EventCapPolicy.RAISE`) and verify resumed replay remains deterministic.
- Validate event-ingestion schemas for `StepResult` counter semantics.
- Confirm docs links point to this file (`migration-v2.0.md`) as the current migration guide.
