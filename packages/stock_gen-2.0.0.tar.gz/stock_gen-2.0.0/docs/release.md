# Release Guide

## 1. Prepare Version Metadata

1. Update `pyproject.toml` version.
2. Add a new top entry in `CHANGELOG.md`.
3. Add/update migration notes in `docs/archive/` for breaking changes.
4. Keep docs practical and current:
   - `README.md` is the canonical source (English-first policy).
   - `README.ko.md` is a concise landing page that links back to `README.md` and English docs.
   - remove stale migration references and point to the current versioned migration note.

## 2. Verify Locally

Prerequisite: install `lychee` (`cargo install lychee` or download binary release).

```bash
pytest -q --cov=stock_gen --cov-report=term-missing --cov-fail-under=90
ruff check .
mypy src tests
python -m build
lychee --no-progress docs README.md README.ko.md
```

## 3. Artifact Smoke Test

```bash
python -m pip install --force-reinstall dist/*.whl
python - <<'PY'
from stock_gen import StockGenerator, StockGeneratorConfig
sim = StockGenerator(StockGeneratorConfig(seed=1, end_time=1.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
PY
```

## 4. Publish (Tag-Driven)

Repository workflow: `.github/workflows/workflow.yml`

```bash
git checkout main
git pull --ff-only
git push origin main
git tag vX.Y.Z
git push origin vX.Y.Z
```

The GitHub Actions workflow validates `tag == pyproject version == top changelog version`, checks docs links, runs tests, builds artifacts, and publishes via PyPI Trusted Publishing.
