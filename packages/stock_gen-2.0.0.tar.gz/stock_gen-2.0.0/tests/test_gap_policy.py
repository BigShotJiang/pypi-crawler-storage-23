from __future__ import annotations

from numpy.random import default_rng

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import BookConstraintConfig, SizeConfig, SpreadControlConfig
from stock_gen.engine.gap_policy import enforce_gap_target
from stock_gen.orderbook import OrderBook
from stock_gen.sim_state import SimulationState
from stock_gen.types import EventType, PlacementMode, Side


def _deterministic_size_cfg() -> SizeConfig:
    return SizeConfig(
        market_mu=0.0,
        market_sigma=0.0,
        improve_mu=0.0,
        improve_sigma=0.0,
        join_mu=0.0,
        join_sigma=0.0,
        deep_mu=0.0,
        deep_sigma=0.0,
        max_order_qty=50,
    )


def test_gap_policy_repairs_inside_gap_with_synthetic_limit() -> None:
    cfg = StockGeneratorConfig(
        size=_deterministic_size_cfg(),
        book_constraints=BookConstraintConfig(target_gap_ticks=1, gap_enforcement="event_hard"),
    )
    ob = OrderBook(min_price_ticks=0, allow_locked_book=False)
    _ = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=7)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=105, qty=9)
    state = SimulationState()

    captured: list[dict[str, object]] = []
    inserted = enforce_gap_target(
        ob=ob,
        state=state,
        cfg=cfg,
        rng=default_rng(11),
        append_event=lambda **kwargs: captured.append(kwargs),
    )

    assert inserted == 1
    assert ob.spread_ticks() == 1
    assert captured
    ev = captured[0]
    assert ev["synthetic"] is True
    assert ev["reason"] == "gap_repair"
    assert ev["event_type"] in (EventType.L_B, EventType.L_A)
    assert ev["placement_mode"] in (PlacementMode.IMPROVE, PlacementMode.JOIN)


def test_event_hard_gap_invariant_holds_across_steps() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        end_time=40.0,
        seed=13,
        spread_control=SpreadControlConfig(enabled=False, enforce_at_snapshot=False),
        book_constraints=BookConstraintConfig(target_gap_ticks=1, gap_enforcement="event_hard"),
    )

    sim = StockGenerator(cfg).gen()

    assert sim.frames
    for frame in sim.frames:
        assert frame.spread_ticks is not None
        assert frame.spread_ticks == 1
