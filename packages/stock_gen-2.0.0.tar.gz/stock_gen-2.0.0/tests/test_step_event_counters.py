import numpy as np

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    ExpLinearIntensityConfig,
    SizeConfig,
    SpreadControlConfig,
)
from stock_gen.types import DepthMaintenancePolicy, EventType


def test_step_counters_split_user_vs_synthetic_events() -> None:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=19,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        depth_maintenance=DepthMaintenanceConfig(policy=DepthMaintenancePolicy.OFF),
        spread_control=SpreadControlConfig(enabled=False, enforce_at_snapshot=False),
    )
    sg = StockGenerator(cfg)

    step = sg.step()
    assert step.events_user == 1
    assert step.events_synthetic == 1
    assert step.events_total == step.events_user + step.events_synthetic
    assert step.events_processed == step.events_user


def test_event_cap_counts_synthetic_events_toward_limit() -> None:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=23,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=2,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        depth_maintenance=DepthMaintenanceConfig(policy=DepthMaintenancePolicy.OFF),
        spread_control=SpreadControlConfig(enabled=False, enforce_at_snapshot=False),
        book_constraints=BookConstraintConfig(target_gap_ticks=1, gap_enforcement="event_hard"),
    )
    sg = StockGenerator(cfg)

    step = sg.step()

    assert step.events_user == 1
    assert step.events_synthetic == 1
    assert step.events_total == 2
    assert step.truncated is True


def test_step_counters_zero_when_no_events_happen() -> None:
    cfg = StockGeneratorConfig(seed=123, intensity=ExpLinearIntensityConfig(theta={}))
    sg = StockGenerator(cfg)

    step = sg.step()
    assert step.events_user == 0
    assert step.events_synthetic == 0
    assert step.events_total == 0
    assert step.events_processed == 0
