from __future__ import annotations

import numpy as np
from numpy.random import default_rng

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import (
    BookConstraintConfig,
    DepthMaintenanceConfig,
    ExpLinearIntensityConfig,
    JointFlowConfig,
    SpreadControlConfig,
)
from stock_gen.models_joint_flow import sample_joint_action
from stock_gen.sim_state import SimulationState
from stock_gen.types import DepthMaintenancePolicy, EventType


def test_joint_action_masks_infeasible_market_buy_without_ask() -> None:
    logits = np.zeros((12, 9), dtype=np.float64)
    logits[6, 0] = 9.0  # strongly prefer M_B if not masked
    cfg = JointFlowConfig(action_logits=logits)
    state = SimulationState()
    rng = default_rng(123)

    sampled = [
        sample_joint_action(
            cfg=cfg,
            rng=rng,
            state=state,
            spread_ticks=None,
            best_bid_qty=10,
            best_ask_qty=None,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=False,
        ).event_type
        for _ in range(100)
    ]
    assert all(event_type is not EventType.M_B for event_type in sampled)


def test_joint_action_adaptation_boosts_market_share_when_flow_is_stale() -> None:
    cfg = JointFlowConfig(action_logits=np.zeros((12, 9), dtype=np.float64))
    state = SimulationState()
    state.rolling_total_events = 100
    state.rolling_market_events = 0
    state.rolling_cancel_events = 70
    state.no_trade_streak_frames = 20
    rng = default_rng(7)

    n = 300
    market_count = 0
    for _ in range(n):
        action = sample_joint_action(
            cfg=cfg,
            rng=rng,
            state=state,
            spread_ticks=1,
            best_bid_qty=25,
            best_ask_qty=25,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=True,
        )
        if action.event_type in (EventType.M_B, EventType.M_A):
            market_count += 1
    assert (market_count / n) >= 0.20


def test_joint_flow_lambda_prior_weight_controls_lambda_bias_strength() -> None:
    zero_logits = np.zeros((12, 9), dtype=np.float64)
    state = SimulationState()
    lambdas = {
        EventType.L_B: 1e-6,
        EventType.L_A: 1e-6,
        EventType.M_B: 100.0,
        EventType.M_A: 1e-6,
        EventType.C_B: 1e-6,
        EventType.C_A: 1e-6,
    }

    cfg_no_prior = JointFlowConfig(
        action_logits=zero_logits,
        adaptation_enabled=False,
        lambda_prior_weight=0.0,
    )
    cfg_strong_prior = JointFlowConfig(
        action_logits=zero_logits,
        adaptation_enabled=False,
        lambda_prior_weight=2.0,
    )
    rng_no_prior = default_rng(21)
    rng_strong_prior = default_rng(21)

    n = 400
    m_b_no_prior = 0
    m_b_strong_prior = 0
    for _ in range(n):
        if (
            sample_joint_action(
                cfg=cfg_no_prior,
                rng=rng_no_prior,
                state=state,
                spread_ticks=1,
                best_bid_qty=10,
                best_ask_qty=10,
                imbalance=0.0,
                recent_flow=0.0,
                has_bid=True,
                has_ask=True,
                lambdas=lambdas,
            ).event_type
            is EventType.M_B
        ):
            m_b_no_prior += 1
        if (
            sample_joint_action(
                cfg=cfg_strong_prior,
                rng=rng_strong_prior,
                state=state,
                spread_ticks=1,
                best_bid_qty=10,
                best_ask_qty=10,
                imbalance=0.0,
                recent_flow=0.0,
                has_bid=True,
                has_ask=True,
                lambdas=lambdas,
            ).event_type
            is EventType.M_B
        ):
            m_b_strong_prior += 1

    assert m_b_strong_prior > m_b_no_prior * 3


def test_joint_flow_stale_trade_boost_knob_changes_market_sampling_rate() -> None:
    zero_logits = np.zeros((12, 9), dtype=np.float64)
    state = SimulationState()
    state.rolling_total_events = 100
    state.rolling_market_events = 30
    state.rolling_cancel_events = 20
    state.no_trade_streak_frames = 20

    cfg_no_boost = JointFlowConfig(action_logits=zero_logits, stale_trade_boost=0.0)
    cfg_boosted = JointFlowConfig(action_logits=zero_logits, stale_trade_boost=1.5)
    rng_no_boost = default_rng(31)
    rng_boosted = default_rng(31)

    n = 600
    market_no_boost = 0
    market_boosted = 0
    for _ in range(n):
        event_no_boost = sample_joint_action(
            cfg=cfg_no_boost,
            rng=rng_no_boost,
            state=state,
            spread_ticks=1,
            best_bid_qty=20,
            best_ask_qty=20,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=True,
        ).event_type
        event_boosted = sample_joint_action(
            cfg=cfg_boosted,
            rng=rng_boosted,
            state=state,
            spread_ticks=1,
            best_bid_qty=20,
            best_ask_qty=20,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=True,
        ).event_type
        if event_no_boost in (EventType.M_B, EventType.M_A):
            market_no_boost += 1
        if event_boosted in (EventType.M_B, EventType.M_A):
            market_boosted += 1

    assert market_boosted > market_no_boost


def test_joint_flow_dominant_shortcut_threshold_is_configurable() -> None:
    logits = np.full((12, 9), -100.0, dtype=np.float64)
    logits[4, 0] = 100.0  # strongly prefer L_A_JOIN when shortcut does not trigger.
    theta = {
        EventType.L_B: np.asarray([1.5, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
        EventType.L_A: np.asarray([1.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }

    cfg_no_shortcut = StockGeneratorConfig(
        dt=1.0,
        seed=29,
        flow_kernel="joint_v1",
        intensity=ExpLinearIntensityConfig(theta=theta),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        depth_maintenance=DepthMaintenanceConfig(policy=DepthMaintenancePolicy.OFF),
        spread_control=SpreadControlConfig(enabled=False, enforce_at_snapshot=False),
        book_constraints=BookConstraintConfig(gap_enforcement="none"),
        joint_flow=JointFlowConfig(
            action_logits=logits,
            adaptation_enabled=False,
            lambda_prior_weight=0.0,
            dominant_shortcut_threshold=0.95,
        ),
    )
    cfg_shortcut = StockGeneratorConfig(
        dt=1.0,
        seed=29,
        flow_kernel="joint_v1",
        intensity=ExpLinearIntensityConfig(theta=theta),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        depth_maintenance=DepthMaintenanceConfig(policy=DepthMaintenancePolicy.OFF),
        spread_control=SpreadControlConfig(enabled=False, enforce_at_snapshot=False),
        book_constraints=BookConstraintConfig(gap_enforcement="none"),
        joint_flow=JointFlowConfig(
            action_logits=logits,
            adaptation_enabled=False,
            lambda_prior_weight=0.0,
            dominant_shortcut_threshold=0.50,
        ),
    )

    no_shortcut = StockGenerator(cfg_no_shortcut)
    shortcut = StockGenerator(cfg_shortcut)

    _ = no_shortcut.step()
    _ = shortcut.step()

    user_events_no_shortcut = [ev for ev in no_shortcut.get_events() if not ev.synthetic]
    user_events_shortcut = [ev for ev in shortcut.get_events() if not ev.synthetic]
    assert user_events_no_shortcut
    assert user_events_shortcut

    assert user_events_no_shortcut[0].event_type is EventType.L_A
    assert user_events_shortcut[0].event_type is EventType.L_B
