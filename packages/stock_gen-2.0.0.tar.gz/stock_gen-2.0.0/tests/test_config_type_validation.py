import pytest

from stock_gen import StockGeneratorConfig
from stock_gen.config import BookConstraintConfig, DepthMaintenanceConfig, JointFlowConfig
from stock_gen.types import DepthMaintenancePolicy


def test_invalid_liquidity_policy_type_raises_type_error() -> None:
    with pytest.raises(TypeError, match="liquidity_policy"):
        StockGeneratorConfig(liquidity_policy="repair")  # type: ignore[arg-type]


def test_invalid_event_cap_policy_type_raises_type_error() -> None:
    with pytest.raises(TypeError, match="event_cap_policy"):
        StockGeneratorConfig(event_cap_policy="raise")  # type: ignore[arg-type]


def test_invalid_nested_config_types_raise_type_error() -> None:
    with pytest.raises(TypeError, match="intensity"):
        StockGeneratorConfig(intensity=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="placement"):
        StockGeneratorConfig(placement=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="size"):
        StockGeneratorConfig(size=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="cancel"):
        StockGeneratorConfig(cancel=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="regime"):
        StockGeneratorConfig(regime=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="depth_maintenance"):
        StockGeneratorConfig(depth_maintenance=object())  # type: ignore[arg-type]


def test_invalid_depth_maintenance_policy_type_raises_type_error() -> None:
    with pytest.raises(TypeError, match="depth_maintenance.policy"):
        DepthMaintenanceConfig(policy="soft_target")  # type: ignore[arg-type]


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"target_levels": 0}, "target_levels"),
        ({"min_level_qty": 0}, "min_level_qty"),
        ({"target_level_qty": 0}, "target_level_qty"),
        ({"min_level_qty": 5, "target_level_qty": 4}, "min_level_qty"),
        ({"level_decay": -0.1}, "level_decay"),
        ({"max_synthetic_orders_per_step": -1}, "max_synthetic_orders_per_step"),
        ({"warmup_frames": -1}, "warmup_frames"),
    ],
)
def test_depth_maintenance_value_bounds(kwargs: dict[str, object], message: str) -> None:
    with pytest.raises(ValueError, match=message):
        DepthMaintenanceConfig(**kwargs)  # type: ignore[arg-type]


def test_depth_maintenance_accepts_explicit_policy_enum() -> None:
    cfg = DepthMaintenanceConfig(policy=DepthMaintenancePolicy.STRICT_TARGET)
    assert cfg.policy is DepthMaintenancePolicy.STRICT_TARGET


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"lambda_prior_weight": -0.01}, "lambda_prior_weight"),
        ({"dominant_shortcut_threshold": -0.01}, "dominant_shortcut_threshold"),
        ({"dominant_shortcut_threshold": 1.01}, "dominant_shortcut_threshold"),
        ({"stale_trade_boost": -0.01}, "stale_trade_boost"),
    ],
)
def test_joint_flow_config_value_bounds(kwargs: dict[str, object], message: str) -> None:
    with pytest.raises(ValueError, match=message):
        JointFlowConfig(**kwargs)  # type: ignore[arg-type]


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"target_gap_ticks": -1}, "target_gap_ticks"),
        ({"gap_enforcement": "hard"}, "gap_enforcement"),
        (
            {"allow_locked_book": True, "gap_enforcement": "event_hard", "target_gap_ticks": 1},
            "allow_locked_book=True conflicts",
        ),
        (
            {"allow_locked_book": True, "gap_enforcement": "event_hard", "target_gap_ticks": 3},
            "allow_locked_book=True conflicts",
        ),
    ],
)
def test_book_constraint_gap_validation(kwargs: dict[str, object], message: str) -> None:
    with pytest.raises(ValueError, match=message):
        BookConstraintConfig(**kwargs)  # type: ignore[arg-type]
