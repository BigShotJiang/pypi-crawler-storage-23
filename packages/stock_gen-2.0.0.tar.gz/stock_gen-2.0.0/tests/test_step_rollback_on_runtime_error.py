import numpy as np
import pytest

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import BookConstraintConfig, ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType


def _m_b_only_intensity() -> ExpLinearIntensityConfig:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return ExpLinearIntensityConfig(theta=theta)


def _small_book_large_market_size() -> SizeConfig:
    return SizeConfig(
        market_mu=8.0,
        market_sigma=0.0,
        improve_mu=0.0,
        improve_sigma=0.0,
        join_mu=0.0,
        join_sigma=0.0,
        deep_mu=0.0,
        deep_sigma=0.0,
        max_order_qty=10_000,
    )


def test_step_rolls_back_on_non_cap_runtime_error() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=17,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=_m_b_only_intensity(),
        size=_small_book_large_market_size(),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.HALT_ON_EMPTY,
        book_constraints=BookConstraintConfig(gap_enforcement="none"),
    )
    sg = StockGenerator(cfg)

    before_time = sg.get_time()
    before_events = sg.get_events()
    before_trades = sg.get_trades()
    before_steps = sg.get_step_results()
    before_history = sg.get_history()

    with pytest.raises(RuntimeError, match="one-sided book"):
        sg.step()

    after_history = sg.get_history()

    assert sg.get_time() == pytest.approx(before_time)
    assert sg.get_events() == before_events
    assert sg.get_trades() == before_trades
    assert sg.get_step_results() == before_steps
    assert after_history.frames == before_history.frames
    assert after_history.events == before_history.events
    assert after_history.trades == before_history.trades


def test_step_rollback_restores_rng_state_for_deterministic_retry(monkeypatch: pytest.MonkeyPatch) -> None:
    cfg = StockGeneratorConfig(seed=113, dt=1.0)
    sg = StockGenerator(cfg)
    sg_ref = StockGenerator(cfg)

    original_append_frame = sg._history_store.append_frame

    def _raise_after_step(_frame: object) -> None:
        raise RuntimeError("injected frame write failure")

    monkeypatch.setattr(sg._history_store, "append_frame", _raise_after_step)
    with pytest.raises(RuntimeError, match="injected frame write failure"):
        sg.step()

    monkeypatch.setattr(sg._history_store, "append_frame", original_append_frame)

    retried = sg.step()
    reference = sg_ref.step()

    assert retried.truncated == reference.truncated
    assert retried.events_user == reference.events_user
    assert retried.events_synthetic == reference.events_synthetic
    assert retried.events_total == reference.events_total
    if retried.t_last_event is None or reference.t_last_event is None:
        assert retried.t_last_event is None
        assert reference.t_last_event is None
    else:
        assert retried.t_last_event == pytest.approx(reference.t_last_event)

    retried_hist = sg.get_history().to_numpy(as_ticks=True)
    reference_hist = sg_ref.get_history().to_numpy(as_ticks=True)
    for key in [
        "t",
        "spread_ticks",
        "spread_valid",
        "best_bid_ticks",
        "best_ask_ticks",
        "best_bid_valid",
        "best_ask_valid",
        "bid_px_ticks",
        "bid_qty",
        "ask_px_ticks",
        "ask_qty",
    ]:
        np.testing.assert_array_equal(retried_hist[key], reference_hist[key], err_msg=f"mismatch at key={key}")
    for key in ["mid", "imbalance", "recent_flow"]:
        np.testing.assert_allclose(retried_hist[key], reference_hist[key], equal_nan=True, err_msg=f"mismatch at key={key}")

    assert sg.get_events() == sg_ref.get_events()
    assert sg.get_trades() == sg_ref.get_trades()
