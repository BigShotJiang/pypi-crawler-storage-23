# stock-gen

언어: [English (canonical)](README.md) | 한국어 랜딩

`stock-gen`은 이벤트 기반 단일자산 CLOB 시뮬레이터입니다.

> 한국어 문서는 빠른 진입용입니다. 규범적 API/데이터 계약 기준은 항상 [README.md](README.md) 및 영문 `docs/` 문서입니다.

## 설치

```bash
python -m pip install stock-gen
```

## 최소 실행 예시

```python
from stock_gen import StockGenerator, StockGeneratorConfig

sim = StockGenerator(StockGeneratorConfig(seed=123, end_time=5.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## 문서 링크 (영문 기준)

- 영문 README(기준 문서): [README.md](README.md)
- 문서 인덱스: [docs/index.md](docs/index.md)
- API 참조: [docs/api.md](docs/api.md)
- 설정 참조: [docs/config-reference.md](docs/config-reference.md)
- v2.0 마이그레이션: [docs/archive/migration-v2.0.md](docs/archive/migration-v2.0.md)
- 변경 이력: [CHANGELOG.md](CHANGELOG.md)
