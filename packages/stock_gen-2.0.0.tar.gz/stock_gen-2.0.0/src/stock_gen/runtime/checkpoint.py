from __future__ import annotations

import copy
from collections.abc import MutableSequence
from dataclasses import dataclass
from typing import Any

from numpy.random import Generator

from ..orderbook import OrderBook, OrderBookSnapshot
from ..sim_state import SimulationState, SimulationStateSnapshot


@dataclass(frozen=True, slots=True)
class StepCheckpoint:
    """Atomic simulator checkpoint used for step rollback."""

    orderbook: OrderBookSnapshot
    rng_state: Any
    state: SimulationStateSnapshot
    frame_len: int
    event_len: int
    trade_len: int
    step_len: int


def capture_step_checkpoint(
    *,
    ob: OrderBook,
    rng: Generator,
    state: SimulationState,
    frame_len: int,
    event_len: int,
    trade_len: int,
    step_len: int,
) -> StepCheckpoint:
    """Capture all mutable simulator state required for full rollback."""

    return StepCheckpoint(
        orderbook=ob.snapshot(),
        rng_state=copy.deepcopy(rng.bit_generator.state),
        state=state.snapshot(),
        frame_len=int(frame_len),
        event_len=int(event_len),
        trade_len=int(trade_len),
        step_len=int(step_len),
    )


def restore_step_checkpoint(
    *,
    checkpoint: StepCheckpoint,
    ob: OrderBook,
    rng: Generator,
    state: SimulationState,
    frames: MutableSequence[Any],
    events: MutableSequence[Any],
    trades: MutableSequence[Any],
    step_results: MutableSequence[Any],
) -> None:
    """Restore simulator state from a previously captured checkpoint."""

    ob.restore(checkpoint.orderbook)
    rng.bit_generator.state = copy.deepcopy(checkpoint.rng_state)
    state.restore(checkpoint.state)
    del frames[checkpoint.frame_len :]
    del events[checkpoint.event_len :]
    del trades[checkpoint.trade_len :]
    del step_results[checkpoint.step_len :]
