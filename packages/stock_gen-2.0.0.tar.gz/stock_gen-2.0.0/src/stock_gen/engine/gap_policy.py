from __future__ import annotations

from numpy.random import Generator

from ..config import StockGeneratorConfig
from ..models_size import sample_limit_qty
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import EventType, PlacementMode, Side
from .event_contracts import EventAppender


def enforce_gap_target(
    *,
    ob: OrderBook,
    state: SimulationState,
    cfg: StockGeneratorConfig,
    rng: Generator,
    append_event: EventAppender,
) -> int:
    """Repair inside spread toward the configured target using synthetic limits."""

    _ = state  # frame_runner owns no-trade streak accounting.
    target = int(cfg.book_constraints.target_gap_ticks)
    if target < 0:
        return 0
    if (not ob.allow_locked_book) and target <= 0:
        target = 1

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    if best_bid is None or best_ask is None:
        return 0

    def _append_limit(*, side: Side, price_ticks: int, mode: PlacementMode) -> int:
        qty = sample_limit_qty(cfg=cfg.size, rng=rng, mode=mode)
        order_id = ob.add_limit_resting(side=side, price_ticks=price_ticks, qty=qty)
        append_event(
            event_type=EventType.L_B if side is Side.BID else EventType.L_A,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=order_id,
            synthetic=True,
            reason="gap_repair",
            placement_mode=mode,
            requested_qty=int(qty),
            executed_qty=0,
            resting_qty=int(qty),
        )
        return 1

    spread = int(best_ask - best_bid)
    if spread <= target:
        return 0

    bid_qty = ob.best_qty(Side.BID)
    ask_qty = ob.best_qty(Side.ASK)
    prefer_bid = bid_qty <= ask_qty

    if prefer_bid:
        price_ticks = max(int(best_ask - target), int(ob.min_price_ticks))
        mode = PlacementMode.IMPROVE if price_ticks > best_bid else PlacementMode.JOIN
        if price_ticks <= best_bid:
            return 0
        if (not ob.allow_locked_book and price_ticks >= best_ask) or (ob.allow_locked_book and price_ticks > best_ask):
            return 0
        return _append_limit(side=Side.BID, price_ticks=price_ticks, mode=mode)

    price_ticks = max(int(best_bid + target), int(ob.min_price_ticks))
    mode = PlacementMode.IMPROVE if price_ticks < best_ask else PlacementMode.JOIN
    if price_ticks >= best_ask:
        return 0
    if (not ob.allow_locked_book and price_ticks <= best_bid) or (ob.allow_locked_book and price_ticks < best_bid):
        return 0
    return _append_limit(side=Side.ASK, price_ticks=price_ticks, mode=mode)
