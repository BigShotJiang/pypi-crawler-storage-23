from __future__ import annotations

from typing import Protocol

from ..types import EventType, PlacementMode, Side


class EventAppender(Protocol):
    """Callable contract used by engine policies to append events."""

    def __call__(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
        requested_qty: int | None = None,
        executed_qty: int | None = None,
        resting_qty: int | None = None,
        canceled_qty: int | None = None,
    ) -> None: ...
