from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class StepStats:
    events_user: int = 0
    events_synthetic: int = 0
    events_total: int = 0
    truncated: bool = False
    t_last_event: float | None = None

    def record_loop_event(self, *, t: float, synthetic: bool = False) -> None:
        self.events_user += 1
        if synthetic:
            self.events_synthetic += 1
        self.events_total += 1
        self.t_last_event = float(t)

    def record_synthetic_events(self, *, count: int) -> None:
        n = int(count)
        if n <= 0:
            return
        self.events_synthetic += n
        self.events_total += n
