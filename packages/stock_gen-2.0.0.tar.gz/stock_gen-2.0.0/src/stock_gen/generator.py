"""Public simulator orchestration API."""

from __future__ import annotations

import math

import numpy as np
from numpy.random import Generator

from .config import StockGeneratorConfig
from .engine.depth_policy import apply_depth_maintenance
from .engine.event_handlers import EventDispatcher, EventHandlerContext
from .engine.frame_runner import FrameRunnerContext, run_frame
from .engine.gap_policy import enforce_gap_target
from .engine.spread_control import apply_spread_control
from .engine.snapshot import build_l2_snapshot
from .models_size import sample_limit_qty
from .orderbook import OrderBook
from .runtime import (
    HistoryStore,
    StepCheckpoint,
    capture_step_checkpoint,
    restore_step_checkpoint,
    run_step_transaction,
)
from .sim_policies import should_repair_liquidity
from .sim_state import SimulationState
from .types import (
    Event,
    EventType,
    L2Snapshot,
    MarketHistory,
    PlacementMode,
    Side,
    SimulationResult,
    StepResult,
    Trade,
)


class StockGenerator:
    """Stateful event-driven CLOB simulator."""

    def __init__(self, config: StockGeneratorConfig | None = None) -> None:
        """Create a simulator with the given config or default settings."""

        self._cfg = config or StockGeneratorConfig()
        self._rng: Generator = np.random.default_rng(self._cfg.seed)
        self._ob = self._create_orderbook()
        self._state = SimulationState()
        self._event_dispatcher = self._create_event_dispatcher()
        self._history_store = HistoryStore()

        self._initialize_book()

    def reset(self, seed: int | None = None) -> None:
        """Reset simulator state and history, optionally overriding RNG seed."""

        if seed is None:
            seed = self._cfg.seed
        self._rng = np.random.default_rng(seed)
        self._ob = self._create_orderbook()
        self._state.reset()
        self._event_dispatcher = self._create_event_dispatcher()
        self._history_store.clear()
        self._initialize_book()
        self._apply_liquidity_policy(reason="reset")

    def get_time(self) -> float:
        """Return current simulation time."""

        return float(self._state.t)

    def get_price(self) -> float:
        """Return current mid price in quote units, or NaN when either side is missing."""

        bb = self._ob.best_price_ticks(Side.BID)
        ba = self._ob.best_price_ticks(Side.ASK)
        if bb is None or ba is None:
            return float("nan")
        return ((bb + ba) / 2.0) * float(self._cfg.tick_size)

    def get_best_bid_ask(self) -> tuple[tuple[float, int], tuple[float, int]]:
        """Return best bid/ask as ((price, qty), (price, qty)) in quote units."""

        bb = self._ob.best_price_ticks(Side.BID)
        ba = self._ob.best_price_ticks(Side.ASK)
        bbq = self._ob.best_qty(Side.BID)
        baq = self._ob.best_qty(Side.ASK)
        tick = float(self._cfg.tick_size)
        bid_px = float("nan") if bb is None else float(bb) * tick
        ask_px = float("nan") if ba is None else float(ba) * tick
        return (bid_px, int(bbq)), (ask_px, int(baq))

    def get_l2(self, levels: int | None = None, *, as_ticks: bool = False) -> L2Snapshot:
        """Return current L2 snapshot at requested depth."""

        k = int(self._cfg.depth_levels if levels is None else levels)
        if k <= 0:
            raise ValueError("levels must be positive")
        return build_l2_snapshot(
            ob=self._ob,
            levels=k,
            tick_size=float(self._cfg.tick_size),
            as_ticks=as_ticks,
        )

    def get_events(self) -> tuple[Event, ...]:
        """Return immutable event history."""

        return self._history_store.events()

    def get_trades(self) -> tuple[Trade, ...]:
        """Return immutable trade history."""

        return self._history_store.trades()

    def get_step_results(self) -> tuple[StepResult, ...]:
        """Return immutable per-step result history."""

        return self._history_store.step_results()

    def get_history(self) -> MarketHistory:
        """Return immutable cumulative market history."""

        return self._history_store.history(tick_size=float(self._cfg.tick_size))

    def step(self, dt: float | None = None) -> StepResult:
        """Advance one frame and return step result."""

        if dt is None:
            dt = float(self._cfg.dt)
        if dt <= 0:
            raise ValueError("dt must be positive")

        return run_step_transaction(
            capture_checkpoint=self._capture_step_checkpoint,
            restore_checkpoint=self._restore_step_checkpoint,
            run_step=lambda: self._step_impl(dt=float(dt)),
        )

    def _step_impl(self, *, dt: float) -> StepResult:
        frame_result = run_frame(
            ctx=FrameRunnerContext(
                cfg=self._cfg,
                rng=self._rng,
                ob=self._ob,
                state=self._state,
                event_dispatcher=self._event_dispatcher,
                apply_liquidity_policy=lambda reason: self._apply_liquidity_policy(reason=reason),
                apply_depth_maintenance=self._apply_depth_maintenance,
                apply_gap_enforcement=self._apply_gap_enforcement,
                apply_spread_control=self._apply_spread_control,
                decay_recent_flow=self._decay_recent_flow,
                record_trades=self._record_trades,
                update_last_mid_ticks_from_book=self._update_last_mid_ticks_from_book,
            ),
            dt=dt,
        )
        frame = frame_result.frame
        stats = frame_result.stats
        self._history_store.append_frame(frame)

        step_result = StepResult(
            frame=frame,
            truncated=stats.truncated,
            events_user=stats.events_user,
            events_synthetic=stats.events_synthetic,
            events_total=stats.events_total,
            t_last_event=stats.t_last_event,
        )
        self._history_store.append_step_result(step_result)
        self._state.frame_index += 1
        return step_result

    def gen(self, until_time: float | None = None) -> SimulationResult:
        """Run simulation until target time and return cumulative immutable result."""

        if until_time is None:
            until_time = float(self._cfg.end_time)
        until_time = float(until_time)
        if until_time < self._state.t:
            raise ValueError("until_time must be >= current time")

        while self._state.t < until_time:
            dt = min(float(self._cfg.dt), until_time - self._state.t)
            self.step(dt=dt)

        return SimulationResult(history=self.get_history(), steps=self._history_store.step_results())

    def _capture_step_checkpoint(self) -> StepCheckpoint:
        return capture_step_checkpoint(
            ob=self._ob,
            rng=self._rng,
            state=self._state,
            frame_len=self._history_store.frame_len,
            event_len=self._history_store.event_len,
            trade_len=self._history_store.trade_len,
            step_len=self._history_store.step_len,
        )

    def _restore_step_checkpoint(self, checkpoint: StepCheckpoint) -> None:
        restore_step_checkpoint(
            checkpoint=checkpoint,
            ob=self._ob,
            rng=self._rng,
            state=self._state,
            frames=self._history_store.frames_buffer,
            events=self._history_store.events_buffer,
            trades=self._history_store.trades_buffer,
            step_results=self._history_store.step_results_buffer,
        )
        self._event_dispatcher = self._create_event_dispatcher()

    def _initialize_book(self) -> None:
        tick = float(self._cfg.tick_size)

        if self._cfg.initial_mid_price is None:
            mid_price = float(self._rng.uniform(100.0, 200.0))
        else:
            mid_price = float(self._cfg.initial_mid_price)

        mid_ticks = int(round(mid_price / tick))
        spread_ticks = max(1, int(self._cfg.initial_spread_ticks))
        best_bid = mid_ticks - spread_ticks // 2
        best_ask = best_bid + spread_ticks

        self._state.last_mid_ticks = mid_ticks

        n_lvls = int(self._cfg.init_levels_per_side)
        n_orders = int(self._cfg.init_orders_per_level)

        # Populate both sides around the initial mid. This does not create events/trades.
        for i in range(n_lvls):
            bid_px = best_bid - i
            ask_px = best_ask + i
            for _ in range(n_orders):
                q_bid = sample_limit_qty(cfg=self._cfg.size, rng=self._rng, mode=PlacementMode.DEEP)
                q_ask = sample_limit_qty(cfg=self._cfg.size, rng=self._rng, mode=PlacementMode.DEEP)
                self._ob.add_limit_resting(side=Side.BID, price_ticks=bid_px, qty=q_bid)
                self._ob.add_limit_resting(side=Side.ASK, price_ticks=ask_px, qty=q_ask)

    def _update_last_mid_ticks_from_book(self) -> None:
        best_bid = self._ob.best_price_ticks(Side.BID)
        best_ask = self._ob.best_price_ticks(Side.ASK)
        if best_bid is not None and best_ask is not None:
            self._state.last_mid_ticks = int(round((best_bid + best_ask) / 2.0))

    def _append_event(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
        requested_qty: int | None = None,
        executed_qty: int | None = None,
        resting_qty: int | None = None,
        canceled_qty: int | None = None,
    ) -> None:
        self._history_store.append_event(
            Event(
                seq=self._state.next_event_seq(),
                frame_index=self._state.frame_index,
                t=float(self._state.t),
                event_type=event_type,
                side=side,
                price_ticks=price_ticks,
                qty=qty,
                order_id=order_id,
                synthetic=synthetic,
                reason=reason,
                placement_mode=placement_mode,
                deep_distance=deep_distance,
                replaced_order_id=replaced_order_id,
                requested_qty=requested_qty,
                executed_qty=executed_qty,
                resting_qty=resting_qty,
                canceled_qty=canceled_qty,
            )
        )

    def _record_trades(self, trades: list[Trade]) -> None:
        if not trades:
            return
        self._history_store.extend_trades(trades)
        signed = sum(tr.qty for tr in trades) * (1.0 if trades[0].aggressor is Side.BID else -1.0)
        self._state.recent_flow += float(signed)

    def _apply_liquidity_policy(self, *, reason: str) -> int:
        bb = self._ob.best_price_ticks(Side.BID)
        ba = self._ob.best_price_ticks(Side.ASK)
        has_bid = bb is not None
        has_ask = ba is not None

        if not should_repair_liquidity(
            policy=self._cfg.liquidity_policy,
            has_bid=has_bid,
            has_ask=has_ask,
            reason=reason,
        ):
            return 0

        bb_anchor, ba_anchor = self._anchor_bests()
        inserted = 0

        if bb is None:
            qty = sample_limit_qty(cfg=self._cfg.size, rng=self._rng, mode=PlacementMode.JOIN)
            order_id = self._ob.add_limit_resting(side=Side.BID, price_ticks=bb_anchor, qty=qty)
            self._append_event(
                event_type=EventType.L_B,
                side=Side.BID,
                price_ticks=int(bb_anchor),
                qty=int(qty),
                order_id=int(order_id),
                synthetic=True,
                reason=reason,
                placement_mode=PlacementMode.JOIN,
                requested_qty=int(qty),
                executed_qty=0,
                resting_qty=int(qty),
            )
            inserted += 1

        if ba is None:
            qty = sample_limit_qty(cfg=self._cfg.size, rng=self._rng, mode=PlacementMode.JOIN)
            order_id = self._ob.add_limit_resting(side=Side.ASK, price_ticks=ba_anchor, qty=qty)
            self._append_event(
                event_type=EventType.L_A,
                side=Side.ASK,
                price_ticks=int(ba_anchor),
                qty=int(qty),
                order_id=int(order_id),
                synthetic=True,
                reason=reason,
                placement_mode=PlacementMode.JOIN,
                requested_qty=int(qty),
                executed_qty=0,
                resting_qty=int(qty),
            )
            inserted += 1
        return inserted

    def _apply_depth_maintenance(self) -> int:
        return apply_depth_maintenance(
            ob=self._ob,
            state=self._state,
            cfg=self._cfg,
            anchor_bests=self._anchor_bests,
            append_event=self._append_event,
        )

    def _apply_gap_enforcement(self) -> int:
        return enforce_gap_target(
            ob=self._ob,
            state=self._state,
            cfg=self._cfg,
            rng=self._rng,
            append_event=self._append_event,
        )

    def _apply_spread_control(self) -> int:
        return apply_spread_control(
            ob=self._ob,
            state=self._state,
            cfg=self._cfg,
            rng=self._rng,
            append_event=self._append_event,
        )

    def _create_orderbook(self) -> OrderBook:
        return OrderBook(
            min_price_ticks=int(self._cfg.book_constraints.min_price_ticks),
            allow_locked_book=bool(self._cfg.book_constraints.allow_locked_book),
        )

    def _anchor_bests(self) -> tuple[int, int]:
        bb = self._ob.best_price_ticks(Side.BID)
        ba = self._ob.best_price_ticks(Side.ASK)

        spread = max(1, int(self._cfg.initial_spread_ticks))
        if bb is not None and ba is not None:
            return int(bb), int(ba)

        if self._state.last_mid_ticks is None:
            self._state.last_mid_ticks = 10_000

        mid = int(self._state.last_mid_ticks)
        if bb is None and ba is None:
            best_bid = mid - spread // 2
            best_ask = best_bid + spread
            return best_bid, best_ask
        if bb is None:
            if ba is None:
                raise RuntimeError("inconsistent order book state: ask anchor missing")
            best_ask = int(ba)
            best_bid = best_ask - spread
            return best_bid, best_ask

        best_bid = int(bb)
        best_ask = best_bid + spread
        return best_bid, best_ask

    def _create_event_dispatcher(self) -> EventDispatcher:
        return EventDispatcher(
            EventHandlerContext(
                cfg=self._cfg,
                rng=self._rng,
                ob=self._ob,
                state=self._state,
                anchor_bests=self._anchor_bests,
                append_event=self._append_event,
            )
        )

    def _decay_recent_flow(self, delta_t: float) -> None:
        hl = float(self._cfg.flow_half_life)
        if hl <= 0.0:
            return
        decay = math.exp(-math.log(2.0) * float(delta_t) / hl)
        self._state.recent_flow *= decay
