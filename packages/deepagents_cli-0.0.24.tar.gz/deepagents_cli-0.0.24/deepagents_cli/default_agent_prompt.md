# Project Notes

This file is for tracking project-specific context as you work.
You can update this file to remember decisions, patterns, and context about this project.

## Architecture Notes

(Add notes about project structure, key files, patterns as you discover them)

## Decisions

(Track important decisions and their rationale)
