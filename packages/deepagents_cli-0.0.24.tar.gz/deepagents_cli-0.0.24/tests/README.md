# Deep Agents CLI Tests

## API Keys

### Required

- **`ANTHROPIC_API_KEY`** - Required for integration tests that use Anthropic models

### Optional

- **`LANGSMITH_API_KEY`** or **`LANGCHAIN_API_KEY`** - Enables LangSmith tracing for test runs
