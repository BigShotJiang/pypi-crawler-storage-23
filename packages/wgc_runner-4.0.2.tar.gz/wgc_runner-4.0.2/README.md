# wgc-runner

Pytest plugin and fixtures for running WGC QA tests. Manages the full test lifecycle: build download, mock server startup, WGC installation, test execution, artifact collection.

## Pytest Plugin

Registered as `wgc_plugin` via `pytest11` entry point. Activated automatically when installed.

### CLI Options

```bash
py.test tests/ \
  --wgc "\\share\builds\wgc\latest" \
  --wgc-build "12345" \
  --wgc-branch "release/1.0" \
  --wgc-arch "x64" \
  --wgc-publisher "wargaming" \
  --video-capture \
  --no-sanity-check
```

| Option | Description |
|---|---|
| `--wgc` | Path to WGC build on shared drive |
| `--wgc-build` | Build number |
| `--wgc-branch` | Git branch |
| `--wgc-arch` | Architecture: `win32` or `x64` |
| `--wgc-publisher` | Publisher: `wargaming`, `steam`, `qihoo` |
| `--video-capture` | Enable screen recording for each test |
| `--no-sanity-check` | Skip WGC sanity check before test session |
| `--testrail` | Enable TestRail reporting |

### Lifecycle Hooks

| Hook | What it does |
|---|---|
| `pytest_cmdline_main` | Download WGC build, start mock server, install WGC |
| `pytest_configure` | Initialize TestRail API, setup config |
| `pytest_runtest_setup` | Prepare environment before each test |
| `pytest_runtest_teardown` | Crash detection, collect logs/video/screenshots, terminate WGC |
| `pytest_collection_modifyitems` | Auto-assign `folder_*` markers by test directory |

### Key Features

- **Auto build download** from shared drive
- **Mock server** startup/shutdown around test session
- **Video recording** — each test recorded via OpenCV
- **Crash detection** — automatic WGC crash check after every test
- **Sanity check** — WGC startup verification before test session
- **Artifact upload** — logs, video, screenshots uploaded to share
- **Auto markers** — `folder_arsenal_login1`, `folder_game_install2`, etc.

## Fixtures

All fixtures are session or function-scoped and available automatically:

| Fixture | Scope | Provides |
|---|---|---|
| `wgc_client` | session | `WGCClient` instance |
| `config` | session | `WGCConfig` instance |
| `wgc_settings` | session | `WGCSettingsHelper` |
| `fake_games` | session | `FakeGamesHelper` |
| `os_helper` | session | `OSHelper` |
| `registry` | session | `RegistryHelper` |
| `browser` | session | `BrowserHelper` |
| `screen` | session | `ScreenHelper` |
| `firewall` | session | `FireWallHelper` |
| `encrypt` | session | `EncryptHelper` |
| `cmd_helper` | session | `CmdHelper` |
| `event_listener` | session | `EventHelper` |
| `wgc_installer` | session | `WGCInstaller` |
| `wgc_uninstaller` | session | `WGCUninstaller` |
| `soft_assert` | function | `SoftAssert` |
| `wgni_users_db` | session | `WGNIUsersDB` |

### Arsenal Fixtures

Additional fixtures for Arsenal UI tests (shop, products, billing):

```python
def test_buy_item(arsenal_shop_page, arsenal_product_list):
    # arsenal_shop_page and arsenal_product_list are auto-configured
    arsenal_shop_page.open_product(arsenal_product_list[0])
```

## Install

```bash
pip install wgc-runner
```

This will pull all WGC packages transitively.

## Dependencies

All WGC packages + `pytest>=7.0`, `pytest-timeout`, `pyhamcrest`
