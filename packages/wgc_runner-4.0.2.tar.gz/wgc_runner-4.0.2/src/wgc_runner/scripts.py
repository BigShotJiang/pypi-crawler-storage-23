﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from os import path
from random import choice

from clippy.helpers.testrail_api import TestRail
from wgc_core.config import WGCConfig


def assign_cases():
    import sys
    testrail_credentials = [WGCConfig.testrail.url, WGCConfig.testrail.user, WGCConfig.testrail.password]
    project_id = WGCConfig.testrail.project_id
    test_rail = TestRail(*(testrail_credentials + [project_id]))
    plan_id = sys.argv[1]
    plan = test_rail.test_plans.get_plan(plan_id)
    users_email = ['n_kovganko@wargaming.net']
    users = {}
    for email in users_email:
        users[email] = test_rail.users.get_user_by_email(email).get('id')

    for entry in plan.get('entries'):
        for run in entry.get('runs'):
            cases = test_rail.test_cases.get_cases(project_id, suite_id=run.get('suite_id'))
            for case in cases:
                try:
                    test_rail.test_result.add_result_for_case(
                        run.get('id'), case.get('id'), assignedto_id=choice(list(users.values())))
                except ConnectionError:
                    try:
                        test_rail.test_result.add_result_for_case(
                            run.get('id'), case.get('id'), assignedto_id=choice(list(users.values())))
                    except ConnectionError:
                        continue


def get_empty_cases():

    result = {}
    testrail_credentials = [WGCConfig.testrail.url, WGCConfig.testrail.user, WGCConfig.testrail.password]
    project_id = WGCConfig.testrail.project_id
    test_rail = TestRail(*(testrail_credentials + [project_id]))

    testrail_suites = {suite['name']: suite['id'] for suite in
                       test_rail.test_suites.get_suites(project_id)}

    for suite in testrail_suites.keys():
        suite_id = testrail_suites[suite]
        print('Suite_ID: %s' % suite_id)
        print('Check %s suite...' % suite)
        if 'Automation' not in suite and (
                suite.startswith('1') or suite.startswith('2')):
            test_cases = \
                test_rail.test_cases.get_cases(project_id, suite_id=suite_id)
            for case in test_cases:
                test_case_desc = case['custom_steps']
                if (test_case_desc == '' or test_case_desc is None) and case['custom_autostatus'] != 3:
                    created = test_rail.users.get_user(case['created_by'])
                    text = 'https://testrail.wargaming.net/web/index.php?/cases/view/%s' % case['id'] + \
                           '  -  ' + created['name']
                    if created['name'] in result:
                        result[created['name']].append(text)
                    else:
                        result[created['name']] = [text]
    print(r"""
                                                  ,Pasha
                                                ,o
        ========== THE KRAKEN TEAM ========     :o
                       _....._                  `:o
                     .'       ``-.                \o
                    /  _      _   \                \o
                   :  /*\    /*\   )                ;o
          Luyda    |  \_/    \_/   /        Vova     ;o
                   (       U      /                 ;o
                    \  (\_____/) /                  /o
                     \   \_m_/  (                  /o
                      \         (                ,o:
                      )          \,           .o;o'           ,o'o'o.
                    ./          /\o;o,,,,,;o;o;''         _,-o,-'''-o:o.
     Kolya      ./o./)        \    'o'o'o''         _,-'o,o'         Max
     o           ./o./ /       .o \.              __,-o o,o'
     \o.       ,/o /  /o/)     | o o'-..____,,-o'o o_o-'
     `o:o...-o,o-' ,o,/ |     \   'o.o_o_o_o,o--''
     .,  ``o-o'  ,.oo/   'o /\.o`.
     `o`o-....o'o,-'   /o /   \o \.                       ,o..         o
    Andrey o-o.o--    /o /      \o.o--..          ,,,o-o'o.--o:o:o,,..:Sasha
                     (oo(          `--o.o`o---o'o'o,o,-'''        o'o'o
                      \ o\              ``-o-o''''
       ,-o;Lesha     \o \
      /o/               )o )
     (o(               /o /
      \o\.       ...-o'o /
        \o`o`-o'o o,o,--'
          ```o--''' """)
    empty_cases = path.join(path.dirname(path.dirname(path.dirname(__file__))), 'empty_cases.txt')
    with open(empty_cases, 'w', encoding='utf-8') as fp:
        for test in result.keys():
            text = '\r\n' + test + ' - ' + str(len(result[test])) + '\r\n'
            print(text)
            fp.write(text + '\n')
            for t in result[test]:
                print(t)
                fp.write(t + '\n')
