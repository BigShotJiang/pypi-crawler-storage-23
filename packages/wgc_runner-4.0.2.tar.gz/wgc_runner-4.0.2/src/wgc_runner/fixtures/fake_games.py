﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from typing import Type

from pytest import fixture

from wgc_helpers.fake_games import FakeGamesHelper


@fixture(scope='session')
def fake_games() -> Type[FakeGamesHelper]:
    """
    Fixture that provides access to fake games helper.
    """
    return FakeGamesHelper
