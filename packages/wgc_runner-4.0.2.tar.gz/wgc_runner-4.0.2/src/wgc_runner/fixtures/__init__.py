# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

# all files in this folder will be loaded and registered as fixture modules.
