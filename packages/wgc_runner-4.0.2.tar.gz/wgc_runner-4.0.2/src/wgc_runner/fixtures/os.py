﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_helpers.os_helper import OSHelper


@fixture(scope='session')
def os_helper():
    return OSHelper
