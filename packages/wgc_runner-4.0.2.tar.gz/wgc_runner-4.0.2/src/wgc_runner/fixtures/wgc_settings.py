﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_helpers.wgc_settings import WGCSettingsHelper


@fixture(scope='session')
def wgc_settings():
    """
    Fixture that provides access to WGC settings.
    """
    return WGCSettingsHelper
