﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_helpers.ui_map_parser import UIMapParser


@fixture(scope='session')
def ui_map_parser():
    """
    Fixture that provides access to UI map parser.
    """
    ui_parser = UIMapParser()
    return ui_parser
