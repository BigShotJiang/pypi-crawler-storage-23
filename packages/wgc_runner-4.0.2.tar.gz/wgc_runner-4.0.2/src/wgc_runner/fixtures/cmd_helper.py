﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from clippy.helpers.cmd_helper import CmdHelper


@fixture(scope='session')
def cmd_helper():
    return CmdHelper
