﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_core.config import WGCConfig


@fixture(scope='session')
def wgc_config():
    """
    Fixture that provides access to WGC config.
    """
    return WGCConfig
