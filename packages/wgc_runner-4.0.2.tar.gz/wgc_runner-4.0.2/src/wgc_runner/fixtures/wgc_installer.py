﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import pytest

from wgc_helpers.wgc_installer import WGCInstaller


@pytest.fixture(scope='session')
def wgc_installer():
    return WGCInstaller
