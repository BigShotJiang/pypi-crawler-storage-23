﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.firewall_helper import FileWallHelper


@fixture(scope='session')
def firewall_helper():
    return FileWallHelper
