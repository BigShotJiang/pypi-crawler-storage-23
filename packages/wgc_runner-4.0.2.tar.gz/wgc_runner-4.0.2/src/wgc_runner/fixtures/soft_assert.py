﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import pytest
from wgc_helpers.soft_assert import SoftAssert


@pytest.fixture
def soft_assert(request):
    """
    Provides a SoftAssert instance with automatic finalization.

    Usage in tests:
        def test_example(soft_assert):
            soft_assert.check(actual, equal_to(expected), 'Description')
            soft_assert.check_true(ok, 'Must be true')
            # assert_all() is called automatically after yield
    """
    sa = SoftAssert(request)
    yield sa
    sa.assert_all()
