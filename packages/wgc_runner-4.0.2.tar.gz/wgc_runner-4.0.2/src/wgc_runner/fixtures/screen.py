﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.screen_helper import ScreenHelper


@fixture(scope='session')
def screen_helper():
    return ScreenHelper
