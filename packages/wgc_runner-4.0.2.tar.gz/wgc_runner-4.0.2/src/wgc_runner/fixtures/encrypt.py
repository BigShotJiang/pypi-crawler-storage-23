﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.encrypt_helper import EncryptHelper


@fixture(scope='session')
def encrypt_helper():
    return EncryptHelper
