﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import pytest

from wgc_helpers.wgc_uninstaller import WGCUninstaller


@pytest.fixture(scope='session')
def wgc_uninstaller():
    return WGCUninstaller
