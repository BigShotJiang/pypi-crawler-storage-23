﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.wnc_notification import WNCNotificationHelper


@fixture(scope='session')
def wnc_helper():
    return WNCNotificationHelper
