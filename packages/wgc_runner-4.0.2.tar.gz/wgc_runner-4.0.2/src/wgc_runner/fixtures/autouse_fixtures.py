﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from os import path

import pytest

from wgc_core.config import WGCConfig
from wgc_mocks import GameMocks

_sanity_check = None if WGCConfig.sanity_check else True
session_running_fixture = []


@pytest.fixture(scope='function', autouse=True)
def prepare_wgc_before_test_run(wgc_client):
    """
    Fixture to terminate WGC process and copy WGC from sources.
    """
    wgc_client.prepare_wgc_before_test_run()


@pytest.fixture(scope='session', autouse=True)
def auto_prepare_environment(firewall_helper, wgc_config, dbgdiag_helper):
    GameMocks.enable()
    if auto_prepare_environment not in session_running_fixture:
        if wgc_config.dbg_diag.dbg_diag_enabled:
            dbgdiag_helper.copy_config()
            dbgdiag_helper.stop_service()
            dbgdiag_helper.start_service()
        firewall_helper.start_service()

        firewall_helper.delete_rule_by_name(
            wgc_config.application.firewall_rule_name)
        firewall_helper.add_rule(path.join(
            wgc_config.application.folder, wgc_config.application.binary_name),
            wgc_config.application.firewall_rule_name)
        firewall_helper.add_rule(path.join(
            wgc_config.games.folder, wgc_config.application.binary_name),
            wgc_config.application.firewall_rule_name)

        if not wgc_config.local_debug:
            firewall_helper.disable_firewall()
        session_running_fixture.append(auto_prepare_environment)
    yield
    GameMocks.disable()
