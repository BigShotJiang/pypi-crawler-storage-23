﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_helpers.event_helper import EventHelper


@fixture(scope='function')
def event_listener():
    EventHelper.enable()
    yield EventHelper
    EventHelper.log_to_file()
    EventHelper.disable()


@fixture(scope='function')
def event_listener_last_write():
    flags_last_write = 16
    EventHelper.enable(flags=flags_last_write)
    yield EventHelper
    EventHelper.disable()
