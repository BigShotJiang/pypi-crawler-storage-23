﻿# -*- coding: utf-8 -*-

"""
Shared fixtures for Arsenal test suites (buy_items1, buy_items2, etc.).

Usage in conftest.py of each test suite:
    from wgc_runner.fixtures.arsenal_fixtures import *

This eliminates fixture duplication across multiple arsenal test directories.
"""

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import pytest
from os import path

from aiohttp import web
from hamcrest import assert_that, equal_to, has_length, is_not, empty

from wgc_helpers.waiter import Waiter
from wgc_mocks import GameMocks
from wgc_mocks.wgcps.commerce_fetch_product_list_personal import CommerceFetchProductListPersonal
from wgc_mocks.wgcps.fetch_client_payment_methods import FetchClientPaymentMethods
from wgc_mocks.wgcps.fetch_storefront_categories_v2 import CommerceFetchStorefrontCategoriesV2
from wgc_mocks.wgcps.fetch_storefront_categories_v7 import CommerceFetchStorefrontCategoriesV7
from wgc_mocks.wgcps.get_account_tsv_method import GetAccountTsvMethod
from wgc_mocks.wgcps.get_game_page_category import GetGamePageCategory
from wgc_mocks.wgcps.get_geo_data import GetGeoData
from wgc_mocks.wgcps.purchase_product_commit import PurchaseProductCommit
from wgc_mocks.wgcps.purchase_product_prepare import PurchaseProductPrepare
from wgc_mocks.wgcps.purchase_zero_product_prepare import PurchaseZeroProductPrepare
from wgc_mocks.wgcps.set_billing_address import SetBillingAddress
from wgc_mocks.wgni.methods.account import AccountInfoV3
from wgc_pages import PageArsenalCommon, PageArsenalInstalledGame, PageArsenalProfile
from wgc_pages.page_arsenal_shop import PageArsenalShop


# ============================================================================
# Error Fixture Factory
# ============================================================================

def _make_error_fixture(target_cls, status, response_body):
    """
    Factory for creating mock error fixtures.

    Creates a pytest fixture that patches target_cls._on_post to return
    a fixed error response, and restores the original after the test.

    Args:
        target_cls: The mock class whose _on_post will be patched.
        status: HTTP status code to return.
        response_body: dict to return as JSON response.

    Returns:
        A pytest fixture function.
    """
    @pytest.fixture
    def _fixture():
        original = target_cls._on_post

        async def error_handler(ins):
            return web.json_response(response_body, status=status)

        target_cls._on_post = error_handler
        yield original
        target_cls._on_post = original

    return _fixture


def _make_platform_error_fixture(target_cls, result_code, status=500):
    """
    Factory for platform_error-type fixtures.

    Creates a fixture that returns a standardized WGCPS platform error
    with the specified result_code.
    """
    return _make_error_fixture(target_cls, status, {
        "status": "error",
        "data": {
            "header": {
                "message-id": "c6976f5b-61d9-4407-9637-b926d00cb1e6",
                "tracking-id": "cf9ffc0b-a6a6-46f9-ab20-67eeb43d9a36"
            }
        },
        "errors": [{
            "code": "platform_error",
            "context": {"result_code": result_code}
        }]
    })


# ============================================================================
# Standard error body constants
# ============================================================================

UNAUTHORIZED_BODY = {'status': 'error', 'errors': [{'code': 'unauthorized'}]}

INTERNAL_ERROR_BODY = {"status": "error", "errors": [{
    "code": "platform_error", "context": {"result_code": "INTERNAL_ERROR"}}]}

PAYMENT_NOT_EXIST_BODY = {"status": "error", "errors": [{
    "code": "platform_error", "context": {"result_code": "PAYMENT_METHOD_DOESNOT_EXIST"}}]}


# ============================================================================
# 401 Unauthorized fixtures (generated via factory)
# ============================================================================

error_401_commerce_info = _make_error_fixture(
    GetAccountTsvMethod, 401, UNAUTHORIZED_BODY)

error_401_prepare_purchase = _make_error_fixture(
    PurchaseProductPrepare, 401, UNAUTHORIZED_BODY)

error_401_commit_purchase = _make_error_fixture(
    PurchaseProductCommit, 401, UNAUTHORIZED_BODY)

error_401_geo_data = _make_error_fixture(
    GetGeoData, 401, UNAUTHORIZED_BODY)

error_401_set_billing = _make_error_fixture(
    SetBillingAddress, 401, UNAUTHORIZED_BODY)


# ============================================================================
# 500 Platform Error fixtures (generated via factory)
# ============================================================================

invalid_otp = _make_platform_error_fixture(
    PurchaseProductCommit, 'TSV_INVALID_OTP_CODE')

# Alias for backward compatibility (identical to invalid_otp)
banner_error_otp = _make_platform_error_fixture(
    PurchaseProductCommit, 'TSV_INVALID_OTP_CODE')

user_profile_not_completed = _make_platform_error_fixture(
    PurchaseProductPrepare, 'USER_PROFILE_NOT_COMPLETED')

order_error = _make_platform_error_fixture(
    PurchaseProductCommit, 'ORDER_PROCESSING_ERROR')

payment_method_not_exist = _make_error_fixture(
    FetchClientPaymentMethods, 500, PAYMENT_NOT_EXIST_BODY)

prepare_zero_500 = _make_error_fixture(
    PurchaseZeroProductPrepare, 500, INTERNAL_ERROR_BODY)

prepare_zero_401 = _make_error_fixture(
    PurchaseZeroProductPrepare, 401, UNAUTHORIZED_BODY)


# ============================================================================
# get_game_page_category_500 — specific to buy_items2 but kept here for sharing
# ============================================================================

@pytest.fixture
def get_game_page_category_500():
    on_post = GetGamePageCategory._on_post

    async def new_on_post(ins):
        await asyncio.sleep(4)
        return web.json_response(
            {"status": "error", "errors": [{"code": "retry", "context": {"interval": 5}}]},
            status=500)

    GetGamePageCategory._on_post = new_on_post
    yield on_post
    GetGamePageCategory._on_post = on_post


# ============================================================================
# Restore fixtures
# ============================================================================

@pytest.fixture
def restore_prepare():
    """Saves and restores PurchaseProductPrepare._on_post."""
    on_post = PurchaseProductPrepare._on_post
    yield on_post
    PurchaseProductPrepare._on_post = on_post


@pytest.fixture
def restore():
    """
    Comprehensive restore fixture covering all commonly patched handlers.

    Saves original handlers and restores them after the test.
    Yields tuple: (getAccountTsvMethod, preparePurchase, commitPurchase)
    for backward compatibility with existing tests.
    """
    getAccountTsvMethod = GetAccountTsvMethod._on_post
    preparePurchase = PurchaseProductPrepare._on_post
    commitPurchase = PurchaseProductCommit._on_post
    page_category = GetGamePageCategory._on_post
    default_info = AccountInfoV3._on_post
    def_billing = SetBillingAddress._on_post
    fetch_categories_v2 = CommerceFetchStorefrontCategoriesV2._on_post
    fetch_categories_v7 = CommerceFetchStorefrontCategoriesV7._on_post
    fetch_products = CommerceFetchProductListPersonal._on_post

    yield getAccountTsvMethod, preparePurchase, commitPurchase

    GetAccountTsvMethod._on_post = getAccountTsvMethod
    PurchaseProductPrepare._on_post = preparePurchase
    PurchaseProductCommit._on_post = commitPurchase
    GetGamePageCategory._on_post = page_category
    AccountInfoV3._on_post = default_info
    SetBillingAddress._on_post = def_billing
    CommerceFetchStorefrontCategoriesV2._on_post = fetch_categories_v2
    CommerceFetchStorefrontCategoriesV7._on_post = fetch_categories_v7
    CommerceFetchProductListPersonal._on_post = fetch_products


# ============================================================================
# Helper class for shared test setup and assertion patterns
# ============================================================================

class ArsenalTestHelpers:
    """
    Shared setup and assertion helpers for Arsenal tests.

    Eliminates duplicated setup blocks and assertion patterns
    across test files.
    """

    @staticmethod
    def setup_standard_product(wgni_users_db, account, count=1, **kwargs):
        """
        Creates standard buy products + entitlements.

        Args:
            wgni_users_db: Users DB fixture.
            account: Account object.
            count: Number of products to create.
            **kwargs: Additional product params (price_type, limited_quantity, etc.)

        Returns:
            list: Created product objects.
        """
        products = []
        defaults = dict(
            buy_item=True,
            title_code=GameMocks.title_id,
            product_code='BUY_WOT_ITEM'
        )
        defaults.update(kwargs)

        for i in range(count):
            name = kwargs.get('name', f'World of {i} tanks')
            lang = kwargs.get('lang', 'en')
            app_id = kwargs.get('app_id', 'WOT.RU.PRODUCTION')

            product = wgni_users_db.add_product(
                name, lang, app_id,
                GameMocks.game_update_url,
                **{k: v for k, v in defaults.items()
                   if k not in ('name', 'lang', 'app_id')})
            products.append(product)

            storefront = kwargs.get('storefront_name', None)
            wgni_users_db.add_entitlements(
                account.id, 'shop', product.link_id,
                GameMocks.title_id, storefront)

        return products

    @staticmethod
    def setup_billing(wgni_users_db, applicable=True, mandatory=False,
                      available=True):
        """
        Configures billing settings.

        Args:
            wgni_users_db: Users DB fixture.
            applicable: Whether billing is applicable.
            mandatory: Whether billing is mandatory.
            available: Whether billing info is available.
        """
        wgni_users_db.billing_info_available = available
        wgni_users_db.billing_applicable = applicable
        wgni_users_db.billing_mandatory = mandatory

    @staticmethod
    def launch_and_open_premium_shop(wgc_client, fake_games, os_helper,
                                     account, game_path):
        """
        Standard flow: launch WGC → select game → verify login →
        play → wait for game → open storefront.

        This is the repetitive ~30-line setup block that appears
        in 20+ tests in test_arsenal_premium_shop.py.

        Args:
            wgc_client: WGC client fixture.
            fake_games: Fake games fixture.
            os_helper: OS helper fixture.
            account: Account object.
            game_path: Path to the fake game directory.
        """
        wgc_client.create_user_info(account)
        wgc_client.run_game_center()
        PageArsenalCommon.select_game_page('WOT')
        PageArsenalCommon.open_user_profile_page()
        Waiter.poll(20, PageArsenalProfile.is_account_balance_loaded,
                    'Expected that shown account balance.')
        Waiter.poll(3, PageArsenalProfile.is_username_in_profile_displayed,
                    'Expected that User is logged in.')
        PageArsenalCommon.close_dialog()
        PageArsenalInstalledGame.click_play()
        Waiter.poll(20, fake_games.is_fake_game_running,
                    'Expected that dummy game will be running.')
        Waiter.poll(15, lambda: 'StoreRememberMeToken return WG_S_OK' in
                    os_helper.get_file_content(
                        path.join(game_path, 'dummy_game.log')),
                    'Expected that game has been launched.')
        assert_that(fake_games.start_dummy(
            game_path, copy_exe=False,
            params=' --open-storefront',
            wait_return_code=True), equal_to('WG_S_OK'))
        Waiter.poll(10, PageArsenalShop.is_storefront_displayed,
                    'Expected that storefront is displayed.')

    @staticmethod
    def standard_purchase_flow(product_code, select_method=0):
        """
        Performs the standard purchase flow:
        click item → payment page → select method → continue → continue(confirm).

        Args:
            product_code: Product code to purchase.
            select_method: Index of payment method to select (default 0).
        """
        PageArsenalShop.click_purchase_item_in_storefront(product_code)
        Waiter.poll(7, PageArsenalShop.is_payment_page_displayed,
                    'Expected that opened payment page.')
        PageArsenalShop.select_payment_method(select_method)
        PageArsenalShop.click_continue_or_purchase()
        Waiter.poll(7, PageArsenalShop.is_payment_page_displayed)
        PageArsenalShop.click_continue_or_purchase()

    @staticmethod
    def assert_choose_product_stats(soft_assert=None, expected_count=1,
                                     redirected=False, result='success',
                                     game_app_id='WOT.RU.PRODUCTION'):
        """
        Asserts wgc_choose_game_product_v1 statistics request.

        With soft_assert: records non-fatal failures.
        Without soft_assert: uses hard assert_that.

        Args:
            soft_assert: Optional SoftAssert instance for soft checks.
            expected_count: Expected number of requests.
            redirected: Expected redirected_to_web value.
            result: Expected result value.
            game_app_id: Expected game_app_id value.

        Returns:
            list: Found requests.
        """
        requests = Waiter.poll(3, lambda: GameMocks.find_requests(
            '/statistic/v2/wgc_choose_game_product_v1'))

        if soft_assert:
            soft_assert.check(requests, has_length(expected_count),
                              'wgc_choose_game_product_v1 request count')
            if requests:
                body = requests[0].params.get('body')
                soft_assert.check(body.get('product_id'), is_not(empty()),
                                  'product_id should not be empty')
                soft_assert.check(body.get('redirected_to_web'), equal_to(redirected),
                                  'redirected_to_web check')
                soft_assert.check(body.get('result'), equal_to(result),
                                  'result check')
                soft_assert.check(body.get('game_app_id'), equal_to(game_app_id),
                                  'game_app_id check')
                soft_assert.check(body.get('buy_transaction_id'), is_not(empty()),
                                  'buy_transaction_id should not be empty')
        else:
            assert_that(requests, has_length(expected_count))
            if requests:
                body = requests[0].params.get('body')
                assert_that(body.get('product_id'), is_not(empty()))
                assert_that(body.get('redirected_to_web'), equal_to(redirected))
                assert_that(body.get('result'), equal_to(result))
                assert_that(body.get('game_app_id'), equal_to(game_app_id))
                assert_that(body.get('buy_transaction_id'), is_not(empty()))

        return requests
