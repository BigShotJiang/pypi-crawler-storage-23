﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import pytest

from wgc_mocks.wgni import WGNIUsersDB


@pytest.fixture(scope='session')
def wgni_users_db():
    return WGNIUsersDB
