﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.registry import RegistryHelper


@fixture(scope='session')
def registry_helper():
    return RegistryHelper
