﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from pytest import fixture

from wgc_helpers.dbgdiag_helper import DbgDiagHelper


@fixture(scope='session')
def dbgdiag_helper():
    return DbgDiagHelper
