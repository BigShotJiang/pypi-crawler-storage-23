﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_core.logger import get_logger


@fixture(scope='session')
def log():
    """
    Fixture that provides access to logger.
    """
    return get_logger()
