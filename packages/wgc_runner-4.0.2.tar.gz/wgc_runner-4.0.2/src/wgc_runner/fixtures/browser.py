﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from pytest import fixture

from wgc_helpers.browser_helper import BrowserHelper


@fixture(scope='session')
def browser_helper():
    return BrowserHelper
