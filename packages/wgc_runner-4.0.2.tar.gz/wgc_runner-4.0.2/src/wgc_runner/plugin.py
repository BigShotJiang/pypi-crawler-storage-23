﻿# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import asyncio
import atexit
import ctypes
import glob
import hashlib
import importlib
import json
import logging
import os
import random
import re
import signal
import string
import sys
import threading
import traceback
import winreg
from datetime import datetime
from os import path, environ, getenv
from pathlib import Path
from pkgutil import iter_modules
from random import choice
from string import ascii_lowercase
from time import time, sleep
from urllib.error import HTTPError
from urllib.parse import urljoin

import pytest
import requests
import yaml

from wgc_runner import fixtures
from wgc_client import WGCClient
from clippy.helpers.cmd_helper import CmdHelper
from clippy.helpers.testrail_api import TestRail, Priorities, \
    CaseTypes, CaseFields
from wgc_core.config import WGCConfig
from wgc_core.exceptions import WGCException
from wgc_helpers.artifacts_helper import ArtifactsHelper
from wgc_helpers.black_screen_detector import BlackScreenSearch
from wgc_helpers.browser_helper import BrowserHelper
from wgc_helpers.dump_helper import DumpHelper
from wgc_helpers.event_helper import EventHelper
from wgc_helpers.localization_helper import Localization
from wgc_helpers.os_helper import OSHelper
from wgc_helpers.registry import RegistryHelper
from wgc_helpers.requirements_helper import RequirementHelper
from wgc_helpers.screen_helper import ScreenHelper
from wgc_helpers.sys_internals import SysInternalsHelper
from wgc_helpers.testdata_helper import TestDataHelper
from wgc_helpers.video_capture import VideoCaptureHelper
from wgc_helpers.waiter import Waiter
from wgc_helpers.wgc_settings import WGCSettingsHelper
from wgc_helpers.winapi_helper import WinApi
from wgc_core.logger import get_logger, log_config_path
from wgc_core.logger.handlers import TestDependentRotatingFileHandler, \
    StepsToReproduceFileHandler, DistributeRotatingFileHandler, \
    MocksRotatingFileHandler, ProductHashRotatingFileHandler, MocksRespRotatingFileHandler
from wgc_mocks import GameMocks
from wgc_third_party import get_third_party_path

asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
log = get_logger()


class WGCPluginError(WGCException):
    """WGC plugin error"""


class WGCRunnerPlugin(object):
    """
        The main plugin for WGC testing framework integration with pytest.
        This plugin configures the test environment, manages the test lifecycle,
        and provides WGC-specific data to other plugins, such as the testhide reporter.
        """
    test_sections = None
    test_priorities = None
    autostatuses = None
    suite_id = None
    test_rail = None
    test_case_types = None
    enabled = False
    os_item_suffix = '[%s]' % OSHelper.get_full_os_name().replace(' ', '_')
    start_test = datetime.now()
    stop_test = datetime.now()
    check_crashes = True
    wgc_info = ''
    is_single_test_job = False
    suite_name = None
    tests_count = 0
    label = 'wgc_regression'
    testrail_suites = None
    elapsed_tests = 0
    relaunched_tests = {}
    sanity_files = []
    _cleanup_done = False
    _cleanup_lock = threading.Lock()
    _console_ctrl_handler = None
    lock_file = 'session.lock'
    
    @classmethod
    def create_lock_file(cls):
        OSHelper.create_file(cls.lock_file, str(os.getpid()))
    
    @classmethod
    def _cleanup(cls, reason=""):
        with cls._cleanup_lock:
            if cls._cleanup_done:
                return
            log.info(f"Cleanup on: {reason}")
            try:
                WGCClient.terminate_all_wgc_related_processes()
            except Exception as e:
                log.exception(e)
            cls._cleanup_done = True
    
    @classmethod
    def _install_termination_hooks(cls):
        atexit.register(lambda: cls._cleanup("atexit"))
        
        def _make_sig_handler(signame):
            def _handler(signum, frame):
                cls._cleanup(f"signal {signame}")
                try:
                    signal.signal(signum, signal.SIG_DFL)
                except Exception:
                    pass
                try:
                    # Py3.8+
                    signal.raise_signal(signum)
                except Exception:
                    os._exit(128 + signum)
            
            return _handler
        
        for name in ("SIGTERM", "SIGINT", "SIGBREAK"):
            sig = getattr(signal, name, None)
            if sig is not None:
                try:
                    signal.signal(sig, _make_sig_handler(name))
                except Exception as e:
                    log.debug(f"Cannot set handler for {name}: {e}")
        
        try:
            import ctypes
            PHANDLER_ROUTINE = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_uint)
            
            @PHANDLER_ROUTINE
            def _console_handler(ctrl_type):
                # 0=CTRL_C_EVENT, 1=CTRL_BREAK_EVENT, 2=CTRL_CLOSE_EVENT, 5=LOGOFF, 6=SHUTDOWN
                cls._cleanup(f"console-ctrl {ctrl_type}")
                return False
            
            ctypes.windll.kernel32.SetConsoleCtrlHandler(_console_handler, True)
            cls._console_ctrl_handler = _console_handler
        except Exception as e:
            log.debug(f"SetConsoleCtrlHandler not installed: {e}")
    
    # -------------------------------------------------------------------------
    # Implementation of TesthidePluginRunner's Custom Hooks
    # -------------------------------------------------------------------------

    @classmethod
    @pytest.hookimpl
    def pytest_testhide_add_metadata(cls, plugin) -> list:
        """
        Provides WGC-specific session metadata to the Testhide reporter plugin.
        This data will be added to the final <properties> block in the XML report.
        """

        branch_name = WGCConfig.wgc_branch.replace("/", "_")

        session_props = [
            ('build', WGCConfig.wgc_build),
            ('branch', WGCConfig.wgc_branch),
            ('arch', WGCConfig.wgc_arch),
            ('publisher', WGCConfig.wgc_publisher),
            ('label', cls.label),
            ('screenshot_report', f"http://lx-dwd.pershastudia.com/"
                                  f"test_artifacts/"
                                  f"wgc_regression/"
                                  f"{branch_name}/"
                                  f"{WGCConfig.wgc_build}/"
                                  f"manual_screenshots/"
                                  f"manual_screenshots_report.html")
        ]

        # Add git commit info
        commit_info = cls._parse_commit_info(cls.wgc_info)
        for key, value in commit_info.items():
            session_props.append((key, value))
        return session_props
    
    @classmethod
    @pytest.hookimpl
    def pytest_testhide_get_test_case_properties(cls, item, report) -> list:
        """
        Provides WGC-specific properties for each test case, including
        docstrings, STR (Steps to Reproduce), and artifact links.
        This data will be added to the <properties> block inside each <testcase>.
        """
        properties = []
        
        # 1. Add test docstring
        if item.obj and item.obj.__doc__:
            properties.append(('docstr', item.obj.__doc__.strip()))
        
        # 2. Add STR (Steps to Reproduce)
        str_file, str_content = WGCClient.prepare_str()
        if str_content:
            properties.append(('info', str_content))
        
        # 3. Add links to all collected artifacts
        # The list of artifacts is prepared in `pytest_runtest_teardown`.
        artifact_paths_to_upload = getattr(item, 'collected_artifacts_to_report', [])
        
        for file_path in artifact_paths_to_upload:
            # For each file path, upload it and get the public URL
            url = ArtifactsHelper.attach_junit_artifact(item, file_path)
            if url:
                properties.append(('attachment', url))
        
        return properties
    
    # -------------------------------------------------------------------------
    # Standard Pytest Hooks
    # -------------------------------------------------------------------------
    
    @classmethod
    def pytest_addoption(cls, parser):
        parser.addoption('--wgc', dest='wgc_enabled', default=False,
                         action='store_true',
                         help='Enables WGC testing framework.')
        
        parser.addoption('--export-requirements', dest='export_requirements', default=False,
                         action='store_true',
                         help='Enables export test requirements to Testhide.')
        
        parser.addoption('--wgc-config-yaml', dest='wgc_config_yaml',
                         default=None, action='store',
                         help='Overrides default WGC config with given.')
        
        parser.addoption('--repeat', action='store',
                         help='Number of times to repeat each test')
        
        parser.addoption('--wgc-build', dest='wgc_build',
                         default=None, action='store',
                         help='Overrides default wgc build.')
        
        parser.addoption('--label', dest='label',
                         default=None, action='store',
                         help='Default label build.')
        
        parser.addoption('--wgc-default-language', dest='wgc_default_language',
                         default=None, action='store',
                         help='Overrides default wgc_default_language.')
        
        parser.addoption('--wgc-publisher', dest='wgc_publisher',
                         default=None, action='store',
                         help='Overrides default wgc publisher.')
        
        parser.addoption('--export-tests', dest='export_tests',
                         default=False, action='store_true',
                         help='Export tests to Testrail and Testhide.')
        
        parser.addoption('--wgc-api-versions-folder',
                         dest='wgc_api_versions_folder', default=None,
                         action='store',
                         help='Overrides default WGC api versions folder.')
        
        parser.addoption('--wgc-branch', dest='wgc_branch',
                         default=None, action='store',
                         help='Overrides default WGC branch.')
        
        parser.addoption('--wgc-arch', dest='wgc_arch',
                         default=None, action='store',
                         help='Overrides default WGC arch.')
        
        parser.addoption('--create-full-dump', dest='create_full_dump',
                         default=False, action='store_true',
                         help='create_full_dump.')
        
        parser.addoption('--create-ui-map', dest='create_ui_map',
                         default=False, action='store_true',
                         help='create_ui_map.')
        
        parser.addoption('--save-wgc-logs-on-pass', dest='save_wgc_logs_on_pass',
                         default=False, action='store_true',
                         help='save_wgc_logs_on_pass.')
        
        parser.addoption('--dbg-view-enabled', dest='dbg_view_enabled',
                         default=False, action='store_true',
                         help='dbg_view_enabled.')
        
        parser.addoption('--wgc-disable-video-capture',
                         dest='wgc_disable_video_capture',
                         default=False, action='store_true',
                         help='Disables video capturing.')

        parser.addoption('--enable-screenshots',
                         dest='enable_screenshots',
                         default=False, action='store_true',
                         help='Enables arsenal screenshots.')
        
        parser.addoption('--procmon-enabled',
                         dest='procmon_enabled',
                         default=False, action='store_true',
                         help='Enable procmonitor.')
        
        parser.addoption('--wgc-distinguish-os', dest='wgc_distinguish_os',
                         default=False, action='store_true',
                         help='Adds OS suffix to test name to distinguish '
                              'same tests on different OS.')
        
        parser.addoption('--wgc-sanity-disabled', dest='wgc_sanity_disabled',
                         default=False, action='store_true',
                         help='Disable sanity check before WGC tests.')
    
    @classmethod
    def pytest_generate_tests(cls, metafunc):
        if metafunc.config.option.repeat is not None:
            count = int(metafunc.config.option.repeat)
            
            # We're going to duplicate these tests by parametrizing them,
            # which requires that each test has a fixture to accept the parameter.
            # We can add a new fixture like so:
            metafunc.fixturenames.append('tmp_ct')
            
            # Now we parametrize. This is what happens when we do e.g.,
            # @pytest.mark.parametrize('tmp_ct', range(count))
            # def test_foo(): pass
            ids = ["".join(choice(ascii_lowercase) for _ in range(8)) for _ in range(count)]
            metafunc.parametrize('tmp_ct', range(count), ids=ids)
    
    @classmethod
    def is_not_known_issue(cls, test_result):
        if test_result and test_result.status != 'skipped' and test_result.statusDetails and \
                test_result.statusDetails.message:
            if test_result.status == 'broken':
                test_result.status = 'failed'
            not_known_issue = 'Known issue' not in test_result.statusDetails.message and \
                              'Verified at Branch' not in test_result.statusDetails.message and \
                              'Resolved in branch' not in test_result.statusDetails.message
            log.debug(f'is_not_known_issue - > not_known_issue={not_known_issue}')
            return not_known_issue
        log.debug('is_not_known_issue - > False')
        return False
    
    @classmethod
    def _parse_commit_info(cls, info_string: str) -> dict:
        info_string = (info_string or '').replace('\n\n', '\n')
        
        commit_match = re.search(r'commit\s+([a-f0-9]+)', info_string, re.IGNORECASE)
        merge_match = re.search(r'Merge:\s+(.*)', info_string)
        author_match = re.search(r'Author:\s+(.*)', info_string)
        date_match = re.search(r'Date:\s+(.*)', info_string)
        
        message_start_index = -1
        if date_match:
            message_start_index = date_match.end()
        elif author_match:
            message_start_index = author_match.end()
        
        message = info_string[message_start_index:].strip() if message_start_index != -1 else ""
        
        return {
            'commit': commit_match.group(1) if commit_match else 'Unknown',
            'merge': merge_match.group(1).strip() if merge_match else 'Unknown',
            'author': author_match.group(1).strip() if author_match else 'Unknown',
            'date_commit': date_match.group(1).strip() if date_match else 'Unknown',
            'message': message,
        }
    
    @classmethod
    def init_testrail_api(cls):
        try:
            testrail_credentials = [WGCConfig.testrail.url, WGCConfig.testrail.user, WGCConfig.testrail.password]
            
            cls.test_rail = TestRail(
                *(testrail_credentials + [WGCConfig.testrail.project_id])
            )
            cls.testrail_suites = {suite['name']: suite['id'] for suite in
                                   cls.test_rail.test_suites.get_suites(
                                       WGCConfig.testrail.project_id)}
            
            priorities = Priorities(*testrail_credentials)
            cls.test_priorities = {priority['name']: priority['id'] for priority in
                                   priorities.get_priorities()}
            case_types = CaseTypes(*testrail_credentials)
            cls.test_case_types = {case_type['name']: case_type['id'] for
                                   case_type in case_types.get_case_types()}
            
            case_fields = CaseFields(*testrail_credentials)
            custom_autostatus_field = \
                list(filter(lambda x: x['system_name'] == 'custom_autostatus',
                            case_fields.get_case_fields()))[0]
            custom_autostatus_items = \
                custom_autostatus_field['configs'][0]['options']['items']
            cls.autostatuses = {}
            
            for item in custom_autostatus_items.split('\n'):
                item = item.split(', ')
                cls.autostatuses[item[1]] = item[0]
            
            cls.suite_name = '1.0 Automation suite'
            dst_suite = cls.testrail_suites.get(cls.suite_name)
            if not dst_suite:
                result = cls.test_rail.test_suites.add_suite(
                    WGCConfig.testrail.project_id, name=cls.suite_name)
                cls.suite_id = result['id']
                cls.testrail_suites[cls.suite_name] = cls.suite_id
            else:
                cls.suite_id = dst_suite
            
            cls.test_sections = {section['name']: section['id'] for section in
                                 cls.test_rail.test_sections.get_sections(
                                     WGCConfig.testrail.project_id,
                                     cls.testrail_suites[cls.suite_name])}
        except Exception as e:
            log.error(f'PLUGIN: {e}')
    
    @classmethod
    @pytest.hookimpl(tryfirst=True)
    def pytest_cmdline_main(cls, config):
        cls.enabled = config.option.wgc_enabled
        if cls.enabled:
            cls._install_termination_hooks()
            path_to_python = path.dirname(sys.executable)
            if not path.isfile(path.join(path_to_python, 'openh264-1.8.0-win64.dll')):
                OSHelper.copy(get_third_party_path('openh264-1.8.0-win64.dll'), path.join(
                    path_to_python, 'openh264-1.8.0-win64.dll'))
            if not path.isfile(path.join(path_to_python, 'openh264-2.1.1-win64.dll')):
                OSHelper.copy(get_third_party_path('openh264-2.1.1-win64.dll'), path.join(
                    path_to_python, 'openh264-2.1.1-win64.dll'))
            
            pfx = get_third_party_path('cert_wgc.pfx')
            crt = get_third_party_path('cert_wgc.crt')
            OSHelper.remove_file_or_directory(pfx)
            OSHelper.remove_file_or_directory(crt)

            geo_id = OSHelper.get_geo_class_os()
            environ['GEO_ID'] = str(geo_id)
            
            # Use System DPI Aware
            ctypes.windll.user32.SetProcessDPIAware()
            
            # region logger configuration
            with open(log_config_path, 'r') as logger_config_file:
                log_config = json.load(logger_config_file)
                logging.config.dictConfig(log_config)
            # endregion
            
            print('\n                     -------WGC FRAMEWORK--------                             ')
            
            # region config reading
            if config.option.wgc_config_yaml:
                with open(config.option.wgc_config_yaml, 'r') as new_config:
                    wgc_config = yaml.safe_load(new_config)
                WGCConfig.override_config(wgc_config)
                GameMocks.reinit_default_attrs()
            # endregion
            
            # Change screen resolution
            try:
                if not WGCConfig.local_debug and not path.isfile(cls.lock_file):
                    print('Changing screen resolution...')
                    modes = ScreenHelper.get_modes()
                    resolution = ScreenHelper.get()
                    if resolution != (1920, 1080) and (1920, 1080, 32) in modes:
                        command = f'{get_third_party_path("qres.exe")} /x 1920 /y 1080'
                        result = CmdHelper.execute(command)
                        log.debug(result.decode('utf-8'))
                    else:
                        modes_info = "\r".join(modes)
                        log.debug(f'Cannot change screen resolution: current resolution: '
                                  f'{resolution}\ravailable modes:{modes_info}')
                    print('Finished changing screen resolution...')
            except Exception as e:
                log.error(e)

            WGCConfig.export_tests = config.option.export_tests
            WGCConfig.export_requirements = config.option.export_requirements
            if config.option.export_requirements:
                cls.init_testrail_api()

            # region clean results folder
            OSHelper.remove_file_or_directory(WGCConfig.test_results_folder)
            OSHelper.remove_file_or_directory(WGCConfig.application.folder)
            OSHelper.remove_file_or_directory(path.join(
                WGCConfig.test_results_folder, 'sanity_check.log'))
            # endregion
            
            # region enable jira marker plugin
            config.option.jira_marker = True
            config.option.jira_url = WGCConfig.jira.url
            config.option.jira_username = WGCConfig.jira.username
            config.option.jira_password = WGCConfig.jira.password
            # endregion
            if config.option.repeat:
                cls.tests_count = int(config.option.repeat)
            if config.option.label:
                cls.label = config.option.label
            if config.option.create_full_dump:
                WGCConfig.create_full_dump = config.option.create_full_dump
            if config.option.create_ui_map:
                WGCConfig.create_ui_map = config.option.create_ui_map
            if config.option.wgc_default_language:
                WGCConfig.wgc_preferences_language = config.option.wgc_default_language
            if config.option.save_wgc_logs_on_pass:
                WGCConfig.save_wgc_logs_on_pass = config.option.save_wgc_logs_on_pass
            if config.option.procmon_enabled:
                WGCConfig.procmon_enabled = config.option.procmon_enabled
            if config.option.dbg_view_enabled:
                WGCConfig.dbg_view_enabled = config.option.dbg_view_enabled
            if config.option.wgc_disable_video_capture:
                WGCConfig.capture_video = config.option.wgc_disable_video_capture
            if config.option.enable_screenshots:
                WGCConfig.enable_screenshots = config.option.enable_screenshots
            
            if WGCConfig.local_debug:
                WGCConfig.dbg_view_enabled = wgc_config.get('dbg-view-enabled')
            
            if config.option.wgc_arch:
                WGCConfig.wgc_arch = config.option.wgc_arch
            
            if config.option.wgc_publisher:
                WGCConfig.wgc_publisher = config.option.wgc_publisher
            
            # endregion
            RegistryHelper.init_config_in_register()
            
            # Generate INSTALLATION_ID
            WGCConfig.application.installation_id = OSHelper.generate_installation_id()
            # Configure creates WER dumps.
            if not path.isfile(cls.lock_file):
                DumpHelper.add_process_for_catch_dumps(WGCConfig.application.binary_name)
                DumpHelper.add_process_for_catch_dumps('helper_process.exe')
                DumpHelper.add_process_for_catch_dumps(WGCConfig.application.renderer_process)
                OSHelper.make_dirs('c:\\python_dumps', exist_ok=True)
                DumpHelper.add_process_for_catch_dumps('python.exe', 'c:\\python_dumps')
                DumpHelper.add_process_for_catch_dumps('wgctmp_setup.tmp')
                DumpHelper.add_process_for_catch_dumps('wgctmp_setup.exe')
            print(f'IP ADDRESS: {WGCConfig.ip_address}')
            print(f'Mock http port: {WGCConfig.mocks.http_port}, https port: {WGCConfig.mocks.https_port}\n')
            cls.check_crashes = WGCConfig.check_crash_wgc_after_test
            cls.start_test = datetime.now()
    
    @classmethod
    def pytest_configure(cls, config):
        if cls.enabled:
            WGCClient._socket_state = None
            # region config override
            if config.option.wgc_branch:
                WGCConfig.wgc_branch = config.option.wgc_branch.strip().replace('\\', '/').rstrip('/')
            
            if config.option.wgc_build:
                WGCConfig.wgc_build = config.option.wgc_build.strip()
            
            url = f'{WGCConfig.share_builds_folder}{WGCConfig.wgc_branch}/'
            if not WGCConfig.wgc_build:
                limit_builds_lookup_behind = 10
                build_index = -1
                try:
                    builds = OSHelper.get_list_content_with_date(url)
                except HTTPError:
                    raise WGCException(f'Folder not found on share {url}')
                while abs(build_index) <= limit_builds_lookup_behind:
                    latest_build = sorted(builds, key=builds.get)[build_index]
                    
                    bin_url = urljoin(url, latest_build + f'/{WGCConfig.wgc_publisher}/bin/{WGCConfig.wgc_arch}/')
                    if OSHelper.is_web_path_exist(bin_url):
                        WGCConfig.wgc_build = latest_build
                        WGCConfig.update_wgc_build(latest_build)
                        print(f'Search for binaries in: {latest_build} - Found.')
                        break
                    else:
                        build_index -= 1
                    print(f'Search for binaries in: {latest_build} - No "bin" folder found.')
                
                if not WGCConfig.wgc_build:
                    raise WGCException(
                        f'"bin" folder was not found '
                        f'in {limit_builds_lookup_behind} latest builds.')
            print('\nRead wgc_src_commit.txt content.')
            path_to_commit_file = f'{url}{WGCConfig.wgc_build}/info/wgc_src_commit.txt'
            cls.wgc_info = OSHelper.get_web_content(path_to_commit_file).decode('utf-8')
            Localization.load_translations(WGCConfig.wgc_preferences_language)
            if config.option.wgc_api_versions_folder:
                WGCConfig.test_data.wgc_api_versions_folder = \
                    config.option.wgc_api_versions_folder
            print(f'markexpr={config.option.markexpr}')
            print(f'\nBRANCH: -> {WGCConfig.wgc_branch}')
            print(f'BUILD: -> {WGCConfig.wgc_build}')
            print(f'PUBLISHER: -> {WGCConfig.wgc_publisher}')
            print(f'ARCH: -> {WGCConfig.wgc_arch}\n')
            
            if config.option.wgc_sanity_disabled:
                WGCConfig.sanity_check = False
            
            # endregion
            WGCClient.terminate_all_wgc_related_processes()
            if not path.isfile(cls.lock_file):
                TestDataHelper.prepare_game_torrents()
            # TestDataHelper.copy_redist_exe()
            
            # set native traceback style
            config.option.tbstyle = 'native'
            
            # region load fixtures
            fixtures_dir = Path(fixtures.__file__).parent
            
            for finder, module_name, _ in iter_modules([str(fixtures_dir)]):
                module_spec = finder.find_spec(module_name)
                if module_spec and module_spec.loader:
                    package = importlib.util.module_from_spec(module_spec)
                    module_spec.loader.exec_module(package)
                    config.pluginmanager.register(package, module_name)
            # endregion
            
            # clear log filename for test dependent logging handler
            TestDependentRotatingFileHandler.log_filename = None
            MocksRotatingFileHandler.log_filename = None
            ProductHashRotatingFileHandler.log_filename = None
            MocksRespRotatingFileHandler.log_filename = None
            DistributeRotatingFileHandler.log_filename = None
            # clear log filename and stats
            DistributeRotatingFileHandler.clear_stats()
    
    @classmethod
    @pytest.hookimpl(trylast=True)
    def pytest_keyboard_interrupt(cls, excinfo):
        if cls.enabled:
            cls._cleanup("KeyboardInterrupt")
    
    @classmethod
    def pytest_unconfigure(cls, config):
        if cls.enabled:
            cls._cleanup("pytest_unconfigure")
    
    @classmethod
    def pytest_runtest_setup(cls, item):
        if cls.enabled:
            item.collected_artifacts_to_report = []
            log.info('\r[testhide_message][test_started]: %s\n' % item.name)
            cls.elapsed_tests += 1
            ArtifactsHelper.queued_files.clear()
            RequirementHelper.clean()
            if not WGCConfig.local_debug:
                WinApi.minimize_all_app()
                WinApi.click(5, 5)
            WGCConfig.check_crash_wgc_after_test = cls.check_crashes
            name = item.originalname or item.name
            if item.config.option.wgc_distinguish_os:
                name = name.replace(cls.os_item_suffix, '')
            environ['current_testname'] = str(name)
            is_single_test_job = 'tmp_ct' in item._fixtureinfo.name2fixturedefs.keys()
            environ['is_single_test_job'] = str(is_single_test_job)
            cls.start_test = datetime.now()
            
            seek_file = path.join(WGCConfig.additional_disk, 'seek.file')
            if path.isfile(seek_file):
                OSHelper.remove_file_or_directory(seek_file)
            
            random_hash = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
            debug_name = f'debug_{random_hash}'
            TestDependentRotatingFileHandler.log_filename = cls._get_full_test_log_filename(item, file_name=debug_name)
            MocksRotatingFileHandler.log_filename = cls._get_full_test_log_filename(
                item, file_name='mock_requests_response')
            
            for f in [r'c:\chrome_html.html', r'c:\DebugView.log']:
                OSHelper.remove_file_or_directory(f)
            
            wgc_report_dir = path.join(WGCConfig.temp_folder, 'wgc_report_dir')
            OSHelper.remove_file_or_directory(wgc_report_dir)
            OSHelper.make_dirs(wgc_report_dir, exist_ok=True)
            
            installer_log = path.join(WGCConfig.temp_folder, 'installer', 'logs')
            OSHelper.remove_file_or_directory(installer_log)
            uninstaller_log = path.join(WGCConfig.temp_folder, 'uninstaller',
                                        'logs')
            OSHelper.remove_file_or_directory(uninstaller_log)
            OSHelper.remove_file_or_directory(WGCConfig.application.chrome_log_path)
            OSHelper.remove_file_or_directory(path.join(WGCConfig.temp_folder, 'events.log'))
            OSHelper.remove_file_or_directory(r'c:\Program Files (x86)\Steam\dumps')
            OSHelper.remove_file_or_directory(r'c:\Program Files (x86)\Steam\GameOverlayRenderer.log')
            OSHelper.remove_file_or_directory(r'c:\Program Files (x86)\Steam\GameOverlayUI.exe.log')
            
            StepsToReproduceFileHandler.reset_str()
            if WGCConfig.capture_video and not VideoCaptureHelper.capturing_in_progress:
                VideoCaptureHelper.start_capturing()

            GameMocks.latest_response = ''
            
            wgc_path = path.join(WGCConfig.additional_disk, 'GamesWGC')
            if path.isdir(wgc_path):
                OSHelper.remove_file_or_directory(wgc_path)
    
    @classmethod
    def save_video(cls, item):
        try:
            if path.isfile(VideoCaptureHelper.video_file):
                item.collected_artifacts_to_report.append(VideoCaptureHelper.video_file)
        except OSError as e:
            log.info(e)
    
    @classmethod
    def attach_wgc_logs(cls, item=None):
        wgc_paths = [WGCConfig.application.folder,
                     path.join(WGCConfig.additional_disk, 'GamesWGC'),
                     WGCConfig.application.unicode_folder]
        for wgc_path in wgc_paths:
            for wgc_log_file in glob.glob(path.join(wgc_path, 'logs') + '**\\*.log'):
                if item and not wgc_log_file.startswith('renderer_'):
                    item.collected_artifacts_to_report.append(wgc_log_file)
    
    @classmethod
    def save_screenshot(cls, item):
        try:
            if item.cls:
                module_name = item.cls.__module__
            else:
                module_name = item.module.__name__

            module_hash = hashlib.md5(module_name.encode('utf-8')).hexdigest()[:8]
            
            screenshot_dir = path.join(
                WGCConfig.test_results_folder,
                'screenshots',
                module_hash)
            
            abs_dir = path.abspath(screenshot_dir)
            if not abs_dir.startswith("\\\\?\\") and ":" in abs_dir:
                abs_dir = "\\\\?\\" + abs_dir
            
            screenshot_full_path = ScreenHelper.save_screen(abs_dir)
            
            if screenshot_full_path and hasattr(item, 'collected_artifacts_to_report'):
                item.collected_artifacts_to_report.append(screenshot_full_path)
                return screenshot_full_path
        except Exception as e:
            log.error(f"Failed to save screenshot: {e}")

    @classmethod
    @pytest.hookimpl(tryfirst=True)
    def pytest_runtest_teardown(cls, item):
        if cls.enabled:
            log.info(f'\r[testhide_message][test_finished]: {item.name}\n')
            if ScreenHelper.screenshot_path not in ArtifactsHelper.queued_files:
                cls.save_screenshot(item)
            reqs = RequirementHelper.to_string()
            if WGCConfig.export_requirements:
                cls.export_test(item, reqs)
            cls.stop_test = datetime.now()
            is_single_test_job = 'tmp_ct' in item._fixtureinfo.name2fixturedefs.keys()
            cls.is_single_test_job = is_single_test_job
            failed = getattr(item, '_was_failed', False)
            if not EventHelper.handler_stopped:
                EventHelper.log_to_file()
                EventHelper.disable()
            start = time()
            
            # Stop Video Capturing
            if VideoCaptureHelper.capturing_in_progress:
                VideoCaptureHelper.stop_capturing()
            if failed and item.cls:
                cls.save_video(item)
            if failed:
                
                # SYSInternals
                if WGCConfig.procmon_enabled:
                    SysInternalsHelper.stop_monitor()
                    logs_p = glob.glob(WGCConfig.procmon_log_file[:-4] + '*.*')
                    for log_ in logs_p:
                        item.collected_artifacts_to_report.append(log_)
                item.collected_artifacts_to_report.append(WGCConfig.dbg_view_log_file)
                
                for file_path in ArtifactsHelper.queued_files:
                    item.collected_artifacts_to_report.append(file_path)
                
                # Write WGC home directory tree
                app_tree_log = OSHelper.write_tree_directory_to_log(
                    WGCConfig.application.folder,
                    path.join(WGCClient.reports_dir(), 'application_tree.log'))
                item.collected_artifacts_to_report.append(app_tree_log)
                # Test directory tree
                cached_folder_tree = OSHelper.write_tree_directory_to_log(
                    WGCConfig.cached_folder,
                    path.join(WGCClient.reports_dir(), 'cached_folder_tree.log'))
                item.collected_artifacts_to_report.append(cached_folder_tree)
                
                # Write Games home directory tree
                game_tree_log = OSHelper.write_tree_directory_to_log(
                    WGCConfig.games.folder,
                    path.join(WGCClient.reports_dir(), 'games_tree.log'),
                    full_info='tests/other' not in item.nodeid)
                item.collected_artifacts_to_report.append(game_tree_log)
                
                # Write Steam Games home directory tree
                dir_ = glob.glob(WGCConfig.steam.games_dir + '\\**\\wgcs_game_config.xml', recursive=True)
                if dir_:
                    item.collected_artifacts_to_report.append(dir_[0])
                
                dir_ = glob.glob(WGCConfig.steam.games_dir + '\\**\\wgcs_game_target.xml', recursive=True)
                if dir_:
                    item.collected_artifacts_to_report.append(dir_[0])
                dir_ = glob.glob(WGCConfig.steam.games_dir + '\\**\\dummy_game.log', recursive=True)
                if dir_:
                    item.collected_artifacts_to_report.append(dir_[0])
                
                # Installer Logs
                files = glob.glob(getenv('TEMP') + '\\Setup Log*.txt')
                log.debug(f'Attach Setup Log FILES: {files}')
                for path_ in files:
                    item.collected_artifacts_to_report.append(path_)
            
            preferences_xml = path.join(WGCConfig.application.folder, WGCConfig.application.preferences_file)
            event_file = path.join(WGCConfig.temp_folder, 'events.log')
            version_file = path.join(WGCConfig.application.folder, WGCConfig.application.version_file)
            version_file_update = path.join(WGCConfig.application.folder, 'version.xml.update')
            installer_log = path.join(WGCConfig.temp_folder, 'installer', 'logs', 'installer.log')
            installer_log1 = path.join(WGCConfig.temp_folder, 'installer', 'logs', 'installer.log~')
            uninstaller_log = path.join(WGCConfig.temp_folder, 'uninstaller', 'logs', 'uninstaller.log')
            uninstaller_log1 = path.join(WGCConfig.temp_folder, 'uninstaller', 'logs', 'uninstaller.log~')
            process_log = path.join(WGCClient.reports_dir(), 'processes.log')
            
            if failed and item.cls:
                for file_ in [installer_log, installer_log1, uninstaller_log, uninstaller_log1, event_file,
                              preferences_xml, version_file, version_file_update, WGCConfig.application.user_info_file]:
                    item.collected_artifacts_to_report.append(file_)
                
                OSHelper.write_processes_to_log(process_log)
                item.collected_artifacts_to_report.append(process_log)
                
                for file_ in cls.sanity_files:
                    item.collected_artifacts_to_report.append(file_)
                
                # Attach files
                for f in [r'c:\chrome_html.html', r'c:\DebugView.log']:
                    if path.isfile(f) and path.getsize(f) > 0:
                        item.collected_artifacts_to_report.append(f)
                
                dummy_exc_files = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\error_log.txt', recursive=True)
                app_type_files = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\app_type.xml', recursive=True)
                game_info_files = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\game_info.xml', recursive=True)
                metadata_files = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\metadata.xml', recursive=True)
                app_type_files_s = OSHelper.glob_safe(WGCConfig.steam.games_dir + '\\**\\app_type.xml', recursive=True)
                game_info_files_s = OSHelper.glob_safe(WGCConfig.steam.games_dir + '\\**\\game_info.xml',
                                                       recursive=True)
                metadata_files_s = OSHelper.glob_safe(WGCConfig.steam.games_dir + '\\**\\metadata.xml', recursive=True)
                log_files = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\*.log', recursive=True)
                output_file = OSHelper.glob_safe(WGCConfig.games.folder + '\\**\\output.xml', recursive=True)
                files = app_type_files + game_info_files + metadata_files + \
                    app_type_files_s + game_info_files_s + metadata_files_s + output_file + dummy_exc_files
                for file_ in files:
                    item.collected_artifacts_to_report.append(file_)
                for file_ in log_files:
                    item.collected_artifacts_to_report.append(file_)
                # WGC dumps
                if WGCConfig.search_events.artifacts_upload:
                    try:
                        dumps = list(Path(WGCConfig.application.folder).glob('**\\*.dmp'))
                        for dump in dumps:
                            item.collected_artifacts_to_report.append(str(dump))
                        zips = list(Path(WGCConfig.application.folder).glob('**\\*.zip'))
                        for dump in zips:
                            item.collected_artifacts_to_report.append(str(dump))
                    except Exception as e:
                        log.debug(e)
                
                wgc_info_xml = path.join(WGCConfig.application.folder, 'wgc_info.xml')
                item.collected_artifacts_to_report.append(wgc_info_xml)
                
                if WGCConfig.create_ui_map:
                    ui_map = path.join(WGCConfig.temp_folder, 'ui_map.html')
                    log.debug('Create ui_map file.')
                    WGCClient.get_elements_dump(ui_map)
                    log.debug('ui_map file was created, files '
                              'exists = %s.' % path.isfile(ui_map))
                    item.collected_artifacts_to_report.append(ui_map)
                    ui_map_screenshot = path.join(WGCConfig.temp_folder, 'ui_map_screenshot.png')
                    if path.isfile(ui_map_screenshot):
                        item.collected_artifacts_to_report.append(ui_map_screenshot)
                
                if MocksRotatingFileHandler.log_filename:
                    item.collected_artifacts_to_report.append(MocksRotatingFileHandler.log_filename)
            
            # Save WGC logs for passed tests
            if not failed and WGCConfig.save_wgc_logs_on_pass:
                item.collected_artifacts_to_report.append(MocksRotatingFileHandler.log_filename)
            
            finished = time()
            log.debug('PLUGIN EXECUTING TIME: %s' % str(finished - start))
            
            dumps = DumpHelper.get_dumps()
            log.debug('DUMPS FOLDER: %s' % str(dumps))
            OSHelper.terminate_process('Dbghost.exe')
            for dump in dumps:
                if 'wgc' in dump or 'manual' in dump or 'Second_Chance' in dump:
                    item.collected_artifacts_to_report.append(dump)
            
            seek_file = path.join(WGCConfig.additional_disk, 'seek.file')
            if path.isfile(seek_file):
                OSHelper.remove_file_or_directory(seek_file)
            if failed:
                item.collected_artifacts_to_report.append(WGCConfig.application.wgc_info_path)
                cls.attach_wgc_logs(item)
            if hasattr(item, 'collected_artifacts_to_report'):
                item.collected_artifacts_to_report.append(TestDependentRotatingFileHandler.log_filename)
                # === SAVE ARTIFACTS LOCALLY ===
                if TestDependentRotatingFileHandler.log_filename:
                    local_test_dir = path.dirname(TestDependentRotatingFileHandler.log_filename)
                    for src_file in list(item.collected_artifacts_to_report):
                        if src_file and path.isfile(src_file):
                            try:
                                dst_file = path.join(local_test_dir, path.basename(src_file))
                                if path.abspath(src_file) != path.abspath(dst_file):
                                    OSHelper.copy(src_file, dst_file)
                            except Exception as e:
                                log.warning(f"Failed to save artifact locally: {src_file}. Error: {e}")
                # ==============================
    
    @classmethod
    def pytest_runtest_logfinish(cls, nodeid, location):
        if WGCConfig.terminate_wgc_after_test:
            WGCClient.terminate_all_wgc_related_processes()
    
    @classmethod
    def pytest_exception_interact(cls, node, call, report):
        if cls.enabled:
            log.exception(str(call.excinfo))
            node._was_failed = True
            node._excinfo = call.excinfo.exconly()
    
    @classmethod
    @pytest.hookimpl(tryfirst=True)
    def pytest_collection_modifyitems(cls, session, config, items):
        if cls.enabled:
            WGCConfig.tests_mark = config.option.markexpr
            TestDependentRotatingFileHandler.log_filename = path.join(
                path.dirname(WGCConfig.test_results_folder), 'sanity_check.log')
            
            WGCClient.terminate_all_wgc_related_processes()
            OSHelper.remove_file_or_directory(
                WGCConfig.application.base_folder)
            OSHelper.remove_file_or_directory(
                WGCConfig.application.folder)
            for item in items:
                # add mark according to folder name
                test_file = Path(item.module.__file__)
                test_folder = path.basename(path.dirname(str(test_file)))
                item.add_marker('folder_%s' % test_folder)
                if config.option.wgc_distinguish_os:
                    item.name += cls.os_item_suffix
            
            cls.tests_count = len(items)
            if WGCConfig.sanity_check and items and not path.isfile(cls.lock_file):
                cls.create_lock_file()
                log.debug('prepare_wgc_before_test_run: start')
                WGCClient.prepare_wgc_before_test_run()
                log.debug('prepare_wgc_before_test_run: finish')
                version = WGCSettingsHelper.get_wgc_current_version()
                if version != WGCConfig.wgc_build:
                    sanity_check = False
                else:
                    try:
                        log.debug('run_wgc: start')
                        start = time()
                        environ['start_sanity'] = str(start)
                        output_video = path.join(
                            path.dirname(WGCConfig.test_results_folder), 'video_sanity_check.avi')
                        VideoCaptureHelper.start_capturing(output_video)
                        sleep(2.5)
                        WGCClient.create_prod_wgc_info()
                        WGCClient.run_game_center(dont_wait=True, log_trace=True)
                        timeout = 25 if WGCConfig.local_debug else 100
                        message = 'Running script with autotests'
                        sanity_check = \
                            Waiter.poll(
                                timeout,
                                lambda: WGCClient.is_wgc_processes_exist() and message in WGCClient.get_cwlfc())
                        log.debug('sanity_check = %s' % sanity_check)
                        WGCConfig.application.is_final_configuration = bool(re.findall(
                            '.*Configuration: Final', WGCClient.get_current_wgc_log_file_content()))
                        if WGCConfig.application.is_final_configuration:
                            WGCConfig.wgc_configuration = 'Final'
                        print(f'markexpr={config.option.markexpr}')
                        if config.option.markexpr and 'folder_arsenal' in config.option.markexpr and WGCConfig.application.is_final_configuration:
                            print('Arsenal tests for final configuration is skipped.')
                            items[:] = []
                            return
                    except Exception as e:
                        log.debug(e)
                        sanity_check = False
                        OSHelper.make_dirs(WGCClient.reports_dir(), exist_ok=True)
                        for log_file in WGCClient.get_wgc_log_filenames(overlay_logs=False):
                            OSHelper.copy(log_file, path.join(WGCClient.reports_dir(), path.basename(log_file)))
                            cls.sanity_files.append(path.join(WGCClient.reports_dir(), path.basename(log_file)))
                        
                        log.info('Sanity check failed.')
                VideoCaptureHelper.stop_capturing()
                StepsToReproduceFileHandler.reset_str()
                
                if not sanity_check:
                    for item in items:
                        if 'sanity_check' in item.name:
                            items[:] = [item]
                            config.option.markexpr = ''
                    
                    config.option.keyword = ''
            
            print('\rCollected %s tests\r\n' % len(items))
    
    @classmethod
    def pytest_collection_finish(cls, session):
        cls.tests_count = len(session.items)
    
    @classmethod
    def _get_full_test_log_filename(cls, test_item, file_name=None):
        full_test_name = '%s.%s.%s' % (test_item.module.__name__,
                                       test_item.cls.__name__ if test_item.cls
                                       else test_item.module.__name__,
                                       test_item.name.replace(
                                           cls.os_item_suffix,
                                           '').replace('|', ''))
        full_test_name = full_test_name.split('[')
        test_results_path = full_test_name[0].split('.')
        if len(full_test_name) > 1:
            test_results_path[-1] = '['.join([test_results_path[-1],
                                              full_test_name[1]])
        test_results_path.insert(0, WGCConfig.test_results_folder)
        if file_name:
            test_results_path[-1] += file_name
        test_log_filename = '%s.txt' % path.join(*test_results_path)
        test_log_filename = \
            test_log_filename.translate(str.maketrans('', '', '"'))
        
        return test_log_filename

    @classmethod
    def pytest_sessionfinish(cls, session, exitstatus):
        start_param = f'"{BrowserHelper.chrome_binary_path}" -- "%1"'
        WGCClient.terminate_all_wgc_related_processes()
        RegistryHelper.set_value(
            winreg.HKEY_CLASSES_ROOT,
            'ChromeHTML\\shell\\open\\command', 1, None, start_param)
        if not WGCConfig.local_debug:
            OSHelper.remove_file_or_directory(WGCConfig.cached_folder)
        if WGCConfig.upload_artifacts_to_share:
            screenshot_dir = path.join(
                WGCConfig.test_results_folder,
                'manual_screenshots')
            ArtifactsHelper.push_artifacts_to_share(src_path=screenshot_dir)
            ArtifactsHelper.generate_remote_html_report()

    @classmethod
    def export_test(cls, item, data):
        log.debug('Tests export started.')
        try:
            section = None
            module_name = item.nodeid.split('/')[1]
            if cls.test_sections:
                section = cls.test_sections.get(module_name)
            if not section:
                result = cls.test_rail.test_sections.add_section(
                    WGCConfig.testrail.project_id, name=module_name,
                    suite_id=cls.testrail_suites[cls.suite_name])
                cls.test_sections[module_name] = result['id']
                section_id = result['id']
            else:
                section_id = section
            name = item.originalname or item.name
            if item.obj.__doc__:
                title = item.obj.__doc__.rstrip().lstrip()
            else:
                log.error(f'Test {name} has no docstring value.')
                title = name + ';'
            title = title.split(';')[0]
            if len(title) > 249:
                title = title[:239] + '...'
            
            if item.config.option.wgc_distinguish_os:
                name = name.replace(cls.os_item_suffix, '')
            new_test_case = \
                {'type_id': cls.test_case_types.get('Functionality'),
                 'title': '[auto] ' + title,
                 'priority_id': cls.test_priorities['2'],
                 'custom_autostatus': cls.autostatuses['Scripted'],
                 'custom_autotest': name,
                 'refs': data}
            cases = []
            for _ in range(3):
                try:
                    cases = cls.test_rail.test_cases.get_cases(32, suite_id=cls.suite_id, section_id=section_id)
                    break
                except requests.ConnectionError:
                    sleep(1)
                    continue
            if not cases:
                return
            exists = False
            case = None
            for case_ in cases:
                if name == case_['custom_autotest']:
                    exists = True
                    case = case_
                    break
            if not exists:
                new_test = cls.test_rail.test_cases.add_case(section_id, **new_test_case)
                case_id = new_test['id']
            else:
                update_test_case = {
                    'title': '[auto] ' + title,
                    'refs': data
                }
                cls.test_rail.test_cases.update_case(case['id'], **update_test_case)
                case_id = case['id']
            url = f'https://testrail.wargaming.net/web/index.php?/cases/view/{case_id}'
            requests.post('https://testhide.pershastudia.com:7771/api/2.0/tests', data={
                'name': name, 'title': title, 'module_name': module_name,
                'requirements': data, 'testrail_url': url})
        except Exception as e:
            tb = ''.join(traceback.format_tb(e.__traceback__))
            msg = f'{e};\n {tb}'
            log.error(f'PLUGIN CREATE TEST: {msg}')
