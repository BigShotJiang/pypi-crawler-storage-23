"""
Communities (社区) 模块

提供社区搜索和加入功能。

Example:
    ```python
    from x_api_rs.communities import CommunitiesClient

    client = await CommunitiesClient.create(cookies)

    # 搜索社区
    result = await client.search("python")
    for community in result.communities:
        print(f"{community.name}: {community.member_count} members")

    # 获取下一页
    if result.next_cursor:
        next_page = await client.search("python", result.next_cursor)

    # 加入社区
    result = await client.join(community.rest_id)
    if result.success:
        print("成功加入社区")
    ```
"""

from ..x_api_rs import communities as _communities

# 客户端
CommunitiesClient = _communities.CommunitiesClient

# 结果类型
Community = _communities.Community
CommunitySearchResult = _communities.CommunitySearchResult
JoinCommunityResult = _communities.JoinCommunityResult

__all__ = [
    # 客户端
    "CommunitiesClient",
    # 结果类型
    "Community",
    "CommunitySearchResult",
    "JoinCommunityResult",
]
