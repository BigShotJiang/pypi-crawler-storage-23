from __future__ import annotations

"""Feature modules grouped by gameplay intent for deterministic dispatch."""
