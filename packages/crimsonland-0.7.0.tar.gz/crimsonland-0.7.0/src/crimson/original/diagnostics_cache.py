from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import os
from collections import Counter, OrderedDict
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Protocol, TypeVar, cast

import msgspec
from platformdirs import PlatformDirs

import crimson.projectiles.runtime.collision as projectiles_mod
import crimson.projectiles.runtime.projectile_pool as projectile_pool_mod
import crimson.projectiles.runtime.secondary_pool as secondary_pool_mod
import crimson.sim.presentation_step as presentation_step_mod
from crimson.bonuses import bonus_label
from crimson.game_modes import GameMode
from crimson.gameplay import build_gameplay_state
from crimson.paths import APP_NAME
from crimson.perks import perk_label
from crimson.quests import quest_by_level
from crimson.quests.runtime import build_quest_spawn_table
from crimson.quests.types import QuestContext
from crimson.replay import apply_replay_bootstrap
from crimson.replay.checkpoints import ReplayCheckpoint
from crimson.replay.types import UnknownEvent
from crimson.sim.driver.replay_events import apply_replay_tick_events, partition_tick_events
from crimson.sim.driver.replay_timing import (
    resolve_dt_frame,
    resolve_dt_frame_ms_i32,
    should_apply_world_dt_steps_for_replay,
)
from crimson.sim.driver.setup import (
    build_damage_scale_by_type,
    build_empty_fx_queues,
    reset_players,
    status_from_snapshot,
)
from crimson.sim.sessions import QuestDeterministicSession, SurvivalDeterministicSession
from crimson.sim.world_state import WorldState
from crimson.weapon_runtime import weapon_assign_player
from crimson.weapons import WEAPON_BY_ID, WeaponId

from .capture import (
    CAPTURE_BOOTSTRAP_EVENT_KIND,
    build_capture_dt_frame_ms_i32_overrides,
    build_capture_dt_frame_overrides,
    build_capture_inter_tick_rand_draws_overrides,
    capture_bootstrap_payload_from_event_payload,
    convert_capture_to_replay,
    load_capture,
)
from .focus_trace import (
    CollisionRow,
    DecalHookRow,
    FocusTraceReport,
    _build_fire_bullets_loop_parity,
    _build_native_caller_gaps,
    _capture_rng_head_entry_to_row,
    _CaptureReplayEvents,
    _collect_creature_presence_diffs,
    _collect_projectile_presence_diffs,
    _decode_inputs_for_tick,
    _load_capture_events,
    _projectile_snapshot,
    _resolve_quest_level,
    _summarize_creature_diffs,
    _summarize_projectile_diffs,
    _summarize_rng_alignment,
)
from .schema import (
    CaptureEventHeadBonusApply,
    CaptureEventHeadStateTransition,
    CaptureEventHeadWeaponAssign,
    CaptureFile,
    CaptureTick,
)

_CACHE_SCHEMA_VERSION = 2
_CAPTURE_BLOB_NAME = "capture.msgpack.gz"
_META_NAME = "meta.json"
_DEFAULT_IDLE_TIMEOUT_SECONDS = 15 * 60
_FOCUS_NEAR_TICK_WINDOW = 256
_FOCUS_ANCHOR_INTERVAL = 64
_FOCUS_ANCHOR_LIMIT = 32
_DecodedT = TypeVar("_DecodedT")


class CaptureFingerprint(msgspec.Struct, forbid_unknown_fields=True):
    resolved_path: str
    size: int
    mtime_ns: int
    sha256: str | None = None


@dataclass(frozen=True, slots=True)
class ReplayKey:
    max_ticks: int | None
    seed: int | None
    inter_tick_rand_draws: int
    aim_scheme_overrides: tuple[tuple[int, int], ...]


@dataclass(frozen=True, slots=True)
class FocusKey:
    inter_tick_rand_draws: int
    aim_scheme_overrides: tuple[tuple[int, int], ...]


class DaemonRequest(msgspec.Struct, forbid_unknown_fields=True):
    tool: str
    args: list[str] = msgspec.field(default_factory=list)
    cwd: str | None = None


class DaemonResponse(msgspec.Struct, forbid_unknown_fields=True):
    exit_code: int
    stdout: str = ""
    stderr: str = ""


class RunSummaryEventLite(msgspec.Struct, forbid_unknown_fields=True):
    tick_index: int
    kind: str
    detail: str


class _CaptureMeta(msgspec.Struct, forbid_unknown_fields=True):
    schema_version: int
    fingerprint: CaptureFingerprint


class _RunSummaryBlob(msgspec.Struct, forbid_unknown_fields=True):
    rows: list[RunSummaryEventLite] = msgspec.field(default_factory=list)


@dataclass(slots=True)
class _FocusStepTraceContext:
    tick: int
    near_miss_threshold: float
    rng_callsites: Counter[str]
    rng_head: list[str]
    rng_values: list[int]
    rng_values_callsites: list[str]
    collision_hits: list[CollisionRow]
    near_misses: list[CollisionRow]
    decal_hook_rows: list[DecalHookRow]
    pre_projectiles: list[dict[str, Any]]
    post_projectiles: list[dict[str, Any]]
    focus_hits: int
    focus_deaths: int
    focus_sfx: int


class _FocusRuntimeLike(Protocol):
    def trace_tick(self, *, tick: int, near_miss_threshold: float) -> FocusTraceReport: ...


class _FocusRuntime:
    """Reusable focus runtime for nearby focus-tick probes."""

    def __init__(
        self,
        *,
        capture: CaptureFile,
        replay: Any,
        inter_tick_rand_draws: int,
    ) -> None:
        self.capture = capture
        self.replay = replay
        self.mode = int(replay.header.game_mode_id)
        if self.mode not in {int(GameMode.SURVIVAL), int(GameMode.QUESTS)}:
            raise ValueError(f"focus trace currently supports survival and quests modes only (got mode={self.mode})")
        self.inter_tick_rand_draws = max(0, int(inter_tick_rand_draws))
        self.root = Path.cwd().resolve()

        self.events_meta: _CaptureReplayEvents = _load_capture_events(replay)
        self.events_by_tick = self.events_meta.events_by_tick
        self.original_capture_replay = bool(self.events_meta.original_capture_replay)
        self.bootstrap_start_tick = self.events_meta.bootstrap_start_tick
        self.has_capture_creature_spawn_events = bool(self.events_meta.has_capture_creature_spawn_events)
        self.dt_frame_overrides = build_capture_dt_frame_overrides(capture, tick_rate=int(replay.header.tick_rate))
        self.dt_frame_ms_i32_overrides = build_capture_dt_frame_ms_i32_overrides(capture)
        if self.mode == int(GameMode.SURVIVAL):
            self.apply_world_dt_steps = should_apply_world_dt_steps_for_replay(
                original_capture_replay=bool(self.original_capture_replay),
                dt_frame_overrides=self.dt_frame_overrides,
                dt_frame_ms_i32_overrides=self.dt_frame_ms_i32_overrides,
            )
        else:
            self.apply_world_dt_steps = should_apply_world_dt_steps_for_replay(
                original_capture_replay=bool(self.original_capture_replay),
                dt_frame_overrides=self.dt_frame_overrides,
                dt_frame_ms_i32_overrides=self.dt_frame_ms_i32_overrides,
            )
        self.default_dt_frame = 1.0 / float(int(replay.header.tick_rate))
        outside_draws_overrides = build_capture_inter_tick_rand_draws_overrides(capture)
        self.outside_draws_by_tick = dict(outside_draws_overrides or {})
        self.use_outside_draws = bool(self.outside_draws_by_tick)

        self.capture_ticks_by_index: dict[int, CaptureTick] = {
            int(item.tick_index): item for item in capture.ticks
        }

        self.tick_start = 0
        if self.mode == int(GameMode.QUESTS) and self.bootstrap_start_tick is not None:
            self.tick_start = max(0, int(self.bootstrap_start_tick))
        self.quest_start_weapon_id = 1
        self.reset_spawn_entries: tuple[Any, ...] = ()
        self.pending_capture_state_reset = False

        self._initial_state = self._build_initial_state()
        self.world, self.session = copy.deepcopy(self._initial_state)
        if self.mode == int(GameMode.QUESTS):
            self._apply_bootstrap_quest_session_timers()
        self.current_tick = int(self.tick_start) - 1
        self.anchors: OrderedDict[int, tuple[WorldState, Any, bool]] = OrderedDict()

    def _build_initial_state(self) -> tuple[WorldState, Any]:
        world_size = float(self.replay.header.world_size)
        world = WorldState.build(
            world_size=world_size,
            demo_mode_active=False,
            hardcore=bool(self.replay.header.hardcore),
            difficulty_level=int(self.replay.header.difficulty_level),
            preserve_bugs=bool(self.replay.header.preserve_bugs),
        )
        reset_players(world.players, world_size=world_size, player_count=int(self.replay.header.player_count))
        world.state.status = status_from_snapshot(
            quest_unlock_index=int(self.replay.header.status.quest_unlock_index),
            quest_unlock_index_full=int(self.replay.header.status.quest_unlock_index_full),
            weapon_usage_counts=self.replay.header.status.weapon_usage_counts,
        )
        fx_queue, fx_queue_rotated = build_empty_fx_queues()
        damage_scale_by_type = build_damage_scale_by_type()

        if self.mode == int(GameMode.SURVIVAL):
            apply_replay_bootstrap(
                self.replay.header,
                rng=world.state.rng,
                world_size=float(world_size),
                strict=True,
            )
            session = SurvivalDeterministicSession(
                world=world,
                world_size=world_size,
                damage_scale_by_type=damage_scale_by_type,
                fx_queue=fx_queue,
                fx_queue_rotated=fx_queue_rotated,
                detail_preset=int(self.replay.header.detail_preset),
                fx_toggle=int(self.replay.header.fx_toggle),
                game_tune_started=False,
                apply_world_dt_steps=bool(self.apply_world_dt_steps),
                clear_fx_queues_each_tick=True,
            )
            return world, session

        world.state.rng.srand(int(self.replay.header.seed))
        quest_level = _resolve_quest_level(self.replay)
        quest = quest_by_level(quest_level) if quest_level else None
        if quest is None:
            raise ValueError(f"focus trace unsupported quest replay: unknown quest_level={quest_level!r}")

        world.state.quest_stage_major, world.state.quest_stage_minor = quest.level_key
        weapon_id = max(1, int(quest.start_weapon_id or 1))
        for player in world.players:
            weapon_assign_player(player, int(weapon_id))
        self.quest_start_weapon_id = int(weapon_id)

        ctx = QuestContext(
            width=int(world_size),
            height=int(world_size),
            player_count=int(self.replay.header.player_count),
        )
        spawn_entries = tuple(
            build_quest_spawn_table(
                quest,
                ctx,
                seed=int(self.replay.header.seed),
                hardcore=bool(self.replay.header.hardcore),
                full_version=True,
            ),
        )
        capture_spawn_events_authoritative = bool(self.original_capture_replay) and bool(
            self.has_capture_creature_spawn_events,
        )
        session_spawn_entries = tuple(spawn_entries)
        if capture_spawn_events_authoritative:
            # Mid-capture quest replays do not encode native quest spawn-table RNG seed/state.
            # Use captured spawn hooks as authoritative and disable local quest-table spawning.
            session_spawn_entries = ()
        world.creatures.capture_spawn_events_authoritative = bool(capture_spawn_events_authoritative)
        self.reset_spawn_entries = tuple(session_spawn_entries)

        session = QuestDeterministicSession(
            world=world,
            world_size=float(world_size),
            damage_scale_by_type=damage_scale_by_type,
            fx_queue=fx_queue,
            fx_queue_rotated=fx_queue_rotated,
            spawn_entries=tuple(session_spawn_entries),
            detail_preset=int(self.replay.header.detail_preset),
            fx_toggle=int(self.replay.header.fx_toggle),
            apply_world_dt_steps=bool(self.apply_world_dt_steps),
            clear_fx_queues_each_tick=True,
            finalize_post_render_lifecycle_each_tick=False,
        )
        return world, session

    def _reset(self) -> None:
        self.world, self.session = copy.deepcopy(self._initial_state)
        if self.mode == int(GameMode.QUESTS):
            self.pending_capture_state_reset = False
            self._apply_bootstrap_quest_session_timers()
        self.current_tick = int(self.tick_start) - 1

    def _apply_bootstrap_quest_session_timers(self) -> None:
        if self.mode != int(GameMode.QUESTS):
            return
        if self.bootstrap_start_tick is None:
            return
        if not isinstance(self.session, QuestDeterministicSession):
            return

        bootstrap_tick = int(self.bootstrap_start_tick)
        bootstrap_dt = resolve_dt_frame(
            tick_index=bootstrap_tick,
            default_dt_frame=float(self.default_dt_frame),
            dt_frame_overrides=self.dt_frame_overrides,
        )
        bootstrap_dt_ms = float(bootstrap_dt) * 1000.0
        if bootstrap_tick not in self.events_by_tick:
            return
        for event in self.events_by_tick[bootstrap_tick]:
            if not (isinstance(event, UnknownEvent) and str(event.kind) == CAPTURE_BOOTSTRAP_EVENT_KIND):
                continue
            payload = capture_bootstrap_payload_from_event_payload(list(event.payload))
            if payload is None:
                break
            if payload.quest_session is not None:
                self.session.spawn_timeline_ms = max(
                    0.0,
                    float(payload.quest_session.spawn_timeline_ms) - float(bootstrap_dt_ms),
                )
                self.session.no_creatures_timer_ms = max(
                    0.0,
                    float(payload.quest_session.no_creatures_timer_ms) - float(bootstrap_dt_ms),
                )
                completion_value = float(payload.quest_session.completion_transition_ms)
                if completion_value >= 0.0:
                    completion_value = max(0.0, float(completion_value) - float(bootstrap_dt_ms))
                self.session.completion_transition_ms = float(completion_value)
            break

    def _apply_capture_state_reset(self) -> None:
        if self.mode != int(GameMode.QUESTS):
            self.pending_capture_state_reset = False
            return
        if not isinstance(self.session, QuestDeterministicSession):
            self.pending_capture_state_reset = False
            return

        rng_state = int(self.world.state.rng.state)
        status = self.world.state.status
        game_mode = int(GameMode.QUESTS)
        demo_mode_active = bool(self.world.state.demo_mode_active)
        hardcore = bool(self.world.state.hardcore)
        preserve_bugs = bool(self.world.state.preserve_bugs)
        quest_stage_major_state = int(self.world.state.quest_stage_major)
        quest_stage_minor_state = int(self.world.state.quest_stage_minor)
        perk_pending = int(self.world.state.perk_selection.pending_count)
        perk_choices = list(self.world.state.perk_selection.choices)
        perk_choices_dirty = bool(self.world.state.perk_selection.choices_dirty)
        man_bomb_interval = float(self.world.state.perk_intervals.man_bomb)
        fire_cough_interval = float(self.world.state.perk_intervals.fire_cough)
        hot_tempered_interval = float(self.world.state.perk_intervals.hot_tempered)

        self.world.state = build_gameplay_state()
        self.world.state.rng.srand(int(rng_state))
        self.world.state.status = status
        self.world.state.game_mode = int(game_mode)
        self.world.state.demo_mode_active = bool(demo_mode_active)
        self.world.state.hardcore = bool(hardcore)
        self.world.state.preserve_bugs = bool(preserve_bugs)
        self.world.state.quest_stage_major = int(quest_stage_major_state)
        self.world.state.quest_stage_minor = int(quest_stage_minor_state)
        self.world.state.perk_selection.pending_count = int(perk_pending)
        self.world.state.perk_selection.choices = list(perk_choices)
        self.world.state.perk_selection.choices_dirty = bool(perk_choices_dirty)
        self.world.state.perk_intervals.man_bomb = float(man_bomb_interval)
        self.world.state.perk_intervals.fire_cough = float(fire_cough_interval)
        self.world.state.perk_intervals.hot_tempered = float(hot_tempered_interval)

        world_size = float(self.replay.header.world_size)
        reset_players(
            self.world.players,
            world_size=float(world_size),
            player_count=int(self.replay.header.player_count),
        )
        for player in self.world.players:
            weapon_assign_player(player, int(self.quest_start_weapon_id))
            if int(self.quest_start_weapon_id) == int(WeaponId.PISTOL):
                player.clip_size = max(12, int(player.clip_size))
                if float(player.ammo) < 12.0:
                    player.ammo = 12.0
        self.world.spawn_env = replace(
            self.world.spawn_env,
            difficulty_level=max(1, int(self.world.spawn_env.difficulty_level)),
        )
        self.world.creatures.env = self.world.spawn_env
        self.world.creatures.effects = self.world.state.effects
        self.world.creatures.reset()
        self.world.creatures.capture_spawn_events_authoritative = bool(
            self.original_capture_replay and self.has_capture_creature_spawn_events,
        )

        self.session.fx_queue.clear()
        self.session.fx_queue_rotated.clear()

        self.session.spawn_entries = tuple(self.reset_spawn_entries)
        self.session.spawn_timeline_ms = 0.0
        self.session.no_creatures_timer_ms = 0.0
        self.session.completion_transition_ms = -1.0
        self.pending_capture_state_reset = False

    def _on_capture_state_transition(
        self,
        target_state: int,
        _before_state: int | None,
        _after_state: int | None,
    ) -> None:
        if int(target_state) != 12:
            return
        self.pending_capture_state_reset = True

    def _store_anchor(self, tick_index: int) -> None:
        if tick_index < 0:
            return
        if (tick_index % _FOCUS_ANCHOR_INTERVAL) != 0:
            return
        self.anchors[int(tick_index)] = copy.deepcopy((self.world, self.session, self.pending_capture_state_reset))
        self.anchors.move_to_end(int(tick_index), last=True)
        while len(self.anchors) > _FOCUS_ANCHOR_LIMIT:
            self.anchors.popitem(last=False)

    def _restore_nearby_anchor(self, target_tick: int) -> bool:
        if not self.anchors:
            return False
        cap = int(target_tick) - 1
        candidates = [tick for tick in self.anchors if tick <= cap]
        if not candidates:
            return False
        best = max(candidates)
        if int(target_tick) - int(best) > _FOCUS_NEAR_TICK_WINDOW:
            return False
        anchor_state = self.anchors.get(int(best))
        if anchor_state is None:
            return False
        self.world, self.session, self.pending_capture_state_reset = copy.deepcopy(anchor_state)
        self.current_tick = int(best)
        return True

    def _build_capture_tick_payload(
        self,
        tick: CaptureTick,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], int]:
        capture_creatures: list[dict[str, Any]] = []
        capture_projectiles: list[dict[str, Any]] = []
        if tick.samples is not None:
            for item in tick.samples.creatures:
                capture_creatures.append(
                    {
                        "index": int(item.index),
                        "active": int(item.active),
                        "type_id": int(item.type_id),
                        "hp": float(item.hp),
                        "hitbox_size": float(item.hitbox_size),
                        "pos": {"x": float(item.pos.x), "y": float(item.pos.y)},
                    },
                )
            for item in tick.samples.projectiles:
                capture_projectiles.append(
                    {
                        "index": int(item.index),
                        "active": int(item.active),
                        "type_id": int(item.type_id),
                        "life_timer": float(item.life_timer),
                        "damage_pool": float(item.damage_pool),
                        "pos": {"x": float(item.pos.x), "y": float(item.pos.y)},
                    },
                )

        capture_rng_head = [_capture_rng_head_entry_to_row(entry) for entry in tick.rng.head]
        capture_rng_calls = int(tick.rng.calls)
        if capture_rng_calls < len(capture_rng_head):
            capture_rng_calls = len(capture_rng_head)
        return capture_creatures, capture_projectiles, capture_rng_head, capture_rng_calls

    def _step_tick(
        self,
        tick_index: int,
        trace: _FocusStepTraceContext | None,
    ) -> None:
        tick_key = int(tick_index)
        if self.mode == int(GameMode.QUESTS) and self.pending_capture_state_reset:
            self._apply_capture_state_reset()

        self.world.state.game_mode = int(self.mode)
        self.world.state.demo_mode_active = False

        if self.use_outside_draws:
            if tick_key in self.outside_draws_by_tick:
                draws = self.outside_draws_by_tick[tick_key]
            else:
                draws = self.inter_tick_rand_draws
            for _ in range(max(0, int(draws))):
                self.world.state.rng.rand()

        dt_tick = resolve_dt_frame(
            tick_index=tick_key,
            default_dt_frame=float(self.default_dt_frame),
            dt_frame_overrides=self.dt_frame_overrides,
        )
        dt_tick_ms_i32 = resolve_dt_frame_ms_i32(
            tick_index=tick_key,
            dt_frame=float(dt_tick),
            dt_frame_ms_i32_overrides=self.dt_frame_ms_i32_overrides,
        )

        if tick_key in self.events_by_tick:
            tick_events = self.events_by_tick[tick_key]
        else:
            tick_events = []
        pre_step_events, post_step_events = partition_tick_events(
            tick_events,
            defer_menu_open=bool(self.original_capture_replay),
        )

        apply_replay_tick_events(
            pre_step_events,
            tick_index=tick_key,
            dt_frame=float(dt_tick),
            world=self.world,
            game_mode_id=int(self.mode),
            strict_events=False,
            on_capture_state_transition=(
                self._on_capture_state_transition if self.mode == int(GameMode.QUESTS) else None
            ),
        )
        if self.mode == int(GameMode.QUESTS) and self.pending_capture_state_reset:
            self._apply_capture_state_reset()
        player_inputs = _decode_inputs_for_tick(self.replay, tick_key)

        orig_rand = self.world.state.rng.rand
        orig_particles_rand = self.world.state.particles._rand
        orig_sprite_effects_rand = self.world.state.sprite_effects._rand
        orig_within = projectiles_mod._within_native_find_radius
        orig_within_projectile_pool = projectile_pool_mod._within_native_find_radius
        orig_within_secondary_pool = secondary_pool_mod._within_native_find_radius
        orig_run_projectile_decal_hooks = presentation_step_mod.run_projectile_decal_hooks

        try:
            if trace is not None:
                trace.pre_projectiles[:] = _projectile_snapshot(self.world)

                def traced_rand() -> int:
                    value = int(orig_rand())
                    frame = None
                    try:
                        import inspect

                        frame = inspect.currentframe()
                    except (TypeError, ValueError):
                        frame = None
                    caller = frame.f_back if frame is not None else None
                    key = "<unknown>"
                    while caller is not None:
                        filename = Path(caller.f_code.co_filename).resolve()
                        try:
                            rel = filename.relative_to(self.root)
                        except ValueError:
                            rel = filename
                        rel_s = str(rel)
                        if "src/crimson/" in rel_s:
                            key = f"{rel_s}:{caller.f_code.co_name}:{caller.f_lineno}"
                            break
                        caller = caller.f_back
                    trace.rng_callsites[key] += 1
                    if len(trace.rng_head) < 256:
                        trace.rng_head.append(key)
                    trace.rng_values.append(int(value))
                    trace.rng_values_callsites.append(str(key))
                    return value

                def traced_within_native_find_radius(
                    *,
                    origin: Any,
                    target: Any,
                    radius: float,
                    target_size: float,
                ) -> bool:
                    dx = float(target.x) - float(origin.x)
                    dy = float(target.y) - float(origin.y)
                    dist = (dx * dx + dy * dy) ** 0.5
                    threshold = float(target_size) * 0.14285715 + 3.0
                    margin = dist - float(radius) - float(threshold)
                    hit = bool(margin < 0.0)

                    step: int | None = None
                    creature_idx: int | None = None
                    proj_index: int | None = None
                    proj_type: int | None = None
                    proj_life: float | None = None
                    try:
                        import inspect

                        frame = inspect.currentframe().f_back  # ty:ignore[possibly-missing-attribute]
                    except (TypeError, ValueError):
                        frame = None
                    if frame is not None:
                        step = _optional_int(frame.f_locals.get("step") if "step" in frame.f_locals else None)
                        creature_idx = _optional_int(frame.f_locals.get("idx") if "idx" in frame.f_locals else None)
                        proj_index = _optional_int(
                            frame.f_locals.get("proj_index") if "proj_index" in frame.f_locals else None,
                        )
                        proj = frame.f_locals.get("proj")
                        if proj is not None:
                            try:
                                proj_ref = cast("Any", proj)
                                proj_type = int(proj_ref.type_id)
                                proj_life = float(proj_ref.life_timer)
                            except (AttributeError, TypeError, ValueError):
                                proj_type = None
                                proj_life = None

                    row = CollisionRow(
                        proj_index=proj_index,
                        proj_type=proj_type,
                        proj_life=proj_life,
                        step=step,
                        creature_idx=creature_idx,
                        margin=float(margin),
                        dist=float(dist),
                        radius=float(radius),
                        threshold=float(threshold),
                        hit=bool(hit),
                    )
                    if bool(hit):
                        trace.collision_hits.append(row)
                    elif 0.0 <= float(margin) <= float(trace.near_miss_threshold):
                        trace.near_misses.append(row)
                    return bool(hit)

                hook_index = 0

                def traced_run_projectile_decal_hooks(ctx: Any) -> bool:
                    nonlocal hook_index
                    before = len(trace.rng_values)
                    handled = bool(orig_run_projectile_decal_hooks(ctx))
                    after = len(trace.rng_values)
                    hit = ctx.hit
                    trace.decal_hook_rows.append(
                        DecalHookRow(
                            hook_index=int(hook_index),
                            type_id=int(hit.type_id),
                            handled=bool(handled),
                            rng_draws=max(0, int(after - before)),
                            target_x=float(hit.target.x),
                            target_y=float(hit.target.y),
                        ),
                    )
                    hook_index += 1
                    return bool(handled)

                rng_ref = cast("Any", self.world.state.rng)
                rng_ref.rand = traced_rand
                self.world.state.particles._rand = traced_rand
                self.world.state.sprite_effects._rand = traced_rand
                projectiles_mod._within_native_find_radius = traced_within_native_find_radius  # type: ignore[assignment]
                projectile_pool_mod._within_native_find_radius = traced_within_native_find_radius  # type: ignore[assignment]
                secondary_pool_mod._within_native_find_radius = traced_within_native_find_radius  # type: ignore[assignment]
                presentation_step_mod.run_projectile_decal_hooks = traced_run_projectile_decal_hooks  # type: ignore[assignment]

            if self.mode == int(GameMode.SURVIVAL):
                if not isinstance(self.session, SurvivalDeterministicSession):
                    raise ValueError("missing survival focus trace runtime session")
                tick_result = self.session.step_tick(
                    dt_frame=float(dt_tick),
                    dt_frame_ms_i32=(int(dt_tick_ms_i32) if dt_tick_ms_i32 is not None else None),
                    inputs=player_inputs,
                    trace_rng=False,
                )
            else:
                if not isinstance(self.session, QuestDeterministicSession):
                    raise ValueError("missing quest focus trace runtime session")
                tick_result = self.session.step_tick(
                    dt_frame=float(dt_tick),
                    dt_frame_ms_i32=(int(dt_tick_ms_i32) if dt_tick_ms_i32 is not None else None),
                    inputs=player_inputs,
                    trace_rng=False,
                )

            if trace is not None:
                trace.post_projectiles[:] = _projectile_snapshot(self.world)
                trace.focus_hits = int(len(tick_result.step.events.hits))
                trace.focus_deaths = int(len(tick_result.step.events.deaths))
                trace.focus_sfx = int(len(tick_result.step.events.sfx))

            if post_step_events:
                apply_replay_tick_events(
                    post_step_events,
                    tick_index=int(tick_index),
                    dt_frame=float(dt_tick),
                    world=self.world,
                    game_mode_id=int(self.mode),
                    strict_events=False,
                    on_capture_state_transition=(
                        self._on_capture_state_transition if self.mode == int(GameMode.QUESTS) else None
                    ),
                )
            if self.mode == int(GameMode.QUESTS):
                self.world.creatures.finalize_post_render_lifecycle()
        finally:
            rng_ref = cast("Any", self.world.state.rng)
            rng_ref.rand = orig_rand
            self.world.state.particles._rand = orig_particles_rand
            self.world.state.sprite_effects._rand = orig_sprite_effects_rand
            projectiles_mod._within_native_find_radius = orig_within
            projectile_pool_mod._within_native_find_radius = orig_within_projectile_pool
            secondary_pool_mod._within_native_find_radius = orig_within_secondary_pool
            presentation_step_mod.run_projectile_decal_hooks = orig_run_projectile_decal_hooks

        if not self.use_outside_draws:
            for _ in range(max(0, int(self.inter_tick_rand_draws))):
                self.world.state.rng.rand()

    def trace_tick(self, *, tick: int, near_miss_threshold: float) -> FocusTraceReport:
        target_tick = int(tick)
        if target_tick < 0:
            raise ValueError(f"tick must be non-negative (got {target_tick})")
        if int(target_tick) < int(self.tick_start):
            raise ValueError(
                f"capture tick {int(target_tick)} precedes quest bootstrap start tick {int(self.tick_start)}",
            )

        capture_tick = self.capture_ticks_by_index.get(int(target_tick))
        if capture_tick is None:
            raise ValueError(f"capture tick {target_tick} not found")

        if self.current_tick >= target_tick:
            if not self._restore_nearby_anchor(target_tick):
                self._reset()

        if self.current_tick >= 0 and (target_tick - self.current_tick) > _FOCUS_NEAR_TICK_WINDOW:
            self._reset()

        trace_ctx = _FocusStepTraceContext(
            tick=int(target_tick),
            near_miss_threshold=max(0.0, float(near_miss_threshold)),
            rng_callsites=Counter(),
            rng_head=[],
            rng_values=[],
            rng_values_callsites=[],
            collision_hits=[],
            near_misses=[],
            decal_hook_rows=[],
            pre_projectiles=[],
            post_projectiles=[],
            focus_hits=0,
            focus_deaths=0,
            focus_sfx=0,
        )

        step_start = max(int(self.current_tick) + 1, int(self.tick_start))
        for tick_index in range(int(step_start), int(target_tick) + 1):
            is_focus_tick = int(tick_index) == int(target_tick)
            self._step_tick(int(tick_index), trace_ctx if is_focus_tick else None)
            self.current_tick = int(tick_index)
            self._store_anchor(int(tick_index))

        trace_ctx.near_misses.sort(key=lambda row: float(row.margin))
        trace_ctx.collision_hits.sort(
            key=lambda row: (int(row.proj_index or -1), int(row.step or -1), int(row.creature_idx or -1)),
        )

        capture_creatures, capture_projectiles, capture_rng_head, capture_rng_calls = self._build_capture_tick_payload(capture_tick)
        creature_diffs_top = _summarize_creature_diffs(capture_creatures, self.world)
        projectile_diffs_top = _summarize_projectile_diffs(capture_projectiles, self.world)
        creature_capture_only, creature_rewrite_only = _collect_creature_presence_diffs(capture_creatures, self.world)
        projectile_capture_only, projectile_rewrite_only = _collect_projectile_presence_diffs(capture_projectiles, self.world)
        rng_alignment = _summarize_rng_alignment(
            capture_rng_head=capture_rng_head,
            capture_rng_calls=int(capture_rng_calls),
            rewrite_rng_values=trace_ctx.rng_values,
            rewrite_rng_callsites=trace_ctx.rng_values_callsites,
        )
        native_caller_gaps_top = _build_native_caller_gaps(rng_alignment)
        fire_bullets_loop_parity = _build_fire_bullets_loop_parity(rng_alignment)

        return FocusTraceReport(
            tick=int(target_tick),
            hits=int(trace_ctx.focus_hits),
            deaths=int(trace_ctx.focus_deaths),
            sfx=int(trace_ctx.focus_sfx),
            rand_calls_total=int(sum(trace_ctx.rng_callsites.values())),
            rng_callsites_top=list(trace_ctx.rng_callsites.most_common(64)),
            rng_callsites_head=list(trace_ctx.rng_head),
            collision_hits=trace_ctx.collision_hits,
            collision_near_misses=trace_ctx.near_misses,
            pre_projectiles=trace_ctx.pre_projectiles,
            post_projectiles=trace_ctx.post_projectiles,
            capture_projectiles=list(capture_projectiles),
            capture_creatures=list(capture_creatures),
            creature_diffs_top=creature_diffs_top,
            creature_capture_only=creature_capture_only,
            creature_rewrite_only=creature_rewrite_only,
            projectile_diffs_top=projectile_diffs_top,
            projectile_capture_only=projectile_capture_only,
            projectile_rewrite_only=projectile_rewrite_only,
            decal_hook_rows=trace_ctx.decal_hook_rows,
            rng_alignment=rng_alignment,
            native_caller_gaps_top=native_caller_gaps_top,
            fire_bullets_loop_parity=fire_bullets_loop_parity,
        )


def cache_enabled() -> bool:
    if "CRIMSON_ORIGINAL_CACHE" in os.environ:
        raw_value = os.environ["CRIMSON_ORIGINAL_CACHE"]
    else:
        raw_value = "1"
    raw = str(raw_value).strip().lower()
    return raw not in {"0", "false", "off", "no"}


def _cache_dirs() -> PlatformDirs:
    return PlatformDirs(appname=APP_NAME, appauthor=False)


def default_cache_root() -> Path:
    return Path(_cache_dirs().user_cache_path) / "original-diagnostics"


def cache_root() -> Path:
    override = os.environ.get("CRIMSON_ORIGINAL_CACHE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return default_cache_root().resolve()


def socket_path() -> Path:
    override = os.environ.get("CRIMSON_ORIGINAL_CACHE_SOCKET")
    if override:
        return Path(override).expanduser().resolve()
    return cache_root() / "daemon.sock"


def idle_timeout_seconds() -> int:
    raw = os.environ.get("CRIMSON_ORIGINAL_CACHE_IDLE_TIMEOUT_SECONDS")
    if raw is None:
        return int(_DEFAULT_IDLE_TIMEOUT_SECONDS)
    try:
        parsed = int(raw)
    except ValueError:
        return int(_DEFAULT_IDLE_TIMEOUT_SECONDS)
    return max(60, int(parsed))


def normalize_override_pairs(mapping: Mapping[int, int] | None) -> tuple[tuple[int, int], ...]:
    if not mapping:
        return tuple()
    return tuple(sorted((int(player), int(scheme)) for player, scheme in mapping.items()))


def build_replay_key(
    *,
    max_ticks: int | None,
    seed: int | None,
    inter_tick_rand_draws: int,
    aim_scheme_overrides_by_player: Mapping[int, int] | None,
) -> ReplayKey:
    return ReplayKey(
        max_ticks=(None if max_ticks is None else int(max_ticks)),
        seed=(None if seed is None else int(seed)),
        inter_tick_rand_draws=max(0, int(inter_tick_rand_draws)),
        aim_scheme_overrides=normalize_override_pairs(aim_scheme_overrides_by_player),
    )


def build_focus_key(
    *,
    inter_tick_rand_draws: int,
    aim_scheme_overrides_by_player: Mapping[int, int] | None,
) -> FocusKey:
    return FocusKey(
        inter_tick_rand_draws=max(0, int(inter_tick_rand_draws)),
        aim_scheme_overrides=normalize_override_pairs(aim_scheme_overrides_by_player),
    )


def _optional_int(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(cast(Any, value))
    except (TypeError, ValueError):
        return None


def _cache_id_for_fingerprint(fingerprint: CaptureFingerprint) -> str:
    key = "\n".join(
        (
            str(fingerprint.resolved_path),
            str(int(fingerprint.size)),
            str(int(fingerprint.mtime_ns)),
        ),
    ).encode("utf-8")
    return hashlib.sha256(key).hexdigest()[:24]


def _meta_matches(path: Path, fingerprint: CaptureFingerprint) -> bool:
    if not path.exists():
        return False
    try:
        meta_obj = json.loads(path.read_text(encoding="utf-8"))
        meta = msgspec.convert(meta_obj, type=_CaptureMeta, strict=True)
    except (TypeError, ValueError):
        return False
    if int(meta.schema_version) != int(_CACHE_SCHEMA_VERSION):
        return False
    cached = meta.fingerprint
    return (
        str(cached.resolved_path) == str(fingerprint.resolved_path)
        and int(cached.size) == int(fingerprint.size)
        and int(cached.mtime_ns) == int(fingerprint.mtime_ns)
    )


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp_path.write_bytes(data)
    tmp_path.replace(path)


def _atomic_write_text(path: Path, text: str) -> None:
    _atomic_write_bytes(path, text.encode("utf-8"))


def _write_msgpack_gz(path: Path, value: object) -> None:
    payload = msgspec.msgpack.encode(value)
    _atomic_write_bytes(path, gzip.compress(payload))


def _read_msgpack_gz(path: Path, *, type: type[_DecodedT]) -> _DecodedT:
    raw = gzip.decompress(path.read_bytes())
    return msgspec.msgpack.decode(raw, type=type)


def _read_capture(path: Path) -> CaptureFile:
    return load_capture(path)


def capture_fingerprint(path: Path, *, include_sha256: bool = False) -> CaptureFingerprint:
    resolved = Path(path).expanduser().resolve()
    stat = resolved.stat()
    sha256_hex: str | None = None
    if include_sha256:
        sha = hashlib.sha256()
        with resolved.open("rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                sha.update(chunk)
        sha256_hex = sha.hexdigest()
    return CaptureFingerprint(
        resolved_path=str(resolved),
        size=int(stat.st_size),
        mtime_ns=int(stat.st_mtime_ns),
        sha256=sha256_hex,
    )


def _weapon_name(weapon_id: int) -> str:
    entry = WEAPON_BY_ID.get(int(weapon_id))
    name = entry.name if entry is not None else None
    if name is None:
        return f"Weapon {int(weapon_id)}"
    return f"{name} ({int(weapon_id)})"


def _bonus_name(bonus_id: int) -> str:
    if int(bonus_id) < 0:
        return f"Bonus {int(bonus_id)}"
    return f"{bonus_label(int(bonus_id))} ({int(bonus_id)})"


def _append_run_summary_event(
    out: list[RunSummaryEventLite],
    *,
    seen: set[tuple[int, str, str]],
    tick: int,
    kind: str,
    detail: str,
) -> None:
    key = (int(tick), str(kind), str(detail))
    if key in seen:
        return
    seen.add(key)
    out.append(
        RunSummaryEventLite(
            tick_index=int(tick),
            kind=str(kind),
            detail=str(detail),
        ),
    )


def _parse_player_perk_counts(tick: CaptureTick) -> dict[int, Counter[int]]:
    out: dict[int, Counter[int]] = {}
    for player_idx, player_counts in enumerate(tick.checkpoint.perk.player_nonzero_counts):
        counts = Counter()
        for pair in player_counts:
            if len(pair) != 2:
                continue
            perk_id = int(pair[0])
            perk_count = int(pair[1])
            if perk_id < 0 or perk_count <= 0:
                continue
            counts[int(perk_id)] = int(perk_count)
        if counts:
            out[int(player_idx)] = counts
    return out


def _build_run_summary_events_from_capture(capture: CaptureFile) -> list[RunSummaryEventLite]:
    events: list[RunSummaryEventLite] = []
    seen: set[tuple[int, str, str]] = set()
    prev_levels: dict[int, int] = {}
    prev_perk_counts: dict[int, Counter[int]] = {}

    for tick in capture.ticks:
        tick_index = int(tick.tick_index)
        for head in tick.event_heads:
            if isinstance(head, CaptureEventHeadBonusApply):
                player_index = int(head.data.player_index) if head.data.player_index is not None else 0
                bonus_id = int(head.data.bonus_id) if head.data.bonus_id is not None else -1
                detail = f"p{player_index} picked {_bonus_name(int(bonus_id))}"
                if int(bonus_id) == 3:
                    weapon_id = int(head.data.amount_i32) if head.data.amount_i32 is not None else -1
                    if weapon_id >= 0:
                        detail += f" -> {_weapon_name(int(weapon_id))}"
                _append_run_summary_event(
                    events,
                    seen=seen,
                    tick=int(tick_index),
                    kind="bonus_pickup",
                    detail=detail,
                )
                continue

            if isinstance(head, CaptureEventHeadWeaponAssign):
                player_index = int(head.data.player_index) if head.data.player_index is not None else 0
                weapon_before = int(head.data.weapon_before) if head.data.weapon_before is not None else -1
                if head.data.weapon_after is not None:
                    weapon_after = int(head.data.weapon_after)
                elif head.data.weapon_id is not None:
                    weapon_after = int(head.data.weapon_id)
                else:
                    weapon_after = -1
                _append_run_summary_event(
                    events,
                    seen=seen,
                    tick=int(tick_index),
                    kind="weapon_assign",
                    detail=(
                        f"p{player_index} weapon "
                        f"{_weapon_name(int(weapon_before))} -> {_weapon_name(int(weapon_after))}"
                    ),
                )
                continue

            if isinstance(head, CaptureEventHeadStateTransition):
                before_state = int(head.data.before.id) if head.data.before.id is not None else -1
                if head.data.after.id is not None:
                    after_state = int(head.data.after.id)
                else:
                    after_state = int(head.data.target_state)
                _append_run_summary_event(
                    events,
                    seen=seen,
                    tick=int(tick_index),
                    kind="state_transition",
                    detail=f"state {before_state} -> {after_state}",
                )

        for player_index, player in enumerate(tick.checkpoint.players):
            level = int(player.level)
            prev_level = prev_levels.get(int(player_index))
            if prev_level is not None and int(level) > int(prev_level):
                _append_run_summary_event(
                    events,
                    seen=seen,
                    tick=int(tick_index),
                    kind="level_up",
                    detail=f"p{int(player_index)} level {int(prev_level)} -> {int(level)} (xp={int(player.experience)})",
                )
            prev_levels[int(player_index)] = int(level)

        perk_counts = _parse_player_perk_counts(tick)
        for player_index, player_counts in perk_counts.items():
            player_key = int(player_index)
            if player_key in prev_perk_counts:
                previous = prev_perk_counts[player_key]
            else:
                previous = Counter()
            for perk_id, perk_count in sorted(player_counts.items()):
                perk_key = int(perk_id)
                if perk_key in previous:
                    previous_count = int(previous[perk_key])
                else:
                    previous_count = 0
                if int(perk_count) <= int(previous_count):
                    continue
                _append_run_summary_event(
                    events,
                    seen=seen,
                    tick=int(tick_index),
                    kind="perk_pick",
                    detail=(
                        f"p{int(player_index)} perk {perk_label(int(perk_id))} ({int(perk_id)}) "
                        f"x{int(perk_count)}"
                    ),
                )
            prev_perk_counts[player_key] = Counter(player_counts)

    events.sort(key=lambda item: (int(item.tick_index), str(item.kind), str(item.detail)))
    return events


def _capture_sample_rate(capture: CaptureFile) -> int:
    ticks = sorted(int(tick.tick_index) for tick in capture.ticks)
    if len(ticks) < 2:
        return 1
    deltas = [next_tick - tick for tick, next_tick in zip(ticks, ticks[1:]) if int(next_tick) > int(tick)]
    if not deltas:
        return 1
    deltas.sort()
    return max(1, int(deltas[len(deltas) // 2]))


class CaptureSession:
    def __init__(self, capture_path: Path) -> None:
        resolved = Path(capture_path).expanduser().resolve()
        self.capture_path = resolved
        self.fingerprint = capture_fingerprint(resolved)
        self.cache_dir = cache_root() / _cache_id_for_fingerprint(self.fingerprint)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.capture = self._load_or_build_capture()
        self.sample_rate = _capture_sample_rate(self.capture)
        self.ticks_by_index = {int(tick.tick_index): tick for tick in self.capture.ticks}
        self.sample_creature_counts = {
            int(tick_index): int(len(tick.samples.creatures))
            for tick_index, tick in self.ticks_by_index.items()
        }
        self.run_summary_events = _build_run_summary_events_from_capture(self.capture)

        self._replay_cache: OrderedDict[ReplayKey, tuple[list[ReplayCheckpoint], list[ReplayCheckpoint], object, object]] = (
            OrderedDict()
        )
        self._divergence_cache: OrderedDict[tuple[ReplayKey, float, int], object] = OrderedDict()
        self._focus_runtime_by_key: dict[FocusKey, _FocusRuntimeLike] = {}
        self._focus_report_cache: OrderedDict[tuple[FocusKey, int, float], FocusTraceReport] = OrderedDict()

    def matches_current_file(self) -> bool:
        try:
            current = capture_fingerprint(self.capture_path)
        except OSError:
            return False
        return (
            str(current.resolved_path) == str(self.fingerprint.resolved_path)
            and int(current.size) == int(self.fingerprint.size)
            and int(current.mtime_ns) == int(self.fingerprint.mtime_ns)
        )

    def _load_or_build_capture(self) -> CaptureFile:
        capture_blob_path = self.cache_dir / _CAPTURE_BLOB_NAME
        meta_path = self.cache_dir / _META_NAME
        if _meta_matches(meta_path, self.fingerprint) and capture_blob_path.exists():
            try:
                return _read_msgpack_gz(capture_blob_path, type=CaptureFile)
            except (TypeError, ValueError):
                pass

        capture = _read_capture(self.capture_path)
        _write_msgpack_gz(capture_blob_path, capture)
        meta = _CaptureMeta(schema_version=int(_CACHE_SCHEMA_VERSION), fingerprint=self.fingerprint)
        _atomic_write_text(meta_path, msgspec.json.encode(meta).decode("utf-8"))
        return capture

    def get_capture(self) -> CaptureFile:
        return self.capture

    def get_sample_rate(self) -> int:
        return int(self.sample_rate)

    def get_sample_creature_counts(self) -> dict[int, int]:
        return dict(self.sample_creature_counts)

    def get_raw_debug_by_tick(self, tick_indices: set[int] | None = None) -> dict[int, CaptureTick]:
        if tick_indices is None:
            return dict(self.ticks_by_index)
        return {
            int(tick): row
            for tick, row in self.ticks_by_index.items()
            if int(tick) in tick_indices
        }

    def get_run_summary_events(self) -> list[RunSummaryEventLite]:
        return list(self.run_summary_events)

    def get_replay_outcome(
        self,
        key: ReplayKey,
    ) -> tuple[list[ReplayCheckpoint], list[ReplayCheckpoint], object, object]:
        cached = self._replay_cache.get(key)
        if cached is not None:
            self._replay_cache.move_to_end(key, last=True)
            return cached

        from . import divergence_report as divergence_report_mod

        aim_overrides = {int(player): int(scheme) for player, scheme in key.aim_scheme_overrides}
        expected, actual, run_result = divergence_report_mod._run_actual_checkpoints(
            self.capture,
            max_ticks=key.max_ticks,
            seed=key.seed,
            inter_tick_rand_draws=int(key.inter_tick_rand_draws),
            aim_scheme_overrides_by_player=aim_overrides,
        )
        replay = convert_capture_to_replay(
            self.capture,
            seed=key.seed,
            aim_scheme_overrides_by_player=aim_overrides,
        )
        result = (expected, actual, run_result, replay)
        self._replay_cache[key] = result
        self._replay_cache.move_to_end(key, last=True)
        while len(self._replay_cache) > 8:
            self._replay_cache.popitem(last=False)
        return result

    def get_divergence(
        self,
        *,
        replay_key: ReplayKey,
        expected: list[ReplayCheckpoint],
        actual: list[ReplayCheckpoint],
        float_abs_tol: float,
        max_field_diffs: int,
    ) -> object:
        cache_key = (replay_key, float(float_abs_tol), int(max_field_diffs))
        cached = self._divergence_cache.get(cache_key)
        if cached is not None:
            self._divergence_cache.move_to_end(cache_key, last=True)
            return cached

        from . import divergence_report as divergence_report_mod

        divergence = divergence_report_mod._find_first_divergence(
            expected,
            actual,
            float_abs_tol=float(float_abs_tol),
            max_field_diffs=max(1, int(max_field_diffs)),
            capture_sample_creature_counts=self.sample_creature_counts,
            raw_debug_by_tick=self.get_raw_debug_by_tick(),
        )

        self._divergence_cache[cache_key] = divergence
        self._divergence_cache.move_to_end(cache_key, last=True)
        while len(self._divergence_cache) > 16:
            self._divergence_cache.popitem(last=False)
        return divergence

    def get_focus_report(
        self,
        *,
        key: FocusKey,
        tick: int,
        near_miss_threshold: float,
    ) -> FocusTraceReport:
        report_key = (key, int(tick), round(float(near_miss_threshold), 6))
        cached = self._focus_report_cache.get(report_key)
        if cached is not None:
            self._focus_report_cache.move_to_end(report_key, last=True)
            return cached

        runtime = self._focus_runtime_by_key.get(key)
        if runtime is None:
            replay = convert_capture_to_replay(
                self.capture,
                aim_scheme_overrides_by_player={int(player): int(scheme) for player, scheme in key.aim_scheme_overrides},
            )
            runtime = _FocusRuntime(
                capture=self.capture,
                replay=replay,
                inter_tick_rand_draws=int(key.inter_tick_rand_draws),
            )
            self._focus_runtime_by_key[key] = runtime

        report = runtime.trace_tick(
            tick=int(tick),
            near_miss_threshold=float(near_miss_threshold),
        )
        self._focus_report_cache[report_key] = report
        self._focus_report_cache.move_to_end(report_key, last=True)
        while len(self._focus_report_cache) > 128:
            self._focus_report_cache.popitem(last=False)
        return report


class SessionRegistry:
    def __init__(self) -> None:
        self._sessions: OrderedDict[str, CaptureSession] = OrderedDict()

    def get_session(self, capture_path: Path) -> CaptureSession:
        resolved = Path(capture_path).expanduser().resolve()
        key = str(resolved)
        existing = self._sessions.get(key)
        if existing is not None and existing.matches_current_file():
            self._sessions.move_to_end(key, last=True)
            return existing

        session = CaptureSession(resolved)
        self._sessions[key] = session
        self._sessions.move_to_end(key, last=True)
        while len(self._sessions) > 4:
            self._sessions.popitem(last=False)
        return session


def replay_key_from_args(args: argparse.Namespace, *, aim_scheme_overrides: Mapping[int, int]) -> ReplayKey:
    return build_replay_key(
        max_ticks=args.max_ticks,
        seed=args.seed,
        inter_tick_rand_draws=args.inter_tick_rand_draws,
        aim_scheme_overrides_by_player=aim_scheme_overrides,
    )


def focus_key_from_args(args: argparse.Namespace, *, aim_scheme_overrides: Mapping[int, int]) -> FocusKey:
    return build_focus_key(
        inter_tick_rand_draws=args.inter_tick_rand_draws,
        aim_scheme_overrides_by_player=aim_scheme_overrides,
    )
