from __future__ import annotations

"""Shared aim tuning constants used by both input sampling and gameplay update."""

_AIM_KEYBOARD_TURN_RATE = 3.0
_AIM_JOYSTICK_TURN_RATE = 4.0

__all__ = [
    "_AIM_KEYBOARD_TURN_RATE",
    "_AIM_JOYSTICK_TURN_RATE",
]
