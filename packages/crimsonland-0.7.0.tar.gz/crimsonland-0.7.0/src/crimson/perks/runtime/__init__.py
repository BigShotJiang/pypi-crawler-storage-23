from __future__ import annotations

"""Perk runtime dispatch and hook contracts."""
