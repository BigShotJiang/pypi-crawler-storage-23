from __future__ import annotations

from ..ids import PerkId
from ..runtime.apply_context import PerkApplyCtx
from ..runtime.hook_types import PerkHooks


def apply_thick_skinned(ctx: PerkApplyCtx) -> None:
    for player in ctx.players:
        if player.health > 0.0:
            player.health = max(1.0, player.health * (2.0 / 3.0))


HOOKS = PerkHooks(
    perk_id=PerkId.THICK_SKINNED,
    apply_handler=apply_thick_skinned,
)
