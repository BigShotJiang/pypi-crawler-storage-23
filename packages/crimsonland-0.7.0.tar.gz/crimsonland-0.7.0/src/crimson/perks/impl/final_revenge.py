from __future__ import annotations

from typing import TYPE_CHECKING

from grim.geom import Vec2

from ...creatures.damage_types import CreatureDamageType
from ...creatures.spawn import CreatureFlags
from ...effects import FxQueue
from ...sim.state_types import GameplayState, PlayerState
from ..helpers import perk_active
from ..ids import PerkId
from ..runtime.hook_types import PerkHooks

if TYPE_CHECKING:
    from ...creatures.runtime import CreatureDeath, CreaturePool


def apply_final_revenge_on_player_death(
    *,
    state: GameplayState,
    creatures: CreaturePool,
    players: list[PlayerState],
    player: PlayerState,
    dt: float,
    world_size: float,
    detail_preset: int,
    fx_queue: FxQueue | None,
    deaths: list[CreatureDeath],
) -> None:
    """Apply Final Revenge perk behavior when a player dies."""
    from ...creatures.damage import creature_apply_damage_with_lethal_followup

    if not perk_active(player, PerkId.FINAL_REVENGE):
        return

    player_pos = player.pos
    rand = state.rng.rand
    state.effects.spawn_explosion_burst(
        pos=player_pos,
        scale=1.8,
        rand=rand,
        detail_preset=int(detail_preset),
    )

    prev_guard = bool(state.bonus_spawn_guard)
    state.bonus_spawn_guard = True
    for creature_idx, creature in enumerate(creatures.entries):
        if not creature.active:
            continue

        delta = creature.pos - player_pos
        if abs(delta.x) > 512.0 or abs(delta.y) > 512.0:
            continue

        remaining = 512.0 - delta.length()
        if remaining <= 0.0:
            continue

        damage = remaining * 5.0
        death_creature_idx = int(creature_idx)
        suppress_death_sfx = bool(creature.flags & CreatureFlags.RANGED_ATTACK_SHOCK)
        creature_apply_damage_with_lethal_followup(
            creature,
            damage_amount=damage,
            damage_type=CreatureDamageType.EXPLOSION,
            impulse=Vec2(),
            owner_id=-1 - int(player.index),
            dt=float(dt),
            players=players,
            rand=rand,
            effects=state.effects,
            detail_preset=int(detail_preset),
            on_lethal=lambda death_creature_idx=death_creature_idx, suppress_death_sfx=suppress_death_sfx: deaths.append(
                creatures.handle_death(
                    int(death_creature_idx),
                    state=state,
                    players=players,
                    rand=rand,
                    dt=float(dt),
                    detail_preset=int(detail_preset),
                    world_width=float(world_size),
                    world_height=float(world_size),
                    fx_queue=fx_queue,
                    plan_death_sfx=not bool(suppress_death_sfx),
                ),
            ),
        )

    state.bonus_spawn_guard = prev_guard
    state.sfx_queue.append("sfx_explosion_large")
    state.sfx_queue.append("sfx_shockwave")


HOOKS = PerkHooks(
    perk_id=PerkId.FINAL_REVENGE,
    player_death_hook=apply_final_revenge_on_player_death,
)
