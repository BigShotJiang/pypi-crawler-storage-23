from __future__ import annotations

from ..math_parity import f32
from .apply_context import BonusApplyCtx


def apply_speed(ctx: BonusApplyCtx) -> None:
    should_register = float(ctx.player.speed_bonus_timer) <= 0.0
    if ctx.players is not None and len(ctx.players) > 1:
        should_register = (
            float(ctx.players[0].speed_bonus_timer) <= 0.0 and float(ctx.players[1].speed_bonus_timer) <= 0.0
        )
    if should_register:
        ctx.register_player("speed_bonus_timer")
    ctx.player.speed_bonus_timer = float(
        f32(float(ctx.player.speed_bonus_timer) + float(ctx.amount) * float(ctx.economist_multiplier)),
    )
