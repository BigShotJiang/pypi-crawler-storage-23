from .view import HighScoresView

__all__ = ["HighScoresView"]
