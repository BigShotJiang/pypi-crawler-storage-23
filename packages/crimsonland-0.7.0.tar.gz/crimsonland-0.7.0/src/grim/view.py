from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


@dataclass(frozen=True, slots=True)
class ViewContext:
    assets_dir: Path = Path("artifacts") / "assets"
    preserve_bugs: bool = False


class View(Protocol):
    def open(self) -> None: ...

    def update(self, dt: float) -> None: ...

    def draw(self) -> None: ...

    def close(self) -> None: ...
