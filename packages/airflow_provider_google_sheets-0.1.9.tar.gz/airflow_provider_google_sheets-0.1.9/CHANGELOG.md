# Changelog

## v0.1.9

- **Breaking:** `transliterate_headers` default changed from `False` to `True` — Cyrillic headers are now transliterated to Latin by default
- Added `sanitize_headers` parameter (default `True`) — removes spaces and special characters from header names, keeping only letters, digits, and underscores
- Added `lowercase_headers` parameter (default `True`) — converts header names to lowercase
- When `normalize_headers=True`, `sanitize_headers` and `lowercase_headers` are ignored (normalize already includes both)
- `column_mapping` now takes priority over all header processing — when provided, transliteration, sanitization, and lowercasing are skipped; the mapping is applied directly to raw header names from the spreadsheet

## v0.1.8

- Added `column_mapping` parameter to `GoogleSheetsReadOperator` — rename headers on read via a dict (e.g. Cyrillic → Latin), applied after transliteration/normalization

## v0.1.7

- Changed JSON output format from JSON array to JSONL (newline-delimited JSON) — each line is a separate JSON object, compatible with BigQuery and other tools that expect NDJSON

## v0.1.6

- Fixed `HttpError 400: Range exceeds grid limits` when writing more rows than the sheet contains
- Added automatic sheet grid expansion — the operator now checks `rowCount` before writing and adds rows via `appendDimension` if needed
- Added `ensure_rows()` and `get_sheet_properties()` methods to `GoogleSheetsHook`

## v0.1.5

- Added support for `key_path` / `keyfile_path` authentication — the hook can now read service account credentials from a JSON file on disk
- Added support for custom scopes from the `scope` field in connection extra
- Full compatibility with standard `Google Cloud` connection type (Keyfile Path, Keyfile JSON, Scopes)
- Refactored example DAGs to use `@dag` and `@task` decorators (TaskFlow API)
- Updated README with detailed connection setup options

## v0.1.4

- Added `Documentation` and `Issues` URLs to package metadata for PyPI sidebar
- Added `project-url` to `get_provider_info()` for Airflow providers page link
- Fixed typo in Documentation URL in `pyproject.toml`

## v0.1.3

- Renamed package from `airflow_google_sheets` to `airflow_provider_google_sheets`
- Fixed `post_insert_updates` index recalculation after structural operations in smart merge
- Added `_adjust_post_insert_indices()` method that correctly skips parent operations
- Fixed internal fields (`row_num`, `_source_op`) leaking into `batch_update_values` API payload
- Added payload cleanliness tests
- Expanded `get_provider_info()` with integrations, operators, hooks metadata
- Switched to `setuptools-scm` for automatic versioning from git tags
- Relaxed dependencies: Python >= 3.10, Apache Airflow >= 2.7 < 3.0
- Changed license from Apache-2.0 to MIT
- Added `readme.md` (EN), `readme_ru.md` (RU), `CHANGELOG.md`, `LICENSE`
- Added example DAGs including BigQuery integration
- Added GitHub Actions workflow for testing and publishing to PyPI

## v0.1.2

- Fixed `_build_range()` generating invalid A1-notation when `cell_range=None`
- Fixed `dicts_to_rows()` to collect union of keys from all dicts (not just first)
- Fixed `has_headers=False` handling in smart merge (row 1 was incorrectly skipped)
- Replaced `set()` with `dict.fromkeys()` for deterministic key ordering in smart merge
- Added `batch_update_values()` to hook — bulk value writes via `values.batchUpdate` API
- Smart merge now uses `batch_update_values` instead of individual `update_values` calls

## v0.1.1

- Fixed overwrite mode writing to wrong column when `cell_range` specifies non-A start column
- Added `_parse_range_start()` for extracting start column/row from A1 ranges
- Added `_adjust_row_indices()` for recalculating value-update positions after structural operations
- Added `_group_contiguous()` for correct deletion of non-adjacent rows
- Rewrote read operator with streaming output — CSV/JSON written chunk-by-chunk without memory accumulation
- Added `_read_chunks()` generator, `_stream_to_csv()`, `_stream_to_json()`, `_read_to_xcom()`
- Added `max_xcom_rows` parameter (default 50,000) with error on exceeded limit

## v0.1.0

- Initial release
- `GoogleSheetsHook` — authentication via service account, all CRUD operations with retry
- `GoogleSheetsReadOperator` — chunked reading, schema validation, CSV/JSON/XCom output
- `GoogleSheetsWriteOperator` — overwrite, append, smart merge modes
- `GoogleSheetsCreateSpreadsheetOperator` / `GoogleSheetsCreateSheetOperator`
- Schema-based type conversion (str, int, float, date, datetime, bool)
- Header processing (deduplication, transliteration, normalization)
- Retry with exponential backoff and jitter
- Custom exceptions hierarchy
