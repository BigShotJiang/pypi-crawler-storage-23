from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Union, get_args
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, RootModel
from typing_extensions import Annotated

from asknews_sdk.dto.base import BaseSchema
from asknews_sdk.dto.common import FilterParams
from asknews_sdk.types import CronStr, HttpUrlString


CheckAlertModel = Literal[
    "meta-llama/Meta-Llama-3.1-8B-Instruct",
    "gpt-4o-mini",
    # "gpt-5-mini",
    # "gpt-5-nano",
    "gpt-4o",
    "o3-mini",
    "meta-llama/Meta-Llama-3.3-70B-Instruct",
    "gpt-4.1-2025-04-14",
    "gpt-4.1-nano-2025-04-14",
    "gpt-4.1-mini-2025-04-14",
]

AlertReportModel = Literal[
    # "gpt-5",
    "gpt-4o",
    "gpt-4.1-2025-04-14",
    "gpt-4.1-mini-2025-04-14" "gpt-4o-mini",
    "o3-mini",
    "claude-3-5-sonnet-latest",
    "claude-sonnet-4-20250514",
    "claude-sonnet-4-5-20250929",
    "claude-opus-4-5-20251101",
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "meta-llama/Meta-Llama-3.1-405B-Instruct",
    "meta-llama/Meta-Llama-3.3-70B-Instruct",
]


class WebSourceParams(BaseModel):
    queries: List[str] = Field(
        ...,
        description="The queries to use for the web search. This is a list of strings.",
    )
    domains: Optional[List[str]] = Field(
        None, description="The domains to restrict the web search to."
    )
    strict: bool = Field(
        True,
        description=(
            "If true, the web search will only return results that have "
            "a known publication date and are within the lookback period."
        ),
    )
    lookback: int = Field(
        24,
        description=(
            "The number of hours back to accept for the web search. "
            "If not provided, no lookback will be applied."
        ),
    )


class WebSource(BaseModel):
    identifier: Literal["web"]
    params: WebSourceParams


class AskNewsSource(BaseModel):
    identifier: Literal["asknews"]
    params: Optional[FilterParams] = Field(None, description="The filter params to use")


class TelegramSourceParams(BaseModel):
    channel_name: str = Field(..., description="The channel name to use as a source")


class TelegramSource(BaseModel):
    identifier: Literal["telegram"]
    params: TelegramSourceParams


class BlueskySourceParams(BaseModel):
    query: Optional[str] = Field(None, description="The search query")


class BlueskySource(BaseModel):
    identifier: Literal["bluesky"]
    params: Optional[BlueskySourceParams] = Field(None, description="Bluesky source parameters")


DeepNewsSourceType = Literal["asknews", "google", "graph", "wiki", "x", "reddit", "charts"]
DeepNewsSourceTypeDefault: list[DeepNewsSourceType] = ["asknews", "google", "wiki", "x"]

DeepNewsInlineCitationType = Literal["markdown_link", "numbered", "none"]
DeepNewsInlineCitationTypeDefault: DeepNewsInlineCitationType = "markdown_link"


class DeepNewsParams(BaseModel):
    model: Optional[str] = Field(
        default=None,
        description=("The model to use for DeepNews. Check API reference for default model."),
    )
    sources: Optional[Union[DeepNewsSourceType, List[DeepNewsSourceType]]] = Field(
        default=DeepNewsSourceTypeDefault,
        description=(
            "Which data sources DeepNews should use. Can be a single source or a list. "
            f"Available sources are: {', '.join(get_args(DeepNewsSourceType))}"
        ),
    )
    filter_params: Optional[Dict[str, Any]] = Field(
        default=None, description="Any filter param available on the /news endpoint."
    )
    include_entities: Optional[bool] = Field(
        default=True,
        description=(
            "Include entities of the sources in the internal context. "
            "Activating this will increase internal token usage."
        ),
    )
    include_graphs: Optional[bool] = Field(
        default=False,
        description=(
            "Include graphs of the sources in the internal context. "
            "Activating this will increase internal token usage."
        ),
    )
    include_coordinates: Optional[bool] = Field(
        default=False,
        description=(
            "Include geocoordinates of the sources in the internal context. "
            "Activating this will increase internal token usage."
        ),
    )


class DeepNewsSourceParams(BaseModel):
    search_depth: Optional[int] = Field(
        default=2,
        description=(
            "The search depth for deep research. Higher values mean more " "thorough research."
        ),
    )
    max_depth: Optional[int] = Field(default=4, description="The maximum research depth allowed.")


class DeepNewsReportParams(DeepNewsParams):
    """Parameters for DeepNews alert report.

    DeepNews performs deep research using multiple tools.
    """
    search_depth: Optional[int] = Field(
        default=2,
        description=(
            "The search depth for deep research. Higher values mean more " "thorough research."
        ),
    )
    max_depth: Optional[int] = Field(default=4, description="The maximum research depth allowed.")
    start_citation_number: Optional[int] = Field(
        default=1,
        description=(
            "Starting number for inline citations. Offsets fetched source citation keys. "
            "Useful if you are providing the agent outside sources with numbered citation keys."
        ),
    )
    journalist_mode: Optional[bool] = Field(
        default=True,
        description=(
            "Activate journalist mode, with improved alignment for making claims "
            "with supporting evidence. Improved journalistic style."
        ),
    )
    asknews_watermark: Optional[bool] = Field(
        default=True, description='Append "Generated by AskNews AI" watermark.'
    )


class DeepNewsSource(BaseModel):
    identifier: Literal["deepnews"]
    params: Optional[DeepNewsSourceParams] = Field(None, description="DeepNews source parameters")


Source = Annotated[
    Union[AskNewsSource, TelegramSource, BlueskySource, WebSource, DeepNewsSource],
    Field(discriminator="identifier"),
]


class Sources(RootModel):
    root: List[Source]


class WebhookParams(BaseModel):
    url: HttpUrlString = Field(
        ..., description="The URL to send the webhook when the alert triggers"
    )
    headers: Optional[Dict[str, str]] = Field(
        None, description="The headers to send with the webhook."
    )
    payload: Optional[Dict[str, Any]] = Field(
        None, description="The payload to send with the webhook."
    )


class EmailParams(BaseModel):
    to: EmailStr = Field(..., description="The email to send the alert to when it triggers")
    subject: Optional[str] = Field(
        None,
        description="The subject of the email. If not provided, the default subject will be used.",
    )
    asknews_watermark: Optional[bool] = Field(
        default=True, description='Append "Generated by AskNews AI" watermark.'
    )


class GoogleDocsParams(BaseModel):
    client_json: Dict[str, Any] = Field(
        ...,
        description=(
            "The google service account json. This should be a dict. You can get this "
            "from the google cloud console. The document will be created in the service "
            "account's google drive and shared with the user."
        ),
    )
    emails: Optional[List[EmailStr]] = Field(
        None, description="The emails to share the doc with")
    asknews_watermark: Optional[bool] = Field(
        default=True, description='Append "Generated by AskNews AI" watermark.'
    )


class WebhookAction(BaseModel):
    action: Literal["webhook"] = Field("webhook")
    params: WebhookParams


class EmailAction(BaseModel):
    action: Literal["email"] = Field("email")
    params: EmailParams


class GoogleDocsAction(BaseModel):
    action: Literal["google_docs"] = Field("google_docs")
    params: GoogleDocsParams


Trigger = Annotated[
    Union[WebhookAction, EmailAction, GoogleDocsAction],
    Field(discriminator="action"),
]


class Triggers(RootModel):
    root: List[Trigger]


class ReportRequestParams(BaseModel):
    prompt: Optional[List[List[str]]] = Field(
        None,
        description=(
            "The optional prompt to use for report generation. The prompt should be a list of "
            "tuples where the first element is the author of the prompt and the second element "
            "is the prompt itself. For example, [['system', 'You are a helpful AI bot. Write a "
            "report based on summaries provided by the user.'], ['human', '{summaries}']]. "
            "If not provided, the default report prompt will be used. You can use {summaries} "
            "to insert the prompt optimized summaries into your report query."
        ),
        examples=[
            [
                "system",
                "You are a helpful AI bot. Write a report based on summaries provided by the user.",
            ],
            ["human", "{summaries}"],
        ],
    )
    logo_url: Optional[HttpUrlString] = Field(
        None, description="The logo URL to use for the report"
    )
    include_appendix: Optional[bool] = Field(
        False,
        description="Whether to append thinking and search traces as an appendix to the report.",
    )
    asknews_watermark: Optional[bool] = Field(
        default=True, description='Append "Generated by AskNews AI" watermark.'
    )


class LegacyReportRequest(ReportRequestParams):
    """Legacy report configuration (original format).

    This is the original ReportRequest format that uses a simple model field
    for report generation without DeepNews capabilities.
    """
    identifier: Literal["legacy"] = "legacy"
    model: Optional[AlertReportModel] = Field(
        None,
        description=(
            "The model to use for the report. Check the API reference for "
            "default model. If you have DeepNews as a source, the DeepNews "
            "model will be used for the report."
        ),
        examples=["gpt-4o"],
    )

class DeepNewsReportRequest(ReportRequestParams):
    """DeepNews report configuration.

    Uses DeepNews deep research capabilities for report generation.
    """
    identifier: Literal["deepnews"]
    params: DeepNewsReportParams


# Type alias for discriminated union (used in type hints)
ReportRequestType = Annotated[
    LegacyReportRequest | DeepNewsReportRequest,
    Field(discriminator="identifier")
]


def ReportRequest(**kwargs: Any) -> LegacyReportRequest | DeepNewsReportRequest:
    identifier = kwargs.get("identifier", "legacy")

    if identifier == "deepnews":
        return DeepNewsReportRequest(**kwargs)
    else:
        # Default to legacy, ensure identifier is set
        if "identifier" not in kwargs:
            kwargs["identifier"] = "legacy"
        return LegacyReportRequest(**kwargs)


AlertType = Literal["AlwaysAlertWhen", "AlertOnceIf", "ReportAbout"]


class CreateAlertRequest(BaseSchema):
    query: Optional[str] = Field(
        None,
        description=("The query to run for the alert."),
        examples=[
            "I want to be alerted if the president of the US says something about the economy",
        ],
    )
    sources: Sources = Field(
        ...,
        description=(
            "The sources to use for the alert query. Available sources are: "
            f"{', '.join([arg.__name__ for arg in get_args(get_args(Source)[0])])}"
        ),
    )
    alert_type: Optional[AlertType] = Field(
        None,
        description=(
            "The type of alert. If specified, overrides `repeat` and `always_trigger`. "
            "'AlwaysAlertWhen': trigger alert actions any time the alert query is "
            "satisfied (`repeat=True`, `always_trigger=False`). "
            "Add Report model if you want a report when this is triggered. "
            "'AlertOnceIf': trigger alert actions when the alert query is satisfied "
            "and then disable the alert (`repeat=False`, `always_trigger=False`). "
            "Add Report model if you want a report when this is triggered. "
            "'ReportAbout': always trigger alert actions according to cron schedule "
            "and write a report (`repeat=True`, `always_trigger=True`). "
            "Defaults to using DeepNews for the report unless specified."
        ),
    )
    model: Optional[CheckAlertModel] = Field(
        None,
        description=(
            "The model that is used to check if the alert conditions are satisfied by "
            "sources (this is not the same as the model used to write the report.)"
            "Check the API reference for default model."
        ),
        examples=[
            "meta-llama/Meta-Llama-3.1-8B-Instruct",
        ],
    )
    cron: CronStr = Field(
        ...,
        description=(
            "How often or when to check sources for this alert, specified as a cron expression. "
            "Examples: '*/15 * * * *' (every 15 minutes), '0 * * * *' (hourly), "
            "'0 9 * * *' (daily at 9am), '0 9 * * 1' (Mondays at 9am). "
            " See https://crontab.run/ for more examples."
        ),
        examples=[
            "'0 0 * * *' (daily at midnight UTC)",
        ],
    )
    triggers: Triggers = Field(
        ...,
        description=(
            "Configuration for actions to trigger for the alert. Available actions are: "
            f"{', '.join([arg.__name__ for arg in get_args(get_args(Trigger)[0])])}"
        ),
    )
    always_trigger: Optional[bool] = Field(
        False,
        description=(
            "Whether to always trigger the actions when sources are scanned. This skips the "
            "check for if the alert conditions are satisfied and run triggers immediately. "
            "Defaults to False."
        ),
    )
    repeat: Optional[bool] = Field(
        True,
        description=(
            "Whether to repeat the alert. Default is True. If False, the alert will be "
            "disabled after it triggers once"
        ),
    )
    active: Optional[bool] = Field(
        True, description="Whether the alert is active or not. Default is True."
    )
    expires_at: Optional[datetime] = Field(
        None,
        description=(
            "The expiration date for the alert. Default is None. "
            "If set, the alert will be disabled after this date."
        ),
    )
    report: Optional[ReportRequestType] = Field(
        None,
        description=(
            "Configuration for generating a written report when the alert triggers. "
            "If not specified, no report is generated. Use ReportRequest(...) or "
            "ReportRequest(identifier='legacy', ...) for "
            "legacy reports or ReportRequest(identifier='deepnews', ...) for "
            "DeepNews reports."
        ),
    )
    title: Optional[str] = Field(
        None,
        description="The title of the alert. If not provided, no title will be used.",
        examples=["Alert for US President's statements on the economy"],
    )
    share_link: Optional[HttpUrlString] = Field(
        None, description="The Newsplunker share link to update when the alert triggers"
    )


class UpdateAlertRequest(BaseSchema):
    query: Optional[str] = Field(
        None,
        description=("The query to run for the alert."),
        examples=[
            "I want to be alerted if the president of the US says something about the economy",
        ],
    )
    sources: Optional[Sources] = Field(
        None,
        description=(
            "The sources to use for the alert query. Available sources are: "
            f"{', '.join([arg.__name__ for arg in get_args(get_args(Source)[0])])}"
        ),
    )
    alert_type: Optional[AlertType] = Field(
        None,
        description=(
            "The type of alert. If specified, overrides `repeat` and `always_trigger`. "
            "'AlwaysAlertWhen': trigger alert actions any time the alert query is "
            "satisfied (`repeat=True`, `always_trigger=False`). "
            "Add Report model if you want a report when this is triggered. "
            "'AlertOnceIf': trigger alert actions when the alert query is satisfied "
            "and then disable the alert (`repeat=False`, `always_trigger=False`). "
            "Add Report model if you want a report when this is triggered. "
            "'ReportAbout': always trigger alert actions according to cron schedule "
            "and write a report (`repeat=True`, `always_trigger=True`). "
            "Defaults to using DeepNews for the report unless specified."
        ),
    )
    model: Optional[CheckAlertModel] = Field(
        None,
        description=(
            "The model that is used to check if the alert conditions are satisfied by "
            "sources (this is not the same as the model used to write the report.)"
        ),
        examples=["gpt-4o-mini"],
    )
    cron: Optional[CronStr] = Field(
        None,
        description=(
            "How often or when to check sources for this alert, specified as a cron expression. "
            "Examples: '*/15 * * * *' (every 15 minutes), '0 * * * *' (hourly), "
            "'0 9 * * *' (daily at 9am), '0 9 * * 1' (Mondays at 9am). "
            " See https://crontab.run/ for more examples."
        ),
        examples=["'0 0 * * *' (daily at midnight UTC)"],
    )
    triggers: Optional[Triggers] = Field(
        None,
        description=(
            "Configuration for actions to trigger for the alert. Available actions are: "
            f"{', '.join([arg.__name__ for arg in get_args(get_args(Trigger)[0])])}"
        ),
    )
    always_trigger: Optional[bool] = Field(
        None,
        description=(
            "Whether to always trigger the actions when sources are scanned. This skips the "
            "check for if the alert conditions are satisfied and run triggers immediately. "
            "Defaults to False."
        ),
    )
    repeat: Optional[bool] = Field(
        None,
        description=(
            "Whether to repeat the alert. Default is True. If False, the alert will be "
            "disabled after it triggers once."
        ),
    )
    active: Optional[bool] = Field(
        None, description="Whether the alert is active or not. Default is True."
    )
    expires_at: Optional[datetime] = Field(
        None,
        description=(
            "The expiration date for the alert. Default is None. "
            "If set, the alert will be disabled after this date."
        ),
    )
    report: Optional[ReportRequestType] = Field(
        None,
        description=(
            "Configuration for generating a written report when the alert triggers. "
            "If not specified, no report is generated.. Use ReportRequest(...) or "
            "ReportRequest(identifier='legacy', ...) for "
            "legacy reports or ReportRequest(identifier='deepnews', ...) for "
            "DeepNews reports."
        ),
    )
    title: Optional[str] = Field(
        None,
        description="The title of the alert. If not provided, no title will be used.",
        examples=["Alert for US President's statements on the economy"],
    )
    share_link: Optional[HttpUrlString] = Field(
        None, description="The Newsplunker share link to update when the alert triggers."
    )


class AlertLog(BaseModel):
    id: UUID
    created_at: datetime
    alert_id: UUID
    user_id: UUID
    alert: bool
    reasoning: str
    report: Optional[str] = None
    report_url: Optional[str] = None
    article_ids: List[UUID]
    webhook: Optional[Dict[str, Any]] = None


class AlertResponse(BaseSchema):
    id: UUID
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    user_id: UUID
    query: Optional[str] = None
    cron: str
    model: Optional[str] = None
    share_link: Optional[str] = None
    sources: List[Dict[str, Any]]
    report: Optional[Dict[str, Any]] = None
    triggers: List[Dict[str, Any]]
    always_trigger: bool = False
    repeat: bool = True
    active: bool = True
    alert_type: Optional[AlertType] = None
    title: Optional[str] = None
