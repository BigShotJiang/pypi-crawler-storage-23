# com_link_gen_10
生成复合链环表示。复合链环的表示方式详见：https://pypi.org/project/link-rep/

## Install

```bash
pip install com-link-gen-10
```

## Usage

```python
import com_link_gen_10

for line in com_link_gen_10.com_link_gen(10, 3):
    print(line)
```
