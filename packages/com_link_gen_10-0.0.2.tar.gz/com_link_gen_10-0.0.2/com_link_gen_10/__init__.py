from .main import com_link_gen

__all__ = [
    "com_link_gen"
]
