"""Dataset browser frontend — server-rendered with Jinja2 + HTMX."""

from atdata_app.frontend.routes import router

__all__ = ["router"]
