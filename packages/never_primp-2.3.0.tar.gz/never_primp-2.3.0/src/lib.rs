// never_primp: High-performance Python HTTP client with browser impersonation
use pyo3::prelude::*;

mod browser_mapping;
mod client;
mod error;
mod response;
mod runtime;
mod types;
mod utils;

use client::RClient;
use response::Response;

/// never_primp Python module
///
/// Convenience functions (get, post, put, delete, patch, head, options) are
/// implemented in the Python wrapper layer (`never_primp/__init__.py`) to support
/// the full parameter set. Only the core classes are exposed here.
#[pymodule]
fn never_primp(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<RClient>()?;
    m.add_class::<Response>()?;
    Ok(())
}
