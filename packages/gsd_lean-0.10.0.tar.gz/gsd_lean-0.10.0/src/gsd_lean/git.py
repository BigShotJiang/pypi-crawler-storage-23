"""Git utilities for branch detection."""

import subprocess
from pathlib import Path

_DEFAULT_FALLBACK = 'main'


def get_current_branch(root: Path) -> str | None:
    """Return the current git branch name, or None if not in a git repo / detached HEAD.

    Args:
        root: Directory to run git from.

    Returns:
        Branch name, or None if unavailable.
    """
    result = subprocess.run(
        ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return None
    branch = result.stdout.strip()
    # Detached HEAD returns literal "HEAD"
    if branch == 'HEAD':
        return None
    return branch


def get_default_branch(root: Path) -> str:
    """Return the repo's default branch name.

    Tries ``git symbolic-ref refs/remotes/origin/HEAD`` first;
    falls back to ``'main'`` if no remote is configured.

    Args:
        root: Directory to run git from.

    Returns:
        Default branch name (e.g. ``'main'``).
    """
    result = subprocess.run(
        ['git', 'symbolic-ref', 'refs/remotes/origin/HEAD'],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        # Output looks like "refs/remotes/origin/main"
        ref = result.stdout.strip()
        return ref.rsplit('/', maxsplit=1)[-1]
    return _DEFAULT_FALLBACK
