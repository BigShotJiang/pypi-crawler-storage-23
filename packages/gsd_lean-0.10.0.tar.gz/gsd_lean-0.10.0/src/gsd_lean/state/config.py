"""Subagent configuration loading, validation, and resolution."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import yaml

from gsd_lean.state.planning import PLANNING_DIR

VALID_MODELS = frozenset({'opus', 'sonnet', 'haiku'})

KNOWN_SUBAGENTS: dict[str, tuple[str, ...]] = {
    'init': ('explore',),
    'discuss': ('explore', 'verify'),
    'plan': ('plan-review',),
    'execute': ('executor', 'auto-debug', 'verify'),
}

DEFAULT_MAX_TURNS: dict[str, dict[str, int]] = {
    'init': {'explore': 15},
    'discuss': {'explore': 20, 'verify': 10},
    'plan': {'plan-review': 25},
    'execute': {'executor': 40, 'auto-debug': 20, 'verify': 15},
}

CONFIG_FILENAME = 'config.yaml'


@dataclass(frozen=True)
class SubagentConfig:
    """Resolved configuration for a single subagent invocation."""

    model: str | None = None
    max_turns: int | None = None


def load_config(root: Path) -> dict[str, Any]:
    """Load .planning/config.yaml. Returns empty dict if file missing or invalid."""
    config_path = root / PLANNING_DIR / CONFIG_FILENAME
    try:
        content = config_path.read_text()
    except FileNotFoundError:
        return {}

    try:
        data: object = yaml.safe_load(content)
    except yaml.YAMLError:
        return {}

    if not isinstance(data, dict):
        return {}

    return cast(dict[str, Any], data)


def validate_config(data: dict[str, Any]) -> list[str]:
    """Validate config structure and values. Returns list of error/warning strings."""
    errors: list[str] = []

    # Validate defaults section
    defaults: object = data.get('defaults')
    if defaults is not None:
        if not isinstance(defaults, dict):
            errors.append('defaults must be a mapping')
        else:
            defaults_typed = cast(dict[str, Any], defaults)
            _validate_model(defaults_typed, 'defaults.model', errors)
            _validate_max_turns(defaults_typed, 'defaults.max_turns', errors)

    # Validate skills section
    skills: object = data.get('skills')
    if skills is not None:
        if not isinstance(skills, dict):
            errors.append('skills must be a mapping')
        else:
            skills_typed = cast(dict[str, Any], skills)
            for skill_name in skills_typed:
                skill_name_str = str(skill_name)
                skill_data: object = skills_typed[skill_name]
                if skill_name_str not in KNOWN_SUBAGENTS:
                    errors.append(f'warning: unknown skill {skill_name_str!r}')
                    continue
                if not isinstance(skill_data, dict):
                    errors.append(f'skills.{skill_name_str} must be a mapping')
                    continue
                skill_data_typed = cast(dict[str, Any], skill_data)
                subagents: object = skill_data_typed.get('subagents')
                if subagents is not None:
                    if not isinstance(subagents, dict):
                        errors.append(f'skills.{skill_name_str}.subagents must be a mapping')
                        continue
                    subagents_typed = cast(dict[str, Any], subagents)
                    for sa_name in subagents_typed:
                        sa_name_str = str(sa_name)
                        sa_data: object = subagents_typed[sa_name]
                        if sa_name_str not in KNOWN_SUBAGENTS[skill_name_str]:
                            errors.append(f'warning: unknown subagent {sa_name_str!r} for skill {skill_name_str!r}')
                            continue
                        if not isinstance(sa_data, dict):
                            errors.append(f'skills.{skill_name_str}.subagents.{sa_name_str} must be a mapping')
                            continue
                        sa_data_typed = cast(dict[str, Any], sa_data)
                        prefix = f'skills.{skill_name_str}.subagents.{sa_name_str}'
                        _validate_model(sa_data_typed, f'{prefix}.model', errors)
                        _validate_max_turns(sa_data_typed, f'{prefix}.max_turns', errors)

    return errors


def _validate_model(data: dict[str, Any], path: str, errors: list[str]) -> None:
    """Validate a model value if present."""
    model: object = data.get('model')
    if model is not None and model not in VALID_MODELS:
        errors.append(f'{path}: invalid model {model!r} (must be one of {sorted(VALID_MODELS)})')


def _validate_max_turns(data: dict[str, Any], path: str, errors: list[str]) -> None:
    """Validate a max_turns value if present."""
    max_turns: object = data.get('max_turns')
    if max_turns is not None:
        if not isinstance(max_turns, int) or isinstance(max_turns, bool):
            errors.append(f'{path}: max_turns must be a positive integer, got {type(max_turns).__name__}')
        elif max_turns <= 0:
            errors.append(f'{path}: max_turns must be positive, got {max_turns}')


def resolve_subagent_config(
    data: dict[str, Any],
    skill_name: str,
    subagent_name: str,
) -> SubagentConfig:
    """Resolve effective config for a subagent.

    Resolution order:
    1. skills.<skill>.subagents.<subagent>.<key>
    2. defaults.<key>
    3. DEFAULT_MAX_TURNS[skill][subagent] (hardcoded fallback for max_turns only)
    4. None (omit parameter, inherit from parent session)
    """
    # Resolve model: skill-specific -> defaults -> None
    raw_model: object = _get_nested(data, 'skills', skill_name, 'subagents', subagent_name, 'model')
    if raw_model is None:
        raw_model = _get_nested(data, 'defaults', 'model')
    model: str | None = None
    if isinstance(raw_model, str) and raw_model in VALID_MODELS:
        model = raw_model

    # Resolve max_turns: skill-specific -> defaults -> hardcoded -> None
    raw_max_turns: object = _get_nested(data, 'skills', skill_name, 'subagents', subagent_name, 'max_turns')
    if raw_max_turns is None:
        raw_max_turns = _get_nested(data, 'defaults', 'max_turns')

    max_turns: int | None = None
    if isinstance(raw_max_turns, int) and not isinstance(raw_max_turns, bool) and raw_max_turns > 0:
        max_turns = raw_max_turns
    elif raw_max_turns is None:
        skill_defaults = DEFAULT_MAX_TURNS.get(skill_name, {})
        max_turns = skill_defaults.get(subagent_name)

    return SubagentConfig(model=model, max_turns=max_turns)


def _get_nested(data: dict[str, Any], *keys: str) -> object:
    """Safely traverse nested dicts. Returns None if any key is missing or not a dict."""
    current: dict[str, Any] = data
    for i, key in enumerate(keys):
        value: object = current.get(key)
        if i == len(keys) - 1:
            return value
        if not isinstance(value, dict):
            return None
        current = cast(dict[str, Any], value)
    return current
