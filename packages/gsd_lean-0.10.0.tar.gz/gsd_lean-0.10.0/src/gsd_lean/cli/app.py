"""CLI application entry point."""

import json
from collections import Counter
from pathlib import Path

import click
import yaml

from gsd_lean.installer import install_statusline
from gsd_lean.state import (
    KNOWN_SUBAGENTS,
    PHASES,
    get_plan_status,
    init_planning,
    load_config,
    migrate_v1_to_v2,
    parse_plan_tasks,
    read_plan,
    read_state,
    reset_cycle,
    resolve_subagent_config,
    validate_config,
)
from gsd_lean.version import __version__
from gsd_lean.workflow import PreconditionError
from gsd_lean.workflow import transition as workflow_transition


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name='gsd-lean')
@click.pass_context
def cli(ctx: click.Context) -> None:
    """GSD-Lean: spec-driven development workflow."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
def version() -> None:
    """Print gsd-lean version."""
    click.echo(__version__)


@cli.command()
@click.option('--force', is_flag=True, help='Overwrite existing files.')
@click.option('--force-statusline', is_flag=True, help='Overwrite existing statusline configuration.')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def init(force: bool, force_statusline: bool, path: Path) -> None:
    """Scaffold .planning/ directory with template files."""
    root = path.resolve()
    try:
        created = init_planning(root, force=force)
    except FileExistsError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    for filepath in created:
        click.echo(f'  created {filepath.relative_to(root)}')
    click.echo(f'\nInitialized .planning/ with {len(created)} file(s).')

    # Install statusline hook
    sl_actions = install_statusline(root, force=force_statusline)
    for action in sl_actions:
        click.echo(f'  {action}')


@cli.command()
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def status(path: Path) -> None:
    """Display current workflow state."""
    root = path.resolve()
    try:
        content = read_state(root)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    click.echo(content, nl=False)


@cli.command()
@click.argument('phase', type=click.Choice(PHASES))
@click.option('--force', is_flag=True, help='Bypass precondition checks.')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
@click.option('--note', default='', help='Note for history table.')
def transition(phase: str, force: bool, path: Path, note: str) -> None:
    """Transition workflow to a new phase."""
    root = path.resolve()
    try:
        new_phase = workflow_transition(root, phase, force=force, note=note)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None
    except ValueError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None
    except PreconditionError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    click.echo(f'Transitioned to: {new_phase}')


@cli.command('new-cycle')
@click.option('--no-archive', is_flag=True, help='Delete old cycle files instead of archiving.')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def new_cycle(no_archive: bool, path: Path) -> None:
    """Archive current cycle and start fresh."""
    root = path.resolve()
    try:
        created = reset_cycle(root, archive=not no_archive)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    for filepath in created:
        click.echo(f'  created {filepath.relative_to(root)}')
    click.echo(f'\nNew cycle started with {len(created)} file(s).')


@cli.command()
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def migrate(path: Path) -> None:
    """Migrate v1 .planning/ layout to v2 (static/cycle split)."""
    root = path.resolve()
    if migrate_v1_to_v2(root):
        click.echo('Migrated .planning/ to v2 layout.')
    else:
        click.echo('No migration needed (already v2 or no .planning/ found).')


@cli.command('plan-status')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON (for ralph).')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def plan_status(as_json: bool, path: Path) -> None:
    """Display plan progress summary."""
    root = path.resolve()
    try:
        content = read_plan(root)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    tasks = parse_plan_tasks(content)
    try:
        status = get_plan_status(content)
    except ValueError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    counts = Counter(t.status for t in tasks)
    total = len(tasks)
    done = counts.get('done', 0)
    waves = sorted({t.wave for t in tasks})
    current_wave = min((t.wave for t in tasks if t.status != 'done'), default=max(waves, default=0))
    next_task = next((t for t in tasks if t.status == 'pending'), None)

    if as_json:
        click.echo(
            json.dumps(
                {
                    'status': status,
                    'total': total,
                    'done': done,
                    'pending': counts.get('pending', 0),
                    'in_progress': counts.get('in-progress', 0),
                    'blocked': counts.get('blocked', 0),
                    'current_wave': current_wave,
                    'total_waves': len(waves),
                    'next_task': next_task.id if next_task else None,
                }
            )
        )
    else:
        click.echo(f'Plan: {status} | Wave: {current_wave}/{len(waves)} | Tasks: {done}/{total} done', nl=False)
        if next_task:
            click.echo(f' | Next: {next_task.id}')
        else:
            click.echo()


@cli.command()
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
@click.option('--validate', 'validate_only', is_flag=True, help='Validate config and exit.')
@click.option('--skill', default=None, help='Skill name to resolve config for.')
@click.option('--subagent', default=None, help='Subagent name to resolve config for.')
def config(path: Path, validate_only: bool, skill: str | None, subagent: str | None) -> None:
    """Display or validate subagent configuration."""
    root = path.resolve()

    if subagent and not skill:
        click.echo('Error: --subagent requires --skill.', err=True)
        raise SystemExit(1)

    data = load_config(root)

    if validate_only:
        errors = validate_config(data)
        if errors:
            for err in errors:
                click.echo(err)
            raise SystemExit(1)
        click.echo('Config is valid.')
        return

    if skill and subagent:
        if skill not in KNOWN_SUBAGENTS:
            click.echo(f'Error: unknown skill {skill!r}.', err=True)
            raise SystemExit(1)
        if subagent not in KNOWN_SUBAGENTS[skill]:
            click.echo(f'Error: unknown subagent {subagent!r} for skill {skill!r}.', err=True)
            raise SystemExit(1)
        resolved = resolve_subagent_config(data, skill, subagent)
        click.echo(f'model: {resolved.model}')
        click.echo(f'max_turns: {resolved.max_turns}')
        return

    if skill and not subagent:
        if skill not in KNOWN_SUBAGENTS:
            click.echo(f'Error: unknown skill {skill!r}.', err=True)
            raise SystemExit(1)
        for sa_name in KNOWN_SUBAGENTS[skill]:
            resolved = resolve_subagent_config(data, skill, sa_name)
            click.echo(f'{sa_name}:')
            click.echo(f'  model: {resolved.model}')
            click.echo(f'  max_turns: {resolved.max_turns}')
        return

    # Default: dump parsed config
    click.echo(yaml.dump(data, default_flow_style=False).rstrip() if data else 'No config found.')


def main() -> None:
    """Entry point for gsd-lean CLI."""
    cli(standalone_mode=False)
    # standalone_mode=False means Click won't call sys.exit itself;
    # we handle exit via SystemExit in command handlers.
