#!/bin/bash
set -e

cleanup() {
    trap - INT TERM EXIT
    rm -f "$tmpfile" 2>/dev/null || true
    pkill -P $$ 2>/dev/null || true
    docker sandbox stop claude-gsd-lean 2>/dev/null || true
    wait 2>/dev/null || true
}
trap cleanup INT TERM EXIT

if [ -z "$1" ]; then
    echo "Usage: $0 <iterations>"
    exit 1
fi

# verify docker is running
if ! docker info &>/dev/null; then
    echo "Error: Docker is not running. Start Docker and retry."
    exit 1
fi

# jq filter to extract streaming text from assistant messages
stream_text='select(.type == "assistant").message.content[]? | select(.type == "text").text // empty | gsub("\n"; "\r\n") | . + "\r\n\n"'

# jq filter to extract final result
final_result='select(.type == "result").result // empty'

# nuke host .venv (macOS binaries incompatible w/ Linux sandbox)
make clean

for ((i=1; i<=$1; i++)); do
    echo "------------------"
    echo "   Iteration $i   "
    echo "------------------"

    tmpfile=$(mktemp)

    # gh issues
    issues=$(gh issue list --state open --json number,title,body,comments)

    # ralph commits
    ralph_commits=$(git log --grep="ralph:" -n 10 --format="%H%n%ad%n%B---" --date=short 2>/dev/null || echo "No ralph commits found")

    docker sandbox run claude-gsd-lean -- \
        --verbose \
        --print \
        --output-format stream-json \
        "$issues\n\n---\n\nPrevious ralph commits:\n\n$ralph_commits\n\n---\n\n@ralph/issues/issues.md" \
    | grep --line-buffered '^{' \
    | tee "$tmpfile" \
    | jq --unbuffered -rj "$stream_text"

    result=$(jq -r "$final_result" "$tmpfile")

    if [[ "$result" == *"<promise>COMPLETE</promise>"* ]]; then
        echo "Ralph complete after $i iterations."
        make setup-venv
        exit 0
    fi
done

# restore host .venv after sandbox run
make setup-venv
