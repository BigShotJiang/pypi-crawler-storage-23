---
description: This skill should be used when the user runs "/gsd-lean:init" or asks to "initialize project", "scaffold planning directory", or "detect tech stack". Two-phase project initialization — scaffold + LSP check, then detect stack + populate docs.
argument-hint: ["project path, defaults to current directory"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(command -v uvx), Bash(uvx gsd-lean:*), Bash(git:*), Task, AskUserQuestion, LSP, EnterPlanMode, ExitPlanMode
---

## Instructions

The **/init skill** of GSD-Lean scaffolds the `.planning/` directory, checks LSP/statusline setup, auto-detects the project's tech stack, populates `PROJECT.md`, and onboards the user to the 5-phase workflow.

The skill has two phases:
- **Phase A (Scaffold):** Create `.planning/`, check LSP and statusline status. If LSP is not configured, stop here with setup guidance.
- **Phase B (Populate):** Detect the project stack, populate planning docs, and onboard. Runs only when LSP is already enabled or on a second `/init` run.

### Step 0: Prerequisites

Run:
```
command -v uvx
```

**If the command fails (exit code != 0):** Print the following error and **STOP immediately** — do not proceed to any other step:

````markdown
## Error: `uvx` is not installed

GSD-Lean requires [uv](https://github.com/astral-sh/uv) to run. Install it:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

After installing, restart your terminal and run `/gsd-lean:init` again.
````

**If the command succeeds:** Proceed to Step 1.

### Step 1: Initialization Gate

Check whether `.planning/STATE.md` exists and whether LSP is enabled.

**1a. Check `.planning/STATE.md` existence.**

**If STATE.md does NOT exist (first run):**

Run:
```
uvx gsd-lean init --path .
```

Then read `.claude/settings.json` (if it exists) and check whether `env.ENABLE_LSP_TOOL` is set to `"1"`.

- **If LSP is NOT enabled:** Print the Phase A output (see Step 1b below), then **STOP**. Do not proceed to Phase B.
- **If LSP IS enabled:** Check statusline (see Step 1c), then proceed to Step 2 (Phase B).

**If STATE.md DOES exist (subsequent run):**

Print: "Project already initialized. Running in populate mode (non-destructive)."

Read `.claude/settings.json` (if it exists) and check whether `env.ENABLE_LSP_TOOL` is set to `"1"`.

- **If LSP is NOT enabled:** Print warning: "LSP not enabled — detection will rely on Glob/Grep/Read instead of LSP tools."
- Continue to Step 2 (Phase B) regardless.

### Step 1b: Phase A Output (LSP Not Configured)

Print the following setup guidance, then STOP:

````markdown
## Setup Required

GSD-Lean works best with LSP tools enabled. Three steps are needed:

### 1. Install an LSP server

Install the LSP server for your project's language globally:

| Language | Install command |
|----------|----------------|
| TypeScript/JavaScript | `npm i -g typescript-language-server@latest` |
| Python | `pip install pyright` or `npm i -g pyright` |

### 2. Install the Claude Code LSP plugin

Run the `/plugin` command in Claude Code and install the appropriate plugin:

| Language | Plugin name |
|----------|-------------|
| TypeScript/JavaScript | `typescript-lsp@claude-plugins-official` |
| Python | `pyright-lsp@claude-plugins-official` |

### 3. Enable LSP in settings

Add the following to your `.claude/settings.json`:

```json
{
  "enabledPlugins": {
    "<plugin-name>@claude-plugins-official": true
  },
  "env": {
    "ENABLE_LSP_TOOL": "1"
  }
}
```

## What's Next

1. Complete the LSP setup above
2. Optionally edit `.planning/config.yaml` to tune subagent settings (model, max_turns)
3. Run `/gsd-lean:init` again to detect your project stack and populate planning docs
````

Also check statusline (see Step 1c) and append statusline guidance if not configured.

### Step 1c: Statusline Check

Check `.claude/settings.json` for the `statusLine` key.

- If not configured, append:
  > **Recommendation:** Install the GSD-Lean statusline hook for phase/branch visibility. Run: `uvx gsd-lean init --force-statusline`
- If already configured, append:
  > **Note:** Statusline is already configured.

---

## Phase B: Populate

The following steps run only after the initialization gate (Step 1) allows progression.

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All codebase exploration, stack detection, and user confirmation happens in plan mode (read-only). Exit plan mode before writing state files.

### Step 3: Read Project Documentation

Read available project documentation to understand existing conventions before detection:

1. **`CLAUDE.md`** at repo root (if exists) — extract:
   - Dev commands (build, test, lint, format, typecheck)
   - Code style conventions
   - Tech stack details
   - CI/CD pipeline info
   - Any existing tooling configuration

   **Conflict check:** Also scan for development workflow instructions (branching strategy, commit conventions, PR workflows, test-before-push rules, feature development flow). If found, print a warning:

   > **Warning:** `CLAUDE.md` contains development workflow instructions that may conflict with GSD-Lean's phased development cycle. Consider removing or commenting out these instructions before proceeding. See the [Caveats section in the README](./README.md#caveats) for details.

   Continue without blocking.

2. **Other documentation** (if exists):
   - `PROJECT_KNOWLEDGE.md`, `CONTRIBUTING.md`, `README.md`, `TROUBLESHOOTING.md`

If `CLAUDE.md` exists, treat it as the canonical source for tooling and conventions. The auto-detection step (Step 5) complements this — it fills gaps, not duplicates.

**Note:** Reference `CLAUDE.md` in the onboarding summary rather than recreating its content in `.planning/` files. `CLAUDE.md` is assumed to be continuously updated and is the living reference.

### Step 4: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| explore | `skills.init.subagents.explore` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 5: Auto-Detect Project Stack

Use the Task tool to spawn an Explore subagent. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.init.subagents.explore`. Omit any parameter that is null/unset.

Read and use the prompt from [references/explore-prompt.md](references/explore-prompt.md) as the subagent prompt.

### Step 6: Present Findings & Confirm

Present the subagent findings to the user:

```
## Detected Project Stack

- **Language:** <language> <version>
- **Framework:** <framework>
- **Build tool:** <tool>
- **Key dependencies:** <deps>
- **Test runner:** <runner>
- **Linter:** <linter>
- **Formatter:** <formatter (if different from linter)>
- **Type checker:** <checker>
- **CI:** <platform>
- **Runtime manager:** <manager>
- **MCP servers:** <servers>
- **Plugins:** <plugins>
- **CLI tools:** <tools discovered from project docs>
- **Custom skills:** <skills discovered>
```

Then use `AskUserQuestion` to ask: "Does this look correct? Should I update PROJECT.md with these details?"

Options:
- "Yes, update PROJECT.md"
- "Edit first — I'll make corrections"
- "Skip — don't update PROJECT.md"

If the user chooses "Edit first", ask specific follow-up questions about what to change.

### Step 7: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps write to `.planning/` files.

### Step 8: Write State Files

If the user confirmed:

1. **Update PROJECT.md** — Edit `.planning/PROJECT.md` to fill in the Stack section with confirmed values. Only fill in fields that are still template placeholders (empty `**Language:**`, `**Framework:**`, `**Key dependencies:**`). Do not overwrite user-edited content.

2. **Optionally seed CONTEXT.md ## Architecture** — If conventions were detected (e.g. ruff config, mypy strict mode, Makefile targets), check whether the Architecture section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "Linting via ruff (configured in pyproject.toml)"
   - "Strict type checking via mypy"
   - "CI via GitHub Actions"

   Only add if the section is still a placeholder — never overwrite user content.

3. **Optionally seed CONTEXT.md ## Tooling** — If MCP servers or plugins were detected, check whether the Tooling section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "MCP servers: context7, filesystem"
   - "Plugins: pyright-lsp (type checking)"
   - "CLI tools: gh (GitHub), docker"

   If CLI tools were discovered by the subagent, include them here too. Only add if the section is still a placeholder — never overwrite user content.

4. **Optionally seed CONTEXT.md ## Skills** — If custom skills were detected, check whether the Skills section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "backend-dev-guidelines: Guidelines on hono routing in backend API"
   - "ci-debugger: Custom skill for debugging CI failures. Documents specific failure patterns and how to resolve them"
   - "frontend-design: Custom skill on building production-grade frontend interfaces"

   Only add if the section is still a placeholder — never overwrite user content.

5. **Optionally seed CONTEXT.md ## Commands** — If dev commands were detected, check whether the Commands section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries. Format: backtick-wrapped command + dash + brief purpose. Examples:
   - `` `make test` — run pytest suite ``
   - `` `npm run dev` — start dev server on port 3000 ``

   Only add if the section is still a placeholder — never overwrite user content.

6. **Optionally seed CONTEXT.md ## Gotchas** — If non-obvious patterns were detected, check whether the Gotchas section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries. Examples:
   - "Tests must run sequentially due to shared DB state"
   - "`yarn.lock` authoritative; delete `node_modules` if deps mismatch"

   Only add if the section is still a placeholder. Never seed generic advice.

> Refer to [references/seeding-guidelines.md](references/seeding-guidelines.md) for what TO/NOT seed. Key principle: only seed info that would genuinely help a fresh agent session. Don't duplicate CLAUDE.md content — reference it.

If the user chose "Skip", do not modify any state files.

### Step 9: Quality Evaluation

If any seeding was performed in Step 8, evaluate the result. If the user chose "Skip" in Step 6, skip this step entirely.

1. Read `.planning/CONTEXT.md` after seeding
2. Score each dimension per [references/quality-criteria.md](references/quality-criteria.md):
   - Architecture Clarity (0-25)
   - Commands/Workflows (0-25)
   - Non-Obvious Patterns (0-25)
   - Actionability (0-25)
3. Calculate total and assign grade (A: 90-100, B: 70-89, C: 50-69, D: 30-49, F: 0-29)
4. Present report to user:

```
## CONTEXT.md Quality: XX/100 (Grade: X)

| Dimension | Score | Notes |
|-----------|-------|-------|
| Architecture Clarity | X/25 | ... |
| Commands/Workflows | X/25 | ... |
| Non-Obvious Patterns | X/25 | ... |
| Actionability | X/25 | ... |

Sections with placeholders remaining: X/5
```

5. If score < 50: suggest user manually enrich CONTEXT.md later

### Step 10: Onboarding Summary

Print:

```
## GSD-Lean Initialized

Project is ready for the 5-phase development workflow:

1. `/gsd-lean:discuss` — Research and capture requirements
2. `/gsd-lean:plan` — Decompose into structured tasks
3. `/gsd-lean:execute` — Implement tasks with auto-verification
4. `/gsd-lean:verify` — Run project checks
5. `/gsd-lean:complete` — Summarize and wrap up

**Next step:** Run `/gsd-lean:discuss <feature description>` to start the first workflow.
```
