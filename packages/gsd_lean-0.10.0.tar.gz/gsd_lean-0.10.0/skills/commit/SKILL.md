---
description: This skill should be used when the user runs /gsd-lean:commit to create a git commit. Pre-computes git context (branch, status, diff, recent commits) and creates a conventional commit.
argument-hint: [additional context]
allowed-tools: Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git add:*), Bash(git commit:*), Bash(git branch:*)
---

## Current Context

**Branch:** !`git branch --show-current`

**Status:**
```
!`git status --porcelain`
```

**Staged changes:**
```
!`git diff --cached --stat`
```

**Unstaged changes:**
```
!`git diff --stat`
```

**Recent commits (for style reference):**
```
!`git log --oneline -5`
```

## Instructions

Based on the context above:

1. Check branch: If on `main`, warn user and ask to create feature branch first
2. Stage changes: If there are unstaged changes, stage all tracked modified files with `git add`. Never stage sensitive files (`.env`, credentials, API keys, secrets) — warn the user if any are detected in the working tree
3. Create a commit following conventional commit style. If provided, take the additional context from user into account. Provided context: "$ARGUMENTS"
4. Use the recent commits as style reference
5. Keep the message concise (1-2 sentences max)
6. End the commit message with:

```
[Generated with Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <model-revision> <noreply@anthropic.com>
```

Replace `<model-revision>` with the current model name and version (e.g. `Opus 4.6`).

If there are no changes to commit, inform the user.
