# Project Knowledge: GSD-Lean Architecture

> **Quick Links**: [CLAUDE.md](./CLAUDE.md) for operational commands | [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) for debugging | [RELEASE.md](./RELEASE.md) for release process

---

## System Overview

GSD-Lean is a lightweight Python reimplementation of [Get-Shit-Done](https://github.com/glittercowboy/get-shit-done), packaged as a Claude Code plugin. It provides meta-prompting and spec-driven development workflows — skills, subagents, and hooks — that streamline common engineering tasks directly from the CLI.

### Core Capabilities

- **Skills** (slash commands): `/commit`, `/verify`, `/pr`, `/merge`, `/release`, `/prd`
- **Workflow skills**: `/init`, `/discuss`, `/plan`, `/execute`, `/verify`, `/complete`
- **Subagents**: `code-simplifier` (installed via plugin), `verify-plugin`
- **Hooks**: PostToolUse auto-format on Write/Edit (ruff check --fix + ruff format)
- **Ralph**: Autonomous Docker-based agent for background issue processing (`ralph/`)

### Workflow Engine (6-Phase Cycle)

The core development loop: **init → discuss → plan → execute → verify → complete**. Each phase is driven by a skill, backed by CLI commands, and optionally spawns subagents.

#### State Machine

```mermaid
stateDiagram-v2
    [*] --> init : /init or gsd-lean init
    init --> discuss : project initialized

    discuss --> plan : requirements populated
    plan --> discuss : plan rejected
    plan --> execute : plan verified
    execute --> plan : revise plan
    execute --> verify
    verify --> execute : tasks remaining
    verify --> complete : all tasks done
    complete --> discuss : new cycle
    complete --> init : re-initialize
```

#### Transition Matrix

| From | To | Precondition | Trigger |
|------|----|-------------|---------|
| `init` | `discuss` | Project initialized | `/discuss` or `gsd-lean transition discuss` |
| `discuss` | `plan` | REQUIREMENTS.md has no template placeholders (`(not yet defined)`, `(none yet)`) | `/plan` or `gsd-lean transition plan` |
| `plan` | `execute` | PLAN.md exists with Status: `verified` | `/execute` or `gsd-lean transition execute` |
| `plan` | `discuss` | _(none)_ | Plan rejected — back to discuss |
| `execute` | `plan` | REQUIREMENTS.md has no template placeholders | `/plan` or `gsd-lean transition plan` |
| `execute` | `verify` | _(none)_ | `/verify` or `gsd-lean transition verify` |
| `verify` | `execute` | _(none)_ | Tasks remaining — back to execute |
| `verify` | `complete` | All tasks in PLAN.md have status `done` | `/complete` or `gsd-lean transition complete` |
| `complete` | `discuss` | _(none)_ | New cycle — `gsd-lean new-cycle` or `gsd-lean transition discuss` (auto-resets cycle) |
| `complete` | `init` | _(none)_ | Re-initialize — `gsd-lean init` |

All preconditions can be bypassed with `--force`.

#### Phase Details

| Phase | Skill | CLI Command | Subagents Spawned | State Files Read | State Files Written | Produces |
|-------|-------|-------------|-------------------|-----------------|--------------------|---------|
| init | `/init` | `gsd-lean init` | **Detection subagent** (Explore) — scans manifest files, config, CI, conventions | CLAUDE.md (if exists) | PROJECT.md, CONTEXT.md, STATE.md | Detected stack + onboarding |
| discuss | `/discuss` | `gsd-lean transition discuss` | **Research subagent** (Explore) — investigates codebase via LSP + web search | PROJECT.md, CONTEXT.md, cycle/REQUIREMENTS.md, cycle/DECISIONS.md | cycle/REQUIREMENTS.md, cycle/DECISIONS.md, STATE.md | Populated requirements + decisions |
| plan | `/plan` | `gsd-lean transition plan` | **Plan-review subagent** (general-purpose) — verifies plan completeness, requirement coverage, decision adherence. **Update mode** (when returning from execute): preserves task statuses, applies targeted updates | cycle/REQUIREMENTS.md, cycle/DECISIONS.md, PROJECT.md, CONTEXT.md | cycle/PLAN.md, STATE.md | Verified PLAN.md with T-NNN tasks |
| execute | `/execute` | `gsd-lean transition execute` | **Executor subagent** (general-purpose) — implements task code; **Auto-debug subagent** (general-purpose) — fixes verification failures | cycle/PLAN.md, CLAUDE.md, PROJECT.md, CONTEXT.md | cycle/PLAN.md (task + plan status updates), STATE.md | Implemented code + commits |
| verify | `/verify` | `gsd-lean plan-status` | _(none)_ | cycle/PLAN.md, CLAUDE.md (discovers check commands) | _(none)_ | PASS/FAIL report per task |
| complete | `/complete` | `gsd-lean transition complete` | _(none)_ | cycle/PLAN.md, cycle/DECISIONS.md, CONTEXT.md | STATE.md | Completion summary |

#### Subagents

| Subagent | Spawned By | Type | Purpose | Key Tools |
|----------|-----------|------|---------|-----------|
| Detection subagent | `/init` skill | `Explore` (Task tool) | Scan repository for manifest files, config, CI, conventions; auto-detect tech stack | LSP, Glob, Grep, Read |
| Research subagent | `/discuss` skill | `Explore` (Task tool) | Investigate codebase for relevant patterns, files, conventions; external best practices via web search | LSP, Glob, Grep, Read, WebSearch |
| Plan-review subagent | `/plan` skill | `general-purpose` (Task tool) | Verify PLAN.md format, requirement coverage, decision adherence, wave ordering, task atomicity | Read, Glob, Grep |
| Executor subagent | `/execute` skill | `general-purpose` (Task tool) | Implement a single task from PLAN.md — code changes only, no git or status updates | Read, Write, Edit, Glob, Grep, Bash, LSP |
| Auto-debug subagent | `/execute` skill | `general-purpose` (Task tool) | Fix verification failures from executor — narrow scope, minimal fix | Read, Write, Edit, Glob, Grep, Bash, LSP |

The plan-review subagent runs up to 2 times (1 revision loop max). If both attempts fail, the user reviews manually.

#### CLI Commands

**`gsd-lean transition <phase>`** — move workflow to a new phase.

```
Options:
  --force       Bypass precondition checks
  --note TEXT   Note for STATE.md history table
  --path PATH   Project root (default: .)
```

Output: `Transitioned to: <phase>` (exit 0) or `Error: <message>` on stderr (exit 1).

**`gsd-lean new-cycle`** — archive current cycle and start fresh.

```
Options:
  --no-archive  Delete old cycle files instead of archiving
  --path PATH   Project root (default: .)
```

Output: Lists created files, `New cycle started with N file(s).` (exit 0) or `Error: <message>` on stderr (exit 1).

**`gsd-lean migrate`** — migrate v1 `.planning/` layout to v2 (static/cycle split).

```
Options:
  --path PATH   Project root (default: .)
```

Output: `Migrated .planning/ to v2 layout.` or `No migration needed (already v2 or no .planning/ found).`

**`gsd-lean plan-status`** — display plan progress.

```
Options:
  --json        Output as JSON (for ralph/scripting)
  --path PATH   Project root (default: .)
```

Human output: `Plan: verified | Wave: 2/3 | Tasks: 4/12 done | Next: T-005`

JSON output: `{"status": "verified", "total": 12, "done": 4, "pending": 6, "in_progress": 1, "blocked": 1, "current_wave": 2, "total_waves": 3, "next_task": "T-005"}`

#### State Files (`.planning/`)

The `.planning/` directory uses a two-tier layout — static files persist across development cycles, ephemeral cycle files are regenerated each `/discuss`.

**Static files** (`.planning/` root — committed to git):

| File | Created By | Purpose |
|------|-----------|---------|
| `PROJECT.md` | `gsd-lean init` | Project name, stack, constraints |
| `CONTEXT.md` | `gsd-lean init` | Architecture, tooling, skills (static project context) |
| `STATE.md` | `gsd-lean init` → `gsd-lean transition` (updated) | Current phase, active task, history table |
| `config.yaml` | `gsd-lean init` | Subagent configuration (model, max_turns) |
| `.gitignore` | `gsd-lean init` | Ignores cycle/, cycle-archive/, STATE.md |

**Ephemeral cycle files** (`.planning/cycle/` — gitignored, regenerated per cycle):

| File | Created By | Purpose |
|------|-----------|---------|
| `REQUIREMENTS.md` | `gsd-lean init` (template) → `/discuss` (populated) | User intent, functional/non-functional requirements |
| `DECISIONS.md` | `gsd-lean init` (template) → `/discuss` (populated) | Cycle-specific decisions: style, constraints, dependencies |
| `PLAN.md` | `/plan` skill | Task breakdown (T-NNN), wave ordering, verification criteria |

**Archive** (`.planning/cycle-archive/<timestamp>/` — auto-created on new cycle):

Previous cycle files are archived with ISO timestamp when starting a new cycle via `gsd-lean new-cycle` or `complete → discuss` transition.

---

## Architecture

### Repo Structure

```
gsd-lean/
├── .claude/               # Claude Code config
│   ├── agents/            # Subagent definitions
│   ├── skills/            # Skill definitions
│   └── settings.json      # Claude Code settings/config
├── src/gsd_lean/          # Python package source
├── tests/                 # pytest tests
├── .claude-plugin/        # Metadata directory
│   └── plugin.json        # Plugin manifest
├── agents/                # Default agent location
├── skills/                # Agent Skills
├── hooks/                 # Hook configurations
│   └── hooks.json         # Main hook config
├── ralph/                 # Autonomous Docker agent (ralph loop)
│   ├── ralph.sh           # Entry script
│   ├── prompt.md          # Agent prompt
│   └── issues/            # Issue tracking
├── docs/prds/             # Product requirement docs
├── .github/workflows/     # CI pipeline
├── pyproject.toml         # Project metadata + tool config
├── Makefile               # Dev commands
├── mise.toml              # uv version pin
└── uv.lock                # Dependency lockfile
```

---

## Core Stack

### Runtime: uv

[uv](https://github.com/astral-sh/uv) is a fast Python package manager that replaces pip, pip-tools, and virtualenv. All dev commands run through `uv run` (via Makefile). Dependencies are locked in `uv.lock`. Version pinned to `0.9.25` in `mise.toml`.

---

## Build & Deployment

### CI/CD Pipeline Architecture

GitHub Actions CI runs on push/PR to `main` with 5 jobs:

1. **lint** — pre-commit (ruff, pyright, yamllint, file checks) on Python 3.14
2. **test** — pytest + coverage on Python 3.12, 3.13, 3.14 (matrix)
3. **coverage** — combines coverage artifacts, enforces 90% minimum
4. **check** — alls-green gate; ensures lint + test + coverage all pass
5. **github-release** — triggered on `v*` tag push; creates GitHub release

```mermaid
graph LR
    lint --> check
    test --> coverage --> check
    check --> github-release
```

---

## Code Quality Philosophy

Automated quality enforcement via ruff (lint + format) and pyright (strict types), gated by pre-commit hooks and CI.

### Ruff Standards

**What is Ruff?**

Fast Python linter and formatter written in Rust. Replaces flake8, isort, black, and pyflakes in a single tool.

**Key Principles**:

- Single quotes for code, double quotes for docstrings
- Google-style docstrings (pydocstyle convention)
- Line length: 130 characters
- Auto-fix on file save via PostToolUse hook

**Configuration** (`pyproject.toml`):

Configured under `[tool.ruff]`. Enabled rule sets:
- `E` — pycodestyle
- `F` — pyflakes
- `UP` — pyupgrade
- `B` — flake8-bugbear
- `SIM` — flake8-simplify
- `I` — isort
- `D` — pydocstyle
- `PL` — pylint

Key ignores: `D100` (module docstring), `D104` (package docstring), `D106`/`D107` (nested/init docstring), `PLR2004` (magic values), `PLR0912`/`PLR0913`/`PLR0915` (complexity limits).

---

## Key File Locations

### Configuration Files

| File | Purpose |
|------|---------|
| `pyproject.toml` | Project metadata, deps, ruff/pyright/pytest/coverage config |
| `Makefile` | Dev commands (sync, ruff, pyright, tests, clean) |
| `.pre-commit-config.yaml` | Pre-commit hook definitions |
| `.github/workflows/ci.yml` | CI pipeline |
| `mise.toml` | uv version pin (0.9.25) |
| `.claude/settings.json` | Plugin config (code-simplifier, pyright-lsp) |
| `hooks/hooks.json` | PostToolUse auto-format hook (ruff check --fix + format) |

---

- **[CLAUDE.md](./CLAUDE.md)**: Operational commands and AI assistant guidelines
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)**: Common issues and debugging workflows
- **[RELEASE.md](./RELEASE.md)**: Release management
- **Skills**: Implementation patterns and commands in `.claude/skills/`
