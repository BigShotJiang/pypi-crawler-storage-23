"""Tests for the MCP server and plugin detection module."""

import pytest

from gsd_lean.state.detector import (
    McpPluginInfo,
    detect_mcp_plugins,
    format_mcp_plugin_summary,
    merge_into_context_md,
)


class TestDetectMcpPlugins:
    """Tests for MCP server and plugin detection."""

    def test_detect_mcp_plugins_full(self, tmp_path):
        """Test both .mcp.json and .claude/settings.json parsed correctly."""
        (tmp_path / '.mcp.json').write_text('{"mcpServers": {"context7": {}, "filesystem": {}}}')
        (tmp_path / '.claude').mkdir()
        (tmp_path / '.claude' / 'settings.json').write_text('{"enabledPlugins": {"pyright-lsp": true, "disabled-one": false}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == ['context7', 'filesystem']
        assert info.plugins == ['pyright-lsp']

    def test_detect_mcp_no_files(self, tmp_path):
        """Test no config files → empty McpPluginInfo."""
        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []
        assert info.plugins == []

    def test_detect_mcp_malformed_json(self, tmp_path):
        """Test malformed .mcp.json → graceful fallback."""
        (tmp_path / '.mcp.json').write_text('{ broken json')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []
        assert info.plugins == []

    def test_detect_mcp_empty_servers(self, tmp_path):
        """Test empty mcpServers dict → empty list."""
        (tmp_path / '.mcp.json').write_text('{"mcpServers": {}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []

    def test_detect_mcp_disabled_plugins(self, tmp_path):
        """Test plugins with false value → filtered out."""
        (tmp_path / '.claude').mkdir()
        (tmp_path / '.claude' / 'settings.json').write_text('{"enabledPlugins": {"a-plugin": false, "b-plugin": false}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.plugins == []


class TestFormatMcpPluginSummary:
    """Tests for format_mcp_plugin_summary function."""

    def test_format_both(self):
        """Test formatting with both servers and plugins."""
        info = McpPluginInfo(mcp_servers=['context7', 'filesystem'], plugins=['pyright-lsp'])
        result = format_mcp_plugin_summary(info)

        assert '- **MCP servers:** context7, filesystem' in result
        assert '- **Plugins:** pyright-lsp' in result

    def test_format_servers_only(self):
        """Test formatting with only servers."""
        info = McpPluginInfo(mcp_servers=['context7'])
        result = format_mcp_plugin_summary(info)

        assert '- **MCP servers:** context7' in result
        assert '**Plugins:**' not in result

    def test_format_empty(self):
        """Test formatting with nothing detected."""
        info = McpPluginInfo()
        result = format_mcp_plugin_summary(info)

        assert result == ''


class TestMergeIntoContextMd:
    """Tests for merge_into_context_md function."""

    def _setup_context_md(self, tmp_path, content):
        """Helper to create .planning/CONTEXT.md."""
        planning_dir = tmp_path / '.planning'
        planning_dir.mkdir(exist_ok=True)
        context_file = planning_dir / 'CONTEXT.md'
        context_file.write_text(content)
        return context_file

    def test_merge_into_context_md(self, tmp_path):
        """Test non-destructive merge into ## Tooling section."""
        template = '# Project Context\n\n## Architecture\n\n- (none yet)\n\n## Tooling\n\n- (none yet)\n'
        self._setup_context_md(tmp_path, template)
        mcp_info = McpPluginInfo(mcp_servers=['context7'], plugins=['pyright-lsp'])

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is True
        content = (tmp_path / '.planning' / 'CONTEXT.md').read_text()
        assert '- **MCP servers:** context7' in content
        assert '- **Plugins:** pyright-lsp' in content
        assert '- (none yet)' not in content.split('## Tooling')[1]

    def test_merge_context_preserves_user_content(self, tmp_path):
        """Test user-edited Tooling section not overwritten."""
        user_content = '# Project Context\n\n## Architecture\n\n- (none yet)\n\n## Tooling\n\n- User added this manually\n'
        self._setup_context_md(tmp_path, user_content)
        mcp_info = McpPluginInfo(mcp_servers=['context7'])

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is False
        content = (tmp_path / '.planning' / 'CONTEXT.md').read_text()
        assert '- User added this manually' in content

    def test_merge_context_empty_info(self, tmp_path):
        """Test that empty McpPluginInfo makes no changes."""
        template = '# Project Context\n\n## Tooling\n\n- (none yet)\n'
        self._setup_context_md(tmp_path, template)
        mcp_info = McpPluginInfo()

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is False

    def test_merge_context_raises_when_missing(self, tmp_path):
        """Test FileNotFoundError when CONTEXT.md is missing."""
        mcp_info = McpPluginInfo(mcp_servers=['context7'])

        with pytest.raises(FileNotFoundError, match='CONTEXT.md not found'):
            merge_into_context_md(tmp_path, mcp_info)
