"""Tests for the installer module."""

import json

from gsd_lean.installer import HOOK_REL, SETTINGS_REL, install_statusline


class TestInstallStatusline:
    """Tests for install_statusline()."""

    def test_fresh_install(self, tmp_path):
        """Fresh install creates settings.json and copies script."""
        actions = install_statusline(tmp_path)

        assert (tmp_path / HOOK_REL).exists()
        assert (tmp_path / SETTINGS_REL).exists()

        settings = json.loads((tmp_path / SETTINGS_REL).read_text())
        assert settings['statusLine']['type'] == 'command'
        assert settings['statusLine']['command'] == str(HOOK_REL)

        assert len(actions) == 2
        assert 'copied' in actions[0]
        assert 'configured' in actions[1]

    def test_script_is_executable(self, tmp_path):
        """Copied script has execute permission."""
        install_statusline(tmp_path)
        hook = tmp_path / HOOK_REL
        assert hook.stat().st_mode & 0o111

    def test_existing_statusline_copies_script_but_preserves_config(self, tmp_path):
        """Existing statusLine config: script copied, settings preserved, info message shown."""
        settings_path = tmp_path / SETTINGS_REL
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({'statusLine': {'type': 'command', 'command': 'custom.sh'}}))

        actions = install_statusline(tmp_path)

        # Script is always copied
        assert (tmp_path / HOOK_REL).exists()
        assert (tmp_path / HOOK_REL).stat().st_mode & 0o111
        assert 'copied' in actions[0]
        # Settings preserved
        settings = json.loads(settings_path.read_text())
        assert settings['statusLine']['command'] == 'custom.sh'
        # Info message about availability
        assert len(actions) == 2
        assert 'already configured' in actions[1]
        assert str(HOOK_REL) in actions[1]

    def test_force_overwrites(self, tmp_path):
        """force=True overwrites existing statusLine config."""
        settings_path = tmp_path / SETTINGS_REL
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({'statusLine': {'type': 'command', 'command': 'custom.sh'}}))

        actions = install_statusline(tmp_path, force=True)

        assert len(actions) == 2
        settings = json.loads(settings_path.read_text())
        assert settings['statusLine']['command'] == str(HOOK_REL)

    def test_missing_claude_dir_creates_it(self, tmp_path):
        """Missing .claude/ directory is created automatically."""
        assert not (tmp_path / '.claude').exists()

        install_statusline(tmp_path)

        assert (tmp_path / '.claude').is_dir()
        assert (tmp_path / HOOK_REL).exists()
        assert (tmp_path / SETTINGS_REL).exists()

    def test_preserves_existing_settings(self, tmp_path):
        """Existing keys in settings.json are preserved."""
        settings_path = tmp_path / SETTINGS_REL
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({'env': {'FOO': '1'}}))

        install_statusline(tmp_path)

        settings = json.loads(settings_path.read_text())
        assert settings['env'] == {'FOO': '1'}
        assert 'statusLine' in settings
