"""Tests for the config module."""

from gsd_lean.state.config import (
    DEFAULT_MAX_TURNS,
    SubagentConfig,
    load_config,
    resolve_subagent_config,
    validate_config,
)
from gsd_lean.state.planning import PLANNING_DIR


class TestLoadConfig:
    """Tests for load_config function."""

    def test_loads_valid_yaml(self, tmp_path):
        """Test that load_config parses a valid YAML file."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('defaults:\n  max_turns: 25\n')

        data = load_config(tmp_path)
        assert data == {'defaults': {'max_turns': 25}}

    def test_returns_empty_dict_when_missing(self, tmp_path):
        """Test that load_config returns {} when config file is missing."""
        data = load_config(tmp_path)
        assert data == {}

    def test_returns_empty_dict_on_invalid_yaml(self, tmp_path):
        """Test that load_config returns {} for malformed YAML."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('{{invalid yaml: [}')

        data = load_config(tmp_path)
        assert data == {}

    def test_returns_empty_dict_on_empty_file(self, tmp_path):
        """Test that load_config returns {} for an empty file."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('')

        data = load_config(tmp_path)
        assert data == {}


class TestValidateConfig:
    """Tests for validate_config function."""

    def test_valid_full_config(self):
        """Test that a fully valid config produces no errors."""
        data = {
            'defaults': {'model': 'sonnet', 'max_turns': 25},
            'skills': {
                'execute': {
                    'subagents': {
                        'executor': {'model': 'sonnet', 'max_turns': 40},
                        'auto-debug': {'model': 'haiku', 'max_turns': 20},
                        'verify': {'max_turns': 15},
                    }
                }
            },
        }
        errors = validate_config(data)
        assert errors == []

    def test_invalid_model_value(self):
        """Test that an invalid model value produces an error."""
        data = {'defaults': {'model': 'gpt-4'}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'invalid model' in errors[0]

    def test_invalid_max_turns_negative(self):
        """Test that a negative max_turns produces an error."""
        data = {'defaults': {'max_turns': -5}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'must be positive' in errors[0]

    def test_invalid_max_turns_non_int(self):
        """Test that a non-int max_turns produces an error."""
        data = {'defaults': {'max_turns': 'abc'}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'must be a positive integer' in errors[0]

    def test_unknown_skill_warns(self):
        """Test that an unknown skill name produces a warning."""
        data = {'skills': {'unknown_skill': {'subagents': {}}}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'unknown skill' in errors[0]

    def test_unknown_subagent_warns(self):
        """Test that an unknown subagent name produces a warning."""
        data = {'skills': {'execute': {'subagents': {'nonexistent': {'model': 'sonnet'}}}}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'unknown subagent' in errors[0]

    def test_empty_config_no_errors(self):
        """Test that an empty dict passes validation."""
        errors = validate_config({})
        assert errors == []


class TestResolveSubagentConfig:
    """Tests for resolve_subagent_config function."""

    def test_skill_specific_overrides_defaults(self):
        """Test that skill-specific config overrides defaults."""
        data = {
            'defaults': {'model': 'sonnet', 'max_turns': 25},
            'skills': {
                'execute': {
                    'subagents': {
                        'executor': {'model': 'opus', 'max_turns': 50},
                    }
                }
            },
        }
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config == SubagentConfig(model='opus', max_turns=50)

    def test_defaults_used_when_no_skill_override(self):
        """Test that defaults are used when no skill-specific config exists."""
        data = {'defaults': {'model': 'sonnet', 'max_turns': 30}}
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config == SubagentConfig(model='sonnet', max_turns=30)

    def test_hardcoded_fallback_for_max_turns(self):
        """Test that DEFAULT_MAX_TURNS is used when nothing else is configured."""
        data = {}
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config.max_turns == DEFAULT_MAX_TURNS['execute']['executor']
        assert config.model is None

    def test_hardcoded_fallback_for_verify(self):
        """Test that DEFAULT_MAX_TURNS is used for execute/verify when nothing else is configured."""
        config = resolve_subagent_config({}, 'execute', 'verify')
        assert config.max_turns == DEFAULT_MAX_TURNS['execute']['verify']
        assert config.model is None

    def test_none_when_not_configured(self):
        """Test that model is None when nothing is set anywhere."""
        data = {}
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config.model is None

    def test_partial_override_model_only(self):
        """Test that model from skill-specific and max_turns from defaults resolve independently."""
        data = {
            'defaults': {'max_turns': 30},
            'skills': {
                'execute': {
                    'subagents': {
                        'executor': {'model': 'opus'},
                    }
                }
            },
        }
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config.model == 'opus'
        assert config.max_turns == 30

    def test_empty_config_returns_hardcoded(self):
        """Test that empty config uses DEFAULT_MAX_TURNS."""
        config = resolve_subagent_config({}, 'discuss', 'explore')
        assert config.model is None
        assert config.max_turns == DEFAULT_MAX_TURNS['discuss']['explore']

    def test_unknown_skill_returns_none_for_max_turns(self):
        """Test that an unknown skill with no defaults returns None for max_turns."""
        config = resolve_subagent_config({}, 'unknown', 'subagent')
        assert config.model is None
        assert config.max_turns is None
