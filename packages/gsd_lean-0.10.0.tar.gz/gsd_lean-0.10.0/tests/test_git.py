"""Tests for git utility functions."""

import subprocess
from unittest.mock import patch

from gsd_lean.git import get_current_branch, get_default_branch


class TestGetCurrentBranch:
    """Tests for get_current_branch."""

    def test_returns_branch_name(self, tmp_path: object) -> None:
        """Test returns branch name on success."""
        fake = subprocess.CompletedProcess(args=[], returncode=0, stdout='feature/foo\n', stderr='')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_current_branch(tmp_path) == 'feature/foo'  # type: ignore[arg-type]

    def test_returns_none_on_failure(self, tmp_path: object) -> None:
        """Test returns None when git fails (not a repo)."""
        fake = subprocess.CompletedProcess(args=[], returncode=128, stdout='', stderr='fatal')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_current_branch(tmp_path) is None  # type: ignore[arg-type]

    def test_returns_none_on_detached_head(self, tmp_path: object) -> None:
        """Test returns None on detached HEAD."""
        fake = subprocess.CompletedProcess(args=[], returncode=0, stdout='HEAD\n', stderr='')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_current_branch(tmp_path) is None  # type: ignore[arg-type]

    def test_strips_whitespace(self, tmp_path: object) -> None:
        """Test strips trailing newline/whitespace."""
        fake = subprocess.CompletedProcess(args=[], returncode=0, stdout='  main  \n', stderr='')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_current_branch(tmp_path) == 'main'  # type: ignore[arg-type]


class TestGetDefaultBranch:
    """Tests for get_default_branch."""

    def test_returns_from_symbolic_ref(self, tmp_path: object) -> None:
        """Test parses symbolic-ref output correctly."""
        fake = subprocess.CompletedProcess(args=[], returncode=0, stdout='refs/remotes/origin/main\n', stderr='')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_default_branch(tmp_path) == 'main'  # type: ignore[arg-type]

    def test_returns_master_from_symbolic_ref(self, tmp_path: object) -> None:
        """Test parses master branch correctly."""
        fake = subprocess.CompletedProcess(args=[], returncode=0, stdout='refs/remotes/origin/master\n', stderr='')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_default_branch(tmp_path) == 'master'  # type: ignore[arg-type]

    def test_falls_back_to_main(self, tmp_path: object) -> None:
        """Test falls back to 'main' when symbolic-ref fails."""
        fake = subprocess.CompletedProcess(args=[], returncode=1, stdout='', stderr='fatal')
        with patch('gsd_lean.git.subprocess.run', return_value=fake):
            assert get_default_branch(tmp_path) == 'main'  # type: ignore[arg-type]
