# Troubleshooting Guide

> **Quick Links**: [CLAUDE.md](./CLAUDE.md#quick-start) for commands | [PROJECT_KNOWLEDGE.md](./PROJECT_KNOWLEDGE.md#architecture) for architecture

---

## Quick Diagnostic Checklist

Before deep debugging, run these checks:

```bash
# 0. Create clean dev environment
make setup-venv

# 1. Run local quality checks
uv run ruff check && uv run pyright

# 2. Run lint + formatting
uv run ruff check --fix && uv run ruff format
```

If all checks pass and issue persists, continue to relevant section below.

---

## Git Worktree Setup (emdash/parallel Claude Code)

### One-Time Setup

Enable mise shims for non-interactive shells ([docs](https://mise.jdx.dev/dev-tools/shims.html#using-mise-in-rc-files)):

```bash
# In ~/.zshrc, replace your mise activation with:
eval "$(mise activate zsh --shims)"
eval "$(mise activate zsh)"
```

Then `source ~/.zshrc`.

### How It Works

- `--shims` activation ensures uv work in non-interactive shells

### Troubleshooting

**mise tools (uv) not found:**
- Verify both mise activate lines in `~/.zshrc`
- Check shims exist: `ls ~/.local/share/mise/shims/`
- Regenerate shims: `mise reshim`

**`/merge` not working from main repo:**
- `/merge` works best from the worktree where the branch is checked out
- From other locations: merge completes but local cleanup skipped

---

## CI/CD Debugging

### Step-by-Step Workflow

Use `gh` CLI for systematic CI debugging:

**1. Check PR status** (after pushing changes):
```bash
gh pr checks <pr-number>
```
Shows: status (pass/fail), duration, and links to all checks

**2. List recent workflow runs** (to find run ID):
```bash
gh run list --branch <branch-name> --limit 5
```
Shows: status, run ID, duration, trigger time

**3. View failed logs** (identify root cause):
```bash
gh run view <run-id> --log-failed
```
Shows: only the failed job logs with error details

**4. Monitor live runs** (watch new run after fixes):
```bash
sleep 10 && gh run list --branch <branch> --limit 1 --json conclusion,status,databaseId
```
Poll for completion, then check final status

### Common CI Failure Patterns

| Error Type | CI Job | Local Repro | Fix |
|------------|--------|-------------|-----|
| **Ruff violations** | lint | `make ruff` | `make ruff` (auto-fixes) |
| **Type errors** | lint | `make pyright` | Fix type annotations |
| **Test failures** | test | `make run-tests` | Fix failing tests |
| **Coverage below 90%** | coverage | `make run-tests-cov` | Add tests |
| **Missing deps** | test/lint | `make sync` | Update `pyproject.toml` |

**Pro tips**:
- Always run `make ruff && make pyright` locally before pushing
- Pre-commit hooks catch most issues, but CI is the final gate
- Use `gh run view --log-failed` to avoid scrolling through successful job logs
- Check `.github/workflows/ci.yml` if you need to understand job dependencies

---

## Linting & Formatting

### Pre-commit Hook Not Running

**Problem**: Push fails with lint errors, but commit succeeded without fixing

**Solution**:
```bash
# Reinstall pre-commit hooks
make pre-commit-install

# Verify hooks installed
ls -la .git/hooks/ | grep pre-commit
```

**Verification**:
```bash
# Stage a file with lint error
echo "lambda x: x if True else 0" > scripts/test_file.py
git add test_file.py
git commit -m "test"  # Should auto-fix or show error
```

### Ruff Lint Errors After Pulling main

**Problem**: New lint errors after pulling latest main branch

**Solution**:
```bash
uv run ruff check --fix   # Auto-fix most issues
uv run ruff format        # Reformat files

# Review changes
git diff

# Commit fixes
git add .
git commit -m "fix: apply ruff formatting updates"
```

**Why This Happens**: Ruff config or rules may have been updated in main branch

---

## Docker Sandbox

For troubleshooting `docker sandbox` problems see [docker sandbox setup](./ralph/SETUP.md)
