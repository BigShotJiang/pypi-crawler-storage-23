---
description: Create a pre-release (alpha/beta/RC) by tagging main
argument-hint: ["version, e.g. v0.2.0a1, v0.2.0b1, v0.2.0rc1"]
disable-model-invocation: true
allowed-tools: Bash(git:*), Bash(gh:*), Bash(xargs:*), Bash(jq:*), Bash(mv:*)
---

## Current Context

**Branch:** !`git branch --show-current`

**Latest tags:**
```
!`git tag --sort=-v:refname | head -5`
```

**Last stable release tag:**
```
!`git tag --sort=-v:refname --list 'v*' | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | head -1`
```

**Last pre-release tag:**
```
!`git tag --sort=-v:refname --list 'v*' | grep -E '(a|b|rc)[0-9]+$' | head -1`
```

**Commits since last tag (or all if no tag):**
```
!`git tag --sort=-v:refname --list 'v*' | head -1 | xargs -I{} git log {}..HEAD --oneline 2>/dev/null || git log --oneline`
```

**Tag exists for requested version?**
```
!`git tag -l "$1" 2>/dev/null || echo "no argument provided"`
```

## Instructions

### PEP 440 Pre-Release Format

| Type   | Tag example   | PyPI version |
|--------|---------------|--------------|
| Alpha  | `v0.2.0a1`    | `0.2.0a1`    |
| Beta   | `v0.2.0b1`    | `0.2.0b1`    |
| RC     | `v0.2.0rc1`   | `0.2.0rc1`   |

### If version argument provided (`$ARGUMENTS` is non-empty):

1. Validate format matches `v*.*.*{a,b,rc}N` (e.g. `v0.2.0a1`, `v0.2.0rc2`). If invalid, stop and show valid examples.
2. If tag already exists, stop.
3. Skip to **Create Pre-Release** below.

### If no version argument:

Determine the next pre-release version interactively.

1. **Find base version**: Parse the latest stable `v*.*.*` tag. If none exists, use `v0.0.0`.
2. **Scan commits** (shown in context above). Apply highest bump found:
   - `BREAKING CHANGE` in body/footer OR `!:` in subject → **major** bump
   - `feat:` or `feat(…):` prefix → **minor** bump
   - Anything else (`fix:`, `chore:`, `docs:`, etc.) → **patch** bump
3. **Compute next base version**: Apply bump to base (e.g. `v0.1.2` + minor = `v0.2.0`).
4. **Determine pre-release suffix**:
   - Check existing pre-release tags for that base version (e.g. `v0.2.0a1`, `v0.2.0a2`).
   - Default to `a1` (alpha 1) if no pre-releases exist.
   - If alpha tags exist, suggest next alpha (`a2`, `a3`, …).
5. **Present to user**: Show suggested version, the commits that informed the bump, and the pre-release type. Ask for confirmation. User may override version or pre-release type (alpha/beta/rc).

### Create Pre-Release

No changelog PR needed — tag directly on main.

1. If not on `main`, switch: `git switch main`
2. Pull latest: `git pull origin main`
3. Sync plugin version: `jq --arg v "<version-without-v>" '.version = $v' .claude-plugin/plugin.json > tmp.json && mv tmp.json .claude-plugin/plugin.json`
4. Commit (if changed): `git add .claude-plugin/plugin.json && git diff --cached --quiet || git commit -m "chore: sync plugin version to <version>"`
5. Create annotated tag: `git tag -a <version> -m "Pre-release <version>"`
6. Push commit and tag: `git push origin main && git push origin <version>`
7. Report: Tag pushed. CI will publish to PyPI (pre-release) and create a GitHub release marked as pre-release.
8. Remind user: `pip install gsd-lean` still installs stable; use `pip install --pre gsd-lean` for pre-releases.
