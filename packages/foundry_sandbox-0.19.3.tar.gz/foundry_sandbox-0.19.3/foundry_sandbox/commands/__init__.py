"""CLI command modules for foundry-sandbox.

Commands are registered with the main CLI group as they are migrated
from shell scripts to Python Click commands.
"""
