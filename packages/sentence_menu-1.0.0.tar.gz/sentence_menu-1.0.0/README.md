# sentence-menu
A command-line fuzzy command-menu keyed with full sentences which runs command.

This is unreviewed AI-generated code. It will likely become more reviewed if anyone uses it.

## Motivation
I want to find snippets to do things based on what I have done before. I use the snippet framework I wrote, zshnip, but sometimes I want to be lazy and use full sentences.

## Alternatives
`navi` is a menuing system with fuzzy search and tags which focuses on commands to run, but focuses on cheat sheet files (supporting several). I dislike editing files and if I have to edit a file to add a command I often won't do it.

`fzf` provides a fuzzy menu but is more a command line tool to build thigns than a complete solution.

`rofi` is another fuzzy menuing system designed for gui environments. It can automatically search your path for commands. Most desktop environments, like KDE or Gnome, provide some sort of fuzzy search.

I also sometimes use Obsidian to keep track of commands related to a topic. This can work well, but not for things I want to run quickly. I have a shortcut to popup Obsidian. You could use emacs org-mode for similar purposes.

You could also use an LLM.

## Installation
pipx install sentence-menu

## Usage
Interactively add a command: `sentence-menu add`

Interactively edit an entry: `sentence-menu edit`

Run a command: `sentence-menu`

Print a command to standard out: `sentence-menu echo`

## About me
I am @readwithai. I make lots of small tools like this. I also make tools for reading with and without AI.
