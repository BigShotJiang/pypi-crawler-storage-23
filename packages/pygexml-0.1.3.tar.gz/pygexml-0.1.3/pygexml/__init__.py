from .page import Page

__all__ = ["Page"]
