.. image:: https://img.shields.io/github/license/kuhl-haus/kuhl-haus-mdp
    :alt: License
    :target: https://github.com/kuhl-haus/kuhl-haus-mdp/blob/mainline/LICENSE.txt
.. image:: https://img.shields.io/pypi/v/kuhl-haus-mdp.svg
    :alt: PyPI
    :target: https://pypi.org/project/kuhl-haus-mdp/
.. image:: https://static.pepy.tech/badge/kuhl-haus-mdp/month
    :alt: Downloads
    :target: https://pepy.tech/project/kuhl-haus-mdp
.. image:: https://github.com/kuhl-haus/kuhl-haus-mdp/actions/workflows/publish-to-pypi.yml/badge.svg
    :alt: Build Status
    :target: https://github.com/kuhl-haus/kuhl-haus-mdp/actions/workflows/publish-to-pypi.yml
.. image:: https://github.com/kuhl-haus/kuhl-haus-mdp/actions/workflows/codeql.yml/badge.svg
    :alt: CodeQL Advanced
    :target: https://github.com/kuhl-haus/kuhl-haus-mdp/actions/workflows/codeql.yml
.. image:: https://codecov.io/gh/kuhl-haus/kuhl-haus-mdp/branch/mainline/graph/badge.svg
    :alt: codecov
    :target: https://codecov.io/gh/kuhl-haus/kuhl-haus-mdp
.. image:: https://img.shields.io/github/issues/kuhl-haus/kuhl-haus-mdp
    :alt: GitHub issues
    :target: https://github.com/kuhl-haus/kuhl-haus-mdp/issues
.. image:: https://img.shields.io/github/issues-pr/kuhl-haus/kuhl-haus-mdp
    :alt: GitHub pull requests
    :target: https://github.com/kuhl-haus/kuhl-haus-mdp/pulls
.. image:: https://readthedocs.org/projects/kuhl-haus-mdp/badge/?version=latest
    :alt: Documentation
    :target: https://kuhl-haus-mdp.readthedocs.io/en/latest/

|

==============
kuhl-haus-mdp
==============

Market data processing library.

Overview
========

The Kuhl Haus Market Data Platform (MDP) is a distributed system for collecting, processing, and serving real-time market data. Built on Kubernetes and leveraging microservices architecture, MDP provides scalable infrastructure for financial data analysis and visualization.

Key Features
------------

- Real-time market data ingestion and processing
- Scalable microservices architecture
- Automated deployment with Ansible and Kubernetes
- Multi-environment support (development, staging, production)
- OAuth integration for secure authentication
- Redis-based caching layer for performance

Code Organization
-----------------

The platform consists of four main packages:

- **Market data processing library** (`kuhl-haus-mdp <https://github.com/kuhl-haus/kuhl-haus-mdp>`_) - Core library with shared data processing logic
- **Backend Services** (`kuhl-haus-mdp-servers <https://github.com/kuhl-haus/kuhl-haus-mdp-servers>`_) - Market data listener, processor, and widget service
- **Frontend Application** (`kuhl-haus-mdp-app <https://github.com/kuhl-haus/kuhl-haus-mdp-app>`_) - Web-based user interface and API
- **Deployment Automation** (`kuhl-haus-mdp-deployment <https://github.com/kuhl-haus/kuhl-haus-mdp-deployment>`_) - Docker Compose, Ansible playbooks and Kubernetes manifests for environment provisioning

Documentation
-------------

For architecture details, component descriptions, and API reference, see the
`full documentation on Read the Docs <https://kuhl-haus-mdp.readthedocs.io/en/latest/>`_.

Additional Resources
--------------------

📖 **Blog Series:**

- `Part 1: Why I Built It <https://the.oldschool.engineer/what-i-built-after-quitting-amazon-spoiler-its-a-stock-scanner-28fc3b6d9be0>`_
- `Part 2: How to Run It <https://the.oldschool.engineer/what-i-built-after-quitting-amazon-spoiler-its-a-stock-scanner-part-2-94e445914951>`_
- `Part 3: How to Deploy It <https://the.oldschool.engineer/what-i-built-after-quitting-amazon-spoiler-its-a-stock-scanner-part-3-eab7d9bbf5f7>`_
- `Part 4: Evolution from Prototype to Production <https://the.oldschool.engineer/what-i-built-after-quitting-amazon-spoiler-its-a-stock-scanner-part-4-408779a1f3f2>`_
