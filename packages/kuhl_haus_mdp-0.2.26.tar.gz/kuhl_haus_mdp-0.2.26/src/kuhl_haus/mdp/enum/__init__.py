"""Enumerations and constants for market data processing pipeline.

Defines scanner types, queue identifiers, cache keys with TTLs, and pub/sub
channel names used throughout the real-time market data ingestion and analysis
system. All Redis key patterns and time constants are centralized here.
"""
