"""Analyzers for real-time market data streams.

Provides base analyzer abstractions and concrete implementations for processing
WebSocket events from Massive.com, including top stocks, top trades, and
leaderboard analysis backed by Redis caching.
"""
