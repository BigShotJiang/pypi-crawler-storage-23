See @AGENTS.md for project context, architecture, and conventions.
