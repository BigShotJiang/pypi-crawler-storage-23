# speakhuman

Welcome to the speakhuman API reference.

- [Number](number.md)
- [Time](time.md)
- [Filesize](filesize.md)
- [Lists](lists.md)
- [I18n](i18n.md)

{%
   include-markdown "../README.md"
   start="<!-- usage-start -->"
   end="<!-- usage-end -->"
   comments=false
%}
