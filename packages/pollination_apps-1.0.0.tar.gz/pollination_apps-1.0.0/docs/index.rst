.. Pollination Apps documentation master file, created by
   sphinx-quickstart on Wed Mar 13 20:09:41 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. mdinclude:: README.md

.. toctree::
   :maxdepth: 1

   cli
   modules
