CLI Docs
========

Installation
------------

You can install the `pollination-apps` cli tool using the following command::

   pip install -u pollination-apps


.. click:: pollination_apps.cli:main
   :prog: Commands
   :show-nested:

