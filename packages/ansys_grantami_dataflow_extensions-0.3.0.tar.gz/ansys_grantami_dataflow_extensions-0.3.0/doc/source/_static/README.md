Static files are found here (like images and other assets).
