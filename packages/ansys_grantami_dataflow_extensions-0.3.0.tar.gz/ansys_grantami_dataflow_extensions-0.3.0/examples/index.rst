.. _ref_grantami_dataflow_extensions_examples:

Examples
========

The following examples demonstrate key aspects of the Granta MI Data Flow Extensions package.

To run these examples, install dependencies with this command:

.. code::

   pip install ansys-grantami-dataflow-extensions[examples]

.. toctree::
   :maxdepth: 1

   1_Standalone
   2_Scripting_Toolkit
   3_RecordLists
