This directory is a working area where we are transitioning code from the Egeria Jupyter labs
into some new labs based on pyegeria. Please treat the contents accordingly.