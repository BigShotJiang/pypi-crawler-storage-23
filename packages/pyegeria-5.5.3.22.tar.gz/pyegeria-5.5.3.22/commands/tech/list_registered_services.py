#!/usr/bin/env python3
"""
SPDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.

A simple widget to retrieve the registered services.

"""

import argparse
import os
import sys
import time

from rich import box
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from pyegeria import (
    RegisteredInfo,
    PyegeriaException,
    print_basic_exception,
    settings,
    config_logging
)
EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")

app_config = settings.Environment
config_logging()
console = Console(width = app_config.console_width)
def display_registered_svcs(
    service: str,
    server: str,
    url: str,
    username: str,
    password: str,
    jupyter: bool = app_config.egeria_jupyter,
    width: int = app_config.console_width,
):
    """Display the registered services list
    Parameters
    ----------
    service : str, optional
        The type of service to display information for. Default is "help".

    server : str, optional
        The server to connect to. Default is `default_server`.

    url : str, optional
        The platform URL. Default is `default_platform`.

    username : str, optional
        The username for authentication. Default is `default_user`.

    password : str, optional
        The password for authentication. Default is `default_password`.
    """

    def generate_table(svc_list) -> Table:
        """Make a new table."""
        table = Table(
            title=f"Services for: {url} @ {time.asctime()}",
            style="bold bright_white on black",
            row_styles=["bold bright_white on black"],
            header_style="white on dark_blue",
            title_style="bold white on black",
            caption_style="white on black",
            show_lines=True,
            box=box.ROUNDED,
            caption=f"Registered Services from Server '{server}' @ Platform - {url}",
            expand=True,
        )
        table.add_column("Service Name")
        table.add_column("Service Type")
        table.add_column("Service  Development Status")
        table.add_column("URL Marker")
        table.add_column("Description")
        table.add_column("Wiki", no_wrap=True)
        table.add_column("Conformance Profile")

        if type(svc_list) is list:
            for svc in svc_list:
                svc_name = svc.get("Service Name", "---")
                svc_type = svc.get("Service Type","---")
                svc_dev_status = svc.get("serviceDevelopmentStatus", "---")
                svc_url_marker = svc.get("Url Marker", "---")
                svc_description = svc.get("Description", "---")
                svc_wiki = svc.get("Wiki", "---")
                svc_conf = svc.get("Conformance Profile","---")

                table.add_row(
                    svc_name,
                    svc_type,
                    svc_dev_status,
                    svc_url_marker,
                    svc_description,
                    svc_wiki,
                    svc_conf,
                )
            return table
        elif type(svc_list) is str:
            help = """
            The kinds of services that you can get more information include:
                all.....................lists all registered services
                access-services.........lists all registered access services
                common-services.........lists all registered common services
                engine-services.........lists all registered engine services
                governance-services.....lists all registered governance services
                integration-services....lists all registered integration services
                view-services...........lists all registered view services
                
                Pass in a parameter from the left-hand column into the function to 
                get more details on the specified service category.
            """
            console.print(help)

        else:
            print("Unknown service type")
            sys.exit(1)

    console = Console(width=width, force_terminal=not jupyter)
    try:
        a_client = RegisteredInfo(server, url, username)
        token = a_client.create_egeria_bearer_token(username, password)
        svc_list = a_client.list_registered_svcs(service)

        with console.pager(styles=True):
            console.print(generate_table(svc_list))

    except (
        PyegeriaException
    ) as e:
        print_basic_exception(e)
    finally:
        a_client.close_session()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", help="Name of the server to display status for")
    parser.add_argument("--url", help="URL Platform to connect to")
    parser.add_argument("--userid", help="User Id")
    parser.add_argument("--password", help="Password")

    args = parser.parse_args()

    server = args.server if args.server is not None else app_config.egeria_metadata_store
    url = args.url if args.url is not None else app_config.egeria_platform_url
    userid = args.userid if args.userid is not None else EGERIA_USER
    password = args.password if args.password is not None else EGERIA_USER_PASSWORD

    try:
        svc_kind = Prompt.ask(
            "Enter the service type you are searching for:", default="all"
        )
        display_registered_svcs(svc_kind, server, url, userid, password=password)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
