"""Protocol handling for server communication."""
