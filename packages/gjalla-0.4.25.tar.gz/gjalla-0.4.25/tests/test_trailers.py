import importlib

import pytest


settings = importlib.import_module("gjalla_precommit.config.settings")


def test_trailer_vs_notes_config(home_dir):
    config = {"receipt_method": "trailer"}
    settings.save_config(config)
    loaded = settings.load_config()
    assert settings.get_receipt_method(loaded) == "trailer"


def test_notes_is_default(home_dir):
    settings.save_config({"api_key": "gj_live_test"})
    loaded = settings.load_config()
    assert settings.get_receipt_method(loaded) == "notes"
