from metameq.scripts.generate_review_workbook import main

main()
