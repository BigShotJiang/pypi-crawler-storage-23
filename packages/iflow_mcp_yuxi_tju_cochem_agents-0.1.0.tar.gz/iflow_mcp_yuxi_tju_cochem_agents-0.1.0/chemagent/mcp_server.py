#!/usr/bin/env python3
"""
ChemAgent MCP Server
Provides MCP interface to chemistry tools and databases
"""

import asyncio
import sys
import json
import logging
from typing import Any, Dict, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ChemAgentMCPServer:
    """
    ChemAgent MCP Server
    Provides chemistry tools via MCP protocol
    """

    def __init__(self):
        self.name = "chemagent-mcp"
        self.version = "0.1.0"
        self.capabilities = {
            "tools": {}
        }

    async def handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request"""
        return {
            "protocolVersion": "2024-11-05",
            "serverInfo": {
                "name": self.name,
                "version": self.version
            },
            "capabilities": self.capabilities,
            "sessionId": f"{self.name}-session"
        }

    async def handle_list_tools(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """List available tools"""
        tools = [
            {
                "name": "search_compound",
                "description": "Search for compounds in PubChem database",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query (name, SMILES, InChI, or formula)"
                        },
                        "search_type": {
                            "type": "string",
                            "enum": ["name", "smiles", "inchi", "formula"],
                            "default": "name",
                            "description": "Type of search"
                        },
                        "max_results": {
                            "type": "integer",
                            "default": 5,
                            "description": "Maximum number of results"
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "get_properties",
                "description": "Get properties for a compound by CID",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "cid": {
                            "type": "integer",
                            "description": "PubChem Compound ID"
                        },
                        "properties": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of properties to retrieve"
                        }
                    },
                    "required": ["cid"]
                }
            },
            {
                "name": "calculate_molecular_weight",
                "description": "Calculate molecular weight from SMILES",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "smiles": {
                            "type": "string",
                            "description": "SMILES string"
                        }
                    },
                    "required": ["smiles"]
                }
            },
            {
                "name": "check_lipinski",
                "description": "Check if a molecule passes Lipinski's Rule of Five",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "smiles": {
                            "type": "string",
                            "description": "SMILES string"
                        }
                    },
                    "required": ["smiles"]
                }
            }
        ]
        return {"tools": tools}

    async def handle_tool_call(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Execute a tool with the given arguments"""
        try:
            if tool_name == "search_compound":
                return await self._search_compound(**arguments)
            elif tool_name == "get_properties":
                return await self._get_properties(**arguments)
            elif tool_name == "calculate_molecular_weight":
                return await self._calculate_molecular_weight(**arguments)
            elif tool_name == "check_lipinski":
                return await self._check_lipinski(**arguments)
            else:
                raise ValueError(f"Unknown tool: {tool_name}")
        except Exception as e:
            logger.error(f"Error executing tool {tool_name}: {e}")
            raise

    async def _search_compound(self, query: str, search_type: str = "name", max_results: int = 5) -> Dict[str, Any]:
        """Search for compounds in PubChem"""
        try:
            import pubchempy as pcp

            if search_type == "name":
                results = pcp.get_compounds(query, 'name', listsize='max')
            elif search_type == "smiles":
                results = pcp.get_compounds(query, 'smiles')
            elif search_type == "inchi":
                results = pcp.get_compounds(query, 'inchi')
            elif search_type == "formula":
                results = pcp.get_compounds(query, 'formula')
            else:
                results = []

            compounds = []
            for compound in results[:max_results]:
                compounds.append({
                    "cid": compound.cid,
                    "name": compound.iupac_name if hasattr(compound, 'iupac_name') else query,
                    "smiles": compound.isomeric_smiles if hasattr(compound, 'isomeric_smiles') else "",
                    "molecular_formula": compound.molecular_formula if hasattr(compound, 'molecular_formula') else "",
                    "molecular_weight": compound.molecular_weight if hasattr(compound, 'molecular_weight') else 0
                })

            return {
                "success": True,
                "compounds": compounds,
                "count": len(compounds)
            }
        except Exception as e:
            logger.error(f"Error searching compounds: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _get_properties(self, cid: int, properties: Optional[List[str]] = None) -> Dict[str, Any]:
        """Get properties for a compound by CID"""
        try:
            import pubchempy as pcp

            compound = pcp.Compound.from_cid(cid)

            result = {
                "cid": cid,
                "success": True
            }

            if properties is None:
                properties = ["molecular_weight", "molecular_formula", "isomeric_smiles", "iupac_name"]

            for prop in properties:
                if hasattr(compound, prop):
                    result[prop] = getattr(compound, prop)
                else:
                    result[prop] = None

            return result
        except Exception as e:
            logger.error(f"Error getting properties: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _calculate_molecular_weight(self, smiles: str) -> Dict[str, Any]:
        """Calculate molecular weight from SMILES"""
        try:
            from rdkit import Chem
            from rdkit.Chem import Descriptors

            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                return {
                    "success": False,
                    "error": "Invalid SMILES string"
                }

            mw = Descriptors.MolWt(mol)

            return {
                "success": True,
                "smiles": smiles,
                "molecular_weight": mw
            }
        except Exception as e:
            logger.error(f"Error calculating molecular weight: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _check_lipinski(self, smiles: str) -> Dict[str, Any]:
        """Check if a molecule passes Lipinski's Rule of Five"""
        try:
            from rdkit import Chem
            from rdkit.Chem import Descriptors, Lipinski

            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                return {
                    "success": False,
                    "error": "Invalid SMILES string"
                }

            mw = Descriptors.MolWt(mol)
            logp = Descriptors.MolLogP(mol)
            hbd = Lipinski.NumHDonors(mol)
            hba = Lipinski.NumHAcceptors(mol)

            # Lipinski's Rule of Five
            passes = (
                mw <= 500 and
                logp <= 5 and
                hbd <= 5 and
                hba <= 10
            )

            return {
                "success": True,
                "smiles": smiles,
                "molecular_weight": mw,
                "logp": logp,
                "h_bond_donors": hbd,
                "h_bond_acceptors": hba,
                "passes_lipinski": passes,
                "violations": sum([
                    mw > 500,
                    logp > 5,
                    hbd > 5,
                    hba > 10
                ])
            }
        except Exception as e:
            logger.error(f"Error checking Lipinski: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    async def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single MCP request"""
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")

        try:
            if method == "initialize":
                result = await self.handle_initialize(params)
            elif method == "tools/list":
                result = await self.handle_list_tools(params)
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                result = await self.handle_tool_call(tool_name, arguments)
            else:
                return {
                    "jsonrpc": "2.0",
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {method}"
                    },
                    "id": request_id
                }

            return {
                "jsonrpc": "2.0",
                "result": result,
                "id": request_id
            }
        except Exception as e:
            logger.error(f"Error processing request: {e}")
            return {
                "jsonrpc": "2.0",
                "error": {
                    "code": -32603,
                    "message": str(e)
                },
                "id": request_id
            }

    async def run_stdio(self):
        """Run server using stdin/stdout (standard MCP mode)"""
        logger.info(f"Starting {self.name} MCP Server v{self.version} (stdio mode)")

        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        await asyncio.get_event_loop().connect_read_pipe(
            lambda: protocol, sys.stdin
        )

        while True:
            try:
                # Read line from stdin
                line = await reader.readline()
                if not line:
                    break

                message = line.decode().strip()
                if not message:
                    continue

                # Process message
                response = await self.process_request(json.loads(message))

                # Write response to stdout
                print(json.dumps(response))
                sys.stdout.flush()

            except KeyboardInterrupt:
                logger.info("Server shutting down...")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")


async def main():
    """Start the ChemAgent MCP Server"""
    server = ChemAgentMCPServer()
    await server.run_stdio()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown complete")
        sys.exit(0)