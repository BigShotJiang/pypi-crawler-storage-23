# Archive Old Backups

**Phase:** 5  
**Purpose:** Keep last 3  

---

## Objective

Keep last 3 for the upgrade workflow.

---

## Steps

### Step 1: Execute Task

Complete the archive old backups step.

[Detailed steps from original phase file]

---

## Completion Criteria

🛑 VALIDATE-GATE: Task Complete

- [ ] Task executed successfully ✅/❌
- [ ] Evidence collected ✅/❌

---

## Next Step

🎯 NEXT-MANDATORY: [../phase.md](../phase.md) (return to phase)
