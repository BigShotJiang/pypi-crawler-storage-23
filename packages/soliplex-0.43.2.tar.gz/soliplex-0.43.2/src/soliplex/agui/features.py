"""Features defined by soliplex"""

from haiku.rag.agents.chat import state as hr_chat_state

HAIKU_CHAT_FEATURE = hr_chat_state.AGUI_STATE_KEY
