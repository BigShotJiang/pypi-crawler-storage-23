#!/usr/bin/env python3

import os, distro

UBUNTU_VERSION = int(float(distro.version())*100.0)

os.system("sudo update-alternatives --install /usr/bin/python python /usr/bin/python3 1")

deplist = []

deplist =  ["gcc-8","g++-8","python-dev"]
deplist =  ["clang-11"] # not avail in ub22

deplist += ["libboost-dev","clang","clang-format"]
deplist += ["libboost-filesystem-dev","libboost-system-dev","libboost-thread-dev"]
deplist += ["libboost-program-options-dev","libftdi-dev"]
deplist += ["libglfw3-dev","libflac++-dev","scons","git"]
deplist += ["rapidjson-dev","graphviz","doxygen","libtiff-dev"]
deplist += ["portaudio19-dev", "pybind11-dev"]
deplist += ["libpng-dev"]
deplist += ["libjemalloc-dev"]
deplist += ["iverilog"]
deplist += ["libopenblas-dev"]
deplist += ["librtmidi-dev"]
deplist += ["texinfo","xmlto"]
deplist += ["libgtkmm-3.0-dev"]
deplist += ["libfltk1.3-dev","freeglut3-dev"]
deplist += ["libfontconfig1-dev"]
deplist += ["libfreetype6-dev"]
deplist += ["libx11-dev"]
deplist += ["libxext-dev"]
deplist += ["libxfixes-dev"]
deplist += ["libxi-dev"]
deplist += ["libxrender-dev"]
deplist += ["libx11-xcb-dev"]
deplist += ["libavformat-dev"]
deplist += ["libavcodec-dev"]
deplist += ["libswscale-dev"]
deplist += ["libssl-dev"]
deplist += ["wget","git","git-lfs", "vim","cmake","python3-pip", "nasm"]
deplist += ["m4","bison","flex"]
deplist += ["libcurl4-openssl-dev","libusb-1.0-0-dev", "libbz2-dev"]
deplist += ["libreadline-dev"]
deplist += ["libsqlite3-dev"]
deplist += ["libtbb-dev"]
deplist += ["openctm-tools"] # ctmviewer
deplist += ["openscad"] # for trimesh
deplist += ["libclang-dev"]
deplist += ["libgmp-dev","libmpfr-dev","texinfo","libmpc-dev"]
deplist += ["libx11-dev"]
deplist += ["libx11-xcb-dev"]
deplist += ["libxext-dev"]
deplist += ["libxfixes-dev"]
deplist += ["libxi-dev"]
deplist += ["libxrender-dev"]
deplist += ["libxcb1-dev"]
deplist += ["libxcb-glx0-dev"]
deplist += ["libxcb-keysyms1-dev"]
deplist += ["libxcb-image0-dev"]
deplist += ["libxcb-shm0-dev"]
deplist += ["libxcb-icccm4-dev"]
deplist += ["libxcb-sync-dev"]
deplist += ["libxcb-xfixes0-dev"]
deplist += ["libxcb-shape0-dev"]
deplist += ["libxcb-randr0-dev"]
deplist += ["libxcb-render-util0-dev"]
deplist += ["libxcb-xinerama0-dev"]
deplist += ["libxkbcommon-dev"]
deplist += ["libxkbcommon-x11-dev"]
deplist += ["libxcb-xkb-dev"]
deplist += ["libxcb-cursor-dev"]
deplist += ["libmad0-dev","libsdl2-dev","libassimp-dev"]
deplist += ["device-tree-compiler"]
deplist += ["imagemagick","curl","tk-dev"]
deplist += ["libgeos-dev","libpng-dev","libspatialindex-dev"]
deplist += ["qt5-style-plugins","qt5ct","python3-gdal","python3-pyqt5","python3-pyqt5.qtopengl"]
deplist += ["python3-simplejson","python3-tk"]

deplist += ["libdrm-dev","libaudiofile-dev","libsndfile1-dev"]
deplist += ["libglew-dev", "libopencv-dev"]

merged = " ".join(deplist)
os.system("sudo apt -y install %s" % merged)

os.system("pip3 install os_release")
