# Changelog

All notable changes to taxomesh will be documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Planned for v0.1.0
- Core domain models: `Item`, `Category`, `Tag`, `CategoryParentLink`
- Abstract repository interface: `TaxomeshRepository`
- Built-in backends: JSON, YAML, SQLite3
- Cycle detection for category hierarchies
- Basic SDK: `TaxomeshSDK`
