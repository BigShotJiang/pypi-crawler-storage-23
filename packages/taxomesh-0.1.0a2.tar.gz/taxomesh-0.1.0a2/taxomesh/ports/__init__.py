"""taxomesh.ports — Storage interface definitions (Protocols)."""
