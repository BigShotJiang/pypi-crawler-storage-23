default_app_config = "hidp_wagtail.apps.HidpWagtailConfig"
