## [0.4.7](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.6...v0.4.7) (2026-02-21)


### Bug Fixes

* add laps readers to table and adjust maq text ([4572632](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/457263232199c1e7fd1c94986b6600fa128438fc))

## [0.4.6](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.5...v0.4.6) (2026-02-21)


### Bug Fixes

* hide non-issue tiles and add maq finding ([e7bfff7](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/e7bfff77ea57bf3eb88718189eb94123a25fc346))

## [0.4.5](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.4...v0.4.5) (2026-02-21)


### Bug Fixes

* counter for security findings in navigation ([f762720](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/f762720bb1d8d1bd63e69aab2b4c71c43b22e64b))

## [0.4.4](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.3...v0.4.4) (2026-02-21)


### Bug Fixes

* show detected cleartext pws in description/info fields ([bcdfc22](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/bcdfc223e00bd696b3145c1c146967eb48ebb629))

## [0.4.3](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.2...v0.4.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([93d9e4b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/93d9e4b36c6fb417549e805788db60099735fb09))

