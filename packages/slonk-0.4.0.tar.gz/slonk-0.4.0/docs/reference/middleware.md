# Middleware

Base middleware class and event dispatch infrastructure.

::: slonk.middleware
    options:
      members:
        - Middleware
        - _EventDispatcher
        - _Event
        - _EventType
