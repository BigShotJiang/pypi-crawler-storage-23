# Pipeline

The core pipeline orchestrator.

::: slonk.pipeline
    options:
      members:
        - Slonk
        - TeeHandler
        - tee
        - _compute_roles
