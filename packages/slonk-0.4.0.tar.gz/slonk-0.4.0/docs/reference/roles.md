# Roles & Protocols

Role definitions and protocol contracts for pipeline stages.

::: slonk.roles
    options:
      members:
        - _Role
        - Source
        - Transform
        - Sink
        - StageType
