from typing import Any

from marshmallow import missing

MISSING: Any = missing
