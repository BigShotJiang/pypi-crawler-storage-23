import sys
from importlib.metadata import version as _get_version

from .bake import bake_schema, get_field_for
from .fields import (
    DateField,
    DateTimeField,
    DecimalField,
    DictField,
    EnumField,
    FloatField,
    FrozenSetField,
    JsonRawField,
    NestedField,
    SetField,
    StrField,
    TupleField,
    UnionField,
)
from .hooks import add_pre_load, pre_load
from .json_schema import json_schema
from .metadata import (
    EMPTY_METADATA,
    Metadata,
    datetime_meta,
    datetime_metadata,
    decimal_meta,
    decimal_metadata,
    frozenset_meta,
    frozenset_metadata,
    is_metadata,
    list_meta,
    list_metadata,
    meta,
    metadata,
    sequence_meta,
    sequence_metadata,
    set_meta,
    set_metadata,
    str_meta,
    str_metadata,
    time_metadata,
    tuple_meta,
    tuple_metadata,
)
from .missing import MISSING
from .naming_case import (
    CAMEL_CASE,
    CAPITAL_CAMEL_CASE,
    UPPER_SNAKE_CASE,
    CamelCase,
    CapitalCamelCase,
    NamingCase,
    UpperSnakeCase,
)
from .options import NoneValueHandling, options
from .serialization import Dataclass, EmptySchema, dump, dump_many, load, load_many, schema
from .validation import (
    ValidationError,
    ValidationFieldError,
    ValidationFunc,
    email_validate,
    get_validation_field_errors,
    regexp_validate,
    validate,
)

__all__: tuple[str, ...] = (
    "CAMEL_CASE",
    "CAPITAL_CAMEL_CASE",
    "EMPTY_METADATA",
    "MISSING",
    "UPPER_SNAKE_CASE",
    "CamelCase",
    "CapitalCamelCase",
    "Dataclass",
    "DateField",
    "DateTimeField",
    "DecimalField",
    "DictField",
    "EmptySchema",
    "EnumField",
    "FloatField",
    "FrozenSetField",
    "JsonRawField",
    "Metadata",
    "NamingCase",
    "NestedField",
    "NoneValueHandling",
    "SetField",
    "StrField",
    "TupleField",
    "UnionField",
    "UpperSnakeCase",
    "ValidationError",
    "ValidationFieldError",
    "ValidationFunc",
    "add_pre_load",
    "bake_schema",
    "datetime_meta",
    "datetime_metadata",
    "decimal_meta",
    "decimal_metadata",
    "dump",
    "dump_many",
    "email_validate",
    "frozenset_meta",
    "frozenset_metadata",
    "get_field_for",
    "get_validation_field_errors",
    "is_metadata",
    "json_schema",
    "list_meta",
    "list_metadata",
    "load",
    "load_many",
    "meta",
    "metadata",
    "options",
    "pre_load",
    "regexp_validate",
    "schema",
    "sequence_meta",
    "sequence_metadata",
    "set_meta",
    "set_metadata",
    "str_meta",
    "str_metadata",
    "time_metadata",
    "tuple_meta",
    "tuple_metadata",
    "validate",
)

__version__ = _get_version("marshmallow-recipe")

version = f"{__version__}, Python {sys.version}"

from marshmallow_recipe import nuked  # noqa: E402

__all__ = (*__all__, "nuked")  # pyright: ignore[reportUnsupportedDunderAll]
