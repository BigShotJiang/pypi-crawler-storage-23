import os
from setuptools import setup

try:
    from torch.utils.cpp_extension import CUDAExtension, BuildExtension

    _here = os.path.dirname(os.path.abspath(__file__))
    submod_rel = os.path.join("submodules", "diff-gaussian-rasterization-orth")
    glm_include = os.path.join(_here, submod_rel, "third_party", "glm")

    ext_modules = [
        CUDAExtension(
            name="diff_gaussian_rasterization_kiui_orth._C",
            sources=[
                os.path.join(submod_rel, "cuda_rasterizer", "rasterizer_impl.cu"),
                os.path.join(submod_rel, "cuda_rasterizer", "forward.cu"),
                os.path.join(submod_rel, "cuda_rasterizer", "backward.cu"),
                os.path.join(submod_rel, "rasterize_points.cu"),
                os.path.join(submod_rel, "ext.cpp"),
            ],
            extra_compile_args={
                "nvcc": ["-I" + glm_include],
            },
        )
    ]
    cmdclass = {"build_ext": BuildExtension}
except (ImportError, OSError):
    # No CUDA when building the sdist — sources are included via MANIFEST.in
    # and compiled on the target machine during `pip install`.
    ext_modules = []
    cmdclass = {}

setup(ext_modules=ext_modules, cmdclass=cmdclass)
