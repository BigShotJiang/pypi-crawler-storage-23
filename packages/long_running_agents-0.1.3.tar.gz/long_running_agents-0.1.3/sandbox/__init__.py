"""Sandbox package for isolated code execution."""
