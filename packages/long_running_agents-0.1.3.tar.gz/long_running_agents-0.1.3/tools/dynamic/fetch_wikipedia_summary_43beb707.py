def fetch_wikipedia_summary(topic: str):
    """Fetch summary information for a given topic from Wikipedia using the Wikipedia API."""
    import requests
    
    WIKIPEDIA_API_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/"
    
    def fetch_wikipedia_summary(topic: str) -> dict:
        """
        Fetch the summary of a given topic from Wikipedia.
        :param topic: The topic to search for on Wikipedia.
        :return: A dictionary containing the summary or an error message.
        """
        response = requests.get(WIKIPEDIA_API_URL + topic)
        if response.status_code == 200:
            return response.json()
        else:
            return {'error': response.status_code, 'message': response.reason}
