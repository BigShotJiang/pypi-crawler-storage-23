def fetch_weather(city_name: str, api_key: str):
    """Fetch weather data for a given city using OpenWeatherMap API. Requires city name and API key."""
    import requests
    
    def fetch_weather(city_name: str, api_key: str):
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}&units=metric"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()  # Return full JSON response
        else:
            return {'error': response.status_code, 'message': response.reason}
