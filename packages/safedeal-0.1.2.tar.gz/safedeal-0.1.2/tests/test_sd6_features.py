import copy

from safedeal.escrow.evm_escrow_v1.backend import EvmEscrowV1Adapter
from safedeal.models import Identity
from safedeal.sdk import SafeDealSDK


def _mk_offer(now: int, arbitration_enabled: bool = True):
    return {
        "seller": Identity(pk="seller_pk", sig_scheme="ed25519"),
        "buyer": Identity(pk="buyer_pk", sig_scheme="ed25519"),
        "asset": {"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        "escrow": {"backend": "EVM_ESCROW_V1", "mode": "FULL", "buffer_rate_ppm": 0, "params": {}},
        "terms": {
            "deliverable_type": "HASH_MATCH",
            "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}],
            "deadlines": {"fund_by": now + 100, "deliver_by": now + 200, "accept_by": now + 300, "dispute_by": now + 400},
        },
        "arbitration": {"enabled": arbitration_enabled, "arb_policy_id": "arb-v1.7", "arb_public_keys": ["arb1"] if arbitration_enabled else [], "quorum": 1 if arbitration_enabled else 0},
        "economics": {"escrow_creation_fee": {"currency": "USDC", "amount": "0.00"}},
    }


def test_stateless_api_and_objective_only_mode():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)

    payload = {
        "quote_hash": "0xquote",
        "buyer_id": {"pk": "buyer_pk", "sig_scheme": "ed25519"},
        "seller_id": {"pk": "seller_pk", "sig_scheme": "ed25519"},
        "asset": {"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        "escrow": {"backend": "EVM_ESCROW_V1", "mode": "FULL", "buffer_rate_ppm": 0},
        "terms": {"deliverable_type": "HASH_MATCH", "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}]},
        "arbitration": {"enabled": False, "arb_public_keys": [], "quorum": 0},
        "economics": {"protocol_fee_ppm": 1000, "protocol_fee_min": 1},
    }
    bind = sdk.build_bind(payload)
    settlement_hash = sdk.compute_settlement_template(bind)
    intent = sdk.compute_release_intent(bind, {"to_seller": 999_000_000, "to_buyer": 0, "fee_to_sink": 1_000_000})

    assert bind["deal_id"].startswith("0x")
    assert settlement_hash == bind["settlement_template_hash"]
    assert sdk.verify_release(bind, intent, 1_000_000_000)

    handle = sdk.create_deal(
        seller=Identity(pk="seller_pk", sig_scheme="ed25519"),
        buyer=Identity(pk="buyer_pk", sig_scheme="ed25519"),
        amount="1000.00",
        deliverable_hash="0xabc",
        objective_only=True,
    )
    assert handle.offer.arbitration["enabled"] is False


def test_adversarial_rejections():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)
    offer = sdk.make_offer(signing_key_hint="seller_pk", **_mk_offer(now))
    accept = sdk.accept_offer(offer, expected_hashes={"M1": "0xabc"}, signing_key_hint="buyer_pk")
    state = sdk.escrow_prepare(offer, accept)
    sdk.escrow_fund(state)

    fee = sdk.escrow.compute_protocol_fee(state.amount_base_units)
    gas = sdk.escrow.gas_cost_base_units
    tx = sdk.escrow.build_settlement_tx(
        offer.deal_id,
        payout={"to_seller": state.amount_base_units - fee - gas, "to_buyer": 0, "fee_to_sink": fee},
        method="releaseByMutual",
        settlement_template_hash=state.settlement_template_hash,
        expiry=now + 100,
    )

    bad_template = copy.deepcopy(tx)
    bad_template["settlement_template_hash"] = "0xdeadbeef"
    try:
        sdk.escrow.broadcast_settlement_tx(bad_template)
        assert False, "adversarial_template_mutation: REJECTED"
    except ValueError:
        pass

    bad_payout = copy.deepcopy(tx)
    bad_payout["payout"]["to_buyer"] = 1
    try:
        sdk.escrow.broadcast_settlement_tx(bad_payout)
        assert False, "adversarial_payout_change: REJECTED"
    except ValueError:
        pass

    sdk.escrow.broadcast_settlement_tx(tx)
    replay = copy.deepcopy(tx)
    replay["expiry"] = now + 999
    try:
        sdk.escrow.broadcast_settlement_tx(replay)
        assert False, "adversarial_replay: REJECTED"
    except ValueError:
        pass

    offer2 = sdk.make_offer(signing_key_hint="seller_pk", **_mk_offer(now + 1))
    accept2 = sdk.accept_offer(offer2, expected_hashes={"M1": "0xabc"}, signing_key_hint="buyer_pk")
    state2 = sdk.escrow_prepare(offer2, accept2)
    sdk.escrow_fund(state2)
    fee2 = sdk.escrow.compute_protocol_fee(state2.amount_base_units)
    tx2 = sdk.escrow.build_settlement_tx(
        offer2.deal_id,
        payout={"to_seller": state2.amount_base_units - fee2, "to_buyer": 0, "fee_to_sink": fee2},
        method="releaseByMutual",
        settlement_template_hash=state2.settlement_template_hash,
        expiry=now + 200,
    )
    tx2["payout"]["fee_to_sink"] = 0
    tx2["payout"]["to_seller"] = state2.amount_base_units
    try:
        sdk.escrow.broadcast_settlement_tx(tx2)
        assert False, "protocol_fee_bypass: REJECTED"
    except ValueError:
        pass
