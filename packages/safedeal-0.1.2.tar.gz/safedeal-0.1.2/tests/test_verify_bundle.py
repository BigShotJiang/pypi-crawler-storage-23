from safedeal.messages import make_bind_message, make_quote_message
from safedeal.models import Identity
from safedeal_verify.verify import compute_deal_id_from_bind_hash, verify_bundle_computed


def _sample_quote():
    seller = Identity(pk="seller_pk", sig_scheme="ed25519")
    buyer = Identity(pk="buyer_pk", sig_scheme="ed25519")
    return make_quote_message(
        seller=seller,
        buyer=buyer,
        asset={"type": "service", "uri": "ipfs://asset"},
        escrow={"amount": 100, "token": "USDC"},
        terms={"milestones": [{"id": "M1", "amount": 100}]},
        arbitration={"adapter": "none"},
        economics={"protocol_fee_ppm": 1000},
    )


def test_compute_deal_id_matches_bind_builder_logic():
    quote = _sample_quote()
    bind = make_bind_message(quote, signing_key_hint="buyer_pk", settlement_template_hash="0x" + "00" * 32)
    assert compute_deal_id_from_bind_hash(bind.bind_hash) == bind.deal_id


def test_verify_bundle_computed_matches_bind_message():
    quote = _sample_quote()
    bind = make_bind_message(quote, signing_key_hint="buyer_pk", settlement_template_hash="0x" + "00" * 32)
    bundle = {
        "computed": {"deal_id": bind.deal_id},
        "messages": [{"bind_hash": bind.bind_hash}],
    }
    assert verify_bundle_computed(bundle)


def test_verify_bundle_computed_rejects_non_hex_bind_hash():
    bundle = {
        "computed": {"deal_id": "0x" + "00" * 32},
        "messages": [{"bind_hash": "not-a-hex-hash"}],
    }
    assert verify_bundle_computed(bundle) is False
