import json

from safedeal.crypto import message_hash
from safedeal.eip712 import build_release_intent_typed_data, typed_data_hash


def test_golden_vectors_consistency():
    vectors = json.loads(open("vectors/golden_vectors.json", "r", encoding="utf-8").read())
    assert message_hash(vectors["offer"], exclude_sig=False) == vectors["expected"]["offer_hash"]
    assert message_hash(vectors["bind"], exclude_sig=False) == vectors["expected"]["bind_hash"]
    assert message_hash(vectors["delivery"], exclude_sig=False) == vectors["expected"]["delivery_hash"]
    assert message_hash(vectors["release"], exclude_sig=False) == vectors["expected"]["release_hash"]

    typed = build_release_intent_typed_data(vectors["release"], 1, "0x0000000000000000000000000000000000000001")
    assert typed_data_hash(typed) == vectors["expected"]["release_eip712_hash"]
