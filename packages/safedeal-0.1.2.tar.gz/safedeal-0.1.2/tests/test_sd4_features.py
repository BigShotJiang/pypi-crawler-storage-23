import random

import pytest

from safedeal.adapters.arb_v17.adapter import ArbV17Adapter
from safedeal.adapters.dummy_rules.adapter import DummyRulesAdapter
from safedeal.eip712 import build_release_intent_typed_data
from safedeal.escrow.evm_escrow_v1.backend import EvmEscrowV1Adapter
from safedeal.models import Identity
from safedeal.sdk import PROFILES, SafeDealSDK
from safedeal.signers import Ed25519Signer, EvmSigner
from safedeal_verify.verify import verify_bundle_computed



def _mk_offer(now: int):
    return {
        "seller": Identity(pk="seller_pk", sig_scheme="ed25519"),
        "buyer": Identity(pk="buyer_pk", sig_scheme="ed25519"),
        "asset": {"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        "escrow": {"backend": "EVM_ESCROW_V1", "mode": "FULL", "buffer_rate_ppm": 0, "params": {}},
        "terms": {
            "deliverable_type": "HASH_MATCH",
            "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}],
            "deadlines": {"fund_by": now + 100, "deliver_by": now + 200, "accept_by": now + 300, "dispute_by": now + 400},
        },
        "arbitration": {"enabled": True, "arb_policy_id": "arb-v1.7", "arb_public_keys": ["arb1"], "quorum": 1},
        "economics": {"escrow_creation_fee": {"currency": "USDC", "amount": "0.00"}},
    }


def test_profiles_and_typed_intent_and_safe_signing():
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: 1700000000)
    handle = sdk.create_deal(
        seller=Identity(pk="seller_pk", sig_scheme="ed25519"),
        buyer=Identity(pk="buyer_pk", sig_scheme="ed25519"),
        amount="1000.00",
        deliverable_hash="0xabc",
        profile="CAPITAL_EFFICIENT",
    )
    assert "CAPITAL_EFFICIENT" in PROFILES
    assert handle.offer.terms["buyer_stall_fee_sats_per_day"] > 0

    state = sdk.escrow_prepare(handle.offer, handle.accept)
    sdk.escrow_fund(state)
    delivery = sdk.deliver(handle.deal_id, "M1", "0xabc")
    settled = sdk.auto_settle_objective(delivery, expected_hash="0xabc", wait_blocks=0, current_block=0, dispute_filed=False)
    estimate = sdk.estimate_total_cost(escrow_amount=1_000_000_000, token_budget=5_000_000, queue_depth=3)
    assert settled["status"] == "released"
    assert estimate["protocol_fee"] > 0


def test_release_signer_guard_and_typed_data_shape():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)
    offer = sdk.make_offer(signing_key_hint="seller_pk", **_mk_offer(now))
    accept = sdk.accept_offer(offer, {"M1": "0xabc"}, signing_key_hint="buyer_pk")
    state = sdk.escrow_prepare(offer, accept)
    sdk.escrow_fund(state)
    dispute = sdk.open_dispute(offer.deal_id, "M1", "NON_DELIVERY", "REFUND_BUYER")
    cb = sdk.to_arb_case_bundle(dispute, evidence={})
    cb["dispute"]["escrow_amount"] = state.amount_base_units
    cb["dispute"]["fee"] = 0
    dec = sdk.call_arbitration(cb)
    tx = sdk.build_release_from_decision(offer.deal_id, dec, state.amount_base_units)

    typed = build_release_intent_typed_data(tx, chain_id=1, verifying_contract="0x0000000000000000000000000000000000000001")
    assert typed["primaryType"] == "ReleaseIntent"

    signed = sdk.sign_release_with_signer(tx, EvmSigner("kms://demo"))
    assert signed["signatures"]

    preview = sdk.preview_release_intent(tx)
    assert EvmSigner("kms://demo").sign(tx, preview).startswith("0x")

    bad_preview = dict(preview)
    bad_preview["to_buyer"] = bad_preview["to_buyer"] + 1
    with pytest.raises(ValueError, match="does not match preview"):
        Ed25519Signer("buyer_pk").sign(tx, bad_preview)


def test_arbitration_adapter_pluggability_compatibility():
    dispute = {"deal_id": "0xabc", "milestone_id": "M1", "claim_code": "QUALITY_MIXED", "escrow_amount": 1000, "fee": 0}
    cb1 = ArbV17Adapter().to_case_bundle(dispute, evidence={})
    cb2 = DummyRulesAdapter().to_case_bundle(dispute, evidence={})
    d1 = ArbV17Adapter().resolve(cb1)
    d2 = DummyRulesAdapter().resolve(cb2)

    assert set(d1.award["amounts"].keys()) == set(d2.award["amounts"].keys())


def test_bundle_mutation_and_fuzz_invariants():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)
    quote = sdk.make_quote(**_mk_offer(now))
    qbf = sdk.quote_bind_fund(quote, buyer_signing_key_hint="buyer_pk")
    did = qbf["deal_id"]
    bundle = sdk.export_deal_bundle(did)
    assert verify_bundle_computed(bundle)

    bad = dict(bundle)
    bad["computed"] = dict(bundle["computed"])
    bad["computed"]["deal_id"] = "0xdeadbeef"
    assert not verify_bundle_computed(bad)

    rng = random.Random(7)
    for _ in range(100):
        a = rng.randint(1, 10_000_000)
        seller_bps = rng.randint(0, 10_000)
        payout = sdk.canonical_payout_split(a, seller_bps=seller_bps, buyer_bps=10_000 - seller_bps)
        assert payout.total() == a
