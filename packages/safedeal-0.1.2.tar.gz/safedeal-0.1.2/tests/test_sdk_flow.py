import json

import pytest

from safedeal.crypto import canonical_json, message_hash
from safedeal.escrow.evm_escrow_v1.backend import EvmEscrowV1Adapter
from safedeal.models import Identity
from safedeal.sdk import DealState, SafeDealSDK


def _base_offer_kwargs(now: int):
    seller = Identity(pk="seller_pk", sig_scheme="ed25519")
    buyer = Identity(pk="buyer_pk", sig_scheme="ed25519")
    return {
        "seller": seller,
        "buyer": buyer,
        "asset": {"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        "escrow": {"backend": "EVM_ESCROW_V1", "mode": "FULL", "buffer_rate_ppm": 0, "params": {}},
        "terms": {
            "deliverable_type": "HASH_MATCH",
            "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}],
            "buyer_stall_fee_sats_per_day": 3000,
            "seller_stall_fee_sats_per_day": 4000,
            "max_stall_fee_cap": 10000,
            "deadlines": {
                "fund_by": now + 100,
                "deliver_by": now + 200,
                "accept_by": now + 300,
                "dispute_by": now + 400,
            },
        },
        "arbitration": {"enabled": True, "arb_policy_id": "arb-v1.7", "arb_public_keys": ["arb1"], "quorum": 1},
        "economics": {"escrow_creation_fee": {"currency": "USDC", "amount": "0.50"}},
    }


def test_canonical_hash_roundtrip_bit_for_bit():
    payload = {"a": {"y": [1, "z"], "x": "v"}, "b": 2, "canonical_spec_version": 1}
    serialized = canonical_json(payload)
    first_hash = message_hash(payload)

    reserialized_payload = json.loads(serialized)
    reserialized = canonical_json(reserialized_payload)
    second_hash = message_hash(reserialized_payload)

    assert serialized == reserialized
    assert first_hash == second_hash


def test_float_rejected_by_canonicalization():
    with pytest.raises(ValueError, match="Float values are not allowed"):
        canonical_json({"bad": 1.5})


def test_adoption_bar_end_to_end():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)

    quote = sdk.make_quote(
        seller=Identity(pk="seller_pk", sig_scheme="ed25519"),
        buyer=Identity(pk="buyer_pk", sig_scheme="ed25519"),
        asset={"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        escrow={"backend": "EVM_ESCROW_V1", "mode": "STREAM_WITH_BUFFER", "buffer_rate_ppm": 150000},
        terms={
            "deliverable_type": "HASH_MATCH",
            "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}],
            "buyer_stall_fee_sats_per_day": 3000,
            "seller_stall_fee_sats_per_day": 4000,
            "max_stall_fee_cap": 10000,
            "deadlines": {"fund_by": now + 100, "deliver_by": now + 200, "accept_by": now + 300, "dispute_by": now + 400},
        },
        arbitration={"enabled": True, "arb_policy_id": "arb-v1.7", "arb_public_keys": ["arb1"], "quorum": 1},
        economics={"escrow_creation_fee": {"currency": "USDC", "amount": "0.10"}},
    )
    qbf = sdk.quote_bind_fund(quote, buyer_signing_key_hint="buyer_pk")
    deal_id = qbf["deal_id"]

    unlocked = sdk.unlock_streamed_amount(deal_id, 850_000_000)
    withdrawn = sdk.withdraw_streamed(deal_id, 800_000_000)

    delivery = sdk.deliver(
        deal_id,
        "M1",
        "0xabc",
        observed_block=100,
        channels=[{"uri": "ipfs://bafy-demo", "hash": "0xabc"}],
        availability_proof={"type": "http_head", "content_length": 64, "hash_preimage_commitment": "0xpre"},
    )
    settled = sdk.auto_settle_objective(delivery, expected_hash="0xabc", wait_blocks=5, current_block=106, dispute_filed=False)

    payout = sdk.canonical_payout(1_000_000_000, winner="buyer", fee=0)
    penalized = sdk.apply_stall_penalty(deal_id, payout, stalled_party="buyer", elapsed_days=2)
    split = sdk.canonical_payout_split(1_000_000_000, seller_bps=7000, buyer_bps=3000)

    bundle = sdk.export_deal_bundle(deal_id)
    imported = sdk.import_deal_bundle(bundle)

    tx = sdk.escrow.build_settlement_tx(
        deal_id,
        payout={"to_seller": 849_000_000, "to_buyer": 150_000_000, "fee_to_sink": 1_000_000},
        method="releaseByMutual",
        settlement_template_hash=qbf["bind"]["settlement_template_hash"],
        expiry=now + 3600,
    )
    sdk.escrow.broadcast_settlement_tx(tx)
    with pytest.raises(ValueError, match="Replay detected"):
        sdk.escrow.broadcast_settlement_tx(tx)

    assert qbf["bind_hash"].startswith("0x")
    assert unlocked["unlocked_base_units"] == 850_000_000
    assert withdrawn["withdrawn_base_units"] == 800_000_000
    assert settled["status"] == "released"
    assert penalized.to_seller == 6000
    assert split.to_buyer == 300_000_000
    assert imported == deal_id


def test_partial_arbitration_and_substitution_and_backend_recommendation():
    now = 1700000000
    sdk = SafeDealSDK(escrow_backend=EvmEscrowV1Adapter(), now_fn=lambda: now)
    offer = sdk.make_offer(signing_key_hint="seller_pk", **_base_offer_kwargs(now))
    accept = sdk.accept_offer(offer, expected_hashes={"M1": "0xabc"}, signing_key_hint="buyer_pk")
    state = sdk.escrow_prepare(offer, accept)
    sdk.escrow_fund(state)

    dispute = sdk.open_dispute(offer.deal_id, "M1", "QUALITY_MIXED", "SPLIT:7000")
    case_bundle = sdk.to_arb_case_bundle(dispute, evidence={"proof": "0x1"})
    case_bundle["dispute"]["escrow_amount"] = state.amount_base_units
    case_bundle["dispute"]["fee"] = 0
    decision = sdk.call_arbitration(case_bundle)

    tx = sdk.build_release_from_decision(offer.deal_id, decision, escrow_amount=state.amount_base_units)
    tx = sdk.sign_release(tx, signer=Identity(pk="arb1", sig_scheme="ed25519"))
    out = sdk.broadcast_release(tx)

    replaced = sdk.replace_counterparty(offer.deal_id, "seller", Identity(pk="seller_pk_2", sig_scheme="ed25519"), authorized=True)
    rec = sdk.recommend_backend(asset="USDC", amount="1000.00", urgency="high", trust="low")

    assert decision.award["amounts"]["to_seller"] == 700_000_000
    assert decision.award["amounts"]["to_buyer"] == 300_000_000
    assert tx["payout"]["fee_to_sink"] == 1_000_000
    assert out["status"] == "released"
    assert replaced["new_pk"] == "seller_pk_2"
    assert rec["backend_id"].startswith("EVM_ESCROW")
    assert sdk._state[offer.deal_id] == DealState.SETTLED
