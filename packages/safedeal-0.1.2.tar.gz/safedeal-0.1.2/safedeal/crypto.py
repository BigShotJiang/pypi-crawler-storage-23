from __future__ import annotations

import hashlib
import json
import math
from copy import deepcopy
from typing import Any, Mapping


SUPPORTED_SIG_SCHEMES = {"ed25519", "secp256k1", "eip712", "eip191"}
CANONICAL_SPEC_VERSION = 1


def _assert_no_floats(value: Any, path: str = "$") -> None:
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise ValueError(f"Non-finite float is not allowed at {path}")
        raise ValueError(f"Float values are not allowed in canonical payloads ({path})")
    if isinstance(value, dict):
        for key, child in value.items():
            _assert_no_floats(child, f"{path}.{key}")
    if isinstance(value, list):
        for idx, child in enumerate(value):
            _assert_no_floats(child, f"{path}[{idx}]")


def canonical_json(payload: Mapping[str, Any]) -> str:
    """Return canonical JSON: sorted keys, no whitespace, float-free."""
    _assert_no_floats(payload)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return canonical_json(payload).encode("utf-8", "strict")


def sha256_hex(text: str) -> str:
    return "0x" + hashlib.sha256(text.encode("utf-8", "strict")).hexdigest()


def message_hash(message: Mapping[str, Any], exclude_sig: bool = True) -> str:
    """Hash canonical JSON, excluding `sig` by default."""
    payload = deepcopy(dict(message))
    if exclude_sig:
        payload.pop("sig", None)
    return "0x" + hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def offer_hash(offer_message: Mapping[str, Any]) -> str:
    return message_hash(offer_message, exclude_sig=True)


def derive_deal_id(offer_hash_hex: str, buyer_pk: str, seller_pk: str) -> str:
    return sha256_hex(f"{offer_hash_hex}|{buyer_pk}|{seller_pk}")


def rolling_chain_hash(previous_hash: str | None, message: Mapping[str, Any]) -> str:
    msg_hash = message_hash(message)
    seed = previous_hash or "0x00"
    return sha256_hex(f"{seed}|{msg_hash}")


def pseudo_sign(msg_hash: str, private_key_hint: str, scheme: str) -> str:
    """Deterministic placeholder signature for SDK wiring tests.

    Real deployments should route through wallet/HSM providers.
    """
    if scheme not in SUPPORTED_SIG_SCHEMES:
        raise ValueError(f"Unsupported signature scheme: {scheme}")
    return sha256_hex(f"sig|{scheme}|{private_key_hint}|{msg_hash}")


def pseudo_verify(msg_hash: str, signature: str, public_key_hint: str, scheme: str) -> bool:
    expected = sha256_hex(f"sig|{scheme}|{public_key_hint}|{msg_hash}")
    return signature == expected
