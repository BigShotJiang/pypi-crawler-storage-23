from __future__ import annotations

from .base import assert_signer_preview_guardrails
from ..crypto import message_hash, pseudo_sign


class Ed25519Signer:
    scheme = "ed25519"

    def __init__(self, key_hint: str) -> None:
        self.key_hint = key_hint

    def sign(self, payload: dict, preview: dict) -> str:
        assert_signer_preview_guardrails(payload, preview)
        return pseudo_sign(message_hash(payload, exclude_sig=False), self.key_hint, self.scheme)
