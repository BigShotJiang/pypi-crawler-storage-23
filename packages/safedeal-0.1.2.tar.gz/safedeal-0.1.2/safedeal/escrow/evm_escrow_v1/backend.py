from __future__ import annotations

from dataclasses import dataclass, field

from ..base import EscrowState


@dataclass(slots=True)
class InMemoryDeal:
    state: EscrowState
    nonce: int = 0
    funding_tx: str | None = None
    settlement_tx: str | None = None
    arb_public_keys: set[str] = field(default_factory=set)
    arb_quorum: int = 1
    used_nonces: set[int] = field(default_factory=set)


class EvmEscrowV1Adapter:
    backend_name = "EVM_ESCROW_V1"
    stream_backend_name = "EVM_ESCROW_STREAM_V1"
    ALLOWED_METHODS = {"releaseByMutual", "releaseByArbitration"}
    ALLOWED_MODES = {"FULL", "STREAM_WITH_BUFFER"}

    def __init__(
        self,
        token_decimals: int = 6,
        escrow_contract_address: str = "0xEscrowV1",
        gas_cost_base_units: int = 0,
        protocol_fee_ppm: int = 1000,
        protocol_fee_min: int = 1,
        protocol_fee_sink: str = "0xFEE0000000000000000000000000000000000000",
    ) -> None:
        self.token_decimals = token_decimals
        self.escrow_contract_address = escrow_contract_address
        self.gas_cost_base_units = gas_cost_base_units
        self.protocol_fee_ppm = protocol_fee_ppm
        self.protocol_fee_min = protocol_fee_min
        self.protocol_fee_sink = protocol_fee_sink
        self._deals: dict[str, InMemoryDeal] = {}

    def _validate_mode(self, mode: str, buffer_rate_ppm: int) -> None:
        if mode not in self.ALLOWED_MODES:
            raise ValueError(f"Unsupported escrow mode: {mode}")
        if not 0 <= buffer_rate_ppm <= 1_000_000:
            raise ValueError("buffer_rate_ppm must be between 0 and 1_000_000")
        if mode == "FULL" and buffer_rate_ppm != 0:
            raise ValueError("FULL mode requires buffer_rate_ppm=0")

    def _compute_buffer_locked(self, amount_base_units: int, mode: str, buffer_rate_ppm: int) -> int:
        if mode != "STREAM_WITH_BUFFER":
            return 0
        return (amount_base_units * buffer_rate_ppm) // 1_000_000

    def create_escrow(
        self,
        deal_id: str,
        amount_base_units: int,
        mode: str = "FULL",
        buffer_rate_ppm: int = 0,
        settlement_template_hash: str | None = None,
        arbitration: dict | None = None,
        **kwargs,
    ) -> EscrowState:
        del kwargs
        self._validate_mode(mode, buffer_rate_ppm)
        buffer_locked = self._compute_buffer_locked(amount_base_units, mode, buffer_rate_ppm)
        state = EscrowState(
            backend=self.stream_backend_name if mode == "STREAM_WITH_BUFFER" else self.backend_name,
            deal_id=deal_id,
            amount_base_units=amount_base_units,
            mode=mode,
            buffer_rate_ppm=buffer_rate_ppm,
            buffer_locked_base_units=buffer_locked,
            settlement_template_hash=settlement_template_hash,
        )
        arbitration = arbitration or {}
        arb_keys = set(arbitration.get("arb_public_keys", []))
        arb_quorum = int(arbitration.get("quorum", 1))
        self._deals[deal_id] = InMemoryDeal(state=state, arb_public_keys=arb_keys, arb_quorum=arb_quorum)
        return state

    def register_settlement_hash(self, deal_id: str, settlement_template_hash: str) -> None:
        self._deals[deal_id].state.settlement_template_hash = settlement_template_hash

    def fund_escrow(self, deal_id: str) -> dict:
        deal = self._deals[deal_id]
        deal.state.funded = True
        deal.funding_tx = f"0xFUND{deal_id[-8:]}"
        return {"tx_hash": deal.funding_tx, "status": "funded"}

    def unlock_streamed_amount(self, deal_id: str, unlocked_base_units: int) -> dict:
        deal = self._deals[deal_id]
        state = deal.state
        if state.mode != "STREAM_WITH_BUFFER":
            raise ValueError("Streaming unlock is only valid for STREAM_WITH_BUFFER mode")
        max_unlockable = state.amount_base_units - state.buffer_locked_base_units
        next_unlocked = max(state.unlocked_base_units, unlocked_base_units)
        if next_unlocked > max_unlockable:
            raise ValueError("Unlocked amount exceeds streamable amount")
        state.unlocked_base_units = next_unlocked
        return {
            "deal_id": deal_id,
            "unlocked_base_units": state.unlocked_base_units,
            "buffer_locked_base_units": state.buffer_locked_base_units,
        }

    def withdraw_streamed(self, deal_id: str, amount_base_units: int) -> dict:
        deal = self._deals[deal_id]
        state = deal.state
        if state.mode != "STREAM_WITH_BUFFER":
            raise ValueError("Streaming withdrawal is only valid for STREAM_WITH_BUFFER mode")
        available = state.unlocked_base_units - state.withdrawn_base_units
        if amount_base_units > available:
            raise ValueError("Insufficient unlocked funds")
        state.withdrawn_base_units += amount_base_units
        return {
            "deal_id": deal_id,
            "withdrawn_base_units": state.withdrawn_base_units,
            "remaining_unlocked_base_units": state.unlocked_base_units - state.withdrawn_base_units,
        }

    def compute_protocol_fee(self, amount_base_units: int) -> int:
        proportional = (amount_base_units * self.protocol_fee_ppm) // 1_000_000
        fee = max(proportional, self.protocol_fee_min)
        return min(fee, amount_base_units)

    def _validate_settlement_invariants(self, deal: InMemoryDeal, tx: dict) -> None:
        payout = tx.get("payout", {})
        required_fee = self.compute_protocol_fee(deal.state.amount_base_units)
        if int(payout.get("fee_to_sink", -1)) != required_fee:
            raise ValueError("Protocol fee invariant violated")
        outputs_sum = int(payout.get("to_seller", 0)) + int(payout.get("to_buyer", 0)) + int(payout.get("fee_to_sink", 0))
        if outputs_sum + self.gas_cost_base_units != deal.state.amount_base_units:
            raise ValueError("Settlement invariant violated: outputs + gas must equal escrow locked")

    def build_settlement_tx(
        self,
        deal_id: str,
        payout: dict,
        method: str = "releaseByArbitration",
        settlement_template_hash: str | None = None,
        expiry: int | None = None,
    ) -> dict:
        deal = self._deals[deal_id]
        if not deal.state.funded:
            raise ValueError("Deal is not funded")
        if method not in self.ALLOWED_METHODS:
            raise ValueError(f"Unsupported settlement method: {method}")
        if settlement_template_hash and deal.state.settlement_template_hash and settlement_template_hash != deal.state.settlement_template_hash:
            raise ValueError("Settlement template hash mismatch")
        self._validate_settlement_invariants(deal, {"payout": payout})
        return {
            "deal_id": deal_id,
            "backend": deal.state.backend,
            "to": self.escrow_contract_address,
            "method": method,
            "payout": payout,
            "gas_cost": self.gas_cost_base_units,
            "escrow_locked": deal.state.amount_base_units,
            "nonce": deal.nonce,
            "settlement_template_hash": deal.state.settlement_template_hash,
            "arb_quorum": deal.arb_quorum,
            "expiry": expiry,
            "protocol_fee_ppm": self.protocol_fee_ppm,
            "protocol_fee_min": self.protocol_fee_min,
            "protocol_fee_sink": self.protocol_fee_sink,
        }

    def _validate_release_tx(self, tx: dict) -> None:
        if tx.get("to") != self.escrow_contract_address:
            raise ValueError("Settlement target address mismatch")
        if tx.get("method") not in self.ALLOWED_METHODS:
            raise ValueError("Arbitrary calldata/method is not allowed")

    def sign_settlement_tx(self, tx: dict, signer: str) -> dict:
        self._validate_release_tx(tx)
        signatures = tx.setdefault("signatures", [])
        signatures.append(signer)
        return tx

    def _enforce_arbitration_signatures(self, tx: dict) -> None:
        if tx.get("method") != "releaseByArbitration":
            return
        deal = self._deals[tx["deal_id"]]
        if not deal.arb_public_keys:
            return
        signatures = set(tx.get("signatures", []))
        valid_signatures = signatures.intersection(deal.arb_public_keys)
        if len(valid_signatures) < deal.arb_quorum:
            raise ValueError("Insufficient arbitrator signatures for configured quorum")

    def broadcast_settlement_tx(self, tx: dict) -> dict:
        self._validate_release_tx(tx)
        self._enforce_arbitration_signatures(tx)
        deal = self._deals[tx["deal_id"]]
        if tx.get("deal_id") != deal.state.deal_id:
            raise ValueError("deal_id mismatch")
        if tx.get("settlement_template_hash") != deal.state.settlement_template_hash:
            raise ValueError("settlement_template_hash mismatch")
        self._validate_settlement_invariants(deal, tx)
        nonce = int(tx.get("nonce", -1))
        if nonce in deal.used_nonces:
            raise ValueError("Replay detected: nonce already used")
        expiry = tx.get("expiry")
        if expiry is not None and int(expiry) < 0:
            raise ValueError("Invalid expiry")
        deal.used_nonces.add(nonce)
        deal.state.released = True
        deal.settlement_tx = f"0xSETTLE{tx['deal_id'][-8:]}"
        deal.nonce += 1
        return {"tx_hash": deal.settlement_tx, "status": "released"}

    def verify_funding(self, deal_id: str) -> bool:
        return self._deals[deal_id].state.funded

    def verify_settlement(self, deal_id: str) -> bool:
        return self._deals[deal_id].state.released
