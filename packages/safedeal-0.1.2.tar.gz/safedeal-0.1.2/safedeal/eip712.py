from __future__ import annotations

from dataclasses import asdict

from .crypto import canonical_json, sha256_hex


def _domain(chain_id: int, verifying_contract: str) -> dict:
    return {
        "name": "SafeDealEscrow",
        "version": "1",
        "chainId": chain_id,
        "verifyingContract": verifying_contract,
    }


def build_bind_typed_data(bind: dict, chain_id: int, verifying_contract: str) -> dict:
    message = {
        "dealId": bind["deal_id"],
        "bindHash": bind["bind_hash"],
        "quoteHash": bind["quote_hash"],
        "settlementTemplateHash": bind["settlement_template_hash"],
        "buyer": bind["buyer_id"]["pk"],
        "seller": bind["seller_id"]["pk"],
    }
    return {
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            "Bind": [
                {"name": "dealId", "type": "bytes32"},
                {"name": "bindHash", "type": "bytes32"},
                {"name": "quoteHash", "type": "bytes32"},
                {"name": "settlementTemplateHash", "type": "bytes32"},
                {"name": "buyer", "type": "address"},
                {"name": "seller", "type": "address"},
            ],
        },
        "primaryType": "Bind",
        "domain": _domain(chain_id, verifying_contract),
        "message": message,
    }


def build_release_intent_typed_data(intent: dict, chain_id: int, verifying_contract: str) -> dict:
    return {
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            "ReleaseIntent": [
                {"name": "dealId", "type": "bytes32"},
                {"name": "settlementTemplateHash", "type": "bytes32"},
                {"name": "toSeller", "type": "uint256"},
                {"name": "toBuyer", "type": "uint256"},
                {"name": "feeToSink", "type": "uint256"},
                {"name": "nonce", "type": "uint256"},
                {"name": "expiry", "type": "uint256"},
            ],
        },
        "primaryType": "ReleaseIntent",
        "domain": _domain(chain_id, verifying_contract),
        "message": {
            "dealId": intent["deal_id"],
            "settlementTemplateHash": intent["settlement_template_hash"],
            "toSeller": int(intent["payout"]["to_seller"]),
            "toBuyer": int(intent["payout"]["to_buyer"]),
            "feeToSink": int(intent["payout"]["fee_to_sink"]),
            "nonce": int(intent["nonce"]),
            "expiry": int(intent["expiry"]),
        },
    }


def typed_data_hash(typed_data: dict) -> str:
    return sha256_hex(canonical_json(typed_data))
