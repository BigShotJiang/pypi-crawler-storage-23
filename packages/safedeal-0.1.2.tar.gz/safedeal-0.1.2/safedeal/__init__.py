"""SafeDeal SDK public ergonomic API."""

from .capabilities import NegotiatedProfile, capabilities_hash, negotiate_capabilities, sign_capabilities, verify_capabilities
from .sdk import (
    PROFILES,
    PROFILE_CAPITAL_EFFICIENT,
    PROFILE_FAST_LOW_RISK,
    PROFILE_TRUSTED_COUNTERPARTY,
    SafeDealSDK,
)

__all__ = [
    "SafeDealSDK",
    "PROFILES",
    "PROFILE_FAST_LOW_RISK",
    "PROFILE_CAPITAL_EFFICIENT",
    "PROFILE_TRUSTED_COUNTERPARTY",
    "NegotiatedProfile",
    "capabilities_hash",
    "sign_capabilities",
    "verify_capabilities",
    "negotiate_capabilities",
]
