from __future__ import annotations

import time
import json
from dataclasses import asdict
from enum import Enum
from hashlib import sha256
from typing import Any
from pathlib import Path

from .adapters.arb_v17.adapter import ArbDecision, ArbV17Adapter
from .adapters.base import ArbitrationAdapter
from .eip712 import build_release_intent_typed_data, typed_data_hash
from .signers import Signer
from .crypto import CANONICAL_SPEC_VERSION, canonical_json, message_hash
from .messages import make_accept_message, make_bind_message, make_offer_message, make_quote_message
from .models import DealBind, DealQuote, DisputeOpen, Identity, Payout, parse_amount_to_base_units

OBJECTIVE_DELIVERABLE_TYPES = {"HASH_MATCH", "SIGNED_ATTESTATION", "ONCHAIN_PROOF"}
DELIVERY_CHANNEL_PREFIXES = ("ipfs://", "ar://", "magnet:?", "https://", "inline://")


class DealState(str, Enum):
    PROPOSED = "PROPOSED"
    BOUND = "BOUND"
    FUNDED = "FUNDED"
    DELIVERED = "DELIVERED"
    ACCEPTED = "ACCEPTED"
    DISPUTED = "DISPUTED"
    ARBITRATED = "ARBITRATED"
    SETTLED = "SETTLED"
    EXPIRED = "EXPIRED"


class DealHandle:
    def __init__(self, sdk: "SafeDealSDK", offer: Any, accept: Any, expected_hash: str | None):
        self._sdk = sdk
        self.offer = offer
        self.accept = accept
        self.expected_hash = expected_hash
        self.escrow_state = None
        self.delivery = None

    @property
    def deal_id(self) -> str:
        return self.offer.deal_id

    def fund(self) -> dict:
        self.escrow_state = self._sdk.escrow_prepare(self.offer, self.accept)
        return self._sdk.escrow_fund(self.escrow_state)

    def wait_for_delivery(
        self,
        milestone_id: str = "M1",
        content_hash: str | None = None,
        channels: list[dict] | None = None,
        availability_proof: dict | None = None,
    ) -> dict:
        observed = content_hash or self.expected_hash
        if not observed:
            raise ValueError("content_hash or expected_hash is required")
        self.delivery = self._sdk.deliver(
            self.deal_id,
            milestone_id=milestone_id,
            content_hash=observed,
            channels=channels,
            availability_proof=availability_proof,
        )
        return self.delivery

    def auto_settle(self, wait_blocks: int = 0, current_block: int = 0, dispute_filed: bool = False) -> dict:
        if self.delivery is None:
            raise ValueError("delivery not available")
        expected_hash = self.expected_hash or self.accept.expected_hashes.get(self.delivery["milestone_id"])
        return self._sdk.auto_settle_objective(
            self.delivery,
            expected_hash=expected_hash,
            wait_blocks=wait_blocks,
            current_block=current_block,
            dispute_filed=dispute_filed,
        )


PROFILE_FAST_LOW_RISK = {"buffer_rate_ppm": 200000, "dispute_window_blocks": 8, "stall_fee_buyer": 3000, "stall_fee_seller": 3000}
PROFILE_CAPITAL_EFFICIENT = {"buffer_rate_ppm": 50000, "dispute_window_blocks": 4, "stall_fee_buyer": 6000, "stall_fee_seller": 6000}
PROFILE_TRUSTED_COUNTERPARTY = {"buffer_rate_ppm": 0, "dispute_window_blocks": 1, "stall_fee_buyer": 0, "stall_fee_seller": 0}
PROFILES = {"FAST_LOW_RISK": PROFILE_FAST_LOW_RISK, "CAPITAL_EFFICIENT": PROFILE_CAPITAL_EFFICIENT, "TRUSTED_COUNTERPARTY": PROFILE_TRUSTED_COUNTERPARTY}
DEFAULT_PROTOCOL_FEE_PPM = 1000
DEFAULT_PROTOCOL_FEE_MIN = 1
DEFAULT_PROTOCOL_FEE_SINK = "0xFEE0000000000000000000000000000000000000"
SAFEDEAL_PROTOCOL_VERSION = "1.0.0"
_RULES_SNAPSHOT = "safe release invariants|objective settlement|protocol fee enforced"
_SCHEMA_TEXT = Path(__file__).resolve().parents[1].joinpath("schemas", "deal_bundle.schema.json").read_text(encoding="utf-8")
SAFEDEAL_PROTOCOL_HASH = "0x" + sha256(f"{_SCHEMA_TEXT}|{_RULES_SNAPSHOT}".encode("utf-8")).hexdigest()


class SafeDealSDK:
    """SafeDeal ergonomic API aligned to v0.1 spec."""

    def __init__(self, escrow_backend: Any, arbitrator_adapter: ArbitrationAdapter | None = None, now_fn: Any | None = None, on_release: Any | None = None) -> None:
        self.escrow = escrow_backend
        self.arb = arbitrator_adapter or ArbV17Adapter()
        self.now_fn = now_fn or (lambda: int(time.time()))
        self.on_release = on_release or (lambda deal_id, amount, fee_paid: None)
        self._state: dict[str, DealState] = {}
        self._deadlines: dict[str, dict[str, int]] = {}
        self._last_case_bundle: dict[str, dict] = {}
        self._offer_by_deal_id: dict[str, Any] = {}
        self._accept_by_deal_id: dict[str, Any] = {}
        self._quote_by_deal_id: dict[str, Any] = {}
        self._bind_by_deal_id: dict[str, Any] = {}
        self._delivery_block: dict[str, int] = {}
        self._escrow_state_by_deal_id: dict[str, Any] = {}
        self._delivery_by_deal_id: dict[str, dict] = {}

    def _now(self) -> int:
        return int(self.now_fn())

    def _set_state(self, deal_id: str, state: DealState) -> None:
        self._state[deal_id] = state

    def _assert_state(self, deal_id: str, allowed: set[DealState]) -> None:
        current = self._state.get(deal_id)
        if current not in allowed:
            raise ValueError(f"Invalid state transition from {current} for deal {deal_id}")

    def _load_deadlines(self, offer) -> None:
        deadlines = offer.terms.get("deadlines", {}) if isinstance(offer.terms, dict) else {}
        self._deadlines[offer.deal_id] = {
            "fund_by": int(deadlines.get("fund_by", 2**31 - 1)),
            "deliver_by": int(deadlines.get("deliver_by", 2**31 - 1)),
            "accept_by": int(deadlines.get("accept_by", 2**31 - 1)),
            "dispute_by": int(deadlines.get("dispute_by", 2**31 - 1)),
        }

    def _assert_before(self, deal_id: str, key: str) -> None:
        if self._now() > self._deadlines[deal_id][key]:
            self._set_state(deal_id, DealState.EXPIRED)
            raise ValueError(f"Deadline passed: {key}")

    def _validate_offer_constraints(self, offer: Any) -> None:
        deliverable_type = offer.terms.get("deliverable_type", "HASH_MATCH")
        if deliverable_type not in OBJECTIVE_DELIVERABLE_TYPES:
            raise ValueError(f"Unsupported deliverable_type: {deliverable_type}")

    def _validate_delivery_channels(self, channels: list[dict] | None) -> None:
        if not channels:
            raise ValueError("At least one delivery channel is required")
        for channel in channels:
            uri = channel.get("uri", "")
            if not uri.startswith(DELIVERY_CHANNEL_PREFIXES):
                raise ValueError(f"Unsupported delivery channel URI: {uri}")

    def compute_settlement_template_hash(self, offer_like: Any) -> str:
        payload = {
            "deal_id": offer_like.deal_id,
            "escrow": offer_like.escrow,
            "arbitration": offer_like.arbitration,
            "economics": getattr(offer_like, "economics", {}),
            "terms": {
                "deliverable_type": offer_like.terms.get("deliverable_type", "HASH_MATCH"),
                "milestones": offer_like.terms.get("milestones", []),
                "protocol_fee": {
                    "protocol_fee_ppm": getattr(offer_like, "economics", {}).get("protocol_fee_ppm", DEFAULT_PROTOCOL_FEE_PPM),
                    "protocol_fee_min": getattr(offer_like, "economics", {}).get("protocol_fee_min", DEFAULT_PROTOCOL_FEE_MIN),
                    "protocol_fee_sink": getattr(offer_like, "economics", {}).get("protocol_fee_sink", DEFAULT_PROTOCOL_FEE_SINK),
                },
                "stall_penalties": {
                    "buyer_stall_fee_sats_per_day": offer_like.terms.get("buyer_stall_fee_sats_per_day", 0),
                    "seller_stall_fee_sats_per_day": offer_like.terms.get("seller_stall_fee_sats_per_day", 0),
                    "max_stall_fee_cap": offer_like.terms.get("max_stall_fee_cap", 0),
                },
            },
        }
        return "0x" + sha256(canonical_json(payload).encode("utf-8")).hexdigest()

    def make_quote(self, **kwargs) -> DealQuote:
        quote = make_quote_message(**kwargs)
        return quote

    def bind_quote(self, quote: DealQuote, signing_key_hint: str) -> DealBind:
        pseudo_offer = type("PseudoOffer", (), {"deal_id": "pending", "escrow": quote.escrow, "arbitration": quote.arbitration, "economics": quote.economics, "terms": quote.terms})
        settlement_template_hash = self.compute_settlement_template_hash(pseudo_offer)
        bind = make_bind_message(quote, signing_key_hint=signing_key_hint, settlement_template_hash=settlement_template_hash)
        self._quote_by_deal_id[bind.deal_id] = quote
        self._bind_by_deal_id[bind.deal_id] = bind
        self._set_state(bind.deal_id, DealState.BOUND)
        return bind

    def quote_bind_fund(self, quote: DealQuote, buyer_signing_key_hint: str) -> dict:
        bind = self.bind_quote(quote, signing_key_hint=buyer_signing_key_hint)
        amount_base_units = parse_amount_to_base_units(bind.asset["amount"])
        escrow_state = self.escrow.create_escrow(
            bind.deal_id,
            amount_base_units,
            mode=bind.escrow.get("mode", "FULL"),
            buffer_rate_ppm=int(bind.escrow.get("buffer_rate_ppm", 0)),
            settlement_template_hash=bind.settlement_template_hash,
            arbitration=bind.arbitration,
        )
        self._escrow_state_by_deal_id[bind.deal_id] = escrow_state
        fund_tx = self.escrow.fund_escrow(bind.deal_id)
        self._set_state(bind.deal_id, DealState.FUNDED)
        return {"bind": asdict(bind), "bind_hash": bind.bind_hash, "deal_id": bind.deal_id, "fund_tx": fund_tx}

    def make_offer(self, **kwargs):
        offer = make_offer_message(**kwargs)
        self._validate_offer_constraints(offer)
        if offer.escrow.get("mode") == "STREAM_WITH_BUFFER" and offer.escrow.get("backend") == "EVM_ESCROW_V1":
            offer.escrow["backend"] = "EVM_ESCROW_STREAM_V1"
        offer.escrow.setdefault("mode", "FULL")
        offer.escrow.setdefault("buffer_rate_ppm", 0)
        offer.arbitration.setdefault("arb_public_keys", [])
        offer.arbitration.setdefault("quorum", 1)
        offer.terms.setdefault("buyer_stall_fee_sats_per_day", 0)
        offer.terms.setdefault("seller_stall_fee_sats_per_day", 0)
        offer.terms.setdefault("max_stall_fee_cap", 0)
        self._set_state(offer.deal_id, DealState.PROPOSED)
        self._load_deadlines(offer)
        self._offer_by_deal_id[offer.deal_id] = offer
        return offer

    def accept_offer(self, offer, expected_hashes: dict[str, str], signing_key_hint: str):
        self._assert_state(offer.deal_id, {DealState.PROPOSED})
        accept = make_accept_message(offer, expected_hashes=expected_hashes, signing_key_hint=signing_key_hint)
        self._accept_by_deal_id[offer.deal_id] = accept
        return accept

    def escrow_prepare(self, offer, accept):
        del accept
        self._assert_state(offer.deal_id, {DealState.PROPOSED})
        amount_base_units = parse_amount_to_base_units(offer.asset["amount"])
        settlement_template_hash = self.compute_settlement_template_hash(offer)
        state = self.escrow.create_escrow(
            offer.deal_id,
            amount_base_units,
            mode=offer.escrow.get("mode", "FULL"),
            buffer_rate_ppm=int(offer.escrow.get("buffer_rate_ppm", 0)),
            settlement_template_hash=settlement_template_hash,
            arbitration=offer.arbitration,
        )
        self._escrow_state_by_deal_id[offer.deal_id] = state
        return state

    def escrow_fund(self, escrow_state):
        self._assert_state(escrow_state.deal_id, {DealState.PROPOSED, DealState.BOUND})
        if escrow_state.deal_id in self._deadlines:
            self._assert_before(escrow_state.deal_id, "fund_by")
        tx = self.escrow.fund_escrow(escrow_state.deal_id)
        self._set_state(escrow_state.deal_id, DealState.FUNDED)
        return tx

    def unlock_streamed_amount(self, deal_id: str, unlocked_base_units: int) -> dict:
        self._assert_state(deal_id, {DealState.FUNDED, DealState.DELIVERED, DealState.ACCEPTED, DealState.DISPUTED})
        return self.escrow.unlock_streamed_amount(deal_id, unlocked_base_units)

    def withdraw_streamed(self, deal_id: str, amount_base_units: int) -> dict:
        self._assert_state(deal_id, {DealState.FUNDED, DealState.DELIVERED, DealState.ACCEPTED, DealState.DISPUTED})
        return self.escrow.withdraw_streamed(deal_id, amount_base_units)

    def deliver(
        self,
        deal_id: str,
        milestone_id: str,
        content_hash: str,
        uris: list[str] | None = None,
        observed_block: int | None = None,
        channels: list[dict] | None = None,
        availability_proof: dict | None = None,
    ) -> dict:
        self._assert_state(deal_id, {DealState.FUNDED})
        if deal_id in self._deadlines:
            self._assert_before(deal_id, "deliver_by")
        channels = channels or ([{"uri": uri, "hash": content_hash} for uri in (uris or [])] if uris else [{"uri": f"inline://{milestone_id}", "hash": content_hash}])
        self._validate_delivery_channels(channels)
        self._set_state(deal_id, DealState.DELIVERED)
        if observed_block is not None:
            self._delivery_block[deal_id] = observed_block
        delivery = {
            "version": "safedeal-0.1",
            "canonical_spec_version": CANONICAL_SPEC_VERSION,
            "deal_id": deal_id,
            "milestone_id": milestone_id,
            "content_hash": content_hash,
            "channels": channels,
            "availability_proof": availability_proof or {},
        }
        self._delivery_by_deal_id[deal_id] = delivery
        return delivery

    def accept_or_reject(self, delivery: dict, expected_hash: str) -> dict:
        deal_id = delivery["deal_id"]
        self._assert_state(deal_id, {DealState.DELIVERED})
        if deal_id in self._deadlines:
            self._assert_before(deal_id, "accept_by")
        observed = delivery["content_hash"]
        accepted = observed == expected_hash
        self._set_state(deal_id, DealState.ACCEPTED if accepted else DealState.DISPUTED)
        return {
            "deal_id": deal_id,
            "milestone_id": delivery["milestone_id"],
            "observed_hash": observed,
            "accepted": accepted,
            "reason": "HASH_MATCH" if accepted else "WRONG_OUTPUT_HASH",
        }

    def auto_settle_objective(
        self,
        delivery: dict,
        expected_hash: str | None,
        wait_blocks: int,
        current_block: int,
        dispute_filed: bool,
    ) -> dict:
        deal_id = delivery["deal_id"]
        self._assert_state(deal_id, {DealState.DELIVERED})
        offer = self._offer_by_deal_id.get(deal_id)
        if offer and offer.terms.get("deliverable_type", "HASH_MATCH") != "HASH_MATCH":
            raise ValueError("Auto-settlement currently supports HASH_MATCH only")
        if not expected_hash or delivery["content_hash"] != expected_hash:
            raise ValueError("HASH_MATCH condition not satisfied")
        if dispute_filed:
            raise ValueError("Cannot auto-settle when a dispute is filed")
        delivery_block = self._delivery_block.get(deal_id, current_block)
        effective_wait_blocks = wait_blocks
        if offer and bool(offer.terms.get("objective_only_fast", False)):
            effective_wait_blocks = 0
        if current_block - delivery_block < effective_wait_blocks:
            raise ValueError("Dispute buffer window has not elapsed")
        self._set_state(deal_id, DealState.ACCEPTED)
        escrow_amount = self._escrow_state_by_deal_id[deal_id].amount_base_units
        payout = self.canonical_payout(escrow_amount=escrow_amount, winner="seller", fee=0)
        economics = offer.economics if offer else {}
        payout = self.apply_protocol_fee(escrow_amount, payout, economics=economics)
        settlement_hash = self.compute_settlement_template_hash(offer) if offer else self._bind_by_deal_id[deal_id].settlement_template_hash
        tx = self.escrow.build_settlement_tx(
            deal_id,
            payout=asdict(payout),
            method="releaseByMutual",
            settlement_template_hash=settlement_hash,
            expiry=self._now() + 3600,
        )
        return self.broadcast_release(tx)

    def compute_stall_penalty(self, deal_id: str, stalled_party: str, elapsed_days: int) -> int:
        offer = self._offer_by_deal_id.get(deal_id)
        terms = offer.terms if offer else self._bind_by_deal_id[deal_id].terms
        if stalled_party == "buyer":
            per_day = int(terms.get("buyer_stall_fee_sats_per_day", 0))
        elif stalled_party == "seller":
            per_day = int(terms.get("seller_stall_fee_sats_per_day", 0))
        else:
            raise ValueError("stalled_party must be buyer or seller")
        cap = int(terms.get("max_stall_fee_cap", 0))
        penalty = max(0, elapsed_days) * per_day
        return min(penalty, cap) if cap else penalty

    def apply_stall_penalty(self, deal_id: str, payout: Payout, stalled_party: str, elapsed_days: int) -> Payout:
        fee = self.compute_stall_penalty(deal_id, stalled_party=stalled_party, elapsed_days=elapsed_days)
        if stalled_party == "buyer":
            moved = min(fee, payout.to_buyer)
            return Payout(to_seller=payout.to_seller + moved, to_buyer=payout.to_buyer - moved, fee_to_sink=payout.fee_to_sink)
        moved = min(fee, payout.to_seller)
        return Payout(to_seller=payout.to_seller - moved, to_buyer=payout.to_buyer + moved, fee_to_sink=payout.fee_to_sink)

    def open_dispute(self, deal_id: str, milestone_id: str, claim_code: str, requested_relief: str) -> DisputeOpen:
        self._assert_state(deal_id, {DealState.FUNDED, DealState.DELIVERED, DealState.DISPUTED})
        offer = self._offer_by_deal_id.get(deal_id)
        if offer and not bool(offer.arbitration.get("enabled", True)):
            raise ValueError("Arbitration is disabled for objective-only deals")
        if deal_id in self._deadlines:
            self._assert_before(deal_id, "dispute_by")
        self._set_state(deal_id, DealState.DISPUTED)
        return DisputeOpen(
            version="safedeal-0.1",
            canonical_spec_version=CANONICAL_SPEC_VERSION,
            deal_id=deal_id,
            milestone_id=milestone_id,
            claim_code=claim_code,
            requested_relief=requested_relief,
        )

    def to_arb_case_bundle(self, dispute: DisputeOpen, evidence: dict) -> dict:
        case_bundle = self.arb.to_case_bundle(asdict(dispute), evidence)
        self._last_case_bundle[dispute.deal_id] = case_bundle
        return case_bundle

    def call_arbitration(self, case_bundle: dict) -> ArbDecision:
        return self.arb.resolve(case_bundle)

    def verify_arb_decision(self, decision: ArbDecision) -> bool:
        return self.arb.verify_decision(decision, self._last_case_bundle.get(decision.deal_id))

    def compute_protocol_fee(self, escrow_amount: int, economics: dict | None = None) -> int:
        economics = economics or {}
        ppm = int(economics.get("protocol_fee_ppm", DEFAULT_PROTOCOL_FEE_PPM))
        fee_min = int(economics.get("protocol_fee_min", DEFAULT_PROTOCOL_FEE_MIN))
        proportional = (escrow_amount * ppm) // 1_000_000
        fee = max(proportional, fee_min)
        return min(fee, escrow_amount)

    def apply_protocol_fee(self, escrow_amount: int, payout: Payout, economics: dict | None = None) -> Payout:
        economics = economics or {}
        required_fee = self.compute_protocol_fee(escrow_amount, economics=economics)
        distributable = escrow_amount - required_fee
        total_non_fee = payout.to_seller + payout.to_buyer
        if total_non_fee == 0:
            return Payout(to_seller=distributable, to_buyer=0, fee_to_sink=required_fee)
        ratio_seller = payout.to_seller / total_non_fee
        to_seller = int(distributable * ratio_seller)
        to_buyer = distributable - to_seller
        return Payout(to_seller=to_seller, to_buyer=to_buyer, fee_to_sink=required_fee)

    def canonical_payout(self, escrow_amount: int, winner: str, fee: int = 0) -> Payout:
        if fee > escrow_amount:
            raise ValueError("fee cannot exceed escrow amount")
        if winner == "seller":
            return Payout(to_seller=escrow_amount - fee, to_buyer=0, fee_to_sink=fee)
        if winner == "buyer":
            return Payout(to_seller=0, to_buyer=escrow_amount - fee, fee_to_sink=fee)
        raise ValueError("winner must be 'buyer' or 'seller'")

    def canonical_payout_split(self, escrow_amount: int, seller_bps: int, buyer_bps: int, fee_to_sink: int = 0) -> Payout:
        if seller_bps < 0 or buyer_bps < 0 or seller_bps + buyer_bps != 10_000:
            raise ValueError("seller_bps and buyer_bps must be non-negative and sum to 10_000")
        distributable = escrow_amount - fee_to_sink
        if distributable < 0:
            raise ValueError("fee_to_sink cannot exceed escrow_amount")
        to_seller = (distributable * seller_bps) // 10_000
        to_buyer = distributable - to_seller
        return Payout(to_seller=to_seller, to_buyer=to_buyer, fee_to_sink=fee_to_sink)

    def preview_release(self, escrow_amount: int, winner: str, fee: int, reason: str) -> dict:
        payout = self.canonical_payout(escrow_amount=escrow_amount, winner=winner, fee=fee)
        return {
            "to_seller": payout.to_seller,
            "to_buyer": payout.to_buyer,
            "fee": payout.fee_to_sink,
            "reason": reason,
        }

    def build_release_from_decision(self, deal_id: str, decision: ArbDecision, escrow_amount: int) -> dict:
        self._assert_state(deal_id, {DealState.DISPUTED, DealState.ARBITRATED})
        if not self.verify_arb_decision(decision):
            raise ValueError("Arbitration decision validation failed")
        payout = Payout(**decision.award.get("amounts"))
        offer = self._offer_by_deal_id[deal_id]
        payout = self.apply_protocol_fee(escrow_amount, payout, economics=offer.economics)
        if payout.total() != escrow_amount:
            raise ValueError("Award consistency validation failed")
        tx = self.escrow.build_settlement_tx(
            deal_id,
            payout=asdict(payout),
            method="releaseByArbitration",
            settlement_template_hash=self.compute_settlement_template_hash(offer),
            expiry=self._now() + 3600,
        )
        if tx.get("to") != self.escrow.escrow_contract_address:
            raise ValueError("Settlement destination mismatch")
        self._set_state(deal_id, DealState.ARBITRATED)
        return tx

    def sign_release(self, settlement_tx: dict, signer: Identity) -> dict:
        return self.escrow.sign_settlement_tx(settlement_tx, signer=signer.pk)


    def preview_release_intent(self, settlement_tx: dict) -> dict:
        payout = settlement_tx["payout"]
        summary = {
            "deal_id": settlement_tx["deal_id"],
            "settlement_template_hash": settlement_tx["settlement_template_hash"],
            "to_seller": int(payout["to_seller"]),
            "to_buyer": int(payout["to_buyer"]),
            "fee_to_sink": int(payout["fee_to_sink"]),
            "nonce": int(settlement_tx["nonce"]),
            "expiry": int(settlement_tx.get("expiry") or 0),
        }
        summary["typed_data_hash"] = typed_data_hash(
            build_release_intent_typed_data(
                settlement_tx,
                chain_id=1,
                verifying_contract=self.escrow.escrow_contract_address,
            )
        )
        return summary

    def sign_release_with_signer(self, settlement_tx: dict, signer: Signer, preview: dict | None = None) -> dict:
        preview_payload = preview or self.preview_release_intent(settlement_tx)
        signature = signer.sign(settlement_tx, preview_payload)
        settlement_tx.setdefault("signatures", []).append(signature)
        return settlement_tx

    def broadcast_release(self, settlement_tx: dict) -> dict:
        self._assert_state(settlement_tx["deal_id"], {DealState.ARBITRATED, DealState.ACCEPTED})
        incoming_hash = settlement_tx.get("protocol_hash")
        if incoming_hash:
            self.assert_protocol_compatibility(incoming_hash)
        out = self.escrow.broadcast_settlement_tx(settlement_tx)
        self._set_state(settlement_tx["deal_id"], DealState.SETTLED)
        payout = settlement_tx.get("payout", {})
        amount = int(payout.get("to_seller", 0)) + int(payout.get("to_buyer", 0)) + int(payout.get("fee_to_sink", 0))
        self.on_release(settlement_tx["deal_id"], amount, int(payout.get("fee_to_sink", 0)))
        return out

    def replace_counterparty(self, deal_id: str, role: str, new_identity: Identity, authorized: bool = False) -> dict:
        if not authorized:
            raise ValueError("Counterparty substitution requires authorization")
        bind = self._bind_by_deal_id.get(deal_id)
        if bind:
            if role == "seller":
                bind.seller_id = asdict(new_identity)
            elif role == "buyer":
                bind.buyer_id = asdict(new_identity)
            else:
                raise ValueError("role must be seller or buyer")
            return {"deal_id": deal_id, "role": role, "new_pk": new_identity.pk}
        offer = self._offer_by_deal_id[deal_id]
        if role == "seller":
            offer.seller_id = asdict(new_identity)
        elif role == "buyer":
            offer.buyer_id = asdict(new_identity)
        else:
            raise ValueError("role must be seller or buyer")
        return {"deal_id": deal_id, "role": role, "new_pk": new_identity.pk}

    def recommend_backend(self, asset: str, amount: str, urgency: str, trust: str) -> dict:
        amount_value = parse_amount_to_base_units(amount)
        high_urgency = urgency == "high"
        low_trust = trust == "low"
        backend_id = "EVM_ESCROW_STREAM_V1" if high_urgency else "EVM_ESCROW_V1"
        return {
            "backend_id": backend_id,
            "buffer_suggestion_ppm": 150000 if high_urgency else 50000,
            "fee_estimate_base_units": max(1, amount_value // 500),
            "expected_confirmation_time": "~12s" if high_urgency and low_trust else "~60s",
        }

    def estimate_dispute_cost(self, escrow_amount: int, token_budget: int, queue_depth: int) -> dict:
        base_fee = max(1, int(escrow_amount * 0.01))
        queue_penalty = max(0, queue_depth) * 5
        budget_penalty = max(0, base_fee - token_budget)
        expected_cost = base_fee + queue_penalty + budget_penalty
        return {
            "base_fee": base_fee,
            "queue_penalty": queue_penalty,
            "budget_penalty": budget_penalty,
            "expected_cost": expected_cost,
            "is_budget_sufficient": token_budget >= base_fee,
        }


    def estimate_total_cost(
        self,
        escrow_amount: int,
        token_budget: int,
        queue_depth: int,
        economics: dict | None = None,
        gas_units: int = 200_000,
        gas_price_base_units: int = 1,
    ) -> dict:
        protocol_fee = self.compute_protocol_fee(escrow_amount, economics=economics or {})
        dispute = self.estimate_dispute_cost(escrow_amount=escrow_amount, token_budget=token_budget, queue_depth=queue_depth)
        gas_est = gas_units * gas_price_base_units
        return {
            "protocol_fee": protocol_fee,
            "worst_case_dispute_fee": dispute["expected_cost"],
            "gas_est": gas_est,
        }

    def export_deal_bundle(self, deal_id: str, include_internal_state: bool = False) -> dict:
        offer = self._offer_by_deal_id.get(deal_id)
        accept = self._accept_by_deal_id.get(deal_id)
        bind = self._bind_by_deal_id.get(deal_id)
        quote = self._quote_by_deal_id.get(deal_id)
        bundle = {
            "bundle_version": 1,
            "messages": [x for x in [asdict(quote) if quote else None, asdict(bind) if bind else None, asdict(offer) if offer else None, asdict(accept) if accept else None] if x],
            "escrow_proofs": [asdict(self._escrow_state_by_deal_id.get(deal_id))] if self._escrow_state_by_deal_id.get(deal_id) else [],
            "delivery_artifacts": [self._delivery_by_deal_id.get(deal_id)] if self._delivery_by_deal_id.get(deal_id) else [],
            "arb_artifacts": [self._last_case_bundle.get(deal_id)] if self._last_case_bundle.get(deal_id) else [],
            "computed": {
                "deal_id": deal_id,
                "settlement_template_hash": self._escrow_state_by_deal_id.get(deal_id).settlement_template_hash if self._escrow_state_by_deal_id.get(deal_id) else None,
                "state": self._state[deal_id].value,
            },
            "state": self._state[deal_id].value,
        }
        if include_internal_state:
            escrow_state = self._escrow_state_by_deal_id.get(deal_id)
            bundle["escrow_state"] = asdict(escrow_state) if escrow_state else None
        return bundle

    def import_deal_bundle(self, bundle: dict) -> str:
        deal_id = bundle.get("computed", {}).get("deal_id")
        if not deal_id and bundle.get("offer"):
            deal_id = bundle["offer"]["deal_id"]
        if not deal_id:
            raise ValueError("Bundle missing deal_id")
        self._state[deal_id] = DealState(bundle.get("computed", {}).get("state", bundle.get("state", "PROPOSED")))
        return deal_id

    def build_bind(self, payload: dict) -> dict:
        bind = dict(payload)
        if "bind_hash" not in bind:
            bind_payload = bind.copy()
            bind_payload.pop("sig", None)
            bind_hash = message_hash(bind_payload)
            bind["bind_hash"] = bind_hash
        if "deal_id" not in bind:
            bind["deal_id"] = "0x" + sha256(bind["bind_hash"].encode("utf-8")).hexdigest()
        bind.setdefault("settlement_template_hash", self.compute_settlement_template_hash(type("OfferLike", (), bind)))
        return bind

    def compute_settlement_template(self, bind_or_offer: dict) -> str:
        as_obj = type("OfferLike", (), bind_or_offer)
        return self.compute_settlement_template_hash(as_obj)

    def compute_release_intent(self, bind: dict, payout: dict, nonce: int = 0, expiry: int = 2**31 - 1) -> dict:
        return {
            "deal_id": bind["deal_id"],
            "settlement_template_hash": bind["settlement_template_hash"],
            "payout": payout,
            "nonce": nonce,
            "expiry": expiry,
        }

    def verify_release(self, bind: dict, intent: dict, escrow_amount: int) -> bool:
        if intent.get("deal_id") != bind.get("deal_id"):
            return False
        if intent.get("settlement_template_hash") != bind.get("settlement_template_hash"):
            return False
        payout = intent.get("payout", {})
        required_fee = self.compute_protocol_fee(escrow_amount, economics=bind.get("economics", {}))
        if int(payout.get("fee_to_sink", -1)) != required_fee:
            return False
        return int(payout.get("to_seller", 0)) + int(payout.get("to_buyer", 0)) + int(payout.get("fee_to_sink", 0)) == escrow_amount

    def assert_protocol_compatibility(self, incoming_protocol_hash: str) -> None:
        if incoming_protocol_hash != SAFEDEAL_PROTOCOL_HASH:
            raise ValueError("Protocol hash mismatch")

    def export_announcement(self, deal_id: str, signing_key_hint: str = "announce_pk") -> dict:
        offer = self._offer_by_deal_id.get(deal_id)
        if not offer:
            raise ValueError("Unknown deal_id")
        announcement = {
            "version": SAFEDEAL_PROTOCOL_VERSION,
            "protocol_hash": SAFEDEAL_PROTOCOL_HASH,
            "deal_id": deal_id,
            "asset": offer.asset.get("currency", "UNKNOWN"),
            "amount": offer.asset.get("amount", "0"),
            "backend": offer.escrow.get("backend", "EVM_ESCROW_V1"),
            "objective_only": not bool(offer.arbitration.get("enabled", True)),
            "timestamp": self._now(),
        }
        serialized = canonical_json(announcement)
        announcement["announcement_sig"] = "0x" + sha256(f"ann|{signing_key_hint}|{serialized}".encode("utf-8")).hexdigest()
        return announcement

    def verify_announcement(self, announcement: dict, signing_key_hint: str = "announce_pk") -> bool:
        incoming_hash = announcement.get("protocol_hash")
        if incoming_hash:
            self.assert_protocol_compatibility(incoming_hash)
        payload = dict(announcement)
        sig = payload.pop("announcement_sig", "")
        serialized = canonical_json(payload)
        expected = "0x" + sha256(f"ann|{signing_key_hint}|{serialized}".encode("utf-8")).hexdigest()
        return sig == expected

    def build_batch_release(self, releases: list[dict]) -> list[dict]:
        batch: list[dict] = []
        for item in releases:
            deal_id = item["deal_id"]
            payout = item["payout"]
            settlement_template_hash = item.get("settlement_template_hash")
            method = item.get("method", "releaseByMutual")
            expiry = item.get("expiry", self._now() + 3600)
            tx = self.escrow.build_settlement_tx(
                deal_id,
                payout=payout,
                method=method,
                settlement_template_hash=settlement_template_hash,
                expiry=expiry,
            )
            batch.append(tx)
        return batch

    def create_deal(
        self,
        seller: Identity,
        buyer: Identity,
        amount: str,
        deliverable_hash: str,
        backend: str = "EVM",
        mode: str = "FULL",
        buffer_rate_ppm: int = 0,
        signing_key_hint_seller: str = "seller_pk",
        signing_key_hint_buyer: str = "buyer_pk",
        good_standing: dict | None = None,
        profile: str | None = None,
        objective_only: bool = False,
        objective_only_fast: bool = False,
    ) -> DealHandle:
        escrow_backend = "EVM_ESCROW_V1" if backend == "EVM" else backend
        if profile:
            if profile not in PROFILES:
                raise ValueError(f"Unknown profile: {profile}")
            profile_cfg = PROFILES[profile]
            if mode == "FULL" and profile_cfg["buffer_rate_ppm"] > 0:
                mode = "STREAM_WITH_BUFFER"
            buffer_rate_ppm = profile_cfg["buffer_rate_ppm"]
        offer = self.make_offer(
            seller=seller,
            buyer=buyer,
            asset={"currency": "USDC", "amount": amount, "amount_sats": None},
            escrow={
                "backend": escrow_backend,
                "mode": mode,
                "buffer_rate_ppm": buffer_rate_ppm,
            },
            terms={
                "deliverable_type": "HASH_MATCH",
                "milestones": [{"milestone_id": "M1", "amount": amount, "expected_hash": deliverable_hash}],
                "buyer_stall_fee_sats_per_day": profile_cfg["stall_fee_buyer"] if profile else 0,
                "seller_stall_fee_sats_per_day": profile_cfg["stall_fee_seller"] if profile else 0,
                "max_stall_fee_cap": 20000 if profile else 0,
                "deadlines": {},
                "objective_only_fast": objective_only and objective_only_fast,
            },
            arbitration={"enabled": not objective_only, "arb_policy_id": "arb-v1.7", "arb_public_keys": [], "quorum": 0 if objective_only else 1},
            economics={"escrow_creation_fee": {"currency": "USDC", "amount": "0.00"}, "good_standing": good_standing, "protocol_fee_ppm": DEFAULT_PROTOCOL_FEE_PPM, "protocol_fee_min": DEFAULT_PROTOCOL_FEE_MIN, "protocol_fee_sink": DEFAULT_PROTOCOL_FEE_SINK},
            signing_key_hint=signing_key_hint_seller,
        )
        accept = self.accept_offer(offer, expected_hashes={"M1": deliverable_hash}, signing_key_hint=signing_key_hint_buyer)
        return DealHandle(self, offer, accept, expected_hash=deliverable_hash)
