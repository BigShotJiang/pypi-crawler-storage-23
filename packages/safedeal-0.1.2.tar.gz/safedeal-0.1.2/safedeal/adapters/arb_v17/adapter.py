from __future__ import annotations

from dataclasses import dataclass

from ...crypto import sha256_hex
from ..base import DecisionArtifact


@dataclass(slots=True)
class ArbDecision(DecisionArtifact):
    pass


class ArbV17Adapter:
    policy_id = "arb-v1.7"

    def to_case_bundle(self, dispute: dict, evidence: dict) -> dict:
        decision_inputs_hash = sha256_hex(f"{dispute['deal_id']}|{dispute['milestone_id']}|{dispute['claim_code']}")
        economic_seal_hash = sha256_hex(f"{dispute.get('escrow_amount', 0)}|{dispute.get('fee', 0)}")
        return {
            "policy_id": self.policy_id,
            "dispute": dispute,
            "evidence": evidence,
            "decision_inputs_hash": decision_inputs_hash,
            "economic_seal_hash": economic_seal_hash,
            "mechanical": True,
        }

    def resolve(self, case_bundle: dict) -> ArbDecision:
        dispute = case_bundle["dispute"]
        winner = "buyer" if dispute["claim_code"] in {"NON_DELIVERY", "WRONG_OUTPUT_HASH", "TIMEOUT_BREACH"} else "seller"
        amount = dispute.get("escrow_amount", 0)
        fee = dispute.get("fee", 0)
        decision_hash = f"0xDEC{dispute['deal_id'][-8:]}"
        requested_relief = str(dispute.get("requested_relief", ""))
        if requested_relief.startswith("SPLIT:"):
            seller_bps = int(requested_relief.split(":", 1)[1])
            seller_bps = max(0, min(10_000, seller_bps))
            distributable = amount - fee
            to_seller = (distributable * seller_bps) // 10_000
            award_amounts = {"to_seller": to_seller, "to_buyer": distributable - to_seller, "fee_to_sink": fee}
            winner = "seller" if to_seller >= (distributable - to_seller) else "buyer"
        elif winner == "seller":
            award_amounts = {"to_seller": amount - fee, "to_buyer": 0, "fee_to_sink": fee}
        else:
            award_amounts = {"to_seller": 0, "to_buyer": amount - fee, "fee_to_sink": fee}
        return ArbDecision(
            deal_id=dispute["deal_id"],
            milestone_id=dispute["milestone_id"],
            winner=winner,
            amount_to_winner=max(0, amount - fee),
            fee=fee,
            decision_hash=decision_hash,
            decision_inputs_hash=case_bundle["decision_inputs_hash"],
            economic_seal_hash=case_bundle["economic_seal_hash"],
            award={"amounts": award_amounts},
        )

    def call_runner(self, case_bundle: dict) -> ArbDecision:
        return self.resolve(case_bundle)

    def verify_decision(self, decision: ArbDecision, case_bundle: dict | None = None) -> bool:
        if not decision.decision_hash.startswith("0xDEC") or decision.amount_to_winner < 0:
            return False
        if case_bundle is None:
            return True
        if decision.decision_inputs_hash != case_bundle.get("decision_inputs_hash"):
            return False
        if decision.economic_seal_hash != case_bundle.get("economic_seal_hash"):
            return False
        expected_amount = case_bundle.get("dispute", {}).get("escrow_amount", 0) - case_bundle.get("dispute", {}).get("fee", 0)
        return decision.amount_to_winner == expected_amount
