from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(slots=True)
class DecisionArtifact:
    deal_id: str
    milestone_id: str
    winner: str
    amount_to_winner: int
    fee: int
    decision_hash: str
    decision_inputs_hash: str
    economic_seal_hash: str
    award: dict[str, dict[str, int]]


class ArbitrationAdapter(Protocol):
    policy_id: str

    def to_case_bundle(self, dispute: dict, evidence: dict) -> dict: ...

    def resolve(self, case_bundle: dict) -> DecisionArtifact: ...

    def verify_decision(self, decision: DecisionArtifact, case_bundle: dict | None = None) -> bool: ...
