from .adapter import DummyDecision, DummyRulesAdapter

__all__ = ["DummyDecision", "DummyRulesAdapter"]
