from __future__ import annotations

import base64
import hashlib
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from .crypto import canonical_json_bytes
from .sdk import SAFEDEAL_PROTOCOL_HASH


SUPPORTED_CAPABILITY_SIG_SCHEMES = {"ed25519", "eip712", "secp256k1"}


@dataclass(frozen=True, slots=True)
class NegotiatedProfile:
    backend_id: str
    mode: str
    deliverable: str
    arbitration_supported: bool
    objective_only_fast_supported: bool


def _assert_lower_hex_strings(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            _assert_lower_hex_strings(child, f"{path}.{key}")
        return
    if isinstance(value, list):
        for idx, child in enumerate(value):
            _assert_lower_hex_strings(child, f"{path}[{idx}]")
        return
    if not isinstance(value, str):
        return
    if not value.startswith("0x"):
        return
    if value != value.lower():
        raise ValueError(f"Hex string must be lowercase at {path}")
    hex_part = value[2:]
    if not hex_part:
        raise ValueError(f"Hex string is missing body at {path}")
    if any(ch not in "0123456789abcdef" for ch in hex_part):
        raise ValueError(f"Invalid hex string at {path}")


def capabilities_payload(capabilities: Mapping[str, Any]) -> dict[str, Any]:
    payload = deepcopy(dict(capabilities))
    payload.pop("sig", None)
    _assert_lower_hex_strings(payload)
    return payload


def capabilities_hash(capabilities: Mapping[str, Any]) -> str:
    payload = capabilities_payload(capabilities)
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return "0x" + digest


def _parse_utc_iso8601(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _sign_capabilities_hash(cap_hash: str, sig_scheme: str, signing_key_hint: str) -> str:
    if sig_scheme == "ed25519":
        raw = hashlib.sha256(f"ed25519|{signing_key_hint}|{cap_hash}".encode("utf-8", "strict")).digest()
        return base64.b64encode(raw).decode("ascii")
    if sig_scheme in {"eip712", "secp256k1"}:
        return "0x" + hashlib.sha256(f"{sig_scheme}|{signing_key_hint}|{cap_hash}".encode("utf-8", "strict")).hexdigest()
    raise ValueError(f"Unsupported capability signature scheme: {sig_scheme}")


def sign_capabilities(capabilities: Mapping[str, Any], signing_key_hint: str) -> dict[str, Any]:
    signed = deepcopy(dict(capabilities))
    sig_scheme = signed.get("agent", {}).get("sig_scheme")
    if sig_scheme not in SUPPORTED_CAPABILITY_SIG_SCHEMES:
        raise ValueError("agent.sig_scheme must be one of ed25519|eip712|secp256k1")
    cap_hash = capabilities_hash(signed)
    signed["sig"] = _sign_capabilities_hash(cap_hash, sig_scheme=sig_scheme, signing_key_hint=signing_key_hint)
    return signed


def verify_capabilities(
    capabilities: Mapping[str, Any],
    now: datetime | None = None,
    expected_protocol_hash: str = SAFEDEAL_PROTOCOL_HASH,
    signing_key_hint: str | None = None,
) -> bool:
    doc = dict(capabilities)
    if doc.get("type") != "safedeal.capabilities" or int(doc.get("schema_version", -1)) != 1:
        return False

    protocol_hash = doc.get("protocol", {}).get("protocol_hash")
    if protocol_hash != expected_protocol_hash:
        return False

    sig_scheme = doc.get("agent", {}).get("sig_scheme")
    if sig_scheme not in SUPPORTED_CAPABILITY_SIG_SCHEMES:
        return False

    validity = doc.get("validity", {})
    try:
        issued_at = _parse_utc_iso8601(validity["issued_at"])
        expires_at = _parse_utc_iso8601(validity["expires_at"])
    except Exception:
        return False

    ts = now or datetime.now(timezone.utc)
    if not (issued_at <= ts <= expires_at):
        return False

    arbitration = doc.get("capabilities", {}).get("arbitration")
    if arbitration:
        quorum = int(arbitration.get("quorum", 0))
        arb_keys = arbitration.get("arbitrator_keys", [])
        if quorum > len(arb_keys):
            return False

    sig = doc.get("sig")
    if not isinstance(sig, str) or not sig:
        return False

    if signing_key_hint is None:
        signing_key_hint = str(doc.get("agent", {}).get("agent_id", ""))

    expected_sig = _sign_capabilities_hash(capabilities_hash(doc), sig_scheme=sig_scheme, signing_key_hint=signing_key_hint)
    return sig == expected_sig


def negotiate_capabilities(local_caps: Mapping[str, Any], remote_caps: Mapping[str, Any]) -> NegotiatedProfile:
    local_protocol = local_caps.get("protocol", {}).get("protocol_hash")
    remote_protocol = remote_caps.get("protocol", {}).get("protocol_hash")
    if local_protocol != remote_protocol:
        raise ValueError("Protocol hash mismatch")

    local_backends = local_caps.get("capabilities", {}).get("supported_backends", [])
    remote_backends = remote_caps.get("capabilities", {}).get("supported_backends", [])
    backend_map = {str(item.get("backend_id")): item for item in remote_backends}

    selected_backend: str | None = None
    selected_mode: str | None = None
    for local_backend in sorted(local_backends, key=lambda b: str(b.get("backend_id", ""))):
        backend_id = str(local_backend.get("backend_id", ""))
        remote_backend = backend_map.get(backend_id)
        if not remote_backend:
            continue
        local_modes = set(local_backend.get("modes", []))
        remote_modes = set(remote_backend.get("modes", []))
        mode_intersection = sorted(local_modes.intersection(remote_modes))
        if not mode_intersection:
            continue
        selected_backend = backend_id
        selected_mode = mode_intersection[0]
        break
    if not selected_backend or not selected_mode:
        raise ValueError("No compatible backend/mode intersection")

    local_deliverables = set(local_caps.get("capabilities", {}).get("objective_only", {}).get("supported_deliverables", []))
    remote_deliverables = set(remote_caps.get("capabilities", {}).get("objective_only", {}).get("supported_deliverables", []))
    deliverable_intersection = sorted(local_deliverables.intersection(remote_deliverables))
    if not deliverable_intersection:
        raise ValueError("No compatible deliverable intersection")

    local_arb = bool(local_caps.get("capabilities", {}).get("arbitration", {}).get("supported", False))
    remote_arb = bool(remote_caps.get("capabilities", {}).get("arbitration", {}).get("supported", False))
    arbitration_supported = local_arb and remote_arb

    local_fast = bool(local_caps.get("capabilities", {}).get("objective_only", {}).get("fast_supported", False))
    remote_fast = bool(remote_caps.get("capabilities", {}).get("objective_only", {}).get("fast_supported", False))

    return NegotiatedProfile(
        backend_id=selected_backend,
        mode=selected_mode,
        deliverable=deliverable_intersection[0],
        arbitration_supported=arbitration_supported,
        objective_only_fast_supported=local_fast and remote_fast,
    )
