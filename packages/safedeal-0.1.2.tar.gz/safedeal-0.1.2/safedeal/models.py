from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any


@dataclass(slots=True)
class Identity:
    pk: str
    sig_scheme: str


@dataclass(slots=True)
class Asset:
    currency: str
    amount: str
    amount_sats: int | None = None


@dataclass(slots=True)
class Milestone:
    milestone_id: str
    amount: str
    deadline: str
    expected_hash: str | None = None
    hash_alg: str = "sha256"


@dataclass(slots=True)
class DealOffer:
    version: str
    canonical_spec_version: int
    deal_id: str
    seller_id: Identity
    buyer_id: Identity
    asset: Asset
    escrow: dict[str, Any]
    terms: dict[str, Any]
    arbitration: dict[str, Any]
    economics: dict[str, Any]
    sig: str | None = None


@dataclass(slots=True)
class DealQuote:
    version: str
    canonical_spec_version: int
    seller_id: Identity
    buyer_id: Identity
    asset: dict[str, Any]
    escrow: dict[str, Any]
    terms: dict[str, Any]
    arbitration: dict[str, Any]
    economics: dict[str, Any]


@dataclass(slots=True)
class DealBind:
    version: str
    canonical_spec_version: int
    deal_id: str
    bind_hash: str
    quote_hash: str
    buyer_id: Identity
    seller_id: Identity
    asset: dict[str, Any]
    escrow: dict[str, Any]
    terms: dict[str, Any]
    arbitration: dict[str, Any]
    settlement_template_hash: str
    sig: str | None = None


@dataclass(slots=True)
class DealAccept:
    version: str
    canonical_spec_version: int
    deal_id: str
    offer_hash: str
    expected_hashes: dict[str, str]
    sig: str | None = None


@dataclass(slots=True)
class DeliveryReceipt:
    version: str
    canonical_spec_version: int
    deal_id: str
    milestone_id: str
    content_hash: str
    uris: list[str] = field(default_factory=list)


@dataclass(slots=True)
class DisputeOpen:
    version: str
    canonical_spec_version: int
    deal_id: str
    milestone_id: str
    claim_code: str
    requested_relief: str
    sig: str | None = None


@dataclass(slots=True)
class Payout:
    to_seller: int
    to_buyer: int
    fee_to_sink: int

    def total(self) -> int:
        return self.to_seller + self.to_buyer + self.fee_to_sink


def parse_amount_to_base_units(amount: str, decimals: int = 6) -> int:
    quantized = Decimal(amount) * (10**decimals)
    if quantized != int(quantized):
        raise ValueError(f"Amount {amount} has more than {decimals} decimals")
    return int(quantized)
