# safedeal-sdk

SafeDeal is a deterministic escrow protocol + SDK for agent-to-agent deals.
It produces a portable deal bundle that any counterparty can verify (Python + TypeScript), and enforces on-chain conservation + protocol-fee invariants on release.
Designed for autonomous agents: canonical hashing, replay/expiry guards, pluggable arbitration, and reproducible smoke flows.

## SD-5.6 adoption upgrades in this revision

- **One-command reproducible env + smoke test**:
  - `requirements.txt` (pinned runtime deps)
  - `scripts/bootstrap_env.sh` (venv + install + version print)
  - `scripts/run_smoke_test.sh` auto-checks deps and bootstraps as needed
- **Mandatory protocol fee on every release**:
  - on-chain fee params: `protocolFeePpm`, `protocolFeeMin`, `protocolFeeSink`
  - enforced in both `releaseByMutual` and `releaseByArbitration`
  - fee validated deterministically and emitted via `ProtocolFeeCharged`
- **Signer guardrails hardened**:
  - signer API is `sign(payload, preview)`
  - signer recomputes canonical preview from payload and rejects mismatch
- **Agent EV planning helper**:
  - `sdk.estimate_total_cost(...)` returns protocol fee + worst-case dispute fee + gas estimate

## One-command smoke test

```bash
./scripts/run_smoke_test.sh local_anvil
```

Expected output includes:

- env package versions
- deployed contract address
- bind/fund/mutual/arbitrated release tx hashes
- bundle export path
- python verify result
- ts verify result (when Node/npm is available)

## Protocol fee defaults

- `protocol_fee_ppm = 1000` (0.10%)
- `protocol_fee_min = 1` (base unit)

These defaults optimize adoption while ensuring non-gameable, volume-based protocol monetization.

## SafeDealCapabilities v1 compatibility freeze

SafeDealCapabilities v1 is frozen.
No required fields will be added.
New features must be optional and backwards compatible.
