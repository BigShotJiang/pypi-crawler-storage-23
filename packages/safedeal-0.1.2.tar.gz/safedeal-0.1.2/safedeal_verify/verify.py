from __future__ import annotations

from hashlib import sha256


def _normalize_bind_hash(bind_hash: str) -> str:
    """Return a canonical ``0x``-prefixed, lower-case 32-byte hex hash string."""
    if not isinstance(bind_hash, str):
        raise TypeError("bind_hash must be a hex string")

    normalized = bind_hash.lower()
    if not normalized.startswith("0x"):
        normalized = "0x" + normalized

    # Validate shape (the protocol uses a bytes32-style hex digest)
    if len(normalized) != 66:
        raise ValueError("bind_hash must be 32-byte hex (66 chars with 0x prefix)")
    int(normalized[2:], 16)
    return normalized


def compute_deal_id_from_bind_hash(bind_hash: str) -> str:
    """
    Deterministically compute deal_id from bind_hash.

    Important: SafeDeal currently defines ``deal_id`` as ``sha256(bind_hash_string)``,
    where ``bind_hash`` is the canonical 0x-prefixed hex string. This matches the
    Python SDK and TypeScript verifier implementations.
    """
    normalized = _normalize_bind_hash(bind_hash)
    return "0x" + sha256(normalized.encode("utf-8")).hexdigest()


def verify_bundle_computed(bundle: dict) -> bool:
    """
    Verify that bundle.computed.deal_id matches deal_id(bind_hash) for the first
    bind-like message in bundle.messages.
    """
    if not isinstance(bundle, dict):
        return False

    computed = bundle.get("computed", {})
    deal_id = computed.get("deal_id")
    if not deal_id:
        return False

    bind_hash = None
    for msg in bundle.get("messages", []):
        if isinstance(msg, dict) and "bind_hash" in msg:
            bind_hash = msg["bind_hash"]
            break

    if not bind_hash:
        return False

    try:
        expected = compute_deal_id_from_bind_hash(bind_hash)
    except (TypeError, ValueError):
        return False
    return deal_id == expected
