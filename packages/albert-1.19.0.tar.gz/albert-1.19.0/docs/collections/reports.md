::: albert.collections.reports.ReportCollection
