# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v0.1.0] - 2026-02-21

### Added
- Initial release of pyg-hyper-ssl (placeholder for future development)
- Project structure setup
- Pre-commit hooks (ruff lint/format)
- CI/CD pipeline configuration
- MIT License
- README with project overview

### Planned Features
- Self-supervised learning methods for hypergraphs:
  - Contrastive learning
  - Masked node/hyperedge prediction
  - Graph reconstruction
  - Hypergraph augmentation strategies
- Integration with pyg-hyper-bench for evaluation
- Pre-training utilities for downstream tasks

### Infrastructure
- Python 3.12+ support
- PyTorch and PyTorch Geometric integration
- Comprehensive testing framework
- Type hints and documentation

[Unreleased]: https://github.com/your-username/pyg-hyper-ssl/compare/v0.1.0...HEAD
[v0.1.0]: https://github.com/your-username/pyg-hyper-ssl/releases/tag/v0.1.0
