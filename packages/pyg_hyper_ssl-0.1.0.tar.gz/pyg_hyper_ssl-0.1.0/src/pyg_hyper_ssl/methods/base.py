"""Base abstract class for SSL methods."""

from abc import ABC, abstractmethod
from typing import Any

import torch
from pyg_hyper_data.data import HyperData
from torch import nn


class BaseSSLMethod(ABC, nn.Module):
    """Abstract base class for self-supervised learning methods.

    This class defines the interface that all SSL methods must implement.
    Subclasses should implement the forward pass and loss computation.

    Example:
        >>> from pyg_hyper_ssl.methods.contrastive import TriCL
        >>> from pyg_hyper_ssl.encoders import EncoderWrapper
        >>> from pyg_hyper_nn.models import HGNN
        >>>
        >>> encoder = EncoderWrapper(HGNN, in_channels=16, hidden_channels=64)
        >>> method = TriCL(encoder=encoder, proj_dim=32)
        >>> loss = method.train_step(data, data_aug)
    """

    def __init__(self, encoder: nn.Module, **kwargs: Any) -> None:
        """Initialize the SSL method.

        Args:
            encoder: Neural network encoder (typically from pyg-hyper-nn)
            **kwargs: Additional method-specific arguments
        """
        super().__init__()
        self.encoder = encoder

    @abstractmethod
    def forward(
        self,
        data: HyperData,
        data_aug: HyperData | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass with optional augmented view.

        Args:
            data: Original hypergraph data
            data_aug: Optional augmented hypergraph data.
                     If None, method should handle single-view case.

        Returns:
            (embeddings1, embeddings2): Tuple of embedding tensors
                - For contrastive methods: embeddings from two views
                - For generative methods: (original_embeddings, reconstructed_embeddings)
                - For predictive methods: (embeddings, predictions)

        Example:
            >>> z1, z2 = method(data, data_aug)
            >>> print(z1.shape, z2.shape)
            torch.Size([100, 64]) torch.Size([100, 64])
        """
        ...

    @abstractmethod
    def compute_loss(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Compute SSL loss from embeddings.

        Args:
            z1: First embedding tensor [num_nodes, hidden_dim]
            z2: Second embedding tensor [num_nodes, hidden_dim]
            **kwargs: Additional method-specific arguments
                     (e.g., data for reconstruction, labels for supervised contrast)

        Returns:
            Loss tensor (scalar)

        Example:
            >>> loss = method.compute_loss(z1, z2)
            >>> loss.backward()
        """
        ...

    def train_step(
        self,
        data: HyperData,
        data_aug: HyperData | None = None,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Complete training step: forward + loss computation.

        This is a convenience method that combines forward pass and loss computation.
        Can be overridden by subclasses for custom training logic.

        Args:
            data: Original hypergraph data
            data_aug: Optional augmented hypergraph data
            **kwargs: Additional arguments for loss computation

        Returns:
            Loss tensor (scalar)

        Example:
            >>> optimizer = torch.optim.Adam(method.parameters(), lr=0.001)
            >>> loss = method.train_step(data, data_aug)
            >>> optimizer.zero_grad()
            >>> loss.backward()
            >>> optimizer.step()
        """
        z1, z2 = self(data, data_aug)
        return self.compute_loss(z1, z2, **kwargs)

    @torch.no_grad()
    def get_embeddings(self, data: HyperData) -> torch.Tensor:
        """Get node embeddings without gradients.

        This method is used for evaluation and inference.

        Args:
            data: Hypergraph data

        Returns:
            Node embeddings [num_nodes, hidden_dim]

        Example:
            >>> embeddings = method.get_embeddings(data)
            >>> # Use embeddings for downstream tasks
            >>> from sklearn.linear_model import LogisticRegression
            >>> clf = LogisticRegression().fit(embeddings, labels)
        """
        self.eval()
        z, _ = self(data)
        return z
