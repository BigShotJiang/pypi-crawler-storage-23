"""SSL method implementations."""

from pyg_hyper_ssl.methods.base import BaseSSLMethod
from pyg_hyper_ssl.methods.contrastive import HyperGCL, TriCL, TriCLEncoder
from pyg_hyper_ssl.methods.generative import HypeBoy, HypeBoyDecoder

__all__ = [
    "BaseSSLMethod",
    "HypeBoy",
    "HypeBoyDecoder",
    "HyperGCL",
    "TriCL",
    "TriCLEncoder",
]
