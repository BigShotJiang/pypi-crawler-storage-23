"""Contrastive SSL methods for hypergraphs."""

from pyg_hyper_ssl.methods.contrastive.hypergcl import HyperGCL
from pyg_hyper_ssl.methods.contrastive.tricl import TriCL
from pyg_hyper_ssl.methods.contrastive.tricl_encoder import TriCLEncoder
from pyg_hyper_ssl.methods.contrastive.tricl_layer import TriCLConv

__all__ = [
    "HyperGCL",
    "TriCL",
    "TriCLConv",
    "TriCLEncoder",
]
