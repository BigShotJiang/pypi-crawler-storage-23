"""TriCL-specific hypergraph convolution layer.

This implements the ProposedConv layer from the TriCL paper (AAAI'23).
It performs node-to-edge and edge-to-node message passing.
"""

from typing import Any

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch.nn import Parameter
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.dense.linear import Linear
from torch_geometric.nn.inits import zeros
from torch_scatter import scatter_add


class TriCLConv(MessagePassing):
    """Hypergraph convolution layer for TriCL.

    This layer performs two-stage message passing:
    1. Node -> Edge aggregation
    2. Edge -> Node aggregation

    Args:
        in_dim: Input node feature dimension
        hid_dim: Hidden dimension (edge embedding dimension)
        out_dim: Output node feature dimension
        dropout: Dropout probability
        act: Activation function (default: PReLU)
        bias: Whether to add bias
        cached: Whether to cache normalization factors
        row_norm: If True, use row normalization (D^-1). If False, use symmetric normalization (D^-0.5)

    Example:
        >>> conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)
        >>> x = torch.randn(10, 16)  # 10 nodes
        >>> hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        >>> n, e = conv(x, hyperedge_index, num_nodes=10, num_edges=1)
        >>> print(n.shape, e.shape)
        torch.Size([10, 16]) torch.Size([1, 32])
    """

    _cached_norm_n2e: Tensor | None
    _cached_norm_e2n: Tensor | None

    def __init__(
        self,
        in_dim: int,
        hid_dim: int,
        out_dim: int,
        dropout: float = 0.0,
        act: nn.Module | None = None,
        bias: bool = True,
        cached: bool = False,
        row_norm: bool = True,
        **kwargs: Any,
    ) -> None:
        """Initialize TriCL convolution layer."""
        kwargs.setdefault("aggr", "add")
        kwargs.setdefault("flow", "source_to_target")
        super().__init__(node_dim=0, **kwargs)

        self.in_dim = in_dim
        self.hid_dim = hid_dim
        self.out_dim = out_dim
        self.dropout = dropout
        self.act = act if act is not None else nn.PReLU()
        self.cached = cached
        self.row_norm = row_norm

        # Linear transformations
        self.lin_n2e = Linear(in_dim, hid_dim, bias=False, weight_initializer="glorot")
        self.lin_e2n = Linear(hid_dim, out_dim, bias=False, weight_initializer="glorot")

        # Bias terms
        if bias:
            self.bias_n2e = Parameter(torch.empty(hid_dim))
            self.bias_e2n = Parameter(torch.empty(out_dim))
        else:
            self.register_parameter("bias_n2e", None)
            self.register_parameter("bias_e2n", None)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset layer parameters."""
        self.lin_n2e.reset_parameters()
        self.lin_e2n.reset_parameters()
        zeros(self.bias_n2e)
        zeros(self.bias_e2n)
        self._cached_norm_n2e = None
        self._cached_norm_e2n = None

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        num_nodes: int | None = None,
        num_edges: int | None = None,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass through the layer.

        Args:
            x: Node features [num_nodes, in_dim]
            hyperedge_index: Hyperedge connections [2, num_connections]
            num_nodes: Number of nodes
            num_edges: Number of hyperedges

        Returns:
            (node_embeddings, edge_embeddings): Tuple of node and edge embeddings
        """
        if num_nodes is None:
            num_nodes = x.shape[0]
        if num_edges is None and hyperedge_index.numel() > 0:
            num_edges = int(hyperedge_index[1].max()) + 1

        # Get or compute normalization factors
        cache_norm_n2e = self._cached_norm_n2e
        cache_norm_e2n = self._cached_norm_e2n

        if (cache_norm_n2e is None) or (cache_norm_e2n is None):
            # Compute degree matrices
            node_idx, edge_idx = hyperedge_index

            # Node degrees: number of hyperedges each node belongs to
            Dn = scatter_add(
                torch.ones_like(edge_idx, dtype=x.dtype),
                node_idx,
                dim=0,
                dim_size=num_nodes,
            )

            # Edge degrees: number of nodes in each hyperedge
            De = scatter_add(
                torch.ones_like(node_idx, dtype=x.dtype),
                edge_idx,
                dim=0,
                dim_size=num_edges,
            )

            if self.row_norm:
                # Row normalization: D^-1
                Dn_inv = 1.0 / Dn
                Dn_inv[Dn_inv == float("inf")] = 0
                De_inv = 1.0 / De
                De_inv[De_inv == float("inf")] = 0

                norm_n2e = De_inv[edge_idx]
                norm_e2n = Dn_inv[node_idx]
            else:
                # Symmetric normalization: D^-0.5
                Dn_inv_sqrt = Dn.pow(-0.5)
                Dn_inv_sqrt[Dn_inv_sqrt == float("inf")] = 0
                De_inv_sqrt = De.pow(-0.5)
                De_inv_sqrt[De_inv_sqrt == float("inf")] = 0

                norm = De_inv_sqrt[edge_idx] * Dn_inv_sqrt[node_idx]
                norm_n2e = norm
                norm_e2n = norm

            if self.cached:
                self._cached_norm_n2e = norm_n2e
                self._cached_norm_e2n = norm_e2n
        else:
            norm_n2e = cache_norm_n2e
            norm_e2n = cache_norm_e2n

        # Stage 1: Node -> Edge aggregation
        x = self.lin_n2e(x)
        e = self.propagate(  # type: ignore[call-arg]
            hyperedge_index, x=x, norm=norm_n2e, size=(num_nodes, num_edges)
        )

        if self.bias_n2e is not None:
            e = e + self.bias_n2e
        e = self.act(e)
        e = F.dropout(e, p=self.dropout, training=self.training)

        # Stage 2: Edge -> Node aggregation
        x = self.lin_e2n(e)
        n = self.propagate(  # type: ignore[call-arg]
            hyperedge_index.flip([0]), x=x, norm=norm_e2n, size=(num_edges, num_nodes)
        )

        if self.bias_e2n is not None:
            n = n + self.bias_e2n

        return n, e  # Note: n has no activation, e has activation

    def message(self, x_j: Tensor, norm: Tensor) -> Tensor:  # type: ignore[override]
        """Compute messages."""
        return norm.view(-1, 1) * x_j
