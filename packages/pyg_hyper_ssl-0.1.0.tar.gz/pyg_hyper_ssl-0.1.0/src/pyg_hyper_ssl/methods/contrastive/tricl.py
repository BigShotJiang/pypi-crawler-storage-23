"""TriCL: Tri-directional Contrastive Learning for Hypergraphs (AAAI'23).

This module implements TriCL, which performs contrastive learning at three levels:
1. Node-level: Contrastive learning between node embeddings
2. Group-level: Contrastive learning between hyperedge embeddings
3. Membership-level: Contrastive learning between nodes and their incident hyperedges

Reference:
    Huang et al. "Contrastive Learning Meets Homophily: Two Birds with One Stone"
    AAAI 2023.
"""

from typing import Any

import torch
import torch.nn.functional as F
from pyg_hyper_data.data import HyperData
from torch import Tensor, nn

from pyg_hyper_ssl.methods.base import BaseSSLMethod
from pyg_hyper_ssl.methods.contrastive.tricl_encoder import TriCLEncoder


class TriCL(BaseSSLMethod):
    """TriCL: Tri-directional Contrastive Learning for Hypergraphs.

    Args:
        encoder: TriCL encoder
        proj_dim: Projection dimension for node and edge projections
        node_tau: Temperature for node-level contrastive loss
        edge_tau: Temperature for group-level contrastive loss
        membership_tau: Temperature for membership-level contrastive loss
        lambda_n: Weight for node-level loss
        lambda_e: Weight for group-level loss
        lambda_m: Weight for membership-level loss

    Example:
        >>> from pyg_hyper_ssl.methods.contrastive import TriCL, TriCLEncoder
        >>> encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        >>> model = TriCL(encoder=encoder, proj_dim=64)
        >>> # Forward pass returns node and edge embeddings
        >>> data = ...  # HyperData object
        >>> (n1, e1), (n2, e2) = model(data, data_aug)
        >>> # Compute loss
        >>> loss = model.compute_loss((n1, e1), (n2, e2), data.hyperedge_index)
    """

    def __init__(
        self,
        encoder: TriCLEncoder,
        proj_dim: int = 64,
        node_tau: float = 0.5,
        edge_tau: float = 0.5,
        membership_tau: float = 0.1,
        lambda_n: float = 1.0,
        lambda_e: float = 1.0,
        lambda_m: float = 1.0,
        **kwargs: Any,
    ) -> None:
        """Initialize TriCL model."""
        super().__init__(encoder=encoder, **kwargs)

        self.encoder = encoder
        self.node_dim = encoder.node_dim
        self.edge_dim = encoder.edge_dim

        # Node projection head
        self.fc1_n = nn.Linear(self.node_dim, proj_dim)
        self.fc2_n = nn.Linear(proj_dim, self.node_dim)

        # Edge projection head
        self.fc1_e = nn.Linear(self.edge_dim, proj_dim)
        self.fc2_e = nn.Linear(proj_dim, self.edge_dim)

        # Discriminator for membership-level loss
        self.disc = nn.Bilinear(self.node_dim, self.edge_dim, 1)

        # Temperature parameters
        self.node_tau = node_tau
        self.edge_tau = edge_tau
        self.membership_tau = membership_tau

        # Loss weights
        self.lambda_n = lambda_n
        self.lambda_e = lambda_e
        self.lambda_m = lambda_m

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset model parameters."""
        self.encoder.reset_parameters()
        self.fc1_n.reset_parameters()
        self.fc2_n.reset_parameters()
        self.fc1_e.reset_parameters()
        self.fc2_e.reset_parameters()
        self.disc.reset_parameters()

    def forward(  # type: ignore[override]
        self,
        data: HyperData,
        data_aug: HyperData | None = None,
    ) -> tuple[tuple[Tensor, Tensor], tuple[Tensor, Tensor]]:
        """Forward pass through TriCL.

        Args:
            data: Original hypergraph data
            data_aug: Augmented hypergraph data

        Returns:
            ((n1, e1), (n2, e2)): Tuple of (node_embeddings, edge_embeddings) for both views
        """
        # Get num_nodes and num_edges
        num_nodes = data.num_nodes if data.num_nodes is not None else data.x.size(0)
        num_edges = data.num_hyperedges

        # Add self-loops for encoding
        node_idx = torch.arange(0, num_nodes, device=data.x.device)
        edge_idx = torch.arange(num_edges, num_edges + num_nodes, device=data.x.device)
        self_loop = torch.stack([node_idx, edge_idx])
        hyperedge_index_with_selfloop = torch.cat(
            [data.hyperedge_index, self_loop], dim=1
        )

        # Encode first view
        n1, e1_full = self.encoder(
            data.x,
            hyperedge_index_with_selfloop,
            num_nodes,
            num_edges + num_nodes,
        )
        e1 = e1_full[:num_edges]  # Remove self-loop edges

        if data_aug is None:
            # If no augmentation provided, return same embeddings
            return (n1, e1), (n1, e1)

        # Encode second view (augmented)
        num_nodes_aug = (
            data_aug.num_nodes if data_aug.num_nodes is not None else data_aug.x.size(0)
        )
        num_edges_aug = data_aug.num_hyperedges

        node_idx_aug = torch.arange(0, num_nodes_aug, device=data_aug.x.device)
        edge_idx_aug = torch.arange(
            num_edges_aug, num_edges_aug + num_nodes_aug, device=data_aug.x.device
        )
        self_loop_aug = torch.stack([node_idx_aug, edge_idx_aug])
        hyperedge_index_aug_with_selfloop = torch.cat(
            [data_aug.hyperedge_index, self_loop_aug], dim=1
        )

        n2, e2_full = self.encoder(
            data_aug.x,
            hyperedge_index_aug_with_selfloop,
            num_nodes_aug,
            num_edges_aug + num_nodes_aug,
        )
        e2 = e2_full[:num_edges_aug]  # Remove self-loop edges

        return (n1, e1), (n2, e2)

    def node_projection(self, z: Tensor) -> Tensor:
        """Project node embeddings."""
        return self.fc2_n(F.elu(self.fc1_n(z)))

    def edge_projection(self, z: Tensor) -> Tensor:
        """Project edge embeddings."""
        return self.fc2_e(F.elu(self.fc1_e(z)))

    def cosine_similarity(self, z1: Tensor, z2: Tensor) -> Tensor:
        """Compute cosine similarity matrix."""
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)
        return torch.mm(z1, z2.t())

    def disc_similarity(self, z_n: Tensor, z_e: Tensor) -> Tensor:
        """Compute discriminator similarity between nodes and edges."""
        return torch.sigmoid(self.disc(z_n, z_e)).squeeze()

    def f(self, x: Tensor, tau: float) -> Tensor:
        """Apply temperature scaling and exponential."""
        return torch.exp(x / tau)

    def _semi_loss(self, h1: Tensor, h2: Tensor, tau: float) -> Tensor:
        """Semi-contrastive loss (one direction)."""
        between_sim = self.f(self.cosine_similarity(h1, h2), tau)
        return -torch.log(between_sim.diag() / between_sim.sum(1))

    def _contrastive_loss(
        self,
        z1: Tensor,
        z2: Tensor,
        tau: float,
        mean: bool = True,
    ) -> Tensor:
        """Bidirectional contrastive loss."""
        l1 = self._semi_loss(z1, z2, tau)
        l2 = self._semi_loss(z2, z1, tau)

        loss = (l1 + l2) * 0.5
        return loss.mean() if mean else loss.sum()

    def node_level_loss(
        self,
        n1: Tensor,
        n2: Tensor,
        mean: bool = True,
    ) -> Tensor:
        """Compute node-level contrastive loss.

        Args:
            n1: Node embeddings from view 1 [num_nodes, node_dim]
            n2: Node embeddings from view 2 [num_nodes, node_dim]
            mean: Whether to take mean (True) or sum (False)

        Returns:
            Node-level contrastive loss
        """
        # Project node embeddings
        n1_proj = self.node_projection(n1)
        n2_proj = self.node_projection(n2)

        # Compute contrastive loss
        return self._contrastive_loss(n1_proj, n2_proj, self.node_tau, mean)

    def group_level_loss(
        self,
        e1: Tensor,
        e2: Tensor,
        mean: bool = True,
    ) -> Tensor:
        """Compute group-level (hyperedge) contrastive loss.

        Args:
            e1: Edge embeddings from view 1 [num_edges, edge_dim]
            e2: Edge embeddings from view 2 [num_edges, edge_dim]
            mean: Whether to take mean (True) or sum (False)

        Returns:
            Group-level contrastive loss
        """
        # Project edge embeddings
        e1_proj = self.edge_projection(e1)
        e2_proj = self.edge_projection(e2)

        # Compute contrastive loss
        return self._contrastive_loss(e1_proj, e2_proj, self.edge_tau, mean)

    def membership_level_loss(
        self,
        n: Tensor,
        e: Tensor,
        hyperedge_index: Tensor,
        mean: bool = True,
    ) -> Tensor:
        """Compute membership-level contrastive loss.

        This loss encourages nodes to be similar to their incident hyperedges.

        Args:
            n: Node embeddings [num_nodes, node_dim]
            e: Edge embeddings [num_edges, edge_dim]
            hyperedge_index: Hyperedge connections [2, num_connections]
            mean: Whether to take mean (True) or sum (False)

        Returns:
            Membership-level contrastive loss
        """
        # Create negative samples by permuting
        e_perm = e[torch.randperm(e.size(0))]
        n_perm = n[torch.randperm(n.size(0))]

        # Positive samples: actual node-edge pairs
        pos = self.f(
            self.disc_similarity(n[hyperedge_index[0]], e[hyperedge_index[1]]),
            self.membership_tau,
        )

        # Negative samples: random edge for each node
        neg_n = self.f(
            self.disc_similarity(n[hyperedge_index[0]], e_perm[hyperedge_index[1]]),
            self.membership_tau,
        )

        # Negative samples: random node for each edge
        neg_e = self.f(
            self.disc_similarity(n_perm[hyperedge_index[0]], e[hyperedge_index[1]]),
            self.membership_tau,
        )

        # Compute losses
        loss_n = -torch.log(pos / (pos + neg_n))
        loss_e = -torch.log(pos / (pos + neg_e))

        # Remove NaN values (can occur with numerical instability)
        loss_n = loss_n[~torch.isnan(loss_n)]
        loss_e = loss_e[~torch.isnan(loss_e)]

        loss = loss_n + loss_e
        return loss.mean() if mean else loss.sum()

    def compute_loss(  # type: ignore[override]
        self,
        z1: tuple[Tensor, Tensor],
        z2: tuple[Tensor, Tensor],
        hyperedge_index: Tensor | None = None,
        **kwargs: Any,
    ) -> Tensor:
        """Compute total TriCL loss.

        Args:
            z1: (node_embeddings, edge_embeddings) from view 1
            z2: (node_embeddings, edge_embeddings) from view 2
            hyperedge_index: Hyperedge connections for membership loss
            **kwargs: Additional arguments

        Returns:
            Total loss: lambda_n * L_node + lambda_e * L_group + lambda_m * L_membership
        """
        n1, e1 = z1
        n2, e2 = z2

        # Node-level contrastive loss
        loss_node = self.node_level_loss(n1, n2)

        # Group-level contrastive loss
        loss_group = self.group_level_loss(e1, e2)

        # Membership-level contrastive loss
        if hyperedge_index is None:
            msg = "hyperedge_index is required for membership loss"
            raise ValueError(msg)

        loss_membership = self.membership_level_loss(n1, e1, hyperedge_index)

        # Total loss
        return (
            self.lambda_n * loss_node
            + self.lambda_e * loss_group
            + self.lambda_m * loss_membership
        )

    def train_step(
        self,
        data: HyperData,
        data_aug: HyperData | None = None,
        **kwargs: Any,
    ) -> Tensor:
        """Complete training step.

        Args:
            data: Original hypergraph data
            data_aug: Augmented hypergraph data
            **kwargs: Additional arguments

        Returns:
            Total loss
        """
        (n1, e1), (n2, e2) = self(data, data_aug)
        return self.compute_loss((n1, e1), (n2, e2), data.hyperedge_index, **kwargs)

    @torch.no_grad()
    def get_embeddings(self, data: HyperData) -> Tensor:
        """Get node embeddings for downstream tasks.

        Args:
            data: Hypergraph data

        Returns:
            Node embeddings [num_nodes, node_dim]
        """
        self.eval()
        (n, _), _ = self(data)
        return n
