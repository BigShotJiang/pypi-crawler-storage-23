"""HyperGCL: Contrastive Learning for Hypergraphs (NeurIPS'22).

This module implements HyperGCL with fabricated augmentations,
which performs node-level contrastive learning on hypergraphs.

Reference:
    Wei et al. "Augmentations in Hypergraph Contrastive Learning:
    Fabricated and Generative" NeurIPS 2022.
"""

from typing import Any

import torch
import torch.nn.functional as F
from pyg_hyper_data.data import HyperData
from torch import Tensor, nn

from pyg_hyper_ssl.methods.base import BaseSSLMethod


class HyperGCL(BaseSSLMethod):
    """HyperGCL: Contrastive Learning for Hypergraphs.

    HyperGCL performs node-level contrastive learning using InfoNCE loss.
    It can work with any hypergraph encoder and uses simple fabricated
    augmentations (edge drop, feature mask, etc.).

    Args:
        encoder: Hypergraph encoder (can be any encoder from pyg-hyper-nn)
        proj_hidden: Hidden dimension for projection head
        proj_out: Output dimension for projection head
        tau: Temperature parameter for InfoNCE loss

    Example:
        >>> from pyg_hyper_nn.models import HGNN
        >>> from pyg_hyper_ssl.methods.contrastive import HyperGCL
        >>> from pyg_hyper_ssl.encoders import EncoderWrapper
        >>>
        >>> # Wrap a pyg-hyper-nn model
        >>> encoder = EncoderWrapper(
        ...     model_class=HGNN,
        ...     in_channels=16,
        ...     hidden_channels=64,
        ...     num_layers=2
        ... )
        >>> model = HyperGCL(encoder=encoder, proj_hidden=64, proj_out=64)
        >>>
        >>> # Forward pass returns node embeddings
        >>> data = ...  # HyperData object
        >>> z1, z2 = model(data, data_aug)
        >>>
        >>> # Compute loss
        >>> loss = model.compute_loss(z1, z2)
    """

    def __init__(
        self,
        encoder: nn.Module,
        proj_hidden: int = 64,
        proj_out: int = 64,
        tau: float = 0.5,
        **kwargs: Any,
    ) -> None:
        """Initialize HyperGCL model."""
        super().__init__(encoder=encoder, **kwargs)

        self.encoder = encoder
        self.tau = tau

        # Get encoder output dimension
        # Try to infer from encoder attributes
        encoder_dim: int
        if hasattr(encoder, "out_channels"):
            out_ch = encoder.out_channels
            encoder_dim = int(out_ch) if isinstance(out_ch, (int, float)) else 64
        elif hasattr(encoder, "hidden_channels"):
            hid_ch = encoder.hidden_channels
            encoder_dim = int(hid_ch) if isinstance(hid_ch, (int, float)) else 64
        elif hasattr(encoder, "node_dim"):
            node_d = encoder.node_dim
            encoder_dim = int(node_d) if isinstance(node_d, (int, float)) else 64
        else:
            msg = (
                "Cannot infer encoder output dimension. "
                "Please ensure encoder has 'out_channels', 'hidden_channels', "
                "or 'node_dim' attribute."
            )
            raise ValueError(msg)

        # Projection head (MLP with ReLU)
        self.projection = nn.Sequential(
            nn.Linear(encoder_dim, proj_hidden),
            nn.ReLU(inplace=True),
            nn.Linear(proj_hidden, proj_out),
        )

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset model parameters."""
        # Reset encoder if it has reset_parameters method
        if hasattr(self.encoder, "reset_parameters") and callable(
            self.encoder.reset_parameters
        ):
            self.encoder.reset_parameters()

        # Reset projection head
        for layer in self.projection:
            if hasattr(layer, "reset_parameters") and callable(layer.reset_parameters):
                layer.reset_parameters()

    def project(self, z: Tensor) -> Tensor:
        """Apply projection head to embeddings.

        Args:
            z: Node embeddings [num_nodes, encoder_dim]

        Returns:
            Projected embeddings [num_nodes, proj_out]
        """
        return self.projection(z)

    def forward(
        self,
        data: HyperData,
        data_aug: HyperData | None = None,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass through HyperGCL.

        Args:
            data: Original hypergraph data
            data_aug: Augmented hypergraph data

        Returns:
            (z1, z2): Tuple of projected node embeddings for both views
        """
        # Encode first view
        if hasattr(self.encoder, "forward_from_data") and callable(
            self.encoder.forward_from_data
        ):
            result1 = self.encoder.forward_from_data(data)
        else:
            msg = "Encoder must have forward_from_data method"
            raise AttributeError(msg)
        # Handle both tuple and single tensor returns
        h1 = result1[0] if isinstance(result1, tuple) else result1
        z1 = self.project(h1)

        if data_aug is None:
            # If no augmentation provided, return same embeddings
            return z1, z1

        # Encode second view (augmented)
        if hasattr(self.encoder, "forward_from_data") and callable(
            self.encoder.forward_from_data
        ):
            result2 = self.encoder.forward_from_data(data_aug)
        else:
            msg = "Encoder must have forward_from_data method"
            raise AttributeError(msg)
        h2 = result2[0] if isinstance(result2, tuple) else result2
        z2 = self.project(h2)

        return z1, z2

    def sim(self, z1: Tensor, z2: Tensor) -> Tensor:
        """Compute cosine similarity matrix.

        Args:
            z1: Embeddings [N, D]
            z2: Embeddings [M, D]

        Returns:
            Similarity matrix [N, M]
        """
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)
        return torch.mm(z1, z2.t())

    def semi_loss(self, z1: Tensor, z2: Tensor) -> Tensor:
        """Compute semi-contrastive loss (one direction).

        This is the InfoNCE loss in one direction.

        Args:
            z1: Embeddings from view 1 [N, D]
            z2: Embeddings from view 2 [N, D]

        Returns:
            Semi-contrastive loss [N]
        """

        def f(x: Tensor) -> Tensor:
            return torch.exp(x / self.tau)

        # Compute similarities
        refl_sim = f(self.sim(z1, z1))  # [N, N]
        between_sim = f(self.sim(z1, z2))  # [N, N]

        # InfoNCE loss
        # Numerator: similarity between positive pairs (diagonal)
        # Denominator: sum of all similarities minus self-similarity
        loss = -torch.log(
            between_sim.diag()
            / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag())
        )

        return loss

    def compute_loss(
        self,
        z1: Tensor,
        z2: Tensor,
        mean: bool = True,
        **kwargs: Any,
    ) -> Tensor:
        """Compute bidirectional contrastive loss.

        Args:
            z1: Projected embeddings from view 1 [N, D]
            z2: Projected embeddings from view 2 [N, D]
            mean: Whether to take mean (True) or sum (False)
            **kwargs: Additional keyword arguments (unused, for compatibility)

        Returns:
            Contrastive loss (scalar)
        """
        # Bidirectional loss
        l1 = self.semi_loss(z1, z2)
        l2 = self.semi_loss(z2, z1)

        loss = (l1 + l2) * 0.5
        return loss.mean() if mean else loss.sum()

    def train_step(  # type: ignore[override]
        self,
        data: HyperData,
        data_aug: HyperData,
        optimizer: torch.optim.Optimizer | None = None,
    ) -> Tensor:
        """Perform a single training step.

        Args:
            data: Original hypergraph data
            data_aug: Augmented hypergraph data
            optimizer: Optimizer (if None, only returns loss without update)

        Returns:
            Loss value
        """
        z1, z2 = self.forward(data, data_aug)
        loss = self.compute_loss(z1, z2)

        if optimizer is not None:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        return loss

    def get_embeddings(self, data: HyperData) -> Tensor:
        """Get node embeddings for downstream tasks.

        Args:
            data: Hypergraph data

        Returns:
            Node embeddings [num_nodes, encoder_dim]
        """
        self.eval()
        with torch.no_grad():
            if hasattr(self.encoder, "forward_from_data") and callable(
                self.encoder.forward_from_data
            ):
                result = self.encoder.forward_from_data(data)
            else:
                msg = "Encoder must have forward_from_data method"
                raise AttributeError(msg)
            # Handle both tuple and single tensor returns
            h = result[0] if isinstance(result, tuple) else result
        return h

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"encoder={self.encoder.__class__.__name__}, "
            f"tau={self.tau})"
        )
