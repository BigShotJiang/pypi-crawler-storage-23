"""TriCL encoder for hypergraphs."""

from torch import Tensor, nn

from pyg_hyper_ssl.methods.contrastive.tricl_layer import TriCLConv


class TriCLEncoder(nn.Module):
    """Hypergraph encoder for TriCL.

    This encoder stacks multiple TriCLConv layers to learn node and edge embeddings.

    Args:
        in_dim: Input node feature dimension
        edge_dim: Edge embedding dimension
        node_dim: Node embedding dimension
        num_layers: Number of convolution layers
        act: Activation function (default: PReLU)
        dropout: Dropout probability
        cached: Whether to cache normalization factors

    Example:
        >>> encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        >>> x = torch.randn(10, 16)
        >>> hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        >>> n, e = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)
        >>> print(n.shape, e.shape)
        torch.Size([10, 64]) torch.Size([1, 32])
    """

    def __init__(
        self,
        in_dim: int,
        edge_dim: int,
        node_dim: int,
        num_layers: int = 2,
        act: nn.Module | None = None,
        dropout: float = 0.0,
        cached: bool = False,
    ) -> None:
        """Initialize TriCL encoder."""
        super().__init__()

        self.in_dim = in_dim
        self.edge_dim = edge_dim
        self.node_dim = node_dim
        self.num_layers = num_layers
        self.act = act if act is not None else nn.PReLU()
        self.dropout = dropout

        self.convs = nn.ModuleList()

        if num_layers == 1:
            # Single layer
            self.convs.append(
                TriCLConv(
                    in_dim=in_dim,
                    hid_dim=edge_dim,
                    out_dim=node_dim,
                    dropout=dropout,
                    act=self.act,
                    cached=cached,
                )
            )
        else:
            # First layer: in_dim -> edge_dim -> node_dim
            self.convs.append(
                TriCLConv(
                    in_dim=in_dim,
                    hid_dim=edge_dim,
                    out_dim=node_dim,
                    dropout=dropout,
                    act=self.act,
                    cached=cached,
                )
            )

            # Middle layers: node_dim -> edge_dim -> node_dim
            for _ in range(num_layers - 2):
                self.convs.append(
                    TriCLConv(
                        in_dim=node_dim,
                        hid_dim=edge_dim,
                        out_dim=node_dim,
                        dropout=dropout,
                        act=self.act,
                        cached=cached,
                    )
                )

            # Last layer: node_dim -> edge_dim -> node_dim
            self.convs.append(
                TriCLConv(
                    in_dim=node_dim,
                    hid_dim=edge_dim,
                    out_dim=node_dim,
                    dropout=dropout,
                    act=self.act,
                    cached=cached,
                )
            )

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset encoder parameters."""
        for conv in self.convs:
            if hasattr(conv, "reset_parameters") and callable(conv.reset_parameters):
                conv.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        num_nodes: int,
        num_edges: int,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass through encoder.

        Args:
            x: Node features [num_nodes, in_dim]
            hyperedge_index: Hyperedge connections [2, num_connections]
            num_nodes: Number of nodes
            num_edges: Number of hyperedges

        Returns:
            (node_embeddings, edge_embeddings): Tuple of node and edge embeddings
                - node_embeddings: [num_nodes, node_dim]
                - edge_embeddings: [num_edges, edge_dim]
        """
        for i in range(self.num_layers):
            n, e = self.convs[i](x, hyperedge_index, num_nodes, num_edges)
            x = self.act(n)  # Apply activation to node features for next layer

        # Return final node and edge embeddings
        # Note: node embeddings have activation, edge embeddings already have activation from conv
        return n, e

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"in_dim={self.in_dim}, "
            f"edge_dim={self.edge_dim}, "
            f"node_dim={self.node_dim}, "
            f"num_layers={self.num_layers})"
        )
