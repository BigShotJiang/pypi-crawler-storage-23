"""HypeBoy: Generative Self-Supervised Learning on Hypergraphs (ICLR'24).

This module implements HypeBoy, a two-stage generative SSL method:
1. Feature Reconstruction: Mask and reconstruct node features
2. Hyperedge Filling: Predict missing hyperedges

Reference:
    Kim et al. "HypeBoy: Generative Self-Supervised Representation Learning
    on Hypergraphs" ICLR 2024.
"""

from typing import Any

import torch
import torch.nn.functional as F
from pyg_hyper_data.data import HyperData
from torch import Tensor, nn
from torch_scatter import scatter

from pyg_hyper_ssl.methods.base import BaseSSLMethod


class HypeBoyDecoder(nn.Module):
    """Decoder for feature reconstruction in HypeBoy.

    This decoder is used in the first stage of HypeBoy to reconstruct
    masked node features. It uses learnable mask tokens.

    Args:
        encoder: The encoder module (any hypergraph encoder)
        in_dim: Input dimension (encoder output dimension)
        out_dim: Output dimension (original feature dimension)
        hidden_dim: Hidden dimension for decoder layers
        num_layers: Number of decoder layers
        dropout: Dropout probability

    Example:
        >>> encoder = TriCLEncoder(in_dim=128, edge_dim=64, node_dim=64)
        >>> decoder = HypeBoyDecoder(
        ...     encoder=encoder,
        ...     in_dim=64,
        ...     out_dim=128,
        ...     hidden_dim=64,
        ...     num_layers=2
        ... )
    """

    def __init__(
        self,
        encoder: nn.Module,
        in_dim: int,
        out_dim: int,
        hidden_dim: int = 128,
        num_layers: int = 2,
        dropout: float = 0.5,
    ) -> None:
        """Initialize HypeBoyDecoder."""
        super().__init__()

        self.encoder = encoder
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.dropout = dropout

        # Learnable mask tokens
        self.input_mask = nn.Parameter(torch.zeros(out_dim))
        self.embedding_mask = nn.Parameter(torch.zeros(in_dim))

        # Decoder layers
        layers = []
        current_dim = in_dim
        for _ in range(num_layers - 1):
            layers.append(nn.Linear(current_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            current_dim = hidden_dim
        layers.append(nn.Linear(current_dim, out_dim))

        self.decoder = nn.Sequential(*layers)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset decoder parameters."""
        nn.init.zeros_(self.input_mask)
        nn.init.zeros_(self.embedding_mask)
        for layer in self.decoder:
            if hasattr(layer, "reset_parameters") and callable(layer.reset_parameters):
                layer.reset_parameters()

    def forward(self, z: Tensor) -> Tensor:
        """Decode embeddings back to features.

        Args:
            z: Node embeddings [num_nodes, in_dim]

        Returns:
            Reconstructed features [num_nodes, out_dim]
        """
        return self.decoder(z)


class HypeBoy(BaseSSLMethod):
    """HypeBoy: Generative SSL for Hypergraphs (ICLR'24).

    HypeBoy performs two-stage generative self-supervised learning:
    1. Feature Reconstruction: Mask node features and reconstruct them
    2. Hyperedge Filling: Drop hyperedges and predict them via contrastive loss

    Args:
        encoder: Hypergraph encoder
        decoder: Feature reconstruction decoder
        proj_hidden: Hidden dimension for projection heads
        proj_out: Output dimension for projection heads
        feature_recon_epochs: Number of epochs for feature reconstruction
        hyperedge_fill_epochs: Number of epochs for hyperedge filling
        feature_mask_prob: Probability of masking features (stage 1)
        edge_drop_prob_stage1: Edge drop probability (stage 1)
        feature_drop_prob_stage2: Feature drop probability (stage 2)
        edge_drop_prob_stage2: Edge drop probability (stage 2)
        lr_stage1: Learning rate for stage 1
        lr_stage2: Learning rate for stage 2
        weight_decay: Weight decay for optimizer

    Example:
        >>> from pyg_hyper_nn.models import HGNN
        >>> from pyg_hyper_ssl.encoders import EncoderWrapper
        >>> from pyg_hyper_ssl.methods.generative import HypeBoy, HypeBoyDecoder
        >>>
        >>> encoder = EncoderWrapper(
        ...     model_class=HGNN,
        ...     in_channels=128,
        ...     hidden_channels=64,
        ...     num_layers=2
        ... )
        >>> decoder = HypeBoyDecoder(
        ...     encoder=encoder,
        ...     in_dim=64,
        ...     out_dim=128,
        ...     hidden_dim=64
        ... )
        >>> model = HypeBoy(encoder=encoder, decoder=decoder)
    """

    def __init__(
        self,
        encoder: nn.Module,
        decoder: HypeBoyDecoder,
        proj_hidden: int = 128,
        proj_out: int = 128,
        feature_recon_epochs: int = 300,
        hyperedge_fill_epochs: int = 200,
        feature_mask_prob: float = 0.5,
        edge_drop_prob_stage1: float = 0.2,
        feature_drop_prob_stage2: float = 0.4,
        edge_drop_prob_stage2: float = 0.9,
        lr_stage1: float = 1e-3,
        lr_stage2: float = 1e-3,
        weight_decay: float = 1e-6,
        **kwargs: Any,
    ) -> None:
        """Initialize HypeBoy."""
        super().__init__(encoder=encoder, **kwargs)

        self.encoder = encoder
        self.decoder = decoder
        self.feature_recon_epochs = feature_recon_epochs
        self.hyperedge_fill_epochs = hyperedge_fill_epochs
        self.feature_mask_prob = feature_mask_prob
        self.edge_drop_prob_stage1 = edge_drop_prob_stage1
        self.feature_drop_prob_stage2 = feature_drop_prob_stage2
        self.edge_drop_prob_stage2 = edge_drop_prob_stage2
        self.lr_stage1 = lr_stage1
        self.lr_stage2 = lr_stage2
        self.weight_decay = weight_decay

        # Get encoder output dimension
        encoder_dim: int
        if hasattr(encoder, "out_channels"):
            out_ch = encoder.out_channels
            encoder_dim = int(out_ch) if isinstance(out_ch, (int, float)) else 64
        elif hasattr(encoder, "hidden_channels"):
            hid_ch = encoder.hidden_channels
            encoder_dim = int(hid_ch) if isinstance(hid_ch, (int, float)) else 64
        elif hasattr(encoder, "node_dim"):
            node_d = encoder.node_dim
            encoder_dim = int(node_d) if isinstance(node_d, (int, float)) else 64
        else:
            msg = (
                "Cannot infer encoder output dimension. "
                "Please ensure encoder has 'out_channels', 'hidden_channels', "
                "or 'node_dim' attribute."
            )
            raise ValueError(msg)

        # Projection heads for hyperedge filling (stage 2)
        self.head1 = nn.Sequential(
            nn.Linear(encoder_dim, proj_hidden),
            nn.ReLU(),
            nn.Linear(proj_hidden, proj_out),
        )
        self.head2 = nn.Sequential(
            nn.Linear(encoder_dim, proj_hidden),
            nn.ReLU(),
            nn.Linear(proj_hidden, proj_out),
        )

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset model parameters."""
        if hasattr(self.encoder, "reset_parameters") and callable(
            self.encoder.reset_parameters
        ):
            self.encoder.reset_parameters()

        self.decoder.reset_parameters()

        for head in [self.head1, self.head2]:
            for layer in head:
                if hasattr(layer, "reset_parameters") and callable(
                    layer.reset_parameters
                ):
                    layer.reset_parameters()

    def forward(
        self, data: HyperData, data_aug: HyperData | None = None
    ) -> tuple[Tensor, Tensor]:  # type: ignore[override]
        """Forward pass through HypeBoy.

        Args:
            data: Original hypergraph data
            data_aug: Augmented hypergraph data (unused, for compatibility)

        Returns:
            (embeddings, reconstructed_features): Node embeddings and reconstructed features
        """
        if hasattr(self.encoder, "forward_from_data") and callable(
            self.encoder.forward_from_data
        ):
            result = self.encoder.forward_from_data(data)
        else:
            msg = "Encoder must have forward_from_data method"
            raise AttributeError(msg)

        # Handle tuple/single tensor returns
        h = result[0] if isinstance(result, tuple) else result

        # Reconstruct features
        x_recon = self.decoder(h)

        return h, x_recon

    def feature_reconstruction_loss(
        self, x_original: Tensor, x_reconstructed: Tensor, masked_indices: Tensor
    ) -> Tensor:
        """Compute feature reconstruction loss (cosine similarity).

        Args:
            x_original: Original features [N, D]
            x_reconstructed: Reconstructed features [N, D]
            masked_indices: Indices of masked nodes

        Returns:
            Reconstruction loss (scalar)
        """
        cos = nn.CosineSimilarity(dim=1, eps=1e-6)
        return torch.mean(
            1 - cos(x_original[masked_indices], x_reconstructed[masked_indices])
        )

    def hyperedge_filling_loss(  # type: ignore[override]
        self,
        z: Tensor,
        hyperedge_index: Tensor,
        head1: nn.Module | None = None,
        head2: nn.Module | None = None,
    ) -> Tensor:
        """Compute hyperedge filling loss (contrastive loss).

        This loss predicts masked nodes in hyperedges using contrastive learning.

        Args:
            z: Node embeddings [N, D]
            hyperedge_index: Hyperedge index [2, E]
            head1: Projection head for nodes (if None, use self.head1)
            head2: Projection head for aggregated embeddings (if None, use self.head2)

        Returns:
            Contrastive loss (scalar)
        """
        if head1 is None:
            head1 = self.head1
        if head2 is None:
            head2 = self.head2

        # Build hyperedge membership structure
        # For each node in a hyperedge, aggregate other nodes
        edge_dict = self._build_edge_dict(hyperedge_index)

        push_vs = []  # Nodes to aggregate
        push_idx = []  # Target index for aggregation
        pull_src = []  # Source node to predict

        eidx = 0
        for edge_nodes in edge_dict.values():
            if len(edge_nodes) <= 1:
                continue
            for k in range(len(edge_nodes)):
                # Exclude one node and aggregate others
                push_vs.extend(edge_nodes[:k] + edge_nodes[k + 1 :])
                push_idx.extend([eidx] * (len(edge_nodes) - 1))
                pull_src.append(edge_nodes[k])
                eidx += 1

        if eidx == 0:
            return torch.tensor(0.0, device=z.device)

        # Normalize node embeddings
        norm_z = F.normalize(head1(z), p=2.0, dim=1, eps=1e-12)

        # Aggregate embeddings for each hyperedge
        target = torch.tensor(push_idx, device=z.device)
        agg_z = scatter(src=z[push_vs, :], index=target, reduce="sum", dim=0)
        agg_z = F.normalize(head2(agg_z), p=2.0, dim=1, eps=1e-12)

        # Compute similarity matrix
        denom = torch.mm(agg_z, norm_z.transpose(1, 0))

        # Contrastive loss (InfoNCE style)
        loss1 = -torch.sum(denom[range(len(pull_src)), pull_src])
        loss2 = torch.sum(torch.logsumexp(denom, dim=1))

        return loss1 + loss2

    def _build_edge_dict(self, hyperedge_index: Tensor) -> dict[int, list[int]]:
        """Build dictionary mapping edge index to list of nodes.

        Args:
            hyperedge_index: Hyperedge index [2, E]

        Returns:
            Dictionary {edge_id: [node_ids]}
        """
        edge_index = hyperedge_index.cpu().numpy()
        edge_dict = {}

        current_edge = -1
        current_nodes = []

        for i in range(edge_index.shape[1]):
            node_idx = int(edge_index[0][i])
            edge_idx = int(edge_index[1][i])

            if edge_idx != current_edge:
                if current_nodes and len(current_nodes) > 1:
                    edge_dict[current_edge] = current_nodes
                current_edge = edge_idx
                current_nodes = [node_idx]
            else:
                current_nodes.append(node_idx)

        # Add last edge
        if current_nodes and len(current_nodes) > 1:
            edge_dict[current_edge] = current_nodes

        return edge_dict

    def compute_loss(  # type: ignore[override]
        self, stage: str = "feature_recon", **kwargs: Any
    ) -> Tensor:
        """Compute loss for the specified stage.

        Args:
            stage: Either "feature_recon" or "hyperedge_fill"
            **kwargs: Additional arguments for the loss function

        Returns:
            Loss (scalar)
        """
        if stage == "feature_recon":
            return self.feature_reconstruction_loss(**kwargs)
        if stage == "hyperedge_fill":
            return self.hyperedge_filling_loss(**kwargs)
        msg = f"Unknown stage: {stage}"
        raise ValueError(msg)

    def get_embeddings(self, data: HyperData) -> Tensor:
        """Get node embeddings for downstream tasks.

        Args:
            data: Hypergraph data

        Returns:
            Node embeddings [num_nodes, encoder_dim]
        """
        self.eval()
        with torch.no_grad():
            if hasattr(self.encoder, "forward_from_data") and callable(
                self.encoder.forward_from_data
            ):
                result = self.encoder.forward_from_data(data)
            else:
                msg = "Encoder must have forward_from_data method"
                raise AttributeError(msg)
            h = result[0] if isinstance(result, tuple) else result
        return h

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"encoder={self.encoder.__class__.__name__}, "
            f"feature_recon_epochs={self.feature_recon_epochs}, "
            f"hyperedge_fill_epochs={self.hyperedge_fill_epochs})"
        )
