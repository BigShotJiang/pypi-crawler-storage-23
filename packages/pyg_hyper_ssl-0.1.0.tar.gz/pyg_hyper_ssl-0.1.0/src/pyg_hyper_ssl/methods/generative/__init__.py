"""Generative SSL methods for hypergraphs."""

from pyg_hyper_ssl.methods.generative.hypeboy import HypeBoy, HypeBoyDecoder

__all__ = [
    "HypeBoy",
    "HypeBoyDecoder",
]
