"""Contrastive loss functions for SSL."""

from typing import Any

import torch
import torch.nn.functional as F

from pyg_hyper_ssl.losses.base import BaseLoss


class InfoNCE(BaseLoss):
    """InfoNCE (Normalized Temperature-scaled Cross Entropy) loss.

    This is the standard contrastive loss used in SimCLR and many other
    self-supervised learning methods. It encourages embeddings from augmented
    views of the same node to be similar while being dissimilar to other nodes.

    Reference:
        Chen et al. "A Simple Framework for Contrastive Learning of Visual
        Representations" (SimCLR), ICML 2020.

    Example:
        >>> from pyg_hyper_ssl.losses.contrastive import InfoNCE
        >>>
        >>> loss_fn = InfoNCE(temperature=0.5)
        >>> z1 = F.normalize(torch.randn(100, 64), dim=1)
        >>> z2 = F.normalize(torch.randn(100, 64), dim=1)
        >>> loss = loss_fn(z1, z2)
    """

    def __init__(self, temperature: float = 0.5) -> None:
        """Initialize InfoNCE loss.

        Args:
            temperature: Temperature parameter for scaling similarities.
                        Lower temperature makes the model more confident.
                        Typical values: 0.1 - 1.0

        Raises:
            ValueError: If temperature <= 0
        """
        super().__init__(temperature=temperature)

        if temperature <= 0:
            msg = f"temperature must be positive, got {temperature}"
            raise ValueError(msg)

        self.temperature = temperature

    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Compute InfoNCE loss.

        Args:
            z1: First view embeddings [N, D]
            z2: Second view embeddings [N, D]
            **kwargs: Unused (for interface compatibility)

        Returns:
            Scalar loss value

        Note:
            Embeddings should be L2-normalized before passing to this loss.
            If not normalized, the loss will still work but may be suboptimal.
        """
        # Ensure embeddings are on the same device
        device = z1.device
        z2 = z2.to(device)

        batch_size = z1.size(0)

        # Normalize embeddings (important for cosine similarity)
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)

        # Compute similarity matrix: [2N, 2N]
        # Concatenate z1 and z2: [2N, D]
        z = torch.cat([z1, z2], dim=0)

        # Cosine similarity matrix: [2N, 2N]
        sim_matrix = torch.mm(z, z.t()) / self.temperature

        # Create positive pair mask
        # For each sample i in z1, its positive pair is i+N in z2
        # For each sample i in z2, its positive pair is i-N in z1
        pos_mask = torch.zeros(
            (2 * batch_size, 2 * batch_size), dtype=torch.bool, device=device
        )
        pos_mask[range(batch_size), range(batch_size, 2 * batch_size)] = True
        pos_mask[range(batch_size, 2 * batch_size), range(batch_size)] = True

        # Create negative pair mask (all pairs except diagonal and positives)
        neg_mask = torch.ones(
            (2 * batch_size, 2 * batch_size), dtype=torch.bool, device=device
        )
        neg_mask[range(2 * batch_size), range(2 * batch_size)] = (
            False  # Remove diagonal
        )
        neg_mask = neg_mask & ~pos_mask

        # Compute loss for each sample
        # For each sample, we have:
        # - 1 positive pair (numerator)
        # - 2N-2 negative pairs (denominator)

        # Extract positive similarities
        pos_sim = sim_matrix[pos_mask].view(2 * batch_size, 1)

        # Extract negative similarities
        neg_sim = sim_matrix[neg_mask].view(2 * batch_size, -1)

        # Concatenate positive and negative similarities
        logits = torch.cat([pos_sim, neg_sim], dim=1)

        # Labels: positive pair is always index 0
        labels = torch.zeros(2 * batch_size, dtype=torch.long, device=device)

        # Cross-entropy loss
        return F.cross_entropy(logits, labels)


class NTXent(InfoNCE):
    """NT-Xent (Normalized Temperature-scaled Cross Entropy) loss.

    This is an alias for InfoNCE, commonly used in the literature.
    NT-Xent and InfoNCE refer to the same loss function.

    Example:
        >>> from pyg_hyper_ssl.losses.contrastive import NTXent
        >>>
        >>> loss_fn = NTXent(temperature=0.5)
        >>> loss = loss_fn(z1, z2)
    """


class CosineSimilarityLoss(BaseLoss):
    """Simple cosine similarity loss for contrastive learning.

    This is a simpler alternative to InfoNCE that directly maximizes
    cosine similarity between positive pairs.

    Example:
        >>> from pyg_hyper_ssl.losses.contrastive import CosineSimilarityLoss
        >>>
        >>> loss_fn = CosineSimilarityLoss()
        >>> z1 = torch.randn(100, 64)
        >>> z2 = torch.randn(100, 64)
        >>> loss = loss_fn(z1, z2)
    """

    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Compute negative cosine similarity loss.

        Args:
            z1: First view embeddings [N, D]
            z2: Second view embeddings [N, D]
            **kwargs: Unused

        Returns:
            Scalar loss value (1 - cosine_similarity)
        """
        # Normalize embeddings
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)

        # Compute cosine similarity
        cos_sim = (z1 * z2).sum(dim=1).mean()

        # Return negative similarity (we want to maximize similarity)
        return 1 - cos_sim
