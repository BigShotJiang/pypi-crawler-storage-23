"""Fairness-aware losses for hypergraph SSL.

This module implements losses for fairness-aware self-supervised learning,
particularly CCA (Canonical Correlation Analysis) loss used in SE-HSSL.
"""

import torch
from torch import Tensor, nn


class CCALoss(nn.Module):
    """Canonical Correlation Analysis (CCA) Loss.

    CCA loss maximizes the correlation between two views while decorrelating
    features within each view. Used in SE-HSSL for fairness-aware learning.

    The loss consists of two terms:
    1. Invariance term: Maximize diagonal of cross-correlation matrix
    2. Decorrelation term: Minimize off-diagonal of auto-correlation matrices

    Args:
        lambda_decorr: Weight for decorrelation term

    Reference:
        SE-HSSL: "Structure-Enhanced Hypergraph Self-Supervised Learning"
        contrast_loss.py: cca_loss function
    """

    def __init__(self, lambda_decorr: float = 0.005) -> None:
        """Initialize CCA Loss."""
        super().__init__()
        self.lambda_decorr = lambda_decorr

    def forward(self, z1: Tensor, z2: Tensor) -> Tensor:
        """Compute CCA loss between two views.

        Args:
            z1: Embeddings from view 1 [N, D]
            z2: Embeddings from view 2 [N, D]

        Returns:
            CCA loss (scalar)
        """
        N = z1.shape[0]

        # Standardize embeddings (mean=0, std=1)
        z1 = (z1 - z1.mean(0)) / (z1.std(0) + 1e-8)
        z2 = (z2 - z2.mean(0)) / (z2.std(0) + 1e-8)

        # Compute correlation matrices
        c = torch.mm(z1.T, z2) / N  # Cross-correlation [D, D]
        c1 = torch.mm(z1.T, z1) / N  # Auto-correlation view 1 [D, D]
        c2 = torch.mm(z2.T, z2) / N  # Auto-correlation view 2 [D, D]

        # Invariance term: maximize diagonal of cross-correlation
        loss_inv = -torch.diagonal(c).sum()

        # Decorrelation term: minimize off-diagonal (encourage independence)
        iden = torch.eye(c.shape[0], device=c.device)
        loss_dec1 = ((iden - c1).pow(2)).sum()
        loss_dec2 = ((iden - c2).pow(2)).sum()

        return loss_inv + self.lambda_decorr * (loss_dec1 + loss_dec2)


def orthogonal_projection(x: Tensor, sens_idx: int) -> Tensor:
    """Apply orthogonal projection to remove bias from sensitive attribute.

    This function projects out the direction of bias in the feature space,
    making features more independent of the sensitive attribute.

    Args:
        x: Node features [N, D] (sensitive attribute is in x[:, sens_idx])
        sens_idx: Index of sensitive attribute column

    Returns:
        Debiased features [N, D]

    Reference:
        SE-HSSL fairaug.py: orth_proj function
    """
    epsilon = 1e-8

    # Get sensitive attribute groups (binary: 0 or 1)
    groups = x[:, sens_idx]

    idx_zero = torch.where(groups == 0)[0]
    idx_one = torch.where(groups == 1)[0]

    x_0 = x[idx_zero]
    x_1 = x[idx_one]

    # Compute group sums
    v_0 = torch.sum(x_0, dim=0)
    v_1 = torch.sum(x_1, dim=0)

    # Normalize to unit vectors
    unit_v0 = v_0 / (torch.norm(v_0, p=2) + epsilon)
    unit_v1 = v_1 / (torch.norm(v_1, p=2) + epsilon)

    # Compute bias direction
    bias_v = unit_v0 - unit_v1
    unit_bias = bias_v / (torch.norm(bias_v, p=2) + epsilon)

    # Project out bias direction
    ip_bias = x @ unit_bias  # Inner product with bias direction
    debias_x = x - ip_bias.unsqueeze(1) @ unit_bias.unsqueeze(0)

    return debias_x


def balance_hyperedges(
    hyperedge_index: Tensor,
    node_groups: Tensor | list[int],
    beta: float = 1.0,
) -> Tensor:
    """Balance hyperedges with respect to group representation.

    This augmentation resamples nodes in hyperedges to make group
    representation more balanced, reducing bias.

    Args:
        hyperedge_index: Hyperedge index [2, E]
        node_groups: Binary group labels for each node (0 or 1)
        beta: Balance strength (higher = more balancing)

    Returns:
        Balanced hyperedge index [2, E']

    Reference:
        SE-HSSL fairaug.py: balance_hyperedges function
    """
    import math

    # Convert to lists for easier manipulation
    if isinstance(node_groups, Tensor):
        node_groups = node_groups.tolist()

    # Build edge dictionary
    edge_dict = {}
    for node, edge in hyperedge_index.T:
        edge_dict.setdefault(int(edge.item()), []).append(int(node.item()))

    # Get nodes by group
    node_group_0 = [i for i, x in enumerate(node_groups) if x == 0]
    node_group_1 = [i for i, x in enumerate(node_groups) if x == 1]

    new_node_list = []
    new_edge_list = []

    for edge, nodes in edge_dict.items():
        # Split nodes by group
        group_0 = [n for n in nodes if node_groups[n] == 0]
        group_1 = [n for n in nodes if node_groups[n] == 1]

        len_0, len_1 = len(group_0), len(group_1)

        # Calculate how many nodes to add for balance
        num_sample = math.ceil(beta * abs(len_1 - len_0))

        # Oversample minority group
        if len_0 < len_1 and len_0 > 0:
            # Oversample from existing group_0 nodes
            group_0 += [
                group_0[i] for i in torch.randint(0, len_0, (num_sample,)).tolist()
            ]
        elif len_0 < len_1 and len_0 == 0:
            # Sample from all group 0 nodes (edge has no group 0)
            aug_idx = torch.randint(0, len(node_group_0), (num_sample,)).tolist()
            group_0 = [node_group_0[i] for i in aug_idx]
        elif len_1 < len_0 and len_1 > 0:
            # Oversample from existing group_1 nodes
            group_1 += [
                group_1[i] for i in torch.randint(0, len_1, (num_sample,)).tolist()
            ]
        elif len_1 < len_0 and len_1 == 0:
            # Sample from all group 1 nodes (edge has no group 1)
            aug_idx = torch.randint(0, len(node_group_1), (num_sample,)).tolist()
            group_1 = [node_group_1[i] for i in aug_idx]

        # Combine balanced nodes
        balanced_nodes = group_0 + group_1
        new_node_list.extend(balanced_nodes)
        new_edge_list.extend([edge] * len(balanced_nodes))

    balanced_hyperedge_index = torch.tensor(
        [new_node_list, new_edge_list], dtype=torch.long, device=hyperedge_index.device
    )

    return balanced_hyperedge_index
