"""SSL loss functions."""

from pyg_hyper_ssl.losses.base import BaseLoss, CompositeLoss
from pyg_hyper_ssl.losses.contrastive import (
    CosineSimilarityLoss,
    InfoNCE,
    NTXent,
)
from pyg_hyper_ssl.losses.fairness import (
    CCALoss,
    balance_hyperedges,
    orthogonal_projection,
)

__all__ = [
    # Base
    "BaseLoss",
    "CCALoss",
    "CompositeLoss",
    "CosineSimilarityLoss",
    # Contrastive
    "InfoNCE",
    "NTXent",
    # Fairness
    "balance_hyperedges",
    "orthogonal_projection",
]
