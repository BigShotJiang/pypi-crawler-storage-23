"""Base abstract class for SSL loss functions."""

from abc import ABC, abstractmethod
from typing import Any

import torch
from torch import nn


class BaseLoss(ABC, nn.Module):
    """Abstract base class for self-supervised learning loss functions.

    This class defines the interface that all SSL loss functions must implement.

    Example:
        >>> from pyg_hyper_ssl.losses.contrastive import InfoNCE
        >>>
        >>> loss_fn = InfoNCE(temperature=0.5)
        >>> z1 = torch.randn(100, 64)
        >>> z2 = torch.randn(100, 64)
        >>> loss = loss_fn(z1, z2)
        >>> loss.backward()
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the loss function.

        Args:
            **kwargs: Loss-specific parameters (e.g., temperature, margin, weight)
        """
        super().__init__()
        self.kwargs = kwargs

    @abstractmethod
    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Compute loss from embeddings.

        Args:
            z1: First embedding tensor [batch_size, hidden_dim]
            z2: Second embedding tensor [batch_size, hidden_dim]
            **kwargs: Additional loss-specific arguments

        Returns:
            Loss tensor (scalar)

        Example:
            >>> loss = loss_fn(z1, z2)
            >>> print(loss.item())
            2.3456
        """
        ...

    def __repr__(self) -> str:
        """Return string representation of loss function."""
        params = ", ".join(f"{k}={v}" for k, v in self.kwargs.items())
        return f"{self.__class__.__name__}({params})"


class CompositeLoss(BaseLoss):
    """Composite loss combining multiple loss terms with weights.

    This allows combining different loss objectives (e.g., contrastive + reconstruction).

    Example:
        >>> from pyg_hyper_ssl.losses import CompositeLoss
        >>> from pyg_hyper_ssl.losses.contrastive import InfoNCE
        >>> from pyg_hyper_ssl.losses.reconstruction import MSELoss
        >>>
        >>> composite = CompositeLoss([
        ...     (InfoNCE(temperature=0.5), 1.0),      # weight = 1.0
        ...     (MSELoss(), 0.5),                      # weight = 0.5
        ... ])
        >>> loss = composite(z1, z2, reconstruction_target=x)
    """

    def __init__(
        self,
        losses: list[tuple[BaseLoss, float]],
    ) -> None:
        """Initialize composite loss.

        Args:
            losses: List of (loss_fn, weight) tuples
        """
        super().__init__()
        self.losses = nn.ModuleList([loss_fn for loss_fn, _ in losses])
        self.weights = [weight for _, weight in losses]

    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Compute weighted sum of all loss terms.

        Args:
            z1: First embedding tensor
            z2: Second embedding tensor
            **kwargs: Additional arguments passed to each loss function

        Returns:
            Weighted sum of all loss terms
        """
        total_loss = torch.tensor(0.0, device=z1.device)
        for loss_fn, weight in zip(self.losses, self.weights, strict=True):
            loss_value = loss_fn(z1, z2, **kwargs)
            total_loss = total_loss + weight * loss_value
        return total_loss

    def __repr__(self) -> str:
        """Return string representation of composite loss."""
        loss_strs = [
            f"({loss}, {weight})"
            for loss, weight in zip(self.losses, self.weights, strict=True)
        ]
        return f"CompositeLoss([{', '.join(loss_strs)}])"
