"""Edge dropping augmentation for hypergraphs."""

import torch
from pyg_hyper_data.data import HyperData
from torch import Tensor

from pyg_hyper_ssl.augmentations.base import BaseAugmentation


class EdgeDrop(BaseAugmentation):
    """Randomly drop hyperedges from the hypergraph.

    This is a fundamental structural augmentation for hypergraphs. It randomly
    removes entire hyperedges with a given probability.

    Example:
        >>> from pyg_hyper_ssl.augmentations.structural import EdgeDrop
        >>>
        >>> aug = EdgeDrop(drop_prob=0.2)  # Drop 20% of hyperedges
        >>> data_aug = aug(data)
        >>> print(data.num_hyperedges, data_aug.num_hyperedges)
        100 80  # Approximately 20% dropped
    """

    def __init__(self, drop_prob: float = 0.2) -> None:
        """Initialize edge drop augmentation.

        Args:
            drop_prob: Probability of dropping each hyperedge (0 <= p <= 1)

        Raises:
            ValueError: If drop_prob is not in [0, 1]
        """
        super().__init__(drop_prob=drop_prob)

        if not 0 <= drop_prob <= 1:
            msg = f"drop_prob must be in [0, 1], got {drop_prob}"
            raise ValueError(msg)

        self.drop_prob = drop_prob

    def __call__(self, data: HyperData) -> HyperData:
        """Apply edge dropping to hypergraph data.

        Args:
            data: Original hypergraph data

        Returns:
            Augmented hypergraph data with dropped edges

        Note:
            - Preserves all nodes (only drops hyperedges)
            - Maintains node indices and features unchanged
            - Uses sparse matrix operations to match TriCL implementation
        """
        if self.drop_prob == 0:
            return data.clone()

        # Get original hyperedge_index
        if data.hyperedge_index is None:
            return data.clone()
        hyperedge_index = data.hyperedge_index.clone()
        num_nodes = data.num_nodes
        num_hyperedges = data.num_hyperedges

        # Ensure num_nodes and num_hyperedges are not None
        if num_nodes is None or num_hyperedges is None:
            return data.clone()

        # Create drop mask: True = drop, False = keep
        # This follows TriCL's drop_hyperedges implementation
        drop_mask = (
            torch.rand(num_hyperedges, device=hyperedge_index.device) < self.drop_prob
        )
        drop_idx = drop_mask.nonzero(as_tuple=True)[0]

        # Build incidence matrix H as sparse tensor
        H = torch.sparse_coo_tensor(
            hyperedge_index,
            hyperedge_index.new_ones((hyperedge_index.shape[1],)),
            (int(num_nodes), int(num_hyperedges)),
        ).to_dense()

        # Drop hyperedges by setting columns to zero
        H[:, drop_idx] = 0

        # Convert back to sparse indices
        new_hyperedge_index = H.to_sparse().indices()

        # Remap edge indices to be contiguous (0, 1, 2, ...)
        # This is necessary because sparse matrix preserves original indices
        if new_hyperedge_index.size(1) > 0:
            unique_edges = torch.unique(new_hyperedge_index[1], sorted=True)
            edge_mapping = torch.full(
                (num_hyperedges,),
                -1,
                dtype=torch.long,
                device=new_hyperedge_index.device,
            )
            edge_mapping[unique_edges] = torch.arange(
                len(unique_edges), device=new_hyperedge_index.device
            )
            new_hyperedge_index[1] = edge_mapping[new_hyperedge_index[1]]

        # Create augmented data
        # Cast y to Tensor if it exists, otherwise None
        y_val = data.y if isinstance(data.y, Tensor) or data.y is None else None
        augmented_data = HyperData(
            x=data.x,
            hyperedge_index=new_hyperedge_index,
            y=y_val,
        )

        # Note: We don't filter hyperedge attributes because the sparse matrix
        # approach automatically handles edge reindexing. The new hyperedge_index
        # already has the correct number of edges after dropping.
        # If we need to preserve hyperedge attributes, we would need to track
        # which edges were kept, but TriCL doesn't use hyperedge attributes.

        # Copy other attributes
        # HyperData inherits keys() from PyG Data
        for key in data.keys():
            if key not in [
                "x",
                "y",
                "hyperedge_index",
                "hyperedge_attr",
                "hyperedge_weight",
            ]:
                augmented_data[key] = data[key]

        return augmented_data

    def __repr__(self) -> str:
        """Return string representation."""
        return f"EdgeDrop(drop_prob={self.drop_prob})"
