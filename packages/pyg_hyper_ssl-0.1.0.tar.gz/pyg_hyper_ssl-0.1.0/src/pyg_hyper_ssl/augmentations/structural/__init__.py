"""Structural augmentations."""

from pyg_hyper_ssl.augmentations.structural.edge_drop import EdgeDrop

__all__ = [
    "EdgeDrop",
]
