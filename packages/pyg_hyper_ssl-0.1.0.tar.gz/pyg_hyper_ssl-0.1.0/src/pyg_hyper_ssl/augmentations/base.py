"""Base abstract class for hypergraph augmentations."""

from abc import ABC, abstractmethod
from typing import Any

import torch
from pyg_hyper_data.data import HyperData


class BaseAugmentation(ABC):
    """Abstract base class for hypergraph augmentation strategies.

    Augmentations are transformations applied to hypergraph data to create
    different views for contrastive learning or to add robustness.

    Example:
        >>> from pyg_hyper_ssl.augmentations.structural import EdgeDrop
        >>> from pyg_hyper_ssl.augmentations.attribute import FeatureMask
        >>>
        >>> aug1 = EdgeDrop(drop_prob=0.2)
        >>> aug2 = FeatureMask(mask_prob=0.3)
        >>>
        >>> data_aug1 = aug1(data)
        >>> data_aug2 = aug2(data)
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the augmentation.

        Args:
            **kwargs: Augmentation-specific parameters
        """
        self.kwargs = kwargs

    @abstractmethod
    def __call__(self, data: HyperData) -> HyperData:
        """Apply augmentation to hypergraph data.

        Args:
            data: Original hypergraph data

        Returns:
            Augmented hypergraph data

        Note:
            This method should NOT modify the input data in-place.
            It should create and return a new HyperData object.

        Example:
            >>> augmented_data = augmentation(data)
            >>> print(data.hyperedge_index.shape)  # Original unchanged
            >>> print(augmented_data.hyperedge_index.shape)  # Possibly different
        """
        ...

    def __repr__(self) -> str:
        """Return string representation of augmentation."""
        params = ", ".join(f"{k}={v}" for k, v in self.kwargs.items())
        return f"{self.__class__.__name__}({params})"


class ComposedAugmentation(BaseAugmentation):
    """Compose multiple augmentations sequentially.

    This allows chaining multiple augmentation strategies together.

    Example:
        >>> from pyg_hyper_ssl.augmentations import ComposedAugmentation
        >>> from pyg_hyper_ssl.augmentations.structural import EdgeDrop, NodeDrop
        >>> from pyg_hyper_ssl.augmentations.attribute import FeatureMask
        >>>
        >>> aug = ComposedAugmentation([
        ...     EdgeDrop(drop_prob=0.2),
        ...     NodeDrop(drop_prob=0.1),
        ...     FeatureMask(mask_prob=0.3)
        ... ])
        >>> data_aug = aug(data)
    """

    def __init__(self, augmentations: list[BaseAugmentation]) -> None:
        """Initialize composed augmentation.

        Args:
            augmentations: List of augmentation strategies to apply sequentially
        """
        super().__init__()
        self.augmentations = augmentations

    def __call__(self, data: HyperData) -> HyperData:
        """Apply all augmentations sequentially.

        Args:
            data: Original hypergraph data

        Returns:
            Augmented hypergraph data after all transformations
        """
        augmented_data = data
        for aug in self.augmentations:
            augmented_data = aug(augmented_data)
        return augmented_data

    def __repr__(self) -> str:
        """Return string representation of composed augmentation."""
        aug_strs = [str(aug) for aug in self.augmentations]
        return f"ComposedAugmentation([{', '.join(aug_strs)}])"


class RandomChoice(BaseAugmentation):
    """Randomly choose one augmentation from a list.

    This allows for more diverse augmentations by randomly selecting
    different strategies for each call.

    Example:
        >>> from pyg_hyper_ssl.augmentations import RandomChoice
        >>> from pyg_hyper_ssl.augmentations.structural import EdgeDrop, NodeDrop
        >>>
        >>> aug = RandomChoice([
        ...     EdgeDrop(drop_prob=0.2),
        ...     NodeDrop(drop_prob=0.1),
        ... ])
        >>> data_aug = aug(data)  # Randomly applies EdgeDrop OR NodeDrop
    """

    def __init__(
        self,
        augmentations: list[BaseAugmentation],
        p: list[float] | None = None,
    ) -> None:
        """Initialize random choice augmentation.

        Args:
            augmentations: List of augmentation strategies to choose from
            p: Optional probabilities for each augmentation.
               If None, uniform probabilities are used.
        """
        super().__init__()
        self.augmentations = augmentations
        self.p = p

        if p is not None and len(p) != len(augmentations):
            msg = f"Length of p ({len(p)}) must match augmentations ({len(augmentations)})"
            raise ValueError(msg)

    def __call__(self, data: HyperData) -> HyperData:
        """Randomly choose and apply one augmentation.

        Args:
            data: Original hypergraph data

        Returns:
            Augmented hypergraph data
        """
        if self.p is not None:
            idx_val = torch.multinomial(torch.tensor(self.p), 1).item()
        else:
            idx_val = torch.randint(0, len(self.augmentations), (1,)).item()

        # Cast to int for list indexing
        idx = int(idx_val)
        aug = self.augmentations[idx]
        return aug(data)

    def __repr__(self) -> str:
        """Return string representation of random choice augmentation."""
        aug_strs = [str(aug) for aug in self.augmentations]
        p_str = f", p={self.p}" if self.p is not None else ""
        return f"RandomChoice([{', '.join(aug_strs)}]{p_str})"
