"""Feature masking augmentation for hypergraphs."""

import torch
from pyg_hyper_data.data import HyperData
from torch import Tensor

from pyg_hyper_ssl.augmentations.base import BaseAugmentation


class FeatureMask(BaseAugmentation):
    """Randomly mask node features with zeros.

    This is a fundamental attribute-based augmentation. It randomly sets
    feature dimensions to zero with a given probability.

    Example:
        >>> from pyg_hyper_ssl.augmentations.attribute import FeatureMask
        >>>
        >>> aug = FeatureMask(mask_prob=0.3)  # Mask 30% of features
        >>> data_aug = aug(data)
        >>> # Approximately 30% of feature values are now zero
    """

    def __init__(self, mask_prob: float = 0.3) -> None:
        """Initialize feature mask augmentation.

        Args:
            mask_prob: Probability of masking each feature dimension (0 <= p <= 1)

        Raises:
            ValueError: If mask_prob is not in [0, 1]
        """
        super().__init__(mask_prob=mask_prob)

        if not 0 <= mask_prob <= 1:
            msg = f"mask_prob must be in [0, 1], got {mask_prob}"
            raise ValueError(msg)

        self.mask_prob = mask_prob

    def __call__(self, data: HyperData) -> HyperData:
        """Apply feature masking to hypergraph data.

        Args:
            data: Original hypergraph data

        Returns:
            Augmented hypergraph data with masked features

        Note:
            - Only modifies node features (x)
            - Preserves graph structure completely
            - Masking is done per-feature dimension (all nodes for a feature are masked together)
            - This follows the original TriCL implementation
        """
        if self.mask_prob == 0:
            return data.clone()

        # Clone features
        if data.x is None:
            msg = "data.x cannot be None"
            raise ValueError(msg)
        x_masked = data.x.clone()

        # Create mask for feature dimensions (not element-wise)
        # Shape: (num_features,) - one mask value per feature dimension
        # This follows TriCL's drop_features implementation
        drop_mask = (
            torch.empty(
                (x_masked.size(1),), dtype=torch.float32, device=x_masked.device
            ).uniform_(0, 1)
            < self.mask_prob
        )

        # Apply mask to entire feature columns
        x_masked[:, drop_mask] = 0

        # Create augmented data
        # Cast y to Tensor if it exists, otherwise None
        y_val = data.y if isinstance(data.y, Tensor) or data.y is None else None
        augmented_data = HyperData(
            x=x_masked,
            hyperedge_index=data.hyperedge_index,
            y=y_val,
        )

        # Copy hyperedge attributes if present
        if hasattr(data, "hyperedge_attr") and data.hyperedge_attr is not None:
            augmented_data.hyperedge_attr = data.hyperedge_attr

        # Copy hyperedge weights if present
        if hasattr(data, "hyperedge_weight") and data.hyperedge_weight is not None:
            augmented_data.hyperedge_weight = data.hyperedge_weight

        # Copy other attributes
        # HyperData inherits keys() from PyG Data
        for key in data.keys():
            if key not in [
                "x",
                "y",
                "hyperedge_index",
                "hyperedge_attr",
                "hyperedge_weight",
            ]:
                augmented_data[key] = data[key]

        return augmented_data

    def __repr__(self) -> str:
        """Return string representation."""
        return f"FeatureMask(mask_prob={self.mask_prob})"
