"""Attribute augmentations."""

from pyg_hyper_ssl.augmentations.attribute.feature_mask import FeatureMask

__all__ = [
    "FeatureMask",
]
