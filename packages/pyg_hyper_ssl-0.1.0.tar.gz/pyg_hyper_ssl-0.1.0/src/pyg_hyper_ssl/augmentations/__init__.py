"""Hypergraph augmentation strategies."""

from pyg_hyper_ssl.augmentations.attribute.feature_mask import FeatureMask
from pyg_hyper_ssl.augmentations.base import (
    BaseAugmentation,
    ComposedAugmentation,
    RandomChoice,
)
from pyg_hyper_ssl.augmentations.structural.edge_drop import EdgeDrop

__all__ = [
    # Base
    "BaseAugmentation",
    "ComposedAugmentation",
    # Structural
    "EdgeDrop",
    # Attribute
    "FeatureMask",
    "RandomChoice",
]
