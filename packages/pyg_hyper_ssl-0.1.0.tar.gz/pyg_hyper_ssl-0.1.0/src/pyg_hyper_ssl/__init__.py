"""pyg-hyper-ssl: Self-supervised learning methods for hypergraphs."""

__version__ = "0.1.0"

from pyg_hyper_ssl.augmentations.base import (
    BaseAugmentation,
    ComposedAugmentation,
    RandomChoice,
)
from pyg_hyper_ssl.encoders.wrapper import EncoderWrapper
from pyg_hyper_ssl.losses.base import BaseLoss, CompositeLoss
from pyg_hyper_ssl.methods.base import BaseSSLMethod
from pyg_hyper_ssl.methods.contrastive import TriCL, TriCLConv, TriCLEncoder

__all__ = [
    "BaseAugmentation",
    "BaseLoss",
    # Base classes
    "BaseSSLMethod",
    # Augmentation utilities
    "ComposedAugmentation",
    # Loss utilities
    "CompositeLoss",
    # Encoder wrapper
    "EncoderWrapper",
    "RandomChoice",
    # SSL methods
    "TriCL",
    "TriCLConv",
    "TriCLEncoder",
]
