"""Encoder wrapper for integrating pyg-hyper-nn models with SSL methods."""

from typing import Any

import torch
from pyg_hyper_data.data import HyperData
from torch import nn


class EncoderWrapper(nn.Module):
    """Wrapper for pyg-hyper-nn models to use as SSL encoders.

    This class wraps any pyg-hyper-nn model and optionally adds a projection head
    for contrastive learning. All 19 models in pyg-hyper-nn share the same interface:
    forward(x, hyperedge_index, hyperedge_weight=None).

    Example:
        >>> from pyg_hyper_nn.models import HGNN, UniGNN, HyperGCN
        >>> from pyg_hyper_ssl.encoders import EncoderWrapper
        >>>
        >>> # Basic encoder without projection head
        >>> encoder = EncoderWrapper(
        ...     model_class=HGNN,
        ...     in_channels=16,
        ...     hidden_channels=64,
        ...     num_layers=2
        ... )
        >>>
        >>> # Encoder with projection head for contrastive learning
        >>> encoder = EncoderWrapper(
        ...     model_class=UniGNN,
        ...     in_channels=16,
        ...     hidden_channels=64,
        ...     out_channels=32,  # Projection dimension
        ...     num_layers=2,
        ...     use_projection=True
        ... )
    """

    def __init__(
        self,
        model_class: type[nn.Module],
        in_channels: int,
        hidden_channels: int,
        out_channels: int | None = None,
        num_layers: int = 2,
        use_projection: bool = False,
        projection_hidden_dim: int | None = None,
        **model_kwargs: Any,
    ) -> None:
        """Initialize encoder wrapper.

        Args:
            model_class: Model class from pyg_hyper_nn.models
                        (e.g., HGNN, UniGNN, HyperGCN, HyperGT)
            in_channels: Input feature dimension
            hidden_channels: Hidden dimension
            out_channels: Output dimension. If None, defaults to hidden_channels.
                         For SSL, typically set to hidden_channels (encoder output)
                         or projection_dim (with use_projection=True).
            num_layers: Number of layers
            use_projection: If True, add MLP projection head after encoder
            projection_hidden_dim: Hidden dimension for projection MLP.
                                  If None, defaults to hidden_channels.
            **model_kwargs: Additional model-specific arguments
                           (e.g., dropout, normalize, etc.)

        Example:
            >>> # HGNN encoder
            >>> encoder = EncoderWrapper(
            ...     model_class=HGNN,
            ...     in_channels=128,
            ...     hidden_channels=256,
            ...     num_layers=3,
            ...     dropout=0.5
            ... )
            >>>
            >>> # HyperGCN encoder with projection head
            >>> encoder = EncoderWrapper(
            ...     model_class=HyperGCN,
            ...     in_channels=128,
            ...     hidden_channels=256,
            ...     out_channels=128,  # Projection dim
            ...     num_layers=2,
            ...     use_projection=True,
            ...     mediators=True  # HyperGCN-specific
            ... )
        """
        super().__init__()

        # Set output dimension for encoder
        # For SSL, encoder typically outputs hidden_channels dimension
        encoder_out_channels = (
            out_channels if out_channels is not None else hidden_channels
        )

        # Create encoder from pyg-hyper-nn
        self.encoder = model_class(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=encoder_out_channels,
            num_layers=num_layers,
            **model_kwargs,
        )

        # Optional projection head for contrastive learning
        self.use_projection = use_projection
        if use_projection:
            proj_hidden = (
                projection_hidden_dim
                if projection_hidden_dim is not None
                else hidden_channels
            )
            self.projection = nn.Sequential(
                nn.Linear(encoder_out_channels, proj_hidden),
                nn.BatchNorm1d(proj_hidden),
                nn.ReLU(inplace=True),
                nn.Linear(proj_hidden, encoder_out_channels),
            )
        else:
            self.projection = None

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = encoder_out_channels

    def forward(
        self,
        x: torch.Tensor,
        hyperedge_index: torch.Tensor,
        hyperedge_weight: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass through encoder and optional projection head.

        Args:
            x: Node features [num_nodes, in_channels]
            hyperedge_index: Hyperedge connections [2, num_connections]
            hyperedge_weight: Optional hyperedge weights [num_hyperedges]

        Returns:
            (embeddings, projections): Tuple of tensors
                - embeddings: Encoder output [num_nodes, out_channels]
                - projections: Projection head output (if use_projection=True)
                              or same as embeddings (if use_projection=False)

        Note:
            For contrastive learning, use projections for computing loss
            and embeddings for downstream tasks.

        Example:
            >>> # Without projection
            >>> h, z = encoder(x, hyperedge_index)
            >>> # h and z are the same
            >>>
            >>> # With projection
            >>> h, z = encoder(x, hyperedge_index)
            >>> # Use z for contrastive loss, h for downstream tasks
        """
        # Get encoder output
        h = self.encoder(x, hyperedge_index, hyperedge_weight)

        # Apply projection head if enabled
        if self.use_projection and self.projection is not None:
            z = self.projection(h)
        else:
            z = h

        return h, z

    def forward_from_data(self, data: HyperData) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass from HyperData object.

        Convenience method that extracts x, hyperedge_index from HyperData.

        Args:
            data: HyperData object

        Returns:
            (embeddings, projections): Same as forward()

        Example:
            >>> h, z = encoder.forward_from_data(data)
        """
        x = data.x
        hyperedge_index = data.hyperedge_index
        hyperedge_weight = getattr(data, "hyperedge_weight", None)

        return self(x, hyperedge_index, hyperedge_weight)

    def __repr__(self) -> str:
        """Return string representation of encoder wrapper."""
        encoder_name = self.encoder.__class__.__name__
        proj_str = f", projection={self.use_projection}" if self.use_projection else ""
        return (
            f"EncoderWrapper({encoder_name}, "
            f"in_channels={self.in_channels}, "
            f"hidden_channels={self.hidden_channels}, "
            f"out_channels={self.out_channels}"
            f"{proj_str})"
        )
