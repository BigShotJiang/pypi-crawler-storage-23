"""Encoder wrappers for SSL."""

from pyg_hyper_ssl.encoders.wrapper import EncoderWrapper

__all__ = [
    "EncoderWrapper",
]
