"""Tests for TriCL encoder."""

import torch

from pyg_hyper_ssl.methods.contrastive.tricl_encoder import TriCLEncoder


class TestTriCLEncoder:
    """Tests for TriCLEncoder."""

    def test_encoder_single_layer(self) -> None:
        """Test encoder with single layer."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=1)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)

        assert n.shape == (10, 64)
        assert e.shape == (1, 32)
        assert not torch.isnan(n).any()
        assert not torch.isnan(e).any()

    def test_encoder_two_layers(self) -> None:
        """Test encoder with two layers."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        n, e = encoder(x, hyperedge_index, num_nodes=10, num_edges=2)

        assert n.shape == (10, 64)
        assert e.shape == (2, 32)
        assert not torch.isnan(n).any()
        assert not torch.isnan(e).any()

    def test_encoder_multiple_layers(self) -> None:
        """Test encoder with multiple layers."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=3)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)

        assert n.shape == (10, 64)
        assert e.shape == (1, 32)

    def test_encoder_complex_hypergraph(self) -> None:
        """Test encoder with complex hypergraph."""
        encoder = TriCLEncoder(in_dim=8, edge_dim=16, node_dim=32, num_layers=2)

        x = torch.randn(20, 8)
        # Create complex hypergraph with multiple hyperedges
        hyperedge_index = torch.tensor(
            [
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                [0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3],
            ]
        )

        n, e = encoder(x, hyperedge_index, num_nodes=20, num_edges=4)

        assert n.shape == (20, 32)
        assert e.shape == (4, 16)

    def test_encoder_backward(self) -> None:
        """Test backward pass."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)

        x = torch.randn(10, 16, requires_grad=True)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Compute dummy loss
        loss = n.sum() + e.sum()
        loss.backward()

        # Check gradients
        assert x.grad is not None
        assert not torch.isnan(x.grad).any()

    def test_encoder_reset_parameters(self) -> None:
        """Test parameter reset."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        # Get initial output
        n1, e1 = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Reset parameters
        encoder.reset_parameters()

        # Get new output
        n2, e2 = encoder(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Outputs should be different after reset
        assert not torch.allclose(n1, n2)
        assert not torch.allclose(e1, e2)
