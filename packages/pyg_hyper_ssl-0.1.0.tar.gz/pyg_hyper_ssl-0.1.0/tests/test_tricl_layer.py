"""Tests for TriCL convolution layer."""

import torch

from pyg_hyper_ssl.methods.contrastive.tricl_layer import TriCLConv


class TestTriCLConv:
    """Tests for TriCLConv layer."""

    def test_tricl_conv_basic(self) -> None:
        """Test basic forward pass."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)

        # Create simple hypergraph: 10 nodes, 3 hyperedges
        x = torch.randn(10, 16)
        # Hyperedge 0: {0, 1, 2}
        # Hyperedge 1: {1, 2, 3}
        # Hyperedge 2: {4, 5}
        hyperedge_index = torch.tensor(
            [[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]]
        )

        n, e = conv(x, hyperedge_index, num_nodes=10, num_edges=3)

        # Check output shapes
        assert n.shape == (10, 16), f"Expected (10, 16), got {n.shape}"
        assert e.shape == (3, 32), f"Expected (3, 32), got {e.shape}"

        # Check that outputs are not NaN
        assert not torch.isnan(n).any(), "Node embeddings contain NaN"
        assert not torch.isnan(e).any(), "Edge embeddings contain NaN"

    def test_tricl_conv_dimensions(self) -> None:
        """Test with different dimensions."""
        conv = TriCLConv(in_dim=8, hid_dim=16, out_dim=12)

        x = torch.randn(5, 8)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = conv(x, hyperedge_index, num_nodes=5, num_edges=1)

        assert n.shape == (5, 12)
        assert e.shape == (1, 16)

    def test_tricl_conv_empty_hypergraph(self) -> None:
        """Test with empty hypergraph."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)

        x = torch.randn(5, 16)
        hyperedge_index = torch.empty((2, 0), dtype=torch.long)

        n, e = conv(x, hyperedge_index, num_nodes=5, num_edges=0)

        # With no edges, nodes should still have output (from linear layer)
        assert n.shape == (5, 16)
        assert e.shape == (0, 32)

    def test_tricl_conv_single_node_hyperedges(self) -> None:
        """Test with single-node hyperedges."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)

        x = torch.randn(5, 16)
        # Each node in its own hyperedge
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 1, 2, 3, 4]])

        n, e = conv(x, hyperedge_index, num_nodes=5, num_edges=5)

        assert n.shape == (5, 16)
        assert e.shape == (5, 32)

    def test_tricl_conv_large_hyperedge(self) -> None:
        """Test with one large hyperedge."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)

        x = torch.randn(100, 16)
        # All nodes in one hyperedge
        nodes = torch.arange(100)
        edges = torch.zeros(100, dtype=torch.long)
        hyperedge_index = torch.stack([nodes, edges])

        n, e = conv(x, hyperedge_index, num_nodes=100, num_edges=1)

        assert n.shape == (100, 16)
        assert e.shape == (1, 32)

    def test_tricl_conv_cached(self) -> None:
        """Test caching of normalization factors."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16, cached=True)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        # First forward pass
        n1, e1 = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Check that cache is populated
        assert conv._cached_norm_n2e is not None
        assert conv._cached_norm_e2n is not None

        # Second forward pass (should use cache)
        n2, e2 = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Results should be identical (same structure, same features)
        assert torch.allclose(n1, n2, atol=1e-6)
        assert torch.allclose(e1, e2, atol=1e-6)

    def test_tricl_conv_dropout(self) -> None:
        """Test dropout during training."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16, dropout=0.5)
        conv.train()

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        # With dropout, outputs should be different
        n1, e1 = conv(x, hyperedge_index, num_nodes=10, num_edges=1)
        n2, e2 = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Due to dropout, edge embeddings should be different
        # (but this test might fail occasionally due to randomness)
        # So we just check that shapes are correct
        assert n1.shape == n2.shape == (10, 16)
        assert e1.shape == e2.shape == (1, 32)

    def test_tricl_conv_no_bias(self) -> None:
        """Test without bias terms."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16, bias=False)

        assert conv.bias_n2e is None
        assert conv.bias_e2n is None

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        assert n.shape == (10, 16)
        assert e.shape == (1, 32)

    def test_tricl_conv_symmetric_norm(self) -> None:
        """Test with symmetric normalization."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16, row_norm=False)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        assert n.shape == (10, 16)
        assert e.shape == (1, 32)
        assert not torch.isnan(n).any()
        assert not torch.isnan(e).any()

    def test_tricl_conv_backward(self) -> None:
        """Test backward pass (gradient flow)."""
        conv = TriCLConv(in_dim=16, hid_dim=32, out_dim=16)

        x = torch.randn(10, 16, requires_grad=True)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        n, e = conv(x, hyperedge_index, num_nodes=10, num_edges=1)

        # Compute dummy loss
        loss = n.sum() + e.sum()
        loss.backward()

        # Check that gradients are computed
        assert x.grad is not None
        assert not torch.isnan(x.grad).any()
