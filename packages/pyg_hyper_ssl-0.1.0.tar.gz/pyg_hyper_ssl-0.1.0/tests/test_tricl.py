"""Tests for TriCL model."""

import torch
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.methods.contrastive.tricl import TriCL
from pyg_hyper_ssl.methods.contrastive.tricl_encoder import TriCLEncoder


def create_dummy_data(
    num_nodes: int = 10, num_edges: int = 3, in_dim: int = 16
) -> HyperData:
    """Create dummy hypergraph data."""
    x = torch.randn(num_nodes, in_dim)

    # Create hyperedge_index
    hyperedge_list = []
    for e in range(num_edges):
        # Each hyperedge connects 3-4 random nodes
        nodes = torch.randperm(num_nodes)[: torch.randint(3, 5, (1,)).item()]
        for node in nodes:
            hyperedge_list.append([node.item(), e])

    hyperedge_index = torch.tensor(hyperedge_list).t()

    return HyperData(x=x, hyperedge_index=hyperedge_index)


class TestTriCL:
    """Tests for TriCL model."""

    def test_tricl_initialization(self) -> None:
        """Test TriCL model initialization."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        assert model.node_dim == 64
        assert model.edge_dim == 32
        assert model.node_tau == 0.5
        assert model.edge_tau == 0.5
        assert model.membership_tau == 0.1

    def test_tricl_forward(self) -> None:
        """Test forward pass."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data_aug = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        (n1, e1), (n2, e2) = model(data, data_aug)

        # Check shapes
        assert n1.shape == (10, 64)
        assert e1.shape == (3, 32)
        assert n2.shape == (10, 64)
        assert e2.shape == (3, 32)

        # Check for NaN
        assert not torch.isnan(n1).any()
        assert not torch.isnan(e1).any()
        assert not torch.isnan(n2).any()
        assert not torch.isnan(e2).any()

    def test_tricl_forward_no_aug(self) -> None:
        """Test forward pass without augmentation."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        (n1, e1), (n2, e2) = model(data, None)

        # Without augmentation, both views should be identical
        assert torch.allclose(n1, n2)
        assert torch.allclose(e1, e2)

    def test_tricl_node_level_loss(self) -> None:
        """Test node-level contrastive loss."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        n1 = torch.randn(10, 64)
        n2 = torch.randn(10, 64)

        loss = model.node_level_loss(n1, n2)

        # Check that loss is scalar and positive
        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_tricl_group_level_loss(self) -> None:
        """Test group-level contrastive loss."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        e1 = torch.randn(5, 32)
        e2 = torch.randn(5, 32)

        loss = model.group_level_loss(e1, e2)

        # Check that loss is scalar and positive
        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_tricl_membership_level_loss(self) -> None:
        """Test membership-level contrastive loss."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        n = torch.randn(10, 64)
        e = torch.randn(3, 32)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        loss = model.membership_level_loss(n, e, hyperedge_index)

        # Check that loss is scalar and positive
        assert loss.dim() == 0
        assert loss.item() >= 0  # Can be 0 if all NaN filtered out
        assert not torch.isnan(loss)

    def test_tricl_compute_loss(self) -> None:
        """Test total loss computation."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(
            encoder=encoder,
            proj_dim=64,
            lambda_n=1.0,
            lambda_e=1.0,
            lambda_m=1.0,
        )

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data_aug = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        (n1, e1), (n2, e2) = model(data, data_aug)

        loss = model.compute_loss((n1, e1), (n2, e2), data.hyperedge_index)

        # Check that loss is scalar and positive
        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_tricl_train_step(self) -> None:
        """Test complete training step."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data_aug = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        loss = model.train_step(data, data_aug)

        # Check that loss is scalar and positive
        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_tricl_backward(self) -> None:
        """Test backward pass."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data.x.requires_grad = True
        data_aug = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data_aug.x.requires_grad = True

        loss = model.train_step(data, data_aug)
        loss.backward()

        # Check that gradients are computed
        assert data.x.grad is not None
        assert data_aug.x.grad is not None
        assert not torch.isnan(data.x.grad).any()
        assert not torch.isnan(data_aug.x.grad).any()

    def test_tricl_get_embeddings(self) -> None:
        """Test getting embeddings for downstream tasks."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)
        model.eval()

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        embeddings = model.get_embeddings(data)

        # Check shape
        assert embeddings.shape == (10, 64)
        assert not torch.isnan(embeddings).any()

    def test_tricl_projection_heads(self) -> None:
        """Test projection heads."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=128)

        n = torch.randn(10, 64)
        e = torch.randn(5, 32)

        n_proj = model.node_projection(n)
        e_proj = model.edge_projection(e)

        # Projections should return to original dimensions
        assert n_proj.shape == (10, 64)
        assert e_proj.shape == (5, 32)

    def test_tricl_cosine_similarity(self) -> None:
        """Test cosine similarity computation."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        z1 = torch.randn(10, 64)
        z2 = torch.randn(10, 64)

        sim = model.cosine_similarity(z1, z2)

        # Similarity matrix should be [10, 10]
        assert sim.shape == (10, 10)
        # Values should be in [-1, 1] range (cosine similarity)
        assert sim.min() >= -1.1  # Small margin for numerical errors
        assert sim.max() <= 1.1

    def test_tricl_disc_similarity(self) -> None:
        """Test discriminator similarity."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(encoder=encoder, proj_dim=64)

        z_n = torch.randn(10, 64)
        z_e = torch.randn(10, 32)

        sim = model.disc_similarity(z_n, z_e)

        # Similarity should be in [0, 1] range (sigmoid output)
        assert sim.shape == (10,)
        assert sim.min() >= 0
        assert sim.max() <= 1

    def test_tricl_different_loss_weights(self) -> None:
        """Test with different loss weights."""
        encoder = TriCLEncoder(in_dim=16, edge_dim=32, node_dim=64, num_layers=2)
        model = TriCL(
            encoder=encoder,
            proj_dim=64,
            lambda_n=2.0,
            lambda_e=0.5,
            lambda_m=1.5,
        )

        data = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)
        data_aug = create_dummy_data(num_nodes=10, num_edges=3, in_dim=16)

        loss = model.train_step(data, data_aug)

        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_tricl_large_hypergraph(self) -> None:
        """Test with larger hypergraph."""
        encoder = TriCLEncoder(in_dim=32, edge_dim=64, node_dim=128, num_layers=3)
        model = TriCL(encoder=encoder, proj_dim=128)

        data = create_dummy_data(num_nodes=100, num_edges=20, in_dim=32)
        data_aug = create_dummy_data(num_nodes=100, num_edges=20, in_dim=32)

        loss = model.train_step(data, data_aug)

        assert loss.dim() == 0
        assert loss.item() > 0
        assert not torch.isnan(loss)
