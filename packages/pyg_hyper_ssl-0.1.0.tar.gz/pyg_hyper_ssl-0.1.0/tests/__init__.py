"""Test suite for {{ package_name }}."""
