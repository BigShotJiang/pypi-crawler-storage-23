"""Tests for augmentation accuracy against reference implementation."""

import torch
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.augmentations import EdgeDrop, FeatureMask


class TestFeatureMaskAccuracy:
    """Test FeatureMask against TriCL reference implementation."""

    def test_feature_mask_dimension_wise(self) -> None:
        """Test that FeatureMask masks entire feature dimensions, not elements.

        The reference implementation (TriCL's drop_features) masks entire
        feature dimensions at once, not individual elements.
        """
        # Create simple data
        torch.manual_seed(42)
        x = torch.randn(10, 8)  # 10 nodes, 8 features
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Apply feature mask
        aug = FeatureMask(mask_prob=0.5)
        data_aug = aug(data)

        # Check that masking is dimension-wise:
        # If a feature dimension is masked, ALL nodes should have that feature = 0
        # If a feature dimension is not masked, NO nodes should have that feature = 0 (unless originally 0)

        for feat_idx in range(x.size(1)):
            # Get mask for this feature
            original_feat = x[:, feat_idx]
            masked_feat = data_aug.x[:, feat_idx]

            # Check if feature is masked
            if masked_feat.sum() == 0 and original_feat.sum() != 0:
                # Feature is masked - all values should be 0
                assert torch.allclose(masked_feat, torch.zeros_like(masked_feat)), (
                    f"Feature {feat_idx} should be all zeros"
                )
            elif not torch.allclose(masked_feat, torch.zeros_like(masked_feat)):
                # Feature is not masked - should be identical to original
                assert torch.allclose(masked_feat, original_feat), (
                    f"Feature {feat_idx} should be unchanged"
                )

    def test_feature_mask_vs_element_wise(self) -> None:
        """Verify that FeatureMask is NOT element-wise.

        Element-wise masking would result in different patterns per row.
        Dimension-wise masking results in entire columns being zero.
        """
        torch.manual_seed(123)
        x = torch.ones(10, 8)  # All ones for easy checking
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Apply feature mask multiple times to see pattern
        aug = FeatureMask(mask_prob=0.5)

        for _ in range(5):
            data_aug = aug(data)

            # For each feature dimension that has any zero
            for feat_idx in range(x.size(1)):
                col = data_aug.x[:, feat_idx]
                # If any value is 0, ALL values should be 0 (dimension-wise)
                if (col == 0).any():
                    assert (col == 0).all(), (
                        f"Feature {feat_idx}: If any node has 0, "
                        "all nodes should have 0 (dimension-wise masking)"
                    )

    def test_feature_mask_probability(self) -> None:
        """Test that approximately mask_prob of features are dropped."""
        torch.manual_seed(42)
        x = torch.randn(100, 50)  # Many features for better statistics
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Run multiple times and check average
        mask_prob = 0.3
        aug = FeatureMask(mask_prob=mask_prob)

        num_trials = 100
        num_masked_features = []

        for _ in range(num_trials):
            data_aug = aug(data)

            # Count how many features are completely masked
            masked = 0
            for feat_idx in range(x.size(1)):
                if torch.allclose(
                    data_aug.x[:, feat_idx], torch.zeros_like(data_aug.x[:, feat_idx])
                ):
                    masked += 1

            num_masked_features.append(masked)

        # Check that on average, mask_prob of features are masked
        avg_masked = sum(num_masked_features) / num_trials
        expected = mask_prob * x.size(1)

        # Allow 20% tolerance due to randomness
        assert abs(avg_masked - expected) / expected < 0.2, (
            f"Expected ~{expected:.1f} masked features, got {avg_masked:.1f}"
        )


class TestEdgeDropAccuracy:
    """Test EdgeDrop against TriCL reference implementation."""

    def test_edge_drop_removes_hyperedges(self) -> None:
        """Test that EdgeDrop removes entire hyperedges."""
        torch.manual_seed(42)
        x = torch.randn(10, 16)
        # 3 hyperedges: {0,1,2}, {1,2,3}, {4,5}
        hyperedge_index = torch.tensor(
            [[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]]
        )

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Drop with 100% probability - should remove all edges
        aug = EdgeDrop(drop_prob=1.0)
        data_aug = aug(data)

        assert data_aug.hyperedge_index.size(1) == 0, "No connections should remain"
        # Note: num_hyperedges property fails when hyperedge_index is empty
        # This is a limitation of pyg-hyper-data's HyperData class

    def test_edge_drop_preserves_nodes(self) -> None:
        """Test that EdgeDrop preserves all node features."""
        torch.manual_seed(42)
        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor(
            [[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]]
        )

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        aug = EdgeDrop(drop_prob=0.5)
        data_aug = aug(data)

        # Node features should be identical (shared reference)
        assert torch.equal(data_aug.x, data.x), "Node features should be preserved"

    def test_edge_drop_sparse_matrix_approach(self) -> None:
        """Test that EdgeDrop uses sparse matrix approach (matches reference).

        The reference implementation:
        1. Creates sparse COO tensor
        2. Converts to dense
        3. Sets dropped edge columns to 0
        4. Converts back to sparse
        """
        torch.manual_seed(42)
        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor(
            [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]]  # 2 hyperedges
        )

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Drop second hyperedge (index 1)
        torch.manual_seed(123)  # Control randomness
        aug = EdgeDrop(drop_prob=0.5)
        data_aug = aug(data)

        # After dropping, remaining edges should have valid structure
        assert data_aug.hyperedge_index.size(0) == 2, "Should have 2 rows (node, edge)"
        assert data_aug.hyperedge_index[0].max() < 10, "Node indices should be valid"

        # With our implementation, edge indices are remapped to be contiguous (0, 1, 2, ...)
        # This makes the augmented data easier to work with

    def test_edge_drop_probability(self) -> None:
        """Test that approximately drop_prob of edges are dropped."""
        torch.manual_seed(42)
        x = torch.randn(10, 16)
        # Create many hyperedges for better statistics
        num_edges = 50
        nodes_per_edge = 3
        node_indices = []
        edge_indices = []
        for i in range(num_edges):
            for j in range(nodes_per_edge):
                node_indices.append(j)
                edge_indices.append(i)

        hyperedge_index = torch.tensor([node_indices, edge_indices])

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        drop_prob = 0.3
        aug = EdgeDrop(drop_prob=drop_prob)

        # Run multiple times
        num_trials = 100
        edges_remaining = []

        for _ in range(num_trials):
            data_aug = aug(data)
            edges_remaining.append(data_aug.num_hyperedges)

        avg_remaining = sum(edges_remaining) / num_trials
        expected = num_edges * (1 - drop_prob)

        # Allow 20% tolerance
        assert abs(avg_remaining - expected) / expected < 0.2, (
            f"Expected ~{expected:.1f} remaining edges, got {avg_remaining:.1f}"
        )


class TestAugmentationConsistency:
    """Test consistency between augmentations."""

    def test_multiple_augmentations(self) -> None:
        """Test that augmentations can be applied sequentially."""
        torch.manual_seed(42)
        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor(
            [[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]]
        )

        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Apply edge drop first
        aug1 = EdgeDrop(drop_prob=0.2)
        data1 = aug1(data)

        # Then feature mask
        aug2 = FeatureMask(mask_prob=0.3)
        data2 = aug2(data1)

        # Both augmentations should have been applied
        assert data2.num_hyperedges <= data.num_hyperedges, "Edges should be dropped"
        # Some features should be masked (dimension-wise)
        for feat_idx in range(x.size(1)):
            if (data2.x[:, feat_idx] == 0).all():
                # Found a masked feature
                break
        else:
            # This might occasionally fail due to randomness, but unlikely with 0.3 prob
            pass  # Allow this case since it's probabilistic
