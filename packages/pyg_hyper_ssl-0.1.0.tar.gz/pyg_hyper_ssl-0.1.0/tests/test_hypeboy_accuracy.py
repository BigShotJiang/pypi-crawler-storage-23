"""Tests for HypeBoy accuracy against reference implementation."""

import torch
import torch.nn.functional as F
from torch_scatter import scatter

from pyg_hyper_ssl.methods.generative import HypeBoy, HypeBoyDecoder


class TestHypeBoyAccuracy:
    """Test HypeBoy against reference implementation."""

    def test_feature_reconstruction_loss_matches_reference(self) -> None:
        """Test that feature reconstruction loss matches reference.

        Reference implementation (hypeboy/src.py:293-336):
        - Uses cosine similarity loss: mean(1 - cos(original, reconstructed))
        - Applied only to masked indices
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=128)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        torch.manual_seed(42)
        x_original = torch.randn(10, 128)
        x_reconstructed = torch.randn(10, 128)
        masked_indices = torch.tensor([0, 2, 5, 7])

        # Our implementation
        loss_ours = model.feature_reconstruction_loss(
            x_original, x_reconstructed, masked_indices
        )

        # Reference implementation
        cos = nn.CosineSimilarity(dim=1, eps=1e-6)
        loss_ref = torch.mean(
            1 - cos(x_original[masked_indices, :], x_reconstructed[masked_indices, :])
        )

        assert torch.allclose(loss_ours, loss_ref, atol=1e-6)

    def test_hyperedge_filling_scatter_aggregation(self) -> None:
        """Test scatter aggregation for hyperedge filling.

        Reference implementation (hypeboy/src.py:141-161):
        - Aggregate node embeddings using scatter with "sum" reduce
        - For each node in hyperedge, exclude it and aggregate others
        """
        torch.manual_seed(42)
        z = torch.randn(6, 64)

        # Hyperedge structure: edge 0 = [0,1,2], edge 1 = [3,4,5]
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])

        # Build aggregation structure (matching reference)
        push_vs = []
        push_idx = []
        eidx = 0

        # Edge 0: nodes [0,1,2]
        push_vs.extend([1, 2])  # Exclude 0
        push_idx.extend([eidx] * 2)
        eidx += 1

        push_vs.extend([0, 2])  # Exclude 1
        push_idx.extend([eidx] * 2)
        eidx += 1

        push_vs.extend([0, 1])  # Exclude 2
        push_idx.extend([eidx] * 2)
        eidx += 1

        # Edge 1: nodes [3,4,5]
        push_vs.extend([4, 5])  # Exclude 3
        push_idx.extend([eidx] * 2)
        eidx += 1

        push_vs.extend([3, 5])  # Exclude 4
        push_idx.extend([eidx] * 2)
        eidx += 1

        push_vs.extend([3, 4])  # Exclude 5
        push_idx.extend([eidx] * 2)
        eidx += 1

        # Aggregate using scatter
        target = torch.tensor(push_idx)
        agg_z_ref = scatter(src=z[push_vs, :], index=target, reduce="sum", dim=0)

        # Our implementation via model
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return z  # Return fixed embeddings

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        edge_dict = model._build_edge_dict(hyperedge_index)

        # Manually build aggregation (matching model's approach)
        push_vs_ours = []
        push_idx_ours = []
        eidx_ours = 0

        for edge_nodes in edge_dict.values():
            for k in range(len(edge_nodes)):
                push_vs_ours.extend(edge_nodes[:k] + edge_nodes[k + 1 :])
                push_idx_ours.extend([eidx_ours] * (len(edge_nodes) - 1))
                eidx_ours += 1

        target_ours = torch.tensor(push_idx_ours)
        agg_z_ours = scatter(
            src=z[push_vs_ours, :], index=target_ours, reduce="sum", dim=0
        )

        # Should match reference aggregation
        assert torch.allclose(agg_z_ours, agg_z_ref, atol=1e-6)

    def test_hyperedge_filling_contrastive_loss_structure(self) -> None:
        """Test contrastive loss structure for hyperedge filling.

        Reference implementation (hypeboy/src.py:155-161):
        ```python
        denom = torch.mm(aggZ, Z.transpose(1, 0))
        loss1 += -torch.sum(denom[range(len(self.pullsrc)), self.pullsrc])
        loss2 += torch.sum(torch.logsumexp(denom, dim=1))
        ```
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder, proj_hidden=64, proj_out=64)

        torch.manual_seed(42)
        z = torch.randn(6, 64)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])

        # Compute loss using model
        loss = model.hyperedge_filling_loss(z, hyperedge_index)

        # Loss should be finite and non-nan
        assert torch.isfinite(loss)
        assert not torch.isnan(loss)

    def test_edge_dict_building_matches_reference(self) -> None:
        """Test edge dictionary building matches reference.

        Reference implementation (hypeboy/src.py:36-51):
        - Builds dict mapping edge_id -> list of node_ids
        - Only includes edges with size > 1 (at least 2 nodes)
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        # Test case 1: Multiple nodes per edge
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])
        edge_dict = model._build_edge_dict(hyperedge_index)

        assert len(edge_dict) == 2
        assert edge_dict[0] == [0, 1, 2]
        assert edge_dict[1] == [3, 4, 5]

        # Test case 2: Including single-node edges (should be filtered)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 1, 1, 2, 2]])
        edge_dict = model._build_edge_dict(hyperedge_index)

        # Edge 0 has only 1 node, should be excluded
        # Edge 1 has 2 nodes: [1, 2]
        # Edge 2 has 2 nodes: [3, 4]
        assert 0 not in edge_dict  # Single-node edge excluded
        assert len(edge_dict) == 2
        assert edge_dict[1] == [1, 2]
        assert edge_dict[2] == [3, 4]

    def test_projection_head_structure(self) -> None:
        """Test projection head structure matches reference.

        Reference implementation (hypeboy/HNNs.py:386-394):
        - Two-layer MLP with ReLU
        - Used for node embeddings (head1) and aggregated embeddings (head2)
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder, proj_hidden=128, proj_out=64)

        # Check head1 structure
        assert len(model.head1) == 3
        assert isinstance(model.head1[0], nn.Linear)
        assert isinstance(model.head1[1], nn.ReLU)
        assert isinstance(model.head1[2], nn.Linear)

        # Check dimensions
        assert model.head1[0].in_features == 64
        assert model.head1[0].out_features == 128
        assert model.head1[2].in_features == 128
        assert model.head1[2].out_features == 64

        # Same for head2
        assert len(model.head2) == 3
        assert isinstance(model.head2[0], nn.Linear)
        assert isinstance(model.head2[1], nn.ReLU)
        assert isinstance(model.head2[2], nn.Linear)

    def test_normalization_in_hyperedge_filling(self) -> None:
        """Test L2 normalization in hyperedge filling loss.

        Reference implementation (hypeboy/src.py:153-157):
        - Both node embeddings and aggregated embeddings are L2 normalized
        - Uses p=2.0, dim=1, eps=1e-12
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        torch.manual_seed(42)
        z = torch.randn(6, 64) * 10  # Large magnitude

        # After projection and normalization, should have unit norm
        z_proj = model.head1(z)
        z_norm = F.normalize(z_proj, p=2.0, dim=1, eps=1e-12)

        # Check L2 norm is close to 1
        norms = torch.norm(z_norm, p=2, dim=1)
        assert torch.allclose(norms, torch.ones(6), atol=1e-5)

    def test_decoder_mask_tokens_are_learnable(self) -> None:
        """Test that decoder mask tokens are learnable parameters.

        Reference implementation (hypeboy/HNNs.py:335-337):
        - input_mask and embedding_mask are nn.Parameter
        - Used during feature reconstruction
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=128)

        # Check mask tokens are parameters
        assert isinstance(decoder.input_mask, nn.Parameter)
        assert isinstance(decoder.embedding_mask, nn.Parameter)

        # Check they are in parameter list
        param_names = [name for name, _ in decoder.named_parameters()]
        assert "input_mask" in param_names
        assert "embedding_mask" in param_names

        # Check gradient is enabled
        assert decoder.input_mask.requires_grad
        assert decoder.embedding_mask.requires_grad
