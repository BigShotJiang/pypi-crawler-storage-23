"""Tests for HyperGCL contrastive learning method."""

import torch
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.encoders import EncoderWrapper
from pyg_hyper_ssl.methods.contrastive import HyperGCL


class TestHyperGCL:
    """Tests for HyperGCL model."""

    def test_hypergcl_initialization(self) -> None:
        """Test HyperGCL initialization."""
        # Create dummy encoder
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, proj_hidden=32, proj_out=32, tau=0.5)

        assert model.tau == 0.5
        assert model.encoder is encoder
        assert len(model.projection) == 3  # Linear, ReLU, Linear

    def test_hypergcl_forward(self) -> None:
        """Test HyperGCL forward pass."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, proj_hidden=32, proj_out=32)

        # Create data
        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)
        data_aug = HyperData(x=x, hyperedge_index=hyperedge_index)

        z1, z2 = model(data, data_aug)

        assert z1.shape == (10, 32)
        assert z2.shape == (10, 32)
        assert not torch.isnan(z1).any()
        assert not torch.isnan(z2).any()

    def test_hypergcl_forward_no_aug(self) -> None:
        """Test HyperGCL forward without augmentation."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        z1, z2 = model(data, None)

        # Without augmentation, should return same embeddings
        assert torch.equal(z1, z2)

    def test_hypergcl_similarity(self) -> None:
        """Test similarity computation."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        z1 = torch.randn(5, 32)
        z2 = torch.randn(5, 32)

        sim_matrix = model.sim(z1, z2)

        assert sim_matrix.shape == (5, 5)
        # Cosine similarity should be in [-1, 1]
        assert sim_matrix.max() <= 1.0
        assert sim_matrix.min() >= -1.0

    def test_hypergcl_semi_loss(self) -> None:
        """Test semi-contrastive loss computation."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, tau=0.5)

        torch.manual_seed(42)
        z1 = torch.randn(5, 32)
        z2 = torch.randn(5, 32)

        loss = model.semi_loss(z1, z2)

        assert loss.shape == (5,)
        assert loss.min() >= 0  # Loss should be non-negative
        assert not torch.isnan(loss).any()

    def test_hypergcl_compute_loss(self) -> None:
        """Test bidirectional contrastive loss."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        z1 = torch.randn(10, 32)
        z2 = torch.randn(10, 32)

        loss = model.compute_loss(z1, z2)

        assert loss.ndim == 0  # Scalar
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_hypergcl_train_step(self) -> None:
        """Test training step."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(16, 64)
                self.out_channels = 64

            def forward_from_data(self, data):
                return self.linear(data.x)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)
        data_aug = HyperData(x=x, hyperedge_index=hyperedge_index)

        optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

        # Training step should not raise error
        loss = model.train_step(data, data_aug, optimizer)

        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_hypergcl_get_embeddings(self) -> None:
        """Test getting embeddings for downstream tasks."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)
        model.eval()

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        embeddings = model.get_embeddings(data)

        assert embeddings.shape == (10, 64)
        assert not torch.isnan(embeddings).any()

    def test_hypergcl_backward(self) -> None:
        """Test backward pass (gradient flow)."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(16, 64)
                self.out_channels = 64

            def forward_from_data(self, data):
                return self.linear(data.x)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        x = torch.randn(10, 16, requires_grad=True)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)
        data_aug = HyperData(x=x, hyperedge_index=hyperedge_index)

        z1, z2 = model(data, data_aug)
        loss = model.compute_loss(z1, z2)
        loss.backward()

        # Check that gradients are computed
        assert x.grad is not None
        assert not torch.isnan(x.grad).any()

    def test_hypergcl_projection_head(self) -> None:
        """Test projection head."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, proj_hidden=128, proj_out=64)

        h = torch.randn(10, 64)
        z = model.project(h)

        assert z.shape == (10, 64)
        assert not torch.isnan(z).any()

    def test_hypergcl_temperature(self) -> None:
        """Test that temperature affects loss."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        torch.manual_seed(42)
        encoder1 = DummyEncoder()
        model1 = HyperGCL(encoder=encoder1, tau=0.1)

        torch.manual_seed(42)
        encoder2 = DummyEncoder()
        model2 = HyperGCL(encoder=encoder2, tau=1.0)

        torch.manual_seed(42)
        z1 = torch.randn(10, 32)
        z2 = torch.randn(10, 32)

        loss1 = model1.compute_loss(z1, z2)
        loss2 = model2.compute_loss(z1, z2)

        # Different temperatures should give different losses
        assert not torch.allclose(loss1, loss2)

    def test_hypergcl_with_real_encoder(self) -> None:
        """Test HyperGCL with a real hypergraph encoder."""
        # Skip if pyg-hyper-nn not available
        try:
            from pyg_hyper_nn.models import HGNN
        except ImportError:
            return

        encoder_wrapper = EncoderWrapper(
            model_class=HGNN,
            in_channels=16,
            hidden_channels=64,
            num_layers=2,
        )

        model = HyperGCL(encoder=encoder_wrapper, proj_hidden=32, proj_out=32)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)
        data_aug = HyperData(x=x, hyperedge_index=hyperedge_index)

        z1, z2 = model(data, data_aug)

        assert z1.shape == (10, 32)
        assert z2.shape == (10, 32)

    def test_hypergcl_identical_views(self) -> None:
        """Test that identical views give lower loss than random views."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                # Return deterministic embeddings based on node features
                return (
                    data.x[:, :64]
                    if data.x.size(1) >= 64
                    else torch.cat([data.x] * (64 // data.x.size(1) + 1), dim=1)[:, :64]
                )

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        torch.manual_seed(42)
        x = torch.randn(10, 64)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        # Identical views
        z1, z2 = model(data, data)
        loss_identical = model.compute_loss(z1, z2)

        # Different views
        x2 = torch.randn(10, 64)
        data2 = HyperData(x=x2, hyperedge_index=hyperedge_index)
        z1, z3 = model(data, data2)
        loss_different = model.compute_loss(z1, z3)

        # Identical views should have lower loss
        assert loss_identical < loss_different
