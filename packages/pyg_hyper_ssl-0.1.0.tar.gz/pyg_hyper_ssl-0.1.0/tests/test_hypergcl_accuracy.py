"""Tests for HyperGCL accuracy against reference implementation."""

import torch
import torch.nn.functional as F
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.methods.contrastive import HyperGCL


class TestHyperGCLAccuracy:
    """Test HyperGCL against reference implementation."""

    def test_hypergcl_similarity_function(self) -> None:
        """Test that similarity function matches reference implementation.

        Reference implementation (HyperGCL/src/train.py:503-506):
        ```python
        def sim(z1: torch.Tensor, z2: torch.Tensor):
            z1 = F.normalize(z1)
            z2 = F.normalize(z2)
            return torch.mm(z1, z2.t())
        ```
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        torch.manual_seed(42)
        z1 = torch.randn(5, 32)
        z2 = torch.randn(5, 32)

        # Our implementation
        sim_ours = model.sim(z1, z2)

        # Reference implementation
        z1_norm = F.normalize(z1, dim=1)
        z2_norm = F.normalize(z2, dim=1)
        sim_ref = torch.mm(z1_norm, z2_norm.t())

        assert torch.allclose(sim_ours, sim_ref, atol=1e-6)

    def test_hypergcl_semi_loss_matches_reference(self) -> None:
        """Test that semi_loss matches reference implementation.

        Reference implementation (HyperGCL/src/train.py:509-515):
        ```python
        def semi_loss(z1: torch.Tensor, z2: torch.Tensor, T):
            f = lambda x: torch.exp(x / T)
            refl_sim = f(sim(z1, z1))
            between_sim = f(sim(z1, z2))
            return -torch.log(
                between_sim.diag() / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag())
            )
        ```
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        tau = 0.5
        model = HyperGCL(encoder=encoder, tau=tau)

        torch.manual_seed(42)
        z1 = torch.randn(5, 32)
        z2 = torch.randn(5, 32)

        # Our implementation
        loss_ours = model.semi_loss(z1, z2)

        # Reference implementation
        def sim_ref(z1, z2):
            z1 = F.normalize(z1, dim=1)
            z2 = F.normalize(z2, dim=1)
            return torch.mm(z1, z2.t())

        f = lambda x: torch.exp(x / tau)
        refl_sim = f(sim_ref(z1, z1))
        between_sim = f(sim_ref(z1, z2))
        loss_ref = -torch.log(
            between_sim.diag()
            / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag())
        )

        assert torch.allclose(loss_ours, loss_ref, atol=1e-6)

    def test_hypergcl_contrastive_loss_matches_reference(self) -> None:
        """Test that bidirectional contrastive loss matches reference.

        Reference implementation (HyperGCL/src/train.py:581-601):
        ```python
        def contrastive_loss_node(x1, x2, args, com_nodes=None):
            T = args.t
            if com_nodes is None:
                l1 = semi_loss(x1, x2, T)
                l2 = semi_loss(x2, x1, T)
            ret = (l1 + l2) * 0.5
            ret = ret.mean()
            return ret
        ```
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        tau = 0.5
        model = HyperGCL(encoder=encoder, tau=tau)

        torch.manual_seed(42)
        z1 = torch.randn(10, 32)
        z2 = torch.randn(10, 32)

        # Our implementation
        loss_ours = model.compute_loss(z1, z2, mean=True)

        # Reference implementation
        def sim_ref(z1, z2):
            z1 = F.normalize(z1, dim=1)
            z2 = F.normalize(z2, dim=1)
            return torch.mm(z1, z2.t())

        def semi_loss_ref(z1, z2, T):
            f = lambda x: torch.exp(x / T)
            refl_sim = f(sim_ref(z1, z1))
            between_sim = f(sim_ref(z1, z2))
            return -torch.log(
                between_sim.diag()
                / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag())
            )

        l1 = semi_loss_ref(z1, z2, tau)
        l2 = semi_loss_ref(z2, z1, tau)
        loss_ref = ((l1 + l2) * 0.5).mean()

        assert torch.allclose(loss_ours, loss_ref, atol=1e-6)

    def test_hypergcl_projection_head_structure(self) -> None:
        """Test that projection head matches reference implementation.

        Reference: HyperGCL uses MLP with ReLU activation.
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, proj_hidden=128, proj_out=64)

        # Check projection head structure
        assert len(model.projection) == 3
        assert isinstance(model.projection[0], nn.Linear)
        assert isinstance(model.projection[1], nn.ReLU)
        assert isinstance(model.projection[2], nn.Linear)

        # Check dimensions
        assert model.projection[0].in_features == 64
        assert model.projection[0].out_features == 128
        assert model.projection[2].in_features == 128
        assert model.projection[2].out_features == 64

    def test_hypergcl_temperature_effect(self) -> None:
        """Test that temperature parameter correctly affects loss.

        Lower temperature should make the loss more sensitive to similarities.
        Higher temperature should make it less sensitive.
        """
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        torch.manual_seed(42)
        z1 = torch.randn(10, 32)
        z2 = torch.randn(10, 32)

        # Low temperature (more sensitive)
        encoder1 = DummyEncoder()
        model1 = HyperGCL(encoder=encoder1, tau=0.1)
        loss_low = model1.compute_loss(z1, z2)

        # Medium temperature
        encoder2 = DummyEncoder()
        model2 = HyperGCL(encoder=encoder2, tau=0.5)
        loss_mid = model2.compute_loss(z1, z2)

        # High temperature (less sensitive)
        encoder3 = DummyEncoder()
        model3 = HyperGCL(encoder=encoder3, tau=1.0)
        loss_high = model3.compute_loss(z1, z2)

        # Lower temperature typically gives higher loss for random embeddings
        assert loss_low > loss_mid
        assert loss_mid > loss_high

    def test_hypergcl_gradient_flow(self) -> None:
        """Test that gradients flow through all components."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(16, 64)
                self.out_channels = 64

            def forward_from_data(self, data):
                return self.linear(data.x)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder, proj_hidden=32, proj_out=32)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)
        data_aug = HyperData(x=x, hyperedge_index=hyperedge_index)

        z1, z2 = model(data, data_aug)
        loss = model.compute_loss(z1, z2)
        loss.backward()

        # Check encoder gradients
        assert encoder.linear.weight.grad is not None
        assert not torch.isnan(encoder.linear.weight.grad).any()

        # Check projection head gradients
        for layer in model.projection:
            if hasattr(layer, "weight"):
                assert layer.weight.grad is not None
                assert not torch.isnan(layer.weight.grad).any()

    def test_hypergcl_normalization(self) -> None:
        """Test that embeddings are normalized in similarity computation."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        model = HyperGCL(encoder=encoder)

        # Create embeddings with different magnitudes
        z1 = torch.randn(5, 32) * 10  # Large magnitude
        z2 = torch.randn(5, 32) * 0.1  # Small magnitude

        sim = model.sim(z1, z2)

        # After normalization, similarity should be in [-1, 1]
        assert sim.max() <= 1.0
        assert sim.min() >= -1.0

        # Diagonal of self-similarity should be close to 1
        self_sim = model.sim(z1, z1)
        assert torch.allclose(self_sim.diag(), torch.ones(5), atol=1e-5)
