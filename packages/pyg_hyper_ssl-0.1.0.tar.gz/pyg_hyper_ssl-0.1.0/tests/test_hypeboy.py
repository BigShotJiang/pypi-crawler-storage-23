"""Tests for HypeBoy implementation."""

import torch
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.methods.generative import HypeBoy, HypeBoyDecoder


class TestHypeBoyDecoder:
    """Test HypeBoyDecoder."""

    def test_decoder_initialization(self) -> None:
        """Test decoder initialization."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(
            encoder=encoder, in_dim=64, out_dim=128, hidden_dim=64, num_layers=2
        )

        assert decoder.in_dim == 64
        assert decoder.out_dim == 128
        assert decoder.hidden_dim == 64
        assert decoder.num_layers == 2
        assert decoder.input_mask.shape == (128,)
        assert decoder.embedding_mask.shape == (64,)

    def test_decoder_forward(self) -> None:
        """Test decoder forward pass."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(
            encoder=encoder, in_dim=64, out_dim=128, hidden_dim=64, num_layers=2
        )

        z = torch.randn(10, 64)
        x_recon = decoder(z)

        assert x_recon.shape == (10, 128)
        assert not torch.isnan(x_recon).any()

    def test_decoder_reset_parameters(self) -> None:
        """Test decoder parameter reset."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=128, hidden_dim=64)

        # Mask tokens should be zero after reset
        decoder.reset_parameters()
        assert torch.allclose(decoder.input_mask, torch.zeros(128))
        assert torch.allclose(decoder.embedding_mask, torch.zeros(64))


class TestHypeBoy:
    """Test HypeBoy."""

    def test_hypeboy_initialization(self) -> None:
        """Test HypeBoy initialization."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=128)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        assert model.encoder == encoder
        assert model.decoder == decoder
        assert model.feature_recon_epochs == 300
        assert model.hyperedge_fill_epochs == 200

    def test_hypeboy_forward(self) -> None:
        """Test HypeBoy forward pass."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 0, 1, 1, 1]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        model = HypeBoy(encoder=encoder, decoder=decoder)
        h, x_recon = model(data)

        assert h.shape == (10, 64)
        assert x_recon.shape == (10, 16)
        assert not torch.isnan(h).any()
        assert not torch.isnan(x_recon).any()

    def test_feature_reconstruction_loss(self) -> None:
        """Test feature reconstruction loss."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        x_original = torch.randn(10, 16)
        x_reconstructed = torch.randn(10, 16)
        masked_indices = torch.tensor([0, 2, 5])

        loss = model.feature_reconstruction_loss(
            x_original, x_reconstructed, masked_indices
        )

        assert loss.shape == ()
        assert loss.item() >= 0
        assert not torch.isnan(loss).any()

    def test_hyperedge_filling_loss(self) -> None:
        """Test hyperedge filling loss."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        z = torch.randn(10, 64)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])

        loss = model.hyperedge_filling_loss(z, hyperedge_index)

        assert loss.shape == ()
        assert not torch.isnan(loss).any()

    def test_build_edge_dict(self) -> None:
        """Test edge dictionary building."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])
        edge_dict = model._build_edge_dict(hyperedge_index)

        assert len(edge_dict) == 2
        assert edge_dict[0] == [0, 1, 2]
        assert edge_dict[1] == [3, 4, 5]

    def test_compute_loss_feature_recon(self) -> None:
        """Test compute_loss for feature reconstruction."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        x_original = torch.randn(10, 16)
        x_reconstructed = torch.randn(10, 16)
        masked_indices = torch.tensor([0, 2, 5])

        loss = model.compute_loss(
            stage="feature_recon",
            x_original=x_original,
            x_reconstructed=x_reconstructed,
            masked_indices=masked_indices,
        )

        assert loss.shape == ()
        assert loss.item() >= 0

    def test_compute_loss_hyperedge_fill(self) -> None:
        """Test compute_loss for hyperedge filling."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        z = torch.randn(10, 64)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1]])

        loss = model.compute_loss(
            stage="hyperedge_fill", z=z, hyperedge_index=hyperedge_index
        )

        assert loss.shape == ()
        assert not torch.isnan(loss).any()

    def test_get_embeddings(self) -> None:
        """Test get_embeddings."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        embeddings = model.get_embeddings(data)

        assert embeddings.shape == (10, 64)
        assert not torch.isnan(embeddings).any()

    def test_empty_hyperedges(self) -> None:
        """Test with empty hyperedges."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.out_channels = 64

            def forward_from_data(self, data):
                return torch.randn(data.num_nodes, self.out_channels)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        z = torch.randn(10, 64)
        hyperedge_index = torch.tensor([[], []]).long()

        loss = model.hyperedge_filling_loss(z, hyperedge_index)

        # Should return 0 for empty hyperedges
        assert loss.item() == 0.0

    def test_gradient_flow(self) -> None:
        """Test that gradients flow through all components."""
        from torch import nn

        class DummyEncoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(16, 64)
                self.out_channels = 64

            def forward_from_data(self, data):
                return self.linear(data.x)

        encoder = DummyEncoder()
        decoder = HypeBoyDecoder(encoder=encoder, in_dim=64, out_dim=16)
        model = HypeBoy(encoder=encoder, decoder=decoder)

        x = torch.randn(10, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 0, 0, 1, 1]])
        data = HyperData(x=x, hyperedge_index=hyperedge_index)

        _h, x_recon = model(data)
        masked_indices = torch.tensor([0, 2, 5])
        loss = model.feature_reconstruction_loss(x, x_recon, masked_indices)
        loss.backward()

        # Check encoder gradients
        assert encoder.linear.weight.grad is not None
        assert not torch.isnan(encoder.linear.weight.grad).any()

        # Check decoder gradients
        for layer in decoder.decoder:
            if hasattr(layer, "weight"):
                assert layer.weight.grad is not None
                assert not torch.isnan(layer.weight.grad).any()
