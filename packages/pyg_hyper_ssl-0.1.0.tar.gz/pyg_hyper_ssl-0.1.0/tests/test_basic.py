"""Basic tests for pyg-hyper-ssl core components."""

import pytest
import torch
from pyg_hyper_data.data import HyperData

from pyg_hyper_ssl.augmentations import EdgeDrop, FeatureMask
from pyg_hyper_ssl.encoders import EncoderWrapper
from pyg_hyper_ssl.losses import InfoNCE


def create_dummy_hyperdata(
    num_nodes: int = 10, num_hyperedges: int = 5, num_features: int = 16
) -> HyperData:
    """Create dummy hypergraph data for testing."""
    # Create node features
    x = torch.randn(num_nodes, num_features)

    # Create hyperedge_index (each hyperedge connects 3 nodes)
    hyperedge_index = []
    for e in range(num_hyperedges):
        nodes = torch.randint(0, num_nodes, (3,))
        for node in nodes:
            hyperedge_index.append([node.item(), e])

    hyperedge_index = torch.tensor(hyperedge_index).t()

    # Create node labels
    y = torch.randint(0, 3, (num_nodes,))

    return HyperData(x=x, hyperedge_index=hyperedge_index, y=y)


class TestEdgeDrop:
    """Tests for EdgeDrop augmentation."""

    def test_edge_drop_basic(self) -> None:
        """Test basic edge dropping."""
        data = create_dummy_hyperdata(num_nodes=10, num_hyperedges=10)
        aug = EdgeDrop(drop_prob=0.5)

        data_aug = aug(data)

        # Check that some edges are dropped
        assert data_aug.num_hyperedges <= data.num_hyperedges
        # Check that node features are preserved
        assert torch.equal(data_aug.x, data.x)

    def test_edge_drop_zero_prob(self) -> None:
        """Test edge dropping with zero probability."""
        data = create_dummy_hyperdata()
        aug = EdgeDrop(drop_prob=0.0)

        data_aug = aug(data)

        # Should be identical
        assert data_aug.num_hyperedges == data.num_hyperedges

    def test_edge_drop_invalid_prob(self) -> None:
        """Test edge dropping with invalid probability."""
        with pytest.raises(ValueError):
            EdgeDrop(drop_prob=1.5)

        with pytest.raises(ValueError):
            EdgeDrop(drop_prob=-0.1)


class TestFeatureMask:
    """Tests for FeatureMask augmentation."""

    def test_feature_mask_basic(self) -> None:
        """Test basic feature masking."""
        data = create_dummy_hyperdata(num_nodes=10, num_features=16)
        aug = FeatureMask(mask_prob=0.5)

        data_aug = aug(data)

        # Check that features are masked (some zeros introduced)
        num_zeros_orig = (data.x == 0).sum().item()
        num_zeros_aug = (data_aug.x == 0).sum().item()
        assert num_zeros_aug >= num_zeros_orig

        # Check that structure is preserved
        assert data_aug.num_hyperedges == data.num_hyperedges
        assert torch.equal(data_aug.hyperedge_index, data.hyperedge_index)

    def test_feature_mask_zero_prob(self) -> None:
        """Test feature masking with zero probability."""
        data = create_dummy_hyperdata()
        aug = FeatureMask(mask_prob=0.0)

        data_aug = aug(data)

        # Should be identical
        assert torch.equal(data_aug.x, data.x)

    def test_feature_mask_invalid_prob(self) -> None:
        """Test feature masking with invalid probability."""
        with pytest.raises(ValueError):
            FeatureMask(mask_prob=1.5)

        with pytest.raises(ValueError):
            FeatureMask(mask_prob=-0.1)


class TestInfoNCE:
    """Tests for InfoNCE loss."""

    def test_info_nce_basic(self) -> None:
        """Test basic InfoNCE loss computation."""
        loss_fn = InfoNCE(temperature=0.5)

        z1 = torch.randn(100, 64)
        z2 = torch.randn(100, 64)

        loss = loss_fn(z1, z2)

        # Check that loss is a scalar
        assert loss.dim() == 0
        # Check that loss is positive
        assert loss.item() > 0

    def test_info_nce_same_embeddings(self) -> None:
        """Test InfoNCE with identical embeddings."""
        loss_fn = InfoNCE(temperature=0.5)

        z = torch.randn(50, 32)

        # Same embeddings should still have reasonable loss
        # (because negative pairs are still formed from other samples)
        loss = loss_fn(z, z)
        assert loss.item() > 0  # Loss should be positive

    def test_info_nce_invalid_temperature(self) -> None:
        """Test InfoNCE with invalid temperature."""
        with pytest.raises(ValueError):
            InfoNCE(temperature=0.0)

        with pytest.raises(ValueError):
            InfoNCE(temperature=-0.5)


class TestEncoderWrapper:
    """Tests for EncoderWrapper."""

    @pytest.mark.skipif(
        not hasattr(torch, "cuda") or not torch.cuda.is_available(),
        reason="Test requires pyg-hyper-nn models",
    )
    def test_encoder_wrapper_basic(self) -> None:
        """Test basic encoder wrapper functionality."""
        try:
            from pyg_hyper_nn.models import HGNN

            encoder = EncoderWrapper(
                model_class=HGNN,
                in_channels=16,
                hidden_channels=32,
                num_layers=2,
            )

            # Test forward pass
            x = torch.randn(10, 16)
            hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

            h, z = encoder(x, hyperedge_index)

            # Check output shapes
            assert h.shape == (10, 32)
            assert z.shape == (10, 32)
            # Without projection, h and z should be the same
            assert torch.equal(h, z)

        except ImportError:
            pytest.skip("pyg-hyper-nn not installed")


def test_imports() -> None:
    """Test that all imports work."""
    from pyg_hyper_ssl import (
        BaseAugmentation,
        BaseLoss,
        BaseSSLMethod,
        ComposedAugmentation,
        CompositeLoss,
        EncoderWrapper,
        RandomChoice,
    )

    assert BaseSSLMethod is not None
    assert BaseAugmentation is not None
    assert BaseLoss is not None
    assert EncoderWrapper is not None
    assert ComposedAugmentation is not None
    assert RandomChoice is not None
    assert CompositeLoss is not None
