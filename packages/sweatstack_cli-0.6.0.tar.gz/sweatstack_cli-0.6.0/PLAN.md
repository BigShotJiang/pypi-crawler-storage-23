# SweatStack CLI — Implementation Plan

## Overview

A lightweight, production-grade CLI for the SweatStack platform built with [Typer](https://typer.tiangolo.com/). Standalone authentication implementation with minimal dependencies. Compatible with the `sweatstack` Python library's token storage for seamless interoperability.

---

## Design Principles

1. **Minimal dependencies** — Only what's necessary: `typer`, `httpx`, `platformdirs`
2. **Fresh implementation** — Clean, modern Python 3.13+ code, not legacy copy-paste
3. **Token compatibility** — Shares token storage with `sweatstack` library
4. **Explicit over magic** — Clear error messages, no hidden behavior
5. **Testable** — Dependency injection, no global state

---

## Architecture

### Project Structure

```
src/sweatstack_cli/
├── __init__.py                 # Package version
├── main.py                     # Typer app entrypoint
├── auth/
│   ├── __init__.py             # Public auth API
│   ├── pkce.py                 # PKCE challenge generation
│   ├── callback_server.py      # Local OAuth callback server
│   ├── tokens.py               # TokenStore: load, save, refresh
│   └── jwt.py                  # Minimal JWT payload decoding
├── commands/
│   ├── __init__.py
│   ├── auth.py                 # login, logout, whoami, status
│   └── pages.py                # pages deploy, list, delete
├── api/
│   ├── __init__.py
│   ├── client.py               # Authenticated HTTP client
│   └── endpoints.py            # API endpoint definitions
├── config.py                   # Settings via env vars
├── console.py                  # Rich console for output
└── exceptions.py               # CLI exception hierarchy
```

### Dependencies

```toml
[project]
dependencies = [
    "typer>=0.15.0",       # CLI framework (includes rich)
    "httpx>=0.28.0",       # HTTP client
    "platformdirs>=4.0",   # OS-appropriate directories
]

[project.scripts]
sweatstack = "sweatstack_cli.main:app"

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-httpx>=0.35",
    "ruff>=0.9",
    "mypy>=1.14",
]
```

**Install size: ~3MB** (vs ~60MB with sweatstack library dependency)

---

## Token Storage — Compatibility Contract

The CLI shares token storage with the `sweatstack` Python library. This is a **documented contract** that both projects must honor.

### Storage Location

```python
import platformdirs

def get_tokens_path() -> Path:
    """Token file path — shared with sweatstack Python library."""
    data_dir = Path(platformdirs.user_data_dir("SweatStack", "SweatStack"))
    return data_dir / "tokens.json"
```

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/SweatStack/SweatStack/tokens.json` |
| Linux | `~/.local/share/SweatStack/SweatStack/tokens.json` |
| Windows | `%APPDATA%\SweatStack\SweatStack\tokens.json` |

### File Format

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIs..."
}
```

### Security

- File permissions: `0o600` (owner read/write only)
- Directory created with `0o700` if missing
- Tokens never logged or printed

---

## Authentication — Implementation Details

### Core Data Types

```python
# src/sweatstack_cli/auth/tokens.py

from dataclasses import dataclass
from pathlib import Path
import time

@dataclass(frozen=True, slots=True)
class TokenPair:
    """Immutable token pair with expiry checking."""
    access_token: str
    refresh_token: str

    def is_expired(self, margin_seconds: int = 30) -> bool:
        """Check if access token expires within margin."""
        from sweatstack_cli.auth.jwt import decode_jwt_payload
        payload = decode_jwt_payload(self.access_token)
        exp = payload.get("exp", 0)
        return time.time() >= (exp - margin_seconds)


@dataclass(frozen=True, slots=True)
class PKCEChallenge:
    """PKCE parameters for OAuth2 authorization."""
    verifier: str
    challenge: str
    state: str
```

### PKCE Implementation

```python
# src/sweatstack_cli/auth/pkce.py

import secrets
import hashlib
import base64

def generate_pkce() -> PKCEChallenge:
    """Generate PKCE challenge per RFC 7636."""
    # 64 bytes = 86 base64url chars (within 43-128 range)
    verifier = secrets.token_urlsafe(64)

    # S256: BASE64URL(SHA256(verifier))
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    # State for CSRF protection
    state = secrets.token_urlsafe(32)

    return PKCEChallenge(verifier=verifier, challenge=challenge, state=state)
```

### JWT Payload Decoding

```python
# src/sweatstack_cli/auth/jwt.py

import base64
import json

def decode_jwt_payload(token: str) -> dict:
    """
    Decode JWT payload without signature verification.

    We only need to read claims (exp, sub) for local decisions.
    The API server validates signatures on every request.
    """
    try:
        payload_b64 = token.split(".")[1]
        # Add padding if needed
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload_bytes = base64.urlsafe_b64decode(padded)
        return json.loads(payload_bytes)
    except (IndexError, ValueError, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid JWT format: {e}") from e
```

### Token Store

```python
# src/sweatstack_cli/auth/tokens.py

import json
import os
from pathlib import Path
from typing import Protocol

class TokenStorage(Protocol):
    """Protocol for token persistence — enables testing with fakes."""
    def load(self) -> TokenPair | None: ...
    def save(self, tokens: TokenPair) -> None: ...
    def delete(self) -> None: ...


class FileTokenStorage:
    """
    Filesystem token storage.

    Compatible with sweatstack Python library token format.
    """

    def __init__(self, path: Path | None = None):
        self._path = path or get_tokens_path()

    def load(self) -> TokenPair | None:
        """Load tokens from disk. Returns None if not found."""
        if not self._path.exists():
            return None

        try:
            data = json.loads(self._path.read_text())
            return TokenPair(
                access_token=data["access_token"],
                refresh_token=data["refresh_token"],
            )
        except (json.JSONDecodeError, KeyError):
            return None

    def save(self, tokens: TokenPair) -> None:
        """Persist tokens with secure permissions."""
        self._path.parent.mkdir(parents=True, exist_ok=True)

        # Write to temp file first, then atomic rename
        tmp_path = self._path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps({
            "access_token": tokens.access_token,
            "refresh_token": tokens.refresh_token,
        }))

        # Set restrictive permissions before rename
        os.chmod(tmp_path, 0o600)
        tmp_path.rename(self._path)

    def delete(self) -> None:
        """Remove stored tokens."""
        if self._path.exists():
            self._path.unlink()
```

### OAuth2 Callback Server

```python
# src/sweatstack_cli/auth/callback_server.py

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from dataclasses import dataclass
import threading
import socket

@dataclass
class AuthorizationResult:
    """Result from OAuth callback."""
    code: str
    state: str


class CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth2 redirect callback."""

    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)

        if "error" in query:
            self.server.error = query["error"][0]  # type: ignore
            self._respond_error(query.get("error_description", ["Unknown error"])[0])
            return

        if "code" not in query or "state" not in query:
            self.server.error = "Missing code or state"  # type: ignore
            self._respond_error("Invalid callback parameters")
            return

        self.server.result = AuthorizationResult(  # type: ignore
            code=query["code"][0],
            state=query["state"][0],
        )
        self._respond_success()

    def _respond_success(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"""
            <!DOCTYPE html>
            <html>
            <head><title>SweatStack CLI</title></head>
            <body style="font-family: system-ui; text-align: center; padding: 50px;">
                <h1>Authentication successful</h1>
                <p>You can close this window and return to the terminal.</p>
            </body>
            </html>
        """)

    def _respond_error(self, message: str):
        self.send_response(400)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(f"""
            <!DOCTYPE html>
            <html>
            <head><title>SweatStack CLI - Error</title></head>
            <body style="font-family: system-ui; text-align: center; padding: 50px;">
                <h1>Authentication failed</h1>
                <p>{message}</p>
            </body>
            </html>
        """.encode())

    def log_message(self, format, *args):
        pass  # Silence HTTP logs


class CallbackServer:
    """
    Local HTTP server to receive OAuth2 callback.

    Finds an available port and waits for the authorization response.
    """

    def __init__(self, timeout: float = 120.0):
        self._timeout = timeout
        self._server: HTTPServer | None = None

    def get_redirect_uri(self) -> str:
        """Start server and return redirect URI."""
        # Find available port in range
        for port in range(8400, 8500):
            try:
                self._server = HTTPServer(("localhost", port), CallbackHandler)
                self._server.result = None  # type: ignore
                self._server.error = None   # type: ignore
                return f"http://localhost:{port}/callback"
            except OSError:
                continue
        raise RuntimeError("No available port for OAuth callback server")

    def wait_for_callback(self, expected_state: str) -> AuthorizationResult:
        """
        Block until callback received or timeout.

        Validates state parameter to prevent CSRF.
        """
        if not self._server:
            raise RuntimeError("Server not started")

        self._server.timeout = self._timeout

        while True:
            self._server.handle_request()

            if self._server.error:  # type: ignore
                raise AuthenticationError(self._server.error)  # type: ignore

            if self._server.result:  # type: ignore
                result: AuthorizationResult = self._server.result  # type: ignore
                if result.state != expected_state:
                    raise AuthenticationError("State mismatch — possible CSRF attack")
                return result

    def shutdown(self):
        if self._server:
            self._server.server_close()
```

### OAuth2 Flow Orchestration

```python
# src/sweatstack_cli/auth/__init__.py

import webbrowser
from urllib.parse import urlencode
import httpx

from sweatstack_cli.auth.pkce import generate_pkce
from sweatstack_cli.auth.callback_server import CallbackServer
from sweatstack_cli.auth.tokens import TokenPair, FileTokenStorage, TokenStorage
from sweatstack_cli.config import get_settings
from sweatstack_cli.exceptions import AuthenticationError

# Public OAuth2 client ID for CLI applications
CLIENT_ID = "5382f68b0d254378"
SCOPES = "data:read data:write profile"


class Authenticator:
    """
    OAuth2 PKCE authentication flow.

    Handles browser-based login and token management.
    """

    def __init__(self, storage: TokenStorage | None = None):
        self._storage = storage or FileTokenStorage()
        self._settings = get_settings()

    def login(self, force: bool = False) -> TokenPair:
        """
        Authenticate user via browser OAuth2 flow.

        Args:
            force: If True, re-authenticate even if valid tokens exist.

        Returns:
            TokenPair with access and refresh tokens.
        """
        # Check existing tokens
        if not force:
            tokens = self.get_valid_tokens()
            if tokens:
                return tokens

        # Start callback server
        server = CallbackServer(timeout=120.0)
        redirect_uri = server.get_redirect_uri()

        try:
            # Generate PKCE challenge
            pkce = generate_pkce()

            # Build authorization URL
            auth_url = self._build_auth_url(redirect_uri, pkce)

            # Open browser
            webbrowser.open(auth_url)

            # Wait for callback
            result = server.wait_for_callback(expected_state=pkce.state)

            # Exchange code for tokens
            tokens = self._exchange_code(
                code=result.code,
                redirect_uri=redirect_uri,
                code_verifier=pkce.verifier,
            )

            # Persist tokens
            self._storage.save(tokens)

            return tokens

        finally:
            server.shutdown()

    def get_valid_tokens(self) -> TokenPair | None:
        """
        Get tokens, refreshing if expired.

        Returns None if no tokens or refresh fails.
        """
        tokens = self._load_tokens()
        if not tokens:
            return None

        if tokens.is_expired(margin_seconds=30):
            try:
                tokens = self._refresh_tokens(tokens.refresh_token)
                self._storage.save(tokens)
            except AuthenticationError:
                return None

        return tokens

    def logout(self) -> None:
        """Remove stored credentials."""
        self._storage.delete()

    def _load_tokens(self) -> TokenPair | None:
        """Load tokens from environment or storage."""
        # Environment variables take precedence (for CI/CD)
        import os
        access = os.environ.get("SWEATSTACK_API_KEY")
        refresh = os.environ.get("SWEATSTACK_REFRESH_TOKEN")
        if access and refresh:
            return TokenPair(access_token=access, refresh_token=refresh)

        return self._storage.load()

    def _build_auth_url(self, redirect_uri: str, pkce) -> str:
        """Construct OAuth2 authorization URL."""
        params = {
            "client_id": CLIENT_ID,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": SCOPES,
            "code_challenge": pkce.challenge,
            "code_challenge_method": "S256",
            "state": pkce.state,
        }
        return f"{self._settings.api_url}/oauth/authorize?{urlencode(params)}"

    def _exchange_code(
        self, code: str, redirect_uri: str, code_verifier: str
    ) -> TokenPair:
        """Exchange authorization code for tokens."""
        with httpx.Client() as client:
            response = client.post(
                f"{self._settings.api_url}/api/v1/oauth/token",
                data={
                    "grant_type": "authorization_code",
                    "client_id": CLIENT_ID,
                    "code": code,
                    "code_verifier": code_verifier,
                    "redirect_uri": redirect_uri,
                },
            )

        if response.status_code != 200:
            raise AuthenticationError(f"Token exchange failed: {response.text}")

        data = response.json()
        return TokenPair(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )

    def _refresh_tokens(self, refresh_token: str) -> TokenPair:
        """Refresh expired access token."""
        with httpx.Client() as client:
            response = client.post(
                f"{self._settings.api_url}/api/v1/oauth/token",
                data={
                    "grant_type": "refresh_token",
                    "client_id": CLIENT_ID,
                    "refresh_token": refresh_token,
                },
            )

        if response.status_code != 200:
            raise AuthenticationError("Token refresh failed — please login again")

        data = response.json()
        return TokenPair(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token", refresh_token),
        )
```

---

## OAuth2 Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  $ sweatstack login                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  1. Check existing tokens                                                   │
│     • Load from env (SWEATSTACK_API_KEY) or ~/.../tokens.json               │
│     • If valid and not expired → return early                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │ (no valid tokens)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  2. Generate PKCE parameters                                                │
│     • verifier: secrets.token_urlsafe(64)  → 86 chars                       │
│     • challenge: base64url(sha256(verifier))                                │
│     • state: secrets.token_urlsafe(32)     → CSRF protection                │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  3. Start local callback server                                             │
│     • Scan ports 8400-8499 for available port                               │
│     • Listen on http://localhost:{port}/callback                            │
│     • 120 second timeout                                                    │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  4. Open browser to authorization URL                                       │
│                                                                             │
│     https://app.sweatstack.no/oauth/authorize?                              │
│       client_id=5382f68b0d254378                                            │
│       &redirect_uri=http://localhost:{port}/callback                        │
│       &response_type=code                                                   │
│       &scope=data:read+data:write+profile                                   │
│       &code_challenge={challenge}                                           │
│       &code_challenge_method=S256                                           │
│       &state={state}                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    ▼                               ▼
           ┌──────────────┐                ┌──────────────────┐
           │  User logs   │                │ User denies or   │
           │  in via      │                │ closes browser   │
           │  browser     │                └────────┬─────────┘
           └──────┬───────┘                         │
                  │                                 ▼
                  │                        ┌──────────────────┐
                  │                        │ Timeout after    │
                  │                        │ 120 seconds      │
                  │                        │ → Error exit     │
                  │                        └──────────────────┘
                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  5. Receive callback                                                        │
│     • Browser redirects to http://localhost:{port}/callback?code=X&state=Y  │
│     • Validate state matches original (CSRF protection)                     │
│     • Show success page in browser                                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  6. Exchange code for tokens                                                │
│                                                                             │
│     POST https://app.sweatstack.no/api/v1/oauth/token                       │
│     Content-Type: application/x-www-form-urlencoded                         │
│                                                                             │
│     grant_type=authorization_code                                           │
│     &client_id=5382f68b0d254378                                             │
│     &code={authorization_code}                                              │
│     &code_verifier={verifier}                                               │
│     &redirect_uri=http://localhost:{port}/callback                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  7. Persist tokens                                                          │
│     • Write to ~/.../SweatStack/SweatStack/tokens.json                      │
│     • Atomic write via temp file + rename                                   │
│     • Set file permissions to 0o600                                         │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  ✓ Logged in as {user.name}                                                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## API Client

```python
# src/sweatstack_cli/api/client.py

from contextlib import contextmanager
from typing import Generator, Any
import httpx

from sweatstack_cli.auth import Authenticator
from sweatstack_cli.config import get_settings
from sweatstack_cli.exceptions import AuthenticationError, APIError


class APIClient:
    """
    HTTP client with automatic authentication.

    Handles token refresh transparently on each request.
    """

    def __init__(self, authenticator: Authenticator | None = None):
        self._auth = authenticator or Authenticator()
        self._settings = get_settings()

    @contextmanager
    def _http(self) -> Generator[httpx.Client, None, None]:
        """Provide authenticated httpx client."""
        tokens = self._auth.get_valid_tokens()
        if not tokens:
            raise AuthenticationError("Not authenticated. Run 'sweatstack login' first.")

        with httpx.Client(
            base_url=self._settings.api_url,
            headers={
                "Authorization": f"Bearer {tokens.access_token}",
                "User-Agent": f"sweatstack-cli/{self._settings.version}",
            },
            timeout=30.0,
        ) as client:
            yield client

    def get(self, path: str, **kwargs) -> dict[str, Any]:
        """GET request with automatic auth."""
        with self._http() as client:
            response = client.get(path, **kwargs)
            return self._handle_response(response)

    def post(self, path: str, **kwargs) -> dict[str, Any]:
        """POST request with automatic auth."""
        with self._http() as client:
            response = client.post(path, **kwargs)
            return self._handle_response(response)

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response, raising appropriate errors."""
        if response.status_code == 401:
            raise AuthenticationError("Session expired. Run 'sweatstack login' again.")

        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIError(f"API error ({response.status_code}): {detail}")

        return response.json()
```

---

## CLI Commands

### Main Entry Point

```python
# src/sweatstack_cli/main.py

import typer
from sweatstack_cli.commands import auth, pages
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import CLIError

app = typer.Typer(
    name="sweatstack",
    help="SweatStack CLI — Deploy and manage your sports data applications.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,  # We handle exceptions ourselves
)

# Command groups
app.add_typer(pages.app, name="pages")

# Top-level auth commands (common operations promoted for convenience)
app.command()(auth.login)
app.command()(auth.logout)
app.command()(auth.whoami)
app.command()(auth.status)


def main():
    """Entry point with global error handling."""
    try:
        app()
    except CLIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(e.exit_code)
    except KeyboardInterrupt:
        console.print("\n[dim]Cancelled[/dim]")
        raise typer.Exit(130)


if __name__ == "__main__":
    main()
```

### Auth Commands

```python
# src/sweatstack_cli/commands/auth.py

import typer
from sweatstack_cli.auth import Authenticator
from sweatstack_cli.auth.jwt import decode_jwt_payload
from sweatstack_cli.api.client import APIClient
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import AuthenticationError


def login(
    force: bool = typer.Option(
        False, "--force", "-f",
        help="Force re-authentication even if already logged in"
    ),
):
    """Authenticate with SweatStack via browser."""
    auth = Authenticator()

    with console.status("[bold]Opening browser for authentication...[/bold]"):
        tokens = auth.login(force=force)

    # Fetch user info to confirm
    client = APIClient(authenticator=auth)
    user = client.get("/api/v1/users/me")

    console.print(f"[green]✓[/green] Logged in as [bold]{user['name']}[/bold]")


def logout():
    """Remove stored credentials."""
    auth = Authenticator()
    auth.logout()
    console.print("[green]✓[/green] Logged out")


def whoami():
    """Show current authenticated user."""
    try:
        client = APIClient()
        user = client.get("/api/v1/users/me")
        console.print(f"Logged in as: [bold]{user['name']}[/bold] ({user['email']})")
    except AuthenticationError:
        console.print("[yellow]Not logged in[/yellow]")
        raise typer.Exit(1)


def status():
    """Show authentication status and token info."""
    auth = Authenticator()
    tokens = auth.get_valid_tokens()

    if not tokens:
        console.print("[yellow]Not authenticated[/yellow]")
        console.print("Run [bold]sweatstack login[/bold] to authenticate")
        raise typer.Exit(1)

    payload = decode_jwt_payload(tokens.access_token)

    import datetime
    exp = datetime.datetime.fromtimestamp(payload["exp"])
    console.print(f"[green]✓[/green] Authenticated")
    console.print(f"  User ID: {payload.get('sub', 'unknown')}")
    console.print(f"  Expires: {exp.isoformat()}")
```

### Pages Commands

```python
# src/sweatstack_cli/commands/pages.py

import typer
from pathlib import Path
from rich.progress import Progress, SpinnerColumn, TextColumn

from sweatstack_cli.api.client import APIClient
from sweatstack_cli.console import console

app = typer.Typer(name="pages", help="Deploy and manage static sites")


@app.command()
def deploy(
    directory: Path = typer.Argument(
        ".",
        help="Directory containing static files",
        exists=True,
        file_okay=False,
        resolve_path=True,
    ),
    project: str | None = typer.Option(
        None, "--project", "-p",
        help="Project name (defaults to directory name)"
    ),
    production: bool = typer.Option(
        False, "--prod",
        help="Deploy to production environment"
    ),
):
    """Deploy a static site to SweatStack Pages."""
    client = APIClient()
    project_name = project or directory.name

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(f"Deploying [bold]{project_name}[/bold]...", total=None)

        # TODO: Implement file upload and deployment API call
        # result = client.post("/api/v1/pages/deploy", ...)
        pass

    console.print(f"\n[green]✓[/green] Deployed successfully!")
    # console.print(f"  URL: {result['url']}")


@app.command(name="list")
def list_sites():
    """List all Pages sites."""
    client = APIClient()
    # TODO: Implement
    console.print("[dim]No sites yet[/dim]")


@app.command()
def delete(
    project: str = typer.Argument(..., help="Project name to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Pages site."""
    if not force:
        confirm = typer.confirm(f"Delete site '{project}'?")
        if not confirm:
            raise typer.Abort()

    client = APIClient()
    # TODO: Implement
    console.print(f"[green]✓[/green] Deleted {project}")
```

---

## Configuration

```python
# src/sweatstack_cli/config.py

import os
from dataclasses import dataclass
from functools import cache


@dataclass(frozen=True, slots=True)
class Settings:
    """Application settings loaded from environment."""
    api_url: str
    version: str


@cache
def get_settings() -> Settings:
    """Load settings (cached)."""
    from sweatstack_cli import __version__

    return Settings(
        api_url=os.environ.get("SWEATSTACK_URL", "https://app.sweatstack.no"),
        version=__version__,
    )
```

---

## Exceptions

```python
# src/sweatstack_cli/exceptions.py

class CLIError(Exception):
    """Base for all CLI errors with exit codes."""
    exit_code: int = 1


class AuthenticationError(CLIError):
    """Authentication failed or not logged in."""
    exit_code = 2


class APIError(CLIError):
    """API returned an error."""
    exit_code = 3


class ValidationError(CLIError):
    """Invalid user input."""
    exit_code = 4
```

---

## Console

```python
# src/sweatstack_cli/console.py

from rich.console import Console

# Singleton console for consistent output
console = Console()
```

---

## Testing Strategy

### Unit Tests

```python
# tests/test_auth/test_pkce.py

from sweatstack_cli.auth.pkce import generate_pkce
import base64
import hashlib

def test_pkce_verifier_length():
    pkce = generate_pkce()
    assert 43 <= len(pkce.verifier) <= 128

def test_pkce_challenge_is_s256():
    pkce = generate_pkce()
    # Verify challenge matches S256(verifier)
    expected = hashlib.sha256(pkce.verifier.encode()).digest()
    expected_b64 = base64.urlsafe_b64encode(expected).rstrip(b"=").decode()
    assert pkce.challenge == expected_b64

def test_pkce_state_is_random():
    a = generate_pkce()
    b = generate_pkce()
    assert a.state != b.state
```

```python
# tests/test_auth/test_tokens.py

from sweatstack_cli.auth.tokens import FileTokenStorage, TokenPair

def test_save_and_load(tmp_path):
    storage = FileTokenStorage(tmp_path / "tokens.json")
    tokens = TokenPair(access_token="access", refresh_token="refresh")

    storage.save(tokens)
    loaded = storage.load()

    assert loaded == tokens

def test_load_missing_file(tmp_path):
    storage = FileTokenStorage(tmp_path / "nonexistent.json")
    assert storage.load() is None

def test_file_permissions(tmp_path):
    import stat
    storage = FileTokenStorage(tmp_path / "tokens.json")
    storage.save(TokenPair(access_token="a", refresh_token="b"))

    mode = (tmp_path / "tokens.json").stat().st_mode
    assert stat.S_IMODE(mode) == 0o600
```

### Integration Tests with Mocked HTTP

```python
# tests/test_auth/test_oauth_flow.py

import pytest
from pytest_httpx import HTTPXMock

def test_code_exchange(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://app.sweatstack.no/api/v1/oauth/token",
        json={"access_token": "new_access", "refresh_token": "new_refresh"},
    )

    from sweatstack_cli.auth import Authenticator
    auth = Authenticator()
    tokens = auth._exchange_code("code", "http://localhost/callback", "verifier")

    assert tokens.access_token == "new_access"
```

---

## Implementation Phases

### Phase 1: Auth Foundation
- [ ] Set up project structure
- [ ] Implement PKCE generation
- [ ] Implement JWT payload decoding
- [ ] Implement token storage (FileTokenStorage)
- [ ] Implement OAuth callback server
- [ ] Implement Authenticator class
- [ ] Implement auth commands (login, logout, whoami, status)
- [ ] Unit tests for auth components

### Phase 2: API Client
- [ ] Implement APIClient with auth injection
- [ ] Error handling for 401, 4xx, 5xx
- [ ] Integration tests with mocked HTTP

### Phase 3: Pages Commands
- [ ] Implement `pages deploy` (file bundling, upload)
- [ ] Implement `pages list`
- [ ] Implement `pages delete`
- [ ] Progress indicators and UX polish

### Phase 4: Polish
- [ ] Shell completion (`--install-completion`)
- [ ] `--version` flag
- [ ] Comprehensive `--help` text
- [ ] CI/CD documentation
- [ ] Error message refinement

---

## Environment Variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `SWEATSTACK_URL` | API base URL | `https://app.sweatstack.no` |
| `SWEATSTACK_API_KEY` | Access token (CI/CD) | — |
| `SWEATSTACK_REFRESH_TOKEN` | Refresh token (CI/CD) | — |

---

## Example Session

```bash
# First time authentication
$ sweatstack login
Opening browser for authentication...
✓ Logged in as Aart Goossens

# Check status
$ sweatstack status
✓ Authenticated
  User ID: usr_abc123
  Expires: 2025-01-15T14:30:00

# Show user info
$ sweatstack whoami
Logged in as: Aart Goossens (aart@goossens.me)

# Deploy a site
$ sweatstack pages deploy ./dist --prod
Deploying dist...
✓ Deployed successfully!
  URL: https://my-app.sweatstack.pages.dev

# Logout
$ sweatstack logout
✓ Logged out
```
