"""Tests for project configuration."""

from __future__ import annotations

from pathlib import Path

from sweatstack_cli.project import ProjectConfig, write_config


class TestWriteConfig:
    """Tests for write_config function."""

    def test_writes_app_only(self, tmp_path: Path) -> None:
        """Should write config with app section only."""
        config_path = tmp_path / "sweatstack.toml"

        write_config(
            path=config_path,
            app_name="My App",
            client_id="abc123",
        )

        content = config_path.read_text()
        assert '[app]' in content
        assert 'name = "My App"' in content
        assert 'client_id = "abc123"' in content
        assert '[page]' not in content

    def test_writes_app_and_page(self, tmp_path: Path) -> None:
        """Should write config with both sections."""
        config_path = tmp_path / "sweatstack.toml"

        write_config(
            path=config_path,
            app_name="My App",
            client_id="abc123",
            page_slug="my-page",
            page_directory="dist",
        )

        content = config_path.read_text()
        assert '[app]' in content
        assert '[page]' in content
        assert 'slug = "my-page"' in content
        assert 'directory = "dist"' in content

    def test_returns_path(self, tmp_path: Path) -> None:
        """Should return the path to the config file."""
        config_path = tmp_path / "sweatstack.toml"

        result = write_config(path=config_path, app_name="Test")

        assert result == config_path


class TestProjectConfigLoad:
    """Tests for ProjectConfig.load method."""

    def test_loads_full_config(self, tmp_path: Path) -> None:
        """Should load all fields from config file."""
        config_path = tmp_path / "sweatstack.toml"
        config_path.write_text('''
[app]
name = "My App"
client_id = "abc123"

[page]
slug = "my-page"
directory = "dist"
''')

        config = ProjectConfig.load(config_path)

        assert config is not None
        assert config.app.name == "My App"
        assert config.app.client_id == "abc123"
        assert config.page.slug == "my-page"
        assert config.page.directory == "dist"

    def test_loads_partial_config(self, tmp_path: Path) -> None:
        """Should handle missing optional fields."""
        config_path = tmp_path / "sweatstack.toml"
        config_path.write_text('''
[app]
client_id = "abc123"
''')

        config = ProjectConfig.load(config_path)

        assert config is not None
        assert config.app.name is None
        assert config.app.client_id == "abc123"
        assert config.page.slug is None

    def test_returns_none_for_missing_file(self, tmp_path: Path) -> None:
        """Should return None if file doesn't exist."""
        config_path = tmp_path / "nonexistent.toml"

        config = ProjectConfig.load(config_path)

        assert config is None

    def test_returns_none_for_invalid_toml(self, tmp_path: Path) -> None:
        """Should return None for invalid TOML."""
        config_path = tmp_path / "sweatstack.toml"
        config_path.write_text("not valid toml [[[")

        config = ProjectConfig.load(config_path)

        assert config is None
