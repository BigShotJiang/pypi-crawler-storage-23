"""Tests for app commands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from sweatstack_cli.exceptions import APIError, AuthenticationError
from sweatstack_cli.main import app

runner = CliRunner()


@pytest.fixture
def mock_api():
    """Mock APIClient for testing."""
    with patch("sweatstack_cli.commands.app.APIClient") as mock_client:
        mock_instance = MagicMock()
        mock_client.return_value = mock_instance
        yield mock_instance


class TestAppCreate:
    """Tests for app create command."""

    def test_create_minimal(self, mock_api: MagicMock) -> None:
        """Should create an app with just a name."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
        }

        result = runner.invoke(app, ["app", "create", "Test App"])

        assert result.exit_code == 0
        assert "Test App" in result.stdout
        assert "abc123" in result.stdout
        mock_api.post.assert_called_once_with(
            "/api/v1/applications",
            json={"name": "Test App"},
        )

    def test_create_with_page(self, mock_api: MagicMock) -> None:
        """Should create an app with page association."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "redirect_uris": ["https://myapp.sweatstack.pages.dev/callback"],
        }

        result = runner.invoke(app, ["app", "create", "Test App", "--page", "myapp"])

        assert result.exit_code == 0
        assert "myapp.sweatstack.pages.dev" in result.stdout
        mock_api.post.assert_called_once_with(
            "/api/v1/applications",
            json={"name": "Test App", "page": "myapp"},
        )

    def test_create_with_secret(self, mock_api: MagicMock) -> None:
        """Should create an app with client secret and show warning."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "client_secret": "secret456",
        }

        result = runner.invoke(app, ["app", "create", "Test App", "--secret"])

        assert result.exit_code == 0
        assert "secret456" in result.stdout
        assert "won't be shown again" in result.stdout
        mock_api.post.assert_called_once_with(
            "/api/v1/applications",
            json={"name": "Test App", "generate_secret": True},
        )

    def test_create_with_short_flags(self, mock_api: MagicMock) -> None:
        """Should support short flags -p and -s."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "client_secret": "secret456",
        }

        result = runner.invoke(app, ["app", "create", "Test App", "-p", "myapp", "-s"])

        assert result.exit_code == 0
        mock_api.post.assert_called_once_with(
            "/api/v1/applications",
            json={"name": "Test App", "page": "myapp", "generate_secret": True},
        )

    def test_create_json_output(self, mock_api: MagicMock) -> None:
        """Should output JSON when --json flag is used."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
        }

        result = runner.invoke(app, ["app", "create", "Test App", "--json"])

        assert result.exit_code == 0
        assert '"client_id": "abc123"' in result.stdout
        assert '"name": "Test App"' in result.stdout

    def test_create_with_env(self, mock_api: MagicMock, tmp_path: Path) -> None:
        """Should write credentials to .env file."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "client_secret": "secret456",
        }

        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(app, ["app", "create", "Test App", "--secret", "--env"])

            assert result.exit_code == 0
            assert "written to" in result.stdout

            env_content = Path(".env").read_text()
            assert "SWEATSTACK_CLIENT_ID=abc123" in env_content
            assert "SWEATSTACK_CLIENT_SECRET=secret456" in env_content

    def test_create_with_env_file(self, mock_api: MagicMock, tmp_path: Path) -> None:
        """Should write credentials to custom env file."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
        }

        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                app, ["app", "create", "Test App", "--env-file", ".env.local"]
            )

            assert result.exit_code == 0
            env_content = Path(".env.local").read_text()
            assert "SWEATSTACK_CLIENT_ID=abc123" in env_content

    def test_create_env_appends_to_existing(
        self, mock_api: MagicMock, tmp_path: Path
    ) -> None:
        """Should append to existing .env file."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
        }

        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path(".env").write_text("EXISTING_VAR=value\n")

            result = runner.invoke(app, ["app", "create", "Test App", "--env"])

            assert result.exit_code == 0
            env_content = Path(".env").read_text()
            assert "EXISTING_VAR=value" in env_content
            assert "SWEATSTACK_CLIENT_ID=abc123" in env_content

    def test_create_env_no_overwrite(
        self, mock_api: MagicMock, tmp_path: Path
    ) -> None:
        """Should not overwrite existing env vars."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
        }

        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path(".env").write_text("SWEATSTACK_CLIENT_ID=existing\n")

            result = runner.invoke(app, ["app", "create", "Test App", "--env"])

            assert result.exit_code == 0

            # Verify the existing value was preserved
            env_content = Path(".env").read_text()
            assert "SWEATSTACK_CLIENT_ID=existing" in env_content
            assert "abc123" not in env_content

    def test_create_env_and_env_file_mutually_exclusive(self) -> None:
        """Should error when both --env and --env-file are used."""
        result = runner.invoke(
            app, ["app", "create", "Test App", "--env", "--env-file", ".env.local"]
        )

        assert result.exit_code == 4  # ValidationError
        assert "mutually exclusive" in result.stdout

    def test_create_not_authenticated(self) -> None:
        """Should error when not authenticated."""
        with patch("sweatstack_cli.commands.app.APIClient") as mock_client:
            mock_client.side_effect = AuthenticationError("Not authenticated")

            result = runner.invoke(app, ["app", "create", "Test App"])

            assert result.exit_code == 2
            assert "Not authenticated" in result.stdout
            assert "sweatstack login" in result.stdout

    def test_create_api_error(self, mock_api: MagicMock) -> None:
        """Should handle API errors."""
        mock_api.post.side_effect = APIError("App name already exists")

        result = runner.invoke(app, ["app", "create", "Test App"])

        assert result.exit_code == 3
        assert "App name already exists" in result.stdout

    def test_create_env_with_secret_no_warning_without_env(
        self, mock_api: MagicMock
    ) -> None:
        """Should show secret warning when --env is not used."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "client_secret": "secret456",
        }

        result = runner.invoke(app, ["app", "create", "Test App", "--secret"])

        assert result.exit_code == 0
        assert "won't be shown again" in result.stdout

    def test_create_env_with_secret_no_warning_with_env(
        self, mock_api: MagicMock, tmp_path: Path
    ) -> None:
        """Should not show secret warning when --env is used."""
        mock_api.post.return_value = {
            "name": "Test App",
            "client_id": "abc123",
            "client_secret": "secret456",
        }

        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(app, ["app", "create", "Test App", "--secret", "--env"])

            assert result.exit_code == 0
            assert "won't be shown again" not in result.stdout
            assert "written to" in result.stdout
