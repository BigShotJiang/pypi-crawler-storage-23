"""Tests for JWT decoding."""

from __future__ import annotations

import base64
import json

import pytest

from sweatstack_cli.auth.jwt import decode_jwt_payload


class TestDecodeJWTPayload:
    """Tests for decode_jwt_payload function."""

    def test_decodes_valid_jwt(self) -> None:
        """Should decode a valid JWT payload."""
        # Create a test JWT
        header = base64.urlsafe_b64encode(b'{"alg":"HS256"}').rstrip(b"=").decode()
        payload = (
            base64.urlsafe_b64encode(b'{"sub":"user_123","exp":1234567890}').rstrip(b"=").decode()
        )
        token = f"{header}.{payload}.signature"

        result = decode_jwt_payload(token)

        assert result == {"sub": "user_123", "exp": 1234567890}

    def test_handles_padding(self) -> None:
        """Should handle base64 strings that need padding."""
        # Payload that requires padding when decoded
        payload_data = {"sub": "a", "exp": 1}
        payload_json = json.dumps(payload_data)
        payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).rstrip(b"=").decode()

        token = f"header.{payload_b64}.signature"

        result = decode_jwt_payload(token)
        assert result == payload_data

    def test_raises_on_invalid_format_no_dots(self) -> None:
        """Should raise ValueError for token without dots."""
        with pytest.raises(ValueError, match="JWT must have exactly 3 parts"):
            decode_jwt_payload("nodots")

    def test_raises_on_invalid_format_one_dot(self) -> None:
        """Should raise ValueError for token with only one dot."""
        with pytest.raises(ValueError, match="JWT must have exactly 3 parts"):
            decode_jwt_payload("one.dot")

    def test_raises_on_invalid_format_four_parts(self) -> None:
        """Should raise ValueError for token with too many parts."""
        with pytest.raises(ValueError, match="JWT must have exactly 3 parts"):
            decode_jwt_payload("a.b.c.d")

    def test_raises_on_invalid_base64(self) -> None:
        """Should raise ValueError for invalid base64 in payload."""
        with pytest.raises(ValueError, match="Invalid JWT format"):
            decode_jwt_payload("header.!!!invalid!!!.signature")

    def test_raises_on_invalid_json(self) -> None:
        """Should raise ValueError for non-JSON payload."""
        # Valid base64 but not JSON
        payload = base64.urlsafe_b64encode(b"not json").rstrip(b"=").decode()
        with pytest.raises(ValueError, match="Invalid JWT format"):
            decode_jwt_payload(f"header.{payload}.signature")

    def test_empty_payload(self) -> None:
        """Should decode empty JSON object."""
        payload = base64.urlsafe_b64encode(b"{}").rstrip(b"=").decode()
        token = f"header.{payload}.signature"

        result = decode_jwt_payload(token)
        assert result == {}

    def test_complex_payload(self) -> None:
        """Should decode complex nested payload."""
        payload_data = {
            "sub": "user_123",
            "exp": 9999999999,
            "iat": 1234567890,
            "tz": "Europe/Amsterdam",
            "roles": ["admin", "user"],
            "meta": {"key": "value"},
        }
        payload_json = json.dumps(payload_data)
        payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).rstrip(b"=").decode()

        token = f"header.{payload_b64}.signature"

        result = decode_jwt_payload(token)
        assert result == payload_data
