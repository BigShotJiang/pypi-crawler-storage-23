"""Tests for token storage."""

from __future__ import annotations

import stat
import sys
from pathlib import Path

import pytest

from sweatstack_cli.auth.tokens import FileTokenStorage, TokenPair, get_tokens_path


class TestTokenPair:
    """Tests for TokenPair dataclass."""

    def test_is_immutable(self) -> None:
        """TokenPair should be frozen."""
        tokens = TokenPair(access_token="access", refresh_token="refresh")

        with pytest.raises(AttributeError):
            tokens.access_token = "new"  # type: ignore[misc]

    def test_is_expired_with_future_exp(self, sample_tokens: TokenPair) -> None:
        """Should return False for token with future expiry."""
        assert sample_tokens.is_expired() is False

    def test_is_expired_with_past_exp(self, expired_tokens: TokenPair) -> None:
        """Should return True for token with past expiry."""
        assert expired_tokens.is_expired() is True

    def test_is_expired_with_margin(self) -> None:
        """Should consider margin when checking expiry."""
        import time

        # Create token expiring in 10 seconds
        exp = int(time.time()) + 10
        import base64

        payload = base64.urlsafe_b64encode(f'{{"exp":{exp}}}'.encode()).rstrip(b"=").decode()
        token = f"header.{payload}.sig"

        tokens = TokenPair(access_token=token, refresh_token="refresh")

        # With 5 second margin, should not be expired
        assert tokens.is_expired(margin_seconds=5) is False

        # With 15 second margin, should be expired
        assert tokens.is_expired(margin_seconds=15) is True

    def test_is_expired_with_invalid_token(self) -> None:
        """Should treat invalid tokens as expired."""
        tokens = TokenPair(access_token="invalid", refresh_token="refresh")
        assert tokens.is_expired() is True


class TestFileTokenStorage:
    """Tests for FileTokenStorage class."""

    def test_save_and_load(self, tmp_path: Path) -> None:
        """Should save and load tokens correctly."""
        storage = FileTokenStorage(tmp_path / "tokens.json")
        tokens = TokenPair(access_token="access_123", refresh_token="refresh_456")

        storage.save(tokens)
        loaded = storage.load()

        assert loaded is not None
        assert loaded.access_token == "access_123"
        assert loaded.refresh_token == "refresh_456"

    def test_load_missing_file(self, tmp_path: Path) -> None:
        """Should return None for missing file."""
        storage = FileTokenStorage(tmp_path / "nonexistent.json")

        assert storage.load() is None

    def test_load_invalid_json(self, tmp_path: Path) -> None:
        """Should return None for corrupted file."""
        path = tmp_path / "tokens.json"
        path.write_text("not valid json")

        storage = FileTokenStorage(path)
        assert storage.load() is None

    def test_load_missing_keys(self, tmp_path: Path) -> None:
        """Should return None for file missing required keys."""
        path = tmp_path / "tokens.json"
        path.write_text('{"access_token": "only_access"}')

        storage = FileTokenStorage(path)
        assert storage.load() is None

    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        """Should create parent directories if they don't exist."""
        path = tmp_path / "nested" / "dir" / "tokens.json"
        storage = FileTokenStorage(path)
        tokens = TokenPair(access_token="a", refresh_token="b")

        storage.save(tokens)

        assert path.exists()
        assert storage.load() == tokens

    @pytest.mark.skipif(sys.platform == "win32", reason="Unix permissions")
    def test_file_permissions(self, tmp_path: Path) -> None:
        """Should set restrictive file permissions."""
        path = tmp_path / "tokens.json"
        storage = FileTokenStorage(path)
        tokens = TokenPair(access_token="a", refresh_token="b")

        storage.save(tokens)

        mode = path.stat().st_mode
        assert stat.S_IMODE(mode) == 0o600

    def test_delete_existing(self, tmp_path: Path) -> None:
        """Should delete existing file."""
        path = tmp_path / "tokens.json"
        path.write_text("{}")

        storage = FileTokenStorage(path)
        storage.delete()

        assert not path.exists()

    def test_delete_missing(self, tmp_path: Path) -> None:
        """Should not raise for missing file."""
        storage = FileTokenStorage(tmp_path / "nonexistent.json")
        storage.delete()  # Should not raise

    def test_atomic_write(self, tmp_path: Path) -> None:
        """Should write atomically via temp file."""
        path = tmp_path / "tokens.json"
        storage = FileTokenStorage(path)

        # Write initial tokens
        tokens1 = TokenPair(access_token="first", refresh_token="first")
        storage.save(tokens1)

        # Write new tokens
        tokens2 = TokenPair(access_token="second", refresh_token="second")
        storage.save(tokens2)

        # No temp file should remain
        assert not (tmp_path / "tokens.tmp").exists()
        assert storage.load() == tokens2

    def test_path_property(self, tmp_path: Path) -> None:
        """Should expose path via property."""
        path = tmp_path / "tokens.json"
        storage = FileTokenStorage(path)

        assert storage.path == path


class TestGetTokensPath:
    """Tests for get_tokens_path function."""

    def test_returns_path(self) -> None:
        """Should return a Path object."""
        result = get_tokens_path()
        assert isinstance(result, Path)

    def test_ends_with_tokens_json(self) -> None:
        """Should point to tokens.json."""
        result = get_tokens_path()
        assert result.name == "tokens.json"

    def test_contains_sweatstack(self) -> None:
        """Should be in a SweatStack directory."""
        result = get_tokens_path()
        assert "SweatStack" in str(result)
