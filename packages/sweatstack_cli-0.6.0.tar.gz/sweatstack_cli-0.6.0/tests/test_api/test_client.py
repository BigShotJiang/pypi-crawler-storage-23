"""Tests for API client."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import Mock

import pytest

from sweatstack_cli.api.client import APIClient
from sweatstack_cli.auth import Authenticator
from sweatstack_cli.auth.tokens import TokenPair
from sweatstack_cli.exceptions import APIError, AuthenticationError

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock


class TestAPIClient:
    """Tests for APIClient class."""

    @pytest.fixture
    def mock_auth(self, sample_tokens: TokenPair) -> Authenticator:
        """Create mock authenticator with valid tokens."""
        auth = Mock(spec=Authenticator)
        auth.get_valid_tokens.return_value = sample_tokens
        return auth

    @pytest.fixture
    def mock_auth_no_tokens(self) -> Authenticator:
        """Create mock authenticator with no tokens."""
        auth = Mock(spec=Authenticator)
        auth.get_valid_tokens.return_value = None
        return auth

    def test_get_success(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should make authenticated GET request."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            json={"data": "value"},
        )

        client = APIClient(authenticator=mock_auth)
        result = client.get("/api/v1/test")

        assert result == {"data": "value"}

        # Verify auth header was sent
        request = httpx_mock.get_request()
        assert request is not None
        assert "Authorization" in request.headers
        assert request.headers["Authorization"].startswith("Bearer ")

    def test_post_success(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should make authenticated POST request."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            method="POST",
            json={"id": 123},
        )

        client = APIClient(authenticator=mock_auth)
        result = client.post("/api/v1/test", json={"name": "test"})

        assert result == {"id": 123}

    def test_raises_when_not_authenticated(
        self,
        mock_auth_no_tokens: Authenticator,
    ) -> None:
        """Should raise AuthenticationError when no tokens."""
        client = APIClient(authenticator=mock_auth_no_tokens)

        with pytest.raises(AuthenticationError, match="Not authenticated"):
            client.get("/api/v1/test")

    def test_raises_on_401(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should raise AuthenticationError on 401 response."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            status_code=401,
            json={"detail": "Token expired"},
        )

        client = APIClient(authenticator=mock_auth)

        with pytest.raises(AuthenticationError, match="Session expired"):
            client.get("/api/v1/test")

    def test_raises_on_4xx(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should raise APIError on 4xx response."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            status_code=404,
            json={"detail": "Not found"},
        )

        client = APIClient(authenticator=mock_auth)

        with pytest.raises(APIError, match="Not found"):
            client.get("/api/v1/test")

    def test_raises_on_5xx(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should raise APIError on 5xx response."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            status_code=500,
            text="Internal Server Error",
        )

        client = APIClient(authenticator=mock_auth)

        with pytest.raises(APIError, match="500"):
            client.get("/api/v1/test")

    def test_extracts_validation_errors(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should extract FastAPI validation error details."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            status_code=422,
            json={
                "detail": [
                    {"loc": ["body", "name"], "msg": "field required"},
                    {"loc": ["body", "email"], "msg": "invalid email"},
                ]
            },
        )

        client = APIClient(authenticator=mock_auth)

        with pytest.raises(APIError) as exc_info:
            client.post("/api/v1/test", json={})

        assert "name: field required" in str(exc_info.value)
        assert "email: invalid email" in str(exc_info.value)

    def test_delete_returns_none_on_204(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should return None for 204 No Content."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test/1",
            method="DELETE",
            status_code=204,
        )

        client = APIClient(authenticator=mock_auth)
        result = client.delete("/api/v1/test/1")

        assert result is None

    def test_includes_user_agent(
        self,
        httpx_mock: HTTPXMock,
        mock_auth: Authenticator,
    ) -> None:
        """Should include User-Agent header."""
        httpx_mock.add_response(
            url="https://app.sweatstack.no/api/v1/test",
            json={},
        )

        client = APIClient(authenticator=mock_auth)
        client.get("/api/v1/test")

        request = httpx_mock.get_request()
        assert request is not None
        assert "User-Agent" in request.headers
        assert request.headers["User-Agent"].startswith("sweatstack-cli/")
