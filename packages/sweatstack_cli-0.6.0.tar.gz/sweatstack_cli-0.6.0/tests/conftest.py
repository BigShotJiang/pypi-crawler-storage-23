"""Pytest fixtures for SweatStack CLI tests."""

from __future__ import annotations

import os
from collections.abc import Generator
from pathlib import Path

import pytest

from sweatstack_cli.auth.tokens import FileTokenStorage, TokenPair


@pytest.fixture
def temp_token_storage(tmp_path: Path) -> FileTokenStorage:
    """Provide a token storage instance using a temporary directory."""
    return FileTokenStorage(tmp_path / "tokens.json")


@pytest.fixture
def sample_tokens() -> TokenPair:
    """Provide sample token pair for testing."""
    # This is a valid JWT structure (but with fake signature)
    # Header: {"alg": "HS256", "typ": "JWT"}
    # Payload: {"sub": "user_123", "exp": 9999999999, "tz": "UTC"}
    access_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiJ1c2VyXzEyMyIsImV4cCI6OTk5OTk5OTk5OSwidHoiOiJVVEMifQ."
        "fake_signature"
    )
    refresh_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiJ1c2VyXzEyMyIsInR5cGUiOiJyZWZyZXNoIn0."
        "fake_signature"
    )
    return TokenPair(access_token=access_token, refresh_token=refresh_token)


@pytest.fixture
def expired_tokens() -> TokenPair:
    """Provide expired token pair for testing."""
    # Payload: {"sub": "user_123", "exp": 0, "tz": "UTC"}
    access_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiJ1c2VyXzEyMyIsImV4cCI6MCwidHoiOiJVVEMifQ."
        "fake_signature"
    )
    refresh_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiJ1c2VyXzEyMyIsInR5cGUiOiJyZWZyZXNoIn0."
        "fake_signature"
    )
    return TokenPair(access_token=access_token, refresh_token=refresh_token)


@pytest.fixture
def clean_env() -> Generator[None]:
    """Remove SweatStack environment variables for test isolation."""
    env_vars = ["SWEATSTACK_API_KEY", "SWEATSTACK_REFRESH_TOKEN", "SWEATSTACK_URL"]
    saved = {k: os.environ.pop(k, None) for k in env_vars}

    yield

    # Restore original values
    for k, v in saved.items():
        if v is not None:
            os.environ[k] = v
        elif k in os.environ:
            del os.environ[k]
