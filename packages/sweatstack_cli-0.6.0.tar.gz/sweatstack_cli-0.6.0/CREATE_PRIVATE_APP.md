# Plan: Add `app create` Command + Rename `pages` → `page`

## Overview

1. Add functionality to create private OAuth2 applications through the CLI
2. Rename `pages` command to `page` for consistency (singular command names)

---

## Part 1: Rename `pages` → `page`

### Rationale

Consistent singular command names across the CLI:
- `sweatstack app create` (new)
- `sweatstack page deploy` (renamed from `pages`)
- `sweatstack login` / `logout` / `whoami` (existing)

This matches the convention used by `gh`, `gcloud`, `aws`, `az`, `docker`, and `fly`.

### Changes Required

| File | Change |
|------|--------|
| `src/sweatstack_cli/commands/pages.py` | Rename to `page.py`, update Typer name |
| `src/sweatstack_cli/main.py` | Update import and registration |
| `tests/test_commands/test_pages.py` | Rename to `test_page.py`, update tests |

### Code Changes

**`src/sweatstack_cli/commands/page.py`** (renamed from `pages.py`):
```python
app = typer.Typer(name="page", help="Deploy static sites to SweatStack Pages.")
```

**`src/sweatstack_cli/main.py`**:
```python
from sweatstack_cli.commands import auth, page  # was: pages

app.add_typer(page.app, name="page")  # was: pages
```

---

## Part 2: Add `app create` Command

### CLI Interface

```bash
sweatstack app create NAME [--page SLUG] [--secret] [--env | --env-file PATH] [--json]
```

### Examples

```bash
# Minimal
sweatstack app create "My App"

# With page (redirect URI auto-included)
sweatstack app create "My App" --page myapp

# With secret, written to .env
sweatstack app create "My App" --secret --env

# Full example
sweatstack app create "My App" --page myapp --secret --env-file .env.local
```

### Design Decisions

| Element | Design | Rationale |
|---------|--------|-----------|
| `NAME` | Positional (required) | Primary identifier, always needed |
| `--page SLUG` | Option | Associates a SweatStack Page; auto-includes redirect URI |
| `--secret` / `-s` | Flag | Generates client secret (explicit opt-in for security) |
| `--env` | Flag | Write credentials to `.env` in current directory |
| `--env-file PATH` | Option | Write credentials to custom path (mutually exclusive with `--env`) |
| `--json` | Flag | Output JSON for scripting/CI |

### Notes

- When `--page` is specified, the API automatically adds the page URL to redirect URIs (no opt-out needed)
- Warnings (e.g., "variable already exists") are written to stderr to keep stdout clean for `--json` piping

### API Mapping

```
CLI                    →  API Request Body
────────────────────────────────────────────────────────────
NAME (positional)      →  "name": "..."
--page SLUG            →  "page": "..."
--secret               →  "generate_secret": true
```

---

## Implementation

### File: `src/sweatstack_cli/commands/app.py`

```python
"""Application management commands."""

from __future__ import annotations

import json as json_lib
from pathlib import Path

import typer

from sweatstack_cli.api.client import APIClient
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import APIError, AuthenticationError, ValidationError

app = typer.Typer(name="app", help="Manage OAuth2 applications.")


@app.command()
def create(
    name: str = typer.Argument(..., help="Application name."),
    page: str | None = typer.Option(
        None, "--page", "-p",
        help="Associate with a SweatStack Page (includes redirect URI).",
    ),
    secret: bool = typer.Option(
        False, "--secret", "-s",
        help="Generate a client secret.",
    ),
    env: bool = typer.Option(
        False, "--env",
        help="Write credentials to .env file.",
    ),
    env_file: Path | None = typer.Option(
        None, "--env-file",
        help="Write credentials to specified file.",
    ),
    json_output: bool = typer.Option(
        False, "--json",
        help="Output as JSON.",
    ),
) -> None:
    """Create a new private OAuth2 application."""
    # Validate mutually exclusive options
    if env and env_file:
        raise ValidationError("--env and --env-file are mutually exclusive.")

    # Build request body
    body: dict[str, str | bool] = {"name": name}

    if page:
        body["page"] = page

    if secret:
        body["generate_secret"] = True

    # Make API call
    try:
        client = APIClient()
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        console.print("[dim]Run 'sweatstack login' to authenticate.[/dim]")
        raise typer.Exit(2)

    try:
        result = client.post("/api/v1/applications", json=body)
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(3)

    # Write to env file if requested
    env_path = Path(".env") if env else env_file
    if env_path:
        _write_env_file(env_path, result)

    # Output result
    if json_output:
        console.print(json_lib.dumps(result, indent=2))
    else:
        _print_app_created(result, env_path)


def _write_env_file(path: Path, result: dict) -> None:
    """Append credentials to an env file."""
    lines_to_add: list[str] = []
    existing_content = ""

    if path.exists():
        existing_content = path.read_text()

    # Check for existing variables and prepare new lines
    client_id = result.get("client_id")
    client_secret = result.get("client_secret")

    if client_id:
        if "SWEATSTACK_CLIENT_ID=" in existing_content:
            # Use stderr so it doesn't pollute JSON output
            console.print(f"[yellow]Warning:[/yellow] SWEATSTACK_CLIENT_ID already exists in {path}, skipping.", stderr=True)
        else:
            lines_to_add.append(f"SWEATSTACK_CLIENT_ID={client_id}")

    if client_secret:
        if "SWEATSTACK_CLIENT_SECRET=" in existing_content:
            console.print(f"[yellow]Warning:[/yellow] SWEATSTACK_CLIENT_SECRET already exists in {path}, skipping.", stderr=True)
        else:
            lines_to_add.append(f"SWEATSTACK_CLIENT_SECRET={client_secret}")

    if lines_to_add:
        # Ensure file ends with newline before appending
        if existing_content and not existing_content.endswith("\n"):
            lines_to_add.insert(0, "")

        with path.open("a") as f:
            f.write("\n".join(lines_to_add) + "\n")


def _print_app_created(result: dict, env_path: Path | None) -> None:
    """Pretty-print the created application details."""
    console.print(f"[green]✓[/green] Created application [bold]{result['name']}[/bold]")
    console.print()
    console.print(f"  Client ID:  [cyan]{result['client_id']}[/cyan]")

    if "client_secret" in result:
        console.print(f"  Secret:     [cyan]{result['client_secret']}[/cyan]")

    if "redirect_uris" in result and result["redirect_uris"]:
        console.print()
        console.print("  Redirect URIs:")
        for uri in result["redirect_uris"]:
            console.print(f"    • {uri}")

    # Show env file status or secret warning
    if env_path:
        console.print()
        console.print(f"[green]✓[/green] Credentials written to [bold]{env_path}[/bold]")
    elif "client_secret" in result:
        console.print()
        console.print("[yellow]Save the secret now — it won't be shown again.[/yellow]")
```

### File: `src/sweatstack_cli/main.py`

Add import and registration:

```python
from sweatstack_cli.commands import auth, page, app as app_commands

# ... existing registrations ...

app.add_typer(page.app, name="page")  # renamed from pages
app.add_typer(app_commands.app, name="app")  # new
```

---

## Tests

### File: `tests/test_commands/test_app.py`

```python
"""Tests for app commands."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from sweatstack_cli.main import app

runner = CliRunner()


@pytest.fixture
def mock_api():
    """Mock APIClient for testing."""
    with patch("sweatstack_cli.commands.app.APIClient") as mock_client:
        mock_instance = MagicMock()
        mock_client.return_value = mock_instance
        yield mock_instance


def test_app_create_minimal(mock_api):
    """Test creating an app with just a name."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
    }

    result = runner.invoke(app, ["app", "create", "Test App"])

    assert result.exit_code == 0
    assert "Test App" in result.stdout
    assert "abc123" in result.stdout
    mock_api.post.assert_called_once_with(
        "/api/v1/applications",
        json={"name": "Test App"},
    )


def test_app_create_with_page(mock_api):
    """Test creating an app with page association."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
        "redirect_uris": ["https://myapp.sweatstack.pages.dev/callback"],
    }

    result = runner.invoke(app, ["app", "create", "Test App", "--page", "myapp"])

    assert result.exit_code == 0
    mock_api.post.assert_called_once_with(
        "/api/v1/applications",
        json={
            "name": "Test App",
            "page": "myapp",
        },
    )


def test_app_create_with_secret(mock_api):
    """Test creating an app with client secret."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
        "client_secret": "secret456",
    }

    result = runner.invoke(app, ["app", "create", "Test App", "--secret"])

    assert result.exit_code == 0
    assert "secret456" in result.stdout
    assert "won't be shown again" in result.stdout


def test_app_create_with_env(mock_api, tmp_path):
    """Test writing credentials to .env file."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
        "client_secret": "secret456",
    }

    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["app", "create", "Test App", "--secret", "--env"])

        assert result.exit_code == 0
        assert "written to" in result.stdout

        env_content = Path(".env").read_text()
        assert "SWEATSTACK_CLIENT_ID=abc123" in env_content
        assert "SWEATSTACK_CLIENT_SECRET=secret456" in env_content


def test_app_create_with_env_file(mock_api, tmp_path):
    """Test writing credentials to custom env file."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
    }

    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["app", "create", "Test App", "--env-file", ".env.local"])

        assert result.exit_code == 0
        env_content = Path(".env.local").read_text()
        assert "SWEATSTACK_CLIENT_ID=abc123" in env_content


def test_app_create_env_no_overwrite(mock_api, tmp_path):
    """Test that existing env vars are not overwritten."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
    }

    with runner.isolated_filesystem(temp_dir=tmp_path):
        Path(".env").write_text("SWEATSTACK_CLIENT_ID=existing\n")

        result = runner.invoke(app, ["app", "create", "Test App", "--env"])

        assert result.exit_code == 0
        assert "already exists" in result.stdout

        env_content = Path(".env").read_text()
        assert "SWEATSTACK_CLIENT_ID=existing" in env_content
        assert "abc123" not in env_content


def test_app_create_env_and_env_file_mutually_exclusive():
    """Test that --env and --env-file cannot be used together."""
    result = runner.invoke(app, ["app", "create", "Test App", "--env", "--env-file", ".env.local"])

    assert result.exit_code == 4  # ValidationError
    assert "mutually exclusive" in result.stdout


def test_app_create_not_authenticated():
    """Test error when not authenticated."""
    with patch("sweatstack_cli.commands.app.APIClient") as mock_client:
        from sweatstack_cli.exceptions import AuthenticationError
        mock_client.side_effect = AuthenticationError("Not authenticated")

        result = runner.invoke(app, ["app", "create", "Test App"])

        assert result.exit_code == 2
        assert "Not authenticated" in result.stdout
        assert "sweatstack login" in result.stdout


def test_app_create_api_error(mock_api):
    """Test error when API returns an error."""
    from sweatstack_cli.exceptions import APIError
    mock_api.post.side_effect = APIError("App name already exists")

    result = runner.invoke(app, ["app", "create", "Test App"])

    assert result.exit_code == 3
    assert "App name already exists" in result.stdout


def test_app_create_json_output(mock_api):
    """Test JSON output format."""
    mock_api.post.return_value = {
        "name": "Test App",
        "client_id": "abc123",
    }

    result = runner.invoke(app, ["app", "create", "Test App", "--json"])

    assert result.exit_code == 0
    assert '"client_id": "abc123"' in result.stdout
```

---

## File Changes Summary

| File | Action |
|------|--------|
| `src/sweatstack_cli/commands/pages.py` | Rename → `page.py`, update Typer name |
| `src/sweatstack_cli/commands/app.py` | Create (new module) |
| `src/sweatstack_cli/main.py` | Update imports and registrations |
| `tests/test_commands/test_pages.py` | Rename → `test_page.py`, update command names |
| `tests/test_commands/test_app.py` | Create (new test module) |

---

## Expected CLI Output

### Success (Human-Readable)

```
$ sweatstack app create "My Dev App" --page myapp --secret --env

✓ Created application My Dev App

  Client ID:  clnt_a1b2c3d4e5f6
  Secret:     sk_live_x9y8z7w6v5u4

  Redirect URIs:
    • https://myapp.sweatstack.pages.dev/callback

✓ Credentials written to .env
```

### Success (JSON)

```
$ sweatstack app create "My Dev App" --json

{
  "name": "My Dev App",
  "client_id": "clnt_a1b2c3d4e5f6"
}
```

### Secret Warning (no --env)

```
$ sweatstack app create "My Dev App" --secret

✓ Created application My Dev App

  Client ID:  clnt_a1b2c3d4e5f6
  Secret:     sk_live_x9y8z7w6v5u4

Save the secret now — it won't be shown again.
```

---

## Final CLI Structure

```
sweatstack
├── login          # Authenticate via browser
├── logout         # Remove stored credentials
├── whoami         # Show current user
├── status         # Show auth status
├── page
│   └── deploy     # Deploy static site
└── app
    └── create     # Create OAuth2 application
```

---

## Checklist

### Part 1: Rename `pages` → `page`
- [ ] Rename `commands/pages.py` → `commands/page.py`
- [ ] Update Typer name in `page.py`
- [ ] Update imports in `main.py`
- [ ] Rename `test_pages.py` → `test_page.py`
- [ ] Update test command invocations

### Part 2: Add `app create`
- [ ] Create `commands/app.py`
- [ ] Register in `main.py`
- [ ] Create `test_app.py`
- [ ] Test manually against staging API

### Documentation
- [ ] Update README if needed
