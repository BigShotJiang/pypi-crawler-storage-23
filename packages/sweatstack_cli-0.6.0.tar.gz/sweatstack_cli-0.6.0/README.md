# SweatStack CLI

Command-line interface for [SweatStack](https://sweatstack.no) — the sports data platform for developers.

## Installation

```bash
pip install sweatstack-cli
```

Requires Python 3.13+.

## Quick Start

```bash
# Authenticate with SweatStack
sweatstack login

# Check who you're logged in as
sweatstack whoami

# Deploy a static site
sweatstack pages deploy ./dist --prod

# View authentication status
sweatstack status

# Logout
sweatstack logout
```

## Commands

### Authentication

| Command | Description |
|---------|-------------|
| `sweatstack login` | Authenticate via browser |
| `sweatstack login --force` | Force re-authentication |
| `sweatstack logout` | Remove stored credentials |
| `sweatstack whoami` | Show current user |
| `sweatstack status` | Show token status and expiry |

### Pages

| Command | Description |
|---------|-------------|
| `sweatstack pages deploy <dir>` | Deploy static site |
| `sweatstack pages deploy --prod` | Deploy to production |
| `sweatstack pages list` | List all sites |
| `sweatstack pages delete <name>` | Delete a site |

## CI/CD Usage

For automated environments, use environment variables instead of interactive login:

```bash
export SWEATSTACK_API_KEY="your-access-token"
export SWEATSTACK_REFRESH_TOKEN="your-refresh-token"

sweatstack pages deploy ./dist --prod
```

## Configuration

| Environment Variable | Description | Default |
|---------------------|-------------|---------|
| `SWEATSTACK_URL` | API base URL | `https://app.sweatstack.no` |
| `SWEATSTACK_API_KEY` | Access token | — |
| `SWEATSTACK_REFRESH_TOKEN` | Refresh token | — |

## Token Storage

Credentials are stored securely in your OS user data directory:

- **macOS**: `~/Library/Application Support/SweatStack/SweatStack/tokens.json`
- **Linux**: `~/.local/share/SweatStack/SweatStack/tokens.json`
- **Windows**: `%APPDATA%\SweatStack\SweatStack\tokens.json`

This location is shared with the [sweatstack Python library](https://github.com/sweatstack/sweatstack-python), so authenticating with either tool works for both.

## Development

See [DEVELOPMENT.md](DEVELOPMENT.md) for development setup and contribution guidelines.

```bash
# Install with dev dependencies
uv pip install -e ".[dev]"

# Run tests
pytest

# Lint and format
ruff check . && ruff format .

# Type check
mypy src/sweatstack_cli
```

## License

MIT
