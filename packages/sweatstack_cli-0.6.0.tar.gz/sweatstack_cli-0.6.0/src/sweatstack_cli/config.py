"""Application configuration loaded from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import cache

DEFAULT_API_URL = "https://app.sweatstack.no"


@dataclass(frozen=True, slots=True)
class Settings:
    """Immutable application settings."""

    api_url: str
    version: str


@cache
def get_settings() -> Settings:
    """
    Load settings from environment.

    Cached to ensure consistent settings throughout the application lifecycle.
    """
    from sweatstack_cli import __version__

    return Settings(
        api_url=os.environ.get("SWEATSTACK_URL", DEFAULT_API_URL).rstrip("/"),
        version=__version__,
    )
