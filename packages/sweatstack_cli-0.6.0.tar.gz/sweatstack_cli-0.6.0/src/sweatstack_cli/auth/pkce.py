"""PKCE (Proof Key for Code Exchange) implementation per RFC 7636."""

from __future__ import annotations

import base64
import hashlib
import secrets
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PKCEChallenge:
    """
    PKCE parameters for OAuth2 authorization.

    Attributes:
        verifier: High-entropy random string (43-128 chars).
        challenge: Base64url-encoded SHA256 hash of verifier.
        state: Random nonce for CSRF protection.
    """

    verifier: str
    challenge: str
    state: str


def generate_pkce() -> PKCEChallenge:
    """
    Generate PKCE challenge parameters per RFC 7636.

    Uses cryptographically secure random generation via the secrets module.
    The verifier is 86 characters (from 64 bytes base64url-encoded),
    which is within the RFC-specified range of 43-128 characters.

    Returns:
        PKCEChallenge with verifier, challenge, and state.
    """
    # Generate code verifier: 64 random bytes = 86 base64url chars
    # This is within the RFC 7636 requirement of 43-128 characters
    verifier = secrets.token_urlsafe(64)

    # S256 challenge: BASE64URL(SHA256(verifier))
    # We encode as ASCII because token_urlsafe returns ASCII-safe string
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    # State parameter for CSRF protection
    state = secrets.token_urlsafe(32)

    return PKCEChallenge(verifier=verifier, challenge=challenge, state=state)
