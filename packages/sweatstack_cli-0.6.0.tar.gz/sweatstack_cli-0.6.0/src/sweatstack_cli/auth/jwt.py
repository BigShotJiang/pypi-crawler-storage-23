"""Minimal JWT payload decoding for token expiry checks."""

from __future__ import annotations

import base64
import json
from typing import Any


def decode_jwt_payload(token: str) -> dict[str, Any]:
    """
    Decode JWT payload without signature verification.

    We only need to read claims (exp, sub) for local expiry decisions.
    The API server validates signatures on every request, so we don't
    need to verify signatures client-side.

    Args:
        token: JWT string in the format "header.payload.signature".

    Returns:
        Decoded payload as a dictionary.

    Raises:
        ValueError: If the token format is invalid.

    Example:
        >>> payload = decode_jwt_payload(token)
        >>> exp_timestamp = payload["exp"]
    """
    try:
        # JWT format: header.payload.signature
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("JWT must have exactly 3 parts")

        payload_b64 = parts[1]

        # Base64url decode with padding normalization
        # JWT uses base64url encoding without padding, so we add it back
        padding_needed = 4 - (len(payload_b64) % 4)
        if padding_needed != 4:
            payload_b64 += "=" * padding_needed

        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        result: dict[str, Any] = json.loads(payload_bytes)
        return result

    except (IndexError, ValueError, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid JWT format: {e}") from e
