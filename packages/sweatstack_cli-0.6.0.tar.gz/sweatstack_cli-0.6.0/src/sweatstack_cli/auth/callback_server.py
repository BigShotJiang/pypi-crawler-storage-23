"""Local HTTP server for OAuth2 callback handling."""

from __future__ import annotations

from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

from sweatstack_cli.exceptions import AuthenticationError

# Port range for callback server
PORT_RANGE_START = 8400
PORT_RANGE_END = 8500


@dataclass(frozen=True, slots=True)
class AuthorizationResult:
    """Result from successful OAuth2 callback."""

    code: str
    state: str


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for OAuth2 redirect callback."""

    server: _CallbackHTTPServer

    def do_GET(self) -> None:
        """Handle GET request from OAuth2 redirect."""
        query = parse_qs(urlparse(self.path).query)

        # Check for OAuth error response
        if "error" in query:
            error = query["error"][0]
            description = query.get("error_description", ["Unknown error"])[0]
            self.server.auth_error = f"{error}: {description}"
            self._respond_error(description)
            return

        # Validate required parameters
        if "code" not in query or "state" not in query:
            self.server.auth_error = "Missing code or state parameter"
            self._respond_error("Invalid callback: missing required parameters")
            return

        # Store successful result
        self.server.auth_result = AuthorizationResult(
            code=query["code"][0],
            state=query["state"][0],
        )
        self._respond_success()

    def _respond_success(self) -> None:
        """Send success response to browser."""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SweatStack CLI</title>
</head>
<body>
    <h1>Authentication successful</h1>
    <p>You can close this window and return to the terminal.</p>
</body>
</html>"""

        self.wfile.write(html.encode("utf-8"))

    def _respond_error(self, message: str) -> None:
        """Send error response to browser."""
        self.send_response(400)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        # Escape HTML to prevent XSS
        safe_message = (
            message.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SweatStack CLI - Error</title>
</head>
<body>
    <h1>Authentication failed</h1>
    <p>{safe_message}</p>
</body>
</html>"""

        self.wfile.write(html.encode("utf-8"))

    def log_message(self, format: str, *args: Any) -> None:
        """Silence default HTTP request logging."""
        pass


class _CallbackHTTPServer(HTTPServer):
    """HTTPServer with attributes for storing auth result."""

    auth_result: AuthorizationResult | None = None
    auth_error: str | None = None


class CallbackServer:
    """
    Local HTTP server to receive OAuth2 authorization callback.

    Finds an available port in the configured range and waits for
    the OAuth2 provider to redirect the user back after authentication.

    Example:
        server = CallbackServer(timeout=120.0)
        redirect_uri = server.get_redirect_uri()
        # ... open browser to auth URL with redirect_uri ...
        result = server.wait_for_callback(expected_state=state)
        server.shutdown()
    """

    def __init__(self, timeout: float = 120.0) -> None:
        """
        Initialize callback server.

        Args:
            timeout: Maximum seconds to wait for callback.
        """
        self._timeout = timeout
        self._server: _CallbackHTTPServer | None = None
        self._port: int | None = None

    def get_redirect_uri(self) -> str:
        """
        Start server and return the redirect URI.

        Finds an available port in the range 8400-8499.

        Returns:
            Redirect URI to use in OAuth2 authorization request.

        Raises:
            RuntimeError: If no port is available.
        """
        for port in range(PORT_RANGE_START, PORT_RANGE_END):
            try:
                self._server = _CallbackHTTPServer(
                    ("localhost", port),
                    _CallbackHandler,
                )
                self._port = port
                return f"http://localhost:{port}/callback"
            except OSError:
                continue

        raise RuntimeError(
            f"No available port in range {PORT_RANGE_START}-{PORT_RANGE_END} "
            "for OAuth callback server"
        )

    def wait_for_callback(self, expected_state: str) -> AuthorizationResult:
        """
        Block until callback received or timeout.

        Validates the state parameter to prevent CSRF attacks.

        Args:
            expected_state: The state value sent in the authorization request.

        Returns:
            AuthorizationResult with code and state.

        Raises:
            AuthenticationError: If callback fails, times out, or state mismatches.
        """
        if self._server is None:
            raise RuntimeError("Server not started. Call get_redirect_uri() first.")

        self._server.timeout = self._timeout

        # Handle requests until we get a result or error
        while self._server.auth_result is None and self._server.auth_error is None:
            self._server.handle_request()

            # Check for timeout (handle_request returns after timeout)
            if self._server.auth_result is None and self._server.auth_error is None:
                raise AuthenticationError("Authentication timed out. Please try again.")

        if self._server.auth_error:
            raise AuthenticationError(self._server.auth_error)

        result = self._server.auth_result
        assert result is not None  # For type checker

        # Validate state to prevent CSRF
        if result.state != expected_state:
            raise AuthenticationError(
                "State parameter mismatch — possible CSRF attack. Please try again."
            )

        return result

    def shutdown(self) -> None:
        """Stop the server and release the port."""
        if self._server is not None:
            self._server.server_close()
            self._server = None
            self._port = None
