"""Token storage and management."""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import platformdirs


def get_tokens_path() -> Path:
    """
    Get the path to the tokens file.

    Uses platformdirs for OS-appropriate user data directory.
    This path is shared with the sweatstack Python library for
    seamless interoperability.

    Returns:
        Path to tokens.json file.

    Platform-specific paths:
        - macOS: ~/Library/Application Support/SweatStack/tokens.json
        - Linux: ~/.local/share/SweatStack/tokens.json
        - Windows: %APPDATA%\\SweatStack\\SweatStack\\tokens.json
    """
    data_dir = Path(platformdirs.user_data_dir("SweatStack", "SweatStack"))
    return data_dir / "tokens.json"


@dataclass(frozen=True, slots=True)
class TokenPair:
    """
    Immutable access and refresh token pair.

    Provides expiry checking via JWT payload inspection.
    """

    access_token: str
    refresh_token: str

    def is_expired(self, margin_seconds: int = 30) -> bool:
        """
        Check if the access token expires within the margin.

        Args:
            margin_seconds: Safety margin before actual expiry.
                Defaults to 30 seconds to avoid edge cases.

        Returns:
            True if token is expired or will expire within margin.
        """
        from sweatstack_cli.auth.jwt import decode_jwt_payload

        try:
            payload = decode_jwt_payload(self.access_token)
            exp: int = payload.get("exp", 0)
            return time.time() >= (exp - margin_seconds)
        except ValueError:
            # Invalid token format - treat as expired
            return True


class TokenStorage(Protocol):
    """
    Protocol for token persistence backends.

    Implement this protocol to provide custom storage
    (e.g., keychain, encrypted file, remote storage).
    """

    def load(self) -> TokenPair | None:
        """Load tokens from storage. Returns None if not found."""
        ...

    def save(self, tokens: TokenPair) -> None:
        """Persist tokens to storage."""
        ...

    def delete(self) -> None:
        """Remove tokens from storage."""
        ...


class FileTokenStorage:
    """
    Filesystem-based token storage.

    Stores tokens as JSON with secure file permissions.
    Compatible with the sweatstack Python library token format.

    Security:
        - File permissions set to 0o600 (owner read/write only)
        - Atomic writes via temp file + rename
        - Directory created with 0o700 if missing
    """

    def __init__(self, path: Path | None = None) -> None:
        """
        Initialize file storage.

        Args:
            path: Custom path to tokens file.
                Defaults to OS-appropriate user data directory.
        """
        self._path = path or get_tokens_path()

    @property
    def path(self) -> Path:
        """Path to the tokens file."""
        return self._path

    def load(self) -> TokenPair | None:
        """
        Load tokens from disk.

        Returns:
            TokenPair if file exists and is valid, None otherwise.
        """
        if not self._path.exists():
            return None

        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            return TokenPair(
                access_token=data["access_token"],
                refresh_token=data["refresh_token"],
            )
        except (json.JSONDecodeError, KeyError, OSError):
            # Corrupted or invalid file - treat as missing
            return None

    def save(self, tokens: TokenPair) -> None:
        """
        Persist tokens with secure permissions.

        Uses atomic write (temp file + rename) to prevent corruption
        if the process is interrupted during write.
        """
        # Create directory with restrictive permissions
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self._path.parent, 0o700)
        except OSError:
            pass  # Best effort on Windows

        # Atomic write: write to temp file, then rename
        tmp_path = self._path.with_suffix(".tmp")

        content = json.dumps(
            {
                "access_token": tokens.access_token,
                "refresh_token": tokens.refresh_token,
            },
            indent=2,
        )

        tmp_path.write_text(content, encoding="utf-8")

        # Set restrictive permissions before rename
        try:
            os.chmod(tmp_path, 0o600)
        except OSError:
            pass  # Best effort on Windows

        # Atomic rename
        tmp_path.replace(self._path)

    def delete(self) -> None:
        """Remove tokens file if it exists."""
        try:
            self._path.unlink(missing_ok=True)
        except OSError:
            pass  # Best effort
