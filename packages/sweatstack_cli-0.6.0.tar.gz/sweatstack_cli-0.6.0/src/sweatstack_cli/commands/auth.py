"""Authentication commands: login, logout, whoami, status."""

from __future__ import annotations

import typer

from sweatstack_cli.api import APIClient
from sweatstack_cli.auth import Authenticator
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import APIError, AuthenticationError
from sweatstack_cli.version_check import check_for_update


def login(
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force re-authentication even if already logged in.",
    ),
) -> None:
    """Authenticate with SweatStack via browser."""
    auth = Authenticator()

    # Check if already logged in
    if not force:
        existing = auth.get_valid_tokens()
        if existing:
            try:
                client = APIClient(authenticator=auth)
                user = client.get("/api/v1/oauth/userinfo")
                console.print(
                    f"Already logged in as [bold]{user['name']}[/bold]. "
                    f"Use [cyan]--force[/cyan] to re-authenticate."
                )
                return
            except AuthenticationError:
                pass  # Token invalid, proceed with login

    with console.status("[bold]Opening browser for authentication...[/bold]"):
        try:
            auth.login(force=True)
        except AuthenticationError as e:
            console.print(f"[red]Authentication failed:[/red] {e}")
            raise typer.Exit(2)

    # Verify by fetching user info
    try:
        client = APIClient(authenticator=auth)
        user = client.get("/api/v1/oauth/userinfo")
        console.print(f"[green]✓[/green] Logged in as [bold]{user['name']}[/bold]")
    except AuthenticationError as e:
        console.print(f"[red]Login succeeded but verification failed:[/red] {e}")
        raise typer.Exit(2)


def logout() -> None:
    """Remove stored credentials."""
    auth = Authenticator()
    auth.logout()
    console.print("[green]✓[/green] Logged out")


def status() -> None:
    """Show authentication status and version info."""
    from sweatstack_cli import __version__

    # Check authentication and get user info
    auth = Authenticator()
    tokens = auth.get_valid_tokens()

    if tokens is None:
        console.print("[red]✗[/red] Not authenticated")
    else:
        console.print("[green]✓[/green] Authenticated")
        try:
            client = APIClient(authenticator=auth)
            user = client.get("/api/v1/oauth/userinfo")
            console.print(f"  Name:   {user.get('name', 'unknown')}")
            console.print(f"  Email:  {user.get('email', 'unknown')}")
            console.print(f"  ID:     {user.get('sub', 'unknown')}")
        except (AuthenticationError, APIError):
            pass  # Silently skip user info on error

    # Check version
    update_available, latest = check_for_update()
    if update_available and latest:
        console.print(
            f"[yellow]⚠[/yellow] Update available: {latest} (current: {__version__})\n"
            f"  Run: [cyan]uv tool upgrade sweatstack-cli[/cyan] [dim](or pip/pipx)[/dim]"
        )
    elif latest:
        console.print(f"[green]✓[/green] Up to date ({__version__})")
    else:
        console.print(f"[dim]?[/dim] Version {__version__} (update check failed)")

    # Exit with error if not authenticated
    if tokens is None:
        console.print("\nRun [bold]sweatstack login[/bold] to authenticate.")
        raise typer.Exit(1)
