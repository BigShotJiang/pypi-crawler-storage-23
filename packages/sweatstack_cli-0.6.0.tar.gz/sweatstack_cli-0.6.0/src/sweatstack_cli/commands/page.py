"""Page commands: deploy static sites."""

from __future__ import annotations

import mimetypes
from pathlib import Path

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from sweatstack_cli.api import APIClient
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import APIError, AuthenticationError
from sweatstack_cli.project import CONFIG_FILENAME, ProjectConfig

# URL where users can create pages for their applications
SETTINGS_URL = "https://app.sweatstack.no/settings/api"

app = typer.Typer(
    name="page",
    help="Deploy static sites to SweatStack Pages.",
)


def _collect_files(directory: Path) -> list[tuple[str, tuple[str, bytes, str]]]:
    """
    Collect all files from a directory for multipart upload.

    Returns a list of tuples suitable for httpx files parameter:
    [("files", (filename, content, content_type)), ...]
    """
    files: list[tuple[str, tuple[str, bytes, str]]] = []

    for file_path in directory.rglob("*"):
        if not file_path.is_file():
            continue

        # Get relative path from directory root
        relative_path = file_path.relative_to(directory)

        # Guess content type
        content_type, _ = mimetypes.guess_type(str(file_path))
        if content_type is None:
            content_type = "application/octet-stream"

        # Read file content
        content = file_path.read_bytes()

        # Use relative path as filename to preserve directory structure
        files.append(("files", (str(relative_path), content, content_type)))

    return files


@app.command()
def deploy(
    slug: str | None = typer.Argument(
        None,
        help="Page slug. Reads from sweatstack.toml if not provided.",
    ),
    directory: Path | None = typer.Argument(
        None,
        help="Directory to deploy. Reads from sweatstack.toml or defaults to current dir.",
    ),
) -> None:
    """Deploy a static site to SweatStack Pages."""
    # Load config for defaults
    config = ProjectConfig.load()

    # Resolve slug
    page_slug = slug or (config.page.slug if config else None)
    if not page_slug:
        console.print("[red]Error:[/red] No page slug provided.")
        console.print(f"Specify a slug or add it to [bold]{CONFIG_FILENAME}[/bold]")
        raise typer.Exit(1)

    # Resolve directory
    if directory is None:
        dir_from_config = config.page.directory if config else None
        directory = Path(dir_from_config) if dir_from_config else Path(".")

    if not directory.exists():
        console.print(f"[red]Error:[/red] Directory '{directory}' does not exist.")
        raise typer.Exit(1)

    if not directory.is_dir():
        console.print(f"[red]Error:[/red] '{directory}' is not a directory.")
        raise typer.Exit(1)

    directory = directory.resolve()

    # Collect files
    files = _collect_files(directory)
    file_count = len(files)

    if file_count == 0:
        console.print(f"[red]Error:[/red] Directory '{directory}' contains no files.")
        raise typer.Exit(1)

    # Check for index.html
    has_index = any(name == "index.html" for _, (name, _, _) in files)
    if not has_index:
        console.print(
            f"[yellow]Warning:[/yellow] No index.html found in '{directory}'. "
            "Your site may not load correctly."
        )

    try:
        client = APIClient()
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(2)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(
            f"Deploying [bold]{page_slug}[/bold] ({file_count} files)...",
            total=None,
        )

        try:
            result = client.put(f"/api/v1/pages/{page_slug}/deploy", files=files)
        except APIError as e:
            error_msg = str(e)

            # Handle 404 - page doesn't exist
            if "(404)" in error_msg:
                console.print(f"[red]Error:[/red] Page '{page_slug}' not found.")
                console.print()
                console.print(
                    f"Create this page first at: [link={SETTINGS_URL}]{SETTINGS_URL}[/link]"
                )
                console.print()
                console.print("[dim]Pages must be created in the SweatStack dashboard[/dim]")
                console.print("[dim]before you can deploy to them.[/dim]")
                raise typer.Exit(1)

            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(3)

    console.print()
    console.print(f"[green]✓[/green] Deployed [bold]{page_slug}[/bold] successfully!")
    console.print(f"  Files: {file_count}")
    console.print(f"  URL:   {result.get('url', 'N/A')}")
