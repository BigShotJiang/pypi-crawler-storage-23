# SweatStack CLI — Development Guide

This document explains how to develop, maintain, and extend the SweatStack CLI.

## Quick Start

```bash
# Clone and install
git clone https://github.com/sweatstack/sweatstack-cli
cd sweatstack-cli

# Create virtual environment and install
uv venv
source .venv/bin/activate  # or `.venv\Scripts\activate` on Windows
uv pip install -e ".[dev]"

# Run the CLI
sweatstack --help

# Run tests
pytest
```

## Project Structure

```
src/sweatstack_cli/
├── __init__.py              # Package version
├── main.py                  # CLI entry point (Typer app)
├── config.py                # Environment-based configuration
├── console.py               # Rich console singleton
├── exceptions.py            # Exception hierarchy with exit codes
├── auth/                    # Authentication module
│   ├── __init__.py          # Authenticator class (main API)
│   ├── pkce.py              # PKCE challenge generation
│   ├── jwt.py               # JWT payload decoding
│   ├── tokens.py            # Token storage
│   └── callback_server.py   # Local OAuth callback server
├── api/                     # API client module
│   ├── __init__.py          # Public exports
│   └── client.py            # Authenticated HTTP client
└── commands/                # CLI command modules
    ├── __init__.py
    ├── auth.py              # login, logout, whoami, status
    └── pages.py             # pages deploy, list, delete
```

## Architecture

### Design Principles

1. **Minimal dependencies** — Only essential packages: `typer`, `httpx`, `platformdirs`
2. **No magic** — Explicit configuration, clear error messages
3. **Testable** — Dependency injection, protocol-based abstractions
4. **Type safe** — Full type hints, strict mypy configuration

### Authentication Flow

The CLI uses OAuth2 PKCE (Proof Key for Code Exchange) for authentication:

```
User runs `sweatstack login`
         │
         ▼
Generate PKCE verifier + challenge
         │
         ▼
Start local HTTP server on port 8400-8499
         │
         ▼
Open browser to SweatStack OAuth page
         │
         ▼
User authenticates in browser
         │
         ▼
Browser redirects to localhost with auth code
         │
         ▼
Exchange code for tokens (access + refresh)
         │
         ▼
Store tokens in ~/.../SweatStack/tokens.json
```

### Token Storage

Tokens are stored in a platform-specific location using `platformdirs`:

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/SweatStack/tokens.json` |
| Linux | `~/.local/share/SweatStack/tokens.json` |
| Windows | `%APPDATA%\SweatStack\SweatStack\tokens.json` |

**Important:** This path is shared with the `sweatstack` Python library. Both projects must maintain compatibility with this format:

```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ..."
}
```

## Adding New Commands

### 1. Create a Command Module

Create a new file in `src/sweatstack_cli/commands/`:

```python
# src/sweatstack_cli/commands/activities.py
"""Activity commands."""

from __future__ import annotations

import typer

from sweatstack_cli.api import APIClient
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import AuthenticationError

app = typer.Typer(
    name="activities",
    help="Manage activities.",
    no_args_is_help=True,
)


@app.command(name="list")
def list_activities(
    limit: int = typer.Option(10, "--limit", "-n", help="Number of activities"),
) -> None:
    """List recent activities."""
    try:
        client = APIClient()
        activities = client.get("/api/v1/activities", params={"limit": limit})

        for activity in activities["items"]:
            console.print(f"  {activity['id']}: {activity['name']}")

    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(2)
```

### 2. Register in main.py

```python
# src/sweatstack_cli/main.py
from sweatstack_cli.commands import activities

app.add_typer(activities.app, name="activities")
```

### 3. Add Tests

```python
# tests/test_commands/test_activities.py
from typer.testing import CliRunner
from sweatstack_cli.main import app

runner = CliRunner()

def test_activities_help():
    result = runner.invoke(app, ["activities", "--help"])
    assert result.exit_code == 0
    assert "list" in result.stdout
```

## Extending the API Client

The `APIClient` class provides authenticated HTTP methods. To add new endpoints:

```python
# src/sweatstack_cli/api/activities.py
from __future__ import annotations

from sweatstack_cli.api.client import APIClient


class ActivitiesAPI:
    """Activities API wrapper."""

    def __init__(self, client: APIClient | None = None) -> None:
        self._client = client or APIClient()

    def list(self, limit: int = 10) -> list[dict]:
        """List activities."""
        response = self._client.get("/api/v1/activities", params={"limit": limit})
        return response["items"]

    def get(self, activity_id: str) -> dict:
        """Get a single activity."""
        return self._client.get(f"/api/v1/activities/{activity_id}")
```

## Testing

### Running Tests

```bash
# All tests
pytest

# With coverage
pytest --cov=sweatstack_cli --cov-report=html

# Specific test file
pytest tests/test_auth/test_pkce.py

# Specific test
pytest tests/test_auth/test_pkce.py::TestGeneratePKCE::test_verifier_length_in_range

# Verbose output
pytest -v
```

### Test Fixtures

Common fixtures are defined in `tests/conftest.py`:

- `temp_token_storage` — FileTokenStorage with temp directory
- `sample_tokens` — Valid TokenPair with future expiry
- `expired_tokens` — TokenPair with past expiry
- `clean_env` — Removes SweatStack env vars for isolation

### Mocking HTTP Requests

Use `pytest-httpx` for HTTP mocking:

```python
from pytest_httpx import HTTPXMock

def test_api_call(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://app.sweatstack.no/api/v1/test",
        json={"data": "value"},
    )

    client = APIClient(authenticator=mock_auth)
    result = client.get("/api/v1/test")

    assert result["data"] == "value"
```

### Mocking Authentication

```python
from unittest.mock import Mock
from sweatstack_cli.auth import Authenticator
from sweatstack_cli.auth.tokens import TokenPair

def test_with_mock_auth(sample_tokens: TokenPair):
    auth = Mock(spec=Authenticator)
    auth.get_valid_tokens.return_value = sample_tokens

    client = APIClient(authenticator=auth)
    # ... test API calls
```

## Code Quality

### Linting and Formatting

```bash
# Check linting
ruff check .

# Auto-fix issues
ruff check --fix .

# Format code
ruff format .
```

### Type Checking

```bash
mypy src/sweatstack_cli
```

### Pre-commit Checks

Consider adding these to CI or as pre-commit hooks:

```bash
ruff check .
ruff format --check .
mypy src/sweatstack_cli
pytest
```

## Environment Variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `SWEATSTACK_URL` | API base URL | `https://app.sweatstack.no` |
| `SWEATSTACK_API_KEY` | Access token (CI/CD) | — |
| `SWEATSTACK_REFRESH_TOKEN` | Refresh token (CI/CD) | — |

For CI/CD pipelines, set `SWEATSTACK_API_KEY` and `SWEATSTACK_REFRESH_TOKEN` to bypass interactive login.

## Error Handling

### Exception Hierarchy

```
CLIError (exit code 1)
├── AuthenticationError (exit code 2)
├── APIError (exit code 3)
└── ValidationError (exit code 4)
```

### Adding New Exceptions

```python
# src/sweatstack_cli/exceptions.py

class RateLimitError(CLIError):
    """API rate limit exceeded."""
    exit_code = 5
```

### Using Exceptions in Commands

```python
from sweatstack_cli.exceptions import AuthenticationError

def my_command():
    try:
        client = APIClient()
        # ...
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(2)
```

## Release Process

1. Update version in `src/sweatstack_cli/__init__.py`
2. Update `pyproject.toml` version if needed
3. Run full test suite: `pytest`
4. Build: `uv build` or `python -m build`
5. Publish: `twine upload dist/*`

## Debugging

### Verbose Output

The CLI respects Rich's console settings. For debugging:

```python
from rich.console import Console
console = Console(force_terminal=True)  # Force colors in CI
```

### Token Inspection

```bash
# Check token status
sweatstack status

# View raw token file (careful with secrets!)
cat ~/Library/Application\ Support/SweatStack/tokens.json | python -m json.tool
```

### Local API Testing

```bash
# Override API URL for local testing
SWEATSTACK_URL=http://localhost:8000 sweatstack login
```

## Compatibility Notes

### Token Storage Compatibility

The CLI shares token storage with the `sweatstack` Python library. Changes to the token format must be coordinated:

1. Token file path: `platformdirs.user_data_dir("SweatStack", "SweatStack") / "tokens.json"`
2. JSON format: `{"access_token": "...", "refresh_token": "..."}`
3. File permissions: `0o600`

### Python Version

Requires Python 3.13+. Uses modern features:
- `type` statement (PEP 695)
- `X | Y` union syntax
- `@dataclass(slots=True)`

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make changes with tests
4. Run checks: `ruff check . && mypy src && pytest`
5. Submit a pull request

## Getting Help

- GitHub Issues: [github.com/sweatstack/sweatstack-cli/issues](https://github.com/sweatstack/sweatstack-cli/issues)
- Documentation: [docs.sweatstack.no](https://docs.sweatstack.no)
