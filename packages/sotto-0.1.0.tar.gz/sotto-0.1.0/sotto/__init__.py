"""Sotto — private voice transcription server."""

__version__ = "0.1.0"
