"""Shared test fixtures for Horizon SDK tests."""

import os

import pytest


@pytest.fixture(autouse=True)
def _set_test_api_key():
    """Ensure HORIZON_API_KEY is set for all tests."""
    prev = os.environ.get("HORIZON_API_KEY")
    os.environ.setdefault("HORIZON_API_KEY", "test-key-123")
    yield
    if prev is None:
        os.environ.pop("HORIZON_API_KEY", None)
    else:
        os.environ["HORIZON_API_KEY"] = prev
