"""Shared constants for the Horizon SDK."""

# Polymarket Gamma API for market metadata and discovery
GAMMA_API_URL = "https://gamma-api.polymarket.com"

# Polymarket Data API for trades, positions, holders
DATA_API_URL = "https://data-api.polymarket.com"

# Kalshi public trading API
KALSHI_API_URL = "https://api.elections.kalshi.com/trade-api/v2"
