"""Run the Horizon MCP server: python -m horizon.mcp"""

import sys

from horizon.mcp_server import mcp

transport = "stdio"
if "--http" in sys.argv:
    transport = "streamable-http"

mcp.run(transport=transport)
