# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel
from .customer_usage import CustomerUsage

__all__ = ["WebsocketUsageResponse", "TopMarket", "Totals"]


class TopMarket(BaseModel):
    parsec_id: str

    subscriptions_total: int


class Totals(BaseModel):
    active_connections: int

    active_subscriptions: int

    auth_failures_total: int

    bytes_sent_total: int

    connections_closed_total: int

    connections_opened_total: int

    messages_sent_total: int

    subscribe_requests_total: int

    unsubscribe_requests_total: int


class WebsocketUsageResponse(BaseModel):
    customers: List[CustomerUsage]

    scope: str

    top_markets: List[TopMarket]

    totals: Totals

    updated_at_ms: int

    customer: Optional[CustomerUsage] = None
