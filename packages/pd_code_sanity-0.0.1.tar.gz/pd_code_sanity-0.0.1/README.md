# pd_code_sanity
check pd_code weak sanity.

## Install

```bash
pip install pd-code-sanity
```

## Usage

```python
import pd_code_sanity

print(pd_code_sanity.sanity([[1, 5, 2, 4], [3, 1, 4, 6], [5, 3, 6, 2]]))
```
