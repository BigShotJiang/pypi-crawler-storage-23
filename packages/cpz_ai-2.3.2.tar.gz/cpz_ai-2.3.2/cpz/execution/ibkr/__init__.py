"""
IBKR (Interactive Brokers) Adapter for CPZ Python SDK
======================================================

This adapter connects to the CPZ AI IBKR Gateway Service running on EC2,
which handles IB Gateway Docker containers and native TWS API communication.

Architecture:
    CPZ SDK -> EC2 Gateway Service -> IB Gateway Docker -> Interactive Brokers
"""

from .adapter import IBKRAdapter

__all__ = ["IBKRAdapter"]
