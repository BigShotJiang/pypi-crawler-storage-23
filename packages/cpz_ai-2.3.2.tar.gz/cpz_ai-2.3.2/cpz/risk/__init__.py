from __future__ import annotations

from .models import (
    RiskSnapshot,
    StrategyRisk,
    RiskAlert,
    RiskThreshold,
    StressScenario,
    MonteCarloResult,
    RollingMetrics,
    DrawdownAnalysis,
    PositionSizeResult,
    SharpeInference,
    FactorExposure,
    TailRiskMetrics,
)
from .engine import RiskAnalytics

# Portfolio decomposition
from .portfolio import (
    euler_decomposition,
    mctr,
    optimize_portfolio,
    what_if_analysis,
    risk_budget_check,
    EulerDecomposition,
    MCTRResult,
    OptimizationResult,
    WhatIfResult,
    RiskBudgetResult,
    RiskContribution,
)

# Cointegration
from .cointegration import (
    cointegration_test,
    cointegration_rolling,
    CointegrationResult,
    RollingCointegrationResult,
    EngleGrangerResult,
    JohansenResult,
)

# Scenario engine
from .scenario import (
    custom_scenario,
    cascade_effects,
    historical_scenario,
    scenario_comparison,
    ScenarioImpact,
    CascadeResult,
    ScenarioComparison,
    HISTORICAL_SCENARIOS as SCENARIO_LIBRARY,
)

# Market fragility
from .fragility import (
    fragility_score,
    correlation_clustering,
    regime_from_returns,
    FragilityResult,
    CorrelationClusterResult,
    RegimeResult,
)

# Backward compat
RiskEngine = RiskAnalytics

__all__ = [
    # Engine
    "RiskAnalytics",
    "RiskEngine",
    # Core models
    "RiskSnapshot",
    "StrategyRisk",
    "StressScenario",
    "MonteCarloResult",
    "RollingMetrics",
    "DrawdownAnalysis",
    "PositionSizeResult",
    "SharpeInference",
    "FactorExposure",
    "TailRiskMetrics",
    # Portfolio
    "euler_decomposition",
    "mctr",
    "optimize_portfolio",
    "what_if_analysis",
    "risk_budget_check",
    "EulerDecomposition",
    "MCTRResult",
    "OptimizationResult",
    "WhatIfResult",
    "RiskBudgetResult",
    "RiskContribution",
    # Cointegration
    "cointegration_test",
    "cointegration_rolling",
    "CointegrationResult",
    "RollingCointegrationResult",
    "EngleGrangerResult",
    "JohansenResult",
    # Scenario
    "custom_scenario",
    "cascade_effects",
    "historical_scenario",
    "scenario_comparison",
    "ScenarioImpact",
    "CascadeResult",
    "ScenarioComparison",
    "SCENARIO_LIBRARY",
    # Fragility
    "fragility_score",
    "correlation_clustering",
    "regime_from_returns",
    "FragilityResult",
    "CorrelationClusterResult",
    "RegimeResult",
]
