# SAR Calibration Toolbox (SCT)

Sar Calibration Toolbox (SCT) is the official Aresys Python toolbox for SAR quality data processing.
This software provides several features to perform a quality analysis of SAR L1-B products (both SLC and GRD).

## Project Status

⚠️ **Coming Soon** ⚠️

This package is currently a placeholder release.

It has been published to PyPI to reserve the project name as part of our release and distribution planning process.
The full implementation, documentation, and production-ready features will be made available in an upcoming official release.

At this stage, the package does not provide functional capabilities and **should not be used in production environments**.

Further updates, including technical documentation and usage guidelines, will follow shortly.

Stay tuned for updates. 🚀
