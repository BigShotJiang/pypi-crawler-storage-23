# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
SCT: the Python SAR Calibration Tool for quality data analysis - PLACEHOLDER
----------------------------------------------------------------------------
"""

__version__ = "0.0.0.dev0"
