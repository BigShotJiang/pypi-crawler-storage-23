# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Analyses Handler for registration"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


@dataclass
class AnalysisTestingHandler:
    """Analysis handler for testing definition"""

    api_runner: Callable[[Any, Path, Any | None, bool], Any]
    cli_runner: Callable[[Any, Path, Path | None, bool], Any]
    validator: Callable[[Any, Any], None]


@dataclass
class AnalysisHandler:
    """Analysis handler definition"""

    config: Any
    cli_command: Any | None
    testing: AnalysisTestingHandler | None
