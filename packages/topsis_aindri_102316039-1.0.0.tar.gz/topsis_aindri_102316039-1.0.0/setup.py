from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="Topsis-Aindri-102316039",
    version="1.0.0",
    author="Aindri Singh",
    author_email="asingh2_be23@thapar.edu",
    description="A Python package for TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) multi-criteria decision making",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aindrisingh/UCS654_Topsis_assignment_2",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires=">=3.6",
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis_aindri_102316039.topsis:main",
        ],
    },
    keywords="TOPSIS, MCDM, decision-making, multi-criteria, ranking",
    project_urls={
        "Bug Reports": "https://github.com/aindrisingh/UCS654_Topsis_assignment_2/issues",
        "Source": "https://github.com/aindrisingh/UCS654_Topsis_assignment_2",
    },
)
