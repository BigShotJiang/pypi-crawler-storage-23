# Topsis-Aindri-102316039

A Python package implementing **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** for multi-criteria decision making.

## What is TOPSIS?

TOPSIS is a multi-criteria decision analysis method that helps rank alternatives based on their similarity to the ideal solution. It calculates:
- The distance of each alternative from the ideal best solution
- The distance from the ideal worst solution
- A score that represents relative closeness to the ideal solution

The alternative with the highest TOPSIS score is ranked first.

## Installation

```bash
pip install Topsis-Aindri-102316039
```

## Usage

### Command Line Interface

```bash
python -m topsis_aindri_102316039.topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>
```

Or if installed via pip:

```bash
topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>
```

### Example

```bash
python -m topsis_aindri_102316039.topsis data.csv "1,1,1,2" "+,+,-,+" result.csv
```

### Input File Format

The input CSV file must have:
- First column: Names/identifiers of alternatives
- Remaining columns: Numeric criteria values

Example (`data.csv`):

```csv
Model,Price,Storage,Camera,Looks
M1,250,16,12,5
M2,200,16,8,3
M3,300,32,16,4
M4,275,32,8,4
M5,225,16,16,2
```

### Parameters

- **Weights**: Comma-separated numeric values representing the importance of each criterion (e.g., `1,1,1,2`)
- **Impacts**: Comma-separated `+` or `-` signs indicating whether higher values are beneficial (`+`) or detrimental (`-`) for each criterion (e.g., `+,+,-,+`)

### Output

The output CSV file will contain all original columns plus:
- **Topsis Score**: Calculated TOPSIS score (0-1, higher is better)
- **Rank**: Ranking based on TOPSIS score (1 is best)

## Python API

You can also use TOPSIS programmatically:

```python
from topsis_aindri_102316039 import topsis

topsis("data.csv", "1,1,1,2", "+,+,-,+", "result.csv")
```

## Input Validation

The package validates:
- ✅ Correct number of parameters (4 required)
- ✅ Input file existence
- ✅ Minimum 3 columns in input file
- ✅ Numeric values in all criteria columns (2nd column onwards)
- ✅ Equal number of weights, impacts, and criteria
- ✅ Impacts are either '+' or '-'

## Requirements

- Python >= 3.6
- pandas >= 1.0.0
- numpy >= 1.18.0

## Author

**Aindri Singh**  
Roll No: 102316039  
Email: asingh2_be23@thapar.edu  
GitHub: [@aindrisingh](https://github.com/aindrisingh)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions, issues, and feature requests are welcome!

## Acknowledgments

- Based on the TOPSIS method developed by Hwang and Yoon (1981)
- Created as part of UCS654 Assignment 2
