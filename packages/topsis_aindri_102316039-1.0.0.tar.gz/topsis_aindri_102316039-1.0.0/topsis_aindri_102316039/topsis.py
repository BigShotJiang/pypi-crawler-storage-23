"""
TOPSIS Implementation
Technique for Order Preference by Similarity to Ideal Solution
"""

import sys
import pandas as pd
import numpy as np


def validate_inputs(input_file, weights, impacts, output_file):
    """
    Validate all input parameters according to assignment requirements.
    
    Returns:
        tuple: (is_valid, error_message)
    """
    # Check if input file exists
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        return False, f"Error: File '{input_file}' not found!"
    except Exception as e:
        return False, f"Error reading file: {str(e)}"
    
    # Check if file has at least 3 columns
    if df.shape[1] < 3:
        return False, "Error: Input file must contain three or more columns!"
    
    # Check if 2nd column onwards contains only numeric values
    try:
        numeric_data = df.iloc[:, 1:].apply(pd.to_numeric, errors='coerce')
        if numeric_data.isnull().any().any():
            return False, "Error: From 2nd to last columns must contain numeric values only!"
    except Exception as e:
        return False, f"Error: Non-numeric values found in data columns: {str(e)}"
    
    # Parse weights and impacts
    try:
        weight_list = [float(w.strip()) for w in weights.split(',')]
    except ValueError:
        return False, "Error: Weights must be numeric values separated by commas!"
    
    impact_list = [i.strip() for i in impacts.split(',')]
    
    # Check if all impacts are either + or -
    for impact in impact_list:
        if impact not in ['+', '-']:
            return False, "Error: Impacts must be either '+' or '-'!"
    
    # Check if number of weights, impacts and columns match
    num_columns = df.shape[1] - 1  # Excluding the first column
    if len(weight_list) != num_columns:
        return False, f"Error: Number of weights ({len(weight_list)}) must equal number of criteria ({num_columns})!"
    
    if len(impact_list) != num_columns:
        return False, f"Error: Number of impacts ({len(impact_list)}) must equal number of criteria ({num_columns})!"
    
    return True, df


def normalize_matrix(matrix):
    """
    Normalize the decision matrix using vector normalization.
    
    Args:
        matrix: numpy array of decision matrix
    
    Returns:
        normalized matrix
    """
    # Calculate the square root of sum of squares for each column
    norms = np.sqrt((matrix ** 2).sum(axis=0))
    
    # Avoid division by zero
    norms[norms == 0] = 1
    
    # Normalize
    normalized = matrix / norms
    return normalized


def calculate_topsis(df, weights, impacts):
    """
    Calculate TOPSIS scores and rankings.
    
    Args:
        df: pandas DataFrame with data
        weights: list of weights
        impacts: list of impacts ('+' or '-')
    
    Returns:
        DataFrame with Topsis Score and Rank columns added
    """
    # Extract the decision matrix (exclude first column - names/models)
    matrix = df.iloc[:, 1:].values
    
    # Normalize the matrix
    normalized_matrix = normalize_matrix(matrix)
    
    # Convert weights to numpy array
    weights_array = np.array(weights)
    
    # Apply weights
    weighted_matrix = normalized_matrix * weights_array
    
    # Find ideal best and ideal worst
    ideal_best = np.zeros(weighted_matrix.shape[1])
    ideal_worst = np.zeros(weighted_matrix.shape[1])
    
    for i, impact in enumerate(impacts):
        if impact == '+':
            ideal_best[i] = weighted_matrix[:, i].max()
            ideal_worst[i] = weighted_matrix[:, i].min()
        else:  # impact == '-'
            ideal_best[i] = weighted_matrix[:, i].min()
            ideal_worst[i] = weighted_matrix[:, i].max()
    
    # Calculate Euclidean distances
    distance_to_best = np.sqrt(((weighted_matrix - ideal_best) ** 2).sum(axis=1))
    distance_to_worst = np.sqrt(((weighted_matrix - ideal_worst) ** 2).sum(axis=1))
    
    # Calculate TOPSIS score
    topsis_score = distance_to_worst / (distance_to_best + distance_to_worst)
    
    # Calculate rank (higher score = better rank = lower rank number)
    rank = pd.Series(topsis_score).rank(ascending=False, method='min').astype(int)
    
    # Add scores and ranks to dataframe
    result_df = df.copy()
    result_df['Topsis Score'] = topsis_score
    result_df['Rank'] = rank
    
    return result_df


def topsis(input_file, weights, impacts, output_file):
    """
    Main TOPSIS function.
    
    Args:
        input_file: path to input CSV file
        weights: comma-separated weights string
        impacts: comma-separated impacts string ('+' or '-')
        output_file: path to output CSV file
    """
    # Validate inputs
    is_valid, result = validate_inputs(input_file, weights, impacts, output_file)
    
    if not is_valid:
        print(result)
        sys.exit(1)
    
    # If validation passed, result contains the dataframe
    df = result
    
    # Parse weights and impacts
    weight_list = [float(w.strip()) for w in weights.split(',')]
    impact_list = [i.strip() for i in impacts.split(',')]
    
    # Calculate TOPSIS
    result_df = calculate_topsis(df, weight_list, impact_list)
    
    # Save to output file
    try:
        result_df.to_csv(output_file, index=False)
        print(f"Success! Results saved to '{output_file}'")
    except Exception as e:
        print(f"Error saving output file: {str(e)}")
        sys.exit(1)


def main():
    """
    Command-line interface for TOPSIS.
    """
    # Check number of arguments
    if len(sys.argv) != 5:
        print("Error: Incorrect number of parameters!")
        print("\nUsage:")
        print("  python topsis.py <InputDataFile> <Weights> <Impacts> <OutputResultFileName>")
        print("\nExample:")
        print('  python topsis.py data.csv "1,1,1,2" "+,+,-,+" output.csv')
        sys.exit(1)
    
    # Get command-line arguments
    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]
    
    # Run TOPSIS
    topsis(input_file, weights, impacts, output_file)


if __name__ == "__main__":
    main()
