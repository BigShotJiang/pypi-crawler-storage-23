from rest_framework.response import Response
from rest_framework.views import APIView
from ..tasks import process_queued_links
from ..permissions import HasCompensationsPluginAccess

class BrProcessorTestView(APIView):
    def get(self,request):
        process_queued_links()
        return Response(status=200)
    permission_classes = [HasCompensationsPluginAccess]