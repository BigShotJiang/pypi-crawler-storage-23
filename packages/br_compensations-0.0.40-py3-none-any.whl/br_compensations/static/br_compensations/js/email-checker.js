document.getElementById('allowMailCheck').addEventListener('change',(e)=>{ changeMailParseState(e)})

async function changeMailParseState(evnt){
    changeParseStateRequest(evnt.target.checked,evnt.target.dataset.id)
}

async function changeParseStateRequest(enabled,character_id){
    fetch(`/br_compensations/api/mailparser/${enabled ? '' :  character_id + '/'}`, {
        method: enabled ? 'POST' : 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({
            character_id: character_id
        })
    })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return true;
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
            showAlert(error)
        })
}