from django.utils.translation import gettext_lazy as _
from allianceauth import hooks
from allianceauth.services.hooks import MenuItemHook, UrlHook
from . import urls
from .permissions import PERMISSION_CAN_MANAGE

class IntegrationHook:
    """Базовый класс для интеграции с AllianceAuth"""
    pass



class BrCompensationsHook(IntegrationHook):
    """Класс для интеграции Killmail Processor с AllianceAuth"""
    
    def integrate_url(self):
        """Добавление URL-маршрутов"""
        return BrCompensationUrls()


# Создаем экземпляр хука для использования в функциях регистрации
br_compensations_hook = BrCompensationsHook()


class BrCompensationMenuItem(MenuItemHook):
    """Меню для доступа к Br compensations"""
    def __init__(self):
        MenuItemHook.__init__(
            self,
            text=_('Battle Compensations'),
            classes='fa-solid fa-jet-fighter fa-fw',
            url_name='br_compensations:dashboard',
            navactive=['br_compensations:'],
            order=1000,
        )
        
    def render(self, request):
        if request.user.has_perm(f'br_compensations.{PERMISSION_CAN_MANAGE}'):
            return MenuItemHook.render(self, request)
        return ''
    
class BrCompensationUrls(UrlHook):
    """URL-маршруты для Killmail Processor"""
    def __init__(self):
        UrlHook.__init__(
            self,
            urls=urls,
            namespace='br_compensations',
            base_url=r'^br_compensations/'
        )
        
        
@hooks.register('menu_item_hook')
def register_menu():
    """Регистрация пункта меню"""
    return BrCompensationMenuItem()

@hooks.register('url_hook')
def register_urls():
    """Регистрация URL-маршрутов"""
    return br_compensations_hook.integrate_url()

@hooks.register('permission_hook')
def register_permissions():
    
    return [..., PERMISSION_CAN_MANAGE]