from django import forms

class AddBrForm(forms.Form):
    link = forms.CharField(label='Ссылка', required=True, max_length=255)
    # type = forms.CharField(label='report_type', max_length=20)
    comment = forms.CharField(label='Комментарий', required= False, max_length=255)