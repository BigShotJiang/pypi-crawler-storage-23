from django.apps import AppConfig


class BattleCompensationsConfig(AppConfig):
    name = 'br_compensations'
    label = 'br_compensations'
    verbose_name = 'Battle Compensations'