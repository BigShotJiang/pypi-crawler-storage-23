# myproject/setup.py

from setuptools import setup, find_packages

setup(
    name="langchain_endee",
    version="0.1.0b2",
    packages=find_packages(include=['langchain_endee', 'langchain_endee.*']),
    install_requires=[
        # List your dependencies here
        "langchain>=0.3.25",
        "langchain-core>=0.3.59",
        "endee>=0.1.13",
        "numpy",
        "fastembed>=0.3.0"
    ],
    author="Endee Labs",
    author_email="support@endee.io",
    description="High Speed Vector Database for Faster and Efficient  ANN Searches with LangChain",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://endee.io",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)