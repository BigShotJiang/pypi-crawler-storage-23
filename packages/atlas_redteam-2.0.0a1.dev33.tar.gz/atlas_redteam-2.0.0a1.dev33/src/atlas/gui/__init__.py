"""Atlas GUI — Streamlit-based web interface."""
