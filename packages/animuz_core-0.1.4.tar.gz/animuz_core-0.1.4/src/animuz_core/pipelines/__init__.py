"""Pipelines module - RAG pipeline implementations."""


def __getattr__(name):
    if name == "BasePipeline":
        from .base import BasePipeline
        return BasePipeline
    if name == "AgenticRAG":
        from .agentic_rag import AgenticRAG
        return AgenticRAG
    if name == "SimpleRAG":
        from .simple_rag import SimpleRAG
        return SimpleRAG
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BasePipeline",
    "SimpleRAG",
    "AgenticRAG",
]
