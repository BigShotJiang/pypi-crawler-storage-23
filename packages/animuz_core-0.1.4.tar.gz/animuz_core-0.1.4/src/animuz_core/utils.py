from typing import List, Dict
import logging

# from src.genai.ollama_client import OLlamaClient
# from src.genai.anthropic_client import AnthropicClient

from pydantic import BaseModel

class ChatRequest(BaseModel):
    messages: List[Dict[str, str]]
    user_chat_id: str

# async def extract_metadata(chunks: List[str], model_name="llama3-8b") -> Dict[str, str]:
#     # client = None
#     client = AnthropicClient()

#     return await client.summarize_chunks(chunks)

def format_sources(sources):
    """
    Takes a list of sources and returns a formatted numbered list as a string.
    
    Args:
    sources (list): A list of source strings.

    Returns:
    str: A formatted numbered list of sources.
    """
    formatted_sources = ""
    for idx, source in enumerate(sources, 1):
        formatted_sources += f"Source {idx}. {source}\n"
    return formatted_sources.strip()

def init_logger(name):
    LOGGER = logging.getLogger(name)
    formatter = logging.Formatter('%(name)s - %(levelname)s - %(filename)s - %(module)s: %(funcName)s: %(lineno)d - %(message)s')
    LOGGER.setLevel(logging.DEBUG)
    try:
        import watchtower
        cw_handler = watchtower.CloudWatchLogHandler(log_group="animuz", stream_name="test", use_queues=False)
        cw_handler.setFormatter(formatter)
        LOGGER.addHandler(cw_handler)
    except Exception:
        pass
    return LOGGER

if __name__ == "__main__":
    pass
    # import asyncio
    # from dotenv import load_dotenv

    # unstructured_client = MyUnstructuredClient(host="localhost", port=12083)
    # load_dotenv()
    # azure_doc_ai_key: str = os.environ.get("AZURE_DOC_AI_KEY")
    # azure_doc_ai_endpoint: str = os.environ.get("AZURE_DOC_AI_ENDPOINT")
    # # azure_doc_ai_client = AzureDocAiClient(endpoint=azure_doc_ai_endpoint, key=azure_doc_ai_key)
    # import pickle
    # async def test(path):
    #     # res = await azure_doc_ai_client.analyze_document(path)
    #     with open("temp.pkl", "rb") as f:
    #         res = pickle.load(f)

    #     return await extract_metadata([str(data_row["text"]) for data_row in res])
    # res = asyncio.run(test("test_docs/test.pdf"))
    # print(res)