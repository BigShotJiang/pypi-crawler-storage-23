"""Animuz Core - Shared utilities for RAG system.

This package provides core utilities for building RAG (Retrieval-Augmented Generation) systems:
- LLM clients (OpenAI, Anthropic, Ollama)
- RAG pipelines (Simple and Agentic)
- Vector database integration (Qdrant)
- Embedding clients (Modal, S3, SageMaker)
- Document ingestion (Azure Doc AI, Unstructured, structured parsers)
"""

# Always-available imports (minimal deps: pydantic, httpx, aiohttp, requests)
from .genai.base import BaseLLM, BaseAgent
from .genai.tools import MCPTools
from .streaming.sse import format_sse_event, format_sse_error
from .streaming.message_mappers import map_to_responses_api, clean_output
from .tooling import ToolSpec, tool

__version__ = "0.1.4"

# Lazy imports for modules with optional dependencies
_LAZY_IMPORTS = {
    # OpenAI (requires openai)
    "OpenAIAgentClient": ".genai.openai_client",
    "OpenAILLMClient": ".genai.openai_llm_client",
    "OpenAIAgentClientStreaming": ".genai.openai_streaming_client",
    "OpenAIAgentClientResponses": ".genai.openai_responses_client",
    # Anthropic (requires anthropic)
    "AnthropicClient": ".genai.anthropic_client",
    "AnthropicAgentClient": ".genai.anthropic_client",
    # Ollama (requires ollama)
    "OLlamaClient": ".genai.ollama_client",
    # Pipelines (requires aiobotocore)
    "BasePipeline": ".pipelines.base",
    "AgenticRAG": ".pipelines.agentic_rag",
    "SimpleRAG": ".pipelines.simple_rag",
    # Vector DB (requires qdrant-client)
    "QdrantDBClient": ".vectordb.utils",
    # Embedding
    "EmbeddingClient": ".embedding.embedding_client",
    "ModalEmbeddingClient": ".embedding.modal_embedding_client",
    "S3EmbeddingClient": ".embedding.s3_embedding_client",
    # Ingestion
    "AzureDocAiClient": ".ingest.azure_doc_ai_client",
    "MyUnstructuredClient": ".ingest.custom_unstructured_client",
    "Structured": ".ingest.structured",
    # Profiling
    "Profiler": ".profiling",
    # Unified RAG
    "RAG": ".rag",
    "RAGConfig": ".rag",
}

# Special name mappings (when the class name differs from the attr name in its module)
_LAZY_RENAMES = {
    "QdrantDBClient": "MyQdrantClient",
}


def __getattr__(name):
    if name in _LAZY_IMPORTS:
        import importlib
        module = importlib.import_module(_LAZY_IMPORTS[name], __name__)
        actual_name = _LAZY_RENAMES.get(name, name)
        return getattr(module, actual_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Base classes
    "BaseLLM",
    "BaseAgent",
    "BasePipeline",
    # LLM clients
    "OpenAIAgentClient",
    "OpenAILLMClient",
    "OpenAIAgentClientStreaming",
    "OpenAIAgentClientResponses",
    "AnthropicClient",
    "AnthropicAgentClient",
    "OLlamaClient",
    # Tools
    "MCPTools",
    # Pipelines
    "AgenticRAG",
    "SimpleRAG",
    # Vector DB
    "QdrantDBClient",
    # Embedding
    "EmbeddingClient",
    "ModalEmbeddingClient",
    "S3EmbeddingClient",
    # Ingestion
    "AzureDocAiClient",
    "MyUnstructuredClient",
    "Structured",
    # Streaming helpers
    "format_sse_event",
    "format_sse_error",
    "map_to_responses_api",
    "clean_output",
    # Profiling
    "Profiler",
    # Unified RAG
    "RAG",
    "RAGConfig",
    "ToolSpec",
    "tool",
]
