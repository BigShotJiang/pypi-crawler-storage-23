# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2026-01-09 11:37
# @Author : 毛鹏
from .base_monitor import MonitorBase
