"""CLI handlers for Agent Teams commands.

Extends the existing /team command with agent team subcommands.
These are separate from the multiuser /team commands — they manage
agent-to-agent collaboration rather than human-to-human collaboration.

Commands:
    /team create <name>         Create an agent team (you become the lead)
    /team spawn <name> <role>   Spawn a teammate with a role
    /team status                Show team and teammate status
    /team tasks                 Show shared task list
    /team message <name> <msg>  Send a message to a teammate
    /team broadcast <msg>       Broadcast to all teammates
    /team shutdown <name>       Request a teammate shutdown
    /team cleanup               Clean up team resources
    /team delegate              Toggle delegate mode
    /team approve <name>        Approve a teammate's plan
    /team reject <name> <why>   Reject a teammate's plan with feedback

These are accessible via:
    /team <subcommand>            Inside the interactive REPL
"""

from rich.console import Console
from rich.table import Table
from rich.markdown import Markdown

console = Console()


def handle_team(args: str, client, session_id: str, user_id: str) -> dict:
    """Handle /team command for agent team management.

    Args:
        args: Subcommand and arguments
        client: API client (httpx)
        session_id: Current session ID
        user_id: Current user ID

    Returns:
        Result dict
    """
    parts = args.strip().split(maxsplit=1)
    subcommand = parts[0] if parts else ""
    subargs = parts[1] if len(parts) > 1 else ""

    if not subcommand:
        _show_team_help()
        return {}

    handlers = {
        "create": _handle_create,
        "spawn": _handle_spawn,
        "status": _handle_status,
        "tasks": _handle_tasks,
        "message": _handle_message,
        "msg": _handle_message,
        "broadcast": _handle_broadcast,
        "shutdown": _handle_shutdown,
        "cleanup": _handle_cleanup,
        "delegate": _handle_delegate,
        "approve": _handle_approve,
        "reject": _handle_reject,
    }

    handler = handlers.get(subcommand)
    if handler:
        return handler(subargs, client, session_id, user_id)
    else:
        console.print(f"[yellow]Unknown subcommand: {subcommand}[/yellow]")
        _show_team_help()
        return {}


def _show_team_help():
    """Show agent teams command help."""
    help_text = """
## Agent Teams Commands

| Command | Description |
|---|---|
| `/team create <name>` | Create an agent team |
| `/team spawn <name> <instructions>` | Spawn a teammate |
| `/team status` | Show team status |
| `/team tasks` | Show shared task list |
| `/team message <name> <msg>` | Message a teammate |
| `/team broadcast <msg>` | Broadcast to all |
| `/team shutdown <name>` | Shutdown a teammate |
| `/team cleanup` | Clean up team |
| `/team delegate` | Toggle delegate mode |
| `/team approve <name>` | Approve a plan |
| `/team reject <name> <feedback>` | Reject a plan |

Agent teams are auto-enabled when you run `/team create`.
"""
    console.print(Markdown(help_text))


# ─────────────────────────────────────────────────────────────
# Individual command handlers
# ─────────────────────────────────────────────────────────────


def _ensure_agent_teams_enabled() -> None:
    """Auto-enable agent teams in config if not already on."""
    from emdash_core.agent.teams import is_agent_teams_enabled
    if not is_agent_teams_enabled():
        from emdash_core.core.config import enable_experimental
        enable_experimental("agent_teams")
        console.print("[dim]Enabled agent_teams in emdash.config.json[/dim]")


def _handle_create(args: str, client, session_id: str, user_id: str) -> dict:
    """Create a new agent team."""
    team_name = args.strip()
    if not team_name:
        console.print("[yellow]Usage: /team create <team-name>[/yellow]")
        return {}

    _ensure_agent_teams_enabled()

    try:
        resp = client.post("/api/agent-teams/teams", json={
            "name": team_name,
            "lead_agent_id": session_id,
        })
        resp.raise_for_status()
        data = resp.json()

        console.print(f"[green]Created agent team '{team_name}'[/green]")
        _print_team_status(data.get("team", {}))
        return data

    except Exception as e:
        console.print(f"[red]Failed to create team: {e}[/red]")
        return {}


def _handle_spawn(args: str, client, session_id: str, user_id: str) -> dict:
    """Spawn a teammate."""
    parts = args.strip().split(maxsplit=1)
    if len(parts) < 2:
        console.print("[yellow]Usage: /team spawn <name> <instructions>[/yellow]")
        return {}

    name, prompt = parts[0], parts[1]

    # Extract labels from prompt if specified as [label1,label2]
    labels = []
    if prompt.startswith("[") and "]" in prompt:
        label_str, prompt = prompt.split("]", 1)
        labels = [label.strip() for label in label_str[1:].split(",")]
        prompt = prompt.strip()

    try:
        # Find active team
        resp = client.get("/api/agent-teams/teams")
        resp.raise_for_status()
        teams = resp.json().get("teams", [])
        if not teams:
            console.print("[yellow]No active team. Create one first: /team create <name>[/yellow]")
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/teammates", json={
            "name": name,
            "prompt": prompt,
            "labels": labels,
        })
        resp.raise_for_status()
        data = resp.json()

        console.print(f"[green]Spawned teammate '{name}' (agent_id: {data.get('agent_id', '?')})[/green]")
        if labels:
            console.print(f"  Labels: {', '.join(labels)}")
        return data

    except Exception as e:
        console.print(f"[red]Failed to spawn teammate: {e}[/red]")
        return {}


def _handle_status(args: str, client, session_id: str, user_id: str) -> dict:
    """Show team status."""
    try:
        resp = client.get("/api/agent-teams/teams")
        resp.raise_for_status()
        teams = resp.json().get("teams", [])

        if not teams:
            console.print("[dim]No active agent teams.[/dim]")
            return {}

        for team in teams:
            _print_team_status(team)

        return {"teams": teams}

    except Exception as e:
        console.print(f"[red]Failed to get status: {e}[/red]")
        return {}


def _handle_tasks(args: str, client, session_id: str, user_id: str) -> dict:
    """Show shared task list."""
    try:
        resp = client.get("/api/agent-teams/teams")
        resp.raise_for_status()
        teams = resp.json().get("teams", [])
        if not teams:
            console.print("[dim]No active agent teams.[/dim]")
            return {}

        team_name = teams[0]["team_name"]

        resp = client.get(f"/api/agent-teams/teams/{team_name}/tasks")
        resp.raise_for_status()
        data = resp.json()

        _print_tasks(data)
        return data

    except Exception as e:
        console.print(f"[red]Failed to get tasks: {e}[/red]")
        return {}


def _handle_message(args: str, client, session_id: str, user_id: str) -> dict:
    """Send a message to a teammate."""
    parts = args.strip().split(maxsplit=1)
    if len(parts) < 2:
        console.print("[yellow]Usage: /team message <name> <message>[/yellow]")
        return {}

    to_name, content = parts[0], parts[1]

    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/messages", json={
            "from_agent": "user",
            "to_agent": to_name,
            "content": content,
        })
        resp.raise_for_status()
        console.print(f"[dim]Message sent to {to_name}[/dim]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to send message: {e}[/red]")
        return {}


def _handle_broadcast(args: str, client, session_id: str, user_id: str) -> dict:
    """Broadcast to all teammates."""
    content = args.strip()
    if not content:
        console.print("[yellow]Usage: /team broadcast <message>[/yellow]")
        return {}

    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/messages", json={
            "from_agent": "user",
            "to_agent": "all",
            "content": content,
        })
        resp.raise_for_status()
        console.print("[dim]Broadcast sent to all teammates[/dim]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to broadcast: {e}[/red]")
        return {}


def _handle_shutdown(args: str, client, session_id: str, user_id: str) -> dict:
    """Shutdown a teammate."""
    name = args.strip()
    if not name:
        console.print("[yellow]Usage: /team shutdown <name>[/yellow]")
        return {}

    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/teammates/{name}/shutdown")
        resp.raise_for_status()
        data = resp.json()

        status = "stopped" if data.get("stopped") else "shutdown requested"
        console.print(f"[dim]Teammate '{name}': {status}[/dim]")
        return data

    except Exception as e:
        console.print(f"[red]Failed to shutdown: {e}[/red]")
        return {}


def _handle_cleanup(args: str, client, session_id: str, user_id: str) -> dict:
    """Clean up team resources."""
    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            console.print("[dim]No active teams to clean up.[/dim]")
            return {}

        team_name = teams[0]["team_name"]
        force = "force" in args.lower()

        resp = client.delete(
            f"/api/agent-teams/teams/{team_name}",
            params={"force": force},
        )
        resp.raise_for_status()
        console.print(f"[green]Team '{team_name}' cleaned up.[/green]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to cleanup: {e}[/red]")
        return {}


def _handle_delegate(args: str, client, session_id: str, user_id: str) -> dict:
    """Toggle delegate mode."""
    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]
        current = teams[0].get("delegate_mode", False)
        new_value = not current

        resp = client.post(f"/api/agent-teams/teams/{team_name}/delegate-mode", json={
            "enabled": new_value,
        })
        resp.raise_for_status()

        state = "ON" if new_value else "OFF"
        console.print(f"[dim]Delegate mode: {state}[/dim]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to toggle delegate mode: {e}[/red]")
        return {}


def _handle_approve(args: str, client, session_id: str, user_id: str) -> dict:
    """Approve a teammate's plan."""
    name = args.strip()
    if not name:
        console.print("[yellow]Usage: /team approve <name>[/yellow]")
        return {}

    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/teammates/{name}/plan", json={
            "approved": True,
        })
        resp.raise_for_status()
        console.print(f"[green]Plan approved for '{name}'[/green]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to approve: {e}[/red]")
        return {}


def _handle_reject(args: str, client, session_id: str, user_id: str) -> dict:
    """Reject a teammate's plan with feedback."""
    parts = args.strip().split(maxsplit=1)
    if len(parts) < 2:
        console.print("[yellow]Usage: /team reject <name> <feedback>[/yellow]")
        return {}

    name, feedback = parts[0], parts[1]

    try:
        resp = client.get("/api/agent-teams/teams")
        teams = resp.json().get("teams", [])
        if not teams:
            return {}

        team_name = teams[0]["team_name"]

        resp = client.post(f"/api/agent-teams/teams/{team_name}/teammates/{name}/plan", json={
            "approved": False,
            "feedback": feedback,
        })
        resp.raise_for_status()
        console.print(f"[yellow]Plan rejected for '{name}' with feedback[/yellow]")
        return resp.json()

    except Exception as e:
        console.print(f"[red]Failed to reject: {e}[/red]")
        return {}


# ─────────────────────────────────────────────────────────────
# Display helpers
# ─────────────────────────────────────────────────────────────


def _print_team_status(team: dict) -> None:
    """Print team status as a rich table."""
    table = Table(title=f"Agent Team: {team.get('team_name', '?')}")
    table.add_column("Name", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Labels")
    table.add_column("Task")
    table.add_column("Iterations", justify="right")

    for member in team.get("members", []):
        status = member.get("status", "?")
        status_style = {
            "working": "green",
            "idle": "yellow",
            "spawning": "blue",
            "plan_mode": "magenta",
            "stopped": "dim",
        }.get(status, "white")

        table.add_row(
            member.get("name", "?"),
            f"[{status_style}]{status}[/{status_style}]",
            ", ".join(member.get("labels", [])) or "-",
            member.get("current_task") or "-",
            str(member.get("iterations", 0)),
        )

    delegate = "[magenta]DELEGATE[/magenta]" if team.get("delegate_mode") else ""
    console.print(table)
    if delegate:
        console.print(f"  Mode: {delegate}")
    console.print(f"  Active: {team.get('active_count', 0)}/{team.get('total_count', 0)} teammates")
    console.print()


def _print_tasks(data: dict) -> None:
    """Print task list as a rich table."""
    table = Table(title=f"Shared Tasks ({data.get('total', 0)} total)")
    table.add_column("ID", style="dim")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Labels")
    table.add_column("Assigned")
    table.add_column("Priority", justify="right")

    status_styles = {
        "pending": "yellow",
        "in_progress": "green",
        "completed": "dim",
        "blocked": "red",
    }

    for task in data.get("tasks", []):
        status = task.get("status", "?")
        style = status_styles.get(status, "white")
        table.add_row(
            task.get("id", "?")[:8],
            task.get("title", "?"),
            f"[{style}]{status}[/{style}]",
            ", ".join(task.get("labels", [])) or "-",
            task.get("claimed_by") or "-",
            str(task.get("priority", 0)),
        )

    console.print(table)

    # Progress bar
    by_status = data.get("by_status", {})
    progress = data.get("progress_percent", 0)
    console.print(f"  Progress: {progress}% complete")
    console.print(
        f"  [yellow]{by_status.get('pending', 0)} pending[/yellow] · "
        f"[green]{by_status.get('in_progress', 0)} in progress[/green] · "
        f"[dim]{by_status.get('completed', 0)} completed[/dim] · "
        f"[red]{by_status.get('blocked', 0)} blocked[/red]"
    )
    console.print()
