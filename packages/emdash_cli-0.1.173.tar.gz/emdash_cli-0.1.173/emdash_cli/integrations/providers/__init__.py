"""Messaging provider abstractions for slash commands.

Provides a clean layer between CLI slash commands and messaging platforms
(Telegram, Slack, WhatsApp, etc.) so commands can be exposed uniformly
across providers.
"""

from .base import CommandProvider
from .modes import DEFAULT_MODE_REGISTRY, ModeDefinition
from .telegram import TelegramCommandProvider

__all__ = [
    "CommandProvider",
    "DEFAULT_MODE_REGISTRY",
    "ModeDefinition",
    "TelegramCommandProvider",
]
