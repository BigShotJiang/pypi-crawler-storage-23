# Digifact

A Python package for calculating manufacturing KPIs including OEE (Overall Equipment Efficiency), Availability, Performance, Quality, MTTR, and MTBF.

## Installation

```bash
pip install digifact