"""Unit tests for digifact core functionality"""

import unittest
from digifact.core import ProductionMetrics,calculate_availability, calculate_mtbf, calculate_mttr, calculate_oee, calculate_quality, calculate_performance

class TestDigifact(unittest.TestCase):
    
    def setUp(self):
        """Setup test data"""
        self.metrics = ProductionMetrics(
            total_time=480,  # 8 hours in minutes
            ideal_production=1000,  # Ideal units per shift
            actual_count=950,  # Actual units produced
            total_count=1000,  # Total units (including defects)
            fault_count=5,  # Number of breakdowns
            total_downtime=60,  # 60 minutes downtime
            total_uptime=420  # 420 minutes uptime
        )
    def test_calculate_availability(self):
        # """Availability = uptime / total_time * 100"""
        # result = calculate_availability(self.metrics)
        # self.assertAlmostEqual(result, 87.5, places=1)
        """Test availability calculation"""
        result = calculate_availability(self.metrics)
        self.assertEqual(result, 95.0)  # (950/1000)*100
        print(f"\nAvailability test passed: {result}%")
    
    def test_calculate_performance(self):
        # """Performance = actual / ideal * 100"""
        # result = calculate_performance(self.metrics)
        # self.assertAlmostEqual(result, 95.0, places=1)
        """Test performance calculation"""
        result = calculate_performance(self.metrics)
        self.assertAlmostEqual(result, 95.0, places=1)
        print(f"\nPerformance test passed: {result}%")
    
    def test_calculate_quality(self):
        # """Quality = good / total * 100"""
        # result = calculate_quality(self.metrics)
        # self.assertAlmostEqual(result, 95.0, places=1)
        """Test quality calculation"""
        result = calculate_quality(self.metrics)
        self.assertEqual(result, -5.0)  # (950-1000)/1000*100
        print(f"\nQuality test passed: {result}%")
    
    def test_calculate_mttr(self):
        # """MTTR = downtime / faults"""
        # result = calculate_mttr(self.metrics)
        # self.assertEqual(result, 12.0)   
        """Test MTTR calculation"""
        result = calculate_mttr(self.metrics)
        self.assertEqual(result, 12.0)  # 60/5
        print(f"\nMTTR test passed: {result} minutes")
    
    def test_calculate_mtbf(self):
        # """MTBF = uptime / faults"""
        # result = calculate_mtbf(self.metrics)
        # self.assertEqual(result, 84.0)
        """Test MTBF calculation"""
        result = calculate_mtbf(self.metrics)
        self.assertEqual(result, 84.0)  # 420/5
        print(f"\nMTBF test passed: {result} minutes")
    
    def test_calculate_oee(self):
        # """OEE = Availability × Performance × Quality / 10000"""
        # result = calculate_oee(self.metrics)

        # self.assertIn("oee", result)
        # self.assertIn("availability", result)
        # self.assertIn("performance", result)
        # self.assertIn("quality", result)

        # self.assertAlmostEqual(result["availability"], 87.5, places=1)
        # self.assertAlmostEqual(result["performance"], 95.0, places=1)
        # self.assertAlmostEqual(result["quality"], 95.0, places=1)

        # expected_oee = (87.5 * 95.0 * 95.0) / 10000
        # self.assertAlmostEqual(result["oee"], expected_oee, places=1)
        """Test OEE calculation"""
        result = calculate_oee(self.metrics)
        self.assertIn('oee', result)
        self.assertIn('availability', result)
        self.assertIn('performance', result)
        self.assertIn('quality', result)
        print(f"\nOEE test passed: {result['oee']}")

    # def test_zero_fault_mttr(self):
    #    self.metrics.fault_count = 0
    #    result = calculate_mttr(self.metrics)
    #    self.assertEqual(result, 0)

    # def test_zero_total_time_availability(self):
    #     self.metrics.total_time = 0
    #     result = calculate_availability(self.metrics)
    #     self.assertEqual(result, 0)
    


if __name__ == '__main__':
    metrics2 = ProductionMetrics(
        total_time=10000,
        ideal_production=1000,
        actual_count=100,
        total_count=800,
        fault_count=5,
        total_downtime=200,
        total_uptime=830
    )
    result = calculate_availability(metrics2)
    print(f"Availability: {result}%")
    # unittest.main()