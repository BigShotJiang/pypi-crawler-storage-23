"""Utility functions for digifact package"""

from typing import Dict, Any
import json
from datetime import datetime


def validate_metrics(data: Dict[str, Any]) -> bool:
    """
    Validate input metrics data
    
    Args:
        data: Dictionary containing metric values
        
    Returns:
        True if valid, raises ValueError if invalid
    """
    required_fields = [
        'total_time', 'ideal_production', 'actual_count', 
        'total_count', 'fault_count', 'total_downtime', 'total_uptime'
    ]
    
    # Check for required fields
    for field in required_fields:
        if field not in data:
            raise ValueError(f"Missing required field: {field}")
        
        # Check for negative values
        if data[field] < 0:
            raise ValueError(f"{field} cannot be negative")
    
    # Validate relationships
    if data['total_downtime'] + data['total_uptime'] > data['total_time']:
        raise ValueError("Downtime + Uptime cannot exceed total time")
    
    if data['actual_count'] > data['total_count']:
        raise ValueError("Actual count cannot exceed total count")
    
    return True


def export_to_json(metrics: Dict[str, Any], filename: str = None) -> str:
    """
    Export metrics to JSON file
    
    Args:
        metrics: Dictionary containing calculated metrics
        filename: Optional filename (auto-generated if not provided)
        
    Returns:
        Path to saved file
    """
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"digifact_metrics_{timestamp}.json"
    
    # Add timestamp to data
    metrics['export_timestamp'] = datetime.now().isoformat()
    
    with open(filename, 'w') as f:
        json.dump(metrics, f, indent=2)
    
    return filename


def format_report(metrics: Dict[str, Any]) -> str:
    """
    Format metrics as readable report
    
    Args:
        metrics: Dictionary containing calculated metrics
        
    Returns:
        Formatted report string
    """
    report = []
    report.append("=" * 50)
    report.append("DIGIFACT PRODUCTION METRICS REPORT")
    report.append("=" * 50)
    report.append("")
    
    if 'oee_analysis' in metrics:
        oee = metrics['oee_analysis']
        report.append("OEE ANALYSIS:")
        report.append(f"  Overall OEE: {oee['oee']:.2f}")
        report.append(f"  Availability: {oee['availability']:.2f}%")
        report.append(f"  Performance: {oee['performance']:.2f}%")
        report.append(f"  Quality: {oee['quality']:.2f}%")
        report.append("")
    
    if 'mttr' in metrics:
        report.append(f"MTTR: {metrics['mttr']:.2f} time units")
    
    if 'mtbf' in metrics:
        mtbf = metrics['mtbf']
        if mtbf == float('inf'):
            report.append("MTBF: Infinite (no failures)")
        else:
            report.append(f"MTBF: {mtbf:.2f} time units")
    
    report.append("")
    report.append("=" * 50)
    
    return "\n".join(report)