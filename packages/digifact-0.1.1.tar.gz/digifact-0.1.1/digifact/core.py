"""Core functionality for digifact package"""
# Module docstring explaining this file's purpose
from dataclasses import dataclass
# Imports dataclass decorator - automatically generates __init__, __repr__, etc.
from typing import Optional, Dict, Any
# Imports Optional and Dict type hints


@dataclass
class ProductionMetrics:
    """Data class to hold production metrics and calculate all KPIs"""
    
    # Attributes
    total_time: float  # Total available time
    ideal_production: float  # Ideal production rate (units per time)
    actual_count: float  # Actual units produced
    total_count: float  # Total units (including defects)
    fault_count: float  # Number of faults/breakdowns
    total_downtime: float  # Total downtime
    total_uptime: float  # Total uptime
    
    def calculate_availability(self) -> float:
        """
        Calculate Availability
        
        Returns:
            Availability percentage
        """
        try:
            availability = (self.total_time - self.total_downtime) / self.total_time * 100
            # availability = (self.actual_count * 100) / self.ideal_production
            return round(availability, 2)
        except ZeroDivisionError:
            raise ValueError("Total time cannot be zero")
        except Exception as e:
            raise ValueError(f"Error calculating availability: {str(e)}")
    
    def calculate_performance(self) -> float:
        """
        Calculate Performance
        
        Returns:
            Performance percentage
        """
        try:
            # Performance = (Actual Production Rate / Ideal Production Rate) * 100
            # actual_rate = self.actual_count / self.total_time
            # ideal_rate = self.ideal_production / self.total_time
            performance = (self.total_count / self.ideal_production) * 100
            return round(performance, 2)
        except ZeroDivisionError:
            raise ValueError("Ideal production cannot be zero")
        except Exception as e:
            raise ValueError(f"Error calculating performance: {str(e)}")
    
    def calculate_quality(self) -> float:
        """
        Calculate Quality
        
        Formula: Quality = (Good Units / Total Units) * 100
        
        Returns:
            Quality percentage
        """
        try:
            if self.total_count == 0:
                raise ValueError("Total count cannot be zero")
            
            # Calculate quality as percentage of good units
            quality = (self.actual_count / self.total_count) * 100
            return round(quality, 2)
            
        except ZeroDivisionError:
            raise ValueError("Total count cannot be zero")
        except Exception as e:
            raise ValueError(f"Error calculating quality: {str(e)}")
    
    def calculate_oee(self) -> Dict[str, Any]:
        """
        Calculate Overall Equipment Efficiency (OEE)
        
        OEE = (Availability × Performance × Quality) / 100
        
        Returns:
            Dictionary containing OEE and its components
        """
        try:
            availability = self.calculate_availability()
            performance = self.calculate_performance()
            quality = self.calculate_quality()
            
            # Calculate OEE (all inputs are percentages)
            oee = (availability/100 * performance/100 * quality/100)*100
            oee = round(oee, 2)
            
            return {
                'oee': oee,
                'availability': availability,
                'performance': performance,
                'quality': quality,
                'components': {
                    'availability_pct': availability,
                    'performance_pct': performance,
                    'quality_pct': quality
                }
            }
        except Exception as e:
            raise ValueError(f"Error calculating OEE: {str(e)}")
    
    def calculate_mttr(self) -> float:
        """
        Calculate Mean Time To Repair (MTTR)
        
        MTTR = Total down time / Fault count
        
        Returns:
            MTTR value
        """
        try:
            if self.fault_count == 0:
                return 0.0
            
            mttr = self.total_downtime / self.fault_count
            return round(mttr, 2)
        except ZeroDivisionError:
            raise ValueError("Fault count cannot be zero")
        except Exception as e:
            raise ValueError(f"Error calculating MTTR: {str(e)}")
    
    def calculate_mtbf(self) -> float:
        """
        Calculate Mean Time Between Failures (MTBF)
        
        MTBF = Total uptime / Fault count
        
        Returns:
            MTBF value
        """
        try:
            if self.fault_count == 0:
                return float('inf')  # No failures means infinite MTBF
            
            mtbf = self.total_uptime / self.fault_count
            return round(mtbf, 2)
        except ZeroDivisionError:
            raise ValueError("Fault count cannot be zero")
        except Exception as e:
            raise ValueError(f"Error calculating MTBF: {str(e)}")
    
    def calculate_all_metrics(self) -> Dict[str, Any]:
        """
        Calculate all metrics at once
        
        Returns:
            Dictionary containing all calculated metrics
        """
        return {
            'oee_analysis': self.calculate_oee(),
            'mttr': self.calculate_mttr(),
            'mtbf': self.calculate_mtbf(),
            'raw_data': {
                'total_time': self.total_time,
                'ideal_production': self.ideal_production,
                'actual_count': self.actual_count,
                'total_count': self.total_count,
                'fault_count': self.fault_count,
                'total_downtime': self.total_downtime,
                'total_uptime': self.total_uptime
            }
        }
    
    def get_defect_count(self) -> float:
        """
        Calculate number of defective units
        
        Returns:
            Number of defective units
        """
        return self.total_count - self.actual_count
    
    def get_defect_rate(self) -> float:
        """
        Calculate defect rate percentage
        
        Returns:
            Defect rate percentage
        """
        if self.total_count == 0:
            return 0.0
        return round((self.get_defect_count() / self.total_count) * 100, 2)
    
    def get_utilization_rate(self) -> float:
        """
        Calculate equipment utilization rate
        
        Returns:
            Utilization rate percentage
        """
        if self.total_time == 0:
            return 0.0
        return round((self.total_uptime / self.total_time) * 100, 2)
    
    def get_production_efficiency(self) -> float:
        """
        Calculate production efficiency
        
        Returns:
            Production efficiency percentage
        """
        if self.ideal_production == 0:
            return 0.0
        return round((self.actual_count / self.ideal_production) * 100, 2)
    
    def get_failure_frequency(self) -> float:
        """
        Calculate failure frequency per hour
        
        Returns:
            Failures per hour
        """
        if self.total_time == 0:
            return 0.0
        return round(self.fault_count / (self.total_time / 60), 2)
    
    def get_cycle_times(self) -> Dict[str, float]:
        """
        Calculate ideal and actual cycle times
        
        Returns:
            Dictionary with cycle times
        """
        ideal_cycle_time = self.total_time / self.ideal_production if self.ideal_production > 0 else 0
        actual_cycle_time = self.total_uptime / self.actual_count if self.actual_count > 0 else 0
        
        return {
            'ideal_cycle_time': round(ideal_cycle_time, 2),
            'actual_cycle_time': round(actual_cycle_time, 2)
        }
    
    def get_run_rates(self) -> Dict[str, float]:
        """
        Calculate ideal and actual run rates
        
        Returns:
            Dictionary with run rates
        """
        ideal_run_rate = self.ideal_production / self.total_time if self.total_time > 0 else 0
        actual_run_rate = self.actual_count / self.total_uptime if self.total_uptime > 0 else 0
        
        return {
            'ideal_run_rate': round(ideal_run_rate, 2),
            'actual_run_rate': round(actual_run_rate, 2)
        }
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Get complete summary of all metrics
        
        Returns:
            Dictionary with all calculated metrics
        """
        return {
            'input_data': {
                'total_time': self.total_time,
                'ideal_production': self.ideal_production,
                'actual_count': self.actual_count,
                'total_count': self.total_count,
                'fault_count': self.fault_count,
                'total_downtime': self.total_downtime,
                'total_uptime': self.total_uptime
            },
            'oee_components': {
                'availability': self.calculate_availability(),
                'performance': self.calculate_performance(),
                'quality': self.calculate_quality()
            },
            'oee': self.calculate_oee()['oee'],
            'maintenance': {
                'mttr': self.calculate_mttr(),
                'mtbf': self.calculate_mtbf()
            },
            'quality_metrics': {
                'defect_count': self.get_defect_count(),
                'defect_rate': self.get_defect_rate()
            },
            'efficiency_metrics': {
                'utilization_rate': self.get_utilization_rate(),
                'production_efficiency': self.get_production_efficiency(),
                'failure_frequency': self.get_failure_frequency()
            },
            'cycle_analysis': {
                'cycle_times': self.get_cycle_times(),
                'run_rates': self.get_run_rates()
            }
        }
    
    def __str__(self) -> str:
        """
        String representation of the metrics
        
        Returns:
            Formatted string with key metrics
        """
        return (f"ProductionMetrics("
                f"total_time={self.total_time}, "
                f"ideal={self.ideal_production}, "
                f"actual={self.actual_count}, "
                f"total={self.total_count}, "
                f"faults={self.fault_count})")
    
    def __repr__(self) -> str:
        """
        Detailed string representation
        
        Returns:
            Detailed string with all attributes
        """
        return (f"ProductionMetrics("
                f"total_time={self.total_time}, "
                f"ideal_production={self.ideal_production}, "
                f"actual_count={self.actual_count}, "
                f"total_count={self.total_count}, "
                f"fault_count={self.fault_count}, "
                f"total_downtime={self.total_downtime}, "
                f"total_uptime={self.total_uptime})")