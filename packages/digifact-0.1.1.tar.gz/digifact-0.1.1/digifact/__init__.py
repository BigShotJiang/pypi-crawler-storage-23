"""Digifact - Manufacturing KPIs Calculation Package"""
# This is a docstring - it describes what the package does
# It appears when someone uses help(digifact) or looks at documentation
from digifact.core import ProductionMetrics

# These import statements make these functions/classes available 
# when someone does "from digifact import *"
# It saves users from having to import from digifact.core directly

__version__ = "0.1.0"
__all__ = [
    "ProductionMetrics"
]
# __all__ specifies what gets imported when someone uses "from digifact import *"
# It's like a whitelist of public objects