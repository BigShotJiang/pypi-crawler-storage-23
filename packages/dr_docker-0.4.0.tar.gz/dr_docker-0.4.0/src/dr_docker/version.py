"""Version constants for dr_docker."""

__version__ = "0.4.0"
CONTRACT_VERSION = "0.4.0"
