"""deepagents version information."""

__version__ = "0.4.2"  # x-release-please-version
