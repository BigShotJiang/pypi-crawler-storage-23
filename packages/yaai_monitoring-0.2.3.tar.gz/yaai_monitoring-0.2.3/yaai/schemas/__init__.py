"""Shared Pydantic schemas for the yaai SDK and server."""
