"""Server-only Pydantic schemas (auth, jobs, dashboard)."""
