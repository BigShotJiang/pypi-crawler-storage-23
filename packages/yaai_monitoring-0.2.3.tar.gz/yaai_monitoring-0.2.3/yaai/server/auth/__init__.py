"""Authentication and authorization module for YAAI Monitoring."""
