"""yaai server - FastAPI backend for the yaai monitoring platform."""
