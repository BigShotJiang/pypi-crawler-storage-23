"""Drift detection algorithms."""
