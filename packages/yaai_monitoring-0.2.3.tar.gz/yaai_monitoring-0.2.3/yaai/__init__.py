"""yaai - Yet Another AI monitoring SDK and platform."""

from yaai.client import YaaiClient

__all__ = ["YaaiClient"]
