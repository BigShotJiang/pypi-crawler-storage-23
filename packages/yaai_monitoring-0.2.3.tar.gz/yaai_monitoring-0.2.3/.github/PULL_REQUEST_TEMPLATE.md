## Summary

Brief description of the changes.

## Changes

- ...

## Testing

How were these changes tested?

- [ ] Backend tests pass (`uv run pytest`)
- [ ] Frontend type check passes (`npm run type-check`)
- [ ] Tested manually in browser
