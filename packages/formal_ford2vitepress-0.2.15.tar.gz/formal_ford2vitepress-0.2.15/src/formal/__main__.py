"""Allow running FORMAL as: python -m formal"""

from formal.cli import main

main()
