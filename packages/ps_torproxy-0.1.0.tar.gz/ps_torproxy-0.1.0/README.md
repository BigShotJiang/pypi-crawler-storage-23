# ps-torproxy

A simple Python library to install, manage, and route HTTP traffic through the Tor network.

## Installation

```bash
pip install ps_torproxy
```

## Prerequisites

- Linux (Debian-based) with `sudo` access
- `apt` package manager

## Usage

```python
from ps_torproxy import TorProxy

proxy = TorProxy()

# Check if traffic is going through Tor
print(proxy.check_proxy())  # True

# Get current exit IP
print(proxy.get_current_ip())

# Get a new identity (new IP)
proxy.renew_identity()

# Make a safe GET request with retries
response = proxy.safe_get("https://example.com")

# Cleanup when done
proxy.cleanup()
```
