import os
from loguru import logger

_LOG_DIR = os.path.join(os.getcwd(), "logs")
os.makedirs(_LOG_DIR, exist_ok=True)

logger.add(
    os.path.join(_LOG_DIR, "ps_torproxy.log"),
    rotation="3 MB",
    retention="7 days",
    level="DEBUG",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level:<8} | {name}:{function}:{line} - {message}",
    backtrace=True,
    diagnose=True,
)

from .main import TorProxy
from .tor_setup import TorSetup

__all__ = ["TorProxy", "TorSetup"]
__version__ = "0.1.0"