import subprocess
import sys
import shutil

from loguru import logger


class TorSetup:
    @staticmethod
    def install_tor():
        command = ['sudo', 'apt', 'install', 'tor', '-y']
        try:
            subprocess.run(command, check=True, stdout=sys.stdout, stderr=sys.stderr)
            logger.success("Successfully installed Tor")
        except subprocess.CalledProcessError as e:
            logger.error(f"Package installation failed: {e}")
            raise
        except FileNotFoundError:
            logger.error("'sudo' or 'apt' command not found. Are you on a Debian-based system?")
            raise

    @staticmethod
    def start_tor():
        command = ["sudo", "service", "tor", "start"]
        try:
            subprocess.run(command, check=True, stdout=sys.stdout, stderr=sys.stderr)
            logger.success("Successfully started Tor")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to start Tor: {e}")
            raise
        except FileNotFoundError:
            logger.error("'sudo' or 'service' command not found")
            raise

    @staticmethod
    def stop_tor():
        command = ["sudo", "service", "tor", "stop"]
        try:
            subprocess.run(command, check=True, stdout=sys.stdout, stderr=sys.stderr)
            logger.success("Successfully stopped Tor")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to stop Tor: {e}")
            raise
        except FileNotFoundError:
            logger.error("'sudo' or 'service' command not found")
            raise

    @staticmethod
    def restart_tor():
        command = ["sudo", "service", "tor", "restart"]
        try:
            subprocess.run(command, check=True, stdout=sys.stdout, stderr=sys.stderr)
            logger.success("Successfully restarted Tor")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to restart Tor: {e}")
            raise
        except FileNotFoundError:
            logger.error("'sudo' or 'service' command not found")
            raise

    @staticmethod
    def status_tor():
        command = ["sudo", "service", "tor", "status"]
        try:
            result = subprocess.run(command, capture_output=True, text=True)
            is_running = "active (running)" in result.stdout
            if is_running:
                logger.info("Tor is running")
            else:
                logger.warning("Tor is not running")
            return is_running
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to check Tor status: {e}")
            return False
        except FileNotFoundError:
            logger.error("'sudo' or 'service' command not found")
            return False

    @staticmethod
    def is_tor_installed():
        installed = shutil.which("tor") is not None
        logger.debug(f"Tor installed: {installed}")
        return installed

    @staticmethod
    def uninstall_tor():
        command = ['sudo', 'apt', 'remove', 'tor', '-y']
        try:
            subprocess.run(command, check=True, stdout=sys.stdout, stderr=sys.stderr)
            logger.success("Successfully uninstalled Tor")
        except subprocess.CalledProcessError as e:
            logger.error(f"Package removal failed: {e}")
            raise
        except FileNotFoundError:
            logger.error("'sudo' or 'apt' command not found")
            raise