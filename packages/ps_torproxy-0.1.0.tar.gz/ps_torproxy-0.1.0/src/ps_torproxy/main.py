import json
import os
import subprocess
import time

import requests
from loguru import logger

from .tor_setup import TorSetup


class TorProxy:
    def __init__(self):
        init_file = os.path.join(os.getcwd(), 'tor_inti.json')
        try:
            if not os.path.exists(init_file):
                if not TorSetup.is_tor_installed():
                    logger.info("Tor not found, installing...")
                    TorSetup.install_tor()
                logger.info("Starting Tor service...")
                TorSetup.start_tor()
                with open(init_file, 'w') as f:
                    json.dump({'tor_initilized': True}, f, indent=2)
                logger.success("TorProxy initialized")
            else:
                logger.debug("Tor already initialized, skipping setup")
        except (subprocess.CalledProcessError, FileNotFoundError, OSError) as e:
            logger.exception(f"Failed to initialize TorProxy: {e}")
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during TorProxy init: {e}")
            raise

    def get_proxy(self):
        return {
            "http": "socks5h://127.0.0.1:9050",
            "https": "socks5h://127.0.0.1:9050"
        }

    def check_proxy(self):
        try:
            r = requests.get(
                "https://check.torproject.org/api/ip",
                proxies=self.get_proxy(),
                timeout=20,
            )
            r.raise_for_status()
            is_tor = r.json().get("IsTor", False)
            logger.info(f"Proxy check — IsTor: {is_tor}")
            return is_tor
        except requests.ConnectionError as e:
            logger.error(f"Connection failed during proxy check (is Tor running?): {e}")
            return False
        except requests.Timeout:
            logger.error("Proxy check timed out")
            return False
        except requests.RequestException as e:
            logger.exception(f"Proxy check failed: {e}")
            return False

    def get_current_ip(self):
        try:
            r = requests.get(
                "https://check.torproject.org/api/ip",
                proxies=self.get_proxy(),
                timeout=20,
            )
            r.raise_for_status()
            ip = r.json().get("IP", None)
            logger.info(f"Current exit IP: {ip}")
            return ip
        except requests.ConnectionError as e:
            logger.error(f"Connection failed while fetching IP: {e}")
            return None
        except requests.Timeout:
            logger.error("IP fetch timed out")
            return None
        except requests.RequestException as e:
            logger.exception(f"Failed to get current IP: {e}")
            return None

    def renew_identity(self, wait=5):
        try:
            logger.info("Renewing Tor identity...")
            TorSetup.restart_tor()
            time.sleep(wait)
            new_ip = self.get_current_ip()
            logger.success(f"New IP: {new_ip}")
            return new_ip
        except Exception as e:
            logger.exception(f"Failed to renew identity: {e}")
            return None

    def get_session(self):
        try:
            session = requests.Session()
            session.proxies.update(self.get_proxy())
            session.timeout = 20
            logger.debug("Created new Tor-proxied session")
            return session
        except Exception as e:
            logger.exception(f"Failed to create session: {e}")
            raise

    def safe_get(self, url, retries=3, **kwargs):
        for attempt in range(retries):
            try:
                logger.debug(f"safe_get attempt {attempt + 1}/{retries} → {url}")
                r = requests.get(url, proxies=self.get_proxy(), timeout=20, **kwargs)
                r.raise_for_status()
                logger.info(f"safe_get succeeded for {url}")
                return r
            except requests.ConnectionError as e:
                logger.warning(f"Attempt {attempt + 1}/{retries} connection error: {e}")
            except requests.Timeout:
                logger.warning(f"Attempt {attempt + 1}/{retries} timed out")
            except requests.HTTPError as e:
                logger.warning(f"Attempt {attempt + 1}/{retries} HTTP error: {e}")
            except requests.RequestException as e:
                logger.warning(f"Attempt {attempt + 1}/{retries} failed: {e}")
            if attempt < retries - 1:
                time.sleep(2)
        logger.error(f"All {retries} attempts failed for {url}")
        return None

    def cleanup(self):
        try:
            TorSetup.stop_tor()
            init_file = os.path.join(os.getcwd(), 'tor_inti.json')
            if os.path.exists(init_file):
                os.remove(init_file)
                logger.info("Removed initialization file")
            logger.success("Cleanup complete")
        except OSError as e:
            logger.exception(f"Failed to remove init file: {e}")
        except Exception as e:
            logger.exception(f"Cleanup failed: {e}")


if __name__ == "__main__":
    tor_proxy = TorProxy()
    proxies = tor_proxy.get_proxy()
    value = tor_proxy.check_proxy()
    logger.info(f"Check proxy result: {value}")