## [0.1.4] - 2026-03-04

### 🐛 Bug Fixes

- *(release)* Verify git-cliff with asset sha512 file
- *(release)* Make git-cliff install resilient to archive layout

### ⚙️ Miscellaneous Tasks

- *(release)* Bump version to 0.1.4
