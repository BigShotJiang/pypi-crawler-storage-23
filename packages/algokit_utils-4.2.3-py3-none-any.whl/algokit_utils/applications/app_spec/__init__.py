from algokit_utils.applications.app_spec.arc32 import *  # noqa: F403
from algokit_utils.applications.app_spec.arc56 import *  # noqa: F403
