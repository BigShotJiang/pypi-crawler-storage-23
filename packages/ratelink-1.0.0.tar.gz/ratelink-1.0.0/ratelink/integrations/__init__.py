"""Framework integrations for ratelink."""
