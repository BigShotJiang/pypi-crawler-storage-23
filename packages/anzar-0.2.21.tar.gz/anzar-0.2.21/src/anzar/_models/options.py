from generated.openapi_client.models import SessionTokens

from dataclasses import dataclass
from collections.abc import Callable


@dataclass
class SdkOptions:
    get_token: Callable[[], str | None]
    get_refresh_token: Callable[[], str | None]
    on_token_refresh: Callable[["SessionTokens"], None] | None = None
    on_session_expired: Callable[[], None] | None = None
    on_logout: Callable[[], None] | None = None
