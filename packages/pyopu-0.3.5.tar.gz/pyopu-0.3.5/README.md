# pyopu: Organoid Processing Unit Framework

`pyopu` is a Python framework for simulating and executing combinatorial optimization tasks on biological wetware (Brain Organoids) using the **Holographic Tensorial Paradigm**.

## Features
- **Agnostic Math Engine:** Compile NP-Hard problems into arbitrary high-order arrays using dynamic `np.einsum`.
- **Holographic NeoCode Paradigm:** Define problems with algebraic logic and visually inspect Hamiltonian graphs.
- **Interchangeable Backends:** Run problems on virtual MEAs (Microelectrode Arrays) or advanced Dual-Opsin Optogenetic interfaces.
- **Observer Telemetry:** Extract spikes, opsin kinetics, and energy dynamics cleanly without cluttering the engine.

## Defining Problems with NeoCode
`pyopu` uses the new NeoCode Compiler to translate logical problem definitions directly into dynamic high-order tensor arrays.

```python
from pyopu.neocode import NeoCode, NeoTerm

prog = NeoCode(num_neobits=5)
prog.add_term(NeoTerm(weight=-20, logic=["x1", "~x3", "x4"]))
prog.draw()
```
The `draw()` method outputs a visual representation of the problem topology and algebraic Hamiltonian equation.

## Quickstart
Check the `examples/` directory for full implementations of the Max-Cut and 3-SAT problems using the new `NeoCode` abstraction.
