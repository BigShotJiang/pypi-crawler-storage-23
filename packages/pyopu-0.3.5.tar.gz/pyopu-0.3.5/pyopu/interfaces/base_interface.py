from abc import ABC, abstractmethod

class BaseInterface(ABC):
    @abstractmethod
    def get_biological_equations(self):
        pass

    @abstractmethod
    def reset(self):
        pass
    @abstractmethod
    def read_from_organoid(self, spike_monitor, neurons_per_neobit, num_neobits): pass
    @abstractmethod
    def write_to_organoid(self, neuron_group, force_array, neurons_per_neobit): pass
