import numpy as np
from .base_telemetry import BaseTelemetry

class EnergyTelemetry(BaseTelemetry):
    def __init__(self):
        self.history_energy = []

    def attach(self, engine):
        from pyopu.engine import TensorEngine
        if not isinstance(engine, TensorEngine):
            raise TypeError("EnergyTelemetry must be attached to a TensorEngine.")

    def update(self, x_state, force):
        energy = -np.sum(x_state * force)
        self.history_energy.append(energy)

    def reset(self):
        self.history_energy = []

    def get_data(self):
        return {"energy_over_time": self.history_energy}
