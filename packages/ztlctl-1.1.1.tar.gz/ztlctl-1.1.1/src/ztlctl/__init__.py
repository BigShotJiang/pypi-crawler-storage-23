"""ztlctl — Zettelkasten Control CLI utility."""

__version__ = "1.1.1"
