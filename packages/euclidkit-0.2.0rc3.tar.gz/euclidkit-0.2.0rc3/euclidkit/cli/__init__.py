"""
Command line interface modules for euclidkit package.

This module provides CLI tools and utilities.
"""

# These imports will be enabled as modules are implemented
# from .main import main, pipeline
# from .cutout_cli import cutouts_main
# from .spec_cli import spectra_main
# from .composite_cli import composite_main

__all__ = [
    # Will be populated as modules are implemented
    # "main", "pipeline",
    # "cutouts_main", "spectra_main", "composite_main",
]