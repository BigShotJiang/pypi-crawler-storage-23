## Summary

<!-- What does this PR do? 1-2 sentences. Link to the issue if applicable. -->

Fixes #

## Changes

<!-- Bullet list of what changed. -->

-

## Type of Change

<!-- Check all that apply. -->

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update
- [ ] Codegen pipeline change (scripts/, seeds/)
- [ ] CI/infrastructure change

## How Has This Been Tested?

<!-- Describe the tests you ran and how to reproduce them. -->

- [ ] `just test` passes
- [ ] New/updated tests cover the change

## Checklist

<!-- Verify all items before requesting review. -->

- [ ] My code follows the project's style (pre-commit hooks pass)
- [ ] I have added tests that prove my fix/feature works
- [ ] New and existing tests pass locally (`just test`)
- [ ] I have updated the CHANGELOG.md (if user-facing change)
- [ ] I have updated documentation (if applicable)
- [ ] Generated files are up-to-date (`just generate && git diff --quiet`)
