# User Guide

```{toctree}
---
maxdepth: 2
---
architecture-and-concepts
builders
expression-language
data-flow
prompts
execution
callbacks
presets
state-transforms
structured-data
context-engineering
patterns
visibility
transfer-control
memory
ir-and-backends
middleware
testing
error-reference
adk-samples/index
```

## Interactive References

Standalone HTML pages — open in browser for the full interactive experience:

- [P·C·S Visual Reference](/pcs-visual-reference.html) — Pipeline, Context, and State module reference
- [Operator Algebra Reference](/operator-algebra-reference.html) — All 9 operators with SVG diagrams and composition rules
