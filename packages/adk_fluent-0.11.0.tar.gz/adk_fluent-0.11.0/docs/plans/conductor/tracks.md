# Tracks Registry

| Track ID        | Description                                          | Status    | Link                                          |
| --------------- | ---------------------------------------------------- | --------- | --------------------------------------------- |
| `docs-codegen`  | Docs & README Auto-generation (Rising with the Tide) | Completed | [View Track](./tracks/docs-codegen/index.md)  |
| `md-formatting` | Markdown Auto-Formatting & Linter Integration        | Completed | [View Track](./tracks/md-formatting/index.md) |
