"""Memory benchmark placeholder package."""
