# batch-evenly

Distribute items into evenly-sized batches.

## Installation

```shell
pip install batch-evenly
```

## Usage

```python
from batch_evenly import batch_evenly

# Distribute 10 items into 3 batches of at most 4 items each
for i, batch in batch_evenly(range(10), max_batch_size=4):
	print(f"Batch {i+1} ({len(batch)} items): {batch}")

# Output:
# Batch 1 (4 items): [0, 1, 2, 3]
# Batch 2 (3 items): [4, 5, 6]
# Batch 3 (3 items): [7, 8, 9]
```

## Features

- Yields evenly sized batches (e.g. in the example, `[4, 3, 3]` instead of `[4, 4, 2]`)
- Works with any iterable
- Optional support for batching Pandas DataFrames by row iteration
- Zero required dependencies

## License

MIT
