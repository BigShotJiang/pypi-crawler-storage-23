from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Generator, Iterable, TypeVar

if TYPE_CHECKING:
    import pandas as pd


T = TypeVar("T")


def batch_evenly(
    items: Iterable[T] | pd.DataFrame, max_batch_size: int
) -> Generator[tuple[int, list[T] | pd.DataFrame], None, None]:
    """
    Yields approximately evenly sized batches from an iterable or data frame such that
    each batch has at most `max_batch_size` items.

    For example, when `len(items)` is 10 and `max_batch_size` is 4, then 3 batches will
    be needed, but we prefer a batch of [4, 3, 3] rather than [4, 4, 2].

    :param items: the iterable or DataFrame to be batched
    :param max_batch_size: the maximum size of each batch
    :return: a generator yielding batches from the input items
    """

    # Check if items is a pandas DataFrame
    try:
        import pandas as pd

        is_dataframe = isinstance(items, pd.DataFrame)
    except ImportError:
        is_dataframe = False

    batchable_items: pd.DataFrame | list[T]

    if is_dataframe:
        batchable_items = items  # type: ignore[assignment]
        comprehender = df_comprehender
    else:
        try:
            batchable_items = list(items)
            comprehender = list_comprehender
        except TypeError as e:
            raise TypeError(f"Cannot batch items of type {type(items)}: {e}")

    n_items = len(batchable_items)

    # Use integer ceiling division to avoid floating point errors
    n_batches = (n_items + max_batch_size - 1) // max_batch_size

    if n_batches > 0:
        logging.info(
            f"Dividing {n_items} items into {n_batches} batches "
            f"of ~{n_items // n_batches}"
        )
    else:
        logging.info("No items in list, so no batching will occur")

    for i in range(n_batches):
        i1 = (i * n_items + n_batches - 1) // n_batches
        i2 = min(((i + 1) * n_items + n_batches - 1) // n_batches, n_items)
        yield i, comprehender(batchable_items, i1, i2)  # pyright:ignore


def list_comprehender(x: list[T], i1: int, i2: int) -> list[T]:
    """
    Perform list comprehension to get a batch of items from a list.

    :param x: the list to extract a batch from
    :param i1: the lower index
    :param i2: the higher index
    :return: a batch from the list
    """

    return x[i1:i2]


def df_comprehender(x: pd.DataFrame, i1: int, i2: int) -> pd.DataFrame:
    """
    Perform list comprehension with `iloc` to get a batch of rows from a data frame.

    :param x: the data frame to extract a batch from
    :param i1: the lower index
    :param i2: the higher index
    :return: a batch from the data frame
    """

    return x.iloc[i1:i2, :]
