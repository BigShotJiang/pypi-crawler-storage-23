"""batch-evenly: A Python package for evenly distributing items into batches."""

__version__ = "0.1.0"

from .core import batch_evenly

__all__ = ["batch_evenly"]
