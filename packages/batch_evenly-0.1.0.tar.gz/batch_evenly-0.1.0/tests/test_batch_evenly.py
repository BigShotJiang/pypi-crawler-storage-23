from batch_evenly import batch_evenly


class TestBatchEvenly:
    def test_empty_list(self):
        """Test batching an empty list."""
        items = []
        batches = list(batch_evenly(items, max_batch_size=5))

        assert len(batches) == 0

    def test_single_item(self):
        """Test batching a single item."""
        items = [1]
        batches = list(batch_evenly(items, max_batch_size=5))

        assert len(batches) == 1

        batch_idx, batch = batches[0]
        assert batch == [1]

    def test_items_less_than_max_batch_size(self):
        """Test when number of items is less than max_batch_size."""
        items = [1, 2, 3]
        batches = list(batch_evenly(items, max_batch_size=5))

        assert len(batches) == 1

        batch_idx, batch = batches[0]
        assert batch == [1, 2, 3]

    def test_items_equal_to_max_batch_size(self):
        """Test when number of items equals max_batch_size."""
        items = [1, 2, 3, 4, 5]
        batches = list(batch_evenly(items, max_batch_size=5))

        assert len(batches) == 1

        batch_idx, batch = batches[0]
        assert batch == [1, 2, 3, 4, 5]

    def test_items_divide_evenly(self):
        """Test when items divide evenly into max_batch_size."""
        items = list(range(12))  # 12 items
        batches = list(batch_evenly(items, max_batch_size=4))

        # Should create 3 batches of size 4 each
        assert len(batches) == 3

        # Check all items are present and in order
        collected = []

        for batch_idx, batch in batches:
            collected.extend(batch)

        assert collected == items

        # Check batch sizes are all 4
        batch_sizes = [len(batch) for _, batch in batches]
        assert batch_sizes == [4, 4, 4]

    def test_example_case_10_items_max_4(self):
        """Test the example from the docstring: 10 items, max_batch_size=4.

        Should create batches of [4, 3, 3] rather than [4, 4, 2].
        """
        items = list(range(10))
        batches = list(batch_evenly(items, max_batch_size=4))

        # Should create 3 batches
        assert len(batches) == 3

        # Check all items are present and in order
        collected = []

        for batch_idx, batch in batches:
            collected.extend(batch)

        assert collected == items

        # Check batch sizes - should be approximately even
        batch_sizes = [len(batch) for _, batch in batches]

        # With 10 items and max_batch_size=4, we need 3 batches
        # 10/3 = 3.33, so we expect batches close to size 3-4
        assert batch_sizes == [4, 3, 3]

        # Verify batches are more even than [4, 4, 2]
        assert max(batch_sizes) - min(batch_sizes) <= 1

    def test_various_combinations(self):
        """Test various combinations of len(items) and max_batch_size."""
        test_cases = [
            # (n_items, max_batch_size, expected_n_batches)
            (7, 3, 3),  # 7/3 = 2.33 -> 3 batches of ~2-3 items
            (11, 5, 3),  # 11/5 = 2.2 -> 3 batches of ~3-4 items
            (20, 6, 4),  # 20/6 = 3.33 -> 4 batches of ~5 items
            (15, 4, 4),  # 15/4 = 3.75 -> 4 batches of ~3-4 items
            (100, 7, 15),  # 100/7 = 14.28 -> 15 batches of ~6-7 items
        ]

        for n_items, max_batch_size, expected_n_batches in test_cases:
            items = list(range(n_items))
            batches = list(batch_evenly(items, max_batch_size=max_batch_size))

            # Check correct number of batches
            assert len(batches) == expected_n_batches, (
                f"For {n_items} items with max_batch_size={max_batch_size}, "
                f"expected {expected_n_batches} batches but got {len(batches)}"
            )

            # Check all items are present and in order
            collected = []

            for batch_idx, batch in batches:
                collected.extend(batch)

            assert collected == items, (
                f"Items not preserved for {n_items} items with max_batch_size={max_batch_size}"
            )

            # Check batch sizes don't exceed max_batch_size
            batch_sizes = [len(batch) for _, batch in batches]

            assert all(size <= max_batch_size for size in batch_sizes), (
                f"Batch size exceeded max_batch_size for {n_items} items with "
                f"max_batch_size={max_batch_size}"
            )

            # Check batches are approximately even (differ by at most 1)
            assert max(batch_sizes) - min(batch_sizes) <= 1, (
                f"Batches not evenly sized for {n_items} items with "
                f"max_batch_size={max_batch_size}: {batch_sizes}"
            )

    def test_no_items_skipped_various_sizes(self):
        """Comprehensive test to ensure no items are skipped for many combinations."""
        for n_items in [1, 2, 5, 10, 13, 17, 23, 50, 99, 100, 101]:
            for max_batch_size in [1, 3, 7, 10, 15, 20]:
                items = list(range(n_items))
                batches = list(batch_evenly(items, max_batch_size=max_batch_size))

                # Collect all items from all batches
                collected = []

                for batch_idx, batch in batches:
                    collected.extend(batch)

                # Verify all items are present and in correct order
                assert collected == items, (
                    f"Items skipped or out of order for n_items={n_items}, "
                    f"max_batch_size={max_batch_size}"
                )

    def test_batch_indices_are_sequential(self):
        """Test that batch indices are sequential starting from 0."""
        items = list(range(20))
        batches = list(batch_evenly(items, max_batch_size=7))

        batch_indices = [idx for idx, _ in batches]
        expected_indices = list(range(len(batches)))
        assert batch_indices == expected_indices

    def test_max_batch_size_one(self):
        """Test edge case where max_batch_size is 1."""
        items = [1, 2, 3, 4, 5]
        batches = list(batch_evenly(items, max_batch_size=1))

        # Should create 5 batches of size 1 each
        assert len(batches) == 5

        # Each batch should have exactly 1 item
        for idx, (batch_idx, batch) in enumerate(batches):
            assert batch_idx == idx
            assert len(batch) == 1
            assert batch == [idx + 1]

    def test_large_max_batch_size(self):
        """Test when max_batch_size is larger than number of items."""
        items = [1, 2, 3]
        batches = list(batch_evenly(items, max_batch_size=100))

        # Should create just 1 batch with all items
        assert len(batches) == 1

        batch_idx, batch = batches[0]
        assert batch == [1, 2, 3]
