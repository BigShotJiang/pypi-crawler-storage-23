import asyncio
import pickle
import json
from arq import create_pool
from arq.connections import RedisSettings

async def check():
    settings = RedisSettings.from_dsn('rediss://:Gandu302redis@redis.arpansahu.space:9551')
    pool = await create_pool(settings)
    
    print('='*70)
    print('REDIS QUEUE ANALYSIS')
    print('='*70)
    
    # Check all tracking queues
    queues = ['arq:track:completed', 'arq:track:failed', 'arq:track:cancelled', 'arq:track:running', 'arq:queue']
    
    for queue_name in queues:
        count = await pool.zcard(queue_name)
        print(f'\n{queue_name}: {count} jobs')
        if count > 0:
            jobs = await pool.zrevrange(queue_name, 0, -1, withscores=True)
            for job_id, score in jobs[:10]:  # Show first 10
                job_id_str = job_id.decode() if isinstance(job_id, bytes) else job_id
                print(f'  - {job_id_str[:16]}... (score: {score})')
    
    # Check specific jobs
    print('\n' + '='*70)
    print('SPECIFIC JOB DETAILS')
    print('='*70)
    
    job_ids = ['70310c8bcf8c49598c4a5d30fd52977d', 'ttl_test_2', 'test_job_3']
    
    for job_id in job_ids:
        print(f'\n{job_id}:')
        
        # Check if in any queue
        for queue_name in queues:
            score = await pool.zscore(queue_name, job_id)
            if score is not None:
                print(f'  ✓ Found in {queue_name} (score: {score})')
        
        # Check keys
        result_exists = await pool.exists(f'arq:result:{job_id}')
        job_exists = await pool.exists(f'arq:job:{job_id}')
        cancelled_exists = await pool.exists(f'arq:cancelled:{job_id}')
        
        print(f'  arq:result:{job_id}: {"EXISTS" if result_exists else "NOT FOUND"}')
        print(f'  arq:job:{job_id}: {"EXISTS" if job_exists else "NOT FOUND"}')
        print(f'  arq:cancelled:{job_id}: {"EXISTS" if cancelled_exists else "NOT FOUND"}')
        
        # Get result if exists
        if result_exists:
            result_data = await pool.get(f'arq:result:{job_id}')
            try:
                result = pickle.loads(result_data)
                print(f'  Result type: {type(result)}')
                print(f'  Result: {result}')
            except Exception as e:
                print(f'  Result: (unparseable - {e})')
        
        # Get cancelled metadata if exists
        if cancelled_exists:
            cancelled_data = await pool.get(f'arq:cancelled:{job_id}')
            try:
                metadata = json.loads(cancelled_data)
                print(f'  Cancelled metadata: {metadata}')
            except Exception as e:
                print(f'  Cancelled metadata: (unparseable - {e})')
    
    await pool.aclose()

asyncio.run(check())
