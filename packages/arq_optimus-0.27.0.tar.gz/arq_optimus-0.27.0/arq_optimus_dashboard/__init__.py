"""
ARQ Optimus Dashboard - Auto-tracking initialization

When this package is imported, it automatically enables job tracking for ARQ workers.
NO USER CONFIGURATION NEEDED!

Just install: pip install arq-optimus-dashboard
Tracking works automatically for all ARQ tasks!

Users can disable tracking by setting:
    WorkerSettings.enable_arq_optimus_tracking = False
"""

import logging

logger = logging.getLogger('arq_optimus')

__version__ = '0.1.0'
__all__ = ['enable_auto_tracking']

_TRACKING_ENABLED = False


def enable_auto_tracking():
    """
    Enable automatic job tracking for all ARQ workers
    
    This patches ARQ to auto-wrap tasks with tracking when WorkerSettings is loaded.
    Called automatically when arq_optimus_dashboard is imported.
    
    Tracking can be disabled per-worker by setting:
        WorkerSettings.enable_arq_optimus_tracking = False
    """
    global _TRACKING_ENABLED
    
    if _TRACKING_ENABLED:
        return  # Already enabled
    
    try:
        # Import ARQ's Worker class
        from arq.worker import Worker
        from arq_optimus_dashboard.tracking import wrap_functions_with_tracking
        
        # Store original __init__
        _original_init = Worker.__init__
        
        # Create patched __init__
        def _patched_init(self, *args, **kwargs):
            """Patched Worker.__init__ that auto-applies tracking"""
            
            # Debug logging
            logger.info(f"🔍 Worker.__init__ called with {len(args)} args, kwargs keys: {list(kwargs.keys())}")
            
            # ARQ passes settings as first positional arg or kwargs
            # Try to get functions from either location
            functions_list = None
            enable_tracking = True
            
            if args:
                # Functions might be passed as first arg (list of functions)
                # Or all settings might be in kwargs unpacked from get_kwargs()
                first_arg = args[0]
                logger.info(f"🔍 First arg type: {type(first_arg)}")
                
                if isinstance(first_arg, list):
                    # Direct list of functions
                    functions_list = first_arg
                    enable_tracking = kwargs.get('enable_arq_optimus_tracking', True)
                elif hasattr(first_arg, 'functions'):
                    # WorkerSettings object/class
                    functions_list = getattr(first_arg, 'functions', [])
                    enable_tracking = getattr(first_arg, 'enable_arq_optimus_tracking', True)
            elif 'functions' in kwargs:
                # Functions passed as kwarg
                functions_list = kwargs['functions']
                enable_tracking = kwargs.get('enable_arq_optimus_tracking', True)
            
            logger.info(f"🔍 enable_tracking = {enable_tracking}, functions_list = {len(functions_list) if functions_list else 0} items")
            
            if enable_tracking and functions_list:
                # Auto-wrap functions with tracking
                try:
                    from arq_optimus_dashboard.tracking import create_tracking_wrapper
                    
                    wrapped_functions = []
                    wrapped_count = 0
                    
                    for func in functions_list:
                        if hasattr(func, '_arq_optimus_tracked'):
                            wrapped_functions.append(func)
                        else:
                            wrapped_func = create_tracking_wrapper(func)
                            wrapped_functions.append(wrapped_func)
                            wrapped_count += 1
                    
                    # Update functions in correct location
                    if args and isinstance(args[0], list):
                        args = (wrapped_functions,) + args[1:]
                    elif args and hasattr(args[0], 'functions'):
                        args[0].functions = wrapped_functions
                    elif 'functions' in kwargs:
                        kwargs['functions'] = wrapped_functions
                    
                    logger.info(f"🎯 ARQ Optimus auto-tracking enabled for {wrapped_count} tasks")
                    
                except Exception as e:
                    logger.exception(f"Failed to enable auto-tracking: {e}")
            elif not enable_tracking:
                logger.info("ARQ Optimus tracking explicitly disabled in WorkerSettings")
            else:
                logger.warning("🔍 Tracking not enabled: no functions found in args or kwargs")
            
            # Call original __init__
            return _original_init(self, *args, **kwargs)
        
        # Apply the monkey-patch
        Worker.__init__ = _patched_init
        
        _TRACKING_ENABLED = True
        logger.info("✅ ARQ Optimus auto-tracking middleware installed")
        logger.info("   Tasks will be tracked automatically when worker starts")
        
    except ImportError:
        logger.debug("ARQ not installed, tracking will be enabled when ARQ is available")
    except Exception as e:
        logger.warning(f"Failed to install auto-tracking middleware: {e}")


# Auto-enable tracking when package is imported
# NOTE: Auto-wrapping is now handled directly in user's arq_worker.py
# by checking if this package is installed and wrapping WorkerSettings.functions
# enable_auto_tracking()  # Disabled - done at module level instead
