"""
Command-line interface for ARQ Optimus Dashboard
"""
import argparse
import os
import sys
from .main import run_dashboard


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="ARQ Optimus Dashboard - Real-time monitoring for ARQ task queues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  arq-optimus-dashboard --redis-url redis://localhost:6379
  
  # With Redis Cloud (SSL)
  arq-optimus-dashboard --redis-url rediss://redis.example.com:6379
  
  # Custom host and port
  arq-optimus-dashboard --redis-url redis://localhost:6379 --host 127.0.0.1 --port 9000
  
  # With authentication
  arq-optimus-dashboard --redis-url redis://localhost:6379 --username admin --password secret
  
  # With key prefix (for multi-project Redis)
  arq-optimus-dashboard --redis-url redis://localhost:6379 --key-prefix myproject
        """
    )
    
    parser.add_argument(
        "--redis-url",
        required=True,
        help="Redis connection URL (e.g., redis://localhost:6379 or rediss:// for SSL)"
    )
    
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)"
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=8910,
        help="Port to bind to (default: 8910)"
    )
    
    parser.add_argument(
        "--username",
        help="Redis username (if authentication required)"
    )
    
    parser.add_argument(
        "--password",
        help="Redis password (if authentication required)"
    )
    
    parser.add_argument(
        "--key-prefix",
        default=os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''),
        help="Key prefix for Redis keys (e.g., 'myproject' → 'myproject:arq:queue'). "
             "Required when multiple projects share the same Redis instance. "
             "Falls back to ARQ_OPTIMUS_KEY_PREFIX env var if not specified."
    )
    
    args = parser.parse_args()
    
    try:
        run_dashboard(
            redis_url=args.redis_url,
            host=args.host,
            port=args.port,
            username=args.username,
            password=args.password,
            key_prefix=args.key_prefix
        )
    except KeyboardInterrupt:
        print("\n👋 Dashboard stopped")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error starting dashboard: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
