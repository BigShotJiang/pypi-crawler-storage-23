"""
API routes for ARQ job management
"""
from fastapi import APIRouter, HTTPException, Request
from typing import List, Dict, Any

router = APIRouter()


@router.get("/status")
async def get_status(request: Request) -> Dict[str, Any]:
    """Get queue status and statistics"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    return await arq_manager.get_queue_info()


@router.get("/jobs")
async def list_jobs(
    request: Request,
    status: str | None = None,
    limit: int = 100,
    offset: int = 0,
    minimal: bool = True
) -> List[Dict[str, Any]]:
    """List jobs with optional filtering - defaults to minimal data for speed"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    return await arq_manager.list_jobs(status=status, limit=limit, offset=offset, minimal=minimal)


@router.get("/jobs/count")
async def get_jobs_count(
    request: Request,
    status: str | None = None
) -> Dict[str, int | str]:
    """Get total job count for accurate pagination (fast, cached!)"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    try:
        stats = await arq_manager.get_queue_info()
        
        if status == "queued":
            total = stats["queued"]
        elif status == "running":
            total = stats["running"]
        elif status == "completed":
            total = stats["completed"]
        elif status == "failed":
            total = stats["failed"]
        else:
            total = stats["total"]
        
        return {"total": total, "status": status if status else "all"}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/jobs/{job_id}")
async def get_job(request: Request, job_id: str) -> Dict[str, Any]:
    """Get full details for a specific job (lazy loading)"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    job_info = await arq_manager.get_job_info(job_id)
    
    if not job_info:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    
    return job_info


@router.get("/jobs/{job_id}/details")
async def get_job_details(request: Request, job_id: str) -> Dict[str, Any]:
    """Get FULL job details including args, result (for modal/detail view)"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    # Get from cache if available
    cache_key = f'job_detail_{job_id}'
    cached = arq_manager.cache.get(cache_key)
    if cached:
        return cached
    
    job_info = await arq_manager.get_job_info(job_id)
    
    if not job_info:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    
    # Cache full details for 10 seconds
    arq_manager.cache.set(cache_key, job_info)
    
    return job_info


@router.post("/jobs/{job_id}/cancel")
async def cancel_job(request: Request, job_id: str) -> Dict[str, Any]:
    """Cancel a queued job using native Job.abort()"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    result = await arq_manager.cancel_job(job_id)
    
    # Invalidate cache on mutation
    arq_manager.cache.clear()
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return result


@router.delete("/jobs/{job_id}")
async def delete_job(request: Request, job_id: str) -> Dict[str, Any]:
    """Delete a completed/failed job"""
    arq_manager = request.app.state.arq_manager
    
    if not arq_manager:
        raise HTTPException(status_code=503, detail="ARQ manager not initialized")
    
    result = await arq_manager.delete_job(job_id)
    
    # Invalidate cache on mutation
    arq_manager.cache.clear()
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return result
