"""
ARQ Optimus Dashboard - FastAPI server for monitoring and managing ARQ jobs
"""
import argparse
import os
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path

from .core import ARQManager
from .api import router as api_router

# Get dashboard directory
DASHBOARD_DIR = Path(__file__).parent

app = FastAPI(
    title="ARQ Optimus Dashboard",
    description="Real-time monitoring and management for ARQ async task queues",
    version="1.0.0"
)

# Mount static files
app.mount("/static", StaticFiles(directory=str(DASHBOARD_DIR / "static")), name="static")

# Setup templates
templates = Jinja2Templates(directory=str(DASHBOARD_DIR / "templates"))

# Include API routes
app.include_router(api_router, prefix="/api")

# Store ARQ manager in app state
app.state.arq_manager = None


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main dashboard page"""
    return templates.TemplateResponse("dashboard.html", {"request": request})


@app.get("/health")
async def health():
    """Health check endpoint"""
    manager = app.state.arq_manager
    if manager:
        connected = await manager.check_connection()
        return {"status": "healthy" if connected else "degraded", "redis": connected}
    return {"status": "not_configured"}


def run_dashboard(
    redis_url: str,
    host: str = "0.0.0.0",
    port: int = 8910,
    username: str | None = None,
    password: str | None = None,
    key_prefix: str = ""
):
    """Run the dashboard server"""
    # Initialize ARQ manager and store in app state
    app.state.arq_manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
    
    prefix_msg = f" (prefix: '{key_prefix}')" if key_prefix else ""
    print(f"🚀 Starting ARQ Optimus Dashboard on http://{host}:{port}{prefix_msg}")
    print(f"📊 Monitoring Redis: {redis_url[:30]}...")
    
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="ARQ Optimus Dashboard")
    parser.add_argument(
        "--redis-url",
        type=str,
        default="redis://localhost:6379",
        help="Redis connection URL (e.g., rediss://user:pass@host:port)"
    )
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8910,
        help="Port to bind to"
    )
    parser.add_argument(
        "--key-prefix",
        type=str,
        default=os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''),
        help="Key prefix for Redis keys (e.g., 'myproject' → 'myproject:arq:queue'). "
             "Falls back to ARQ_OPTIMUS_KEY_PREFIX env var."
    )
    args = parser.parse_args()
    
    run_dashboard(redis_url=args.redis_url, host=args.host, port=args.port, key_prefix=args.key_prefix)
