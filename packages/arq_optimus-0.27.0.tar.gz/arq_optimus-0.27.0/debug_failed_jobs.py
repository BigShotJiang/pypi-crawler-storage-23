import asyncio
from arq import create_pool
from arq.connections import RedisSettings
from arq.jobs import Job

async def check():
    settings = RedisSettings.from_dsn('rediss://:Gandu302redis@redis.arpansahu.space:9551')
    pool = await create_pool(settings)
    
    failed_ids = ['ttl_test_2', 'test_job_3']
    
    for job_id in failed_ids:
        print(f'\n{"="*60}')
        print(f'Job: {job_id}')
        print("="*60)
        
        # Check if job data exists
        job_key_exists = await pool.exists(f'arq:job:{job_id}')
        result_key_exists = await pool.exists(f'arq:result:{job_id}')
        print(f'arq:job:{job_id} exists: {job_key_exists > 0}')
        print(f'arq:result:{job_id} exists: {result_key_exists > 0}')
        
        # Try to get job info
        try:
            job = Job(job_id, redis=pool)
            info = await job.info()
            if info:
                print(f'Job info available: YES')
                print(f'  Function: {info.function}')
                print(f'  Status: {info.job_status if hasattr(info, "job_status") else "N/A"}')
            else:
                print(f'Job info: None')
        except Exception as e:
            print(f'Error getting job info: {e}')
        
        # Check if it's in failed tracking
        score = await pool.zscore('arq:track:failed', job_id)
        print(f'In arq:track:failed: {score is not None} (score: {score})')
    
    await pool.aclose()

asyncio.run(check())
