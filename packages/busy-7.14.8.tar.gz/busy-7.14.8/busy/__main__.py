from . import BusyApp

if __name__ == '__main__':  # pragma: nocover
    BusyApp.main()
