from .function import upload_tiktok

__all__ = ['upload_tiktok']