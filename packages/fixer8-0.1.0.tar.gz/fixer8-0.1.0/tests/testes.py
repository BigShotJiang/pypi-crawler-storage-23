num = 1+2
