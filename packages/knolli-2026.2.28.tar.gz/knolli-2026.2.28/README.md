# Knolli — No-Code AI Workflow Builder & Copilot for Python

[![PyPI](https://img.shields.io/pypi/v/knolli.svg)](https://pypi.org/project/knolli/) [![Python](https://img.shields.io/pypi/pyversions/knolli.svg)](https://pypi.org/project/knolli/) [![license](https://img.shields.io/pypi/l/knolli.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

Knolli provides no-code workflow automation in Python. Build structured AI pipelines visually with our AI copilot workflow builder. Ditch the boilerplate and Python SDKs of n8n, Zapier, LangChain, and Temporal. Define, execute, and monitor complex workflows without writing code. Boost your productivity now.

## Features

- Design Python-based structured AI pipelines visually with a no-code workflow automation builder.
- Automate AI copilot workflows using a drag-and-drop interface.
- Orchestrate complex tasks with a user-friendly AI copilot workflow builder.
- Integrate diverse data sources and APIs into your no-code workflow automation.
- Monitor and manage structured AI pipelines with built-in observability tools.

## Use Cases

- Chain shell commands and AI tasks in a fluent workflow
- Run preset deployment and health-check workflows
- Build repeatable automation without boilerplate

## Installation

```bash
pip install knolli
```

## Quick Start

```python
from knolli import Knolli

client = Knolli.remote(api_key="cmdop_live_xxx")

results = (client.workflow()
    .shell("git pull")
    .shell("pip install -r requirements.txt")
    .agent("Summarize recent changes")
    .run())

print(results[2]["text"])
client.run_preset("health-check")
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [knolli on PyPI](https://pypi.org/project/knolli/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
