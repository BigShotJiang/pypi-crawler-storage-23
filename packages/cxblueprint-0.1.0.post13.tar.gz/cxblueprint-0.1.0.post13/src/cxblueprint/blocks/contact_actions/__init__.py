"""
Contact Actions - blocks that manipulate contact data.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions.html
"""

from .complete_outbound_call import CompleteOutboundCall
from .create_task import CreateTask
from .create_wisdom_session import CreateWisdomSession
from .dequeue_contact_and_transfer_to_queue import DequeueContactAndTransferToQueue
from .resume_contact import ResumeContact
from .start_outbound_chat_contact import StartOutboundChatContact
from .tag_contact import TagContact
from .transfer_contact_to_agent import TransferContactToAgent
from .transfer_contact_to_queue import TransferContactToQueue
from .untag_contact import UnTagContact
from .update_contact_attributes import UpdateContactAttributes
from .update_contact_callback_number import UpdateContactCallbackNumber
from .update_contact_data import UpdateContactData
from .update_contact_event_hooks import UpdateContactEventHooks
from .update_contact_media_processing import UpdateContactMediaProcessing
from .update_contact_media_streaming_behavior import UpdateContactMediaStreamingBehavior
from .update_contact_recording_and_analytics_behavior import UpdateContactRecordingAndAnalyticsBehavior
from .update_contact_recording_behavior import UpdateContactRecordingBehavior
from .update_contact_routing_behavior import UpdateContactRoutingBehavior
from .update_contact_target_queue import UpdateContactTargetQueue
from .update_contact_text_to_speech_voice import UpdateContactTextToSpeechVoice
from .update_previous_contact_participant_state import UpdatePreviousContactParticipantState

__all__ = [
    "CompleteOutboundCall",
    "CreateTask",
    "CreateWisdomSession",
    "DequeueContactAndTransferToQueue",
    "ResumeContact",
    "StartOutboundChatContact",
    "TagContact",
    "TransferContactToAgent",
    "TransferContactToQueue",
    "UnTagContact",
    "UpdateContactAttributes",
    "UpdateContactCallbackNumber",
    "UpdateContactData",
    "UpdateContactEventHooks",
    "UpdateContactMediaProcessing",
    "UpdateContactMediaStreamingBehavior",
    "UpdateContactRecordingAndAnalyticsBehavior",
    "UpdateContactRecordingBehavior",
    "UpdateContactRoutingBehavior",
    "UpdateContactTargetQueue",
    "UpdateContactTextToSpeechVoice",
    "UpdatePreviousContactParticipantState",
]
