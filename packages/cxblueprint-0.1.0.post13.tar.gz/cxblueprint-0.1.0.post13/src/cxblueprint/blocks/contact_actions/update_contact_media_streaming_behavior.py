"""
UpdateContactMediaStreamingBehavior - Configure media streaming.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatecontactmediastreamingbehavior.html
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class UpdateContactMediaStreamingBehavior(FlowBlock):
    """
    Enable or disable media streaming for contact participants.

    Errors:
        - NoMatchingError - Default error handler

    Restrictions:
        - Voice channel only
        - Supported in contact flows, customer queue flows, transfer flows, whisper flows
        - Not supported in hold flows
    """

    media_streaming_state: Optional[str] = None
    participants: Optional[List[Dict[str, Any]]] = None
    media_stream_type: Optional[str] = None

    def __post_init__(self):
        self.type = "UpdateContactMediaStreamingBehavior"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.media_streaming_state is not None:
            params["MediaStreamingState"] = self.media_streaming_state
        if self.participants is not None:
            params["Participants"] = self.participants
        if self.media_stream_type is not None:
            params["MediaStreamType"] = self.media_stream_type
        self.parameters = params

    def __repr__(self) -> str:
        if self.media_streaming_state:
            return f"UpdateContactMediaStreamingBehavior(state='{self.media_streaming_state}')"
        return "UpdateContactMediaStreamingBehavior()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateContactMediaStreamingBehavior":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            media_streaming_state=params.get("MediaStreamingState"),
            participants=params.get("Participants"),
            media_stream_type=params.get("MediaStreamType"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
