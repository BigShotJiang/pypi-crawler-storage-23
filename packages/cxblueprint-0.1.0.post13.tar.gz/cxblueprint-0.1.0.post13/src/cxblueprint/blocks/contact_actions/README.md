# Contact Actions

https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions.html

Actions that manipulate contact data within flows running in the context of a contact.

## Implementation Status

| Block | Status | Notes |
|-------|--------|-------|
| CompleteOutboundCall | Implemented | Full AWS schema |
| CreateCase | Implemented | Full AWS schema |
| CreateTask | Implemented | Full AWS schema |
| CreateWisdomSession | Implemented | Amazon Q integration |
| DequeueContactAndTransferToQueue | Implemented | Full AWS schema |
| EndFlowModuleExecution | Implemented | Full AWS schema |
| GetCase | Implemented | Full AWS schema |
| InvokeFlowModule | Implemented | Full AWS schema |
| ResumeContact | Implemented | Full AWS schema |
| StartOutboundChatContact | Implemented | Full AWS schema |
| TagContact | Implemented | Full AWS schema |
| TransferContactToAgent | Implemented | Full AWS schema |
| TransferContactToQueue | Implemented | Full AWS schema |
| UnTagContact | Implemented | Full AWS schema |
| UpdateCase | Implemented | Full AWS schema |
| UpdateContactAttributes | Implemented | Full AWS schema |
| UpdateContactCallbackNumber | Implemented | Full AWS schema |
| UpdateContactData | Implemented | Full AWS schema |
| UpdateContactEventHooks | Implemented | Full AWS schema |
| UpdateContactMediaProcessing | Implemented | Chat Lambda processor |
| UpdateContactMediaStreamingBehavior | Implemented | Full AWS schema |
| UpdateContactRecordingAndAnalyticsBehavior | Implemented | Recording + Contact Lens |
| UpdateContactRecordingBehavior | Implemented | Full AWS schema |
| UpdateContactRoutingBehavior | Implemented | Full AWS schema |
| UpdateContactTargetQueue | Implemented | Full AWS schema |
| UpdateContactTextToSpeechVoice | Implemented | Full AWS schema |
| UpdatePreviousContactParticipantState | Implemented | Full AWS schema |

## Implemented: 27/27 (100%)
