"""
CreateWisdomSession - Associate a Wisdom/Amazon Q domain to a contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-createwisdomsession.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class CreateWisdomSession(FlowBlock):
    """
    Associate a Wisdom (Amazon Q) domain to a contact to enable real-time
    recommendations during the contact.

    Parameters:
        - WisdomAssistantArn: ARN for the Wisdom Assistant. May be static or dynamic.

    Results:
        - No conditions supported

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Voice channel only
        - Can be used in all contact flow types
    """

    wisdom_assistant_arn: Optional[str] = None

    def __post_init__(self):
        self.type = "CreateWisdomSession"
        self._build_parameters()

    def _build_parameters(self):
        if self.wisdom_assistant_arn:
            self.parameters = {
                "WisdomAssistantArn": self.wisdom_assistant_arn
            }

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.wisdom_assistant_arn:
            return f"CreateWisdomSession(arn='{self.wisdom_assistant_arn}')"
        return "CreateWisdomSession()"

    @classmethod
    def from_dict(cls, data: dict) -> "CreateWisdomSession":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            wisdom_assistant_arn=params.get("WisdomAssistantArn"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
