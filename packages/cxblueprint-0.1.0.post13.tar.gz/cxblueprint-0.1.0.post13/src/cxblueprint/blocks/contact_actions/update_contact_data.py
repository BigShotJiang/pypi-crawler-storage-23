"""
UpdateContactData - Update contact data/attributes.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatecontactdata.html
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class UpdateContactData(FlowBlock):
    """
    Update contact data including name, description, language, customer ID, and Voice ID settings.

    Errors:
        - NoMatchingError - Default error handler

    Restrictions:
        - Supported on all channels and all flow types
        - All-or-nothing operation
    """

    name: Optional[str] = None
    description: Optional[str] = None
    language_code: Optional[str] = None
    customer_id: Optional[str] = None
    references: Optional[Dict[str, Any]] = None
    is_voice_id_streaming_enabled: Optional[str] = None
    is_voice_authentication_enabled: Optional[str] = None
    is_fraud_detection_enabled: Optional[str] = None
    voice_authentication_threshold: Optional[str] = None
    voice_authentication_response_time: Optional[str] = None
    fraud_detection_threshold: Optional[str] = None
    watchlist_id: Optional[str] = None
    wisdom_session_arn: Optional[str] = None
    target_contact: str = "Current"

    def __post_init__(self):
        self.type = "UpdateContactData"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.name is not None:
            params["Name"] = self.name
        if self.description is not None:
            params["Description"] = self.description
        if self.language_code is not None:
            params["LanguageCode"] = self.language_code
        if self.customer_id is not None:
            params["CustomerId"] = self.customer_id
        if self.references is not None:
            params["References"] = self.references
        if self.is_voice_id_streaming_enabled is not None:
            params["IsVoiceIdStreamingEnabled"] = self.is_voice_id_streaming_enabled
        if self.is_voice_authentication_enabled is not None:
            params["IsVoiceAuthenticationEnabled"] = self.is_voice_authentication_enabled
        if self.is_fraud_detection_enabled is not None:
            params["IsFraudDetectionEnabled"] = self.is_fraud_detection_enabled
        if self.voice_authentication_threshold is not None:
            params["VoiceAuthenticationThreshold"] = self.voice_authentication_threshold
        if self.voice_authentication_response_time is not None:
            params["VoiceAuthenticationResponseTime"] = self.voice_authentication_response_time
        if self.fraud_detection_threshold is not None:
            params["FraudDetectionThreshold"] = self.fraud_detection_threshold
        if self.watchlist_id is not None:
            params["WatchlistId"] = self.watchlist_id
        if self.wisdom_session_arn is not None:
            params["WisdomSessionArn"] = self.wisdom_session_arn
        params["TargetContact"] = self.target_contact
        self.parameters = params

    def __repr__(self) -> str:
        parts = []
        if self.name:
            parts.append(f"name='{self.name}'")
        if self.customer_id:
            parts.append(f"customer_id='{self.customer_id}'")
        parts.append(f"target='{self.target_contact}'")
        return f"UpdateContactData({', '.join(parts)})"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateContactData":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            name=params.get("Name"),
            description=params.get("Description"),
            language_code=params.get("LanguageCode"),
            customer_id=params.get("CustomerId"),
            references=params.get("References"),
            is_voice_id_streaming_enabled=params.get("IsVoiceIdStreamingEnabled"),
            is_voice_authentication_enabled=params.get("IsVoiceAuthenticationEnabled"),
            is_fraud_detection_enabled=params.get("IsFraudDetectionEnabled"),
            voice_authentication_threshold=params.get("VoiceAuthenticationThreshold"),
            voice_authentication_response_time=params.get("VoiceAuthenticationResponseTime"),
            fraud_detection_threshold=params.get("FraudDetectionThreshold"),
            watchlist_id=params.get("WatchlistId"),
            wisdom_session_arn=params.get("WisdomSessionArn"),
            target_contact=params.get("TargetContact", "Current"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
