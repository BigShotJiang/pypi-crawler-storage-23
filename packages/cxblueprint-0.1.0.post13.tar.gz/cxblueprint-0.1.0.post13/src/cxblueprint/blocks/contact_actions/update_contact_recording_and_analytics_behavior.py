"""
UpdateContactRecordingAndAnalyticsBehavior - Configure recording, analytics, and screen capture.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatecontactrecordingandanalyticsbehavior.html
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class UpdateContactRecordingAndAnalyticsBehavior(FlowBlock):
    """
    Configure recording behavior, Contact Lens analytics, and screen recording settings.

    Parameters:
        - VoiceBehavior: Object containing:
          - VoiceRecordingBehavior:
            - RecordedParticipants: List of "Agent" and/or "Customer"
          - IVRRecordingBehavior: "Enabled" or "Disabled"
          - VoiceAnalyticsBehavior:
            - Enabled: "True" or "False"
            - AnalyticsLanguage: Contact Lens supported language code
        - ChatBehavior: Chat recording configuration
        - TaskBehavior: Task recording configuration
        - EmailBehavior: Email recording configuration
        - ScreenRecordingBehavior:
          - ScreenRecordedParticipants: List containing "Agent"
        - SummaryConfiguration:
          - SummaryModes: List of "PostContact" and/or "AutomatedInteraction"
        - AnalyticsRedactionMaskMode: "PII" or "EntityType"
        - AnalyticsRedactionEntities: List of PII entity types to redact

    Results:
        - No conditions supported

    Errors:
        - ChannelMismatch - Media channel doesn't match defined action
        - InFlightRedactionConfigurationFailed - Chat redaction failed
        - NoMatchingError - No other error matches

    Restrictions:
        - All parameters must be set statically
        - Voice analytics requires both Agent and Customer in RecordedParticipants
    """

    voice_behavior: Optional[Dict[str, Any]] = None
    chat_behavior: Optional[Dict[str, Any]] = None
    task_behavior: Optional[Dict[str, Any]] = None
    email_behavior: Optional[Dict[str, Any]] = None
    screen_recording_behavior: Optional[Dict[str, Any]] = None
    summary_configuration: Optional[Dict[str, Any]] = None
    analytics_redaction_mask_mode: Optional[str] = None
    analytics_redaction_entities: Optional[list] = None

    def __post_init__(self):
        self.type = "UpdateContactRecordingAndAnalyticsBehavior"
        self._build_parameters()

    def _build_parameters(self):
        params = {}
        if self.voice_behavior:
            params["VoiceBehavior"] = self.voice_behavior
        if self.chat_behavior:
            params["ChatBehavior"] = self.chat_behavior
        if self.task_behavior:
            params["TaskBehavior"] = self.task_behavior
        if self.email_behavior:
            params["EmailBehavior"] = self.email_behavior
        if self.screen_recording_behavior:
            params["ScreenRecordingBehavior"] = self.screen_recording_behavior
        if self.summary_configuration:
            params["SummaryConfiguration"] = self.summary_configuration
        if self.analytics_redaction_mask_mode:
            params["AnalyticsRedactionMaskMode"] = self.analytics_redaction_mask_mode
        if self.analytics_redaction_entities:
            params["AnalyticsRedactionEntities"] = self.analytics_redaction_entities
        if params:
            self.parameters = params

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        parts = []
        if self.voice_behavior:
            parts.append("voice")
        if self.chat_behavior:
            parts.append("chat")
        if self.screen_recording_behavior:
            parts.append("screen")
        if parts:
            return f"UpdateContactRecordingAndAnalyticsBehavior({', '.join(parts)})"
        return "UpdateContactRecordingAndAnalyticsBehavior()"

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateContactRecordingAndAnalyticsBehavior":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            voice_behavior=params.get("VoiceBehavior"),
            chat_behavior=params.get("ChatBehavior"),
            task_behavior=params.get("TaskBehavior"),
            email_behavior=params.get("EmailBehavior"),
            screen_recording_behavior=params.get("ScreenRecordingBehavior"),
            summary_configuration=params.get("SummaryConfiguration"),
            analytics_redaction_mask_mode=params.get("AnalyticsRedactionMaskMode"),
            analytics_redaction_entities=params.get("AnalyticsRedactionEntities"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
