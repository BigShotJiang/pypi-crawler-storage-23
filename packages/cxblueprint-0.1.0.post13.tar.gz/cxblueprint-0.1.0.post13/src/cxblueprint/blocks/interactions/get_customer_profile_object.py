"""
GetCustomerProfileObject - Retrieve a specific profile object by type.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-getcustomerprofileobject.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class GetCustomerProfileObject(FlowBlock):
    """
    Retrieve a customer profile object of the desired type, based on recency
    or any search identifier.

    Parameters:
        - ProfileId: The profile ID (required, use Get profile block first)
        - ObjectType: The type of profile object to retrieve

    Results:
        - Response attributes available under $.Customer path
        - Based on attributes included in ProfileResponseData

    Errors:
        - NoneFoundError - No profiles found for the search key
        - NoMatchingError - No other error matches

    Restrictions:
        - Customer Profiles must be enabled
        - ProfileId must be provided (use GetCustomerProfile first)
        - Total Customer Profiles attributes limited to 14,000 characters per flow
    """

    profile_id: Optional[str] = None
    object_type: Optional[str] = None

    def __post_init__(self):
        self.type = "GetCustomerProfileObject"
        self._build_parameters()

    def _build_parameters(self):
        params = {}
        if self.profile_id:
            params["ProfileId"] = self.profile_id
        if self.object_type:
            params["ObjectType"] = self.object_type
        if params:
            self.parameters = params

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.object_type:
            return f"GetCustomerProfileObject(type='{self.object_type}')"
        return "GetCustomerProfileObject()"

    @classmethod
    def from_dict(cls, data: dict) -> "GetCustomerProfileObject":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            profile_id=params.get("ProfileId"),
            object_type=params.get("ObjectType"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
