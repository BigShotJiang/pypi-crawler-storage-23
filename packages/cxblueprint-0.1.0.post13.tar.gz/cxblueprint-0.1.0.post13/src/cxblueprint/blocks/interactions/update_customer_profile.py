"""
UpdateCustomerProfile - Update a customer profile.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-updatecustomerprofile.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class UpdateCustomerProfile(FlowBlock):
    """
    Update a customer profile that was previously created or retrieved in the flow.
    Customer Profiles must be enabled for your Amazon Connect instance.

    Results:
        - No conditions supported
        - Response attributes are available dynamically under $.Customer path
        - Profile ID is persisted under $.Customer.ProfileId

    Errors:
        - NoMatchingError - if no other error matches

    Restrictions:
        - Customer Profiles must be enabled for your Amazon Connect instance
    """

    def __post_init__(self):
        self.type = "UpdateCustomerProfile"

    def __repr__(self) -> str:
        return "UpdateCustomerProfile()"

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateCustomerProfile":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
