"""
Interactions - blocks with side effects that don't require a contact/participant.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions.html
"""

from .associate_contact_to_customer_profile import AssociateContactToCustomerProfile
from .create_callback_contact import CreateCallbackContact
from .create_customer_profile import CreateCustomerProfile
from .get_calculated_attributes_for_customer_profile import GetCalculatedAttributesForCustomerProfile
from .get_customer_profile import GetCustomerProfile
from .get_customer_profile_object import GetCustomerProfileObject
from .invoke_lambda_function import InvokeLambdaFunction
from .update_customer_profile import UpdateCustomerProfile

__all__ = [
    "AssociateContactToCustomerProfile",
    "CreateCallbackContact",
    "CreateCustomerProfile",
    "GetCalculatedAttributesForCustomerProfile",
    "GetCustomerProfile",
    "GetCustomerProfileObject",
    "InvokeLambdaFunction",
    "UpdateCustomerProfile",
]
