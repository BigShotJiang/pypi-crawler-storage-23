# Interactions

https://docs.aws.amazon.com/connect/latest/APIReference/interactions.html

Actions with side effects that don't require a contact or participant. Generally work in every circumstance.

## Implementation Status

| Block | Status | Notes |
|-------|--------|-------|
| AssociateContactToCustomerProfile | Implemented | Full AWS schema |
| CreateCallbackContact | Implemented | Full AWS schema |
| CreateCustomerProfile | Implemented | Full AWS schema |
| GetCalculatedAttributesForCustomerProfile | Implemented | Computed attributes |
| GetCustomerProfile | Implemented | Full AWS schema |
| GetCustomerProfileObject | Implemented | Profile object retrieval |
| InvokeLambdaFunction | Implemented | Full AWS schema |
| UpdateCustomerProfile | Implemented | Full AWS schema |

## Implemented: 8/8 (100%)
