"""
GetCustomerProfile - Retrieve a customer profile based on search identifiers.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-getcustomerprofile.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class GetCustomerProfile(FlowBlock):
    """
    Retrieve a customer profile based on any search identifier, up to five total.
    Customer Profiles must be enabled for your Amazon Connect instance.

    Results:
        - No conditions supported
        - If successful, response attributes are available dynamically under $.Customer path
        - Profile ID is persisted under $.Customer.ProfileId

    Errors:
        - MultipleFoundError - Multiple profiles found for the search key
        - NoneFoundError - No profiles found for the search key
        - NoMatchingError - No other error matches

    Restrictions:
        - Customer Profiles must be enabled for your Amazon Connect instance
        - At least one search identifier must be provided
    """

    def __post_init__(self):
        self.type = "GetCustomerProfile"

    def __repr__(self) -> str:
        return "GetCustomerProfile()"

    @classmethod
    def from_dict(cls, data: dict) -> "GetCustomerProfile":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
