"""
CheckOutboundCallStatus - Check the status of an outbound call for campaign flows.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-checkoutboundcallstatus.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class CheckOutboundCallStatus(FlowBlock):
    """
    Check the status of an outbound call and route based on answering machine detection.
    Used with Amazon Connect outbound campaigns only.

    Results:
        - CallAnswered - Person answered the call
        - VoicemailBeep - Voicemail with beep detected
        - VoicemailNoBeep - Voicemail without beep detected

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Only available in CAMPAIGN flow type
        - Parameters is an empty object
    """

    def __post_init__(self):
        self.type = "CheckOutboundCallStatus"
        if not self.parameters:
            self.parameters = {}

    def __repr__(self) -> str:
        return "CheckOutboundCallStatus()"

    @classmethod
    def from_dict(cls, data: dict) -> "CheckOutboundCallStatus":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
