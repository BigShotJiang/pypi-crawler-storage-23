"""
UpdateFlowAttributes - Set flow-scoped temporary attributes.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-updateflowattributes.html
"""

from dataclasses import dataclass
from typing import Optional, Dict
import uuid
from ..base import FlowBlock


@dataclass
class UpdateFlowAttributes(FlowBlock):
    """
    Set flow-scoped attributes that are only available within the current flow.
    Flow attributes are not persisted to the contact record and are not visible
    outside the flow, even when transferred to another flow.

    Parameters:
        - FlowAttributes: Dict of key-value pairs to set as flow attributes

    Results:
        - No conditions supported

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Flow attributes are not passed to Lambda unless explicitly configured
        - Flow attributes are not passed to modules
        - Flow attributes don't appear in contact record or CCP
        - Maximum 32 KB total size for flow attributes
    """

    flow_attributes: Optional[Dict[str, str]] = None

    def __post_init__(self):
        self.type = "UpdateFlowAttributes"
        self._build_parameters()

    def _build_parameters(self):
        if self.flow_attributes:
            self.parameters = {
                "FlowAttributes": self.flow_attributes
            }

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.flow_attributes:
            return f"UpdateFlowAttributes(attributes={list(self.flow_attributes.keys())})"
        return "UpdateFlowAttributes()"

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateFlowAttributes":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            flow_attributes=params.get("FlowAttributes"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
