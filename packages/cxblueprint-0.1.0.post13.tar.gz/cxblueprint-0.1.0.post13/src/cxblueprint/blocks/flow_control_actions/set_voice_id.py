"""
SetVoiceId - Set Voice ID authentication settings.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-setvoiceid.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class SetVoiceId(FlowBlock):
    """
    Set Voice ID authentication settings for the contact.

    Errors:
        - NoMatchingError - if no other error matches

    Restrictions:
        - Voice channel only
        - Not supported on Chat or Task channels
    """

    def __post_init__(self):
        self.type = "SetVoiceId"

    def __repr__(self) -> str:
        return "SetVoiceId()"

    @classmethod
    def from_dict(cls, data: dict) -> "SetVoiceId":
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=data.get("Parameters", {}),
            transitions=data.get("Transitions", {}),
        )
