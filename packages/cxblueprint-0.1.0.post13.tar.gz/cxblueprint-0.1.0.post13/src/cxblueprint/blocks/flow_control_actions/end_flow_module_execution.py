"""
EndFlowModuleExecution - Return from a flow module to the calling flow.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-endflowmoduleexecution.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class EndFlowModuleExecution(FlowBlock):
    """
    End flow module execution and return to the calling flow.

    Results:
        None.

    Errors:
        None.

    Restrictions:
        - Can only be used in flow modules
        - Returns control to the calling flow at the point after InvokeFlowModule
    """

    def __post_init__(self):
        self.type = "EndFlowModuleExecution"

    def __repr__(self) -> str:
        return "EndFlowModuleExecution()"

    @classmethod
    def from_dict(cls, data: dict) -> "EndFlowModuleExecution":
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=data.get("Parameters", {}),
            transitions=data.get("Transitions", {}),
        )
