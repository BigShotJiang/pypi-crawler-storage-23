"""
CreateCase - Create a case in Amazon Connect Cases.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-createcase.html
"""

from dataclasses import dataclass
from typing import Optional, Dict
import uuid
from ..base import FlowBlock
from ..serialization import to_aws_bool


@dataclass
class CreateCase(FlowBlock):
    """
    Create a case in Amazon Connect Cases.

    Results:
        None.

    Errors:
        - ContactNotLinked - Contact failed to link after case creation
        - NoMatchingError - Error creating or finding the case

    Restrictions:
        None (all channels, all flow types)
    """

    link_contact_to_case: bool = False
    case_template_id: Optional[str] = None
    case_request_fields: Optional[Dict[str, str]] = None

    def __post_init__(self):
        self.type = "CreateCase"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        params["LinkContactToCase"] = to_aws_bool(self.link_contact_to_case)
        if self.case_template_id is not None:
            params["CaseTemplateId"] = self.case_template_id
        if self.case_request_fields is not None:
            params["CaseRequestFields"] = self.case_request_fields
        self.parameters = params

    def __repr__(self) -> str:
        return f"CreateCase(template_id='{self.case_template_id}')"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "CreateCase":
        params = data.get("Parameters", {})
        link = params.get("LinkContactToCase", "False")
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            link_contact_to_case=(link == "True"),
            case_template_id=params.get("CaseTemplateId"),
            case_request_fields=params.get("CaseRequestFields"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
