# Flow Control Actions

https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions.html

Actions that control flow behavior by enabling/disabling features or choosing branches. No side effects, no contact/participant required.

## Implementation Status

| Block | Status | Notes |
|-------|--------|-------|
| CheckHoursOfOperation | Implemented | Full AWS schema |
| CheckMetricData | Implemented | Full AWS schema |
| CheckOutboundCallStatus | Implemented | Campaign flows only |
| CheckVoiceId | Implemented | Full AWS schema |
| Compare | Implemented | Full AWS schema |
| DistributeByPercentage | Implemented | Full AWS schema |
| EndFlowExecution | Implemented | Full AWS schema |
| GetMetricData | Implemented | Queue metrics retrieval |
| Loop | Implemented | Full AWS schema |
| SetVoiceId | Implemented | Full AWS schema |
| StartVoiceIdStream | Implemented | Voice ID streaming |
| TransferToFlow | Implemented | Full AWS schema |
| UpdateFlowAttributes | Implemented | Flow-scoped variables |
| UpdateFlowLoggingBehavior | Implemented | Full AWS schema |
| UpdateRoutingCriteria | Implemented | Routing steps config |
| Wait | Implemented | Full AWS schema |

## Implemented: 16/16 (100%)
