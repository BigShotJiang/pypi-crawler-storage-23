
## Commands

```bash
cd full_example
python flow_generator.py
cd terraform
terraform init
terraform apply  # Type 'yes' when prompted
```

# Next steps
Open up your connect instance and checkout the counter_flow

