"""Tests for AWS Connect parameter serialization helpers."""

from cxblueprint.blocks.serialization import (
    to_aws_bool,
    from_aws_bool,
    to_aws_int,
    from_aws_int,
    serialize_optional,
    build_parameters,
)


class TestToAwsBool:
    def test_true(self):
        assert to_aws_bool(True) == "True"

    def test_false(self):
        assert to_aws_bool(False) == "False"


class TestFromAwsBool:
    def test_true_string(self):
        assert from_aws_bool("True") is True

    def test_false_string(self):
        assert from_aws_bool("False") is False

    def test_empty_returns_default_false(self):
        assert from_aws_bool("") is False

    def test_empty_returns_custom_default(self):
        assert from_aws_bool("", default=True) is True

    def test_none_returns_default(self):
        assert from_aws_bool(None) is False


class TestToAwsInt:
    def test_positive(self):
        assert to_aws_int(5) == "5"

    def test_zero(self):
        assert to_aws_int(0) == "0"

    def test_large(self):
        assert to_aws_int(900) == "900"


class TestFromAwsInt:
    def test_valid_string(self):
        assert from_aws_int("5") == 5

    def test_empty_returns_default(self):
        assert from_aws_int("") == 0

    def test_empty_returns_custom_default(self):
        assert from_aws_int("", default=10) == 10

    def test_invalid_returns_default(self):
        assert from_aws_int("abc") == 0

    def test_none_returns_default(self):
        assert from_aws_int(None) == 0


class TestSerializeOptional:
    def test_with_value(self):
        assert serialize_optional("Name", "test") == {"Name": "test"}

    def test_none_returns_empty(self):
        assert serialize_optional("Name", None) == {}

    def test_with_converter(self):
        assert serialize_optional("Timeout", 5, to_aws_int) == {"Timeout": "5"}

    def test_with_bool_converter(self):
        assert serialize_optional("Enabled", True, to_aws_bool) == {"Enabled": "True"}

    def test_int_value_without_converter(self):
        assert serialize_optional("Count", 42) == {"Count": "42"}


class TestBuildParameters:
    def test_filters_none(self):
        result = build_parameters(Text="Hello", Timeout=5, Missing=None)
        assert result == {"Text": "Hello", "Timeout": "5"}

    def test_empty(self):
        assert build_parameters() == {}

    def test_all_none(self):
        assert build_parameters(A=None, B=None) == {}

    def test_converts_to_strings(self):
        result = build_parameters(Int=42, Bool=True)
        assert result == {"Int": "42", "Bool": "True"}
