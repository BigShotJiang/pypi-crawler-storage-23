"""
This subpackage manages source code.
"""

from __future__ import annotations

from moat.lib.config import register as _register

_register(__name__)
