import os
import sys

_TESTS_DIR = os.path.dirname(__file__)
_SRC_DIR = os.path.abspath(os.path.join(_TESTS_DIR, "..", "src"))
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

import mapmatcher4gmns as m4g

def main():
    data_root = os.path.join(_TESTS_DIR, "Maricopa")
    net = m4g.LoadNetFromCSV(folder=os.path.join(data_root, "network"), node_file="node.csv", link_file="link.csv")
    
    gps_csv = os.path.join(data_root, "data", "waypoint_08_04.csv")
    # gps_csv = "/Users/leo/ASU Dropbox/Yajun Liu/Documents/Projects/Phoenix_mapmatching/Maricopa/data/waypoint_04_21_2025.csv"

    matcher = m4g.MapMatcher(
        network=net,
        time_field='local_time',
        time_format='%Y-%m-%dT%H:%M:%S%z',
        extra_fields=['capture_time'],
        out_dir=os.path.join(data_root, "result"),
        result_file="matched_result.csv",
        route_file="matched_route.csv",
        core_num=4
    )

    matcher.match(gps_csv)

if __name__ == '__main__':
    main()
