from .anam import AnamAvatar

__all__ = ["AnamAvatar"]
