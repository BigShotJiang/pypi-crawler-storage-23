# VideoSDK Anam

This plugin integrates Anam's Virtual AI Avatar with VideoSDK Agents framework.

## Requirements

- Python 3.12+


## Installation

```bash
pip install videosdk-plugins-anam
```
