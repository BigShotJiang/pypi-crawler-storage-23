# CHANGELOG

<!-- version list -->

## v1.13.0 (2026-03-04)

### Bug Fixes

- Exclude blocked sections from auto-advance, guard duplicate ACs
  ([#312](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/312),
  [`f759d09`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

### Chores

- Update lockfile version to 1.12.0
  ([#312](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/312),
  [`f759d09`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

### Documentation

- Mark ticket sync §3 (real-time reverse sync) as done
  ([#312](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/312),
  [`f759d09`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

- Snapshot v1.12 docs
  ([`73b7ae0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/73b7ae0860e3491a41a072aa81308855980bcfc3))

- Update specs based on #298 ([#299](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/299),
  [`77d81e5`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/77d81e50232b369d4f546ac2201f2b4bff11d7bc))

### Features

- Auto-advance section status to done on PR merge
  ([#312](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/312),
  [`f759d09`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

- Auto-advance spec section status on PR merge
  ([#312](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/312),
  [`f759d09`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))


## v1.12.0 (2026-03-04)

### Bug Fixes

- Address final PR review round
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address final review — logging, test coverage, race comment
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address PR review feedback ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address second PR review round
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Unify preview workflow trigger and fix comment formatting
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Code Style

- Ruff format client.py debug log line
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Continuous Integration

- Lint Helm chart with preview values in CI
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Re-trigger CI workflow ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Documentation

- Add preview deployments implementation plan
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Mark PR comment & preview spec as done
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Preview deployment design and spec status updates
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Snapshot v1.11 docs
  ([`79a2b9f`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/79a2b9f9e9e1d1b5b900d900c98d27f8d0c583f0))

### Features

- Add Helm values override for preview deployments
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Add PLATFORM_URL to Helm configmap for preview links
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Add preview deployment workflow for PR UI changes
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Preview deployments for Spec Explorer
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Surface preview deployment URL in Specwright bot comment
  ([#298](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/298),
  [`f23023b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))


## v1.11.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback for webhook reverse sync
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 2 — error handling, security, code quality
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 3 — Linear type filter, public API, clarity
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 4 — Linear ID, HMAC case, error codes
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Base64-encode embedded analysis JSON to prevent HTML comment leak
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Structured error classification and webhook hardening
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Webhook response classification, error leaking, and logging
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Chores

- Update uv.lock for v1.10.1 ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Code Style

- Run ruff format on 5 files ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Documentation

- Snapshot v1.10 docs
  ([`ced354c`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ced354c9933621c2ae37164726909bde8c001e10))

### Features

- Real-time reverse sync via webhooks
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Real-time reverse sync via webhooks for all ticket systems
  ([#295](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/295),
  [`1e41eae`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1e41eaef36064c60ecca50f394771d023c0a1614))


## v1.10.1 (2026-03-04)

### Bug Fixes

- **ci**: Make uv install conditional on release in publish workflow
  ([`af78920`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af78920a976845f22b4100d94e990db665106832))

### Chores

- Add spec-view-redesign spec and gitignore frontend build artifacts
  ([`cf9e3c7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/cf9e3c71d0087a7f56618d33dbb5fc436382cb6c))

- Repo level settings
  ([`5530e88`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/5530e888f92e8abc802aac199b31b1a1305ae1de))

### Documentation

- Snapshot v1.10 docs
  ([`02367b9`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/02367b9b2bc4a4cd02abca877f1d49ec3a1185ba))

- Update specs based on #296 ([#297](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/297),
  [`5a31eb4`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/5a31eb47f27f24d91c09a12db681ebdf59661079))


## v1.10.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback across spec view components
  ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Chores

- Update uv.lock after merge ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Documentation

- Check off verified ACs across 6 specs (11% → 58% coverage)
  ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

- Snapshot v1.9 docs
  ([`56e7371`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/56e7371f3b80f7719ad986310308baa4fffe754e))

### Features

- Status-aware progress indicator for spec list views
  ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

- Structured spec detail view with collapsible section cards
  ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Refactoring

- Replace getStatusState() with sectionStatus computed
  ([#296](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/296),
  [`af5a518`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))


## v1.9.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback — deep merge bug, system detection, CLI config
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- GitHub reverse sync bug, auto-parent warning, review nits
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Recursive flatten, org config cache, dead code removal
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Reduce auto-parent warning noise, note 404 detection debt
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Chores

- Update uv.lock to match 1.7.0
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Code Style

- Apply ruff format ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Documentation

- Update specs based on #291 ([#294](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/294),
  [`8da29bb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/8da29bbd24b15c2e6fc9b5d28fb170da298df2d3))

- Update specs based on #292 ([#293](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/293),
  [`1fe6f1e`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1fe6f1ec64713c65acb112076033a5d881febd06))

### Features

- Add issue type labels and title prefix for hierarchy visibility
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Wire ticket mapping config into sync engine
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Wire ticket mapping config into sync engine (§2-§8)
  ([#291](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/291),
  [`fa502e0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))


## v1.8.0 (2026-03-04)

### Bug Fixes

- Add uv/python to docs CI and commit lockfile
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Resolve ruff lint errors in gen scripts
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Skip gen-refs prebuild when uv is not available
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

### Code Style

- Format gen scripts with ruff
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Ruff format 6 pre-existing unformatted files
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

### Documentation

- Add cross-links to concept pages and verify content migration
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Check off verified ACs across 6 specs (11% → 58% coverage)
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Update spec statuses based on codebase audit
  ([`dc889c3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/dc889c39544426e689bfac5df6a25877f2c70a02))

### Features

- Auto-generate CLI, MCP, and API reference docs at build time
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Auto-generate reference docs + concept cross-links
  ([#292](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/292),
  [`a74e301`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Configurable spec paths, sitemap/SEO, and versioned docs (§2, §11, §10)
  ([`ea685a8`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ea685a8b1552ed552add76cda93a42f434d9bd12))


## v1.7.0 (2026-03-04)

### Bug Fixes

- Apply AC updates even when section status is unchanged
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Chores

- Update uv.lock to match 1.6.0
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Code Style

- Ruff format ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Documentation

- Fix ticket links and set ticket_project on all specs
  ([`b923d39`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b923d3952a9a80af41ee5a77a9800e59a038851a))

- Update spec statuses based on codebase audit
  ([`e85eff1`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/e85eff152ce50c3e571f98dbff1633c8f6cead20))

### Features

- Audit checks off realized ACs and inserts evidence
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

- Audit checks off realized ACs and inserts evidence comments
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))


## v1.6.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Chores

- Regenerate uv.lock for v1.5.0
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Code Style

- Ruff format ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Documentation

- Update specs based on #269 ([#270](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/270),
  [`6e9e414`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/6e9e414c8641eb3a6fead2e540f1cc9da405b943))

### Features

- Add production hardening for web app
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

- Production hardening for web app
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))


## v1.5.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback on audit command
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Address second round of PR review feedback
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Chores

- Update uv.lock to match current version
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Documentation

- Add ticket links from specwright sync
  ([`925d4f9`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/925d4f9cb848c35c1dd9894f683b88fbf44c7731))

- Mark Background sections as done, fix parent section statuses
  ([`b284ff5`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b284ff5c889687115cf6846d2b95dc9ac7e71ad3))

- Update spec statuses based on codebase implementation audit
  ([`ff42ab2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ff42ab28687ce2c9866754bac9d773defa8395fb))

### Features

- Add /sw-audit skill for full spec audit workflow
  ([`60c4e72`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/60c4e726c38bb3a9a4b532694016e4fdfc4ec178))

- Add `specwright audit` CLI command for Claude-powered spec status auditing
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Add specwright audit CLI command
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))


## v1.4.5 (2026-03-04)

### Bug Fixes

- **auth**: Decouple auth0_orgs_enabled from auth0_audience
  ([`5a7887b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/5a7887bdb4d668ca408a57cfe85bee4d23db0c61))

- **lint**: Remove unused SyncResult import in test_engine
  ([`7c70fbb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7c70fbb7d19a2f3ba922743a59ba9951dafeb10b))

- **sync**: Only create tickets for todo/in_progress sections
  ([`449a202`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/449a2020caeee102c32d0e08cf330444b2548dc1))

### Chores

- Remove temporary debug-org endpoint
  ([`a6e1bd6`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a6e1bd65e0437df201c400e8a36c9d6d474e3a27))

### Code Style

- Fix ruff formatting in test_engine.py
  ([`47059c9`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/47059c97de8e8fcac84890becc03089fabc1410e))

### Documentation

- Fix configuration reference to match actual parser
  ([`7ebe983`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7ebe983bf6ee915c46e4c920852cbb1ce76d6442))

- Update docs for server-proxied sync, device auth, and AUTH0_AUDIENCE
  ([`23e0957`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/23e0957b9686325e15e27cfdbb2251b64a765fce))


## v1.4.4 (2026-03-04)

### Bug Fixes

- **auth**: Resolve org for device auth JWTs without org_id claim
  ([`2b8b8e4`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/2b8b8e4af8e9337d055d660b6535e8249c7d47fe))


## v1.4.3 (2026-03-04)

### Bug Fixes

- **deploy**: Include AUTH0_AUDIENCE in K8s secret
  ([`22cd8c0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/22cd8c0e6d0d44d850a4ed03332950e8d06942c1))


## v1.4.2 (2026-03-04)

### Bug Fixes

- **auth**: Fail fast on missing AUTH0_AUDIENCE and use correct status codes
  ([`0400cc6`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/0400cc65cc73515d2f68381e7c3d733508832f92))


## v1.4.1 (2026-03-04)

### Bug Fixes

- **ci**: Fail if uv.lock is out of sync with pyproject.toml
  ([`b798442`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b798442c30253cf517659b6e92aeab7b213e7200))

### Chores

- Sync uv.lock with pyproject.toml v1.3.0
  ([`c4fde9c`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/c4fde9cf35ea79dd7f8dfbe007ce6634d90f1aa3))


## v1.4.0 (2026-03-04)

### Bug Fixes

- Address PR security feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- Address round 2 PR review feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- **ci**: Prevent duplicate claude review comments
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Code Style

- Format test_ticket_routes.py
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Documentation

- Update specs based on #118 ([#120](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/120),
  [`2abefec`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/2abefec28cd029636da9f4e22078d5e16d79e492))

### Features

- Server-proxied ticket sync via GitHub App tokens
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))


## v1.3.0 (2026-03-01)

### Bug Fixes

- Ruff format on integration conftest
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address PR review — permissions, marker conflict, coverage paths
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address round 2 review feedback
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Format integration tests and fix set -e in combine step
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

### Documentation

- Update specs based on #117 ([#119](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/119),
  [`b7a6def`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b7a6defc6c30dbe7095fc27d0902a9ba6aa2410c))

### Features

- **ci**: Add coverage reporting for unit and integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Coverage reporting for unit & integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))


## v1.2.0 (2026-03-01)

### Bug Fixes

- Default platform_url to empty, use module-level Settings, drop redundant path
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

- URL-encode spec paths and add links to reanalyze handler
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Chores

- Lock updates
  ([`566ee0a`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/566ee0aa09fbbf9d62a67fa0a204541000003be9))

### Code Style

- Fix ruff formatting ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Documentation

- Update specs based on #112 ([#114](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/114),
  [`a47ece3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a47ece3fc43189a0b043018237d53bd8dd2b9f52))

### Features

- Add Specwright web app links to PR comments
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))


## v1.1.0 (2026-02-28)

### Documentation

- Update install commands to use gv-specwright package name
  ([`8536e8b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/8536e8bdd3261f6cf2a68ed4be41d2ce92008064))

### Features

- **docs-site**: Logo links to main site + gradient wordmark
  ([`7e55c6b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7e55c6ba18aee0b5569382afcc14793850cf4b13))


## v1.0.3 (2026-02-28)

### Bug Fixes

- Add AUTH0_DEVICE_CLIENT_ID to deploy K8s secret
  ([#116](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/116),
  [`fc8b3a8`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fc8b3a8c21b14a4e9e0cfa21d1942c826976a7c7))


## v1.0.2 (2026-02-28)

### Bug Fixes

- Rename PyPI package to gv-specwright (specwright was taken)
  ([`44e3af3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/44e3af3397bb8c4deba4da6f4a11edf89edf3433))


## v1.0.1 (2026-02-28)

### Bug Fixes

- Use version tag for pypi-publish action (Docker-based, SHA pinning unsupported)
  ([`b48f730`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b48f730f7f8d066135010f9ff72b8cb1e55e3df9))


## v1.0.0 (2026-02-28)

- Initial Release
