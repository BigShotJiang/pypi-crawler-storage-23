# Preview Deployments Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Enable ephemeral preview deployments for the Spec Explorer web UI on PRs that modify frontend/template files, and surface the preview URL in the Specwright bot comment.

**Architecture:** GitHub Actions workflow builds a Docker image per PR, deploys to an ephemeral K8s namespace on the existing DOKS cluster using the Helm chart with a preview values override, and cleans up on PR close. The PR handler queries for active preview deployments and passes the URL to the bot comment formatter.

**Tech Stack:** GitHub Actions, Docker, Helm, kubectl, DigitalOcean K8s (DOKS), Doppler (secrets), GitHub Deployments API

---

### Task 1: Create Helm Preview Values Override

**Files:**
- Create: `chart/specwright/values-preview.yaml`

**Step 1: Create the values file**

```yaml
## Preview deployment overrides — ephemeral per-PR namespace
## Usage: helm upgrade --install specwright-pr-N chart/specwright/ \
##   -f chart/specwright/values-production.yaml \
##   -f chart/specwright/values-preview.yaml \
##   --set ingress.hostname=pr-N.specwright.gernerventures.com \
##   --set image.tag=pr-N \
##   -n specwright-preview-N --create-namespace

replicaCount: 1

ingress:
  enabled: true
  className: nginx
  hostname: ""  # set via --set at deploy time
  tls: true
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-production

resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    memory: 256Mi

# Disable all cron jobs — previews are read-only UI
cronJob:
  enabled: false
reindexCronJob:
  enabled: false
staleCheckCronJob:
  enabled: false
coverageSnapshotCronJob:
  enabled: false
```

**Step 2: Lint the chart with preview values**

Run: `cd /home/ng/Code/gv-exp-specwright-pr-comments && helm lint chart/specwright/ -f chart/specwright/values-production.yaml -f chart/specwright/values-preview.yaml --set ingress.hostname=pr-99.specwright.gernerventures.com`
Expected: Lint passes with 0 errors

**Step 3: Commit**

```bash
git add chart/specwright/values-preview.yaml
git commit -m "feat: add Helm values override for preview deployments"
```

---

### Task 2: Add PLATFORM_URL to Helm ConfigMap

The `PLATFORM_URL` setting controls deep links in bot comments. It needs to be configurable per-deploy so previews link back to themselves.

**Files:**
- Modify: `chart/specwright/values.yaml` (add `config.platformUrl`)
- Modify: `chart/specwright/templates/configmap.yaml` (add `PLATFORM_URL` entry)

**Step 1: Add platformUrl to values.yaml**

In `chart/specwright/values.yaml`, add after line 129 (after `posthogLogsMinLevel`):

```yaml
  platformUrl: ""
```

**Step 2: Add PLATFORM_URL to configmap.yaml**

In `chart/specwright/templates/configmap.yaml`, add after the last data entry (line 16):

```yaml
  {{- if .Values.config.platformUrl }}
  PLATFORM_URL: {{ .Values.config.platformUrl | quote }}
  {{- end }}
```

**Step 3: Update values-production.yaml**

In `chart/specwright/values-production.yaml`, add to the `config:` section:

```yaml
  platformUrl: "https://specwright.gernerventures.com"
```

**Step 4: Lint the chart**

Run: `helm lint chart/specwright/ -f chart/specwright/values-production.yaml`
Expected: Lint passes

Run: `helm lint chart/specwright/ -f chart/specwright/values-production.yaml -f chart/specwright/values-preview.yaml --set ingress.hostname=pr-99.specwright.gernerventures.com --set config.platformUrl=https://pr-99.specwright.gernerventures.com`
Expected: Lint passes

**Step 5: Commit**

```bash
git add chart/specwright/values.yaml chart/specwright/templates/configmap.yaml chart/specwright/values-production.yaml
git commit -m "feat: add PLATFORM_URL to Helm configmap for preview links"
```

---

### Task 3: Add CI Lint for Preview Values

The existing CI `helm-lint` job only lints with production values. Add a lint step for preview values to catch breakage.

**Files:**
- Modify: `.github/workflows/ci.yml`

**Step 1: Add preview values lint**

In `.github/workflows/ci.yml`, add a new step after the existing "Lint with production values" step (line 181):

```yaml
      - name: Lint with preview values
        run: |
          helm lint chart/specwright/ \
            -f chart/specwright/values-production.yaml \
            -f chart/specwright/values-preview.yaml \
            --set ingress.hostname=pr-99.specwright.gernerventures.com \
            --set config.platformUrl=https://pr-99.specwright.gernerventures.com
```

**Step 2: Commit**

```bash
git add .github/workflows/ci.yml
git commit -m "ci: lint Helm chart with preview values in CI"
```

---

### Task 4: Create Preview Deploy Workflow

**Files:**
- Create: `.github/workflows/preview.yml`

**Step 1: Create the workflow file**

```yaml
name: Preview

on:
  pull_request:
    types: [opened, synchronize, reopened]
    paths:
      - 'templates/**'
      - 'static/**'
      - 'frontend/**'
      - 'src/specwright/web/**'
  pull_request_target:
    types: [closed]

concurrency:
  group: preview-pr-${{ github.event.pull_request.number }}
  cancel-in-progress: true

jobs:
  deploy:
    if: github.event.action != 'closed'
    runs-on: ubuntu-latest
    environment:
      name: preview-pr-${{ github.event.pull_request.number }}
      url: https://pr-${{ github.event.pull_request.number }}.specwright.gernerventures.com
    permissions:
      contents: read
      deployments: write
      pull-requests: write
    steps:
      - uses: actions/checkout@v4

      - name: Set PR number
        run: echo "PR_NUM=${{ github.event.pull_request.number }}" >> "$GITHUB_ENV"

      - name: Fetch secrets from Doppler
        uses: dopplerhq/secrets-fetch-action@v1.3.1
        id: secrets
        with:
          doppler-token: ${{ secrets.DOPPLER_SERVICE_TOKEN }}
          doppler-project: specwright
          doppler-config: prd

      - name: Install doctl
        uses: digitalocean/action-doctl@v2
        with:
          token: ${{ steps.secrets.outputs.DIGITALOCEAN_ACCESS_TOKEN }}

      - name: Log in to DOCR
        run: doctl registry login --expiry-seconds 600

      - name: Build and push Docker image
        run: |
          IMAGE="registry.digitalocean.com/${{ steps.secrets.outputs.DOCR_REGISTRY_NAME }}/specwright"
          TAG="pr-${PR_NUM}"
          docker build -t "${IMAGE}:${TAG}" .
          docker push "${IMAGE}:${TAG}"
          echo "IMAGE_TAG=${TAG}" >> "$GITHUB_ENV"

      - name: Save kubeconfig
        run: doctl kubernetes cluster kubeconfig save ${{ steps.secrets.outputs.DOKS_CLUSTER_NAME }}

      - name: Create namespace and pull secret
        run: |
          NAMESPACE="specwright-preview-${PR_NUM}"
          kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          doctl registry kubernetes-manifest --namespace "${NAMESPACE}" | kubectl apply -f -

      - name: Create app secrets
        env:
          GH_APP_ID: ${{ steps.secrets.outputs.GH_APP_ID }}
          GH_PRIVATE_KEY: ${{ steps.secrets.outputs.GH_PRIVATE_KEY }}
          GH_WEBHOOK_SECRET: ${{ steps.secrets.outputs.GH_WEBHOOK_SECRET }}
          GH_INSTALLATION_ID: ${{ steps.secrets.outputs.GH_INSTALLATION_ID }}
          ANTHROPIC_API_KEY: ${{ steps.secrets.outputs.ANTHROPIC_API_KEY }}
          DATABASE_URL: ${{ steps.secrets.outputs.DATABASE_URL }}
          GCP_SERVICE_ACCOUNT_KEY: ${{ steps.secrets.outputs.GCP_SERVICE_ACCOUNT_KEY }}
          GOOGLE_CLOUD_PROJECT: ${{ steps.secrets.outputs.GOOGLE_CLOUD_PROJECT }}
          GOOGLE_CLOUD_LOCATION: ${{ steps.secrets.outputs.GOOGLE_CLOUD_LOCATION }}
          AUTH0_DOMAIN: ${{ steps.secrets.outputs.AUTH0_DOMAIN }}
          AUTH0_CLIENT_ID: ${{ steps.secrets.outputs.AUTH0_CLIENT_ID }}
          AUTH0_CLIENT_SECRET: ${{ steps.secrets.outputs.AUTH0_CLIENT_SECRET }}
          AUTH0_AUDIENCE: ${{ steps.secrets.outputs.AUTH0_AUDIENCE }}
          AUTH0_DEVICE_CLIENT_ID: ${{ steps.secrets.outputs.AUTH0_DEVICE_CLIENT_ID }}
          POSTHOG_KEY: ${{ steps.secrets.outputs.POSTHOG_KEY }}
        run: |
          NAMESPACE="specwright-preview-${PR_NUM}"
          kubectl create secret generic specwright-github \
            --from-literal=GH_APP_ID="$GH_APP_ID" \
            --from-literal=GH_PRIVATE_KEY="$GH_PRIVATE_KEY" \
            --from-literal=GH_WEBHOOK_SECRET="$GH_WEBHOOK_SECRET" \
            --from-literal=GH_INSTALLATION_ID="$GH_INSTALLATION_ID" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          kubectl create secret generic specwright-anthropic \
            --from-literal=ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          kubectl create secret generic specwright-neon \
            --from-literal=DATABASE_URL="$DATABASE_URL" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          kubectl create secret generic specwright-gcp \
            --from-literal=GCP_SERVICE_ACCOUNT_KEY="$GCP_SERVICE_ACCOUNT_KEY" \
            --from-literal=GOOGLE_CLOUD_PROJECT="$GOOGLE_CLOUD_PROJECT" \
            --from-literal=GOOGLE_CLOUD_LOCATION="$GOOGLE_CLOUD_LOCATION" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          kubectl create secret generic specwright-auth0 \
            --from-literal=AUTH0_DOMAIN="$AUTH0_DOMAIN" \
            --from-literal=AUTH0_CLIENT_ID="$AUTH0_CLIENT_ID" \
            --from-literal=AUTH0_CLIENT_SECRET="$AUTH0_CLIENT_SECRET" \
            --from-literal=AUTH0_AUDIENCE="$AUTH0_AUDIENCE" \
            --from-literal=AUTH0_DEVICE_CLIENT_ID="$AUTH0_DEVICE_CLIENT_ID" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
          kubectl create secret generic specwright-posthog \
            --from-literal=POSTHOG_KEY="$POSTHOG_KEY" \
            -n "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -

      - name: Deploy with Helm
        run: |
          NAMESPACE="specwright-preview-${PR_NUM}"
          PREVIEW_HOST="pr-${PR_NUM}.specwright.gernerventures.com"
          helm upgrade --install "specwright-pr-${PR_NUM}" chart/specwright/ \
            -f chart/specwright/values-production.yaml \
            -f chart/specwright/values-preview.yaml \
            --set image.tag="${IMAGE_TAG}" \
            --set ingress.hostname="${PREVIEW_HOST}" \
            --set config.platformUrl="https://${PREVIEW_HOST}" \
            -n "${NAMESPACE}" --create-namespace \
            --wait --timeout 5m

      - name: Post preview URL comment
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: |
          PREVIEW_URL="https://pr-${PR_NUM}.specwright.gernerventures.com"
          SENTINEL="<!-- specwright-preview -->"
          BODY="${SENTINEL}
          **Preview deployment ready**

          ${PREVIEW_URL}

          <sub>specwright preview · pr-${PR_NUM} · ${GITHUB_SHA::7}</sub>"

          # Find existing preview comment
          COMMENT_ID=$(gh api "repos/${{ github.repository }}/issues/${PR_NUM}/comments" \
            --paginate --jq ".[] | select(.body | startswith(\"${SENTINEL}\")) | .id" \
            | head -1)

          if [ -n "$COMMENT_ID" ]; then
            gh api "repos/${{ github.repository }}/issues/comments/${COMMENT_ID}" \
              --method PATCH --field body="$BODY"
          else
            gh api "repos/${{ github.repository }}/issues/${PR_NUM}/comments" \
              --method POST --field body="$BODY"
          fi

  cleanup:
    if: github.event.action == 'closed'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      deployments: write
    steps:
      - name: Set PR number
        run: echo "PR_NUM=${{ github.event.pull_request.number }}" >> "$GITHUB_ENV"

      - name: Fetch secrets from Doppler
        uses: dopplerhq/secrets-fetch-action@v1.3.1
        id: secrets
        with:
          doppler-token: ${{ secrets.DOPPLER_SERVICE_TOKEN }}
          doppler-project: specwright
          doppler-config: prd

      - name: Install doctl
        uses: digitalocean/action-doctl@v2
        with:
          token: ${{ steps.secrets.outputs.DIGITALOCEAN_ACCESS_TOKEN }}

      - name: Save kubeconfig
        run: doctl kubernetes cluster kubeconfig save ${{ steps.secrets.outputs.DOKS_CLUSTER_NAME }}

      - name: Delete preview namespace
        run: |
          NAMESPACE="specwright-preview-${PR_NUM}"
          if kubectl get namespace "${NAMESPACE}" 2>/dev/null; then
            kubectl delete namespace "${NAMESPACE}" --wait=false
            echo "Deleted namespace ${NAMESPACE}"
          else
            echo "Namespace ${NAMESPACE} does not exist, skipping"
          fi

      - name: Mark deployment inactive
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: |
          # Deactivate the GitHub environment
          gh api "repos/${{ github.repository }}/environments/preview-pr-${PR_NUM}" \
            --method DELETE || true
```

**Step 2: Validate YAML syntax**

Run: `python -c "import yaml; yaml.safe_load(open('.github/workflows/preview.yml'))" && echo "Valid YAML"`
Expected: Valid YAML

**Step 3: Commit**

```bash
git add .github/workflows/preview.yml
git commit -m "feat: add preview deployment workflow for PR UI changes"
```

---

### Task 5: Surface Preview URL in Specwright Bot Comment

When the PR handler posts its analysis comment, check if a preview deployment exists for this PR and include the URL in the comment footer.

**Files:**
- Modify: `src/specwright/github/client.py` (add `get_preview_deployment_url` method)
- Test: `tests/test_github/test_client.py`
- Modify: `src/specwright/github/handlers/on_pull_request.py` (call it before formatting)

**Step 1: Write the failing test for the client method**

Add to `tests/test_github/test_client.py`:

```python
class TestGetPreviewDeploymentUrl:
    """Test preview deployment URL lookup."""

    @pytest.mark.asyncio
    async def test_returns_url_when_active_deployment_exists(self, client):
        client._request = AsyncMock(return_value=[
            {
                "environment": "preview-pr-42",
                "statuses_url": "https://api.github.com/repos/acme/repo/deployments/123/statuses",
            }
        ])
        # Mock the statuses request
        original_request = client._request
        call_count = 0

        async def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [{"environment": "preview-pr-42", "id": 123}]
            return [{"state": "success", "environment_url": "https://pr-42.specwright.gernerventures.com"}]

        client._request = AsyncMock(side_effect=side_effect)
        url = await client.get_preview_deployment_url("acme", "repo", 42)
        assert url == "https://pr-42.specwright.gernerventures.com"

    @pytest.mark.asyncio
    async def test_returns_none_when_no_deployment(self, client):
        client._request = AsyncMock(return_value=[])
        url = await client.get_preview_deployment_url("acme", "repo", 42)
        assert url is None

    @pytest.mark.asyncio
    async def test_returns_none_on_api_error(self, client):
        client._request = AsyncMock(side_effect=Exception("API error"))
        url = await client.get_preview_deployment_url("acme", "repo", 42)
        assert url is None
```

**Step 2: Run test to verify it fails**

Run: `cd /home/ng/Code/gv-exp-specwright-pr-comments && uv run pytest tests/test_github/test_client.py::TestGetPreviewDeploymentUrl -v`
Expected: FAIL — `get_preview_deployment_url` does not exist

**Step 3: Implement the method**

Add to `src/specwright/github/client.py` in the `GitHubClient` class:

```python
async def get_preview_deployment_url(
    self, owner: str, repo: str, pr_number: int
) -> str | None:
    """Return the preview deployment URL for a PR, or None if not deployed."""
    env_name = f"preview-pr-{pr_number}"
    try:
        deployments = await self._request(
            "GET", f"/repos/{owner}/{repo}/deployments",
            params={"environment": env_name, "per_page": 1},
        )
        if not deployments:
            return None
        statuses = await self._request(
            "GET", f"/repos/{owner}/{repo}/deployments/{deployments[0]['id']}/statuses",
            params={"per_page": 1},
        )
        if statuses and statuses[0].get("state") == "success":
            return statuses[0].get("environment_url")
        return None
    except Exception:
        return None
```

**Step 4: Run test to verify it passes**

Run: `cd /home/ng/Code/gv-exp-specwright-pr-comments && uv run pytest tests/test_github/test_client.py::TestGetPreviewDeploymentUrl -v`
Expected: PASS

**Step 5: Modify on_pull_request.py to pass preview_url**

In `src/specwright/github/handlers/on_pull_request.py`, around line 321 (before `format_analysis_comment` call):

```python
        # Check for active preview deployment
        preview_url = await client.get_preview_deployment_url(owner, repo, pr_number)
```

Then update the `format_analysis_comment` call (line 324) to pass it:

```python
            comment = format_analysis_comment(
                result,
                model=DEFAULT_AGENT_CONFIG.model,
                preview_url=preview_url,
                base_url=_settings.platform_url,
                owner=owner,
                repo=repo,
                doc_patterns=doc_paths,
            )
```

**Step 6: Run full test suite**

Run: `cd /home/ng/Code/gv-exp-specwright-pr-comments && uv run pytest -q`
Expected: All tests pass

**Step 7: Commit**

```bash
git add src/specwright/github/client.py tests/test_github/test_client.py src/specwright/github/handlers/on_pull_request.py
git commit -m "feat: surface preview deployment URL in Specwright bot comment"
```

---

### Task 6: Update Spec and Run Final Checks

**Files:**
- Modify: `docs/specs/pr-comment-enhancements.md`

**Step 1: Update Section 3 status to done and add realization comments**

Update the Section 3 acceptance criteria:

```markdown
- [x] PRs that modify `templates/` or `static/` files trigger a preview deployment
<!-- specwright:realized-in:PR#TBD file:.github/workflows/preview.yml -->
- [x] Preview URL is accessible and shows the updated UI
<!-- specwright:realized-in:PR#TBD file:chart/specwright/values-preview.yaml -->
- [x] Preview connects to production data source (read-only)
<!-- specwright:realized-in:PR#TBD file:.github/workflows/preview.yml -->
- [x] Preview deployments are cleaned up after PR merge/close
<!-- specwright:realized-in:PR#TBD file:.github/workflows/preview.yml -->
- [x] Preview URL is posted as a GitHub deployment status or PR comment
<!-- specwright:realized-in:PR#TBD file:src/specwright/github/handlers/on_pull_request.py -->
```

Update section 3 system status from `in_progress` to `done`.
Update frontmatter status from `in_progress` to `done`.

**Step 2: Run lint and tests**

Run: `cd /home/ng/Code/gv-exp-specwright-pr-comments && uv run ruff check && uv run ruff format --check && uv run pytest -q`
Expected: All pass

**Step 3: Commit**

```bash
git add docs/specs/pr-comment-enhancements.md
git commit -m "docs: mark PR comment spec sections as done"
```

---

## gv-infra Items (Separate PR)

These must be done in the `gv-infra` repo before preview deployments will actually work:

1. **Wildcard DNS**: Add/verify `*.specwright.gernerventures.com` A/CNAME record pointing to the DOKS ingress IP
2. **Auth0 Callback URL**: Add `https://pr-*.specwright.gernerventures.com/auth/callback` to the Auth0 app's "Allowed Callback URLs"
3. **Wildcard TLS**: Verify cert-manager handles per-subdomain certificates (or add a wildcard cert)

---

## Task Summary

| # | Task | Type | Files |
|---|------|------|-------|
| 1 | Helm preview values override | Create | `chart/specwright/values-preview.yaml` |
| 2 | Add PLATFORM_URL to Helm configmap | Modify | `values.yaml`, `configmap.yaml`, `values-production.yaml` |
| 3 | CI lint for preview values | Modify | `ci.yml` |
| 4 | Preview deploy workflow | Create | `preview.yml` |
| 5 | Preview URL in bot comment | Modify + Test | `client.py`, `on_pull_request.py`, test |
| 6 | Spec updates + final checks | Modify | `pr-comment-enhancements.md` |
