import{b as r}from"./baseUniq.Dz0Wn4lV.js";var e=4;function a(o){return r(o,e)}export{a as c};
