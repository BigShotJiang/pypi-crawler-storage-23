import{b as r}from"./baseUniq.BvEV_L-G.js";var e=4;function a(o){return r(o,e)}export{a as c};
