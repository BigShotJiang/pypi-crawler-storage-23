import{b as r}from"./baseUniq.CF87aG1g.js";var e=4;function a(o){return r(o,e)}export{a as c};
