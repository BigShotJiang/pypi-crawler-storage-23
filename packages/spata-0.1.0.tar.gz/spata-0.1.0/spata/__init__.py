"""spata"""

__version__ = "0.1.0"

from spata.base.card import Card
