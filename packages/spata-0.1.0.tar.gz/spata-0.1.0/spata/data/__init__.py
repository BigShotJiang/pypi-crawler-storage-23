"""spata.data"""
