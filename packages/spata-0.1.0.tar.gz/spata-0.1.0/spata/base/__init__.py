"""spata.base"""
