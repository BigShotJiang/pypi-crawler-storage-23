SPATA
=====

This is SPATA.

Check out the official documentation: `https://spata.readthedocs.io/en/latest <https://spata.readthedocs.io/en/latest/>`_

Explore the open source code repository: `https://github.com/vitorinojoao/spata <https://github.com/vitorinojoao/spata>`_

Install it from the Python Package Index: `https://pypi.org/project/spata <https://pypi.org/project/spata/>`_
