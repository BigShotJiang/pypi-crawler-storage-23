from .core import ServiceAgent
import logging

logger = logging.getLogger("service_agent")
logging.basicConfig(level=logging.INFO)
