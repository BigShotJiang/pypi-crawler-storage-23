def must_be_number(value):
    return isinstance(value, (int, float))

def must_be_non_empty_string(value):
    return isinstance(value, str) and bool(value.strip())

def must_exist(value):
    return value is not None
