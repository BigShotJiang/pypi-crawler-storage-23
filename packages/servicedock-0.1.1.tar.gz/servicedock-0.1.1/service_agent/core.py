import os
import requests
import logging
import json
from urllib.parse import urlencode
from pathlib import Path
from dotenv import load_dotenv
from .config import load_config

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()


def _recordings_dir():
    """Directory for replay recordings; overridable via env."""
    return os.getenv("SERVICE_AGENT_RECORDINGS_DIR", "recordings")


def _load_replay_response(endpoint_name, params, recordings_dir):
    """
    Load a recorded response from disk for replay mode.
    Uses same naming as recording_agent: {endpoint_name}_{params.get('id', 'default')}.json
    """
    recording_id = params.get("id", "default")
    filename = f"{endpoint_name}_{recording_id}.json"
    path = Path(recordings_dir) / filename
    if not path.exists():
        raise FileNotFoundError(
            f"No recording found for replay: {path}. "
            f"Run: python agentstack.py call {endpoint_name} --<params> to record first."
        )
    with open(path, "r") as f:
        data = json.load(f)
    return data["response"]["body"]


class ServiceAgent:
    def __init__(self):
        self.config = load_config()
        self.mode = os.getenv("SERVICE_AGENT_MODE", "live")
        logger.info(f"ServiceAgent initialized in {self.mode} mode")

    def api(self, name):
        name = name.lower()
        config_lookup = {k.lower(): v for k, v in self.config.items()}
        if name not in config_lookup:
            raise ValueError(f"Unknown API: {name}")
        return APIWrapper(config_lookup[name], self.mode, _recordings_dir())


class APIWrapper:
    def __init__(self, config, mode, recordings_dir=None):
        self.config = config
        self.mode = mode
        self._recordings_dir = recordings_dir or _recordings_dir()
        logger.info(f"APIWrapper initialized for {config.get('name', 'unknown')} in {mode} mode")

    def get(self, endpoint_name, params):
        endpoint = self.config["endpoints"].get(endpoint_name)
        if not endpoint:
            raise ValueError(f"Unknown endpoint: {endpoint_name}")

        # Check required params
        for key in endpoint.get("required_params", []):
            if key not in params:
                raise ValueError(f"Missing required param: {key}")

        # Auth (only inject for live)
        auth_conf = self.config.get("auth")
        if auth_conf and auth_conf.get("type") == "query" and self.mode != "replay":
            key = os.getenv(auth_conf["env_var"])
            if not key:
                raise EnvironmentError(f"Missing API key for {auth_conf['env_var']}")
            params = {**params, auth_conf["key_name"]: key}

        # Start with the base path
        path = endpoint["path"]

        # Extract path parameters and remove them from query params
        query_params = params.copy()
        for key in endpoint.get("required_params", []):
            placeholder = f"{{{key}}}"
            if placeholder in path:
                path = path.replace(placeholder, str(params[key]))
                query_params.pop(key, None)  # Remove from query params if it was a path param

        base_url = (self.config.get("base_url") or "").rstrip("/")
        if base_url and not base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"Invalid base_url (missing scheme): {base_url!r}. "
                "Edit the API config and set base_url to a full URL, e.g. https://api.example.com"
            )
        url = base_url + path
        full_url = f"{url}?{urlencode(query_params)}" if query_params else url

        if self.mode == "replay":
            logger.info(f"[REPLAY MODE] Loading recording for {endpoint_name} (no network)")
            return _load_replay_response(endpoint_name, params, self._recordings_dir)

        logger.info(f"[LIVE MODE] Making GET request to: {full_url}")
        res = requests.get(full_url)
        if res.status_code != 200:
            logger.error(f"API request failed: {res.status_code} {res.text}")
            raise Exception(f"API request failed: {res.status_code} {res.text}")
        logger.info(f"[LIVE MODE] Request successful. Status code: {res.status_code}")
        return res.json()

    def post(self, endpoint_name, body):
        endpoint = self.config["endpoints"].get(endpoint_name)
        if not endpoint:
            raise ValueError(f"Unknown endpoint: {endpoint_name}")

        if self.mode == "replay":
            logger.info(f"[REPLAY MODE] Loading recording for {endpoint_name} (no network)")
            return _load_replay_response(endpoint_name, body, self._recordings_dir)

        # Auth handling (if needed)
        auth_conf = self.config.get("auth")
        if auth_conf and auth_conf.get("type") == "query":
            key = os.getenv(auth_conf["env_var"])
            if not key:
                raise EnvironmentError(f"Missing API key for {auth_conf['env_var']}")
            body = {**body, auth_conf["key_name"]: key}

        path = endpoint["path"]
        base_url = (self.config.get("base_url") or "").rstrip("/")
        if base_url and not base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"Invalid base_url (missing scheme): {base_url!r}. "
                "Edit the API config and set base_url to a full URL, e.g. https://api.example.com"
            )
        url = base_url + path

        logger.info(f"[LIVE MODE] Making POST request to: {url}")
        logger.info(f"[PAYLOAD] {json.dumps(body, indent=2)}")

        res = requests.post(url, json=body)

        if res.status_code != 200:
            raise Exception(f"API request failed: {res.status_code} {res.text}")

        data = res.json()
        logger.info("[LIVE MODE] Request successful. Status code: 200")
        return data

