MODE = "live"  # Options: "live", "replay"

def set_mode(mode):
    global MODE
    if mode not in ["live", "replay"]:
        raise ValueError("Invalid mode. Use 'live' or 'replay'.")
    MODE = mode

def get_mode():
    return MODE
