from .errors import ContractViolationError
from .contract_types import *
import inspect

CONTRACT_TYPE_MAP = {
    "must_be_number": must_be_number,
    "must_be_non_empty_string": must_be_non_empty_string,
    "must_exist": must_exist,
}

def contract(spec):
    def decorator(fn):
        fn._contract_spec = spec
        def wrapper(*args, **kwargs):
            _check_requires(spec, fn, args, kwargs)
            result = fn(*args, **kwargs)
            _check_expects(spec, result)
            result = _apply_prohibits(spec, result)
            result = _apply_only_allow(spec, result)
            _enforce_no_pii(spec, result)
            if spec.get("policy", {}).get("sanitize_ALL", False):
                result = _sanitize_all(result)
                print("🧼 Entire response sanitized due to `sanitize_ALL` policy.")
            return result
        wrapper._contract_spec = spec
        return wrapper
    return decorator

def _check_requires(spec, fn, args, kwargs):
    if "requires" not in spec:
        return
    sig = inspect.signature(fn)
    bound = sig.bind(*args, **kwargs)
    bound.apply_defaults()
    for key, rule in spec["requires"].items():
        check = CONTRACT_TYPE_MAP.get(rule)
        value = bound.arguments.get(key)
        if check and not check(value):
            raise ContractViolationError(f"`{key}` failed contract: {rule}", field=key)

def _check_expects(spec, data):
    if "expects" not in spec:
        return
    for field_path, rule in spec["expects"].items():
        val = data
        try:
            for k in field_path.split("."):
                val = val[k]
        except (KeyError, TypeError):
            raise ContractViolationError(f"Missing field `{field_path}`", field=field_path)
        check = CONTRACT_TYPE_MAP.get(rule)
        if check and not check(val):
            raise ContractViolationError(f"`{field_path}` failed contract: {rule}", field=field_path)

def _apply_prohibits(spec, data):
    if "prohibits" not in spec or not isinstance(data, dict):
        return data
    
    prohibited = spec["prohibits"].get("*", [])
    mode = spec.get("mode", "fail")  # default to fail

    for key in data.keys():
        if key in prohibited:
            msg = f"🚫 Contract violation: Prohibited field `{key}` present in response"
            if mode == "warn":
                print(f"⚠️  {msg}")
                return data  # allow to pass through
            else:
                raise ContractViolationError(msg, field=key)
    return data

def _apply_only_allow(spec, data):
    if "only_allow" not in spec or not isinstance(data, dict):
        return data
    allowed = spec["only_allow"]
    if not allowed:
        return data  # empty list = no filter, pass through
    allowed_set = set(allowed)
    return {k: v for k, v in data.items() if k in allowed_set}

PII_FIELDS = {
    "email", "username", "phone", "ssn", "dob", "birthdate", "geo",
    "address", "first_name", "last_name", "location", "full_name"
}

def _enforce_no_pii(spec, data):
    if not spec.get("policy", {}).get("no_PII", False):
        return

    if not isinstance(data, dict):
        return

    sanitize = spec.get("policy", {}).get("sanitize_PII", False)
    mode = spec.get("mode", "fail")

    violations = []
    for key in list(data.keys()):
        if key.lower() in PII_FIELDS:
            violations.append(key)
            if sanitize:
                data[key] = "[redacted]"
    
    if violations:
        message = f"PII field(s) {violations} present in response"
        if sanitize:
            print(f"⚠️ 🧼 PII fields sanitized: {violations}")
        elif mode == "warn":
            print(f"⚠️ 🚫 Contract violation: {message}")
        elif mode != "silent":
            raise ContractViolationError(f"🚫 Contract violation: {message}", field=violations[0])
        
def _sanitize_all(data):
    if isinstance(data, dict):
        return {k: _sanitize_all(v) for k, v in data.items()}
    elif isinstance(data, list):
        return []
    elif isinstance(data, str):
        return "REDACTED"
    elif isinstance(data, (int, float)):
        return 0
    elif isinstance(data, bool):
        return False
    return data


