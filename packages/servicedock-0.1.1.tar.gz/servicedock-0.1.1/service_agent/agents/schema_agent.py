import yaml
import json
import os
from pathlib import Path

def load_spec(spec_path):
    """Load OpenAPI spec from a .json or .yaml/.yml file."""
    path = Path(spec_path)
    with open(path, "r") as f:
        text = f.read()
    if path.suffix.lower() == ".json":
        return json.loads(text)
    return yaml.safe_load(text)

def scaffold_from_spec(spec, api_name="unknown", output_dir="scaffolds"):
    os.makedirs(output_dir, exist_ok=True)

    for path, ops in spec.get("paths", {}).items():
        for method, details in ops.items():
            method_name = method.lower()
            clean_path = path.replace("/", ".").strip(".").replace("{", "").replace("}", "")
            scaffold_name = f"{clean_path}.{method_name}.json"
            scaffold_path = os.path.join(output_dir, scaffold_name)

            scaffold = {
                "api": api_name,
                "method": method.upper(),
                "path": path,
                "params": {},
                "body": {}
            }

            for p in details.get("parameters", []):
                name = p["name"]
                location = p.get("in")

                if location in ["query", "path"]:
                    typ = p.get("schema", {}).get("type", "unknown")
                    scaffold["params"][name] = f"<{typ}>"

                elif location == "body":
                    schema = p.get("schema", {})
                    if "$ref" in schema:
                        schema = resolve_ref(schema["$ref"], spec)
                    if "properties" in schema:
                        for field, field_spec in schema["properties"].items():
                            if "$ref" in field_spec:
                                field_spec = resolve_ref(field_spec["$ref"], spec)
                            ftype = field_spec.get("type", "unknown")
                            scaffold["body"][field] = expand_schema(field_spec, spec)

            # Also support OpenAPI 3.x style requestBody (if present)
            if "requestBody" in details:
                content = details["requestBody"].get("content", {})
                json_body = content.get("application/json", {})
                schema = json_body.get("schema", {})

                if "$ref" in schema:
                    schema = resolve_ref(schema["$ref"], spec)

                if "properties" in schema:
                    for field, field_spec in schema["properties"].items():
                        if "$ref" in field_spec:
                            field_spec = resolve_ref(field_spec["$ref"], spec)
                        ftype = field_spec.get("type", "unknown")
                        if ftype == "array":
                            scaffold["body"][field] = [f"<{field_spec.get('items', {}).get('type', 'unknown')}>"]
                        elif ftype == "object":
                            scaffold["body"][field] = {"<object>": "..."}
                        else:
                            scaffold["body"][field] = f"<{ftype}>"

            # ✅ Write to file for *every* endpoint
            with open(scaffold_path, "w") as f:
                json.dump(scaffold, f, indent=2)

            print(f"🧱 Created scaffold: {scaffold_path}")


def resolve_ref(ref, spec):
    """Given a $ref like '#/components/schemas/Pet', return the actual schema dict."""
    if not ref.startswith("#/"):
        return {}

    path_parts = ref[2:].split("/")
    resolved = spec
    for part in path_parts:
        resolved = resolved.get(part, {})
    return resolved

def expand_schema(schema, spec):
    """Recursively convert a schema into a representative placeholder."""
    if "$ref" in schema:
        schema = resolve_ref(schema["$ref"], spec)

    ftype = schema.get("type", "object")

    if ftype == "array":
        item_schema = schema.get("items", {})
        return [expand_schema(item_schema, spec)]

    elif ftype == "object":
        if "properties" in schema:
            obj = {}
            for field, field_spec in schema["properties"].items():
                obj[field] = expand_schema(field_spec, spec)
            return obj
        else:
            return {"<object>": "..."}

    return f"<{ftype}>"


def _endpoint_key(path, method):
    """Same naming as scaffold filenames: path to dot-notation + method."""
    clean = path.replace("/", ".").strip(".").replace("{", "").replace("}", "")
    return f"{clean}.{method.lower()}"


def _required_params(details):
    """Required params: path params plus any with required=True."""
    required = []
    for p in details.get("parameters", []):
        if p.get("in") == "path":
            required.append(p["name"])
        elif p.get("required", False):
            required.append(p["name"])
    return required


def _base_url_from_spec(spec):
    """OpenAPI 3: servers[0].url; OpenAPI 2: scheme + host + basePath.
    If the spec has a relative server URL (e.g. /api/v3), returns https://localhost
    so the config always has a valid scheme; override in the generated JSON if needed.
    """
    url = ""
    if spec.get("servers"):
        url = (spec["servers"][0].get("url") or "").rstrip("/")
    else:
        # OpenAPI 2
        scheme = spec.get("schemes", ["https"])[0]
        host = spec.get("host", "")
        base = spec.get("basePath", "")
        url = f"{scheme}://{host}{base}".rstrip("/")
    # Relative URLs have no scheme; requests.get() requires one
    if url and not url.startswith(("http://", "https://")):
        url = "https://localhost"
        print("  ⚠️  Server URL in spec was relative; using https://localhost. Edit the config file to set the real base URL.")
    return url or "https://localhost"


def write_api_config(spec, api_name, output_dir):
    """
    Generate one API config file from the OpenAPI spec (same source as scaffolds).
    Writes {output_dir}/{api_name}.json with base_url, auth (null), and endpoints.
    """
    os.makedirs(output_dir, exist_ok=True)
    base_url = _base_url_from_spec(spec)
    endpoints = {}
    for path, ops in spec.get("paths", {}).items():
        for method, details in ops.items():
            if method.lower() not in ("get", "post", "put", "delete", "patch"):
                continue
            key = _endpoint_key(path, method)
            endpoints[key] = {
                "method": method.upper(),
                "path": path,
                "required_params": _required_params(details),
            }
    config = {
        "name": api_name,
        "base_url": base_url,
        "auth": None,
        "endpoints": endpoints,
    }
    path = os.path.join(output_dir, f"{api_name}.json")
    with open(path, "w") as f:
        json.dump(config, f, indent=2)
    print(f"📋 Created config: {path}")
