import os
import json

def save_recording(endpoint_name, params, response_body):
    filename = f"{endpoint_name}_{params.get('id', 'default')}.json"
    out_dir = "recordings"
    os.makedirs(out_dir, exist_ok=True)

    recording = {
        "request": {
            "endpoint": endpoint_name,
            "params": params
        },
        "response": {
            "body": response_body
        }
    }

    path = os.path.join(out_dir, filename)
    with open(path, "w") as f:
        json.dump(recording, f, indent=2)

    print(f"🧾 Recorded to {path}")
