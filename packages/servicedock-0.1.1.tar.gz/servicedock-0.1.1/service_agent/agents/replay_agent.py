import os
import json

def replay_recording(name, cli_args):
    recording_name = f"{name}_{cli_args.get('id', 'default')}.json"
    recording_path = os.path.join("recordings", recording_name)

    if not os.path.exists(recording_path):
        print(f"❌ No recording found: {recording_path}")
        return

    with open(recording_path, "r") as f:
        data = json.load(f)

    print("🔁 Replaying request:")
    print(json.dumps(data["request"], indent=2))
    print("\n🎯 Simulated response:")
    print(json.dumps(data["response"], indent=2))
