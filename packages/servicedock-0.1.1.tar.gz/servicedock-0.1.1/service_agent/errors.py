class ContractViolationError(Exception):
    def __init__(self, message, field=None):
        super().__init__(f"🚫 Contract violation: {message}")
        self.field = field
