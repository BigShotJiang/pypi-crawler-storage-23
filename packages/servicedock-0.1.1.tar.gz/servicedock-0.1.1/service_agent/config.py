import os
import json
from pathlib import Path

# Default configs (used when no generated configs exist, or merged with generated)
API_CONFIG = {
    "Weatherstack": {
        "base_url": "http://api.weatherstack.com",
        "auth": {
            "type": "query",
            "key_name": "access_key",
            "env_var": "WEATHERSTACK_API_KEY"
        },
        "endpoints": {
            "current": {
                "method": "GET",
                "path": "/current",
                "required_params": ["query"]
            }
        }
    },
    "IPAPI": {
        "base_url": "http://ip-api.com",
        "auth": None,
        "endpoints": {
            "lookup": {
                "method": "GET",
                "path": "/json",
                "required_params": ["ip"]
            }
        }
    },
    "JSONPlaceholder": {
        "base_url": "https://jsonplaceholder.typicode.com",
        "auth": None,
        "endpoints": {
            "posts.id.get": {
                "method": "GET",
                "path": "/posts/{id}",
                "required_params": ["id"]
            }
        }
    },
    "FakeUserAPI": {
        "base_url": "https://fake-json-api.mock.beeceptor.com",
        "auth": None,
        "endpoints": {
            "users.list": {
                "method": "GET",
                "path": "/users",
                "required_params": []
            }
        }
    },
    "FakeStore": {
        "base_url": "https://fakestoreapi.com",
        "auth": None,
        "endpoints": {
            "products.id.get": {
                "method": "GET",
                "path": "/products/{id}",
                "required_params": ["id"]
            }
        }
    },
    "Petstore": {
        "base_url": "https://petstore.swagger.io/v2",
        "auth": None,  # No auth required
        "endpoints": {
            "pet.petId.get": {
                "method": "GET",
                "path": "/pet/{petId}",
                "required_params": ["petId"]
            },
            "store.inventory.get": {
                "method": "GET",
                "path": "/store/inventory",
                "required_params": []
            },
                "pet.post": {
                    "method": "POST",
                    "path": "/pet",
                    "required_params": []
                }
        }
    },
    "DogAPI": {
        "base_url": "https://dog.ceo/api",
        "auth": None,
        "endpoints": {
            "breeds.list.all.get": {
                "method": "GET",
                "path": "/breeds/list/all",
                "required_params": []
            },
            "breed.breed.images.random.get": {
                "method": "GET",
                "path": "/breed/{breed}/images/random",
                "required_params": ["breed"]
            },
            "breeds.image.random.get": {
                "method": "GET",
                "path": "/breeds/image/random",
                "required_params": []
            }
        }
    }
}


def _configs_dir():
    """Directory for generated API configs (next to this file)."""
    return Path(__file__).parent / "configs"


def load_config():
    """
    Load API config: from service_agent/configs/*.json if present,
    otherwise fall back to built-in API_CONFIG.
    Generated configs override built-in entries with the same key (key = filename stem, e.g. dogapi).
    """
    out = dict(API_CONFIG)
    configs_dir = _configs_dir()
    if not configs_dir.exists():
        return out
    for path in configs_dir.glob("*.json"):
        try:
            with open(path, "r") as f:
                data = json.load(f)
            key = path.stem  # e.g. dogapi
            out[key] = data
        except (json.JSONDecodeError, OSError) as e:
            import logging
            logging.getLogger(__name__).warning("Skip config %s: %s", path, e)
    return out
