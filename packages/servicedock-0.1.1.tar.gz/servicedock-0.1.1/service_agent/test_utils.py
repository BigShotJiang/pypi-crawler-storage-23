import argparse
import os
import json
from service_agent.runtime import set_mode, get_mode
from service_agent import ServiceAgent
from service_agent.config import load_config

agent = ServiceAgent()

def init_test_runtime():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["live", "replay"], default="replay")
    args, _ = parser.parse_known_args()

    set_mode(args.mode)

    print(f"\n⚙️  Test Mode: {args.mode.upper()}")
    if args.mode == "replay":
        print("🔁 Loading response from recording...")
    else:
        print("🌐 Making live API request...")

def override_contract(endpoint_name, contract_spec):
    """Override the contract for a specific endpoint."""
    if not hasattr(agent, '_contract_overrides'):
        agent._contract_overrides = {}
    agent._contract_overrides[endpoint_name] = contract_spec

# TEMP until contract registry exists
import inspect

def get_contract_for_endpoint(name):
    # Look for decorated test function with _contract_spec in caller module
    for frame in inspect.stack():
        f_globals = frame.frame.f_globals
        for obj in f_globals.values():
            if callable(obj) and hasattr(obj, "_contract_spec"):
                return getattr(obj, "_contract_spec")
    return {}

def _recordings_dir():
    return os.getenv("SERVICE_AGENT_RECORDINGS_DIR", "recordings")

def load_response(endpoint_name, params, api_name="JSONPlaceholder"):
    mode = get_mode()
    recording_id = params.get("id", "default")
    filename = f"{endpoint_name}_{recording_id}.json"
    path = os.path.join(_recordings_dir(), filename)

    print(f"\n=== 📦 Contract Test: `{endpoint_name}` ===")
    print(f"🔧 Mode: {mode.upper()}")
    print(f"📁 Recording: {filename}")
    print(f"🔍 Params: {params}")
    print(f"🔗 API: {api_name}")

    if mode == "replay":
        print("🔁 Replaying from recording...")
        with open(path, "r") as f:
            return json.load(f)["response"]["body"]

    if mode == "live":
        config = load_config()
        config_lookup = {k.lower(): v for k, v in config.items()}
        api_config = config_lookup.get(api_name.lower())
        if not api_config:
            raise ValueError(f"Unknown API: {api_name}")
        method = api_config["endpoints"][endpoint_name]["method"]
        print(f"🌐 Live request type: {method}")

        if method != "GET":
            print(f"🚫 Live test blocked: {method} calls are not allowed in test mode.")
            raise RuntimeError(
                f"🚫 Live test for {method} `{endpoint_name}` is not allowed. Use `agentstack call` to generate recordings."
            )

        with open(path, "r") as f:
            original_request = json.load(f)["request"]["params"]

        return agent.api(api_name).get(endpoint_name, original_request)


    raise RuntimeError("Unknown test mode or unsupported config.")

