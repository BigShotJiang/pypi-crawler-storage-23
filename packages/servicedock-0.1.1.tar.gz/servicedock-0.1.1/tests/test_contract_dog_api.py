"""
Contract Test: Dog API
Demonstrates the unique value of Service Agent Stack vs OpenAPI CodeGen:
1. Runtime contract validation
2. Policy enforcement
3. Replay testing without network calls
"""

from service_agent.test_utils import init_test_runtime, load_response
from service_agent.decorators import contract
from service_agent.errors import ContractViolationError

init_test_runtime()

# ============================================================================
# Test 1: Basic Contract Validation
# ============================================================================
# This ensures the API response matches our expectations at runtime
# Unlike codegen which only gives you types, this VALIDATES the actual data

@contract({
    "expects": {
        "message": "must_be_non_empty_string",
        "status": "must_be_non_empty_string"
    }
})
def validate_dog_image_response(resp):
    return resp

print("\n" + "="*70)
print("📋 TEST 1: Basic Contract Validation")
print("="*70)
print("✨ Value: Runtime validation ensures API actually returns what we expect")
print("   (OpenAPI CodeGen only gives you types, not runtime validation)")

response = load_response("breed.breed.images.random.get", {"breed": "husky"}, api_name="DogAPI")

try:
    validated = validate_dog_image_response(response)
    print("✅ Contract passed! Response structure is valid.")
    print(f"   Image URL: {validated['message']}")
except ContractViolationError as e:
    print(f"❌ Contract failed: {e}")
    raise


# ============================================================================
# Test 2: Field Filtering (only_allow)
# ============================================================================
# Filter out unnecessary fields before passing data to your frontend/clients

@contract({
    "expects": {
        "message": "must_be_non_empty_string",
        "status": "must_be_non_empty_string"
    },
    "only_allow": ["message"]  # Only return the image URL, filter out status
})
def validate_and_filter_dog_image(resp):
    return resp

print("\n" + "="*70)
print("📋 TEST 2: Field Filtering with only_allow")
print("="*70)
print("✨ Value: Automatically filter response to only return what you need")
print("   (Reduces payload size, prevents leaking internal API fields)")

response = load_response("breed.breed.images.random.get", {"breed": "husky"}, api_name="DogAPI")

try:
    filtered = validate_and_filter_dog_image(response)
    print(f"✅ Contract passed! Filtered response: {filtered}")
    print(f"   Notice: 'status' field was removed automatically")
    assert "status" not in filtered, "Status should be filtered out"
    assert "message" in filtered, "Message should be present"
except ContractViolationError as e:
    print(f"❌ Contract failed: {e}")
    raise


# ============================================================================
# Test 3: Policy Enforcement - PII Detection
# ============================================================================
# Imagine the API accidentally returned user data with PII

@contract({
    "expects": {
        "message": "must_be_non_empty_string"
    },
    "policy": {
        "no_PII": True,
        "sanitize_PII": True  # Automatically redact PII if found
    }
})
def validate_with_pii_protection(resp):
    return resp

print("\n" + "="*70)
print("📋 TEST 3: PII Protection Policy")
print("="*70)
print("✨ Value: Automatic PII detection and sanitization")
print("   (Critical for GDPR/compliance - OpenAPI CodeGen can't do this)")

# Simulate a response with PII (in reality, this might be an API bug)
response_with_pii = {
    "message": "https://images.dog.ceo/breeds/husky/n02110185_7980.jpg",
    "status": "success",
    "email": "user@example.com",  # Oops! API leaked PII
    "phone": "555-1234"
}

try:
    sanitized = validate_with_pii_protection(response_with_pii)
    print(f"✅ PII detected and sanitized!")
    print(f"   Original had: email, phone")
    print(f"   Sanitized result: {sanitized}")
except ContractViolationError as e:
    print(f"❌ Contract failed: {e}")


# ============================================================================
# Test 4: Breeds List Structure Validation
# ============================================================================

@contract({
    "expects": {
        "message": "must_exist",
        "status": "must_be_non_empty_string"
    }
})
def validate_breeds_list(resp):
    # Additional custom validation
    if not isinstance(resp["message"], dict):
        raise ValueError("Expected 'message' to be a dictionary of breeds")
    return resp

print("\n" + "="*70)
print("📋 TEST 4: Complex Structure Validation")
print("="*70)
print("✨ Value: Validate nested structures and add custom business logic")

response = load_response("breeds.list.all.get", {}, api_name="DogAPI")

try:
    validated = validate_breeds_list(response)
    breed_count = len(validated["message"])
    print(f"✅ Contract passed! Found {breed_count} breeds.")
    print(f"   Sample breeds: {list(validated['message'].keys())[:5]}")
except ContractViolationError as e:
    print(f"❌ Contract failed: {e}")
    raise


print("\n" + "="*70)
print("🎉 ALL TESTS PASSED!")
print("="*70)
print("\n💡 KEY DIFFERENTIATORS vs OpenAPI CodeGen:")
print("   1. ✅ Runtime validation of actual API responses")
print("   2. 🔒 PII detection and sanitization")
print("   3. 🎯 Field filtering (only_allow)")
print("   4. 📼 Recording/Replay for deterministic tests")
print("   5. 🛡️ Policy enforcement (GDPR, compliance)")
print("   6. 🚀 No code generation step needed")
print("\n🎯 Use Case: Testing, validation, and runtime safety - NOT a replacement")
print("   for codegen, but a complementary tool for contract testing!")

