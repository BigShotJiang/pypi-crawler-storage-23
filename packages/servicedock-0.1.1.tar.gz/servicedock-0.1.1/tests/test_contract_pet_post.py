from service_agent.test_utils import init_test_runtime, load_response
from service_agent.decorators import contract
from service_agent.errors import ContractViolationError

@contract({
    "expects": {
        "id": "must_be_number",
        "name": "must_be_non_empty_string",
        "status": "must_be_non_empty_string"
    },
    "only_allow": ["id", "name", "status"],
    "idempotent": True
})
def validate_pet_post(resp):
    return resp

def main():
    from service_agent.test_utils import init_test_runtime, load_response, override_contract
    init_test_runtime()
    print(f"🐛 Attached contract: {validate_pet_post._contract_spec}")

    override_contract("pet.post", validate_pet_post._contract_spec)

    response = load_response("pet.post", {"id": 123}, api_name="Petstore")

    print("\n=== ✅ Validating Contract ===")
    try:
        validate_pet_post(response)
        print("✅ Contract passed.")
    except ContractViolationError as e:
        print(f"🚫 Contract failed: {e}")
        raise e
    except Exception as e:
        print(f"💥 Unexpected error: {e}")
        raise e

if __name__ == "__main__":
    main()
