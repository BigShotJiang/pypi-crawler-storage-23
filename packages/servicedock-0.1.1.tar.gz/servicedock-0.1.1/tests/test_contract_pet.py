from service_agent.test_utils import init_test_runtime, load_response
from service_agent.decorators import contract
from service_agent.errors import ContractViolationError

init_test_runtime()

response = load_response("pet.petId.get", {"petId": 1}, api_name="Petstore")

@contract({
    "expects": {
        "id": "must_be_number",
        "name": "must_be_non_empty_string",
        "status": "must_be_non_empty_string"
    },
    "only_allow": ["id", "name", "status", "category", "photoUrls", "tags"]
})
def validate_pet_response(resp):
    return resp

print("=== Contract Test: pet.petId.get_1 ===")
try:
    validate_pet_response(response)
    print("✅ Contract passed.")
except ContractViolationError as e:
    print(e)
    raise e
