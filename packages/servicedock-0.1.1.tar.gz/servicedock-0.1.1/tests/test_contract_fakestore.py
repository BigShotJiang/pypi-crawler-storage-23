from service_agent.test_utils import init_test_runtime, load_response
from service_agent.decorators import contract
from service_agent.errors import ContractViolationError

init_test_runtime()
response = load_response("products.id.get", {"id": 1}, "FakeStore")

@contract({
    "expects": {
        "title": "must_be_non_empty_string",
        "price": "must_be_number",
        "description": "must_be_non_empty_string",
        "category": "must_be_non_empty_string",
        "image": "must_be_non_empty_string"
    }
})
def get_product(resp):
    return resp

print("\n=== Contract Test: fakestore.products.id.get ===")
try:
    get_product(response)
    print("✅ Contract passed.")
except ContractViolationError as e:
    print(f"🚫 Contract failed: {e}")
