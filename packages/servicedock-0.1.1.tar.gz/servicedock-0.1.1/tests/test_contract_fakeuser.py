from service_agent.test_utils import init_test_runtime, load_response
from service_agent.decorators import contract
from service_agent.errors import ContractViolationError

init_test_runtime()
response = load_response("fakeuser.users.list", {})

@contract({
    "expects": {
        "body.0.id": "must_be_number",
        "body.0.name": "must_be_non_empty_string"
    }
})
def get_users(resp):
    return resp

print("Running contract test for fakeuser.users.list")
try:
    get_users(response)
    print("Contract test passed")
except ContractViolationError as e:
    print(f"Contract test failed: {e}")
    raise e
