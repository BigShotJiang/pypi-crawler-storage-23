from service_agent.decorators import contract
from service_agent.errors import ContractViolationError
from service_agent.test_utils import init_test_runtime, load_response

init_test_runtime()
response = load_response("posts.id.get", {"id": 1}, "JSONPlaceholder")

@contract({
    "expects": {
        "title": "must_be_non_empty_string",
        "userId": "must_be_number"
    }
})
def validate_post_response(resp):
    return resp

print("=== Contract Test: posts.id.get_1 ===")
try:
    validate_post_response(response)
    print("✅ Contract passed.")
except ContractViolationError as e:
    print(e)
