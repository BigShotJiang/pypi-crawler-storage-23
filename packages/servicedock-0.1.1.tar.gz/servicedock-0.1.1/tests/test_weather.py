from service_agent import ServiceAgent
from service_agent.decorators import contract

agent = ServiceAgent()

@contract({
    "requires": {
        "city": "must_be_non_empty_string"
    },
    "expects": {
        "current.temperature": "must_be_number",
        "location.name": "must_be_non_empty_string"
    }
})
def get_weather(city):
    return agent.api("Weatherstack").get("current", {
        "query": city
    })

print("\n=== Weatherstack Test ===")
try:
    weather = get_weather("Berlin")
    print(f"🌤️ Weather in {weather['location']['name']}: {weather['current']['temperature']}°C")
except Exception as e:
    print(e)

print("\n=== IPAPI Test ===")
ip = agent.api("IPAPI").get("lookup", {
    "ip": "8.8.8.8"
})
print(f"📍 IP 8.8.8.8 is located in {ip['city']}, {ip['country']}")
