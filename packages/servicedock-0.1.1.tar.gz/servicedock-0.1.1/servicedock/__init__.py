"""
Service Dock public API.

This package re-exports the core runtime from the internal `service_agent` module
so that users can:

    pip install servicedock
    servicedock setup
    from servicedock import ServiceAgent
"""

from service_agent.core import ServiceAgent  # noqa: F401
from service_agent.decorators import contract  # noqa: F401
from service_agent.errors import ContractViolationError  # noqa: F401

__all__ = ["ServiceAgent", "contract", "ContractViolationError"]

__version__ = "0.1.0"

