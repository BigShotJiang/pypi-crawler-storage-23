import argparse
import json
from pathlib import Path
import os
import sys

import requests

from service_agent.agents.schema_agent import load_spec, scaffold_from_spec, write_api_config
from service_agent.agents.recording_agent import save_recording
from service_agent.agents.replay_agent import replay_recording


def main() -> None:
    """
    Service Dock CLI entry point.

    Exposed as the `servicedock` console script.
    """
    parser = argparse.ArgumentParser(
        description="Service Dock — scaffold from OpenAPI, record/replay responses, and enforce runtime contracts & policies."
    )
    subparsers = parser.add_subparsers(dest="command", help="command")

    # Setup wizard (guided flow)
    setup_cmd = subparsers.add_parser(
        "setup",
        help="Interactive setup: plug in API schema URL and get a working service (scaffolds, recordings, optional FastAPI shell)",
    )
    setup_cmd.set_defaults(func=lambda _: None)  # handled below

    # Init command
    init_cmd = subparsers.add_parser("init", help="Add an API from OpenAPI spec (scaffolds + config)")
    init_cmd.add_argument("--url", help="Optional URL to fetch OpenAPI spec from")
    init_cmd.add_argument("--api", required=True, help="Path to OpenAPI spec")

    # Call command
    call_cmd = subparsers.add_parser("call", help="Call an endpoint based on a scaffold and record the response")
    call_cmd.add_argument("name", help="Name of the scaffold (e.g. posts.get)")
    call_cmd.add_argument(
        "extra_args",
        nargs=argparse.REMAINDER,
        help=argparse.SUPPRESS,  # capture remaining arguments as --param value ...
    )

    # Replay command (print a recording)
    replay_cmd = subparsers.add_parser("replay", help="Print a past recording (no HTTP)")
    replay_cmd.add_argument("name", help="Name of the recording (e.g. posts.id.get)")
    replay_cmd.add_argument("--id")

    args = parser.parse_args()

    if args.command == "setup":
        from servicedock.setup import run_setup_wizard

        run_setup_wizard()
        return

    if args.command is None:
        print("Service Dock — no command given.\n")
        print("  Get started:  servicedock setup")
        print("  Manual flow:  servicedock init --api <name> [--url <spec_url>]")
        print("                servicedock call <endpoint> [--param value ...]")
        print("  Help:         servicedock --help")
        return

    if args.command == "init":
        # Specs live under ./service_agent/specs relative to the current working dir
        os.makedirs("service_agent/specs", exist_ok=True)

        # If URL provided, download the spec first
        if getattr(args, "url", None):
            ext = "json" if args.url.endswith(".json") else "yaml"
            spec_path = Path(f"service_agent/specs/{args.api}.{ext}")

            print(f"🌐 Downloading spec from {args.url}")
            res = requests.get(args.url)
            if res.status_code != 200:
                raise Exception(f"Failed to download spec: {res.status_code}")

            with open(spec_path, "w") as f:
                f.write(res.text)

            print(f"✅ Saved spec to {spec_path}")
        else:
            # Fallback to existing local spec
            yaml_path = Path(f"service_agent/specs/{args.api}.yaml")
            json_path = Path(f"service_agent/specs/{args.api}.json")

            if yaml_path.exists():
                spec_path = yaml_path
            elif json_path.exists():
                spec_path = json_path
            else:
                raise FileNotFoundError(
                    f"No spec found for {args.api}. Looked for .yaml and .json in service_agent/specs/"
                )

        spec = load_spec(spec_path)
        scaffold_from_spec(spec, args.api)
        configs_dir = Path("service_agent") / "configs"
        configs_dir.mkdir(parents=True, exist_ok=True)
        write_api_config(spec, args.api, str(configs_dir))

    elif args.command == "replay":
        cli_args = {
            k: v
            for k, v in vars(args).items()
            if k not in ["command", "name"] and v is not None
        }
        replay_recording(args.name, cli_args)

    elif args.command == "call":
        # Endpoint name is the scaffold filename without .json (e.g. pet.petId.get)
        endpoint_name = args.name.rstrip(".json") if args.name.endswith(".json") else args.name
        scaffold_file = Path("scaffolds") / f"{endpoint_name}.json"

        if not scaffold_file.exists():
            print(f"Error: No scaffold found for '{endpoint_name}'.")
            print(f"  Looked for: {scaffold_file}")
            print("  List endpoints: ls scaffolds/")
            sys.exit(1)

        with open(scaffold_file, "r") as f:
            scaffold = json.load(f)

        api_name = scaffold.get("api")
        if not api_name:
            raise ValueError("Scaffold is missing required 'api' field.")

        # Get all parameters from the scaffold
        all_params = {**scaffold.get("params", {}), **scaffold.get("body", {})}

        # Parse the extra arguments
        cli_args = {}
        i = 0
        while i < len(args.extra_args):
            arg = args.extra_args[i]
            if arg.startswith("--"):
                param_name = arg[2:]  # Remove the --
                if i + 1 < len(args.extra_args) and not args.extra_args[i + 1].startswith("--"):
                    value = args.extra_args[i + 1]
                    # Try to parse as JSON if it looks like a JSON string
                    if value.startswith(("[", "{", '"')):
                        try:
                            value = json.loads(value)
                        except json.JSONDecodeError:
                            pass
                    cli_args[param_name] = value
                    i += 2
                else:
                    i += 1
            else:
                i += 1

        # Validate that all required parameters are provided
        for param_name in all_params.keys():
            if param_name not in cli_args:
                print(f"Error: Missing required parameter --{param_name}")
                sys.exit(1)

        from service_agent import ServiceAgent

        agent = ServiceAgent()

        api = agent.api(api_name)
        method = scaffold.get("method", "GET").upper()

        if method == "GET":
            result = api.get(endpoint_name, cli_args)
        elif method == "POST":
            result = api.post(endpoint_name, cli_args)
        else:
            raise ValueError(f"Unsupported method: {method}")

        # Record the request + response
        save_recording(endpoint_name, cli_args, result)

        print("✅ Request successful. Result:")
        print(result)


if __name__ == "__main__":
    main()

