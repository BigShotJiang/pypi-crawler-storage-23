"""
Setup wizard entry point for Service Dock.

This file wraps the existing agentstack_setup.run_setup_wizard so that
the installed `servicedock` package has a stable import path.
"""

from agentstack_setup import run_setup_wizard  # re-export for CLI

__all__ = ["run_setup_wizard"]

