def test_import() -> None:
    import pydjirecord

    assert pydjirecord.__doc__ is not None
