from enum import Enum


class Provider(str, Enum):
    OPENAI = "OPENAI"
    ANTHROPIC = "ANTHROPIC"


SDK_PROVIDER_HEADER_NAME = "X-Scalar-SDK-Provider"
