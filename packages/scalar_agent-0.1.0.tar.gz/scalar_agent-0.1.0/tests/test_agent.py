from scalar_agent import agent_scalar
from scalar_agent.constants import SDK_PROVIDER_HEADER_NAME

TOKEN = "test-token"
INSTALLATION_ID = "test-installation-id"


def test_installation_url():
    scalar = agent_scalar(token=TOKEN)
    installation = scalar.installation(INSTALLATION_ID)
    assert installation._url == f"https://services.scalar.com/vector/mcp/{INSTALLATION_ID}"


def test_installation_url_custom_base():
    scalar = agent_scalar(token=TOKEN, base_url="https://custom.example.com")
    installation = scalar.installation(INSTALLATION_ID)
    assert installation._url == f"https://custom.example.com/vector/mcp/{INSTALLATION_ID}"


def test_installation_url_strips_trailing_slash():
    scalar = agent_scalar(token=TOKEN, base_url="https://services.scalar.com/")
    installation = scalar.installation(INSTALLATION_ID)
    assert installation._url == f"https://services.scalar.com/vector/mcp/{INSTALLATION_ID}"


def test_create_anthropic_mcp():
    installation = agent_scalar(token=TOKEN).installation(INSTALLATION_ID)
    config = installation.create_anthropic_mcp()

    assert config["type"] == "http"
    assert config["url"] == f"https://services.scalar.com/vector/mcp/{INSTALLATION_ID}"
    assert config["headers"]["Authorization"] == TOKEN
    assert config["headers"][SDK_PROVIDER_HEADER_NAME] == "ANTHROPIC"


def test_create_openai_mcp():
    installation = agent_scalar(token=TOKEN).installation(INSTALLATION_ID)
    config = installation.create_openai_mcp()

    assert config["name"] == INSTALLATION_ID
    assert config["params"]["url"] == f"https://services.scalar.com/vector/mcp/{INSTALLATION_ID}"
    assert config["params"]["headers"]["Authorization"] == TOKEN
    assert config["params"]["headers"][SDK_PROVIDER_HEADER_NAME] == "OPENAI"
