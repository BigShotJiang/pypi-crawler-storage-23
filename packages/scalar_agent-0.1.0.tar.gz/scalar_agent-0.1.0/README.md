# Scalar Agent SDK (Python)

Connect your AI agent to Scalar's OpenAPI MCP servers. Provides native integrations for the OpenAI Agents SDK and Anthropic Claude Agent SDK.

## Installation

```bash
pip install scalar-agent
```

With provider extras:

```bash
# For Anthropic
pip install "scalar-agent[anthropic]"

# For OpenAI
pip install "scalar-agent[openai]"

# Both
pip install "scalar-agent[all]"
```

## Setup

```python
from scalar_agent import agent_scalar

scalar = agent_scalar(token="your-personal-token")
installation = scalar.installation("your-installation-id")
```

## Providers

### OpenAI Agents SDK

Returns params for `MCPServerStreamableHttp` from `openai-agents`. The agent runtime handles tool discovery and execution natively.

```python
from scalar_agent import agent_scalar
from agents import Agent, Runner
from agents.mcp import MCPServerStreamableHttp

scalar = agent_scalar(token="your-personal-token")
installation = scalar.installation("your-installation-id")

server = MCPServerStreamableHttp(**installation.create_openai_mcp())
await server.connect()

agent = Agent(name="api-agent", mcp_servers=[server])

result = await Runner.run(agent, "Which APIs are available that let me create a planet?")
print(result.final_output)

await server.cleanup()
```

### Anthropic Claude Agent SDK

Returns an MCP server configuration for `claude_agent_sdk`.

```python
from scalar_agent import agent_scalar
from claude_agent_sdk import query
from claude_agent_sdk.types import ClaudeAgentOptions, ResultMessage

scalar = agent_scalar(token="your-personal-token")
installation = scalar.installation("your-installation-id")

async for message in query(
    prompt="Which APIs are available that let me create a planet?",
    options=ClaudeAgentOptions(
        mcp_servers={"scalar": installation.create_anthropic_mcp()},
        allowed_tools=["mcp__scalar__*"],
    ),
):
    if isinstance(message, ResultMessage):
        print(message.result)
```

## Configuration

| Parameter  | Type  | Description                                                           |
| ---------- | ----- | --------------------------------------------------------------------- |
| `token`    | `str` | Your Scalar Personal Token used to authenticate requests to your MCP  |
| `base_url` | `str` | Base URL of the Scalar MCP server. Defaults to the Scalar environment |
