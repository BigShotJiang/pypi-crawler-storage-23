"""Allow ``python -m sanna.gateway`` to start the gateway."""

from sanna.gateway import main

main()
