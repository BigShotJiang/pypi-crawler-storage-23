"""Sanna shared utilities."""
