"""Shared test fixtures for exokit tests."""

from __future__ import annotations

import pytest

from exokit.core.models import (
    DemoManifest,
    ManifestMeta,
    QuestionnaireAnswers,
    ScaffoldContext,
    WaveDefinition,
)


@pytest.fixture()
def sample_answers() -> QuestionnaireAnswers:
    """Sample questionnaire answers for a Financial Services demo."""
    return QuestionnaireAnswers(
        company="Acme Bank",
        industry="fsi",
        demo_description=(
            "Comprehensive FSI demo spanning all departments with fraud detection and customer 360"
        ),
        catalog="acme_bank_fsi",
        warehouse_id="abc123def456",
        workspace_host="https://adb-1234567890.azuredatabricks.net",
        databricks_profile="DEFAULT",
        lakebase_url=None,
        notification_email="demo@acmebank.com",
    )


@pytest.fixture()
def sample_context(sample_answers: QuestionnaireAnswers) -> ScaffoldContext:
    """Sample scaffold context with computed fields."""
    return ScaffoldContext(
        **sample_answers.model_dump(),
        bundle_name="acme-bank-fsi-demo",
        app_name="acme-bank-fsi-app",
    )


@pytest.fixture()
def sample_manifest() -> DemoManifest:
    """Sample demo manifest for testing."""
    return DemoManifest(
        meta=ManifestMeta(
            company="Acme Bank",
            industry="fsi",
            demo_description="Comprehensive FSI demo",
            generated_at="2026-03-02T00:00:00Z",
            exokit_version="0.1.0",
        ),
        waves=[
            WaveDefinition(
                id=1,
                name="Data Foundation",
                status="pending",
                components=["data_generation", "bronze_pipelines"],
                description="Generate synthetic data and create bronze layer",
            ),
            WaveDefinition(
                id=2,
                name="Silver & Gold",
                status="pending",
                components=["silver_pipelines", "gold_pipelines"],
                description="Transform data through silver and gold layers",
            ),
        ],
        talk_track_hints=["Start with the data lineage story"],
    )
