"""Template rendering validation tests."""
