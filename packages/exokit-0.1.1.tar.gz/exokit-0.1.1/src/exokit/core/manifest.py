"""Manifest builder for exokit.

Creates the 5-wave DemoManifest structure from a ScaffoldContext.
"""

from __future__ import annotations

from datetime import UTC, datetime

import exokit
from exokit.core.models import (
    DemoManifest,
    ManifestMeta,
    ScaffoldContext,
    WaveDefinition,
)

# ---------------------------------------------------------------------------
# Wave definitions — the canonical 5-wave demo build plan
# ---------------------------------------------------------------------------

_WAVE_DEFINITIONS: list[dict[str, object]] = [
    {
        "id": 1,
        "name": "Data Foundation",
        "components": [
            "data_generation",
            "bronze_pipelines",
            "unity_catalog_setup",
        ],
        "description": (
            "Generate synthetic data (structured + unstructured), "
            "create bronze-layer DLT pipelines, and configure Unity Catalog schemas."
        ),
    },
    {
        "id": 2,
        "name": "Silver & Gold Layers",
        "components": [
            "silver_pipelines",
            "gold_pipelines",
            "data_quality_expectations",
        ],
        "description": (
            "Build silver and gold DLT pipelines with data quality expectations "
            "and business-level aggregations."
        ),
    },
    {
        "id": 3,
        "name": "ML & AI",
        "components": [
            "feature_engineering",
            "model_training",
            "model_serving",
            "vector_search",
        ],
        "description": (
            "Train ML models, register in Unity Catalog, deploy to serving endpoints, "
            "and configure vector search for RAG patterns."
        ),
    },
    {
        "id": 4,
        "name": "Dashboards & Genie",
        "components": [
            "ai_bi_dashboards",
            "genie_space",
            "dashboard_deployment",
        ],
        "description": (
            "Create AI/BI dashboards, configure Genie spaces, "
            "and set up automated dashboard deployment."
        ),
    },
    {
        "id": 5,
        "name": "App & Integration",
        "components": [
            "fastapi_backend",
            "react_frontend",
            "agent_integration",
            "end_to_end_testing",
        ],
        "description": (
            "Build the Lakebase-powered FastAPI + React application, "
            "integrate AI agents, and run end-to-end validation."
        ),
    },
]


def build_manifest(context: ScaffoldContext) -> DemoManifest:
    """Build the canonical 5-wave DemoManifest from a ScaffoldContext.

    All waves start in ``"pending"`` status.  The meta block captures the
    company, industry, generation timestamp, and current exokit version.

    Args:
        context: Fully-resolved scaffold context (answers + computed fields).

    Returns:
        A ``DemoManifest`` ready for JSON serialisation.
    """
    meta = ManifestMeta(
        company=context.company,
        industry=context.industry,
        demo_description=context.demo_description,
        generated_at=datetime.now(tz=UTC).isoformat(),
        exokit_version=exokit.__version__,
    )

    waves = [
        WaveDefinition(
            id=w["id"],  # type: ignore[arg-type]
            name=w["name"],  # type: ignore[arg-type]
            status="pending",
            components=w["components"],  # type: ignore[arg-type]
            description=w["description"],  # type: ignore[arg-type]
        )
        for w in _WAVE_DEFINITIONS
    ]

    return DemoManifest(meta=meta, waves=waves)
