"""Question definitions as data + validation.

No UI code — just question definitions, compute functions, and validation.
JSON-serializable for V2 web forms.
"""

from __future__ import annotations

from collections.abc import Callable

from exokit.core.models import Question, QuestionnaireAnswers, ScaffoldContext


def _compute_catalog(answers: dict[str, str]) -> str:
    """Compute default catalog name from company and industry."""
    company = answers.get("company", "").strip().lower().replace(" ", "_")
    industry = answers.get("industry", "general").lower()
    if not company or company == industry:
        return f"{industry}_demo"
    return f"{company}_{industry}"


# Named compute functions registry: key -> callable
DEFAULT_COMPUTERS: dict[str, Callable[[dict[str, str]], str]] = {
    "catalog_from_company_industry": _compute_catalog,
}


QUESTIONS: list[Question] = [
    Question(
        id="company",
        type="text",
        prompt="Company name",
        required=True,
        help_text="The customer/company name for this demo",
    ),
    Question(
        id="industry",
        type="select",
        prompt="Industry vertical",
        required=True,
        options=["fsi", "telecom", "retail", "healthcare", "manufacturing"],
        help_text="Select the industry vertical for this demo",
    ),
    Question(
        id="catalog",
        type="text",
        prompt="Unity Catalog name",
        required=True,
        default_from="catalog_from_company_industry",
        help_text="Unity Catalog name (defaults to company_industry)",
    ),
    Question(
        id="warehouse_id",
        type="text",
        prompt="SQL Warehouse ID",
        required=True,
        help_text="Databricks SQL Warehouse ID for queries and dashboards",
    ),
    Question(
        id="workspace_host",
        type="text",
        prompt="Workspace host URL",
        required=True,
        help_text="Databricks workspace host (e.g. https://adb-1234.azuredatabricks.net)",
    ),
    Question(
        id="databricks_profile",
        type="text",
        prompt="Databricks CLI profile",
        required=False,
        default="DEFAULT",
        help_text="Databricks CLI profile name (optional, defaults to DEFAULT)",
    ),
    Question(
        id="lakebase_url",
        type="text",
        prompt="Lakebase URL",
        required=False,
        help_text="Lakebase connection URL (optional, for app scaffolding)",
    ),
    Question(
        id="notification_email",
        type="text",
        prompt="Notification email",
        required=True,
        help_text="Email for job notifications and alerts",
    ),
]


def compute_default(question: Question, answers: dict[str, str]) -> str | None:
    """Compute the default value for a question given current answers.

    Returns the static default if no compute function is registered,
    or the computed default if default_from references a known function.
    """
    if question.default_from is not None:
        compute_fn = DEFAULT_COMPUTERS.get(question.default_from)
        if compute_fn is not None:
            return compute_fn(answers)
    return question.default


def build_context(answers: QuestionnaireAnswers) -> ScaffoldContext:
    """Create ScaffoldContext from raw QuestionnaireAnswers.

    Computes derived fields (bundle_name, app_name) from the raw answers.
    If company is empty or matches the industry, use industry-only naming.
    """
    company_slug = answers.company.lower().replace(" ", "-")
    industry = answers.industry.lower()

    # Avoid duplication like "fsi-fsi-demo" when company == industry
    if not company_slug or company_slug == industry:
        bundle_name = f"{industry}-demo"
        app_name = f"{industry}-app"
    else:
        bundle_name = f"{company_slug}-{industry}-demo"
        app_name = f"{company_slug}-{industry}-app"

    return ScaffoldContext(
        **answers.model_dump(),
        bundle_name=bundle_name,
        app_name=app_name,
    )
