"""Core library for exokit — reusable by CLI (V1) and web app (V2)."""
