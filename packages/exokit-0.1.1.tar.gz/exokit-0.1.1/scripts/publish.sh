#!/usr/bin/env bash
# Exokit — Publish to PyPI
#
# Usage:
#   ./scripts/publish.sh                    # Publish current version to PyPI
#   ./scripts/publish.sh --test             # Publish to TestPyPI first
#   ./scripts/publish.sh --bump patch       # Bump 0.1.0 → 0.1.1, then publish
#   ./scripts/publish.sh --bump minor       # Bump 0.1.0 → 0.2.0, then publish
#   ./scripts/publish.sh --bump major       # Bump 0.1.0 → 1.0.0, then publish
#   UV_PUBLISH_TOKEN=pypi-xxx ./scripts/publish.sh  # Token via env var
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/.."

VERSION_FILE="src/exokit/__init__.py"
TEST_PYPI=false
BUMP=""

# Parse args
while [[ $# -gt 0 ]]; do
  case "$1" in
    --test) TEST_PYPI=true; shift ;;
    --bump) BUMP="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# Read current version
CURRENT_VERSION=$(python3 -c "
import re
with open('$VERSION_FILE') as f:
    m = re.search(r'__version__\s*=\s*\"(.+?)\"', f.read())
    print(m.group(1) if m else 'unknown')
")
echo "========================================="
echo "Exokit — Publish to PyPI"
echo "Current version: $CURRENT_VERSION"
echo "========================================="

# Bump version if requested
if [ -n "$BUMP" ]; then
  IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"
  case "$BUMP" in
    patch) PATCH=$((PATCH + 1)) ;;
    minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
    major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
    *) echo "ERROR: --bump must be patch, minor, or major"; exit 1 ;;
  esac
  NEW_VERSION="$MAJOR.$MINOR.$PATCH"
  echo ""
  echo "Bumping version: $CURRENT_VERSION → $NEW_VERSION"
  sed -i '' "s/__version__ = \"$CURRENT_VERSION\"/__version__ = \"$NEW_VERSION\"/" "$VERSION_FILE"
  CURRENT_VERSION="$NEW_VERSION"
  echo "Updated $VERSION_FILE"
fi

# Step 1: Quality gates
echo ""
echo "=== Step 1: Quality gates ==="
uv run ruff check src/ tests/
uv run ruff format --check src/ tests/
uv run mypy src/exokit/
uv run pytest tests/ -q --tb=short
echo "All gates passed."

# Step 2: Clean build
echo ""
echo "=== Step 2: Build v$CURRENT_VERSION ==="
rm -rf dist/
uv build
echo "Built:"
ls -lh dist/*.whl dist/*.tar.gz

# Step 3: Verify package
echo ""
echo "=== Step 3: Verify package ==="
TEMPLATES=$(unzip -l dist/*.whl 2>/dev/null | grep -c "\.j2" || echo "0")
PY_FILES=$(unzip -l dist/*.whl 2>/dev/null | grep -c "\.py" || echo "0")
echo "  Templates: $TEMPLATES"
echo "  Python files: $PY_FILES"
if [ "$TEMPLATES" -lt 40 ]; then
  echo "ERROR: Expected 40+ templates, got $TEMPLATES. Aborting."
  exit 1
fi

# Step 4: Publish
echo ""
if [ "$TEST_PYPI" = true ]; then
  echo "=== Step 4: Publish to TestPyPI ==="
  uv publish --publish-url https://test.pypi.org/legacy/
  echo ""
  echo "Verify:  https://test.pypi.org/project/exokit/"
  echo "Install: uv tool install --index-url https://test.pypi.org/simple/ exokit"
else
  echo "=== Step 4: Publish to PyPI ==="
  uv publish
  echo ""
  echo "Verify:  https://pypi.org/project/exokit/"
  echo "Install: uv tool install exokit"
fi

echo ""
echo "========================================="
echo "Published exokit v$CURRENT_VERSION"
echo "========================================="
