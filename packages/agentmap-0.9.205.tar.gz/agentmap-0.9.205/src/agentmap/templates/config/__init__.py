"""
AgentMap configuration templates.

This module contains template configuration files that can be copied to
user projects to set up AgentMap with default settings.
"""
