<h3 align="center">
  <a name="readme-top"></a>
  <img
    src="https://docs.arcade.dev/images/logo/arcade-logo.png"
  >
</h3>
<div align="center">
  <h1>⚠️ DEPRECATED ⚠️</h1>
  <h3>crewai-arcade is no longer maintained</h3>
</div>

---

## Important Notice

**This package has been deprecated and is no longer maintained.**

The `crewai-arcade` package is no longer needed. Arcade now provides better ways to integrate with your AI applications.

## What Should I Use Instead?

Please visit **[docs.arcade.dev](https://docs.arcade.dev)** for the latest documentation on how to integrate Arcade tools into your applications.

## Migration Guide

If you were previously using `crewai-arcade`, we recommend:

1. Visit [docs.arcade.dev](https://docs.arcade.dev) to learn about the new integration options

---

<p align="center">
  Thank you for using crewai-arcade. We hope to see you using Arcade's new integrations!
</p>
