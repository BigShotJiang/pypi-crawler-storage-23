r'''
# `snowflake_semantic_view`

Refer to the Terraform Registry for docs: [`snowflake_semantic_view`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class SemanticView(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticView",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view snowflake_semantic_view}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        tables: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
        comment: typing.Optional[builtins.str] = None,
        dimensions: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        facts: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        metrics: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]]] = None,
        relationships: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["SemanticViewTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view snowflake_semantic_view} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param database: The database in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#database SemanticView#database}
        :param name: Specifies the identifier for the semantic view; must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#name SemanticView#name}
        :param schema: The schema in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#schema SemanticView#schema}
        :param tables: tables block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#tables SemanticView#tables}
        :param comment: Specifies a comment for the semantic view. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param dimensions: dimensions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        :param facts: facts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#facts SemanticView#facts}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#id SemanticView#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param metrics: metrics block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        :param relationships: relationships block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__621c421f0546997d503161fd3a89f458f721951fc8c37b96729bd3e2113f2e74)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = SemanticViewConfig(
            database=database,
            name=name,
            schema=schema,
            tables=tables,
            comment=comment,
            dimensions=dimensions,
            facts=facts,
            id=id,
            metrics=metrics,
            relationships=relationships,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a SemanticView resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the SemanticView to import.
        :param import_from_id: The id of the existing SemanticView that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the SemanticView to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e20988390c5e468998be448cb2059e9ffc9ff6d0007a7483159e2d81135c1a6a)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putDimensions")
    def put_dimensions(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83782870b70c9ca05f52e21fd84ca1e5a0c5c862dfab39dd8580335c5e8abb26)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putDimensions", [value]))

    @jsii.member(jsii_name="putFacts")
    def put_facts(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25eb63f1581a1ab4ba8e2de2d735dc6c3e75d4a027b144044d96b60d4fb1d245)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putFacts", [value]))

    @jsii.member(jsii_name="putMetrics")
    def put_metrics(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__67f3acb957a63bad49fe8bca087ac6a81d036b147950f980b45ad5e9cb57f4f5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putMetrics", [value]))

    @jsii.member(jsii_name="putRelationships")
    def put_relationships(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fdcc0cb7e193d7d472ec151350730304ef01d7a277245d028df507b964eccafd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRelationships", [value]))

    @jsii.member(jsii_name="putTables")
    def put_tables(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4be1f14c7dc4c85eea265d998bd20c71c3ffa6c88d7fadd703e3c09275465225)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putTables", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#create SemanticView#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#delete SemanticView#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#read SemanticView#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#update SemanticView#update}.
        '''
        value = SemanticViewTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetDimensions")
    def reset_dimensions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDimensions", []))

    @jsii.member(jsii_name="resetFacts")
    def reset_facts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFacts", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetMetrics")
    def reset_metrics(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetrics", []))

    @jsii.member(jsii_name="resetRelationships")
    def reset_relationships(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRelationships", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="dimensions")
    def dimensions(self) -> "SemanticViewDimensionsList":
        return typing.cast("SemanticViewDimensionsList", jsii.get(self, "dimensions"))

    @builtins.property
    @jsii.member(jsii_name="facts")
    def facts(self) -> "SemanticViewFactsList":
        return typing.cast("SemanticViewFactsList", jsii.get(self, "facts"))

    @builtins.property
    @jsii.member(jsii_name="fullyQualifiedName")
    def fully_qualified_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullyQualifiedName"))

    @builtins.property
    @jsii.member(jsii_name="metrics")
    def metrics(self) -> "SemanticViewMetricsList":
        return typing.cast("SemanticViewMetricsList", jsii.get(self, "metrics"))

    @builtins.property
    @jsii.member(jsii_name="relationships")
    def relationships(self) -> "SemanticViewRelationshipsList":
        return typing.cast("SemanticViewRelationshipsList", jsii.get(self, "relationships"))

    @builtins.property
    @jsii.member(jsii_name="showOutput")
    def show_output(self) -> "SemanticViewShowOutputList":
        return typing.cast("SemanticViewShowOutputList", jsii.get(self, "showOutput"))

    @builtins.property
    @jsii.member(jsii_name="tables")
    def tables(self) -> "SemanticViewTablesList":
        return typing.cast("SemanticViewTablesList", jsii.get(self, "tables"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "SemanticViewTimeoutsOutputReference":
        return typing.cast("SemanticViewTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="dimensionsInput")
    def dimensions_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]], jsii.get(self, "dimensionsInput"))

    @builtins.property
    @jsii.member(jsii_name="factsInput")
    def facts_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]], jsii.get(self, "factsInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsInput")
    def metrics_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]], jsii.get(self, "metricsInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipsInput")
    def relationships_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]], jsii.get(self, "relationshipsInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="tablesInput")
    def tables_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]], jsii.get(self, "tablesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3ee26a7f4d5a1e286c5f98829c89f197ea859e568d47aeed3755d092a4b7e65)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__354df98ae5f13d314f17b511f524ebf7eaa5ebedad3f86a01cab81d7e9c55495)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ffae480d867107d395f55e9e819c6efabc62ad18dba575504aeb1073aed63fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13889e20ade931d97d7e3b2a9921e9044f655bf5b7f495750c96b4563a69b81f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1723ece5fdb2a4da407763747372d2b598673bba8f3bcb21f157b5cbd45737cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "database": "database",
        "name": "name",
        "schema": "schema",
        "tables": "tables",
        "comment": "comment",
        "dimensions": "dimensions",
        "facts": "facts",
        "id": "id",
        "metrics": "metrics",
        "relationships": "relationships",
        "timeouts": "timeouts",
    },
)
class SemanticViewConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        tables: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
        comment: typing.Optional[builtins.str] = None,
        dimensions: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        facts: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        metrics: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]]] = None,
        relationships: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["SemanticViewTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param database: The database in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#database SemanticView#database}
        :param name: Specifies the identifier for the semantic view; must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#name SemanticView#name}
        :param schema: The schema in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#schema SemanticView#schema}
        :param tables: tables block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#tables SemanticView#tables}
        :param comment: Specifies a comment for the semantic view. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param dimensions: dimensions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        :param facts: facts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#facts SemanticView#facts}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#id SemanticView#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param metrics: metrics block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        :param relationships: relationships block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(timeouts, dict):
            timeouts = SemanticViewTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89157a14d448ee09cdc12c969b1653f28c75c334e153878a099bcaab451a1622)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument tables", value=tables, expected_type=type_hints["tables"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
            check_type(argname="argument facts", value=facts, expected_type=type_hints["facts"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument metrics", value=metrics, expected_type=type_hints["metrics"])
            check_type(argname="argument relationships", value=relationships, expected_type=type_hints["relationships"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "database": database,
            "name": name,
            "schema": schema,
            "tables": tables,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if comment is not None:
            self._values["comment"] = comment
        if dimensions is not None:
            self._values["dimensions"] = dimensions
        if facts is not None:
            self._values["facts"] = facts
        if id is not None:
            self._values["id"] = id
        if metrics is not None:
            self._values["metrics"] = metrics
        if relationships is not None:
            self._values["relationships"] = relationships
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def database(self) -> builtins.str:
        '''The database in which to create the semantic view.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#database SemanticView#database}
        '''
        result = self._values.get("database")
        assert result is not None, "Required property 'database' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Specifies the identifier for the semantic view;

        must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#name SemanticView#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> builtins.str:
        '''The schema in which to create the semantic view.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#schema SemanticView#schema}
        '''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def tables(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]:
        '''tables block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#tables SemanticView#tables}
        '''
        result = self._values.get("tables")
        assert result is not None, "Required property 'tables' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]], result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the semantic view.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def dimensions(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]]:
        '''dimensions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        '''
        result = self._values.get("dimensions")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]], result)

    @builtins.property
    def facts(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]]:
        '''facts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#facts SemanticView#facts}
        '''
        result = self._values.get("facts")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#id SemanticView#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metrics(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]]:
        '''metrics block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        '''
        result = self._values.get("metrics")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]], result)

    @builtins.property
    def relationships(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]]:
        '''relationships block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        '''
        result = self._values.get("relationships")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["SemanticViewTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["SemanticViewTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewDimensions",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewDimensions:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the dimension, including the table name and a unique identifier for the dimension: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__deacbc56485df5bf1c6482e554030de73a2d01011ddfc1dcf305732f3b007ff9)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the dimension, including the table name and a unique identifier for the dimension: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewDimensions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewDimensionsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewDimensionsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee247ed2743a62cba6d8671993402d88040305d8603271e76e5ddd4e204370c5)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewDimensionsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c16c965dafa685b4661ba0b63fb2def635e51db65de68584398264aa03ac281)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewDimensionsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e20b07c480cbd705ead37aa0b45506908129e05d2ea9389fc06309fa129134b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97876b872094cb918dd26482174b79a84a019b66f0c56cd6ba14186613d86745)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a61651fe1cbef364306a2e588f68ce682128d0e8846d19baae264785c47e5476)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewDimensions"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b2382d1f25d577b620d384078aa8c17658f18daf33e8c4862accf7457ee2740)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewDimensionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewDimensionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6921dd81918d8a7eacb1f54a09f64ca1f7976660a34e3aea4a6d37583b996550)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02f6f057fb5eaac049cbe9d4264b9e6fdef0dea4b529b6d22ed01243622f5235)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f834c240895a9bb2d4a3db8c5ee06bb908905991522377fb6938ef78155993d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40e790b3b76f90f293424f5d91aa927b855dd99976f30a07ca1498c38967896d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e79cdcd204f7259ad458881d4f9ae8722a89d3e1609ae543d174309161b7de6c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewDimensions"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewDimensions"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewDimensions"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__afdefb6a3c4ac64c616a386e191de0a30b06d0a05068a79b7b7544b53b013e50)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewFacts",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewFacts:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the fact, including the table name and a unique identifier for the fact: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2622c4143bc411f11ab7065fe03c5f0615e227806e45de306cae1c54e56c39f)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the fact, including the table name and a unique identifier for the fact: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewFacts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewFactsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewFactsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e6b7a663a6da10c17f9063df073a69d00cb24fff316329c6f78363626a3addb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewFactsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86842f48bfda761c810969f7e370c467f1d8b563197b03937fdead5845ab9e0a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewFactsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57290199e87b055a02c15873591db098697c24a0593458e96900390d5c823059)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c77fc006213d607cc1961d44ddf952d6ba2bba9854fdb6b41620fc5c3250fa6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f68cfb987e768b022d4510801e4e974e71e260a6f57994f7588cbe6ff15a82af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewFacts"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9873b91d71721f656564a96c9d7f907ed7f426f64ee5ae7cbe9eeaea34b51a67)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewFactsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewFactsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3d484870bc74d79e72ffc8c4a3504136d0c8d079690f758d5a5d565552bd3e56)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bbd0497a6f34598cd7277bcdcdca77c21440d0c3a1f2155df2eb1d7eb409716)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80643fb7b732b443502ec849cf121a6640d2bbb91f732ffd27234b173109dbf1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b64bfd32660d6ffc78bdb3936ab80a545fac83fb695ab1e88b2e945150b6bd49)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1036a4e8bc26a187f5f3e55080456d274e974394d31adeb8570d5a5ba988ec5f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewFacts"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewFacts"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewFacts"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f18dd71db9c6ad4e0d94afb9454729c199921c09c276ee7e624004f89859c6d6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetrics",
    jsii_struct_bases=[],
    name_mapping={
        "semantic_expression": "semanticExpression",
        "window_function": "windowFunction",
    },
)
class SemanticViewMetrics:
    def __init__(
        self,
        *,
        semantic_expression: typing.Optional[typing.Union["SemanticViewMetricsSemanticExpression", typing.Dict[builtins.str, typing.Any]]] = None,
        window_function: typing.Optional[typing.Union["SemanticViewMetricsWindowFunction", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param semantic_expression: semantic_expression block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#semantic_expression SemanticView#semantic_expression}
        :param window_function: window_function block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#window_function SemanticView#window_function}
        '''
        if isinstance(semantic_expression, dict):
            semantic_expression = SemanticViewMetricsSemanticExpression(**semantic_expression)
        if isinstance(window_function, dict):
            window_function = SemanticViewMetricsWindowFunction(**window_function)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0faa6cb74051c7eabca10b45ec1a882f0b50a0e30ea849acbfbda2380387b0c4)
            check_type(argname="argument semantic_expression", value=semantic_expression, expected_type=type_hints["semantic_expression"])
            check_type(argname="argument window_function", value=window_function, expected_type=type_hints["window_function"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if semantic_expression is not None:
            self._values["semantic_expression"] = semantic_expression
        if window_function is not None:
            self._values["window_function"] = window_function

    @builtins.property
    def semantic_expression(
        self,
    ) -> typing.Optional["SemanticViewMetricsSemanticExpression"]:
        '''semantic_expression block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#semantic_expression SemanticView#semantic_expression}
        '''
        result = self._values.get("semantic_expression")
        return typing.cast(typing.Optional["SemanticViewMetricsSemanticExpression"], result)

    @builtins.property
    def window_function(self) -> typing.Optional["SemanticViewMetricsWindowFunction"]:
        '''window_function block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#window_function SemanticView#window_function}
        '''
        result = self._values.get("window_function")
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunction"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetrics(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f78511c0707b1028a8657945f2040982298c3f5cd490e8e0a84c21055ea3c4ef)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewMetricsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d310e8b024939bb6590e333683b902fa4ccadb47fc741e845e8de5b8b537dc4c)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewMetricsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4881adb663bc185579b06ec2aa9d11af5e92fa08cbda422470e69974d71357a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2f0e747beaac738926be87f19175b7db72c577463cb48f73e888b7b5e0ba0c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94fbedcd9200ffc9b860dd442f7cf452c5633734ed1e2dacdc6bdf944fe03413)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewMetrics"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6dca92f70d9229412ca7429b3bae9fce8a8fd8f90ffaada6e92f77dbf50322af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewMetricsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7e00a80b7b34dc1b44e155ad3fb1e80910cab5fb4deec1da23b598e40047672)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putSemanticExpression")
    def put_semantic_expression(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for this semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        value = SemanticViewMetricsSemanticExpression(
            qualified_expression_name=qualified_expression_name,
            sql_expression=sql_expression,
            comment=comment,
            synonym=synonym,
        )

        return typing.cast(None, jsii.invoke(self, "putSemanticExpression", [value]))

    @jsii.member(jsii_name="putWindowFunction")
    def put_window_function(
        self,
        *,
        over_clause: typing.Union["SemanticViewMetricsWindowFunctionOverClause", typing.Dict[builtins.str, typing.Any]],
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
    ) -> None:
        '''
        :param over_clause: over_clause block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        value = SemanticViewMetricsWindowFunction(
            over_clause=over_clause,
            qualified_expression_name=qualified_expression_name,
            sql_expression=sql_expression,
        )

        return typing.cast(None, jsii.invoke(self, "putWindowFunction", [value]))

    @jsii.member(jsii_name="resetSemanticExpression")
    def reset_semantic_expression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSemanticExpression", []))

    @jsii.member(jsii_name="resetWindowFunction")
    def reset_window_function(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWindowFunction", []))

    @builtins.property
    @jsii.member(jsii_name="semanticExpression")
    def semantic_expression(
        self,
    ) -> "SemanticViewMetricsSemanticExpressionOutputReference":
        return typing.cast("SemanticViewMetricsSemanticExpressionOutputReference", jsii.get(self, "semanticExpression"))

    @builtins.property
    @jsii.member(jsii_name="windowFunction")
    def window_function(self) -> "SemanticViewMetricsWindowFunctionOutputReference":
        return typing.cast("SemanticViewMetricsWindowFunctionOutputReference", jsii.get(self, "windowFunction"))

    @builtins.property
    @jsii.member(jsii_name="semanticExpressionInput")
    def semantic_expression_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsSemanticExpression"]:
        return typing.cast(typing.Optional["SemanticViewMetricsSemanticExpression"], jsii.get(self, "semanticExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="windowFunctionInput")
    def window_function_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsWindowFunction"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunction"], jsii.get(self, "windowFunctionInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewMetrics"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewMetrics"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewMetrics"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aebd2dad08f3888748b639c66784ace15a06835be9f1f685fd5521f37b73a537)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsSemanticExpression",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewMetricsSemanticExpression:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for this semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a798273fa0ed47444102bf7b99a05ef1a671d2848af9bf715536d8e743b73fd6)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the metric.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the semantic expression.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for this semantic expression.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsSemanticExpression(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsSemanticExpressionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsSemanticExpressionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8749130a7c6d59b8e1d96d1e4b33e71f1bdee0b69efa7aa4aed3e9d5d4d8523b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1a8b57cd5ea86d8886d29be3c8f7c399e2b178dbff06dfac58ba3f9bf304d7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1feb4a3b32718fb745b84b8f3dd8934711558d7255a180850832a06d94565db5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e08a6b93de9818b993f10fe15a3296cac65907edc83eadd305da6eee03b30f66)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a8688a9cea0fcc575c9260309f01b1012eb5930d98818f7fd288884f1cf3f03)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["SemanticViewMetricsSemanticExpression"]:
        return typing.cast(typing.Optional["SemanticViewMetricsSemanticExpression"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["SemanticViewMetricsSemanticExpression"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55f297f37716ef9977023c664b62a62a4175b4b9bb3e87f841f61bc34f0b9e52)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsWindowFunction",
    jsii_struct_bases=[],
    name_mapping={
        "over_clause": "overClause",
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
    },
)
class SemanticViewMetricsWindowFunction:
    def __init__(
        self,
        *,
        over_clause: typing.Union["SemanticViewMetricsWindowFunctionOverClause", typing.Dict[builtins.str, typing.Any]],
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
    ) -> None:
        '''
        :param over_clause: over_clause block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        if isinstance(over_clause, dict):
            over_clause = SemanticViewMetricsWindowFunctionOverClause(**over_clause)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6164d848271697d27bc6d250e3272102a66d4d6d8433bdcad616dbd1567ea7ea)
            check_type(argname="argument over_clause", value=over_clause, expected_type=type_hints["over_clause"])
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "over_clause": over_clause,
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }

    @builtins.property
    def over_clause(self) -> "SemanticViewMetricsWindowFunctionOverClause":
        '''over_clause block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        '''
        result = self._values.get("over_clause")
        assert result is not None, "Required property 'over_clause' is missing"
        return typing.cast("SemanticViewMetricsWindowFunctionOverClause", result)

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsWindowFunction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsWindowFunctionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__741884a872c0cc2adfa7db5d66f54e75817e4619eed24ce0d1019b64dedd13ce)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putOverClause")
    def put_over_clause(
        self,
        *,
        order_by: typing.Optional[builtins.str] = None,
        partition_by: typing.Optional[builtins.str] = None,
        window_frame_clause: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param order_by: Specifies an order by clause. It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        :param partition_by: Specifies a partition by clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        :param window_frame_clause: Specifies a window frame clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        value = SemanticViewMetricsWindowFunctionOverClause(
            order_by=order_by,
            partition_by=partition_by,
            window_frame_clause=window_frame_clause,
        )

        return typing.cast(None, jsii.invoke(self, "putOverClause", [value]))

    @builtins.property
    @jsii.member(jsii_name="overClause")
    def over_clause(
        self,
    ) -> "SemanticViewMetricsWindowFunctionOverClauseOutputReference":
        return typing.cast("SemanticViewMetricsWindowFunctionOverClauseOutputReference", jsii.get(self, "overClause"))

    @builtins.property
    @jsii.member(jsii_name="overClauseInput")
    def over_clause_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsWindowFunctionOverClause"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunctionOverClause"], jsii.get(self, "overClauseInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60e45771c3ff835cd7d580c8b86b4bebd7c0db8af1fd5b178d957381150af378)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ed4524f60b2e60f551cf736eec3c2e4b56fce322a9b876abf646f998a1b8fa1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["SemanticViewMetricsWindowFunction"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunction"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["SemanticViewMetricsWindowFunction"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e00af931d03115cbc6e9b9b2d6b1900596b71e7fffcaff2a5375a75e9b7842f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOverClause",
    jsii_struct_bases=[],
    name_mapping={
        "order_by": "orderBy",
        "partition_by": "partitionBy",
        "window_frame_clause": "windowFrameClause",
    },
)
class SemanticViewMetricsWindowFunctionOverClause:
    def __init__(
        self,
        *,
        order_by: typing.Optional[builtins.str] = None,
        partition_by: typing.Optional[builtins.str] = None,
        window_frame_clause: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param order_by: Specifies an order by clause. It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        :param partition_by: Specifies a partition by clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        :param window_frame_clause: Specifies a window frame clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a34b5b429dbf12254cfb1330b00f4bc198dc21b895fcfd71d1a0ed6306c3538e)
            check_type(argname="argument order_by", value=order_by, expected_type=type_hints["order_by"])
            check_type(argname="argument partition_by", value=partition_by, expected_type=type_hints["partition_by"])
            check_type(argname="argument window_frame_clause", value=window_frame_clause, expected_type=type_hints["window_frame_clause"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if order_by is not None:
            self._values["order_by"] = order_by
        if partition_by is not None:
            self._values["partition_by"] = partition_by
        if window_frame_clause is not None:
            self._values["window_frame_clause"] = window_frame_clause

    @builtins.property
    def order_by(self) -> typing.Optional[builtins.str]:
        '''Specifies an order by clause.

        It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        '''
        result = self._values.get("order_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def partition_by(self) -> typing.Optional[builtins.str]:
        '''Specifies a partition by clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        '''
        result = self._values.get("partition_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def window_frame_clause(self) -> typing.Optional[builtins.str]:
        '''Specifies a window frame clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        result = self._values.get("window_frame_clause")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsWindowFunctionOverClause(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsWindowFunctionOverClauseOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOverClauseOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32faed80dfae0fba99c0a52ba36153a94f79f11ffc6823cdd589aad780a09a68)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetOrderBy")
    def reset_order_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrderBy", []))

    @jsii.member(jsii_name="resetPartitionBy")
    def reset_partition_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPartitionBy", []))

    @jsii.member(jsii_name="resetWindowFrameClause")
    def reset_window_frame_clause(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWindowFrameClause", []))

    @builtins.property
    @jsii.member(jsii_name="orderByInput")
    def order_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "orderByInput"))

    @builtins.property
    @jsii.member(jsii_name="partitionByInput")
    def partition_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "partitionByInput"))

    @builtins.property
    @jsii.member(jsii_name="windowFrameClauseInput")
    def window_frame_clause_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "windowFrameClauseInput"))

    @builtins.property
    @jsii.member(jsii_name="orderBy")
    def order_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "orderBy"))

    @order_by.setter
    def order_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b5a8f8a8c942b43215264e07392ce793982e3f663a363b75daf36abe5655453)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "orderBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="partitionBy")
    def partition_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "partitionBy"))

    @partition_by.setter
    def partition_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__386e3e15ff25cc9b7e799ff383e62594a5d092e6c7c9639f3742c339a7e58d1e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "partitionBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="windowFrameClause")
    def window_frame_clause(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "windowFrameClause"))

    @window_frame_clause.setter
    def window_frame_clause(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a510be84776a8d66daff07f5e053b3f1bfea077d0d6284097c13d7ff8e8a10e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "windowFrameClause", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["SemanticViewMetricsWindowFunctionOverClause"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunctionOverClause"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["SemanticViewMetricsWindowFunctionOverClause"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b56f0ce4b56d417286759e5e93c82030fce58120898976b759ef9cd83545a72)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationships",
    jsii_struct_bases=[],
    name_mapping={
        "referenced_table_name_or_alias": "referencedTableNameOrAlias",
        "relationship_columns": "relationshipColumns",
        "table_name_or_alias": "tableNameOrAlias",
        "referenced_relationship_columns": "referencedRelationshipColumns",
        "relationship_identifier": "relationshipIdentifier",
    },
)
class SemanticViewRelationships:
    def __init__(
        self,
        *,
        referenced_table_name_or_alias: typing.Union["SemanticViewRelationshipsReferencedTableNameOrAlias", typing.Dict[builtins.str, typing.Any]],
        relationship_columns: typing.Sequence[builtins.str],
        table_name_or_alias: typing.Union["SemanticViewRelationshipsTableNameOrAlias", typing.Dict[builtins.str, typing.Any]],
        referenced_relationship_columns: typing.Optional[typing.Sequence[builtins.str]] = None,
        relationship_identifier: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param referenced_table_name_or_alias: referenced_table_name_or_alias block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#referenced_table_name_or_alias SemanticView#referenced_table_name_or_alias}
        :param relationship_columns: Specifies one or more columns in the first logical table that refers to columns in another logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationship_columns SemanticView#relationship_columns}
        :param table_name_or_alias: table_name_or_alias block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name_or_alias SemanticView#table_name_or_alias}
        :param referenced_relationship_columns: Specifies one or more columns in the second logical table that are referred to by the first logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#referenced_relationship_columns SemanticView#referenced_relationship_columns}
        :param relationship_identifier: Specifies an optional identifier for the relationship. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationship_identifier SemanticView#relationship_identifier}
        '''
        if isinstance(referenced_table_name_or_alias, dict):
            referenced_table_name_or_alias = SemanticViewRelationshipsReferencedTableNameOrAlias(**referenced_table_name_or_alias)
        if isinstance(table_name_or_alias, dict):
            table_name_or_alias = SemanticViewRelationshipsTableNameOrAlias(**table_name_or_alias)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8fc267f0ddbbaa6a5a82ca1146ede627361802980043f15afd166fa04df7ab8b)
            check_type(argname="argument referenced_table_name_or_alias", value=referenced_table_name_or_alias, expected_type=type_hints["referenced_table_name_or_alias"])
            check_type(argname="argument relationship_columns", value=relationship_columns, expected_type=type_hints["relationship_columns"])
            check_type(argname="argument table_name_or_alias", value=table_name_or_alias, expected_type=type_hints["table_name_or_alias"])
            check_type(argname="argument referenced_relationship_columns", value=referenced_relationship_columns, expected_type=type_hints["referenced_relationship_columns"])
            check_type(argname="argument relationship_identifier", value=relationship_identifier, expected_type=type_hints["relationship_identifier"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "referenced_table_name_or_alias": referenced_table_name_or_alias,
            "relationship_columns": relationship_columns,
            "table_name_or_alias": table_name_or_alias,
        }
        if referenced_relationship_columns is not None:
            self._values["referenced_relationship_columns"] = referenced_relationship_columns
        if relationship_identifier is not None:
            self._values["relationship_identifier"] = relationship_identifier

    @builtins.property
    def referenced_table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsReferencedTableNameOrAlias":
        '''referenced_table_name_or_alias block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#referenced_table_name_or_alias SemanticView#referenced_table_name_or_alias}
        '''
        result = self._values.get("referenced_table_name_or_alias")
        assert result is not None, "Required property 'referenced_table_name_or_alias' is missing"
        return typing.cast("SemanticViewRelationshipsReferencedTableNameOrAlias", result)

    @builtins.property
    def relationship_columns(self) -> typing.List[builtins.str]:
        '''Specifies one or more columns in the first logical table that refers to columns in another logical table.

        Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationship_columns SemanticView#relationship_columns}
        '''
        result = self._values.get("relationship_columns")
        assert result is not None, "Required property 'relationship_columns' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def table_name_or_alias(self) -> "SemanticViewRelationshipsTableNameOrAlias":
        '''table_name_or_alias block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name_or_alias SemanticView#table_name_or_alias}
        '''
        result = self._values.get("table_name_or_alias")
        assert result is not None, "Required property 'table_name_or_alias' is missing"
        return typing.cast("SemanticViewRelationshipsTableNameOrAlias", result)

    @builtins.property
    def referenced_relationship_columns(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''Specifies one or more columns in the second logical table that are referred to by the first logical table.

        Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#referenced_relationship_columns SemanticView#referenced_relationship_columns}
        '''
        result = self._values.get("referenced_relationship_columns")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def relationship_identifier(self) -> typing.Optional[builtins.str]:
        '''Specifies an optional identifier for the relationship.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#relationship_identifier SemanticView#relationship_identifier}
        '''
        result = self._values.get("relationship_identifier")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationships(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcdd2824c6a870d27c17a0ec5501235fb05c412b5487eac1a6567e30fa77252f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewRelationshipsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7da8fb046504661fe21e175a946dbac385a868c977c5b97d06fd4c4f8b33e23)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewRelationshipsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3d89d6ac195ce030078b551bc5b07e9f66c273be1c0ad8c3a73cc31bf7b032c1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c897d4183249b86bae895abc3dfe23d291ee9684ac2400efadff89669fa6fbd7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e1bb5600c82b1f4bcc091b2159c5557ad576b193e048689f525799937522262c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewRelationships"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81f1b28125b12ec4a2da79e30fb07e35a958ecda12f9346fcc9e8d14e102ea1f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewRelationshipsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05644697414dcab67f2e59eb628c36ef59f3fcae00f1d772e2dfbc8b95bb6105)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putReferencedTableNameOrAlias")
    def put_referenced_table_name_or_alias(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        value = SemanticViewRelationshipsReferencedTableNameOrAlias(
            table_alias=table_alias, table_name=table_name
        )

        return typing.cast(None, jsii.invoke(self, "putReferencedTableNameOrAlias", [value]))

    @jsii.member(jsii_name="putTableNameOrAlias")
    def put_table_name_or_alias(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        value = SemanticViewRelationshipsTableNameOrAlias(
            table_alias=table_alias, table_name=table_name
        )

        return typing.cast(None, jsii.invoke(self, "putTableNameOrAlias", [value]))

    @jsii.member(jsii_name="resetReferencedRelationshipColumns")
    def reset_referenced_relationship_columns(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReferencedRelationshipColumns", []))

    @jsii.member(jsii_name="resetRelationshipIdentifier")
    def reset_relationship_identifier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRelationshipIdentifier", []))

    @builtins.property
    @jsii.member(jsii_name="referencedTableNameOrAlias")
    def referenced_table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference":
        return typing.cast("SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference", jsii.get(self, "referencedTableNameOrAlias"))

    @builtins.property
    @jsii.member(jsii_name="tableNameOrAlias")
    def table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsTableNameOrAliasOutputReference":
        return typing.cast("SemanticViewRelationshipsTableNameOrAliasOutputReference", jsii.get(self, "tableNameOrAlias"))

    @builtins.property
    @jsii.member(jsii_name="referencedRelationshipColumnsInput")
    def referenced_relationship_columns_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "referencedRelationshipColumnsInput"))

    @builtins.property
    @jsii.member(jsii_name="referencedTableNameOrAliasInput")
    def referenced_table_name_or_alias_input(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"], jsii.get(self, "referencedTableNameOrAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipColumnsInput")
    def relationship_columns_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "relationshipColumnsInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipIdentifierInput")
    def relationship_identifier_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "relationshipIdentifierInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameOrAliasInput")
    def table_name_or_alias_input(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsTableNameOrAlias"], jsii.get(self, "tableNameOrAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="referencedRelationshipColumns")
    def referenced_relationship_columns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "referencedRelationshipColumns"))

    @referenced_relationship_columns.setter
    def referenced_relationship_columns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b9ec8cc21068e8df994ce4647b780c7be3bacd3f65762af98d207159df536328)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "referencedRelationshipColumns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="relationshipColumns")
    def relationship_columns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "relationshipColumns"))

    @relationship_columns.setter
    def relationship_columns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14b1dab82dbb4db1003ee04d89a8b0f76010c755806d4e21fe5b75a34752cc59)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "relationshipColumns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="relationshipIdentifier")
    def relationship_identifier(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "relationshipIdentifier"))

    @relationship_identifier.setter
    def relationship_identifier(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3747bd326272d6b824ff1820716a4834a4803a7f5fe5329f67186238648e867)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "relationshipIdentifier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewRelationships"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewRelationships"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewRelationships"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35bf2170bcf63aed25c3fbc7152fb6fa23adaf7c6fafb17129c105a37f54893b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsReferencedTableNameOrAlias",
    jsii_struct_bases=[],
    name_mapping={"table_alias": "tableAlias", "table_name": "tableName"},
)
class SemanticViewRelationshipsReferencedTableNameOrAlias:
    def __init__(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c49b41bdf46f16c432add13d69af5643570568eb62f1bb9b5d8702f61446807a)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if table_alias is not None:
            self._values["table_alias"] = table_alias
        if table_name is not None:
            self._values["table_name"] = table_name

    @builtins.property
    def table_alias(self) -> typing.Optional[builtins.str]:
        '''The alias used for the logical table, cannot be used in combination with the ``table_name``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def table_name(self) -> typing.Optional[builtins.str]:
        '''The name of the logical table, cannot be used in combination with the ``table_alias``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationshipsReferencedTableNameOrAlias(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89289cf97df6d416954ec38ada05a6844e1d06e1079472f7323617c24e22488b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetTableAlias")
    def reset_table_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableAlias", []))

    @jsii.member(jsii_name="resetTableName")
    def reset_table_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableName", []))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76cdc1414b159a5987cdf7a0b40fb8e2b09b7def550a6858917f83c623e3377a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f0d0c05771bb8f396d935da2a5705a52253e0ea1c26e2fbef2fc6763369eb6d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af7c7583151c4b4062fa1366cfe08772d67c75aa66b4df7a0b8021faeefb1d8f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsTableNameOrAlias",
    jsii_struct_bases=[],
    name_mapping={"table_alias": "tableAlias", "table_name": "tableName"},
)
class SemanticViewRelationshipsTableNameOrAlias:
    def __init__(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__788f72942851f6cb5b9878d7edb464bdab0fc4a631c93aa4ede9cdcf50c2d5f7)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if table_alias is not None:
            self._values["table_alias"] = table_alias
        if table_name is not None:
            self._values["table_name"] = table_name

    @builtins.property
    def table_alias(self) -> typing.Optional[builtins.str]:
        '''The alias used for the logical table, cannot be used in combination with the ``table_name``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def table_name(self) -> typing.Optional[builtins.str]:
        '''The name of the logical table, cannot be used in combination with the ``table_alias``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationshipsTableNameOrAlias(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsTableNameOrAliasOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewRelationshipsTableNameOrAliasOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52bb0006302290d32ac53a386d8efa8c850dee8c4529ea47435e6ec688c56c1f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetTableAlias")
    def reset_table_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableAlias", []))

    @jsii.member(jsii_name="resetTableName")
    def reset_table_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableName", []))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__433b46b71bcf29afa97381231a98b8c4e803c350959c959c9d5e054f9b4e9e08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbe4bdba7feb4f85e66c70859c8afe36ec27a64477e4b206e41c1db4b31aca0d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsTableNameOrAlias"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["SemanticViewRelationshipsTableNameOrAlias"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92017d940e664ec8d4b6b071bff991e56e4cdc72fe7869f7d0a0a9d6a112c032)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewShowOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class SemanticViewShowOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewShowOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewShowOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewShowOutputList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e6e9932db363f7b659a28effc400df185725e9cba4f22a68e8fadd1da8099e2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewShowOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__afd7f492b767b602ad994d737bb777e38aa3bd2f02743b07b8f401f7cae1ace1)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewShowOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b24230840f5f27f32375822f737a364219034df8ddb17e52a21402a7ef994ffd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4dd88aae276c3c4e2d507f2de1c0206c46ec24ad40a31ff05007fab0249f171)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2fcc2f6f7ea9b671ea914171c6524990b4c9349dc88b4ff308055c61a3e1c4b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class SemanticViewShowOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewShowOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e10f4a0a48ca054cf37e5354bddac6f8e710cb6d13a180022a4c43d6f0aa2ace)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="databaseName")
    def database_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseName"))

    @builtins.property
    @jsii.member(jsii_name="extension")
    def extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "extension"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @builtins.property
    @jsii.member(jsii_name="ownerRoleType")
    def owner_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ownerRoleType"))

    @builtins.property
    @jsii.member(jsii_name="schemaName")
    def schema_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schemaName"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["SemanticViewShowOutput"]:
        return typing.cast(typing.Optional["SemanticViewShowOutput"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["SemanticViewShowOutput"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4992776bd9636c322a0fb7c41349f5cd22b17798a56b874516b8189954fe95c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTables",
    jsii_struct_bases=[],
    name_mapping={
        "table_alias": "tableAlias",
        "table_name": "tableName",
        "comment": "comment",
        "primary_key": "primaryKey",
        "synonym": "synonym",
        "unique": "unique",
    },
)
class SemanticViewTables:
    def __init__(
        self,
        *,
        table_alias: builtins.str,
        table_name: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        primary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
        unique: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewTablesUnique", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param table_alias: Specifies an alias for a logical table in the semantic view. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: Specifies an identifier for the logical table. Example: ``"\\"<db_name>\\".\\"<schema_name>\\".\\"<table_name>\\""``. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        :param comment: Specifies a comment for the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param primary_key: Definitions of primary keys in the logical table. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#primary_key SemanticView#primary_key}
        :param synonym: List of synonyms for the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        :param unique: unique block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#unique SemanticView#unique}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44e0772b474aa6656bc7117536bacd25d40320d88a2ceb614b1fb8e25f837d5a)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument primary_key", value=primary_key, expected_type=type_hints["primary_key"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
            check_type(argname="argument unique", value=unique, expected_type=type_hints["unique"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "table_alias": table_alias,
            "table_name": table_name,
        }
        if comment is not None:
            self._values["comment"] = comment
        if primary_key is not None:
            self._values["primary_key"] = primary_key
        if synonym is not None:
            self._values["synonym"] = synonym
        if unique is not None:
            self._values["unique"] = unique

    @builtins.property
    def table_alias(self) -> builtins.str:
        '''Specifies an alias for a logical table in the semantic view.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        assert result is not None, "Required property 'table_alias' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def table_name(self) -> builtins.str:
        '''Specifies an identifier for the logical table.

        Example: ``"\\"<db_name>\\".\\"<schema_name>\\".\\"<table_name>\\""``. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        assert result is not None, "Required property 'table_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def primary_key(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Definitions of primary keys in the logical table.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#primary_key SemanticView#primary_key}
        '''
        result = self._values.get("primary_key")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def unique(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]]:
        '''unique block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#unique SemanticView#unique}
        '''
        result = self._values.get("unique")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTables(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTablesList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTablesList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df6437c85e433ae5166538751a594bb49443678174dc1fe118822ad673d0c764)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewTablesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__416f4fac1e69420180f09a9081fe7700edccb07e0a3f7d03ccf5a6af68e69a70)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewTablesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2229d17ccf89cd4c3f46ad343b7b9bad1efdac8ef32f4334fac80a884eb6c11c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ab5d9b14f741bcbcc9d062e23e5f48f302058fc45c27c73ed5dba91a3d73fbc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d3584b7ff7123d80d1a5d608db9232a9227a3405ee486d04d8d50ed9a918ad1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTables"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d55fed9f00b8328ad3aa612b7abf661b83194cc35f33b30e1dde8d2b8a860043)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewTablesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTablesOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b02eb5b58bcae2a97fbd6243d2e0fe86059fbae503d3792314d9e6e1549f3ec0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putUnique")
    def put_unique(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["SemanticViewTablesUnique", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fbb64399e8145fd663a27bad7fa2cf01ca7aea63c52da9380bd4aaf2d8b9ed3c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putUnique", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetPrimaryKey")
    def reset_primary_key(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrimaryKey", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @jsii.member(jsii_name="resetUnique")
    def reset_unique(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUnique", []))

    @builtins.property
    @jsii.member(jsii_name="unique")
    def unique(self) -> "SemanticViewTablesUniqueList":
        return typing.cast("SemanticViewTablesUniqueList", jsii.get(self, "unique"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="primaryKeyInput")
    def primary_key_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "primaryKeyInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="uniqueInput")
    def unique_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]], jsii.get(self, "uniqueInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bfc9e095b95bf3c65603f44bbf3c0260f27c05ba914802d6e8ca5978c2c2009)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="primaryKey")
    def primary_key(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "primaryKey"))

    @primary_key.setter
    def primary_key(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ef7e7158a58c66f5365227c6b9ce00215807f3f03209199f54e417b175bd00e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "primaryKey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b22a2874b217d45f82d6a6d4704c87fc17e5b02c429cae2e7a6c1d4454456990)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__447e91545c410f57df457c2f77adf17cd878a9aaa57376134bcf2feb729968f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da5f320b54a44a54dcd04e8e6dee199ff961c1e917f82de2dba56d42bba1f5df)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTables"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTables"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTables"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2068f429b253fae001aac294c99c5d8e2150909962c6a03fb0416ec91cd03924)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTablesUnique",
    jsii_struct_bases=[],
    name_mapping={"values": "values"},
)
class SemanticViewTablesUnique:
    def __init__(self, *, values: typing.Sequence[builtins.str]) -> None:
        '''
        :param values: Unique key combinations in the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#values SemanticView#values}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09f5d489c560e927de947c33290043f33a34a4996cca6d50be21287c65f3229e)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "values": values,
        }

    @builtins.property
    def values(self) -> typing.List[builtins.str]:
        '''Unique key combinations in the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#values SemanticView#values}
        '''
        result = self._values.get("values")
        assert result is not None, "Required property 'values' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTablesUnique(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTablesUniqueList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTablesUniqueList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4321116f7ccd9a7ce6b38f5feb38b0eff4116797e585ea69b2b2b52bd69bf765)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewTablesUniqueOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5018c4807f75f7284d3da4136641298f824da69ee135db7ea194c976a0e3470)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewTablesUniqueOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ff96f930cd6a00bdf79f4205ca997a5315b8600c9389b41df0c2020a9ae9b4c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6329565cc22fc64afb168662e1ca13d7ec689247a9a724d319f8e9af344d31d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fae51e401a28e467352d47f316d9d3e124b16ca65dfff3b55ed52616d0ff2892)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["SemanticViewTablesUnique"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77b3217ff4cd4c11956139861587d486ce580a71dccf0f0d27f315c090adf6b2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewTablesUniqueOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTablesUniqueOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c0dd553621328f88cdc56ae75f71bc8ee5e24698c125ab49d08be9ee74e9424)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="valuesInput")
    def values_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "valuesInput"))

    @builtins.property
    @jsii.member(jsii_name="values")
    def values(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "values"))

    @values.setter
    def values(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__67eb8521d57936759bc8c1da911f47c9a954566d562b5f22166e487eb798902b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "values", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTablesUnique"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTablesUnique"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTablesUnique"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83ec0c77c0e8baaf318daa0a5fbd381ebcf258d8db328505ae5a3cca143f1149)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class SemanticViewTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#create SemanticView#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#delete SemanticView#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#read SemanticView#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#update SemanticView#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fec7fdbef5bc5e2c29cce0e04d2a63754d75741f7bb640db9c2d0caa46b0f8ae)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#create SemanticView#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#delete SemanticView#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#read SemanticView#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/semantic_view#update SemanticView#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.semanticView.SemanticViewTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af4d6e56b85da43cde6b59b9353b12d4007a432fe1ac8e145ec04c24de89ef27)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dfe6a614632e765dee66eea2cb9a08f5116ec99a0af00b13406bdad1608a16e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5016691f4c8b29076096d7822d02de4a5f0d6763c1b268dedb5d718129409af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d13d2eb17e4d9c812ac5a9c864dc621379522ca633e7da4f0a8671bb0ae4c9d5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a783969220fdb923be984e8213cd24d19243f8cefee944bc654307eb2336168c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTimeouts"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "SemanticViewTimeouts"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__928ee86178b5b2082846fd6c9ce3681055abf375c6ebc56ef813c09149ddadfe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "SemanticView",
    "SemanticViewConfig",
    "SemanticViewDimensions",
    "SemanticViewDimensionsList",
    "SemanticViewDimensionsOutputReference",
    "SemanticViewFacts",
    "SemanticViewFactsList",
    "SemanticViewFactsOutputReference",
    "SemanticViewMetrics",
    "SemanticViewMetricsList",
    "SemanticViewMetricsOutputReference",
    "SemanticViewMetricsSemanticExpression",
    "SemanticViewMetricsSemanticExpressionOutputReference",
    "SemanticViewMetricsWindowFunction",
    "SemanticViewMetricsWindowFunctionOutputReference",
    "SemanticViewMetricsWindowFunctionOverClause",
    "SemanticViewMetricsWindowFunctionOverClauseOutputReference",
    "SemanticViewRelationships",
    "SemanticViewRelationshipsList",
    "SemanticViewRelationshipsOutputReference",
    "SemanticViewRelationshipsReferencedTableNameOrAlias",
    "SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference",
    "SemanticViewRelationshipsTableNameOrAlias",
    "SemanticViewRelationshipsTableNameOrAliasOutputReference",
    "SemanticViewShowOutput",
    "SemanticViewShowOutputList",
    "SemanticViewShowOutputOutputReference",
    "SemanticViewTables",
    "SemanticViewTablesList",
    "SemanticViewTablesOutputReference",
    "SemanticViewTablesUnique",
    "SemanticViewTablesUniqueList",
    "SemanticViewTablesUniqueOutputReference",
    "SemanticViewTimeouts",
    "SemanticViewTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__621c421f0546997d503161fd3a89f458f721951fc8c37b96729bd3e2113f2e74(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    tables: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
    comment: typing.Optional[builtins.str] = None,
    dimensions: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    facts: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    metrics: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]]] = None,
    relationships: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[SemanticViewTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e20988390c5e468998be448cb2059e9ffc9ff6d0007a7483159e2d81135c1a6a(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83782870b70c9ca05f52e21fd84ca1e5a0c5c862dfab39dd8580335c5e8abb26(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25eb63f1581a1ab4ba8e2de2d735dc6c3e75d4a027b144044d96b60d4fb1d245(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67f3acb957a63bad49fe8bca087ac6a81d036b147950f980b45ad5e9cb57f4f5(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fdcc0cb7e193d7d472ec151350730304ef01d7a277245d028df507b964eccafd(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4be1f14c7dc4c85eea265d998bd20c71c3ffa6c88d7fadd703e3c09275465225(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3ee26a7f4d5a1e286c5f98829c89f197ea859e568d47aeed3755d092a4b7e65(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__354df98ae5f13d314f17b511f524ebf7eaa5ebedad3f86a01cab81d7e9c55495(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ffae480d867107d395f55e9e819c6efabc62ad18dba575504aeb1073aed63fe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13889e20ade931d97d7e3b2a9921e9044f655bf5b7f495750c96b4563a69b81f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1723ece5fdb2a4da407763747372d2b598673bba8f3bcb21f157b5cbd45737cf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89157a14d448ee09cdc12c969b1653f28c75c334e153878a099bcaab451a1622(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    tables: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
    comment: typing.Optional[builtins.str] = None,
    dimensions: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    facts: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    metrics: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]]] = None,
    relationships: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[SemanticViewTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__deacbc56485df5bf1c6482e554030de73a2d01011ddfc1dcf305732f3b007ff9(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee247ed2743a62cba6d8671993402d88040305d8603271e76e5ddd4e204370c5(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c16c965dafa685b4661ba0b63fb2def635e51db65de68584398264aa03ac281(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e20b07c480cbd705ead37aa0b45506908129e05d2ea9389fc06309fa129134b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97876b872094cb918dd26482174b79a84a019b66f0c56cd6ba14186613d86745(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a61651fe1cbef364306a2e588f68ce682128d0e8846d19baae264785c47e5476(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b2382d1f25d577b620d384078aa8c17658f18daf33e8c4862accf7457ee2740(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewDimensions]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6921dd81918d8a7eacb1f54a09f64ca1f7976660a34e3aea4a6d37583b996550(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02f6f057fb5eaac049cbe9d4264b9e6fdef0dea4b529b6d22ed01243622f5235(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f834c240895a9bb2d4a3db8c5ee06bb908905991522377fb6938ef78155993d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40e790b3b76f90f293424f5d91aa927b855dd99976f30a07ca1498c38967896d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e79cdcd204f7259ad458881d4f9ae8722a89d3e1609ae543d174309161b7de6c(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__afdefb6a3c4ac64c616a386e191de0a30b06d0a05068a79b7b7544b53b013e50(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewDimensions]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2622c4143bc411f11ab7065fe03c5f0615e227806e45de306cae1c54e56c39f(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e6b7a663a6da10c17f9063df073a69d00cb24fff316329c6f78363626a3addb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86842f48bfda761c810969f7e370c467f1d8b563197b03937fdead5845ab9e0a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57290199e87b055a02c15873591db098697c24a0593458e96900390d5c823059(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c77fc006213d607cc1961d44ddf952d6ba2bba9854fdb6b41620fc5c3250fa6(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f68cfb987e768b022d4510801e4e974e71e260a6f57994f7588cbe6ff15a82af(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9873b91d71721f656564a96c9d7f907ed7f426f64ee5ae7cbe9eeaea34b51a67(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewFacts]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d484870bc74d79e72ffc8c4a3504136d0c8d079690f758d5a5d565552bd3e56(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bbd0497a6f34598cd7277bcdcdca77c21440d0c3a1f2155df2eb1d7eb409716(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80643fb7b732b443502ec849cf121a6640d2bbb91f732ffd27234b173109dbf1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b64bfd32660d6ffc78bdb3936ab80a545fac83fb695ab1e88b2e945150b6bd49(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1036a4e8bc26a187f5f3e55080456d274e974394d31adeb8570d5a5ba988ec5f(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f18dd71db9c6ad4e0d94afb9454729c199921c09c276ee7e624004f89859c6d6(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewFacts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0faa6cb74051c7eabca10b45ec1a882f0b50a0e30ea849acbfbda2380387b0c4(
    *,
    semantic_expression: typing.Optional[typing.Union[SemanticViewMetricsSemanticExpression, typing.Dict[builtins.str, typing.Any]]] = None,
    window_function: typing.Optional[typing.Union[SemanticViewMetricsWindowFunction, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f78511c0707b1028a8657945f2040982298c3f5cd490e8e0a84c21055ea3c4ef(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d310e8b024939bb6590e333683b902fa4ccadb47fc741e845e8de5b8b537dc4c(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4881adb663bc185579b06ec2aa9d11af5e92fa08cbda422470e69974d71357a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2f0e747beaac738926be87f19175b7db72c577463cb48f73e888b7b5e0ba0c0(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94fbedcd9200ffc9b860dd442f7cf452c5633734ed1e2dacdc6bdf944fe03413(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6dca92f70d9229412ca7429b3bae9fce8a8fd8f90ffaada6e92f77dbf50322af(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewMetrics]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7e00a80b7b34dc1b44e155ad3fb1e80910cab5fb4deec1da23b598e40047672(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aebd2dad08f3888748b639c66784ace15a06835be9f1f685fd5521f37b73a537(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewMetrics]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a798273fa0ed47444102bf7b99a05ef1a671d2848af9bf715536d8e743b73fd6(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8749130a7c6d59b8e1d96d1e4b33e71f1bdee0b69efa7aa4aed3e9d5d4d8523b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1a8b57cd5ea86d8886d29be3c8f7c399e2b178dbff06dfac58ba3f9bf304d7e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1feb4a3b32718fb745b84b8f3dd8934711558d7255a180850832a06d94565db5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e08a6b93de9818b993f10fe15a3296cac65907edc83eadd305da6eee03b30f66(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a8688a9cea0fcc575c9260309f01b1012eb5930d98818f7fd288884f1cf3f03(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55f297f37716ef9977023c664b62a62a4175b4b9bb3e87f841f61bc34f0b9e52(
    value: typing.Optional[SemanticViewMetricsSemanticExpression],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6164d848271697d27bc6d250e3272102a66d4d6d8433bdcad616dbd1567ea7ea(
    *,
    over_clause: typing.Union[SemanticViewMetricsWindowFunctionOverClause, typing.Dict[builtins.str, typing.Any]],
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__741884a872c0cc2adfa7db5d66f54e75817e4619eed24ce0d1019b64dedd13ce(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60e45771c3ff835cd7d580c8b86b4bebd7c0db8af1fd5b178d957381150af378(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ed4524f60b2e60f551cf736eec3c2e4b56fce322a9b876abf646f998a1b8fa1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e00af931d03115cbc6e9b9b2d6b1900596b71e7fffcaff2a5375a75e9b7842f(
    value: typing.Optional[SemanticViewMetricsWindowFunction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a34b5b429dbf12254cfb1330b00f4bc198dc21b895fcfd71d1a0ed6306c3538e(
    *,
    order_by: typing.Optional[builtins.str] = None,
    partition_by: typing.Optional[builtins.str] = None,
    window_frame_clause: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32faed80dfae0fba99c0a52ba36153a94f79f11ffc6823cdd589aad780a09a68(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b5a8f8a8c942b43215264e07392ce793982e3f663a363b75daf36abe5655453(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__386e3e15ff25cc9b7e799ff383e62594a5d092e6c7c9639f3742c339a7e58d1e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a510be84776a8d66daff07f5e053b3f1bfea077d0d6284097c13d7ff8e8a10e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b56f0ce4b56d417286759e5e93c82030fce58120898976b759ef9cd83545a72(
    value: typing.Optional[SemanticViewMetricsWindowFunctionOverClause],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fc267f0ddbbaa6a5a82ca1146ede627361802980043f15afd166fa04df7ab8b(
    *,
    referenced_table_name_or_alias: typing.Union[SemanticViewRelationshipsReferencedTableNameOrAlias, typing.Dict[builtins.str, typing.Any]],
    relationship_columns: typing.Sequence[builtins.str],
    table_name_or_alias: typing.Union[SemanticViewRelationshipsTableNameOrAlias, typing.Dict[builtins.str, typing.Any]],
    referenced_relationship_columns: typing.Optional[typing.Sequence[builtins.str]] = None,
    relationship_identifier: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcdd2824c6a870d27c17a0ec5501235fb05c412b5487eac1a6567e30fa77252f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7da8fb046504661fe21e175a946dbac385a868c977c5b97d06fd4c4f8b33e23(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d89d6ac195ce030078b551bc5b07e9f66c273be1c0ad8c3a73cc31bf7b032c1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c897d4183249b86bae895abc3dfe23d291ee9684ac2400efadff89669fa6fbd7(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e1bb5600c82b1f4bcc091b2159c5557ad576b193e048689f525799937522262c(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81f1b28125b12ec4a2da79e30fb07e35a958ecda12f9346fcc9e8d14e102ea1f(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewRelationships]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05644697414dcab67f2e59eb628c36ef59f3fcae00f1d772e2dfbc8b95bb6105(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b9ec8cc21068e8df994ce4647b780c7be3bacd3f65762af98d207159df536328(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14b1dab82dbb4db1003ee04d89a8b0f76010c755806d4e21fe5b75a34752cc59(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3747bd326272d6b824ff1820716a4834a4803a7f5fe5329f67186238648e867(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35bf2170bcf63aed25c3fbc7152fb6fa23adaf7c6fafb17129c105a37f54893b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewRelationships]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c49b41bdf46f16c432add13d69af5643570568eb62f1bb9b5d8702f61446807a(
    *,
    table_alias: typing.Optional[builtins.str] = None,
    table_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89289cf97df6d416954ec38ada05a6844e1d06e1079472f7323617c24e22488b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76cdc1414b159a5987cdf7a0b40fb8e2b09b7def550a6858917f83c623e3377a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f0d0c05771bb8f396d935da2a5705a52253e0ea1c26e2fbef2fc6763369eb6d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af7c7583151c4b4062fa1366cfe08772d67c75aa66b4df7a0b8021faeefb1d8f(
    value: typing.Optional[SemanticViewRelationshipsReferencedTableNameOrAlias],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__788f72942851f6cb5b9878d7edb464bdab0fc4a631c93aa4ede9cdcf50c2d5f7(
    *,
    table_alias: typing.Optional[builtins.str] = None,
    table_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52bb0006302290d32ac53a386d8efa8c850dee8c4529ea47435e6ec688c56c1f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__433b46b71bcf29afa97381231a98b8c4e803c350959c959c9d5e054f9b4e9e08(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbe4bdba7feb4f85e66c70859c8afe36ec27a64477e4b206e41c1db4b31aca0d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92017d940e664ec8d4b6b071bff991e56e4cdc72fe7869f7d0a0a9d6a112c032(
    value: typing.Optional[SemanticViewRelationshipsTableNameOrAlias],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e6e9932db363f7b659a28effc400df185725e9cba4f22a68e8fadd1da8099e2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__afd7f492b767b602ad994d737bb777e38aa3bd2f02743b07b8f401f7cae1ace1(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b24230840f5f27f32375822f737a364219034df8ddb17e52a21402a7ef994ffd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4dd88aae276c3c4e2d507f2de1c0206c46ec24ad40a31ff05007fab0249f171(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2fcc2f6f7ea9b671ea914171c6524990b4c9349dc88b4ff308055c61a3e1c4b0(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e10f4a0a48ca054cf37e5354bddac6f8e710cb6d13a180022a4c43d6f0aa2ace(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4992776bd9636c322a0fb7c41349f5cd22b17798a56b874516b8189954fe95c4(
    value: typing.Optional[SemanticViewShowOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44e0772b474aa6656bc7117536bacd25d40320d88a2ceb614b1fb8e25f837d5a(
    *,
    table_alias: builtins.str,
    table_name: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    primary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    unique: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewTablesUnique, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df6437c85e433ae5166538751a594bb49443678174dc1fe118822ad673d0c764(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__416f4fac1e69420180f09a9081fe7700edccb07e0a3f7d03ccf5a6af68e69a70(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2229d17ccf89cd4c3f46ad343b7b9bad1efdac8ef32f4334fac80a884eb6c11c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ab5d9b14f741bcbcc9d062e23e5f48f302058fc45c27c73ed5dba91a3d73fbc(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d3584b7ff7123d80d1a5d608db9232a9227a3405ee486d04d8d50ed9a918ad1(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d55fed9f00b8328ad3aa612b7abf661b83194cc35f33b30e1dde8d2b8a860043(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewTables]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b02eb5b58bcae2a97fbd6243d2e0fe86059fbae503d3792314d9e6e1549f3ec0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fbb64399e8145fd663a27bad7fa2cf01ca7aea63c52da9380bd4aaf2d8b9ed3c(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[SemanticViewTablesUnique, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bfc9e095b95bf3c65603f44bbf3c0260f27c05ba914802d6e8ca5978c2c2009(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ef7e7158a58c66f5365227c6b9ce00215807f3f03209199f54e417b175bd00e(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b22a2874b217d45f82d6a6d4704c87fc17e5b02c429cae2e7a6c1d4454456990(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__447e91545c410f57df457c2f77adf17cd878a9aaa57376134bcf2feb729968f8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da5f320b54a44a54dcd04e8e6dee199ff961c1e917f82de2dba56d42bba1f5df(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2068f429b253fae001aac294c99c5d8e2150909962c6a03fb0416ec91cd03924(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewTables]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09f5d489c560e927de947c33290043f33a34a4996cca6d50be21287c65f3229e(
    *,
    values: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4321116f7ccd9a7ce6b38f5feb38b0eff4116797e585ea69b2b2b52bd69bf765(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5018c4807f75f7284d3da4136641298f824da69ee135db7ea194c976a0e3470(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ff96f930cd6a00bdf79f4205ca997a5315b8600c9389b41df0c2020a9ae9b4c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6329565cc22fc64afb168662e1ca13d7ec689247a9a724d319f8e9af344d31d(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fae51e401a28e467352d47f316d9d3e124b16ca65dfff3b55ed52616d0ff2892(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77b3217ff4cd4c11956139861587d486ce580a71dccf0f0d27f315c090adf6b2(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[SemanticViewTablesUnique]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c0dd553621328f88cdc56ae75f71bc8ee5e24698c125ab49d08be9ee74e9424(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67eb8521d57936759bc8c1da911f47c9a954566d562b5f22166e487eb798902b(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83ec0c77c0e8baaf318daa0a5fbd381ebcf258d8db328505ae5a3cca143f1149(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewTablesUnique]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fec7fdbef5bc5e2c29cce0e04d2a63754d75741f7bb640db9c2d0caa46b0f8ae(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af4d6e56b85da43cde6b59b9353b12d4007a432fe1ac8e145ec04c24de89ef27(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dfe6a614632e765dee66eea2cb9a08f5116ec99a0af00b13406bdad1608a16e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5016691f4c8b29076096d7822d02de4a5f0d6763c1b268dedb5d718129409af(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d13d2eb17e4d9c812ac5a9c864dc621379522ca633e7da4f0a8671bb0ae4c9d5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a783969220fdb923be984e8213cd24d19243f8cefee944bc654307eb2336168c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__928ee86178b5b2082846fd6c9ce3681055abf375c6ebc56ef813c09149ddadfe(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, SemanticViewTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
