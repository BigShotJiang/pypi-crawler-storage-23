r'''
# `snowflake_stage_internal`

Refer to the Terraform Registry for docs: [`snowflake_stage_internal`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class StageInternal(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternal",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal snowflake_stage_internal}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        directory: typing.Optional[typing.Union["StageInternalDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageInternalEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageInternalFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageInternalTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal snowflake_stage_internal} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#database StageInternal#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#name StageInternal#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#schema StageInternal#schema}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#comment StageInternal#comment}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#directory StageInternal#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encryption StageInternal#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_format StageInternal#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#id StageInternal#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timeouts StageInternal#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71fcb9a9642d2e49097b24bbf647f3f11d4d6b4bd0197f33bf0103652461bedd)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = StageInternalConfig(
            database=database,
            name=name,
            schema=schema,
            comment=comment,
            directory=directory,
            encryption=encryption,
            file_format=file_format,
            id=id,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a StageInternal resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the StageInternal to import.
        :param import_from_id: The id of the existing StageInternal that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the StageInternal to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aa45b6f3673eed54bd5a207c396e8e2f76520f718a5e0699adc83e14c8ff99ac)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putDirectory")
    def put_directory(
        self,
        *,
        enable: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
        auto_refresh: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the internal named stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable StageInternal#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should automatically refresh the directory table metadata when new or updated data files are available on the internal named stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#auto_refresh StageInternal#auto_refresh}
        '''
        value = StageInternalDirectory(enable=enable, auto_refresh=auto_refresh)

        return typing.cast(None, jsii.invoke(self, "putDirectory", [value]))

    @jsii.member(jsii_name="putEncryption")
    def put_encryption(
        self,
        *,
        snowflake_full: typing.Optional[typing.Union["StageInternalEncryptionSnowflakeFull", typing.Dict[builtins.str, typing.Any]]] = None,
        snowflake_sse: typing.Optional[typing.Union["StageInternalEncryptionSnowflakeSse", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param snowflake_full: snowflake_full block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_full StageInternal#snowflake_full}
        :param snowflake_sse: snowflake_sse block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_sse StageInternal#snowflake_sse}
        '''
        value = StageInternalEncryption(
            snowflake_full=snowflake_full, snowflake_sse=snowflake_sse
        )

        return typing.cast(None, jsii.invoke(self, "putEncryption", [value]))

    @jsii.member(jsii_name="putFileFormat")
    def put_file_format(
        self,
        *,
        avro: typing.Optional[typing.Union["StageInternalFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageInternalFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageInternalFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageInternalFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageInternalFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageInternalFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#avro StageInternal#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#csv StageInternal#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#format_name StageInternal#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#json StageInternal#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#orc StageInternal#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parquet StageInternal#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#xml StageInternal#xml}
        '''
        value = StageInternalFileFormat(
            avro=avro,
            csv=csv,
            format_name=format_name,
            json=json,
            orc=orc,
            parquet=parquet,
            xml=xml,
        )

        return typing.cast(None, jsii.invoke(self, "putFileFormat", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#create StageInternal#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#delete StageInternal#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#read StageInternal#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#update StageInternal#update}.
        '''
        value = StageInternalTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetDirectory")
    def reset_directory(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDirectory", []))

    @jsii.member(jsii_name="resetEncryption")
    def reset_encryption(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncryption", []))

    @jsii.member(jsii_name="resetFileFormat")
    def reset_file_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileFormat", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="describeOutput")
    def describe_output(self) -> "StageInternalDescribeOutputList":
        return typing.cast("StageInternalDescribeOutputList", jsii.get(self, "describeOutput"))

    @builtins.property
    @jsii.member(jsii_name="directory")
    def directory(self) -> "StageInternalDirectoryOutputReference":
        return typing.cast("StageInternalDirectoryOutputReference", jsii.get(self, "directory"))

    @builtins.property
    @jsii.member(jsii_name="encryption")
    def encryption(self) -> "StageInternalEncryptionOutputReference":
        return typing.cast("StageInternalEncryptionOutputReference", jsii.get(self, "encryption"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> "StageInternalFileFormatOutputReference":
        return typing.cast("StageInternalFileFormatOutputReference", jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="fullyQualifiedName")
    def fully_qualified_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullyQualifiedName"))

    @builtins.property
    @jsii.member(jsii_name="showOutput")
    def show_output(self) -> "StageInternalShowOutputList":
        return typing.cast("StageInternalShowOutputList", jsii.get(self, "showOutput"))

    @builtins.property
    @jsii.member(jsii_name="stageType")
    def stage_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stageType"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "StageInternalTimeoutsOutputReference":
        return typing.cast("StageInternalTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="directoryInput")
    def directory_input(self) -> typing.Optional["StageInternalDirectory"]:
        return typing.cast(typing.Optional["StageInternalDirectory"], jsii.get(self, "directoryInput"))

    @builtins.property
    @jsii.member(jsii_name="encryptionInput")
    def encryption_input(self) -> typing.Optional["StageInternalEncryption"]:
        return typing.cast(typing.Optional["StageInternalEncryption"], jsii.get(self, "encryptionInput"))

    @builtins.property
    @jsii.member(jsii_name="fileFormatInput")
    def file_format_input(self) -> typing.Optional["StageInternalFileFormat"]:
        return typing.cast(typing.Optional["StageInternalFileFormat"], jsii.get(self, "fileFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "StageInternalTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "StageInternalTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f3af50625cbdfb963d0ec8761f7baa5510a2472fca4aa42257253d7361c181de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__224e9f088a6882f5b7aaa2b11c64f6c1473547ec6b0716be0b7e338685eedd23)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c57efce34699de686e42624a92db6884a47ac3575fdb7e3ea9be4211f87e9e48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c176b2681e3114420c1038b83ca041c2b6481c32707ba3b7ff832c6bb9665e08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36bdd8cce0a7d154157ea5fd6406f8dd9550e69f10a1b12361e44f37b50996b4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "database": "database",
        "name": "name",
        "schema": "schema",
        "comment": "comment",
        "directory": "directory",
        "encryption": "encryption",
        "file_format": "fileFormat",
        "id": "id",
        "timeouts": "timeouts",
    },
)
class StageInternalConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        directory: typing.Optional[typing.Union["StageInternalDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageInternalEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageInternalFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageInternalTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#database StageInternal#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#name StageInternal#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#schema StageInternal#schema}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#comment StageInternal#comment}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#directory StageInternal#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encryption StageInternal#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_format StageInternal#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#id StageInternal#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timeouts StageInternal#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(directory, dict):
            directory = StageInternalDirectory(**directory)
        if isinstance(encryption, dict):
            encryption = StageInternalEncryption(**encryption)
        if isinstance(file_format, dict):
            file_format = StageInternalFileFormat(**file_format)
        if isinstance(timeouts, dict):
            timeouts = StageInternalTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcc538e2622ad8fd129afe7b0acd197471f6d6054b9bbae8faf385942446ad95)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument directory", value=directory, expected_type=type_hints["directory"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument file_format", value=file_format, expected_type=type_hints["file_format"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "database": database,
            "name": name,
            "schema": schema,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if comment is not None:
            self._values["comment"] = comment
        if directory is not None:
            self._values["directory"] = directory
        if encryption is not None:
            self._values["encryption"] = encryption
        if file_format is not None:
            self._values["file_format"] = file_format
        if id is not None:
            self._values["id"] = id
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def database(self) -> builtins.str:
        '''The database in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#database StageInternal#database}
        '''
        result = self._values.get("database")
        assert result is not None, "Required property 'database' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Specifies the identifier for the stage;

        must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#name StageInternal#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> builtins.str:
        '''The schema in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#schema StageInternal#schema}
        '''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#comment StageInternal#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def directory(self) -> typing.Optional["StageInternalDirectory"]:
        '''directory block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#directory StageInternal#directory}
        '''
        result = self._values.get("directory")
        return typing.cast(typing.Optional["StageInternalDirectory"], result)

    @builtins.property
    def encryption(self) -> typing.Optional["StageInternalEncryption"]:
        '''encryption block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encryption StageInternal#encryption}
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["StageInternalEncryption"], result)

    @builtins.property
    def file_format(self) -> typing.Optional["StageInternalFileFormat"]:
        '''file_format block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_format StageInternal#file_format}
        '''
        result = self._values.get("file_format")
        return typing.cast(typing.Optional["StageInternalFileFormat"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#id StageInternal#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["StageInternalTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timeouts StageInternal#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["StageInternalTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputDirectoryTable",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputDirectoryTable:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputDirectoryTable(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputDirectoryTableList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputDirectoryTableList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9665d2f5efbe37fc21ae037315b13adffa7c4c86ad0d58af4ed5afe5cdc682e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputDirectoryTableOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__113e505f372153d39353649b945f87b8efbfebaf6090011560ed55dcf2259520)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputDirectoryTableOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b9e66981213aa6f64072bea6da1299b0e9a3e4bf2f5937557281167bd72d1d8a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ff255e90d6eb9fb0d869206da779401c62e936077701ea3600da46e1123eab7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90585298bc71cd299834566b51dbe0007081dd581ba2397ecff5f23e8919fc47)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputDirectoryTableOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputDirectoryTableOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__303b8e3848f1639df13051009cb8438c3fc9632a39da2a7bf09f2ab018758241)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "autoRefresh"))

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "enable"))

    @builtins.property
    @jsii.member(jsii_name="lastRefreshedOn")
    def last_refreshed_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "lastRefreshedOn"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputDirectoryTable"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputDirectoryTable"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputDirectoryTable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e1bcc297f145881694bce335811e54fd25eb05cd953f2e8269d1fae28cb9d83)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormat",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormat:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatAvro:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatAvroList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatAvroList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3a8711eddae3becdb2bec074e058a1c48af2fc1e93eace90f1024e5e498ce67)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatAvroOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f05855f28495a5edef1d1b0609b730020131d381b4c587db452d1f69dfbdd44)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatAvroOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e6c1270d69fe833d1d4e62996c3f4a89a76ff9ab7d3b46277797bcf1f119ae4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33da0d1e70421e2a3a820548b102bb27812d9e8975f4924902c66fa584f9a6c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c071ee48f965434e8794db7ac6cf7eaf9c1a98abaaeca2b6afa0d52368f0a73)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1f893b4d252dc0cc2b11ca45bdbca5b1e804c0671deef605acab17c7fdbcc233)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatAvro"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatAvro"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatAvro"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0322fe9f4afef66e2143758731c962498262ab345f15f1c46037ad8c8ef173a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatCsv:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatCsvList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatCsvList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ab7a01bc2e5ac95be5e5598ca3f2fd8651f02fd3d5141131be32f4aa58d45ad)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatCsvOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d7b0a20911dede692ad5cd6934af1aa1d54e6f7e6cfabbc8ed7e1e2980b159a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatCsvOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4e3cca888c26cfbe8aae2e76925a9030d6b5c06433cf2a70961f625a3ccdc28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53f3f80b30906b4c3b4fc7b701ae6f6f86d5840d1513f76b043f9965802cf7ad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d3c140d0f5f5724bb1d1bcba9b624b8786d019cad066fed83fdeeb86bbe1667)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e3723e780e61705f30b9125c21831e72e38f7b05e8229f99a76d34b4ef69e94)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "emptyFieldAsNull"))

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "errorOnColumnCountMismatch"))

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "parseHeader"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "skipBlankLines"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="validateUtf8")
    def validate_utf8(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "validateUtf8"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatCsv"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatCsv"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatCsv"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d8a7161acf972484ebbba49cfe9ba245c3fbbda9765804453cb44f87f6c8ebe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatJson:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatJsonList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatJsonList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d25b49df5a77ca1cdf266ba3dd788a8a010b74aba0301f7b5462e44e693e38ce)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatJsonOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__685ce4ef5610c3d94b523d99cd71a84bbab324afd7120cc848985e37ebfe0773)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatJsonOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6bd23fb708160d57fb88e42f7e8440d80ed7a8e5f585f4a8d73edcde4bcb7a5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73a7782bdcd34378613c06dd4bd11428f1cd692860fa8ad5f2a6d88d3b2e7932)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__516a98df2b8a4d96dbf4d0f5d81724a88550f9a1da089fdf695e816faf8bee28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__655ff984fc62ee33d08c6c10727c89d11cbfaa3b75a6cdd194e177cde6dd9fa7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "allowDuplicate"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "enableOctal"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "stripNullValues"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "stripOuterArray"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatJson"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatJson"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatJson"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08a598ac11579aaab15457108a2150c2a09019777b34e3bb9e8618f0bf2cd0fb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a573c3c211dfb10b427c5fc42f0b20f6a1d9372fc9f73dd8b2e60da7bfd6a66)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__844c8858cf1e3b0299b594be7b8a9fd215700f2bf1da6d870ffb902c72a53c99)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cff951026f3bf92c4c2f8027dd3fc49ab6fbef04ace8b0b8e147a3b4dd2d4e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b743e128e399cd892327050a57a902e7a1b7ae5bc599bac91c37c505220769b7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04b984a0242d49397f243aeb7ff98681008891a623c2c0ab30b8a3577eb77f19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatOrc:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatOrcList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatOrcList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39dd1073b6ec2110e73770154e9814aa8d02ba3acf7fa2673be0de32a9bb7125)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatOrcOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b2831118d32fac228cd9b705d71826077efec56f1b2041f55409598d89c1e3a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatOrcOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52ce1f5aa3a072b40fb7f6cf32dccb46fc7417fc5f24cfc43edf3ba49d8036c2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a8875dadeab25cdc39e8ad5d38cf955b9ae3eff06ee0d6a8c8d68d68e90fb15)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d067bab2b71af6ee135bc403019efd02aa9ed4ac0d1a9f18f288f9e6cfe2dff1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__342fafc73e223a3326868f76054c6e7233b081b8407c93fc1306971a2f552aef)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatOrc"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatOrc"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatOrc"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16fba3b7d75bd1a31165e0f17eb1e4ca657f160ebd08695980e4d49d0850037c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a28e71b9108f170283a1c6da73bd3b43c78daae544d25ede72ee7ee84b8c9b0a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> "StageInternalDescribeOutputFileFormatAvroList":
        return typing.cast("StageInternalDescribeOutputFileFormatAvroList", jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> "StageInternalDescribeOutputFileFormatCsvList":
        return typing.cast("StageInternalDescribeOutputFileFormatCsvList", jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> "StageInternalDescribeOutputFileFormatJsonList":
        return typing.cast("StageInternalDescribeOutputFileFormatJsonList", jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> "StageInternalDescribeOutputFileFormatOrcList":
        return typing.cast("StageInternalDescribeOutputFileFormatOrcList", jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageInternalDescribeOutputFileFormatParquetList":
        return typing.cast("StageInternalDescribeOutputFileFormatParquetList", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageInternalDescribeOutputFileFormatXmlList":
        return typing.cast("StageInternalDescribeOutputFileFormatXmlList", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormat"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormat"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormat"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18833a657bfac7bf812b42b5a2ce7f35f2ec541fa95109bb7d36d3facceb6623)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatParquet:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatParquetList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatParquetList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e30db80889a767207b14930a749fd6f80a95cdfb5ad1de92b3a3dfd3aca8d3e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatParquetOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2cbda310d4527f6c6a655ab09b91ef35036ef8954cd3c0035efb8e7de037040)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatParquetOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12e3cfb999156dfd5e314e90650756efc4be388075a929965ae2e35b4198961c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca352e34524c88c1ff91e0ccb3ebec67da007f0d45084f11a9730ad96fb4ccd1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1962499a661f04fcef7f5b6259d6f1ea70a35449a5cf0e58b77de874f13ff7ff)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eea42636104f429c6074e9434a7aeefa244199e3e167c384c3e4f3f44cd1e778)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "binaryAsText"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "useLogicalType"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "useVectorizedScanner"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatParquet"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatParquet"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatParquet"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d25a5b3d943f2332de5b91fb250d172752de972f3734578209811d61d2db9b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalDescribeOutputFileFormatXml:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDescribeOutputFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDescribeOutputFileFormatXmlList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatXmlList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0543b0bb96865b4687b6619cc40f168b8713e3e68830898eed3c03e6417be1f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageInternalDescribeOutputFileFormatXmlOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89d4b5070f678c57379d94269f31ed5b51c147753058094c0527701fbfb4f9cd)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputFileFormatXmlOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75c691d876fc86f9ee5efaae46f1694887dcbf4b464eef3b908c94e5cc644aab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3baaee402f08e2b871027877e91cf746908900564cf4d86ff5e0f637b493267b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e1b095d5705f7a6bf33b3c2c2c4f00ff8d3ae48bb76f5f765efb4666b266e3b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ac300ca33410dad15c9daf3cb443d6b4e9ba488581c8c0024ef5be64ede5ba2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "disableAutoConvert"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "preserveSpace"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "stripOuterElement"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["StageInternalDescribeOutputFileFormatXml"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutputFileFormatXml"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutputFileFormatXml"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0b7eff98d2005089ea6db7a02d665c79ab311d49ab02284625913b7bbac3ffe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c926972ee6d0c7033ce1837b93c4fcae185eeec2a034f6700e47b33d08170230)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "StageInternalDescribeOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1591144ff7d45993f0254a54f5d8760494b74aa630c274734f923dc5f94c36cd)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalDescribeOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20073c24fe922f6f6f3d43efdf9ed8d94211aabd8804a6c0b3ee8b2e3128034a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d80e3db3826dc385765755008ccf3d86c9d5d59403a2e38d53935c24ed1183c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13093ecde02251dacecf34c41ddd5ab34612938dd7e7df411f84a1171eeb9a99)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalDescribeOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDescribeOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81618d4b5414f136d0d68e5d7767c94a9876fbd44454fe488799c8f3771c3626)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="directoryTable")
    def directory_table(self) -> "StageInternalDescribeOutputDirectoryTableList":
        return typing.cast("StageInternalDescribeOutputDirectoryTableList", jsii.get(self, "directoryTable"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> "StageInternalDescribeOutputFileFormatList":
        return typing.cast("StageInternalDescribeOutputFileFormatList", jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalDescribeOutput"]:
        return typing.cast(typing.Optional["StageInternalDescribeOutput"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalDescribeOutput"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6517709eb717c611d1e4ef85366699e93d57c0a1fb5b209534029bb1396f7c7b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDirectory",
    jsii_struct_bases=[],
    name_mapping={"enable": "enable", "auto_refresh": "autoRefresh"},
)
class StageInternalDirectory:
    def __init__(
        self,
        *,
        enable: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
        auto_refresh: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the internal named stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable StageInternal#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should automatically refresh the directory table metadata when new or updated data files are available on the internal named stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#auto_refresh StageInternal#auto_refresh}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de5622a0c888c70229b2b06cc38cdaa73d8fad2870e50097e0063a945b39c240)
            check_type(argname="argument enable", value=enable, expected_type=type_hints["enable"])
            check_type(argname="argument auto_refresh", value=auto_refresh, expected_type=type_hints["auto_refresh"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enable": enable,
        }
        if auto_refresh is not None:
            self._values["auto_refresh"] = auto_refresh

    @builtins.property
    def enable(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        '''Specifies whether to enable a directory table on the internal named stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable StageInternal#enable}
        '''
        result = self._values.get("enable")
        assert result is not None, "Required property 'enable' is missing"
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], result)

    @builtins.property
    def auto_refresh(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should automatically refresh the directory table metadata when new or updated data files are available on the internal named stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#auto_refresh StageInternal#auto_refresh}
        '''
        result = self._values.get("auto_refresh")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalDirectory(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalDirectoryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalDirectoryOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1140c6b284732a7e9c110b82a30e0118f8e2d73c51eafe5ed5fb64aad0e4a0fb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAutoRefresh")
    def reset_auto_refresh(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoRefresh", []))

    @builtins.property
    @jsii.member(jsii_name="autoRefreshInput")
    def auto_refresh_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "autoRefreshInput"))

    @builtins.property
    @jsii.member(jsii_name="enableInput")
    def enable_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "enableInput"))

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autoRefresh"))

    @auto_refresh.setter
    def auto_refresh(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99bc1975ece811201717d7605433789ae2c1b75cc9879e1affafd8a9278f07e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoRefresh", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "enable"))

    @enable.setter
    def enable(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb8b4a7fc4252a8f799473fc4b7ba9d593c34c5378ba8ab6a3c88b8caec37abe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enable", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalDirectory"]:
        return typing.cast(typing.Optional["StageInternalDirectory"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["StageInternalDirectory"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c8342ac22d18ae2d8c0355cd0128d8b78bc9c71ad5745fee1e6672d782da234)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryption",
    jsii_struct_bases=[],
    name_mapping={"snowflake_full": "snowflakeFull", "snowflake_sse": "snowflakeSse"},
)
class StageInternalEncryption:
    def __init__(
        self,
        *,
        snowflake_full: typing.Optional[typing.Union["StageInternalEncryptionSnowflakeFull", typing.Dict[builtins.str, typing.Any]]] = None,
        snowflake_sse: typing.Optional[typing.Union["StageInternalEncryptionSnowflakeSse", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param snowflake_full: snowflake_full block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_full StageInternal#snowflake_full}
        :param snowflake_sse: snowflake_sse block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_sse StageInternal#snowflake_sse}
        '''
        if isinstance(snowflake_full, dict):
            snowflake_full = StageInternalEncryptionSnowflakeFull(**snowflake_full)
        if isinstance(snowflake_sse, dict):
            snowflake_sse = StageInternalEncryptionSnowflakeSse(**snowflake_sse)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3eb23b52f6eb2756f927f1ce647a7c2f4333fd177f27bfee1528805648d10b6)
            check_type(argname="argument snowflake_full", value=snowflake_full, expected_type=type_hints["snowflake_full"])
            check_type(argname="argument snowflake_sse", value=snowflake_sse, expected_type=type_hints["snowflake_sse"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if snowflake_full is not None:
            self._values["snowflake_full"] = snowflake_full
        if snowflake_sse is not None:
            self._values["snowflake_sse"] = snowflake_sse

    @builtins.property
    def snowflake_full(self) -> typing.Optional["StageInternalEncryptionSnowflakeFull"]:
        '''snowflake_full block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_full StageInternal#snowflake_full}
        '''
        result = self._values.get("snowflake_full")
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeFull"], result)

    @builtins.property
    def snowflake_sse(self) -> typing.Optional["StageInternalEncryptionSnowflakeSse"]:
        '''snowflake_sse block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_sse StageInternal#snowflake_sse}
        '''
        result = self._values.get("snowflake_sse")
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeSse"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalEncryption(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalEncryptionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryptionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df643cf8b8046950a3741f2ce5ca9e235d19229038ec0df001c1cae5e2e1db98)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putSnowflakeFull")
    def put_snowflake_full(self) -> None:
        value = StageInternalEncryptionSnowflakeFull()

        return typing.cast(None, jsii.invoke(self, "putSnowflakeFull", [value]))

    @jsii.member(jsii_name="putSnowflakeSse")
    def put_snowflake_sse(self) -> None:
        value = StageInternalEncryptionSnowflakeSse()

        return typing.cast(None, jsii.invoke(self, "putSnowflakeSse", [value]))

    @jsii.member(jsii_name="resetSnowflakeFull")
    def reset_snowflake_full(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSnowflakeFull", []))

    @jsii.member(jsii_name="resetSnowflakeSse")
    def reset_snowflake_sse(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSnowflakeSse", []))

    @builtins.property
    @jsii.member(jsii_name="snowflakeFull")
    def snowflake_full(self) -> "StageInternalEncryptionSnowflakeFullOutputReference":
        return typing.cast("StageInternalEncryptionSnowflakeFullOutputReference", jsii.get(self, "snowflakeFull"))

    @builtins.property
    @jsii.member(jsii_name="snowflakeSse")
    def snowflake_sse(self) -> "StageInternalEncryptionSnowflakeSseOutputReference":
        return typing.cast("StageInternalEncryptionSnowflakeSseOutputReference", jsii.get(self, "snowflakeSse"))

    @builtins.property
    @jsii.member(jsii_name="snowflakeFullInput")
    def snowflake_full_input(
        self,
    ) -> typing.Optional["StageInternalEncryptionSnowflakeFull"]:
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeFull"], jsii.get(self, "snowflakeFullInput"))

    @builtins.property
    @jsii.member(jsii_name="snowflakeSseInput")
    def snowflake_sse_input(
        self,
    ) -> typing.Optional["StageInternalEncryptionSnowflakeSse"]:
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeSse"], jsii.get(self, "snowflakeSseInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalEncryption"]:
        return typing.cast(typing.Optional["StageInternalEncryption"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["StageInternalEncryption"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__632fef5b723da27c929b399346a58815f99db695967d8f763d70e34e466284be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryptionSnowflakeFull",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalEncryptionSnowflakeFull:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalEncryptionSnowflakeFull(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalEncryptionSnowflakeFullOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryptionSnowflakeFullOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ae939daac78f4973ab0562ffd1cde6b42884d1dc1c2e1c2c17d0a70f0fc5bf0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalEncryptionSnowflakeFull"]:
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeFull"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalEncryptionSnowflakeFull"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88cf80dc57de86dc46f1dba17c154bfcee8ed3c60d42773ccd516722dee64f8a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryptionSnowflakeSse",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalEncryptionSnowflakeSse:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalEncryptionSnowflakeSse(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalEncryptionSnowflakeSseOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalEncryptionSnowflakeSseOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d45c2bab466c73ed65d70702ab6cc23e8e380e6d72e7b47587a9a74019f4ff0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalEncryptionSnowflakeSse"]:
        return typing.cast(typing.Optional["StageInternalEncryptionSnowflakeSse"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalEncryptionSnowflakeSse"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cff0005d6fef7f53425b7e491f93d280dfcbfa401b88505103906e0e4491a3cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormat",
    jsii_struct_bases=[],
    name_mapping={
        "avro": "avro",
        "csv": "csv",
        "format_name": "formatName",
        "json": "json",
        "orc": "orc",
        "parquet": "parquet",
        "xml": "xml",
    },
)
class StageInternalFileFormat:
    def __init__(
        self,
        *,
        avro: typing.Optional[typing.Union["StageInternalFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageInternalFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageInternalFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageInternalFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageInternalFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageInternalFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#avro StageInternal#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#csv StageInternal#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#format_name StageInternal#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#json StageInternal#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#orc StageInternal#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parquet StageInternal#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#xml StageInternal#xml}
        '''
        if isinstance(avro, dict):
            avro = StageInternalFileFormatAvro(**avro)
        if isinstance(csv, dict):
            csv = StageInternalFileFormatCsv(**csv)
        if isinstance(json, dict):
            json = StageInternalFileFormatJson(**json)
        if isinstance(orc, dict):
            orc = StageInternalFileFormatOrc(**orc)
        if isinstance(parquet, dict):
            parquet = StageInternalFileFormatParquet(**parquet)
        if isinstance(xml, dict):
            xml = StageInternalFileFormatXml(**xml)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b138a1ff52a4fb6bf7b3bc98fe067a5487923d8794d50686b4a359437d804ba)
            check_type(argname="argument avro", value=avro, expected_type=type_hints["avro"])
            check_type(argname="argument csv", value=csv, expected_type=type_hints["csv"])
            check_type(argname="argument format_name", value=format_name, expected_type=type_hints["format_name"])
            check_type(argname="argument json", value=json, expected_type=type_hints["json"])
            check_type(argname="argument orc", value=orc, expected_type=type_hints["orc"])
            check_type(argname="argument parquet", value=parquet, expected_type=type_hints["parquet"])
            check_type(argname="argument xml", value=xml, expected_type=type_hints["xml"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if avro is not None:
            self._values["avro"] = avro
        if csv is not None:
            self._values["csv"] = csv
        if format_name is not None:
            self._values["format_name"] = format_name
        if json is not None:
            self._values["json"] = json
        if orc is not None:
            self._values["orc"] = orc
        if parquet is not None:
            self._values["parquet"] = parquet
        if xml is not None:
            self._values["xml"] = xml

    @builtins.property
    def avro(self) -> typing.Optional["StageInternalFileFormatAvro"]:
        '''avro block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#avro StageInternal#avro}
        '''
        result = self._values.get("avro")
        return typing.cast(typing.Optional["StageInternalFileFormatAvro"], result)

    @builtins.property
    def csv(self) -> typing.Optional["StageInternalFileFormatCsv"]:
        '''csv block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#csv StageInternal#csv}
        '''
        result = self._values.get("csv")
        return typing.cast(typing.Optional["StageInternalFileFormatCsv"], result)

    @builtins.property
    def format_name(self) -> typing.Optional[builtins.str]:
        '''Fully qualified name of the file format (e.g., 'database.schema.format_name').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#format_name StageInternal#format_name}
        '''
        result = self._values.get("format_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def json(self) -> typing.Optional["StageInternalFileFormatJson"]:
        '''json block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#json StageInternal#json}
        '''
        result = self._values.get("json")
        return typing.cast(typing.Optional["StageInternalFileFormatJson"], result)

    @builtins.property
    def orc(self) -> typing.Optional["StageInternalFileFormatOrc"]:
        '''orc block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#orc StageInternal#orc}
        '''
        result = self._values.get("orc")
        return typing.cast(typing.Optional["StageInternalFileFormatOrc"], result)

    @builtins.property
    def parquet(self) -> typing.Optional["StageInternalFileFormatParquet"]:
        '''parquet block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parquet StageInternal#parquet}
        '''
        result = self._values.get("parquet")
        return typing.cast(typing.Optional["StageInternalFileFormatParquet"], result)

    @builtins.property
    def xml(self) -> typing.Optional["StageInternalFileFormatXml"]:
        '''xml block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#xml StageInternal#xml}
        '''
        result = self._values.get("xml")
        return typing.cast(typing.Optional["StageInternalFileFormatXml"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageInternalFileFormatAvro:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0794f086ffa78ba2e3f29c389c8864cd11e9eea723b218cd5509feeead9a259e)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce60f30ac4f1391dae4f81fe3f1e37159ee946f86d619be8e7a63eac157847dc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b914915ce38b3d310525ce964a81fa050f74c78757d084485d3c10633f240242)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e2ffeeb595136e9d6d9505d3d8799ffdd9bad966dbb53cfd6f74fd8a47f1a28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2ab15db0c9e30bfd66f2079aeda5e341acafab86f1a0e111b41bf9d5ecb8ac7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3471d30ee953d4c2293f689575fb7a1948d8f1e0e7bda3805b1678b5a39a1c87)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatAvro"]:
        return typing.cast(typing.Optional["StageInternalFileFormatAvro"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatAvro"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5845895a412b97aa8efeb92c43d86d8c0ebf592964bcc5b750d6a371c8e63c0e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "empty_field_as_null": "emptyFieldAsNull",
        "encoding": "encoding",
        "error_on_column_count_mismatch": "errorOnColumnCountMismatch",
        "escape": "escape",
        "escape_unenclosed_field": "escapeUnenclosedField",
        "field_delimiter": "fieldDelimiter",
        "field_optionally_enclosed_by": "fieldOptionallyEnclosedBy",
        "file_extension": "fileExtension",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "parse_header": "parseHeader",
        "record_delimiter": "recordDelimiter",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_blank_lines": "skipBlankLines",
        "skip_byte_order_mark": "skipByteOrderMark",
        "skip_header": "skipHeader",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageInternalFileFormatCsv:
    def __init__(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#empty_field_as_null StageInternal#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encoding StageInternal#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#error_on_column_count_mismatch StageInternal#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape StageInternal#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape_unenclosed_field StageInternal#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_delimiter StageInternal#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_optionally_enclosed_by StageInternal#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parse_header StageInternal#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#record_delimiter StageInternal#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_blank_lines StageInternal#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_header StageInternal#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dea64d2f91ab318ee8d5be1f049292b07eec3939688fb4aa45a92b1acdfcd503)
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument empty_field_as_null", value=empty_field_as_null, expected_type=type_hints["empty_field_as_null"])
            check_type(argname="argument encoding", value=encoding, expected_type=type_hints["encoding"])
            check_type(argname="argument error_on_column_count_mismatch", value=error_on_column_count_mismatch, expected_type=type_hints["error_on_column_count_mismatch"])
            check_type(argname="argument escape", value=escape, expected_type=type_hints["escape"])
            check_type(argname="argument escape_unenclosed_field", value=escape_unenclosed_field, expected_type=type_hints["escape_unenclosed_field"])
            check_type(argname="argument field_delimiter", value=field_delimiter, expected_type=type_hints["field_delimiter"])
            check_type(argname="argument field_optionally_enclosed_by", value=field_optionally_enclosed_by, expected_type=type_hints["field_optionally_enclosed_by"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument parse_header", value=parse_header, expected_type=type_hints["parse_header"])
            check_type(argname="argument record_delimiter", value=record_delimiter, expected_type=type_hints["record_delimiter"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_blank_lines", value=skip_blank_lines, expected_type=type_hints["skip_blank_lines"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument skip_header", value=skip_header, expected_type=type_hints["skip_header"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if empty_field_as_null is not None:
            self._values["empty_field_as_null"] = empty_field_as_null
        if encoding is not None:
            self._values["encoding"] = encoding
        if error_on_column_count_mismatch is not None:
            self._values["error_on_column_count_mismatch"] = error_on_column_count_mismatch
        if escape is not None:
            self._values["escape"] = escape
        if escape_unenclosed_field is not None:
            self._values["escape_unenclosed_field"] = escape_unenclosed_field
        if field_delimiter is not None:
            self._values["field_delimiter"] = field_delimiter
        if field_optionally_enclosed_by is not None:
            self._values["field_optionally_enclosed_by"] = field_optionally_enclosed_by
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if parse_header is not None:
            self._values["parse_header"] = parse_header
        if record_delimiter is not None:
            self._values["record_delimiter"] = record_delimiter
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_blank_lines is not None:
            self._values["skip_blank_lines"] = skip_blank_lines
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if skip_header is not None:
            self._values["skip_header"] = skip_header
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def empty_field_as_null(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#empty_field_as_null StageInternal#empty_field_as_null}
        '''
        result = self._values.get("empty_field_as_null")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encoding(self) -> typing.Optional[builtins.str]:
        '''Specifies the character set of the source data when loading data into a table.

        Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encoding StageInternal#encoding}
        '''
        result = self._values.get("encoding")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def error_on_column_count_mismatch(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#error_on_column_count_mismatch StageInternal#error_on_column_count_mismatch}
        '''
        result = self._values.get("error_on_column_count_mismatch")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for field values.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape StageInternal#escape}
        '''
        result = self._values.get("escape")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape_unenclosed_field(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for unenclosed field values only.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape_unenclosed_field StageInternal#escape_unenclosed_field}
        '''
        result = self._values.get("escape_unenclosed_field")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate fields in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_delimiter StageInternal#field_delimiter}
        '''
        result = self._values.get("field_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_optionally_enclosed_by(self) -> typing.Optional[builtins.str]:
        '''Character used to enclose strings. Use ``NONE`` to specify no enclosure character.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_optionally_enclosed_by StageInternal#field_optionally_enclosed_by}
        '''
        result = self._values.get("field_optionally_enclosed_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def parse_header(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parse_header StageInternal#parse_header}
        '''
        result = self._values.get("parse_header")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def record_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate records in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#record_delimiter StageInternal#record_delimiter}
        '''
        result = self._values.get("record_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_blank_lines(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_blank_lines StageInternal#skip_blank_lines}
        '''
        result = self._values.get("skip_blank_lines")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_header(self) -> typing.Optional[jsii.Number]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_header StageInternal#skip_header}
        '''
        result = self._values.get("skip_header")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__067fee58ee2eb8b1784de86f50f3c2d8a0c1ad95ffd34dcbdeaf7fcb98a22c0b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEmptyFieldAsNull")
    def reset_empty_field_as_null(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmptyFieldAsNull", []))

    @jsii.member(jsii_name="resetEncoding")
    def reset_encoding(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncoding", []))

    @jsii.member(jsii_name="resetErrorOnColumnCountMismatch")
    def reset_error_on_column_count_mismatch(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetErrorOnColumnCountMismatch", []))

    @jsii.member(jsii_name="resetEscape")
    def reset_escape(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscape", []))

    @jsii.member(jsii_name="resetEscapeUnenclosedField")
    def reset_escape_unenclosed_field(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscapeUnenclosedField", []))

    @jsii.member(jsii_name="resetFieldDelimiter")
    def reset_field_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldDelimiter", []))

    @jsii.member(jsii_name="resetFieldOptionallyEnclosedBy")
    def reset_field_optionally_enclosed_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldOptionallyEnclosedBy", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetParseHeader")
    def reset_parse_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParseHeader", []))

    @jsii.member(jsii_name="resetRecordDelimiter")
    def reset_record_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRecordDelimiter", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipBlankLines")
    def reset_skip_blank_lines(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipBlankLines", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetSkipHeader")
    def reset_skip_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipHeader", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNullInput")
    def empty_field_as_null_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emptyFieldAsNullInput"))

    @builtins.property
    @jsii.member(jsii_name="encodingInput")
    def encoding_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "encodingInput"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatchInput")
    def error_on_column_count_mismatch_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "errorOnColumnCountMismatchInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeInput")
    def escape_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedFieldInput")
    def escape_unenclosed_field_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeUnenclosedFieldInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiterInput")
    def field_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedByInput")
    def field_optionally_enclosed_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldOptionallyEnclosedByInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="parseHeaderInput")
    def parse_header_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parseHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiterInput")
    def record_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "recordDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLinesInput")
    def skip_blank_lines_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipBlankLinesInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="skipHeaderInput")
    def skip_header_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "skipHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54e61075ea45e7eb72d72d046ff13e89cf04590f850884177070a74363fecf54)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4c56a9b665f91c7fc2512cdf591cb689cfc37badfd4d180181b21d2ccc411c2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5fcadf80b9618eaef8395493de527a9857f9228dd1acadb7dfa2eef93a4c8f5b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emptyFieldAsNull"))

    @empty_field_as_null.setter
    def empty_field_as_null(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58e53b576efdd7c64de94136e5393c8d1c12fcb6f32005fd9c977f259d19f1fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emptyFieldAsNull", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @encoding.setter
    def encoding(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d460c1a053493ebfcc6b38a9e27a87ac62b95bb872a9136b6559968ff31f69e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "encoding", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "errorOnColumnCountMismatch"))

    @error_on_column_count_mismatch.setter
    def error_on_column_count_mismatch(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf305e42959383de5a1bebbbec511a52a3ec722df989d5c5cf338ac5702529be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorOnColumnCountMismatch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @escape.setter
    def escape(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba2c5abb4745aa2f814936042f72a6818009d9d0b03fbe26c83facd9692e2012)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escape", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @escape_unenclosed_field.setter
    def escape_unenclosed_field(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__974c88fe066599971f744a478683015ce056de61535330820d4277ca234d8c4e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escapeUnenclosedField", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @field_delimiter.setter
    def field_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1e6844a205f7683d8829683971cb80e738b952ef216873d7f834c15198e0ade)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @field_optionally_enclosed_by.setter
    def field_optionally_enclosed_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__158aa39dc8b2ceb26ef89e5f22b11c6661f6d1a1c1f4d3cbc2490bd3971a5e50)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldOptionallyEnclosedBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a03ed98405d34c9b421f296c160daa2108f8cd7aa36d8182e25d8540198db851)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2275b9394d1cb7da7c5e3ea0fbc55228ca6a83b158c7793d50ee646cd20c428c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d71708b77facd65842da6e4fbfae18c3a117d51e895699220e8271007924e184)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parseHeader"))

    @parse_header.setter
    def parse_header(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3ac553783be1192b2b750fa48e14d31b4a43298f51e75f36da07341cd95e09d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parseHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @record_delimiter.setter
    def record_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba5b6e600afd1c73c5106d0c0d205b1794c2854540b63a7ca79b3cfeb783de32)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "recordDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c1e8e09808b6933b1829cebc58a081ff7a9c727a7adff489827c23d4a967cddf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipBlankLines"))

    @skip_blank_lines.setter
    def skip_blank_lines(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__78b80d6486789cea8b6770827a966b69c6c4a108dd76f9b531b274cc1f16603a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipBlankLines", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f533b739829f69682900f2327070167b79288d8ef8591234ef5a6d5671d72ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @skip_header.setter
    def skip_header(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__177c618a46319652853bb88bd2f329abc314fb2a3f2d0ba180f54e08fac0e4ff)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39bf0b98fb39d78bae7b9f242aed5ce6eb0888170a107827d1750fe1577c371f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f6c7552f51f0e16cbf392136a9e433c710405fec3f3085b5b38d2670461558e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__760480e67446e1266a1832567196a34d1ff4a5ede9efe60f4d3aacccd89c0bbf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatCsv"]:
        return typing.cast(typing.Optional["StageInternalFileFormatCsv"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatCsv"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4053aabea5a5775985831fd0a425a28ee5ebbdb1c46985d839424a06c8dd4d48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={
        "allow_duplicate": "allowDuplicate",
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "enable_octal": "enableOctal",
        "file_extension": "fileExtension",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_null_values": "stripNullValues",
        "strip_outer_array": "stripOuterArray",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageInternalFileFormatJson:
    def __init__(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#allow_duplicate StageInternal#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable_octal StageInternal#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_null_values StageInternal#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_array StageInternal#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a4d197376e015164da98ed4f03fe18a4871d142c6cd5a7c2093fabeaccc99c45)
            check_type(argname="argument allow_duplicate", value=allow_duplicate, expected_type=type_hints["allow_duplicate"])
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument enable_octal", value=enable_octal, expected_type=type_hints["enable_octal"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_null_values", value=strip_null_values, expected_type=type_hints["strip_null_values"])
            check_type(argname="argument strip_outer_array", value=strip_outer_array, expected_type=type_hints["strip_outer_array"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allow_duplicate is not None:
            self._values["allow_duplicate"] = allow_duplicate
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if enable_octal is not None:
            self._values["enable_octal"] = enable_octal
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_null_values is not None:
            self._values["strip_null_values"] = strip_null_values
        if strip_outer_array is not None:
            self._values["strip_outer_array"] = strip_outer_array
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def allow_duplicate(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved).

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#allow_duplicate StageInternal#allow_duplicate}
        '''
        result = self._values.get("allow_duplicate")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_octal(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable_octal StageInternal#enable_octal}
        '''
        result = self._values.get("enable_octal")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_null_values(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_null_values StageInternal#strip_null_values}
        '''
        result = self._values.get("strip_null_values")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_array(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_array StageInternal#strip_outer_array}
        '''
        result = self._values.get("strip_outer_array")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03c74c0010bb3e7d0427e35dea01420780269993d5de142d66699f9a8e5face6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAllowDuplicate")
    def reset_allow_duplicate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowDuplicate", []))

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEnableOctal")
    def reset_enable_octal(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableOctal", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripNullValues")
    def reset_strip_null_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripNullValues", []))

    @jsii.member(jsii_name="resetStripOuterArray")
    def reset_strip_outer_array(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterArray", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicateInput")
    def allow_duplicate_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "allowDuplicateInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="enableOctalInput")
    def enable_octal_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "enableOctalInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValuesInput")
    def strip_null_values_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripNullValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArrayInput")
    def strip_outer_array_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterArrayInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "allowDuplicate"))

    @allow_duplicate.setter
    def allow_duplicate(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f26b58083c6a57120d7eb32be257774e57994daacdef2b064b7a254a3bcc1f3f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowDuplicate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__834939eb99b2f03e713a6ebb20cf1cb866ce8773f32d328ee43c6ebfc83c0733)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74be1d57503232eef4235616cfa2aeb93108bf20aaab8f5565a795d729e64761)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__42ac0e8a4bf2d9ac789a5484a3945167ddcee473ef4717d172968a2b8ddd2e5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "enableOctal"))

    @enable_octal.setter
    def enable_octal(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__091ce97e65e8793da9b39cd96b3dbd5c4e8f8578b8a92c3a503c0b9c7e66c5c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableOctal", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__061b9c5bb944ff5283fd021f3e352b5dfd76edd46b304f84de5a61f255d1e915)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da481f5795c65af419e2df781075db92d79106ec104a376e2a70f410c037c245)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d19716905bb75a9a05196723f475a9b45d805874ddef08bbe0d7574e93c3516)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cc512cc015ee0ed8355bb977874be84c2cf0df212a4dad0608cb85c059148ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c93f07a6b9aa2bbda26e091cdff3ae5e9786ca538313152b6beb60b49297a3ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56c63283ebe6214f083a228600ff976ca342458db29f8b7b2760bb748f4cfeae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripNullValues"))

    @strip_null_values.setter
    def strip_null_values(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__48bd2a088f77bc95c5a9235f2870cb9c5cf5e17fa8e4d95d1298ae747909f5bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripNullValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterArray"))

    @strip_outer_array.setter
    def strip_outer_array(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a4be4feab088837945f918e84d691a63b8992eaa70bfe690f5ab811c485c3231)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterArray", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bb96ccf7844c6de0928926c542de048a3e67ae1023ff547dd270b7ad7fa89b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e68ecc82e0182a8dbc1d9431015b33737ef7a8574adb2c2f24f5a1282d8e170e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__010ea63c36f147f30a0ad80e9c5cfc5acbdcf794c7e1a968cca04d0e18d9f745)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatJson"]:
        return typing.cast(typing.Optional["StageInternalFileFormatJson"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatJson"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fdeccea77b0ebe6f61e557acc7b3401b50b0385dde9d92dfd31abc03dc61cff)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageInternalFileFormatOrc:
    def __init__(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44fc70bf9154ba26a67a35a6b90379648aa5c2dcc4c98769d45c0bf0c076cc9d)
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__876e36f18fe477bc8b711948c1bb601b86904499f6e7ac53e8e77584c7ad797c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ad2e93f9a7a2854ccb9289435f6d442e25476d92ad44ec0d4478ba8f0058cb0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79dc64eb6647c0d69ace1c4d52b3f1afa54793b3b80812b90fa63dd0c9f06c65)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0345c1e7efadb6e017f806a2fbe35723cb48dc5b1ab205b69af9a37529491e9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatOrc"]:
        return typing.cast(typing.Optional["StageInternalFileFormatOrc"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatOrc"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4f7d1c89dbdb0d92db37c4a49dfdef694dd43363848c0bafa4ae9965663a9ad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageInternalFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__094fda2df6b2479f469759530c58a8b6af2a05084cc297599166c01698f3f508)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAvro")
    def put_avro(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        value = StageInternalFileFormatAvro(
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putAvro", [value]))

    @jsii.member(jsii_name="putCsv")
    def put_csv(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#empty_field_as_null StageInternal#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encoding StageInternal#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#error_on_column_count_mismatch StageInternal#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape StageInternal#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape_unenclosed_field StageInternal#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_delimiter StageInternal#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_optionally_enclosed_by StageInternal#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parse_header StageInternal#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#record_delimiter StageInternal#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_blank_lines StageInternal#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_header StageInternal#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        value = StageInternalFileFormatCsv(
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            empty_field_as_null=empty_field_as_null,
            encoding=encoding,
            error_on_column_count_mismatch=error_on_column_count_mismatch,
            escape=escape,
            escape_unenclosed_field=escape_unenclosed_field,
            field_delimiter=field_delimiter,
            field_optionally_enclosed_by=field_optionally_enclosed_by,
            file_extension=file_extension,
            multi_line=multi_line,
            null_if=null_if,
            parse_header=parse_header,
            record_delimiter=record_delimiter,
            replace_invalid_characters=replace_invalid_characters,
            skip_blank_lines=skip_blank_lines,
            skip_byte_order_mark=skip_byte_order_mark,
            skip_header=skip_header,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putCsv", [value]))

    @jsii.member(jsii_name="putJson")
    def put_json(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#allow_duplicate StageInternal#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable_octal StageInternal#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_null_values StageInternal#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_array StageInternal#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        value = StageInternalFileFormatJson(
            allow_duplicate=allow_duplicate,
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            enable_octal=enable_octal,
            file_extension=file_extension,
            ignore_utf8_errors=ignore_utf8_errors,
            multi_line=multi_line,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_null_values=strip_null_values,
            strip_outer_array=strip_outer_array,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putJson", [value]))

    @jsii.member(jsii_name="putOrc")
    def put_orc(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        value = StageInternalFileFormatOrc(
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putOrc", [value]))

    @jsii.member(jsii_name="putParquet")
    def put_parquet(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_as_text StageInternal#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_logical_type StageInternal#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_vectorized_scanner StageInternal#use_vectorized_scanner}
        '''
        value = StageInternalFileFormatParquet(
            binary_as_text=binary_as_text,
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
            use_logical_type=use_logical_type,
            use_vectorized_scanner=use_vectorized_scanner,
        )

        return typing.cast(None, jsii.invoke(self, "putParquet", [value]))

    @jsii.member(jsii_name="putXml")
    def put_xml(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#disable_auto_convert StageInternal#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#preserve_space StageInternal#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_element StageInternal#strip_outer_element}
        '''
        value = StageInternalFileFormatXml(
            compression=compression,
            disable_auto_convert=disable_auto_convert,
            ignore_utf8_errors=ignore_utf8_errors,
            preserve_space=preserve_space,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_outer_element=strip_outer_element,
        )

        return typing.cast(None, jsii.invoke(self, "putXml", [value]))

    @jsii.member(jsii_name="resetAvro")
    def reset_avro(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAvro", []))

    @jsii.member(jsii_name="resetCsv")
    def reset_csv(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCsv", []))

    @jsii.member(jsii_name="resetFormatName")
    def reset_format_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFormatName", []))

    @jsii.member(jsii_name="resetJson")
    def reset_json(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJson", []))

    @jsii.member(jsii_name="resetOrc")
    def reset_orc(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrc", []))

    @jsii.member(jsii_name="resetParquet")
    def reset_parquet(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParquet", []))

    @jsii.member(jsii_name="resetXml")
    def reset_xml(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetXml", []))

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> "StageInternalFileFormatAvroOutputReference":
        return typing.cast("StageInternalFileFormatAvroOutputReference", jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> "StageInternalFileFormatCsvOutputReference":
        return typing.cast("StageInternalFileFormatCsvOutputReference", jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> "StageInternalFileFormatJsonOutputReference":
        return typing.cast("StageInternalFileFormatJsonOutputReference", jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> "StageInternalFileFormatOrcOutputReference":
        return typing.cast("StageInternalFileFormatOrcOutputReference", jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageInternalFileFormatParquetOutputReference":
        return typing.cast("StageInternalFileFormatParquetOutputReference", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageInternalFileFormatXmlOutputReference":
        return typing.cast("StageInternalFileFormatXmlOutputReference", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="avroInput")
    def avro_input(self) -> typing.Optional["StageInternalFileFormatAvro"]:
        return typing.cast(typing.Optional["StageInternalFileFormatAvro"], jsii.get(self, "avroInput"))

    @builtins.property
    @jsii.member(jsii_name="csvInput")
    def csv_input(self) -> typing.Optional["StageInternalFileFormatCsv"]:
        return typing.cast(typing.Optional["StageInternalFileFormatCsv"], jsii.get(self, "csvInput"))

    @builtins.property
    @jsii.member(jsii_name="formatNameInput")
    def format_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "formatNameInput"))

    @builtins.property
    @jsii.member(jsii_name="jsonInput")
    def json_input(self) -> typing.Optional["StageInternalFileFormatJson"]:
        return typing.cast(typing.Optional["StageInternalFileFormatJson"], jsii.get(self, "jsonInput"))

    @builtins.property
    @jsii.member(jsii_name="orcInput")
    def orc_input(self) -> typing.Optional["StageInternalFileFormatOrc"]:
        return typing.cast(typing.Optional["StageInternalFileFormatOrc"], jsii.get(self, "orcInput"))

    @builtins.property
    @jsii.member(jsii_name="parquetInput")
    def parquet_input(self) -> typing.Optional["StageInternalFileFormatParquet"]:
        return typing.cast(typing.Optional["StageInternalFileFormatParquet"], jsii.get(self, "parquetInput"))

    @builtins.property
    @jsii.member(jsii_name="xmlInput")
    def xml_input(self) -> typing.Optional["StageInternalFileFormatXml"]:
        return typing.cast(typing.Optional["StageInternalFileFormatXml"], jsii.get(self, "xmlInput"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @format_name.setter
    def format_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__78bf40cc46e90a3b87b096de2810b9536f49e91e78dc999446d16e05e1727446)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "formatName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormat"]:
        return typing.cast(typing.Optional["StageInternalFileFormat"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["StageInternalFileFormat"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00cec7ecf0a49a570ee27e90ebc5b63816d29129d79b9bda240e1970669a56f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={
        "binary_as_text": "binaryAsText",
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
        "use_logical_type": "useLogicalType",
        "use_vectorized_scanner": "useVectorizedScanner",
    },
)
class StageInternalFileFormatParquet:
    def __init__(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_as_text StageInternal#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_logical_type StageInternal#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_vectorized_scanner StageInternal#use_vectorized_scanner}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__897099e576ca5a9eed29d4c02e2586772f0133e276585b8efad169e7cebf1c60)
            check_type(argname="argument binary_as_text", value=binary_as_text, expected_type=type_hints["binary_as_text"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
            check_type(argname="argument use_logical_type", value=use_logical_type, expected_type=type_hints["use_logical_type"])
            check_type(argname="argument use_vectorized_scanner", value=use_vectorized_scanner, expected_type=type_hints["use_vectorized_scanner"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_as_text is not None:
            self._values["binary_as_text"] = binary_as_text
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space
        if use_logical_type is not None:
            self._values["use_logical_type"] = use_logical_type
        if use_vectorized_scanner is not None:
            self._values["use_vectorized_scanner"] = use_vectorized_scanner

    @builtins.property
    def binary_as_text(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_as_text StageInternal#binary_as_text}
        '''
        result = self._values.get("binary_as_text")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_logical_type(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_logical_type StageInternal#use_logical_type}
        '''
        result = self._values.get("use_logical_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_vectorized_scanner(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_vectorized_scanner StageInternal#use_vectorized_scanner}
        '''
        result = self._values.get("use_vectorized_scanner")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__362f6950e8ee29e81a58aaad547137f014827e02799ec04d26402cdfd99918fb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryAsText")
    def reset_binary_as_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryAsText", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @jsii.member(jsii_name="resetUseLogicalType")
    def reset_use_logical_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseLogicalType", []))

    @jsii.member(jsii_name="resetUseVectorizedScanner")
    def reset_use_vectorized_scanner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseVectorizedScanner", []))

    @builtins.property
    @jsii.member(jsii_name="binaryAsTextInput")
    def binary_as_text_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryAsTextInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalTypeInput")
    def use_logical_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useLogicalTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScannerInput")
    def use_vectorized_scanner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useVectorizedScannerInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryAsText"))

    @binary_as_text.setter
    def binary_as_text(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2075da35fcc8b6e226ecbfb1f4850e705ab5edbb2537709ef94a00ff91e7b27)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryAsText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62cb4981bceb93a59b14e0fa9e1d6d1f27b06bf496f2630df01a82fd7d500d70)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1c7c8aa6d7211290e97770b7cd28a44a39aa9893e0d16dea74bf79624794690)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ed9fcccf9c8786184508bb540c4d2beb557bcc19b0fdb52d6da9790963ff4ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1593a96d5597f4e8b01dff367ddc9e6ee47184729cd97263dea7569ca2fb60a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useLogicalType"))

    @use_logical_type.setter
    def use_logical_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eba149436d259a67898ad66531cbd65f519e032d1e85a5bfdca966d29c69fa9e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useLogicalType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useVectorizedScanner"))

    @use_vectorized_scanner.setter
    def use_vectorized_scanner(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__690e49fa783569f945a66af1305695d30f784171ea54924e78267b35743e711b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useVectorizedScanner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatParquet"]:
        return typing.cast(typing.Optional["StageInternalFileFormatParquet"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatParquet"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a967772e0b71dd8c7f042388889f763640504d28fcaa8e44353c6b538da7fa64)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "disable_auto_convert": "disableAutoConvert",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "preserve_space": "preserveSpace",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_outer_element": "stripOuterElement",
    },
)
class StageInternalFileFormatXml:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#disable_auto_convert StageInternal#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#preserve_space StageInternal#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_element StageInternal#strip_outer_element}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3aff3bd46da48cb76ce4d5ffcf1809706d2271d32938de742fadd9154b5b348d)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument disable_auto_convert", value=disable_auto_convert, expected_type=type_hints["disable_auto_convert"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument preserve_space", value=preserve_space, expected_type=type_hints["preserve_space"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_outer_element", value=strip_outer_element, expected_type=type_hints["strip_outer_element"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if disable_auto_convert is not None:
            self._values["disable_auto_convert"] = disable_auto_convert
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if preserve_space is not None:
            self._values["preserve_space"] = preserve_space
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_outer_element is not None:
            self._values["strip_outer_element"] = strip_outer_element

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def disable_auto_convert(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#disable_auto_convert StageInternal#disable_auto_convert}
        '''
        result = self._values.get("disable_auto_convert")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def preserve_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#preserve_space StageInternal#preserve_space}
        '''
        result = self._values.get("preserve_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_element(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_element StageInternal#strip_outer_element}
        '''
        result = self._values.get("strip_outer_element")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__853e48e9004adb62b5701955049e0877a248375deb29377455603dbeb24f699c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDisableAutoConvert")
    def reset_disable_auto_convert(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableAutoConvert", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetPreserveSpace")
    def reset_preserve_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreserveSpace", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripOuterElement")
    def reset_strip_outer_element(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterElement", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvertInput")
    def disable_auto_convert_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableAutoConvertInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpaceInput")
    def preserve_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "preserveSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElementInput")
    def strip_outer_element_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterElementInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5830c4b92a0ec1254b8ef5bc3d7428cac6454ea2bd5754fc410a98c88743a965)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "disableAutoConvert"))

    @disable_auto_convert.setter
    def disable_auto_convert(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86f4a7fee43936d90ceb0f5fd91b79edeb0d8b78158d085d591f6d1f524e77e7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableAutoConvert", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8dfa56f3f2e320ba0e9fc713c9c32ad3e81d93282927ff475600c26eb1d532e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "preserveSpace"))

    @preserve_space.setter
    def preserve_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd8da7d06704917eff3793298b28fea68f55c2a89908555a2f21e50be058a93a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preserveSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64b1bdbfb740b4564f819b0673905c1da73c4f654de55b493cc41a733a46f7b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b340b95cb8f26eb15e202ff5a07886d72b79fe951f0e51d011bd29c81f157286)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterElement"))

    @strip_outer_element.setter
    def strip_outer_element(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e2e8658ad0ab101a109eb26eb7ee5be7f6908f884e01340f7b028834818c624)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterElement", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalFileFormatXml"]:
        return typing.cast(typing.Optional["StageInternalFileFormatXml"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["StageInternalFileFormatXml"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7bc0bb0475ac20377b6f8537bb120b4e63ab96fe1882d427a68329136105afc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalShowOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageInternalShowOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalShowOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalShowOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalShowOutputList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecd4ba4be793426d7146baa0c6c99f9cb22353930d27ecb7b2694b2d9ad09e53)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "StageInternalShowOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f02b03c5ff63cc3ffd649cebb896a5393c8f0e2ce74180b94620d1dcdf70305f)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageInternalShowOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5fc4a770f7f6e7f438bc8578072b69bb1df22a0cddfd87f987cf7667e5c1cc19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64e438540e339225a665686c3db85881684becdc69d09ad97d96a285f1167721)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63a0263ce9ea5892b00937e301726d2bec05363c99c02ee8495d15d97a294f16)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageInternalShowOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalShowOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5614ad2e54da3b3540a5995ecbc3db792859ee7e607fcb2e2ab87978a9937298)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="cloud")
    def cloud(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cloud"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="databaseName")
    def database_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseName"))

    @builtins.property
    @jsii.member(jsii_name="directoryEnabled")
    def directory_enabled(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "directoryEnabled"))

    @builtins.property
    @jsii.member(jsii_name="endpoint")
    def endpoint(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "endpoint"))

    @builtins.property
    @jsii.member(jsii_name="hasCredentials")
    def has_credentials(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "hasCredentials"))

    @builtins.property
    @jsii.member(jsii_name="hasEncryptionKey")
    def has_encryption_key(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "hasEncryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @builtins.property
    @jsii.member(jsii_name="ownerRoleType")
    def owner_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ownerRoleType"))

    @builtins.property
    @jsii.member(jsii_name="region")
    def region(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "region"))

    @builtins.property
    @jsii.member(jsii_name="schemaName")
    def schema_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schemaName"))

    @builtins.property
    @jsii.member(jsii_name="storageIntegration")
    def storage_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "storageIntegration"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["StageInternalShowOutput"]:
        return typing.cast(typing.Optional["StageInternalShowOutput"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["StageInternalShowOutput"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57f7eff3a88c511d818de4b9311be18e5eef57cf2b1a97f8b709d4cb3ddc0525)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class StageInternalTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#create StageInternal#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#delete StageInternal#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#read StageInternal#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#update StageInternal#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52080097782c8566ba210591a2b66474d00fb7f2d0fe6f12a164307ed5dba6f5)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#create StageInternal#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#delete StageInternal#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#read StageInternal#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#update StageInternal#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageInternalTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageInternalTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageInternal.StageInternalTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acff3dad7be4f31aceaf98ebe2e924526ff1d47edb7b26bee4d08b57cac779fc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdb3ebe394e97a2c24bb2f1c25fd3d4fe2c796e2788fb5818d711b148ffdf447)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99a4b2ddc9cbdb0dca6c267b4c620eead18c16597c3c2b00eb25ac0cc3a92e61)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50b1f7b73de05dc416d113a2d0efbcf2de998695e289a498d20685a32e8798b6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fe8737a00d07f3a7337dc7772a7f2f6e296cdc8f71d010f1645e6afa6b1458a0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "StageInternalTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "StageInternalTimeouts"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "StageInternalTimeouts"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e44b42a01774c1825384fe09c79ab5fc201e68556d1b3cda78f57ee588a921c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "StageInternal",
    "StageInternalConfig",
    "StageInternalDescribeOutput",
    "StageInternalDescribeOutputDirectoryTable",
    "StageInternalDescribeOutputDirectoryTableList",
    "StageInternalDescribeOutputDirectoryTableOutputReference",
    "StageInternalDescribeOutputFileFormat",
    "StageInternalDescribeOutputFileFormatAvro",
    "StageInternalDescribeOutputFileFormatAvroList",
    "StageInternalDescribeOutputFileFormatAvroOutputReference",
    "StageInternalDescribeOutputFileFormatCsv",
    "StageInternalDescribeOutputFileFormatCsvList",
    "StageInternalDescribeOutputFileFormatCsvOutputReference",
    "StageInternalDescribeOutputFileFormatJson",
    "StageInternalDescribeOutputFileFormatJsonList",
    "StageInternalDescribeOutputFileFormatJsonOutputReference",
    "StageInternalDescribeOutputFileFormatList",
    "StageInternalDescribeOutputFileFormatOrc",
    "StageInternalDescribeOutputFileFormatOrcList",
    "StageInternalDescribeOutputFileFormatOrcOutputReference",
    "StageInternalDescribeOutputFileFormatOutputReference",
    "StageInternalDescribeOutputFileFormatParquet",
    "StageInternalDescribeOutputFileFormatParquetList",
    "StageInternalDescribeOutputFileFormatParquetOutputReference",
    "StageInternalDescribeOutputFileFormatXml",
    "StageInternalDescribeOutputFileFormatXmlList",
    "StageInternalDescribeOutputFileFormatXmlOutputReference",
    "StageInternalDescribeOutputList",
    "StageInternalDescribeOutputOutputReference",
    "StageInternalDirectory",
    "StageInternalDirectoryOutputReference",
    "StageInternalEncryption",
    "StageInternalEncryptionOutputReference",
    "StageInternalEncryptionSnowflakeFull",
    "StageInternalEncryptionSnowflakeFullOutputReference",
    "StageInternalEncryptionSnowflakeSse",
    "StageInternalEncryptionSnowflakeSseOutputReference",
    "StageInternalFileFormat",
    "StageInternalFileFormatAvro",
    "StageInternalFileFormatAvroOutputReference",
    "StageInternalFileFormatCsv",
    "StageInternalFileFormatCsvOutputReference",
    "StageInternalFileFormatJson",
    "StageInternalFileFormatJsonOutputReference",
    "StageInternalFileFormatOrc",
    "StageInternalFileFormatOrcOutputReference",
    "StageInternalFileFormatOutputReference",
    "StageInternalFileFormatParquet",
    "StageInternalFileFormatParquetOutputReference",
    "StageInternalFileFormatXml",
    "StageInternalFileFormatXmlOutputReference",
    "StageInternalShowOutput",
    "StageInternalShowOutputList",
    "StageInternalShowOutputOutputReference",
    "StageInternalTimeouts",
    "StageInternalTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__71fcb9a9642d2e49097b24bbf647f3f11d4d6b4bd0197f33bf0103652461bedd(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    directory: typing.Optional[typing.Union[StageInternalDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageInternalEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageInternalFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageInternalTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa45b6f3673eed54bd5a207c396e8e2f76520f718a5e0699adc83e14c8ff99ac(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f3af50625cbdfb963d0ec8761f7baa5510a2472fca4aa42257253d7361c181de(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__224e9f088a6882f5b7aaa2b11c64f6c1473547ec6b0716be0b7e338685eedd23(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c57efce34699de686e42624a92db6884a47ac3575fdb7e3ea9be4211f87e9e48(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c176b2681e3114420c1038b83ca041c2b6481c32707ba3b7ff832c6bb9665e08(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36bdd8cce0a7d154157ea5fd6406f8dd9550e69f10a1b12361e44f37b50996b4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcc538e2622ad8fd129afe7b0acd197471f6d6054b9bbae8faf385942446ad95(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    directory: typing.Optional[typing.Union[StageInternalDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageInternalEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageInternalFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageInternalTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9665d2f5efbe37fc21ae037315b13adffa7c4c86ad0d58af4ed5afe5cdc682e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__113e505f372153d39353649b945f87b8efbfebaf6090011560ed55dcf2259520(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b9e66981213aa6f64072bea6da1299b0e9a3e4bf2f5937557281167bd72d1d8a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ff255e90d6eb9fb0d869206da779401c62e936077701ea3600da46e1123eab7(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90585298bc71cd299834566b51dbe0007081dd581ba2397ecff5f23e8919fc47(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__303b8e3848f1639df13051009cb8438c3fc9632a39da2a7bf09f2ab018758241(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e1bcc297f145881694bce335811e54fd25eb05cd953f2e8269d1fae28cb9d83(
    value: typing.Optional[StageInternalDescribeOutputDirectoryTable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3a8711eddae3becdb2bec074e058a1c48af2fc1e93eace90f1024e5e498ce67(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f05855f28495a5edef1d1b0609b730020131d381b4c587db452d1f69dfbdd44(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e6c1270d69fe833d1d4e62996c3f4a89a76ff9ab7d3b46277797bcf1f119ae4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33da0d1e70421e2a3a820548b102bb27812d9e8975f4924902c66fa584f9a6c4(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c071ee48f965434e8794db7ac6cf7eaf9c1a98abaaeca2b6afa0d52368f0a73(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1f893b4d252dc0cc2b11ca45bdbca5b1e804c0671deef605acab17c7fdbcc233(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0322fe9f4afef66e2143758731c962498262ab345f15f1c46037ad8c8ef173a(
    value: typing.Optional[StageInternalDescribeOutputFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ab7a01bc2e5ac95be5e5598ca3f2fd8651f02fd3d5141131be32f4aa58d45ad(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d7b0a20911dede692ad5cd6934af1aa1d54e6f7e6cfabbc8ed7e1e2980b159a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4e3cca888c26cfbe8aae2e76925a9030d6b5c06433cf2a70961f625a3ccdc28(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53f3f80b30906b4c3b4fc7b701ae6f6f86d5840d1513f76b043f9965802cf7ad(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d3c140d0f5f5724bb1d1bcba9b624b8786d019cad066fed83fdeeb86bbe1667(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e3723e780e61705f30b9125c21831e72e38f7b05e8229f99a76d34b4ef69e94(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d8a7161acf972484ebbba49cfe9ba245c3fbbda9765804453cb44f87f6c8ebe(
    value: typing.Optional[StageInternalDescribeOutputFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d25b49df5a77ca1cdf266ba3dd788a8a010b74aba0301f7b5462e44e693e38ce(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__685ce4ef5610c3d94b523d99cd71a84bbab324afd7120cc848985e37ebfe0773(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6bd23fb708160d57fb88e42f7e8440d80ed7a8e5f585f4a8d73edcde4bcb7a5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73a7782bdcd34378613c06dd4bd11428f1cd692860fa8ad5f2a6d88d3b2e7932(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__516a98df2b8a4d96dbf4d0f5d81724a88550f9a1da089fdf695e816faf8bee28(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__655ff984fc62ee33d08c6c10727c89d11cbfaa3b75a6cdd194e177cde6dd9fa7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08a598ac11579aaab15457108a2150c2a09019777b34e3bb9e8618f0bf2cd0fb(
    value: typing.Optional[StageInternalDescribeOutputFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a573c3c211dfb10b427c5fc42f0b20f6a1d9372fc9f73dd8b2e60da7bfd6a66(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__844c8858cf1e3b0299b594be7b8a9fd215700f2bf1da6d870ffb902c72a53c99(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cff951026f3bf92c4c2f8027dd3fc49ab6fbef04ace8b0b8e147a3b4dd2d4e4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b743e128e399cd892327050a57a902e7a1b7ae5bc599bac91c37c505220769b7(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04b984a0242d49397f243aeb7ff98681008891a623c2c0ab30b8a3577eb77f19(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39dd1073b6ec2110e73770154e9814aa8d02ba3acf7fa2673be0de32a9bb7125(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b2831118d32fac228cd9b705d71826077efec56f1b2041f55409598d89c1e3a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52ce1f5aa3a072b40fb7f6cf32dccb46fc7417fc5f24cfc43edf3ba49d8036c2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a8875dadeab25cdc39e8ad5d38cf955b9ae3eff06ee0d6a8c8d68d68e90fb15(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d067bab2b71af6ee135bc403019efd02aa9ed4ac0d1a9f18f288f9e6cfe2dff1(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__342fafc73e223a3326868f76054c6e7233b081b8407c93fc1306971a2f552aef(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16fba3b7d75bd1a31165e0f17eb1e4ca657f160ebd08695980e4d49d0850037c(
    value: typing.Optional[StageInternalDescribeOutputFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a28e71b9108f170283a1c6da73bd3b43c78daae544d25ede72ee7ee84b8c9b0a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18833a657bfac7bf812b42b5a2ce7f35f2ec541fa95109bb7d36d3facceb6623(
    value: typing.Optional[StageInternalDescribeOutputFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e30db80889a767207b14930a749fd6f80a95cdfb5ad1de92b3a3dfd3aca8d3e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2cbda310d4527f6c6a655ab09b91ef35036ef8954cd3c0035efb8e7de037040(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12e3cfb999156dfd5e314e90650756efc4be388075a929965ae2e35b4198961c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca352e34524c88c1ff91e0ccb3ebec67da007f0d45084f11a9730ad96fb4ccd1(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1962499a661f04fcef7f5b6259d6f1ea70a35449a5cf0e58b77de874f13ff7ff(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eea42636104f429c6074e9434a7aeefa244199e3e167c384c3e4f3f44cd1e778(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d25a5b3d943f2332de5b91fb250d172752de972f3734578209811d61d2db9b5(
    value: typing.Optional[StageInternalDescribeOutputFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0543b0bb96865b4687b6619cc40f168b8713e3e68830898eed3c03e6417be1f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89d4b5070f678c57379d94269f31ed5b51c147753058094c0527701fbfb4f9cd(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75c691d876fc86f9ee5efaae46f1694887dcbf4b464eef3b908c94e5cc644aab(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3baaee402f08e2b871027877e91cf746908900564cf4d86ff5e0f637b493267b(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e1b095d5705f7a6bf33b3c2c2c4f00ff8d3ae48bb76f5f765efb4666b266e3b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ac300ca33410dad15c9daf3cb443d6b4e9ba488581c8c0024ef5be64ede5ba2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0b7eff98d2005089ea6db7a02d665c79ab311d49ab02284625913b7bbac3ffe(
    value: typing.Optional[StageInternalDescribeOutputFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c926972ee6d0c7033ce1837b93c4fcae185eeec2a034f6700e47b33d08170230(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1591144ff7d45993f0254a54f5d8760494b74aa630c274734f923dc5f94c36cd(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20073c24fe922f6f6f3d43efdf9ed8d94211aabd8804a6c0b3ee8b2e3128034a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d80e3db3826dc385765755008ccf3d86c9d5d59403a2e38d53935c24ed1183c0(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13093ecde02251dacecf34c41ddd5ab34612938dd7e7df411f84a1171eeb9a99(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81618d4b5414f136d0d68e5d7767c94a9876fbd44454fe488799c8f3771c3626(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6517709eb717c611d1e4ef85366699e93d57c0a1fb5b209534029bb1396f7c7b(
    value: typing.Optional[StageInternalDescribeOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de5622a0c888c70229b2b06cc38cdaa73d8fad2870e50097e0063a945b39c240(
    *,
    enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    auto_refresh: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1140c6b284732a7e9c110b82a30e0118f8e2d73c51eafe5ed5fb64aad0e4a0fb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99bc1975ece811201717d7605433789ae2c1b75cc9879e1affafd8a9278f07e6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb8b4a7fc4252a8f799473fc4b7ba9d593c34c5378ba8ab6a3c88b8caec37abe(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c8342ac22d18ae2d8c0355cd0128d8b78bc9c71ad5745fee1e6672d782da234(
    value: typing.Optional[StageInternalDirectory],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3eb23b52f6eb2756f927f1ce647a7c2f4333fd177f27bfee1528805648d10b6(
    *,
    snowflake_full: typing.Optional[typing.Union[StageInternalEncryptionSnowflakeFull, typing.Dict[builtins.str, typing.Any]]] = None,
    snowflake_sse: typing.Optional[typing.Union[StageInternalEncryptionSnowflakeSse, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df643cf8b8046950a3741f2ce5ca9e235d19229038ec0df001c1cae5e2e1db98(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__632fef5b723da27c929b399346a58815f99db695967d8f763d70e34e466284be(
    value: typing.Optional[StageInternalEncryption],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ae939daac78f4973ab0562ffd1cde6b42884d1dc1c2e1c2c17d0a70f0fc5bf0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88cf80dc57de86dc46f1dba17c154bfcee8ed3c60d42773ccd516722dee64f8a(
    value: typing.Optional[StageInternalEncryptionSnowflakeFull],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d45c2bab466c73ed65d70702ab6cc23e8e380e6d72e7b47587a9a74019f4ff0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cff0005d6fef7f53425b7e491f93d280dfcbfa401b88505103906e0e4491a3cf(
    value: typing.Optional[StageInternalEncryptionSnowflakeSse],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b138a1ff52a4fb6bf7b3bc98fe067a5487923d8794d50686b4a359437d804ba(
    *,
    avro: typing.Optional[typing.Union[StageInternalFileFormatAvro, typing.Dict[builtins.str, typing.Any]]] = None,
    csv: typing.Optional[typing.Union[StageInternalFileFormatCsv, typing.Dict[builtins.str, typing.Any]]] = None,
    format_name: typing.Optional[builtins.str] = None,
    json: typing.Optional[typing.Union[StageInternalFileFormatJson, typing.Dict[builtins.str, typing.Any]]] = None,
    orc: typing.Optional[typing.Union[StageInternalFileFormatOrc, typing.Dict[builtins.str, typing.Any]]] = None,
    parquet: typing.Optional[typing.Union[StageInternalFileFormatParquet, typing.Dict[builtins.str, typing.Any]]] = None,
    xml: typing.Optional[typing.Union[StageInternalFileFormatXml, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0794f086ffa78ba2e3f29c389c8864cd11e9eea723b218cd5509feeead9a259e(
    *,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce60f30ac4f1391dae4f81fe3f1e37159ee946f86d619be8e7a63eac157847dc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b914915ce38b3d310525ce964a81fa050f74c78757d084485d3c10633f240242(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e2ffeeb595136e9d6d9505d3d8799ffdd9bad966dbb53cfd6f74fd8a47f1a28(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2ab15db0c9e30bfd66f2079aeda5e341acafab86f1a0e111b41bf9d5ecb8ac7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3471d30ee953d4c2293f689575fb7a1948d8f1e0e7bda3805b1678b5a39a1c87(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5845895a412b97aa8efeb92c43d86d8c0ebf592964bcc5b750d6a371c8e63c0e(
    value: typing.Optional[StageInternalFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dea64d2f91ab318ee8d5be1f049292b07eec3939688fb4aa45a92b1acdfcd503(
    *,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    empty_field_as_null: typing.Optional[builtins.str] = None,
    encoding: typing.Optional[builtins.str] = None,
    error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
    escape: typing.Optional[builtins.str] = None,
    escape_unenclosed_field: typing.Optional[builtins.str] = None,
    field_delimiter: typing.Optional[builtins.str] = None,
    field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    parse_header: typing.Optional[builtins.str] = None,
    record_delimiter: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_blank_lines: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    skip_header: typing.Optional[jsii.Number] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__067fee58ee2eb8b1784de86f50f3c2d8a0c1ad95ffd34dcbdeaf7fcb98a22c0b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54e61075ea45e7eb72d72d046ff13e89cf04590f850884177070a74363fecf54(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4c56a9b665f91c7fc2512cdf591cb689cfc37badfd4d180181b21d2ccc411c2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5fcadf80b9618eaef8395493de527a9857f9228dd1acadb7dfa2eef93a4c8f5b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58e53b576efdd7c64de94136e5393c8d1c12fcb6f32005fd9c977f259d19f1fe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d460c1a053493ebfcc6b38a9e27a87ac62b95bb872a9136b6559968ff31f69e9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf305e42959383de5a1bebbbec511a52a3ec722df989d5c5cf338ac5702529be(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba2c5abb4745aa2f814936042f72a6818009d9d0b03fbe26c83facd9692e2012(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__974c88fe066599971f744a478683015ce056de61535330820d4277ca234d8c4e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1e6844a205f7683d8829683971cb80e738b952ef216873d7f834c15198e0ade(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__158aa39dc8b2ceb26ef89e5f22b11c6661f6d1a1c1f4d3cbc2490bd3971a5e50(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a03ed98405d34c9b421f296c160daa2108f8cd7aa36d8182e25d8540198db851(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2275b9394d1cb7da7c5e3ea0fbc55228ca6a83b158c7793d50ee646cd20c428c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d71708b77facd65842da6e4fbfae18c3a117d51e895699220e8271007924e184(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3ac553783be1192b2b750fa48e14d31b4a43298f51e75f36da07341cd95e09d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba5b6e600afd1c73c5106d0c0d205b1794c2854540b63a7ca79b3cfeb783de32(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1e8e09808b6933b1829cebc58a081ff7a9c727a7adff489827c23d4a967cddf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__78b80d6486789cea8b6770827a966b69c6c4a108dd76f9b531b274cc1f16603a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f533b739829f69682900f2327070167b79288d8ef8591234ef5a6d5671d72ce(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__177c618a46319652853bb88bd2f329abc314fb2a3f2d0ba180f54e08fac0e4ff(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39bf0b98fb39d78bae7b9f242aed5ce6eb0888170a107827d1750fe1577c371f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f6c7552f51f0e16cbf392136a9e433c710405fec3f3085b5b38d2670461558e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__760480e67446e1266a1832567196a34d1ff4a5ede9efe60f4d3aacccd89c0bbf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4053aabea5a5775985831fd0a425a28ee5ebbdb1c46985d839424a06c8dd4d48(
    value: typing.Optional[StageInternalFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4d197376e015164da98ed4f03fe18a4871d142c6cd5a7c2093fabeaccc99c45(
    *,
    allow_duplicate: typing.Optional[builtins.str] = None,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    enable_octal: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_null_values: typing.Optional[builtins.str] = None,
    strip_outer_array: typing.Optional[builtins.str] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03c74c0010bb3e7d0427e35dea01420780269993d5de142d66699f9a8e5face6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f26b58083c6a57120d7eb32be257774e57994daacdef2b064b7a254a3bcc1f3f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__834939eb99b2f03e713a6ebb20cf1cb866ce8773f32d328ee43c6ebfc83c0733(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74be1d57503232eef4235616cfa2aeb93108bf20aaab8f5565a795d729e64761(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42ac0e8a4bf2d9ac789a5484a3945167ddcee473ef4717d172968a2b8ddd2e5d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__091ce97e65e8793da9b39cd96b3dbd5c4e8f8578b8a92c3a503c0b9c7e66c5c0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__061b9c5bb944ff5283fd021f3e352b5dfd76edd46b304f84de5a61f255d1e915(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da481f5795c65af419e2df781075db92d79106ec104a376e2a70f410c037c245(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d19716905bb75a9a05196723f475a9b45d805874ddef08bbe0d7574e93c3516(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cc512cc015ee0ed8355bb977874be84c2cf0df212a4dad0608cb85c059148ae(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c93f07a6b9aa2bbda26e091cdff3ae5e9786ca538313152b6beb60b49297a3ca(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56c63283ebe6214f083a228600ff976ca342458db29f8b7b2760bb748f4cfeae(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__48bd2a088f77bc95c5a9235f2870cb9c5cf5e17fa8e4d95d1298ae747909f5bd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4be4feab088837945f918e84d691a63b8992eaa70bfe690f5ab811c485c3231(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bb96ccf7844c6de0928926c542de048a3e67ae1023ff547dd270b7ad7fa89b8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e68ecc82e0182a8dbc1d9431015b33737ef7a8574adb2c2f24f5a1282d8e170e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__010ea63c36f147f30a0ad80e9c5cfc5acbdcf794c7e1a968cca04d0e18d9f745(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fdeccea77b0ebe6f61e557acc7b3401b50b0385dde9d92dfd31abc03dc61cff(
    value: typing.Optional[StageInternalFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44fc70bf9154ba26a67a35a6b90379648aa5c2dcc4c98769d45c0bf0c076cc9d(
    *,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__876e36f18fe477bc8b711948c1bb601b86904499f6e7ac53e8e77584c7ad797c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ad2e93f9a7a2854ccb9289435f6d442e25476d92ad44ec0d4478ba8f0058cb0(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79dc64eb6647c0d69ace1c4d52b3f1afa54793b3b80812b90fa63dd0c9f06c65(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0345c1e7efadb6e017f806a2fbe35723cb48dc5b1ab205b69af9a37529491e9d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4f7d1c89dbdb0d92db37c4a49dfdef694dd43363848c0bafa4ae9965663a9ad(
    value: typing.Optional[StageInternalFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__094fda2df6b2479f469759530c58a8b6af2a05084cc297599166c01698f3f508(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__78bf40cc46e90a3b87b096de2810b9536f49e91e78dc999446d16e05e1727446(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00cec7ecf0a49a570ee27e90ebc5b63816d29129d79b9bda240e1970669a56f9(
    value: typing.Optional[StageInternalFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__897099e576ca5a9eed29d4c02e2586772f0133e276585b8efad169e7cebf1c60(
    *,
    binary_as_text: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
    use_logical_type: typing.Optional[builtins.str] = None,
    use_vectorized_scanner: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__362f6950e8ee29e81a58aaad547137f014827e02799ec04d26402cdfd99918fb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2075da35fcc8b6e226ecbfb1f4850e705ab5edbb2537709ef94a00ff91e7b27(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62cb4981bceb93a59b14e0fa9e1d6d1f27b06bf496f2630df01a82fd7d500d70(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1c7c8aa6d7211290e97770b7cd28a44a39aa9893e0d16dea74bf79624794690(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ed9fcccf9c8786184508bb540c4d2beb557bcc19b0fdb52d6da9790963ff4ee(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1593a96d5597f4e8b01dff367ddc9e6ee47184729cd97263dea7569ca2fb60a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eba149436d259a67898ad66531cbd65f519e032d1e85a5bfdca966d29c69fa9e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__690e49fa783569f945a66af1305695d30f784171ea54924e78267b35743e711b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a967772e0b71dd8c7f042388889f763640504d28fcaa8e44353c6b538da7fa64(
    value: typing.Optional[StageInternalFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3aff3bd46da48cb76ce4d5ffcf1809706d2271d32938de742fadd9154b5b348d(
    *,
    compression: typing.Optional[builtins.str] = None,
    disable_auto_convert: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    preserve_space: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_outer_element: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__853e48e9004adb62b5701955049e0877a248375deb29377455603dbeb24f699c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5830c4b92a0ec1254b8ef5bc3d7428cac6454ea2bd5754fc410a98c88743a965(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86f4a7fee43936d90ceb0f5fd91b79edeb0d8b78158d085d591f6d1f524e77e7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8dfa56f3f2e320ba0e9fc713c9c32ad3e81d93282927ff475600c26eb1d532e4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd8da7d06704917eff3793298b28fea68f55c2a89908555a2f21e50be058a93a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64b1bdbfb740b4564f819b0673905c1da73c4f654de55b493cc41a733a46f7b3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b340b95cb8f26eb15e202ff5a07886d72b79fe951f0e51d011bd29c81f157286(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e2e8658ad0ab101a109eb26eb7ee5be7f6908f884e01340f7b028834818c624(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7bc0bb0475ac20377b6f8537bb120b4e63ab96fe1882d427a68329136105afc(
    value: typing.Optional[StageInternalFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecd4ba4be793426d7146baa0c6c99f9cb22353930d27ecb7b2694b2d9ad09e53(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f02b03c5ff63cc3ffd649cebb896a5393c8f0e2ce74180b94620d1dcdf70305f(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5fc4a770f7f6e7f438bc8578072b69bb1df22a0cddfd87f987cf7667e5c1cc19(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64e438540e339225a665686c3db85881684becdc69d09ad97d96a285f1167721(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63a0263ce9ea5892b00937e301726d2bec05363c99c02ee8495d15d97a294f16(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5614ad2e54da3b3540a5995ecbc3db792859ee7e607fcb2e2ab87978a9937298(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57f7eff3a88c511d818de4b9311be18e5eef57cf2b1a97f8b709d4cb3ddc0525(
    value: typing.Optional[StageInternalShowOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52080097782c8566ba210591a2b66474d00fb7f2d0fe6f12a164307ed5dba6f5(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acff3dad7be4f31aceaf98ebe2e924526ff1d47edb7b26bee4d08b57cac779fc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdb3ebe394e97a2c24bb2f1c25fd3d4fe2c796e2788fb5818d711b148ffdf447(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99a4b2ddc9cbdb0dca6c267b4c620eead18c16597c3c2b00eb25ac0cc3a92e61(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50b1f7b73de05dc416d113a2d0efbcf2de998695e289a498d20685a32e8798b6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fe8737a00d07f3a7337dc7772a7f2f6e296cdc8f71d010f1645e6afa6b1458a0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e44b42a01774c1825384fe09c79ab5fc201e68556d1b3cda78f57ee588a921c(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageInternalTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
