from .fasttps import *

__doc__ = fasttps.__doc__
if hasattr(fasttps, "__all__"):
    __all__ = fasttps.__all__