# Keiro

EB1 multi-model ensemble inference. Run multiple frontier models in parallel
and synthesize the best response.

## Quick start

```bash
pip install keiro
keiro setup
```

```python
from keiro import complete

print(complete("What is machine learning?"))
```

## How it works

EB1 sends your prompt to multiple frontier models (Claude, GPT, Gemini) in
parallel, then a judge synthesizes the strongest elements into a single
response. The result is more accurate and more complete than any individual
model.

## Models

| Model | Description |
|-------|-------------|
| `eb1` (default) | 3-model ensemble with synthesis |
| `eb1-pro` | 4-model ensemble for harder tasks |
| `claude-opus-4-6` | Direct passthrough (no ensemble) |
| `gpt-5.2` | Direct passthrough |

```python
from keiro import complete

# Default ensemble
answer = complete("Solve this step by step: what is 23 * 47?")

# Specific model
answer = complete("Write a haiku", model="claude-opus-4-6")
```

## Configuration

**Interactive setup** (recommended):

```bash
keiro setup
```

This validates your API key against the gateway and saves credentials to
`~/.keiro/credentials`.

**Environment variables**:

```bash
export KEIRO_API_KEY="your-api-key"
export KEIRO_BASE_URL="https://api.keiro.ai"  # optional
```

**Explicit arguments**:

```python
complete("Hello", api_key="your-key", base_url="https://api.keiro.ai")
```

Precedence: explicit arguments > environment variables > credentials file.

## Requirements

- Python 3.11+
- No GPU required (inference runs on Keiro's hosted infrastructure)
