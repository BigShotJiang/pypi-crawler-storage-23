"""Keiro infrastructure defaults — single source of truth.

Values are read from ``defaults.yaml`` (bundled inside the wheel).
Override at runtime via ``~/.keiro/credentials``, environment variables,
or explicit function arguments.

Missing keys cause immediate ``KeyError`` with a clear traceback —
no silent fallbacks.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict

import yaml

_DEFAULTS_PATH = Path(__file__).parent / "defaults.yaml"
_DEFAULTS = yaml.safe_load(_DEFAULTS_PATH.read_text())

DEFAULT_GATEWAY_URL: str = _DEFAULTS["gateway"]["url"]
DEFAULT_MODEL: str = _DEFAULTS["gateway"]["model"]

# --- Timeout defaults (seconds) ---
_TIMEOUTS: Dict[str, object] = _DEFAULTS["timeouts"]

CONNECT_TIMEOUT: float = float(_TIMEOUTS["connect"])
READ_TIMEOUT_STANDARD: float = float(_TIMEOUTS["read_standard"])
READ_TIMEOUT_REASONING: float = float(_TIMEOUTS["read_reasoning"])

EB1_PER_STAGE_TIMEOUT: Dict[str, float] = {
    k: float(v) for k, v in _TIMEOUTS["eb1_per_stage"].items()  # type: ignore[union-attr]
}
EB1_VARIANT_STAGES: Dict[str, int] = {
    k: int(v) for k, v in _TIMEOUTS["eb1_stages"].items()  # type: ignore[union-attr]
}
