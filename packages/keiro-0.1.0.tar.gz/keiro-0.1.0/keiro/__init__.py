"""Keiro — EB1 multi-model ensemble inference.

Quick start::

    pip install keiro
    keiro setup                          # configure your API key
    from keiro import complete
    print(complete("What is ML?"))

The ``complete`` function sends a prompt to the hosted Keiro API and
returns the response text. EB1 runs multiple frontier models in
parallel and synthesizes the best response.

Models:

    - ``"eb1"`` (default) — 3-model ensemble with synthesis
    - ``"eb1-pro"`` — 4-model ensemble for harder tasks
    - ``"claude-opus-4-6"`` — direct passthrough (no ensemble)
    - ``"gpt-5.2"`` — direct passthrough

Configuration:

    Run ``keiro setup`` to store your API key at ``~/.keiro/credentials``,
    or set ``KEIRO_API_KEY`` and ``KEIRO_BASE_URL`` environment variables.
"""

__version__ = "0.1.0"


def complete(
    prompt: str,
    **kwargs: object,
) -> str:
    """Send a prompt to the Keiro gateway and return the response text.

    Args:
        prompt: The user message to send.
        **kwargs: Passed to :func:`keiro.client.complete`. Supported
            keyword arguments: ``model``, ``api_key``, ``base_url``,
            ``timeout``.

    Returns:
        The model's response text.

    Raises:
        ValueError: If no API key is configured.
        requests.HTTPError: On non-2xx gateway responses.
    """
    from keiro.client import complete as _complete

    return _complete(prompt, **kwargs)  # type: ignore[arg-type]


__all__ = ["complete", "__version__"]
