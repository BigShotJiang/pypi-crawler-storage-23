Misorientations
===============