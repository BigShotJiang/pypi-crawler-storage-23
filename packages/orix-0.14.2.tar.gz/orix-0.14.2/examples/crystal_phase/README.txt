Crystal phase
=============

Examples showing how to create and work with crystal phases.