Crystal symmetry
================
