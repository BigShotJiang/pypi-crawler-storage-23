{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. minigallery:: {{ module }}.{{ objname }}
    :add-heading: Examples using ``{{ objname }}``
