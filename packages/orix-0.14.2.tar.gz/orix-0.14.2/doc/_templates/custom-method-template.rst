{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}

.. minigallery:: {{ module }}.{{ objname }}
    :add-heading: Examples using ``{{ objname }}``
