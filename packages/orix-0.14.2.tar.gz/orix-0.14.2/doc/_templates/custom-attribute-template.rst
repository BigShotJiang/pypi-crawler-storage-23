{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. autoproperty:: {{ objname }}

.. minigallery:: {{ module }}.{{ objname }}
    :add-heading: Examples using ``{{ objname }}``
