Visit https://github.com/pyxem/orix/tree/develop/doc/tutorials/ for the tutorials.

.. The tutorials must be placed there and not here to prevent ``nbsphinx`` running the
   notebooks every time the documentation is built (with ``nbsphinx_execute = "auto"``).