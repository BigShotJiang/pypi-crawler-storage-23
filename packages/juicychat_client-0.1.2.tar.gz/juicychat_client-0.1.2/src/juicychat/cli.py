import getpass
import json
import os
import re
import textwrap
from typing import Any, Callable, Optional, Sequence

import dotenv

from .client import Gender, JuicyChatClient, SortName, TaskId


def display_message(user: str, message: str, max_width: int = 90) -> None:
    user = user.upper()
    message = re.sub(r"\s+", " ", message).strip()
    combined_message = f"{user}: {message}"
    formatted_message = "\n" + textwrap.fill(
        combined_message, width=max_width, subsequent_indent="  "
    )
    print(formatted_message)


def select_option(
    options: Sequence[Any],
    prompt: str = "Enter option number: ",
    label_func: Optional[Callable[[Any], str]] = None,
    allow_skip: bool = False,
) -> Any:
    print("")
    if allow_skip:
        print("0: Skip selection")

    for idx, option in enumerate(options):
        label = label_func(option) if label_func is not None else option
        print(f"{idx + 1}: {label}")

    print("")
    while True:
        try:
            selected_idx = int(input(prompt))
            if allow_skip and selected_idx == 0:
                return None
            if 1 <= selected_idx <= len(options):
                return options[selected_idx - 1]
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid index.")


def interactive_chat(client: JuicyChatClient):

    relations = client.get_chat_relations()
    if not relations:
        print("No chat relation found.")
        return

    print("Chat Relations:")
    print(json.dumps(relations, indent=4))

    relation = select_option(
        relations,
        prompt="Enter character number: ",
        label_func=lambda x: x["characterInfo"]["characterName"],
        allow_skip=True,
    )
    if not relation:
        return

    character_id = relation["characterId"]
    character_name = relation["characterInfo"]["characterName"]
    introduction = relation["characterInfo"]["introduction"]
    print(f"Selected Character: {character_name} (ID: {character_id})")

    print(f"\nIntroduction: {introduction}")

    messages = client.get_chat_messages(character_id)
    for message in reversed(messages):
        user = message["sendType"]
        content = message["content"]
        display_message(user, content)

    while True:
        message = input("\nEnter message (or 'q' to quit): ")
        if message.lower() == "q":
            print("Chat terminated by user. Bye!")
            break
        response = client.send_chat_message(character_id, message)
        display_message(character_name, response)


def search_characters(client: JuicyChatClient):
    while True:
        search_terms = input("Enter search terms: ")
        characters = client.search_characters(
            search_terms, gender=Gender.FEMALE, sort_name=SortName.POPULAR
        )
        if not characters:
            print("No character matches the search terms. Please try again.")
            continue
        character = select_option(
            characters,
            prompt="Enter character number: ",
            label_func=lambda x: x["characterName"],
            allow_skip=True,
        )
        if character:
            print(
                f"Selected Character: {character['characterName']} (ID: {character['characterId']})"
            )
            break
        else:
            print("No character selected. Please try again.")
            continue


def create_persona(client: JuicyChatClient):
    title = input("Enter title: ")
    name = input("Enter name: ")
    description = input("Enter description: ")
    gender = input("Enter gender (male/female/non-binary): ")
    gender = gender.strip().lower()
    if gender == "male":
        gender = Gender.MALE
    elif gender == "female":
        gender = Gender.FEMALE
    elif gender == "non-binary":
        gender = Gender.NON_BINARY
    else:
        raise ValueError("Invalid gender")

    while True:
        try:
            age = int(input("Enter age: "))
            if age > 0:
                break
            else:
                print("Invalid age. Please enter a valid age.")
        except ValueError:
            print("Invalid age. Please enter a valid age.")
            continue

    client.create_persona(title, name, description, gender, age)
    print("Created persona")


def claim_task_rewards(client: JuicyChatClient):
    user_info = client.get_user_info()
    user_id = user_info["userId"]
    print(f"User ID: {user_id}")

    claim_response = client.claim_task_reward(user_id, TaskId.SEND_TEN_MESSAGES)
    print("Claim 'Send 10 Messages' response:")
    print(json.dumps(claim_response, indent=4))

    claim_response = client.claim_task_reward(user_id, TaskId.CHAT_THREE_CHARACTERS)
    print("Claim 'Chat Three Characters' response:")
    print(json.dumps(claim_response, indent=4))


def get_user_number_and_password():
    user_number = os.getenv("JUICYCHAT_USERNUMBER")
    if not user_number:
        user_number = input("Enter user number: ")

    password = os.getenv("JUICYCHAT_PASSWORD")
    if not password:
        password = getpass.getpass("Enter password: ")
    return user_number, password


def main() -> None:
    dotenv.load_dotenv()
    user_number, password = get_user_number_and_password()
    client = JuicyChatClient(
        user_number,
        password,
        key=os.getenv("JUICYCHAT_KEY"),
        iv=os.getenv("JUICYCHAT_IV"),
    )
    client.update_content_filter(allow_nsfw=True)

    options = [
        "Interactive Chat",
        "Search Characters",
        "Claim Task Rewards",
        "Create Persona",
        "Exit",
    ]

    try:
        while True:
            option = select_option(options)
            print("")

            if option == "Interactive Chat":
                interactive_chat(client)
            elif option == "Search Characters":
                search_characters(client)
            elif option == "Claim Task Rewards":
                claim_task_rewards(client)
            elif option == "Create Persona":
                create_persona(client)
            elif option == "Exit":
                break
            else:
                print("Invalid option; please try again.")
                continue
    except KeyboardInterrupt:
        print("Keyboard interrupt")
    finally:
        print("Exiting...")
        exit(0)


if __name__ == "__main__":
    main()
