import datetime as dt
import random
import uuid


def create_random_uuid() -> str:
    """
    Generate a custom UUID-like 34-character string:
    - Standard UUID v4 with hyphens removed (32 hex chars)
    - Two random marker characters inserted at positions 5 and 10
      from ["m", "t", "6", "6"] and ["4", "g", "l", "l"] respectively.
    """
    raw = uuid.uuid4().hex  # 32 hex chars, no hyphens
    markers = [
        ["m", "t", "6", "6"],
        ["4", "g", "l", "l"],
    ]
    chars = list(raw)
    chars.insert(5, random.choice(markers[0]))
    chars.insert(10, random.choice(markers[1]))
    return "".join(chars)


def timezone_offset_minutes() -> int:
    """Return JS-style timezone offset (UTC - local), in minutes."""
    now = dt.datetime.now().astimezone()
    offset = now.utcoffset() or dt.timedelta(0)
    local_minus_utc = int(offset.total_seconds() // 60)
    return -local_minus_utc
