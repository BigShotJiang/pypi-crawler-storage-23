BASE_URL = "https://www.juicychat.ai"
