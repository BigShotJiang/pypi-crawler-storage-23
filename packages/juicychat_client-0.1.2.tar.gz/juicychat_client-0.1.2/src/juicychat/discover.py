import re
import urllib.parse
from dataclasses import dataclass

from curl_cffi import requests

from .constants import BASE_URL

BUNDLE_SCRIPT_RE = re.compile(
    r'<script[^>]+src="([^"]*index-[^"]+\.js)"', re.IGNORECASE
)
CRYPTO_RE = re.compile(
    r'key=CryptoJS\.enc\.Utf8\.parse\("([^"]+)"\),iv=CryptoJS\.enc\.Utf8\.parse\("([^"]+)"\)'
)
ENDPOINT_RE = re.compile(r"/yume/api/[A-Za-z0-9_\-/]+")
APP_VERSION_RE = re.compile(r"/yume-home/([^/]+)/dist/index-[^/]+\.js$")


@dataclass
class BundleInfo:
    base_url: str
    bundle_url: str
    key: str
    iv: str
    app_version: str
    endpoints: list[str]


def discover_bundle(timeout: int = 30) -> BundleInfo:
    session = requests.Session(impersonate="chrome")
    html = session.get(BASE_URL, timeout=timeout).text
    script_candidates = BUNDLE_SCRIPT_RE.findall(html)
    if not script_candidates:
        raise RuntimeError("Could not find index-*.js bundle on homepage.")

    bundle_url = urllib.parse.urljoin(BASE_URL, script_candidates[-1])
    bundle_text = session.get(bundle_url, timeout=timeout).text

    crypto_match = CRYPTO_RE.search(bundle_text)
    if not crypto_match:
        raise RuntimeError("Could not find crypto values in bundle.")
    key, iv = crypto_match.group(1), crypto_match.group(2)

    app_version_match = APP_VERSION_RE.search(bundle_url)
    if not app_version_match:
        raise RuntimeError("Could not find app version in bundle.")
    app_version = app_version_match.group(1)

    endpoints = sorted(set(ENDPOINT_RE.findall(bundle_text)))

    return BundleInfo(
        base_url=BASE_URL,
        bundle_url=bundle_url,
        key=key,
        iv=iv,
        app_version=app_version,
        endpoints=endpoints,
    )
