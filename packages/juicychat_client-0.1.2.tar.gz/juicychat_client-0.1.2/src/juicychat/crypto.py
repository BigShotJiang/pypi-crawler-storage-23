import base64
import os
import sys
import argparse

import dotenv
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


class JuicyChatCrypto:
    def __init__(self, key: str, iv: str):
        key_bytes = key.encode("utf-8")
        iv_bytes = iv.encode("utf-8")
        if len(key_bytes) != 16:
            raise ValueError(f"AES key must be 16 bytes, got {len(key_bytes)}")
        if len(iv_bytes) != 16:
            raise ValueError(f"AES IV must be 16 bytes, got {len(iv_bytes)}")
        self.key_bytes = key_bytes
        self.iv_bytes = iv_bytes

    def encrypt_request_data(self, plaintext: str) -> str:
        base64_plaintext = base64.b64encode(plaintext.encode("utf-8"))
        padder = padding.PKCS7(128).padder()
        padded = padder.update(base64_plaintext) + padder.finalize()

        cipher = Cipher(algorithms.AES(self.key_bytes), modes.CBC(self.iv_bytes))
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(padded) + encryptor.finalize()
        return base64.b64encode(ciphertext).decode("utf-8")

    def decrypt_response_data(self, ciphertext_b64: str) -> str:
        ciphertext = base64.b64decode(ciphertext_b64)
        cipher = Cipher(algorithms.AES(self.key_bytes), modes.CBC(self.iv_bytes))
        decryptor = cipher.decryptor()
        padded = decryptor.update(ciphertext) + decryptor.finalize()

        unpadder = padding.PKCS7(128).unpadder()
        base64_plaintext = unpadder.update(padded) + unpadder.finalize()
        plaintext = base64.b64decode(base64_plaintext)
        return plaintext.decode("utf-8")


if __name__ == "__main__":
    dotenv.load_dotenv()

    parser = argparse.ArgumentParser(description="Decrypt a ciphertext")
    parser.add_argument("file", help="File to decrypt; use '-' for stdin")
    args = parser.parse_args()

    if args.file == "-":
        data = sys.stdin.read().strip()
    else:
        with open(args.file, "r") as file:
            data = file.read().strip()

    key = os.getenv("JUICYCHAT_KEY")
    iv = os.getenv("JUICYCHAT_IV")
    if not key or not iv:
        print("Error: JUICYCHAT_KEY or JUICYCHAT_IV is not set")
        sys.exit(1)

    crypto = JuicyChatCrypto(key, iv)
    print(crypto.decrypt_response_data(data))
