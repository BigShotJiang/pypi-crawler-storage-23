# JuicyChat Client

Unofficial Python client for [JuicyChat](https://www.juicychat.ai). It handles login, encrypted request/response payloads, and provides a rudimentary CLI for interactive chat, character search, personas, and task rewards.

## Features

- **Authentication** — Login with user number and password
- **Characters** — Search characters by term, tags, gender, and sort order; list chat relations
- **Chat** — Send messages and stream replies; list and clear chat history
- **Personas** — Create personas and attach them to character chats
- **Tasks** — Claim task rewards (e.g. send 10 messages, chat with 3 characters)
- **Crypto** — AES-encrypted API payloads; key/IV from env or auto-discovered from the site bundle

## Requirements

- Python 3.11+
- `cryptography`, `curl_cffi`, `python-dotenv` (see `requirements.txt`)

## Installation

```bash
pip install juicychat-client
```

## Configuration

Credentials and crypto can be set via environment variables or a `.env` file.

| Variable | Description |
|----------|-------------|
| `JUICYCHAT_USERNUMBER` | Account user number |
| `JUICYCHAT_PASSWORD` | Account password |
| `JUICYCHAT_KEY` | 16-byte AES key (UTF-8) for request/response encryption |
| `JUICYCHAT_IV` | 16-byte AES IV (UTF-8) |

If `JUICYCHAT_KEY` and `JUICYCHAT_IV` are not set, the CLI and `discover_bundle()` will fetch the site’s JS bundle and extract the current key/IV. For stability, setting them in `.env` is recommended once you have them.

## Usage

### CLI

Run the interactive menu (login uses env or prompts for user number/password):

```bash
python -m juicychat.cli
```

Options:

- **Interactive Chat** — Pick a chat relation, view history, send messages
- **Search Characters** — Search and select a character
- **Claim Task Rewards** — Claim “Send 10 Messages” and “Chat Three Characters” rewards
- **Create Persona** — Create a new persona (title, name, description, gender, age)

### Library

```python
import os
from dotenv import load_dotenv
from juicychat.client import JuicyChatClient, Gender, SortName

load_dotenv()

client = JuicyChatClient(
    user_number=os.getenv("JUICYCHAT_USERNUMBER"),
    password=os.getenv("JUICYCHAT_PASSWORD"),
    key=os.getenv("JUICYCHAT_KEY"),
    iv=os.getenv("JUICYCHAT_IV"),
)

# Examples
info = client.get_user_info()
characters = client.search_characters("elf", gender=Gender.FEMALE, sort_name=SortName.POPULAR)
relations = client.get_chat_relations()
reply = client.send_chat_message(character_id="...", message="Hello")
```

Main client methods:

- `get_user_info()` — Current user details
- `search_characters(search_content, character_tags, gender, sort_name, page_no, page_size)` — List characters
- `get_chat_relations()`, `get_chat_messages(character_id, chat_id)` — Chats and history
- `send_chat_message(character_id, message, request_type)` — Send message and get streamed reply
- `update_content_filter(allow_nsfw)` — Toggle content filter
- `get_personas()`, `create_persona(...)`, `set_persona(character_id, persona_id)` — Personas
- `clear_chat_history(character_id)` — Clear chat
- `claim_task_reward(user_id, task_id)` — Claim a task reward

Enums: `SortName` (e.g. `POPULAR`, `NEW`, `TRENDING`), `Gender`, `TaskId`.


## Notes

- **Unofficial** — This project is not affiliated with JuicyChat. The API may change; key/IV discovery depends on the current web bundle.
- **Credentials** — Store user number, password, and key/IV securely.
- **TLS** — Requests use `curl_cffi` with Chrome impersonation for compatibility with the site.
