"""
Spark Hooks - Event capture hooks for AI coding agents.
"""
