"""Custom exceptions and error types"""
