"""pypreset: A meta-tool for setting up Poetry-based Python projects."""

__version__ = "0.1.0"
