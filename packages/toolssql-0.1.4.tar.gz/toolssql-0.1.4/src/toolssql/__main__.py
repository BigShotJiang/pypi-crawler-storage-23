def main() -> None:
    print("toolssql: import classes from toolssql")

if __name__ == "__main__":
    main()
