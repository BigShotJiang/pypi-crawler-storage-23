"""SQL Tools = Tools used for MySQL manipulation
Version 2026-02-28

- make config import conifgurable -> project root, user root, env var
  -> can just put on ~/authsql.py and it will be loaded

- * Structured error handling: all public run methods now update one uniform
  dictionary stored in ``self.error_info``

        {
            "success": True | False,
            "error": <short_code | None>,
            "errorCode": <mysql_err_code | None>,
            "errorDetails": <message | None>,
        }

Format of example config:

from typing import Dict, Any
CONNECTION_CONFIG: Dict[str, Any] = {
    'config1':
    {
        'host': 'localhost',
        'user': 'Analyst',
        'password': 'XXXXXXXXXXXXXXXXX',
        'database': 'Playground',
    },
    'config2':
    {
        'host': 'localhost',
        'user': 'Analyst2',
        'password': 'XXXXXXXXXXXXXXXXX',
    },
}

# default connection to be used, if nothing else is specified
CONNECTION_CONFIG_DEFAULT = "config1"
"""

import logging
import time
import pymysql
import os
from pymysql import cursors
from typing import Any, Dict, Optional, Sequence
import importlib

import importlib.util
from pathlib import Path

logger = logging.getLogger(__name__)

# ===============================================================================
# Import connection details from authsql.py as global varaibles
# ===============================================================================

# Optional auth configuration loader
# - In local dev, you can keep an `authsql.py` next to your entry script (project root).
# - In packaged/installed usage, the project root is usually NOT on sys.path, so you can:
#     * set AUTHSQL_MODULE to an importable module path (e.g. "myapp.authsql"), OR
#     * pass connection_config / connection_default into MysqlConnect.


def _load_authsql_config():
    """Best-effort load of CONNECTION_CONFIG and CONNECTION_CONFIG_DEFAULT.

    Priority:
    1) Env var AUTHSQL_MODULE (importable module path, e.g. "myapp.authsql")
    2) Module named "authsql" (works when project root is on sys.path)
    3) File path via env var AUTHSQL_PATH (absolute or ~-relative path to authsql.py)
        -> e.g. in a subfolder, can use it to point to the file (can also have a different name)
        (could also just set it to a file anywhere on the path with any name)
        important: set env var before importing toolssql
        -> example to import from the parent folder
        import os
        os.environ["AUTHSQL_PATH"] = "../authsql.py"
        from toolssql import MysqlFetch

    4) Common locations in the current user's home directory:
       - ~/authsql.py
       - ~/.authsql.py
       - ~/.config/authsql.py
    5) Fallback: empty config / None default

    This lets you keep authsql.py outside git (e.g. in your home directory),
    while still supporting local dev and packaged installs.
    """
    # (A) importable module path
    module_name = os.getenv("AUTHSQL_MODULE")
    candidates = [module_name] if module_name else []
    candidates.append("authsql")
    for name in candidates:
        if not name:
            continue
        try:
            mod = importlib.import_module(name)
            cfg = getattr(mod, "CONNECTION_CONFIG", None)
            dflt = getattr(mod, "CONNECTION_CONFIG_DEFAULT", None)
            if isinstance(cfg, dict):
                return cfg, dflt
        except ModuleNotFoundError:
            continue

    # (B) load from file path (AUTHSQL_PATH or home fallbacks)
    def _load_from_file(path: Path):
        try:
            if not path.is_file():
                return None
            spec = importlib.util.spec_from_file_location("_authsql_external", str(path))
            if spec is None or spec.loader is None:
                return None
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore[attr-defined]
            cfg = getattr(mod, "CONNECTION_CONFIG", None)
            dflt = getattr(mod, "CONNECTION_CONFIG_DEFAULT", None)
            if isinstance(cfg, dict):
                return cfg, dflt
        except Exception:
            return None
        return None

    env_path = os.getenv("AUTHSQL_PATH")
    if env_path:
        p = Path(os.path.expandvars(env_path)).expanduser()
        loaded = _load_from_file(p)
        if loaded:
            return loaded

    home = Path.home()
    for p in (
        home / "authsql.py",
        home / ".authsql.py",
        home / ".config" / "authsql.py",
    ):
        loaded = _load_from_file(p)
        if loaded:
            return loaded

    return {}, None


CONNECTION_CONFIG, CONNECTION_CONFIG_DEFAULT = _load_authsql_config()
# ===============================================================================
# Structured error helper
# ===============================================================================

# Mapping of MySQL error codes to short error identifiers
ERROR_CODE_MAP: Dict[int, str] = {
    1213: "deadlock",  # ER_LOCK_DEADLOCK – Deadlock found when trying to get lock; try restarting transaction
    1205: "lock_timeout",  # ER_LOCK_WAIT_TIMEOUT – Lock wait timeout exceeded; try restarting transaction
    1062: "duplicate_key",  # ER_DUP_ENTRY – Duplicate entry for key
    1451: "fk_constraint_delete",  # ER_ROW_IS_REFERENCED_2 – Cannot delete/update parent row: a foreign key constraint fails
    1452: "fk_constraint_add",  # ER_NO_REFERENCED_ROW_2 – Cannot add/update child row: a foreign key constraint fails
    1049: "db_not_found",  # ER_BAD_DB_ERROR – Unknown database
    1045: "access_denied",  # ER_ACCESS_DENIED_ERROR – Access denied for user
    2006: "server_gone",  # CR_SERVER_GONE_ERROR – MySQL server has gone away
    2013: "lost_connection",  # CR_SERVER_LOST – Lost connection to MySQL server during query
    1064: "syntax_error",  # ER_PARSE_ERROR – You have an error in your SQL syntax
}

# Transient errors that are worth retrying automatically
RETRYABLE_ERRORS = {"deadlock", "lock_timeout", "server_gone", "lost_connection"}


def _success_result() -> Dict[str, Any]:
    """Return a fully‑populated success dictionary."""
    return {"success": True, "error": None, "errorCode": None, "errorDetails": None}


def parse_mysql_error(err: pymysql.Error) -> Dict[str, Any]:
    """Convert a ``pymysql.Error`` into a structured dictionary.

    Robustness tweaks: wrapped in try/except so that *any* unexpected situation
    still returns the mandated keys.
    """
    try:
        # ``pymysql.Error`` exposes the numeric error code in ``args[0]``
        # and the human‑readable message in ``args[1]``.
        code: Optional[int] = err.args[0] if err.args else None
        message: str = err.args[1] if len(err.args) > 1 else str(err)
        short = ERROR_CODE_MAP.get(code, "mysql_error") if isinstance(code, int) else "mysql_error"
        return {
            "success": False,
            "error": short,
            "errorCode": code,
            "errorDetails": message,
        }
    except Exception as exc:  # pragma: no cover
        # Fallback – guarantee the required keys are present
        return {
            "success": False,
            "error": "mysql_error",
            "errorCode": None,
            "errorDetails": f"Unhandled exception while parsing MySQL error: {exc}",
        }


# ===============================================================================
# Define global variables used in classes/functions
# ===============================================================================

bad_attempts_counter = 0

# ===============================================================================
# Define Functions and Classes
# ===============================================================================


def check_db_connection(conn_input: Any) -> bool:
    """Check if a connection exists and return True/False"""
    return hasattr(conn_input, "conn") and conn_input.conn is not None


class MysqlConnect:
    """Class to create and close MySQL connection

    Class checks, if connection exists to avoid error messages when it does not, see "check_db_connection()"
    Global counter "bad_attempts_counter" on bad connection attempts -> does not try anymore when hitting BAD_ATTEMPTS_LIMIT
    """

    # possible to specify multiple connection paramaters
    # if nothing is specified, "Default" will be used
    # Array with different connections (imported from authsql)
    CONNECTION_PARAM = CONNECTION_CONFIG
    AUTOCOMMIT = False

    # do not try to reconnect anymore, if there was already more than x errors
    BAD_ATTEMPTS_LIMIT = 3

    # CONNECTION_DEFAULT e.g. = name of connection to be used, if nothing else is specified
    def __init__(
        self,
        connection: Optional[str] = None,
        connection_config: Optional[Dict[str, Any]] = None,
        connection_default: Optional[str] = None,
    ):
        global bad_attempts_counter  # define it here, so it can be used
        # Allow config injection (recommended for packaged usage)
        # If not provided, fall back to authsql-loaded defaults (or empty dict).
        self.CONNECTION_PARAM = (
            connection_config if connection_config is not None else self.CONNECTION_PARAM
        )
        effective_default = (
            connection_default if connection_default is not None else CONNECTION_CONFIG_DEFAULT
        )

        # if no connection name is handed over then use effective default
        self.connection = connection or effective_default
        if not self.connection:
            logger.error("DB connect class - No connection name provided and no default available")
            self.error_info = {
                "success": False,
                "error": "config_missing_default",
                "errorCode": None,
                "errorDetails": "No connection specified and no CONNECTION_CONFIG_DEFAULT found",
            }
            return

        # if no connecton name to be used is handed over then use default connection defined in input file
        self.conn: Optional[pymysql.Connection] = None  # Initialize self.conn
        self.error_info: Dict[str, Any] = _success_result()  # always present!

        self.connection_details = self.CONNECTION_PARAM.get(self.connection)
        if not self.connection_details:
            logger.error(
                "DB connect class - No connection details found for '%s'",
                self.connection,
            )
            self.error_info = {
                "success": False,
                "error": "config_missing",
                "errorCode": None,
                "errorDetails": f"No connection details for {self.connection}",
            }
            return

        if bad_attempts_counter < self.BAD_ATTEMPTS_LIMIT:  # only try to connect, if there are not
            try:
                self.conn = pymysql.connect(**self.connection_details, autocommit=self.AUTOCOMMIT)
                # print("DB connect Class - DB connection established successfully")
                bad_attempts_counter = 0
                self.error_info = _success_result()
            except KeyError as e:  # if the self.connection entry does not exist in CONNECTION_PARAM
                logger.error(
                    "DB connect class - Key Error (connection config not properly set up): %s",
                    e,
                )
                self.error_info = {
                    "success": False,
                    "error": "config_key_error",
                    "errorCode": None,
                    "errorDetails": str(e),
                }

            except pymysql.Error as e:
                logger.error("DB connect class - MySQL Error: %s", e)
                bad_attempts_counter += 1
                self.error_info = parse_mysql_error(e)
        # print("Bad attempts counter: ",bad_attempts_counter)

        else:
            logger.error("DB connect class - too many bad connection attempts")
            self.error_info = {
                "success": False,
                "error": "too_many_attempts",
                "errorCode": None,
                "errorDetails": "Connection disabled after repeated failures",
            }

    def close(self) -> None:
        if check_db_connection(self):
            assert self.conn is not None
            self.conn.close()


class MysqlFetch:
    """Class to handle one individual SQL query with *fetchall* (no fetchone supported as of now)

    Two options:
    1) Hand over an existing connection
      -> this connection will be used, but needs to be opened first and closed afterwards
      -> only makes sense if a high number of e.g. SELECT statements is required and exception handling is properly done on closing
      example: [check for "db" option]

        db=MysqlConnect()
        sql_test=MysqlFetch("SELECT count(*) as count from TestDB.testTable limit 1;",db)
        sql_test.runsql()
        print(sql_test.sql_result)
        # update sql and run it again with updated sql
        sql_test.sql="SELECT count(*)+5 as count from TestDB.testTable limit 1;"
        sql_test.runsql()
        print(sql_test.sql_result)
        db.close()

    2) Create a temporary DB connection every time when "runsql" is called
      -> better option to be sure all exception handling is done properly
      -> only to be used if there are not too many cases
      example: [no "db" option present]

        sql_test_truncate=MysqlFetch("TRUNCATE TestDB.testTable;")
        sql_test_truncate.runsql()
    """

    def __init__(
        self,
        sql: str,
        sql_conn: Optional[str] = None,
        sql_db: Optional[MysqlConnect] = None,
        retry_on_error: int = 0,
        retry_delay: int = 10,
    ):
        self.sql = sql
        # to store name of connection name to be used. if None is used then use default connection
        self.sql_conn = sql_conn
        self.sql_db_status = sql_db  # to track if sql_db was handed over or not
        self.sql_db = sql_db  # to store/create actual sql_db connection
        self.sql_result: Sequence[Dict[str, Any]] = []
        self.error_info: Dict[str, Any] = _success_result()  # to collect structured error info
        self.retry_on_error = retry_on_error
        self.retry_delay = retry_delay

    def runsql(self) -> None:
        for attempt in range(1 + self.retry_on_error):
            try:
                # 1) check if a connection was handed over (sql_db)
                #    if not then create a temp connection that will be close aagain in the end
                if self.sql_db_status is None:
                    # print("No DB connection specified -> create a temp DB connection")
                    self.sql_db = MysqlConnect(self.sql_conn)
                # 2) Check if the connection exists before doing:
                #    a) create cursor, execute sql, fetchall, commit
                if check_db_connection(self.sql_db):
                    # print("Connection is established: creating cursor, executing sql, fetchall, commit")
                    assert self.sql_db is not None
                    assert self.sql_db.conn is not None
                    sqlcursor = self.sql_db.conn.cursor(cursors.DictCursor)
                    sqlcursor.execute(self.sql)
                    # print("MySql query executed")
                    self.sql_result = sqlcursor.fetchall()
                    self.sql_db.conn.commit()
                    self.error_info = _success_result()
                else:
                    # print("Connection does not exist, not creating cursor, not running SQL code")
                    self.error_info = {
                        "success": False,
                        "error": "no_connection",
                        "errorCode": None,
                        "errorDetails": "Database connection not available",
                    }
            except pymysql.Error as e:
                if check_db_connection(self.sql_db):
                    assert self.sql_db is not None
                    assert self.sql_db.conn is not None
                    self.sql_db.conn.rollback()
                self.error_info = parse_mysql_error(e)
                # Retry on transient errors if retries remain
                if self.error_info["error"] in RETRYABLE_ERRORS and attempt < self.retry_on_error:
                    # Log warning during retry attempts, not error (error only on final failure)
                    logger.warning(
                        "RunSQL MySQL Error (attempt %d/%d, will retry in %ds): %s",
                        attempt + 1,
                        1 + self.retry_on_error,
                        self.retry_delay,
                        e,
                    )
                    # Sleep before retry; finally block handles closing temp connection
                    time.sleep(self.retry_delay)
                    continue
                # Final attempt failed or non-retryable error -> log as error
                logger.error("RunSQL MySQL Error: %s", e)
            finally:
                try:
                    sqlcursor.close()
                except UnboundLocalError:
                    pass
                # Close temp connection (on retry it will be recreated next iteration)
                if self.sql_db_status is None and check_db_connection(self.sql_db):
                    assert self.sql_db is not None
                    self.sql_db.close()
            # If we reach here (no continue from retry), break out of the loop
            break


class MysqlFetchOne:
    """Class to handle one individual SQL query with *fetchone*

    Process:
        1) sql_test = MysqlFetchOne("Select * from TestDB.testTable limit 10;")
        2) sql_test.runsql()
          -> this defines connection and opens cursor
        3) sql_test.fetchone()
          -> will fetch only one results
             -> check it with sql_test.sql_result
          -> when no more results are returned, connection will be closed
        4) sql_test.close()
          -> always close connection to be on the safe side (not actually needed, because closed at end of loop)

        Example to loop over:
            while sql_test.sql_result is not None:
                sql_test.fetchone()
                if sql_test.sql_result:
                    print(sql_test.sql_result)
            sql_test.close() # not needed as already closed when None is reached
    """

    def __init__(self, sql: str):
        self.sql = sql
        # to store name of connection name to be used. if None is used then use default connection
        self.sql_conn = None
        self.sql_result: Optional[Dict[str, Any]] = {}
        self.error_info: Dict[str, Any] = _success_result()

    def runsql(self) -> None:
        try:
            self.sql_db = MysqlConnect(self.sql_conn)
            assert self.sql_db.conn is not None
            self.sqlcursor = self.sql_db.conn.cursor(cursors.DictCursor)
            self.sqlcursor.execute(self.sql)
            self.error_info = _success_result()
        except pymysql.Error as e:
            if check_db_connection(self.sql_db):
                assert self.sql_db.conn is not None
                self.sql_db.conn.rollback()
            logger.error("RunSQL MySQL Error: %s", e)
            self.error_info = parse_mysql_error(e)
        except Exception:
            logger.error("RunSQL Undefined error")
            self.error_info = {
                "success": False,
                "error": "undefined",
                "errorCode": None,
                "errorDetails": "Unknown exception",
            }

    def fetchone(self) -> None:
        try:
            self.sql_result = self.sqlcursor.fetchone()
            assert self.sql_db.conn is not None
            self.sql_db.conn.commit()
            # if no more results are returned -> close connection
            if self.sql_result is None:
                self.close()
                # print("Mysql - No more results returned, connection closed")
            self.error_info = _success_result()

        except pymysql.Error as e:
            if check_db_connection(self.sql_db):
                assert self.sql_db.conn is not None
                self.sql_db.conn.rollback()
            logger.error("RunSQL MySQL Error: %s", e)
            self.error_info = parse_mysql_error(e)

    def close(self) -> None:
        try:
            self.sqlcursor.close()
        except UnboundLocalError:
            pass

        try:
            if check_db_connection(self.sql_db):
                self.sql_db.close()
                logger.info("Mysql connection closed")
        except Exception:
            logger.warning("Mysql connection already closed")


class MysqlInsertValues:
    """Class to handle bulk mysql DB entries using pymsql db connection -> need to be opened and passed over as input on what to be used!

    General approach: add sql_values to sql_values, then run runsql_if_big every time, at the end run runsql_if_big(True) to force it
    """

    def __init__(
        self,
        name,
        sql: str,
        sql_values_limit=500,
        sql_conn: Optional[str] = None,
        sql_db: Optional[MysqlConnect] = None,
        retry_on_error: int = 0,
        retry_delay: int = 10,
    ):
        self.name = name
        self.sql = sql
        self.sql_values = []
        # to store name of connection name to be used. if None is used then use default connection
        self.sql_conn = sql_conn
        self.sql_db_status = sql_db  # to track if sql_db was handed over or not
        self.sql_db = sql_db  # to store/create actual sql_db connection
        # limit for sql_values length before executing the bulk insert statement
        self.sql_values_limit = sql_values_limit
        # count the commas in sql1 => defines values to add
        self.number_values_to_add = sql[sql.find("(") + 1 : sql.find(")")].count(",") + 1
        self.error_info: Dict[str, Any] = _success_result()
        self.retry_on_error = retry_on_error
        self.retry_delay = retry_delay

    # append sql_values by providing a list of elements -> only if number of elements matches the elements provided in sql
    def append_values(self, append_values):
        if len(append_values) == self.number_values_to_add:
            self.sql_values.append(append_values)
        else:
            logger.error(
                "Not same number of elements provided to be added to sql_values as required in sql - nothing done!"
            )

    # only run if the sql_values string length is big enough
    def runsql_if_big(self, force_run=False):
        sql_success = False  # variable to return back, if DB was successfully updated or not
        if (len(self.sql_values) > self.sql_values_limit) or (
            force_run and len(self.sql_values) > 0
        ):
            for attempt in range(1 + self.retry_on_error):
                try:
                    # 1) check if a connection was handed over (sql_db)
                    #    if not then create a temp connection that will be close aagain in the end
                    if self.sql_db_status is None:
                        # print("No DB connection specified -> create a temp DB connection")
                        self.sql_db = MysqlConnect(self.sql_conn)
                    # 2) Check if the connection exists before doing:
                    #    a) create cursor, execute sql, fetchall, commit
                    if check_db_connection(self.sql_db):
                        assert self.sql_db is not None
                        assert self.sql_db.conn is not None
                        sqlcursor = self.sql_db.conn.cursor(cursors.DictCursor)
                        sqlcursor.executemany(self.sql, self.sql_values)
                        logger.info(
                            "%s - %d entries added to DB successfully",
                            self.name,
                            len(self.sql_values),
                        )
                        self.sql_db.conn.commit()
                        self.sql_values = []
                        sql_success = True
                        self.error_info = _success_result()
                    else:
                        # print("Connection does not exist, not creating cursor, not running SQL code")
                        self.error_info = {
                            "success": False,
                            "error": "no_connection",
                            "errorCode": None,
                            "errorDetails": "Database connection not available",
                        }

                except pymysql.Error as e:
                    if check_db_connection(self.sql_db):
                        assert self.sql_db is not None
                        assert self.sql_db.conn is not None
                        self.sql_db.conn.rollback()
                    self.error_info = parse_mysql_error(e)
                    # Retry on transient errors if retries remain
                    if (
                        self.error_info["error"] in RETRYABLE_ERRORS
                        and attempt < self.retry_on_error
                    ):
                        # Log warning during retry attempts, not error (error only on final failure)
                        logger.warning(
                            "RunSQL MySQL Error (attempt %d/%d, will retry in %ds): %s",
                            attempt + 1,
                            1 + self.retry_on_error,
                            self.retry_delay,
                            e,
                        )
                        # Sleep before retry; finally block handles closing temp connection
                        time.sleep(self.retry_delay)
                        continue
                    # Final attempt failed or non-retryable error -> log as error
                    logger.error("RunSQL MySQL Error: %s", e)

                finally:
                    try:
                        sqlcursor.close()
                    except UnboundLocalError:
                        pass
                    # Close temp connection (on retry it will be recreated next iteration)
                    if self.sql_db_status is None and check_db_connection(self.sql_db):
                        assert self.sql_db is not None
                        self.sql_db.close()
                # If we reach here (no continue from retry), break out of the loop
                break
        elif force_run and len(self.sql_values) == 0:
            logger.info("%s - nothing done, no sql_values entries available", self.name)
            self.error_info = _success_result()
        return sql_success
