def test_import():
    from toolssql import MysqlConnect  # noqa: F401
