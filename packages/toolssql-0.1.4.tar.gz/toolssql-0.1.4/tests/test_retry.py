"""Tests for retry logic in MysqlFetch and MysqlInsertValues.

Uses unittest.mock to simulate deadlock / transient MySQL errors
without needing a real database connection.

How to run (from project root):
    pip install -e .              # install package in editable mode (once)
    pip install pytest            # install pytest (once)
    python -m pytest tests/test_retry.py -v          # run all retry tests
    python -m pytest tests/test_retry.py::TestMysqlFetchRetry -v        # only MysqlFetch tests
    python -m pytest tests/test_retry.py::TestMysqlInsertValuesRetry -v # only MysqlInsertValues tests
    python -m pytest tests/ -v                       # run all tests
"""

import time
from unittest.mock import MagicMock, patch
import pymysql
import pytest

from toolssql.sql import (
    MysqlFetch,
    MysqlInsertValues,
    MysqlConnect,
    RETRYABLE_ERRORS,
    ERROR_CODE_MAP,
    parse_mysql_error,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_deadlock_error():
    """Create a pymysql.Error that looks like a deadlock (errno 1213)."""
    return pymysql.Error(1213, "Deadlock found when trying to get lock; try restarting transaction")


def _make_lock_timeout_error():
    """Create a pymysql.Error that looks like a lock wait timeout (errno 1205)."""
    return pymysql.Error(1205, "Lock wait timeout exceeded; try restarting transaction")


def _make_server_gone_error():
    """Create a pymysql.Error for server gone away (errno 2006)."""
    return pymysql.Error(2006, "MySQL server has gone away")


def _make_syntax_error():
    """Create a non-retryable pymysql.Error (errno 1064)."""
    return pymysql.Error(1064, "You have an error in your SQL syntax")


def _mock_db_connection():
    """Create a mock MysqlConnect with a mock pymysql connection."""
    db = MagicMock(spec=MysqlConnect)
    db.conn = MagicMock()
    cursor = MagicMock()
    db.conn.cursor.return_value = cursor
    cursor.fetchall.return_value = [{"id": 1}]
    return db, cursor


# ===========================================================================
# MysqlFetch retry tests
# ===========================================================================

class TestMysqlFetchRetry:
    """Test retry logic in MysqlFetch.runsql."""

    # --- no retry (default) ---

    def test_no_retry_default_on_deadlock(self):
        """With default retry_on_error=0, a deadlock should NOT be retried."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = _make_deadlock_error()

        fetch = MysqlFetch("SELECT 1", sql_db=db)
        assert fetch.retry_on_error == 0
        fetch.runsql()

        assert fetch.error_info["success"] is False
        assert fetch.error_info["error"] == "deadlock"
        assert cursor.execute.call_count == 1  # no retry

    # --- retry succeeds on 2nd attempt ---

    def test_retry_succeeds_on_second_attempt(self):
        """Deadlock on 1st attempt, success on 2nd."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = [_make_deadlock_error(), None]
        cursor.fetchall.return_value = [{"count": 42}]

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=1, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is True
        assert fetch.sql_result == [{"count": 42}]
        assert cursor.execute.call_count == 2

    # --- retry exhausted ---

    def test_retry_exhausted_deadlock(self):
        """Deadlock on all attempts -> final error reported."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = [_make_deadlock_error(), _make_deadlock_error()]

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=1, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is False
        assert fetch.error_info["error"] == "deadlock"
        assert cursor.execute.call_count == 2

    # --- non-retryable error is never retried ---

    def test_non_retryable_error_not_retried(self):
        """Syntax error should not be retried even with retry_on_error > 0."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = _make_syntax_error()

        fetch = MysqlFetch("SELECT BAD", sql_db=db, retry_on_error=2, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is False
        assert fetch.error_info["error"] == "syntax_error"
        assert cursor.execute.call_count == 1  # no retry

    # --- multiple retries ---

    def test_three_retries_success_on_last(self):
        """Deadlock 3 times, success on 4th (retry_on_error=3)."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = [
            _make_deadlock_error(),
            _make_deadlock_error(),
            _make_deadlock_error(),
            None,  # success
        ]
        cursor.fetchall.return_value = [{"ok": 1}]

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=3, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is True
        assert cursor.execute.call_count == 4

    # --- all retryable error types ---

    @pytest.mark.parametrize("error_factory,expected_code", [
        (_make_deadlock_error, "deadlock"),
        (_make_lock_timeout_error, "lock_timeout"),
        (_make_server_gone_error, "server_gone"),
    ])
    def test_retryable_errors_are_retried(self, error_factory, expected_code):
        """Each transient error type should trigger a retry."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = [error_factory(), None]
        cursor.fetchall.return_value = [{"v": 1}]

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=1, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is True
        assert cursor.execute.call_count == 2

    # --- retry with temp connection (sql_db=None) ---

    @patch("toolssql.sql.MysqlConnect")
    def test_retry_creates_new_temp_connection(self, MockConnect):
        """When no sql_db is provided, each retry should create a fresh connection."""
        cursor = MagicMock()
        cursor.execute.side_effect = [_make_deadlock_error(), None]
        cursor.fetchall.return_value = [{"r": 1}]

        mock_conn = MagicMock()
        mock_conn.cursor.return_value = cursor

        mock_db = MagicMock(spec=MysqlConnect)
        mock_db.conn = mock_conn
        MockConnect.return_value = mock_db

        fetch = MysqlFetch("SELECT 1", retry_on_error=1, retry_delay=0)
        fetch.runsql()

        assert fetch.error_info["success"] is True
        # MysqlConnect called twice: once per attempt
        assert MockConnect.call_count == 2
        # temp connection closed after each attempt
        assert mock_db.close.call_count == 2

    # --- verify rollback on error ---

    def test_rollback_called_on_error(self):
        """Connection should be rolled back when a query fails."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = _make_deadlock_error()

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=0, retry_delay=0)
        fetch.runsql()

        db.conn.rollback.assert_called()

    # --- verify delay is applied ---

    def test_retry_delay_is_applied(self):
        """Retry should sleep for retry_delay seconds between attempts."""
        db, cursor = _mock_db_connection()
        cursor.execute.side_effect = [_make_deadlock_error(), None]
        cursor.fetchall.return_value = []

        fetch = MysqlFetch("SELECT 1", sql_db=db, retry_on_error=1, retry_delay=1)
        start = time.time()
        fetch.runsql()
        elapsed = time.time() - start

        assert elapsed >= 0.9  # should have slept ~1s
        assert fetch.error_info["success"] is True


# ===========================================================================
# MysqlInsertValues retry tests
# ===========================================================================

class TestMysqlInsertValuesRetry:
    """Test retry logic in MysqlInsertValues.runsql_if_big."""

    # --- no retry (default) ---

    def test_no_retry_default_on_deadlock(self):
        """With default retry_on_error=0, a deadlock should NOT be retried."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = _make_deadlock_error()

        ins = MysqlInsertValues("test", "INSERT INTO t (a) VALUES (%s)", sql_db=db)
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is False
        assert ins.error_info["success"] is False
        assert ins.error_info["error"] == "deadlock"
        assert cursor.executemany.call_count == 1

    # --- retry succeeds on 2nd attempt ---

    def test_retry_succeeds_on_second_attempt(self):
        """Deadlock on 1st attempt, success on 2nd."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = [_make_deadlock_error(), None]

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            sql_db=db, retry_on_error=1, retry_delay=0,
        )
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is True
        assert ins.error_info["success"] is True
        assert len(ins.sql_values) == 0  # cleared on success
        assert cursor.executemany.call_count == 2

    # --- retry exhausted ---

    def test_retry_exhausted(self):
        """Deadlock on all attempts -> values NOT cleared, returns False."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = [_make_deadlock_error(), _make_deadlock_error()]

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            sql_db=db, retry_on_error=1, retry_delay=0,
        )
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is False
        assert ins.error_info["error"] == "deadlock"
        assert len(ins.sql_values) == 1  # values preserved for manual retry
        assert cursor.executemany.call_count == 2

    # --- non-retryable error ---

    def test_non_retryable_error_not_retried(self):
        """Duplicate key error should not be retried."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = pymysql.Error(1062, "Duplicate entry")

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            sql_db=db, retry_on_error=2, retry_delay=0,
        )
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is False
        assert ins.error_info["error"] == "duplicate_key"
        assert cursor.executemany.call_count == 1

    # --- empty values ---

    def test_empty_values_force_run(self):
        """force_run=True with no values should be a no-op success."""
        db, cursor = _mock_db_connection()
        ins = MysqlInsertValues("test", "INSERT INTO t (a) VALUES (%s)", sql_db=db)
        result = ins.runsql_if_big(force_run=True)

        assert result is False
        assert ins.error_info["success"] is True
        cursor.executemany.assert_not_called()

    # --- retry with temp connection ---

    @patch("toolssql.sql.MysqlConnect")
    def test_retry_creates_new_temp_connection(self, MockConnect):
        """Each retry should create a fresh temp connection."""
        cursor = MagicMock()
        cursor.executemany.side_effect = [_make_deadlock_error(), None]

        mock_conn = MagicMock()
        mock_conn.cursor.return_value = cursor

        mock_db = MagicMock(spec=MysqlConnect)
        mock_db.conn = mock_conn
        MockConnect.return_value = mock_db

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            retry_on_error=1, retry_delay=0,
        )
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is True
        assert MockConnect.call_count == 2
        assert mock_db.close.call_count == 2

    # --- lock timeout retried ---

    def test_lock_timeout_retried(self):
        """Lock wait timeout should also trigger retry."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = [_make_lock_timeout_error(), None]

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            sql_db=db, retry_on_error=1, retry_delay=0,
        )
        ins.append_values([1])
        result = ins.runsql_if_big(force_run=True)

        assert result is True
        assert ins.error_info["success"] is True

    # --- rollback called on error ---

    def test_rollback_called_on_error(self):
        """Connection should be rolled back on insert failure."""
        db, cursor = _mock_db_connection()
        cursor.executemany.side_effect = _make_deadlock_error()

        ins = MysqlInsertValues(
            "test", "INSERT INTO t (a) VALUES (%s)",
            sql_db=db, retry_on_error=0, retry_delay=0,
        )
        ins.append_values([1])
        ins.runsql_if_big(force_run=True)

        db.conn.rollback.assert_called()


# ===========================================================================
# Sanity checks for RETRYABLE_ERRORS and parse_mysql_error
# ===========================================================================

class TestRetryableErrorsConfig:
    """Verify RETRYABLE_ERRORS is consistent with ERROR_CODE_MAP."""

    def test_retryable_errors_subset_of_error_code_map(self):
        """Every entry in RETRYABLE_ERRORS must exist as a value in ERROR_CODE_MAP."""
        map_values = set(ERROR_CODE_MAP.values())
        assert RETRYABLE_ERRORS.issubset(map_values), (
            f"Unknown retryable errors: {RETRYABLE_ERRORS - map_values}"
        )

    def test_parse_deadlock_error(self):
        err = _make_deadlock_error()
        result = parse_mysql_error(err)
        assert result["error"] == "deadlock"
        assert result["errorCode"] == 1213
        assert result["success"] is False

    def test_parse_lock_timeout_error(self):
        err = _make_lock_timeout_error()
        result = parse_mysql_error(err)
        assert result["error"] == "lock_timeout"
        assert result["errorCode"] == 1205

    def test_parse_server_gone_error(self):
        err = _make_server_gone_error()
        result = parse_mysql_error(err)
        assert result["error"] == "server_gone"
        assert result["errorCode"] == 2006
