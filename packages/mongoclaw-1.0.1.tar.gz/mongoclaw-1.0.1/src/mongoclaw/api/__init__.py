"""FastAPI application module."""

from mongoclaw.api.app import create_app

__all__ = ["create_app"]
