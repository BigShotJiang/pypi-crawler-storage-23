"""CLI module for MongoClaw."""

from mongoclaw.cli.main import cli

__all__ = ["cli"]
