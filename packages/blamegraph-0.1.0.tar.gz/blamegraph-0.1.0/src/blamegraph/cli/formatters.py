"""Output formatting helpers for the BlameGraph CLI."""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

from blamegraph.models import Entity, RiskLevel, RiskScore

if TYPE_CHECKING:
    from blamegraph.graph.blast import BlastResult
    from blamegraph.history import DriftReport, EntityHistory
    from blamegraph.radar import RadarReport, RadarSeverity
    from blamegraph.unblock import UnblockAnalysis
    from blamegraph.watch import WatchResult

_RISK_COLORS = {
    RiskLevel.LOW: "green",
    RiskLevel.MEDIUM: "yellow",
    RiskLevel.HIGH: "red",
    RiskLevel.CRITICAL: "bold red",
}

_SEVERITY_COLORS: dict[str, str] = {
    "critical": "bold red",
    "warning": "yellow",
    "info": "dim",
}

_TREND_ARROWS: dict[str, str] = {
    "increasing": "[red]\u2197 Increasing risk[/red]",
    "decreasing": "[green]\u2198 Decreasing risk[/green]",
    "stable": "[dim]\u2192 Stable[/dim]",
}


def format_risk_table(scores: list[RiskScore]) -> Table:
    """Build a rich Table with color-coded risk levels."""
    table = Table(title="Risk Scores")
    table.add_column("Entity", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Level")
    table.add_column("Action")

    for rs in scores:
        color = _RISK_COLORS.get(rs.level, "white")
        table.add_row(
            rs.entity_id,
            f"{rs.score:.1f}",
            f"[{color}]{rs.level.value}[/{color}]",
            rs.suggested_action or "-",
        )
    return table


def format_dependency_chain(chain: list[dict[str, str]]) -> Tree:
    """Build a rich Tree visualization of a dependency chain.

    Each item in chain should have 'id' and optionally 'label' keys.
    """
    tree = Tree("Dependency Chain")
    for item in chain:
        label = item.get("label", item.get("id", "?"))
        tree.add(label)
    return tree


def format_entity_panel(entity: Entity) -> Panel:
    """Build a rich Panel showing entity details."""
    lines = [
        f"[bold]ID:[/bold] {entity.id}",
        f"[bold]Type:[/bold] {entity.entity_type.value}",
        f"[bold]External ID:[/bold] {entity.external_id}",
        f"[bold]Title:[/bold] {entity.title}",
    ]
    if entity.attributes:
        lines.append(f"[bold]Attributes:[/bold] {json.dumps(entity.attributes, default=str)}")
    return Panel("\n".join(lines), title=entity.title or entity.id)


def to_json(data: Any) -> str:
    """Serialize data to JSON string for --json mode."""
    if hasattr(data, "model_dump"):
        data = data.model_dump(mode="json")
    elif isinstance(data, list) and data and hasattr(data[0], "model_dump"):
        data = [item.model_dump(mode="json") for item in data]
    return json.dumps(data, indent=2, default=str)


# -- Morning Radar --


def format_radar_report(report: RadarReport) -> Panel:
    """Build a rich Panel for the Morning Radar report."""
    from blamegraph.radar import RadarSeverity

    lines: list[str] = []
    header = f"Morning Radar"
    if report.team:
        header += f" \u2014 {report.team}"
    header += f" ({report.generated_at.strftime('%Y-%m-%d')})"

    critical = report.critical_items
    if critical:
        lines.append(f"\n [bold red]Critical ({len(critical)}):[/bold red]")
        for i, item in enumerate(critical, 1):
            lines.append(
                f"  {i}. {item.external_id} \"{item.title}\" \u2014 {item.reason}"
            )

    warnings = report.warning_items
    if warnings:
        lines.append(f"\n [yellow]Warning ({len(warnings)}):[/yellow]")
        for i, item in enumerate(warnings, 1):
            lines.append(
                f"  {i}. {item.external_id} \"{item.title}\" \u2014 {item.reason}"
            )

    info = report.info_items
    if info:
        lines.append(f"\n [dim]Info ({len(info)}):[/dim]")
        for i, item in enumerate(info, 1):
            lines.append(
                f"  {i}. {item.external_id} \"{item.title}\" \u2014 {item.reason}"
            )

    if not report.items:
        lines.append("\n [green]All clear! No issues detected.[/green]")

    if report.ai_summary:
        lines.append(f"\n [bold]AI Summary:[/bold] {report.ai_summary}")

    return Panel("\n".join(lines), title=header, border_style="blue")


def radar_to_json(report: RadarReport) -> dict[str, object]:
    """Serialize a RadarReport to a JSON-compatible dict."""
    return {
        "team": report.team,
        "generated_at": report.generated_at.isoformat(),
        "items": [asdict(item) for item in report.items],
        "ai_summary": report.ai_summary,
        "counts": {
            "critical": len(report.critical_items),
            "warning": len(report.warning_items),
            "info": len(report.info_items),
        },
    }


# -- Blast Radius --


def format_blast_result(result: BlastResult) -> Panel:
    """Build a rich Panel for Blast Radius analysis."""
    lines: list[str] = []

    if result.direct:
        lines.append(f"\n [bold]Direct dependents ({len(result.direct)}):[/bold]")
        for node in result.direct:
            team_str = f"[{node.team}]" if node.team else ""
            sprint_str = f", {node.sprint}" if node.sprint else ""
            lines.append(
                f"  \u2192 {node.external_id} \"{node.title}\"     "
                f"{team_str}{sprint_str}"
            )

    if result.transitive:
        lines.append(f"\n [bold]Transitive dependents ({len(result.transitive)}):[/bold]")
        for node in result.transitive:
            team_str = f"[{node.team}]" if node.team else ""
            sprint_str = f", {node.sprint}" if node.sprint else ""
            lines.append(
                f"  \u2192 {node.external_id} \"{node.title}\"     "
                f"{team_str}{sprint_str}"
            )

    lines.append("")
    lines.append(
        f" [bold]Blast radius:[/bold] {result.total_affected} tickets"
        f" across {len(result.teams_affected)} teams"
    )
    lines.append(f" [bold]Blast score:[/bold] {result.blast_score:.1f}")

    if result.ai_summary:
        lines.append(f"\n [bold]AI:[/bold] {result.ai_summary}")

    title = f"Blast Radius: {result.root_external_id} \"{result.root_title}\""
    return Panel("\n".join(lines), title=title, border_style="red")


def blast_to_json(result: BlastResult) -> dict[str, object]:
    """Serialize a BlastResult to a JSON-compatible dict."""
    return {
        "root": {
            "entity_id": result.root_entity_id,
            "external_id": result.root_external_id,
            "title": result.root_title,
        },
        "direct": [asdict(n) for n in result.direct],
        "transitive": [asdict(n) for n in result.transitive],
        "blast_score": result.blast_score,
        "teams_affected": result.teams_affected,
        "total_affected": result.total_affected,
        "ai_summary": result.ai_summary,
    }


# -- Drift Report --


def format_drift_report(report: DriftReport) -> Panel:
    """Build a rich Panel for Dependency Drift report."""
    lines: list[str] = []
    header = "Dependency Drift"
    if report.team:
        header += f" \u2014 {report.team}"
    header += f" (last {report.since})"

    lines.append("")
    lines.append(f" [bold]New blockers:[/bold]      +{report.new_blockers}")
    lines.append(f" [bold]Resolved:[/bold]          -{report.resolved}")
    lines.append(f" [bold]Net change:[/bold]        {report.net_change:+d} blockers")
    lines.append(f" [bold]Trend:[/bold]             {_TREND_ARROWS.get(report.trend, report.trend)}")

    if report.items:
        lines.append("")
        for item in report.items:
            if item.kind == "new_blocker":
                lines.append(f"  [red]+[/red] {item.external_id} \"{item.title}\"")
            elif item.kind == "resolved":
                lines.append(f"  [green]-[/green] {item.external_id} \"{item.title}\"")
            else:
                lines.append(f"  [yellow]~[/yellow] {item.external_id} \"{item.title}\" \u2014 {item.detail}")

    if report.scope_creep:
        lines.append(f"\n [bold]Scope creep:[/bold]")
        for item in report.scope_creep:
            lines.append(f"  {item.external_id} \"{item.title}\" \u2014 {item.detail}")

    return Panel("\n".join(lines), title=header, border_style="yellow")


def drift_to_json(report: DriftReport) -> dict[str, object]:
    """Serialize a DriftReport to a JSON-compatible dict."""
    return {
        "team": report.team,
        "since": report.since,
        "new_blockers": report.new_blockers,
        "resolved": report.resolved,
        "net_change": report.net_change,
        "trend": report.trend,
        "items": [asdict(item) for item in report.items],
        "scope_creep": [asdict(item) for item in report.scope_creep],
    }


# -- Entity History --


def format_entity_history(history: EntityHistory) -> Panel:
    """Build a rich Panel for entity history timeline."""
    lines: list[str] = []
    header = f"History: {history.external_id} \"{history.title}\""

    if not history.events:
        lines.append("\n [dim]No events recorded.[/dim]")
    else:
        for event in history.events:
            ts = str(event.get("ts", ""))[:10]
            kind = event.get("kind", "")
            lines.append(f"  [{ts}] {kind}")
            payload = event.get("payload", {})
            if isinstance(payload, dict):
                for k, v in payload.items():
                    lines.append(f"           {k}: {v}")

    return Panel("\n".join(lines), title=header, border_style="cyan")


# -- Watch Result --


def format_watch_result(result: WatchResult) -> Panel:
    """Build a rich Panel for CI/CD gate check result."""
    lines: list[str] = []

    if result.should_fail:
        status = "[bold red]FAIL[/bold red]"
    else:
        status = "[bold green]PASS[/bold green]"

    lines.append(f"\n Gate: {status}")
    lines.append(f" Ticket: {result.ticket_key}")
    lines.append(f" Risk: {result.risk_level} ({result.risk_score:.0f})")

    if result.blockers:
        lines.append(f"\n [bold]Active blockers ({len(result.blockers)}):[/bold]")
        for b in result.blockers:
            lines.append(
                f"  \u2022 {b.get('key', '?')} \"{b.get('title', '')}\" "
                f"\u2014 {b.get('status', '')} ({b.get('risk_level', '')})"
            )

    if result.reason:
        lines.append(f"\n [dim]{result.reason}[/dim]")

    title = f"Watch: {result.ticket_key}"
    border = "red" if result.should_fail else "green"
    return Panel("\n".join(lines), title=title, border_style=border)


def watch_to_json(result: WatchResult) -> dict[str, object]:
    """Serialize a WatchResult to a JSON-compatible dict."""
    return {
        "ticket_key": result.ticket_key,
        "entity_id": result.entity_id,
        "should_fail": result.should_fail,
        "has_critical": result.has_critical,
        "has_high": result.has_high,
        "risk_score": result.risk_score,
        "risk_level": result.risk_level,
        "blockers": result.blockers,
        "reason": result.reason,
    }


# -- Unblock Analysis --


def format_unblock_analysis(analysis: UnblockAnalysis) -> Panel:
    """Build a rich Panel for Auto-Unblock analysis."""
    lines: list[str] = []
    header = f"Unblock Analysis: {analysis.target_external_id} \"{analysis.target_title}\""

    if not analysis.suggestions:
        lines.append("\n [green]No active blockers found.[/green]")
    else:
        seen_blockers: set[str] = set()
        blocker_num = 0
        for s in analysis.suggestions:
            if s.blocker_external_id not in seen_blockers:
                seen_blockers.add(s.blocker_external_id)
                blocker_num += 1
                lines.append(
                    f"\n [bold]Blocker {blocker_num}:[/bold] "
                    f"{s.blocker_external_id} \"{s.blocker_title}\""
                )
            lines.append(f"  Suggestion: {s.suggestion}")
            if s.action_command:
                lines.append(f"  Action: [cyan]{s.action_command}[/cyan]")

    if analysis.ai_summary:
        lines.append(f"\n [bold]AI:[/bold] {analysis.ai_summary}")

    return Panel("\n".join(lines), title=header, border_style="magenta")


def unblock_to_json(analysis: UnblockAnalysis) -> dict[str, object]:
    """Serialize an UnblockAnalysis to a JSON-compatible dict."""
    return {
        "target": {
            "entity_id": analysis.target_entity_id,
            "external_id": analysis.target_external_id,
            "title": analysis.target_title,
        },
        "suggestions": [asdict(s) for s in analysis.suggestions],
        "ai_summary": analysis.ai_summary,
    }
