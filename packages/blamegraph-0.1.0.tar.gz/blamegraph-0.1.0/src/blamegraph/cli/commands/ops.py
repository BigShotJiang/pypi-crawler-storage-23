"""Operational commands — analyze, radar, drift, watch, report, draft, apply, history."""

from __future__ import annotations

import asyncio
import contextlib
import json
import sys
from pathlib import Path

import click

from blamegraph.cli.context import AppContext, parse_since, pick_model
from blamegraph.cli.errors import handle_cli_errors


@click.command()
@click.pass_obj
@handle_cli_errors
def analyze(ctx: AppContext) -> None:
    """Build/update dependency graph, owners, and risk scores."""
    cfg = ctx.config
    ctx.console.print(f"[bold]Analyze[/bold] workspace={cfg.workspace}")
    ctx.console.print("[dim]Stub: would build graph, infer owners, compute risk scores.[/dim]")


@click.command()
@click.option("--team", default=None, help="Filter by team name.")
@click.option("--stale-days", default=7, help="Days without update to consider stale.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--model", default=None, help="Model ID for AI summary.")
@click.pass_obj
@handle_cli_errors
def radar(
    ctx: AppContext, team: str | None, stale_days: int, as_json: bool, model: str | None
) -> None:
    """Morning Radar — proactive daily scan for issues requiring attention."""
    cfg = ctx.config
    console = ctx.console

    from blamegraph.cli.formatters import format_radar_report, radar_to_json
    from blamegraph.radar import RadarEngine

    storage = ctx.open_storage()

    try:
        with console.status("[bold blue]Running Morning Radar scan...", spinner="dots"):
            engine = RadarEngine(storage, stale_days=stale_days)
            report = engine.scan(team=team)

        # Optional LLM summary
        if model or (not as_json and not model):
            llm_client = ctx.create_llm_client()
            if llm_client and report.items:
                if not model:
                    model = pick_model(cfg, console)

                context_lines = [f"Radar findings for team '{team or 'all'}':\n"]
                for item in report.items:
                    context_lines.append(
                        f"- [{item.severity.value}] {item.external_id}: "
                        f"{item.title} — {item.reason}"
                    )

                messages = [
                    {
                        "role": "system",
                        "content": (
                            "You are BlameGraph's Morning Radar assistant. "
                            "Summarize the radar findings in 2-3 concise sentences. "
                            "Focus on the highest-risk items and recommend actions."
                        ),
                    },
                    {"role": "user", "content": "\n".join(context_lines)},
                ]

                with contextlib.suppress(Exception):
                    report.ai_summary = asyncio.run(
                        llm_client.chat(messages, model=model)  # type: ignore[call-arg]
                    )

        if as_json:
            console.print(json.dumps(radar_to_json(report), indent=2, default=str))
        else:
            console.print(format_radar_report(report))
    finally:
        storage.close()


@click.command()
@click.argument("ticket_key")
@click.pass_obj
@handle_cli_errors
def history(ctx: AppContext, ticket_key: str) -> None:
    """Show event history for a ticket (Time Machine)."""
    console = ctx.console
    _cfg = ctx.config

    from blamegraph.cli.formatters import format_entity_history
    from blamegraph.history import get_entity_history

    storage = ctx.open_storage()

    try:
        result = get_entity_history(storage, ticket_key)
        if result is None:
            console.print(f"[red]Error:[/red] Ticket {ticket_key} not found in graph.")
            sys.exit(1)
        console.print(format_entity_history(result))
    finally:
        storage.close()


@click.command()
@click.option("--team", default=None, help="Filter by team name.")
@click.option("--since", default="7d", help="Time window (e.g. 7d, 14d).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_obj
@handle_cli_errors
def drift(ctx: AppContext, team: str | None, since: str, as_json: bool) -> None:
    """Detect dependency drift — new blockers, resolved, scope creep."""
    console = ctx.console
    _cfg = ctx.config

    from blamegraph.cli.formatters import drift_to_json, format_drift_report
    from blamegraph.history import compute_drift

    storage = ctx.open_storage()

    try:
        days = parse_since(since)
        with console.status("[bold blue]Analyzing dependency drift...", spinner="dots"):
            report = compute_drift(storage, since_days=days, team=team)

        if as_json:
            console.print(json.dumps(drift_to_json(report), indent=2, default=str))
        else:
            console.print(format_drift_report(report))
    finally:
        storage.close()


@click.command()
@click.option("--ticket", required=True, help="Ticket key to check.")
@click.option(
    "--fail-on",
    type=click.Choice(["critical", "high", "medium"]),
    default="critical",
    help="Risk level threshold for gate failure.",
)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_obj
@handle_cli_errors
def watch(ctx: AppContext, ticket: str, fail_on: str, as_json: bool) -> None:
    """CI/CD Gate — fail pipeline if critical blockers exist."""
    console = ctx.console
    _cfg = ctx.config

    from blamegraph.cli.formatters import format_watch_result, watch_to_json
    from blamegraph.watch import check_ticket

    storage = ctx.open_storage()

    try:
        result = check_ticket(storage, ticket, fail_on=fail_on)

        if as_json:
            console.print(json.dumps(watch_to_json(result), indent=2, default=str))
        else:
            console.print(format_watch_result(result))

        if result.should_fail:
            sys.exit(1)
    finally:
        storage.close()


@click.command()
@click.option("--team", default=None, help="Filter by team name.")
@click.option("--since", default="7d", help="Time window (e.g. 24h, 7d).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--output", "output_file", type=click.Path(), default=None, help="Write to file.")
@click.pass_obj
@handle_cli_errors
def report(
    ctx: AppContext, team: str | None, since: str, as_json: bool, output_file: str | None
) -> None:
    """Generate a markdown report of dependencies and risks."""
    cfg = ctx.config
    console = ctx.console
    content = (
        f"# BlameGraph Report\n\n"
        f"Workspace: {cfg.workspace}\n"
        f"Team: {team or 'all'}\n"
        f"Since: {since}\n\n"
        f"*Stub: no data ingested yet.*\n"
    )
    if as_json:
        console.print(json.dumps({"team": team, "since": since, "report": content}))
    elif output_file:
        Path(output_file).write_text(content)
        console.print(f"[green]Report written to {output_file}[/green]")
    else:
        console.print(content)


@click.command()
@click.option("--ticket", required=True, help="Ticket key to draft a comment for.")
@click.option("--yes", is_flag=True, help="Actually write (skip dry-run).")
@click.pass_obj
@handle_cli_errors
def draft(ctx: AppContext, ticket: str, yes: bool) -> None:
    """Propose a ticket comment with dependency info (dry-run by default)."""
    _cfg = ctx.config
    console = ctx.console
    mode = "WRITE" if yes else "DRY-RUN"
    console.print(f"[bold]Draft[/bold] ticket={ticket} mode={mode}")
    console.print("[dim]Stub: would generate and preview comment.[/dim]")


@click.command()
@click.option("--draft-id", required=True, help="Draft ID to apply.")
@click.option("--yes", is_flag=True, help="Confirm write-back.")
@click.pass_obj
@handle_cli_errors
def apply(ctx: AppContext, draft_id: str, yes: bool) -> None:
    """Apply a previously drafted write-back."""
    _cfg = ctx.config
    console = ctx.console
    if not yes:
        console.print(
            f"[yellow]Dry-run:[/yellow] draft {draft_id} would be applied. Pass --yes to confirm."
        )
        return
    console.print(f"[bold]Applying[/bold] draft={draft_id}")
    console.print("[dim]Stub: would post write-back to external system.[/dim]")
