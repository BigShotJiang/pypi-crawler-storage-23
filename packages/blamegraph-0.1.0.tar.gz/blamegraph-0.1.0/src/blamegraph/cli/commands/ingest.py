"""``blamegraph sync`` — ingest data from connectors."""

from __future__ import annotations

import click

from blamegraph.cli.context import AppContext
from blamegraph.cli.errors import handle_cli_errors


@click.command()
@click.option("--since", default="24h", help="Time window (e.g. 24h, 7d).")
@click.option(
    "--source",
    type=click.Choice(["jira", "gitlab", "slack", "github", "bitbucket", "teams", "all"]),
    default="all",
    help="Data source to sync.",
)
@click.pass_obj
@handle_cli_errors
def sync(ctx: AppContext, since: str, source: str) -> None:
    """Ingest data from connectors."""
    cfg = ctx.config
    ctx.console.print(f"[bold]Sync[/bold] source={source} since={since} workspace={cfg.workspace}")
    ctx.console.print("[dim]Stub: would ingest data from connectors.[/dim]")
