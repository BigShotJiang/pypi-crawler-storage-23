"""``blamegraph init`` — interactive project setup wizard."""

from __future__ import annotations

from pathlib import Path

import click

from blamegraph.cli.context import AppContext, update_config_yaml
from blamegraph.cli.errors import handle_cli_errors
from blamegraph.config import load_config
from blamegraph.credentials import save_token

_CONFIG_TEMPLATE = """\
# BlameGraph configuration
workspace: my-workspace

connectors:
  jira:
    base_url: https://jira.example.com
    project_keys: ["PROJ"]
    token_env: JIRA_TOKEN

  gitlab:
    base_url: https://gitlab.example.com
    group: my-group
    token_env: GITLAB_TOKEN

  slack:
    enabled: false
    token_env: SLACK_TOKEN
    channels: []

  github:
    repos: []
    token_env: GITHUB_TOKEN

  bitbucket:
    workspace: ""
    repos: []
    token_env: BITBUCKET_TOKEN

  teams:
    enabled: false
    team_id: ""
    token_env: TEAMS_TOKEN
    channels: []

teams:
  default:
    repos: []
    jira_components: []

llm:
  provider: ""
  model_extract: ""
  model_answer: ""
  max_context_chars: 12000
  redact:
    patterns: []

storage:
  url: "sqlite:///./blamegraph.db"

writeback:
  dry_run_default: true
"""


@click.command()
@click.pass_obj
@handle_cli_errors
def init(ctx: AppContext) -> None:
    """Create a blamegraph.yaml config from template and validate it."""
    console = ctx.console
    target = Path(ctx.config_path) if ctx.config_path else Path("blamegraph.yaml")

    if target.exists():
        console.print(f"[yellow]Config already exists:[/yellow] {target}")
        cfg = load_config(target)
        console.print(f"[green]Config valid.[/green] Workspace: {cfg.workspace}")
        return

    target.write_text(_CONFIG_TEMPLATE)
    console.print(f"[green]Created config:[/green] {target}")

    console.print("\nSet up required API tokens (saved in ~/.blamegraph/credentials.yaml):")
    for service, label in [("jira", "Jira"), ("anthropic", "Anthropic")]:
        token = click.prompt(
            f"  {label} token",
            hide_input=True,
            show_default=False,
            prompt_suffix=": ",
        )
        save_token(service, token)
    console.print("[green]Tokens saved.[/green]")

    console.print("\nConfigure connectors (Enter to skip):")
    connectors: dict[str, dict[str, object]] = {}
    updates: dict[str, object] = {}

    workspace = click.prompt("  Workspace name", default="my-workspace")
    updates["workspace"] = workspace

    jira_url = click.prompt("  Jira URL", default="")
    if jira_url:
        jira_projects = click.prompt("  Jira project keys (comma-separated)", default="")
        keys = [k.strip() for k in jira_projects.split(",") if k.strip()]
        connectors["jira"] = {"base_url": jira_url, "project_keys": keys}

    gitlab_url = click.prompt("  GitLab URL", default="")
    if gitlab_url:
        gitlab_ids = click.prompt("  GitLab project IDs (comma-separated)", default="")
        ids = [int(i.strip()) for i in gitlab_ids.split(",") if i.strip()]
        gitlab_group = click.prompt("  GitLab group", default="")
        gl: dict[str, object] = {"base_url": gitlab_url, "project_ids": ids}
        if gitlab_group:
            gl["group"] = gitlab_group
        connectors["gitlab"] = gl

    slack_channels = click.prompt("  Slack channel IDs (comma-separated)", default="")
    if slack_channels:
        chs = [c.strip() for c in slack_channels.split(",") if c.strip()]
        connectors["slack"] = {"enabled": True, "channels": chs}

    github_repos = click.prompt("  GitHub repos (owner/repo, comma-separated)", default="")
    if github_repos:
        repos = [r.strip() for r in github_repos.split(",") if r.strip()]
        connectors["github"] = {"repos": repos}

    bb_workspace = click.prompt("  Bitbucket workspace", default="")
    if bb_workspace:
        bb_repos = click.prompt("  Bitbucket repos (comma-separated)", default="")
        repos = [r.strip() for r in bb_repos.split(",") if r.strip()]
        connectors["bitbucket"] = {"workspace": bb_workspace, "repos": repos}

    teams_id = click.prompt("  Teams team ID", default="")
    if teams_id:
        teams_channels = click.prompt("  Teams channel IDs (comma-separated)", default="")
        chs = [c.strip() for c in teams_channels.split(",") if c.strip()]
        connectors["teams"] = {"enabled": True, "team_id": teams_id, "channels": chs}

    if connectors:
        updates["connectors"] = connectors
    if updates:
        update_config_yaml(target, updates)
        console.print("[green]Config updated.[/green]")

    console.print(
        "\n[dim]# Enable tab completion:[/dim]"
        "\n[dim]# Bash: eval \"$(_BLAMEGRAPH_COMPLETE=bash_source blamegraph)\"[/dim]"
        "\n[dim]# Zsh:  eval \"$(_BLAMEGRAPH_COMPLETE=zsh_source blamegraph)\"[/dim]"
    )
