"""``blamegraph config`` — manage API tokens and connector settings."""

from __future__ import annotations

from pathlib import Path

import click

from blamegraph.cli.context import AppContext, update_config_yaml
from blamegraph.cli.errors import handle_cli_errors
from blamegraph.credentials import list_services, load_token, remove_token, save_token


def _find_config_path() -> Path:
    """Find the config file, defaulting to blamegraph.yaml in cwd."""
    for candidate in [Path("blamegraph.yaml"), Path.home() / ".blamegraph" / "config.yaml"]:
        if candidate.exists():
            return candidate
    return Path("blamegraph.yaml")


@click.group("config")
def config_group() -> None:
    """Manage API tokens and credentials."""


@config_group.command("set-token")
@click.argument(
    "service",
    type=click.Choice(
        ["jira", "gitlab", "slack", "anthropic", "github", "bitbucket", "teams"]
    ),
)
@click.pass_obj
@handle_cli_errors
def config_set_token(ctx: AppContext, service: str) -> None:
    """Set an API token for a service."""
    token = click.prompt(f"{service.capitalize()} token", hide_input=True)
    save_token(service, token)
    ctx.console.print(f"[green]Token saved for {service}.[/green]")


@config_group.command("show")
@click.pass_obj
@handle_cli_errors
def config_show(ctx: AppContext) -> None:
    """Show which services have tokens configured."""
    services = list_services()
    for service, has_token in services.items():
        if has_token:
            token = load_token(service) or ""
            masked = token[:4] + "****" if len(token) > 4 else "****"
            ctx.console.print(f"  {service}: {masked}")
        else:
            ctx.console.print(f"  {service}: [dim]not set[/dim]")


@config_group.command("remove-token")
@click.argument(
    "service",
    type=click.Choice(
        ["jira", "gitlab", "slack", "anthropic", "github", "bitbucket", "teams"]
    ),
)
@click.pass_obj
@handle_cli_errors
def config_remove_token(ctx: AppContext, service: str) -> None:
    """Remove an API token for a service."""
    remove_token(service)
    ctx.console.print(f"[yellow]Token removed for {service}.[/yellow]")


@config_group.command("set-jira")
@click.option("--url", prompt="Jira URL", help="Jira base URL.")
@click.option(
    "--projects",
    prompt="Project keys (comma-separated)",
    help="Jira project keys.",
)
@click.pass_obj
@handle_cli_errors
def config_set_jira(ctx: AppContext, url: str, projects: str) -> None:
    """Configure Jira connector (URL and project keys)."""
    keys = [k.strip() for k in projects.split(",") if k.strip()]
    path = _find_config_path()
    update_config_yaml(path, {"connectors": {"jira": {"base_url": url, "project_keys": keys}}})
    ctx.console.print(f"[green]Jira configured:[/green] {url} projects={keys}")


@config_group.command("set-gitlab")
@click.option("--url", prompt="GitLab URL", help="GitLab base URL.")
@click.option(
    "--projects",
    prompt="Project IDs (comma-separated)",
    help="GitLab project IDs.",
)
@click.option("--group", default="", prompt="Group name", help="GitLab group.")
@click.pass_obj
@handle_cli_errors
def config_set_gitlab(ctx: AppContext, url: str, projects: str, group: str) -> None:
    """Configure GitLab connector (URL, project IDs, group)."""
    ids = [int(i.strip()) for i in projects.split(",") if i.strip()]
    updates: dict[str, object] = {"base_url": url, "project_ids": ids}
    if group:
        updates["group"] = group
    path = _find_config_path()
    update_config_yaml(path, {"connectors": {"gitlab": updates}})
    ctx.console.print(f"[green]GitLab configured:[/green] {url} projects={ids}")


@config_group.command("set-slack")
@click.option(
    "--channels",
    prompt="Channel IDs (comma-separated)",
    help="Slack channel IDs.",
)
@click.pass_obj
@handle_cli_errors
def config_set_slack(ctx: AppContext, channels: str) -> None:
    """Configure Slack connector (channel IDs)."""
    ch = [c.strip() for c in channels.split(",") if c.strip()]
    path = _find_config_path()
    update_config_yaml(path, {"connectors": {"slack": {"enabled": True, "channels": ch}}})
    ctx.console.print(f"[green]Slack configured:[/green] channels={ch}")


@config_group.command("set-github")
@click.option(
    "--repos",
    prompt="GitHub repos (owner/repo, comma-separated)",
    help="GitHub repositories in owner/repo format.",
)
@click.pass_obj
@handle_cli_errors
def config_set_github(ctx: AppContext, repos: str) -> None:
    """Configure GitHub connector (repos)."""
    repo_list = [r.strip() for r in repos.split(",") if r.strip()]
    path = _find_config_path()
    update_config_yaml(path, {"connectors": {"github": {"repos": repo_list}}})
    ctx.console.print(f"[green]GitHub configured:[/green] repos={repo_list}")


@config_group.command("set-bitbucket")
@click.option("--workspace", prompt="Bitbucket workspace", help="Bitbucket workspace.")
@click.option(
    "--repos",
    prompt="Repo slugs (comma-separated)",
    help="Bitbucket repo slugs.",
)
@click.pass_obj
@handle_cli_errors
def config_set_bitbucket(ctx: AppContext, workspace: str, repos: str) -> None:
    """Configure Bitbucket connector (workspace and repos)."""
    repo_list = [r.strip() for r in repos.split(",") if r.strip()]
    path = _find_config_path()
    update_config_yaml(
        path,
        {"connectors": {"bitbucket": {"workspace": workspace, "repos": repo_list}}},
    )
    ctx.console.print(
        f"[green]Bitbucket configured:[/green] workspace={workspace} repos={repo_list}"
    )


@config_group.command("set-teams")
@click.option("--team-id", prompt="Teams team ID", help="Microsoft Teams team ID.")
@click.option(
    "--channels",
    prompt="Channel IDs (comma-separated)",
    help="Teams channel IDs.",
)
@click.pass_obj
@handle_cli_errors
def config_set_teams(ctx: AppContext, team_id: str, channels: str) -> None:
    """Configure Microsoft Teams connector (team ID and channels)."""
    ch = [c.strip() for c in channels.split(",") if c.strip()]
    path = _find_config_path()
    update_config_yaml(
        path,
        {"connectors": {"teams": {"enabled": True, "team_id": team_id, "channels": ch}}},
    )
    ctx.console.print(f"[green]Teams configured:[/green] team_id={team_id} channels={ch}")
