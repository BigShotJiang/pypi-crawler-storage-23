"""Query commands — ``ask``, ``chain``, ``blast``, ``unblock``."""

from __future__ import annotations

import asyncio
import contextlib
import json
import sys

import click

from blamegraph.cli.context import AppContext, pick_model
from blamegraph.cli.errors import handle_cli_errors


@click.command()
@click.argument("question")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--no-llm", is_flag=True, help="Skip LLM analysis.")
@click.option("--model", default=None, help="Model ID to use.")
@click.pass_obj
@handle_cli_errors
def ask(ctx: AppContext, question: str, as_json: bool, no_llm: bool, model: str | None) -> None:
    """Answer questions about dependencies with citations."""
    cfg = ctx.config
    console = ctx.console

    from blamegraph.search import LazySearcher, render_results, result_to_json

    llm_client = None
    if not no_llm:
        llm_client = ctx.create_llm_client()
        if llm_client is None:
            console.print(
                "[yellow]No Anthropic API key configured. "
                "Run: blamegraph config set-token anthropic[/yellow]"
            )
            console.print("[dim](Showing raw results without LLM analysis)[/dim]\n")
        elif not model:
            model = pick_model(cfg, console)

    searcher = LazySearcher(cfg, console=console, llm_client=llm_client)
    result = asyncio.run(searcher.search(question, model=model))

    if as_json:
        console.print(json.dumps(result_to_json(result), indent=2, default=str))
    else:
        render_results(console, result)


@click.command()
@click.option("--from", "from_key", required=True, help="Starting ticket key.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_obj
@handle_cli_errors
def chain(ctx: AppContext, from_key: str, as_json: bool) -> None:
    """Show dependency chain for a ticket."""
    _cfg = ctx.config
    console = ctx.console
    if as_json:
        console.print(json.dumps({"root": from_key, "chain": []}))
    else:
        console.print(f"[bold]Chain from:[/bold] {from_key}")
        console.print("[dim]Stub: would traverse dependency graph.[/dim]")


@click.command()
@click.argument("ticket_key")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--model", default=None, help="Model ID for AI summary.")
@click.pass_obj
@handle_cli_errors
def blast(ctx: AppContext, ticket_key: str, as_json: bool, model: str | None) -> None:
    """Blast Radius — show downstream impact if a ticket slips."""
    cfg = ctx.config
    console = ctx.console

    from blamegraph.cli.formatters import blast_to_json, format_blast_result
    from blamegraph.graph.blast import compute_blast_radius

    storage = ctx.open_storage()

    try:
        entity = storage.get_entity_by_external_id(ticket_key)
        if entity is None:
            console.print(f"[red]Error:[/red] Ticket {ticket_key} not found in graph.")
            console.print("[dim]Run 'blamegraph sync' and 'blamegraph analyze' first.[/dim]")
            sys.exit(1)

        with console.status("[bold blue]Computing blast radius...", spinner="dots"):
            result = compute_blast_radius(entity.id, storage)

        # Optional LLM summary
        if model or (not as_json and result.total_affected > 0):
            llm_client = ctx.create_llm_client()
            if llm_client:
                if not model:
                    model = pick_model(cfg, console)

                context_lines = [
                    f"Blast radius for {result.root_external_id} \"{result.root_title}\":",
                    f"Direct dependents: {len(result.direct)}",
                    f"Transitive dependents: {len(result.transitive)}",
                    f"Teams affected: {', '.join(result.teams_affected)}",
                ]
                for n in result.direct + result.transitive:
                    context_lines.append(
                        f"- {n.external_id} \"{n.title}\" [{n.team}] (depth {n.depth})"
                    )

                messages = [
                    {
                        "role": "system",
                        "content": (
                            "You are BlameGraph's blast radius analyst. "
                            "Summarize the cascading impact in 2-3 sentences. "
                            "Focus on cross-team implications and estimated delay."
                        ),
                    },
                    {"role": "user", "content": "\n".join(context_lines)},
                ]

                with contextlib.suppress(Exception):
                    result.ai_summary = asyncio.run(
                        llm_client.chat(messages, model=model)  # type: ignore[call-arg]
                    )

        if as_json:
            console.print(json.dumps(blast_to_json(result), indent=2, default=str))
        else:
            console.print(format_blast_result(result))
    finally:
        storage.close()


@click.command()
@click.argument("ticket_key")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--model", default=None, help="Model ID for AI summary.")
@click.pass_obj
@handle_cli_errors
def unblock(ctx: AppContext, ticket_key: str, as_json: bool, model: str | None) -> None:
    """Auto-Unblock — suggest actions to unblock a stalled ticket."""
    cfg = ctx.config
    console = ctx.console

    from blamegraph.cli.formatters import format_unblock_analysis, unblock_to_json
    from blamegraph.unblock import UnblockEngine, build_unblock_context

    storage = ctx.open_storage()

    try:
        with console.status("[bold blue]Analyzing blockers...", spinner="dots"):
            engine = UnblockEngine(storage)
            analysis = engine.analyze(ticket_key)

        # Optional LLM summary
        if model or (not as_json and analysis.suggestions):
            llm_client = ctx.create_llm_client()
            if llm_client:
                if not model:
                    model = pick_model(cfg, console)

                context = build_unblock_context(analysis)
                messages = [
                    {
                        "role": "system",
                        "content": (
                            "You are BlameGraph's unblock advisor. "
                            "Given the blocker analysis, suggest the fastest path "
                            "to unblocking the target ticket in 2-3 sentences."
                        ),
                    },
                    {"role": "user", "content": context},
                ]

                with contextlib.suppress(Exception):
                    analysis.ai_summary = asyncio.run(
                        llm_client.chat(messages, model=model)  # type: ignore[call-arg]
                    )

        if as_json:
            console.print(json.dumps(unblock_to_json(analysis), indent=2, default=str))
        else:
            console.print(format_unblock_analysis(analysis))
    finally:
        storage.close()
