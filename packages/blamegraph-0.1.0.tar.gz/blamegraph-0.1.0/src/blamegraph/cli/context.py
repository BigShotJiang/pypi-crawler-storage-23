"""Shared CLI context and helper utilities."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

import click
import yaml
from rich.console import Console

from blamegraph.config import FALLBACK_MODELS, load_config

if TYPE_CHECKING:
    from blamegraph.config import BlameGraphConfig
    from blamegraph.llm.client import LLMClientProtocol
    from blamegraph.storage.sqlite import SQLiteStorage


class AppContext:
    """Shared state threaded through ``@click.pass_obj``."""

    def __init__(
        self,
        *,
        config_path: str | None = None,
        verbose: bool = False,
        quiet: bool = False,
        no_color: bool = False,
    ) -> None:
        self.config_path = config_path
        self.verbose = verbose
        self.quiet = quiet
        self.no_color = no_color
        self._console: Console | None = None
        self._config: BlameGraphConfig | None = None

    # -- lazy properties ------------------------------------------------

    @property
    def console(self) -> Console:
        if self._console is None:
            self._console = Console(no_color=self.no_color, quiet=self.quiet)
        return self._console

    @property
    def config(self) -> BlameGraphConfig:
        if self._config is None:
            path = Path(self.config_path) if self.config_path else None
            self._config = load_config(path)
        return self._config

    # -- helpers --------------------------------------------------------

    def get_db_path(self) -> str:
        """Extract SQLite database path from config."""
        url = self.config.storage.url
        if url.startswith("sqlite:///"):
            return url[len("sqlite:///"):]
        return "blamegraph.db"

    def open_storage(self) -> SQLiteStorage:
        """Create an initialised ``SQLiteStorage`` handle."""
        from blamegraph.storage.sqlite import SQLiteStorage

        storage = SQLiteStorage(self.get_db_path())
        storage.initialize()
        return storage

    def create_llm_client(self) -> LLMClientProtocol | None:
        """Create an LLM client from the current config (or ``None``)."""
        from blamegraph.llm.client import create_llm_client

        return create_llm_client(self.config)


# -- free-standing helpers used by multiple command modules --------------


def update_config_yaml(path: Path, updates: dict[str, object]) -> None:
    """Read *blamegraph.yaml*, deep-merge *updates*, and write back."""
    raw = yaml.safe_load(path.read_text()) or {}

    def _merge(base: dict, patch: dict) -> dict:  # type: ignore[type-arg]
        for k, v in patch.items():
            if isinstance(v, dict) and isinstance(base.get(k), dict):
                _merge(base[k], v)
            else:
                base[k] = v
        return base

    _merge(raw, updates)
    path.write_text(yaml.safe_dump(raw, default_flow_style=False, sort_keys=False))


def parse_since(since: str) -> int:
    """Parse a human time delta like ``'7d'``, ``'24h'`` into days."""
    m = re.match(r"(\d+)\s*([dhw])", since.lower())
    if not m:
        return 7
    value, unit = int(m.group(1)), m.group(2)
    if unit == "h":
        return max(1, value // 24)
    if unit == "w":
        return value * 7
    return value


def fetch_models(cfg: object) -> list[str]:
    """Return available Anthropic models, with fallback."""
    from blamegraph.config import BlameGraphConfig

    if not isinstance(cfg, BlameGraphConfig):
        return list(FALLBACK_MODELS)

    from blamegraph.llm.anthropic import ANTHROPIC_MODELS

    return [str(m["id"]) for m in ANTHROPIC_MODELS]


def pick_model(cfg: object, console: Console) -> str:
    """Interactive model picker or return configured default."""
    from blamegraph.config import BlameGraphConfig

    if isinstance(cfg, BlameGraphConfig) and cfg.llm.model:
        return cfg.llm.model

    with console.status("[bold blue]Loading models...", spinner="dots"):
        models = fetch_models(cfg)

    console.print("\n[bold]Select model for analysis:[/bold]")
    for i, model_id in enumerate(models, 1):
        rec = " [green](Recommended)[/green]" if i == 1 else ""
        console.print(f"  {i}. {model_id}{rec}")
    choice: int = click.prompt("Choose", type=int, default=1)
    idx = max(1, min(choice, len(models))) - 1
    return models[idx]
