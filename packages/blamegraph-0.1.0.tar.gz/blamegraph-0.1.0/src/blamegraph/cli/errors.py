"""CLI error-handling decorator — replaces repetitive try/except blocks."""

from __future__ import annotations

import functools
import sys
from collections.abc import Callable
from typing import Any, TypeVar

import click
from rich.console import Console
from rich.panel import Panel

from blamegraph.errors import (
    BlameGraphError,
    ConfigError,
    ConnectorError,
    LLMError,
    StorageError,
)

F = TypeVar("F", bound=Callable[..., Any])

_SUGGESTIONS: dict[type[BlameGraphError], str] = {
    ConfigError: "Run [bold]blamegraph init[/bold] to create a config file.",
    ConnectorError: "Check your tokens with [bold]blamegraph config show[/bold].",
    StorageError: "Run [bold]blamegraph sync[/bold] and [bold]blamegraph analyze[/bold] first.",
    LLMError: "Run [bold]blamegraph config set-token anthropic[/bold] to set an API key.",
}


def handle_cli_errors(fn: F) -> F:
    """Decorator that wraps a Click command with uniform error handling.

    * ``BlameGraphError`` → Rich panel with red border + fix suggestion
    * ``click.Abort``     → "Aborted." message
    * ``SystemExit``      → re-raised (Click / ``sys.exit`` handles it)
    * ``Exception``       → "Unexpected Error" panel, exit code 10
    """

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except SystemExit:
            raise
        except KeyboardInterrupt:
            raise
        except click.Abort:
            _get_console(args).print("\n[yellow]Aborted.[/yellow]")
            sys.exit(1)
        except BlameGraphError as exc:
            con = _get_console(args)
            lines = [f"[bold red]{exc}[/bold red]"]
            if exc.detail:
                lines.append(f"[dim]{exc.detail}[/dim]")
            suggestion = _SUGGESTIONS.get(type(exc))
            if suggestion:
                lines.append(f"\n{suggestion}")
            con.print(Panel("\n".join(lines), title="Error", border_style="red"))
            sys.exit(exc.exit_code)
        except Exception as exc:
            con = _get_console(args)
            con.print(
                Panel(
                    f"[bold red]{type(exc).__name__}:[/bold red] {exc}",
                    title="Unexpected Error",
                    border_style="red",
                )
            )
            sys.exit(10)

    return wrapper  # type: ignore[return-value]


def _get_console(args: tuple[Any, ...]) -> Console:
    """Try to extract a Console from the Click context or AppContext."""
    from blamegraph.cli.context import AppContext

    for arg in args:
        if isinstance(arg, AppContext):
            return arg.console
        if isinstance(arg, click.Context) and isinstance(arg.obj, AppContext):
            return arg.obj.console
    return Console()
