"""BlameGraph CLI package — re-exports the root ``cli`` group."""

from blamegraph.cli.app import cli

__all__ = ["cli"]
