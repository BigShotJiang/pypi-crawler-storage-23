"""BlameGraph CLI — root group, global options, and command registration."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

import click

from blamegraph.cli.context import AppContext
from blamegraph.cli.errors import handle_cli_errors
from blamegraph.cli.help import RichGroup


def _get_version() -> str:
    try:
        return version("blamegraph")
    except PackageNotFoundError:
        return "0.0.0-dev"


@click.group(cls=RichGroup)
@click.version_option(version=_get_version(), prog_name="blamegraph")
@click.option(
    "-c",
    "--config",
    "config_path",
    type=click.Path(),
    default=None,
    envvar="BLAMEGRAPH_CONFIG",
    help="Path to config file.",
)
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
@click.option("-q", "--quiet", is_flag=True, help="Suppress non-essential output.")
@click.option("--no-color", is_flag=True, envvar="NO_COLOR", help="Disable coloured output.")
@click.pass_context
@handle_cli_errors
def cli(
    ctx: click.Context,
    config_path: str | None,
    verbose: bool,
    quiet: bool,
    no_color: bool,
) -> None:
    """BlameGraph — cross-team dependency and risk analyst."""
    ctx.ensure_object(dict)
    ctx.obj = AppContext(
        config_path=config_path,
        verbose=verbose,
        quiet=quiet,
        no_color=no_color,
    )

    if verbose:
        import logging

        logging.basicConfig(level=logging.DEBUG)


# -- register commands ---------------------------------------------------

from blamegraph.cli.commands.config import config_group  # noqa: E402
from blamegraph.cli.commands.ingest import sync  # noqa: E402
from blamegraph.cli.commands.ops import (  # noqa: E402
    analyze,
    apply,
    draft,
    drift,
    history,
    radar,
    report,
    watch,
)
from blamegraph.cli.commands.query import ask, blast, chain, unblock  # noqa: E402
from blamegraph.cli.commands.setup import init  # noqa: E402

cli.add_command(init)
cli.add_command(config_group, "config")
cli.add_command(sync)
cli.add_command(analyze)
cli.add_command(ask)
cli.add_command(chain)
cli.add_command(blast)
cli.add_command(unblock)
cli.add_command(radar)
cli.add_command(drift)
cli.add_command(watch)
cli.add_command(report)
cli.add_command(draft)
cli.add_command(apply)
cli.add_command(history)
