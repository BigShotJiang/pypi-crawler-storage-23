"""Backward-compatibility shim — imports from the new modular CLI."""

from blamegraph.cli.app import cli

__all__ = ["cli"]
