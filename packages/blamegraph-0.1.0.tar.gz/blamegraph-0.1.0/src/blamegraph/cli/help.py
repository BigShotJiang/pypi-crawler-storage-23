"""Rich-formatted help and command aliasing for the BlameGraph CLI."""

from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table
from rich.text import Text

BANNER = r"""
 ____  _                       ____                 _
| __ )| | __ _ _ __ ___   ___ / ___|_ __ __ _ _ __ | |__
|  _ \| |/ _` | '_ ` _ \ / _ \ |  _| '__/ _` | '_ \| '_ \
| |_) | | (_| | | | | | |  __/ |_| | | | (_| | |_) | | | |
|____/|_|\__,_|_| |_| |_|\___|\____|_|  \__,_| .__/|_| |_|
                                              |_|
"""

# command name → category
CATEGORIES: dict[str, str] = {
    "init": "Setup",
    "config": "Setup",
    "sync": "Data",
    "analyze": "Data",
    "ask": "Analysis",
    "chain": "Analysis",
    "blast": "Analysis",
    "unblock": "Analysis",
    "radar": "Operations",
    "drift": "Operations",
    "watch": "Operations",
    "report": "Operations",
    "draft": "Operations",
    "apply": "Operations",
    "history": "Operations",
}

CATEGORY_ORDER = ["Setup", "Data", "Analysis", "Operations"]

ALIASES: dict[str, str] = {
    "r": "radar",
    "b": "blast",
    "a": "ask",
    "s": "sync",
    "h": "history",
    "d": "drift",
    "w": "watch",
    "u": "unblock",
}

# reverse map: canonical → list of aliases
_REVERSE_ALIASES: dict[str, list[str]] = {}
for _alias, _canonical in ALIASES.items():
    _REVERSE_ALIASES.setdefault(_canonical, []).append(_alias)


class RichGroup(click.Group):
    """``click.Group`` subclass with Rich-formatted help and alias support."""

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """Resolve aliases before looking up the real command."""
        cmd_name = ALIASES.get(cmd_name, cmd_name)
        return super().get_command(ctx, cmd_name)

    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str | None, click.Command | None, list[str]]:
        """Resolve aliases so that Click's token normalisation works."""
        if args:
            args[0] = ALIASES.get(args[0], args[0])
        return super().resolve_command(ctx, args)

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Render a Rich-formatted help page with banner and categories."""
        console = Console()

        # Banner
        console.print(Text(BANNER, style="bold cyan"))
        console.print(
            "  [bold]BlameGraph[/bold] — Cross-team dependency and risk analyst\n",
        )

        # Global options
        opts = self.get_params(ctx)
        if opts:
            console.print("[bold underline]Options:[/bold underline]")
            for param in opts:
                rv = param.get_help_record(ctx)
                if rv is not None:
                    name, helptext = rv
                    console.print(f"  {name:<28} {helptext}")
            console.print()

        # Commands by category
        commands = self.list_commands(ctx)
        categorised: dict[str, list[tuple[str, click.Command]]] = {
            cat: [] for cat in CATEGORY_ORDER
        }

        for cmd_name in commands:
            cmd = self.get_command(ctx, cmd_name)
            if cmd is None or cmd.hidden:
                continue
            cat = CATEGORIES.get(cmd_name, "Operations")
            categorised.setdefault(cat, []).append((cmd_name, cmd))

        for cat in CATEGORY_ORDER:
            cmds = categorised.get(cat)
            if not cmds:
                continue

            table = Table(
                title=cat,
                title_style="bold underline",
                show_header=False,
                show_edge=False,
                pad_edge=False,
                box=None,
                padding=(0, 2),
            )
            table.add_column(style="cyan", min_width=22)
            table.add_column()

            for cmd_name, cmd in cmds:
                aliases = _REVERSE_ALIASES.get(cmd_name, [])
                alias_str = f" ({', '.join(aliases)})" if aliases else ""
                short_help = cmd.get_short_help_str(limit=60)
                table.add_row(f"  {cmd_name}{alias_str}", short_help)

            console.print(table)
            console.print()
