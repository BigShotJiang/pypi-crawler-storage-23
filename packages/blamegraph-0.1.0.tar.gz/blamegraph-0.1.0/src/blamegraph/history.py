"""Dependency Time Machine — graph snapshots and drift detection."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from blamegraph.models import EdgeType, GraphSnapshot
from blamegraph.storage.sqlite import SQLiteStorage


@dataclass
class DriftItem:
    """A single drift observation."""
    kind: str  # new_blocker, resolved, reopened, scope_creep
    entity_id: str
    external_id: str
    title: str
    detail: str


@dataclass
class DriftReport:
    """Drift analysis between two time periods."""
    team: str | None
    since: str
    new_blockers: int = 0
    resolved: int = 0
    net_change: int = 0
    trend: str = "stable"  # increasing, decreasing, stable
    items: list[DriftItem] = field(default_factory=list)
    scope_creep: list[DriftItem] = field(default_factory=list)


@dataclass
class EntityHistory:
    """Timeline of changes for a single entity."""
    entity_id: str
    external_id: str
    title: str
    events: list[dict[str, object]] = field(default_factory=list)


def take_snapshot(storage: SQLiteStorage) -> GraphSnapshot:
    """Capture a point-in-time snapshot of the current graph state."""
    entities = storage.list_entities()
    edges = storage.list_edges()

    blocker_edges = [e for e in edges if e.edge_type == EdgeType.BLOCKS]

    # Build snapshot data with entity/edge summaries
    entity_summaries = []
    for ent in entities:
        entity_summaries.append({
            "id": ent.id,
            "external_id": ent.external_id,
            "title": ent.title,
            "entity_type": ent.entity_type.value,
            "status": str(ent.attributes.get("status", "")),
            "assignee": str(ent.attributes.get("assignee", "")),
        })

    edge_summaries = []
    for edge in edges:
        edge_summaries.append({
            "id": edge.id,
            "from_entity": edge.from_entity,
            "to_entity": edge.to_entity,
            "edge_type": edge.edge_type.value,
            "confidence": edge.confidence,
        })

    snapshot = GraphSnapshot(
        id=str(uuid.uuid4()),
        ts=datetime.utcnow(),
        entity_count=len(entities),
        edge_count=len(edges),
        blocker_count=len(blocker_edges),
        snapshot_data={
            "entities": entity_summaries,
            "edges": edge_summaries,
        },
    )

    storage.save_snapshot(snapshot)
    return snapshot


def compute_drift(
    storage: SQLiteStorage,
    since_days: int = 7,
    team: str | None = None,
) -> DriftReport:
    """Compare current graph state against the oldest snapshot within the window."""
    since_str = f"{since_days}d"
    report = DriftReport(team=team, since=since_str)

    cutoff = datetime.utcnow() - timedelta(days=since_days)
    cutoff_iso = cutoff.isoformat()

    snapshots = storage.list_snapshots(since=cutoff_iso)
    if not snapshots:
        # No historical data — take a snapshot now for future comparisons
        take_snapshot(storage)
        return report

    # Use the oldest snapshot in the window as baseline
    baseline = snapshots[-1]  # list is ordered DESC, so last is oldest
    baseline_data = baseline.snapshot_data

    # Current state
    current_entities = storage.list_entities(entity_type="ticket")
    current_edges = storage.list_edges()

    current_blocker_from = {
        (e.from_entity, e.to_entity)
        for e in current_edges
        if e.edge_type == EdgeType.BLOCKS
    }

    # Reconstruct baseline blocker set
    baseline_edges = baseline_data.get("edges", [])
    baseline_blocker_from: set[tuple[str, str]] = set()
    if isinstance(baseline_edges, list):
        for edge_data in baseline_edges:
            if isinstance(edge_data, dict) and edge_data.get("edge_type") == "blocks":
                from_e = str(edge_data.get("from_entity", ""))
                to_e = str(edge_data.get("to_entity", ""))
                if from_e and to_e:
                    baseline_blocker_from.add((from_e, to_e))

    # New blockers (in current but not in baseline)
    new_blocker_pairs = current_blocker_from - baseline_blocker_from
    # Resolved blockers (in baseline but not in current)
    resolved_pairs = baseline_blocker_from - current_blocker_from

    entity_map = {e.id: e for e in current_entities}
    all_entities = {e.id: e for e in storage.list_entities()}

    for from_id, to_id in new_blocker_pairs:
        entity = all_entities.get(to_id) or all_entities.get(from_id)
        if entity:
            report.items.append(DriftItem(
                kind="new_blocker",
                entity_id=entity.id,
                external_id=entity.external_id,
                title=entity.title,
                detail=f"New blocker: {from_id} blocks {to_id}",
            ))

    for from_id, to_id in resolved_pairs:
        entity = all_entities.get(to_id) or all_entities.get(from_id)
        if entity:
            report.items.append(DriftItem(
                kind="resolved",
                entity_id=entity.id,
                external_id=entity.external_id,
                title=entity.title,
                detail=f"Resolved: {from_id} no longer blocks {to_id}",
            ))

    # Scope creep detection: entities that gained new dependencies
    baseline_entity_ids: set[str] = set()
    baseline_entities_list = baseline_data.get("entities", [])
    if isinstance(baseline_entities_list, list):
        for ent_data in baseline_entities_list:
            if isinstance(ent_data, dict):
                baseline_entity_ids.add(str(ent_data.get("id", "")))

    current_entity_ids = {e.id for e in current_entities}
    new_entity_ids = current_entity_ids - baseline_entity_ids

    for eid in new_entity_ids:
        entity = entity_map.get(eid)
        if entity:
            # Check if this new entity has blockers (scope creep)
            has_deps = any(
                e.to_entity == eid or e.from_entity == eid
                for e in current_edges
                if e.edge_type in (EdgeType.BLOCKS, EdgeType.DEPENDS_ON)
            )
            if has_deps:
                report.scope_creep.append(DriftItem(
                    kind="scope_creep",
                    entity_id=entity.id,
                    external_id=entity.external_id,
                    title=entity.title,
                    detail=f"New ticket with dependencies added during period",
                ))

    report.new_blockers = len(new_blocker_pairs)
    report.resolved = len(resolved_pairs)
    report.net_change = report.new_blockers - report.resolved

    if report.net_change > 0:
        report.trend = "increasing"
    elif report.net_change < 0:
        report.trend = "decreasing"
    else:
        report.trend = "stable"

    return report


def get_entity_history(
    storage: SQLiteStorage,
    external_id: str,
) -> EntityHistory | None:
    """Get the full event timeline for an entity by its external ID."""
    entity = storage.get_entity_by_external_id(external_id)
    if entity is None:
        return None

    events = storage.list_events(entity.id)

    event_dicts: list[dict[str, object]] = []
    for event in events:
        event_dicts.append({
            "ts": event.ts.isoformat(),
            "kind": event.kind,
            "payload": event.payload,
        })

    return EntityHistory(
        entity_id=entity.id,
        external_id=entity.external_id,
        title=entity.title,
        events=event_dicts,
    )
