"""Morning Radar — proactive daily scan for team-scoped issues."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from blamegraph.models import Edge, EdgeType, Entity, RiskLevel, RiskScore
from blamegraph.storage.sqlite import SQLiteStorage


class RadarSeverity(enum.StrEnum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


@dataclass
class RadarItem:
    """A single radar finding."""
    severity: RadarSeverity
    entity_id: str
    external_id: str
    title: str
    reason: str
    details: dict[str, object] = field(default_factory=dict)


@dataclass
class RadarReport:
    """Complete radar scan result."""
    team: str | None
    generated_at: datetime = field(default_factory=datetime.utcnow)
    items: list[RadarItem] = field(default_factory=list)
    ai_summary: str = ""

    @property
    def critical_items(self) -> list[RadarItem]:
        return [i for i in self.items if i.severity == RadarSeverity.CRITICAL]

    @property
    def warning_items(self) -> list[RadarItem]:
        return [i for i in self.items if i.severity == RadarSeverity.WARNING]

    @property
    def info_items(self) -> list[RadarItem]:
        return [i for i in self.items if i.severity == RadarSeverity.INFO]


class RadarEngine:
    """Scans the dependency graph for issues requiring attention."""

    def __init__(self, storage: SQLiteStorage, stale_days: int = 7) -> None:
        self._storage = storage
        self._stale_days = stale_days

    def scan(self, team: str | None = None) -> RadarReport:
        """Run all radar checks and return a prioritized report."""
        report = RadarReport(team=team)

        entities = self._storage.list_entities(entity_type="ticket")
        edges = self._storage.list_edges()
        risk_scores = self._storage.list_risk_scores()

        # Filter by team if specified
        if team:
            entities = self._filter_by_team(entities, team)

        entity_ids = {e.id for e in entities}

        report.items.extend(self._find_blocked_no_assignee(entities, edges))
        report.items.extend(self._find_stale_tickets(entities))
        report.items.extend(self._find_high_risk(entities, risk_scores))
        report.items.extend(self._find_blocking_many(entities, edges, entity_ids))
        report.items.extend(self._find_no_activity(entities))

        # Sort: critical first, then warning, then info
        severity_order = {RadarSeverity.CRITICAL: 0, RadarSeverity.WARNING: 1, RadarSeverity.INFO: 2}
        report.items.sort(key=lambda i: severity_order.get(i.severity, 3))

        return report

    def _filter_by_team(self, entities: list[Entity], team: str) -> list[Entity]:
        """Filter entities by team based on labels, components, or assignee."""
        filtered = []
        team_lower = team.lower()
        for e in entities:
            labels = e.attributes.get("labels", [])
            components = e.attributes.get("components", [])
            assignee = str(e.attributes.get("assignee", "")).lower()
            # Check if team name appears in labels, components, or project key prefix
            all_tags = [str(l).lower() for l in (labels if isinstance(labels, list) else [])]
            all_tags.extend(str(c).lower() for c in (components if isinstance(components, list) else []))
            prefix = e.external_id.split("-")[0].lower() if "-" in e.external_id else ""
            if (
                team_lower in all_tags
                or team_lower == prefix
                or team_lower in assignee
            ):
                filtered.append(e)
        return filtered if filtered else entities  # Fall back to all if no match

    def _find_blocked_no_assignee(
        self, entities: list[Entity], edges: list[Edge]
    ) -> list[RadarItem]:
        """Find tickets that are blocked and have no assignee."""
        items: list[RadarItem] = []
        blocked_ids = {e.to_entity for e in edges if e.edge_type == EdgeType.BLOCKS}

        for entity in entities:
            if entity.id not in blocked_ids:
                continue
            assignee = entity.attributes.get("assignee")
            status = str(entity.attributes.get("status", "")).lower()
            if status in ("done", "closed", "resolved"):
                continue
            if not assignee:
                # Count how long it's been blocked
                days_old = (datetime.utcnow() - entity.updated_at).days
                items.append(
                    RadarItem(
                        severity=RadarSeverity.CRITICAL,
                        entity_id=entity.id,
                        external_id=entity.external_id,
                        title=entity.title,
                        reason=f"Blocked {days_old} days, no assignee",
                        details={"days_blocked": days_old, "status": status},
                    )
                )
        return items

    def _find_stale_tickets(self, entities: list[Entity]) -> list[RadarItem]:
        """Find tickets with no update in stale_days."""
        items: list[RadarItem] = []
        cutoff = datetime.utcnow() - timedelta(days=self._stale_days)

        for entity in entities:
            status = str(entity.attributes.get("status", "")).lower()
            if status in ("done", "closed", "resolved"):
                continue
            if entity.updated_at < cutoff:
                days_stale = (datetime.utcnow() - entity.updated_at).days
                items.append(
                    RadarItem(
                        severity=RadarSeverity.WARNING,
                        entity_id=entity.id,
                        external_id=entity.external_id,
                        title=entity.title,
                        reason=f"No update for {days_stale} days",
                        details={"days_stale": days_stale, "last_update": entity.updated_at.isoformat()},
                    )
                )
        return items

    def _find_high_risk(
        self, entities: list[Entity], risk_scores: list[RiskScore]
    ) -> list[RadarItem]:
        """Find entities with HIGH or CRITICAL risk scores."""
        items: list[RadarItem] = []
        entity_ids = {e.id for e in entities}
        risk_map = {rs.entity_id: rs for rs in risk_scores}

        for entity in entities:
            rs = risk_map.get(entity.id)
            if rs and rs.level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
                severity = (
                    RadarSeverity.CRITICAL
                    if rs.level == RiskLevel.CRITICAL
                    else RadarSeverity.WARNING
                )
                items.append(
                    RadarItem(
                        severity=severity,
                        entity_id=entity.id,
                        external_id=entity.external_id,
                        title=entity.title,
                        reason=f"Risk score {rs.score:.0f} ({rs.level.value})",
                        details={
                            "risk_score": rs.score,
                            "risk_level": rs.level.value,
                            "suggested_action": rs.suggested_action,
                        },
                    )
                )
        return items

    def _find_blocking_many(
        self,
        entities: list[Entity],
        edges: list[Edge],
        entity_ids: set[str],
    ) -> list[RadarItem]:
        """Find tickets that block 3+ other tickets (critical path items)."""
        items: list[RadarItem] = []
        entity_map = {e.id: e for e in entities}

        # Count how many tickets each entity blocks
        blocker_counts: dict[str, int] = {}
        for edge in edges:
            if edge.edge_type == EdgeType.BLOCKS and edge.from_entity in entity_ids:
                blocker_counts[edge.from_entity] = blocker_counts.get(edge.from_entity, 0) + 1

        for entity_id, count in blocker_counts.items():
            if count >= 3:
                entity = entity_map.get(entity_id)
                if entity:
                    status = str(entity.attributes.get("status", "")).lower()
                    if status not in ("done", "closed", "resolved"):
                        items.append(
                            RadarItem(
                                severity=RadarSeverity.CRITICAL,
                                entity_id=entity.id,
                                external_id=entity.external_id,
                                title=entity.title,
                                reason=f"Blocks {count} downstream tickets",
                                details={"downstream_count": count},
                            )
                        )
        return items

    def _find_no_activity(self, entities: list[Entity]) -> list[RadarItem]:
        """Find in-progress tickets with MRs open too long."""
        items: list[RadarItem] = []
        for entity in entities:
            status = str(entity.attributes.get("status", "")).lower()
            if status not in ("in progress", "in review"):
                continue
            days_since = (datetime.utcnow() - entity.updated_at).days
            if days_since >= 10:
                items.append(
                    RadarItem(
                        severity=RadarSeverity.WARNING,
                        entity_id=entity.id,
                        external_id=entity.external_id,
                        title=entity.title,
                        reason=f"In '{status}' for {days_since} days with no update",
                        details={"status": status, "days_no_activity": days_since},
                    )
                )
        return items
