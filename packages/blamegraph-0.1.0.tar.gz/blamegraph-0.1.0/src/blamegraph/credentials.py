"""Credential management — save and load API tokens from ~/.blamegraph/credentials.yaml."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import yaml

CREDENTIALS_DIR = Path.home() / ".blamegraph"
CREDENTIALS_PATH = CREDENTIALS_DIR / "credentials.yaml"

_KNOWN_SERVICES = (
    "jira",
    "gitlab",
    "slack",
    "anthropic",
    "github",
    "bitbucket",
    "teams",
)


def _ensure_dir() -> None:
    """Create ~/.blamegraph/ with 0o700 if it doesn't exist."""
    CREDENTIALS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def _read_file() -> dict[str, str]:
    """Read the credentials YAML file, returning an empty dict if missing."""
    if not CREDENTIALS_PATH.exists():
        return {}
    raw = yaml.safe_load(CREDENTIALS_PATH.read_text())
    if not isinstance(raw, dict):
        return {}
    return {k: str(v) for k, v in raw.items()}


def _write_file(data: dict[str, str]) -> None:
    """Write credentials dict to YAML and set file permissions to 0o600."""
    _ensure_dir()
    CREDENTIALS_PATH.write_text(yaml.safe_dump(data, default_flow_style=False))
    os.chmod(CREDENTIALS_PATH, stat.S_IRUSR | stat.S_IWUSR)


def save_token(service: str, token: str) -> None:
    """Save a token for the given service, creating or updating the file."""
    data = _read_file()
    data[service] = token
    _write_file(data)


def load_token(service: str) -> str | None:
    """Load a token for the given service, returning None if not found."""
    data = _read_file()
    return data.get(service)


def list_services() -> dict[str, bool]:
    """Return a dict of known services mapped to whether a token is set."""
    data = _read_file()
    return {svc: bool(data.get(svc)) for svc in _KNOWN_SERVICES}


def remove_token(service: str) -> None:
    """Remove a token for the given service."""
    data = _read_file()
    data.pop(service, None)
    _write_file(data)
