"""Slack digest delivery — stub for future implementation."""

from __future__ import annotations


class SlackDigest:
    """Send digest messages to Slack channels."""

    async def send(self, channel: str, content: str) -> None:
        """Send a digest to a Slack channel.

        Not yet implemented.
        """
        raise NotImplementedError("Slack digest delivery is not implemented yet.")
