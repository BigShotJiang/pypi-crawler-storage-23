"""Markdown report generation for BlameGraph."""

from __future__ import annotations

from blamegraph.models import Edge, Entity, RiskLevel, RiskScore


class ReportGenerator:
    """Generate markdown reports from graph data."""

    def generate_markdown(
        self,
        entities: list[Entity],
        edges: list[Edge],
        risk_scores: list[RiskScore],
        team: str | None = None,
        since: str | None = None,
    ) -> str:
        """Produce a full markdown report with standard sections."""
        sections: list[str] = []

        # Summary
        sections.append("# BlameGraph Report\n")
        if team:
            sections.append(f"**Team:** {team}\n")
        if since:
            sections.append(f"**Period:** last {since}\n")
        sections.append(
            f"**Entities:** {len(entities)} | "
            f"**Edges:** {len(edges)} | "
            f"**Risk scores:** {len(risk_scores)}\n"
        )

        # High-Risk Items
        high_risk = [rs for rs in risk_scores if rs.level in (RiskLevel.HIGH, RiskLevel.CRITICAL)]
        sections.append("## High-Risk Items\n")
        if high_risk:
            for rs in sorted(high_risk, key=lambda r: r.score, reverse=True):
                sections.append(
                    f"- **{rs.entity_id}** — score {rs.score:.1f} "
                    f"({rs.level.value}): {rs.suggested_action or 'no action suggested'}"
                )
            sections.append("")
        else:
            sections.append("No high-risk items found.\n")

        # Dependency Chains
        sections.append("## Dependency Chains\n")
        if edges:
            for edge in edges:
                sections.append(
                    f"- {edge.from_entity} --[{edge.edge_type.value}]--> {edge.to_entity} "
                    f"(confidence: {edge.confidence:.2f})"
                )
            sections.append("")
        else:
            sections.append("No dependency edges found.\n")

        # Owner Map
        sections.append("## Owner Map\n")
        owner_entities = [e for e in entities if e.entity_type.value in ("person", "team")]
        if owner_entities:
            for e in owner_entities:
                sections.append(f"- **{e.title or e.id}** ({e.entity_type.value})")
            sections.append("")
        else:
            sections.append("No owners mapped yet.\n")

        # Recommendations
        sections.append("## Recommendations\n")
        if high_risk:
            sections.append("- Address high-risk items above as priority.")
            sections.append("- Review dependency chains for potential blockers.")
            sections.append("- Confirm owner assignments are up to date.")
            sections.append("")
        else:
            sections.append("No immediate recommendations.\n")

        return "\n".join(sections)
