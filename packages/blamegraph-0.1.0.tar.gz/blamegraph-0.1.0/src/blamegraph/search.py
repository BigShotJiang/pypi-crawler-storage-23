"""Lazy search orchestrator — analyzes questions and searches connectors on-demand."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from blamegraph.config import BlameGraphConfig
from blamegraph.connectors.gitlab import GitLabConnector
from blamegraph.connectors.jira import JiraConnector
from blamegraph.connectors.slack import SlackConnector
from blamegraph.errors import ConnectorError
from blamegraph.graph.inference import DependencyInferrer
from blamegraph.llm.context import build_context
from blamegraph.llm.prompts import ANSWER_SYSTEM_PROMPT
from blamegraph.models import Edge, Entity, RawPayload
from blamegraph.normalizer import normalize_gitlab_mr, normalize_jira_issue, normalize_slack_message

logger = logging.getLogger(__name__)

_TICKET_KEY_RE = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")

# Common stop words to filter from keyword extraction
_STOP_WORDS = frozenset(
    {
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "what",
        "who",
        "how",
        "why",
        "when",
        "where",
        "do",
        "does",
        "did",
        "co",
        "to",
        "for",
        "in",
        "on",
        "at",
        "by",
        "of",
        "and",
        "or",
        "not",
        "with",
        "from",
        "it",
        "its",
        "this",
        "that",
        "be",
        "has",
        "have",
        "had",
        "can",
        "will",
        "would",
        "should",
        "could",
        "may",
        "might",
        "shall",
        "status",
        "blocked",
        "blocks",
        "blocking",
        "blokuje",
    }
)


@dataclass
class ParsedQuestion:
    """Result of parsing a natural language question."""

    ticket_keys: list[str]
    keywords: list[str]


@dataclass
class SearchResult:
    """Aggregated result from lazy search across all connectors."""

    question: str
    ticket_keys: list[str]
    entities: list[Entity] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    slack_mentions: list[dict[str, object]] = field(default_factory=list)
    sources: dict[str, int] = field(default_factory=dict)
    llm_answer: str = ""


def parse_question(question: str) -> ParsedQuestion:
    """Extract ticket keys and keywords from a question string."""
    ticket_keys = _TICKET_KEY_RE.findall(question)

    # Extract keywords: remove ticket keys and stop words
    cleaned = _TICKET_KEY_RE.sub("", question)
    words = re.findall(r"[a-zA-Z0-9]+", cleaned)
    keywords = [w for w in words if w.lower() not in _STOP_WORDS and len(w) > 1]

    return ParsedQuestion(ticket_keys=ticket_keys, keywords=keywords)


class LazySearcher:
    """Orchestrates on-demand search across Jira, GitLab, and Slack."""

    def __init__(
        self,
        config: BlameGraphConfig,
        console: Console | None = None,
        llm_client: object | None = None,
    ) -> None:
        self._config = config
        self._console = console or Console()
        self._jira = JiraConnector(config.connectors.jira)
        self._gitlab = GitLabConnector(config.connectors.gitlab)
        self._slack = SlackConnector(config.connectors.slack)
        self._llm_client = llm_client

    async def search(self, question: str, model: str | None = None) -> SearchResult:
        """Run the full lazy search flow for a question."""
        result = SearchResult(question=question, ticket_keys=[])

        # Step 1: Parse question
        with self._console.status("[bold blue]Analyzing question...", spinner="dots"):
            parsed = parse_question(question)
            result.ticket_keys = parsed.ticket_keys

        if parsed.ticket_keys:
            self._console.print(
                f"  [dim]->[/dim] Found: {', '.join(parsed.ticket_keys)} (Jira ticket)"
            )
        if parsed.keywords:
            self._console.print(f"  [dim]->[/dim] Keywords: {', '.join(parsed.keywords)}")

        all_payloads: list[RawPayload] = []

        # Step 2: Search Jira
        jira_payloads = await self._search_jira(parsed)
        all_payloads.extend(jira_payloads)
        result.sources["jira"] = len(jira_payloads)

        # Step 3: Search GitLab
        gitlab_payloads = await self._search_gitlab(parsed)
        all_payloads.extend(gitlab_payloads)
        result.sources["gitlab"] = len(gitlab_payloads)

        # Step 4: Search Slack
        slack_payloads = await self._search_slack(parsed)
        all_payloads.extend(slack_payloads)
        result.sources["slack"] = len(slack_payloads)

        # Step 5: Normalize and infer
        with self._console.status("[bold blue]Analyzing dependencies...", spinner="dots"):
            entities, edges, slack_mentions = self._normalize_and_infer(all_payloads)
            result.entities = entities
            result.edges = edges
            result.slack_mentions = slack_mentions

        blocker_count = sum(1 for e in edges if e.edge_type == "blocks")
        self._console.print(f"  [dim]->[/dim] {blocker_count} blocker(s) identified")

        # Step 6: LLM Analysis (if client available)
        if self._llm_client and model:
            self._console.print()
            with self._console.status(f"[bold blue]Analyzing with {model}...", spinner="dots"):
                context = build_context(result, config=self._config)
                messages = [
                    {"role": "system", "content": ANSWER_SYSTEM_PROMPT},
                    {"role": "user", "content": f"Question: {question}\n\nContext:\n{context}"},
                ]
                try:
                    result.llm_answer = await self._llm_client.chat(messages, model=model)
                except Exception as exc:
                    logger.warning("LLM analysis failed: %s", exc)
                    result.llm_answer = f"[LLM error: {exc}]"

        return result

    async def _search_jira(self, parsed: ParsedQuestion) -> list[RawPayload]:
        """Search Jira by ticket key, linked issues, and text."""
        self._console.print()
        payloads: list[RawPayload] = []
        with self._console.status("[bold blue]Searching Jira...", spinner="dots"):
            try:
                for key in parsed.ticket_keys:
                    payloads.extend(await self._jira.search_by_key(key))
                    payloads.extend(await self._jira.search_linked(key))

                search_query = " ".join(parsed.ticket_keys + parsed.keywords)
                if search_query.strip():
                    text_results = await self._jira.search_text(search_query)
                    # Deduplicate by external_id
                    seen = {p.external_id for p in payloads}
                    for p in text_results:
                        if p.external_id not in seen:
                            payloads.append(p)
                            seen.add(p.external_id)
            except ConnectorError as exc:
                logger.warning("Jira search failed: %s", exc)

        if payloads:
            keys = [p.external_id for p in payloads[:5]]
            keys_str = ", ".join(keys)
            self._console.print(f"  [dim]->[/dim] {len(payloads)} issue(s) found: {keys_str}")
        else:
            self._console.print("  [dim]->[/dim] No Jira results")

        return payloads

    async def _search_gitlab(self, parsed: ParsedQuestion) -> list[RawPayload]:
        """Search GitLab MRs by keyword."""
        self._console.print()
        payloads: list[RawPayload] = []
        search_query = " ".join(parsed.ticket_keys + parsed.keywords)
        if not search_query.strip():
            return payloads

        with self._console.status("[bold blue]Searching GitLab...", spinner="dots"):
            try:
                payloads = await self._gitlab.search_mrs(search_query)
            except ConnectorError as exc:
                logger.warning("GitLab search failed: %s", exc)

        self._console.print(f"  [dim]->[/dim] {len(payloads)} related merge request(s) found")
        return payloads

    async def _search_slack(self, parsed: ParsedQuestion) -> list[RawPayload]:
        """Search Slack messages by keyword."""
        self._console.print()
        payloads: list[RawPayload] = []
        search_query = " ".join(parsed.ticket_keys + parsed.keywords)
        if not search_query.strip():
            return payloads

        with self._console.status("[bold blue]Searching Slack...", spinner="dots"):
            try:
                payloads = await self._slack.search_messages(search_query)
            except ConnectorError as exc:
                logger.warning("Slack search failed: %s", exc)

        self._console.print(f"  [dim]->[/dim] {len(payloads)} mention(s) found")
        return payloads

    def _normalize_and_infer(
        self, payloads: list[RawPayload]
    ) -> tuple[list[Entity], list[Edge], list[dict[str, object]]]:
        """Normalize payloads into entities/edges and run dependency inference."""
        entities: list[Entity] = []
        events = []
        slack_mentions: list[dict[str, object]] = []

        for p in payloads:
            if p.source == "jira":
                entity, evts, _artifacts = normalize_jira_issue(p)
                entities.append(entity)
                events.extend(evts)
            elif p.source == "gitlab_mr":
                entity, evts, _artifacts = normalize_gitlab_mr(p)
                entities.append(entity)
                events.extend(evts)
            elif p.source in ("slack", "slack_reply"):
                entity, evts, _artifacts = normalize_slack_message(p)
                entities.append(entity)
                events.extend(evts)
                slack_mentions.append(
                    {"channel": p.payload.get("_channel", ""), "text": p.payload.get("text", "")}
                )

        # Build team_config dict for inference
        team_config: dict[str, object] = {
            name: mapping.model_dump() for name, mapping in self._config.teams.items()
        }

        inferrer = DependencyInferrer()
        edges = inferrer.infer_edges(entities, events, team_config)

        return entities, edges, slack_mentions


def render_results(console: Console, result: SearchResult) -> None:
    """Render search results as a Rich panel with blockers table."""
    # Find blocker edges
    entity_map = {e.id: e for e in result.entities}
    blocker_edges = [e for e in result.edges if e.edge_type == "blocks"]

    if not blocker_edges and not result.entities:
        console.print(
            Panel(
                "No results found. Check your connector configuration.",
                title="Results",
                border_style="yellow",
            )
        )
        return

    lines: list[str] = []

    # Primary ticket info
    for key in result.ticket_keys:
        matching = [e for e in result.entities if e.external_id == key]
        if matching:
            ent = matching[0]
            status = ent.attributes.get("status", "")
            lines.append(f"[bold]{key}[/bold]: {ent.title}")
            if status:
                lines.append(f"  Status: {status}")

    if blocker_edges:
        lines.append("")
        lines.append(f"[bold]Blocked by ({len(blocker_edges)}):[/bold]")
        lines.append("")

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("#", style="dim", width=3)
        table.add_column("Ticket", style="cyan")
        table.add_column("Title")
        table.add_column("Status")
        table.add_column("Source", style="dim")

        for i, edge in enumerate(blocker_edges, 1):
            blocker = entity_map.get(edge.from_entity)
            if blocker:
                status = str(blocker.attributes.get("status", ""))
                source = edge.evidence[0].source_type if edge.evidence else ""
                table.add_row(
                    str(i),
                    blocker.external_id,
                    blocker.title,
                    status,
                    source,
                )

        console.print(
            Panel(
                "\n".join(lines),
                title="Results",
                border_style="green",
            )
        )
        console.print(table)
    else:
        if result.entities:
            lines.append("")
            count = len(result.entities)
            lines.append(f"[dim]{count} entities found, no blockers identified.[/dim]")
        console.print(
            Panel(
                "\n".join(lines),
                title="Results",
                border_style="green",
            )
        )

    # LLM Analysis
    if result.llm_answer:
        console.print()
        console.print(
            Panel(
                Markdown(result.llm_answer),
                title="LLM Analysis",
                border_style="cyan",
            )
        )

    # Sources summary
    source_parts = [f"{src.capitalize()} ({cnt})" for src, cnt in result.sources.items() if cnt > 0]
    if source_parts:
        console.print(f"\n[dim]Sources: {', '.join(source_parts)}[/dim]")


def result_to_json(result: SearchResult) -> dict[str, object]:
    """Convert search result to a JSON-serializable dict."""
    entity_map = {e.id: e for e in result.entities}
    blocker_edges = [e for e in result.edges if e.edge_type == "blocks"]

    blockers = []
    for edge in blocker_edges:
        blocker = entity_map.get(edge.from_entity)
        if blocker:
            blockers.append(
                {
                    "key": blocker.external_id,
                    "title": blocker.title,
                    "status": blocker.attributes.get("status", ""),
                    "source": edge.evidence[0].source_type if edge.evidence else "",
                }
            )

    out: dict[str, object] = {
        "question": result.question,
        "ticket_keys": result.ticket_keys,
        "blockers": blockers,
        "entity_count": len(result.entities),
        "edge_count": len(result.edges),
        "sources": result.sources,
    }
    if result.llm_answer:
        out["llm_answer"] = result.llm_answer
    return out
