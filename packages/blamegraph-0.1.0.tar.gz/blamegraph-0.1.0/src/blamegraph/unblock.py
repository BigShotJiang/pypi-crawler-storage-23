"""Auto-Unblock — LLM-powered suggestions for unblocking stalled tickets."""

from __future__ import annotations

from dataclasses import dataclass, field

from blamegraph.models import EdgeType, Entity
from blamegraph.storage.sqlite import SQLiteStorage


@dataclass
class UnblockSuggestion:
    """A single suggestion for unblocking a ticket."""
    blocker_entity_id: str
    blocker_external_id: str
    blocker_title: str
    suggestion: str
    action_command: str = ""
    confidence: float = 0.5


@dataclass
class UnblockAnalysis:
    """Complete unblock analysis for a ticket."""
    target_entity_id: str
    target_external_id: str
    target_title: str
    suggestions: list[UnblockSuggestion] = field(default_factory=list)
    ai_summary: str = ""


class UnblockEngine:
    """Analyze blockers and suggest concrete actions to unblock tickets."""

    def __init__(self, storage: SQLiteStorage) -> None:
        self._storage = storage

    def analyze(self, external_id: str) -> UnblockAnalysis:
        """Analyze a ticket's blockers and generate unblock suggestions."""
        entity = self._storage.get_entity_by_external_id(external_id)
        if entity is None:
            return UnblockAnalysis(
                target_entity_id="",
                target_external_id=external_id,
                target_title="(not found)",
            )

        analysis = UnblockAnalysis(
            target_entity_id=entity.id,
            target_external_id=entity.external_id,
            target_title=entity.title,
        )

        # Find all blockers
        blocking_edges = self._storage.get_edges_to(entity.id)
        blocker_edges = [e for e in blocking_edges if e.edge_type == EdgeType.BLOCKS]

        for edge in blocker_edges:
            blocker = self._storage.get_entity(edge.from_entity)
            if blocker is None:
                continue

            status = str(blocker.attributes.get("status", "")).lower()
            if status in ("done", "closed", "resolved"):
                continue

            suggestions = self._suggest_for_blocker(blocker)
            analysis.suggestions.extend(suggestions)

        return analysis

    def _suggest_for_blocker(self, blocker: Entity) -> list[UnblockSuggestion]:
        """Generate suggestions for a single blocker."""
        suggestions: list[UnblockSuggestion] = []

        status = str(blocker.attributes.get("status", "")).lower()
        assignee = blocker.attributes.get("assignee")

        # Suggestion 1: Assign if unassigned
        if not assignee:
            candidate = self._find_best_candidate(blocker)
            if candidate:
                suggestions.append(UnblockSuggestion(
                    blocker_entity_id=blocker.id,
                    blocker_external_id=blocker.external_id,
                    blocker_title=blocker.title,
                    suggestion=f"Assign to {candidate} — has relevant ownership signals",
                    action_command=f"bg draft --ticket {blocker.external_id} --assign {candidate}",
                    confidence=0.7,
                ))
            else:
                suggestions.append(UnblockSuggestion(
                    blocker_entity_id=blocker.id,
                    blocker_external_id=blocker.external_id,
                    blocker_title=blocker.title,
                    suggestion="No assignee — find an owner for this ticket",
                    action_command=f"bg draft --ticket {blocker.external_id}",
                    confidence=0.5,
                ))

        # Suggestion 2: Escalate if stale
        if status in ("open", "to do", "blocked", ""):
            days_stale = self._days_since_update(blocker)
            if days_stale >= 7:
                suggestions.append(UnblockSuggestion(
                    blocker_entity_id=blocker.id,
                    blocker_external_id=blocker.external_id,
                    blocker_title=blocker.title,
                    suggestion=f"Escalate — no progress for {days_stale} days",
                    action_command=f"bg draft --ticket {blocker.external_id} --escalate",
                    confidence=0.8,
                ))

        # Suggestion 3: Check for similar resolved tickets
        similar = self._find_similar_resolved(blocker)
        if similar:
            suggestions.append(UnblockSuggestion(
                blocker_entity_id=blocker.id,
                blocker_external_id=blocker.external_id,
                blocker_title=blocker.title,
                suggestion=(
                    f"Reference {similar.external_id} \"{similar.title}\" — "
                    f"similar ticket was resolved"
                ),
                action_command="",
                confidence=0.6,
            ))

        # Suggestion 4: If ticket blocks many, suggest splitting
        downstream_count = self._count_downstream(blocker)
        if downstream_count >= 2:
            suggestions.append(UnblockSuggestion(
                blocker_entity_id=blocker.id,
                blocker_external_id=blocker.external_id,
                blocker_title=blocker.title,
                suggestion=(
                    f"Consider splitting — blocks {downstream_count} tickets. "
                    f"A partial resolution may unblock some dependents."
                ),
                action_command="",
                confidence=0.5,
            ))

        return suggestions

    def _find_best_candidate(self, entity: Entity) -> str | None:
        """Find the best owner candidate from the owners table."""
        owners = self._storage.get_owners(entity.id)
        if owners:
            # Return top-scoring confirmed owner, or top overall
            confirmed = [o for o in owners if o.confirmed]
            if confirmed:
                return confirmed[0].candidate_owner
            return owners[0].candidate_owner
        return None

    def _days_since_update(self, entity: Entity) -> int:
        """Calculate days since last update."""
        from datetime import datetime

        delta = datetime.utcnow() - entity.updated_at
        return delta.days

    def _find_similar_resolved(self, entity: Entity) -> Entity | None:
        """Find a resolved ticket from the same project with similar title words."""
        prefix = entity.external_id.split("-")[0] if "-" in entity.external_id else ""
        if not prefix:
            return None

        all_entities = self._storage.list_entities(entity_type="ticket")
        title_words = set(entity.title.lower().split())

        best: Entity | None = None
        best_overlap = 0

        for other in all_entities:
            if other.id == entity.id:
                continue
            status = str(other.attributes.get("status", "")).lower()
            if status not in ("done", "closed", "resolved"):
                continue
            if not other.external_id.startswith(prefix + "-"):
                continue

            other_words = set(other.title.lower().split())
            overlap = len(title_words & other_words)
            if overlap > best_overlap and overlap >= 2:
                best_overlap = overlap
                best = other

        return best

    def _count_downstream(self, entity: Entity) -> int:
        """Count how many tickets this entity blocks."""
        edges = self._storage.get_edges_from(entity.id)
        return sum(1 for e in edges if e.edge_type == EdgeType.BLOCKS)


def build_unblock_context(analysis: UnblockAnalysis) -> str:
    """Build LLM context from unblock analysis for AI summary generation."""
    lines: list[str] = []
    lines.append(f"Target: {analysis.target_external_id} \"{analysis.target_title}\"")
    lines.append(f"Blockers: {len(analysis.suggestions)} suggestions")
    lines.append("")

    for i, s in enumerate(analysis.suggestions, 1):
        lines.append(f"Blocker {i}: {s.blocker_external_id} \"{s.blocker_title}\"")
        lines.append(f"  Suggestion: {s.suggestion}")
        if s.action_command:
            lines.append(f"  Action: {s.action_command}")
        lines.append("")

    return "\n".join(lines)
