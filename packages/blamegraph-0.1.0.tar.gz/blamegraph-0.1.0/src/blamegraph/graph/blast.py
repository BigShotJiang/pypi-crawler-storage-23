"""Blast Radius Analysis — forward dependency impact assessment."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from blamegraph.models import Edge, EdgeType, Entity
from blamegraph.storage.sqlite import SQLiteStorage


@dataclass
class BlastNode:
    """A single node in the blast radius."""
    entity_id: str
    external_id: str
    title: str
    team: str = ""
    sprint: str = ""
    depth: int = 0  # 0=root, 1=direct dependent, 2+=transitive
    priority: str = ""


@dataclass
class BlastResult:
    """Complete blast radius analysis result."""
    root_entity_id: str
    root_external_id: str
    root_title: str
    direct: list[BlastNode] = field(default_factory=list)
    transitive: list[BlastNode] = field(default_factory=list)
    blast_score: float = 0.0
    teams_affected: list[str] = field(default_factory=list)
    ai_summary: str = ""

    @property
    def total_affected(self) -> int:
        return len(self.direct) + len(self.transitive)


# Priority weights for blast score computation
_PRIORITY_WEIGHTS: dict[str, float] = {
    "critical": 4.0,
    "high": 3.0,
    "medium": 2.0,
    "low": 1.0,
}


def compute_blast_radius(
    entity_id: str,
    storage: SQLiteStorage,
) -> BlastResult:
    """Compute the blast radius for a given entity by traversing forward.

    "Forward" means: find all entities that DEPEND ON or are BLOCKED BY this entity.
    We look at edges where this entity is the from_entity with BLOCKS type,
    meaning other entities are blocked by (depend on) this one.
    """
    root = storage.get_entity(entity_id)
    if root is None:
        return BlastResult(
            root_entity_id=entity_id,
            root_external_id=entity_id,
            root_title="(not found)",
        )

    result = BlastResult(
        root_entity_id=root.id,
        root_external_id=root.external_id,
        root_title=root.title,
    )

    # BFS forward traversal — find everything downstream
    visited: set[str] = {entity_id}
    queue: deque[tuple[str, int]] = deque()  # (entity_id, depth)

    # Seed with direct dependents (things this entity blocks)
    for edge in storage.get_edges_from(entity_id):
        if edge.edge_type in (EdgeType.BLOCKS, EdgeType.IMPACTS):
            if edge.to_entity not in visited:
                visited.add(edge.to_entity)
                queue.append((edge.to_entity, 1))

    # Also check reverse: entities that have DEPENDS_ON pointing to us
    for edge in storage.get_edges_to(entity_id):
        if edge.edge_type == EdgeType.DEPENDS_ON:
            if edge.from_entity not in visited:
                visited.add(edge.from_entity)
                queue.append((edge.from_entity, 1))

    while queue:
        current_id, depth = queue.popleft()
        entity = storage.get_entity(current_id)
        if entity is None:
            continue

        node = _make_blast_node(entity, depth)

        if depth == 1:
            result.direct.append(node)
        else:
            result.transitive.append(node)

        # Continue traversal: find what this entity blocks
        for edge in storage.get_edges_from(current_id):
            if edge.edge_type in (EdgeType.BLOCKS, EdgeType.IMPACTS):
                if edge.to_entity not in visited:
                    visited.add(edge.to_entity)
                    queue.append((edge.to_entity, depth + 1))

        for edge in storage.get_edges_to(current_id):
            if edge.edge_type == EdgeType.DEPENDS_ON:
                if edge.from_entity not in visited:
                    visited.add(edge.from_entity)
                    queue.append((edge.from_entity, depth + 1))

    # Compute blast score and affected teams
    result.blast_score = _compute_score(result.direct + result.transitive)
    result.teams_affected = _extract_teams(result.direct + result.transitive)

    return result


def _make_blast_node(entity: Entity, depth: int) -> BlastNode:
    """Create a BlastNode from an Entity."""
    attrs = entity.attributes
    team = ""
    components = attrs.get("components", [])
    if isinstance(components, list) and components:
        team = str(components[0])
    labels = attrs.get("labels", [])
    if not team and isinstance(labels, list):
        for label in labels:
            label_str = str(label).lower()
            if label_str.startswith("team-") or label_str.startswith("team:"):
                team = str(label)
                break

    # Derive team from project key prefix if not found
    if not team and "-" in entity.external_id:
        team = entity.external_id.split("-")[0]

    sprint = str(attrs.get("sprint", ""))
    priority = str(attrs.get("priority", "medium")).lower()

    return BlastNode(
        entity_id=entity.id,
        external_id=entity.external_id,
        title=entity.title,
        team=team,
        sprint=sprint,
        depth=depth,
        priority=priority,
    )


def _compute_score(nodes: list[BlastNode]) -> float:
    """Blast score = sum(priority_weight) for all affected nodes."""
    return sum(_PRIORITY_WEIGHTS.get(n.priority, 1.0) for n in nodes)


def _extract_teams(nodes: list[BlastNode]) -> list[str]:
    """Extract unique teams from blast nodes, preserving order."""
    seen: set[str] = set()
    teams: list[str] = []
    for node in nodes:
        if node.team and node.team not in seen:
            seen.add(node.team)
            teams.append(node.team)
    return teams
