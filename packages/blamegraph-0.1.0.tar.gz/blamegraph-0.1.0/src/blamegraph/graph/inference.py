"""Deterministic dependency inference rules for BlameGraph."""

from __future__ import annotations

import re
import uuid

from blamegraph.models import Edge, EdgeType, Entity, Event, Evidence, InferenceMethod

# Matches Jira-style ticket keys like PROJ-123, MOB-881, etc.
_TICKET_KEY_RE = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")


class DependencyInferrer:
    """Infer dependency edges from entities and events using deterministic rules."""

    def infer_edges(
        self,
        entities: list[Entity],
        events: list[Event],
        team_config: dict[str, object],
    ) -> list[Edge]:
        """Run all inference rules and return discovered edges.

        Rules (in priority order):
        1. Explicit Jira link (issuelinks with type blocks/is blocked by)
        2. Status Blocked + ticket key regex in description/comments
        3. Cross-team PR reference
        """
        edges: list[Edge] = []
        entity_map = {e.id: e for e in entities}

        edges.extend(self._rule_explicit_links(entities))
        edges.extend(self._rule_blocked_status(entities, events, entity_map))
        edges.extend(self._rule_cross_team_pr(entities, team_config, entity_map))

        return edges

    def _rule_explicit_links(self, entities: list[Entity]) -> list[Edge]:
        """Rule 1: Explicit Jira issuelinks with blocks/is-blocked-by type."""
        edges: list[Edge] = []
        entity_by_ext = {e.external_id: e for e in entities}

        for entity in entities:
            issue_links = entity.attributes.get("issuelinks", [])
            if not isinstance(issue_links, list):
                continue
            for link in issue_links:
                if not isinstance(link, dict):
                    continue
                link_type = str(link.get("type", "")).lower()
                target_key = str(link.get("target", ""))

                if link_type == "blocks" and target_key:
                    to_entity = entity_by_ext.get(target_key)
                    if to_entity:
                        edges.append(
                            Edge(
                                id=str(uuid.uuid4()),
                                from_entity=entity.id,
                                to_entity=to_entity.id,
                                edge_type=EdgeType.BLOCKS,
                                confidence=1.0,
                                method=InferenceMethod.EXPLICIT,
                                evidence=[
                                    Evidence(
                                        source_type="jira_issuelink",
                                        source_id=entity.external_id,
                                        snippet=f"{entity.external_id} blocks {target_key}",
                                    )
                                ],
                            )
                        )
                elif link_type == "is blocked by" and target_key:
                    from_entity = entity_by_ext.get(target_key)
                    if from_entity:
                        edges.append(
                            Edge(
                                id=str(uuid.uuid4()),
                                from_entity=from_entity.id,
                                to_entity=entity.id,
                                edge_type=EdgeType.BLOCKS,
                                confidence=1.0,
                                method=InferenceMethod.EXPLICIT,
                                evidence=[
                                    Evidence(
                                        source_type="jira_issuelink",
                                        source_id=entity.external_id,
                                        snippet=f"{entity.external_id} is blocked by {target_key}",
                                    )
                                ],
                            )
                        )
        return edges

    def _rule_blocked_status(
        self,
        entities: list[Entity],
        events: list[Event],
        entity_map: dict[str, Entity],
    ) -> list[Edge]:
        """Rule 2: Status Blocked + ticket key regex in description/comments."""
        edges: list[Edge] = []
        entity_by_ext = {e.external_id: e for e in entities}

        for entity in entities:
            status = str(entity.attributes.get("status", "")).lower()
            if status != "blocked":
                continue

            # Gather text from description and comment events
            texts: list[str] = []
            description = entity.attributes.get("description")
            if isinstance(description, str):
                texts.append(description)

            for event in events:
                if event.entity_id == entity.id and event.kind == "comment":
                    body = event.payload.get("body", "")
                    if isinstance(body, str):
                        texts.append(body)

            combined_text = " ".join(texts)
            referenced_keys = set(_TICKET_KEY_RE.findall(combined_text))
            # Remove self-references
            referenced_keys.discard(entity.external_id)

            for key in referenced_keys:
                target = entity_by_ext.get(key)
                if target:
                    edges.append(
                        Edge(
                            id=str(uuid.uuid4()),
                            from_entity=target.id,
                            to_entity=entity.id,
                            edge_type=EdgeType.BLOCKS,
                            confidence=0.7,
                            method=InferenceMethod.HEURISTIC,
                            evidence=[
                                Evidence(
                                    source_type="status_regex",
                                    source_id=entity.external_id,
                                    snippet=f"{entity.external_id} (Blocked) references {key}",
                                )
                            ],
                        )
                    )
        return edges

    def _rule_cross_team_pr(
        self,
        entities: list[Entity],
        team_config: dict[str, object],
        entity_map: dict[str, Entity],
    ) -> list[Edge]:
        """Rule 3: Cross-team PR reference (PR mentions ticket from another team)."""
        edges: list[Edge] = []
        entity_by_ext = {e.external_id: e for e in entities}

        # Build project-key -> team mapping from team_config
        project_team: dict[str, str] = {}
        for team_name, mapping in team_config.items():
            if isinstance(mapping, dict):
                for comp in mapping.get("jira_components", []):
                    if isinstance(comp, str):
                        project_team[comp] = team_name
                for repo in mapping.get("repos", []):
                    if isinstance(repo, str):
                        project_team[repo] = team_name

        pr_entities = [e for e in entities if e.entity_type.value == "pr"]

        for pr in pr_entities:
            pr_repo = str(pr.attributes.get("repo", ""))
            pr_team = project_team.get(pr_repo)

            pr_text_parts: list[str] = [pr.title]
            pr_desc = pr.attributes.get("description")
            if isinstance(pr_desc, str):
                pr_text_parts.append(pr_desc)

            combined = " ".join(pr_text_parts)
            referenced_keys = set(_TICKET_KEY_RE.findall(combined))

            for key in referenced_keys:
                target = entity_by_ext.get(key)
                if not target:
                    continue

                # Determine ticket's team via project prefix
                ticket_project = key.split("-")[0] if "-" in key else ""
                ticket_team = project_team.get(ticket_project)

                if pr_team and ticket_team and pr_team != ticket_team:
                    edges.append(
                        Edge(
                            id=str(uuid.uuid4()),
                            from_entity=pr.id,
                            to_entity=target.id,
                            edge_type=EdgeType.IMPACTS,
                            confidence=0.6,
                            method=InferenceMethod.HEURISTIC,
                            evidence=[
                                Evidence(
                                    source_type="cross_team_pr",
                                    source_id=pr.external_id,
                                    snippet=(
                                        f"PR {pr.external_id} ({pr_team})"
                                        f" references {key} ({ticket_team})"
                                    ),
                                )
                            ],
                        )
                    )
        return edges
