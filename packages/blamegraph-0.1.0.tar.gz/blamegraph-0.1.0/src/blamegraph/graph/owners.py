"""Owner inference for BlameGraph entities."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from blamegraph.models import Entity, Evidence, Owner

_MENTION_RE = re.compile(r"@([\w.-]+)")


@dataclass
class OwnerContext:
    """Contextual data for owner inference."""

    # team_config: team_name -> {"repos": [...], "jira_components": [...]}
    team_config: dict[str, dict[str, list[str]]] = field(default_factory=dict)
    # CODEOWNERS entries: file_pattern -> owner (team or person)
    codeowners: dict[str, str] = field(default_factory=dict)
    # Files changed in linked PRs
    changed_files: list[str] = field(default_factory=list)
    # Historical merge/comment authors
    historical_authors: list[str] = field(default_factory=list)
    # Text artifacts (descriptions, comments) for mention extraction
    text_artifacts: list[str] = field(default_factory=list)
    # Repo name for the entity's linked PRs
    repo: str = ""


class OwnerInferrer:
    """Infer entity ownership using ranked signals."""

    def infer_owners(self, entity: Entity, context: OwnerContext) -> list[Owner]:
        """Infer owners for an entity using 5 ranked signals.

        Signals (highest to lowest):
        1. Explicit field: ticket assignee/component -> team mapping (1.0)
        2. CODEOWNERS: file ownership from linked PRs (0.9)
        3. Historical: who merged PRs / commented on similar tickets (0.7)
        4. Mentioned: @mentions in ticket/chat (0.5)
        5. Repo-team fallback: repo -> team mapping from config (0.3)
        """
        candidates: dict[str, Owner] = {}

        self._signal_explicit(entity, context, candidates)
        self._signal_codeowners(entity, context, candidates)
        self._signal_historical(entity, context, candidates)
        self._signal_mentioned(entity, context, candidates)
        self._signal_repo_fallback(entity, context, candidates)

        result = sorted(candidates.values(), key=lambda o: o.score, reverse=True)
        return result

    def _signal_explicit(
        self,
        entity: Entity,
        context: OwnerContext,
        candidates: dict[str, Owner],
    ) -> None:
        """Signal 1: Explicit ticket assignee or component -> team mapping."""
        assignee = entity.attributes.get("assignee")
        if isinstance(assignee, str) and assignee:
            self._add_candidate(
                candidates,
                entity_id=entity.id,
                owner=assignee,
                score=1.0,
                signal="explicit_assignee",
                snippet=f"Assigned to {assignee}",
            )

        component = entity.attributes.get("component")
        if isinstance(component, str) and component:
            for team_name, mapping in context.team_config.items():
                if component in mapping.get("jira_components", []):
                    self._add_candidate(
                        candidates,
                        entity_id=entity.id,
                        owner=team_name,
                        score=1.0,
                        signal="explicit_component",
                        snippet=f"Component {component} maps to {team_name}",
                    )

    def _signal_codeowners(
        self,
        entity: Entity,
        context: OwnerContext,
        candidates: dict[str, Owner],
    ) -> None:
        """Signal 2: CODEOWNERS file ownership from linked PRs."""
        for changed_file in context.changed_files:
            for pattern, owner in context.codeowners.items():
                if _file_matches_pattern(changed_file, pattern):
                    self._add_candidate(
                        candidates,
                        entity_id=entity.id,
                        owner=owner,
                        score=0.9,
                        signal="codeowners",
                        snippet=f"{changed_file} owned by {owner} (pattern: {pattern})",
                    )

    def _signal_historical(
        self,
        entity: Entity,
        context: OwnerContext,
        candidates: dict[str, Owner],
    ) -> None:
        """Signal 3: Historical merge/comment authors."""
        for author in context.historical_authors:
            self._add_candidate(
                candidates,
                entity_id=entity.id,
                owner=author,
                score=0.7,
                signal="historical",
                snippet=f"{author} has historical activity on similar tickets",
            )

    def _signal_mentioned(
        self,
        entity: Entity,
        context: OwnerContext,
        candidates: dict[str, Owner],
    ) -> None:
        """Signal 4: @mentions in ticket/chat text."""
        for text in context.text_artifacts:
            mentions = _MENTION_RE.findall(text)
            for mention in mentions:
                self._add_candidate(
                    candidates,
                    entity_id=entity.id,
                    owner=mention,
                    score=0.5,
                    signal="mentioned",
                    snippet=f"@{mention} mentioned in text",
                )

    def _signal_repo_fallback(
        self,
        entity: Entity,
        context: OwnerContext,
        candidates: dict[str, Owner],
    ) -> None:
        """Signal 5: Repo -> team mapping fallback."""
        if not context.repo:
            return
        for team_name, mapping in context.team_config.items():
            if context.repo in mapping.get("repos", []):
                self._add_candidate(
                    candidates,
                    entity_id=entity.id,
                    owner=team_name,
                    score=0.3,
                    signal="repo_fallback",
                    snippet=f"Repo {context.repo} maps to {team_name}",
                )

    @staticmethod
    def _add_candidate(
        candidates: dict[str, Owner],
        *,
        entity_id: str,
        owner: str,
        score: float,
        signal: str,
        snippet: str,
    ) -> None:
        """Add or update a candidate, keeping the highest score."""
        existing = candidates.get(owner)
        if existing is None or score > existing.score:
            candidates[owner] = Owner(
                entity_id=entity_id,
                candidate_owner=owner,
                score=score,
                signal=signal,
                evidence=[
                    Evidence(
                        source_type=signal,
                        source_id=entity_id,
                        snippet=snippet,
                    )
                ],
            )


def _file_matches_pattern(filepath: str, pattern: str) -> bool:
    """Simple glob-like matching for CODEOWNERS patterns."""
    if pattern.endswith("/*"):
        directory = pattern[:-2]
        return filepath.startswith(directory + "/") or filepath == directory
    if pattern.startswith("*."):
        ext = pattern[1:]  # e.g. ".py"
        return filepath.endswith(ext)
    return filepath == pattern or filepath.startswith(pattern + "/")
