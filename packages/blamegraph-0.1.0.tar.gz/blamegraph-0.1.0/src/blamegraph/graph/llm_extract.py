"""LLM-assisted dependency extraction for BlameGraph."""

from __future__ import annotations

import json
import re
import uuid

from blamegraph.llm.client import LLMClientProtocol
from blamegraph.llm.prompts import EXTRACT_SYSTEM_PROMPT
from blamegraph.models import Edge, EdgeType, Evidence, InferenceMethod

# Matches concrete artifacts: Jira keys, repo-like names, API names
_TICKET_KEY_RE = re.compile(r"\b[A-Z][A-Z0-9]+-\d+\b")
_REPO_RE = re.compile(r"\b[\w.-]+/[\w.-]+\b")
_API_RE = re.compile(r"\b\w+[-_](?:api|service|svc)\b", re.IGNORECASE)

_USER_PROMPT_TEMPLATE = """\
Given a ticket (summary, description, recent comments), \
extract candidate dependencies and blockers.

## Output JSON schema
{{
  "dependencies": [
    {{
      "type": "depends_on" | "blocked_by" | "impacts" | "related_to",
      "target_hint": "ticket key or repo or API name",
      "confidence": 0.0,
      "evidence_snippet": "short quote <= 200 chars",
      "reason": "why this is a dependency"
    }}
  ]
}}

## Rules
- Only include items supported by explicit text.
- Prefer concrete references (ticket keys like ABC-123).
- If none, return empty list.

## Ticket text
{ticket_text}"""

_EDGE_TYPE_MAP: dict[str, EdgeType] = {
    "depends_on": EdgeType.DEPENDS_ON,
    "blocked_by": EdgeType.BLOCKS,
    "impacts": EdgeType.IMPACTS,
    "related_to": EdgeType.RELATED_TO,
}


class LLMDependencyExtractor:
    """Extract dependency edges from ticket text using an LLM."""

    def __init__(self, llm_client: LLMClientProtocol) -> None:
        self._client = llm_client

    async def extract(
        self,
        entity_id: str,
        ticket_text: str,
    ) -> list[Edge]:
        """Extract candidate dependency edges from ticket text.

        Sends redacted text to LLM, parses JSON response, and gates
        results to only accept references to concrete artifacts.
        """
        if not ticket_text.strip():
            return []

        user_prompt = _USER_PROMPT_TEMPLATE.format(ticket_text=ticket_text)
        messages = [
            {"role": "system", "content": EXTRACT_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ]
        raw_response = await self._client.chat(messages)

        return self._parse_response(entity_id, raw_response)

    def _parse_response(self, entity_id: str, raw: str) -> list[Edge]:
        """Parse LLM JSON response into gated Edge objects."""
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            return []

        if not isinstance(data, dict):
            return []

        deps = data.get("dependencies", [])
        if not isinstance(deps, list):
            return []

        edges: list[Edge] = []
        for dep in deps:
            if not isinstance(dep, dict):
                continue

            target_hint = str(dep.get("target_hint", ""))
            if not _is_concrete_artifact(target_hint):
                continue

            dep_type = str(dep.get("type", "related_to"))
            edge_type = _EDGE_TYPE_MAP.get(dep_type, EdgeType.RELATED_TO)

            confidence = dep.get("confidence", 0.5)
            if not isinstance(confidence, (int, float)):
                confidence = 0.5
            confidence = max(0.0, min(1.0, float(confidence)))

            snippet = str(dep.get("evidence_snippet", ""))[:200]
            reason = str(dep.get("reason", ""))

            edges.append(
                Edge(
                    id=str(uuid.uuid4()),
                    from_entity=entity_id,
                    to_entity=target_hint,
                    edge_type=edge_type,
                    confidence=confidence,
                    method=InferenceMethod.LLM_EXTRACT,
                    evidence=[
                        Evidence(
                            source_type="llm_extract",
                            source_id=entity_id,
                            snippet=snippet or reason,
                        )
                    ],
                )
            )

        return edges


def _is_concrete_artifact(hint: str) -> bool:
    """Gate: only accept if target_hint references a concrete artifact."""
    if not hint:
        return False
    if _TICKET_KEY_RE.search(hint):
        return True
    if _REPO_RE.search(hint):
        return True
    return bool(_API_RE.search(hint))
