"""Graph traversal utilities for BlameGraph."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

from blamegraph.models import Edge


@dataclass
class DependencyChain:
    """A dependency path represented as a list of (entity_id, edge) pairs."""

    steps: list[tuple[str, Edge | None]] = field(default_factory=list)

    @property
    def entity_ids(self) -> list[str]:
        return [entity_id for entity_id, _ in self.steps]

    @property
    def length(self) -> int:
        return len(self.steps)


# Type alias for the edge-lookup callback
GetEdgesFn = Callable[[str], list[Edge]]


def bfs(start_id: str, get_edges_fn: GetEdgesFn) -> list[str]:
    """Breadth-first traversal from start_id, returning visited entity IDs in order."""
    visited: list[str] = []
    seen: set[str] = {start_id}
    queue: deque[str] = deque([start_id])

    while queue:
        current = queue.popleft()
        visited.append(current)

        for edge in get_edges_fn(current):
            neighbor = edge.to_entity
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)

    return visited


def dfs(start_id: str, get_edges_fn: GetEdgesFn) -> list[str]:
    """Depth-first traversal from start_id, returning visited entity IDs in order."""
    visited: list[str] = []
    seen: set[str] = set()

    def _visit(node: str) -> None:
        if node in seen:
            return
        seen.add(node)
        visited.append(node)
        for edge in get_edges_fn(node):
            _visit(edge.to_entity)

    _visit(start_id)
    return visited


def find_chains(start_id: str, get_edges_fn: GetEdgesFn) -> list[DependencyChain]:
    """Find all dependency paths from start_id to leaf nodes (no outgoing edges)."""
    chains: list[DependencyChain] = []

    def _walk(node: str, path: list[tuple[str, Edge | None]], visited: set[str]) -> None:
        edges = get_edges_fn(node)
        # Filter out edges that would create a cycle
        forward_edges = [e for e in edges if e.to_entity not in visited]

        if not forward_edges:
            # Leaf node -- record the chain
            chains.append(DependencyChain(steps=list(path)))
            return

        for edge in forward_edges:
            next_node = edge.to_entity
            new_visited = visited | {next_node}
            _walk(next_node, [*path, (next_node, edge)], new_visited)

    _walk(start_id, [(start_id, None)], {start_id})
    return chains


def detect_cycles(get_edges_fn: GetEdgesFn, entity_ids: list[str]) -> list[list[str]]:
    """Detect circular dependencies among the given entity IDs.

    Returns a list of cycles, each represented as a list of entity IDs
    forming the cycle (first and last element are the same).
    """
    cycles: list[list[str]] = []
    all_ids = set(entity_ids)

    # Color-based DFS: WHITE=unvisited, GRAY=in-stack, BLACK=done
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {eid: WHITE for eid in entity_ids}
    path: list[str] = []
    seen_cycles: set[tuple[str, ...]] = set()

    def _dfs(node: str) -> None:
        color[node] = GRAY
        path.append(node)

        for edge in get_edges_fn(node):
            neighbor = edge.to_entity
            if neighbor not in all_ids:
                continue
            if color.get(neighbor, BLACK) == GRAY:
                # Found a cycle -- extract it
                cycle_start = path.index(neighbor)
                cycle = [*path[cycle_start:], neighbor]
                # Normalize to avoid duplicates
                _record_cycle(cycle, seen_cycles, cycles)
            elif color.get(neighbor, BLACK) == WHITE:
                _dfs(neighbor)

        path.pop()
        color[node] = BLACK

    for eid in entity_ids:
        if color[eid] == WHITE:
            _dfs(eid)

    return cycles


def _record_cycle(
    cycle: list[str],
    seen: set[tuple[str, ...]],
    cycles: list[list[str]],
) -> None:
    """Record a cycle if not already seen (normalized by rotation)."""
    # Normalize: rotate so smallest element is first
    body = cycle[:-1]  # remove duplicate end
    if not body:
        return
    min_idx = body.index(min(body))
    normalized = tuple(body[min_idx:] + body[:min_idx])
    if normalized not in seen:
        seen.add(normalized)
        cycles.append([*list(normalized), normalized[0]])
