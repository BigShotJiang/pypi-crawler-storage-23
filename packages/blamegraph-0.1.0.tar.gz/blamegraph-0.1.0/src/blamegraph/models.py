"""Core domain models for BlameGraph."""

from __future__ import annotations

import enum
from datetime import datetime

from pydantic import BaseModel, Field


class EntityType(enum.StrEnum):
    TICKET = "ticket"
    PR = "pr"
    REPO = "repo"
    SERVICE = "service"
    TEAM = "team"
    PERSON = "person"


class EdgeType(enum.StrEnum):
    BLOCKS = "blocks"
    DEPENDS_ON = "depends_on"
    RELATED_TO = "related_to"
    IMPACTS = "impacts"
    OWNED_BY = "owned_by"


class InferenceMethod(enum.StrEnum):
    EXPLICIT = "explicit"
    HEURISTIC = "heuristic"
    EMBEDDING = "embedding"
    LLM_EXTRACT = "llm_extract"


class RiskLevel(enum.StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @classmethod
    def from_score(cls, score: float) -> RiskLevel:
        if score < 30:
            return cls.LOW
        if score < 60:
            return cls.MEDIUM
        if score < 80:
            return cls.HIGH
        return cls.CRITICAL


class Evidence(BaseModel):
    source_type: str
    source_id: str
    url: str = ""
    snippet: str = ""
    ts: datetime | None = None


class Entity(BaseModel):
    id: str
    entity_type: EntityType
    external_id: str
    title: str = ""
    attributes: dict[str, object] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Edge(BaseModel):
    id: str = ""
    from_entity: str
    to_entity: str
    edge_type: EdgeType
    confidence: float = Field(ge=0.0, le=1.0)
    method: InferenceMethod = InferenceMethod.EXPLICIT
    evidence: list[Evidence] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class RiskScore(BaseModel):
    entity_id: str
    score: float = Field(ge=0.0, le=100.0)
    level: RiskLevel = RiskLevel.LOW
    features: dict[str, float] = Field(default_factory=dict)
    why: list[str] = Field(default_factory=list)
    suggested_action: str = ""
    ts: datetime = Field(default_factory=datetime.utcnow)


class Owner(BaseModel):
    entity_id: str
    candidate_owner: str
    score: float = Field(ge=0.0, le=1.0)
    signal: str = ""
    evidence: list[Evidence] = Field(default_factory=list)
    confirmed: bool = False


class RawPayload(BaseModel):
    source: str
    external_id: str
    payload: dict[str, object] = Field(default_factory=dict)
    fetched_at: datetime = Field(default_factory=datetime.utcnow)


class Event(BaseModel):
    entity_id: str
    ts: datetime
    kind: str
    payload: dict[str, object] = Field(default_factory=dict)


class TextArtifact(BaseModel):
    entity_id: str
    artifact_type: str  # title, description, comment, message
    text: str
    metadata: dict[str, object] = Field(default_factory=dict)


class GraphSnapshot(BaseModel):
    """Point-in-time snapshot of the dependency graph for trend analysis."""

    id: str
    ts: datetime = Field(default_factory=datetime.utcnow)
    entity_count: int = 0
    edge_count: int = 0
    blocker_count: int = 0
    snapshot_data: dict[str, object] = Field(default_factory=dict)
