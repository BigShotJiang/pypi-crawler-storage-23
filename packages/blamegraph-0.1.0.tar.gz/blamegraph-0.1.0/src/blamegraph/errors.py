"""BlameGraph error hierarchy."""


class BlameGraphError(Exception):
    """Base error for all BlameGraph exceptions."""

    exit_code: int = 1

    def __init__(self, message: str, *, detail: str = "") -> None:
        self.detail = detail
        super().__init__(message)


class ConfigError(BlameGraphError):
    """Configuration loading or validation error."""

    exit_code = 2


class ConnectorError(BlameGraphError):
    """Error communicating with an external data source."""

    exit_code = 3


class StorageError(BlameGraphError):
    """Database or persistence error."""

    exit_code = 4


class LLMError(BlameGraphError):
    """LLM provider communication or response parsing error."""

    exit_code = 5
