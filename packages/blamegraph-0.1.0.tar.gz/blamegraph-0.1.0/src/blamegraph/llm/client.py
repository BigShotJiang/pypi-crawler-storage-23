"""Unified LLM client protocol, AnthropicLLMClient, and factory."""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncIterator
from typing import Protocol

from blamegraph.config import BlameGraphConfig
from blamegraph.credentials import load_token
from blamegraph.llm.anthropic import AnthropicClient, ChatMessage
from blamegraph.llm.audit import AuditLogger
from blamegraph.llm.redactor import Redactor

logger = logging.getLogger(__name__)


class LLMClientProtocol(Protocol):
    """Unified LLM interface for all consumers."""

    async def chat(self, messages: list[dict[str, str]]) -> str: ...


class AnthropicLLMClient:
    """Real LLM implementation using AnthropicClient."""

    def __init__(self, config: BlameGraphConfig) -> None:
        api_key = self._get_token(config)
        self._client = AnthropicClient(
            api_key=api_key,
            base_url=config.llm.api_base,
        )
        self._redactor = Redactor(config)
        self._audit = AuditLogger()
        self._max_context_chars = config.llm.max_context_chars

    @staticmethod
    def _get_token(config: BlameGraphConfig) -> str:
        """Load API key from credential file or env var."""
        # Credentials file (set via `blamegraph config set-token anthropic`) takes priority
        token = load_token("anthropic")
        if token:
            return token
        token = os.environ.get(config.llm.token_env)
        if token:
            return token
        raise ValueError(
            f"No Anthropic API key found. Set {config.llm.token_env} env var "
            "or run: blamegraph config set-token anthropic"
        )

    async def chat(self, messages: list[dict[str, str]], model: str = "") -> str:
        """Send a chat request and return the response content."""
        chat_messages = [ChatMessage(role=m["role"], content=m["content"]) for m in messages]

        if not model:
            raise ValueError("Model must be specified for AnthropicLLMClient.chat()")

        response = await self._client.chat(chat_messages, model=model)

        self._audit.log_call(
            template_id="chat",
            model=response.model,
            input_text=messages[-1].get("content", ""),
            output_text=response.content,
            token_count=response.usage.get("total_tokens", 0),
        )

        return response.content

    async def stream_chat(
        self, messages: list[dict[str, str]], model: str = ""
    ) -> AsyncIterator[str]:
        """Stream a chat completion, yielding content chunks."""
        chat_messages = [ChatMessage(role=m["role"], content=m["content"]) for m in messages]

        if not model:
            raise ValueError("Model must be specified for AnthropicLLMClient.stream_chat()")

        async for chunk in self._client.stream_chat(chat_messages, model=model):
            yield chunk

    async def list_models(self) -> list[dict[str, str]]:
        """Return available Anthropic models."""
        return await self._client.list_models()

    async def close(self) -> None:
        await self._client.close()


class StubLLMClient:
    """Returns placeholder responses when no LLM is configured."""

    def __init__(self, config: BlameGraphConfig | None = None) -> None:
        self._max_context_chars = config.llm.max_context_chars if config else 12000

    async def chat(self, messages: list[dict[str, str]], model: str = "") -> str:
        question = messages[-1].get("content", "") if messages else ""
        return f"[Stub] No LLM configured. Question: {question}"


def create_llm_client(config: BlameGraphConfig) -> AnthropicLLMClient | None:
    """Factory: returns AnthropicLLMClient if API key is available, else None."""
    try:
        return AnthropicLLMClient(config)
    except ValueError:
        logger.debug("No Anthropic API key available, LLM features disabled")
        return None
