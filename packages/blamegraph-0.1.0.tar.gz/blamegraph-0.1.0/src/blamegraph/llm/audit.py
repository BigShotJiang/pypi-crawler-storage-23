"""Audit logger for LLM calls — writes JSONL to ~/.blamegraph/logs/llm_audit.jsonl."""

from __future__ import annotations

import getpass
import json
from datetime import UTC, datetime
from pathlib import Path

_DEFAULT_LOG_DIR = Path.home() / ".blamegraph" / "logs"
_DEFAULT_LOG_FILE = "llm_audit.jsonl"


class AuditLogger:
    """Append-only JSONL logger for LLM usage auditing."""

    def __init__(self, log_dir: Path | None = None) -> None:
        self._log_dir = log_dir or _DEFAULT_LOG_DIR
        self._log_file = self._log_dir / _DEFAULT_LOG_FILE

    def _ensure_dir(self) -> None:
        self._log_dir.mkdir(parents=True, exist_ok=True)

    def log_call(
        self,
        template_id: str,
        model: str,
        input_text: str,
        output_text: str,
        **extras: object,
    ) -> None:
        """Write a single audit entry as a JSON line."""
        self._ensure_dir()
        entry: dict[str, object] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "template_id": template_id,
            "model": model,
            "input_chars": len(input_text),
            "output_chars": len(output_text),
            "token_count": extras.get("token_count"),
            "cost": extras.get("cost"),
            "user": extras.get("user") or _current_user(),
        }
        # Merge any additional extras
        for k, v in extras.items():
            if k not in ("token_count", "cost", "user"):
                entry[k] = v

        with open(self._log_file, "a") as f:
            f.write(json.dumps(entry) + "\n")


def _current_user() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return "unknown"
