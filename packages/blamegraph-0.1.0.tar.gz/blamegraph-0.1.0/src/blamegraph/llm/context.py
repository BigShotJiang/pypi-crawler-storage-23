"""Context assembler — converts SearchResult into LLM-ready text."""

from __future__ import annotations

from typing import TYPE_CHECKING

from blamegraph.llm.redactor import Redactor

if TYPE_CHECKING:
    from blamegraph.config import BlameGraphConfig
    from blamegraph.search import SearchResult


def build_context(
    result: SearchResult,
    max_chars: int = 12000,
    config: BlameGraphConfig | None = None,
) -> str:
    """Assemble search results into a text block for LLM context.

    Sections: Jira Tickets, GitLab MRs, Slack Mentions, Dependency Edges.
    Applies redaction and respects max_chars truncation.
    """
    redactor = Redactor(config)
    sections: list[str] = []

    # Jira Tickets
    jira_entities = [e for e in result.entities if e.entity_type == "ticket"]
    if jira_entities:
        lines = ["## Jira Tickets"]
        for ent in jira_entities:
            status = ent.attributes.get("status", "")
            assignee = ent.attributes.get("assignee", "")
            labels = ent.attributes.get("labels", [])
            linked = ent.attributes.get("linked_issues", [])
            line = f"- {ent.external_id}: {ent.title}"
            if status:
                line += f" | Status: {status}"
            if assignee:
                line += f" | Assignee: {assignee}"
            if labels:
                line += f" | Labels: {', '.join(str(l) for l in labels)}"  # noqa: E741
            if linked:
                line += f" | Linked: {', '.join(str(l) for l in linked)}"  # noqa: E741
            lines.append(line)
        sections.append("\n".join(lines))

    # GitLab MRs
    mr_entities = [e for e in result.entities if e.entity_type == "pr"]
    if mr_entities:
        lines = ["## GitLab Merge Requests"]
        for ent in mr_entities:
            state = ent.attributes.get("state", "")
            author = ent.attributes.get("author", "")
            target = ent.attributes.get("target_branch", "")
            line = f"- {ent.external_id}: {ent.title}"
            if state:
                line += f" | State: {state}"
            if author:
                line += f" | Author: {author}"
            if target:
                line += f" | Target: {target}"
            lines.append(line)
        sections.append("\n".join(lines))

    # Slack Mentions
    if result.slack_mentions:
        lines = ["## Slack Mentions"]
        for mention in result.slack_mentions:
            channel = mention.get("channel", "")
            text = str(mention.get("text", ""))[:200]
            lines.append(f"- #{channel}: {text}")
        sections.append("\n".join(lines))

    # Dependency Edges
    if result.edges:
        lines = ["## Dependency Edges"]
        for edge in result.edges:
            evidence_str = ""
            if edge.evidence:
                evidence_str = f" (evidence: {edge.evidence[0].snippet[:100]})"
            lines.append(
                f"- {edge.from_entity} → {edge.to_entity}"
                f" | Type: {edge.edge_type}"
                f" | Confidence: {edge.confidence:.2f}"
                f"{evidence_str}"
            )
        sections.append("\n".join(lines))

    context = "\n\n".join(sections)
    context = redactor.redact(context)

    if len(context) > max_chars:
        context = context[:max_chars]

    return context
