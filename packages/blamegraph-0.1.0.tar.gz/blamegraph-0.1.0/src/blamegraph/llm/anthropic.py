"""Anthropic Messages API client for chat completions with streaming."""

from __future__ import annotations

import asyncio
import json
import logging
import random
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

import httpx

logger = logging.getLogger(__name__)

MAX_WAIT_TIME = 120  # seconds

ANTHROPIC_MODELS = [
    {"id": "claude-sonnet-4-6", "name": "Claude Sonnet 4.6", "owned_by": "anthropic"},
    {"id": "claude-haiku-4-5", "name": "Claude Haiku 4.5", "owned_by": "anthropic"},
    {"id": "claude-opus-4-6", "name": "Claude Opus 4.6", "owned_by": "anthropic"},
]


@dataclass
class ChatMessage:
    """A message in the chat conversation."""

    role: str  # "system" | "user" | "assistant"
    content: str

    def to_dict(self) -> dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass
class ChatResponse:
    """Response from chat completion API."""

    content: str
    model: str
    usage: dict[str, int] = field(default_factory=dict)


class AnthropicClientError(Exception):
    """Base exception for Anthropic client errors."""


class AnthropicAPIError(AnthropicClientError):
    """API returned an error response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"API error {status_code}: {message}")


class AnthropicClient:
    """Async client for Anthropic Messages API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.anthropic.com/v1",
        timeout: float = 120.0,
        max_retries: int = 3,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "x-api-key": self._api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                timeout=httpx.Timeout(self._timeout),
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _build_payload(
        self,
        messages: list[ChatMessage],
        model: str,
        temperature: float,
        max_tokens: int,
        *,
        stream: bool = False,
    ) -> dict[str, object]:
        """Build Anthropic Messages API payload, extracting system messages."""
        system_parts: list[str] = []
        api_messages: list[dict[str, str]] = []

        for m in messages:
            if m.role == "system":
                system_parts.append(m.content)
            else:
                api_messages.append(m.to_dict())

        payload: dict[str, object] = {
            "model": model,
            "messages": api_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_parts:
            payload["system"] = "\n\n".join(system_parts)

        if stream:
            payload["stream"] = True

        return payload

    async def _request_with_retry(
        self,
        payload: dict[str, object],
        *,
        stream: bool = False,
    ) -> httpx.Response:
        """POST /messages with exponential backoff retry for 429/5xx."""
        client = self._get_client()
        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                if stream:
                    request = client.build_request("POST", "/messages", json=payload)
                    response = await client.send(request, stream=True)
                else:
                    response = await client.request("POST", "/messages", json=payload)

                if response.status_code == 429:
                    retry_after = min(
                        int(response.headers.get("Retry-After", str(2**attempt))),
                        MAX_WAIT_TIME,
                    )
                    logger.warning("Rate limited, waiting %ds before retry", retry_after)
                    await asyncio.sleep(retry_after)
                    continue

                if response.status_code >= 500:
                    wait_time = min(2**attempt + random.uniform(0, 1), MAX_WAIT_TIME)
                    logger.warning(
                        "Server error %d, retrying in %.1fs",
                        response.status_code,
                        wait_time,
                    )
                    await asyncio.sleep(wait_time)
                    continue

                if response.status_code >= 400:
                    body = ""
                    if not stream:
                        body = response.text
                    if response.status_code == 401:
                        detail = f": {body}" if body else ""
                        raise AnthropicAPIError(
                            401,
                            f"Invalid API key{detail}. "
                            "Run: blamegraph config set-token anthropic",
                        )
                    raise AnthropicAPIError(
                        response.status_code, body or "Unknown error"
                    )

                return response

            except httpx.TimeoutException as exc:
                last_error = exc
                wait_time = min(2**attempt + random.uniform(0, 1), MAX_WAIT_TIME)
                logger.warning("Request timeout, retrying in %.1fs", wait_time)
                await asyncio.sleep(wait_time)
            except httpx.NetworkError as exc:
                last_error = exc
                wait_time = min(2**attempt + random.uniform(0, 1), MAX_WAIT_TIME)
                logger.warning("Network error: %s, retrying in %.1fs", exc, wait_time)
                await asyncio.sleep(wait_time)

        raise AnthropicClientError(
            f"Request failed after {self._max_retries} retries"
        ) from last_error

    async def chat(
        self,
        messages: list[ChatMessage],
        model: str,
        temperature: float = 0.2,
        max_tokens: int = 4096,
    ) -> ChatResponse:
        """Send a chat completion request and return the full response."""
        payload = self._build_payload(messages, model, temperature, max_tokens)

        response = await self._request_with_retry(payload)
        data = response.json()

        usage_data = data.get("usage", {})
        content_blocks = data.get("content", [])
        text = content_blocks[0]["text"] if content_blocks else ""

        return ChatResponse(
            content=text,
            model=data.get("model", model),
            usage={
                "prompt_tokens": usage_data.get("input_tokens", 0),
                "completion_tokens": usage_data.get("output_tokens", 0),
                "total_tokens": (
                    usage_data.get("input_tokens", 0)
                    + usage_data.get("output_tokens", 0)
                ),
            },
        )

    async def stream_chat(
        self,
        messages: list[ChatMessage],
        model: str,
        temperature: float = 0.2,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        """Stream a chat completion using SSE, yielding content chunks."""
        payload = self._build_payload(
            messages, model, temperature, max_tokens, stream=True
        )

        response = await self._request_with_retry(payload, stream=True)

        try:
            event_type = ""
            async for line in response.aiter_lines():
                if not line:
                    event_type = ""
                    continue
                if line.startswith("event: "):
                    event_type = line[7:].strip()
                    continue
                if line.startswith("data: "):
                    data_str = line[6:]
                    try:
                        data = json.loads(data_str)
                    except json.JSONDecodeError:
                        logger.warning("Failed to parse SSE data: %s", data_str)
                        continue

                    if event_type == "content_block_delta":
                        delta = data.get("delta", {})
                        text = delta.get("text", "")
                        if text:
                            yield text
                    elif event_type == "message_stop":
                        break
        finally:
            await response.aclose()

    async def list_models(self) -> list[dict[str, str]]:
        """Return available Anthropic models (hardcoded list)."""
        return list(ANTHROPIC_MODELS)
