"""Regex-based secret and PII redaction for LLM inputs."""

from __future__ import annotations

import re

from blamegraph.config import BlameGraphConfig

_DEFAULT_PATTERNS: list[str] = [
    r"AKIA[0-9A-Z]{16}",
    r"-----BEGIN .*PRIVATE KEY-----",
    r"https?://[^\s]*[?&](token|key|secret|password)=[^\s&]*",
    r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
    r"[0-9a-f]{32,}",
    r"xox[baprs]-[0-9A-Za-z\-]{10,48}",
]

_REPLACEMENT = "[REDACTED]"


class Redactor:
    """Strip secrets and PII from text before sending to LLM."""

    def __init__(self, config: BlameGraphConfig | None = None) -> None:
        patterns = list(_DEFAULT_PATTERNS)
        if config and config.llm.redact_patterns:
            patterns.extend(config.llm.redact_patterns)
        self._compiled = [re.compile(p) for p in patterns]

    def redact(self, text: str) -> str:
        """Apply all redaction patterns, replacing matches with [REDACTED]."""
        for pattern in self._compiled:
            text = pattern.sub(_REPLACEMENT, text)
        return text
