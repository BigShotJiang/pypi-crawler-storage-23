"""SQLite implementation of StorageProtocol."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime

from blamegraph.errors import StorageError
from blamegraph.models import (
    Edge,
    EdgeType,
    Entity,
    EntityType,
    Event,
    Evidence,
    GraphSnapshot,
    InferenceMethod,
    Owner,
    RiskLevel,
    RiskScore,
)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    entity_type TEXT NOT NULL,
    external_id TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    attributes TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_entities_external ON entities(entity_type, external_id);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_id TEXT NOT NULL REFERENCES entities(id),
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_events_entity ON events(entity_id);

CREATE TABLE IF NOT EXISTS edges (
    id TEXT PRIMARY KEY,
    from_entity TEXT NOT NULL REFERENCES entities(id),
    to_entity TEXT NOT NULL REFERENCES entities(id),
    edge_type TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 1.0,
    method TEXT NOT NULL DEFAULT 'explicit',
    evidence TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_entity);
CREATE INDEX IF NOT EXISTS idx_edges_to ON edges(to_entity);

CREATE TABLE IF NOT EXISTS owners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_id TEXT NOT NULL REFERENCES entities(id),
    candidate_owner TEXT NOT NULL,
    score REAL NOT NULL DEFAULT 0.0,
    signal TEXT NOT NULL DEFAULT '',
    evidence TEXT NOT NULL DEFAULT '[]',
    confirmed INTEGER NOT NULL DEFAULT 0,
    UNIQUE(entity_id, candidate_owner)
);
CREATE INDEX IF NOT EXISTS idx_owners_entity ON owners(entity_id);

CREATE TABLE IF NOT EXISTS risk_scores (
    entity_id TEXT PRIMARY KEY REFERENCES entities(id),
    score REAL NOT NULL,
    level TEXT NOT NULL,
    features TEXT NOT NULL DEFAULT '{}',
    why TEXT NOT NULL DEFAULT '[]',
    suggested_action TEXT NOT NULL DEFAULT '',
    ts TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS graph_snapshots (
    id TEXT PRIMARY KEY,
    ts TEXT NOT NULL,
    entity_count INTEGER NOT NULL DEFAULT 0,
    edge_count INTEGER NOT NULL DEFAULT 0,
    blocker_count INTEGER NOT NULL DEFAULT 0,
    snapshot_data TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_snapshots_ts ON graph_snapshots(ts);
"""


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _parse_dt(s: str) -> datetime:
    return datetime.fromisoformat(s)


class SQLiteStorage:
    """SQLite-backed storage. Pass ':memory:' for in-memory testing."""

    def __init__(self, db_path: str = "blamegraph.db") -> None:
        self._db_path = db_path
        try:
            self._conn = sqlite3.connect(db_path)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        except sqlite3.Error as exc:
            raise StorageError(f"Failed to open database: {db_path}") from exc

    def initialize(self) -> None:
        try:
            self._conn.executescript(_SCHEMA)
        except sqlite3.Error as exc:
            raise StorageError("Failed to initialize schema") from exc

    # -- Entities --

    def upsert_entity(self, entity: Entity) -> None:
        self._conn.execute(
            """INSERT INTO entities
               (id, entity_type, external_id, title, attributes,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 title=excluded.title,
                 attributes=excluded.attributes,
                 updated_at=excluded.updated_at""",
            (
                entity.id,
                entity.entity_type.value,
                entity.external_id,
                entity.title,
                json.dumps(entity.attributes, default=str),
                _iso(entity.created_at),
                _iso(entity.updated_at),
            ),
        )
        self._conn.commit()

    def get_entity(self, entity_id: str) -> Entity | None:
        row = self._conn.execute("SELECT * FROM entities WHERE id = ?", (entity_id,)).fetchone()
        if row is None:
            return None
        return _entity_from_row(row)

    def list_entities(self, entity_type: str | None = None) -> list[Entity]:
        if entity_type:
            rows = self._conn.execute(
                "SELECT * FROM entities WHERE entity_type = ?", (entity_type,)
            ).fetchall()
        else:
            rows = self._conn.execute("SELECT * FROM entities").fetchall()
        return [_entity_from_row(r) for r in rows]

    # -- Events --

    def add_event(self, event: Event) -> None:
        self._conn.execute(
            "INSERT INTO events (entity_id, ts, kind, payload) VALUES (?, ?, ?, ?)",
            (event.entity_id, _iso(event.ts), event.kind, json.dumps(event.payload, default=str)),
        )
        self._conn.commit()

    def list_events(self, entity_id: str) -> list[Event]:
        rows = self._conn.execute(
            "SELECT * FROM events WHERE entity_id = ? ORDER BY ts", (entity_id,)
        ).fetchall()
        return [
            Event(
                entity_id=r["entity_id"],
                ts=_parse_dt(r["ts"]),
                kind=r["kind"],
                payload=json.loads(r["payload"]),
            )
            for r in rows
        ]

    # -- Edges --

    def upsert_edge(self, edge: Edge) -> None:
        edge_id = edge.id or str(uuid.uuid4())
        self._conn.execute(
            """INSERT INTO edges
               (id, from_entity, to_entity, edge_type,
                confidence, method, evidence, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 confidence=excluded.confidence,
                 method=excluded.method,
                 evidence=excluded.evidence""",
            (
                edge_id,
                edge.from_entity,
                edge.to_entity,
                edge.edge_type.value,
                edge.confidence,
                edge.method.value,
                json.dumps([e.model_dump(mode="json") for e in edge.evidence], default=str),
                _iso(edge.created_at),
            ),
        )
        self._conn.commit()

    def get_edges_from(self, entity_id: str) -> list[Edge]:
        rows = self._conn.execute(
            "SELECT * FROM edges WHERE from_entity = ?", (entity_id,)
        ).fetchall()
        return [_edge_from_row(r) for r in rows]

    def get_edges_to(self, entity_id: str) -> list[Edge]:
        rows = self._conn.execute(
            "SELECT * FROM edges WHERE to_entity = ?", (entity_id,)
        ).fetchall()
        return [_edge_from_row(r) for r in rows]

    def list_edges(self) -> list[Edge]:
        rows = self._conn.execute("SELECT * FROM edges").fetchall()
        return [_edge_from_row(r) for r in rows]

    # -- Owners --

    def upsert_owner(self, owner: Owner) -> None:
        self._conn.execute(
            """INSERT INTO owners (entity_id, candidate_owner, score, signal, evidence, confirmed)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(entity_id, candidate_owner) DO UPDATE SET
                 score=excluded.score,
                 signal=excluded.signal,
                 evidence=excluded.evidence,
                 confirmed=excluded.confirmed""",
            (
                owner.entity_id,
                owner.candidate_owner,
                owner.score,
                owner.signal,
                json.dumps([e.model_dump(mode="json") for e in owner.evidence], default=str),
                1 if owner.confirmed else 0,
            ),
        )
        self._conn.commit()

    def get_owners(self, entity_id: str) -> list[Owner]:
        rows = self._conn.execute(
            "SELECT * FROM owners WHERE entity_id = ? ORDER BY score DESC", (entity_id,)
        ).fetchall()
        return [
            Owner(
                entity_id=r["entity_id"],
                candidate_owner=r["candidate_owner"],
                score=r["score"],
                signal=r["signal"],
                evidence=[Evidence(**e) for e in json.loads(r["evidence"])],
                confirmed=bool(r["confirmed"]),
            )
            for r in rows
        ]

    # -- Risk scores --

    def upsert_risk_score(self, risk_score: RiskScore) -> None:
        self._conn.execute(
            """INSERT INTO risk_scores
               (entity_id, score, level, features, why,
                suggested_action, ts)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(entity_id) DO UPDATE SET
                 score=excluded.score,
                 level=excluded.level,
                 features=excluded.features,
                 why=excluded.why,
                 suggested_action=excluded.suggested_action,
                 ts=excluded.ts""",
            (
                risk_score.entity_id,
                risk_score.score,
                risk_score.level.value,
                json.dumps(risk_score.features, default=str),
                json.dumps(risk_score.why),
                risk_score.suggested_action,
                _iso(risk_score.ts),
            ),
        )
        self._conn.commit()

    def get_risk_score(self, entity_id: str) -> RiskScore | None:
        row = self._conn.execute(
            "SELECT * FROM risk_scores WHERE entity_id = ?", (entity_id,)
        ).fetchone()
        if row is None:
            return None
        return _risk_from_row(row)

    def list_risk_scores(self, min_score: float = 0.0) -> list[RiskScore]:
        rows = self._conn.execute(
            "SELECT * FROM risk_scores WHERE score >= ? ORDER BY score DESC", (min_score,)
        ).fetchall()
        return [_risk_from_row(r) for r in rows]

    # -- Graph Snapshots --

    def save_snapshot(self, snapshot: GraphSnapshot) -> None:
        self._conn.execute(
            """INSERT INTO graph_snapshots
               (id, ts, entity_count, edge_count, blocker_count, snapshot_data)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 ts=excluded.ts,
                 entity_count=excluded.entity_count,
                 edge_count=excluded.edge_count,
                 blocker_count=excluded.blocker_count,
                 snapshot_data=excluded.snapshot_data""",
            (
                snapshot.id,
                _iso(snapshot.ts),
                snapshot.entity_count,
                snapshot.edge_count,
                snapshot.blocker_count,
                json.dumps(snapshot.snapshot_data, default=str),
            ),
        )
        self._conn.commit()

    def get_snapshot(self, snapshot_id: str) -> GraphSnapshot | None:
        row = self._conn.execute(
            "SELECT * FROM graph_snapshots WHERE id = ?", (snapshot_id,)
        ).fetchone()
        if row is None:
            return None
        return _snapshot_from_row(row)

    def list_snapshots(self, since: str | None = None) -> list[GraphSnapshot]:
        if since:
            rows = self._conn.execute(
                "SELECT * FROM graph_snapshots WHERE ts >= ? ORDER BY ts DESC", (since,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM graph_snapshots ORDER BY ts DESC"
            ).fetchall()
        return [_snapshot_from_row(r) for r in rows]

    # -- Helper queries --

    def get_entity_by_external_id(self, external_id: str) -> Entity | None:
        row = self._conn.execute(
            "SELECT * FROM entities WHERE external_id = ?", (external_id,)
        ).fetchone()
        if row is None:
            return None
        return _entity_from_row(row)

    def list_events_since(self, since: str) -> list[Event]:
        rows = self._conn.execute(
            "SELECT * FROM events WHERE ts >= ? ORDER BY ts", (since,)
        ).fetchall()
        return [
            Event(
                entity_id=r["entity_id"],
                ts=_parse_dt(r["ts"]),
                kind=r["kind"],
                payload=json.loads(r["payload"]),
            )
            for r in rows
        ]

    def close(self) -> None:
        self._conn.close()


def _entity_from_row(row: sqlite3.Row) -> Entity:
    return Entity(
        id=row["id"],
        entity_type=EntityType(row["entity_type"]),
        external_id=row["external_id"],
        title=row["title"],
        attributes=json.loads(row["attributes"]),
        created_at=_parse_dt(row["created_at"]),
        updated_at=_parse_dt(row["updated_at"]),
    )


def _edge_from_row(row: sqlite3.Row) -> Edge:
    return Edge(
        id=row["id"],
        from_entity=row["from_entity"],
        to_entity=row["to_entity"],
        edge_type=EdgeType(row["edge_type"]),
        confidence=row["confidence"],
        method=InferenceMethod(row["method"]),
        evidence=[Evidence(**e) for e in json.loads(row["evidence"])],
        created_at=_parse_dt(row["created_at"]),
    )


def _risk_from_row(row: sqlite3.Row) -> RiskScore:
    return RiskScore(
        entity_id=row["entity_id"],
        score=row["score"],
        level=RiskLevel(row["level"]),
        features=json.loads(row["features"]),
        why=json.loads(row["why"]),
        suggested_action=row["suggested_action"],
        ts=_parse_dt(row["ts"]),
    )


def _snapshot_from_row(row: sqlite3.Row) -> GraphSnapshot:
    return GraphSnapshot(
        id=row["id"],
        ts=_parse_dt(row["ts"]),
        entity_count=row["entity_count"],
        edge_count=row["edge_count"],
        blocker_count=row["blocker_count"],
        snapshot_data=json.loads(row["snapshot_data"]),
    )
