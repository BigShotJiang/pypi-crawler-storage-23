"""Normalizer — converts raw payloads from connectors into domain models."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from blamegraph.models import Entity, EntityType, Event, RawPayload, TextArtifact

logger = logging.getLogger(__name__)


def _raw(payload: RawPayload) -> dict[str, Any]:
    """Extract payload dict with Any-typed values for dynamic access."""
    return payload.payload


def normalize_jira_issue(
    payload: RawPayload,
) -> tuple[Entity, list[Event], list[TextArtifact]]:
    """Normalize a Jira issue payload into domain models."""
    data = _raw(payload)
    fields: dict[str, Any] = data.get("fields", {}) or {}
    key = data.get("key", payload.external_id)

    entity = Entity(
        id=f"jira:{key}",
        entity_type=EntityType.TICKET,
        external_id=str(key),
        title=str(fields.get("summary", "")),
        attributes=_jira_attributes(fields),
        created_at=payload.fetched_at,
        updated_at=payload.fetched_at,
    )

    events: list[Event] = []
    artifacts: list[TextArtifact] = []

    # Description
    description = fields.get("description")
    if description:
        artifacts.append(
            TextArtifact(
                entity_id=entity.id,
                artifact_type="description",
                text=str(description),
            )
        )

    # Comments
    comment_block = fields.get("comment", {})
    comments = comment_block.get("comments", []) if isinstance(comment_block, dict) else []
    for comment in comments:
        body = comment.get("body", "")
        if body:
            artifacts.append(
                TextArtifact(
                    entity_id=entity.id,
                    artifact_type="comment",
                    text=str(body),
                    metadata={
                        "author": _safe_display_name(comment.get("author")),
                        "comment_id": str(comment.get("id", "")),
                    },
                )
            )

    # Changelog events
    changelog = data.get("changelog", {})
    histories = changelog.get("histories", []) if isinstance(changelog, dict) else []
    for history in histories:
        created = history.get("created", "")
        ts = _parse_jira_datetime(created) if created else payload.fetched_at
        items = history.get("items", [])
        for item in items:
            events.append(
                Event(
                    entity_id=entity.id,
                    ts=ts,
                    kind=f"field_change:{item.get('field', 'unknown')}",
                    payload={
                        "field": item.get("field", ""),
                        "from": item.get("fromString", ""),
                        "to": item.get("toString", ""),
                    },
                )
            )

    return entity, events, artifacts


def normalize_gitlab_mr(
    payload: RawPayload,
) -> tuple[Entity, list[Event], list[TextArtifact]]:
    """Normalize a GitLab merge request payload into domain models."""
    data = _raw(payload)
    iid = data.get("iid", "")
    project_id = str(data.get("project_id", payload.external_id.split("!")[0]))

    entity = Entity(
        id=f"gitlab_mr:{project_id}!{iid}",
        entity_type=EntityType.PR,
        external_id=f"{project_id}!{iid}",
        title=str(data.get("title", "")),
        attributes={
            "state": str(data.get("state", "")),
            "source_branch": str(data.get("source_branch", "")),
            "target_branch": str(data.get("target_branch", "")),
            "labels": data.get("labels", []),
            "web_url": str(data.get("web_url", "")),
            "author": str((data.get("author") or {}).get("username", "")),
        },
        created_at=payload.fetched_at,
        updated_at=payload.fetched_at,
    )

    events: list[Event] = []
    artifacts: list[TextArtifact] = []

    # Title
    title = data.get("title", "")
    if title:
        artifacts.append(
            TextArtifact(
                entity_id=entity.id,
                artifact_type="title",
                text=str(title),
            )
        )

    # Description
    description = data.get("description")
    if description:
        artifacts.append(
            TextArtifact(
                entity_id=entity.id,
                artifact_type="description",
                text=str(description),
            )
        )

    # State change event
    state = data.get("state", "")
    if state:
        merged_at = data.get("merged_at")
        created_at = data.get("created_at")
        ts_str = merged_at or created_at
        ts = _parse_iso_datetime(str(ts_str)) if ts_str else payload.fetched_at
        events.append(
            Event(
                entity_id=entity.id,
                ts=ts,
                kind=f"mr_state:{state}",
                payload={"state": str(state)},
            )
        )

    return entity, events, artifacts


def normalize_slack_message(
    payload: RawPayload,
) -> tuple[Entity, list[Event], list[TextArtifact]]:
    """Normalize a Slack message payload into domain models."""
    data = _raw(payload)
    ts = data.get("ts", "")
    channel = data.get("_channel", "")
    user = data.get("user", "unknown")

    entity = Entity(
        id=f"slack:{channel}:{ts}",
        entity_type=EntityType.TICKET,  # messages mapped to ticket for graph
        external_id=f"{channel}:{ts}",
        title=_truncate(str(data.get("text", "")), 120),
        attributes={
            "channel": str(channel),
            "user": str(user),
            "thread_ts": str(data.get("thread_ts", "")),
            "reactions": data.get("reactions", []),
        },
        created_at=_ts_to_datetime(str(ts)),
        updated_at=payload.fetched_at,
    )

    events: list[Event] = []
    artifacts: list[TextArtifact] = []

    text = data.get("text", "")
    if text:
        artifacts.append(
            TextArtifact(
                entity_id=entity.id,
                artifact_type="message",
                text=str(text),
                metadata={"user": str(user), "channel": str(channel)},
            )
        )

    events.append(
        Event(
            entity_id=entity.id,
            ts=_ts_to_datetime(str(ts)),
            kind="message_posted",
            payload={"channel": str(channel), "user": str(user)},
        )
    )

    return entity, events, artifacts


# --- Helpers ---


def _jira_attributes(fields: dict[str, Any]) -> dict[str, object]:
    status_obj = fields.get("status")
    status_name = status_obj.get("name", "") if isinstance(status_obj, dict) else ""

    priority_obj = fields.get("priority")
    priority_name = priority_obj.get("name", "") if isinstance(priority_obj, dict) else ""

    assignee_obj = fields.get("assignee")
    assignee_name = _safe_display_name(assignee_obj)

    components = fields.get("components", [])
    component_names = (
        [c.get("name", "") for c in components] if isinstance(components, list) else []
    )

    return {
        "status": status_name,
        "priority": priority_name,
        "assignee": assignee_name,
        "labels": fields.get("labels", []),
        "components": component_names,
        "duedate": str(fields.get("duedate", "") or ""),
    }


def _safe_display_name(user_obj: object) -> str:
    if isinstance(user_obj, dict):
        return str(user_obj.get("displayName", user_obj.get("name", "")))
    return ""


def _parse_jira_datetime(s: str) -> datetime:
    """Parse Jira datetime format like '2024-01-15T10:30:00.000+0000'."""
    try:
        # Strip milliseconds and timezone for simpler parsing
        clean = s.split(".")[0]
        return datetime.strptime(clean, "%Y-%m-%dT%H:%M:%S")
    except (ValueError, IndexError):
        return datetime.utcnow()


def _parse_iso_datetime(s: str) -> datetime:
    """Parse ISO 8601 datetime."""
    try:
        clean = s.replace("Z", "").split("+")[0].split(".")[0]
        return datetime.strptime(clean, "%Y-%m-%dT%H:%M:%S")
    except (ValueError, IndexError):
        return datetime.utcnow()


def _ts_to_datetime(ts: str) -> datetime:
    """Convert Slack timestamp (epoch.sequence) to datetime."""
    try:
        epoch = float(ts.split(".")[0]) if "." in ts else float(ts)
        return datetime.utcfromtimestamp(epoch)
    except (ValueError, OSError):
        return datetime.utcnow()


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
