"""CI/CD Gate — BlameGraph Watch for pipeline integration."""

from __future__ import annotations

from dataclasses import dataclass, field

from blamegraph.models import EdgeType, RiskLevel, RiskScore
from blamegraph.storage.sqlite import SQLiteStorage


@dataclass
class WatchResult:
    """Result of a CI/CD gate check."""
    ticket_key: str
    entity_id: str = ""
    has_critical: bool = False
    has_high: bool = False
    blockers: list[dict[str, object]] = field(default_factory=list)
    risk_score: float = 0.0
    risk_level: str = "low"
    should_fail: bool = False
    reason: str = ""


def check_ticket(
    storage: SQLiteStorage,
    ticket_key: str,
    fail_on: str = "critical",
) -> WatchResult:
    """Check if a ticket has blockers that should fail a CI/CD gate.

    Args:
        storage: Storage instance.
        ticket_key: External ticket key (e.g. "NAPPS-396").
        fail_on: Risk level threshold — "critical", "high", "medium".
                 Gate fails if any blocker meets or exceeds this level.
    """
    result = WatchResult(ticket_key=ticket_key)

    entity = storage.get_entity_by_external_id(ticket_key)
    if entity is None:
        result.reason = f"Ticket {ticket_key} not found in graph"
        return result

    result.entity_id = entity.id

    # Get risk score for this entity
    rs = storage.get_risk_score(entity.id)
    if rs:
        result.risk_score = rs.score
        result.risk_level = rs.level.value

    # Find blockers (edges where something blocks this entity)
    blocking_edges = storage.get_edges_to(entity.id)
    blocker_edges = [e for e in blocking_edges if e.edge_type == EdgeType.BLOCKS]

    for edge in blocker_edges:
        blocker = storage.get_entity(edge.from_entity)
        if blocker is None:
            continue

        status = str(blocker.attributes.get("status", "")).lower()
        if status in ("done", "closed", "resolved"):
            continue  # Resolved blockers don't count

        blocker_rs = storage.get_risk_score(edge.from_entity)
        blocker_level = blocker_rs.level.value if blocker_rs else "unknown"
        blocker_score = blocker_rs.score if blocker_rs else 0.0

        if blocker_level == "critical":
            result.has_critical = True
        elif blocker_level == "high":
            result.has_high = True

        result.blockers.append({
            "key": blocker.external_id,
            "title": blocker.title,
            "status": status,
            "risk_level": blocker_level,
            "risk_score": blocker_score,
        })

    # Also check unresolved blockers (status-based)
    entity_status = str(entity.attributes.get("status", "")).lower()
    if entity_status == "blocked" and not result.blockers:
        result.has_high = True
        result.blockers.append({
            "key": ticket_key,
            "title": entity.title,
            "status": entity_status,
            "risk_level": "high",
            "risk_score": result.risk_score,
        })

    # Determine if gate should fail
    fail_levels = _fail_levels(fail_on)
    if result.has_critical and "critical" in fail_levels:
        result.should_fail = True
        result.reason = f"Critical blocker(s) found for {ticket_key}"
    elif result.has_high and "high" in fail_levels:
        result.should_fail = True
        result.reason = f"High-risk blocker(s) found for {ticket_key}"
    elif result.blockers and "medium" in fail_levels:
        result.should_fail = True
        result.reason = f"Unresolved blocker(s) found for {ticket_key}"

    if not result.should_fail and not result.blockers:
        result.reason = f"No active blockers for {ticket_key}"

    return result


def _fail_levels(fail_on: str) -> set[str]:
    """Return the set of risk levels that should trigger a gate failure."""
    fail_on = fail_on.lower()
    if fail_on == "critical":
        return {"critical"}
    if fail_on == "high":
        return {"critical", "high"}
    if fail_on == "medium":
        return {"critical", "high", "medium"}
    return {"critical"}
