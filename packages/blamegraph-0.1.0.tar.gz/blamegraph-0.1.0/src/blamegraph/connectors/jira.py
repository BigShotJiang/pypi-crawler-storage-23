"""Jira connector — pulls issues via JQL search with pagination."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import JiraConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_FIELDS = ",".join(
    [
        "key",
        "summary",
        "description",
        "status",
        "assignee",
        "labels",
        "components",
        "priority",
        "duedate",
        "issuelinks",
        "comment",
        "changelog",
    ]
)

_PAGE_SIZE = 50


class JiraConnector:
    """Connector for Jira REST API v2."""

    def __init__(self, config: JiraConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("jira")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token jira'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        import base64

        token = self._get_token()
        if self._config.user_email:
            # Jira Cloud: Basic Auth with email:api_token
            credentials = base64.b64encode(f"{self._config.user_email}:{token}".encode()).decode()
            auth_header = f"Basic {credentials}"
        else:
            # Jira Server/DC: Bearer token
            auth_header = f"Bearer {token}"
        return httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/"),
            headers={
                "Authorization": auth_header,
                "Accept": "application/json",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to Jira by fetching server info."""
        client = self._client or self._build_client()
        try:
            resp = await client.get("/rest/api/3/serverInfo")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch Jira issues using JQL search with startAt pagination."""
        if not self._config.project_keys:
            logger.warning("No Jira project keys configured; skipping sync")
            return []

        project_clause = ", ".join(f'"{k}"' for k in self._config.project_keys)
        jql = f"project in ({project_clause})"
        if since is not None:
            jql += f' AND updated >= "{since.strftime("%Y-%m-%d %H:%M")}"'

        client = self._client or self._build_client()
        try:
            return await self._paginate(client, jql)
        finally:
            if self._client is None:
                await client.aclose()

    async def search_by_key(self, key: str) -> list[RawPayload]:
        """Fetch a single issue by its key (e.g. PROJ-123)."""
        jql = f'key = "{key}"'
        client = self._client or self._build_client()
        try:
            return await self._paginate(client, jql, max_results=1)
        finally:
            if self._client is None:
                await client.aclose()

    async def search_linked(self, key: str) -> list[RawPayload]:
        """Fetch issues linked to the given key."""
        jql = f'issue in linkedIssues("{key}")'
        client = self._client or self._build_client()
        try:
            return await self._paginate(client, jql)
        finally:
            if self._client is None:
                await client.aclose()

    async def search_text(self, query: str, max_results: int = 50) -> list[RawPayload]:
        """Search issues by text content."""
        jql = f'text ~ "{query}"'
        client = self._client or self._build_client()
        try:
            return await self._paginate(client, jql, max_results=max_results)
        finally:
            if self._client is None:
                await client.aclose()

    async def _paginate(
        self, client: httpx.AsyncClient, jql: str, max_results: int = 0
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        start_at = 0

        while True:
            if max_results > 0:
                page_size = min(_PAGE_SIZE, max_results - len(results))
            else:
                page_size = _PAGE_SIZE
            params = {
                "jql": jql,
                "fields": _FIELDS,
                "expand": "changelog",
                "startAt": str(start_at),
                "maxResults": str(page_size),
            }
            try:
                resp = await client.get("/rest/api/3/search/jql", params=params)
            except httpx.HTTPError as exc:
                raise ConnectorError("Jira API request failed", detail=str(exc)) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"Jira API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            data = resp.json()
            issues = data.get("issues", [])
            now = datetime.utcnow()

            for issue in issues:
                results.append(
                    RawPayload(
                        source="jira",
                        external_id=issue["key"],
                        payload=issue,
                        fetched_at=now,
                    )
                )

            total = data.get("total", 0)
            start_at += len(issues)
            logger.debug("Jira pagination: fetched %d / %d", start_at, total)

            if start_at >= total or not issues:
                break
            if max_results > 0 and len(results) >= max_results:
                break

        return results
