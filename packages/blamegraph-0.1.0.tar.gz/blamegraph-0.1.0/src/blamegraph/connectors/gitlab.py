"""GitLab connector — pulls MRs, commits, pipelines, and CODEOWNERS."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import GitLabConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_PAGE_SIZE = 100


def _parse_next_link(link_header: str) -> str | None:
    """Parse the 'next' URL from a Link header value."""
    for part in link_header.split(","):
        part = part.strip()
        if 'rel="next"' in part:
            url = part.split(";")[0].strip().strip("<>")
            return url
    return None


class GitLabConnector:
    """Connector for GitLab REST API v4."""

    def __init__(self, config: GitLabConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("gitlab")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token gitlab'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        token = self._get_token()
        return httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/"),
            headers={
                "PRIVATE-TOKEN": token,
                "Accept": "application/json",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to GitLab."""
        client = self._client or self._build_client()
        try:
            resp = await client.get("/api/v4/version")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch merge requests, commits, pipelines, and CODEOWNERS for configured projects."""
        if not self._config.project_ids:
            logger.warning("No GitLab project IDs configured; skipping sync")
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            for project_id in self._config.project_ids:
                results.extend(await self._sync_project(client, project_id, since))
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _sync_project(
        self,
        client: httpx.AsyncClient,
        project_id: int,
        since: datetime | None,
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        now = datetime.utcnow()
        since_param = since.strftime("%Y-%m-%dT%H:%M:%SZ") if since else None

        # Merge Requests
        mr_params: dict[str, str] = {"per_page": str(_PAGE_SIZE)}
        if since_param:
            mr_params["updated_after"] = since_param
        mrs = await self._paginate_link(
            client, f"/api/v4/projects/{project_id}/merge_requests", mr_params
        )
        for mr in mrs:
            results.append(
                RawPayload(
                    source="gitlab_mr",
                    external_id=f"{project_id}!{mr['iid']}",
                    payload=mr,
                    fetched_at=now,
                )
            )

        # Commits
        commit_params: dict[str, str] = {"per_page": str(_PAGE_SIZE)}
        if since_param:
            commit_params["since"] = since_param
        commits = await self._paginate_link(
            client, f"/api/v4/projects/{project_id}/repository/commits", commit_params
        )
        for commit in commits:
            results.append(
                RawPayload(
                    source="gitlab_commit",
                    external_id=f"{project_id}:{commit['id']}",
                    payload=commit,
                    fetched_at=now,
                )
            )

        # Pipelines
        pipeline_params: dict[str, str] = {"per_page": str(_PAGE_SIZE)}
        if since_param:
            pipeline_params["updated_after"] = since_param
        pipelines = await self._paginate_link(
            client, f"/api/v4/projects/{project_id}/pipelines", pipeline_params
        )
        for pipeline in pipelines:
            results.append(
                RawPayload(
                    source="gitlab_pipeline",
                    external_id=f"{project_id}:pipeline:{pipeline['id']}",
                    payload=pipeline,
                    fetched_at=now,
                )
            )

        # CODEOWNERS
        try:
            resp = await client.get(
                f"/api/v4/projects/{project_id}/repository/files/CODEOWNERS",
                params={"ref": "main"},
            )
            if resp.status_code == 200:
                codeowners_data = resp.json()
                results.append(
                    RawPayload(
                        source="gitlab_codeowners",
                        external_id=f"{project_id}:CODEOWNERS",
                        payload=codeowners_data,
                        fetched_at=now,
                    )
                )
        except httpx.HTTPError:
            logger.debug("Failed to fetch CODEOWNERS for project %d", project_id)

        return results

    async def search_mrs(self, query: str, max_results: int = 50) -> list[RawPayload]:
        """Search merge requests by keyword across configured projects."""
        if not self._config.project_ids:
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            now = datetime.utcnow()
            for project_id in self._config.project_ids:
                params: dict[str, str] = {
                    "search": query,
                    "per_page": str(min(max_results, _PAGE_SIZE)),
                }
                items = await self._paginate_link(
                    client,
                    f"/api/v4/projects/{project_id}/merge_requests",
                    params,
                )
                for mr in items[: max_results - len(results)]:
                    results.append(
                        RawPayload(
                            source="gitlab_mr",
                            external_id=f"{project_id}!{mr['iid']}",
                            payload=mr,
                            fetched_at=now,
                        )
                    )
                    if len(results) >= max_results:
                        break
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _paginate_link(
        self,
        client: httpx.AsyncClient,
        url: str,
        params: dict[str, str],
    ) -> list[dict[str, object]]:
        """Paginate using Link header 'next' URLs."""
        all_items: list[dict[str, object]] = []

        try:
            resp = await client.get(url, params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError(f"GitLab API request failed for {url}", detail=str(exc)) from exc

        if resp.status_code != 200:
            raise ConnectorError(
                f"GitLab API returned {resp.status_code} for {url}",
                detail=resp.text[:500],
            )

        all_items.extend(resp.json())

        while True:
            link_header = resp.headers.get("Link", "")
            next_url = _parse_next_link(link_header)
            if not next_url:
                break

            try:
                resp = await client.get(next_url)
            except httpx.HTTPError as exc:
                raise ConnectorError(
                    f"GitLab API request failed for {next_url}", detail=str(exc)
                ) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"GitLab API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            all_items.extend(resp.json())

        return all_items
