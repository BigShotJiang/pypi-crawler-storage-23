"""Bitbucket Cloud connector — pulls PRs and issues."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import BitbucketConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_PAGE_SIZE = 50


class BitbucketConnector:
    """Connector for Bitbucket Cloud REST API v2.0."""

    def __init__(self, config: BitbucketConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("bitbucket")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token bitbucket'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        token = self._get_token()
        return httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to Bitbucket."""
        client = self._client or self._build_client()
        try:
            resp = await client.get("/user")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch PRs and issues for configured repos in workspace."""
        if not self._config.repos:
            logger.warning("No Bitbucket repos configured; skipping sync")
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            for repo_slug in self._config.repos:
                results.extend(
                    await self._sync_repo(client, self._config.workspace, repo_slug, since)
                )
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _sync_repo(
        self,
        client: httpx.AsyncClient,
        workspace: str,
        repo_slug: str,
        since: datetime | None,
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        now = datetime.utcnow()

        # Pull Requests
        pr_params: dict[str, str] = {"pagelen": str(_PAGE_SIZE)}
        if since:
            pr_params["q"] = f'updated_on>"{since.strftime("%Y-%m-%dT%H:%M:%SZ")}"'
        prs = await self._paginate_next(
            client, f"/repositories/{workspace}/{repo_slug}/pullrequests", pr_params
        )
        for pr in prs:
            results.append(
                RawPayload(
                    source="bitbucket_pr",
                    external_id=f"{workspace}/{repo_slug}!{pr['id']}",
                    payload=pr,
                    fetched_at=now,
                )
            )

        # Issues (may be disabled for some repos)
        issue_params: dict[str, str] = {"pagelen": str(_PAGE_SIZE)}
        if since:
            issue_params["q"] = f'updated_on>"{since.strftime("%Y-%m-%dT%H:%M:%SZ")}"'
        try:
            issues = await self._paginate_next(
                client, f"/repositories/{workspace}/{repo_slug}/issues", issue_params
            )
            for issue in issues:
                results.append(
                    RawPayload(
                        source="bitbucket_issue",
                        external_id=f"{workspace}/{repo_slug}#{issue['id']}",
                        payload=issue,
                        fetched_at=now,
                    )
                )
        except ConnectorError as exc:
            if "404" in str(exc):
                logger.debug(
                    "Issue tracker disabled for %s/%s, skipping issues",
                    workspace,
                    repo_slug,
                )
            else:
                raise

        return results

    async def search_prs(self, query: str, max_results: int = 50) -> list[RawPayload]:
        """Search pull requests by title across configured repos."""
        if not self._config.repos:
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            now = datetime.utcnow()
            workspace = self._config.workspace
            for repo_slug in self._config.repos:
                params: dict[str, str] = {
                    "pagelen": str(min(max_results, _PAGE_SIZE)),
                    "q": f'title~"{query}"',
                }
                prs = await self._paginate_next(
                    client,
                    f"/repositories/{workspace}/{repo_slug}/pullrequests",
                    params,
                )
                for pr in prs[:max_results - len(results)]:
                    results.append(
                        RawPayload(
                            source="bitbucket_pr",
                            external_id=f"{workspace}/{repo_slug}!{pr['id']}",
                            payload=pr,
                            fetched_at=now,
                        )
                    )
                    if len(results) >= max_results:
                        break
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _paginate_next(
        self,
        client: httpx.AsyncClient,
        url: str,
        params: dict[str, str],
    ) -> list[dict[str, object]]:
        """Paginate using body-based 'next' URL and 'values' array."""
        all_items: list[dict[str, object]] = []

        try:
            resp = await client.get(url, params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError(
                f"Bitbucket API request failed for {url}", detail=str(exc)
            ) from exc

        if resp.status_code != 200:
            raise ConnectorError(
                f"Bitbucket API returned {resp.status_code} for {url}",
                detail=resp.text[:500],
            )

        data = resp.json()
        all_items.extend(data.get("values", []))

        while data.get("next"):
            next_url = data["next"]
            try:
                resp = await client.get(next_url)
            except httpx.HTTPError as exc:
                raise ConnectorError(
                    f"Bitbucket API request failed for {next_url}", detail=str(exc)
                ) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"Bitbucket API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            data = resp.json()
            all_items.extend(data.get("values", []))

        return all_items
