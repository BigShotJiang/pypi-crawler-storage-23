"""Microsoft Teams connector — pulls messages and replies from channels."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import TeamsConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_PAGE_SIZE = 50


class TeamsConnector:
    """Connector for Microsoft Graph API (Teams messages)."""

    def __init__(self, config: TeamsConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("teams")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token teams'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        token = self._get_token()
        return httpx.AsyncClient(
            base_url=_GRAPH_BASE,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to Microsoft Graph."""
        client = self._client or self._build_client()
        try:
            resp = await client.get("/me")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch messages from configured Teams channels."""
        if not self._config.channels:
            logger.warning("No Teams channels configured; skipping sync")
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            for channel_id in self._config.channels:
                results.extend(
                    await self._sync_channel(client, self._config.team_id, channel_id, since)
                )
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _sync_channel(
        self,
        client: httpx.AsyncClient,
        team_id: str,
        channel_id: str,
        since: datetime | None,
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        now = datetime.utcnow()

        params: dict[str, str] = {"$top": str(_PAGE_SIZE)}
        if since:
            params["$filter"] = (
                f"lastModifiedDateTime gt {since.strftime('%Y-%m-%dT%H:%M:%SZ')}"
            )

        messages = await self._paginate_odata(
            client, f"/teams/{team_id}/channels/{channel_id}/messages", params
        )

        for msg in messages:
            msg_id = msg["id"]
            results.append(
                RawPayload(
                    source="teams",
                    external_id=f"{team_id}:{channel_id}:{msg_id}",
                    payload=msg,
                    fetched_at=now,
                )
            )

            # Fetch replies
            replies = await self._fetch_replies(client, team_id, channel_id, str(msg_id))
            for reply in replies:
                reply_id = reply["id"]
                results.append(
                    RawPayload(
                        source="teams_reply",
                        external_id=f"{team_id}:{channel_id}:{msg_id}:{reply_id}",
                        payload=reply,
                        fetched_at=now,
                    )
                )

        return results

    async def _fetch_replies(
        self,
        client: httpx.AsyncClient,
        team_id: str,
        channel_id: str,
        msg_id: str,
    ) -> list[dict[str, object]]:
        """Fetch replies for a message."""
        try:
            url = f"/teams/{team_id}/channels/{channel_id}/messages/{msg_id}/replies"
            return await self._paginate_odata(client, url, {})
        except ConnectorError:
            logger.debug("Failed to fetch replies for message %s", msg_id)
            return []

    async def search_messages(self, query: str, max_results: int = 100) -> list[RawPayload]:
        """Search messages by client-side filtering."""
        if not self._config.channels:
            return []

        client = self._client or self._build_client()
        try:
            query_lower = query.lower()
            results: list[RawPayload] = []
            for channel_id in self._config.channels:
                payloads = await self._sync_channel(
                    client, self._config.team_id, channel_id, since=None
                )
                for p in payloads:
                    body = p.payload.get("body", {})
                    content = str(body.get("content", "")) if isinstance(body, dict) else str(body)
                    if query_lower in content.lower():
                        results.append(p)
                        if len(results) >= max_results:
                            return results
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _paginate_odata(
        self,
        client: httpx.AsyncClient,
        url: str,
        params: dict[str, str],
    ) -> list[dict[str, object]]:
        """Paginate using OData @odata.nextLink and 'value' array."""
        all_items: list[dict[str, object]] = []

        try:
            resp = await client.get(url, params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError(
                f"Teams API request failed for {url}", detail=str(exc)
            ) from exc

        if resp.status_code != 200:
            raise ConnectorError(
                f"Teams API returned {resp.status_code} for {url}",
                detail=resp.text[:500],
            )

        data = resp.json()
        all_items.extend(data.get("value", []))

        while data.get("@odata.nextLink"):
            next_url = data["@odata.nextLink"]
            try:
                resp = await client.get(next_url)
            except httpx.HTTPError as exc:
                raise ConnectorError(
                    f"Teams API request failed for {next_url}", detail=str(exc)
                ) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"Teams API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            data = resp.json()
            all_items.extend(data.get("value", []))

        return all_items
