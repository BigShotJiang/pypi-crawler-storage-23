"""Connector protocol defining the interface all connectors must implement."""

from __future__ import annotations

from datetime import datetime
from typing import Protocol, runtime_checkable

from blamegraph.models import RawPayload


@runtime_checkable
class ConnectorProtocol(Protocol):
    """Interface for data source connectors."""

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch raw payloads from the data source.

        Args:
            since: If provided, only fetch records updated after this time.

        Returns:
            List of raw payloads from the source.
        """
        ...

    async def health_check(self) -> bool:
        """Check if the data source is reachable and credentials are valid."""
        ...
