"""GitHub connector — pulls issues, PRs, and PR details."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import GitHubConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_PAGE_SIZE = 100


def _parse_next_link(link_header: str) -> str | None:
    """Parse the 'next' URL from a Link header value."""
    for part in link_header.split(","):
        part = part.strip()
        if 'rel="next"' in part:
            url = part.split(";")[0].strip().strip("<>")
            return url
    return None


class GitHubConnector:
    """Connector for GitHub REST API."""

    def __init__(self, config: GitHubConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("github")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token github'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        token = self._get_token()
        return httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to GitHub."""
        client = self._client or self._build_client()
        try:
            resp = await client.get("/user")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch issues and PRs for configured repos."""
        if not self._config.repos:
            logger.warning("No GitHub repos configured; skipping sync")
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            for repo in self._config.repos:
                results.extend(await self._sync_repo(client, repo, since))
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _sync_repo(
        self,
        client: httpx.AsyncClient,
        repo: str,
        since: datetime | None,
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        now = datetime.utcnow()
        since_param = since.strftime("%Y-%m-%dT%H:%M:%SZ") if since else None

        # Issues (includes PRs — differentiated by pull_request key)
        issue_params: dict[str, str] = {
            "state": "all",
            "sort": "updated",
            "per_page": str(_PAGE_SIZE),
        }
        if since_param:
            issue_params["since"] = since_param
        issues = await self._paginate_link(
            client, f"/repos/{repo}/issues", issue_params
        )
        for issue in issues:
            is_pr = "pull_request" in issue
            source = "github_pr" if is_pr else "github_issue"
            results.append(
                RawPayload(
                    source=source,
                    external_id=f"{repo}#{issue['number']}",
                    payload=issue,
                    fetched_at=now,
                )
            )

        # Pull request details
        pr_params: dict[str, str] = {
            "state": "all",
            "sort": "updated",
            "per_page": str(_PAGE_SIZE),
        }
        prs = await self._paginate_link(
            client, f"/repos/{repo}/pulls", pr_params
        )
        for pr in prs:
            results.append(
                RawPayload(
                    source="github_pr_detail",
                    external_id=f"{repo}#pr:{pr['number']}",
                    payload=pr,
                    fetched_at=now,
                )
            )

        return results

    async def search_issues(self, query: str, max_results: int = 50) -> list[RawPayload]:
        """Search issues across configured repos."""
        if not self._config.repos:
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            now = datetime.utcnow()
            for repo in self._config.repos:
                params: dict[str, str] = {
                    "q": f"{query} repo:{repo}",
                    "per_page": str(min(max_results, _PAGE_SIZE)),
                }
                try:
                    resp = await client.get("/search/issues", params=params)
                except httpx.HTTPError as exc:
                    raise ConnectorError(
                        "GitHub search API request failed", detail=str(exc)
                    ) from exc

                if resp.status_code != 200:
                    raise ConnectorError(
                        f"GitHub search API returned {resp.status_code}",
                        detail=resp.text[:500],
                    )

                data = resp.json()
                for item in data.get("items", [])[:max_results - len(results)]:
                    results.append(
                        RawPayload(
                            source="github_issue",
                            external_id=f"{repo}#{item['number']}",
                            payload=item,
                            fetched_at=now,
                        )
                    )
                    if len(results) >= max_results:
                        break
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def _paginate_link(
        self,
        client: httpx.AsyncClient,
        url: str,
        params: dict[str, str],
    ) -> list[dict[str, object]]:
        """Paginate using Link header 'next' URLs."""
        all_items: list[dict[str, object]] = []

        try:
            resp = await client.get(url, params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError(
                f"GitHub API request failed for {url}", detail=str(exc)
            ) from exc

        if resp.status_code != 200:
            raise ConnectorError(
                f"GitHub API returned {resp.status_code} for {url}",
                detail=resp.text[:500],
            )

        all_items.extend(resp.json())

        while True:
            link_header = resp.headers.get("Link", "")
            next_url = _parse_next_link(link_header)
            if not next_url:
                break

            try:
                resp = await client.get(next_url)
            except httpx.HTTPError as exc:
                raise ConnectorError(
                    f"GitHub API request failed for {next_url}", detail=str(exc)
                ) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"GitHub API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            all_items.extend(resp.json())

        return all_items
