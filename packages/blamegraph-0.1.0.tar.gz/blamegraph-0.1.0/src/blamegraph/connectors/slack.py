"""Slack connector — pulls messages and threads from allowlisted channels."""

from __future__ import annotations

import logging
import os
from datetime import datetime

import httpx

from blamegraph.config import SlackConfig
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload

logger = logging.getLogger(__name__)

_SLACK_BASE = "https://slack.com/api"
_PAGE_LIMIT = 200


class SlackConnector:
    """Connector for Slack Web API."""

    def __init__(self, config: SlackConfig, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client

    def _get_token(self) -> str:
        token = os.environ.get(self._config.token_env)
        if not token:
            from blamegraph.credentials import load_token

            token = load_token("slack")
        if not token:
            raise ConnectorError(
                f"Missing environment variable {self._config.token_env}",
                detail="Set the token env var or run 'bg config set-token slack'.",
            )
        return token

    def _build_client(self) -> httpx.AsyncClient:
        token = self._get_token()
        return httpx.AsyncClient(
            base_url=_SLACK_BASE,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=30.0,
        )

    async def health_check(self) -> bool:
        """Check connectivity to Slack via auth.test."""
        client = self._client or self._build_client()
        try:
            resp = await client.post("/auth.test")
            if resp.status_code != 200:
                return False
            data = resp.json()
            return bool(data.get("ok", False))
        except httpx.HTTPError:
            return False
        finally:
            if self._client is None:
                await client.aclose()

    async def sync(self, since: datetime | None = None) -> list[RawPayload]:
        """Fetch messages from allowlisted channels with cursor pagination."""
        if not self._config.channels:
            logger.warning("No Slack channels configured; skipping sync")
            return []

        client = self._client or self._build_client()
        try:
            results: list[RawPayload] = []
            for channel_id in self._config.channels:
                results.extend(await self._sync_channel(client, channel_id, since))
            return results
        finally:
            if self._client is None:
                await client.aclose()

    async def search_messages(self, query: str, max_results: int = 100) -> list[RawPayload]:
        """Search messages by query using search.messages API.

        Falls back to filtering conversations.history client-side
        if the search scope is not available.
        """
        client = self._client or self._build_client()
        try:
            return await self._search_api(client, query, max_results)
        except ConnectorError:
            # Fallback: filter channel history client-side
            return await self._search_history_fallback(client, query, max_results)
        finally:
            if self._client is None:
                await client.aclose()

    async def _search_api(
        self,
        client: httpx.AsyncClient,
        query: str,
        max_results: int,
    ) -> list[RawPayload]:
        """Use Slack search.messages API (requires search:read scope)."""
        params = {"query": query, "count": str(min(max_results, 100))}
        try:
            resp = await client.get("/search.messages", params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError("Slack search API request failed", detail=str(exc)) from exc

        if resp.status_code != 200:
            raise ConnectorError(
                f"Slack search API returned {resp.status_code}",
                detail=resp.text[:500],
            )

        data = resp.json()
        if not data.get("ok", False):
            raise ConnectorError(
                f"Slack search API error: {data.get('error', 'unknown')}",
                detail=str(data),
            )

        results: list[RawPayload] = []
        now = datetime.utcnow()
        matches = data.get("messages", {}).get("matches", [])
        for msg in matches[:max_results]:
            channel = msg.get("channel", {}).get("id", "")
            ts = msg.get("ts", "")
            results.append(
                RawPayload(
                    source="slack",
                    external_id=f"{channel}:{ts}",
                    payload={**msg, "_channel": channel},
                    fetched_at=now,
                )
            )
        return results

    async def _search_history_fallback(
        self,
        client: httpx.AsyncClient,
        query: str,
        max_results: int,
    ) -> list[RawPayload]:
        """Fallback: fetch channel history and filter client-side."""
        query_lower = query.lower()
        results: list[RawPayload] = []
        for channel_id in self._config.channels:
            try:
                payloads = await self._sync_channel(client, channel_id, since=None)
            except ConnectorError:
                logger.debug("Skipping channel %s (not accessible)", channel_id)
                continue
            for p in payloads:
                text = str(p.payload.get("text", "")).lower()
                if query_lower in text:
                    results.append(p)
                    if len(results) >= max_results:
                        return results
        return results

    async def _sync_channel(
        self,
        client: httpx.AsyncClient,
        channel_id: str,
        since: datetime | None,
    ) -> list[RawPayload]:
        results: list[RawPayload] = []
        now = datetime.utcnow()

        params: dict[str, str] = {
            "channel": channel_id,
            "limit": str(_PAGE_LIMIT),
        }
        if since is not None:
            params["oldest"] = str(since.timestamp())

        cursor: str | None = None

        while True:
            if cursor:
                params["cursor"] = cursor

            try:
                resp = await client.get("/conversations.history", params=params)
            except httpx.HTTPError as exc:
                raise ConnectorError(
                    f"Slack API request failed for channel {channel_id}",
                    detail=str(exc),
                ) from exc

            if resp.status_code != 200:
                raise ConnectorError(
                    f"Slack API returned {resp.status_code}",
                    detail=resp.text[:500],
                )

            data = resp.json()
            if not data.get("ok", False):
                raise ConnectorError(
                    f"Slack API error: {data.get('error', 'unknown')}",
                    detail=str(data),
                )

            messages = data.get("messages", [])
            for msg in messages:
                ts = msg.get("ts", "")
                results.append(
                    RawPayload(
                        source="slack",
                        external_id=f"{channel_id}:{ts}",
                        payload={**msg, "_channel": channel_id},
                        fetched_at=now,
                    )
                )

                # Fetch thread replies if message has a thread
                if msg.get("thread_ts") == ts and int(msg.get("reply_count", 0)) > 0:
                    replies = await self._fetch_replies(client, channel_id, ts)
                    for reply in replies:
                        reply_ts = reply.get("ts", "")
                        if reply_ts == ts:
                            continue  # skip parent message
                        results.append(
                            RawPayload(
                                source="slack_reply",
                                external_id=f"{channel_id}:{reply_ts}",
                                payload={**reply, "_channel": channel_id, "_thread_ts": ts},
                                fetched_at=now,
                            )
                        )

            cursor = data.get("response_metadata", {}).get("next_cursor", "")
            if not cursor:
                break

        return results

    async def _fetch_replies(
        self,
        client: httpx.AsyncClient,
        channel_id: str,
        thread_ts: str,
    ) -> list[dict[str, object]]:
        """Fetch all replies in a thread with cursor pagination."""
        all_replies: list[dict[str, object]] = []
        cursor: str | None = None

        while True:
            params: dict[str, str] = {
                "channel": channel_id,
                "ts": thread_ts,
                "limit": str(_PAGE_LIMIT),
            }
            if cursor:
                params["cursor"] = cursor

            try:
                resp = await client.get("/conversations.replies", params=params)
            except httpx.HTTPError as exc:
                logger.warning("Failed to fetch replies for thread %s: %s", thread_ts, exc)
                break

            if resp.status_code != 200:
                logger.warning(
                    "Slack replies API returned %d for thread %s",
                    resp.status_code,
                    thread_ts,
                )
                break

            data = resp.json()
            if not data.get("ok", False):
                logger.warning("Slack replies error: %s", data.get("error"))
                break

            all_replies.extend(data.get("messages", []))

            cursor = data.get("response_metadata", {}).get("next_cursor", "")
            if not cursor:
                break

        return all_replies
