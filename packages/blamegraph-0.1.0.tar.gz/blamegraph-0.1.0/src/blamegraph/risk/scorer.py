"""Risk scoring engine for BlameGraph."""

from __future__ import annotations

import math
from datetime import datetime

from blamegraph.models import RiskLevel, RiskScore

# Feature weights
FEATURE_WEIGHTS: dict[str, float] = {
    "staleness": 0.5,
    "no_clear_owner": 1.0,
    "cross_team_hops": 0.8,
    "criticality": 1.2,
    "unbounded_dependency": 0.9,
    "broken_ci": 0.7,
    "churn": 0.4,
}

BIAS = -3.0


def _sigmoid(x: float) -> float:
    """Standard sigmoid function, clamped for numerical stability."""
    x = max(-500.0, min(500.0, x))
    return 1.0 / (1.0 + math.exp(-x))


class RiskScorer:
    """Score entity risk using a weighted sigmoid formula."""

    def __init__(
        self,
        weights: dict[str, float] | None = None,
        bias: float = BIAS,
    ) -> None:
        self._weights = weights or FEATURE_WEIGHTS
        self._bias = bias

    def score(self, entity_id: str, features: dict[str, float]) -> RiskScore:
        """Compute risk score for an entity given its features.

        Formula: risk = sigmoid(weighted_sum(features) + bias) * 100
        """
        weighted_sum = sum(self._weights.get(name, 0.0) * value for name, value in features.items())

        raw = _sigmoid(weighted_sum + self._bias)
        score_value = round(raw * 100, 2)
        # Clamp to valid range
        score_value = max(0.0, min(100.0, score_value))

        level = RiskLevel.from_score(score_value)

        # Build "why" bullets from top contributing features
        contributions = sorted(
            (
                (name, self._weights.get(name, 0.0) * value)
                for name, value in features.items()
                if value != 0.0 and name in self._weights
            ),
            key=lambda x: abs(x[1]),
            reverse=True,
        )
        why = [
            f"{name}: {value:.1f} (weight {self._weights[name]}, contribution {contrib:.2f})"
            for name, contrib in contributions[:3]
            for value in [features[name]]
        ]

        return RiskScore(
            entity_id=entity_id,
            score=score_value,
            level=level,
            features=features,
            why=why,
            ts=datetime.utcnow(),
        )
