"""Blocker detection heuristics for BlameGraph."""

from __future__ import annotations

import re

from blamegraph.models import Edge, Entity, TextArtifact

# Phrases that suggest a hidden dependency
_BLOCKER_PHRASES = [
    "waiting for",
    "blocked by",
    "needs api",
    "pending",
    "depends on",
    "waiting on",
]

_BLOCKER_PHRASE_RE = re.compile(
    "|".join(re.escape(p) for p in _BLOCKER_PHRASES),
    re.IGNORECASE,
)

_TODO_PLATFORM_RE = re.compile(
    r"TODO\s+after\s+platform\s+change",
    re.IGNORECASE,
)

_TICKET_KEY_RE = re.compile(r"\b[A-Z][A-Z0-9]+-\d+\b")


class BlockerDetector:
    """Detect hidden blockers using heuristic rules."""

    def detect_hidden_blockers(
        self,
        entity: Entity,
        edges: list[Edge],
        text_artifacts: list[TextArtifact],
    ) -> list[str]:
        """Detect hidden blockers for an entity.

        Returns a list of human-readable blocker descriptions.
        """
        blockers: list[str] = []

        has_explicit_dep = any(
            e.to_entity == entity.id or e.from_entity == entity.id for e in edges
        )

        # Heuristic 1: Ticket marked Blocked with no linked dependency
        status = str(entity.attributes.get("status", "")).lower()
        if status == "blocked" and not has_explicit_dep:
            blockers.append(
                f"Hidden blocker: {entity.external_id} is marked Blocked "
                f"but has no linked dependency"
            )

        # Collect all text for phrase analysis
        all_text = " ".join(a.text for a in text_artifacts if a.entity_id == entity.id)

        # Heuristic 2: Blocker phrases with no explicit link
        if not has_explicit_dep and _BLOCKER_PHRASE_RE.search(all_text):
            matches = _BLOCKER_PHRASE_RE.findall(all_text)
            unique_phrases = sorted(set(m.lower() for m in matches))
            phrase_list = ", ".join(repr(p) for p in unique_phrases)
            blockers.append(
                f"Hidden blocker: {entity.external_id} contains blocking "
                f"language ({phrase_list}) but has no explicit dependency link"
            )

        # Heuristic 3: PR mentions "TODO after platform change" and ticket
        # exists in other team
        if _TODO_PLATFORM_RE.search(all_text):
            referenced_keys = _TICKET_KEY_RE.findall(all_text)
            if referenced_keys:
                blockers.append(
                    f"Hidden blocker: {entity.external_id} mentions "
                    f"'TODO after platform change' with cross-reference to "
                    f"{', '.join(sorted(set(referenced_keys)))}"
                )

        return blockers
