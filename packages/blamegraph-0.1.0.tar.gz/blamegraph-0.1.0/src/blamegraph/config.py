"""BlameGraph configuration loading and validation."""

from __future__ import annotations

import os
import re
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

from blamegraph.errors import ConfigError

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

DEFAULT_CONFIG_PATHS = (
    Path("blamegraph.yaml"),
    Path.home() / ".blamegraph" / "config.yaml",
)


def _resolve_env_vars(value: object) -> object:
    """Recursively resolve ${ENV_VAR} references in config values."""
    if isinstance(value, str):

        def _replace(m: re.Match[str]) -> str:
            env_name = m.group(1)
            env_val = os.environ.get(env_name)
            if env_val is None:
                raise ConfigError(
                    f"Environment variable {env_name} is not set",
                    detail=f"Referenced as ${{{env_name}}} in config",
                )
            return env_val

        return _ENV_PATTERN.sub(_replace, value)
    if isinstance(value, dict):
        return {k: _resolve_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_env_vars(item) for item in value]
    return value


class JiraConfig(BaseModel):
    base_url: str = ""
    project_keys: list[str] = Field(default_factory=list)
    token_env: str = "JIRA_TOKEN"
    user_email: str = ""


class GitLabConfig(BaseModel):
    base_url: str = ""
    group: str = ""
    project_ids: list[int] = Field(default_factory=list)
    token_env: str = "GITLAB_TOKEN"


class SlackConfig(BaseModel):
    enabled: bool = False
    token_env: str = "SLACK_TOKEN"
    channels: list[str] = Field(default_factory=list)


class GitHubConfig(BaseModel):
    base_url: str = "https://api.github.com"
    repos: list[str] = Field(default_factory=list)  # "owner/repo" format
    token_env: str = "GITHUB_TOKEN"


class BitbucketConfig(BaseModel):
    base_url: str = "https://api.bitbucket.org/2.0"
    workspace: str = ""
    repos: list[str] = Field(default_factory=list)  # repo slugs
    token_env: str = "BITBUCKET_TOKEN"


class TeamsConfig(BaseModel):
    enabled: bool = False
    team_id: str = ""
    channels: list[str] = Field(default_factory=list)
    token_env: str = "TEAMS_TOKEN"


class ConnectorsConfig(BaseModel):
    jira: JiraConfig = Field(default_factory=JiraConfig)
    gitlab: GitLabConfig = Field(default_factory=GitLabConfig)
    slack: SlackConfig = Field(default_factory=SlackConfig)
    github: GitHubConfig = Field(default_factory=GitHubConfig)
    bitbucket: BitbucketConfig = Field(default_factory=BitbucketConfig)
    teams: TeamsConfig = Field(default_factory=TeamsConfig)


class TeamMapping(BaseModel):
    repos: list[str] = Field(default_factory=list)
    jira_components: list[str] = Field(default_factory=list)


# Fallback models if API is unreachable (Anthropic model IDs)
FALLBACK_MODELS = [
    "claude-sonnet-4-6",
    "claude-haiku-4-5",
    "claude-opus-4-6",
]

# Models to prioritize at the top of the picker (substring match on model ID)
_PREFERRED_MODEL_PATTERNS = [
    "claude-sonnet",
    "claude-haiku",
    "claude-opus",
]


class LLMConfig(BaseModel):
    provider: str = "anthropic"
    model: str = ""
    model_extract: str = ""
    model_answer: str = ""
    max_context_chars: int = 12000
    redact_patterns: list[str] = Field(default_factory=list)
    api_base: str = "https://api.anthropic.com/v1"
    token_env: str = "ANTHROPIC_API_KEY"


class StorageConfig(BaseModel):
    url: str = "sqlite:///./blamegraph.db"


class WritebackConfig(BaseModel):
    dry_run_default: bool = True


class BlameGraphConfig(BaseModel):
    workspace: str = ""
    connectors: ConnectorsConfig = Field(default_factory=ConnectorsConfig)
    teams: dict[str, TeamMapping] = Field(default_factory=dict)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    writeback: WritebackConfig = Field(default_factory=WritebackConfig)


def load_config(path: Path | None = None) -> BlameGraphConfig:
    """Load and validate configuration from YAML file.

    If no path is given, searches DEFAULT_CONFIG_PATHS in order.
    """
    config_path: Path
    if path is not None:
        config_path = path
    else:
        found: Path | None = None
        for candidate in DEFAULT_CONFIG_PATHS:
            if candidate.exists():
                found = candidate
                break
        if found is None:
            return BlameGraphConfig()
        config_path = found

    if not config_path.exists():
        raise ConfigError(f"Config file not found: {config_path}")

    try:
        raw = yaml.safe_load(config_path.read_text())
    except yaml.YAMLError as exc:
        raise ConfigError(f"Invalid YAML in {config_path}: {exc}") from exc

    if raw is None:
        return BlameGraphConfig()

    resolved = _resolve_env_vars(raw)
    if not isinstance(resolved, dict):
        raise ConfigError("Config must be a YAML mapping")

    # Remap nested redact.patterns to flat redact_patterns for LLMConfig
    llm_raw = resolved.get("llm", {})
    if isinstance(llm_raw, dict) and "redact" in llm_raw:
        redact = llm_raw.pop("redact")
        if isinstance(redact, dict) and "patterns" in redact:
            llm_raw["redact_patterns"] = redact["patterns"]

    return BlameGraphConfig.model_validate(resolved)
