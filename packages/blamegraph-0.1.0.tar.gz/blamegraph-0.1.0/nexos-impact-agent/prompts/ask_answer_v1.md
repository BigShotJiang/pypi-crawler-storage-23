# Prompt Template: ask_answer_v1

## Task
Answer the user question using only the provided context items (tickets, edges, messages).

## Requirements
- Provide a clear answer.
- List dependency chain (if applicable).
- Name likely owners (with confidence).
- Include citations: for each key claim, reference the evidence item id.

## Output
Markdown with sections:
- Answer
- Dependency chain
- Owners
- Evidence (bulleted)
- Next action
