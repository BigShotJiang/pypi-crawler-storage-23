# CLI Spec

## Command overview
- `nia init` — create config + validate connectivity/tokens
- `nia sync` — ingest incremental data (Jira/GitLab/Slack)
- `nia analyze` — build/update graph + owners + risks
- `nia ask "<question>"` — answer with citations
- `nia chain --from MOB-881` — show dependency chain
- `nia draft --ticket MOB-881` — propose ticket comment + links (dry-run)
- `nia apply --draft-id <id>` — apply write-backs (explicit; optional later)
- `nia report --team mobile --since 7d` — markdown report

## Config
- Local file: `./nia.yaml` (recommended) or `~/.nia/config.yaml`
- See: `configs/nia.yaml.example`

Minimal env vars:
```bash
export JIRA_TOKEN=...
export GITLAB_TOKEN=...
export SLACK_TOKEN=...   # optional
```

## Examples

### 1) Sync + analyze (daily)
```bash
nia sync --since 24h
nia analyze
nia report --team mobile --since 24h > report_mobile.md
```

### 2) Ask ad-hoc
```bash
nia ask "is auto-rooting ready on mobile?"
```
Output includes:
- Answer
- Dependency chain
- Owners + status
- Evidence links
- Next action

### 3) Draft dependency comment (dry-run)
```bash
nia draft --ticket MOB-881
```

### 4) Apply (later, behind flag)
```bash
nia apply --draft-id 20260220-001
```
Requires interactive confirmation unless `--yes`.

## Output formatting
- Default: human readable tables
- `--json`: machine-readable output for pipelines
