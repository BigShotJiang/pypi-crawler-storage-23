# Architecture

## High-level
NIA is a pipeline:
1) **Ingest** → 2) **Normalize** → 3) **Index** → 4) **Infer graph** → 5) **Score risks** → 6) **Deliver outputs**

CLI orchestrates steps; optional API wraps the same services.

## Components

### 1. Connectors (ingest)
- Jira/Linear connector: issues, links, fields, comments, changelog
- GitLab connector (self-hosted): PRs, commits, codeowners, CI signals
- Slack connector (opt-in): channel messages + threads

### 2. Normalizer
Converts raw payloads into:
- `Entity`: Ticket, PR, Repo, Team, Person, Service
- `Event`: created/updated/commented/merged/deployed/failed-build/etc
- `TextArtifact`: title/description/comment/message with metadata

### 3. Storage
**Postgres** as source of truth:
- `entities` (id, type, external_id, attributes jsonb)
- `events` (entity_id, ts, kind, payload jsonb)
- `edges` (from_entity, to_entity, type, confidence, evidence jsonb)
- `owners` (entity_id, candidate_owner, score, evidence jsonb, confirmed bool)
- `risk_scores` (entity_id, score, features jsonb, ts)

**Vector store**: pgvector on `text_artifacts` for similarity search.

### 4. Graph inference
Two lanes:
- **Deterministic**: explicit links, status fields, repo→team mapping, CODEOWNERS
- **Probabilistic**: NLP/LLM-assisted extraction + embedding similarity

Outputs edges with:
- edge type: depends_on / blocked_by / related_to / owned_by / impacts
- confidence: 0–1
- evidence: list of pointers (ticket comment IDs, PR IDs, message permalinks)

### 5. Risk engine
Runs heuristics + ML-light scoring:
- staleness, missing owner, cross-team hops, critical path length, SLA breaches

### 6. Delivery
- CLI output (tables + markdown)
- Write-back to Jira/Linear (comments, labels, link suggestions)
- Slack digest (optional)

## LLM usage (guardrails)
LLM is used for:
- extracting candidate dependencies from free text
- summarizing dependency chains into human-readable explanations
- answering “ask” queries with citations

LLM is **not** used for:
- writing back without human-visible draft
- accessing raw secrets/PII
- final authority decisions

## Data flow
1. `nia sync` pulls incremental data → stores raw blobs (optional) + normalized entities/events
2. `nia analyze` updates embeddings + edges + owner candidates + risk scores
3. `nia ask` retrieves relevant nodes/edges/text → produces answer + citations
4. `nia draft` creates a proposed comment/link list (dry-run default)
