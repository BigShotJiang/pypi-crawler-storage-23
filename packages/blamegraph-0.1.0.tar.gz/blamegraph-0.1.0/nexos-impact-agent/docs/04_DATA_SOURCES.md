# Data Sources & Connectors (MVP: Jira + GitLab + Slack)

## Network / VPN assumption (MVP)
NIA runs as a **local CLI on a laptop** that already has VPN access to Jira/GitLab.
No inbound connections required. Everything is outbound API calls.

---

## Jira (self-hosted)
### Needed scopes (least privilege)
- Read: issues, issue links, comments, project metadata, changelog
- Optional write-back (keep OFF for MVP): add comment, add label, create issue links

### Fields to ingest
- key, summary, description, status, assignee, reporter
- labels/components, priority, due date
- issue links (blocks/is blocked by/relates)
- comments + changelog (status transitions)

---

## GitLab self-hosted
### Needed scopes
- Read-only MVP:
  - `read_api`
  - `read_repository`
  - `read_user`
- Optional write-back later:
  - `api` (to post MR notes / issue comments)

### What we ingest
- Merge Requests: title/body, labels, approvals, reviewers
- Commits: refs to ticket keys (e.g., MOB-881)
- Pipelines: statuses, failing jobs (risk signal)
- Repository metadata:
  - CODEOWNERS (owner inference)
  - default branch, recent activity

---

## Slack (opt-in; allowlist channels only)
**MVP policy:** only configured public channels, no DMs.
- messages + threads
- reactions (importance signal)
- message permalinks for evidence

---

## Mapping model: Team ↔ repos ↔ components
Provide a config mapping:
- repo → owning team
- Jira component/label → team
- people → team (optional later)

Example in `configs/nia.yaml.example`.
