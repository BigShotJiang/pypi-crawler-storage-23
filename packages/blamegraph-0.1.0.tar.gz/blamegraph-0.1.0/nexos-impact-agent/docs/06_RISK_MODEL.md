# Risk Model

## The hard truth
If you can’t *name* the blockers, you don’t have a plan — you have hope.

## Risk score
`risk = sigmoid(weighted_sum(features))` mapped to 0–100.

### Features (MVP)
- **Staleness**: days since last meaningful activity
- **No clear owner**: missing assignee + low owner-confidence
- **Cross-team hops**: number of unique teams in dependency chain
- **Criticality**: priority/label (P0/P1) + customer impact flags
- **Unbounded dependency**: depends on ticket without due date or status movement
- **Broken CI**: repeated failing checks on linked PRs
- **Churn**: frequent status flips or reopens

### Levels
- 0–29: Low
- 30–59: Medium
- 60–79: High
- 80–100: Critical

## Blocker detection heuristics
- Ticket marked Blocked with no linked dependency → “Hidden blocker”
- Ticket has phrases like “waiting for”, “blocked by”, “needs API”, “pending” + no explicit link
- PR mentions “TODO after platform change” and ticket exists in other team

## Output requirements
For each risk item:
- Score + level
- “Why” bullets (top 3 features)
- Evidence links
- Suggested action (single next step)
