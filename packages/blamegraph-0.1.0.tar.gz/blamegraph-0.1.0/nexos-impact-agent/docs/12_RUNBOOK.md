# Runbook

## Common ops

### Sync failures
- Check token expiry / scopes
- Check API rate limits
- Re-run with `--verbose` and `--since 72h`

### Bad suggestions
- Inspect evidence list (if evidence is weak → tweak extraction gates)
- Collect feedback via `nia feedback`
- Adjust team mapping config (most common root cause)

### LLM cost spike
- Reduce max_context_chars
- Increase caching TTL
- Switch model tier for extraction vs answering
- Disable Slack ingestion first (high noise)

## Incident response
- If write-back misbehaves: disable apply path (`writeback.enabled=false`)
- Rotate tokens
- Review audit log entries
