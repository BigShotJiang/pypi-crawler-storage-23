# Deployment (MVP: Local CLI inside VPN)

## The hard truth
Shipping this as a server first is how you die on security reviews.
MVP runs **locally** where VPN already exists.

## Modes
### 1) Local CLI (recommended MVP)
- Run on laptop inside VPN
- Storage: SQLite (`nia.db`) for MVP
- Scheduling: cron / launchd / Task Scheduler (optional)

Suggested daily:
```bash
nia sync --since 24h
nia analyze
nia report --team mobile --since 24h > report_mobile.md
```

### 2) Internal runner (next)
- Small VM inside VPN
- Postgres + pgvector recommended
- Optional Slack digest

## Observability
- Structured logs to stdout
- Optional file log `~/.nia/logs/*.jsonl`
- Metrics (later): sync duration, edges created, LLM cost

## Backups
- If SQLite: back up `nia.db`
- If Postgres: standard snapshots
