# Roadmap

## Phase 0 (3–7 days): CLI MVP
- Jira + GitHub connectors
- Explicit dependency graph + simple inference
- Owner inference via config + CODEOWNERS
- `ask`, `chain`, `report`, `draft` (dry-run only)

## Phase 1 (2–4 weeks): Useful automation
- Linear support
- Slack (channel allowlist)
- Apply write-backs behind feature flag
- Risk scoring v1 + weekly trend report
- Feedback loop to improve ranking

## Phase 2 (1–2 months): Cross-team “control tower”
- Dashboard (read-only)
- Alerts to Slack (digest + threshold-based)
- Service catalog integration
- Incident mode: “what changed since last deploy?”

## Phase 3: Predictive planning
- Critical path forecasting
- SLA / due-date probability
- What-if simulations (“if PLAT-312 slips 1 week…”)

## Phase 4: Org-level intelligence
- Knowledge graph across code, tickets, docs
- Copilot for EM/PM: “create a coordination plan for release X”
