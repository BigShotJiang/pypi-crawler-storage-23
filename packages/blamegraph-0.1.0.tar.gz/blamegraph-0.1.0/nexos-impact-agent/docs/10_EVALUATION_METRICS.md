# Evaluation & Metrics

## Product KPIs (MVP)
- % of blocked tickets with explicit dependency links
- Median time from “blocked” to “dependency created”
- Median time-to-unblock for cross-team blockers
- Number of “silent waits” detected per week (should go down over time)
- Human acceptance rate of drafts (apply vs reject)

## Model/Inference metrics
- Precision/recall (sampled) for dependency suggestions
- Owner inference accuracy (top-1, top-3)
- Risk calibration (high risk correlates with late or escalated outcomes)

## Quality loop
- `nia feedback --accept/--reject --reason` on drafts
- Store feedback to tune heuristics and re-rankers
