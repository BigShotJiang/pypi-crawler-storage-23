# Dependency & Ownership Model

## Entity types
- Ticket (issue)
- PR
- Repo
- Service (optional later)
- Team
- Person

## Edge types (core)
- `blocks` (A blocks B)
- `depends_on` (A depends on B)  — inverse of blocks
- `related_to` (weak relationship)
- `impacts` (A affects B’s outcome; broader than depends)
- `owned_by` (entity → team/person)

## Evidence schema (required)
Every inferred edge includes:
- `evidence[]`: { source_type, source_id, url, snippet, ts }
- `method`: explicit | heuristic | embedding | llm_extract
- `confidence`: 0..1

## Owner inference (ranked)
Signals, in order:
1) Explicit: ticket component/team field
2) CODEOWNERS for touched files in linked PRs
3) Historical: who merged PRs / commented on similar tickets
4) Mentioned: @mentions in tickets/chats
5) Repo-to-team mapping fallback

Store:
- candidates with scores
- `confirmed_owner` (manual override) takes precedence

## Dependency inference (MVP)
Deterministic rules:
- If ticket link type is “blocks/is blocked by” → create edge with confidence 1.0
- If ticket is in status “Blocked” and has referenced ticket keys in description/comments → edge 0.7
- If PR references ticket key and touches files owned by another team → cross-team impact edge 0.6

LLM-assisted extraction (bounded):
- Input: a single ticket’s description + latest N comments (after redaction)
- Output: list of candidate dependencies with rationale and quoted snippets (<= 200 chars each)
- Gate: only accept if it references concrete artifacts (ticket key / repo / API name)

## Output format (human)
For any chain, produce:
- Chain: MOB-881 → PLAT-312 → SEC-144
- Owners: Mobile → Platform → Security
- Status summary: [In Progress | Blocked | Done]
- Next action: “Assign owner to PLAT-312, add due date, confirm API contract”
