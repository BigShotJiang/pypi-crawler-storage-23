# Requirements

## Functional requirements

### R1. Ingest & normalize signals
- R1.1 Pull tickets (issues) from Jira/Linear with incremental sync
- R1.2 Pull PRs/commits from GitLab (self-hosted) (repo-scoped)
- R1.3 Optional: pull Slack messages from configured channels
- R1.4 Normalize into a common event model (see `docs/03_ARCHITECTURE.md`)

### R2. Build dependency graph
- R2.1 Identify explicit dependencies (linked issues, “blocked by”, “depends on” fields)
- R2.2 Infer implicit dependencies (NLP over titles/descriptions/comments + code signals)
- R2.3 Maintain graph edges with confidence + evidence (citations)

### R3. Owner inference
- R3.1 Use ticket assignee/component + repo ownership (CODEOWNERS) + historical activity
- R3.2 Provide ranked owners with confidence and rationale
- R3.3 Allow overrides (human confirmed owner stored)

### R4. Risk & blocker detection
- R4.1 Detect “waiting” patterns (no activity + mentions of dependency + status stagnation)
- R4.2 Detect cross-team critical chains (edges crossing team boundaries)
- R4.3 Score risk with explainable features (see `docs/06_RISK_MODEL.md`)

### R5. Actionable outputs
- R5.1 Draft a dependency comment for a ticket with suggested owner mention
- R5.2 Generate “Blockers & Risks” report per team
- R5.3 Answer natural-language questions with citations:
  - “Is X ready?”
  - “What’s blocking Y?”
  - “What tickets depend on Z?”

### R6. CLI-first UX
- R6.1 `nia sync` (ingest)
- R6.2 `nia analyze` (build graph + risks)
- R6.3 `nia ask "..."` (Q&A with citations)
- R6.4 `nia draft --ticket XYZ` (draft comment/link suggestions)
- R6.5 `nia report --team mobile --since 7d`

### R7. Auditability
- R7.1 Every inference stores evidence pointers (source IDs, URLs, timestamps)
- R7.2 Every LLM call is logged (prompt template ID, inputs hash, model, cost)
- R7.3 Every write-back action is dry-run by default

## Non-functional requirements

### NFR1. Security & privacy
- Least privilege tokens
- PII/secret redaction before LLM
- Tenant separation (workspace/org) if multi-tenant later

### NFR2. Reliability
- Incremental sync with backfill
- Idempotent processing
- Retry with exponential backoff

### NFR3. Performance (MVP targets)
- Sync: 10k tickets + 20k PR events within < 30 minutes on a small instance
- Ask: < 5 seconds for typical queries (excluding LLM latency)
- Analyze: incremental runs complete in minutes

### NFR4. Explainability
- Always show: confidence + top evidence items
- Never claim certainty without evidence

### NFR5. Extensibility
- New connector should be addable with minimal coupling
- New graph edge type should not require schema rewrite
