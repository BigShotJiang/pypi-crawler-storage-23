# Security & Privacy

## Principles
- Least privilege connectors
- Redact before LLM
- Keep an immutable audit log
- Default to dry-run for write-back

## Data handling
- Store normalized metadata + minimal text for embeddings (configurable)
- Option: store raw payloads encrypted-at-rest (disabled by default)

## Redaction
- Regex-based secret detection (keys, tokens, private keys)
- Optional: integrate with secrets scanner (gitleaks-like) for text artifacts
- PII policy: avoid DMs; if chat enabled, only public channels + allowlist keywords

## LLM safety
- Prompt templates are versioned + reviewed
- Constrain extraction tasks (structured JSON output)
- Never send more than configured char limit
- Strip URLs with auth tokens

## Audit logging
Record:
- who ran what command (user id)
- connector access timestamps
- LLM calls: template_id, model, token usage, cost
- write-backs: before/after + external IDs

## VPN / local-run implication (MVP)
- No inbound ports, no external exposure
- Tokens stored in env vars (not in config file)
- Local data stored in `nia.db` (SQLite) — treat as sensitive; encrypt disk or use OS vault if required
