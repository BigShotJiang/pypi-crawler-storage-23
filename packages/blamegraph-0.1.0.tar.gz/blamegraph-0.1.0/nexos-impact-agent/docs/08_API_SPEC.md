# API Spec (Optional)

If you want a thin service wrapper around the CLI engine.

## Endpoints
- `POST /sync`  { since: "24h" }
- `POST /analyze`
- `GET /ask?q=...`
- `GET /tickets/{key}/chain`
- `POST /tickets/{key}/draft`
- `POST /drafts/{id}/apply`

## Responses
Always include:
- `answer` (string)
- `artifacts` (nodes/edges referenced)
- `citations[]` (url + snippet + source_type)
- `confidence`

## Auth
- Internal: service-to-service (Nexos standard)
- User-level: optional later via OAuth

## Rate limiting
- protect upstream tools (Jira, GitHub, Slack)
