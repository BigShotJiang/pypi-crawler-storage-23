# Product Brief — Nexos Impact Agent (NIA)

**One-liner:** Cross-team dependency & risk analyst that continuously converts messy signals into an explicit ownership + dependency graph.

## The hard truth
Most “execution problems” are just **unseen dependencies** and **unclear ownership**. Your teams are not slow — they’re blindfolded.

## Goal
Make cross-team impact obvious within minutes, not weeks.

## Non-goals (for MVP)
- Perfect correctness (we aim for *usefully correct* with human confirmation)
- Replacing PMs / EMs (we augment, we don’t “decide”)
- Deep forecasting (later phase)

## Users
- Engineering Managers (primary)
- Tech Leads / Staff Engineers
- PMs / TPMs
- On-call / Incident commanders (secondary)

## Primary jobs-to-be-done
1. **Ask:** “Is X ready?” → get dependency chain + owners + status + next action.
2. **Detect:** “We’re blocked and didn’t notice.” → alerts + drafted ticket links.
3. **Draft:** “Connect these teams.” → suggested dependency comments / linked issues.
4. **Explain:** “Why is this late?” → evidence-based narrative with traceable sources.

## Inputs
- Tickets: Jira / Linear (status, assignees, labels, components, linked issues, comments)
- Code: GitHub / GitLab (PRs, commits, CODEOWNERS, review activity, build failures)
- Chat: Slack (opt-in; messages in specific channels; no DMs for MVP unless explicitly allowed)
- Docs: Confluence / Notion (optional later)

## Outputs
- Ticket comments: “Possible dependency: … Owner: … Evidence: …”
- Daily/weekly reports: per team + cross-team top risks
- On-demand Q&A: “ask” mode with citations
- Optional: dashboard later

## Success definition (MVP)
- 1) **Reduced silent waiting**: fewer tickets sitting “Blocked” without linked dependency
- 2) **Higher dependency hygiene**: more explicit links, owners, due dates
- 3) **Faster resolution**: time-to-unblock down

## Constraints
- Must work across teams and repos
- Must be low-friction (CLI first, minimal permissions)
- Must be safe (no secrets leakage, least privilege, audit trail)
