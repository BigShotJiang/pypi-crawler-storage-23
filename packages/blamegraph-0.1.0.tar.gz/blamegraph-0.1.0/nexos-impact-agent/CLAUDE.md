# NIA — Nexos Impact Agent

Cross-team dependency & risk analyst that converts messy signals (Jira, GitLab, Slack) into an explicit ownership + dependency graph.

Pipeline: **Ingest -> Normalize -> Index -> Infer -> Score -> Deliver**

---

## Architecture (8 layers)

| Layer | Purpose | Key modules |
|-------|---------|-------------|
| Connectors | Pull data from Jira, GitLab, Slack | `src/nia/connectors/` |
| Normalizer | Raw payloads -> Entity / Event / TextArtifact | `src/nia/normalizer.py` |
| Storage | Persist entities, edges, owners, risk scores | `src/nia/storage/` |
| Graph Inference | Deterministic + LLM-assisted edge creation | `src/nia/graph/` |
| Risk Engine | Sigmoid scoring, blocker detection | `src/nia/risk/` |
| LLM | Redaction, prompt templates, audit | `src/nia/llm/` |
| CLI | Click commands: sync, analyze, ask, chain, draft, report | `src/nia/cli/` |
| Delivery | Write-back to Jira, Slack digest, markdown reports | `src/nia/delivery/` |

## Project layout (target)

```
nexos-impact-agent/
  CLAUDE.md              # <-- this file
  pyproject.toml
  nia.yaml               # local config (gitignored)
  src/nia/
    __init__.py
    models.py            # Pydantic v2 models: Entity, Edge, Event, RiskScore, Owner
    config.py            # NiaConfig (Pydantic Settings, loads nia.yaml + env vars)
    connectors/
      __init__.py
      protocol.py        # ConnectorProtocol (sync, health_check)
      jira.py
      gitlab.py
      slack.py
    normalizer.py
    storage/
      __init__.py
      protocol.py        # StorageProtocol
      sqlite.py          # MVP implementation
    graph/
      __init__.py
      inference.py       # deterministic rules
      llm_extract.py     # LLM-assisted dependency extraction
      traversal.py       # chain walk, BFS/DFS, cycle detection
    risk/
      __init__.py
      scorer.py          # sigmoid + features
      detector.py        # blocker heuristics
    llm/
      __init__.py
      client.py          # LLMClient Protocol + implementation
      redactor.py        # regex-based secret/PII stripping
      audit.py           # JSONL logger for LLM calls
    cli/
      __init__.py
      main.py            # Click group + commands
      formatters.py      # rich tables, markdown, JSON output
    delivery/
      __init__.py
      jira_writer.py
      slack_digest.py
      report.py
  tests/
    conftest.py          # shared fixtures
    fixtures/            # JSON fixture files
    test_connectors/
    test_normalizer.py
    test_storage.py
    test_graph/
    test_risk/
    test_llm/
    test_cli/
  docs/                  # existing documentation (13 files)
  prompts/               # existing prompt templates
  configs/               # config examples
```

## Tech stack

- **Python**: 3.11+
- **CLI**: Click
- **HTTP**: httpx (async)
- **Validation**: Pydantic v2
- **Storage MVP**: SQLite (via sqlite3 stdlib)
- **Storage later**: PostgreSQL + pgvector
- **Output**: rich (tables, panels, markdown)
- **Packaging**: uv + pyproject.toml
- **Linting**: ruff (check + format)
- **Types**: mypy (strict)
- **Testing**: pytest + pytest-cov + pytest-asyncio

## Code conventions

- Type hints on all public functions and method signatures
- Use `dataclasses` for internal DTOs, `Pydantic BaseModel` for external boundaries (config, API, serialization)
- Use `Protocol` classes for dependency injection interfaces (connectors, storage, LLM client)
- Google-style docstrings on public APIs only
- Formatting: `ruff format` (black-compatible), imports sorted by `ruff check --select I`
- Naming: `snake_case` everywhere, `UPPER_CASE` for constants, `PascalCase` for classes
- No `print()` — use `logging` or `rich.console` for output
- Prefer explicit over magic: no metaclasses, no dynamic attribute creation

## Security rules (CRITICAL)

1. **Tokens in env vars only** — never in config files, never in code, never in tests
2. **Redact before LLM** — run `redactor.py` on ALL text before sending to any LLM endpoint
3. **Dry-run by default** — `nia draft` and `nia apply` require explicit `--yes` flag for write-back
4. **Read-only scopes** — connectors use minimal permissions; write-back is a separate opt-in
5. **No secrets in tests** — use fixture data; mock all HTTP; never call real APIs in CI
6. **Audit all LLM calls** — log template_id, model, token count, cost to JSONL
7. **Slack: allowlisted channels only** — never ingest DMs, never post to non-allowlisted channels
8. **Strip auth from URLs** — remove tokens/keys from any URL before storing or logging

## Dev commands

```bash
# Install dependencies
uv sync

# Run tests
pytest tests/ -v

# Run tests with coverage
pytest tests/ --cov=nia --cov-report=term-missing

# Lint
ruff check src/ tests/

# Format
ruff format src/ tests/

# Type check
mypy src/nia/

# Run CLI
python -m nia --help
```

## Testing patterns

- **Unit tests**: mock all external dependencies (HTTP, DB, LLM). Test one module at a time.
- **Integration tests**: use SQLite in-memory (`":memory:"`) for storage tests.
- **Fixtures**: JSON files in `tests/fixtures/` representing API responses, normalized entities, etc.
- **Factory functions** in `conftest.py`: `make_ticket()`, `make_edge()`, `make_risk_score()` — return valid model instances with sensible defaults.
- **No network calls in tests** — use `httpx.MockTransport` or `respx` for HTTP mocking.
- **Naming**: `test_{module}_{scenario}_{expected}` e.g. `test_scorer_stale_ticket_high_risk`

## Documentation map

| Doc | Topic |
|-----|-------|
| `docs/01_PRODUCT_BRIEF.md` | What NIA is, users, jobs-to-be-done |
| `docs/02_REQUIREMENTS.md` | Functional + non-functional requirements |
| `docs/03_ARCHITECTURE.md` | Pipeline, components, data flow |
| `docs/04_DATA_SOURCES.md` | Jira/GitLab/Slack API details, scopes, fields |
| `docs/05_DEPENDENCY_MODEL.md` | Entity/edge types, evidence schema, owner inference |
| `docs/06_RISK_MODEL.md` | Sigmoid scoring, features, levels, blocker detection |
| `docs/07_CLI_SPEC.md` | Commands, flags, output formatting |
| `docs/08_API_SPEC.md` | Optional REST API (not Phase 0) |
| `docs/09_SECURITY_PRIVACY.md` | Redaction, audit, least privilege |
| `docs/10_EVALUATION_METRICS.md` | KPIs, precision/recall, feedback loop |
| `docs/11_DEPLOYMENT.md` | Local CLI (MVP), internal runner (later) |
| `docs/12_RUNBOOK.md` | Troubleshooting sync, LLM cost, incidents |
| `docs/13_ROADMAP.md` | Phase 0-4 timeline |

## Prompt templates

Templates live in `prompts/`. Conventions:
- File naming: `{purpose}_v{version}.md` (e.g. `dependency_extract_v1.md`)
- Structure: **System** (role) / **Task** (what to do) / **Output** (JSON schema or markdown format) / **Rules** (constraints)
- Always version templates — never overwrite, create `_v2` instead
- Existing templates:
  - `prompts/dependency_extract_v1.md` — extract candidate dependencies from ticket text
  - `prompts/ask_answer_v1.md` — answer user questions with citations

## Config (`nia.yaml`)

Example in `configs/nia.yaml.example`. Key sections:
- `jira`: base_url, project_keys, token via `${JIRA_TOKEN}`
- `gitlab`: base_url, project_ids, token via `${GITLAB_TOKEN}`
- `slack`: enabled, channel_allowlist, token via `${SLACK_TOKEN}`
- `teams`: team-name -> repos + jira_components mapping
- `llm`: provider, model, max_context_chars
- `storage`: type (sqlite/postgres), path/connection_string

Token resolution: `${ENV_VAR}` syntax in YAML values is resolved at config load time from environment variables.

## What NOT to do

- **No server in Phase 0** — NIA is a CLI tool. Do not build REST/gRPC endpoints yet.
- **No tokens in config files** — use `${ENV_VAR}` references, resolved at runtime.
- **No raw text to LLM** — always run through `redactor.py` first.
- **No write-back without dry-run** — `draft` shows what would happen; `apply` requires `--yes`.
- **No DM ingestion** — Slack connector reads only allowlisted public channels.
- **No unbounded LLM context** — enforce `max_context_chars` from config.
- **No dynamic imports or plugin systems** — keep it simple, explicit imports only.
