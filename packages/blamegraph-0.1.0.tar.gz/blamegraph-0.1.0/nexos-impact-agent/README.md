# Nexos Impact Agent (NIA)

Agent for cross-team impact / correlation analysis.

**MVP (your setup):**
- Jira **self-hosted** (reachable via VPN)
- GitLab **self-hosted** (reachable via VPN)
- Slack (optional; **channel allowlist** only)
- Runs as a **local CLI on a laptop** inside VPN (no server required for MVP)

## What it does
NIA scans tickets + code + (optionally) chat, detects cross-team dependencies, suggests owners, and highlights blockers/risks — with evidence.

Example:
> “Is auto-rooting ready on mobile?”  
NIA: “No — Mobile is blocked on Platform API. See ticket **PLAT-312**. Chain: **MOB-881 → PLAT-312 → SEC-144**. Next action: ping @platform-owner, add due date, confirm API contract.”

## Why this exists
The *real schedule* is the dependency graph. Today it’s implicit and split across tools.
NIA makes it explicit, continuously.

## Quick start (local CLI)
1) Copy config:
```bash
cp configs/nia.yaml.example nia.yaml
```
2) Export tokens:
```bash
export JIRA_TOKEN=...
export GITLAB_TOKEN=...
# Optional:
export SLACK_TOKEN=...
```
3) Run:
```bash
nia sync --since 24h
nia analyze
nia ask "is auto-rooting ready on mobile?"
nia report --team mobile --since 7d > report_mobile.md
nia draft --ticket MOB-881
```

## Docs (A–Z scope)
- [Product brief](docs/01_PRODUCT_BRIEF.md)
- [Requirements](docs/02_REQUIREMENTS.md)
- [Architecture](docs/03_ARCHITECTURE.md)
- [Data sources & connectors](docs/04_DATA_SOURCES.md)
- [Dependency & ownership model](docs/05_DEPENDENCY_MODEL.md)
- [Risk scoring](docs/06_RISK_MODEL.md)
- [CLI spec](docs/07_CLI_SPEC.md)
- [API spec (optional)](docs/08_API_SPEC.md)
- [Security & privacy](docs/09_SECURITY_PRIVACY.md)
- [Evaluation & metrics](docs/10_EVALUATION_METRICS.md)
- [Deployment (local/VPN)](docs/11_DEPLOYMENT.md)
- [Runbook](docs/12_RUNBOOK.md)
- [Roadmap](docs/13_ROADMAP.md)

**Date:** 2026-02-20
