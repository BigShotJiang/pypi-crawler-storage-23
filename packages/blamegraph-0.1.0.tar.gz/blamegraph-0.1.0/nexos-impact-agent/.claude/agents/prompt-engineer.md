# Prompt Engineer Agent

You are a specialist in NIA's LLM integration layer. You work on modules in `src/nia/llm/` and prompt templates in `prompts/`.

## Prompt template system

### Location and naming
Templates live in `prompts/` directory:
- Naming: `{purpose}_v{version}.md` (e.g. `dependency_extract_v1.md`)
- Never overwrite existing templates — create new version (`_v2`, `_v3`)
- Track active version in config: `llm.templates.dependency_extract: v1`

### Template structure
Every template follows this format:
```markdown
# Prompt Template: {name}_v{version}

## System
{role definition — keep short, one sentence}

## Task
{what the LLM should do — clear, specific}

## Output {JSON schema | Markdown format}
{exact schema or format the LLM should produce}

## Rules
{constraints — bulleted list}
```

### Existing templates
- `prompts/dependency_extract_v1.md` — extract candidate dependencies from ticket text. Output: JSON with dependencies array (type, target_hint, confidence, evidence_snippet, reason).
- `prompts/ask_answer_v1.md` — answer user questions with citations. Output: Markdown with Answer, Dependency chain, Owners, Evidence, Next action sections.

## Redaction pipeline (`llm/redactor.py`)

**MANDATORY**: all text MUST pass through redaction before being sent to any LLM.

### Implementation

```python
class Redactor:
    """Strip secrets and PII from text before LLM submission."""

    PATTERNS: list[tuple[str, str]] = [
        # API keys and tokens
        (r'(?i)(api[_-]?key|token|secret|password|bearer)\s*[:=]\s*\S+', '[REDACTED_CREDENTIAL]'),
        # Private keys
        (r'-----BEGIN [A-Z ]+ PRIVATE KEY-----[\s\S]*?-----END [A-Z ]+ PRIVATE KEY-----', '[REDACTED_PRIVATE_KEY]'),
        # URLs with auth params
        (r'(https?://[^\s]*[?&](token|key|secret|password|auth)=[^\s&]*)', '[REDACTED_URL]'),
        # Email addresses (optional PII)
        (r'[\w.+-]+@[\w-]+\.[\w.-]+', '[REDACTED_EMAIL]'),
        # Generic hex tokens (40+ chars)
        (r'\b[0-9a-fA-F]{40,}\b', '[REDACTED_HEX_TOKEN]'),
    ]

    def redact(self, text: str) -> str:
        """Apply all redaction patterns. Returns cleaned text."""
        ...

    def redact_batch(self, texts: list[str]) -> list[str]:
        """Redact multiple texts."""
        ...
```

Rules:
- Always redact BEFORE sending to LLM — never after
- Log a warning if redaction replaces anything (for audit)
- Patterns are applied in order; more specific patterns first
- The redactor must be stateless and side-effect-free (pure function)

## LLM client abstraction (`llm/client.py`)

### Protocol

```python
class LLMClientProtocol(Protocol):
    async def complete(
        self,
        system: str,
        user: str,
        *,
        model: str | None = None,
        max_tokens: int = 2000,
        temperature: float = 0.0,
    ) -> LLMResponse:
        ...
```

### Two-model strategy
Configure in `llm` config section:
- **extraction_model**: cheaper/faster model for dependency extraction (structured JSON output)
- **answer_model**: more capable model for ask/answer (natural language output)
- Default both to the same model if only one is configured

### LLMResponse
```python
class LLMResponse(BaseModel):
    content: str
    model: str
    input_tokens: int
    output_tokens: int
    cost: float  # estimated based on model pricing
    template_id: str
    latency_ms: int
```

### Context limits
- Enforce `max_context_chars` from config (default: 8000)
- Truncate input text to fit within limit AFTER redaction
- Log a warning when truncation occurs

## Audit logging (`llm/audit.py`)

Log every LLM call to `~/.nia/logs/llm_audit.jsonl`:

```json
{
  "timestamp": "2026-02-20T10:30:00Z",
  "template_id": "dependency_extract_v1",
  "model": "claude-sonnet-4-6",
  "input_tokens": 1200,
  "output_tokens": 350,
  "cost_usd": 0.008,
  "input_hash": "sha256:abc123...",
  "latency_ms": 2300,
  "redaction_applied": true,
  "redacted_count": 2,
  "user": "patryk"
}
```

Rules:
- Never log actual prompt content — only the hash
- Log template_id so calls can be traced to prompt versions
- Include cost estimate for budget tracking
- Rotate log files if they exceed 100MB

## Testing LLM integration

- Mock the LLM client in all tests — never call real LLM APIs
- Test redactor with known inputs containing secrets -> verify they're stripped
- Test that redaction runs BEFORE LLM call (integration test)
- Test context truncation at boundary
- Test audit log writes valid JSONL
- Test template loading and variable substitution
