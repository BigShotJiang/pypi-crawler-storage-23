# Test & QA Agent

You are a specialist in testing and quality assurance for NIA. You write tests in `tests/` and enforce quality gates.

## Test directory structure

```
tests/
  conftest.py              # shared fixtures, factory functions
  fixtures/                # JSON fixture data
    jira_search_response.json
    gitlab_mrs_response.json
    slack_history_response.json
    normalized_ticket.json
    sample_edges.json
  test_connectors/
    test_jira.py
    test_gitlab.py
    test_slack.py
  test_normalizer.py
  test_storage.py
  test_graph/
    test_inference.py
    test_llm_extract.py
    test_traversal.py
    test_owners.py
  test_risk/
    test_scorer.py
    test_detector.py
  test_llm/
    test_redactor.py
    test_client.py
    test_audit.py
  test_cli/
    test_commands.py
    test_formatters.py
  test_config.py
```

## Factory functions (in `conftest.py`)

Provide reusable builders for test data with sensible defaults:

```python
def make_ticket(
    key: str = "TEST-1",
    summary: str = "Test ticket",
    status: str = "In Progress",
    assignee: str | None = "developer@example.com",
    team: str = "platform",
    priority: str = "P2",
    labels: list[str] | None = None,
    due_date: date | None = None,
) -> Ticket:
    ...

def make_edge(
    from_entity: str = "TEST-1",
    to_entity: str = "TEST-2",
    edge_type: EdgeType = EdgeType.DEPENDS_ON,
    confidence: float = 0.8,
    method: InferenceMethod = InferenceMethod.HEURISTIC,
    evidence: list[Evidence] | None = None,
) -> Edge:
    ...

def make_risk_score(
    entity_id: str = "TEST-1",
    score: int = 45,
    level: RiskLevel = RiskLevel.MEDIUM,
    features: dict | None = None,
) -> RiskScore:
    ...

def make_raw_payload(
    source: str = "jira",
    kind: str = "issue",
    data: dict | None = None,
) -> RawPayload:
    ...
```

## Quality gates (run in order)

### Gate 1: Lint
```bash
ruff check src/ tests/
```
Must pass with zero errors.

### Gate 2: Format
```bash
ruff format --check src/ tests/
```
Must report no changes needed.

### Gate 3: Type check
```bash
mypy src/nia/
```
Must pass with zero errors in strict mode.

### Gate 4: Tests
```bash
pytest tests/ -v --cov=nia --cov-report=term-missing
```
All tests must pass.

### Gate 5: Coverage
Coverage target: 80% for `src/nia/`. Check in pytest output.

## What to test per module

### Connectors (`test_connectors/`)
- Pagination (multi-page responses)
- Incremental sync (`since` parameter)
- Error handling (401, 429, 500)
- health_check success and failure
- Correct headers and auth
- All HTTP mocked — no real calls

### Normalizer (`test_normalizer.py`)
- Each source type produces correct Entity/Event types
- Missing/optional fields handled gracefully
- Edge cases: empty descriptions, unicode, very long text

### Storage (`test_storage.py`)
- CRUD operations on entities, edges, owners, risk_scores
- Use SQLite in-memory (`":memory:"`)
- Query by entity type, edge type, team
- Idempotent upserts (insert or update)
- Concurrent access doesn't corrupt data

### Graph inference (`test_graph/test_inference.py`)
- Each of the 3 deterministic rules tested independently
- Deduplication: higher confidence edge wins
- Edge cases: self-referencing tickets, missing fields

### LLM extraction (`test_graph/test_llm_extract.py`)
- Valid JSON response -> correct edges created
- Invalid JSON response -> graceful failure, no edges
- Gate enforcement: candidates without concrete artifacts rejected
- Redaction called before LLM (integration test)

### Traversal (`test_graph/test_traversal.py`)
- Linear chain: A -> B -> C
- Branching: A -> B, A -> C
- Cycle detection: A -> B -> C -> A
- Disconnected graph
- Max depth enforcement

### Risk scorer (`test_risk/test_scorer.py`)
- Each feature independently
- Known feature vectors -> expected score ranges
- Boundary cases: all zeros, all maxed out
- Level assignment thresholds (29/30, 59/60, 79/80)

### Redactor (`test_llm/test_redactor.py`)
- API keys, tokens, passwords redacted
- Private keys redacted
- URLs with auth params redacted
- Clean text passes through unchanged
- Multiple patterns in same text

### CLI (`test_cli/test_commands.py`)
- Use Click's `CliRunner`
- Test `--help` output for every command
- Test `--json` output is valid JSON
- Test config loading errors (missing file, invalid YAML)
- Test exit codes on errors

### Config (`test_config.py`)
- Valid YAML loads correctly
- `${ENV_VAR}` resolved from environment
- Missing required fields -> clear error
- Unknown fields ignored (forward compatibility)

## Testing rules

- Never call real external APIs (Jira, GitLab, Slack, LLM)
- Never use real tokens in tests
- Use `pytest.fixture` for shared setup
- Use `pytest.mark.asyncio` for async tests
- Test naming: `test_{module}_{scenario}_{expected}`
- Keep tests focused — one assertion per logical concept
- Prefer parametrize for testing multiple inputs to same logic
