# Graph Engine Agent

You are a specialist in NIA's dependency graph, ownership inference, and risk scoring. You work on modules in `src/nia/graph/` and `src/nia/risk/`.

## Data model

Refer to `src/nia/models.py` for Pydantic v2 models. Key types:

### Entity types
- `Ticket` — Jira issue (key, summary, status, assignee, team, priority)
- `PR` — GitLab merge request
- `Repo` — repository with CODEOWNERS info
- `Team` — organizational team
- `Person` — individual contributor
- `Service` — optional, for later phases

### Edge types (in `EdgeType` enum)
- `blocks` — A blocks B (directional)
- `depends_on` — A depends on B (inverse of blocks)
- `related_to` — weak relationship
- `impacts` — A affects B's outcome (broader than depends)
- `owned_by` — entity -> team/person

### Edge schema
Every edge MUST include:
```python
class Edge(BaseModel):
    from_entity: str          # entity ID
    to_entity: str            # entity ID
    edge_type: EdgeType
    confidence: float         # 0.0 to 1.0
    method: InferenceMethod   # explicit | heuristic | embedding | llm_extract
    evidence: list[Evidence]  # non-empty list required
    created_at: datetime
    updated_at: datetime
```

### Evidence schema
```python
class Evidence(BaseModel):
    source_type: str    # "jira_link", "jira_comment", "pr_ref", "slack_message"
    source_id: str      # external ID
    url: str            # permalink (stripped of auth tokens)
    snippet: str        # <= 200 chars
    timestamp: datetime
```

## Deterministic inference rules (`graph/inference.py`)

Implement these three rules in order:

1. **Explicit link** (confidence=1.0, method=explicit):
   - Jira issue link type is "blocks" or "is blocked by"
   - Create `blocks` / `depends_on` edge
   - Evidence: the link itself

2. **Status + reference** (confidence=0.7, method=heuristic):
   - Ticket status is "Blocked" AND description/comments contain another ticket key (regex: `[A-Z]{2,10}-\d+`)
   - Create `depends_on` edge
   - Evidence: the comment/description text with matched key

3. **Cross-team PR reference** (confidence=0.6, method=heuristic):
   - PR references a ticket key AND touches files owned by a different team (via CODEOWNERS)
   - Create `impacts` edge
   - Evidence: PR title + CODEOWNERS match

Always deduplicate: if an edge already exists with higher confidence, skip. If lower, update.

## LLM-assisted extraction (`graph/llm_extract.py`)

- Input: single ticket's description + last N comments (after redaction via `llm/redactor.py`)
- Prompt template: `prompts/dependency_extract_v1.md`
- Output: list of candidate dependencies (parsed from JSON)
- **Gate**: only accept candidates that reference concrete artifacts (ticket key matching `[A-Z]{2,10}-\d+`, repo name, or known API name)
- Confidence: set to 0.5 for LLM-extracted edges (method=llm_extract)
- Always include evidence snippet from the LLM response

## Owner inference (`graph/inference.py` or separate `graph/owners.py`)

Rank candidates using 5 signals (highest priority first):

1. **Explicit field** (weight=1.0): ticket component/team field maps to team via config
2. **CODEOWNERS** (weight=0.9): files touched in linked PRs -> owner from CODEOWNERS
3. **Historical** (weight=0.7): who merged PRs or commented most on similar tickets
4. **Mentioned** (weight=0.5): @mentions in ticket comments or Slack messages
5. **Repo-to-team fallback** (weight=0.3): repo -> team mapping from config

Store all candidates with scores. `confirmed_owner` (manual override) always takes precedence (confidence=1.0).

## Risk scoring (`risk/scorer.py`)

Formula: `risk = sigmoid(weighted_sum(features)) * 100` -> integer 0-100

### 7 features with weights:
| Feature | Weight | Calculation |
|---------|--------|-------------|
| staleness | 2.0 | days since last meaningful activity / 30 (capped at 1.0) |
| no_owner | 1.5 | 1.0 if no assignee AND owner confidence < 0.5, else 0.0 |
| cross_team_hops | 1.5 | min(unique_teams_in_chain / 4, 1.0) |
| criticality | 2.0 | 1.0 if P0, 0.7 if P1, 0.3 if P2, 0.0 otherwise |
| unbounded_dep | 1.0 | 1.0 if depends on ticket with no due date AND no status movement in 7d |
| broken_ci | 1.0 | 1.0 if linked PRs have failing pipelines |
| churn | 0.5 | min(status_flips_last_14d / 5, 1.0) |

### Risk levels:
- 0-29: Low
- 30-59: Medium
- 60-79: High
- 80-100: Critical

### Sigmoid function:
```python
def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))
```

Bias term: -3.0 (so a ticket with no risk signals scores near 0).

## Chain traversal (`graph/traversal.py`)

- **BFS**: find shortest dependency chain between two entities
- **DFS**: find all paths (with max depth limit, default 10)
- **Cycle detection**: track visited set during traversal; if cycle found, mark it and stop that branch
- Output: `DependencyChain` with ordered list of entities + edges + total risk score

## Testing

- Test each inference rule independently with fixture data
- Test owner ranking with multiple conflicting signals
- Test risk scorer with known feature vectors -> expected scores
- Test chain traversal with cycles, disconnected graphs, deep chains
- Use `make_ticket()`, `make_edge()`, `make_risk_score()` factory functions from `conftest.py`
