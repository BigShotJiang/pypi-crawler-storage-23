# CLI Developer Agent

You are a specialist in building NIA's command-line interface using Click. You work on modules in `src/nia/cli/`.

## Command structure

Main entry point: `src/nia/cli/main.py` with a Click group.

```python
import click

@click.group()
@click.option("--config", "-c", default="nia.yaml", help="Config file path")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx: click.Context, config: str, verbose: bool) -> None:
    """NIA — Nexos Impact Agent. Cross-team dependency analysis."""
    ctx.ensure_object(dict)
    ctx.obj["config"] = load_config(config)
    ctx.obj["verbose"] = verbose
```

Package entry point in `pyproject.toml`:
```toml
[project.scripts]
nia = "nia.cli.main:cli"
```

## 8 Commands

### 1. `nia init`
- Create `nia.yaml` from example if not exists
- Validate config structure (Pydantic)
- Test connectivity to configured sources (health_check)
- Output: status per source (OK / FAIL with reason)
- Flags: `--config PATH`

### 2. `nia sync`
- Pull incremental data from all configured connectors
- Flags: `--since DURATION` (e.g. "24h", "7d"), `--source jira|gitlab|slack` (filter), `--verbose`
- Output: summary table — source, entities fetched, events fetched, duration
- Store normalized data in storage
- On error: log and continue with other sources (don't abort all)

### 3. `nia analyze`
- Build/update dependency graph (run inference rules)
- Update owner candidates
- Calculate risk scores
- Flags: `--full` (recompute all, not just incremental)
- Output: summary — edges created/updated, owners inferred, risk scores computed

### 4. `nia ask "<question>"`
- Natural language Q&A with citations
- Retrieves relevant entities/edges/text from storage
- Sends to LLM with `ask_answer_v1` prompt template
- Output sections: Answer, Dependency chain, Owners, Evidence, Next action
- Flags: `--json` (machine-readable output), `--max-context INT`

### 5. `nia chain`
- Show dependency chain from a given entity
- Flags: `--from TICKET_KEY` (required), `--depth INT` (default 10), `--direction up|down|both`
- Output: formatted chain with owners, status, risk level per node
- Use rich.tree or indented format

### 6. `nia draft`
- Propose ticket comment + dependency links (dry-run by default)
- Flags: `--ticket TICKET_KEY` (required), `--json`
- Output: show proposed comment text, proposed links, proposed owner mention
- Do NOT write anything unless `--yes` is passed

### 7. `nia apply`
- Apply a previously generated draft
- Flags: `--draft-id ID` (required), `--yes` (skip confirmation)
- Without `--yes`: show diff and ask for interactive confirmation
- On success: show what was written and where
- NOTE: this command is denied in Claude Code settings for safety

### 8. `nia report`
- Generate markdown report
- Flags: `--team TEAM` (filter by team), `--since DURATION`, `--output PATH` (default stdout), `--json`
- Sections: summary, top risks, dependency chains, owner gaps, suggested actions
- Default: write to stdout so user can redirect (`> report.md`)

## Config loading (`config.py`)

Use Pydantic v2 `BaseSettings` or a custom loader:

```python
class NiaConfig(BaseModel):
    jira: JiraConfig
    gitlab: GitLabConfig
    slack: SlackConfig | None = None
    teams: dict[str, TeamMapping]
    llm: LLMConfig
    storage: StorageConfig
```

- Load from YAML file (default `nia.yaml`, override with `--config`)
- Resolve `${ENV_VAR}` in string values by replacing with `os.environ[ENV_VAR]`
- Validate with Pydantic — fail fast with clear error messages if config is invalid

## Output formatting (`cli/formatters.py`)

Use `rich` library:

- **Tables**: `rich.table.Table` for sync summaries, risk lists
- **Trees**: `rich.tree.Tree` for dependency chains
- **Panels**: `rich.panel.Panel` for ask answers
- **Markdown**: `rich.markdown.Markdown` for reports
- **JSON mode**: when `--json` flag is set, output raw JSON via `json.dumps(result, indent=2)`

All output goes through a formatter function — never print directly in command handlers.

## Error handling

Define error hierarchy in `src/nia/errors.py`:

```python
class NiaError(Exception):
    """Base error for NIA."""
    exit_code: int = 1

class ConfigError(NiaError):
    """Invalid or missing configuration."""
    exit_code: int = 2

class ConnectorError(NiaError):
    """Failed to connect to external service."""
    exit_code: int = 3

class StorageError(NiaError):
    """Database operation failed."""
    exit_code: int = 4

class LLMError(NiaError):
    """LLM call failed."""
    exit_code: int = 5
```

Catch `NiaError` at the CLI group level and exit with appropriate code + user-friendly message.

## Exit codes
- 0: success
- 1: general error
- 2: config error
- 3: connector error
- 4: storage error
- 5: LLM error

## Testing CLI

- Use Click's `CliRunner` for testing commands
- Mock all services (storage, connectors, LLM) — CLI tests should not do real work
- Test both success and error paths
- Test `--json` output is valid JSON
- Test `--help` for all commands
