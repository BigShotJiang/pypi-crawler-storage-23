Scaffold the NIA project from scratch. Execute these 14 steps in order. After each step, verify the result before proceeding. Reference `CLAUDE.md` for conventions and `docs/` for specifications.

## Step 1: pyproject.toml
Create `pyproject.toml` with:
- Project name: `nexos-impact-agent`
- Python: `>=3.11`
- Dependencies: click, httpx, pydantic (v2), rich, pyyaml
- Dev dependencies: pytest, pytest-cov, pytest-asyncio, ruff, mypy, respx
- Entry point: `nia = "nia.cli.main:cli"`
- Ruff config: line-length 100, target Python 3.11
- Mypy config: strict mode

## Step 2: Package structure
Create directory tree as specified in `CLAUDE.md` project layout section. All `__init__.py` files should be empty or contain `__all__` exports.

## Step 3: Core models (`src/nia/models.py`)
Define Pydantic v2 models based on `docs/05_DEPENDENCY_MODEL.md`:
- Entity types (Ticket, PR, Repo, Team, Person)
- Edge with EdgeType enum, confidence, evidence list
- Evidence schema
- RiskScore with features and level
- Owner with candidates and confirmed flag
- RawPayload dataclass

## Step 4: Config (`src/nia/config.py`)
Implement NiaConfig with Pydantic v2 based on `docs/07_CLI_SPEC.md`:
- YAML loading
- `${ENV_VAR}` resolution
- Sections: jira, gitlab, slack, teams, llm, storage
Then create `configs/nia.yaml.example` with all sections documented.

## Step 5: Storage layer
Implement `src/nia/storage/protocol.py` (StorageProtocol) and `src/nia/storage/sqlite.py`:
- Tables: entities, events, edges, owners, risk_scores
- CRUD operations
- SQLite as MVP (support `:memory:` for tests)

## Step 6: Jira connector
Implement `src/nia/connectors/protocol.py` and `src/nia/connectors/jira.py`:
- ConnectorProtocol with sync + health_check
- Pagination, incremental sync, auth
- Reference `docs/04_DATA_SOURCES.md` for fields and endpoints

## Step 7: CLI skeleton
Implement `src/nia/cli/main.py` with Click group + all 8 commands as stubs:
- init, sync, analyze, ask, chain, draft, apply, report
- Each command with correct flags and help text
- Verify with `python -m nia --help`

## Step 8: Remaining connectors
Implement `src/nia/connectors/gitlab.py` and `src/nia/connectors/slack.py`:
- Follow ConnectorProtocol
- Reference `docs/04_DATA_SOURCES.md`

## Step 9: Graph inference
Implement `src/nia/graph/inference.py` and `src/nia/graph/traversal.py`:
- 3 deterministic rules from `docs/05_DEPENDENCY_MODEL.md`
- Owner inference with 5 ranked signals
- BFS/DFS traversal with cycle detection

## Step 10: Risk scoring
Implement `src/nia/risk/scorer.py` and `src/nia/risk/detector.py`:
- Sigmoid formula with 7 features from `docs/06_RISK_MODEL.md`
- Blocker detection heuristics

## Step 11: Remaining CLI commands
Wire up the stub commands to real service logic:
- sync -> connectors + normalizer + storage
- analyze -> graph inference + risk scoring
- ask -> LLM client
- chain -> traversal
- draft/apply -> delivery
- report -> formatters

## Step 12: LLM integration
Implement `src/nia/llm/` modules:
- `redactor.py` — regex-based secret stripping (MANDATORY before LLM)
- `client.py` — LLMClientProtocol + implementation
- `audit.py` — JSONL audit logger
- `src/nia/graph/llm_extract.py` — LLM-assisted dependency extraction

## Step 13: Tests
Create test files for all modules following `tests/` structure in CLAUDE.md:
- conftest.py with factory functions
- JSON fixtures in tests/fixtures/
- Unit tests with mocked dependencies
- Integration tests with SQLite in-memory

## Step 14: Quality check
Run the full quality gate:
```bash
ruff check src/ tests/
ruff format --check src/ tests/
mypy src/nia/
pytest tests/ -v --cov=nia --cov-report=term-missing
python -m nia --help
```
Fix any issues until all checks pass.
