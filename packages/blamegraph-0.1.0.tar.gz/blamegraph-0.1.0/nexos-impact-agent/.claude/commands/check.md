Run the full NIA quality gate. Execute each step in order. Stop and report if any step fails.

## Step 1: Lint
```bash
ruff check src/ tests/
```
All checks must pass with zero errors.

## Step 2: Format verification
```bash
ruff format --check src/ tests/
```
No files should need reformatting. If they do, run `ruff format src/ tests/` to fix, then re-check.

## Step 3: Type checking
```bash
mypy src/nia/
```
Zero errors required. If there are errors, list them and fix.

## Step 4: Tests with coverage
```bash
pytest tests/ -v --cov=nia --cov-report=term-missing
```
All tests must pass. Coverage target: 80%+. Report any uncovered lines.

## Step 5: CLI smoke test
```bash
python -m nia --help
```
Must print the help text without errors.

## Summary
After all steps, report:
- Lint: PASS/FAIL (error count)
- Format: PASS/FAIL
- Types: PASS/FAIL (error count)
- Tests: PASS/FAIL (passed/failed/skipped counts)
- Coverage: XX%
- CLI: PASS/FAIL
