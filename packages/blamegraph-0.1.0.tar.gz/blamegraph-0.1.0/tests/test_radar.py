"""Tests for the Morning Radar feature (blamegraph.radar)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from blamegraph.models import EdgeType, RiskLevel
from blamegraph.radar import RadarEngine, RadarReport, RadarSeverity
from blamegraph.storage.sqlite import SQLiteStorage
from tests.conftest import make_edge, make_risk_score, make_ticket

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime.utcnow()  # naive UTC — matches radar.py's datetime.utcnow()

RECENT = _NOW - timedelta(days=1)
STALE_8D = _NOW - timedelta(days=8)
STALE_15D = _NOW - timedelta(days=15)
STALE_11D = _NOW - timedelta(days=11)  # triggers _find_no_activity (>= 10 days)


def _make_storage() -> SQLiteStorage:
    store = SQLiteStorage(":memory:")
    store.initialize()
    return store


# ---------------------------------------------------------------------------
# scan() — basic integration
# ---------------------------------------------------------------------------


def test_scan_empty_graph_returns_empty_report() -> None:
    store = _make_storage()
    engine = RadarEngine(store)

    report = engine.scan()

    assert isinstance(report, RadarReport)
    assert report.items == []
    assert report.team is None


def test_scan_no_findings_for_healthy_ticket() -> None:
    """A recently-updated, assigned, low-risk, unblocked open ticket produces no findings."""
    store = _make_storage()
    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=RECENT,
        attributes={"status": "open", "assignee": "alice"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    assert report.items == []


def test_scan_returns_report_with_correct_team() -> None:
    store = _make_storage()
    engine = RadarEngine(store)

    report = engine.scan(team="backend")

    assert report.team == "backend"


def test_scan_items_sorted_critical_first() -> None:
    """Items must be ordered critical → warning → info regardless of detection order."""
    store = _make_storage()

    # Ticket that is stale (→ WARNING)
    stale = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "assignee": "alice"},
    )
    # Ticket that is blocked and has no assignee (→ CRITICAL)
    blocked_unassigned = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "open"},
    )
    blocker = make_ticket(
        id="t3",
        external_id="PROJ-3",
        updated_at=RECENT,
        attributes={"status": "open", "assignee": "bob"},
    )
    store.upsert_entity(stale)
    store.upsert_entity(blocked_unassigned)
    store.upsert_entity(blocker)
    store.upsert_edge(
        make_edge(
            id="e1",
            from_entity="t3",
            to_entity="t2",
            edge_type=EdgeType.BLOCKS,
        )
    )
    engine = RadarEngine(store)

    report = engine.scan()

    severities = [i.severity for i in report.items]
    critical_pos = severities.index(RadarSeverity.CRITICAL)
    warning_pos = severities.index(RadarSeverity.WARNING)
    assert critical_pos < warning_pos


def test_scan_with_team_filter_passes_team_to_report() -> None:
    store = _make_storage()
    engine = RadarEngine(store)
    report = engine.scan(team="platform")
    assert report.team == "platform"


# ---------------------------------------------------------------------------
# _find_blocked_no_assignee
# ---------------------------------------------------------------------------


def test_blocked_no_assignee_detected_as_critical() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    victim = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "open"},  # no assignee key
    )
    store.upsert_entity(blocker)
    store.upsert_entity(victim)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    critical = report.critical_items
    assert any(i.entity_id == "t2" for i in critical)


def test_blocked_with_assignee_not_flagged() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    victim = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "open", "assignee": "alice"},  # has assignee
    )
    store.upsert_entity(blocker)
    store.upsert_entity(victim)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t2" and i.reason.startswith("Blocked") for i in report.items)


def test_blocked_no_assignee_done_status_skipped() -> None:
    """A 'done' ticket should be ignored even if it is blocked and has no assignee."""
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    done_victim = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "done"},
    )
    store.upsert_entity(blocker)
    store.upsert_entity(done_victim)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t2" for i in report.critical_items)


def test_blocked_no_assignee_closed_status_skipped() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    closed = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "closed"},
    )
    store.upsert_entity(blocker)
    store.upsert_entity(closed)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t2" for i in report.critical_items)


def test_blocked_no_assignee_resolved_status_skipped() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    resolved = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "resolved"},
    )
    store.upsert_entity(blocker)
    store.upsert_entity(resolved)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t2" for i in report.critical_items)


def test_blocked_no_assignee_detail_fields() -> None:
    """Verify the details dict contains expected keys with sensible values."""
    store = _make_storage()

    blocker = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    victim = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=_NOW - timedelta(days=3),
        attributes={"status": "in progress"},
    )
    store.upsert_entity(blocker)
    store.upsert_entity(victim)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    item = next(i for i in report.critical_items if i.entity_id == "t2")
    assert "days_blocked" in item.details
    assert item.details["days_blocked"] >= 3
    assert "status" in item.details


def test_depends_on_edge_does_not_trigger_blocked_no_assignee() -> None:
    """Only BLOCKS edges should mark a ticket as blocked — not DEPENDS_ON."""
    store = _make_storage()

    dependency = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    dependent = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=RECENT,
        attributes={"status": "open"},
    )
    store.upsert_entity(dependency)
    store.upsert_entity(dependent)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t2", to_entity="t1", edge_type=EdgeType.DEPENDS_ON)
    )
    engine = RadarEngine(store)

    report = engine.scan()

    # Neither ticket should be flagged as blocked-no-assignee
    blocked_reasons = [i for i in report.items if i.reason.startswith("Blocked")]
    assert not blocked_reasons


# ---------------------------------------------------------------------------
# _find_stale_tickets
# ---------------------------------------------------------------------------


def test_stale_ticket_detected_as_warning() -> None:
    store = _make_storage()

    stale = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open"},
    )
    store.upsert_entity(stale)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert any(i.entity_id == "t1" and i.severity == RadarSeverity.WARNING for i in report.items)


def test_recent_ticket_not_stale() -> None:
    store = _make_storage()

    fresh = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=RECENT,
        attributes={"status": "open"},
    )
    store.upsert_entity(fresh)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    stale_items = [i for i in report.items if "No update for" in i.reason]
    assert not stale_items


def test_stale_done_ticket_not_flagged() -> None:
    store = _make_storage()

    done_stale = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_15D,
        attributes={"status": "done"},
    )
    store.upsert_entity(done_stale)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "No update for" in i.reason for i in report.items)


def test_stale_closed_ticket_not_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_15D,
        attributes={"status": "closed"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "No update for" in i.reason for i in report.items)


def test_stale_resolved_ticket_not_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_15D,
        attributes={"status": "resolved"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "No update for" in i.reason for i in report.items)


def test_stale_ticket_detail_fields() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_15D,
        attributes={"status": "open"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    item = next(i for i in report.items if "No update for" in i.reason)
    assert "days_stale" in item.details
    assert item.details["days_stale"] >= 15
    assert "last_update" in item.details


def test_custom_stale_days_threshold() -> None:
    """Engine with stale_days=3 should flag a 4-day-old ticket."""
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=_NOW - timedelta(days=4),
        attributes={"status": "open"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=3)

    report = engine.scan()

    assert any(i.entity_id == "t1" and "No update for" in i.reason for i in report.items)


def test_exact_stale_boundary_not_flagged() -> None:
    """A ticket updated exactly stale_days ago (not past the cutoff) should not be flagged."""
    store = _make_storage()

    # timedelta(days=7) puts updated_at right at the cutoff — not strictly less, so no finding
    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=_NOW - timedelta(days=6, hours=23),
        attributes={"status": "open"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "No update for" in i.reason for i in report.items)


# ---------------------------------------------------------------------------
# _find_high_risk
# ---------------------------------------------------------------------------


def test_high_risk_score_detected_as_warning() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    rs = make_risk_score(entity_id="t1", score=70.0, level=RiskLevel.HIGH, suggested_action="Escalate now")
    store.upsert_entity(ticket)
    store.upsert_risk_score(rs)
    engine = RadarEngine(store)

    report = engine.scan()

    high_risk_items = [
        i for i in report.items if i.entity_id == "t1" and "Risk score" in i.reason
    ]
    assert len(high_risk_items) == 1
    assert high_risk_items[0].severity == RadarSeverity.WARNING


def test_critical_risk_score_detected_as_critical() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    rs = make_risk_score(entity_id="t1", score=90.0, level=RiskLevel.CRITICAL, suggested_action="Immediate action required")
    store.upsert_entity(ticket)
    store.upsert_risk_score(rs)
    engine = RadarEngine(store)

    report = engine.scan()

    critical_risk = [i for i in report.critical_items if "Risk score" in i.reason]
    assert any(i.entity_id == "t1" for i in critical_risk)


def test_medium_risk_score_not_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    rs = make_risk_score(entity_id="t1", score=50.0, level=RiskLevel.MEDIUM)
    store.upsert_entity(ticket)
    store.upsert_risk_score(rs)
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "Risk score" in i.reason for i in report.items)


def test_low_risk_score_not_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    rs = make_risk_score(entity_id="t1", score=10.0, level=RiskLevel.LOW)
    store.upsert_entity(ticket)
    store.upsert_risk_score(rs)
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any(i.entity_id == "t1" and "Risk score" in i.reason for i in report.items)


def test_high_risk_detail_fields() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    rs = make_risk_score(
        entity_id="t1",
        score=75.0,
        level=RiskLevel.HIGH,
        suggested_action="Assign an owner",
    )
    store.upsert_entity(ticket)
    store.upsert_risk_score(rs)
    engine = RadarEngine(store)

    report = engine.scan()

    item = next(i for i in report.items if i.entity_id == "t1" and "Risk score" in i.reason)
    assert item.details["risk_score"] == 75.0
    assert item.details["risk_level"] == "high"
    assert item.details["suggested_action"] == "Assign an owner"


def test_ticket_without_risk_score_not_flagged_for_risk() -> None:
    store = _make_storage()

    ticket = make_ticket(id="t1", external_id="PROJ-1", updated_at=RECENT, attributes={"status": "open"})
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    assert not any("Risk score" in i.reason for i in report.items)


# ---------------------------------------------------------------------------
# _find_blocking_many
# ---------------------------------------------------------------------------


def test_blocking_three_flagged_as_critical() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t0", external_id="PROJ-0", updated_at=RECENT, attributes={"status": "open"})
    downstream = [
        make_ticket(id=f"t{n}", external_id=f"PROJ-{n}", updated_at=RECENT, attributes={"status": "open"})
        for n in range(1, 4)
    ]
    store.upsert_entity(blocker)
    for ticket in downstream:
        store.upsert_entity(ticket)
    for n, ticket in enumerate(downstream, start=1):
        store.upsert_edge(
            make_edge(id=f"e{n}", from_entity="t0", to_entity=ticket.id, edge_type=EdgeType.BLOCKS)
        )
    engine = RadarEngine(store)

    report = engine.scan()

    blocking_many = [i for i in report.critical_items if "downstream" in i.reason]
    assert any(i.entity_id == "t0" for i in blocking_many)


def test_blocking_exactly_two_not_flagged() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t0", external_id="PROJ-0", updated_at=RECENT, attributes={"status": "open"})
    for n in range(1, 3):
        store.upsert_entity(
            make_ticket(id=f"t{n}", external_id=f"PROJ-{n}", updated_at=RECENT, attributes={"status": "open"})
        )
    store.upsert_entity(blocker)
    for n in range(1, 3):
        store.upsert_edge(
            make_edge(id=f"e{n}", from_entity="t0", to_entity=f"t{n}", edge_type=EdgeType.BLOCKS)
        )
    engine = RadarEngine(store)

    report = engine.scan()

    blocking_many = [i for i in report.items if "downstream" in i.reason]
    assert not any(i.entity_id == "t0" for i in blocking_many)


def test_blocking_many_done_blocker_skipped() -> None:
    """A done ticket blocking 3+ others should not be flagged."""
    store = _make_storage()

    done_blocker = make_ticket(
        id="t0",
        external_id="PROJ-0",
        updated_at=RECENT,
        attributes={"status": "done"},
    )
    store.upsert_entity(done_blocker)
    for n in range(1, 4):
        store.upsert_entity(
            make_ticket(id=f"t{n}", external_id=f"PROJ-{n}", updated_at=RECENT, attributes={"status": "open"})
        )
        store.upsert_edge(
            make_edge(id=f"e{n}", from_entity="t0", to_entity=f"t{n}", edge_type=EdgeType.BLOCKS)
        )
    engine = RadarEngine(store)

    report = engine.scan()

    blocking_many = [i for i in report.items if "downstream" in i.reason]
    assert not any(i.entity_id == "t0" for i in blocking_many)


def test_blocking_many_detail_shows_downstream_count() -> None:
    store = _make_storage()

    blocker = make_ticket(id="t0", external_id="PROJ-0", updated_at=RECENT, attributes={"status": "open"})
    store.upsert_entity(blocker)
    for n in range(1, 5):
        store.upsert_entity(
            make_ticket(id=f"t{n}", external_id=f"PROJ-{n}", updated_at=RECENT, attributes={"status": "open"})
        )
        store.upsert_edge(
            make_edge(id=f"e{n}", from_entity="t0", to_entity=f"t{n}", edge_type=EdgeType.BLOCKS)
        )
    engine = RadarEngine(store)

    report = engine.scan()

    item = next(i for i in report.critical_items if i.entity_id == "t0" and "downstream" in i.reason)
    assert item.details["downstream_count"] == 4


def test_blocking_many_only_counts_blocks_edges() -> None:
    """DEPENDS_ON edges from a ticket must not count towards the blocking threshold."""
    store = _make_storage()

    hub = make_ticket(id="t0", external_id="PROJ-0", updated_at=RECENT, attributes={"status": "open"})
    store.upsert_entity(hub)
    for n in range(1, 4):
        store.upsert_entity(
            make_ticket(id=f"t{n}", external_id=f"PROJ-{n}", updated_at=RECENT, attributes={"status": "open"})
        )
        store.upsert_edge(
            make_edge(id=f"e{n}", from_entity="t0", to_entity=f"t{n}", edge_type=EdgeType.DEPENDS_ON)
        )
    engine = RadarEngine(store)

    report = engine.scan()

    blocking_many = [i for i in report.items if "downstream" in i.reason]
    assert not blocking_many


# ---------------------------------------------------------------------------
# _find_no_activity
# ---------------------------------------------------------------------------


def test_in_progress_with_no_activity_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_11D,
        attributes={"status": "in progress"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    no_activity = [i for i in report.warning_items if "In '" in i.reason]
    assert any(i.entity_id == "t1" for i in no_activity)


def test_in_review_with_no_activity_flagged() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_11D,
        attributes={"status": "in review"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    no_activity = [i for i in report.warning_items if "In '" in i.reason]
    assert any(i.entity_id == "t1" for i in no_activity)


def test_open_status_not_flagged_for_no_activity() -> None:
    """Only 'in progress' / 'in review' tickets trigger the no-activity check."""
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_11D,
        attributes={"status": "open"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    no_activity = [i for i in report.items if "In '" in i.reason and i.entity_id == "t1"]
    assert not no_activity


def test_in_progress_recently_updated_not_flagged() -> None:
    """A recently-touched in-progress ticket must not produce a no-activity warning."""
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=RECENT,
        attributes={"status": "in progress"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    no_activity = [i for i in report.items if "In '" in i.reason and i.entity_id == "t1"]
    assert not no_activity


def test_no_activity_boundary_nine_days_not_flagged() -> None:
    """9 days since last update should be under the 10-day threshold."""
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=_NOW - timedelta(days=9, hours=23),
        attributes={"status": "in progress"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    no_activity = [i for i in report.items if "In '" in i.reason and i.entity_id == "t1"]
    assert not no_activity


def test_no_activity_detail_fields() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=_NOW - timedelta(days=12),
        attributes={"status": "in review"},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store)

    report = engine.scan()

    item = next(i for i in report.warning_items if i.entity_id == "t1" and "In '" in i.reason)
    assert item.details["status"] == "in review"
    assert item.details["days_no_activity"] >= 12


# ---------------------------------------------------------------------------
# _filter_by_team
# ---------------------------------------------------------------------------


def test_filter_by_team_label_match() -> None:
    store = _make_storage()

    backend_ticket = make_ticket(
        id="t1",
        external_id="PLAT-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["backend", "api"]},
    )
    frontend_ticket = make_ticket(
        id="t2",
        external_id="PLAT-2",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["frontend"]},
    )
    store.upsert_entity(backend_ticket)
    store.upsert_entity(frontend_ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan(team="backend")

    # Only the backend ticket should be scanned and flagged as stale
    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" not in stale_ids


def test_filter_by_team_component_match() -> None:
    store = _make_storage()

    payments_ticket = make_ticket(
        id="t1",
        external_id="CORE-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "components": ["payments", "billing"]},
    )
    auth_ticket = make_ticket(
        id="t2",
        external_id="CORE-2",
        updated_at=STALE_8D,
        attributes={"status": "open", "components": ["auth"]},
    )
    store.upsert_entity(payments_ticket)
    store.upsert_entity(auth_ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan(team="payments")

    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" not in stale_ids


def test_filter_by_team_project_key_prefix() -> None:
    store = _make_storage()

    # external_id prefix "mob" matches team "mob"
    mob_ticket = make_ticket(
        id="t1",
        external_id="MOB-42",
        updated_at=STALE_8D,
        attributes={"status": "open"},
    )
    other_ticket = make_ticket(
        id="t2",
        external_id="WEB-99",
        updated_at=STALE_8D,
        attributes={"status": "open"},
    )
    store.upsert_entity(mob_ticket)
    store.upsert_entity(other_ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan(team="mob")

    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" not in stale_ids


def test_filter_by_team_assignee_match() -> None:
    store = _make_storage()

    alice_ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "assignee": "alice@backend.io"},
    )
    bob_ticket = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=STALE_8D,
        attributes={"status": "open", "assignee": "bob@frontend.io"},
    )
    store.upsert_entity(alice_ticket)
    store.upsert_entity(bob_ticket)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan(team="backend")

    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" not in stale_ids


def test_filter_by_team_no_match_falls_back_to_all() -> None:
    """When no entity matches the team, the engine falls back to scanning all entities."""
    store = _make_storage()

    t1 = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["backend"]},
    )
    t2 = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["frontend"]},
    )
    store.upsert_entity(t1)
    store.upsert_entity(t2)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan(team="nonexistentteam")

    # Falls back to all entities → both should be flagged as stale
    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" in stale_ids


def test_filter_by_team_case_insensitive() -> None:
    store = _make_storage()

    ticket = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["Backend"]},
    )
    store.upsert_entity(ticket)
    engine = RadarEngine(store, stale_days=7)

    # Team name supplied in different case
    report = engine.scan(team="BACKEND")

    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids


def test_scan_without_team_scans_all_entities() -> None:
    store = _make_storage()

    t1 = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["backend"]},
    )
    t2 = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=STALE_8D,
        attributes={"status": "open", "labels": ["frontend"]},
    )
    store.upsert_entity(t1)
    store.upsert_entity(t2)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()  # no team argument

    stale_ids = {i.entity_id for i in report.items if "No update for" in i.reason}
    assert "t1" in stale_ids
    assert "t2" in stale_ids


# ---------------------------------------------------------------------------
# RadarReport properties
# ---------------------------------------------------------------------------


def test_radar_report_critical_items_property() -> None:
    report = RadarReport(team=None)
    from blamegraph.radar import RadarItem

    report.items = [
        RadarItem(severity=RadarSeverity.CRITICAL, entity_id="t1", external_id="P-1", title="A", reason="r"),
        RadarItem(severity=RadarSeverity.WARNING, entity_id="t2", external_id="P-2", title="B", reason="r"),
        RadarItem(severity=RadarSeverity.INFO, entity_id="t3", external_id="P-3", title="C", reason="r"),
        RadarItem(severity=RadarSeverity.CRITICAL, entity_id="t4", external_id="P-4", title="D", reason="r"),
    ]

    assert len(report.critical_items) == 2
    assert all(i.severity == RadarSeverity.CRITICAL for i in report.critical_items)


def test_radar_report_warning_items_property() -> None:
    report = RadarReport(team=None)
    from blamegraph.radar import RadarItem

    report.items = [
        RadarItem(severity=RadarSeverity.CRITICAL, entity_id="t1", external_id="P-1", title="A", reason="r"),
        RadarItem(severity=RadarSeverity.WARNING, entity_id="t2", external_id="P-2", title="B", reason="r"),
        RadarItem(severity=RadarSeverity.WARNING, entity_id="t3", external_id="P-3", title="C", reason="r"),
    ]

    assert len(report.warning_items) == 2
    assert all(i.severity == RadarSeverity.WARNING for i in report.warning_items)


def test_radar_report_info_items_property() -> None:
    report = RadarReport(team=None)
    from blamegraph.radar import RadarItem

    report.items = [
        RadarItem(severity=RadarSeverity.INFO, entity_id="t1", external_id="P-1", title="A", reason="r"),
        RadarItem(severity=RadarSeverity.CRITICAL, entity_id="t2", external_id="P-2", title="B", reason="r"),
    ]

    assert len(report.info_items) == 1
    assert report.info_items[0].entity_id == "t1"


def test_radar_report_empty_properties_when_no_items() -> None:
    report = RadarReport(team="alpha")

    assert report.critical_items == []
    assert report.warning_items == []
    assert report.info_items == []


def test_radar_report_generated_at_is_datetime() -> None:
    report = RadarReport(team=None)
    assert isinstance(report.generated_at, datetime)


def test_radar_report_ai_summary_default_empty() -> None:
    report = RadarReport(team=None)
    assert report.ai_summary == ""


# ---------------------------------------------------------------------------
# Non-ticket entity types excluded
# ---------------------------------------------------------------------------


def test_pr_entities_not_included_in_scan() -> None:
    """Radar only operates on ticket entities; PRs stored in graph must not appear."""
    from blamegraph.models import EntityType

    store = _make_storage()

    pr = make_ticket(
        id="pr1",
        external_id="!42",
        updated_at=STALE_8D,
        attributes={"status": "open"},
    )
    # Override type after creation to set it as a PR
    pr_entity = pr.model_copy(update={"entity_type": EntityType.PR})
    store.upsert_entity(pr_entity)
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    assert report.items == []


# ---------------------------------------------------------------------------
# Multiple detectors fire on a single ticket
# ---------------------------------------------------------------------------


def test_multiple_findings_for_same_ticket() -> None:
    """A ticket can accumulate findings from several detectors at once."""
    store = _make_storage()

    # Ticket that is: stale, blocked-no-assignee, and in progress with no activity
    victim = make_ticket(
        id="t2",
        external_id="PROJ-2",
        updated_at=STALE_11D,
        attributes={"status": "in progress"},  # no assignee
    )
    blocker = make_ticket(
        id="t1",
        external_id="PROJ-1",
        updated_at=RECENT,
        attributes={"status": "open", "assignee": "bob"},
    )
    store.upsert_entity(victim)
    store.upsert_entity(blocker)
    store.upsert_edge(
        make_edge(id="e1", from_entity="t1", to_entity="t2", edge_type=EdgeType.BLOCKS)
    )
    engine = RadarEngine(store, stale_days=7)

    report = engine.scan()

    ids_found = [i.entity_id for i in report.items]
    # t2 should appear multiple times — once per detector that fires
    assert ids_found.count("t2") >= 2
