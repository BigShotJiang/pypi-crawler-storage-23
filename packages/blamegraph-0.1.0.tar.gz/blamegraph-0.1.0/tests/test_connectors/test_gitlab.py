"""Tests for the GitLab connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import GitLabConfig
from blamegraph.connectors.gitlab import GitLabConnector, _parse_next_link
from blamegraph.errors import ConnectorError


@pytest.fixture()
def gitlab_config() -> GitLabConfig:
    return GitLabConfig(
        base_url="https://gitlab.example.com",
        group="mygroup",
        project_ids=[42],
        token_env="GITLAB_TOKEN",
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GITLAB_TOKEN", "glpat-test-token")


def _make_mr(iid: int) -> dict:
    return {
        "iid": iid,
        "project_id": 42,
        "title": f"MR !{iid}",
        "description": f"Description of MR !{iid}",
        "state": "merged",
        "source_branch": "feature",
        "target_branch": "main",
        "labels": ["bugfix"],
        "web_url": f"https://gitlab.example.com/mygroup/repo/-/merge_requests/{iid}",
        "author": {"username": "alice"},
        "created_at": "2024-01-10T12:00:00Z",
        "merged_at": "2024-01-12T15:00:00Z",
    }


def _make_commit(sha: str) -> dict:
    return {
        "id": sha,
        "message": f"Commit {sha[:8]}",
        "author_name": "Alice",
    }


def _make_pipeline(pid: int) -> dict:
    return {
        "id": pid,
        "status": "success",
        "ref": "main",
    }


@respx.mock
async def test_gitlab_sync_single_page(gitlab_config: GitLabConfig) -> None:
    """Test basic sync returns MRs, commits, pipelines, and CODEOWNERS."""
    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        return_value=httpx.Response(200, json=[_make_mr(1), _make_mr(2)])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/commits").mock(
        return_value=httpx.Response(200, json=[_make_commit("abc123")])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/pipelines").mock(
        return_value=httpx.Response(200, json=[_make_pipeline(100)])
    )
    codeowners_url = "https://gitlab.example.com/api/v4/projects/42/repository/files/CODEOWNERS"
    respx.get(codeowners_url).mock(
        return_value=httpx.Response(
            200, json={"file_name": "CODEOWNERS", "content": "KiBAYWxpY2U="}
        )
    )

    connector = GitLabConnector(gitlab_config)
    results = await connector.sync()

    sources = [r.source for r in results]
    assert "gitlab_mr" in sources
    assert "gitlab_commit" in sources
    assert "gitlab_pipeline" in sources
    assert "gitlab_codeowners" in sources

    mrs = [r for r in results if r.source == "gitlab_mr"]
    assert len(mrs) == 2
    assert mrs[0].external_id == "42!1"


@respx.mock
async def test_gitlab_link_header_pagination(gitlab_config: GitLabConfig) -> None:
    """Test pagination via Link header with rel=next."""
    mr_route = respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests")

    call_count = 0

    def mr_side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        page = request.url.params.get("page", "")
        if page == "2":
            return httpx.Response(200, json=[_make_mr(2)])
        else:
            page2_url = (
                "https://gitlab.example.com/api/v4/projects/42/merge_requests?page=2&per_page=100"
            )
            return httpx.Response(
                200,
                json=[_make_mr(1)],
                headers={"Link": f'<{page2_url}>; rel="next"'},
            )

    mr_route.mock(side_effect=mr_side_effect)
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/commits").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/pipelines").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/files/CODEOWNERS").mock(
        return_value=httpx.Response(404)
    )

    connector = GitLabConnector(gitlab_config)
    results = await connector.sync()

    mrs = [r for r in results if r.source == "gitlab_mr"]
    assert len(mrs) == 2
    assert call_count == 2


@respx.mock
async def test_gitlab_private_token_header(gitlab_config: GitLabConfig) -> None:
    """Test that PRIVATE-TOKEN header is sent."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(200, json=[])

    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        side_effect=side_effect
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/commits").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/pipelines").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/files/CODEOWNERS").mock(
        return_value=httpx.Response(404)
    )

    connector = GitLabConnector(gitlab_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("private-token") == "glpat-test-token"


@respx.mock
async def test_gitlab_incremental_sync(gitlab_config: GitLabConfig) -> None:
    """Test that since param adds updated_after to MR params."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json=[])

    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        side_effect=side_effect
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/commits").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/pipelines").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/files/CODEOWNERS").mock(
        return_value=httpx.Response(404)
    )

    connector = GitLabConnector(gitlab_config)
    since = datetime(2024, 6, 15, 10, 30, 0)
    await connector.sync(since=since)

    assert captured_params is not None
    assert captured_params.get("updated_after") == "2024-06-15T10:30:00Z"


@respx.mock
async def test_gitlab_health_check_success(gitlab_config: GitLabConfig) -> None:
    respx.get("https://gitlab.example.com/api/v4/version").mock(
        return_value=httpx.Response(200, json={"version": "16.0"})
    )
    connector = GitLabConnector(gitlab_config)
    assert await connector.health_check() is True


@respx.mock
async def test_gitlab_health_check_failure(gitlab_config: GitLabConfig) -> None:
    respx.get("https://gitlab.example.com/api/v4/version").mock(return_value=httpx.Response(401))
    connector = GitLabConnector(gitlab_config)
    assert await connector.health_check() is False


@respx.mock
async def test_gitlab_api_error_raises(gitlab_config: GitLabConfig) -> None:
    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    connector = GitLabConnector(gitlab_config)
    with pytest.raises(ConnectorError, match="500"):
        await connector.sync()


async def test_gitlab_missing_token_raises(
    gitlab_config: GitLabConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from blamegraph import credentials

    monkeypatch.delenv("GITLAB_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = GitLabConnector(gitlab_config)
    with pytest.raises(ConnectorError, match="GITLAB_TOKEN"):
        await connector.sync()


@respx.mock
async def test_gitlab_search_mrs(gitlab_config: GitLabConfig) -> None:
    """Test search_mrs fetches merge requests matching a query."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json=[_make_mr(10), _make_mr(11)])

    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        side_effect=side_effect
    )

    connector = GitLabConnector(gitlab_config)
    results = await connector.search_mrs("login fix")

    assert len(results) == 2
    assert results[0].source == "gitlab_mr"
    assert captured_params is not None
    assert captured_params.get("search") == "login fix"


@respx.mock
async def test_gitlab_search_mrs_empty_projects() -> None:
    """Test search_mrs returns empty list when no projects configured."""
    config = GitLabConfig(base_url="https://gitlab.example.com", project_ids=[])
    connector = GitLabConnector(config)
    results = await connector.search_mrs("test")
    assert results == []


@respx.mock
async def test_gitlab_empty_project_ids() -> None:
    config = GitLabConfig(base_url="https://gitlab.example.com", project_ids=[])
    connector = GitLabConnector(config)
    results = await connector.sync()
    assert results == []


def test_parse_next_link() -> None:
    header = '<https://example.com/page2>; rel="next", <https://example.com/page1>; rel="first"'
    assert _parse_next_link(header) == "https://example.com/page2"


def test_parse_next_link_no_next() -> None:
    header = '<https://example.com/page1>; rel="first"'
    assert _parse_next_link(header) is None


@respx.mock
async def test_gitlab_token_fallback_to_credential_file(
    gitlab_config: GitLabConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("GITLAB_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("gitlab", "file-token-gitlab")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(200, json=[])

    respx.get("https://gitlab.example.com/api/v4/projects/42/merge_requests").mock(
        side_effect=side_effect
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/commits").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/pipelines").mock(
        return_value=httpx.Response(200, json=[])
    )
    respx.get("https://gitlab.example.com/api/v4/projects/42/repository/files/CODEOWNERS").mock(
        return_value=httpx.Response(404)
    )

    connector = GitLabConnector(gitlab_config)
    await connector.sync()

    assert captured_headers.get("private-token") == "file-token-gitlab"
