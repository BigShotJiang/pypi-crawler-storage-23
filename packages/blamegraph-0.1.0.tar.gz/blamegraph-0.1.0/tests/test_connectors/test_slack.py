"""Tests for the Slack connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import SlackConfig
from blamegraph.connectors.slack import SlackConnector
from blamegraph.errors import ConnectorError


@pytest.fixture()
def slack_config() -> SlackConfig:
    return SlackConfig(
        enabled=True,
        token_env="SLACK_TOKEN",
        channels=["C12345"],
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SLACK_TOKEN", "xoxb-test-token")


def _make_message(ts: str, text: str, **kwargs: object) -> dict:
    msg: dict[str, object] = {"ts": ts, "text": text, "user": "U001", **kwargs}
    return msg


@respx.mock
async def test_slack_sync_single_page(slack_config: SlackConfig) -> None:
    """Test basic sync returns messages as RawPayloads."""
    respx.get("https://slack.com/api/conversations.history").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "messages": [
                    _make_message("1700000001.000001", "Hello world"),
                    _make_message("1700000002.000002", "Follow up"),
                ],
                "response_metadata": {"next_cursor": ""},
            },
        )
    )

    connector = SlackConnector(slack_config)
    results = await connector.sync()

    assert len(results) == 2
    assert results[0].source == "slack"
    assert results[0].external_id == "C12345:1700000001.000001"
    assert results[0].payload["text"] == "Hello world"


@respx.mock
async def test_slack_cursor_pagination(slack_config: SlackConfig) -> None:
    """Test cursor-based pagination fetches multiple pages."""
    route = respx.get("https://slack.com/api/conversations.history")

    call_count = 0

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        cursor = request.url.params.get("cursor", "")
        if not cursor:
            return httpx.Response(
                200,
                json={
                    "ok": True,
                    "messages": [_make_message("1700000001.000001", "Page 1")],
                    "response_metadata": {"next_cursor": "cursor_page2"},
                },
            )
        else:
            return httpx.Response(
                200,
                json={
                    "ok": True,
                    "messages": [_make_message("1700000002.000002", "Page 2")],
                    "response_metadata": {"next_cursor": ""},
                },
            )

    route.mock(side_effect=side_effect)

    connector = SlackConnector(slack_config)
    results = await connector.sync()

    assert len(results) == 2
    assert call_count == 2


@respx.mock
async def test_slack_bearer_auth(slack_config: SlackConfig) -> None:
    """Test that Bearer token is sent in Authorization header."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(
            200,
            json={"ok": True, "messages": [], "response_metadata": {"next_cursor": ""}},
        )

    respx.get("https://slack.com/api/conversations.history").mock(side_effect=side_effect)

    connector = SlackConnector(slack_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("authorization") == "Bearer xoxb-test-token"


@respx.mock
async def test_slack_channel_allowlist_filtering() -> None:
    """Test that only configured channels are fetched."""
    config = SlackConfig(enabled=True, channels=["C111", "C222"])

    channels_requested: list[str] = []

    def side_effect(request: httpx.Request) -> httpx.Response:
        ch = request.url.params.get("channel", "")
        channels_requested.append(ch)
        return httpx.Response(
            200,
            json={"ok": True, "messages": [], "response_metadata": {"next_cursor": ""}},
        )

    respx.get("https://slack.com/api/conversations.history").mock(side_effect=side_effect)

    connector = SlackConnector(config)
    await connector.sync()

    assert set(channels_requested) == {"C111", "C222"}


@respx.mock
async def test_slack_thread_replies(slack_config: SlackConfig) -> None:
    """Test that thread replies are fetched for threaded messages."""
    respx.get("https://slack.com/api/conversations.history").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "messages": [
                    _make_message(
                        "1700000001.000001",
                        "Parent message",
                        thread_ts="1700000001.000001",
                        reply_count=1,
                    ),
                ],
                "response_metadata": {"next_cursor": ""},
            },
        )
    )

    respx.get("https://slack.com/api/conversations.replies").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "messages": [
                    _make_message("1700000001.000001", "Parent message"),
                    _make_message("1700000001.000002", "Reply 1"),
                ],
                "response_metadata": {"next_cursor": ""},
            },
        )
    )

    connector = SlackConnector(slack_config)
    results = await connector.sync()

    # Parent + 1 reply (parent in replies is skipped)
    assert len(results) == 2
    sources = [r.source for r in results]
    assert "slack" in sources
    assert "slack_reply" in sources


@respx.mock
async def test_slack_incremental_sync(slack_config: SlackConfig) -> None:
    """Test that since parameter adds oldest to API call."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(
            200,
            json={"ok": True, "messages": [], "response_metadata": {"next_cursor": ""}},
        )

    respx.get("https://slack.com/api/conversations.history").mock(side_effect=side_effect)

    connector = SlackConnector(slack_config)
    since = datetime(2024, 6, 15, 10, 0, 0)
    await connector.sync(since=since)

    assert captured_params is not None
    assert "oldest" in captured_params
    assert float(captured_params["oldest"]) == since.timestamp()


@respx.mock
async def test_slack_health_check_success(slack_config: SlackConfig) -> None:
    respx.post("https://slack.com/api/auth.test").mock(
        return_value=httpx.Response(200, json={"ok": True, "user": "bot"})
    )
    connector = SlackConnector(slack_config)
    assert await connector.health_check() is True


@respx.mock
async def test_slack_health_check_failure(slack_config: SlackConfig) -> None:
    respx.post("https://slack.com/api/auth.test").mock(
        return_value=httpx.Response(200, json={"ok": False, "error": "invalid_auth"})
    )
    connector = SlackConnector(slack_config)
    assert await connector.health_check() is False


@respx.mock
async def test_slack_api_error_raises(slack_config: SlackConfig) -> None:
    respx.get("https://slack.com/api/conversations.history").mock(
        return_value=httpx.Response(
            200,
            json={"ok": False, "error": "channel_not_found"},
        )
    )
    connector = SlackConnector(slack_config)
    with pytest.raises(ConnectorError, match="channel_not_found"):
        await connector.sync()


async def test_slack_missing_token_raises(
    slack_config: SlackConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from blamegraph import credentials

    monkeypatch.delenv("SLACK_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = SlackConnector(slack_config)
    with pytest.raises(ConnectorError, match="SLACK_TOKEN"):
        await connector.sync()


@respx.mock
async def test_slack_search_messages(slack_config: SlackConfig) -> None:
    """Test search_messages uses the search.messages API."""
    respx.get("https://slack.com/api/search.messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "messages": {
                    "matches": [
                        {
                            "ts": "1700000001.000001",
                            "text": "PROJ-123 is blocked",
                            "channel": {"id": "C12345"},
                        },
                        {
                            "ts": "1700000002.000002",
                            "text": "PROJ-123 needs review",
                            "channel": {"id": "C12345"},
                        },
                    ]
                },
            },
        )
    )

    connector = SlackConnector(slack_config)
    results = await connector.search_messages("PROJ-123")

    assert len(results) == 2
    assert results[0].source == "slack"
    assert "PROJ-123" in str(results[0].payload.get("text", ""))


@respx.mock
async def test_slack_search_messages_fallback(slack_config: SlackConfig) -> None:
    """Test search_messages falls back to history filtering when search API fails."""
    # Search API returns error
    respx.get("https://slack.com/api/search.messages").mock(
        return_value=httpx.Response(
            200,
            json={"ok": False, "error": "missing_scope"},
        )
    )

    # History fallback
    respx.get("https://slack.com/api/conversations.history").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "messages": [
                    _make_message("1700000001.000001", "PROJ-123 is blocked"),
                    _make_message("1700000002.000002", "Unrelated message"),
                    _make_message("1700000003.000003", "Another PROJ-123 mention"),
                ],
                "response_metadata": {"next_cursor": ""},
            },
        )
    )

    connector = SlackConnector(slack_config)
    results = await connector.search_messages("PROJ-123")

    # Only messages containing "PROJ-123"
    assert len(results) == 2
    for r in results:
        assert "PROJ-123" in str(r.payload.get("text", "")).upper()


@respx.mock
async def test_slack_empty_channels() -> None:
    config = SlackConfig(enabled=True, channels=[])
    connector = SlackConnector(config)
    results = await connector.sync()
    assert results == []


@respx.mock
async def test_slack_token_fallback_to_credential_file(
    slack_config: SlackConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("SLACK_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("slack", "file-token-slack")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(
            200,
            json={"ok": True, "messages": [], "response_metadata": {"next_cursor": ""}},
        )

    respx.get("https://slack.com/api/conversations.history").mock(side_effect=side_effect)

    connector = SlackConnector(slack_config)
    await connector.sync()

    assert captured_headers.get("authorization") == "Bearer file-token-slack"
