"""Tests for the Jira connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import JiraConfig
from blamegraph.connectors.jira import JiraConnector
from blamegraph.errors import ConnectorError


@pytest.fixture()
def jira_config() -> JiraConfig:
    return JiraConfig(
        base_url="https://jira.example.com",
        project_keys=["MOB", "PLAT"],
        token_env="JIRA_TOKEN",
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("JIRA_TOKEN", "test-token-123")


def _make_issue(key: str) -> dict:
    return {
        "key": key,
        "fields": {
            "summary": f"Summary of {key}",
            "description": f"Description of {key}",
            "status": {"name": "In Progress"},
            "assignee": {"displayName": "Alice"},
            "labels": ["backend"],
            "components": [{"name": "api"}],
            "priority": {"name": "High"},
            "duedate": "2024-06-01",
            "issuelinks": [],
            "comment": {
                "comments": [
                    {"id": "1001", "body": "First comment", "author": {"displayName": "Bob"}},
                ]
            },
        },
        "changelog": {
            "histories": [
                {
                    "created": "2024-01-10T12:00:00.000+0000",
                    "items": [
                        {
                            "field": "status",
                            "fromString": "Open",
                            "toString": "In Progress",
                        }
                    ],
                }
            ]
        },
    }


@respx.mock
async def test_jira_sync_single_page(jira_config: JiraConfig) -> None:
    """Test basic sync returns parsed RawPayloads."""
    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(
        return_value=httpx.Response(
            200,
            json={
                "startAt": 0,
                "maxResults": 50,
                "total": 2,
                "issues": [_make_issue("MOB-1"), _make_issue("MOB-2")],
            },
        )
    )

    connector = JiraConnector(jira_config)
    results = await connector.sync()

    assert len(results) == 2
    assert results[0].source == "jira"
    assert results[0].external_id == "MOB-1"
    assert results[1].external_id == "MOB-2"
    assert results[0].payload["key"] == "MOB-1"


@respx.mock
async def test_jira_sync_pagination(jira_config: JiraConfig) -> None:
    """Test startAt pagination fetches multiple pages."""
    route = respx.get("https://jira.example.com/rest/api/3/search/jql")

    call_count = 0

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        start = int(request.url.params.get("startAt", "0"))
        call_count += 1
        if start == 0:
            return httpx.Response(
                200,
                json={
                    "startAt": 0,
                    "maxResults": 2,
                    "total": 3,
                    "issues": [_make_issue("MOB-1"), _make_issue("MOB-2")],
                },
            )
        else:
            return httpx.Response(
                200,
                json={
                    "startAt": 2,
                    "maxResults": 2,
                    "total": 3,
                    "issues": [_make_issue("MOB-3")],
                },
            )

    route.mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    results = await connector.sync()

    assert len(results) == 3
    assert call_count == 2
    assert results[2].external_id == "MOB-3"


@respx.mock
async def test_jira_sync_incremental(jira_config: JiraConfig) -> None:
    """Test that 'since' param adds updated>= to JQL."""
    route = respx.get("https://jira.example.com/rest/api/3/search/jql")

    captured_jql = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_jql
        captured_jql = request.url.params.get("jql", "")
        return httpx.Response(
            200,
            json={"startAt": 0, "maxResults": 50, "total": 0, "issues": []},
        )

    route.mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    since = datetime(2024, 6, 15, 10, 30)
    await connector.sync(since=since)

    assert captured_jql is not None
    assert 'updated >= "2024-06-15 10:30"' in captured_jql


@respx.mock
async def test_jira_auth_header(jira_config: JiraConfig) -> None:
    """Test that Bearer token auth header is sent."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(
            200,
            json={"startAt": 0, "maxResults": 50, "total": 0, "issues": []},
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("authorization") == "Bearer test-token-123"


@respx.mock
async def test_jira_field_extraction(jira_config: JiraConfig) -> None:
    """Test that requested fields are included in the search params."""
    captured_fields = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_fields
        captured_fields = request.url.params.get("fields", "")
        return httpx.Response(
            200,
            json={"startAt": 0, "maxResults": 50, "total": 1, "issues": [_make_issue("MOB-1")]},
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    await connector.sync()

    assert captured_fields is not None
    expected_fields = [
        "key",
        "summary",
        "status",
        "assignee",
        "labels",
        "components",
        "priority",
        "issuelinks",
        "comment",
        "changelog",
    ]
    for field in expected_fields:
        assert field in captured_fields


@respx.mock
async def test_jira_health_check_success(jira_config: JiraConfig) -> None:
    respx.get("https://jira.example.com/rest/api/3/serverInfo").mock(
        return_value=httpx.Response(200, json={"serverTitle": "Jira"})
    )
    connector = JiraConnector(jira_config)
    assert await connector.health_check() is True


@respx.mock
async def test_jira_health_check_failure(jira_config: JiraConfig) -> None:
    respx.get("https://jira.example.com/rest/api/3/serverInfo").mock(
        return_value=httpx.Response(401)
    )
    connector = JiraConnector(jira_config)
    assert await connector.health_check() is False


@respx.mock
async def test_jira_api_error_raises(jira_config: JiraConfig) -> None:
    """Test that non-200 response raises ConnectorError."""
    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )

    connector = JiraConnector(jira_config)
    with pytest.raises(ConnectorError, match="500"):
        await connector.sync()


async def test_jira_missing_token_raises(
    jira_config: JiraConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that missing env var and credential file raises ConnectorError."""
    from blamegraph import credentials

    monkeypatch.delenv("JIRA_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = JiraConnector(jira_config)
    with pytest.raises(ConnectorError, match="JIRA_TOKEN"):
        await connector.sync()


@respx.mock
async def test_jira_search_by_key(jira_config: JiraConfig) -> None:
    """Test search_by_key fetches a single issue by its key."""
    captured_jql = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_jql
        captured_jql = request.url.params.get("jql", "")
        return httpx.Response(
            200,
            json={
                "startAt": 0,
                "maxResults": 1,
                "total": 1,
                "issues": [_make_issue("PROJ-123")],
            },
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    results = await connector.search_by_key("PROJ-123")

    assert len(results) == 1
    assert results[0].external_id == "PROJ-123"
    assert captured_jql is not None
    assert 'key = "PROJ-123"' in captured_jql


@respx.mock
async def test_jira_search_linked(jira_config: JiraConfig) -> None:
    """Test search_linked fetches issues linked to a key."""
    captured_jql = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_jql
        captured_jql = request.url.params.get("jql", "")
        return httpx.Response(
            200,
            json={
                "startAt": 0,
                "maxResults": 50,
                "total": 2,
                "issues": [_make_issue("PLAT-456"), _make_issue("INFRA-89")],
            },
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    results = await connector.search_linked("PROJ-123")

    assert len(results) == 2
    assert captured_jql is not None
    assert 'linkedIssues("PROJ-123")' in captured_jql


@respx.mock
async def test_jira_search_text(jira_config: JiraConfig) -> None:
    """Test search_text uses text ~ JQL query."""
    captured_jql = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_jql
        captured_jql = request.url.params.get("jql", "")
        return httpx.Response(
            200,
            json={
                "startAt": 0,
                "maxResults": 50,
                "total": 1,
                "issues": [_make_issue("MOB-42")],
            },
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    results = await connector.search_text("login bug")

    assert len(results) == 1
    assert captured_jql is not None
    assert 'text ~ "login bug"' in captured_jql


@respx.mock
async def test_jira_empty_project_keys() -> None:
    """Test that no project keys returns empty list."""
    config = JiraConfig(base_url="https://jira.example.com", project_keys=[])
    connector = JiraConnector(config)
    results = await connector.sync()
    assert results == []


@respx.mock
async def test_jira_token_fallback_to_credential_file(
    jira_config: JiraConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("JIRA_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("jira", "file-token-jira")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(
            200,
            json={"startAt": 0, "maxResults": 50, "total": 0, "issues": []},
        )

    respx.get("https://jira.example.com/rest/api/3/search/jql").mock(side_effect=side_effect)

    connector = JiraConnector(jira_config)
    await connector.sync()

    assert captured_headers.get("authorization") == "Bearer file-token-jira"
