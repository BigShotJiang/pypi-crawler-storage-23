"""Tests for the Bitbucket connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import BitbucketConfig
from blamegraph.connectors.bitbucket import BitbucketConnector
from blamegraph.errors import ConnectorError


@pytest.fixture()
def bitbucket_config() -> BitbucketConfig:
    return BitbucketConfig(
        base_url="https://api.bitbucket.org/2.0",
        workspace="myteam",
        repos=["myrepo"],
        token_env="BITBUCKET_TOKEN",
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BITBUCKET_TOKEN", "bb-test-token")


def _make_pr(pr_id: int) -> dict:
    return {
        "id": pr_id,
        "title": f"PR #{pr_id}",
        "state": "OPEN",
        "author": {"display_name": "Alice"},
        "source": {"branch": {"name": "feature"}},
        "destination": {"branch": {"name": "main"}},
        "created_on": "2024-01-10T12:00:00Z",
        "updated_on": "2024-01-12T15:00:00Z",
    }


def _make_issue(issue_id: int) -> dict:
    return {
        "id": issue_id,
        "title": f"Issue #{issue_id}",
        "state": "new",
        "reporter": {"display_name": "Bob"},
        "created_on": "2024-01-10T12:00:00Z",
        "updated_on": "2024-01-12T15:00:00Z",
    }


@respx.mock
async def test_bitbucket_sync_single_page(bitbucket_config: BitbucketConfig) -> None:
    """Test basic sync returns PRs and issues."""
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        return_value=httpx.Response(
            200, json={"values": [_make_pr(1), _make_pr(2)]}
        )
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(
            200, json={"values": [_make_issue(10)]}
        )
    )

    connector = BitbucketConnector(bitbucket_config)
    results = await connector.sync()

    sources = [r.source for r in results]
    assert "bitbucket_pr" in sources
    assert "bitbucket_issue" in sources

    prs = [r for r in results if r.source == "bitbucket_pr"]
    assert len(prs) == 2
    assert prs[0].external_id == "myteam/myrepo!1"

    issues = [r for r in results if r.source == "bitbucket_issue"]
    assert len(issues) == 1
    assert issues[0].external_id == "myteam/myrepo#10"


@respx.mock
async def test_bitbucket_next_url_pagination(bitbucket_config: BitbucketConfig) -> None:
    """Test body-based pagination using 'next' URL."""
    call_count = 0

    def pr_side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(
                200,
                json={
                    "values": [_make_pr(1)],
                    "next": "https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests?page=2",
                },
            )
        else:
            return httpx.Response(200, json={"values": [_make_pr(2)]})

    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        side_effect=pr_side_effect
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(200, json={"values": []})
    )

    connector = BitbucketConnector(bitbucket_config)
    results = await connector.sync()

    prs = [r for r in results if r.source == "bitbucket_pr"]
    assert len(prs) == 2
    assert call_count == 2


@respx.mock
async def test_bitbucket_bearer_auth(bitbucket_config: BitbucketConfig) -> None:
    """Test that Bearer token is sent in Authorization header."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(200, json={"values": []})

    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        side_effect=side_effect
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(200, json={"values": []})
    )

    connector = BitbucketConnector(bitbucket_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("authorization") == "Bearer bb-test-token"


@respx.mock
async def test_bitbucket_incremental_sync(bitbucket_config: BitbucketConfig) -> None:
    """Test that since param adds 'q' with updated_on filter."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json={"values": []})

    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        side_effect=side_effect
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(200, json={"values": []})
    )

    connector = BitbucketConnector(bitbucket_config)
    since = datetime(2024, 6, 15, 10, 30, 0)
    await connector.sync(since=since)

    assert captured_params is not None
    assert "updated_on" in captured_params.get("q", "")
    assert "2024-06-15T10:30:00Z" in captured_params.get("q", "")


@respx.mock
async def test_bitbucket_health_check_success(bitbucket_config: BitbucketConfig) -> None:
    respx.get("https://api.bitbucket.org/2.0/user").mock(
        return_value=httpx.Response(200, json={"username": "alice"})
    )
    connector = BitbucketConnector(bitbucket_config)
    assert await connector.health_check() is True


@respx.mock
async def test_bitbucket_health_check_failure(bitbucket_config: BitbucketConfig) -> None:
    respx.get("https://api.bitbucket.org/2.0/user").mock(
        return_value=httpx.Response(401)
    )
    connector = BitbucketConnector(bitbucket_config)
    assert await connector.health_check() is False


@respx.mock
async def test_bitbucket_api_error_raises(bitbucket_config: BitbucketConfig) -> None:
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    connector = BitbucketConnector(bitbucket_config)
    with pytest.raises(ConnectorError, match="500"):
        await connector.sync()


async def test_bitbucket_missing_token_raises(
    bitbucket_config: BitbucketConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from blamegraph import credentials

    monkeypatch.delenv("BITBUCKET_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = BitbucketConnector(bitbucket_config)
    with pytest.raises(ConnectorError, match="BITBUCKET_TOKEN"):
        await connector.sync()


@respx.mock
async def test_bitbucket_empty_repos() -> None:
    config = BitbucketConfig(
        base_url="https://api.bitbucket.org/2.0", workspace="myteam", repos=[]
    )
    connector = BitbucketConnector(config)
    results = await connector.sync()
    assert results == []


@respx.mock
async def test_bitbucket_issues_disabled(bitbucket_config: BitbucketConfig) -> None:
    """Test that 404 on issues endpoint is gracefully skipped."""
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        return_value=httpx.Response(200, json={"values": [_make_pr(1)]})
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(404, text="Issue tracker is disabled")
    )

    connector = BitbucketConnector(bitbucket_config)
    results = await connector.sync()

    # Only PRs, no error
    assert len(results) == 1
    assert results[0].source == "bitbucket_pr"


@respx.mock
async def test_bitbucket_search_prs(bitbucket_config: BitbucketConfig) -> None:
    """Test search_prs uses title filter."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json={"values": [_make_pr(5)]})

    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        side_effect=side_effect
    )

    connector = BitbucketConnector(bitbucket_config)
    results = await connector.search_prs("login fix")

    assert len(results) == 1
    assert results[0].source == "bitbucket_pr"
    assert captured_params is not None
    assert "login fix" in captured_params.get("q", "")


@respx.mock
async def test_bitbucket_token_fallback_to_credential_file(
    bitbucket_config: BitbucketConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("BITBUCKET_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("bitbucket", "file-token-bb")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(200, json={"values": []})

    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/pullrequests").mock(
        side_effect=side_effect
    )
    respx.get("https://api.bitbucket.org/2.0/repositories/myteam/myrepo/issues").mock(
        return_value=httpx.Response(200, json={"values": []})
    )

    connector = BitbucketConnector(bitbucket_config)
    await connector.sync()

    assert captured_headers.get("authorization") == "Bearer file-token-bb"
