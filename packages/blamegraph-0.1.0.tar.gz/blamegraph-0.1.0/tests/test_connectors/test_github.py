"""Tests for the GitHub connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import GitHubConfig
from blamegraph.connectors.github import GitHubConnector, _parse_next_link
from blamegraph.errors import ConnectorError


@pytest.fixture()
def github_config() -> GitHubConfig:
    return GitHubConfig(
        base_url="https://api.github.com",
        repos=["octocat/hello-world"],
        token_env="GITHUB_TOKEN",
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GITHUB_TOKEN", "ghp-test-token")


def _make_issue(number: int, is_pr: bool = False) -> dict:
    issue: dict[str, object] = {
        "number": number,
        "title": f"Issue #{number}",
        "state": "open",
        "user": {"login": "alice"},
        "created_at": "2024-01-10T12:00:00Z",
        "updated_at": "2024-01-12T15:00:00Z",
    }
    if is_pr:
        issue["pull_request"] = {"url": f"https://api.github.com/repos/octocat/hello-world/pulls/{number}"}
    return issue


def _make_pr(number: int) -> dict:
    return {
        "number": number,
        "title": f"PR #{number}",
        "state": "open",
        "user": {"login": "bob"},
        "head": {"ref": "feature"},
        "base": {"ref": "main"},
        "created_at": "2024-01-10T12:00:00Z",
        "updated_at": "2024-01-12T15:00:00Z",
    }


@respx.mock
async def test_github_sync_single_page(github_config: GitHubConfig) -> None:
    """Test basic sync returns issues and PR details."""
    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        return_value=httpx.Response(
            200, json=[_make_issue(1), _make_issue(2, is_pr=True)]
        )
    )
    respx.get("https://api.github.com/repos/octocat/hello-world/pulls").mock(
        return_value=httpx.Response(200, json=[_make_pr(2)])
    )

    connector = GitHubConnector(github_config)
    results = await connector.sync()

    sources = [r.source for r in results]
    assert "github_issue" in sources
    assert "github_pr" in sources
    assert "github_pr_detail" in sources

    issues = [r for r in results if r.source == "github_issue"]
    assert len(issues) == 1
    assert issues[0].external_id == "octocat/hello-world#1"

    prs = [r for r in results if r.source == "github_pr"]
    assert len(prs) == 1
    assert prs[0].external_id == "octocat/hello-world#2"

    pr_details = [r for r in results if r.source == "github_pr_detail"]
    assert len(pr_details) == 1
    assert pr_details[0].external_id == "octocat/hello-world#pr:2"


@respx.mock
async def test_github_link_header_pagination(github_config: GitHubConfig) -> None:
    """Test pagination via Link header with rel=next."""
    call_count = 0

    def issues_side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        page = request.url.params.get("page", "")
        if page == "2":
            return httpx.Response(200, json=[_make_issue(2)])
        else:
            page2_url = "https://api.github.com/repos/octocat/hello-world/issues?page=2&per_page=100"
            return httpx.Response(
                200,
                json=[_make_issue(1)],
                headers={"Link": f'<{page2_url}>; rel="next"'},
            )

    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        side_effect=issues_side_effect
    )
    respx.get("https://api.github.com/repos/octocat/hello-world/pulls").mock(
        return_value=httpx.Response(200, json=[])
    )

    connector = GitHubConnector(github_config)
    results = await connector.sync()

    issues = [r for r in results if r.source == "github_issue"]
    assert len(issues) == 2
    assert call_count == 2


@respx.mock
async def test_github_bearer_auth(github_config: GitHubConfig) -> None:
    """Test that Bearer token is sent in Authorization header."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(200, json=[])

    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        side_effect=side_effect
    )
    respx.get("https://api.github.com/repos/octocat/hello-world/pulls").mock(
        return_value=httpx.Response(200, json=[])
    )

    connector = GitHubConnector(github_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("authorization") == "Bearer ghp-test-token"


@respx.mock
async def test_github_incremental_sync(github_config: GitHubConfig) -> None:
    """Test that since param adds 'since' to issues params."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json=[])

    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        side_effect=side_effect
    )
    respx.get("https://api.github.com/repos/octocat/hello-world/pulls").mock(
        return_value=httpx.Response(200, json=[])
    )

    connector = GitHubConnector(github_config)
    since = datetime(2024, 6, 15, 10, 30, 0)
    await connector.sync(since=since)

    assert captured_params is not None
    assert captured_params.get("since") == "2024-06-15T10:30:00Z"


@respx.mock
async def test_github_health_check_success(github_config: GitHubConfig) -> None:
    respx.get("https://api.github.com/user").mock(
        return_value=httpx.Response(200, json={"login": "octocat"})
    )
    connector = GitHubConnector(github_config)
    assert await connector.health_check() is True


@respx.mock
async def test_github_health_check_failure(github_config: GitHubConfig) -> None:
    respx.get("https://api.github.com/user").mock(return_value=httpx.Response(401))
    connector = GitHubConnector(github_config)
    assert await connector.health_check() is False


@respx.mock
async def test_github_api_error_raises(github_config: GitHubConfig) -> None:
    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    connector = GitHubConnector(github_config)
    with pytest.raises(ConnectorError, match="500"):
        await connector.sync()


async def test_github_missing_token_raises(
    github_config: GitHubConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from blamegraph import credentials

    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = GitHubConnector(github_config)
    with pytest.raises(ConnectorError, match="GITHUB_TOKEN"):
        await connector.sync()


@respx.mock
async def test_github_empty_repos() -> None:
    config = GitHubConfig(base_url="https://api.github.com", repos=[])
    connector = GitHubConnector(config)
    results = await connector.sync()
    assert results == []


@respx.mock
async def test_github_search_issues(github_config: GitHubConfig) -> None:
    """Test search_issues uses the search/issues endpoint."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(
            200,
            json={
                "items": [
                    {"number": 10, "title": "Login fix"},
                    {"number": 11, "title": "Login refactor"},
                ]
            },
        )

    respx.get("https://api.github.com/search/issues").mock(side_effect=side_effect)

    connector = GitHubConnector(github_config)
    results = await connector.search_issues("login fix")

    assert len(results) == 2
    assert results[0].source == "github_issue"
    assert captured_params is not None
    assert "login fix" in captured_params.get("q", "")


@respx.mock
async def test_github_token_fallback_to_credential_file(
    github_config: GitHubConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("github", "file-token-github")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(200, json=[])

    respx.get("https://api.github.com/repos/octocat/hello-world/issues").mock(
        side_effect=side_effect
    )
    respx.get("https://api.github.com/repos/octocat/hello-world/pulls").mock(
        return_value=httpx.Response(200, json=[])
    )

    connector = GitHubConnector(github_config)
    await connector.sync()

    assert captured_headers.get("authorization") == "Bearer file-token-github"


def test_parse_next_link() -> None:
    header = (
        '<https://api.github.com/page2>; rel="next", '
        '<https://api.github.com/page1>; rel="first"'
    )
    assert _parse_next_link(header) == "https://api.github.com/page2"


def test_parse_next_link_no_next() -> None:
    header = '<https://api.github.com/page1>; rel="first"'
    assert _parse_next_link(header) is None
