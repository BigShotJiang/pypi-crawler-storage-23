"""Tests for the Microsoft Teams connector."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest
import respx

from blamegraph.config import TeamsConfig
from blamegraph.connectors.teams import TeamsConnector
from blamegraph.errors import ConnectorError


@pytest.fixture()
def teams_config() -> TeamsConfig:
    return TeamsConfig(
        enabled=True,
        team_id="team-123",
        channels=["channel-456"],
        token_env="TEAMS_TOKEN",
    )


@pytest.fixture(autouse=True)
def _set_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TEAMS_TOKEN", "teams-test-token")


def _make_message(msg_id: str, content: str) -> dict:
    return {
        "id": msg_id,
        "body": {"contentType": "text", "content": content},
        "from": {"user": {"displayName": "Alice"}},
        "createdDateTime": "2024-01-10T12:00:00Z",
        "lastModifiedDateTime": "2024-01-12T15:00:00Z",
    }


def _make_reply(reply_id: str, content: str) -> dict:
    return {
        "id": reply_id,
        "body": {"contentType": "text", "content": content},
        "from": {"user": {"displayName": "Bob"}},
        "createdDateTime": "2024-01-10T13:00:00Z",
        "lastModifiedDateTime": "2024-01-10T13:00:00Z",
    }


@respx.mock
async def test_teams_sync_single_page(teams_config: TeamsConfig) -> None:
    """Test basic sync returns messages."""
    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        return_value=httpx.Response(
            200, json={"value": [_make_message("msg-1", "Hello world")]}
        )
    )
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-1/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))

    connector = TeamsConnector(teams_config)
    results = await connector.sync()

    assert len(results) == 1
    assert results[0].source == "teams"
    assert results[0].external_id == "team-123:channel-456:msg-1"


@respx.mock
async def test_teams_odata_pagination(teams_config: TeamsConfig) -> None:
    """Test OData pagination using @odata.nextLink."""
    call_count = 0

    def msg_side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(
                200,
                json={
                    "value": [_make_message("msg-1", "Page 1")],
                    "@odata.nextLink": "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages?$skip=1",
                },
            )
        else:
            return httpx.Response(
                200, json={"value": [_make_message("msg-2", "Page 2")]}
            )

    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        side_effect=msg_side_effect
    )
    # Reply endpoints for both messages
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-1/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-2/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))

    connector = TeamsConnector(teams_config)
    results = await connector.sync()

    msgs = [r for r in results if r.source == "teams"]
    assert len(msgs) == 2
    assert call_count == 2


@respx.mock
async def test_teams_bearer_auth(teams_config: TeamsConfig) -> None:
    """Test that Bearer token is sent in Authorization header."""
    captured_headers = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_headers
        captured_headers = dict(request.headers)
        return httpx.Response(200, json={"value": []})

    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        side_effect=side_effect
    )

    connector = TeamsConnector(teams_config)
    await connector.sync()

    assert captured_headers is not None
    assert captured_headers.get("authorization") == "Bearer teams-test-token"


@respx.mock
async def test_teams_incremental_sync(teams_config: TeamsConfig) -> None:
    """Test that since param adds $filter with lastModifiedDateTime."""
    captured_params = None

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal captured_params
        captured_params = dict(request.url.params)
        return httpx.Response(200, json={"value": []})

    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        side_effect=side_effect
    )

    connector = TeamsConnector(teams_config)
    since = datetime(2024, 6, 15, 10, 30, 0)
    await connector.sync(since=since)

    assert captured_params is not None
    assert "lastModifiedDateTime" in captured_params.get("$filter", "")
    assert "2024-06-15T10:30:00Z" in captured_params.get("$filter", "")


@respx.mock
async def test_teams_thread_replies(teams_config: TeamsConfig) -> None:
    """Test that thread replies are fetched for messages."""
    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        return_value=httpx.Response(
            200, json={"value": [_make_message("msg-1", "Parent message")]}
        )
    )
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-1/replies"
    ).mock(
        return_value=httpx.Response(
            200, json={"value": [_make_reply("reply-1", "Reply text")]}
        )
    )

    connector = TeamsConnector(teams_config)
    results = await connector.sync()

    assert len(results) == 2
    sources = [r.source for r in results]
    assert "teams" in sources
    assert "teams_reply" in sources

    reply = next(r for r in results if r.source == "teams_reply")
    assert reply.external_id == "team-123:channel-456:msg-1:reply-1"


@respx.mock
async def test_teams_health_check_success(teams_config: TeamsConfig) -> None:
    respx.get("https://graph.microsoft.com/v1.0/me").mock(
        return_value=httpx.Response(200, json={"displayName": "Alice"})
    )
    connector = TeamsConnector(teams_config)
    assert await connector.health_check() is True


@respx.mock
async def test_teams_health_check_failure(teams_config: TeamsConfig) -> None:
    respx.get("https://graph.microsoft.com/v1.0/me").mock(
        return_value=httpx.Response(401)
    )
    connector = TeamsConnector(teams_config)
    assert await connector.health_check() is False


@respx.mock
async def test_teams_api_error_raises(teams_config: TeamsConfig) -> None:
    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    connector = TeamsConnector(teams_config)
    with pytest.raises(ConnectorError, match="500"):
        await connector.sync()


async def test_teams_missing_token_raises(
    teams_config: TeamsConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from blamegraph import credentials

    monkeypatch.delenv("TEAMS_TOKEN", raising=False)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", tmp_path / "empty.yaml")
    connector = TeamsConnector(teams_config)
    with pytest.raises(ConnectorError, match="TEAMS_TOKEN"):
        await connector.sync()


@respx.mock
async def test_teams_empty_channels() -> None:
    config = TeamsConfig(enabled=True, team_id="team-123", channels=[])
    connector = TeamsConnector(config)
    results = await connector.sync()
    assert results == []


@respx.mock
async def test_teams_search_messages(teams_config: TeamsConfig) -> None:
    """Test search_messages uses client-side filtering."""
    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "value": [
                    _make_message("msg-1", "PROJ-123 is blocked"),
                    _make_message("msg-2", "Unrelated message"),
                    _make_message("msg-3", "Another PROJ-123 mention"),
                ]
            },
        )
    )
    # Replies for all messages (empty)
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-1/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-2/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))
    respx.get(
        "https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages/msg-3/replies"
    ).mock(return_value=httpx.Response(200, json={"value": []}))

    connector = TeamsConnector(teams_config)
    results = await connector.search_messages("PROJ-123")

    assert len(results) == 2
    for r in results:
        body = r.payload.get("body", {})
        assert isinstance(body, dict)
        assert "PROJ-123" in str(body.get("content", ""))


@respx.mock
async def test_teams_token_fallback_to_credential_file(
    teams_config: TeamsConfig, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Test that token is loaded from credential file when env var is missing."""
    from blamegraph import credentials

    monkeypatch.delenv("TEAMS_TOKEN", raising=False)
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)
    credentials.save_token("teams", "file-token-teams")

    captured_headers: dict[str, str] = {}

    def side_effect(request: httpx.Request) -> httpx.Response:
        captured_headers.update(dict(request.headers))
        return httpx.Response(200, json={"value": []})

    respx.get("https://graph.microsoft.com/v1.0/teams/team-123/channels/channel-456/messages").mock(
        side_effect=side_effect
    )

    connector = TeamsConnector(teams_config)
    await connector.sync()

    assert captured_headers.get("authorization") == "Bearer file-token-teams"
