"""Tests for the normalizer module."""

from __future__ import annotations

from datetime import datetime

from blamegraph.models import EntityType, RawPayload
from blamegraph.normalizer import (
    normalize_gitlab_mr,
    normalize_jira_issue,
    normalize_slack_message,
)


def _jira_payload() -> RawPayload:
    return RawPayload(
        source="jira",
        external_id="MOB-881",
        fetched_at=datetime(2024, 6, 15, 12, 0, 0),
        payload={
            "key": "MOB-881",
            "fields": {
                "summary": "Fix login crash on iOS 17",
                "description": "Users report crash when tapping login button.",
                "status": {"name": "In Progress"},
                "assignee": {"displayName": "Alice Smith"},
                "labels": ["ios", "crash"],
                "components": [{"name": "mobile-auth"}],
                "priority": {"name": "Critical"},
                "duedate": "2024-07-01",
                "issuelinks": [],
                "comment": {
                    "comments": [
                        {
                            "id": "10001",
                            "body": "Investigating root cause now.",
                            "author": {"displayName": "Bob"},
                        },
                        {
                            "id": "10002",
                            "body": "Found the issue in auth module.",
                            "author": {"displayName": "Alice Smith"},
                        },
                    ]
                },
            },
            "changelog": {
                "histories": [
                    {
                        "created": "2024-06-10T09:00:00.000+0000",
                        "items": [
                            {
                                "field": "status",
                                "fromString": "Open",
                                "toString": "In Progress",
                            }
                        ],
                    }
                ]
            },
        },
    )


def _gitlab_mr_payload() -> RawPayload:
    return RawPayload(
        source="gitlab_mr",
        external_id="42!99",
        fetched_at=datetime(2024, 6, 15, 12, 0, 0),
        payload={
            "iid": 99,
            "project_id": 42,
            "title": "Fix auth token refresh",
            "description": "Resolves MOB-881: token refresh was not retried on 401.",
            "state": "merged",
            "source_branch": "fix/auth-refresh",
            "target_branch": "main",
            "labels": ["bugfix"],
            "web_url": "https://gitlab.example.com/mygroup/repo/-/merge_requests/99",
            "author": {"username": "alice"},
            "created_at": "2024-06-12T10:00:00Z",
            "merged_at": "2024-06-14T16:30:00Z",
        },
    )


def _slack_message_payload() -> RawPayload:
    return RawPayload(
        source="slack",
        external_id="C12345:1700000001.000001",
        fetched_at=datetime(2024, 6, 15, 12, 0, 0),
        payload={
            "ts": "1700000001.000001",
            "text": (
                "Hey team, MOB-881 is blocking our release."
                " Can someone from platform look at PLAT-312?"
            ),
            "user": "U001",
            "_channel": "C12345",
            "thread_ts": "",
            "reactions": [{"name": "eyes", "count": 3}],
        },
    )


class TestNormalizeJiraIssue:
    def test_entity_fields(self) -> None:
        entity, _, _ = normalize_jira_issue(_jira_payload())

        assert entity.id == "jira:MOB-881"
        assert entity.entity_type == EntityType.TICKET
        assert entity.external_id == "MOB-881"
        assert entity.title == "Fix login crash on iOS 17"

    def test_entity_attributes(self) -> None:
        entity, _, _ = normalize_jira_issue(_jira_payload())

        assert entity.attributes["status"] == "In Progress"
        assert entity.attributes["priority"] == "Critical"
        assert entity.attributes["assignee"] == "Alice Smith"
        assert entity.attributes["labels"] == ["ios", "crash"]
        assert entity.attributes["components"] == ["mobile-auth"]
        assert entity.attributes["duedate"] == "2024-07-01"

    def test_description_artifact(self) -> None:
        _, _, artifacts = normalize_jira_issue(_jira_payload())

        descriptions = [a for a in artifacts if a.artifact_type == "description"]
        assert len(descriptions) == 1
        assert "crash when tapping login" in descriptions[0].text

    def test_comment_artifacts(self) -> None:
        _, _, artifacts = normalize_jira_issue(_jira_payload())

        comments = [a for a in artifacts if a.artifact_type == "comment"]
        assert len(comments) == 2
        assert comments[0].metadata["author"] == "Bob"
        assert comments[1].text == "Found the issue in auth module."

    def test_changelog_events(self) -> None:
        _, events, _ = normalize_jira_issue(_jira_payload())

        assert len(events) >= 1
        status_events = [e for e in events if "status" in e.kind]
        assert len(status_events) == 1
        assert status_events[0].payload["from"] == "Open"
        assert status_events[0].payload["to"] == "In Progress"
        assert status_events[0].ts == datetime(2024, 6, 10, 9, 0, 0)

    def test_empty_description(self) -> None:
        payload = _jira_payload()
        payload.payload["fields"]["description"] = None
        _entity, _, artifacts = normalize_jira_issue(payload)
        descriptions = [a for a in artifacts if a.artifact_type == "description"]
        assert len(descriptions) == 0

    def test_no_changelog(self) -> None:
        payload = _jira_payload()
        payload.payload.pop("changelog", None)
        _, events, _ = normalize_jira_issue(payload)
        assert events == []


class TestNormalizeGitLabMR:
    def test_entity_fields(self) -> None:
        entity, _, _ = normalize_gitlab_mr(_gitlab_mr_payload())

        assert entity.id == "gitlab_mr:42!99"
        assert entity.entity_type == EntityType.PR
        assert entity.external_id == "42!99"
        assert entity.title == "Fix auth token refresh"

    def test_entity_attributes(self) -> None:
        entity, _, _ = normalize_gitlab_mr(_gitlab_mr_payload())

        assert entity.attributes["state"] == "merged"
        assert entity.attributes["source_branch"] == "fix/auth-refresh"
        assert entity.attributes["target_branch"] == "main"
        assert entity.attributes["author"] == "alice"
        assert entity.attributes["labels"] == ["bugfix"]

    def test_title_artifact(self) -> None:
        _, _, artifacts = normalize_gitlab_mr(_gitlab_mr_payload())

        titles = [a for a in artifacts if a.artifact_type == "title"]
        assert len(titles) == 1
        assert titles[0].text == "Fix auth token refresh"

    def test_description_artifact(self) -> None:
        _, _, artifacts = normalize_gitlab_mr(_gitlab_mr_payload())

        descriptions = [a for a in artifacts if a.artifact_type == "description"]
        assert len(descriptions) == 1
        assert "MOB-881" in descriptions[0].text

    def test_state_event(self) -> None:
        _, events, _ = normalize_gitlab_mr(_gitlab_mr_payload())

        assert len(events) == 1
        assert events[0].kind == "mr_state:merged"
        assert events[0].ts == datetime(2024, 6, 14, 16, 30, 0)

    def test_no_description(self) -> None:
        payload = _gitlab_mr_payload()
        payload.payload["description"] = None
        _, _, artifacts = normalize_gitlab_mr(payload)
        descriptions = [a for a in artifacts if a.artifact_type == "description"]
        assert len(descriptions) == 0


class TestNormalizeSlackMessage:
    def test_entity_fields(self) -> None:
        entity, _, _ = normalize_slack_message(_slack_message_payload())

        assert entity.id == "slack:C12345:1700000001.000001"
        assert entity.entity_type == EntityType.TICKET
        assert entity.external_id == "C12345:1700000001.000001"

    def test_entity_attributes(self) -> None:
        entity, _, _ = normalize_slack_message(_slack_message_payload())

        assert entity.attributes["channel"] == "C12345"
        assert entity.attributes["user"] == "U001"

    def test_message_artifact(self) -> None:
        _, _, artifacts = normalize_slack_message(_slack_message_payload())

        assert len(artifacts) == 1
        assert artifacts[0].artifact_type == "message"
        assert "MOB-881" in artifacts[0].text
        assert artifacts[0].metadata["user"] == "U001"

    def test_message_event(self) -> None:
        _, events, _ = normalize_slack_message(_slack_message_payload())

        assert len(events) == 1
        assert events[0].kind == "message_posted"
        assert events[0].payload["channel"] == "C12345"

    def test_title_truncation(self) -> None:
        payload = _slack_message_payload()
        payload.payload["text"] = "x" * 200
        entity, _, _ = normalize_slack_message(payload)
        assert len(entity.title) <= 120

    def test_reactions_in_attributes(self) -> None:
        entity, _, _ = normalize_slack_message(_slack_message_payload())
        reactions = entity.attributes.get("reactions", [])
        assert len(reactions) == 1
        assert reactions[0]["name"] == "eyes"
