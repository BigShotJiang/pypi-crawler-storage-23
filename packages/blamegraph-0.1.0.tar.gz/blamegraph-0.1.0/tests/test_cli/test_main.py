"""Tests for the BlameGraph CLI commands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from blamegraph.cli.app import cli


class TestCLIHelp:
    """Verify --help works for all commands."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_main_help(self) -> None:
        result = self.runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "BlameGraph" in result.output

    def test_init_help(self) -> None:
        result = self.runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0

    def test_sync_help(self) -> None:
        result = self.runner.invoke(cli, ["sync", "--help"])
        assert result.exit_code == 0
        assert "--since" in result.output
        assert "--source" in result.output

    def test_analyze_help(self) -> None:
        result = self.runner.invoke(cli, ["analyze", "--help"])
        assert result.exit_code == 0

    def test_ask_help(self) -> None:
        result = self.runner.invoke(cli, ["ask", "--help"])
        assert result.exit_code == 0
        assert "--json" in result.output

    def test_chain_help(self) -> None:
        result = self.runner.invoke(cli, ["chain", "--help"])
        assert result.exit_code == 0
        assert "--from" in result.output

    def test_draft_help(self) -> None:
        result = self.runner.invoke(cli, ["draft", "--help"])
        assert result.exit_code == 0
        assert "--ticket" in result.output
        assert "--yes" in result.output

    def test_apply_help(self) -> None:
        result = self.runner.invoke(cli, ["apply", "--help"])
        assert result.exit_code == 0
        assert "--draft-id" in result.output
        assert "--yes" in result.output

    def test_report_help(self) -> None:
        result = self.runner.invoke(cli, ["report", "--help"])
        assert result.exit_code == 0
        assert "--team" in result.output
        assert "--since" in result.output
        assert "--output" in result.output

    def test_config_help(self) -> None:
        result = self.runner.invoke(cli, ["config", "--help"])
        assert result.exit_code == 0
        assert "set-token" in result.output
        assert "show" in result.output
        assert "remove-token" in result.output


class TestCLIInit:
    """Test the init command."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_init_creates_config(self) -> None:
        with (
            self.runner.isolated_filesystem(),
            patch("blamegraph.cli.commands.setup.save_token") as mock_save,
            patch("blamegraph.cli.commands.setup.update_config_yaml"),
        ):
            # 2 required tokens + workspace + jira url + gitlab url + slack
            # + github repos + bitbucket workspace + teams team id
            result = self.runner.invoke(
                cli, ["init"], input="jira-tok\nanthropic-key\n\n\n\n\n\n\n\n"
            )
            assert result.exit_code == 0
            assert Path("blamegraph.yaml").exists()
            assert "Created config" in result.output
            assert "Tokens saved" in result.output
            assert mock_save.call_count == 2
            mock_save.assert_any_call("jira", "jira-tok")
            mock_save.assert_any_call("anthropic", "anthropic-key")

    def test_init_existing_config(self) -> None:
        with self.runner.isolated_filesystem():
            Path("blamegraph.yaml").write_text("workspace: test\n")
            result = self.runner.invoke(cli, ["init"])
            assert result.exit_code == 0
            assert "already exists" in result.output

    def test_init_custom_path(self) -> None:
        with (
            self.runner.isolated_filesystem(),
            patch("blamegraph.cli.commands.setup.save_token"),
            patch("blamegraph.cli.commands.setup.update_config_yaml"),
        ):
            # 2 required tokens + workspace + jira url + gitlab url + slack
            # + github repos + bitbucket workspace + teams team id
            result = self.runner.invoke(
                cli, ["-c", "custom.yaml", "init"],
                input="j-tok\na-key\n\n\n\n\n\n\n\n",
            )
            assert result.exit_code == 0
            assert Path("custom.yaml").exists()


class TestCLICommands:
    """Test basic invocation of stub commands."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_sync_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sync"])
            assert result.exit_code == 0
            assert "Sync" in result.output

    def test_sync_with_options(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sync", "--since", "7d", "--source", "jira"])
            assert result.exit_code == 0
            assert "jira" in result.output

    def test_analyze_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["analyze"])
            assert result.exit_code == 0
            assert "Analyze" in result.output

    def test_ask_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["ask", "--no-llm", "what is blocked?"])
            assert result.exit_code == 0
            assert "Results" in result.output

    def test_ask_json(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["ask", "--no-llm", "--json", "test question"])
            assert result.exit_code == 0
            assert '"question"' in result.output

    def test_chain_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["chain", "--from", "MOB-881"])
            assert result.exit_code == 0
            assert "MOB-881" in result.output

    def test_chain_json(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["chain", "--from", "MOB-881", "--json"])
            assert result.exit_code == 0
            assert '"root"' in result.output

    def test_draft_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["draft", "--ticket", "PROJ-100"])
            assert result.exit_code == 0
            assert "DRY-RUN" in result.output

    def test_draft_with_yes(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["draft", "--ticket", "PROJ-100", "--yes"])
            assert result.exit_code == 0
            assert "WRITE" in result.output

    def test_apply_dry_run(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["apply", "--draft-id", "draft-001"])
            assert result.exit_code == 0
            assert "Dry-run" in result.output

    def test_apply_with_yes(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["apply", "--draft-id", "draft-001", "--yes"])
            assert result.exit_code == 0
            assert "Applying" in result.output

    def test_report_runs(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["report"])
            assert result.exit_code == 0
            assert "Report" in result.output

    def test_report_with_options(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["report", "--team", "mobile", "--since", "24h"])
            assert result.exit_code == 0

    def test_report_json(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["report", "--json"])
            assert result.exit_code == 0
            assert '"report"' in result.output

    def test_report_output_file(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["report", "--output", "out.md"])
            assert result.exit_code == 0
            assert Path("out.md").exists()


class TestCLIConfig:
    """Test the config subcommands."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_config_set_token(self) -> None:
        with patch("blamegraph.cli.commands.config.save_token") as mock_save:
            result = self.runner.invoke(cli, ["config", "set-token", "jira"], input="my-token\n")
            assert result.exit_code == 0
            assert "Token saved" in result.output
            mock_save.assert_called_once_with("jira", "my-token")

    def test_config_show_empty(self) -> None:
        services = {"jira": False, "gitlab": False, "slack": False}
        with patch("blamegraph.cli.commands.config.list_services", return_value=services):
            result = self.runner.invoke(cli, ["config", "show"])
            assert result.exit_code == 0
            assert "not set" in result.output

    def test_config_show_with_tokens(self) -> None:
        services = {"jira": True, "gitlab": False, "slack": False}
        with (
            patch("blamegraph.cli.commands.config.list_services", return_value=services),
            patch("blamegraph.cli.commands.config.load_token", return_value="my-secret-token"),
        ):
            result = self.runner.invoke(cli, ["config", "show"])
            assert result.exit_code == 0
            assert "my-s****" in result.output
            assert "not set" in result.output

    def test_config_remove_token(self) -> None:
        with patch("blamegraph.cli.commands.config.remove_token") as mock_remove:
            result = self.runner.invoke(cli, ["config", "remove-token", "jira"])
            assert result.exit_code == 0
            assert "Token removed" in result.output
            mock_remove.assert_called_once_with("jira")

    def test_config_set_token_invalid_service(self) -> None:
        result = self.runner.invoke(cli, ["config", "set-token", "unknown"])
        assert result.exit_code != 0

    def test_config_set_token_anthropic(self) -> None:
        with patch("blamegraph.cli.commands.config.save_token") as mock_save:
            result = self.runner.invoke(
                cli, ["config", "set-token", "anthropic"], input="anthropic-key\n"
            )
            assert result.exit_code == 0
            assert "Token saved" in result.output
            mock_save.assert_called_once_with("anthropic", "anthropic-key")


class TestCLIAsk:
    """Test the ask command with LLM flags."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_ask_no_llm_flag(self) -> None:
        """Test that --no-llm skips LLM analysis."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["ask", "--no-llm", "what blocks X?"])
            assert result.exit_code == 0
            assert "Results" in result.output

    def test_ask_with_model_flag(self) -> None:
        """Test that --model flag is accepted."""
        with self.runner.isolated_filesystem():
            # No API key so LLM client won't be created, but flag should be accepted
            result = self.runner.invoke(cli, ["ask", "--model", "gpt-4o", "what blocks X?"])
            assert result.exit_code == 0

    def test_ask_help_shows_llm_options(self) -> None:
        result = self.runner.invoke(cli, ["ask", "--help"])
        assert result.exit_code == 0
        assert "--no-llm" in result.output
        assert "--model" in result.output


class TestCLISyncSources:
    """Test sync command with new source options."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_sync_with_github_source(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sync", "--source", "github"])
            assert result.exit_code == 0
            assert "github" in result.output

    def test_sync_with_bitbucket_source(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sync", "--source", "bitbucket"])
            assert result.exit_code == 0
            assert "bitbucket" in result.output

    def test_sync_with_teams_source(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sync", "--source", "teams"])
            assert result.exit_code == 0
            assert "teams" in result.output


class TestCLIConfigNewCommands:
    """Test the new config set-* subcommands."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_config_set_github_help(self) -> None:
        result = self.runner.invoke(cli, ["config", "set-github", "--help"])
        assert result.exit_code == 0
        assert "--repos" in result.output

    def test_config_set_bitbucket_help(self) -> None:
        result = self.runner.invoke(cli, ["config", "set-bitbucket", "--help"])
        assert result.exit_code == 0
        assert "--workspace" in result.output
        assert "--repos" in result.output

    def test_config_set_teams_help(self) -> None:
        result = self.runner.invoke(cli, ["config", "set-teams", "--help"])
        assert result.exit_code == 0
        assert "--team-id" in result.output
        assert "--channels" in result.output


# -- New tests for the modular CLI --


class TestCLIGlobalOptions:
    """Test global CLI options (--version, --no-color, --verbose)."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_version_flag(self) -> None:
        result = self.runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "blamegraph" in result.output

    def test_no_color_flag(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["--no-color", "sync"])
            assert result.exit_code == 0
            assert "Sync" in result.output

    def test_verbose_flag(self) -> None:
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["--verbose", "sync"])
            assert result.exit_code == 0


class TestCommandAliases:
    """Test that single-letter command aliases work."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_r_alias_is_radar(self) -> None:
        result = self.runner.invoke(cli, ["r", "--help"])
        assert result.exit_code == 0
        assert "Morning Radar" in result.output

    def test_b_alias_is_blast(self) -> None:
        result = self.runner.invoke(cli, ["b", "--help"])
        assert result.exit_code == 0
        assert "Blast Radius" in result.output

    def test_a_alias_is_ask(self) -> None:
        result = self.runner.invoke(cli, ["a", "--help"])
        assert result.exit_code == 0
        assert "Answer questions" in result.output

    def test_s_alias_is_sync(self) -> None:
        result = self.runner.invoke(cli, ["s", "--help"])
        assert result.exit_code == 0
        assert "Ingest data" in result.output

    def test_h_alias_is_history(self) -> None:
        result = self.runner.invoke(cli, ["h", "--help"])
        assert result.exit_code == 0
        assert "history" in result.output.lower()

    def test_d_alias_is_drift(self) -> None:
        result = self.runner.invoke(cli, ["d", "--help"])
        assert result.exit_code == 0
        assert "drift" in result.output.lower()

    def test_w_alias_is_watch(self) -> None:
        result = self.runner.invoke(cli, ["w", "--help"])
        assert result.exit_code == 0
        assert "CI/CD" in result.output

    def test_u_alias_is_unblock(self) -> None:
        result = self.runner.invoke(cli, ["u", "--help"])
        assert result.exit_code == 0
        assert "Unblock" in result.output


class TestCategorizedHelp:
    """Test that --help shows categorized commands."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_help_contains_categories(self) -> None:
        result = self.runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Setup" in result.output
        assert "Data" in result.output
        assert "Analysis" in result.output
        assert "Operations" in result.output

    def test_help_contains_aliases(self) -> None:
        result = self.runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        # At least some aliases should appear in the help output
        for alias in ["(r)", "(b)", "(a)", "(s)"]:
            assert alias in result.output


class TestErrorPanel:
    """Test that BlameGraphErrors are caught and result in non-zero exit."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_blamegraph_error_exits_with_error_code(self) -> None:
        from blamegraph.errors import ConfigError

        with patch(
            "blamegraph.cli.context.load_config",
            side_effect=ConfigError("Config file not found"),
        ):
            result = self.runner.invoke(cli, ["sync"])
            assert result.exit_code == 2  # ConfigError.exit_code


class TestBackwardCompat:
    """Test that the backward-compatibility shim works."""

    def test_import_from_main(self) -> None:
        from blamegraph.cli.main import cli as main_cli

        assert main_cli is cli
