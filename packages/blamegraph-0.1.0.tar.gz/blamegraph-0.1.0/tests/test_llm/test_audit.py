"""Tests for the LLM audit logger module."""

from __future__ import annotations

import json
from pathlib import Path

from blamegraph.llm.audit import AuditLogger


class TestAuditLogger:
    """Test JSONL audit logging."""

    def test_log_creates_directory(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call("test_template", "test-model", "input text", "output text")
        assert log_dir.exists()

    def test_log_creates_file(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call("test_template", "test-model", "input text", "output text")
        log_file = log_dir / "llm_audit.jsonl"
        assert log_file.exists()

    def test_log_entry_is_valid_json(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call("dep_extract_v1", "gpt-5-mini", "some input", "some output")
        log_file = log_dir / "llm_audit.jsonl"
        line = log_file.read_text().strip()
        entry = json.loads(line)
        assert entry["template_id"] == "dep_extract_v1"
        assert entry["model"] == "gpt-5-mini"

    def test_log_entry_fields(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call(
            "ask_v1",
            "gpt-5",
            "hello world",
            "answer here",
            token_count=150,
            cost=0.003,
        )
        log_file = log_dir / "llm_audit.jsonl"
        entry = json.loads(log_file.read_text().strip())
        assert entry["input_chars"] == 11
        assert entry["output_chars"] == 11
        assert entry["token_count"] == 150
        assert entry["cost"] == 0.003
        assert "timestamp" in entry
        assert "user" in entry

    def test_multiple_entries_are_appended(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call("t1", "m1", "in1", "out1")
        logger.log_call("t2", "m2", "in2", "out2")
        log_file = log_dir / "llm_audit.jsonl"
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 2
        assert json.loads(lines[0])["template_id"] == "t1"
        assert json.loads(lines[1])["template_id"] == "t2"

    def test_existing_directory_no_error(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "logs"
        log_dir.mkdir(parents=True)
        logger = AuditLogger(log_dir=log_dir)
        logger.log_call("t", "m", "i", "o")
        assert (log_dir / "llm_audit.jsonl").exists()
