"""Tests for the LLM context assembler."""

from __future__ import annotations

from datetime import UTC, datetime

from blamegraph.config import BlameGraphConfig, LLMConfig
from blamegraph.llm.context import build_context
from blamegraph.models import Edge, EdgeType, Entity, EntityType, Evidence, InferenceMethod
from blamegraph.search import SearchResult


def _make_search_result() -> SearchResult:
    """Create a SearchResult with representative data."""
    entities = [
        Entity(
            id="t1",
            entity_type=EntityType.TICKET,
            external_id="PROJ-123",
            title="Fix login redirect",
            attributes={"status": "Blocked", "assignee": "Alice", "labels": ["backend"]},
            created_at=datetime(2025, 1, 1, tzinfo=UTC),
            updated_at=datetime(2025, 1, 2, tzinfo=UTC),
        ),
        Entity(
            id="mr1",
            entity_type=EntityType.PR,
            external_id="42!10",
            title="MR: Fix auth flow",
            attributes={"state": "merged", "author": "bob", "target_branch": "main"},
            created_at=datetime(2025, 1, 1, tzinfo=UTC),
            updated_at=datetime(2025, 1, 2, tzinfo=UTC),
        ),
    ]
    edges = [
        Edge(
            id="e1",
            from_entity="t1",
            to_entity="t2",
            edge_type=EdgeType.BLOCKS,
            confidence=0.9,
            method=InferenceMethod.HEURISTIC,
            evidence=[Evidence(source_type="jira_link", source_id="t1", snippet="blocks PLAT-456")],
            created_at=datetime(2025, 1, 1, tzinfo=UTC),
        )
    ]
    slack_mentions = [
        {"channel": "platform", "text": "PROJ-123 is stuck because of auth migration"},
    ]

    return SearchResult(
        question="co blokuje PROJ-123?",
        ticket_keys=["PROJ-123"],
        entities=entities,
        edges=edges,
        slack_mentions=slack_mentions,
        sources={"jira": 1, "gitlab": 1, "slack": 1},
    )


def test_build_context_from_search_result() -> None:
    """Test that build_context produces text with all sections."""
    result = _make_search_result()
    context = build_context(result)

    assert "## Jira Tickets" in context
    assert "PROJ-123" in context
    assert "Fix login redirect" in context
    assert "## GitLab Merge Requests" in context
    assert "42!10" in context
    assert "## Slack Mentions" in context
    assert "platform" in context
    assert "## Dependency Edges" in context
    assert "blocks" in context.lower()


def test_context_truncation() -> None:
    """Test that context is truncated to max_chars."""
    result = _make_search_result()
    context = build_context(result, max_chars=50)
    assert len(context) <= 50


def test_redaction_applied() -> None:
    """Test that redaction patterns are applied to context."""
    result = _make_search_result()
    # Add an entity with a secret-like value in title
    result.entities.append(
        Entity(
            id="t2",
            entity_type=EntityType.TICKET,
            external_id="SEC-1",
            title="Token AKIA1234567890ABCDEF exposed",
            attributes={"status": "Open"},
            created_at=datetime(2025, 1, 1, tzinfo=UTC),
            updated_at=datetime(2025, 1, 2, tzinfo=UTC),
        )
    )

    context = build_context(result)
    # The AWS key pattern should be redacted
    assert "AKIA1234567890ABCDEF" not in context
    assert "[REDACTED]" in context


def test_empty_result_returns_empty_string() -> None:
    """Test that an empty SearchResult produces empty context."""
    result = SearchResult(
        question="test?",
        ticket_keys=[],
        entities=[],
        edges=[],
        slack_mentions=[],
        sources={},
    )
    context = build_context(result)
    assert context == ""


def test_config_max_context_chars() -> None:
    """Test that config.llm.max_context_chars is respected."""
    result = _make_search_result()
    config = BlameGraphConfig(llm=LLMConfig(max_context_chars=100))
    context = build_context(result, max_chars=config.llm.max_context_chars, config=config)
    assert len(context) <= 100
