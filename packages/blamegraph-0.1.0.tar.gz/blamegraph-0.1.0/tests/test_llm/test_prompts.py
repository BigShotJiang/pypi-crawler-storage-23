"""Tests for LLM prompt constants."""

from __future__ import annotations

from blamegraph.llm.prompts import ANSWER_SYSTEM_PROMPT, EXTRACT_SYSTEM_PROMPT


def test_prompts_not_empty() -> None:
    """Ensure prompt constants are non-empty strings."""
    assert isinstance(ANSWER_SYSTEM_PROMPT, str)
    assert len(ANSWER_SYSTEM_PROMPT) > 50
    assert isinstance(EXTRACT_SYSTEM_PROMPT, str)
    assert len(EXTRACT_SYSTEM_PROMPT) > 20


def test_answer_prompt_contains_key_instructions() -> None:
    """Ensure the answer prompt includes essential analyst instructions."""
    assert "BlameGraph" in ANSWER_SYSTEM_PROMPT
    assert "blocker" in ANSWER_SYSTEM_PROMPT.lower()
    assert "recommendation" in ANSWER_SYSTEM_PROMPT.lower()
    assert "fabricate" in ANSWER_SYSTEM_PROMPT.lower()


def test_extract_prompt_mentions_json() -> None:
    """Ensure the extract prompt requests JSON output."""
    assert "JSON" in EXTRACT_SYSTEM_PROMPT
