"""Tests for the Anthropic Messages API client."""

from __future__ import annotations

import httpx
import pytest
import respx

from blamegraph.llm.anthropic import (
    AnthropicClient,
    AnthropicClientError,
    ChatMessage,
    ChatResponse,
)


@pytest.fixture()
def api_key() -> str:
    return "test-api-key-123"


@pytest.fixture()
def client(api_key: str) -> AnthropicClient:
    return AnthropicClient(
        api_key=api_key, base_url="https://api.anthropic.com/v1", max_retries=1
    )


@respx.mock
async def test_chat_completion(client: AnthropicClient) -> None:
    """Test a successful chat completion request."""
    respx.post("https://api.anthropic.com/v1/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "content": [{"type": "text", "text": "Hello!"}],
                "model": "claude-sonnet-4-6",
                "usage": {"input_tokens": 10, "output_tokens": 5},
            },
        )
    )

    messages = [ChatMessage(role="user", content="Hi")]
    response = await client.chat(messages, model="claude-sonnet-4-6")

    assert isinstance(response, ChatResponse)
    assert response.content == "Hello!"
    assert response.model == "claude-sonnet-4-6"
    assert response.usage["prompt_tokens"] == 10
    assert response.usage["completion_tokens"] == 5
    assert response.usage["total_tokens"] == 15
    await client.close()


@respx.mock
async def test_auth_header(client: AnthropicClient, api_key: str) -> None:
    """Test that the x-api-key and anthropic-version headers are sent correctly."""
    route = respx.post("https://api.anthropic.com/v1/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "content": [{"type": "text", "text": "ok"}],
                "model": "m",
                "usage": {"input_tokens": 0, "output_tokens": 0},
            },
        )
    )

    await client.chat([ChatMessage(role="user", content="test")], model="m")
    assert route.called
    request = route.calls[0].request
    assert request.headers["x-api-key"] == api_key
    assert request.headers["anthropic-version"] == "2023-06-01"
    await client.close()


@respx.mock
async def test_system_message_extracted() -> None:
    """Test that system messages are sent as top-level 'system' field."""
    cl = AnthropicClient(
        api_key="key", base_url="https://api.anthropic.com/v1", max_retries=1
    )

    route = respx.post("https://api.anthropic.com/v1/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "content": [{"type": "text", "text": "ok"}],
                "model": "m",
                "usage": {"input_tokens": 0, "output_tokens": 0},
            },
        )
    )

    messages = [
        ChatMessage(role="system", content="You are helpful."),
        ChatMessage(role="user", content="Hi"),
    ]
    await cl.chat(messages, model="m")

    import json

    body = json.loads(route.calls[0].request.content)
    assert body["system"] == "You are helpful."
    # System message should NOT appear in messages array
    assert all(m["role"] != "system" for m in body["messages"])
    await cl.close()


@respx.mock
async def test_retry_on_429() -> None:
    """Test that 429 responses trigger retry."""
    cl = AnthropicClient(
        api_key="key", base_url="https://api.anthropic.com/v1", max_retries=2
    )

    respx.post("https://api.anthropic.com/v1/messages").mock(
        side_effect=[
            httpx.Response(429, headers={"Retry-After": "0"}),
            httpx.Response(
                200,
                json={
                    "content": [{"type": "text", "text": "ok"}],
                    "model": "m",
                    "usage": {"input_tokens": 0, "output_tokens": 0},
                },
            ),
        ]
    )

    response = await cl.chat([ChatMessage(role="user", content="test")], model="m")
    assert response.content == "ok"
    await cl.close()


@respx.mock
async def test_stream_chat(client: AnthropicClient) -> None:
    """Test streaming chat completion via SSE."""
    msg_start = '{"type":"message_start","message":{"id":"msg_1","model":"m",'
    msg_start += '"usage":{"input_tokens":10,"output_tokens":0}}}'
    block_start = (
        '{"type":"content_block_start","index":0,'
        '"content_block":{"type":"text","text":""}}'
    )
    delta_hello = (
        '{"type":"content_block_delta","index":0,'
        '"delta":{"type":"text_delta","text":"Hello"}}'
    )
    delta_world = (
        '{"type":"content_block_delta","index":0,'
        '"delta":{"type":"text_delta","text":" world"}}'
    )
    sse_body = (
        f"event: message_start\ndata: {msg_start}\n\n"
        f"event: content_block_start\ndata: {block_start}\n\n"
        f"event: content_block_delta\ndata: {delta_hello}\n\n"
        f"event: content_block_delta\ndata: {delta_world}\n\n"
        "event: content_block_stop\n"
        'data: {"type":"content_block_stop","index":0}\n\n'
        "event: message_stop\n"
        'data: {"type":"message_stop"}\n\n'
    )

    respx.post("https://api.anthropic.com/v1/messages").mock(
        return_value=httpx.Response(200, text=sse_body)
    )

    chunks: list[str] = []
    async for chunk in client.stream_chat(
        [ChatMessage(role="user", content="Hi")], model="test-model"
    ):
        chunks.append(chunk)

    assert "".join(chunks) == "Hello world"
    await client.close()


@respx.mock
async def test_server_error_exhausts_retries() -> None:
    """Test that repeated 5xx errors raise after max_retries."""
    cl = AnthropicClient(
        api_key="key", base_url="https://api.anthropic.com/v1", max_retries=2
    )

    respx.post("https://api.anthropic.com/v1/messages").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )

    with pytest.raises(AnthropicClientError, match="failed after 2 retries"):
        await cl.chat([ChatMessage(role="user", content="test")], model="m")
    await cl.close()


async def test_list_models(client: AnthropicClient) -> None:
    """Test that list_models returns hardcoded Anthropic models."""
    models = await client.list_models()
    assert len(models) == 3
    model_ids = [m["id"] for m in models]
    assert "claude-sonnet-4-6" in model_ids
    assert "claude-haiku-4-5" in model_ids
    assert "claude-opus-4-6" in model_ids
    await client.close()
