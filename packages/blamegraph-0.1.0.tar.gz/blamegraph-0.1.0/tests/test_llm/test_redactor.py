"""Tests for the LLM redactor module."""

from __future__ import annotations

from blamegraph.config import BlameGraphConfig, LLMConfig
from blamegraph.llm.redactor import Redactor


class TestRedactorDefaults:
    """Test default redaction patterns."""

    def setup_method(self) -> None:
        self.redactor = Redactor()

    def test_aws_key(self) -> None:
        text = "key=AKIAIOSFODNN7EXAMPLE"
        result = self.redactor.redact(text)
        assert "AKIA" not in result
        assert "[REDACTED]" in result

    def test_private_key(self) -> None:
        text = "-----BEGIN RSA PRIVATE KEY-----\nMIIBog..."
        result = self.redactor.redact(text)
        assert "BEGIN" not in result
        assert "[REDACTED]" in result

    def test_auth_url_token(self) -> None:
        text = "visit https://api.example.com/v1?token=abc123secret"
        result = self.redactor.redact(text)
        assert "token=abc123" not in result
        assert "[REDACTED]" in result

    def test_auth_url_key(self) -> None:
        text = "url: https://service.io/api?key=mysecretkey"
        result = self.redactor.redact(text)
        assert "key=mysecretkey" not in result

    def test_auth_url_password(self) -> None:
        text = "https://host.com/auth?password=hunter2"
        result = self.redactor.redact(text)
        assert "hunter2" not in result

    def test_email(self) -> None:
        text = "contact user@example.com for help"
        result = self.redactor.redact(text)
        assert "user@example.com" not in result
        assert "[REDACTED]" in result

    def test_hex_token(self) -> None:
        text = f"token={('a1b2c3d4' * 4)}"  # 32 hex chars
        result = self.redactor.redact(text)
        assert "a1b2c3d4" not in result
        assert "[REDACTED]" in result

    def test_slack_token(self) -> None:
        text = "SLACK_TOKEN=xoxb-123456789012-abcdefgh"
        result = self.redactor.redact(text)
        assert "xoxb-" not in result
        assert "[REDACTED]" in result

    def test_no_false_positive_on_clean_text(self) -> None:
        text = "This is a normal ticket description about login flow."
        result = self.redactor.redact(text)
        assert result == text

    def test_multiple_patterns_in_one_text(self) -> None:
        text = (
            "Key: AKIAIOSFODNN7EXAMPLE Email: test@example.com Token: xoxb-1234567890-abcdefghijk"
        )
        result = self.redactor.redact(text)
        assert result.count("[REDACTED]") >= 3


class TestRedactorCustomPatterns:
    """Test custom patterns from config."""

    def test_custom_pattern(self) -> None:
        config = BlameGraphConfig(llm=LLMConfig(redact_patterns=[r"SECRET_\w+"]))
        redactor = Redactor(config)
        text = "value is SECRET_ABCDEF"
        result = redactor.redact(text)
        assert "SECRET_ABCDEF" not in result
        assert "[REDACTED]" in result

    def test_custom_plus_defaults(self) -> None:
        config = BlameGraphConfig(llm=LLMConfig(redact_patterns=[r"CUSTOM_\d+"]))
        redactor = Redactor(config)
        # Custom pattern
        assert "[REDACTED]" in redactor.redact("CUSTOM_12345")
        # Default pattern (AWS key) still works
        assert "[REDACTED]" in redactor.redact("AKIAIOSFODNN7EXAMPLE")

    def test_no_config(self) -> None:
        redactor = Redactor(config=None)
        # Still has defaults
        assert "[REDACTED]" in redactor.redact("AKIAIOSFODNN7EXAMPLE")
