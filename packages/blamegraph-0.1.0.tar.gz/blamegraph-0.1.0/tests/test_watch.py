"""Tests for the BlameGraph CI/CD Gate (watch) feature."""

from __future__ import annotations

from datetime import UTC, datetime

from blamegraph.models import EdgeType, RiskLevel
from blamegraph.storage.sqlite import SQLiteStorage
from blamegraph.watch import WatchResult, _fail_levels, check_ticket
from tests.conftest import make_edge, make_risk_score, make_ticket


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fresh_storage() -> SQLiteStorage:
    """Return a fully initialised in-memory storage instance."""
    storage = SQLiteStorage(":memory:")
    storage.initialize()
    return storage


# ---------------------------------------------------------------------------
# WatchResult properties
# ---------------------------------------------------------------------------

def test_watch_result_defaults() -> None:
    result = WatchResult(ticket_key="PROJ-1")
    assert result.ticket_key == "PROJ-1"
    assert result.entity_id == ""
    assert result.has_critical is False
    assert result.has_high is False
    assert result.blockers == []
    assert result.risk_score == 0.0
    assert result.risk_level == "low"
    assert result.should_fail is False
    assert result.reason == ""


def test_watch_result_explicit_values() -> None:
    result = WatchResult(
        ticket_key="PROJ-42",
        entity_id="ent-42",
        has_critical=True,
        has_high=True,
        blockers=[{"key": "PROJ-1", "title": "Bug", "status": "open", "risk_level": "critical", "risk_score": 90.0}],
        risk_score=88.5,
        risk_level="critical",
        should_fail=True,
        reason="Critical blocker(s) found for PROJ-42",
    )
    assert result.ticket_key == "PROJ-42"
    assert result.entity_id == "ent-42"
    assert result.has_critical is True
    assert result.has_high is True
    assert len(result.blockers) == 1
    assert result.risk_score == 88.5
    assert result.risk_level == "critical"
    assert result.should_fail is True
    assert "PROJ-42" in result.reason


# ---------------------------------------------------------------------------
# _fail_levels helper
# ---------------------------------------------------------------------------

def test_fail_levels_critical_threshold() -> None:
    levels = _fail_levels("critical")
    assert levels == {"critical"}


def test_fail_levels_high_threshold_includes_critical() -> None:
    levels = _fail_levels("high")
    assert "critical" in levels
    assert "high" in levels
    assert "medium" not in levels


def test_fail_levels_medium_threshold_includes_all_severe() -> None:
    levels = _fail_levels("medium")
    assert "critical" in levels
    assert "high" in levels
    assert "medium" in levels


def test_fail_levels_unknown_threshold_defaults_to_critical_only() -> None:
    levels = _fail_levels("unknown_value")
    assert levels == {"critical"}


def test_fail_levels_case_insensitive() -> None:
    assert _fail_levels("CRITICAL") == {"critical"}
    assert _fail_levels("HIGH") == {"critical", "high"}
    assert _fail_levels("MEDIUM") == {"critical", "high", "medium"}


# ---------------------------------------------------------------------------
# check_ticket — ticket not found
# ---------------------------------------------------------------------------

def test_check_ticket_not_found_returns_result_with_reason() -> None:
    storage = _fresh_storage()
    result = check_ticket(storage, "DOES-NOT-EXIST")
    assert result.ticket_key == "DOES-NOT-EXIST"
    assert result.entity_id == ""
    assert result.should_fail is False
    assert "not found" in result.reason.lower()


def test_check_ticket_not_found_has_empty_blockers() -> None:
    storage = _fresh_storage()
    result = check_ticket(storage, "MISSING-999")
    assert result.blockers == []
    assert result.has_critical is False
    assert result.has_high is False


# ---------------------------------------------------------------------------
# check_ticket — no blockers (should pass)
# ---------------------------------------------------------------------------

def test_check_ticket_no_blockers_does_not_fail() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100")

    assert result.should_fail is False
    assert result.entity_id == "ent-1"
    assert result.blockers == []


def test_check_ticket_no_blockers_reason_states_no_active_blockers() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100")

    assert "no active blockers" in result.reason.lower()


def test_check_ticket_no_blockers_picks_up_risk_score() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    storage.upsert_entity(ticket)
    rs = make_risk_score(entity_id="ent-1", score=25.0, level=RiskLevel.LOW)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.risk_score == 25.0
    assert result.risk_level == "low"
    assert result.should_fail is False


def test_check_ticket_no_blockers_non_blocking_edge_does_not_fail() -> None:
    """An edge with edge_type=DEPENDS_ON should not be counted as a blocker."""
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    dep = make_ticket(
        id="ent-2",
        external_id="PROJ-99",
        title="Upstream service",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(dep)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-2",
        to_entity="ent-1",
        edge_type=EdgeType.DEPENDS_ON,
    )
    storage.upsert_edge(edge)

    result = check_ticket(storage, "PROJ-100")

    assert result.should_fail is False
    assert result.blockers == []


# ---------------------------------------------------------------------------
# check_ticket — critical blocker (fail on "critical")
# ---------------------------------------------------------------------------

def test_check_ticket_critical_blocker_fails_on_critical() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Critical infrastructure failure",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=85.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="critical")

    assert result.should_fail is True
    assert result.has_critical is True
    assert "critical" in result.reason.lower()


def test_check_ticket_critical_blocker_populates_blockers_list() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Critical infrastructure failure",
        attributes={"status": "in-progress"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=85.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert len(result.blockers) == 1
    blocker_entry = result.blockers[0]
    assert blocker_entry["key"] == "PROJ-9"
    assert blocker_entry["risk_level"] == "critical"
    assert blocker_entry["risk_score"] == 85.0


def test_check_ticket_critical_blocker_sets_has_critical_flag() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Critical blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=90.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.has_critical is True
    assert result.has_high is False


# ---------------------------------------------------------------------------
# check_ticket — high blocker (fail on "high" but pass on "critical")
# ---------------------------------------------------------------------------

def test_check_ticket_high_blocker_passes_on_critical_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="High risk blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=70.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="critical")

    assert result.should_fail is False
    assert result.has_high is True
    assert result.has_critical is False


def test_check_ticket_high_blocker_fails_on_high_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="High risk blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=70.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="high")

    assert result.should_fail is True
    assert "high" in result.reason.lower()


def test_check_ticket_high_blocker_fails_on_medium_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="High risk blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=70.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="medium")

    assert result.should_fail is True


def test_check_ticket_high_blocker_has_high_flag_not_critical() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="High risk blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=75.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.has_high is True
    assert result.has_critical is False


# ---------------------------------------------------------------------------
# check_ticket — resolved blockers (should not count)
# ---------------------------------------------------------------------------

def test_check_ticket_done_blocker_is_ignored() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Completed work",
        attributes={"status": "done"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=85.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.should_fail is False
    assert result.blockers == []
    assert result.has_critical is False


def test_check_ticket_closed_blocker_is_ignored() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Closed issue",
        attributes={"status": "closed"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=85.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.should_fail is False
    assert result.blockers == []


def test_check_ticket_resolved_blocker_is_ignored() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Resolved issue",
        attributes={"status": "resolved"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=85.0, level=RiskLevel.CRITICAL)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.should_fail is False
    assert result.blockers == []


def test_check_ticket_mix_of_resolved_and_active_blockers() -> None:
    """Only the active blocker should be counted; resolved ones are skipped."""
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    resolved_blocker = make_ticket(
        id="ent-b1",
        external_id="PROJ-8",
        title="Already fixed",
        attributes={"status": "done"},
    )
    active_blocker = make_ticket(
        id="ent-b2",
        external_id="PROJ-9",
        title="Still blocking",
        attributes={"status": "in-progress"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(resolved_blocker)
    storage.upsert_entity(active_blocker)
    storage.upsert_edge(
        make_edge(id="edge-1", from_entity="ent-b1", to_entity="ent-1", edge_type=EdgeType.BLOCKS)
    )
    storage.upsert_edge(
        make_edge(id="edge-2", from_entity="ent-b2", to_entity="ent-1", edge_type=EdgeType.BLOCKS)
    )
    storage.upsert_risk_score(
        make_risk_score(entity_id="ent-b1", score=90.0, level=RiskLevel.CRITICAL)
    )
    storage.upsert_risk_score(
        make_risk_score(entity_id="ent-b2", score=70.0, level=RiskLevel.HIGH)
    )

    result = check_ticket(storage, "PROJ-100", fail_on="high")

    assert len(result.blockers) == 1
    assert result.blockers[0]["key"] == "PROJ-9"
    assert result.has_high is True
    assert result.has_critical is False
    assert result.should_fail is True


# ---------------------------------------------------------------------------
# check_ticket — blocked status but no edges
# ---------------------------------------------------------------------------

def test_check_ticket_blocked_status_no_edges_sets_has_high() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "blocked"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100")

    assert result.has_high is True
    assert result.has_critical is False


def test_check_ticket_blocked_status_no_edges_adds_self_to_blockers() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(
        id="ent-1",
        external_id="PROJ-100",
        title="Blocked feature work",
        attributes={"status": "blocked"},
    )
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100")

    assert len(result.blockers) == 1
    entry = result.blockers[0]
    assert entry["key"] == "PROJ-100"
    assert entry["status"] == "blocked"
    assert entry["risk_level"] == "high"


def test_check_ticket_blocked_status_no_edges_fails_on_high_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "blocked"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100", fail_on="high")

    assert result.should_fail is True


def test_check_ticket_blocked_status_no_edges_passes_on_critical_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "blocked"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-100", fail_on="critical")

    assert result.should_fail is False


def test_check_ticket_blocked_status_with_blocking_edges_does_not_double_count() -> None:
    """When an entity is 'blocked' and has real BLOCKS edges, the status fallback
    should NOT fire — the edge-based blockers take precedence."""
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "blocked"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Real blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=70.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    # Only the real blocker entry, no self-referential entry
    assert len(result.blockers) == 1
    assert result.blockers[0]["key"] == "PROJ-9"


# ---------------------------------------------------------------------------
# check_ticket — multiple blockers with mixed severity
# ---------------------------------------------------------------------------

def test_check_ticket_multiple_blockers_highest_severity_drives_failure() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    low_blocker = make_ticket(
        id="ent-b1",
        external_id="PROJ-7",
        title="Low priority item",
        attributes={"status": "open"},
    )
    critical_blocker = make_ticket(
        id="ent-b2",
        external_id="PROJ-8",
        title="Critical outage",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(low_blocker)
    storage.upsert_entity(critical_blocker)
    storage.upsert_edge(
        make_edge(id="edge-1", from_entity="ent-b1", to_entity="ent-1", edge_type=EdgeType.BLOCKS)
    )
    storage.upsert_edge(
        make_edge(id="edge-2", from_entity="ent-b2", to_entity="ent-1", edge_type=EdgeType.BLOCKS)
    )
    storage.upsert_risk_score(
        make_risk_score(entity_id="ent-b1", score=20.0, level=RiskLevel.LOW)
    )
    storage.upsert_risk_score(
        make_risk_score(entity_id="ent-b2", score=90.0, level=RiskLevel.CRITICAL)
    )

    result = check_ticket(storage, "PROJ-100", fail_on="critical")

    assert result.should_fail is True
    assert result.has_critical is True
    assert len(result.blockers) == 2


def test_check_ticket_blocker_without_risk_score_has_unknown_level() -> None:
    """A blocker with no persisted RiskScore should appear with risk_level='unknown'."""
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Unscored blocker",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    # No risk score upserted for the blocker

    result = check_ticket(storage, "PROJ-100")

    assert len(result.blockers) == 1
    assert result.blockers[0]["risk_level"] == "unknown"
    assert result.blockers[0]["risk_score"] == 0.0
    assert result.should_fail is False  # "unknown" does not trigger either flag


def test_check_ticket_entity_id_populated_on_success() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-xyz", external_id="PROJ-200", attributes={"status": "open"})
    storage.upsert_entity(ticket)

    result = check_ticket(storage, "PROJ-200")

    assert result.entity_id == "ent-xyz"


def test_check_ticket_risk_score_reflected_in_result() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    storage.upsert_entity(ticket)
    rs = make_risk_score(entity_id="ent-1", score=78.0, level=RiskLevel.HIGH)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100")

    assert result.risk_score == 78.0
    assert result.risk_level == "high"


def test_check_ticket_no_risk_score_keeps_defaults() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    storage.upsert_entity(ticket)
    # No risk score stored

    result = check_ticket(storage, "PROJ-100")

    assert result.risk_score == 0.0
    assert result.risk_level == "low"


# ---------------------------------------------------------------------------
# check_ticket — medium blocker with medium threshold
# ---------------------------------------------------------------------------

def test_check_ticket_medium_blocker_fails_on_medium_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Medium risk task",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=45.0, level=RiskLevel.MEDIUM)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="medium")

    assert result.should_fail is True
    assert "blocker" in result.reason.lower()


def test_check_ticket_medium_blocker_passes_on_high_threshold() -> None:
    storage = _fresh_storage()
    ticket = make_ticket(id="ent-1", external_id="PROJ-100", attributes={"status": "open"})
    blocker = make_ticket(
        id="ent-blocker",
        external_id="PROJ-9",
        title="Medium risk task",
        attributes={"status": "open"},
    )
    storage.upsert_entity(ticket)
    storage.upsert_entity(blocker)
    edge = make_edge(
        id="edge-1",
        from_entity="ent-blocker",
        to_entity="ent-1",
        edge_type=EdgeType.BLOCKS,
    )
    storage.upsert_edge(edge)
    rs = make_risk_score(entity_id="ent-blocker", score=45.0, level=RiskLevel.MEDIUM)
    storage.upsert_risk_score(rs)

    result = check_ticket(storage, "PROJ-100", fail_on="high")

    assert result.should_fail is False
    assert len(result.blockers) == 1  # blocker is still listed, just not a failure
