"""Tests for blocker detection heuristics."""

from __future__ import annotations

from blamegraph.models import Edge, EdgeType, Entity, EntityType, InferenceMethod, TextArtifact
from blamegraph.risk.detector import BlockerDetector


def _make_ticket(
    ext_id: str,
    *,
    status: str = "In Progress",
) -> Entity:
    return Entity(
        id=ext_id.lower().replace("-", "_"),
        entity_type=EntityType.TICKET,
        external_id=ext_id,
        title=f"Ticket {ext_id}",
        attributes={"status": status},
    )


def _make_edge(from_id: str, to_id: str) -> Edge:
    return Edge(
        id=f"{from_id}->{to_id}",
        from_entity=from_id,
        to_entity=to_id,
        edge_type=EdgeType.BLOCKS,
        confidence=1.0,
        method=InferenceMethod.EXPLICIT,
    )


def _make_text(entity_id: str, text: str) -> TextArtifact:
    return TextArtifact(
        entity_id=entity_id,
        artifact_type="description",
        text=text,
    )


class TestHeuristic1BlockedNoLink:
    """Ticket marked Blocked with no linked dependency."""

    def test_blocked_no_edges_detected(self) -> None:
        entity = _make_ticket("MOB-100", status="Blocked")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [])

        assert len(blockers) >= 1
        assert "Hidden blocker" in blockers[0]
        assert "MOB-100" in blockers[0]

    def test_blocked_with_edges_not_detected(self) -> None:
        entity = _make_ticket("MOB-100", status="Blocked")
        edge = _make_edge("other", entity.id)
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [edge], [])

        # Should NOT flag "no linked dependency" since edge exists
        no_link_blockers = [b for b in blockers if "no linked dependency" in b]
        assert len(no_link_blockers) == 0

    def test_not_blocked_status_ignored(self) -> None:
        entity = _make_ticket("MOB-100", status="In Progress")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [])

        no_link_blockers = [b for b in blockers if "no linked dependency" in b]
        assert len(no_link_blockers) == 0


class TestHeuristic2BlockerPhrases:
    """Phrases like 'waiting for', 'blocked by' with no explicit link."""

    def test_waiting_for_phrase_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "We are waiting for the platform team to deploy.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 1
        assert "'waiting for'" in phrase_blockers[0]

    def test_blocked_by_phrase_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "This is blocked by an upstream change.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 1

    def test_needs_api_phrase_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "Needs API contract finalized before starting.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 1

    def test_pending_phrase_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "This is pending approval from security.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 1

    def test_phrase_with_explicit_link_not_flagged(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "Waiting for PLAT-200.")
        edge = _make_edge("plat_200", entity.id)
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [edge], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 0

    def test_no_phrase_no_detection(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "Everything is fine, making progress.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        phrase_blockers = [b for b in blockers if "blocking language" in b]
        assert len(phrase_blockers) == 0


class TestHeuristic3TodoPlatformChange:
    """PR mentions 'TODO after platform change' with cross-reference."""

    def test_todo_platform_with_ticket_ref(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(
            entity.id,
            "TODO after platform change -- need to update once PLAT-200 is done.",
        )
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        platform_blockers = [b for b in blockers if "platform change" in b]
        assert len(platform_blockers) == 1
        assert "PLAT-200" in platform_blockers[0]

    def test_todo_platform_without_ticket_ref_not_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(
            entity.id,
            "TODO after platform change -- needs rework.",
        )
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        platform_blockers = [b for b in blockers if "platform change" in b]
        assert len(platform_blockers) == 0

    def test_no_todo_phrase_not_detected(self) -> None:
        entity = _make_ticket("MOB-100")
        text = _make_text(entity.id, "Refactoring for PLAT-200 compatibility.")
        detector = BlockerDetector()

        blockers = detector.detect_hidden_blockers(entity, [], [text])

        platform_blockers = [b for b in blockers if "platform change" in b]
        assert len(platform_blockers) == 0
