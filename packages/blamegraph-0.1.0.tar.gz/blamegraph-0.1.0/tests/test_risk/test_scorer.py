"""Tests for risk scoring engine."""

from __future__ import annotations

import math

import pytest

from blamegraph.models import RiskLevel
from blamegraph.risk.scorer import BIAS, FEATURE_WEIGHTS, RiskScorer, _sigmoid


class TestSigmoid:
    def test_zero_input(self) -> None:
        assert _sigmoid(0.0) == pytest.approx(0.5)

    def test_large_positive(self) -> None:
        assert _sigmoid(100.0) == pytest.approx(1.0, abs=1e-6)

    def test_large_negative(self) -> None:
        assert _sigmoid(-100.0) == pytest.approx(0.0, abs=1e-6)

    def test_positive_value(self) -> None:
        result = _sigmoid(2.0)
        expected = 1.0 / (1.0 + math.exp(-2.0))
        assert result == pytest.approx(expected)


class TestFeatureWeights:
    def test_all_seven_features_defined(self) -> None:
        expected_features = {
            "staleness",
            "no_clear_owner",
            "cross_team_hops",
            "criticality",
            "unbounded_dependency",
            "broken_ci",
            "churn",
        }
        assert set(FEATURE_WEIGHTS.keys()) == expected_features

    def test_weight_values(self) -> None:
        assert FEATURE_WEIGHTS["staleness"] == 0.5
        assert FEATURE_WEIGHTS["no_clear_owner"] == 1.0
        assert FEATURE_WEIGHTS["cross_team_hops"] == 0.8
        assert FEATURE_WEIGHTS["criticality"] == 1.2
        assert FEATURE_WEIGHTS["unbounded_dependency"] == 0.9
        assert FEATURE_WEIGHTS["broken_ci"] == 0.7
        assert FEATURE_WEIGHTS["churn"] == 0.4

    def test_bias_value(self) -> None:
        assert BIAS == -3.0


class TestRiskScorer:
    def test_all_zero_features_gives_low_score(self) -> None:
        scorer = RiskScorer()
        features = {
            "staleness": 0.0,
            "no_clear_owner": 0.0,
            "cross_team_hops": 0.0,
            "criticality": 0.0,
            "unbounded_dependency": 0.0,
            "broken_ci": 0.0,
            "churn": 0.0,
        }
        result = scorer.score("entity-1", features)

        # sigmoid(-3.0) * 100 ~ 4.74
        expected = _sigmoid(BIAS) * 100
        assert result.score == pytest.approx(expected, abs=0.1)
        assert result.level == RiskLevel.LOW

    def test_high_features_give_critical_score(self) -> None:
        scorer = RiskScorer()
        features = {
            "staleness": 10.0,
            "no_clear_owner": 1.0,
            "cross_team_hops": 5.0,
            "criticality": 1.0,
            "unbounded_dependency": 1.0,
            "broken_ci": 1.0,
            "churn": 10.0,
        }
        result = scorer.score("entity-1", features)

        # Large positive weighted sum + bias -> sigmoid near 1.0 -> score ~100
        assert result.score > 80
        assert result.level == RiskLevel.CRITICAL

    def test_formula_correctness(self) -> None:
        scorer = RiskScorer()
        features = {
            "staleness": 2.0,
            "no_clear_owner": 1.0,
            "cross_team_hops": 1.0,
        }
        weighted_sum = (
            FEATURE_WEIGHTS["staleness"] * 2.0
            + FEATURE_WEIGHTS["no_clear_owner"] * 1.0
            + FEATURE_WEIGHTS["cross_team_hops"] * 1.0
        )
        expected = round(_sigmoid(weighted_sum + BIAS) * 100, 2)

        result = scorer.score("entity-1", features)
        assert result.score == pytest.approx(expected, abs=0.01)

    def test_score_clamped_to_0_100(self) -> None:
        scorer = RiskScorer()
        result_low = scorer.score("e1", {"staleness": -1000.0})
        result_high = scorer.score("e2", {"staleness": 1000.0})

        assert 0.0 <= result_low.score <= 100.0
        assert 0.0 <= result_high.score <= 100.0

    def test_entity_id_preserved(self) -> None:
        scorer = RiskScorer()
        result = scorer.score("my-entity", {})
        assert result.entity_id == "my-entity"

    def test_features_stored_in_result(self) -> None:
        scorer = RiskScorer()
        features = {"staleness": 3.0, "churn": 2.0}
        result = scorer.score("e1", features)
        assert result.features == features


class TestRiskLevels:
    def test_low_level(self) -> None:
        assert RiskLevel.from_score(0) == RiskLevel.LOW
        assert RiskLevel.from_score(29) == RiskLevel.LOW
        assert RiskLevel.from_score(29.99) == RiskLevel.LOW

    def test_medium_level(self) -> None:
        assert RiskLevel.from_score(30) == RiskLevel.MEDIUM
        assert RiskLevel.from_score(59) == RiskLevel.MEDIUM
        assert RiskLevel.from_score(59.99) == RiskLevel.MEDIUM

    def test_high_level(self) -> None:
        assert RiskLevel.from_score(60) == RiskLevel.HIGH
        assert RiskLevel.from_score(79) == RiskLevel.HIGH
        assert RiskLevel.from_score(79.99) == RiskLevel.HIGH

    def test_critical_level(self) -> None:
        assert RiskLevel.from_score(80) == RiskLevel.CRITICAL
        assert RiskLevel.from_score(100) == RiskLevel.CRITICAL


class TestWhyBullets:
    def test_top_3_contributors_in_why(self) -> None:
        scorer = RiskScorer()
        features = {
            "staleness": 5.0,
            "no_clear_owner": 1.0,
            "cross_team_hops": 3.0,
            "criticality": 0.8,
            "unbounded_dependency": 1.0,
            "broken_ci": 1.0,
            "churn": 2.0,
        }
        result = scorer.score("e1", features)
        assert len(result.why) <= 3
        assert len(result.why) > 0

    def test_zero_features_no_why(self) -> None:
        scorer = RiskScorer()
        features = {"staleness": 0.0, "churn": 0.0}
        result = scorer.score("e1", features)
        assert len(result.why) == 0
