"""Tests for the lazy search orchestrator."""

from __future__ import annotations

from datetime import datetime
from unittest.mock import AsyncMock

import pytest
from rich.console import Console

from blamegraph.config import (
    BlameGraphConfig,
    ConnectorsConfig,
    GitLabConfig,
    JiraConfig,
    SlackConfig,
)
from blamegraph.errors import ConnectorError
from blamegraph.models import RawPayload
from blamegraph.search import (
    LazySearcher,
    SearchResult,
    parse_question,
    render_results,
    result_to_json,
)


def test_parse_question_extracts_ticket_keys() -> None:
    parsed = parse_question("co blokuje PROJ-123?")
    assert parsed.ticket_keys == ["PROJ-123"]


def test_parse_question_extracts_multiple_keys() -> None:
    parsed = parse_question("link between PROJ-123 and PLAT-456")
    assert set(parsed.ticket_keys) == {"PROJ-123", "PLAT-456"}


def test_parse_question_extracts_keywords() -> None:
    parsed = parse_question("co blokuje PROJ-123?")
    # "co" is a stop word, "PROJ-123" is extracted as ticket key
    # Only non-stop, non-ticket words remain
    assert "PROJ-123" not in parsed.keywords
    for kw in parsed.keywords:
        assert kw.lower() not in {"co", "a", "the", "is"}


def test_parse_question_no_tickets() -> None:
    parsed = parse_question("show me all blockers")
    assert parsed.ticket_keys == []
    assert len(parsed.keywords) > 0


def test_parse_question_complex_keys() -> None:
    parsed = parse_question("status of MOB2-99 and INFRA-1")
    assert set(parsed.ticket_keys) == {"MOB2-99", "INFRA-1"}


def _make_jira_payload(key: str, status: str = "Open") -> RawPayload:
    return RawPayload(
        source="jira",
        external_id=key,
        payload={
            "key": key,
            "fields": {
                "summary": f"Issue {key}",
                "description": f"Description of {key}",
                "status": {"name": status},
                "assignee": {"displayName": "Alice"},
                "labels": [],
                "components": [],
                "priority": {"name": "High"},
                "duedate": None,
                "issuelinks": [],
                "comment": {"comments": []},
            },
            "changelog": {"histories": []},
        },
        fetched_at=datetime(2025, 1, 1),
    )


def _make_gitlab_mr_payload(project_id: int, iid: int) -> RawPayload:
    return RawPayload(
        source="gitlab_mr",
        external_id=f"{project_id}!{iid}",
        payload={
            "iid": iid,
            "project_id": project_id,
            "title": f"MR !{iid}",
            "description": "Fix something",
            "state": "merged",
            "source_branch": "feature",
            "target_branch": "main",
            "labels": [],
            "web_url": f"https://gitlab.example.com/project/-/merge_requests/{iid}",
            "author": {"username": "alice"},
            "created_at": "2025-01-10T12:00:00Z",
        },
        fetched_at=datetime(2025, 1, 1),
    )


def _make_slack_payload(channel: str, ts: str, text: str) -> RawPayload:
    return RawPayload(
        source="slack",
        external_id=f"{channel}:{ts}",
        payload={"ts": ts, "text": text, "user": "U001", "_channel": channel},
        fetched_at=datetime(2025, 1, 1),
    )


@pytest.fixture()
def config() -> BlameGraphConfig:
    return BlameGraphConfig(
        workspace="test",
        connectors=ConnectorsConfig(
            jira=JiraConfig(
                base_url="https://jira.example.com",
                project_keys=["PROJ"],
                token_env="JIRA_TOKEN",
            ),
            gitlab=GitLabConfig(
                base_url="https://gitlab.example.com",
                project_ids=[42],
                token_env="GITLAB_TOKEN",
            ),
            slack=SlackConfig(
                enabled=True,
                token_env="SLACK_TOKEN",
                channels=["C123"],
            ),
        ),
    )


@pytest.fixture()
def quiet_console() -> Console:
    return Console(quiet=True)


async def test_search_jira_by_key(
    config: BlameGraphConfig, quiet_console: Console, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that LazySearcher calls jira.search_by_key for ticket keys."""
    monkeypatch.setenv("JIRA_TOKEN", "test")
    monkeypatch.setenv("GITLAB_TOKEN", "test")
    monkeypatch.setenv("SLACK_TOKEN", "test")

    jira_payload = _make_jira_payload("PROJ-123")

    searcher = LazySearcher(config, console=quiet_console)
    searcher._jira.search_by_key = AsyncMock(return_value=[jira_payload])  # type: ignore[method-assign]
    searcher._jira.search_linked = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._jira.search_text = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._gitlab.search_mrs = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._slack.search_messages = AsyncMock(return_value=[])  # type: ignore[method-assign]

    result = await searcher.search("co blokuje PROJ-123?")

    searcher._jira.search_by_key.assert_called_once_with("PROJ-123")
    searcher._jira.search_linked.assert_called_once_with("PROJ-123")
    assert "PROJ-123" in result.ticket_keys
    assert result.sources["jira"] == 1


async def test_search_full_flow(
    config: BlameGraphConfig, quiet_console: Console, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Integration test: full search flow with mocked connectors."""
    monkeypatch.setenv("JIRA_TOKEN", "test")
    monkeypatch.setenv("GITLAB_TOKEN", "test")
    monkeypatch.setenv("SLACK_TOKEN", "test")

    jira_payloads = [
        _make_jira_payload("PROJ-123", "Blocked"),
        _make_jira_payload("PLAT-456", "In Progress"),
    ]
    gitlab_payloads = [_make_gitlab_mr_payload(42, 10)]
    slack_payloads = [_make_slack_payload("C123", "170000.001", "PROJ-123 is stuck")]

    searcher = LazySearcher(config, console=quiet_console)
    searcher._jira.search_by_key = AsyncMock(return_value=[jira_payloads[0]])  # type: ignore[method-assign]
    searcher._jira.search_linked = AsyncMock(return_value=[jira_payloads[1]])  # type: ignore[method-assign]
    searcher._jira.search_text = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._gitlab.search_mrs = AsyncMock(return_value=gitlab_payloads)  # type: ignore[method-assign]
    searcher._slack.search_messages = AsyncMock(return_value=slack_payloads)  # type: ignore[method-assign]

    result = await searcher.search("co blokuje PROJ-123?")

    assert result.question == "co blokuje PROJ-123?"
    assert result.ticket_keys == ["PROJ-123"]
    assert result.sources["jira"] == 2
    assert result.sources["gitlab"] == 1
    assert result.sources["slack"] == 1
    assert len(result.entities) == 4  # 2 jira + 1 gitlab + 1 slack
    assert len(result.slack_mentions) == 1


async def test_search_connector_error_handled(
    config: BlameGraphConfig, quiet_console: Console, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that connector errors are caught and don't crash the search."""
    monkeypatch.setenv("JIRA_TOKEN", "test")
    monkeypatch.setenv("GITLAB_TOKEN", "test")
    monkeypatch.setenv("SLACK_TOKEN", "test")

    searcher = LazySearcher(config, console=quiet_console)
    searcher._jira.search_by_key = AsyncMock(side_effect=ConnectorError("Jira down"))  # type: ignore[method-assign]
    searcher._jira.search_linked = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._jira.search_text = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._gitlab.search_mrs = AsyncMock(side_effect=ConnectorError("GitLab down"))  # type: ignore[method-assign]
    searcher._slack.search_messages = AsyncMock(side_effect=ConnectorError("Slack down"))  # type: ignore[method-assign]

    result = await searcher.search("status PROJ-100")

    # Should not raise, just return empty results
    assert result.sources["jira"] == 0
    assert result.sources["gitlab"] == 0
    assert result.sources["slack"] == 0


def test_result_to_json() -> None:
    result = SearchResult(
        question="test?",
        ticket_keys=["PROJ-1"],
        entities=[],
        edges=[],
        sources={"jira": 1, "gitlab": 0, "slack": 2},
    )
    data = result_to_json(result)
    assert data["question"] == "test?"
    assert data["ticket_keys"] == ["PROJ-1"]
    assert data["sources"] == {"jira": 1, "gitlab": 0, "slack": 2}


def test_render_results_no_crash(quiet_console: Console) -> None:
    """Smoke test: render_results doesn't crash on empty results."""
    result = SearchResult(
        question="test?",
        ticket_keys=[],
        entities=[],
        edges=[],
        sources={},
    )
    render_results(quiet_console, result)


async def test_search_with_llm_answer(
    config: BlameGraphConfig, quiet_console: Console, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that LazySearcher calls the LLM client and populates llm_answer."""
    monkeypatch.setenv("JIRA_TOKEN", "test")
    monkeypatch.setenv("GITLAB_TOKEN", "test")
    monkeypatch.setenv("SLACK_TOKEN", "test")

    jira_payload = _make_jira_payload("PROJ-123")

    llm_client = AsyncMock()
    llm_client.chat = AsyncMock(return_value="PROJ-123 is blocked by PLAT-456.")

    searcher = LazySearcher(config, console=quiet_console, llm_client=llm_client)
    searcher._jira.search_by_key = AsyncMock(return_value=[jira_payload])  # type: ignore[method-assign]
    searcher._jira.search_linked = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._jira.search_text = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._gitlab.search_mrs = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._slack.search_messages = AsyncMock(return_value=[])  # type: ignore[method-assign]

    result = await searcher.search("co blokuje PROJ-123?", model="test-model")

    assert result.llm_answer == "PROJ-123 is blocked by PLAT-456."
    llm_client.chat.assert_called_once()


async def test_search_without_llm(
    config: BlameGraphConfig, quiet_console: Console, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that search works without LLM client (llm_answer stays empty)."""
    monkeypatch.setenv("JIRA_TOKEN", "test")
    monkeypatch.setenv("GITLAB_TOKEN", "test")
    monkeypatch.setenv("SLACK_TOKEN", "test")

    searcher = LazySearcher(config, console=quiet_console)
    searcher._jira.search_by_key = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._jira.search_linked = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._jira.search_text = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._gitlab.search_mrs = AsyncMock(return_value=[])  # type: ignore[method-assign]
    searcher._slack.search_messages = AsyncMock(return_value=[])  # type: ignore[method-assign]

    result = await searcher.search("test?")
    assert result.llm_answer == ""


def test_result_to_json_with_llm_answer() -> None:
    result = SearchResult(
        question="test?",
        ticket_keys=["PROJ-1"],
        entities=[],
        edges=[],
        sources={"jira": 1},
        llm_answer="Analysis result here.",
    )
    data = result_to_json(result)
    assert data["llm_answer"] == "Analysis result here."


def test_result_to_json_without_llm_answer() -> None:
    result = SearchResult(
        question="test?",
        ticket_keys=["PROJ-1"],
        entities=[],
        edges=[],
        sources={"jira": 1},
    )
    data = result_to_json(result)
    assert "llm_answer" not in data
