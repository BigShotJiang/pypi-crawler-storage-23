"""Tests for blamegraph.config."""

from __future__ import annotations

from pathlib import Path

import pytest

from blamegraph.config import BlameGraphConfig, load_config
from blamegraph.errors import ConfigError


class TestLoadConfig:
    def test_load_from_file(self, tmp_path: Path) -> None:
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text("workspace: test-ws\nstorage:\n  url: sqlite:///test.db\n")
        cfg = load_config(cfg_file)
        assert cfg.workspace == "test-ws"
        assert cfg.storage.url == "sqlite:///test.db"

    def test_load_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(ConfigError, match="not found"):
            load_config(tmp_path / "nonexistent.yaml")

    def test_load_no_path_returns_defaults(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cfg = load_config()
        assert isinstance(cfg, BlameGraphConfig)
        assert cfg.workspace == ""

    def test_load_empty_yaml_returns_defaults(self, tmp_path: Path) -> None:
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text("")
        cfg = load_config(cfg_file)
        assert isinstance(cfg, BlameGraphConfig)

    def test_invalid_yaml_raises(self, tmp_path: Path) -> None:
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text("key: [\ninvalid\n  - broken")
        with pytest.raises(ConfigError, match="Invalid YAML"):
            load_config(cfg_file)

    def test_env_var_resolution(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("TEST_TOKEN", "secret123")
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text("workspace: ${TEST_TOKEN}\n")
        cfg = load_config(cfg_file)
        assert cfg.workspace == "secret123"

    def test_missing_env_var_raises(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("NONEXISTENT_VAR_XYZ", raising=False)
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text("workspace: ${NONEXISTENT_VAR_XYZ}\n")
        with pytest.raises(ConfigError, match="NONEXISTENT_VAR_XYZ"):
            load_config(cfg_file)

    def test_full_config(self, tmp_path: Path) -> None:
        cfg_file = tmp_path / "blamegraph.yaml"
        cfg_file.write_text(
            "workspace: nexos\n"
            "connectors:\n"
            "  jira:\n"
            "    base_url: https://jira.example.com\n"
            "    project_keys: [MOB, PLAT]\n"
            "    token_env: JIRA_TOKEN\n"
            "  gitlab:\n"
            "    base_url: https://gitlab.example.com\n"
            "    group: nexos\n"
            "    token_env: GITLAB_TOKEN\n"
            "  slack:\n"
            "    enabled: false\n"
            "    token_env: SLACK_TOKEN\n"
            "    channels: [general]\n"
            "  github:\n"
            "    repos: [octocat/hello-world, nexos/backend]\n"
            "    token_env: GITHUB_TOKEN\n"
            "  bitbucket:\n"
            "    workspace: nexos-team\n"
            "    repos: [frontend, backend]\n"
            "    token_env: BITBUCKET_TOKEN\n"
            "  teams:\n"
            "    enabled: true\n"
            "    team_id: team-abc\n"
            "    channels: [ch-1, ch-2]\n"
            "    token_env: TEAMS_TOKEN\n"
            "teams:\n"
            "  mobile:\n"
            "    repos: [nexos/mobile]\n"
            "    jira_components: [Mobile]\n"
            "llm:\n"
            "  provider: openai\n"
            "  model_extract: gpt-4\n"
            "  model_answer: gpt-4\n"
            "  max_context_chars: 8000\n"
            "  redact:\n"
            "    patterns:\n"
            "      - 'AKIA[0-9A-Z]{16}'\n"
            "storage:\n"
            "  url: sqlite:///./test.db\n"
            "writeback:\n"
            "  dry_run_default: true\n"
        )
        cfg = load_config(cfg_file)
        assert cfg.workspace == "nexos"
        assert cfg.connectors.jira.base_url == "https://jira.example.com"
        assert cfg.connectors.jira.project_keys == ["MOB", "PLAT"]
        assert cfg.connectors.slack.enabled is False
        assert cfg.connectors.github.repos == ["octocat/hello-world", "nexos/backend"]
        assert cfg.connectors.github.token_env == "GITHUB_TOKEN"
        assert cfg.connectors.bitbucket.workspace == "nexos-team"
        assert cfg.connectors.bitbucket.repos == ["frontend", "backend"]
        assert cfg.connectors.teams.enabled is True
        assert cfg.connectors.teams.team_id == "team-abc"
        assert cfg.connectors.teams.channels == ["ch-1", "ch-2"]
        assert "mobile" in cfg.teams
        assert cfg.teams["mobile"].repos == ["nexos/mobile"]
        assert cfg.llm.provider == "openai"
        assert cfg.llm.max_context_chars == 8000
        assert len(cfg.llm.redact_patterns) == 1
        assert cfg.writeback.dry_run_default is True


class TestDefaultConfigPaths:
    def test_finds_local_config(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        local_cfg = tmp_path / "blamegraph.yaml"
        local_cfg.write_text("workspace: local\n")
        cfg = load_config()
        assert cfg.workspace == "local"
