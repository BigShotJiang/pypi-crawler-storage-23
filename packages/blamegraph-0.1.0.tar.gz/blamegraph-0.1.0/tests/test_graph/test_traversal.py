"""Tests for graph traversal utilities."""

from __future__ import annotations

from blamegraph.graph.traversal import (
    bfs,
    detect_cycles,
    dfs,
    find_chains,
)
from blamegraph.models import Edge, EdgeType, InferenceMethod


def _make_edge(from_id: str, to_id: str) -> Edge:
    return Edge(
        id=f"{from_id}->{to_id}",
        from_entity=from_id,
        to_entity=to_id,
        edge_type=EdgeType.BLOCKS,
        confidence=1.0,
        method=InferenceMethod.EXPLICIT,
    )


def _build_adjacency(
    edge_list: list[tuple[str, str]],
) -> dict[str, list[Edge]]:
    """Build adjacency map from (from, to) pairs."""
    adj: dict[str, list[Edge]] = {}
    for from_id, to_id in edge_list:
        adj.setdefault(from_id, []).append(_make_edge(from_id, to_id))
    return adj


class TestBFS:
    def test_linear_chain(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "C"), ("C", "D")])
        result = bfs("A", lambda n: adj.get(n, []))
        assert result == ["A", "B", "C", "D"]

    def test_branching(self) -> None:
        adj = _build_adjacency([("A", "B"), ("A", "C"), ("B", "D"), ("C", "D")])
        result = bfs("A", lambda n: adj.get(n, []))
        assert result[0] == "A"
        assert set(result) == {"A", "B", "C", "D"}
        # BFS visits B, C before D
        assert result.index("D") > result.index("B")
        assert result.index("D") > result.index("C")

    def test_single_node(self) -> None:
        result = bfs("A", lambda n: [])
        assert result == ["A"]

    def test_no_revisit_in_cycle(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "A")])
        result = bfs("A", lambda n: adj.get(n, []))
        assert result == ["A", "B"]


class TestDFS:
    def test_linear_chain(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "C"), ("C", "D")])
        result = dfs("A", lambda n: adj.get(n, []))
        assert result == ["A", "B", "C", "D"]

    def test_branching_goes_deep_first(self) -> None:
        adj = _build_adjacency([("A", "B"), ("A", "C"), ("B", "D")])
        result = dfs("A", lambda n: adj.get(n, []))
        assert result[0] == "A"
        # DFS follows A -> B -> D before visiting C
        assert result.index("D") < result.index("C")

    def test_single_node(self) -> None:
        result = dfs("A", lambda n: [])
        assert result == ["A"]

    def test_no_revisit_in_cycle(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "A")])
        result = dfs("A", lambda n: adj.get(n, []))
        assert result == ["A", "B"]


class TestFindChains:
    def test_single_chain(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "C")])
        chains = find_chains("A", lambda n: adj.get(n, []))
        assert len(chains) == 1
        assert chains[0].entity_ids == ["A", "B", "C"]

    def test_branching_produces_multiple_chains(self) -> None:
        adj = _build_adjacency([("A", "B"), ("A", "C"), ("B", "D")])
        chains = find_chains("A", lambda n: adj.get(n, []))
        chain_ids = [c.entity_ids for c in chains]
        assert ["A", "B", "D"] in chain_ids
        assert ["A", "C"] in chain_ids

    def test_leaf_node_returns_single_chain(self) -> None:
        chains = find_chains("A", lambda n: [])
        assert len(chains) == 1
        assert chains[0].entity_ids == ["A"]

    def test_cycle_does_not_loop_forever(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "A")])
        chains = find_chains("A", lambda n: adj.get(n, []))
        # Should terminate: A -> B is a chain (B -> A is back-edge, so B is leaf)
        assert len(chains) == 1
        assert chains[0].entity_ids == ["A", "B"]


class TestDetectCycles:
    def test_simple_cycle(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "A")])
        cycles = detect_cycles(lambda n: adj.get(n, []), ["A", "B"])
        assert len(cycles) == 1
        # Cycle should contain both A and B
        cycle_body = set(cycles[0][:-1])
        assert cycle_body == {"A", "B"}
        # First and last should be the same
        assert cycles[0][0] == cycles[0][-1]

    def test_triangle_cycle(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "C"), ("C", "A")])
        cycles = detect_cycles(lambda n: adj.get(n, []), ["A", "B", "C"])
        assert len(cycles) == 1
        cycle_body = set(cycles[0][:-1])
        assert cycle_body == {"A", "B", "C"}

    def test_no_cycle(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "C")])
        cycles = detect_cycles(lambda n: adj.get(n, []), ["A", "B", "C"])
        assert len(cycles) == 0

    def test_self_loop(self) -> None:
        adj = _build_adjacency([("A", "A")])
        cycles = detect_cycles(lambda n: adj.get(n, []), ["A"])
        assert len(cycles) == 1

    def test_multiple_independent_cycles(self) -> None:
        adj = _build_adjacency([("A", "B"), ("B", "A"), ("C", "D"), ("D", "C")])
        cycles = detect_cycles(lambda n: adj.get(n, []), ["A", "B", "C", "D"])
        assert len(cycles) == 2
