"""Tests for owner inference signals and ranking."""

from __future__ import annotations

from blamegraph.graph.owners import OwnerContext, OwnerInferrer
from blamegraph.models import Entity, EntityType


def _make_ticket(
    ext_id: str,
    *,
    assignee: str = "",
    component: str = "",
) -> Entity:
    attrs: dict[str, object] = {}
    if assignee:
        attrs["assignee"] = assignee
    if component:
        attrs["component"] = component
    return Entity(
        id=ext_id.lower().replace("-", "_"),
        entity_type=EntityType.TICKET,
        external_id=ext_id,
        title=f"Ticket {ext_id}",
        attributes=attrs,
    )


class TestSignalRanking:
    """Test that signals are ranked by score correctly."""

    def test_explicit_assignee_highest_score(self) -> None:
        entity = _make_ticket("MOB-100", assignee="alice")
        ctx = OwnerContext(
            historical_authors=["bob"],
            text_artifacts=["cc @charlie"],
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert owners[0].candidate_owner == "alice"
        assert owners[0].score == 1.0
        assert owners[0].signal == "explicit_assignee"

    def test_component_maps_to_team(self) -> None:
        entity = _make_ticket("MOB-100", component="mobile-ui")
        ctx = OwnerContext(
            team_config={
                "mobile": {"repos": [], "jira_components": ["mobile-ui"]},
            },
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert len(owners) == 1
        assert owners[0].candidate_owner == "mobile"
        assert owners[0].score == 1.0
        assert owners[0].signal == "explicit_component"

    def test_codeowners_signal(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext(
            codeowners={"src/mobile/*": "mobile-team"},
            changed_files=["src/mobile/app.py"],
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert len(owners) == 1
        assert owners[0].candidate_owner == "mobile-team"
        assert owners[0].score == 0.9
        assert owners[0].signal == "codeowners"

    def test_historical_signal(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext(historical_authors=["dave"])
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert len(owners) == 1
        assert owners[0].candidate_owner == "dave"
        assert owners[0].score == 0.7
        assert owners[0].signal == "historical"

    def test_mention_signal(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext(text_artifacts=["Can @eve review this?"])
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert len(owners) == 1
        assert owners[0].candidate_owner == "eve"
        assert owners[0].score == 0.5
        assert owners[0].signal == "mentioned"

    def test_repo_fallback_signal(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext(
            team_config={
                "mobile": {"repos": ["mobile-app"], "jira_components": []},
            },
            repo="mobile-app",
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        assert len(owners) == 1
        assert owners[0].candidate_owner == "mobile"
        assert owners[0].score == 0.3
        assert owners[0].signal == "repo_fallback"


class TestOwnerDeduplication:
    """Test that the same owner keeps the highest score."""

    def test_same_owner_multiple_signals_keeps_highest(self) -> None:
        entity = _make_ticket("MOB-100", assignee="alice")
        ctx = OwnerContext(
            text_artifacts=["Let @alice know"],
            historical_authors=["alice"],
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        alice_owners = [o for o in owners if o.candidate_owner == "alice"]
        assert len(alice_owners) == 1
        assert alice_owners[0].score == 1.0  # explicit > historical > mentioned


class TestOwnerOutput:
    """Test output ordering and structure."""

    def test_output_sorted_by_score_descending(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext(
            historical_authors=["bob"],
            text_artifacts=["@charlie"],
            team_config={"platform": {"repos": ["plat-core"], "jira_components": []}},
            repo="plat-core",
        )
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)

        scores = [o.score for o in owners]
        assert scores == sorted(scores, reverse=True)
        assert len(owners) == 3  # historical, mentioned, fallback

    def test_empty_context_returns_no_owners(self) -> None:
        entity = _make_ticket("MOB-100")
        ctx = OwnerContext()
        inferrer = OwnerInferrer()

        owners = inferrer.infer_owners(entity, ctx)
        assert len(owners) == 0
