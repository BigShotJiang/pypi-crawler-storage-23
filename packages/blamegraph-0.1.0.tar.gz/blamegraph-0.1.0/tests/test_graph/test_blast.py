"""Tests for blast radius computation."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from blamegraph.graph.blast import (
    BlastNode,
    BlastResult,
    _compute_score,
    _extract_teams,
    compute_blast_radius,
)
from blamegraph.models import EdgeType, InferenceMethod
from blamegraph.storage.sqlite import SQLiteStorage
from tests.conftest import make_edge, make_ticket


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _storage() -> SQLiteStorage:
    """Return a freshly initialised in-memory storage instance."""
    store = SQLiteStorage(":memory:")
    store.initialize()
    return store


def _node(
    entity_id: str = "t-1",
    external_id: str = "PROJ-1",
    team: str = "PROJ",
    priority: str = "medium",
    depth: int = 1,
) -> BlastNode:
    return BlastNode(
        entity_id=entity_id,
        external_id=external_id,
        title="Some ticket",
        team=team,
        sprint="",
        depth=depth,
        priority=priority,
    )


# ---------------------------------------------------------------------------
# compute_blast_radius — entity not found
# ---------------------------------------------------------------------------


def test_compute_blast_radius_entity_not_found() -> None:
    store = _storage()

    result = compute_blast_radius("ghost-999", store)

    assert result.root_entity_id == "ghost-999"
    assert result.root_external_id == "ghost-999"
    assert result.root_title == "(not found)"
    assert result.direct == []
    assert result.transitive == []
    assert result.blast_score == 0.0
    assert result.teams_affected == []


# ---------------------------------------------------------------------------
# compute_blast_radius — no dependents
# ---------------------------------------------------------------------------


def test_compute_blast_radius_no_dependents() -> None:
    store = _storage()
    root = make_ticket(id="t-root", external_id="PROJ-1", title="Root ticket")
    store.upsert_entity(root)

    result = compute_blast_radius("t-root", store)

    assert result.root_entity_id == "t-root"
    assert result.root_external_id == "PROJ-1"
    assert result.root_title == "Root ticket"
    assert result.direct == []
    assert result.transitive == []
    assert result.total_affected == 0
    assert result.blast_score == 0.0
    assert result.teams_affected == []


# ---------------------------------------------------------------------------
# compute_blast_radius — direct dependents via BLOCKS edge
# ---------------------------------------------------------------------------


def test_compute_blast_radius_direct_dependents_via_blocks() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="ALPHA-1", title="Root")
    dep1 = make_ticket(id="t-dep1", external_id="ALPHA-2", title="Dep 1")
    dep2 = make_ticket(id="t-dep2", external_id="ALPHA-3", title="Dep 2")
    for e in (root, dep1, dep2):
        store.upsert_entity(e)

    # root BLOCKS dep1 and dep2
    store.upsert_edge(
        make_edge(
            id="edge-a",
            from_entity="t-root",
            to_entity="t-dep1",
            edge_type=EdgeType.BLOCKS,
        )
    )
    store.upsert_edge(
        make_edge(
            id="edge-b",
            from_entity="t-root",
            to_entity="t-dep2",
            edge_type=EdgeType.BLOCKS,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert len(result.direct) == 2
    assert result.transitive == []
    assert result.total_affected == 2

    direct_ids = {n.entity_id for n in result.direct}
    assert direct_ids == {"t-dep1", "t-dep2"}

    for node in result.direct:
        assert node.depth == 1


# ---------------------------------------------------------------------------
# compute_blast_radius — direct dependents via IMPACTS edge
# ---------------------------------------------------------------------------


def test_compute_blast_radius_direct_dependents_via_impacts() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="BETA-1", title="Root")
    dep = make_ticket(id="t-dep", external_id="BETA-2", title="Impacted ticket")
    store.upsert_entity(root)
    store.upsert_entity(dep)

    store.upsert_edge(
        make_edge(
            id="edge-impacts",
            from_entity="t-root",
            to_entity="t-dep",
            edge_type=EdgeType.IMPACTS,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert len(result.direct) == 1
    assert result.direct[0].entity_id == "t-dep"
    assert result.direct[0].depth == 1


# ---------------------------------------------------------------------------
# compute_blast_radius — direct dependents via reverse DEPENDS_ON edge
# ---------------------------------------------------------------------------


def test_compute_blast_radius_direct_dependents_via_reverse_depends_on() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="GAMMA-1", title="Root")
    dep = make_ticket(id="t-dep", external_id="GAMMA-2", title="Dependent")
    store.upsert_entity(root)
    store.upsert_entity(dep)

    # dep DEPENDS_ON root — root is a dependency of dep, so dep is in root's blast
    store.upsert_edge(
        make_edge(
            id="edge-dep-on",
            from_entity="t-dep",
            to_entity="t-root",
            edge_type=EdgeType.DEPENDS_ON,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert len(result.direct) == 1
    assert result.direct[0].entity_id == "t-dep"
    assert result.direct[0].depth == 1


# ---------------------------------------------------------------------------
# compute_blast_radius — transitive dependents (depth 2)
# ---------------------------------------------------------------------------


def test_compute_blast_radius_transitive_depth_2() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="CHAIN-1", title="Root")
    mid = make_ticket(id="t-mid", external_id="CHAIN-2", title="Middle")
    leaf = make_ticket(id="t-leaf", external_id="CHAIN-3", title="Leaf")
    for e in (root, mid, leaf):
        store.upsert_entity(e)

    store.upsert_edge(
        make_edge(
            id="edge-root-mid",
            from_entity="t-root",
            to_entity="t-mid",
            edge_type=EdgeType.BLOCKS,
        )
    )
    store.upsert_edge(
        make_edge(
            id="edge-mid-leaf",
            from_entity="t-mid",
            to_entity="t-leaf",
            edge_type=EdgeType.BLOCKS,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert len(result.direct) == 1
    assert result.direct[0].entity_id == "t-mid"
    assert result.direct[0].depth == 1

    assert len(result.transitive) == 1
    assert result.transitive[0].entity_id == "t-leaf"
    assert result.transitive[0].depth == 2

    assert result.total_affected == 2


# ---------------------------------------------------------------------------
# compute_blast_radius — transitive dependents (depth 3)
# ---------------------------------------------------------------------------


def test_compute_blast_radius_transitive_depth_3() -> None:
    store = _storage()

    entities = [
        make_ticket(id=f"t-{i}", external_id=f"DEEP-{i}", title=f"Node {i}")
        for i in range(1, 5)  # t-1 through t-4
    ]
    for e in entities:
        store.upsert_entity(e)

    # Chain: t-1 -> t-2 -> t-3 -> t-4
    for i in range(1, 4):
        store.upsert_edge(
            make_edge(
                id=f"edge-{i}-{i + 1}",
                from_entity=f"t-{i}",
                to_entity=f"t-{i + 1}",
                edge_type=EdgeType.BLOCKS,
            )
        )

    result = compute_blast_radius("t-1", store)

    assert len(result.direct) == 1
    assert result.direct[0].entity_id == "t-2"

    assert len(result.transitive) == 2
    transitive_ids = {n.entity_id for n in result.transitive}
    assert transitive_ids == {"t-3", "t-4"}

    depths = {n.entity_id: n.depth for n in result.transitive}
    assert depths["t-3"] == 2
    assert depths["t-4"] == 3

    assert result.total_affected == 3


# ---------------------------------------------------------------------------
# compute_blast_radius — fan-out (one root blocks many)
# ---------------------------------------------------------------------------


def test_compute_blast_radius_fan_out() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="FAN-0", title="Root")
    store.upsert_entity(root)

    n = 5
    for i in range(1, n + 1):
        dep = make_ticket(id=f"t-fan-{i}", external_id=f"FAN-{i}", title=f"Fan {i}")
        store.upsert_entity(dep)
        store.upsert_edge(
            make_edge(
                id=f"edge-fan-{i}",
                from_entity="t-root",
                to_entity=f"t-fan-{i}",
                edge_type=EdgeType.BLOCKS,
            )
        )

    result = compute_blast_radius("t-root", store)

    assert result.total_affected == n
    assert len(result.direct) == n
    assert result.transitive == []


# ---------------------------------------------------------------------------
# compute_blast_radius — cycle does not cause infinite loop
# ---------------------------------------------------------------------------


def test_compute_blast_radius_cycle_does_not_loop() -> None:
    store = _storage()

    a = make_ticket(id="t-a", external_id="CYCLE-1", title="A")
    b = make_ticket(id="t-b", external_id="CYCLE-2", title="B")
    c = make_ticket(id="t-c", external_id="CYCLE-3", title="C")
    for e in (a, b, c):
        store.upsert_entity(e)

    # A -> B -> C -> A (cycle)
    store.upsert_edge(
        make_edge(id="e-ab", from_entity="t-a", to_entity="t-b", edge_type=EdgeType.BLOCKS)
    )
    store.upsert_edge(
        make_edge(id="e-bc", from_entity="t-b", to_entity="t-c", edge_type=EdgeType.BLOCKS)
    )
    store.upsert_edge(
        make_edge(id="e-ca", from_entity="t-c", to_entity="t-a", edge_type=EdgeType.BLOCKS)
    )

    # Must terminate and not raise
    result = compute_blast_radius("t-a", store)

    # B and C are reachable; A is root (already visited) so not double-counted
    assert result.total_affected == 2
    affected_ids = {n.entity_id for n in result.direct + result.transitive}
    assert affected_ids == {"t-b", "t-c"}


def test_compute_blast_radius_self_loop_does_not_loop() -> None:
    store = _storage()

    a = make_ticket(id="t-self", external_id="SELF-1", title="Self")
    store.upsert_entity(a)

    store.upsert_edge(
        make_edge(id="e-self", from_entity="t-self", to_entity="t-self", edge_type=EdgeType.BLOCKS)
    )

    # Must terminate immediately — root is already in visited
    result = compute_blast_radius("t-self", store)

    assert result.total_affected == 0


# ---------------------------------------------------------------------------
# compute_blast_radius — mixed RELATED_TO edges are ignored
# ---------------------------------------------------------------------------


def test_compute_blast_radius_ignores_related_to_edges() -> None:
    store = _storage()

    root = make_ticket(id="t-root", external_id="MISC-1", title="Root")
    unrelated = make_ticket(id="t-unrelated", external_id="MISC-2", title="Unrelated")
    store.upsert_entity(root)
    store.upsert_entity(unrelated)

    store.upsert_edge(
        make_edge(
            id="edge-related",
            from_entity="t-root",
            to_entity="t-unrelated",
            edge_type=EdgeType.RELATED_TO,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert result.total_affected == 0


# ---------------------------------------------------------------------------
# BlastResult.total_affected property
# ---------------------------------------------------------------------------


def test_blast_result_total_affected_empty() -> None:
    result = BlastResult(
        root_entity_id="t-1",
        root_external_id="X-1",
        root_title="Root",
    )
    assert result.total_affected == 0


def test_blast_result_total_affected_direct_only() -> None:
    result = BlastResult(
        root_entity_id="t-1",
        root_external_id="X-1",
        root_title="Root",
        direct=[_node("t-2"), _node("t-3")],
    )
    assert result.total_affected == 2


def test_blast_result_total_affected_transitive_only() -> None:
    result = BlastResult(
        root_entity_id="t-1",
        root_external_id="X-1",
        root_title="Root",
        transitive=[_node("t-2", depth=2), _node("t-3", depth=3)],
    )
    assert result.total_affected == 2


def test_blast_result_total_affected_mixed() -> None:
    result = BlastResult(
        root_entity_id="t-1",
        root_external_id="X-1",
        root_title="Root",
        direct=[_node("t-2"), _node("t-3")],
        transitive=[_node("t-4", depth=2), _node("t-5", depth=2), _node("t-6", depth=3)],
    )
    assert result.total_affected == 5


# ---------------------------------------------------------------------------
# _compute_score
# ---------------------------------------------------------------------------


def test_compute_score_empty() -> None:
    assert _compute_score([]) == 0.0


def test_compute_score_known_priorities() -> None:
    nodes = [
        _node(priority="critical"),   # 4.0
        _node(priority="high"),       # 3.0
        _node(priority="medium"),     # 2.0
        _node(priority="low"),        # 1.0
    ]
    assert _compute_score(nodes) == pytest.approx(10.0)


def test_compute_score_unknown_priority_defaults_to_1() -> None:
    nodes = [_node(priority="unknown_level")]
    assert _compute_score(nodes) == pytest.approx(1.0)


def test_compute_score_all_critical() -> None:
    nodes = [_node(priority="critical") for _ in range(3)]
    assert _compute_score(nodes) == pytest.approx(12.0)


def test_compute_score_single_high() -> None:
    assert _compute_score([_node(priority="high")]) == pytest.approx(3.0)


def test_compute_score_reflects_blast_result() -> None:
    """Score stored in BlastResult should equal the hand-computed value."""
    store = _storage()

    root = make_ticket(id="t-root", external_id="SCORE-1", title="Root")
    dep = make_ticket(
        id="t-dep",
        external_id="SCORE-2",
        title="Dep",
        attributes={"priority": "critical"},
    )
    store.upsert_entity(root)
    store.upsert_entity(dep)

    store.upsert_edge(
        make_edge(
            id="edge-score",
            from_entity="t-root",
            to_entity="t-dep",
            edge_type=EdgeType.BLOCKS,
        )
    )

    result = compute_blast_radius("t-root", store)

    # dep has priority=critical → weight 4.0
    assert result.blast_score == pytest.approx(4.0)


# ---------------------------------------------------------------------------
# _extract_teams
# ---------------------------------------------------------------------------


def test_extract_teams_empty() -> None:
    assert _extract_teams([]) == []


def test_extract_teams_single_team() -> None:
    nodes = [_node(team="ALPHA"), _node(team="ALPHA")]
    assert _extract_teams(nodes) == ["ALPHA"]


def test_extract_teams_multiple_teams_preserves_order() -> None:
    nodes = [
        _node(team="ALPHA"),
        _node(team="BETA"),
        _node(team="ALPHA"),  # duplicate — should not be re-added
        _node(team="GAMMA"),
    ]
    result = _extract_teams(nodes)
    assert result == ["ALPHA", "BETA", "GAMMA"]


def test_extract_teams_skips_empty_team() -> None:
    nodes = [_node(team=""), _node(team="DELTA"), _node(team="")]
    assert _extract_teams(nodes) == ["DELTA"]


def test_extract_teams_all_empty() -> None:
    nodes = [_node(team=""), _node(team="")]
    assert _extract_teams(nodes) == []


# ---------------------------------------------------------------------------
# Multiple teams affected — end-to-end via compute_blast_radius
# ---------------------------------------------------------------------------


def test_compute_blast_radius_multiple_teams_affected() -> None:
    """Teams are derived from the project-key prefix of external_id."""
    store = _storage()

    root = make_ticket(id="t-root", external_id="ALPHA-1", title="Root")

    # Each ticket belongs to a different team (project prefix)
    dep_alpha = make_ticket(id="t-dep-alpha", external_id="ALPHA-2", title="Alpha dep")
    dep_beta = make_ticket(id="t-dep-beta", external_id="BETA-1", title="Beta dep")
    dep_gamma = make_ticket(id="t-dep-gamma", external_id="GAMMA-1", title="Gamma dep")

    for e in (root, dep_alpha, dep_beta, dep_gamma):
        store.upsert_entity(e)

    for dep_id in ("t-dep-alpha", "t-dep-beta", "t-dep-gamma"):
        store.upsert_edge(
            make_edge(
                id=f"edge-to-{dep_id}",
                from_entity="t-root",
                to_entity=dep_id,
                edge_type=EdgeType.BLOCKS,
            )
        )

    result = compute_blast_radius("t-root", store)

    assert result.total_affected == 3
    assert set(result.teams_affected) == {"ALPHA", "BETA", "GAMMA"}


def test_compute_blast_radius_team_from_components_attribute() -> None:
    """When 'components' attribute is present it takes precedence over the external_id prefix."""
    store = _storage()

    root = make_ticket(id="t-root", external_id="ROOT-1", title="Root")
    dep = make_ticket(
        id="t-dep",
        external_id="DEP-1",
        title="Dep with component",
        attributes={"components": ["payments-team"], "priority": "medium"},
    )
    store.upsert_entity(root)
    store.upsert_entity(dep)

    store.upsert_edge(
        make_edge(
            id="edge-comp",
            from_entity="t-root",
            to_entity="t-dep",
            edge_type=EdgeType.BLOCKS,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert "payments-team" in result.teams_affected


def test_compute_blast_radius_team_from_label_prefix() -> None:
    """When 'labels' contains a 'team-' or 'team:' entry it is used as the team."""
    store = _storage()

    root = make_ticket(id="t-root", external_id="ROOT-2", title="Root")
    dep = make_ticket(
        id="t-dep-label",
        external_id="DEP-2",
        title="Dep with label",
        attributes={"labels": ["team-platform", "other-label"], "priority": "low"},
    )
    store.upsert_entity(root)
    store.upsert_entity(dep)

    store.upsert_edge(
        make_edge(
            id="edge-label",
            from_entity="t-root",
            to_entity="t-dep-label",
            edge_type=EdgeType.BLOCKS,
        )
    )

    result = compute_blast_radius("t-root", store)

    assert "team-platform" in result.teams_affected


# ---------------------------------------------------------------------------
# compute_blast_radius — root entity metadata is correct
# ---------------------------------------------------------------------------


def test_compute_blast_radius_root_metadata() -> None:
    store = _storage()

    root = make_ticket(
        id="t-meta-root",
        external_id="META-99",
        title="Metadata Root Ticket",
    )
    store.upsert_entity(root)

    result = compute_blast_radius("t-meta-root", store)

    assert result.root_entity_id == "t-meta-root"
    assert result.root_external_id == "META-99"
    assert result.root_title == "Metadata Root Ticket"
    assert result.ai_summary == ""


# ---------------------------------------------------------------------------
# compute_blast_radius — diamond dependency (shared transitive node)
# ---------------------------------------------------------------------------


def test_compute_blast_radius_diamond_no_duplicate_nodes() -> None:
    """A diamond dependency (A->B->D, A->C->D) must not produce duplicate nodes."""
    store = _storage()

    a = make_ticket(id="t-a", external_id="DIA-1", title="A")
    b = make_ticket(id="t-b", external_id="DIA-2", title="B")
    c = make_ticket(id="t-c", external_id="DIA-3", title="C")
    d = make_ticket(id="t-d", external_id="DIA-4", title="D")

    for e in (a, b, c, d):
        store.upsert_entity(e)

    store.upsert_edge(make_edge(id="e-ab", from_entity="t-a", to_entity="t-b", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-ac", from_entity="t-a", to_entity="t-c", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-bd", from_entity="t-b", to_entity="t-d", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-cd", from_entity="t-c", to_entity="t-d", edge_type=EdgeType.BLOCKS))

    result = compute_blast_radius("t-a", store)

    all_nodes = result.direct + result.transitive
    all_ids = [n.entity_id for n in all_nodes]

    # No duplicate entity IDs
    assert len(all_ids) == len(set(all_ids))

    # B and C are direct; D is transitive (reached via B or C, whichever BFS visits first)
    assert {n.entity_id for n in result.direct} == {"t-b", "t-c"}
    assert {n.entity_id for n in result.transitive} == {"t-d"}
    assert result.total_affected == 3
