"""Tests for graph dependency inference rules."""

from __future__ import annotations

from datetime import datetime

from blamegraph.graph.inference import DependencyInferrer
from blamegraph.models import EdgeType, Entity, EntityType, Event, InferenceMethod


def _make_ticket(
    ext_id: str,
    *,
    status: str = "In Progress",
    description: str = "",
    issuelinks: list[dict] | None = None,
    component: str = "",
) -> Entity:
    attrs: dict[str, object] = {"status": status}
    if description:
        attrs["description"] = description
    if issuelinks is not None:
        attrs["issuelinks"] = issuelinks
    if component:
        attrs["component"] = component
    return Entity(
        id=ext_id.lower().replace("-", "_"),
        entity_type=EntityType.TICKET,
        external_id=ext_id,
        title=f"Ticket {ext_id}",
        attributes=attrs,
    )


def _make_pr(
    ext_id: str,
    *,
    title: str = "",
    repo: str = "",
    description: str = "",
) -> Entity:
    attrs: dict[str, object] = {"repo": repo}
    if description:
        attrs["description"] = description
    return Entity(
        id=ext_id.lower().replace("-", "_"),
        entity_type=EntityType.PR,
        external_id=ext_id,
        title=title,
        attributes=attrs,
    )


class TestRule1ExplicitLinks:
    """Test Rule 1: Explicit Jira issuelinks."""

    def test_blocks_link_creates_edge(self) -> None:
        a = _make_ticket(
            "MOB-100",
            issuelinks=[{"type": "blocks", "target": "PLAT-200"}],
        )
        b = _make_ticket("PLAT-200")
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [], {})

        assert len(edges) == 1
        edge = edges[0]
        assert edge.from_entity == a.id
        assert edge.to_entity == b.id
        assert edge.edge_type == EdgeType.BLOCKS
        assert edge.confidence == 1.0
        assert edge.method == InferenceMethod.EXPLICIT

    def test_is_blocked_by_link_creates_edge(self) -> None:
        a = _make_ticket("MOB-100")
        b = _make_ticket(
            "PLAT-200",
            issuelinks=[{"type": "is blocked by", "target": "MOB-100"}],
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [], {})

        assert len(edges) == 1
        edge = edges[0]
        assert edge.from_entity == a.id
        assert edge.to_entity == b.id
        assert edge.edge_type == EdgeType.BLOCKS
        assert edge.confidence == 1.0

    def test_unknown_link_type_ignored(self) -> None:
        a = _make_ticket(
            "MOB-100",
            issuelinks=[{"type": "related to", "target": "PLAT-200"}],
        )
        b = _make_ticket("PLAT-200")
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [], {})
        assert len(edges) == 0

    def test_missing_target_entity_ignored(self) -> None:
        a = _make_ticket(
            "MOB-100",
            issuelinks=[{"type": "blocks", "target": "UNKNOWN-999"}],
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a], [], {})
        assert len(edges) == 0


class TestRule2BlockedStatus:
    """Test Rule 2: Status Blocked + ticket key regex."""

    def test_blocked_with_reference_in_description(self) -> None:
        a = _make_ticket("PLAT-312")
        b = _make_ticket(
            "MOB-881",
            status="Blocked",
            description="Cannot proceed, waiting on PLAT-312 to finish.",
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [], {})

        assert len(edges) == 1
        edge = edges[0]
        assert edge.from_entity == a.id
        assert edge.to_entity == b.id
        assert edge.confidence == 0.7
        assert edge.method == InferenceMethod.HEURISTIC

    def test_blocked_with_reference_in_comments(self) -> None:
        a = _make_ticket("SEC-144")
        b = _make_ticket("MOB-881", status="Blocked")
        comment_event = Event(
            entity_id=b.id,
            ts=datetime.utcnow(),
            kind="comment",
            payload={"body": "We need SEC-144 resolved first."},
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [comment_event], {})

        assert len(edges) == 1
        assert edges[0].from_entity == a.id

    def test_not_blocked_status_ignored(self) -> None:
        a = _make_ticket("PLAT-312")
        b = _make_ticket(
            "MOB-881",
            status="In Progress",
            description="See also PLAT-312.",
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a, b], [], {})
        assert len(edges) == 0

    def test_self_reference_ignored(self) -> None:
        a = _make_ticket(
            "MOB-881",
            status="Blocked",
            description="This is MOB-881 tracking itself.",
        )
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([a], [], {})
        assert len(edges) == 0


class TestRule3CrossTeamPR:
    """Test Rule 3: Cross-team PR reference."""

    def test_cross_team_pr_creates_impact_edge(self) -> None:
        ticket = _make_ticket("PLAT-200")
        pr = _make_pr(
            "MR-55",
            title="Fix PLAT-200 integration",
            repo="mobile-app",
        )
        team_config = {
            "mobile": {"repos": ["mobile-app"], "jira_components": ["MOB"]},
            "platform": {"repos": ["platform-core"], "jira_components": ["PLAT"]},
        }
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([ticket, pr], [], team_config)

        assert len(edges) == 1
        edge = edges[0]
        assert edge.from_entity == pr.id
        assert edge.to_entity == ticket.id
        assert edge.edge_type == EdgeType.IMPACTS
        assert edge.confidence == 0.6
        assert edge.method == InferenceMethod.HEURISTIC

    def test_same_team_pr_ignored(self) -> None:
        ticket = _make_ticket("MOB-100")
        pr = _make_pr(
            "MR-55",
            title="Fix MOB-100 bug",
            repo="mobile-app",
        )
        team_config = {
            "mobile": {"repos": ["mobile-app"], "jira_components": ["MOB"]},
        }
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([ticket, pr], [], team_config)
        assert len(edges) == 0

    def test_pr_with_no_team_mapping_ignored(self) -> None:
        ticket = _make_ticket("PLAT-200")
        pr = _make_pr(
            "MR-55",
            title="Fix PLAT-200 integration",
            repo="unknown-repo",
        )
        team_config = {
            "platform": {"repos": ["platform-core"], "jira_components": ["PLAT"]},
        }
        inferrer = DependencyInferrer()

        edges = inferrer.infer_edges([ticket, pr], [], team_config)
        assert len(edges) == 0
