"""Tests for the BlameGraph Auto-Unblock feature."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from blamegraph.models import EdgeType, EntityType, InferenceMethod, Owner
from blamegraph.storage.sqlite import SQLiteStorage
from blamegraph.unblock import UnblockAnalysis, UnblockEngine, UnblockSuggestion, build_unblock_context

from tests.conftest import make_edge, make_ticket

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

NOW = datetime(2025, 6, 15, 12, 0, 0, tzinfo=UTC)
STALE_UPDATED_AT = NOW - timedelta(days=10)
FRESH_UPDATED_AT = NOW - timedelta(days=2)


def _storage() -> SQLiteStorage:
    """Return a freshly initialised in-memory SQLiteStorage."""
    store = SQLiteStorage(":memory:")
    store.initialize()
    return store


def _utcnow_naive() -> datetime:
    """Return a timezone-naive UTC datetime close to now (mirrors unblock.py behaviour)."""
    return datetime.utcnow()


# ---------------------------------------------------------------------------
# analyze — entity not found
# ---------------------------------------------------------------------------


def test_analyze_entity_not_found_returns_empty_analysis() -> None:
    store = _storage()
    engine = UnblockEngine(store)

    result = engine.analyze("PROJ-999")

    assert isinstance(result, UnblockAnalysis)
    assert result.target_external_id == "PROJ-999"
    assert result.target_entity_id == ""
    assert result.target_title == "(not found)"
    assert result.suggestions == []


# ---------------------------------------------------------------------------
# analyze — ticket exists but has no blockers
# ---------------------------------------------------------------------------


def test_analyze_no_blockers_returns_empty_suggestions() -> None:
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    store.upsert_entity(target)
    engine = UnblockEngine(store)

    result = engine.analyze("PROJ-1")

    assert result.target_entity_id == "t-1"
    assert result.target_external_id == "PROJ-1"
    assert result.target_title == "Ship feature"
    assert result.suggestions == []


def test_analyze_no_blocking_edges_only_other_edge_types() -> None:
    """DEPENDS_ON and RELATED_TO edges must not be treated as blockers."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    upstream = make_ticket(id="t-2", external_id="PROJ-2", title="Dependency")
    store.upsert_entity(target)
    store.upsert_entity(upstream)

    edge = make_edge(
        id="e-1",
        from_entity="t-2",
        to_entity="t-1",
        edge_type=EdgeType.DEPENDS_ON,
    )
    store.upsert_edge(edge)

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assert result.suggestions == []


# ---------------------------------------------------------------------------
# analyze — resolved blockers are skipped
# ---------------------------------------------------------------------------


def test_analyze_resolved_blocker_skipped_done() -> None:
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Done blocker",
        attributes={"status": "done"},
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)

    edge = make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS)
    store.upsert_edge(edge)

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assert result.suggestions == []


def test_analyze_resolved_blocker_skipped_closed() -> None:
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Closed blocker",
        attributes={"status": "closed"},
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)

    edge = make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS)
    store.upsert_edge(edge)

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assert result.suggestions == []


def test_analyze_resolved_blocker_skipped_resolved() -> None:
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Resolved blocker",
        attributes={"status": "resolved"},
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)

    edge = make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS)
    store.upsert_edge(edge)

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assert result.suggestions == []


def test_analyze_mixed_resolved_and_open_blockers() -> None:
    """Only the open blocker should generate suggestions; resolved one is ignored.

    The open blocker is left unassigned so it always generates at least one
    assignment suggestion, making the assertion robust regardless of staleness.
    """
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    resolved_blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Done blocker",
        attributes={"status": "done"},
    )
    # No assignee → will always generate an assignment suggestion.
    open_blocker = make_ticket(
        id="t-3",
        external_id="PROJ-3",
        title="Open blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(resolved_blocker)
    store.upsert_entity(open_blocker)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-2", from_entity="t-3", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    blocker_ids = {s.blocker_entity_id for s in result.suggestions}
    assert "t-2" not in blocker_ids, "Resolved blocker must not appear in suggestions"
    assert "t-3" in blocker_ids, "Open blocker must appear in suggestions"


# ---------------------------------------------------------------------------
# analyze — unassigned blocker → suggest assignment
# ---------------------------------------------------------------------------


def test_analyze_unassigned_blocker_no_owner_candidate() -> None:
    """No owner in the owners table → generic 'find an owner' suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Unassigned blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assign_suggestions = [s for s in result.suggestions if "No assignee" in s.suggestion]
    assert len(assign_suggestions) == 1
    s = assign_suggestions[0]
    assert s.blocker_entity_id == "t-2"
    assert s.blocker_external_id == "PROJ-2"
    assert s.confidence == 0.5
    assert "bg draft --ticket PROJ-2" in s.action_command


def test_analyze_unassigned_blocker_with_owner_candidate() -> None:
    """Owner exists in owners table → suggest that candidate with higher confidence."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Unassigned blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    owner = Owner(entity_id="t-2", candidate_owner="bob@example.com", score=0.9, signal="git-blame")
    store.upsert_owner(owner)

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assign_suggestions = [s for s in result.suggestions if "bob@example.com" in s.suggestion]
    assert len(assign_suggestions) == 1
    s = assign_suggestions[0]
    assert s.confidence == 0.7
    assert "--assign bob@example.com" in s.action_command


def test_analyze_assigned_blocker_does_not_suggest_assignment() -> None:
    """An assignee is already set → no assignment suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Assigned blocker",
        attributes={"status": "open", "assignee": "carol"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    assign_suggestions = [
        s for s in result.suggestions
        if "Assign to" in s.suggestion or "No assignee" in s.suggestion
    ]
    assert assign_suggestions == []


# ---------------------------------------------------------------------------
# analyze — stale blocker → suggest escalation
# ---------------------------------------------------------------------------


def test_analyze_stale_blocker_produces_escalation_suggestion() -> None:
    """Blocker not updated for >= 7 days → escalate suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    stale_updated = datetime.utcnow() - timedelta(days=10)
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Stale blocker",
        attributes={"status": "open", "assignee": "dave"},
        updated_at=stale_updated,
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    escalate_suggestions = [s for s in result.suggestions if "Escalate" in s.suggestion]
    assert len(escalate_suggestions) == 1
    s = escalate_suggestions[0]
    assert "10 days" in s.suggestion
    assert "--escalate" in s.action_command
    assert s.confidence == 0.8


def test_analyze_stale_exactly_seven_days_triggers_escalation() -> None:
    """Boundary: exactly 7 days stale must still trigger escalation."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    stale_updated = datetime.utcnow() - timedelta(days=7)
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Border stale blocker",
        attributes={"status": "open", "assignee": "eve"},
        updated_at=stale_updated,
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    escalate_suggestions = [s for s in result.suggestions if "Escalate" in s.suggestion]
    assert len(escalate_suggestions) == 1


def test_analyze_fresh_blocker_does_not_escalate() -> None:
    """Blocker updated 2 days ago (< 7) → no escalation suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Fresh blocker",
        attributes={"status": "open", "assignee": "frank"},
        updated_at=datetime.utcnow() - timedelta(days=2),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    escalate_suggestions = [s for s in result.suggestions if "Escalate" in s.suggestion]
    assert escalate_suggestions == []


def test_analyze_stale_blocked_status_triggers_escalation() -> None:
    """'blocked' status is in the stale-eligible set."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Blocked blocker",
        attributes={"status": "blocked", "assignee": "grace"},
        updated_at=datetime.utcnow() - timedelta(days=8),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    escalate_suggestions = [s for s in result.suggestions if "Escalate" in s.suggestion]
    assert len(escalate_suggestions) == 1


# ---------------------------------------------------------------------------
# analyze — blocker blocking many → suggest splitting
# ---------------------------------------------------------------------------


def test_analyze_blocker_blocking_many_suggests_splitting() -> None:
    """Blocker with >= 2 downstream BLOCKS edges → suggest splitting."""
    store = _storage()
    target1 = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature A")
    target2 = make_ticket(id="t-2", external_id="PROJ-2", title="Ship feature B")
    target3 = make_ticket(id="t-3", external_id="PROJ-3", title="Ship feature C")
    blocker = make_ticket(
        id="t-blocker",
        external_id="PROJ-99",
        title="Big blocker",
        attributes={"status": "open", "assignee": "henry"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target1)
    store.upsert_entity(target2)
    store.upsert_entity(target3)
    store.upsert_entity(blocker)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-blocker", to_entity="t-1", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-2", from_entity="t-blocker", to_entity="t-2", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-3", from_entity="t-blocker", to_entity="t-3", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    split_suggestions = [s for s in result.suggestions if "splitting" in s.suggestion.lower()]
    assert len(split_suggestions) == 1
    s = split_suggestions[0]
    assert "3" in s.suggestion
    assert s.confidence == 0.5


def test_analyze_blocker_blocking_exactly_two_suggests_splitting() -> None:
    """Boundary: exactly 2 downstream tickets triggers split suggestion."""
    store = _storage()
    t1 = make_ticket(id="t-1", external_id="PROJ-1", title="Feature A")
    t2 = make_ticket(id="t-2", external_id="PROJ-2", title="Feature B")
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Dual blocker",
        attributes={"status": "open", "assignee": "ivan"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(t1)
    store.upsert_entity(t2)
    store.upsert_entity(blocker)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-b", to_entity="t-1", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-2", from_entity="t-b", to_entity="t-2", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    split_suggestions = [s for s in result.suggestions if "splitting" in s.suggestion.lower()]
    assert len(split_suggestions) == 1


def test_analyze_blocker_blocking_one_does_not_suggest_splitting() -> None:
    """Only 1 downstream ticket → no split suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Feature A")
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Single blocker",
        attributes={"status": "open", "assignee": "judy"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-b", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    split_suggestions = [s for s in result.suggestions if "splitting" in s.suggestion.lower()]
    assert split_suggestions == []


def test_analyze_non_blocks_edges_not_counted_for_splitting() -> None:
    """DEPENDS_ON edges from the blocker must not inflate the downstream count."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Feature A")
    t2 = make_ticket(id="t-2", external_id="PROJ-2", title="Unrelated")
    t3 = make_ticket(id="t-3", external_id="PROJ-3", title="Also unrelated")
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Single real blocker",
        attributes={"status": "open", "assignee": "karen"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(t2)
    store.upsert_entity(t3)
    store.upsert_entity(blocker)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-b", to_entity="t-1", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-2", from_entity="t-b", to_entity="t-2", edge_type=EdgeType.DEPENDS_ON))
    store.upsert_edge(make_edge(id="e-3", from_entity="t-b", to_entity="t-3", edge_type=EdgeType.RELATED_TO))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    split_suggestions = [s for s in result.suggestions if "splitting" in s.suggestion.lower()]
    assert split_suggestions == []


# ---------------------------------------------------------------------------
# _find_best_candidate — owner resolution
# ---------------------------------------------------------------------------


def test_find_best_candidate_returns_confirmed_owner_first() -> None:
    """Confirmed owner must be preferred over unconfirmed even if scored lower."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    unconfirmed = Owner(entity_id="t-b", candidate_owner="high-scorer@example.com", score=0.95, signal="commits", confirmed=False)
    confirmed = Owner(entity_id="t-b", candidate_owner="confirmed@example.com", score=0.60, signal="review", confirmed=True)
    store.upsert_owner(unconfirmed)
    store.upsert_owner(confirmed)

    engine = UnblockEngine(store)
    candidate = engine._find_best_candidate(blocker)

    assert candidate == "confirmed@example.com"


def test_find_best_candidate_returns_highest_scored_when_no_confirmed() -> None:
    """No confirmed owners → fall back to the top-scored candidate (storage orders by score DESC)."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    low = Owner(entity_id="t-b", candidate_owner="low@example.com", score=0.3, signal="mentions", confirmed=False)
    high = Owner(entity_id="t-b", candidate_owner="high@example.com", score=0.8, signal="commits", confirmed=False)
    store.upsert_owner(low)
    store.upsert_owner(high)

    engine = UnblockEngine(store)
    candidate = engine._find_best_candidate(blocker)

    assert candidate == "high@example.com"


def test_find_best_candidate_returns_none_when_no_owners() -> None:
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    engine = UnblockEngine(store)
    candidate = engine._find_best_candidate(blocker)

    assert candidate is None


def test_find_best_candidate_single_confirmed_owner() -> None:
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-99",
        title="Blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    owner = Owner(entity_id="t-b", candidate_owner="solo@example.com", score=0.75, signal="git-blame", confirmed=True)
    store.upsert_owner(owner)

    engine = UnblockEngine(store)
    candidate = engine._find_best_candidate(blocker)

    assert candidate == "solo@example.com"


# ---------------------------------------------------------------------------
# _find_similar_resolved
# ---------------------------------------------------------------------------


def test_find_similar_resolved_returns_matching_resolved_ticket() -> None:
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-10",
        title="Fix authentication timeout error",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    resolved = make_ticket(
        id="t-r",
        external_id="PROJ-5",
        title="Fix authentication session error",
        attributes={"status": "done"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)
    store.upsert_entity(resolved)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is not None
    assert result.id == "t-r"


def test_find_similar_resolved_ignores_different_project_prefix() -> None:
    """Tickets from a different project prefix must not match."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-10",
        title="Fix authentication timeout error",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    other_proj = make_ticket(
        id="t-r",
        external_id="OTHER-5",
        title="Fix authentication timeout error",
        attributes={"status": "done"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)
    store.upsert_entity(other_proj)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is None


def test_find_similar_resolved_ignores_open_tickets() -> None:
    """Open tickets (same project) must not be returned as 'similar resolved'."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-10",
        title="Fix authentication timeout error",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    open_sibling = make_ticket(
        id="t-s",
        external_id="PROJ-8",
        title="Fix authentication session error",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)
    store.upsert_entity(open_sibling)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is None


def test_find_similar_resolved_requires_at_least_two_word_overlap() -> None:
    """Single-word overlap must not be enough to qualify as 'similar'."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-10",
        title="Fix login page",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    resolved_one_word = make_ticket(
        id="t-r",
        external_id="PROJ-3",
        title="Fix unrelated totally different thing",
        attributes={"status": "done"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)
    store.upsert_entity(resolved_one_word)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is None


def test_find_similar_resolved_returns_none_when_external_id_has_no_dash() -> None:
    """No dash in external_id means no prefix → should return None immediately."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="NODASH",
        title="Fix authentication timeout error",
        attributes={"status": "open"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is None


def test_find_similar_resolved_skips_self() -> None:
    """The blocker itself must not be returned as its own similar resolved ticket."""
    store = _storage()
    blocker = make_ticket(
        id="t-b",
        external_id="PROJ-10",
        title="Fix authentication timeout resolved",
        attributes={"status": "done"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(blocker)

    engine = UnblockEngine(store)
    result = engine._find_similar_resolved(blocker)

    assert result is None


# ---------------------------------------------------------------------------
# _count_downstream
# ---------------------------------------------------------------------------


def test_count_downstream_counts_only_blocks_edges() -> None:
    store = _storage()
    source = make_ticket(id="t-src", external_id="PROJ-0", title="Source")
    t1 = make_ticket(id="t-1", external_id="PROJ-1", title="Downstream A")
    t2 = make_ticket(id="t-2", external_id="PROJ-2", title="Downstream B")
    t3 = make_ticket(id="t-3", external_id="PROJ-3", title="Related")
    for e in (source, t1, t2, t3):
        store.upsert_entity(e)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-src", to_entity="t-1", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-2", from_entity="t-src", to_entity="t-2", edge_type=EdgeType.BLOCKS))
    store.upsert_edge(make_edge(id="e-3", from_entity="t-src", to_entity="t-3", edge_type=EdgeType.RELATED_TO))

    engine = UnblockEngine(store)
    count = engine._count_downstream(source)

    assert count == 2


def test_count_downstream_zero_when_no_outbound_edges() -> None:
    store = _storage()
    entity = make_ticket(id="t-lone", external_id="PROJ-0", title="Lone ranger")
    store.upsert_entity(entity)

    engine = UnblockEngine(store)
    assert engine._count_downstream(entity) == 0


def test_count_downstream_zero_when_only_non_blocks_edges() -> None:
    store = _storage()
    src = make_ticket(id="t-src", external_id="PROJ-0", title="Source")
    dst = make_ticket(id="t-dst", external_id="PROJ-1", title="Destination")
    store.upsert_entity(src)
    store.upsert_entity(dst)

    store.upsert_edge(make_edge(id="e-1", from_entity="t-src", to_entity="t-dst", edge_type=EdgeType.DEPENDS_ON))

    engine = UnblockEngine(store)
    assert engine._count_downstream(src) == 0


# ---------------------------------------------------------------------------
# build_unblock_context
# ---------------------------------------------------------------------------


def test_build_unblock_context_contains_target_info() -> None:
    analysis = UnblockAnalysis(
        target_entity_id="t-1",
        target_external_id="PROJ-1",
        target_title="Deploy service",
        suggestions=[],
    )
    context = build_unblock_context(analysis)

    assert "PROJ-1" in context
    assert "Deploy service" in context
    assert "0 suggestions" in context


def test_build_unblock_context_lists_all_suggestions() -> None:
    analysis = UnblockAnalysis(
        target_entity_id="t-1",
        target_external_id="PROJ-1",
        target_title="Deploy service",
        suggestions=[
            UnblockSuggestion(
                blocker_entity_id="t-2",
                blocker_external_id="PROJ-2",
                blocker_title="Auth service down",
                suggestion="Assign to alice — has relevant ownership signals",
                action_command="bg draft --ticket PROJ-2 --assign alice",
                confidence=0.7,
            ),
            UnblockSuggestion(
                blocker_entity_id="t-3",
                blocker_external_id="PROJ-3",
                blocker_title="DB migration pending",
                suggestion="Escalate — no progress for 9 days",
                action_command="bg draft --ticket PROJ-3 --escalate",
                confidence=0.8,
            ),
        ],
    )
    context = build_unblock_context(analysis)

    assert "PROJ-2" in context
    assert "Auth service down" in context
    assert "Assign to alice" in context
    assert "bg draft --ticket PROJ-2 --assign alice" in context
    assert "PROJ-3" in context
    assert "Escalate" in context
    assert "bg draft --ticket PROJ-3 --escalate" in context
    assert "2 suggestions" in context


def test_build_unblock_context_omits_action_line_when_empty() -> None:
    analysis = UnblockAnalysis(
        target_entity_id="t-1",
        target_external_id="PROJ-1",
        target_title="Deploy service",
        suggestions=[
            UnblockSuggestion(
                blocker_entity_id="t-2",
                blocker_external_id="PROJ-2",
                blocker_title="Some blocker",
                suggestion="Reference PROJ-5 — similar ticket was resolved",
                action_command="",
                confidence=0.6,
            ),
        ],
    )
    context = build_unblock_context(analysis)

    assert "Action:" not in context
    assert "Reference PROJ-5" in context


def test_build_unblock_context_not_found_entity() -> None:
    """Graceful context generation when the entity was not found."""
    analysis = UnblockAnalysis(
        target_entity_id="",
        target_external_id="PROJ-999",
        target_title="(not found)",
        suggestions=[],
    )
    context = build_unblock_context(analysis)

    assert "PROJ-999" in context
    assert "(not found)" in context


def test_build_unblock_context_includes_blocker_numbering() -> None:
    """Each blocker should be numbered sequentially."""
    suggestions = [
        UnblockSuggestion(
            blocker_entity_id=f"t-{i}",
            blocker_external_id=f"PROJ-{i}",
            blocker_title=f"Blocker {i}",
            suggestion=f"Suggestion {i}",
            action_command="",
            confidence=0.5,
        )
        for i in range(1, 4)
    ]
    analysis = UnblockAnalysis(
        target_entity_id="t-0",
        target_external_id="PROJ-0",
        target_title="Main ticket",
        suggestions=suggestions,
    )
    context = build_unblock_context(analysis)

    assert "Blocker 1:" in context
    assert "Blocker 2:" in context
    assert "Blocker 3:" in context


# ---------------------------------------------------------------------------
# Integration — multiple suggestion types on a single blocker
# ---------------------------------------------------------------------------


def test_analyze_stale_unassigned_blocker_generates_multiple_suggestions() -> None:
    """An unassigned, stale blocker with no owner candidate generates two suggestions:
    the generic 'find an owner' suggestion and the escalation suggestion."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Unassigned stale blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow() - timedelta(days=14),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    types_found = {
        "assign": any("No assignee" in s.suggestion for s in result.suggestions),
        "escalate": any("Escalate" in s.suggestion for s in result.suggestions),
    }
    assert types_found["assign"], "Expected an assignment suggestion"
    assert types_found["escalate"], "Expected an escalation suggestion"


def test_analyze_preserves_correct_blocker_metadata_in_suggestions() -> None:
    """Suggestion fields must accurately reflect the blocker entity that caused them."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Final feature")
    blocker = make_ticket(
        id="t-99",
        external_id="PROJ-99",
        title="The real blocker",
        attributes={"status": "open"},
        updated_at=datetime.utcnow() - timedelta(days=9),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-99", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    for suggestion in result.suggestions:
        assert suggestion.blocker_entity_id == "t-99"
        assert suggestion.blocker_external_id == "PROJ-99"
        assert suggestion.blocker_title == "The real blocker"


def test_analyze_similar_resolved_suggestion_included() -> None:
    """When a similar resolved ticket exists, a reference suggestion is generated."""
    store = _storage()
    target = make_ticket(id="t-1", external_id="PROJ-1", title="Ship feature")
    blocker = make_ticket(
        id="t-2",
        external_id="PROJ-2",
        title="Fix database connection timeout issue",
        attributes={"status": "open", "assignee": "leon"},
        updated_at=datetime.utcnow(),
    )
    resolved = make_ticket(
        id="t-3",
        external_id="PROJ-0",
        title="Fix database connection pool issue",
        attributes={"status": "done"},
        updated_at=datetime.utcnow(),
    )
    store.upsert_entity(target)
    store.upsert_entity(blocker)
    store.upsert_entity(resolved)
    store.upsert_edge(make_edge(id="e-1", from_entity="t-2", to_entity="t-1", edge_type=EdgeType.BLOCKS))

    engine = UnblockEngine(store)
    result = engine.analyze("PROJ-1")

    reference_suggestions = [s for s in result.suggestions if "similar ticket was resolved" in s.suggestion]
    assert len(reference_suggestions) == 1
    s = reference_suggestions[0]
    assert "PROJ-0" in s.suggestion
    assert s.confidence == 0.6
    assert s.action_command == ""
