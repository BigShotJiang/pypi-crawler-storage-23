"""Tests for the BlameGraph Time Machine — history snapshots and drift detection."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from blamegraph.history import (
    DriftItem,
    DriftReport,
    EntityHistory,
    compute_drift,
    get_entity_history,
    take_snapshot,
)
from blamegraph.models import (
    Edge,
    EdgeType,
    Entity,
    EntityType,
    Event,
    GraphSnapshot,
    InferenceMethod,
)
from blamegraph.storage.sqlite import SQLiteStorage

# ---------------------------------------------------------------------------
# Shared helpers imported from conftest
# ---------------------------------------------------------------------------
from tests.conftest import make_edge, make_ticket


# ---------------------------------------------------------------------------
# Internal factory helpers
# ---------------------------------------------------------------------------

def _make_storage() -> SQLiteStorage:
    """Return a freshly initialised in-memory store."""
    store = SQLiteStorage(":memory:")
    store.initialize()
    return store


def _ticket(
    tid: str,
    ext_id: str,
    title: str = "A ticket",
    status: str = "open",
) -> Entity:
    return make_ticket(
        id=tid,
        external_id=ext_id,
        title=title,
        attributes={"status": status, "priority": "medium"},
        created_at=datetime(2025, 1, 1, tzinfo=UTC),
        updated_at=datetime(2025, 1, 2, tzinfo=UTC),
    )


def _blocker_edge(eid: str, from_id: str, to_id: str) -> Edge:
    return make_edge(
        id=eid,
        from_entity=from_id,
        to_entity=to_id,
        edge_type=EdgeType.BLOCKS,
        confidence=1.0,
        created_at=datetime(2025, 1, 1, tzinfo=UTC),
    )


def _depends_edge(eid: str, from_id: str, to_id: str) -> Edge:
    return make_edge(
        id=eid,
        from_entity=from_id,
        to_entity=to_id,
        edge_type=EdgeType.DEPENDS_ON,
        confidence=0.9,
        created_at=datetime(2025, 1, 1, tzinfo=UTC),
    )


def _inject_snapshot_in_past(storage: SQLiteStorage, days_ago: int) -> GraphSnapshot:
    """
    Take a snapshot and then back-date its timestamp so it falls inside the
    drift window used by compute_drift.  This is necessary because
    list_snapshots filters by ts >= cutoff, and take_snapshot always stamps
    with datetime.utcnow().
    """
    snapshot = take_snapshot(storage)

    # Overwrite the ts to be `days_ago` days in the past (still inside window)
    past_ts = datetime.utcnow() - timedelta(days=days_ago)
    # Re-save with the back-dated timestamp
    snapshot = GraphSnapshot(
        id=snapshot.id,
        ts=past_ts,
        entity_count=snapshot.entity_count,
        edge_count=snapshot.edge_count,
        blocker_count=snapshot.blocker_count,
        snapshot_data=snapshot.snapshot_data,
    )
    storage.save_snapshot(snapshot)
    return snapshot


# ===========================================================================
# take_snapshot
# ===========================================================================

def test_take_snapshot_returns_graph_snapshot() -> None:
    """take_snapshot must return a GraphSnapshot instance."""
    store = _make_storage()
    snapshot = take_snapshot(store)
    assert isinstance(snapshot, GraphSnapshot)


def test_take_snapshot_empty_graph_has_zero_counts() -> None:
    """An empty graph produces a snapshot with all counts at zero."""
    store = _make_storage()
    snapshot = take_snapshot(store)
    assert snapshot.entity_count == 0
    assert snapshot.edge_count == 0
    assert snapshot.blocker_count == 0


def test_take_snapshot_entity_count_matches_upserted_entities() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))

    snapshot = take_snapshot(store)

    assert snapshot.entity_count == 3


def test_take_snapshot_edge_count_matches_upserted_edges() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    snapshot = take_snapshot(store)

    assert snapshot.edge_count == 1


def test_take_snapshot_blocker_count_only_counts_blocks_edges() -> None:
    """blocker_count must count only BLOCKS-type edges, not other edge types."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))

    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))  # BLOCKS — counts
    store.upsert_edge(_depends_edge("e2", "t2", "t3"))  # DEPENDS_ON — does not count

    snapshot = take_snapshot(store)

    assert snapshot.blocker_count == 1
    assert snapshot.edge_count == 2


def test_take_snapshot_multiple_blockers_all_counted() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))

    snapshot = take_snapshot(store)

    assert snapshot.blocker_count == 2


def test_take_snapshot_has_unique_id() -> None:
    """Each call to take_snapshot must produce a distinct snapshot id."""
    store = _make_storage()
    s1 = take_snapshot(store)
    s2 = take_snapshot(store)
    assert s1.id != s2.id


def test_take_snapshot_persists_to_storage() -> None:
    """The snapshot returned must also be retrievable via storage."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    snapshot = take_snapshot(store)

    stored = store.get_snapshot(snapshot.id)
    assert stored is not None
    assert stored.id == snapshot.id
    assert stored.entity_count == 1


# ---------------------------------------------------------------------------
# snapshot_data structure
# ---------------------------------------------------------------------------

def test_take_snapshot_data_contains_entities_key() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    snapshot = take_snapshot(store)

    assert "entities" in snapshot.snapshot_data


def test_take_snapshot_data_contains_edges_key() -> None:
    store = _make_storage()
    snapshot = take_snapshot(store)

    assert "edges" in snapshot.snapshot_data


def test_take_snapshot_entity_summaries_include_required_fields() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-42", title="My Ticket", status="in_progress"))
    snapshot = take_snapshot(store)

    entities = snapshot.snapshot_data["entities"]
    assert isinstance(entities, list)
    assert len(entities) == 1

    summary = entities[0]
    assert summary["id"] == "t1"
    assert summary["external_id"] == "PROJ-42"
    assert summary["title"] == "My Ticket"
    assert summary["entity_type"] == "ticket"
    assert summary["status"] == "in_progress"


def test_take_snapshot_edge_summaries_include_required_fields() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("edge-99", "t1", "t2"))
    snapshot = take_snapshot(store)

    edges = snapshot.snapshot_data["edges"]
    assert isinstance(edges, list)
    assert len(edges) == 1

    summary = edges[0]
    assert summary["id"] == "edge-99"
    assert summary["from_entity"] == "t1"
    assert summary["to_entity"] == "t2"
    assert summary["edge_type"] == "blocks"
    assert "confidence" in summary


def test_take_snapshot_edge_summaries_include_all_edge_types() -> None:
    """All edge types should appear in snapshot_data edges, not just blockers."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_depends_edge("e2", "t2", "t3"))

    snapshot = take_snapshot(store)

    edge_types = {e["edge_type"] for e in snapshot.snapshot_data["edges"]}
    assert "blocks" in edge_types
    assert "depends_on" in edge_types


def test_take_snapshot_empty_graph_has_empty_summaries() -> None:
    store = _make_storage()
    snapshot = take_snapshot(store)

    assert snapshot.snapshot_data["entities"] == []
    assert snapshot.snapshot_data["edges"] == []


# ===========================================================================
# compute_drift — no historical snapshots
# ===========================================================================

def test_compute_drift_no_snapshots_returns_empty_report() -> None:
    """
    When there are no prior snapshots compute_drift takes a baseline now and
    returns a zeroed-out DriftReport.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    assert isinstance(report, DriftReport)
    assert report.new_blockers == 0
    assert report.resolved == 0
    assert report.net_change == 0
    assert report.trend == "stable"
    assert report.items == []
    assert report.scope_creep == []


def test_compute_drift_no_snapshots_creates_baseline_snapshot() -> None:
    """After compute_drift with no history, a snapshot is stored for future use."""
    store = _make_storage()

    compute_drift(store, since_days=7)

    snapshots = store.list_snapshots()
    assert len(snapshots) == 1


def test_compute_drift_no_snapshots_since_field_reflects_window() -> None:
    store = _make_storage()

    report = compute_drift(store, since_days=14)

    assert report.since == "14d"


def test_compute_drift_no_snapshots_team_field_preserved() -> None:
    store = _make_storage()

    report = compute_drift(store, since_days=7, team="platform")

    assert report.team == "platform"


# ===========================================================================
# compute_drift — new blockers
# ===========================================================================

def test_compute_drift_detects_new_blocker_added_after_snapshot() -> None:
    """
    Sequence:
      1. Upsert two tickets.
      2. Take a baseline snapshot (no blocker edges yet).
      3. Add a BLOCKS edge.
      4. compute_drift must report new_blockers == 1.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1", title="Ticket One"))
    store.upsert_entity(_ticket("t2", "PROJ-2", title="Ticket Two"))

    _inject_snapshot_in_past(store, days_ago=1)

    # Now add a blocker that did not exist at snapshot time
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    assert report.new_blockers == 1
    assert report.resolved == 0
    assert report.net_change == 1
    assert report.trend == "increasing"


def test_compute_drift_new_blocker_item_has_correct_kind() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))

    _inject_snapshot_in_past(store, days_ago=1)
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    new_blocker_items = [item for item in report.items if item.kind == "new_blocker"]
    assert len(new_blocker_items) == 1


def test_compute_drift_new_blocker_item_references_valid_entity() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1", title="Blocker Ticket"))
    store.upsert_entity(_ticket("t2", "PROJ-2", title="Blocked Ticket"))

    _inject_snapshot_in_past(store, days_ago=1)
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    item = next(i for i in report.items if i.kind == "new_blocker")
    assert item.entity_id in {"t1", "t2"}
    assert item.external_id in {"PROJ-1", "PROJ-2"}
    assert item.title in {"Blocker Ticket", "Blocked Ticket"}


def test_compute_drift_detail_string_mentions_both_entity_ids() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))

    _inject_snapshot_in_past(store, days_ago=1)
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    item = next(i for i in report.items if i.kind == "new_blocker")
    assert "t1" in item.detail
    assert "t2" in item.detail


def test_compute_drift_multiple_new_blockers_all_counted() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))

    _inject_snapshot_in_past(store, days_ago=1)

    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))

    report = compute_drift(store, since_days=7)

    assert report.new_blockers == 2


def test_compute_drift_existing_blocker_not_reported_as_new() -> None:
    """
    A BLOCKS edge present before the snapshot is not new — it should not appear
    in the drift report.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    # Snapshot captures the existing blocker as baseline
    _inject_snapshot_in_past(store, days_ago=1)

    report = compute_drift(store, since_days=7)

    assert report.new_blockers == 0
    assert report.items == []


# ===========================================================================
# compute_drift — resolved blockers
# ===========================================================================

def test_compute_drift_detects_resolved_blocker() -> None:
    """
    Sequence:
      1. Upsert two tickets and a BLOCKS edge.
      2. Take a baseline snapshot (blocker present).
      3. Remove the edge.
      4. compute_drift must report resolved == 1.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    _inject_snapshot_in_past(store, days_ago=1)

    # Simulate resolution by deleting the edge directly via SQL (storage has no
    # delete_edge API, so we use the underlying connection for test purposes).
    store._conn.execute("DELETE FROM edges WHERE id = 'e1'")
    store._conn.commit()

    report = compute_drift(store, since_days=7)

    assert report.resolved == 1
    assert report.new_blockers == 0
    assert report.net_change == -1
    assert report.trend == "decreasing"


def test_compute_drift_resolved_item_has_correct_kind() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    _inject_snapshot_in_past(store, days_ago=1)

    store._conn.execute("DELETE FROM edges WHERE id = 'e1'")
    store._conn.commit()

    report = compute_drift(store, since_days=7)

    resolved_items = [item for item in report.items if item.kind == "resolved"]
    assert len(resolved_items) == 1


def test_compute_drift_resolved_detail_string_describes_removal() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    _inject_snapshot_in_past(store, days_ago=1)

    store._conn.execute("DELETE FROM edges WHERE id = 'e1'")
    store._conn.commit()

    report = compute_drift(store, since_days=7)

    item = next(i for i in report.items if i.kind == "resolved")
    assert "t1" in item.detail
    assert "t2" in item.detail


def test_compute_drift_multiple_resolved_blockers() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))

    _inject_snapshot_in_past(store, days_ago=1)

    store._conn.execute("DELETE FROM edges WHERE id IN ('e1', 'e2')")
    store._conn.commit()

    report = compute_drift(store, since_days=7)

    assert report.resolved == 2


# ===========================================================================
# compute_drift — trend detection
# ===========================================================================

def test_compute_drift_trend_stable_when_no_change() -> None:
    """Trend must be 'stable' when net_change == 0."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    _inject_snapshot_in_past(store, days_ago=1)

    # No changes since snapshot
    report = compute_drift(store, since_days=7)

    assert report.net_change == 0
    assert report.trend == "stable"


def test_compute_drift_trend_increasing_when_net_positive() -> None:
    """Trend must be 'increasing' when new_blockers > resolved."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))

    # Snapshot with one existing blocker
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    _inject_snapshot_in_past(store, days_ago=1)

    # Add two more blockers (net +2)
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))
    store.upsert_edge(_blocker_edge("e3", "t2", "t3"))

    report = compute_drift(store, since_days=7)

    assert report.trend == "increasing"
    assert report.net_change > 0


def test_compute_drift_trend_decreasing_when_net_negative() -> None:
    """Trend must be 'decreasing' when resolved > new_blockers."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_blocker_edge("e2", "t2", "t3"))

    _inject_snapshot_in_past(store, days_ago=1)

    # Resolve both blockers, add none
    store._conn.execute("DELETE FROM edges WHERE id IN ('e1', 'e2')")
    store._conn.commit()

    report = compute_drift(store, since_days=7)

    assert report.trend == "decreasing"
    assert report.net_change < 0


def test_compute_drift_trend_stable_when_equal_new_and_resolved() -> None:
    """Trend must be 'stable' when one blocker added and one removed."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    _inject_snapshot_in_past(store, days_ago=1)

    # Remove one blocker and add one new blocker (net 0)
    store._conn.execute("DELETE FROM edges WHERE id = 'e1'")
    store._conn.commit()
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))

    report = compute_drift(store, since_days=7)

    assert report.net_change == 0
    assert report.trend == "stable"


# ===========================================================================
# compute_drift — scope creep detection
# ===========================================================================

def test_compute_drift_scope_creep_detected_for_new_entity_with_deps() -> None:
    """
    A ticket added after the baseline snapshot that has at least one BLOCKS or
    DEPENDS_ON edge should appear in scope_creep.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))

    _inject_snapshot_in_past(store, days_ago=1)

    # New ticket added after baseline, with a dependency
    store.upsert_entity(_ticket("t3", "PROJ-3", title="New Scope Ticket"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t3"))

    report = compute_drift(store, since_days=7)

    assert len(report.scope_creep) == 1
    assert report.scope_creep[0].kind == "scope_creep"
    assert report.scope_creep[0].external_id == "PROJ-3"


def test_compute_drift_scope_creep_item_has_entity_details() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    _inject_snapshot_in_past(store, days_ago=1)

    store.upsert_entity(_ticket("t2", "PROJ-2", title="Late Addition"))
    store.upsert_edge(_depends_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    item = report.scope_creep[0]
    assert item.entity_id == "t2"
    assert item.external_id == "PROJ-2"
    assert item.title == "Late Addition"
    assert item.kind == "scope_creep"


def test_compute_drift_new_entity_without_deps_is_not_scope_creep() -> None:
    """A new ticket with no edges connected to it should not be scope creep."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    _inject_snapshot_in_past(store, days_ago=1)

    # New ticket with no edges — should not be flagged as scope creep
    store.upsert_entity(_ticket("t2", "PROJ-2", title="Isolated New Ticket"))

    report = compute_drift(store, since_days=7)

    assert report.scope_creep == []


def test_compute_drift_scope_creep_triggered_by_depends_on_edge() -> None:
    """DEPENDS_ON edges (not just BLOCKS) can trigger scope-creep detection."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    _inject_snapshot_in_past(store, days_ago=1)

    store.upsert_entity(_ticket("t2", "PROJ-2"))
    # t2 appears for the first time and has a DEPENDS_ON edge
    store.upsert_edge(_depends_edge("e1", "t2", "t1"))

    report = compute_drift(store, since_days=7)

    assert len(report.scope_creep) == 1
    assert report.scope_creep[0].entity_id == "t2"


def test_compute_drift_existing_entity_not_flagged_as_scope_creep() -> None:
    """Tickets present in the baseline must never be flagged as scope creep."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))

    _inject_snapshot_in_past(store, days_ago=1)

    # Add an edge between existing entities — no new ticket introduced
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    report = compute_drift(store, since_days=7)

    assert report.scope_creep == []


def test_compute_drift_multiple_scope_creep_items() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    _inject_snapshot_in_past(store, days_ago=1)

    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_entity(_ticket("t3", "PROJ-3"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))
    store.upsert_edge(_blocker_edge("e2", "t1", "t3"))

    report = compute_drift(store, since_days=7)

    assert len(report.scope_creep) == 2


# ===========================================================================
# compute_drift — snapshot window boundary
# ===========================================================================

def test_compute_drift_snapshot_outside_window_is_ignored() -> None:
    """
    A snapshot older than since_days must not be used as the baseline; the
    function should behave as if there were no snapshots and create a new one.
    """
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))
    store.upsert_edge(_blocker_edge("e1", "t1", "t2"))

    # Manually save a snapshot with a ts that is older than 7 days
    old_snapshot = take_snapshot(store)
    ancient_ts = datetime.utcnow() - timedelta(days=30)
    old_snapshot = GraphSnapshot(
        id=old_snapshot.id,
        ts=ancient_ts,
        entity_count=old_snapshot.entity_count,
        edge_count=old_snapshot.edge_count,
        blocker_count=old_snapshot.blocker_count,
        snapshot_data=old_snapshot.snapshot_data,
    )
    store.save_snapshot(old_snapshot)

    # The out-of-window snapshot must be ignored; a new baseline is created
    report = compute_drift(store, since_days=7)

    assert report.new_blockers == 0
    assert report.resolved == 0


# ===========================================================================
# get_entity_history
# ===========================================================================

def test_get_entity_history_returns_entity_history_for_known_entity() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-100", title="History Ticket"))

    result = get_entity_history(store, "PROJ-100")

    assert isinstance(result, EntityHistory)
    assert result.entity_id == "t1"
    assert result.external_id == "PROJ-100"
    assert result.title == "History Ticket"


def test_get_entity_history_returns_none_for_unknown_entity() -> None:
    store = _make_storage()

    result = get_entity_history(store, "DOES-NOT-EXIST")

    assert result is None


def test_get_entity_history_empty_events_when_no_events_recorded() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert result.events == []


def test_get_entity_history_returns_events_in_chronological_order() -> None:
    """Events must be returned ordered by ts ascending."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    e1 = Event(
        entity_id="t1",
        ts=datetime(2025, 3, 10, 8, 0, 0),
        kind="status_change",
        payload={"from": "open", "to": "in_progress"},
    )
    e2 = Event(
        entity_id="t1",
        ts=datetime(2025, 3, 15, 12, 0, 0),
        kind="comment_added",
        payload={"author": "alice", "body": "Working on this"},
    )
    e3 = Event(
        entity_id="t1",
        ts=datetime(2025, 3, 20, 9, 30, 0),
        kind="status_change",
        payload={"from": "in_progress", "to": "done"},
    )

    # Insert in reverse order to verify ordering is applied by storage
    store.add_event(e3)
    store.add_event(e1)
    store.add_event(e2)

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert len(result.events) == 3
    ts_list = [ev["ts"] for ev in result.events]
    assert ts_list == sorted(ts_list)


def test_get_entity_history_event_dicts_contain_required_keys() -> None:
    """Each event dict must contain 'ts', 'kind', and 'payload' keys."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    store.add_event(
        Event(
            entity_id="t1",
            ts=datetime(2025, 4, 1, 10, 0, 0),
            kind="status_change",
            payload={"from": "open", "to": "done"},
        )
    )

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert len(result.events) == 1
    ev = result.events[0]
    assert "ts" in ev
    assert "kind" in ev
    assert "payload" in ev


def test_get_entity_history_event_ts_is_iso_format_string() -> None:
    """The 'ts' field in each event dict must be an ISO-formatted string."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    record_ts = datetime(2025, 6, 15, 14, 30, 0)
    store.add_event(
        Event(
            entity_id="t1",
            ts=record_ts,
            kind="blocker_added",
            payload={},
        )
    )

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    ev_ts_str = result.events[0]["ts"]
    assert isinstance(ev_ts_str, str)
    # Must parse without error
    parsed = datetime.fromisoformat(ev_ts_str)
    assert parsed == record_ts


def test_get_entity_history_event_payload_is_preserved() -> None:
    """The payload dict of an event must survive the round-trip intact."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    payload = {"from": "open", "to": "in_review", "reviewer": "bob"}
    store.add_event(
        Event(
            entity_id="t1",
            ts=datetime(2025, 5, 1, 9, 0, 0),
            kind="status_change",
            payload=payload,
        )
    )

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert result.events[0]["payload"] == payload


def test_get_entity_history_event_kind_is_preserved() -> None:
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    store.add_event(
        Event(
            entity_id="t1",
            ts=datetime(2025, 5, 1, 9, 0, 0),
            kind="blocker_resolved",
            payload={"by": "charlie"},
        )
    )

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert result.events[0]["kind"] == "blocker_resolved"


def test_get_entity_history_multiple_events_all_returned() -> None:
    """All events for an entity must appear in the history — none skipped."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))

    for i in range(5):
        store.add_event(
            Event(
                entity_id="t1",
                ts=datetime(2025, 1, i + 1, 12, 0, 0),
                kind=f"event_{i}",
                payload={"index": i},
            )
        )

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert len(result.events) == 5


def test_get_entity_history_does_not_return_events_for_other_entities() -> None:
    """Events attached to a different entity must not appear in the result."""
    store = _make_storage()
    store.upsert_entity(_ticket("t1", "PROJ-1"))
    store.upsert_entity(_ticket("t2", "PROJ-2"))

    store.add_event(Event(entity_id="t1", ts=datetime(2025, 1, 1), kind="t1_event", payload={}))
    store.add_event(Event(entity_id="t2", ts=datetime(2025, 1, 2), kind="t2_event", payload={}))

    result = get_entity_history(store, "PROJ-1")

    assert result is not None
    assert len(result.events) == 1
    assert result.events[0]["kind"] == "t1_event"


# ===========================================================================
# DriftReport and DriftItem dataclass sanity checks
# ===========================================================================

def test_drift_report_defaults() -> None:
    report = DriftReport(team=None, since="7d")
    assert report.new_blockers == 0
    assert report.resolved == 0
    assert report.net_change == 0
    assert report.trend == "stable"
    assert report.items == []
    assert report.scope_creep == []


def test_drift_item_fields_stored_correctly() -> None:
    item = DriftItem(
        kind="new_blocker",
        entity_id="t1",
        external_id="PROJ-1",
        title="Some Ticket",
        detail="New blocker: t1 blocks t2",
    )
    assert item.kind == "new_blocker"
    assert item.entity_id == "t1"
    assert item.external_id == "PROJ-1"
    assert item.title == "Some Ticket"
    assert "t1" in item.detail


def test_entity_history_defaults() -> None:
    history = EntityHistory(entity_id="t1", external_id="PROJ-1", title="T")
    assert history.events == []
