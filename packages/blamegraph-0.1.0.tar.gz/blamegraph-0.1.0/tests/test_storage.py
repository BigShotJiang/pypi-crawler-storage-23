"""Tests for blamegraph.storage.sqlite."""

from __future__ import annotations

from datetime import datetime

from blamegraph.models import (
    Edge,
    EdgeType,
    Entity,
    EntityType,
    Event,
    Evidence,
    InferenceMethod,
    Owner,
    RiskLevel,
    RiskScore,
)
from blamegraph.storage.sqlite import SQLiteStorage


def _make_storage() -> SQLiteStorage:
    store = SQLiteStorage(":memory:")
    store.initialize()
    return store


def _entity(eid: str = "e1", ext_id: str = "MOB-100") -> Entity:
    return Entity(
        id=eid,
        entity_type=EntityType.TICKET,
        external_id=ext_id,
        title="Test ticket",
        created_at=datetime(2024, 1, 1),
        updated_at=datetime(2024, 1, 2),
    )


class TestEntityCRUD:
    def test_upsert_and_get(self) -> None:
        store = _make_storage()
        entity = _entity()
        store.upsert_entity(entity)
        result = store.get_entity("e1")
        assert result is not None
        assert result.id == "e1"
        assert result.external_id == "MOB-100"
        assert result.title == "Test ticket"

    def test_get_nonexistent_returns_none(self) -> None:
        store = _make_storage()
        assert store.get_entity("nope") is None

    def test_upsert_updates_existing(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity())
        updated = _entity()
        updated.title = "Updated title"
        store.upsert_entity(updated)
        result = store.get_entity("e1")
        assert result is not None
        assert result.title == "Updated title"

    def test_list_entities(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(_entity("e2", "MOB-2"))
        all_entities = store.list_entities()
        assert len(all_entities) == 2

    def test_list_entities_by_type(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(
            Entity(
                id="p1",
                entity_type=EntityType.PR,
                external_id="!42",
                created_at=datetime(2024, 1, 1),
                updated_at=datetime(2024, 1, 1),
            )
        )
        tickets = store.list_entities("ticket")
        assert len(tickets) == 1
        assert tickets[0].id == "e1"


class TestEventCRUD:
    def test_add_and_list_events(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity())
        event = Event(
            entity_id="e1",
            ts=datetime(2024, 1, 5),
            kind="status_change",
            payload={"from": "Open", "to": "Done"},
        )
        store.add_event(event)
        events = store.list_events("e1")
        assert len(events) == 1
        assert events[0].kind == "status_change"
        assert events[0].payload["from"] == "Open"


class TestEdgeCRUD:
    def test_upsert_and_get_edges(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(_entity("e2", "MOB-2"))
        edge = Edge(
            id="edge1",
            from_entity="e1",
            to_entity="e2",
            edge_type=EdgeType.BLOCKS,
            confidence=1.0,
            method=InferenceMethod.EXPLICIT,
            evidence=[Evidence(source_type="jira", source_id="MOB-1")],
            created_at=datetime(2024, 1, 1),
        )
        store.upsert_edge(edge)

        from_edges = store.get_edges_from("e1")
        assert len(from_edges) == 1
        assert from_edges[0].to_entity == "e2"
        assert from_edges[0].confidence == 1.0

        to_edges = store.get_edges_to("e2")
        assert len(to_edges) == 1

    def test_list_all_edges(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(_entity("e2", "MOB-2"))
        store.upsert_edge(
            Edge(
                id="edge1",
                from_entity="e1",
                to_entity="e2",
                edge_type=EdgeType.DEPENDS_ON,
                confidence=0.8,
                created_at=datetime(2024, 1, 1),
            )
        )
        all_edges = store.list_edges()
        assert len(all_edges) == 1

    def test_auto_generate_edge_id(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(_entity("e2", "MOB-2"))
        store.upsert_edge(
            Edge(
                from_entity="e1",
                to_entity="e2",
                edge_type=EdgeType.RELATED_TO,
                confidence=0.5,
                created_at=datetime(2024, 1, 1),
            )
        )
        edges = store.list_edges()
        assert len(edges) == 1
        assert edges[0].id != ""


class TestOwnerCRUD:
    def test_upsert_and_get_owners(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity())
        owner = Owner(
            entity_id="e1",
            candidate_owner="team-mobile",
            score=0.9,
            signal="explicit",
            confirmed=False,
        )
        store.upsert_owner(owner)
        owners = store.get_owners("e1")
        assert len(owners) == 1
        assert owners[0].candidate_owner == "team-mobile"
        assert owners[0].score == 0.9

    def test_owner_dedup_on_conflict(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity())
        store.upsert_owner(Owner(entity_id="e1", candidate_owner="team-a", score=0.5))
        store.upsert_owner(Owner(entity_id="e1", candidate_owner="team-a", score=0.9))
        owners = store.get_owners("e1")
        assert len(owners) == 1
        assert owners[0].score == 0.9


class TestRiskScoreCRUD:
    def test_upsert_and_get(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity())
        rs = RiskScore(
            entity_id="e1",
            score=75.0,
            level=RiskLevel.HIGH,
            features={"staleness": 0.8, "no_clear_owner": 1.0},
            why=["Stale ticket", "No owner assigned"],
            suggested_action="Assign owner",
            ts=datetime(2024, 1, 10),
        )
        store.upsert_risk_score(rs)
        result = store.get_risk_score("e1")
        assert result is not None
        assert result.score == 75.0
        assert result.level == RiskLevel.HIGH
        assert len(result.why) == 2
        assert result.suggested_action == "Assign owner"

    def test_get_nonexistent_returns_none(self) -> None:
        store = _make_storage()
        assert store.get_risk_score("nope") is None

    def test_list_risk_scores_with_min(self) -> None:
        store = _make_storage()
        store.upsert_entity(_entity("e1", "MOB-1"))
        store.upsert_entity(_entity("e2", "MOB-2"))
        store.upsert_risk_score(
            RiskScore(
                entity_id="e1",
                score=20.0,
                level=RiskLevel.LOW,
                ts=datetime(2024, 1, 1),
            )
        )
        store.upsert_risk_score(
            RiskScore(
                entity_id="e2",
                score=80.0,
                level=RiskLevel.CRITICAL,
                ts=datetime(2024, 1, 1),
            )
        )
        high = store.list_risk_scores(min_score=50.0)
        assert len(high) == 1
        assert high[0].entity_id == "e2"

        all_scores = store.list_risk_scores()
        assert len(all_scores) == 2


class TestStorageLifecycle:
    def test_close(self) -> None:
        store = _make_storage()
        store.close()
