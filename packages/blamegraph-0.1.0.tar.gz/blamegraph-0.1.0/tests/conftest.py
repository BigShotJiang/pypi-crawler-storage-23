"""Shared test fixtures and factory functions for BlameGraph tests."""

from __future__ import annotations

from datetime import UTC, datetime

from blamegraph.models import (
    Edge,
    EdgeType,
    Entity,
    EntityType,
    InferenceMethod,
    RiskLevel,
    RiskScore,
)


def make_ticket(**overrides: object) -> Entity:
    """Create a valid ticket Entity with sensible defaults."""
    defaults: dict[str, object] = {
        "id": "ticket-001",
        "entity_type": EntityType.TICKET,
        "external_id": "PROJ-100",
        "title": "Fix login bug",
        "attributes": {"status": "open", "priority": "high"},
        "created_at": datetime(2025, 1, 1, tzinfo=UTC),
        "updated_at": datetime(2025, 1, 2, tzinfo=UTC),
    }
    defaults.update(overrides)
    return Entity(**defaults)  # type: ignore[arg-type]


def make_edge(**overrides: object) -> Edge:
    """Create a valid Edge with sensible defaults."""
    defaults: dict[str, object] = {
        "id": "edge-001",
        "from_entity": "ticket-001",
        "to_entity": "ticket-002",
        "edge_type": EdgeType.DEPENDS_ON,
        "confidence": 0.85,
        "method": InferenceMethod.EXPLICIT,
        "evidence": [],
        "created_at": datetime(2025, 1, 1, tzinfo=UTC),
    }
    defaults.update(overrides)
    return Edge(**defaults)  # type: ignore[arg-type]


def make_risk_score(**overrides: object) -> RiskScore:
    """Create a valid RiskScore with sensible defaults."""
    defaults: dict[str, object] = {
        "entity_id": "ticket-001",
        "score": 45.0,
        "level": RiskLevel.MEDIUM,
        "features": {"staleness": 0.5, "blocker_count": 1.0},
        "why": ["Ticket has been open for 30 days"],
        "suggested_action": "Review and update status",
        "ts": datetime(2025, 1, 1, tzinfo=UTC),
    }
    defaults.update(overrides)
    return RiskScore(**defaults)  # type: ignore[arg-type]
