"""Tests for the credentials module."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from blamegraph import credentials


@pytest.fixture(autouse=True)
def _isolate_credentials(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Redirect credential paths to a temp directory for every test."""
    cred_dir = tmp_path / ".blamegraph"
    cred_file = cred_dir / "credentials.yaml"
    monkeypatch.setattr(credentials, "CREDENTIALS_DIR", cred_dir)
    monkeypatch.setattr(credentials, "CREDENTIALS_PATH", cred_file)


def test_save_and_load_roundtrip() -> None:
    credentials.save_token("jira", "my-jira-token")
    assert credentials.load_token("jira") == "my-jira-token"


def test_load_nonexistent_returns_none() -> None:
    assert credentials.load_token("jira") is None


def test_file_permissions() -> None:
    credentials.save_token("jira", "tok")
    mode = os.stat(credentials.CREDENTIALS_PATH).st_mode
    assert stat.S_IMODE(mode) == 0o600


def test_dir_permissions() -> None:
    credentials.save_token("jira", "tok")
    mode = os.stat(credentials.CREDENTIALS_DIR).st_mode
    assert stat.S_IMODE(mode) == 0o700


def test_list_services_all_empty() -> None:
    result = credentials.list_services()
    assert result == {
        "jira": False,
        "gitlab": False,
        "slack": False,
        "anthropic": False,
        "github": False,
        "bitbucket": False,
        "teams": False,
    }


def test_list_services_partial() -> None:
    credentials.save_token("gitlab", "gl-token")
    result = credentials.list_services()
    assert result["gitlab"] is True
    assert result["jira"] is False
    assert result["slack"] is False


def test_remove_token() -> None:
    credentials.save_token("jira", "tok")
    assert credentials.load_token("jira") == "tok"
    credentials.remove_token("jira")
    assert credentials.load_token("jira") is None


def test_remove_nonexistent_token_no_error() -> None:
    credentials.remove_token("jira")  # should not raise


def test_overwrite_token() -> None:
    credentials.save_token("jira", "old-token")
    credentials.save_token("jira", "new-token")
    assert credentials.load_token("jira") == "new-token"


def test_multiple_services() -> None:
    credentials.save_token("jira", "j-tok")
    credentials.save_token("gitlab", "g-tok")
    credentials.save_token("slack", "s-tok")
    assert credentials.load_token("jira") == "j-tok"
    assert credentials.load_token("gitlab") == "g-tok"
    assert credentials.load_token("slack") == "s-tok"


def test_save_preserves_other_tokens() -> None:
    credentials.save_token("jira", "j-tok")
    credentials.save_token("gitlab", "g-tok")
    assert credentials.load_token("jira") == "j-tok"
