#!/usr/bin/env bash
set -e

echo "=== BlameGraph Setup ==="

# Install uv if not available
if ! command -v uv &> /dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
fi

# Install dependencies and project
echo "Installing dependencies..."
uv sync
uv pip install -e .

# Run init using venv binary directly
echo ""
.venv/bin/blamegraph init "$@"

echo ""
echo "Done! Next time just run:"
echo "  .venv/bin/blamegraph config show"
echo "  .venv/bin/blamegraph sync"
