"""Jupyter integration for QuickView via jupyter-server-proxy."""

from .proxy import setup_quickview

__all__ = ["setup_quickview"]
