"""QuickView: Visual Analysis for E3SM Atmosphere Data."""

__version__ = "1.3.4"
__author__ = "Kitware Inc."
__license__ = "Apache-2.0"
