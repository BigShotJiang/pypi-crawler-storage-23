"""Tools for pausing and resuming campaigns.

Provides safety controls to stop outreach when needed
and resume it when ready.
"""

from __future__ import annotations

import logging

from ..db.queries import (
    get_campaign,
    get_setting,
    list_campaigns,
    update_campaign,
)

logger = logging.getLogger(__name__)


async def run_pause_campaign(campaign_id: str = "") -> str:
    """Pause an active campaign, stopping all outreach.

    If no campaign_id is provided, pauses the first active campaign found.
    """

    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before managing campaigns.\n\n"
            "Please run setup_profile first."
        )

    # Find the campaign to pause
    if campaign_id:
        campaign = get_campaign(campaign_id)
        if not campaign:
            return f"Campaign not found: {campaign_id}"
    else:
        campaigns = list_campaigns(status="active")
        if not campaigns:
            return (
                "No active campaigns to pause.\n\n"
                "Use show_status() to see all campaigns."
            )
        campaign = campaigns[0]
        campaign_id = campaign["id"]

    # Check current status
    status = campaign.get("status", "")
    if status == "paused":
        return (
            f"Campaign '{campaign['name']}' is already paused.\n\n"
            "Use resume_campaign() to resume it."
        )
    if status not in ("active", "draft"):
        return (
            f"Campaign '{campaign['name']}' has status '{status}' and cannot be paused.\n"
            "Only active or draft campaigns can be paused."
        )

    # Pause it
    update_campaign(campaign_id, status="paused")
    logger.info(f"Paused campaign {campaign_id}: {campaign['name']}")

    return (
        f"Campaign '{campaign['name']}' is now paused.\n\n"
        "All outreach for this campaign is stopped.\n"
        "No invitations or messages will be sent.\n\n"
        "Use resume_campaign() when you're ready to continue."
    )


async def run_resume_campaign(campaign_id: str = "") -> str:
    """Resume a paused campaign, re-enabling outreach.

    If no campaign_id is provided, resumes the first paused campaign found.
    """

    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before managing campaigns.\n\n"
            "Please run setup_profile first."
        )

    # Find the campaign to resume
    if campaign_id:
        campaign = get_campaign(campaign_id)
        if not campaign:
            return f"Campaign not found: {campaign_id}"
    else:
        campaigns = list_campaigns(status="paused")
        if not campaigns:
            return (
                "No paused campaigns to resume.\n\n"
                "Use show_status() to see all campaigns."
            )
        campaign = campaigns[0]
        campaign_id = campaign["id"]

    # Check current status
    status = campaign.get("status", "")
    if status == "active":
        return (
            f"Campaign '{campaign['name']}' is already active.\n\n"
            "Outreach is running normally."
        )
    if status != "paused":
        return (
            f"Campaign '{campaign['name']}' has status '{status}' and cannot be resumed.\n"
            "Only paused campaigns can be resumed."
        )

    # Resume it
    update_campaign(campaign_id, status="active")
    logger.info(f"Resumed campaign {campaign_id}: {campaign['name']}")

    return (
        f"Campaign '{campaign['name']}' is now active again.\n\n"
        "Outreach will resume. Use generate_and_send() to send the next message."
    )
