def main():
    print("Hello from rakam-systems-vectorstore!")


if __name__ == "__main__":
    main()
