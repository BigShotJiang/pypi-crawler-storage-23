"""Backward compatibility alias for graphsense.models.location_inner."""

from graphsense.models.location_inner import *  # noqa: F401, F403
