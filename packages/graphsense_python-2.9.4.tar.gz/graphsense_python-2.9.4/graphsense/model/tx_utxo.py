"""Backward compatibility alias for graphsense.models.tx_utxo."""

from graphsense.models.tx_utxo import *  # noqa: F401, F403
