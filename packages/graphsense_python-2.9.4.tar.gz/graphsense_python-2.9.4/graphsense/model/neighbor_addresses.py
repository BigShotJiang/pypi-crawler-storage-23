"""Backward compatibility alias for graphsense.models.neighbor_addresses."""

from graphsense.models.neighbor_addresses import *  # noqa: F401, F403
