"""Backward compatibility alias for graphsense.models.related_address."""

from graphsense.models.related_address import *  # noqa: F401, F403
