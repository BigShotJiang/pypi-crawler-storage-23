"""Backward compatibility alias for graphsense.models.entity_addresses."""

from graphsense.models.entity_addresses import *  # noqa: F401, F403
