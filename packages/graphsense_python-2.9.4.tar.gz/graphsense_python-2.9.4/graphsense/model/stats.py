"""Backward compatibility alias for graphsense.models.stats."""

from graphsense.models.stats import *  # noqa: F401, F403
