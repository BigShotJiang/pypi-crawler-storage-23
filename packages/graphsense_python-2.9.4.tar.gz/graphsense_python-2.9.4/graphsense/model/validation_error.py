"""Backward compatibility alias for graphsense.models.validation_error."""

from graphsense.models.validation_error import *  # noqa: F401, F403
