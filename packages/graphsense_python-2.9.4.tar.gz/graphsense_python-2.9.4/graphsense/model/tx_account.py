"""Backward compatibility alias for graphsense.models.tx_account."""

from graphsense.models.tx_account import *  # noqa: F401, F403
