"""Backward compatibility alias for graphsense.models.user_reported_tag."""

from graphsense.models.user_reported_tag import *  # noqa: F401, F403
