"""Backward compatibility alias for graphsense.models.tx_summary."""

from graphsense.models.tx_summary import *  # noqa: F401, F403
