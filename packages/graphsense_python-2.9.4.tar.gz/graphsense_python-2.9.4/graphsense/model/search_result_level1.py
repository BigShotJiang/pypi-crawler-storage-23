"""Backward compatibility alias for graphsense.models.search_result_level1."""

from graphsense.models.search_result_level1 import *  # noqa: F401, F403
