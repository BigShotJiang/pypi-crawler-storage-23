"""Backward compatibility alias for graphsense.models.links."""

from graphsense.models.links import *  # noqa: F401, F403
