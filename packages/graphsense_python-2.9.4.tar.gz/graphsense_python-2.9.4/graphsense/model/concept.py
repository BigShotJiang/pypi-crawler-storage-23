"""Backward compatibility alias for graphsense.models.concept."""

from graphsense.models.concept import *  # noqa: F401, F403
