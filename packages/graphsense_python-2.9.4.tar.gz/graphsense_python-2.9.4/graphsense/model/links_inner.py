"""Backward compatibility alias for graphsense.models.links_inner."""

from graphsense.models.links_inner import *  # noqa: F401, F403
