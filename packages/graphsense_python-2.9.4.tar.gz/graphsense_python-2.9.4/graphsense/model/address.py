"""Backward compatibility alias for graphsense.models.address."""

from graphsense.models.address import *  # noqa: F401, F403
