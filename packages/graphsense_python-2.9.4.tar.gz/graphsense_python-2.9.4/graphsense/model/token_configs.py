"""Backward compatibility alias for graphsense.models.token_configs."""

from graphsense.models.token_configs import *  # noqa: F401, F403
