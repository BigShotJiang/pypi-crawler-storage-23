"""Backward compatibility alias for graphsense.models.search_result."""

from graphsense.models.search_result import *  # noqa: F401, F403
