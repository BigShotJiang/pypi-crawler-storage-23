"""Backward compatibility alias for graphsense.models.address_tag."""

from graphsense.models.address_tag import *  # noqa: F401, F403
