"""Backward compatibility alias for graphsense.models.tag."""

from graphsense.models.tag import *  # noqa: F401, F403
