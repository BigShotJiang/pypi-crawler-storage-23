"""Backward compatibility alias for graphsense.models.related_addresses."""

from graphsense.models.related_addresses import *  # noqa: F401, F403
