"""Backward compatibility alias for graphsense.models.link."""

from graphsense.models.link import *  # noqa: F401, F403
