"""Backward compatibility alias for graphsense.models.token_config."""

from graphsense.models.token_config import *  # noqa: F401, F403
