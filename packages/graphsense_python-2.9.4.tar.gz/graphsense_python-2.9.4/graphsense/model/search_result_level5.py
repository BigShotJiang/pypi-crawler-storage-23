"""Backward compatibility alias for graphsense.models.search_result_level5."""

from graphsense.models.search_result_level5 import *  # noqa: F401, F403
