"""Backward compatibility alias for graphsense.models.link_utxo."""

from graphsense.models.link_utxo import *  # noqa: F401, F403
