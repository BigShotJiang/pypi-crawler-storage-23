"""Backward compatibility alias for graphsense.models.address_tx."""

from graphsense.models.address_tx import *  # noqa: F401, F403
