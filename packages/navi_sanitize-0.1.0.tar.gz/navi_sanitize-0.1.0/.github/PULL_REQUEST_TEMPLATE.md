## Description

<!-- What does this PR do? Why is it needed? -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Refactoring
- [ ] Documentation
- [ ] CI / infrastructure

## Checklist

- [ ] Code follows the project's style guidelines
- [ ] Tests added or updated as appropriate
- [ ] No new warnings introduced
- [ ] Security implications reviewed (pipeline ordering, bypass vectors)

## Related issues

<!-- Closes #123 -->
