# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our community a positive experience for everyone, regardless of background or identity.

## Our Standards

**Encouraged behavior:**

- Being respectful and constructive
- Giving and accepting feedback gracefully
- Focusing on what is best for the community
- Showing empathy toward other community members

**Unacceptable behavior:**

- Personal attacks, insults, or derogatory comments
- Publishing others' private information without permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement

Instances of unacceptable behavior may be reported to the project maintainer at security@projectnavi.ai. All reports will be reviewed and investigated promptly and fairly.

The project maintainer has the right and responsibility to remove, edit, or reject contributions that are not aligned with this Code of Conduct, and to temporarily or permanently restrict any contributor for behavior they deem inappropriate.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
