# Governance

## Project Lead

navi-sanitize is maintained by [Nelson Spence](https://github.com/ndspence) at [Project Navi LLC](https://github.com/Project-Navi).

## Decision Making

This project follows a benevolent dictator model. The project lead makes final decisions on:

- Feature scope and API design
- Pipeline stage additions or changes
- Release timing and versioning
- Security response

## Contributions

All contributions are welcome via pull requests. The project lead reviews and merges PRs. See [CONTRIBUTING.md](CONTRIBUTING.md) for the development workflow.

## Releases

Releases follow [semantic versioning](https://semver.org/). The project lead decides when to cut releases.

## Security

Security vulnerabilities are handled per [SECURITY.md](SECURITY.md). The project lead coordinates fixes and disclosure.

## Changes to Governance

This governance model may evolve as the project grows. Changes will be documented in this file.
