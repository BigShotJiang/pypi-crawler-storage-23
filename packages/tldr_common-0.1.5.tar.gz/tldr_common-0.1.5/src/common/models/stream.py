from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class StreamBase(BaseModel):
    """Base model for stream data."""

    game_name: Optional[str] = None
    user_id: int
    stream_id: str
    stream_start_time: datetime
    stream_end_time: Optional[datetime] = None
    platform: Optional[str] = None  # New field to specify the platform


class StreamCreate(StreamBase):
    """Model for creating a new stream."""

    pass


class StreamUpdate(BaseModel):
    """Model for updating stream data."""

    game_name: Optional[str] = None
    stream_start_time: Optional[datetime] = None
    stream_end_time: Optional[datetime] = None
    platform: Optional[str] = None  # New field to specify the platform


class Stream(StreamBase):
    """Complete stream model including database ID and end time."""

    id: int

    model_config = ConfigDict(from_attributes=True)
