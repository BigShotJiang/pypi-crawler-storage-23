from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field
from common.models.common import Platform


class StreamSignalHistoryCreate(BaseModel):
    user_id: int
    clip_id: int
    description: Optional[str] = None


class StreamSignalHistory(BaseModel):
    id: int
    user_id: int
    clip_id: int
    description: Optional[str] = None
    created_at: datetime
    deleted_at: Optional[datetime] = None


class StreamSignalHistoryPlatformCreate(BaseModel):
    stream_signal_history_id: int
    platform: Platform


class StreamSignalHistoryPlatform(BaseModel):
    id: int
    stream_signal_history_id: int
    platform: Platform


class StreamSignalHistoryItem(BaseModel):
    clip_type: str
    thumbnail_url: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime
    platforms: List[Platform] = Field(default_factory=list)
