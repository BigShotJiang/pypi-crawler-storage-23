import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, ConfigDict, Field
from common.models.common import Platform, UserAccessToken


class KickAccountBase(BaseModel):
    """Model for Kick account data."""

    user_id: int
    kick_id: str
    kick_username: str
    profile_link: Optional[str] = None
    profile_picture: Optional[str] = None
    authorized_at: Optional[datetime.datetime] = None


class KickAccountCreate(KickAccountBase):
    """Model for creating a new Kick account."""

    pass


class KickAccountUpdate(BaseModel):
    """Model for updating Kick account data."""

    user_id: Optional[int] = None
    kick_id: Optional[str] = None
    kick_username: Optional[str] = None
    profile_link: Optional[str] = None
    profile_picture: Optional[str] = None
    updated_at: Optional[datetime.datetime] = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC)
    )
    deleted_at: Optional[datetime.datetime] = None
    authorized_at: Optional[datetime.datetime] = None


class KickAccount(KickAccountBase):
    """Complete Kick account model including database ID."""

    id: int
    access_token: Optional[UserAccessToken] = None
    created_at: datetime.datetime
    updated_at: datetime.datetime
    deleted_at: Optional[datetime.datetime] = None
    authorized_at: Optional[datetime.datetime] = None

    model_config = ConfigDict(from_attributes=True)


class TwitchAccountBase(BaseModel):
    """Model for Twitch account data."""

    user_id: int
    twitch_id: str
    twitch_username: str
    profile_link: Optional[str] = None
    profile_picture: Optional[str] = None
    authorized_at: Optional[datetime.datetime] = None
    oauth_token_id: Optional[int] = None


class SocialMediaAccountCreate(BaseModel):
    """Model for Social Media account data creation."""

    platform: Platform
    user_id: int
    oauth_token_id: Optional[int] = None
    username: Optional[str] = None
    authorized_at: Optional[datetime.datetime] = None
    created_at: Optional[datetime.datetime] = None
    updated_at: Optional[datetime.datetime] = None


class SocialMediaAccount(SocialMediaAccountCreate):
    """Model for Social Media account data."""

    id: int


class TwitchAccountCreate(TwitchAccountBase):
    """Model for creating a new Twitch account."""

    pass


class TwitchAccountUpdate(BaseModel):
    """Model for updating Twitch account data."""

    user_id: Optional[int] = None
    twitch_id: Optional[str] = None
    twitch_username: Optional[str] = None
    profile_link: Optional[str] = None
    profile_picture: Optional[str] = None
    updated_at: Optional[datetime.datetime] = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC)
    )
    deleted_at: Optional[datetime.datetime] = None
    authorized_at: Optional[datetime.datetime] = None
    oauth_token_id: Optional[int] = None


class TwitchAccount(TwitchAccountBase):
    id: int
    access_token: Optional[UserAccessToken] = None
    created_at: datetime.datetime
    updated_at: datetime.datetime
    deleted_at: Optional[datetime.datetime] = None

    model_config = ConfigDict(from_attributes=True)


class UserBase(BaseModel):
    """Base model for user data."""

    email: EmailStr
    first_promoter_id: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    tier: str = "basic"
    product: Optional[str] = None


class UserCreate(UserBase):
    """Model for creating a new user."""

    pass


class UserUpdate(BaseModel):
    """Model for updating user data."""

    email: Optional[EmailStr] = None
    first_promoter_id: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    tier: Optional[str] = None
    product: Optional[str] = None
    updated_at: Optional[datetime.datetime] = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC)
    )
    last_login: Optional[datetime.datetime] = None
    deleted_at: Optional[datetime.datetime] = None


class User(UserBase):
    """Complete user model including database ID."""

    id: int
    twitch_account: Optional[TwitchAccount] = None
    kick_account: Optional[KickAccount] = None
    created_at: datetime.datetime
    updated_at: datetime.datetime
    deleted_at: Optional[datetime.datetime] = None
    last_login: Optional[datetime.datetime] = None
    social_media_platforms: Optional[List[str]] = None
    is_tenant_user: Optional[bool] = None

    model_config = ConfigDict(from_attributes=True)
