"""Pydantic models for highlight candidate audit trail.

These models support the comprehensive audit trail for clip generation A/B testing,
persisting ALL highlight candidates (accepted AND rejected) with full scoring data.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict


class CandidateDecision(str, Enum):
    """Decision outcome for a highlight candidate."""

    ACCEPTED = "accepted"
    REJECTED = "rejected"


class RejectionReason(str, Enum):
    """Reason why a highlight candidate was rejected.

    Used for retrospective analysis of rejection decisions and threshold tuning.
    """

    BELOW_CONFIDENCE = "below_confidence"
    BELOW_COMBINED_SCORE = "below_combined_score"
    INSUFFICIENT_DIMENSIONS = "insufficient_dimensions"
    RATE_LIMITED = "rate_limited"
    SPACING_VIOLATION = "spacing_violation"
    DEDUPLICATED = "deduplicated"
    QUOTA_EXCEEDED = "quota_exceeded"


class HighlightCandidateBase(BaseModel):
    """Base fields shared by all highlight candidate models."""

    stream_id: int
    user_id: int
    peak_timestamp: float
    start_timestamp: str
    end_timestamp: str
    confidence: float
    combined_score: float
    dimension_scores: Dict[str, Any]
    prompt_version: str
    game_config_name: Optional[str] = None
    decision: CandidateDecision
    rejection_reason: Optional[RejectionReason] = None
    description: Optional[str] = None
    trigger_type: Optional[str] = None
    source_segment_id: Optional[str] = None
    clip_id: Optional[int] = None


class HighlightCandidateCreate(HighlightCandidateBase):
    """Data required to create a new highlight candidate record."""

    pass


class HighlightCandidateUpdate(BaseModel):
    """Data required to update a highlight candidate record."""

    clip_id: Optional[int] = None
    deleted_at: Optional[datetime] = None


class HighlightCandidate(HighlightCandidateBase):
    """Full highlight candidate model with database fields."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
    deleted_at: Optional[datetime] = None
