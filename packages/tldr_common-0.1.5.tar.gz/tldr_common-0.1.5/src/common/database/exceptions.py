class DatabaseError(Exception):
    """Base class for all database-related exceptions."""

    pass


class UniqueConstraintError(DatabaseError):
    """Raised when a unique constraint is violated."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message
