from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class ProModelSettings(BaseSettings):
    clip_gen_login_grace_days: int = 14
    max_clips_per_day: int = 10
    max_clips_per_month: int = 30
    pro_feature_enable: bool = False
    max_custom_wake_words: int = 5
    max_seats: int = 5

    free_tier: str = "basic"
    pro_tier: str = "pro"

    model_config = SettingsConfigDict(
        env_prefix="PRO_MODEL_", extra="ignore", case_sensitive=False, env_file=".env"
    )


@lru_cache
def get_pro_model_settings() -> ProModelSettings:
    return ProModelSettings()
