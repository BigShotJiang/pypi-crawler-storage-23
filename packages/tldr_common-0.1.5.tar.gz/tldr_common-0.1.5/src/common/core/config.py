"""Common configuration for the TL;DR.tv platform."""

from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class CommonConfig(BaseSettings):
    """Base configuration for all services."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Application settings
    environment: str = "development"
    debug: bool = False
    log_level: str = "INFO"

    # Database settings (can be overridden by services)
    database_url: Optional[str] = None
    database_pool_size: int = 10
    database_max_overflow: int = 20

    # Message queue settings
    rabbitmq_url: Optional[str] = None
    rabbitmq_pool_size: int = 10

    # API settings
    api_timeout: int = 30
    api_retry_attempts: int = 3
    api_retry_delay: float = 1.0

    # Feature flags
    enable_metrics: bool = True
    enable_tracing: bool = True
    enable_logfire: bool = True
