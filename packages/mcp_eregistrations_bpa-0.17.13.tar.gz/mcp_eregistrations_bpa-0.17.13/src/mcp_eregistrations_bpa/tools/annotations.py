"""Shared MCP tool annotations for read/write/destructive classification.

These annotations inform MCP clients about tool behavior so they can make
smarter permission decisions (e.g., auto-approving read-only tools).

See: https://modelcontextprotocol.io/docs/concepts/tools#tool-annotations
"""

from mcp.types import ToolAnnotations

# Read-only tools: never modify data (list, get, search, export, analyze, validate)
READ = ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True)

# Write tools: create or update data, but non-destructive (create, update, link)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True)

# Destructive tools: delete data or perform irreversible operations
DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=True, openWorldHint=True
)
