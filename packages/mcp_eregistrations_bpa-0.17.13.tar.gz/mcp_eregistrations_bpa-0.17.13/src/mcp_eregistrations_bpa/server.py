"""MCP server for eRegistrations BPA platform."""

from __future__ import annotations

import logging
import os
import time

from fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa import __version__
from mcp_eregistrations_bpa.auth import TokenManager
from mcp_eregistrations_bpa.auth.credentials import (
    delete_credentials,
    get_credentials,
    store_credentials,
)
from mcp_eregistrations_bpa.auth.oidc import is_browser_available
from mcp_eregistrations_bpa.auth.permissions import browser_login, password_login
from mcp_eregistrations_bpa.config import load_config
from mcp_eregistrations_bpa.tools import (
    register_action_tools,
    register_analysis_tools,
    register_audit_tools,
    register_behaviour_tools,
    register_bot_mapping_tools,
    register_bot_tools,
    register_classification_tools,
    register_cost_tools,
    register_debug_tools,
    register_determinant_tools,
    register_document_requirement_tools,
    register_export_tools,
    register_external_service_tools,
    register_field_tools,
    register_form_tools,
    register_message_tools,
    register_notification_tools,
    register_print_document_tools,
    register_registration_institution_tools,
    register_registration_tools,
    register_role_status_tools,
    register_role_tools,
    register_role_unit_tools,
    register_rollback_tools,
    register_service_tools,
    register_workflow_tools,
)

logger = logging.getLogger(__name__)

# GitHub releases API for version checks
_GITHUB_REPO = "UNCTAD-eRegistrations/mcp-eregistrations-bpa"
_GITHUB_API_URL = f"https://api.github.com/repos/{_GITHUB_REPO}/releases/latest"

# Version cache: (latest_version_str, timestamp)
_version_cache: tuple[str, float] | None = None
_VERSION_CACHE_TTL = 3600  # 1 hour

mcp = FastMCP("eregistrations-bpa")

# Register BPA tools
register_service_tools(mcp)
register_registration_tools(mcp)
register_registration_institution_tools(mcp)
register_field_tools(mcp)
register_form_tools(mcp)
register_determinant_tools(mcp)
register_action_tools(mcp)
register_behaviour_tools(mcp)
register_bot_tools(mcp)
register_bot_mapping_tools(mcp)
register_external_service_tools(mcp)
register_classification_tools(mcp)
register_notification_tools(mcp)
register_print_document_tools(mcp)
register_message_tools(mcp)
register_role_tools(mcp)
register_role_status_tools(mcp)
register_role_unit_tools(mcp)
register_document_requirement_tools(mcp)
register_cost_tools(mcp)
register_analysis_tools(mcp)
register_audit_tools(mcp)
register_rollback_tools(mcp)
register_export_tools(mcp)
register_workflow_tools(mcp)
register_debug_tools(mcp)

# Global token manager instance (in-memory storage)
_token_manager = TokenManager()


@mcp.tool(
    annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": True}
)
async def auth_login(
    username: str | None = None,
    password: str | None = None,
    persist_credentials: bool = False,
) -> dict[str, object]:
    """Authenticate with BPA. Supports browser and password grant.

    When called without credentials in a non-interactive environment,
    returns an ask_credentials response for the AI agent to handle.

    Args:
        username: BPA username (optional; enables password grant).
        password: BPA password (optional; required if username given).
        persist_credentials: Save credentials to system keyring (default: False).

    Returns:
        dict with success/ask_credentials status, user info, session duration.
    """
    from mcp_eregistrations_bpa.exceptions import AuthenticationError

    # Validation
    if username and not password:
        raise ToolError("Password is required when username is provided.")
    if password and not username:
        raise ToolError("Username is required when password is provided.")

    config = load_config()

    # Branch A: Credentials provided
    if username and password:
        result = await password_login(username, password)
        if result.get("success") and persist_credentials:
            stored = store_credentials(config.instance_id, username, password)
            if not stored:
                result["credential_storage_warning"] = (
                    "Keyring unavailable; credentials not saved."
                )
        return result

    # Branch B: No credentials, try automatic methods

    # Try keyring
    creds = get_credentials(config.instance_id)
    if creds:
        try:
            result = await password_login(creds[0], creds[1])
            if result.get("success"):
                return result
        except AuthenticationError:
            pass
        # Stale creds - clean up
        delete_credentials(config.instance_id)

    # Try browser
    if is_browser_available():
        try:
            result = await browser_login()
            if result.get("success"):
                return result
        except AuthenticationError:
            pass

    # All methods exhausted - return ask_credentials
    return {
        "action_required": "ask_credentials",
        "message": (
            "Cannot open browser for authentication. "
            "Please provide your BPA credentials."
        ),
        "fields": [
            {
                "name": "username",
                "type": "text",
                "label": "BPA Username (email)",
                "required": True,
            },
            {
                "name": "password",
                "type": "password",
                "label": "BPA Password",
                "required": True,
            },
            {
                "name": "persist_credentials",
                "type": "boolean",
                "label": "Remember credentials",
                "required": False,
            },
        ],
        "retry_tool": "auth_login",
        "instance_url": config.bpa_instance_url,
    }


def _get_github_token() -> str | None:
    """Get a GitHub token from env vars or gh CLI."""
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token
    try:
        import subprocess

        result = subprocess.run(  # noqa: S603, S607
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass
    return None


async def _check_latest_version() -> str | None:
    """Check GitHub for the latest release version (cached 1h).

    Returns:
        Latest version string (e.g. "0.14.1"), or None if check fails.
    """
    global _version_cache  # noqa: PLW0603

    # Return cached value if fresh
    if _version_cache is not None:
        cached_version, cached_at = _version_cache
        if time.monotonic() - cached_at < _VERSION_CACHE_TTL:
            return cached_version

    try:
        import httpx

        headers = {"Accept": "application/vnd.github+json"}
        # Private repo: use GitHub token if available
        gh_token = _get_github_token()
        if gh_token:
            headers["Authorization"] = f"Bearer {gh_token}"

        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(_GITHUB_API_URL, headers=headers)
            resp.raise_for_status()
            tag: str = resp.json().get("tag_name", "")
            latest = tag.lstrip("v")
            _version_cache = (latest, time.monotonic())
            return latest
    except Exception:
        logger.debug("Version check failed", exc_info=True)
        return None


def _version_info(latest: str | None) -> dict[str, object]:
    """Build version info dict comparing current vs latest.

    Args:
        latest: Latest version string from GitHub, or None.

    Returns:
        dict with version, latest_version, update_available, update_message.
    """
    info: dict[str, object] = {"version": __version__}

    if latest is None:
        return info

    info["latest_version"] = latest

    try:
        current = tuple(int(x) for x in __version__.split("."))
        remote = tuple(int(x) for x in latest.split("."))
        if remote > current:
            info["update_available"] = True
            info["update_message"] = (
                f"Update available: v{latest}. "
                f"See https://github.com/{_GITHUB_REPO}/releases/tag/v{latest}"
            )
        else:
            info["update_available"] = False
    except (ValueError, TypeError):
        pass

    return info


async def get_connection_status() -> dict[str, object]:
    """Get current BPA connection status (internal implementation).

    Returns connection state, authenticated user, permissions, and session info.
    This is a read-only operation that does not trigger token refresh.

    Returns:
        dict: Connection status with instance URL, instance_id, user, permissions,
        and expiry.
    """
    config = load_config()
    latest = await _check_latest_version()
    version = _version_info(latest)

    # Check if not authenticated
    if not _token_manager.is_authenticated():
        return {
            "connected": False,
            "instance_id": config.instance_id,
            "instance_url": config.bpa_instance_url,
            "message": "Not authenticated. Run auth_login to connect.",
            **version,
        }

    # Check if token has already expired
    if _token_manager.is_token_expired():
        return {
            "connected": False,
            "instance_id": config.instance_id,
            "instance_url": config.bpa_instance_url,
            "message": "Session expired. Run auth_login to reconnect.",
            **version,
        }

    # Return full authenticated status
    return {
        "connected": True,
        "instance_id": config.instance_id,
        "instance_url": config.bpa_instance_url,
        "user": _token_manager.user_email,
        "permissions": _token_manager.permissions,
        "session_expires_in": f"{_token_manager.expires_in_minutes} minutes",
        **version,
    }


@mcp.tool(
    annotations={"readOnlyHint": True, "destructiveHint": False, "openWorldHint": True}
)
async def connection_status() -> dict[str, object]:
    """View current BPA connection status.

    Returns connection state, authenticated user, permissions, and session info.
    This is a read-only operation that does not trigger token refresh.

    Returns:
        dict: Connection status with instance URL, user, permissions, and expiry.
    """
    return await get_connection_status()


@mcp.tool(
    annotations={"readOnlyHint": True, "destructiveHint": False, "openWorldHint": False}
)
async def server_info() -> dict[str, object]:
    """Get metadata about this BPA MCP instance. No authentication required.

    Returns the BPA instance URL, realm, instance ID, and MCP version.
    Use this to identify which BPA environment this server is connected to,
    and to discover available BPA instances across multiple configured servers.

    Returns:
        dict with bpa_instance_url, instance_id, auth_provider, mcp_version,
        and keycloak_realm (if configured).
    """
    config = load_config()
    info: dict[str, object] = {
        "bpa_instance_url": config.bpa_instance_url,
        "instance_id": config.instance_id,
        "auth_provider": config.auth_provider.value,
        "mcp_version": __version__,
    }
    if config.keycloak_realm:
        info["keycloak_realm"] = config.keycloak_realm
    return info


def get_token_manager() -> TokenManager:
    """Get the global token manager instance.

    This is used by other modules to access the authenticated session.

    Returns:
        The global TokenManager instance.
    """
    return _token_manager
