"""Permission enforcement for MCP tools.

This module provides guards and utility functions to enforce
BPA permissions before tool execution. All permission checks
are server-side and based on JWT token claims.

Usage in MCP tools:
    @mcp.tool()
    async def service_create(name: str) -> dict[str, object]:
        # Ensure write permission before proceeding
        access_token = await ensure_write_permission()
        # ... use access_token for BPA API call
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from mcp.server.fastmcp.exceptions import ToolError

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from mcp_eregistrations_bpa.auth.token_manager import TokenManager

__all__ = [
    "PERMISSION_VIEWER",
    "PERMISSION_SERVICE_DESIGNER",
    "WRITE_PERMISSIONS",
    "browser_login",
    "check_permission",
    "ensure_authenticated",
    "ensure_write_permission",
    "password_login",
]

# Permission constants
PERMISSION_VIEWER = "viewer"
PERMISSION_SERVICE_DESIGNER = "service_designer"

# Roles that allow write operations
WRITE_PERMISSIONS: list[str] = [PERMISSION_SERVICE_DESIGNER]


def get_token_manager() -> TokenManager:
    """Get the global token manager instance.

    Uses late import to avoid circular dependency with server.py.

    Returns:
        The global TokenManager instance.
    """
    from mcp_eregistrations_bpa.server import get_token_manager as _get_tm

    return _get_tm()


async def password_login(username: str, password: str) -> dict[str, object]:
    """Dispatch password grant to correct provider (Keycloak or CAS).

    Args:
        username: BPA username.
        password: BPA password.

    Returns:
        Auth result dict (same contract as perform_password_login).
    """
    from mcp_eregistrations_bpa.config import AuthProvider, load_config

    config = load_config()
    if config.auth_provider == AuthProvider.CAS:
        from mcp_eregistrations_bpa.auth.cas import perform_cas_password_login

        return await perform_cas_password_login(username, password)
    else:
        from mcp_eregistrations_bpa.auth.oidc import perform_password_login

        return await perform_password_login(username, password)


async def browser_login() -> dict[str, object]:
    """Dispatch browser login to correct provider (Keycloak or CAS).

    Returns:
        Auth result dict.
    """
    from mcp_eregistrations_bpa.config import AuthProvider, load_config

    config = load_config()
    if config.auth_provider == AuthProvider.CAS:
        from mcp_eregistrations_bpa.auth.cas import perform_cas_browser_login

        return await perform_cas_browser_login()
    else:
        from mcp_eregistrations_bpa.auth.oidc import perform_browser_login

        return await perform_browser_login()


async def ensure_authenticated() -> str:
    """Ensure user is authenticated and return access token.

    Priority chain:
    1. Valid cached token -> return immediately
    2. Refresh token -> attempt refresh
    3. Keyring credentials -> password grant
    4. Browser available -> browser login
    5. Raise ToolError with instructions

    Returns:
        Valid access token.

    Raises:
        ToolError: If all authentication methods fail.
    """
    from mcp_eregistrations_bpa.exceptions import AuthenticationError

    token_manager = get_token_manager()
    logger.debug("Checking authentication status...")

    # Step 1: Valid cached token
    if token_manager.is_authenticated() and not token_manager.is_token_expired():
        logger.debug("User authenticated: %s", token_manager.user_email)
        return await token_manager.get_access_token()

    # Step 2: Refresh token available
    if token_manager.is_authenticated():
        logger.info("Token expired or near-expiry, attempting refresh")
        try:
            return await token_manager.get_access_token()  # triggers _refresh()
        except AuthenticationError:
            logger.info("Token refresh failed, falling through to re-auth")

    # Step 3: Keyring credentials
    from mcp_eregistrations_bpa.auth.credentials import (
        delete_credentials,
        get_credentials,
    )
    from mcp_eregistrations_bpa.config import load_config

    config = load_config()
    try:
        creds = get_credentials(config.instance_id)
    except Exception:
        creds = None
        logger.debug("Keyring read failed, continuing")
    if creds:
        logger.info("Found keyring credentials, attempting password grant")
        try:
            result = await password_login(creds[0], creds[1])
            if result.get("success"):
                return await token_manager.get_access_token()
        except AuthenticationError:
            pass
        # Stored creds are stale - delete them
        logger.info("Keyring credentials failed, removing stale entry")
        delete_credentials(config.instance_id)

    # Step 4: Browser available
    from mcp_eregistrations_bpa.auth.oidc import is_browser_available

    if is_browser_available():
        logger.info("Browser available, attempting browser login")
        try:
            result = await browser_login()
            if result.get("success"):
                return await token_manager.get_access_token()
            if result.get("error"):
                logger.error("Browser login failed: %s", result.get("message"))
        except AuthenticationError as e:
            logger.error("Browser login error: %s", e)

    # Step 5: All methods exhausted
    raise ToolError("Not authenticated. Call auth_login with your credentials.")


async def ensure_write_permission() -> str:
    """Ensure user has write permission and return access token.

    Combines authentication check with write permission verification.
    Checks if user has any role in WRITE_PERMISSIONS.

    Returns:
        Valid access token for BPA API calls.

    Raises:
        ToolError: If not authenticated or lacks write permission.
    """
    # First ensure authenticated (raises if not)
    token = await ensure_authenticated()

    # Check for write permission
    token_manager = get_token_manager()
    user_permissions = set(token_manager.permissions)

    if not user_permissions.intersection(WRITE_PERMISSIONS):
        raise ToolError(
            "Permission denied: You don't have write access. "
            "Contact your administrator."
        )

    return token


def check_permission(required_permission: str) -> None:
    """Check if user has a specific permission.

    This is a synchronous check that also validates authentication status.
    Raises ToolError if not authenticated or if permission is missing.

    Args:
        required_permission: The permission role required.

    Raises:
        ToolError: If not authenticated or user lacks the required permission.
    """
    token_manager = get_token_manager()

    # Verify authentication first (sync check - doesn't refresh)
    if not token_manager.is_authenticated():
        raise ToolError("Not authenticated. Run auth_login first.")

    if token_manager.is_token_expired():
        raise ToolError("Session expired. Please run auth_login again.")

    if required_permission not in token_manager.permissions:
        raise ToolError(
            f"Permission denied: You need '{required_permission}' permission. "
            "Contact your administrator."
        )
