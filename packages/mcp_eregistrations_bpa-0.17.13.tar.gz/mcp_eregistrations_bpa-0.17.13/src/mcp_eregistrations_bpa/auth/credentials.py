"""Secure credential storage using OS system keyring."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

KEYRING_SERVICE_PREFIX = "mcp-eregistrations-bpa"


def _get_keyring() -> Any:
    """Lazy-import keyring to avoid hard dependency at module load."""
    try:
        import keyring
        import keyring.errors  # noqa: F401

        return keyring
    except ImportError:
        return None


def _service_name(instance_id: str) -> str:
    """Build keyring service name scoped to a BPA instance.

    Args:
        instance_id: Instance slug (e.g., "els-dev-a1b2c3").

    Returns:
        Keyring service name like "mcp-eregistrations-bpa/els-dev-a1b2c3".
    """
    return f"{KEYRING_SERVICE_PREFIX}/{instance_id}"


def store_credentials(instance_id: str, username: str, password: str) -> bool:
    """Store credentials in system keyring, scoped to instance.

    Args:
        instance_id: BPA instance slug.
        username: BPA username (email).
        password: BPA password.

    Returns:
        True if stored successfully, False if keyring unavailable.
    """
    kr = _get_keyring()
    if kr is None:
        logger.warning("keyring package not installed; credentials not stored")
        return False
    try:
        service = _service_name(instance_id)
        kr.set_password(service, "username", username)
        kr.set_password(service, "password", password)
        return True
    except Exception as e:
        # Clean up partial write (username stored but password failed)
        try:
            kr.delete_password(_service_name(instance_id), "username")
        except Exception:
            pass
        logger.warning("Cannot store credentials in keyring: %s", e)
        return False


def get_credentials(instance_id: str) -> tuple[str, str] | None:
    """Retrieve credentials from system keyring.

    Args:
        instance_id: BPA instance slug.

    Returns:
        (username, password) tuple, or None if not found or keyring unavailable.
    """
    kr = _get_keyring()
    if kr is None:
        return None
    try:
        service = _service_name(instance_id)
        username = kr.get_password(service, "username")
        password = kr.get_password(service, "password")
        if username and password:
            return (username, password)
        return None
    except Exception as e:
        logger.warning("Cannot read credentials from keyring: %s", e)
        return None


def delete_credentials(instance_id: str) -> None:
    """Remove stored credentials from keyring. Silently ignores missing entries.

    Args:
        instance_id: BPA instance slug.
    """
    kr = _get_keyring()
    if kr is None:
        return
    try:
        import keyring.errors

        service = _service_name(instance_id)
        try:
            kr.delete_password(service, "username")
        except keyring.errors.PasswordDeleteError:
            pass
        try:
            kr.delete_password(service, "password")
        except keyring.errors.PasswordDeleteError:
            pass
    except Exception as e:
        logger.warning("Cannot delete credentials from keyring: %s", e)
