"""Worker routes - reads worker data from Redis."""

import logging

from fastapi import APIRouter, HTTPException
from shared.contracts import WorkerInfo, WorkerInstance, WorkersListResponse

from server.services.registry import (
    get_worker_definitions,
    get_worker_instance,
    list_worker_instances,
)

logger = logging.getLogger(__name__)

worker_root_router = APIRouter(tags=["workers"])


@worker_root_router.get("", response_model=WorkersListResponse)
async def list_workers_route() -> WorkersListResponse:
    """List all workers with active instances, matching API pattern."""
    try:
        worker_defs = await get_worker_definitions()
        all_instances = await list_worker_instances()
    except RuntimeError:
        return WorkersListResponse(workers=[], total=0)

    # Group instances by worker_name
    instances_by_name: dict[str, list[WorkerInstance]] = {}
    for inst in all_instances:
        instances_by_name.setdefault(inst.worker_name, []).append(inst)

    workers: list[WorkerInfo] = []

    # Build from persistent definitions (always shown, even when inactive)
    for name, defn in worker_defs.items():
        instances = instances_by_name.pop(name, [])
        workers.append(
            WorkerInfo(
                name=name,
                active=bool(instances),
                instance_count=len(instances),
                instances=instances,
                functions=defn.functions,
                function_names=defn.function_names,
                concurrency=defn.concurrency,
            )
        )

    # Also include workers with live instances but no persistent definition yet
    for name, instances in instances_by_name.items():
        first = instances[0]
        workers.append(
            WorkerInfo(
                name=name,
                active=True,
                instance_count=len(instances),
                instances=instances,
                functions=first.functions,
                function_names=first.function_names,
                concurrency=first.concurrency,
            )
        )

    return WorkersListResponse(workers=workers, total=len(workers))


@worker_root_router.get("/{worker_id}", response_model=WorkerInstance)
async def get_worker_route(worker_id: str) -> WorkerInstance:
    """Get a specific worker instance by ID."""
    try:
        instance = await get_worker_instance(worker_id)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    if not instance:
        raise HTTPException(status_code=404, detail=f"Worker {worker_id} not found")

    return instance
