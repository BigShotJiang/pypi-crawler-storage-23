"""Health check routes."""

import asyncio
import logging
import time

from fastapi import APIRouter, Response, status
from shared.contracts import (
    DependencyHealth,
    EventProcessingStats,
    HealthMetrics,
    HealthResponse,
    QueueHealthSummary,
    ReadinessMetrics,
)

from server.config import get_settings
from server.backends import get_backend
from server.services.events import get_event_processing_stats
from server.services.jobs import get_queue_depth_stats
from server.services.operations import get_alert_delivery_stats
from server.services.redis import get_redis

logger = logging.getLogger(__name__)

router = APIRouter(tags=["health"])
_HEALTH_METRICS_CACHE_TTL_SECONDS = 5.0
_health_metrics_cache: (
    tuple[float, QueueHealthSummary, EventProcessingStats] | None
) = None
_health_metrics_lock = asyncio.Lock()


def clear_health_metrics_cache() -> None:
    """Clear cached operational health metrics (useful for tests)."""
    global _health_metrics_cache
    _health_metrics_cache = None


async def _check_database_readiness() -> DependencyHealth:
    try:
        db = get_backend()
    except RuntimeError as exc:
        return DependencyHealth(status="error", detail=str(exc))

    try:
        await db.check_readiness()
    except Exception as exc:  # pragma: no cover - defensive guard
        return DependencyHealth(
            status="error",
            detail=f"Backend readiness probe failed: {exc}",
        )

    return DependencyHealth(status="ok")


async def _check_redis_readiness(
    redis_url: str | None,
    *,
    required: bool,
) -> DependencyHealth:
    if not redis_url:
        if required:
            return DependencyHealth(
                status="error",
                detail="UPNEXT_REDIS_URL not set",
            )
        return DependencyHealth(
            status="skipped",
            detail="UPNEXT_REDIS_URL not set",
        )

    try:
        redis_client = await get_redis()
    except RuntimeError as exc:
        return DependencyHealth(status="error", detail=str(exc))

    try:
        pong = await redis_client.ping()  # type: ignore[misc]
    except Exception as exc:  # pragma: no cover - defensive guard
        return DependencyHealth(status="error", detail=f"Redis ping failed: {exc}")

    if pong is False:
        return DependencyHealth(status="error", detail="Redis ping returned false")

    return DependencyHealth(status="ok")


async def _get_queue_health() -> QueueHealthSummary:
    """Fetch queue depth stats for health response."""
    try:
        depth = await get_queue_depth_stats()
        return QueueHealthSummary(
            running=depth.running,
            waiting=depth.waiting,
            claimed=depth.claimed,
            backlog=depth.backlog,
            capacity=depth.capacity,
        )
    except Exception:
        return QueueHealthSummary()


async def _get_cached_operational_metrics() -> tuple[
    QueueHealthSummary,
    EventProcessingStats,
]:
    global _health_metrics_cache
    now = time.monotonic()
    cached = _health_metrics_cache
    if cached and cached[0] > now:
        return cached[1], cached[2]

    async with _health_metrics_lock:
        cached = _health_metrics_cache
        if cached and cached[0] > now:
            return cached[1], cached[2]

        queue_health = await _get_queue_health()
        event_stats = get_event_processing_stats()
        _health_metrics_cache = (
            now + _HEALTH_METRICS_CACHE_TTL_SECONDS,
            queue_health,
            event_stats,
        )
        return queue_health, event_stats


async def _build_health_response() -> tuple[HealthResponse, bool]:
    settings = get_settings()
    redis_required = bool(
        getattr(settings, "readiness_require_redis", False)
        or getattr(settings, "is_production", False)
    )
    db_readiness = await _check_database_readiness()
    redis_readiness = await _check_redis_readiness(
        settings.redis_url,
        required=redis_required,
    )
    readiness = ReadinessMetrics(
        database=db_readiness,
        redis=redis_readiness,
    )
    if redis_required:
        redis_ready = redis_readiness.status == "ok"
    else:
        redis_ready = redis_readiness.status in {"ok", "skipped"}
    ready = db_readiness.status == "ok" and redis_ready

    # Fetch operational metrics (best-effort, failures don't affect readiness).
    queue_health, event_stats = await _get_cached_operational_metrics()

    payload = HealthResponse(
        status="ok" if ready else "degraded",
        version=settings.version,
        features=[],
        metrics=HealthMetrics(
            alerts=get_alert_delivery_stats(),
            readiness=readiness,
            queue=queue_health,
            events=event_stats,
        ),
    )
    return payload, ready


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """
    Liveness endpoint with dependency status details.

    This endpoint always returns 200 when the API process is alive.
    See /ready for strict readiness signaling.
    """
    payload, _ = await _build_health_response()
    return payload


@router.get("/ready", response_model=HealthResponse)
async def readiness_check(response: Response) -> HealthResponse:
    """Readiness endpoint for load balancers and traffic gating."""
    payload, ready = await _build_health_response()
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return payload
