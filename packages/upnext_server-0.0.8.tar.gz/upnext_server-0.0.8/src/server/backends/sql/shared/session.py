"""Database session management for UpNext."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from sqlalchemy import inspect
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from server.backends.sql.shared.tables import Base

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from sqlalchemy.ext.asyncio import AsyncEngine


class Database:
    """
    Async database connection manager.

    Example:
        db = Database(url="postgresql+asyncpg://user:pass@localhost/upnext")
        await db.connect()

        async with db.session() as session:
            result = await session.execute(select(JobHistoryTable))
            jobs = result.scalars().all()

        await db.disconnect()
    """

    def __init__(
        self,
        url: str,
        *,
        echo: bool = False,
        pool_size: int = 5,
        max_overflow: int = 10,
    ) -> None:
        """
        Initialize database connection.

        Args:
            url: Database URL (postgresql+asyncpg:// or sqlite+aiosqlite://)
            echo: Enable SQL logging
            pool_size: Connection pool size (ignored for SQLite)
            max_overflow: Max connections above pool_size (ignored for SQLite)
        """
        self._url = url
        self._echo = echo
        self._pool_size = pool_size
        self._max_overflow = max_overflow
        self._is_sqlite = url.startswith("sqlite")

        self._engine: AsyncEngine | None = None
        self._session_factory: async_sessionmaker[AsyncSession] | None = None

    @property
    def engine(self) -> AsyncEngine:
        """Get the database engine."""
        if self._engine is None:
            raise RuntimeError("Database not connected. Call connect() first.")
        return self._engine

    async def connect(self) -> None:
        """Establish database connection and create tables."""
        if self._is_sqlite:
            # SQLite doesn't support connection pooling
            self._engine = create_async_engine(
                self._url,
                echo=self._echo,
            )
        else:
            self._engine = create_async_engine(
                self._url,
                echo=self._echo,
                pool_size=self._pool_size,
                max_overflow=self._max_overflow,
            )

        self._session_factory = async_sessionmaker(
            bind=self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def disconnect(self) -> None:
        """Close database connection."""
        if self._engine:
            await self._engine.dispose()
            self._engine = None
            self._session_factory = None

    async def create_tables(self) -> None:
        """Create all tables (for development/testing)."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def drop_tables(self) -> None:
        """Drop all tables (for testing)."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)

    async def get_missing_tables(self, required_tables: set[str]) -> list[str]:
        """Return required table names that are missing from the current schema."""
        async with self.engine.connect() as conn:
            missing = await conn.run_sync(
                lambda sync_conn: sorted(
                    required_tables - set(inspect(sync_conn).get_table_names())
                )
            )
        return list(missing)

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        """
        Get a database session.

        Example:
            async with db.session() as session:
                session.add(job)
                await session.commit()
        """
        if self._session_factory is None:
            raise RuntimeError("Database not connected. Call connect() first.")

        session = self._session_factory()
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
