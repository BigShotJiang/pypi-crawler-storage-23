"""Tests for Knowledge Tree data models."""

import pytest
from pathlib import Path

from knowledge_tree._yaml_helpers import load_yaml, save_yaml
from knowledge_tree.models import (
    PACKAGE_NAME_RE,
    PackageMetadata,
    Registry,
    RegistryEntry,
    InstalledPackage,
    ProjectConfig,
    _levenshtein,
)


# ---------------------------------------------------------------------------
# _levenshtein
# ---------------------------------------------------------------------------


class TestLevenshtein:
    def test_identical_strings(self):
        assert _levenshtein("abc", "abc") == 0

    def test_empty_strings(self):
        assert _levenshtein("", "") == 0

    def test_one_empty(self):
        assert _levenshtein("abc", "") == 3
        assert _levenshtein("", "abc") == 3

    def test_single_edit(self):
        assert _levenshtein("cat", "bat") == 1  # substitution
        assert _levenshtein("cat", "cats") == 1  # insertion
        assert _levenshtein("cats", "cat") == 1  # deletion

    def test_multiple_edits(self):
        assert _levenshtein("kitten", "sitting") == 3


# ---------------------------------------------------------------------------
# PACKAGE_NAME_RE
# ---------------------------------------------------------------------------


class TestPackageNameRegex:
    @pytest.mark.parametrize(
        "name",
        ["base", "git-conventions", "cloud-aws-lambda", "a1", "abc-123"],
    )
    def test_valid_names(self, name):
        assert PACKAGE_NAME_RE.match(name)

    @pytest.mark.parametrize(
        "name",
        [
            "",
            "Base",  # uppercase
            "1abc",  # starts with digit
            "-abc",  # starts with hyphen
            "abc-",  # ends with hyphen
            "abc--def",  # double hyphen
            "abc_def",  # underscore
            "abc def",  # space
            "abc.def",  # dot
        ],
    )
    def test_invalid_names(self, name):
        assert not PACKAGE_NAME_RE.match(name)


# ---------------------------------------------------------------------------
# PackageMetadata
# ---------------------------------------------------------------------------


class TestPackageMetadata:
    def _valid_meta(self, **overrides) -> PackageMetadata:
        defaults = dict(
            name="test-pkg",
            description="A test package",
            authors=["Alice"],
            classification="evergreen",
        )
        defaults.update(overrides)
        return PackageMetadata(**defaults)

    def test_valid_package_no_errors(self):
        meta = self._valid_meta()
        assert meta.validate() == []

    def test_missing_name(self):
        meta = self._valid_meta(name="")
        errors = meta.validate()
        assert any("'name' is required" in e for e in errors)

    def test_invalid_name(self):
        meta = self._valid_meta(name="Invalid-Name")
        errors = meta.validate()
        assert any("Invalid package name" in e for e in errors)

    def test_missing_description(self):
        meta = self._valid_meta(description="")
        errors = meta.validate()
        assert any("'description' is required" in e for e in errors)

    def test_missing_authors(self):
        meta = self._valid_meta(authors=[])
        errors = meta.validate()
        assert any("author" in e.lower() for e in errors)

    def test_missing_classification(self):
        meta = self._valid_meta(classification="")
        errors = meta.validate()
        assert any("'classification' is required" in e for e in errors)

    def test_invalid_classification(self):
        meta = self._valid_meta(classification="bogus")
        errors = meta.validate()
        assert any("Invalid classification" in e for e in errors)

    def test_seasonal_classification_valid(self):
        meta = self._valid_meta(classification="seasonal")
        assert meta.validate() == []

    def test_valid_status(self):
        for status in ["pending", "promoted", "archived"]:
            meta = self._valid_meta(status=status)
            assert meta.validate() == []

    def test_invalid_status(self):
        meta = self._valid_meta(status="bogus")
        errors = meta.validate()
        assert any("Invalid status" in e for e in errors)

    def test_none_status_is_valid(self):
        meta = self._valid_meta(status=None)
        assert meta.validate() == []

    def test_yaml_round_trip(self, tmp_path):
        path = tmp_path / "package.yaml"
        meta = self._valid_meta(
            tags=["testing", "core"],
            depends_on=["base"],
            parent="root",
            created="2026-01-01",
            updated="2026-02-01",
            status="pending",
            promoted_to="main-pkg",
            promoted_date="2026-03-01",
        )
        meta.to_yaml_file(path)
        loaded = PackageMetadata.from_yaml_file(path)

        assert loaded.name == meta.name
        assert loaded.description == meta.description
        assert loaded.authors == meta.authors
        assert loaded.classification == meta.classification
        assert loaded.tags == meta.tags
        assert loaded.depends_on == meta.depends_on
        assert loaded.parent == meta.parent
        assert loaded.created == meta.created
        assert loaded.updated == meta.updated
        assert loaded.status == meta.status
        assert loaded.promoted_to == meta.promoted_to
        assert loaded.promoted_date == meta.promoted_date

    def test_yaml_omits_none_and_empty(self, tmp_path):
        path = tmp_path / "package.yaml"
        meta = self._valid_meta()
        meta.to_yaml_file(path)
        data = load_yaml(path)

        # These should be present
        assert "name" in data
        assert "description" in data

        # These should be absent (None or empty list)
        assert "parent" not in data
        assert "depends_on" not in data
        assert "suggests" not in data
        assert "tags" not in data
        assert "status" not in data
        assert "promoted_to" not in data

    def test_from_yaml_handles_missing_keys(self, tmp_path):
        path = tmp_path / "package.yaml"
        save_yaml({"name": "minimal"}, path)
        meta = PackageMetadata.from_yaml_file(path)
        assert meta.name == "minimal"
        assert meta.description == ""
        assert meta.authors == []
        assert meta.classification == ""
        assert meta.parent is None
        assert meta.depends_on == []
        assert meta.status is None

    def test_multiple_validation_errors(self):
        meta = PackageMetadata()  # all defaults = all empty
        errors = meta.validate()
        assert len(errors) >= 3  # name, description, authors, classification


# ---------------------------------------------------------------------------
# RegistryEntry
# ---------------------------------------------------------------------------


class TestRegistryEntry:
    def test_defaults(self):
        entry = RegistryEntry()
        assert entry.description == ""
        assert entry.classification == ""
        assert entry.tags == []
        assert entry.path == ""
        assert entry.parent is None
        assert entry.depends_on == []


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def _sample_registry() -> Registry:
    """Build a small in-memory registry for testing."""
    return Registry(
        packages={
            "base": RegistryEntry(
                description="Universal coding conventions",
                classification="evergreen",
                tags=["core", "conventions"],
                path="packages/base",
            ),
            "git-conventions": RegistryEntry(
                description="Git commit message standards",
                classification="evergreen",
                tags=["git", "conventions"],
                path="packages/git-conventions",
                parent="base",
            ),
            "api-patterns": RegistryEntry(
                description="REST API patterns and auth",
                classification="seasonal",
                tags=["api", "rest"],
                path="packages/api-patterns",
                depends_on=["base"],
            ),
        }
    )


class TestRegistry:
    def test_yaml_round_trip(self, tmp_path):
        path = tmp_path / "registry.yaml"
        reg = _sample_registry()
        reg.to_yaml_file(path)
        loaded = Registry.from_yaml_file(path)

        assert set(loaded.packages.keys()) == {"base", "git-conventions", "api-patterns"}
        assert loaded.packages["base"].description == "Universal coding conventions"
        assert loaded.packages["api-patterns"].depends_on == ["base"]
        assert loaded.packages["git-conventions"].parent == "base"

    def test_search_exact_name(self):
        reg = _sample_registry()
        results = reg.search("base")
        assert results[0][0] == "base"

    def test_search_name_contains(self):
        reg = _sample_registry()
        results = reg.search("git")
        names = [name for name, _ in results]
        assert "git-conventions" in names

    def test_search_description(self):
        reg = _sample_registry()
        results = reg.search("REST")
        names = [name for name, _ in results]
        assert "api-patterns" in names

    def test_search_tag(self):
        reg = _sample_registry()
        results = reg.search("core")
        names = [name for name, _ in results]
        assert "base" in names

    def test_search_no_results(self):
        reg = _sample_registry()
        results = reg.search("nonexistent-xyz")
        assert results == []

    def test_search_relevance_order(self):
        reg = _sample_registry()
        # "conventions" appears in tags and descriptions
        results = reg.search("conventions")
        names = [name for name, _ in results]
        # Both should be found
        assert "base" in names
        assert "git-conventions" in names

    def test_get_children(self):
        reg = _sample_registry()
        children = reg.get_children("base")
        assert children == ["git-conventions"]

    def test_get_children_none(self):
        reg = _sample_registry()
        children = reg.get_children("api-patterns")
        assert children == []

    def test_resolve_dependency_chain_no_deps(self):
        reg = _sample_registry()
        chain = reg.resolve_dependency_chain("base")
        assert chain == ["base"]

    def test_resolve_dependency_chain_simple(self):
        reg = _sample_registry()
        chain = reg.resolve_dependency_chain("api-patterns")
        assert chain == ["base", "api-patterns"]

    def test_resolve_dependency_chain_transitive(self):
        reg = _sample_registry()
        # Add a package that depends on api-patterns (which depends on base)
        reg.packages["advanced-api"] = RegistryEntry(
            description="Advanced API patterns",
            classification="seasonal",
            depends_on=["api-patterns"],
        )
        chain = reg.resolve_dependency_chain("advanced-api")
        assert chain == ["base", "api-patterns", "advanced-api"]

    def test_resolve_dependency_chain_circular(self):
        reg = Registry(
            packages={
                "a": RegistryEntry(depends_on=["b"]),
                "b": RegistryEntry(depends_on=["a"]),
            }
        )
        with pytest.raises(ValueError, match="Circular dependency"):
            reg.resolve_dependency_chain("a")

    def test_resolve_dependency_chain_missing_package(self):
        reg = _sample_registry()
        with pytest.raises(ValueError, match="not found"):
            reg.resolve_dependency_chain("nonexistent")

    def test_resolve_dependency_chain_missing_dep(self):
        reg = Registry(
            packages={
                "a": RegistryEntry(depends_on=["missing"]),
            }
        )
        with pytest.raises(ValueError, match="not found"):
            reg.resolve_dependency_chain("a")

    def test_resolve_missing_with_suggestion(self):
        reg = _sample_registry()
        with pytest.raises(ValueError, match="Did you mean"):
            reg.resolve_dependency_chain("bse")  # close to "base"

    def test_find_similar_names(self):
        reg = _sample_registry()
        similar = reg.find_similar_names("bse")
        assert "base" in similar

    def test_find_similar_names_no_match(self):
        reg = _sample_registry()
        similar = reg.find_similar_names("zzzzzzzzz")
        assert similar == []

    def test_rebuild_from_packages(self, tmp_path):
        # Create a mini packages directory with one package
        pkg_dir = tmp_path / "packages" / "test-pkg"
        pkg_dir.mkdir(parents=True)
        meta = PackageMetadata(
            name="test-pkg",
            description="A test",
            authors=["Bob"],
            classification="evergreen",
            tags=["testing"],
            parent=None,
            depends_on=["base"],
        )
        meta.to_yaml_file(pkg_dir / "package.yaml")

        reg = Registry()
        reg.rebuild_from_packages(tmp_path / "packages")

        assert "test-pkg" in reg.packages
        entry = reg.packages["test-pkg"]
        assert entry.description == "A test"
        assert entry.classification == "evergreen"
        assert entry.tags == ["testing"]
        assert entry.path == "packages/test-pkg"
        assert entry.depends_on == ["base"]

    def test_rebuild_skips_non_directories(self, tmp_path):
        pkg_dir = tmp_path / "packages"
        pkg_dir.mkdir()
        (pkg_dir / "random-file.txt").write_text("not a package")

        reg = Registry()
        reg.rebuild_from_packages(pkg_dir)
        assert len(reg.packages) == 0

    def test_rebuild_skips_dirs_without_yaml(self, tmp_path):
        pkg_dir = tmp_path / "packages" / "no-yaml"
        pkg_dir.mkdir(parents=True)

        reg = Registry()
        reg.rebuild_from_packages(tmp_path / "packages")
        assert len(reg.packages) == 0

    def test_rebuild_nonexistent_dir(self, tmp_path):
        reg = Registry()
        reg.rebuild_from_packages(tmp_path / "nonexistent")
        assert len(reg.packages) == 0

    def test_from_yaml_skips_non_dict_entries(self, tmp_path):
        path = tmp_path / "registry.yaml"
        save_yaml(
            {"packages": {"good": {"description": "ok"}, "bad": "not-a-dict"}},
            path,
        )
        reg = Registry.from_yaml_file(path)
        assert "good" in reg.packages
        assert "bad" not in reg.packages


# ---------------------------------------------------------------------------
# InstalledPackage
# ---------------------------------------------------------------------------


class TestInstalledPackage:
    def test_defaults(self):
        pkg = InstalledPackage()
        assert pkg.name == ""
        assert pkg.ref == ""

    def test_fields(self):
        pkg = InstalledPackage(name="base", ref="abc1234")
        assert pkg.name == "base"
        assert pkg.ref == "abc1234"


# ---------------------------------------------------------------------------
# ProjectConfig
# ---------------------------------------------------------------------------


class TestProjectConfig:
    def test_yaml_round_trip(self, tmp_path):
        path = tmp_path / "kt.yaml"
        config = ProjectConfig(
            registry="https://example.com/registry.git",
            registry_ref="v1",
            packages=[
                InstalledPackage(name="base", ref="abc1234"),
                InstalledPackage(name="api-patterns", ref="def5678"),
            ],
            telemetry_enabled=True,
            telemetry_anonymous_id="test123",
        )
        config.to_yaml_file(path)
        loaded = ProjectConfig.from_yaml_file(path)

        assert loaded.registry == config.registry
        assert loaded.registry_ref == config.registry_ref
        assert len(loaded.packages) == 2
        assert loaded.packages[0].name == "base"
        assert loaded.packages[0].ref == "abc1234"
        assert loaded.packages[1].name == "api-patterns"
        assert loaded.telemetry_enabled is True
        assert loaded.telemetry_anonymous_id == "test123"

    def test_defaults(self):
        config = ProjectConfig()
        assert config.registry == ""
        assert config.registry_ref == "main"
        assert config.packages == []
        assert config.telemetry_enabled is False

    def test_add_package_new(self):
        config = ProjectConfig()
        config.add_package("base", "abc1234")
        assert len(config.packages) == 1
        assert config.packages[0].name == "base"
        assert config.packages[0].ref == "abc1234"

    def test_add_package_update_existing(self):
        config = ProjectConfig(
            packages=[InstalledPackage(name="base", ref="old")]
        )
        config.add_package("base", "new")
        assert len(config.packages) == 1
        assert config.packages[0].ref == "new"

    def test_remove_package_exists(self):
        config = ProjectConfig(
            packages=[InstalledPackage(name="base", ref="abc")]
        )
        result = config.remove_package("base")
        assert result is True
        assert len(config.packages) == 0

    def test_remove_package_not_found(self):
        config = ProjectConfig()
        result = config.remove_package("nonexistent")
        assert result is False

    def test_get_installed_names(self):
        config = ProjectConfig(
            packages=[
                InstalledPackage(name="base", ref="a"),
                InstalledPackage(name="api-patterns", ref="b"),
            ]
        )
        names = config.get_installed_names()
        assert names == {"base", "api-patterns"}

    def test_get_installed_names_empty(self):
        config = ProjectConfig()
        assert config.get_installed_names() == set()

    def test_get_package_ref_found(self):
        config = ProjectConfig(
            packages=[InstalledPackage(name="base", ref="abc1234")]
        )
        assert config.get_package_ref("base") == "abc1234"

    def test_get_package_ref_not_found(self):
        config = ProjectConfig()
        assert config.get_package_ref("nonexistent") is None

    def test_from_yaml_handles_missing_keys(self, tmp_path):
        path = tmp_path / "kt.yaml"
        save_yaml({}, path)
        config = ProjectConfig.from_yaml_file(path)
        assert config.registry == ""
        assert config.registry_ref == "main"
        assert config.packages == []
        assert config.telemetry_enabled is False


# ---------------------------------------------------------------------------
# _yaml_helpers
# ---------------------------------------------------------------------------


class TestYamlHelpers:
    def test_load_empty_file(self, tmp_path):
        path = tmp_path / "empty.yaml"
        path.write_text("")
        data = load_yaml(path)
        assert data == {}

    def test_save_creates_parent_dirs(self, tmp_path):
        path = tmp_path / "deep" / "nested" / "file.yaml"
        save_yaml({"key": "value"}, path)
        assert path.exists()
        data = load_yaml(path)
        assert data["key"] == "value"

    def test_round_trip_preserves_types(self, tmp_path):
        path = tmp_path / "types.yaml"
        original = {
            "string": "hello",
            "number": 42,
            "boolean": True,
            "list": [1, 2, 3],
            "nested": {"a": "b"},
        }
        save_yaml(original, path)
        loaded = load_yaml(path)
        assert loaded["string"] == "hello"
        assert loaded["number"] == 42
        assert loaded["boolean"] is True
        assert loaded["list"] == [1, 2, 3]
        assert loaded["nested"]["a"] == "b"
