"""Tests for Knowledge Tree engine."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from knowledge_tree.engine import KnowledgeTreeEngine


def _run_git(args: list[str], cwd: Path) -> str:
    result = subprocess.run(
        ["git"] + args, cwd=cwd, capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {result.stderr}")
    return result.stdout.strip()


@pytest.fixture
def project_dir(tmp_path: Path) -> Path:
    """Return a clean project directory."""
    project = tmp_path / "my-project"
    project.mkdir()
    return project


@pytest.fixture
def initialized_project(
    registry_repo: tuple[Path, Path],
    tmp_path: Path,
) -> tuple[KnowledgeTreeEngine, Path]:
    """Return an initialized engine + project dir.

    Uses the registry_repo fixture from conftest.py.
    """
    bare, _ = registry_repo
    project = tmp_path / "my-project"
    project.mkdir()
    engine = KnowledgeTreeEngine(project)
    engine.init(str(bare), branch="main")
    return engine, project


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


class TestInit:
    def test_creates_directories(
        self, registry_repo: tuple[Path, Path], project_dir: Path
    ):
        bare, _ = registry_repo
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(bare), branch="main")

        assert (project_dir / ".kt").is_dir()
        assert (project_dir / ".knowledge").is_dir()
        assert (project_dir / ".kt" / "kt.yaml").exists()

    def test_clones_registry(
        self, registry_repo: tuple[Path, Path], project_dir: Path
    ):
        bare, _ = registry_repo
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(bare), branch="main")

        cache = project_dir / ".kt" / "registry_cache"
        assert cache.is_dir()
        assert (cache / "registry.yaml").exists()

    def test_returns_available_packages(
        self, registry_repo: tuple[Path, Path], project_dir: Path
    ):
        bare, _ = registry_repo
        engine = KnowledgeTreeEngine(project_dir)
        packages = engine.init(str(bare), branch="main")

        assert "base" in packages
        assert "git-conventions" in packages
        assert "api-patterns" in packages

    def test_saves_config(
        self, registry_repo: tuple[Path, Path], project_dir: Path
    ):
        bare, _ = registry_repo
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(bare), branch="main")

        from knowledge_tree.models import ProjectConfig

        config = ProjectConfig.from_yaml_file(project_dir / ".kt" / "kt.yaml")
        assert config.registry == str(bare)
        assert config.registry_ref == "main"
        assert config.telemetry_anonymous_id != ""

    def test_already_initialized_error(
        self, registry_repo: tuple[Path, Path], project_dir: Path
    ):
        bare, _ = registry_repo
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(bare), branch="main")

        with pytest.raises(FileExistsError, match="Already initialized"):
            engine.init(str(bare), branch="main")


# ---------------------------------------------------------------------------
# add_package
# ---------------------------------------------------------------------------


class TestAddPackage:
    def test_add_single_package(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        result = engine.add_package("base")

        assert "base" in result["installed"]
        assert (project / ".knowledge" / "base").is_dir()
        # Check a content file was copied
        assert (project / ".knowledge" / "base" / "safe-deletion.md").exists()

    def test_add_with_dependency(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        result = engine.add_package("api-patterns")

        # base is a dependency of api-patterns
        assert "base" in result["installed"]
        assert "api-patterns" in result["installed"]
        assert (project / ".knowledge" / "base").is_dir()
        assert (project / ".knowledge" / "api-patterns").is_dir()

    def test_add_with_explicit_content_list(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("api-patterns")

        # api-patterns has explicit content list
        api_dir = project / ".knowledge" / "api-patterns"
        assert (api_dir / "rest-conventions.md").exists()
        assert (api_dir / "authentication.md").exists()

    def test_add_already_installed(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")
        result = engine.add_package("base")

        assert result["installed"] == []
        assert "base" in result["already_installed"]

    def test_add_nonexistent_with_suggestion(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        with pytest.raises(ValueError, match="Did you mean"):
            engine.add_package("bse")  # close to "base"

    def test_add_nonexistent_no_match(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        with pytest.raises(ValueError, match="not found"):
            engine.add_package("zzzzzzz")

    def test_dependency_not_duplicated(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")
        result = engine.add_package("api-patterns")

        assert "base" not in result["installed"]
        assert "base" in result["already_installed"]
        assert "api-patterns" in result["installed"]

    def test_manifest_generated_on_add(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("base")

        manifest = project / ".knowledge" / "KNOWLEDGE_MANIFEST.md"
        assert manifest.exists()
        content = manifest.read_text()
        assert "base" in content
        assert "Knowledge Manifest" in content


# ---------------------------------------------------------------------------
# remove_package
# ---------------------------------------------------------------------------


class TestRemovePackage:
    def test_remove_package(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("base")
        result = engine.remove_package("base")

        assert result["removed"] is True
        assert not (project / ".knowledge" / "base").exists()

    def test_remove_nonexistent(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        with pytest.raises(ValueError, match="not installed"):
            engine.remove_package("nonexistent")

    def test_remove_warns_if_depended_on(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("api-patterns")  # installs base + api-patterns
        result = engine.remove_package("base")

        assert result["removed"] is True
        assert "api-patterns" in result["dependents"]

    def test_manifest_updated_on_remove(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("base")
        engine.add_package("git-conventions")
        engine.remove_package("base")

        manifest = project / ".knowledge" / "KNOWLEDGE_MANIFEST.md"
        content = manifest.read_text()
        assert "git-conventions" in content

    def test_manifest_removed_when_empty(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("base")
        engine.remove_package("base")

        manifest = project / ".knowledge" / "KNOWLEDGE_MANIFEST.md"
        assert not manifest.exists()


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


class TestUpdate:
    def test_update_pulls_changes(
        self,
        registry_repo: tuple[Path, Path],
        tmp_path: Path,
    ):
        bare, work = registry_repo
        project = tmp_path / "my-project"
        project.mkdir()
        engine = KnowledgeTreeEngine(project)
        engine.init(str(bare), branch="main")
        engine.add_package("base")

        # Push a change to the registry
        new_file = work / "packages" / "base" / "new-content.md"
        new_file.write_text("# New Content\nNew stuff.\n")
        _run_git(["add", "."], cwd=work)
        _run_git(["commit", "-m", "Add new content"], cwd=work)
        _run_git(["push", "origin", "main"], cwd=work)

        result = engine.update()

        assert "base" in result["updated_packages"]
        # The new file should now be materialized
        assert (project / ".knowledge" / "base" / "new-content.md").exists()

    def test_update_detects_new_evergreen(
        self,
        registry_repo: tuple[Path, Path],
        tmp_path: Path,
    ):
        bare, work = registry_repo
        project = tmp_path / "my-project"
        project.mkdir()
        engine = KnowledgeTreeEngine(project)
        engine.init(str(bare), branch="main")
        engine.add_package("base")  # install only base

        # git-conventions is evergreen and not installed
        result = engine.update()
        assert "git-conventions" in result["new_evergreen"]


# ---------------------------------------------------------------------------
# list_packages
# ---------------------------------------------------------------------------


class TestListPackages:
    def test_list_installed(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")

        results = engine.list_packages(available=False)
        names = [r["name"] for r in results]
        assert "base" in names
        assert all(r["installed"] for r in results)

    def test_list_available(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")

        results = engine.list_packages(available=True)
        names = [r["name"] for r in results]
        assert "base" not in names
        assert "api-patterns" in names
        assert "git-conventions" in names


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


class TestSearch:
    def test_search_by_name(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        results = engine.search("base")
        names = [r["name"] for r in results]
        assert "base" in names

    def test_search_by_tag(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        results = engine.search("api")
        names = [r["name"] for r in results]
        assert "api-patterns" in names

    def test_search_no_results(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        results = engine.search("nonexistent-xyz")
        assert results == []

    def test_search_annotates_installed(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")
        results = engine.search("base")
        base_result = next(r for r in results if r["name"] == "base")
        assert base_result["installed"] is True


# ---------------------------------------------------------------------------
# get_tree_data
# ---------------------------------------------------------------------------


class TestGetTreeData:
    def test_tree_structure(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        data = engine.get_tree_data()

        root_names = [n["name"] for n in data["roots"]]
        # base and api-patterns are roots, git-conventions is child of base
        assert "base" in root_names
        assert "api-patterns" in root_names
        assert "git-conventions" not in root_names

        base_node = next(n for n in data["roots"] if n["name"] == "base")
        child_names = [c["name"] for c in base_node["children"]]
        assert "git-conventions" in child_names


# ---------------------------------------------------------------------------
# get_status
# ---------------------------------------------------------------------------


class TestGetStatus:
    def test_status_counts(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")

        status = engine.get_status()
        assert status["installed_count"] == 1
        assert status["available_count"] == 2  # git-conventions + api-patterns
        assert status["total_files"] > 0
        assert status["total_lines"] > 0


# ---------------------------------------------------------------------------
# get_info
# ---------------------------------------------------------------------------


class TestGetInfo:
    def test_info_installed(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        engine.add_package("base")
        info = engine.get_info("base")

        assert info["name"] == "base"
        assert info["installed"] is True
        assert len(info["files"]) > 0
        assert info["children"] == ["git-conventions"]

    def test_info_not_installed(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        info = engine.get_info("base")

        assert info["name"] == "base"
        assert info["installed"] is False
        assert info["files"] == []

    def test_info_nonexistent(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        with pytest.raises(ValueError, match="not found"):
            engine.get_info("nonexistent")

    def test_info_with_suggestion(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        with pytest.raises(ValueError, match="Did you mean"):
            engine.get_info("bse")


# ---------------------------------------------------------------------------
# validate_package
# ---------------------------------------------------------------------------


class TestValidatePackage:
    def test_valid_package(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, _ = initialized_project
        pkg_path = engine.cache_dir / "packages" / "base"
        result = engine.validate_package(pkg_path)

        assert result["valid"] is True
        assert result["errors"] == []

    def test_invalid_package_missing_yaml(self, tmp_path: Path):
        engine = KnowledgeTreeEngine(tmp_path)
        pkg_path = tmp_path / "bad-pkg"
        pkg_path.mkdir()

        result = engine.validate_package(pkg_path)
        assert result["valid"] is False
        assert any("Missing package.yaml" in e for e in result["errors"])

    def test_invalid_package_missing_content_file(self, tmp_path: Path):
        engine = KnowledgeTreeEngine(tmp_path)
        pkg_path = tmp_path / "bad-pkg"
        pkg_path.mkdir()

        from knowledge_tree.models import PackageMetadata

        meta = PackageMetadata(
            name="bad-pkg",
            description="Test",
            authors=["Test"],
            classification="evergreen",
            content=["missing-file.md"],
        )
        meta.to_yaml_file(pkg_path / "package.yaml")

        result = engine.validate_package(pkg_path)
        assert result["valid"] is False
        assert any("not found" in e for e in result["errors"])


# ---------------------------------------------------------------------------
# manifest generation
# ---------------------------------------------------------------------------


class TestManifest:
    def test_manifest_format(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("base")
        engine.add_package("git-conventions")

        content = (project / ".knowledge" / "KNOWLEDGE_MANIFEST.md").read_text()
        assert "# Knowledge Manifest" in content
        assert "## base" in content
        assert "### git-conventions" in content  # child of base
        assert "safe-deletion.md" in content

    def test_manifest_with_dependencies(
        self, initialized_project: tuple[KnowledgeTreeEngine, Path]
    ):
        engine, project = initialized_project
        engine.add_package("api-patterns")

        content = (project / ".knowledge" / "KNOWLEDGE_MANIFEST.md").read_text()
        assert "base" in content
        assert "api-patterns" in content


# ---------------------------------------------------------------------------
# registry_rebuild
# ---------------------------------------------------------------------------


class TestRegistryRebuild:
    def test_rebuild(
        self, registry_repo: tuple[Path, Path]
    ):
        _, work = registry_repo
        engine = KnowledgeTreeEngine(work)
        count = engine.registry_rebuild(work)

        assert count == 3  # base, git-conventions, api-patterns
        assert (work / "registry.yaml").exists()
