"""Knowledge Tree - Crowdsourced knowledge management for AI agent context."""

__version__ = "0.1.1"
