"""CLI interface for Knowledge Tree."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

from knowledge_tree.engine import KnowledgeTreeEngine

console = Console()
err_console = Console(stderr=True)


def _get_engine() -> KnowledgeTreeEngine:
    return KnowledgeTreeEngine(Path.cwd())


def _handle_error(func):
    """Decorator for common error handling across commands."""

    @click.pass_context
    def wrapper(ctx, *args, **kwargs):
        try:
            return ctx.invoke(func, *args, **kwargs)
        except FileNotFoundError as e:
            err_console.print(f"[red]{e}[/red]")
            raise SystemExit(1)
        except FileExistsError as e:
            err_console.print(f"[yellow]{e}[/yellow]")
            raise SystemExit(1)
        except ValueError as e:
            err_console.print(f"[red]{e}[/red]")
            raise SystemExit(1)
        except RuntimeError as e:
            err_console.print(f"[red]Error: {e}[/red]")
            err_console.print(
                "[dim]Check your network connection and git configuration.[/dim]"
            )
            raise SystemExit(1)

    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


def _classification_icon(classification: str) -> str:
    if classification == "evergreen":
        return "\U0001f332"  # evergreen tree
    elif classification == "seasonal":
        return "\U0001f342"  # fallen leaf
    return ""


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group()
@click.version_option()
def cli():
    """Knowledge Tree - Crowdsourced knowledge management for AI agent context."""
    pass


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--from", "registry_url", required=True, help="Registry git URL.")
@click.option("--branch", default="main", help="Registry branch.")
@_handle_error
def init(registry_url: str, branch: str):
    """Initialize a Knowledge Tree project."""
    engine = _get_engine()
    packages = engine.init(registry_url, branch=branch)

    console.print("[green]Initialized Knowledge Tree.[/green]")
    console.print(f"  Registry: {registry_url}")
    console.print(f"  Branch: {branch}")
    console.print(f"  Available packages: {len(packages)}")
    console.print()
    console.print("Run [bold]kt add <package>[/bold] to install a package.")


# ---------------------------------------------------------------------------
# add
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("package")
@_handle_error
def add(package: str):
    """Install a knowledge package and its dependencies."""
    engine = _get_engine()

    with console.status(f"Installing {package}..."):
        result = engine.add_package(package)

    if result["installed"]:
        for name in result["installed"]:
            console.print(f"  [green]+[/green] {name}")
    if result["already_installed"]:
        for name in result["already_installed"]:
            console.print(f"  [dim]  {name} (already installed)[/dim]")

    total = len(result["installed"])
    if total:
        console.print(
            f"\n[green]Installed {total} package{'s' if total > 1 else ''}.[/green]"
        )
    else:
        console.print("[dim]Nothing new to install.[/dim]")


# ---------------------------------------------------------------------------
# remove
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("package")
@_handle_error
def remove(package: str):
    """Remove an installed knowledge package."""
    engine = _get_engine()
    result = engine.remove_package(package)

    console.print(f"  [red]-[/red] {package}")

    if result["dependents"]:
        console.print(
            f"\n[yellow]Warning:[/yellow] The following installed packages "
            f"depend on [bold]{package}[/bold]:"
        )
        for dep in result["dependents"]:
            console.print(f"  - {dep}")
        console.print("[dim]Consider removing them or re-adding this package.[/dim]")

    console.print(f"\n[green]Removed {package}.[/green]")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
@click.option("--available", is_flag=True, help="Show available (not installed) packages.")
@click.option("--community", is_flag=True, help="Show community packages.")
@_handle_error
def list_cmd(available: bool, community: bool):
    """List knowledge packages."""
    engine = _get_engine()
    results = engine.list_packages(available=available, community=community)

    if not results:
        if available:
            console.print("[dim]All packages are installed.[/dim]")
        elif community:
            console.print("[dim]No community packages found.[/dim]")
        else:
            console.print("[dim]No packages installed. Run [bold]kt add <package>[/bold].[/dim]")
        return

    title = "Community Packages" if community else (
        "Available Packages" if available else "Installed Packages"
    )
    table = Table(title=title)
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Type")
    table.add_column("Tags", style="dim")

    if not available and not community:
        table.add_column("Ref", style="dim")

    for pkg in results:
        icon = _classification_icon(pkg["classification"])
        row = [
            pkg["name"],
            pkg["description"],
            f"{icon} {pkg['classification']}",
            ", ".join(pkg.get("tags", [])),
        ]
        if not available and not community:
            row.append(pkg.get("ref", ""))
        table.add_row(*row)

    console.print(table)


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("query")
@_handle_error
def search(query: str):
    """Search for knowledge packages."""
    engine = _get_engine()
    results = engine.search(query)

    if not results:
        console.print(f"[dim]No packages match '{query}'.[/dim]")
        return

    table = Table(title=f"Search: {query}")
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Type")
    table.add_column("Tags", style="dim")
    table.add_column("Installed")

    for pkg in results:
        icon = _classification_icon(pkg["classification"])
        installed = "[green]yes[/green]" if pkg["installed"] else "[dim]no[/dim]"
        table.add_row(
            pkg["name"],
            pkg["description"],
            f"{icon} {pkg['classification']}",
            ", ".join(pkg.get("tags", [])),
            installed,
        )

    console.print(table)


# ---------------------------------------------------------------------------
# tree
# ---------------------------------------------------------------------------


@cli.command()
@_handle_error
def tree():
    """Show the knowledge package tree."""
    engine = _get_engine()
    data = engine.get_tree_data()

    rich_tree = Tree("\U0001f333 Knowledge Tree")

    def _add_nodes(parent_tree, nodes):
        for node in nodes:
            icon = _classification_icon(node["classification"])
            status = " [green](installed)[/green]" if node["installed"] else ""
            label = f"{icon} [bold]{node['name']}[/bold]{status}"
            if node["description"]:
                label += f" — {node['description']}"
            branch = parent_tree.add(label)
            _add_nodes(branch, node.get("children", []))

    _add_nodes(rich_tree, data["roots"])
    console.print(rich_tree)


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@cli.command()
@_handle_error
def update():
    """Pull latest registry and re-materialize packages."""
    engine = _get_engine()

    with console.status("Updating..."):
        result = engine.update()

    console.print(f"[green]Updated to ref {result['new_ref']}.[/green]")

    if result["updated_packages"]:
        console.print(f"  Re-materialized: {', '.join(result['updated_packages'])}")

    if result["new_evergreen"]:
        console.print(
            f"\n[yellow]New evergreen packages available:[/yellow] "
            f"{', '.join(result['new_evergreen'])}"
        )
        console.print("[dim]Run [bold]kt add <package>[/bold] to install.[/dim]")


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@cli.command()
@_handle_error
def status():
    """Show project status."""
    engine = _get_engine()
    data = engine.get_status()

    panel_content = (
        f"Registry: {data['registry']}\n"
        f"Branch: {data['registry_ref']}\n"
        f"Installed packages: {data['installed_count']}\n"
        f"Available packages: {data['available_count']}\n"
        f"Knowledge files: {data['total_files']}\n"
        f"Total lines: {data['total_lines']}"
    )

    console.print(Panel(panel_content, title="Knowledge Tree Status", border_style="green"))


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("package")
@_handle_error
def info(package: str):
    """Show detailed information about a package."""
    engine = _get_engine()
    data = engine.get_info(package)

    icon = _classification_icon(data["classification"])
    lines = [
        f"[bold]{data['name']}[/bold] {icon} {data['classification']}",
        f"{data['description']}",
        "",
    ]

    if data["authors"]:
        lines.append(f"Authors: {', '.join(data['authors'])}")
    if data["tags"]:
        lines.append(f"Tags: {', '.join(data['tags'])}")
    if data["parent"]:
        lines.append(f"Parent: {data['parent']}")
    if data["depends_on"]:
        lines.append(f"Dependencies: {', '.join(data['depends_on'])}")
    if data["children"]:
        lines.append(f"Children: {', '.join(data['children'])}")
    if data["transitive_deps"]:
        lines.append(f"Transitive deps: {', '.join(data['transitive_deps'])}")

    status_line = (
        f"[green]Installed[/green] (ref: {data['ref']})"
        if data["installed"]
        else "[dim]Not installed[/dim]"
    )
    lines.append(f"\nStatus: {status_line}")

    if data["files"]:
        lines.append("\nContent files:")
        for f in data["files"]:
            lines.append(f"  - {f['name']} ({f['lines']} lines)")

    console.print(Panel("\n".join(lines), border_style="blue"))


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option("--all", "validate_all", is_flag=True, help="Validate all packages in directory.")
@_handle_error
def validate(path: Path, validate_all: bool):
    """Validate a knowledge package."""
    engine = _get_engine()

    if validate_all:
        # Validate all subdirectories as packages
        any_errors = False
        for pkg_dir in sorted(path.iterdir()):
            if not pkg_dir.is_dir():
                continue
            result = engine.validate_package(pkg_dir)
            if result["errors"]:
                console.print(f"[red]\u2717[/red] {pkg_dir.name}")
                for err in result["errors"]:
                    console.print(f"    [red]{err}[/red]")
                any_errors = True
            elif result["warnings"]:
                console.print(f"[yellow]![/yellow] {pkg_dir.name}")
                for warn in result["warnings"]:
                    console.print(f"    [yellow]{warn}[/yellow]")
            else:
                console.print(f"[green]\u2713[/green] {pkg_dir.name}")

        if any_errors:
            raise SystemExit(1)
    else:
        result = engine.validate_package(path)

        if result["errors"]:
            console.print(f"[red]Validation failed for {path.name}:[/red]")
            for err in result["errors"]:
                console.print(f"  [red]\u2717 {err}[/red]")
            raise SystemExit(1)

        if result["warnings"]:
            console.print(f"[yellow]Warnings for {path.name}:[/yellow]")
            for warn in result["warnings"]:
                console.print(f"  [yellow]! {warn}[/yellow]")

        console.print(f"[green]\u2713 {path.name} is valid.[/green]")


# ---------------------------------------------------------------------------
# contribute (Phase 2)
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option("--name", required=True, help="Package name for the contribution.")
@click.option("--to", "to_existing", default=None, help="Contribute as child of existing package.")
@_handle_error
def contribute(file: Path, name: str, to_existing: str | None):
    """Contribute a knowledge file to the community."""
    engine = _get_engine()

    with console.status("Preparing contribution..."):
        mr_url = engine.contribute(file, name, to_existing=to_existing)

    console.print(f"[green]Contribution prepared![/green]")
    console.print(f"\nOpen this URL to create a merge/pull request:")
    console.print(f"  [bold blue]{mr_url}[/bold blue]")


# ---------------------------------------------------------------------------
# registry rebuild (Phase 2)
# ---------------------------------------------------------------------------


@cli.group()
def registry():
    """Registry management commands."""
    pass


@registry.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@_handle_error
def rebuild(path: Path):
    """Rebuild registry.yaml from packages directory."""
    engine = _get_engine()
    count = engine.registry_rebuild(path)
    console.print(f"[green]Rebuilt registry with {count} packages.[/green]")


cli.add_command(registry)
