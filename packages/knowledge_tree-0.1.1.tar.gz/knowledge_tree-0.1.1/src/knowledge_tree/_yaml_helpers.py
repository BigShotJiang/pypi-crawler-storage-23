"""Centralized YAML load/save using ruamel.yaml."""

from pathlib import Path

from ruamel.yaml import YAML


def load_yaml(path: Path) -> dict:
    """Load a YAML file and return its contents as a dict.

    Returns an empty dict for empty or nonexistent content.
    """
    yaml = YAML()
    with open(path) as f:
        data = yaml.load(f)
    return data if data is not None else {}


def save_yaml(data: dict, path: Path) -> None:
    """Save a dict to a YAML file.

    Creates parent directories if they don't exist.
    Uses block style (no flow style).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    yaml = YAML()
    yaml.default_flow_style = False
    with open(path, "w") as f:
        yaml.dump(data, f)
