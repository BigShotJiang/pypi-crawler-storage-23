"""Core engine for Knowledge Tree operations."""

from __future__ import annotations

import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

from knowledge_tree import git_ops
from knowledge_tree.models import (
    PackageMetadata,
    ProjectConfig,
    Registry,
    RegistryEntry,
)


class KnowledgeTreeEngine:
    """Orchestrates all Knowledge Tree operations for a project."""

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.kt_dir = project_root / ".kt"
        self.knowledge_dir = project_root / ".knowledge"
        self.config_path = self.kt_dir / "kt.yaml"
        self.cache_dir = self.kt_dir / "registry_cache"
        self.manifest_path = self.knowledge_dir / "KNOWLEDGE_MANIFEST.md"

    def _load_config(self) -> ProjectConfig:
        if not self.config_path.exists():
            raise FileNotFoundError(
                "Not initialized. Run `kt init --from <url>` first."
            )
        return ProjectConfig.from_yaml_file(self.config_path)

    def _load_registry(self) -> Registry:
        registry_yaml = self.cache_dir / "registry.yaml"
        if not registry_yaml.exists():
            raise FileNotFoundError(
                "Registry cache not found. Run `kt init --from <url>` first."
            )
        return Registry.from_yaml_file(registry_yaml)

    # ------------------------------------------------------------------
    # init
    # ------------------------------------------------------------------

    def init(
        self,
        registry_url: str,
        branch: str = "main",
    ) -> list[str]:
        """Initialize a Knowledge Tree project.

        Clones the registry, creates config, returns list of available packages.
        Raises FileExistsError if already initialized.
        """
        if self.kt_dir.exists():
            raise FileExistsError(
                "Already initialized. Remove .kt/ directory to re-initialize."
            )

        self.kt_dir.mkdir(parents=True)
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)

        git_ops.clone(
            url=registry_url,
            dest=self.cache_dir,
            branch=branch,
            depth=1,
        )

        head_ref = git_ops.get_head_ref(self.cache_dir)

        config = ProjectConfig(
            registry=registry_url,
            registry_ref=branch,
            packages=[],
            telemetry_enabled=False,
            telemetry_anonymous_id=uuid.uuid4().hex[:8],
        )
        config.to_yaml_file(self.config_path)

        registry = self._load_registry()
        self._generate_manifest(config, registry)

        return sorted(registry.packages.keys())

    # ------------------------------------------------------------------
    # add_package
    # ------------------------------------------------------------------

    def add_package(self, package_name: str) -> dict:
        """Install a package and its dependencies.

        Returns dict with keys:
            installed: list of newly installed package names
            already_installed: list of already-installed package names
        """
        config = self._load_config()
        registry = self._load_registry()

        chain = registry.resolve_dependency_chain(package_name)

        installed_names = config.get_installed_names()
        newly_installed: list[str] = []
        already_installed: list[str] = []

        for name in chain:
            if name in installed_names:
                already_installed.append(name)
                continue

            self._materialize_package(name, registry)

            ref = git_ops.get_short_ref(self.cache_dir)
            config.add_package(name, ref)
            installed_names.add(name)
            newly_installed.append(name)

        config.to_yaml_file(self.config_path)
        self._generate_manifest(config, registry)

        return {
            "installed": newly_installed,
            "already_installed": already_installed,
        }

    # ------------------------------------------------------------------
    # _materialize_package
    # ------------------------------------------------------------------

    def _materialize_package(
        self,
        name: str,
        registry: Registry,
    ) -> None:
        """Copy a package's content files from cache to .knowledge/."""
        entry = registry.packages.get(name)
        if entry is None:
            raise ValueError(f"Package '{name}' not found in registry.")

        dest = self.knowledge_dir / name
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True)

        src = self.cache_dir / entry.path
        if not src.is_dir():
            raise ValueError(
                f"Package directory not found in registry cache: {entry.path}"
            )

        # Load package.yaml to check for explicit content list
        pkg_yaml = src / "package.yaml"
        content_files: list[str] = []
        if pkg_yaml.exists():
            meta = PackageMetadata.from_yaml_file(pkg_yaml)
            content_files = list(meta.content)

        if content_files:
            for filename in content_files:
                src_file = src / filename
                if src_file.exists():
                    shutil.copy2(src_file, dest / filename)
        else:
            # Fall back to all .md files
            for md_file in sorted(src.glob("*.md")):
                shutil.copy2(md_file, dest / md_file.name)

    # ------------------------------------------------------------------
    # remove_package
    # ------------------------------------------------------------------

    def remove_package(self, package_name: str) -> dict:
        """Remove a package.

        Returns dict with keys:
            removed: bool
            dependents: list of installed packages that depend on the removed one
        """
        config = self._load_config()
        registry = self._load_registry()

        if package_name not in config.get_installed_names():
            similar = registry.find_similar_names(package_name)
            msg = f"Package '{package_name}' is not installed."
            if similar:
                msg += f" Did you mean: {', '.join(similar)}?"
            raise ValueError(msg)

        # Check what other installed packages depend on this one
        dependents = []
        for name in config.get_installed_names():
            if name == package_name:
                continue
            entry = registry.packages.get(name)
            if entry and package_name in entry.depends_on:
                dependents.append(name)

        # Remove files
        pkg_dir = self.knowledge_dir / package_name
        if pkg_dir.exists():
            shutil.rmtree(pkg_dir)

        config.remove_package(package_name)
        config.to_yaml_file(self.config_path)
        self._generate_manifest(config, registry)

        return {"removed": True, "dependents": dependents}

    # ------------------------------------------------------------------
    # update
    # ------------------------------------------------------------------

    def update(self) -> dict:
        """Pull latest registry, re-materialize all packages.

        Returns dict with keys:
            updated_packages: list of re-materialized package names
            new_ref: new HEAD short ref
            new_evergreen: list of new evergreen packages not yet installed
        """
        config = self._load_config()

        new_ref = git_ops.pull(self.cache_dir, config.registry_ref)
        short_ref = git_ops.get_short_ref(self.cache_dir)

        registry = self._load_registry()
        installed_names = config.get_installed_names()

        # Re-materialize all installed packages
        updated: list[str] = []
        for name in list(installed_names):
            if name in registry.packages:
                self._materialize_package(name, registry)
                config.add_package(name, short_ref)
                updated.append(name)

        # Detect new evergreen packages
        new_evergreen = []
        for name, entry in registry.packages.items():
            if (
                name not in installed_names
                and entry.classification == "evergreen"
            ):
                new_evergreen.append(name)

        config.to_yaml_file(self.config_path)
        self._generate_manifest(config, registry)

        return {
            "updated_packages": updated,
            "new_ref": short_ref,
            "new_evergreen": sorted(new_evergreen),
        }

    # ------------------------------------------------------------------
    # list_packages
    # ------------------------------------------------------------------

    def list_packages(
        self,
        available: bool = False,
        community: bool = False,
    ) -> list[dict]:
        """List packages.

        Args:
            available: If True, list available (not installed) packages.
            community: If True, list community packages.

        Returns list of dicts with package info.
        """
        config = self._load_config()
        registry = self._load_registry()
        installed_names = config.get_installed_names()

        results = []

        if community:
            community_dir = self.cache_dir / "community"
            if community_dir.is_dir():
                for pkg_dir in sorted(community_dir.iterdir()):
                    if not pkg_dir.is_dir():
                        continue
                    yaml_path = pkg_dir / "package.yaml"
                    if yaml_path.exists():
                        meta = PackageMetadata.from_yaml_file(yaml_path)
                        results.append({
                            "name": meta.name,
                            "description": meta.description,
                            "classification": meta.classification,
                            "tags": meta.tags,
                            "status": meta.status or "pending",
                            "installed": meta.name in installed_names,
                            "source": "community",
                        })
            return results

        for name, entry in sorted(registry.packages.items()):
            is_installed = name in installed_names
            if available and is_installed:
                continue
            if not available and not is_installed:
                continue
            results.append({
                "name": name,
                "description": entry.description,
                "classification": entry.classification,
                "tags": entry.tags,
                "installed": is_installed,
                "ref": config.get_package_ref(name) or "",
                "source": "registry",
            })

        return results

    # ------------------------------------------------------------------
    # search
    # ------------------------------------------------------------------

    def search(self, query: str) -> list[dict]:
        """Search packages in the registry."""
        config = self._load_config()
        registry = self._load_registry()
        installed_names = config.get_installed_names()

        results = []
        for name, entry in registry.search(query):
            results.append({
                "name": name,
                "description": entry.description,
                "classification": entry.classification,
                "tags": entry.tags,
                "installed": name in installed_names,
            })
        return results

    # ------------------------------------------------------------------
    # get_tree_data
    # ------------------------------------------------------------------

    def get_tree_data(self) -> dict:
        """Build nested tree structure for rendering.

        Returns dict:
            roots: list of tree nodes (dicts with name, children, entry)
        """
        registry = self._load_registry()
        config = self._load_config()
        installed_names = config.get_installed_names()

        # Build tree
        nodes: dict[str, dict] = {}
        for name, entry in registry.packages.items():
            nodes[name] = {
                "name": name,
                "description": entry.description,
                "classification": entry.classification,
                "installed": name in installed_names,
                "children": [],
            }

        # Link parents
        roots: list[dict] = []
        for name, entry in registry.packages.items():
            node = nodes[name]
            if entry.parent and entry.parent in nodes:
                nodes[entry.parent]["children"].append(node)
            else:
                roots.append(node)

        # Sort
        roots.sort(key=lambda n: n["name"])
        for node in nodes.values():
            node["children"].sort(key=lambda n: n["name"])

        return {"roots": roots}

    # ------------------------------------------------------------------
    # get_status
    # ------------------------------------------------------------------

    def get_status(self) -> dict:
        """Get project status summary."""
        config = self._load_config()
        registry = self._load_registry()
        installed_names = config.get_installed_names()

        total_files = 0
        total_lines = 0
        for name in installed_names:
            pkg_dir = self.knowledge_dir / name
            if pkg_dir.is_dir():
                for f in pkg_dir.iterdir():
                    if f.is_file():
                        total_files += 1
                        total_lines += len(f.read_text().splitlines())

        return {
            "registry": config.registry,
            "registry_ref": config.registry_ref,
            "installed_count": len(installed_names),
            "available_count": len(registry.packages) - len(installed_names),
            "total_files": total_files,
            "total_lines": total_lines,
        }

    # ------------------------------------------------------------------
    # get_info
    # ------------------------------------------------------------------

    def get_info(self, package_name: str) -> dict:
        """Get detailed info for a package."""
        config = self._load_config()
        registry = self._load_registry()

        if package_name not in registry.packages:
            similar = registry.find_similar_names(package_name)
            msg = f"Package '{package_name}' not found in registry."
            if similar:
                msg += f" Did you mean: {', '.join(similar)}?"
            raise ValueError(msg)

        entry = registry.packages[package_name]
        is_installed = package_name in config.get_installed_names()

        # Load full metadata from cache
        pkg_yaml = self.cache_dir / entry.path / "package.yaml"
        meta = PackageMetadata.from_yaml_file(pkg_yaml) if pkg_yaml.exists() else None

        # Count content files and lines if installed
        files_info: list[dict] = []
        if is_installed:
            pkg_dir = self.knowledge_dir / package_name
            if pkg_dir.is_dir():
                for f in sorted(pkg_dir.iterdir()):
                    if f.is_file():
                        lines = len(f.read_text().splitlines())
                        files_info.append({"name": f.name, "lines": lines})

        children = registry.get_children(package_name)
        deps = registry.resolve_dependency_chain(package_name)
        deps.remove(package_name)  # remove self

        return {
            "name": package_name,
            "description": entry.description,
            "classification": entry.classification,
            "tags": entry.tags,
            "parent": entry.parent,
            "depends_on": entry.depends_on,
            "children": children,
            "transitive_deps": deps,
            "installed": is_installed,
            "ref": config.get_package_ref(package_name) or "",
            "files": files_info,
            "authors": meta.authors if meta else [],
            "created": meta.created if meta else None,
            "updated": meta.updated if meta else None,
        }

    # ------------------------------------------------------------------
    # validate_package
    # ------------------------------------------------------------------

    def validate_package(self, package_path: Path) -> dict:
        """Validate a package at the given path.

        Returns dict with:
            valid: bool
            errors: list of error strings
            warnings: list of warning strings
        """
        errors: list[str] = []
        warnings: list[str] = []

        yaml_path = package_path / "package.yaml"
        if not yaml_path.exists():
            errors.append("Missing package.yaml")
            return {"valid": False, "errors": errors, "warnings": warnings}

        meta = PackageMetadata.from_yaml_file(yaml_path)
        errors.extend(meta.validate())

        # Check content files exist
        if meta.content:
            for filename in meta.content:
                if not (package_path / filename).exists():
                    errors.append(
                        f"Content file '{filename}' listed but not found"
                    )
        else:
            # No explicit content list — check for any .md files
            md_files = list(package_path.glob("*.md"))
            if not md_files:
                warnings.append(
                    "No content list in package.yaml and no .md files found"
                )

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
        }

    # ------------------------------------------------------------------
    # _generate_manifest
    # ------------------------------------------------------------------

    def _generate_manifest(
        self,
        config: ProjectConfig,
        registry: Registry,
    ) -> None:
        """Generate KNOWLEDGE_MANIFEST.md in .knowledge/ directory."""
        installed_names = config.get_installed_names()
        if not installed_names:
            if self.manifest_path.exists():
                self.manifest_path.unlink()
            return

        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lines = [
            "# Knowledge Manifest",
            f"<!-- Generated by Knowledge Tree on {now} -->",
            "",
            "This file describes the knowledge packages installed in this project.",
            "AI agents should read this file to understand what context is available.",
            "",
        ]

        # Group packages by scope (parent chain)
        # Build scope groups: root -> children
        scopes: dict[str, list[str]] = {}  # root_name -> [child names]
        standalone: list[str] = []

        for name in sorted(installed_names):
            entry = registry.packages.get(name)
            if entry is None:
                standalone.append(name)
                continue

            # Walk up parent chain to find the root
            root = name
            visited = {name}
            current = entry
            while current.parent and current.parent in registry.packages:
                if current.parent in visited:
                    break
                root = current.parent
                visited.add(root)
                current = registry.packages[root]

            if root == name:
                # This is a root or standalone
                if name not in scopes:
                    scopes[name] = []
            else:
                if root not in scopes:
                    scopes[root] = []
                scopes[root].append(name)

        # Write scope sections
        for root_name in sorted(scopes.keys()):
            root_entry = registry.packages.get(root_name)
            if root_name in installed_names:
                desc = root_entry.description if root_entry else ""
                lines.append(f"## {root_name}")
                lines.append(f"{desc}")
                lines.append("")
                self._append_package_files(lines, root_name)

            for child_name in sorted(scopes[root_name]):
                child_entry = registry.packages.get(child_name)
                desc = child_entry.description if child_entry else ""
                lines.append(f"### {child_name}")
                lines.append(f"{desc}")
                lines.append("")
                self._append_package_files(lines, child_name)

        for name in standalone:
            lines.append(f"## {name}")
            lines.append("")
            self._append_package_files(lines, name)

        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)
        self.manifest_path.write_text("\n".join(lines))

    def _append_package_files(self, lines: list[str], name: str) -> None:
        """Append file listing for a package to manifest lines."""
        pkg_dir = self.knowledge_dir / name
        if not pkg_dir.is_dir():
            return
        lines.append("Files:")
        for f in sorted(pkg_dir.iterdir()):
            if f.is_file():
                line_count = len(f.read_text().splitlines())
                lines.append(f"- [{f.name}]({name}/{f.name}) ({line_count} lines)")
        lines.append("")

    # ------------------------------------------------------------------
    # contribute (Phase 2)
    # ------------------------------------------------------------------

    def contribute(
        self,
        file_path: Path,
        name: str,
        to_existing: str | None = None,
    ) -> str:
        """Contribute a knowledge file to the community directory.

        Returns the MR/PR URL string.
        """
        config = self._load_config()

        # Unshallow the cache so we can push
        git_ops.unshallow(self.cache_dir)

        # Create branch
        branch_name = f"contribute/{name}"
        git_ops.create_branch(self.cache_dir, branch_name)

        # Determine destination
        if to_existing:
            dest_dir = self.cache_dir / "community" / to_existing / name
        else:
            dest_dir = self.cache_dir / "community" / name
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Copy file
        shutil.copy2(file_path, dest_dir / file_path.name)

        # Generate package.yaml
        meta = PackageMetadata(
            name=name,
            description=f"Community contribution: {name}",
            authors=["Contributor"],
            classification="seasonal",
            status="pending",
            content=[file_path.name],
        )
        meta.to_yaml_file(dest_dir / "package.yaml")

        # Commit and push
        git_ops.add_and_commit(
            self.cache_dir,
            [str(dest_dir.relative_to(self.cache_dir))],
            f"Add community package: {name}",
        )
        git_ops.push_branch(self.cache_dir, branch_name)

        # Generate MR URL
        remote_url = git_ops.run_git(
            ["remote", "get-url", "origin"], cwd=self.cache_dir
        )
        return git_ops.get_mr_url(remote_url, branch_name)

    # ------------------------------------------------------------------
    # registry_rebuild (Phase 2)
    # ------------------------------------------------------------------

    def registry_rebuild(self, registry_path: Path) -> int:
        """Rebuild registry.yaml from packages directory.

        Returns the number of packages found.
        """
        packages_dir = registry_path / "packages"
        registry = Registry()
        registry.rebuild_from_packages(packages_dir)
        registry.to_yaml_file(registry_path / "registry.yaml")
        return len(registry.packages)
