"""Data models for Knowledge Tree."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from knowledge_tree._yaml_helpers import load_yaml, save_yaml

# Valid package name: lowercase letters, digits, hyphens. Must start with letter.
# Examples: "base", "git-conventions", "cloud-aws-lambda"
PACKAGE_NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")

VALID_CLASSIFICATIONS = {"evergreen", "seasonal"}
VALID_STATUSES = {"pending", "promoted", "archived"}


def _levenshtein(s1: str, s2: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    prev_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            cost = 0 if c1 == c2 else 1
            curr_row.append(
                min(prev_row[j + 1] + 1, curr_row[j] + 1, prev_row[j] + cost)
            )
        prev_row = curr_row
    return prev_row[-1]


# ---------------------------------------------------------------------------
# PackageMetadata
# ---------------------------------------------------------------------------


@dataclass
class PackageMetadata:
    """Represents a package.yaml file."""

    # Required fields
    name: str = ""
    description: str = ""
    authors: list[str] = field(default_factory=list)
    classification: str = ""

    # Optional relationship fields
    parent: str | None = None
    depends_on: list[str] = field(default_factory=list)
    suggests: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    audience: list[str] = field(default_factory=list)
    content: list[str] = field(default_factory=list)

    # Optional dates
    created: str | None = None
    updated: str | None = None

    # Community-only fields (Phase 2, defined now to avoid migration)
    status: str | None = None
    promoted_to: str | None = None
    promoted_date: str | None = None

    def validate(self) -> list[str]:
        """Return a list of validation error strings. Empty list = valid."""
        errors: list[str] = []

        if not self.name:
            errors.append("'name' is required")
        elif not PACKAGE_NAME_RE.match(self.name):
            errors.append(
                f"Invalid package name '{self.name}'. "
                "Must be lowercase kebab-case (e.g., 'cloud-aws')."
            )

        if not self.description:
            errors.append("'description' is required")

        if not self.authors:
            errors.append("At least one author is required")

        if not self.classification:
            errors.append("'classification' is required")
        elif self.classification not in VALID_CLASSIFICATIONS:
            errors.append(
                f"Invalid classification '{self.classification}'. "
                f"Must be one of: {', '.join(sorted(VALID_CLASSIFICATIONS))}"
            )

        if self.status is not None and self.status not in VALID_STATUSES:
            errors.append(
                f"Invalid status '{self.status}'. "
                f"Must be one of: {', '.join(sorted(VALID_STATUSES))}"
            )

        return errors

    @classmethod
    def from_yaml_file(cls, path: Path) -> PackageMetadata:
        """Load a PackageMetadata from a package.yaml file."""
        data = load_yaml(path)
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            authors=list(data.get("authors", [])),
            classification=data.get("classification", ""),
            parent=data.get("parent"),
            depends_on=list(data.get("depends_on", [])),
            suggests=list(data.get("suggests", [])),
            tags=list(data.get("tags", [])),
            audience=list(data.get("audience", [])),
            content=list(data.get("content", [])),
            created=data.get("created"),
            updated=data.get("updated"),
            status=data.get("status"),
            promoted_to=data.get("promoted_to"),
            promoted_date=data.get("promoted_date"),
        )

    def to_yaml_file(self, path: Path) -> None:
        """Save this PackageMetadata to a package.yaml file.

        Omits fields that are None or empty lists (keeps output clean).
        """
        data: dict = {}
        data["name"] = self.name
        data["description"] = self.description
        data["authors"] = self.authors
        data["classification"] = self.classification

        if self.parent is not None:
            data["parent"] = self.parent
        if self.depends_on:
            data["depends_on"] = self.depends_on
        if self.suggests:
            data["suggests"] = self.suggests
        if self.tags:
            data["tags"] = self.tags
        if self.audience:
            data["audience"] = self.audience
        if self.content:
            data["content"] = self.content
        if self.created is not None:
            data["created"] = self.created
        if self.updated is not None:
            data["updated"] = self.updated
        if self.status is not None:
            data["status"] = self.status
        if self.promoted_to is not None:
            data["promoted_to"] = self.promoted_to
        if self.promoted_date is not None:
            data["promoted_date"] = self.promoted_date

        save_yaml(data, path)


# ---------------------------------------------------------------------------
# RegistryEntry
# ---------------------------------------------------------------------------


@dataclass
class RegistryEntry:
    """Lightweight entry for registry.yaml."""

    description: str = ""
    classification: str = ""
    tags: list[str] = field(default_factory=list)
    path: str = ""
    parent: str | None = None
    depends_on: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


@dataclass
class Registry:
    """The full registry index, loaded from registry.yaml."""

    packages: dict[str, RegistryEntry] = field(default_factory=dict)

    @classmethod
    def from_yaml_file(cls, path: Path) -> Registry:
        """Load a Registry from registry.yaml."""
        data = load_yaml(path)
        packages_data = data.get("packages", {})
        packages: dict[str, RegistryEntry] = {}
        for name, entry_data in packages_data.items():
            if not isinstance(entry_data, dict):
                continue
            packages[name] = RegistryEntry(
                description=entry_data.get("description", ""),
                classification=entry_data.get("classification", ""),
                tags=list(entry_data.get("tags", [])),
                path=entry_data.get("path", ""),
                parent=entry_data.get("parent"),
                depends_on=list(entry_data.get("depends_on", [])),
            )
        return cls(packages=packages)

    def to_yaml_file(self, path: Path) -> None:
        """Save this Registry to registry.yaml."""
        packages_data: dict = {}
        for name, entry in self.packages.items():
            entry_data: dict = {
                "description": entry.description,
                "classification": entry.classification,
            }
            if entry.tags:
                entry_data["tags"] = entry.tags
            if entry.path:
                entry_data["path"] = entry.path
            if entry.parent is not None:
                entry_data["parent"] = entry.parent
            if entry.depends_on:
                entry_data["depends_on"] = entry.depends_on
            packages_data[name] = entry_data
        save_yaml({"packages": packages_data}, path)

    def search(self, query: str) -> list[tuple[str, RegistryEntry]]:
        """Search packages by name, description, and tags.

        Returns list of (name, entry) tuples sorted by relevance:
        exact name match > name contains > description contains > tag match.
        """
        query_lower = query.lower()
        results: list[tuple[int, str, RegistryEntry]] = []

        for name, entry in self.packages.items():
            score = 0
            name_lower = name.lower()
            desc_lower = entry.description.lower()
            tags_lower = [t.lower() for t in entry.tags]

            if name_lower == query_lower:
                score = 100
            elif query_lower in name_lower:
                score = 80
            elif query_lower in desc_lower:
                score = 60
            elif any(query_lower in tag for tag in tags_lower):
                score = 40

            if score > 0:
                results.append((score, name, entry))

        results.sort(key=lambda r: (-r[0], r[1]))
        return [(name, entry) for _, name, entry in results]

    def get_children(self, package_name: str) -> list[str]:
        """Return names of packages whose parent is package_name."""
        return [
            name
            for name, entry in self.packages.items()
            if entry.parent == package_name
        ]

    def resolve_dependency_chain(self, package_name: str) -> list[str]:
        """Return topologically-sorted list of transitive dependencies.

        The list ends with package_name itself.
        Raises ValueError on circular dependency or missing package.
        """
        if package_name not in self.packages:
            similar = self.find_similar_names(package_name)
            msg = f"Package '{package_name}' not found in registry."
            if similar:
                msg += f" Did you mean: {', '.join(similar)}?"
            raise ValueError(msg)

        visited: set[str] = set()
        stack: set[str] = set()  # for cycle detection
        chain: list[str] = []

        def _resolve(name: str) -> None:
            if name in stack:
                raise ValueError(
                    f"Circular dependency detected involving '{name}'"
                )
            if name in visited:
                return
            stack.add(name)
            entry = self.packages.get(name)
            if entry is None:
                raise ValueError(
                    f"Dependency '{name}' not found in registry"
                )
            for dep in entry.depends_on:
                _resolve(dep)
            stack.remove(name)
            visited.add(name)
            chain.append(name)

        _resolve(package_name)
        return chain

    def rebuild_from_packages(self, packages_dir: Path) -> None:
        """Scan packages_dir and rebuild registry entries from package.yaml files."""
        self.packages.clear()
        if not packages_dir.is_dir():
            return
        for pkg_dir in sorted(packages_dir.iterdir()):
            if not pkg_dir.is_dir():
                continue
            yaml_path = pkg_dir / "package.yaml"
            if not yaml_path.exists():
                continue
            meta = PackageMetadata.from_yaml_file(yaml_path)
            self.packages[meta.name] = RegistryEntry(
                description=meta.description,
                classification=meta.classification,
                tags=list(meta.tags),
                path=f"packages/{pkg_dir.name}",
                parent=meta.parent,
                depends_on=list(meta.depends_on),
            )

    def find_similar_names(self, name: str, threshold: int = 2) -> list[str]:
        """Return package names within edit distance threshold of name."""
        similar: list[tuple[int, str]] = []
        for pkg_name in self.packages:
            dist = _levenshtein(name.lower(), pkg_name.lower())
            if dist <= threshold:
                similar.append((dist, pkg_name))
        similar.sort()
        return [s[1] for s in similar]


# ---------------------------------------------------------------------------
# InstalledPackage
# ---------------------------------------------------------------------------


@dataclass
class InstalledPackage:
    """A package installed in the project, with its pinned git ref."""

    name: str = ""
    ref: str = ""


# ---------------------------------------------------------------------------
# ProjectConfig
# ---------------------------------------------------------------------------


@dataclass
class ProjectConfig:
    """Project configuration loaded from .kt/kt.yaml."""

    registry: str = ""
    registry_ref: str = "main"
    packages: list[InstalledPackage] = field(default_factory=list)
    telemetry_enabled: bool = False
    telemetry_anonymous_id: str = ""

    @classmethod
    def from_yaml_file(cls, path: Path) -> ProjectConfig:
        """Load project config from kt.yaml."""
        data = load_yaml(path)
        packages = []
        for pkg_data in data.get("packages", []):
            packages.append(
                InstalledPackage(
                    name=pkg_data.get("name", ""),
                    ref=pkg_data.get("ref", ""),
                )
            )
        telemetry = data.get("telemetry", {})
        return cls(
            registry=data.get("registry", ""),
            registry_ref=data.get("registry_ref", "main"),
            packages=packages,
            telemetry_enabled=telemetry.get("enabled", False),
            telemetry_anonymous_id=telemetry.get("anonymous_id", ""),
        )

    def to_yaml_file(self, path: Path) -> None:
        """Save project config to kt.yaml."""
        data: dict = {
            "registry": self.registry,
            "registry_ref": self.registry_ref,
            "packages": [
                {"name": pkg.name, "ref": pkg.ref} for pkg in self.packages
            ],
            "telemetry": {
                "enabled": self.telemetry_enabled,
                "anonymous_id": self.telemetry_anonymous_id,
            },
        }
        save_yaml(data, path)

    def add_package(self, name: str, ref: str) -> None:
        """Add or update a package entry."""
        for pkg in self.packages:
            if pkg.name == name:
                pkg.ref = ref
                return
        self.packages.append(InstalledPackage(name=name, ref=ref))

    def remove_package(self, name: str) -> bool:
        """Remove a package by name. Return True if found and removed."""
        for i, pkg in enumerate(self.packages):
            if pkg.name == name:
                self.packages.pop(i)
                return True
        return False

    def get_installed_names(self) -> set[str]:
        """Return the set of installed package names."""
        return {pkg.name for pkg in self.packages}

    def get_package_ref(self, name: str) -> str | None:
        """Get the ref for an installed package, or None."""
        for pkg in self.packages:
            if pkg.name == name:
                return pkg.ref
        return None
