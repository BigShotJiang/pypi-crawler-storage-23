---
tags:
  category: system
  context: meta
---
# .meta/artist — Same Artist

Items tagged with the same artist. Surfaces other work
by the same creator when viewing a media item.

artist=*
artist=
