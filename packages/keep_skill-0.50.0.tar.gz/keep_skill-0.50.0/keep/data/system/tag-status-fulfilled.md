---
tags:
  category: system
  context: tag-value
---
# status: `fulfilled`

Completed and satisfied. The commitment has been kept, the request has been answered, or the offer has been delivered. Terminal state.
