"""drp CLI — command-line tool for drp."""

__version__ = '0.1.1'
DEFAULT_HOST = 'https://drp.vicnas.me'