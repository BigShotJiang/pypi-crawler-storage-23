if __name__ == "__main__":
    from cap_upload_validator.cli import validate
    validate()
