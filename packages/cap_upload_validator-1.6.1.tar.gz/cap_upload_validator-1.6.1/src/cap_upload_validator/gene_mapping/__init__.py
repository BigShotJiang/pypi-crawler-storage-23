from .gene_map import (
    HomoSapiens,
    MusMusculus,
    MultiSpecies,
    UnsupportedOrganism, 
    GeneMap,
    Organism,
    str_to_organism,
    ontology_id_to_organism,
)
