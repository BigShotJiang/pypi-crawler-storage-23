"""VideoContext — Extract video content for AI CLI consumption."""

__version__ = "0.1.0"
