"""Allow running as python -m videocontext."""

from videocontext.cli import cli

cli()
