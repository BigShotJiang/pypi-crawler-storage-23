# The `npfl138` Package: Modules Used in the Deep Learning Course (NPFL138)

This package contains the modules used in the
[Deep Learning course (NPFL138)](http://ufal.mff.cuni.cz/courses/npfl138),
available under the Mozilla Public License 2.0.

The documentation of the package can be found
[here](https://ufal.mff.cuni.cz/~straka/courses/npfl138/2526/docs/).
