import os
import time
import threading
import uuid
import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
from robot.api.deco import keyword, library
from robot.api import logger

import docker
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from hmd_lib_containers.hmd_lib_containers import (
    run_container as rc,
    kill_container,
    exec_container as ec,
)


@library
class ContainerLib:
    def __init__(self):
        self.docker_client = docker.from_env()

    def _monitor_container(
        self, container_id: str, stats_data: Dict, stop_event: threading.Event
    ):
        """Monitor container CPU and memory usage in a separate thread."""
        container = self.docker_client.containers.get(container_id)

        while not stop_event.is_set():
            try:
                stats = container.stats(stream=False)
                timestamp = datetime.now()

                # Calculate CPU usage percentage
                cpu_delta = (
                    stats["cpu_stats"]["cpu_usage"]["total_usage"]
                    - stats["precpu_stats"]["cpu_usage"]["total_usage"]
                )
                system_delta = (
                    stats["cpu_stats"]["system_cpu_usage"]
                    - stats["precpu_stats"]["system_cpu_usage"]
                )
                cpu_count = stats["cpu_stats"].get("online_cpus", 1)

                if system_delta > 0 and cpu_delta > 0:
                    cpu_percent = (cpu_delta / system_delta) * cpu_count * 100.0
                else:
                    cpu_percent = 0.0

                # Calculate memory usage in MB
                memory_usage = stats["memory_stats"].get("usage", 0) / (1024 * 1024)
                memory_limit = stats["memory_stats"].get("limit", 0) / (1024 * 1024)

                stats_data["timestamps"].append(timestamp)
                stats_data["cpu"].append(cpu_percent)
                stats_data["memory"].append(memory_usage)
                stats_data["memory_limit"] = memory_limit

                time.sleep(1)  # Sample every second
            except Exception as e:
                logger.warn(f"Error monitoring container: {e}")
                break

    def _generate_usage_charts(
        self,
        container_name: str,
        stats_data: Dict,
        output_dir: Path,
        suite_name: str = None,
        test_name: str = None,
    ) -> tuple:
        """Generate CPU and memory usage charts and save stats as JSON.

        Args:
            container_name: Name of the container
            stats_data: Dictionary containing monitoring data
            output_dir: Base output directory (e.g., ../bender)
            suite_name: Optional suite name for organizing artifacts
            test_name: Optional test name for organizing artifacts

        Returns:
            Tuple of (cpu_chart_path, memory_chart_path, json_path)
        """
        if not stats_data["timestamps"]:
            logger.warn("No monitoring data collected")
            return None, None, None

        # Create hierarchical output directory if suite/test names provided
        if suite_name and test_name:
            safe_suite_name = suite_name.replace(" ", "_").replace("/", "_").lower()
            safe_test_name = test_name.replace(" ", "_").replace("/", "_").lower()
            artifacts_dir = output_dir / "artifacts" / safe_suite_name / safe_test_name
        elif test_name:
            safe_test_name = test_name.replace(" ", "_").replace("/", "_").lower()
            artifacts_dir = output_dir / "artifacts" / safe_test_name
        else:
            # Legacy behavior: save to bender root
            artifacts_dir = output_dir

        artifacts_dir.mkdir(parents=True, exist_ok=True)

        timestamps = stats_data["timestamps"]
        relative_times = [(t - timestamps[0]).total_seconds() for t in timestamps]

        # Generate CPU usage chart
        plt.figure(figsize=(10, 6))
        plt.plot(relative_times, stats_data["cpu"], linewidth=2, color="#2E86AB")
        plt.xlabel("Time (seconds)", fontsize=12)
        plt.ylabel("CPU Usage (%)", fontsize=12)
        plt.title(f"CPU Usage - {container_name}", fontsize=14, fontweight="bold")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()

        cpu_chart_path = artifacts_dir / f"{container_name}_cpu_usage.png"
        plt.savefig(cpu_chart_path, dpi=100, bbox_inches="tight")
        plt.close()

        # Generate memory usage chart
        plt.figure(figsize=(10, 6))
        plt.plot(relative_times, stats_data["memory"], linewidth=2, color="#A23B72")

        # Calculate min/max for y-axis scaling
        if stats_data["memory"]:
            min_memory = min(stats_data["memory"])
            max_memory = max(stats_data["memory"])

            # Add 10% padding for better visualization
            memory_range = max_memory - min_memory
            if memory_range > 0:
                padding = memory_range * 0.1
                y_min = max(0, min_memory - padding)  # Don't go below 0
                y_max = max_memory + padding
            else:
                # If memory is constant, add fixed padding
                y_min = max(0, min_memory - 10)
                y_max = max_memory + 10

            # If there's a memory limit, include it in the range
            # if stats_data["memory_limit"] > 0:
            #     y_max = max(y_max, stats_data["memory_limit"] + (y_max - y_min) * 0.05)
            #     plt.axhline(
            #         y=stats_data["memory_limit"],
            #         color="red",
            #         linestyle="--",
            #         label=f'Limit: {stats_data["memory_limit"]:.0f} MB',
            #         alpha=0.7,
            #     )
            #     plt.legend()

            plt.ylim(y_min, y_max)

        plt.xlabel("Time (seconds)", fontsize=12)
        plt.ylabel("Memory Usage (MB)", fontsize=12)
        plt.title(f"Memory Usage - {container_name}", fontsize=14, fontweight="bold")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()

        memory_chart_path = artifacts_dir / f"{container_name}_memory_usage.png"
        plt.savefig(memory_chart_path, dpi=100, bbox_inches="tight")
        plt.close()

        # Save stats data as JSON
        json_data = {
            "container_name": container_name,
            "timestamps": [t.isoformat() for t in timestamps],
            "relative_times_seconds": relative_times,
            "cpu_percent": stats_data["cpu"],
            "memory_mb": stats_data["memory"],
            "memory_limit_mb": stats_data["memory_limit"],
            "statistics": {
                "cpu": {
                    "avg": (
                        sum(stats_data["cpu"]) / len(stats_data["cpu"])
                        if stats_data["cpu"]
                        else 0
                    ),
                    "max": max(stats_data["cpu"]) if stats_data["cpu"] else 0,
                    "min": min(stats_data["cpu"]) if stats_data["cpu"] else 0,
                },
                "memory": {
                    "avg": (
                        sum(stats_data["memory"]) / len(stats_data["memory"])
                        if stats_data["memory"]
                        else 0
                    ),
                    "max": max(stats_data["memory"]) if stats_data["memory"] else 0,
                    "min": min(stats_data["memory"]) if stats_data["memory"] else 0,
                },
            },
        }

        json_path = artifacts_dir / f"{container_name}_stats.json"
        with open(json_path, "w") as f:
            json.dump(json_data, f, indent=2)

        logger.info(f"Saved monitoring data to {json_path}")

        return cpu_chart_path, memory_chart_path, json_path

    def _log_charts_to_robot(self, cpu_chart_path: Path, memory_chart_path: Path):
        """Include charts in RobotFramework HTML log."""
        if cpu_chart_path and cpu_chart_path.exists():
            logger.info(
                f'<img src="{cpu_chart_path.absolute()}" width="800px" />',
                html=True,
            )

        if memory_chart_path and memory_chart_path.exists():
            logger.info(
                f'<img src="{memory_chart_path.absolute()}" width="800px" />',
                html=True,
            )

    def _background_monitor_and_chart(
        self,
        container,
        container_name: str,
        stats_data: Dict,
        stop_event: threading.Event,
        timeout: int = None,
        suite_name: str = None,
        test_name: str = None,
    ):
        """Background thread to wait for container and generate charts for detached containers.

        Args:
            container: Container object
            container_name: Name of the container
            stats_data: Dictionary containing monitoring data
            stop_event: Event to signal monitoring thread to stop
            timeout: Optional timeout in seconds
            suite_name: Optional suite name for organizing artifacts
            test_name: Optional test name for organizing artifacts
        """
        timed_out = False
        try:
            if timeout:
                logger.info(
                    f"Container {container_name} timeout set to {timeout} seconds (background)"
                )
                container.wait(timeout=timeout)
            else:
                container.wait()
        except Exception as e:
            # Timeout or other error occurred
            timed_out = True
            logger.warn(
                f"Container {container_name} exceeded timeout of {timeout} seconds. Stopping container..."
            )
            try:
                container.stop(timeout=10)
                logger.info(f"Container {container_name} stopped successfully")
            except Exception as stop_error:
                logger.error(f"Failed to stop container {container_name}: {stop_error}")
                try:
                    container.kill()
                    logger.warn(f"Container {container_name} killed forcefully")
                except Exception as kill_error:
                    logger.error(
                        f"Failed to kill container {container_name}: {kill_error}"
                    )
        finally:
            # Stop monitoring thread
            stop_event.set()
            time.sleep(1)  # Give monitoring thread time to collect final stats

        # Generate and log charts
        if stats_data and stats_data["timestamps"]:
            output_dir = Path("../bender")
            cpu_chart, memory_chart, json_path = self._generate_usage_charts(
                container_name, stats_data, output_dir, suite_name, test_name
            )

            if cpu_chart and memory_chart:
                logger.info(
                    f"Background monitoring: Usage charts saved to: {cpu_chart.parent.absolute()}"
                )
                self._log_charts_to_robot(cpu_chart, memory_chart)

                # Log statistics summary
                if stats_data["cpu"]:
                    avg_cpu = sum(stats_data["cpu"]) / len(stats_data["cpu"])
                    max_cpu = max(stats_data["cpu"])
                    avg_mem = sum(stats_data["memory"]) / len(stats_data["memory"])
                    max_mem = max(stats_data["memory"])

                    status = "TIMEOUT" if timed_out else "COMPLETED"
                    logger.info(
                        f"Container {container_name} [{status}] - "
                        f"Avg CPU: {avg_cpu:.1f}%, Max CPU: {max_cpu:.1f}%, "
                        f"Avg Memory: {avg_mem:.1f} MB, Max Memory: {max_mem:.1f} MB"
                    )

        if timed_out:
            logger.warn(f"Container {container_name} was terminated due to timeout")

    @keyword
    def run_container(
        self,
        image: str,
        name: str = None,
        entrypoint: str = None,
        command: List[str] = None,
        environment: Dict = {},
        volumes: List = [],
        detach: bool = False,
        monitor: bool = False,
        timeout: int = None,
        suite_name: str = None,
        test_name: str = None,
        cap_add: List[str] = None,
    ):
        """Run a container with optional CPU and memory monitoring and timeout.

        Args:
            image: Container image to run
            name: Optional container name
            entrypoint: Optional entrypoint override
            command: Optional command to run
            environment: Environment variables
            volumes: Volume mounts
            detach: Run container in detached mode
            monitor: Enable CPU and memory monitoring with chart generation
            timeout: Optional timeout in seconds. Container will be stopped if it runs longer.
            suite_name: Optional suite name for organizing artifacts in bender/artifacts/<suite>/<test>/
            test_name: Optional test name for organizing artifacts in bender/artifacts/<suite>/<test>/
            cap_add: Linux capabilities to add (e.g., ["NET_ADMIN", "SYS_TIME"])

        Returns:
            Container object or string (output) depending on detach parameter

        Raises:
            Exception: If container times out and fails to stop gracefully
        """
        # Generate a container name if not provided, needed for monitoring/timeout
        if name is None and (monitor or timeout):
            container_name = f"robot-container-{uuid.uuid4().hex[:8]}"
        else:
            container_name = name

        # If monitoring or timeout is enabled, we need to run detached
        # so we can monitor in real-time and apply timeout
        use_detach = detach or monitor or (timeout is not None)
        original_detach = detach

        result = rc(
            image,
            name=container_name,
            entrypoint=entrypoint,
            command=command,
            network="neuronsphere_default",
            environment=environment,
            volumes=volumes,
            detach=use_detach,
            cap_add=cap_add,
        )

        # If no monitoring or timeout, return immediately
        if not monitor and timeout is None:
            return result

        # Get the actual container object for monitoring/timeout operations
        try:
            container = self.docker_client.containers.get(container_name)
        except docker.errors.NotFound:
            logger.warn(f"Container {container_name} not found for monitoring/timeout")
            return result

        timed_out = False
        stats_data = None
        stop_event = None
        monitor_thread = None

        # If user wants detached mode, return immediately (with monitoring running in background if enabled)
        if original_detach:
            if monitor or timeout:
                logger.info(
                    f"Container {container_name} running in detached mode with background monitoring/timeout"
                )
                stats_data = {
                    "timestamps": [],
                    "cpu": [],
                    "memory": [],
                    "memory_limit": 0,
                }
                stop_event = threading.Event()

                # Start monitoring thread if enabled
                if monitor:
                    monitor_thread = threading.Thread(
                        target=self._monitor_container,
                        args=(container.id, stats_data, stop_event),
                        daemon=True,
                    )
                    monitor_thread.start()

                # Start background thread to wait for container and generate charts
                background_thread = threading.Thread(
                    target=self._background_monitor_and_chart,
                    args=(
                        container,
                        container_name,
                        stats_data,
                        stop_event,
                        timeout,
                        suite_name,
                        test_name,
                    ),
                    daemon=True,
                )
                background_thread.start()

                if monitor:
                    logger.info(
                        "Monitoring charts will be generated in background when container completes"
                    )
                if timeout:
                    logger.info(
                        f"Timeout of {timeout} seconds will be enforced in background"
                    )
            return container

        # User wants blocking mode - wait for container and generate charts
        # Start monitoring if enabled
        if monitor:
            logger.info(f"Monitoring enabled for container: {container_name}")

            stats_data = {
                "timestamps": [],
                "cpu": [],
                "memory": [],
                "memory_limit": 0,
            }

            stop_event = threading.Event()
            monitor_thread = threading.Thread(
                target=self._monitor_container,
                args=(container.id, stats_data, stop_event),
                daemon=True,
            )
            monitor_thread.start()

        # Wait for container to finish
        try:
            if timeout:
                logger.info(
                    f"Container {container_name} timeout set to {timeout} seconds"
                )
                container.wait(timeout=timeout)
            else:
                container.wait()
        except Exception as e:
            # Timeout or other error occurred
            timed_out = True
            logger.warn(
                f"Container {container_name} exceeded timeout of {timeout} seconds. Stopping container..."
            )
            try:
                container.stop(timeout=10)
                logger.info(f"Container {container_name} stopped successfully")
            except Exception as stop_error:
                logger.error(f"Failed to stop container {container_name}: {stop_error}")
                try:
                    container.kill()
                    logger.warn(f"Container {container_name} killed forcefully")
                except Exception as kill_error:
                    logger.error(
                        f"Failed to kill container {container_name}: {kill_error}"
                    )
        finally:
            # Stop monitoring thread if it was started
            if stop_event and monitor_thread:
                stop_event.set()
                monitor_thread.join(timeout=5)

        # Generate and log charts if monitoring was enabled
        if monitor and stats_data:
            output_dir = Path("../bender")
            cpu_chart, memory_chart, json_path = self._generate_usage_charts(
                container_name, stats_data, output_dir, suite_name, test_name
            )

            if cpu_chart and memory_chart:
                logger.info(f"Usage charts saved to: {cpu_chart.parent.absolute()}")
                self._log_charts_to_robot(cpu_chart, memory_chart)

                # Log statistics summary
                if stats_data["cpu"]:
                    avg_cpu = sum(stats_data["cpu"]) / len(stats_data["cpu"])
                    max_cpu = max(stats_data["cpu"])
                    avg_mem = sum(stats_data["memory"]) / len(stats_data["memory"])
                    max_mem = max(stats_data["memory"])

                    status = "TIMEOUT" if timed_out else "COMPLETED"
                    logger.info(
                        f"Container {container_name} [{status}] - "
                        f"Avg CPU: {avg_cpu:.1f}%, Max CPU: {max_cpu:.1f}%, "
                        f"Avg Memory: {avg_mem:.1f} MB, Max Memory: {max_mem:.1f} MB"
                    )

        if timed_out:
            logger.warn(f"Container {container_name} was terminated due to timeout")

        # User wanted blocking mode, return logs as string
        try:
            logs = container.logs(stdout=True, stderr=True).decode("utf-8")
            # Remove the container if it was auto-created
            if name is None:
                try:
                    container.remove()
                except Exception:
                    pass
            return logs
        except Exception as e:
            logger.error(f"Failed to get container logs: {e}")
            return container

    @keyword
    def run_transform_container(
        self,
        image: str,
        context: Dict,
        environment: Dict = {},
        volumes: List = [],
        monitor: bool = False,
        timeout: int = None,
    ):
        """Run a transform container with optional monitoring and timeout.

        Args:
            image: Container image to run
            context: Transform context
            environment: Environment variables
            volumes: Volume mounts
            monitor: Enable CPU and memory monitoring with chart generation
            timeout: Optional timeout in seconds. Container will be stopped if it runs longer.
        """
        volumes.append((os.environ["HMD_REPO_PATH"], "/hmd_transform/input"))
        volumes.append((os.environ["HMD_REPO_PATH"], "/hmd_transform/output"))

        environment["TRANSFORM_INSTANCE_CONTEXT"] = context

        return self.run_container(
            image=image,
            environment=environment,
            volumes=volumes,
            detach=False,
            monitor=monitor,
            timeout=timeout,
        )

    @keyword
    def stop_container(self, container):
        """Stop a running container."""
        kill_container(container)

    @keyword
    def exec_container(
        self,
        container,
        command: List[str],
        user: str = None,
        workdir: str = None,
        environment: Dict = None,
        detach: bool = False,
        tty: bool = False,
        privileged: bool = False,
    ):
        """Execute a command in a running container.

        This keyword wraps docker exec functionality, allowing you to run commands
        inside an already running container.

        Args:
            container: Container object or name/ID returned from Run Container
            command: Command to execute as a list (e.g., ["ls", "-la", "/tmp"])
            user: Optional user to run the command as (e.g., "root")
            workdir: Optional working directory for the command
            environment: Optional environment variables as dictionary
            detach: Run command in detached mode (default: False)
            tty: Allocate a pseudo-TTY (default: False)
            privileged: Run command with elevated privileges (default: False)

        Returns:
            Command output string (if not detached) or None (if detached)

        Examples:
            | ${output}= | Exec Container | ${container} | ["ls", "-la"] |
            | ${output}= | Exec Container | ${container} | ["cat", "/etc/hosts"] | user=root |
            | Exec Container | ${container} | ["touch", "/tmp/test"] | detach=${True} |
        """
        # Pass container directly - the underlying function handles conversion
        return ec(
            container=container,
            command=command,
            user=user,
            workdir=workdir,
            environment=environment,
            detach=detach,
            tty=tty,
            privileged=privileged,
        )
