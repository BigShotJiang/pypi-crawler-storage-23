"""
Attestant: Unified Compliance Platform for Regulated ML

Quick pass/fail after training — full details on the dashboard::

    import attestant
    attestant.configure(api_key="pvt_live_...")

    clf = GradientBoostingClassifier()
    clf.fit(X_train, y_train)

    result = attestant.validate(
        model=clf,
        X_test=X_test,
        y_test=y_test,
        protected_df=demographics_test,
        protected_columns=["age", "race", "gender"],
    )

    if result.approved:
        print(f"APPROVED (score: {result.compliance_score}/100)")
    else:
        print(f"BLOCKED: {result.reason}")

    print(f"Full report: {result.dashboard_url}")

Wrap for ongoing inference monitoring::

    model = attestant.wrap(clf, model_name="loan_approval",
                           protected_columns=["age", "race", "gender"])
    preds = model.predict(X_new, protected_df=demographics_new)

    # Results at: https://getattestant.com/client/

Check connectivity::

    info = attestant.status()
    # info.connected → True
    # info.version → "1.0.0"

Dashboard: https://getattestant.com/client/
Full docs: https://attestant.ai/docs
"""

import logging
import os
import threading
import time
import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

__version__ = "0.13.1"

__all__ = [
    "__version__",
    "configure",
    "validate",
    "status",
    "wrap",
    "log_inference",
    "setup_logging",
    "ValidationResult",
    "StatusInfo",
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Result from ``attestant.validate()`` or ``model.result``.

    Quick pass/fail — see the dashboard for full details.
    """
    approved: bool
    compliance_score: float
    findings: List[str]
    dashboard_url: str
    model_id: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    protected_isolation_verified: Optional[bool] = None
    protected_in_model: List[str] = field(default_factory=list)
    profile_used: Optional[str] = None
    regulations_run: List[str] = field(default_factory=list)

    @property
    def reason(self) -> str:
        """Human-readable explanation of why the model was blocked."""
        if self.approved:
            return "Model approved for deployment"
        return "%d finding(s) — review on dashboard: %s" % (
            len(self.findings), self.dashboard_url,
        )

    def __bool__(self) -> bool:
        return self.approved

    def __repr__(self) -> str:
        status = "APPROVED" if self.approved else "BLOCKED"
        return "ValidationResult(%s, score=%.0f, findings=%d)" % (
            status, self.compliance_score, len(self.findings),
        )


@dataclass
class StatusInfo:
    """Result from ``attestant.status()``.

    Truthy when the service is reachable.
    """
    connected: bool
    version: str = ""
    latency_ms: float = 0.0
    error: str = ""

    def __bool__(self) -> bool:
        return self.connected

    def __repr__(self) -> str:
        if self.connected:
            return "StatusInfo(connected=True, version=%r, latency_ms=%.0f)" % (
                self.version, self.latency_ms,
            )
        return "StatusInfo(connected=False, error=%r)" % self.error


# ---------------------------------------------------------------------------
# Global configuration
# ---------------------------------------------------------------------------

_API_KEY: Optional[str] = None
_SERVICE_URL: str = os.environ.get("ATTESTANT_SERVICE_URL", "https://getattestant.com")

_logger = logging.getLogger(__name__)


def configure(api_key: str, service_url: str = "https://getattestant.com") -> None:
    """
    Configure Attestant with your API key.

    Call this once at application startup, before any calls to ``validate()``,
    ``wrap()``, or ``log_inference()``.

    Parameters
    ----------
    api_key : str
        Your Attestant API key (copy from the dashboard → Settings).
    service_url : str, optional
        Attestant service URL. Defaults to the hosted service.

    Example::

        import attestant
        attestant.configure(api_key="pvt_live_...")
    """
    global _API_KEY, _SERVICE_URL
    _API_KEY = api_key
    _SERVICE_URL = service_url.rstrip("/")
    # Also export to environment so sub-processes can inherit config
    os.environ["ATTESTANT_API_KEY"] = api_key
    os.environ["ATTESTANT_SERVICE_URL"] = _SERVICE_URL


# ---------------------------------------------------------------------------
# validate() — synchronous golden path
# ---------------------------------------------------------------------------

def validate(
    model: Any,
    X_test: Any,
    y_test: Any,
    protected_df: Any,
    protected_columns: List[str],
    model_name: str = "model",
    model_version: str = "1.0.0",
    protected_column_types: Optional[Dict[str, str]] = None,
    compliance_profile: Optional[str] = None,
    di_threshold: Optional[float] = None,
    regulations: Optional[List[str]] = None,
    taint_risks: Optional[Dict[str, float]] = None,
    **metadata,
) -> ValidationResult:
    """
    Validate a trained model for compliance, fairness, and deployment readiness.

    Sends the model and evaluation data to the Attestant service
    **synchronously**. The server runs predictions on X_test, compares
    outcomes across protected groups in protected_df, and returns a
    pass/fail with a dashboard URL for full details.

    You are not responsible for storing training data — only evaluation
    data is needed. If protected attributes flow into the model as
    features, that shows up in the predictions automatically.

    Parameters
    ----------
    model : Any
        A **trained** ML model (scikit-learn, XGBoost, LightGBM, etc.).
    X_test : array-like
        Evaluation/holdout features.
    y_test : array-like
        Evaluation/holdout labels (ground truth).
    protected_df : DataFrame
        Protected attributes (age, race, gender, …) aligned row-for-row
        with X_test. **Required** — the system needs to know which
        demographic group each row belongs to for fairness analysis.
    protected_columns : list of str
        Column names in ``protected_df`` to use for fairness analysis,
        e.g. ``["age", "race", "gender"]``.
    model_name : str
        Display name shown in the dashboard.
    model_version : str
        Version string, e.g. ``"2.0"``.
    protected_column_types : dict, optional
        Override automatic age-column detection for columns with non-standard
        names. Map column name → semantic type. Supported types:

        - ``"age"``         — numeric age in years (default for most columns)
        - ``"age_months"``  — age expressed in months, auto-divided by 12
        - ``"birth_year"``  — 4-digit year of birth, auto-converted to age
        - ``"dob"``         — date-of-birth string (ISO or MM/DD/YYYY)

        Example::

            protected_column_types={"applicant_months_old": "age_months"}

    **metadata
        Optional key-value pairs attached to this model in the dashboard.

    Returns
    -------
    ValidationResult
        Quick pass/fail, compliance score, findings list, and dashboard URL.
        Use ``result.dashboard_url`` to review full details.

    Raises
    ------
    ConnectionError
        If the Attestant service is unreachable.
    RuntimeError
        If the server returns an error.
    ValueError
        If ``configure()`` has not been called.

    Example::

        result = attestant.validate(
            model=clf,
            X_test=X_test,
            y_test=y_test,
            protected_df=demographics_test,
            protected_columns=["age", "race", "gender"],
        )

        if result.approved:
            print(f"APPROVED (score: {result.compliance_score}/100)")
        else:
            print(f"BLOCKED: {result.reason}")

        print(f"Full report: {result.dashboard_url}")
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before validate(). "
            "Get your API key from the dashboard → Settings."
        )

    import base64
    import pickle
    from .wrapper import _serialize, _post_json

    # Serialize model
    model_b64 = base64.b64encode(pickle.dumps(model)).decode("utf-8")

    payload = {
        "model_name": model_name,
        "model_version": model_version,
        "model_b64": model_b64,
        "model_serialization_method": "pickle",
        "X_test": _serialize(X_test),
        "y_test": _serialize(y_test),
        "protected_data": _serialize(protected_df),
        "protected_columns": list(protected_columns),
        "metadata": metadata,
    }
    if protected_column_types:
        payload["protected_column_types"] = protected_column_types
    if compliance_profile is not None:
        payload["compliance_profile"] = compliance_profile
    if di_threshold is not None:
        payload["di_threshold"] = di_threshold
    if regulations is not None:
        payload["regulations"] = regulations
    if taint_risks:
        payload["taint_risks"] = taint_risks

    url = "%s/v1/training" % _SERVICE_URL

    try:
        resp = _post_json(url, _API_KEY, payload)
    except urllib.error.URLError as e:
        raise ConnectionError(
            "Could not reach Attestant service at %s: %s" % (_SERVICE_URL, e)
        ) from e

    # Parse response into ValidationResult
    approved = resp.get("deployment_approved", False)
    compliance_score = float(resp.get("compliance_score", 0))
    findings = resp.get("findings", [])
    dashboard_url = resp.get("dashboard_url", "%s/client/models/%s" % (_SERVICE_URL, model_name))
    model_id = resp.get("model_id", "")
    isolation_verified = resp.get("protected_isolation_verified")
    in_model = resp.get("protected_in_model", [])

    result = ValidationResult(
        approved=approved,
        compliance_score=compliance_score,
        findings=findings,
        dashboard_url=dashboard_url,
        model_id=model_id,
        details=resp,
        protected_isolation_verified=isolation_verified,
        protected_in_model=in_model,
        profile_used=resp.get("profile_used"),
        regulations_run=resp.get("regulations_run", []),
    )

    # Store row-level provenance (pipeline + nodes + cell values)
    try:
        from .wrapper import _run_validate_provenance
        _run_validate_provenance(
            X=X_test,
            y=y_test,
            protected_data=protected_df,
            protected_columns=list(protected_columns),
            model_name=model_name,
            model_version=model_version,
            api_key=_API_KEY,
            service_url=_SERVICE_URL,
            model_id=model_id,
        )
    except Exception as _prov_err:
        _logger.error("[attestant] validate() provenance upload failed: %s", _prov_err)

    if isolation_verified is False and in_model:
        _logger.warning(
            "[attestant] protected_columns %s found in X_test — pass via protected_df only",
            in_model,
        )

    return result


# ---------------------------------------------------------------------------
# status() — connectivity check
# ---------------------------------------------------------------------------

def status() -> StatusInfo:
    """
    Check connectivity to the Attestant service.

    Calls ``/v1/health`` (unauthenticated). Never raises — returns
    ``StatusInfo(connected=False, error="...")`` on failure.

    Returns
    -------
    StatusInfo
        Connection status, server version, and round-trip latency.

    Example::

        info = attestant.status()
        if info.connected:
            print(f"Attestant v{info.version} ({info.latency_ms:.0f}ms)")
        else:
            print(f"Cannot reach service: {info.error}")
    """
    url = "%s/v1/health" % _SERVICE_URL
    start = time.monotonic()
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        elapsed = (time.monotonic() - start) * 1000
        return StatusInfo(
            connected=True,
            version=data.get("version", ""),
            latency_ms=round(elapsed, 1),
        )
    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        return StatusInfo(
            connected=False,
            latency_ms=round(elapsed, 1),
            error=str(e),
        )


# ---------------------------------------------------------------------------
# wrap()
# ---------------------------------------------------------------------------

def wrap(
    model: Any,
    model_name: str,
    protected_columns: List[str],
    model_version: str = "1.0.0",
    **metadata,
):
    """
    Wrap a model to automatically track training and inference with Attestant.

    The wrapped model is a drop-in replacement — it accepts all the same
    arguments, returns all the same values, and exposes all the same
    attributes as the original. Attestant captures data in a background
    thread without blocking your pipeline.

    Parameters
    ----------
    model : Any
        Your ML model (scikit-learn, XGBoost, LightGBM, PyTorch, etc.)
    model_name : str
        Display name shown in the dashboard, e.g. ``"loan_approval"``.
    protected_columns : list of str
        Protected attribute column names for fairness analysis,
        e.g. ``["age", "race", "gender"]``.
        These are used for monitoring only — never as model input features.
    model_version : str, optional
        Version string, e.g. ``"2.1.0"`` (default ``"1.0.0"``).
    **metadata
        Optional key-value pairs attached to this model in the dashboard.

    Returns
    -------
    ModelWrapper
        A wrapper that behaves exactly like the original model.

    Example — simple case (protected columns already in X)::

        model = attestant.wrap(
            GradientBoostingClassifier(),
            model_name="loan_approval",
            protected_columns=["age", "race", "gender"],
        )
        model.fit(X_train, y_train)        # age/race/gender auto-extracted
        preds = model.predict(X_test)

    Example — ECOA / Reg B pattern (protected columns NOT in X)::

        model = attestant.wrap(
            GradientBoostingClassifier(),
            model_name="loan_approval",
            protected_columns=["age", "race", "gender"],
        )
        model.fit(X_train, y_train, protected_df=demographics_train)
        preds = model.predict(X_test, protected_df=demographics_test)

    Example — real-time single decision::

        pred = model.predict(
            applicant_features,
            protected_df={"age": 34, "race": "White", "gender": "M"},
        )

    Notes
    -----
    Call :func:`flush` before your script exits to ensure all uploads
    complete before the daemon thread is killed::

        model.flush()

    After ``flush()``, check ``model.result`` for compliance results::

        model.flush()
        if model.result:
            print(model.result.dashboard_url)
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before wrap(). "
            "Get your API key from the dashboard → Settings."
        )

    from .wrapper import ModelWrapper

    return ModelWrapper(
        model=model,
        model_name=model_name,
        protected_columns=protected_columns,
        api_key=_API_KEY,
        service_url=_SERVICE_URL,
        model_version=model_version,
        **metadata,
    )


def log_inference(
    model_name: str,
    predictions: Any,
    X: Any = None,
    protected_df: Any = None,
    protected_columns: Optional[List[str]] = None,
    model_version: str = "1.0.0",
) -> None:
    """
    Log inference results for an existing deployed model.

    Use this when you cannot (or do not want to) rewrap the model — for
    example, a scoring pipeline that calls an external model API, a
    pre-compiled binary, or a model deployed as a microservice.

    Unlike ``wrap()``, this is a fire-and-forget call: it enqueues the data
    in a daemon thread and returns immediately. Use ``log_inference_sync()``
    if you need a blocking call.

    Parameters
    ----------
    model_name : str
        Name matching the model registered in the Attestant dashboard.
    predictions : array-like
        Model output — binary predictions, probabilities, or scores.
    X : array-like, optional
        Input features used to produce the predictions. Used for feature
        distribution monitoring and drift detection.
    protected_df : DataFrame or dict, optional
        Protected attributes (age, race, gender, …) for fairness monitoring.
        Provide a DataFrame aligned row-for-row with ``predictions``, or a
        single ``dict`` for one-record logging.
    protected_columns : list of str, optional
        Column names to extract from ``X`` when ``protected_df`` is not
        provided. Ignored if ``protected_df`` is passed explicitly.
    model_version : str, optional
        Version string (default ``"1.0.0"``).

    Example — batch scoring pipeline::

        import attestant
        attestant.configure(api_key="pvt_live_...")

        # Your existing deployed model
        preds = deployed_model.score(batch_features)

        attestant.log_inference(
            model_name="loan_approval",
            predictions=preds,
            X=batch_features,
            protected_df=demographics_df,
            protected_columns=["age", "race", "gender"],
        )

    Example — single real-time decision::

        attestant.log_inference(
            model_name="loan_approval",
            predictions=[1],
            X=applicant_features,
            protected_df={"age": 34, "race": "White", "gender": "M"},
        )
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before log_inference()."
        )

    # Capture at call time — globals could change before the thread runs
    api_key = _API_KEY
    service_url = _SERVICE_URL

    def _send() -> None:
        try:
            from datetime import datetime
            from .wrapper import _serialize, _resolve_protected, _post_json

            batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            resolved = _resolve_protected(X, protected_df, protected_columns)

            payload = {
                "model_name":        model_name,
                "model_version":     model_version,
                "X_production":      _serialize(X),
                "predictions":       _serialize(predictions),
                "protected_data":    _serialize(resolved),
                "protected_columns": list(protected_columns or []),
                "batch_id":          batch_id,
                "metadata":          {},
            }
            _post_json(f"{service_url}/v1/inference", api_key, payload)
        except Exception as e:
            _logger.error(
                f"[attestant] log_inference upload failed for '{model_name}': {e}"
            )

    threading.Thread(
        target=_send, daemon=True, name=f"attestant-log-{model_name}"
    ).start()


# ---------------------------------------------------------------------------
# Production logging setup
# ---------------------------------------------------------------------------

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """
    Configure structured logging for all ``attestant.*`` loggers.

    Compatible with Splunk, ELK, Datadog, and CloudWatch Logs.

    Parameters
    ----------
    level : str
        Log level: ``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``.
    fmt : str
        ``"json"`` for structured JSON lines (default, recommended for
        production), or ``"text"`` for human-readable output.
    include_timestamp : bool
        Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging as _logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(_logging, level.upper(), _logging.INFO)

    class _JSONFormatter(_logging.Formatter):
        def format(self, record: _logging.LogRecord) -> str:
            entry: dict = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(_logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root = _logging.getLogger("attestant")
    root.setLevel(numeric_level)
    root.handlers.clear()

    handler = _logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)
    handler.setFormatter(
        _JSONFormatter() if fmt == "json" else _TextFormatter(with_ts=include_timestamp)
    )
    root.addHandler(handler)
