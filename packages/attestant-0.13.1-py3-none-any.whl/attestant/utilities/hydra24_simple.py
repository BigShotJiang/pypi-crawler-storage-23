"""
HYDRA-24 Enhanced: Full provenance tracking with entity and chain_hash.

Uses flat 9-bit pair IDs (0-511) with tiered precision for extended metadata.
100% accurate pair tracking + row identification + computation path tracking.

24-bit provenance layout (tiered precision):

  Mode 00 (0-1 pairs, ~80% of data): Maximum precision
  ├── mode:        2 bits
  ├── pair_data:  10 bits (0=none, 1-512=single pair, EXACT)
  ├── entity:      6 bits (64 buckets, ~1.5% collision)
  └── chain:       6 bits (64 buckets, ~1.5% collision)

  Mode 01 (2 pairs, ~15% of data): Medium precision
  ├── mode:        2 bits
  ├── pair_index: 17 bits (combinatorial encoding, EXACT)
  ├── entity:      3 bits (8 buckets, ~12% collision)
  └── chain:       2 bits (4 buckets, ~25% collision)

  Mode 11 (3+ pairs, ~5% of data): Pairs only
  ├── mode:        2 bits
  └── signature:  22 bits (registry lookup, EXACT pairs)
  // Entity/chain stored in registry metadata

Usage:
    from attestant.hydra24_simple import ProvenanceTracker

    tracker = ProvenanceTracker()

    # Register any (table, column) - returns pair_id 0-511
    pid1 = tracker.register("users.csv", "email")
    pid2 = tracker.register("users.csv", "name")

    # Encode provenance with entity and chain
    prov = tracker.encode({pid1}, entity=42, chain=0)

    # Decode full provenance
    pairs, entity, chain = tracker.decode_full(prov)

    # Human-readable explanation
    info = tracker.explain_full(prov)
    # {'pairs': [('users.csv', 'email')], 'entity': 42, 'chain': 0, 'mode': 'EXACT-1'}
"""

from dataclasses import dataclass, field
from typing import Dict, Set, List, Tuple, Optional, FrozenSet, Any, NamedTuple
import numpy as np
import pandas as pd


# =============================================================================
# Constants
# =============================================================================

MAX_PAIRS = 512  # 9-bit pair IDs

# Mode bits
MODE_01 = 0b00   # 0-1 pairs: 10 bits pair + 6 entity + 6 chain
MODE_2 = 0b01    # 2 pairs: 17 bits combinatorial + 3 entity + 2 chain
MODE_DENSE = 0b11  # 3+ pairs: 22 bits registry signature

# Bit allocations per mode
MODE_01_PAIR_BITS = 10     # 0-1023, but we use 0-512
MODE_01_ENTITY_BITS = 6    # 64 buckets
MODE_01_CHAIN_BITS = 6     # 64 buckets

MODE_2_PAIR_BITS = 17      # Enough for C(512,2) = 130,816
MODE_2_ENTITY_BITS = 3     # 8 buckets
MODE_2_CHAIN_BITS = 2      # 4 buckets

MODE_DENSE_SIG_BITS = 22   # Registry signature


# =============================================================================
# Operation Codes for Chain Hash
# =============================================================================

class OpCode:
    """Operation codes for chain hash computation."""
    RAW = 0        # Raw data from source
    ADD = 1        # Addition
    SUB = 2        # Subtraction
    MUL = 3        # Multiplication
    DIV = 4        # Division
    NEG = 5        # Negation
    CLIP = 6       # Clipping
    FILL = 7       # Fill NA
    MAP = 8        # Mapping
    CMP = 9        # Comparison
    MERGE = 10     # Merge/join
    AGG = 11       # Aggregation
    CUSTOM = 15    # Custom operation


# =============================================================================
# Provenance Result Types
# =============================================================================

class ProvenanceInfo(NamedTuple):
    """Full decoded provenance information."""
    pairs: Set[int]
    entity: int
    chain: int
    mode: str


# =============================================================================
# Core Encoding Functions
# =============================================================================

def _binomial(n: int, k: int) -> int:
    """Compute C(n, k)."""
    if k < 0 or k > n:
        return 0
    if k == 0 or k == n:
        return 1
    k = min(k, n - k)
    result = 1
    for i in range(k):
        result = result * (n - i) // (i + 1)
    return result


def _encode_pair_01(pairs: Set[int]) -> int:
    """Encode 0-1 pairs to 10 bits. Returns 0 for empty, 1+pair_id for single."""
    if len(pairs) == 0:
        return 0
    if len(pairs) == 1:
        return 1 + next(iter(pairs))
    raise ValueError("_encode_pair_01 only handles 0-1 pairs")


def _decode_pair_01(data: int) -> Set[int]:
    """Decode 10-bit data to 0-1 pairs."""
    if data == 0:
        return set()
    return {data - 1}


def _encode_pair_2(pairs: Set[int]) -> int:
    """Encode exactly 2 pairs using combinatorial index (17 bits)."""
    if len(pairs) != 2:
        raise ValueError("_encode_pair_2 requires exactly 2 pairs")

    sorted_pairs = sorted(pairs)
    p0, p1 = sorted_pairs
    # Combinatorial number: C(p0, 1) + C(p1, 2) gives unique index
    return _binomial(p0, 1) + _binomial(p1, 2)


def _decode_pair_2(index: int) -> Set[int]:
    """Decode combinatorial index to exactly 2 pairs."""
    # Find p1: largest value where C(p1, 2) <= index
    p1 = 1
    while _binomial(p1 + 1, 2) <= index:
        p1 += 1

    p0 = index - _binomial(p1, 2)
    return {p0, p1}


def _compute_signature(pairs: FrozenSet[int], entity: int = 0, chain: int = 0) -> int:
    """Compute 22-bit signature for registry lookup."""
    h = 0
    for p in sorted(pairs):
        h = ((h * 31) + p) & 0xFFFFFFFF

    # Include entity and chain in hash to differentiate same-pair sets
    h = ((h * 31) + entity) & 0xFFFFFFFF
    h = ((h * 31) + chain) & 0xFFFFFFFF

    # Finalize with avalanche
    h ^= h >> 16
    h = (h * 0x85EBCA6B) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * 0xC2B2AE35) & 0xFFFFFFFF
    h ^= h >> 16

    return h & 0x3FFFFF  # 22 bits


def _hash_entity(row_id: Any) -> int:
    """Hash a row identifier to entity bits."""
    if row_id is None:
        return 0
    h = hash(row_id) & 0xFFFFFFFF
    return h


def _combine_chains(chain_a: int, chain_b: int, op: int, bits: int) -> int:
    """Combine two chain hashes with an operation code."""
    # XOR the inputs, then roll in the operation
    combined = chain_a ^ chain_b
    result = ((combined * 31) + op) & 0xFFFFFFFF
    return result % (1 << bits)


def _update_chain(chain: int, op: int, bits: int) -> int:
    """Update chain hash with a unary operation."""
    result = ((chain * 31) + op) & 0xFFFFFFFF
    return result % (1 << bits)


# =============================================================================
# Registry Entry for Dense Mode
# =============================================================================

@dataclass
class DenseEntry:
    """Registry entry for 3+ pair provenances."""
    pairs: FrozenSet[int]
    entity: int
    chain: int


# =============================================================================
# Provenance Tracker (Unified Registry)
# =============================================================================

class ProvenanceTracker:
    """
    Enhanced provenance tracker with entity and chain_hash support.

    Provides:
    - 100% accurate pair tracking in all modes
    - Entity (row ID) tracking with tiered precision
    - Chain hash (computation path) tracking with tiered precision
    - Protected table detection for fairness auditing
    """

    def __init__(self):
        # Mapping table (bidirectional)
        self._id_to_name: Dict[int, Tuple[str, str]] = {}
        self._name_to_id: Dict[Tuple[str, str], int] = {}
        self._next_id = 0

        # Dense registry (for 3+ pairs)
        self._dense: Dict[int, DenseEntry] = {}

        # Protected tables and columns
        self._protected: Set[str] = set()
        self._protected_columns: Set[Tuple[str, str]] = set()

    # -------------------------------------------------------------------------
    # Registration
    # -------------------------------------------------------------------------

    def register(self, table: str, column: str, protected: bool = False) -> int:
        """Register a (table, column) pair and return its ID (0-511)."""
        key = (table, column)

        if key in self._name_to_id:
            return self._name_to_id[key]

        if self._next_id >= MAX_PAIRS:
            raise ValueError(f"Maximum {MAX_PAIRS} pairs supported")

        pair_id = self._next_id
        self._id_to_name[pair_id] = key
        self._name_to_id[key] = pair_id
        self._next_id += 1

        if protected is True:
            self._protected.add(table)
        elif protected:
            self._protected_columns.add((table, column))

        return pair_id

    def register_table(self, table: str, columns: List[str], protected: bool = False) -> List[int]:
        """Register all columns for a table. Returns list of pair IDs."""
        return [self.register(table, col, protected) for col in columns]

    def get_name(self, pair_id: int) -> Optional[Tuple[str, str]]:
        """Get (table, column) name for a pair ID."""
        return self._id_to_name.get(pair_id)

    def get_id(self, table: str, column: str) -> Optional[int]:
        """Get pair ID for a (table, column)."""
        return self._name_to_id.get((table, column))

    def is_protected(self, table: str, column: str = None) -> bool:
        """Check if a table or specific column is protected."""
        if table in self._protected:
            return True
        if column and (table, column) in self._protected_columns:
            return True
        return False

    # -------------------------------------------------------------------------
    # Encoding / Decoding
    # -------------------------------------------------------------------------

    def encode(self, pairs: Set[int], entity: int = 0, chain: int = 0) -> int:
        """
        Encode a set of pair IDs with entity and chain to 24-bit provenance.

        Args:
            pairs: Set of pair IDs (0-511)
            entity: Row identifier hash (will be truncated to fit mode)
            chain: Computation chain hash (will be truncated to fit mode)

        Returns:
            24-bit provenance value
        """
        n = len(pairs)

        if n <= 1:
            # Mode 00: 0-1 pairs with 6-bit entity and 6-bit chain
            pair_data = _encode_pair_01(pairs)
            entity_6 = entity % (1 << MODE_01_ENTITY_BITS)
            chain_6 = chain % (1 << MODE_01_CHAIN_BITS)

            # Layout: [2-bit mode=00 | 10-bit pair | 6-bit entity | 6-bit chain]
            return ((MODE_01 << 22) |
                    (pair_data << 12) |
                    (entity_6 << 6) |
                    chain_6)

        elif n == 2:
            # Mode 01: 2 pairs with 3-bit entity and 2-bit chain
            pair_data = _encode_pair_2(pairs)
            entity_3 = entity % (1 << MODE_2_ENTITY_BITS)
            chain_2 = chain % (1 << MODE_2_CHAIN_BITS)

            # Layout: [2-bit mode=01 | 17-bit pair_index | 3-bit entity | 2-bit chain]
            return ((MODE_2 << 22) |
                    (pair_data << 5) |
                    (entity_3 << 2) |
                    chain_2)

        else:
            # Mode 11: 3+ pairs, store full info in registry
            frozen = frozenset(pairs)
            sig = _compute_signature(frozen, entity, chain)

            # Store in registry
            self._dense[sig] = DenseEntry(pairs=frozen, entity=entity, chain=chain)

            # Layout: [2-bit mode=11 | 22-bit signature]
            return (MODE_DENSE << 22) | sig

    def decode(self, provenance: int) -> Set[int]:
        """Decode 24-bit provenance to set of pair IDs (legacy API)."""
        pairs, _, _ = self.decode_full(provenance)
        return pairs

    def decode_full(self, provenance: int) -> Tuple[Set[int], int, int]:
        """
        Decode 24-bit provenance to (pairs, entity, chain).

        Returns:
            (pairs, entity, chain) tuple
        """
        mode = (provenance >> 22) & 0b11

        if mode == MODE_01:
            # Mode 00: 0-1 pairs
            pair_data = (provenance >> 12) & 0x3FF  # 10 bits
            entity = (provenance >> 6) & 0x3F       # 6 bits
            chain = provenance & 0x3F               # 6 bits

            pairs = _decode_pair_01(pair_data)
            return (pairs, entity, chain)

        elif mode == MODE_2:
            # Mode 01: 2 pairs
            pair_data = (provenance >> 5) & 0x1FFFF  # 17 bits
            entity = (provenance >> 2) & 0x7         # 3 bits
            chain = provenance & 0x3                 # 2 bits

            pairs = _decode_pair_2(pair_data)
            return (pairs, entity, chain)

        elif mode == MODE_DENSE:
            # Mode 11: Registry lookup
            sig = provenance & 0x3FFFFF  # 22 bits

            entry = self._dense.get(sig)
            if entry:
                return (set(entry.pairs), entry.entity, entry.chain)
            return (set(), 0, 0)

        else:
            # Reserved mode 10
            return (set(), 0, 0)

    def get_mode(self, provenance: int) -> str:
        """Get the mode name for a provenance value."""
        mode = (provenance >> 22) & 0b11
        if mode == MODE_01:
            pairs = self.decode(provenance)
            return "EXACT-0" if len(pairs) == 0 else "EXACT-1"
        elif mode == MODE_2:
            return "EXACT-2"
        elif mode == MODE_DENSE:
            return "DENSE"
        return "UNKNOWN"

    def explain(self, provenance: int) -> List[Tuple[str, str]]:
        """Decode provenance to human-readable (table, column) names."""
        pairs = self.decode(provenance)
        result = []
        for pid in sorted(pairs):
            name = self.get_name(pid)
            if name:
                result.append(name)
        return result

    def explain_full(self, provenance: int) -> Dict[str, Any]:
        """Get full provenance explanation."""
        pairs, entity, chain = self.decode_full(provenance)
        names = [self.get_name(pid) for pid in sorted(pairs)]
        names = [n for n in names if n is not None]

        return {
            'pairs': names,
            'pair_ids': sorted(pairs),
            'entity': entity,
            'chain': chain,
            'mode': self.get_mode(provenance),
            'provenance_hex': f"0x{provenance:06X}",
        }

    def explain_tables(self, provenance: int) -> List[str]:
        """Get unique table names from provenance."""
        names = self.explain(provenance)
        seen: Dict[str, None] = {}
        for table, _ in names:
            seen.setdefault(table, None)
        return list(seen)

    def has_protected(self, provenance: int) -> bool:
        """Check if provenance uses any protected tables."""
        for table in self.explain_tables(provenance):
            if self.is_protected(table):
                return True
        return False

    # -------------------------------------------------------------------------
    # Provenance Operations
    # -------------------------------------------------------------------------

    def combine(self, prov_a: int, prov_b: int, op: int = OpCode.ADD) -> int:
        """
        Combine two provenances with an operation.

        - Pairs are unioned
        - Entities are XORed (to detect mixed sources)
        - Chains are combined with the operation code
        """
        if prov_a == 0:
            return prov_b
        if prov_b == 0:
            return prov_a

        pairs_a, entity_a, chain_a = self.decode_full(prov_a)
        pairs_b, entity_b, chain_b = self.decode_full(prov_b)

        combined_pairs = pairs_a | pairs_b
        combined_entity = entity_a ^ entity_b

        # Determine chain bits based on result mode
        n = len(combined_pairs)
        if n <= 1:
            chain_bits = MODE_01_CHAIN_BITS
        elif n == 2:
            chain_bits = MODE_2_CHAIN_BITS
        else:
            chain_bits = 16  # More precision in registry

        combined_chain = _combine_chains(chain_a, chain_b, op, chain_bits)

        return self.encode(combined_pairs, combined_entity, combined_chain)

    def update_chain(self, provenance: int, op: int) -> int:
        """Update a provenance's chain hash with a unary operation."""
        pairs, entity, chain = self.decode_full(provenance)

        n = len(pairs)
        if n <= 1:
            chain_bits = MODE_01_CHAIN_BITS
        elif n == 2:
            chain_bits = MODE_2_CHAIN_BITS
        else:
            chain_bits = 16

        new_chain = _update_chain(chain, op, chain_bits)
        return self.encode(pairs, entity, new_chain)

    def contains(self, provenance: int, pair_id: int) -> bool:
        """Check if a pair is in the provenance."""
        return pair_id in self.decode(provenance)

    def contains_table(self, provenance: int, table: str) -> bool:
        """Check if a table is in the provenance."""
        return table in self.explain_tables(provenance)

    # -------------------------------------------------------------------------
    # Entity Helpers
    # -------------------------------------------------------------------------

    def entity_from_row(self, row_id: Any) -> int:
        """Create entity hash from a row identifier."""
        return _hash_entity(row_id)

    # -------------------------------------------------------------------------
    # Stats
    # -------------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """Get tracker statistics."""
        return {
            'registered_pairs': self._next_id,
            'dense_entries': len(self._dense),
            'protected_tables': list(self._protected),
        }

    @property
    def mode_name(self):
        """Get mode name helper (legacy)."""
        return {MODE_01: "EXACT", MODE_2: "EXACT-2", MODE_DENSE: "DENSE"}


# =============================================================================
# Pandas Integration
# =============================================================================

class TrackedSeries(pd.Series):
    """Pandas Series with HYDRA-24 provenance including entity and chain."""

    _metadata = ['_prov', '_tracker']

    def __init__(self, *args, **kwargs):
        prov = kwargs.pop('_prov', None)
        tracker = kwargs.pop('_tracker', None)
        super().__init__(*args, **kwargs)
        self._prov = prov if prov is not None else np.zeros(len(self), dtype=np.uint32)
        self._tracker = tracker

    @property
    def _constructor(self):
        return TrackedSeries

    def _binop(self, other, op, op_code: int = OpCode.ADD):
        """Binary operation with provenance combination."""
        result_values = op(self.values, other.values if hasattr(other, 'values') else other)

        if isinstance(other, TrackedSeries) and self._tracker:
            # Combine provenance element-wise
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                pa = int(self._prov[i]) if i < len(self._prov) else 0
                pb = int(other._prov[i]) if i < len(other._prov) else 0
                new_prov[i] = self._tracker.combine(pa, pb, op_code)
            return TrackedSeries(result_values, index=self.index, _prov=new_prov, _tracker=self._tracker)
        else:
            return TrackedSeries(result_values, index=self.index, _prov=self._prov.copy(), _tracker=self._tracker)

    def _unop(self, op, op_code: int):
        """Unary operation with chain update."""
        result_values = op(self.values)

        if self._tracker:
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, op_code)
            return TrackedSeries(result_values, index=self.index, _prov=new_prov, _tracker=self._tracker)
        else:
            return TrackedSeries(result_values, index=self.index, _prov=self._prov.copy(), _tracker=self._tracker)

    def __add__(self, other): return self._binop(other, np.add, OpCode.ADD)
    def __sub__(self, other): return self._binop(other, np.subtract, OpCode.SUB)
    def __mul__(self, other): return self._binop(other, np.multiply, OpCode.MUL)
    def __truediv__(self, other): return self._binop(other, np.true_divide, OpCode.DIV)
    def __floordiv__(self, other): return self._binop(other, np.floor_divide, OpCode.DIV)
    def __pow__(self, other): return self._binop(other, np.power, OpCode.MUL)
    def __radd__(self, other): return self._binop(other, lambda a, b: np.add(b, a), OpCode.ADD)
    def __rsub__(self, other): return self._binop(other, lambda a, b: np.subtract(b, a), OpCode.SUB)
    def __rmul__(self, other): return self._binop(other, lambda a, b: np.multiply(b, a), OpCode.MUL)
    def __rtruediv__(self, other): return self._binop(other, lambda a, b: np.true_divide(b, a), OpCode.DIV)

    def __neg__(self):
        return self._unop(lambda x: -x, OpCode.NEG)

    def __gt__(self, other): return self._binop(other, lambda a, b: a > b, OpCode.CMP)
    def __lt__(self, other): return self._binop(other, lambda a, b: a < b, OpCode.CMP)
    def __ge__(self, other): return self._binop(other, lambda a, b: a >= b, OpCode.CMP)
    def __le__(self, other): return self._binop(other, lambda a, b: a <= b, OpCode.CMP)

    def clip(self, lower=None, upper=None, **kwargs):
        return self._unop(lambda x: np.clip(x, lower, upper), OpCode.CLIP)

    def fillna(self, value=0, **kwargs):
        result = super().fillna(value, **kwargs)
        if self._tracker:
            n = len(result)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, OpCode.FILL)
            return TrackedSeries(result.values, index=self.index, _prov=new_prov, _tracker=self._tracker)
        return TrackedSeries(result.values, index=self.index, _prov=self._prov.copy(), _tracker=self._tracker)

    def map(self, arg, **kwargs):
        result = super().map(arg, **kwargs)
        if self._tracker:
            n = len(result)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, OpCode.MAP)
            return TrackedSeries(result.values, index=self.index, _prov=new_prov, _tracker=self._tracker)
        return TrackedSeries(result.values, index=self.index, _prov=self._prov.copy(), _tracker=self._tracker)

    def replace(self, *args, **kwargs):
        result = super().replace(*args, **kwargs)
        if isinstance(result, pd.Series):
            if self._tracker:
                n = len(result)
                new_prov = np.zeros(n, dtype=np.uint32)
                for i in range(n):
                    p = int(self._prov[i]) if i < len(self._prov) else 0
                    new_prov[i] = self._tracker.update_chain(p, OpCode.MAP)
                return TrackedSeries(result.values, index=result.index, _prov=new_prov, _tracker=self._tracker)
            return TrackedSeries(result.values, index=result.index, _prov=self._prov.copy(), _tracker=self._tracker)
        return result


class TrackedDataFrame(pd.DataFrame):
    """Pandas DataFrame with HYDRA-24 provenance."""

    _metadata = ['_tracker', '_col_prov']

    def __init__(self, *args, **kwargs):
        tracker = kwargs.pop('_tracker', None)
        col_prov = kwargs.pop('_col_prov', None)
        super().__init__(*args, **kwargs)
        self._tracker = tracker
        self._col_prov = col_prov if col_prov is not None else {}

    @property
    def _constructor(self):
        return TrackedDataFrame

    @property
    def _constructor_sliced(self):
        return TrackedSeries

    def __getitem__(self, key):
        result = super().__getitem__(key)
        if isinstance(result, pd.Series) and key in self._col_prov:
            prov = self._col_prov[key]
            n = len(result)
            if len(prov) != n:
                prov = np.broadcast_to(prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n).copy()
            return TrackedSeries(result.values, index=result.index, _prov=prov.copy(), _tracker=self._tracker)
        elif isinstance(result, pd.Series):
            return TrackedSeries(result.values, index=result.index, _prov=np.zeros(len(result), dtype=np.uint32), _tracker=self._tracker)
        return result

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        if isinstance(value, TrackedSeries):
            self._col_prov[key] = value._prov.copy()

    def merge(self, right, *args, **kwargs):
        result = super().merge(right, *args, **kwargs)
        new_prov = {}
        n = len(result)

        for col, prov in self._col_prov.items():
            if col in result.columns:
                # Update chain to indicate merge operation
                if self._tracker and len(prov) > 0:
                    base_prov = int(prov[0])
                    merged_prov = self._tracker.update_chain(base_prov, OpCode.MERGE)
                    new_prov[col] = np.full(n, merged_prov, dtype=np.uint32)
                else:
                    new_prov[col] = np.broadcast_to(prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n).copy()

        if isinstance(right, TrackedDataFrame):
            for col, prov in right._col_prov.items():
                if col in result.columns and col not in new_prov:
                    if self._tracker and len(prov) > 0:
                        base_prov = int(prov[0])
                        merged_prov = self._tracker.update_chain(base_prov, OpCode.MERGE)
                        new_prov[col] = np.full(n, merged_prov, dtype=np.uint32)
                    else:
                        new_prov[col] = np.broadcast_to(prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n).copy()

        return TrackedDataFrame(result, _tracker=self._tracker, _col_prov=new_prov)


# =============================================================================
# Helper Functions
# =============================================================================

def wrap_dataframe(df: pd.DataFrame, tracker: ProvenanceTracker, table: str,
                   protected=False, include_entity: bool = True) -> TrackedDataFrame:
    """
    Wrap a DataFrame with provenance tracking.

    Args:
        df: DataFrame to wrap
        tracker: ProvenanceTracker instance
        table: Table name for provenance
        protected: True to mark entire table, or list of column names
                   to mark specific columns as protected.
        include_entity: Whether to include row entity hash (default True)
    """
    result = TrackedDataFrame(df, _tracker=tracker)
    n = len(df)

    if isinstance(protected, (list, tuple, set)):
        protected_cols = set(str(c) for c in protected)
    else:
        protected_cols = None

    for col in df.columns:
        col_protected = protected if protected_cols is None else (str(col) in protected_cols)
        pair_id = tracker.register(table, str(col), col_protected)

        # Create per-row provenance with entity hash
        prov_array = np.zeros(n, dtype=np.uint32)
        for i in range(n):
            entity = tracker.entity_from_row(df.index[i]) if include_entity else 0
            # Truncate to 6 bits for mode 00
            entity_6 = entity % (1 << MODE_01_ENTITY_BITS)
            prov_array[i] = tracker.encode({pair_id}, entity=entity_6, chain=0)

        result._col_prov[col] = prov_array

    return result


def audit(series: TrackedSeries) -> Dict[str, Any]:
    """Audit a series for provenance information."""
    if not series._tracker or len(series) == 0:
        return {'error': 'No tracker or empty series'}

    prov = int(series._prov[0])
    tracker = series._tracker

    pairs, entity, chain = tracker.decode_full(prov)
    names = tracker.explain(prov)
    tables = tracker.explain_tables(prov)

    return {
        'provenance': f"0x{prov:06X}",
        'mode': tracker.get_mode(prov),
        'pair_count': len(pairs),
        'pair_ids': sorted(pairs),
        'columns': names,
        'tables': tables,
        'entity': entity,
        'chain': chain,
        'has_protected': tracker.has_protected(prov),
    }


def audit_series_diversity(series: TrackedSeries) -> Dict[str, Any]:
    """Analyze provenance diversity across a series (useful for debugging)."""
    if not series._tracker or len(series) == 0:
        return {'error': 'No tracker or empty series'}

    tracker = series._tracker

    unique_provs = set(int(p) for p in series._prov)
    unique_pairs = set()
    unique_entities = set()
    unique_chains = set()

    for prov in unique_provs:
        pairs, entity, chain = tracker.decode_full(prov)
        unique_pairs.update(pairs)
        unique_entities.add(entity)
        unique_chains.add(chain)

    return {
        'total_rows': len(series),
        'unique_provenances': len(unique_provs),
        'unique_pair_sets': len(unique_pairs),
        'unique_entities': len(unique_entities),
        'unique_chains': len(unique_chains),
        'entity_diversity': len(unique_entities) / len(series) if len(series) > 0 else 0,
    }
