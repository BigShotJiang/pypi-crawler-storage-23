//! # AutogradResourceManager - Trait Implementations
//!
//! This module contains trait implementations for `AutogradResourceManager`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::AutogradResourceManager;

impl Default for AutogradResourceManager {
    fn default() -> Self {
        Self::new()
    }
}
