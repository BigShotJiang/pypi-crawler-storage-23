//! # ComputationGraphManager - Trait Implementations
//!
//! This module contains trait implementations for `ComputationGraphManager`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ComputationGraphManager;

impl Default for ComputationGraphManager {
    fn default() -> Self {
        Self::new()
    }
}
