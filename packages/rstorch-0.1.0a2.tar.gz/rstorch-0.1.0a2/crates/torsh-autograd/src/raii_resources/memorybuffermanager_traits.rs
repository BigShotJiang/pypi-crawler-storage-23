//! # MemoryBufferManager - Trait Implementations
//!
//! This module contains trait implementations for `MemoryBufferManager`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::MemoryBufferManager;

impl Default for MemoryBufferManager {
    fn default() -> Self {
        Self::new()
    }
}
