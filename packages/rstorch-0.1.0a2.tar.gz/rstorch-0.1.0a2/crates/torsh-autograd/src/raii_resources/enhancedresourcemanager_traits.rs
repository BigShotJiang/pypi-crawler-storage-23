//! # EnhancedResourceManager - Trait Implementations
//!
//! This module contains trait implementations for `EnhancedResourceManager`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::EnhancedResourceManager;

impl Default for EnhancedResourceManager {
    fn default() -> Self {
        Self::new()
    }
}
