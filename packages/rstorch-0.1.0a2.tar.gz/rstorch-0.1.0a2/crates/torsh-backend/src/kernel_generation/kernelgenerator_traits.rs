//! # KernelGenerator - Trait Implementations
//!
//! This module contains trait implementations for `KernelGenerator`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::KernelGenerator;

impl Default for KernelGenerator {
    fn default() -> Self {
        Self::new()
    }
}
