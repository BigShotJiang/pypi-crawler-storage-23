//! # HistoryStorageConfig - Trait Implementations
//!
//! This module contains trait implementations for `HistoryStorageConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::HistoryStorageConfig;

impl Default for HistoryStorageConfig {
    fn default() -> Self {
        Self
    }
}

