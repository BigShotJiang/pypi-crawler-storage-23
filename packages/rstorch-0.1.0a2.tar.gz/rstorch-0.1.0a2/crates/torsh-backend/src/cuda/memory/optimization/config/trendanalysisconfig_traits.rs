//! # TrendAnalysisConfig - Trait Implementations
//!
//! This module contains trait implementations for `TrendAnalysisConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::TrendAnalysisConfig;

impl Default for TrendAnalysisConfig {
    fn default() -> Self {
        Self
    }
}

