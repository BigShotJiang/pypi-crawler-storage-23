//! # QualityGatesConfig - Trait Implementations
//!
//! This module contains trait implementations for `QualityGatesConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::QualityGatesConfig;

impl Default for QualityGatesConfig {
    fn default() -> Self {
        Self
    }
}

