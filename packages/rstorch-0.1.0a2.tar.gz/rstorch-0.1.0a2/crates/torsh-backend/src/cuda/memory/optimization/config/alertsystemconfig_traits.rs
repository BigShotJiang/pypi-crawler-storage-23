//! # AlertSystemConfig - Trait Implementations
//!
//! This module contains trait implementations for `AlertSystemConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::AlertSystemConfig;

impl Default for AlertSystemConfig {
    fn default() -> Self {
        Self
    }
}

