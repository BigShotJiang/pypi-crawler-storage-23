//! # ConfigPersistenceConfig - Trait Implementations
//!
//! This module contains trait implementations for `ConfigPersistenceConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ConfigPersistenceConfig;

impl Default for ConfigPersistenceConfig {
    fn default() -> Self {
        Self
    }
}

