//! # ConfigEnvironmentConfig - Trait Implementations
//!
//! This module contains trait implementations for `ConfigEnvironmentConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ConfigEnvironmentConfig;

impl Default for ConfigEnvironmentConfig {
    fn default() -> Self {
        Self
    }
}

