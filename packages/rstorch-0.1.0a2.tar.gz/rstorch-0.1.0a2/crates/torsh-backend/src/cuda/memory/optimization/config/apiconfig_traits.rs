//! # APIConfig - Trait Implementations
//!
//! This module contains trait implementations for `APIConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::APIConfig;

impl Default for APIConfig {
    fn default() -> Self {
        Self
    }
}

