//! # SecurityConfig - Trait Implementations
//!
//! This module contains trait implementations for `SecurityConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::SecurityConfig;

impl Default for SecurityConfig {
    fn default() -> Self {
        Self
    }
}

