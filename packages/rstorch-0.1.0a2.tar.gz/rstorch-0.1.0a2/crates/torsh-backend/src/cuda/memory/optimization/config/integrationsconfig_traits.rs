//! # IntegrationsConfig - Trait Implementations
//!
//! This module contains trait implementations for `IntegrationsConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::IntegrationsConfig;

impl Default for IntegrationsConfig {
    fn default() -> Self {
        Self
    }
}

