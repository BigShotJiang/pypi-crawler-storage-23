//! # ConfigManagerConfig - Trait Implementations
//!
//! This module contains trait implementations for `ConfigManagerConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ConfigManagerConfig;

impl Default for ConfigManagerConfig {
    fn default() -> Self {
        Self
    }
}

