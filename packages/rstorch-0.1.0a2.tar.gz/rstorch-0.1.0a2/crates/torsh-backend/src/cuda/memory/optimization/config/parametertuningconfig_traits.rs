//! # ParameterTuningConfig - Trait Implementations
//!
//! This module contains trait implementations for `ParameterTuningConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ParameterTuningConfig;

impl Default for ParameterTuningConfig {
    fn default() -> Self {
        Self
    }
}

