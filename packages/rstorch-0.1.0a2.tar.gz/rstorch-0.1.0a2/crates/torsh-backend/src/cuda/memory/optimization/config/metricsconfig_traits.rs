//! # MetricsConfig - Trait Implementations
//!
//! This module contains trait implementations for `MetricsConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::MetricsConfig;

impl Default for MetricsConfig {
    fn default() -> Self {
        Self
    }
}

