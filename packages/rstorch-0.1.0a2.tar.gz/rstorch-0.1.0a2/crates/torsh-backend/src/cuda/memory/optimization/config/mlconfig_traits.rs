//! # MLConfig - Trait Implementations
//!
//! This module contains trait implementations for `MLConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::MLConfig;

impl Default for MLConfig {
    fn default() -> Self {
        Self
    }
}

