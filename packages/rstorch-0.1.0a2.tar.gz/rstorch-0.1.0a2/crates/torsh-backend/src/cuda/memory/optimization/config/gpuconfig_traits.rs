//! # GpuConfig - Trait Implementations
//!
//! This module contains trait implementations for `GpuConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::GpuConfig;

impl Default for GpuConfig {
    fn default() -> Self {
        Self
    }
}

