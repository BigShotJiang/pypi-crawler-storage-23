//! # CompressionConfig - Trait Implementations
//!
//! This module contains trait implementations for `CompressionConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::CompressionConfig;

impl Default for CompressionConfig {
    fn default() -> Self {
        Self
    }
}

