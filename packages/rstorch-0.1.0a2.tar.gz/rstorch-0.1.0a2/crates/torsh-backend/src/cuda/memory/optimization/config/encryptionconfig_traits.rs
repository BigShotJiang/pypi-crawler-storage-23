//! # EncryptionConfig - Trait Implementations
//!
//! This module contains trait implementations for `EncryptionConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::EncryptionConfig;

impl Default for EncryptionConfig {
    fn default() -> Self {
        Self
    }
}

