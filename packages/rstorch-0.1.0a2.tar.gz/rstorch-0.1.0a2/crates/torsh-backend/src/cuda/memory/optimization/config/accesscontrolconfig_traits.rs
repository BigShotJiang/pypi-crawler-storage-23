//! # AccessControlConfig - Trait Implementations
//!
//! This module contains trait implementations for `AccessControlConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::AccessControlConfig;

impl Default for AccessControlConfig {
    fn default() -> Self {
        Self
    }
}

