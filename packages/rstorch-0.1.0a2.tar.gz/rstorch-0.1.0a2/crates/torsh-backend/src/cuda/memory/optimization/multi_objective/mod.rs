//! Auto-generated module structure

pub mod coveragemetrics_traits;
pub mod performancestats_traits;
pub mod diversitystrategy_traits;
pub mod convergencecriteria_traits;
pub mod multiobjectivemetrics_traits;
pub mod archiveconfig_traits;
pub mod qualityindicators_traits;
pub mod types;
pub mod functions;

// Re-export all types
pub use coveragemetrics_traits::*;
pub use performancestats_traits::*;
pub use diversitystrategy_traits::*;
pub use convergencecriteria_traits::*;
pub use multiobjectivemetrics_traits::*;
pub use archiveconfig_traits::*;
pub use qualityindicators_traits::*;
pub use types::*;
pub use functions::*;
