//! # AnalysisConfig - Trait Implementations
//!
//! This module contains trait implementations for `AnalysisConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::AnalysisConfig;

impl Default for AnalysisConfig {
    fn default() -> Self {
        Self
    }
}

