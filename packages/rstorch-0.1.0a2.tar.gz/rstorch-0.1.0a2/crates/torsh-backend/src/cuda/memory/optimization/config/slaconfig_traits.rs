//! # SLAConfig - Trait Implementations
//!
//! This module contains trait implementations for `SLAConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::SLAConfig;

impl Default for SLAConfig {
    fn default() -> Self {
        Self
    }
}

