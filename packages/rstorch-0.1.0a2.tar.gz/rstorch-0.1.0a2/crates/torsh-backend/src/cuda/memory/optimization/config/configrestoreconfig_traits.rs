//! # ConfigRestoreConfig - Trait Implementations
//!
//! This module contains trait implementations for `ConfigRestoreConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ConfigRestoreConfig;

impl Default for ConfigRestoreConfig {
    fn default() -> Self {
        Self
    }
}

