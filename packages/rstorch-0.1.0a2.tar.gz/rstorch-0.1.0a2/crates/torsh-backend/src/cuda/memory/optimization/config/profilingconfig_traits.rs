//! # ProfilingConfig - Trait Implementations
//!
//! This module contains trait implementations for `ProfilingConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ProfilingConfig;

impl Default for ProfilingConfig {
    fn default() -> Self {
        Self
    }
}

