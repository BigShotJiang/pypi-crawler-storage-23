//! # ExperimentalConfig - Trait Implementations
//!
//! This module contains trait implementations for `ExperimentalConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ExperimentalConfig;

impl Default for ExperimentalConfig {
    fn default() -> Self {
        Self
    }
}

