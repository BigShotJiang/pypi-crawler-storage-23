//! # ThermalConfig - Trait Implementations
//!
//! This module contains trait implementations for `ThermalConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ThermalConfig;

impl Default for ThermalConfig {
    fn default() -> Self {
        Self
    }
}

