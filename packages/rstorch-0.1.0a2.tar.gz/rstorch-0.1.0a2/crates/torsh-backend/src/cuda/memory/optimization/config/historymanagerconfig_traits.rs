//! # HistoryManagerConfig - Trait Implementations
//!
//! This module contains trait implementations for `HistoryManagerConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::HistoryManagerConfig;

impl Default for HistoryManagerConfig {
    fn default() -> Self {
        Self
    }
}

