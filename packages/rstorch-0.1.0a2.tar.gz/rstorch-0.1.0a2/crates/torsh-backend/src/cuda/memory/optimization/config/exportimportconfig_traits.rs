//! # ExportImportConfig - Trait Implementations
//!
//! This module contains trait implementations for `ExportImportConfig`.
//!
//! ## Implemented Traits
//!
//! - `Default`
//!
//! 🤖 Generated with [SplitRS](https://github.com/cool-japan/splitrs)

use super::types::ExportImportConfig;

impl Default for ExportImportConfig {
    fn default() -> Self {
        Self
    }
}

