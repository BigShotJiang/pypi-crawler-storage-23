from mkdocs_nodegraph.plugin import GraphViewPlugin

__version__ = "0.4.1"
