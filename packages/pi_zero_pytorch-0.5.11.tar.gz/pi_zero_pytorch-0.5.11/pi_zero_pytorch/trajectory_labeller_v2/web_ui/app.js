const { createApp, ref, onMounted, computed, reactive, watch, nextTick } = Vue;

const App = {
    setup() {
        const state = reactive({
            tasks: [],
            videos: [],
            activeVideo: null,
            activeTask: null,
            currentFrame: 0,
            isPlaying: false,
            labels: {},
            recapState: null,
            metadata: null,
            loading: {
                global: false,
                returns: false,
                value: false,
                advantage: false,
                finetune: false
            },
            errorMessage: null,
            isExpertMode: false,
            expertState: {
                actions: [], // Will be nested (16, 6) or flat (16,)
                proprio: [],
                currentFrameIdx: 0
            },
            advantageCutoff: 0,
            advantageStats: null,
            quantileValue: 0.5
        });

        const videoPlayers = ref([]);

        const notify = (msg, type = 'error') => {
            state.errorMessage = msg;
            if (type === 'error') console.error(`[RECAP] ${msg}`);
            else console.log(`[RECAP] ${msg}`);
            setTimeout(() => { if (state.errorMessage === msg) state.errorMessage = null; }, 5000);
        };

        const framesUrlArray = computed(() => {
            if (!state.activeVideo) return [];
            return Array.from({ length: state.activeVideo.frames }, (_, i) => i);
        });

        const workflowStatus = computed(() => ({
            canCalcReturns: !!state.activeVideo,
            canTrainValue: state.metadata?.returns?.some(v => v !== null),
            canCalcAdvantage: state.metadata?.value?.some(v => v !== null),
            canFinetune: state.metadata?.advantages?.some(v => v !== null) || state.metadata?.advantage_ids?.some(v => v !== -1)
        }));

        const fetchData = async () => {
            try {
                const [vRes, tRes, sRes] = await Promise.all([
                    fetch('/api/videos').then(r => r.json()),
                    fetch('/api/tasks').then(r => r.json()),
                    fetch('/api/recap/state').then(r => r.json())
                ]);
                state.videos = vRes;
                state.tasks = tRes;
                state.recapState = sRes;
            } catch (e) {
                notify("Failed to fetch initial data");
            }
        };

        const fetchMetadata = async (filename) => {
            state.loading.global = true;
            try {
                const res = await fetch(`/api/metadata/${filename}`).then(r => r.json());
                state.metadata = res;
                state.labels = {};
                if (res.advantage_ids) {
                    res.advantage_ids.forEach((id, idx) => {
                        if (id !== -1) state.labels[idx] = { status: id === 1 ? 'success' : 'fail' };
                    });
                }
            } catch (e) {
                notify("Failed to fetch video metadata");
            } finally {
                state.loading.global = false;
            }
        };

        const selectVideo = async (video) => {
            state.activeVideo = video;
            state.currentFrame = 0;
            state.isPlaying = false;
            await fetchMetadata(video.filename);
        };

        const labelFrame = async (idx, isSuccess) => {
            if (!state.activeVideo) return;
            try {
                await fetch('/api/label', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        filename: state.activeVideo.filename,
                        timestep: idx,
                        success: isSuccess
                    })
                });
                await fetchMetadata(state.activeVideo.filename);
            } catch (e) {
                notify("Failed to save label");
            }
        };

        const onTimeUpdate = (e) => {
            const p = e.target;
            if (!state.activeVideo || p !== videoPlayers.value[0]) return;
            const progress = p.currentTime / p.duration;
            const idx = Math.floor(progress * state.activeVideo.frames);
            if (idx !== state.currentFrame) {
                state.currentFrame = idx;
                videoPlayers.value.forEach((other, i) => {
                    if (i > 0 && other) {
                        if (Math.abs(other.currentTime - p.currentTime) > 0.1) {
                            other.currentTime = p.currentTime;
                        }
                    }
                });
            }
        };

        const jumpToFrame = (idx) => {
            const player = videoPlayers.value[0];
            if (!player || !state.activeVideo || !player.duration || isNaN(player.duration)) return;
            state.currentFrame = idx;
            const time = (idx / state.activeVideo.frames) * player.duration;
            videoPlayers.value.forEach(p => { if (p) p.currentTime = time; });
        };

        const calcReturns = async () => {
            if (!state.activeVideo) return;
            state.loading.returns = true;
            try {
                await fetch('/api/returns/calculate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ filename: state.activeVideo.filename })
                });
                await fetchMetadata(state.activeVideo.filename);
            } finally {
                state.loading.returns = false;
            }
        };

        const trainValue = async () => {
            state.loading.value = true;
            try {
                await fetch('/api/value/train', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ config: 'small' })
                });
                await fetch('/api/episode/value/calculate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ filename: state.activeVideo.filename })
                });
                await fetchMetadata(state.activeVideo.filename);
            } finally {
                state.loading.value = false;
            }
        };

        const calcAdvantage = async () => {
            state.loading.advantage = true;
            try {
                await fetch('/api/episode/advantage/calculate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ filename: state.activeVideo.filename })
                });
                await fetchMetadata(state.activeVideo.filename);
            } finally {
                state.loading.advantage = false;
            }
        };

        const finetunePolicy = async () => {
            state.loading.finetune = true;
            try {
                await fetch('/api/recap/finetune', { method: 'POST' });
                notify("Policy finetuning started", "success");
            } finally {
                state.loading.finetune = false;
            }
        };

        const openExpertMode = (idx) => {
            state.currentFrame = idx;
            state.isExpertMode = true;
            state.expertState.currentFrameIdx = idx;
            if (state.metadata) {
                state.expertState.actions = JSON.parse(JSON.stringify(state.metadata.actions[idx]));
                state.expertState.proprio = JSON.parse(JSON.stringify(state.metadata.proprioception[idx]));
            }
        };

        const saveExpertState = async () => {
            try {
                await fetch('/api/expert/save', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        filename: state.activeVideo.filename,
                        timestep: state.expertState.currentFrameIdx,
                        actions: state.expertState.actions,
                        proprioception: state.expertState.proprio
                    })
                });
                state.isExpertMode = false;
                await fetchMetadata(state.activeVideo.filename);
            } catch (e) {
                notify("Failed to save expert annotation");
            }
        };

        const getFrameUrl = (idx) => {
            if (!state.activeVideo) return '';
            return `/api/frame/${state.activeVideo.filename}/${idx}`;
        };

        const getViewUrl = (vidx) => {
            if (!state.activeVideo) return '';
            const baseName = state.activeVideo.filename.split('.')[0];
            return `/videos/${baseName}.${vidx}.mp4`;
        };

        const togglePlay = () => {
            state.isPlaying = !state.isPlaying;
            videoPlayers.value.forEach(p => {
                if (p) {
                    if (state.isPlaying) p.play();
                    else p.pause();
                }
            });
        };

        const selectDataset = async (taskName, iterId, dataId, isPretrained = false) => {
            state.loading.global = true;
            try {
                await fetch('/api/recap/load_data', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ task_name: taskName, iter_id: iterId, data_id: dataId, is_pretrained: isPretrained })
                });

                const poll = setInterval(async () => {
                    const status = await fetch('/api/status').then(r => r.json());
                    if (!status.is_converting) {
                        clearInterval(poll);
                        await fetchData();
                        state.loading.global = false;
                    }
                }, 1000);
            } catch (e) {
                state.loading.global = false;
            }
        };

        const pretrain = async () => {
            state.loading.global = true;
            try {
                await fetch('/api/recap/pretrain', { method: 'POST' });
                await fetchData();
            } finally {
                state.loading.global = false;
            }
        };

        const specialize = async (taskName) => {
            state.loading.global = true;
            try {
                await fetch('/api/recap/specialize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ task_name: taskName })
                });
                await fetchData();
            } finally {
                state.loading.global = false;
            }
        };

        const collect = async (taskName, iterId = 0) => {
            state.loading.global = true;
            try {
                await fetch('/api/recap/collect', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ task_name: taskName, iter_id: iterId })
                });
                await fetchData();
            } finally {
                state.loading.global = false;
            }
        };

        onMounted(fetchData);

        return {
            state, workflowStatus, framesUrlArray, videoPlayers,
            fetchData, selectVideo, labelFrame, onTimeUpdate, jumpToFrame,
            calcReturns, trainValue, calcAdvantage, finetunePolicy,
            openExpertMode, saveExpertState, notify, togglePlay,
            selectDataset, getFrameUrl, getViewUrl, pretrain, specialize, collect
        };
    }
};

createApp(App).mount('#app');
