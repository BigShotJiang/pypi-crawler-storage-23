import os
import time
import json
import torch
import av
import numpy as np
import threading
import asyncio
import shutil
import click
import uvicorn
from pathlib import Path
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, BackgroundTasks, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from memmap_replay_buffer import ReplayBuffer
from pi_zero_pytorch.pi_zero import calc_generalized_advantage_estimate, SigLIP, BinnedValueLayer, PiZero
import torchvision.transforms.functional as TF

# --- Configuration & Constants ---

DEVICE = torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
FAST_MOCK = os.getenv("FAST_MOCK", "false").lower() == "true"
recap_config_path = Path(__file__).parent.parent / "recap_config.json"
RECAP_CONFIG = {}
if recap_config_path.exists():
    with open(recap_config_path) as f:
        RECAP_CONFIG = json.load(f)

# --- Small Models (Refactored from v1) ---

class SmallValueNetwork(torch.nn.Module):
    def __init__(self, image_size=224, patch_size=14, dim=256, depth=4, heads=8, min_value=-1., max_value=0., num_bins=201):
        super().__init__()
        self.image_size, self.patch_size = image_size, patch_size
        self.siglip = SigLIP(image_size=image_size, patch_size=patch_size, dim=dim, depth=depth, heads=heads)
        self.to_value = BinnedValueLayer(dim=dim, min_value=min_value, max_value=max_value, num_bins=num_bins)

    def forward(self, images, return_value_and_logits=False):
        embeds = self.siglip(images)
        pooled = embeds.mean(dim=1)
        return self.to_value(pooled, return_value_and_logits=return_value_and_logits)

class SmallPiZero(torch.nn.Module):
    def __init__(self, dim=32, dim_action=32, dim_action_input=6, dim_joint_state=32, num_tokens=256, depth=2, heads=4, image_size=32, patch_size=4, max_text_len=32, num_advantage_tokens=2):
        super().__init__()
        self.vit = SigLIP(image_size=image_size, patch_size=patch_size, dim=dim, depth=depth, heads=heads)
        self.pizero = PiZero(dim=dim, num_tokens=num_tokens, dim_action_input=dim_action_input, dim_joint_state=dim_joint_state, dim_action=dim_action, depth=depth, heads=heads, vit=self.vit, vit_dim=dim, num_advantage_tokens=num_advantage_tokens)

    def forward(self, images, token_ids, joint_state, actions, advantage_ids=None, **kwargs):
        return self.pizero(images=images, token_ids=token_ids, joint_state=joint_state, actions=actions, advantage_ids=advantage_ids, **kwargs)

VALUE_NETWORK_CONFIGS = {
    "mock": {"dim": 8, "depth": 1, "heads": 1, "image_size": 32, "patch_size": 16},
    "small": {"dim": 64, "depth": 2, "heads": 4, "image_size": 224, "patch_size": 14}
}

# --- State Management ---

class AppState:
    def __init__(self):
        self.workspace: Optional[Path] = None
        self.video_dirs: List[Path] = []
        self.replay_buffer: Optional[ReplayBuffer] = None
        self.video_map: Dict[str, int] = {} # filename -> episode_id
        self.path_map: Dict[str, Path] = {} # filename -> Path
        self.conversion_status = {"is_converting": False, "progress": 0, "total": 0, "current_video": ""}
        self.training_state = {"is_training": False, "current_epoch": 0, "total_epochs": 0, "last_loss": 0.0}
        self.value_network = None
        self.num_views = 1

STATE = AppState()

app = FastAPI()

# --- Video Utility ---

class VideoUtil:
    @staticmethod
    def get_info(path: Path):
        with av.open(str(path)) as container:
            stream = container.streams.video[0]
            return {"frames": stream.frames, "fps": float(stream.average_rate), "width": stream.width, "height": stream.height}

    @staticmethod
    def extract_frame_to_buffer(path: Path, frame_idx: int):
        with av.open(str(path)) as container:
            stream = container.streams.video[0]
            # Approximate seek
            target_pts = int(frame_idx * stream.time_base.denominator / stream.average_rate / stream.time_base.numerator)
            container.seek(target_pts, stream=stream)
            count = 0 
            for frame in container.decode(stream):
                # We want the frame at frame_idx. Seek gets us close.
                # Since we don't have global index on frame easily, 
                # and seek isn't frame-accurate always, we'll just take the first one after seek for mock.
                # For real use, we'd need to calculate index from PTS.
                import io
                buf = io.BytesIO()
                frame.to_image().save(buf, format="JPEG")
                return buf.getvalue()
        return None

# --- Replay Buffer Initialization ---

def init_buffer(folders: List[Path]):
    # STATE.conversion_status["is_converting"] is now set in the caller
    try:
        tmp_dir = Path("tmp/v2_buffer")
        if tmp_dir.exists(): shutil.rmtree(tmp_dir)
        tmp_dir.mkdir(parents=True)

        episodes = {}
        for fdir in folders:
            print(f"DEBUG: init_buffer processing folder: {fdir} (exists: {fdir.exists()})")
            if not fdir.exists():
                print(f"DEBUG: Folder {fdir} does not exist!")
                continue
            
            # Scan multiple folders if requested (e.g. pretrained + experientially gathered)
            scan_dirs = [fdir]
            pretrained_dir = STATE.workspace / "pretrained_data"
            if pretrained_dir.exists() and pretrained_dir != fdir:
                scan_dirs.append(pretrained_dir)
            
            for d in scan_dirs:
                for ext in [".mp4", ".webm", ".avi", ".mov"]:
                    files = list(d.glob(f"*{ext}"))
                    print(f"DEBUG: Found {len(files)} files with ext {ext} in {d}")
                    for f in files:
                        if '.' in f.name:
                            parts = f.name.split('.')
                            if len(parts) >= 3 and parts[-2].isdigit():
                                ep_name = ".".join(parts[:-2])
                                view_idx = int(parts[-2])
                            else:
                                ep_name = f.stem
                                view_idx = 0
                        else:
                            ep_name = f.stem
                            view_idx = 0

                        print(f"DEBUG: Registering episode: {ep_name} view: {view_idx} from {f}")
                        if ep_name not in episodes: episodes[ep_name] = {}
                        episodes[ep_name][view_idx] = f 
                        STATE.path_map[f.name] = f
                        STATE.path_map[f.stem] = f
                        STATE.path_map[ep_name] = f
        
        ep_names = sorted(episodes.keys())
        print(f"DEBUG: Total episodes found: {len(ep_names)} -> {ep_names}")
        if not ep_names: 
            print("DEBUG: No episodes found, returning early.")
            return

        # Detect dimensions from first video
        vinfo = VideoUtil.get_info(episodes[ep_names[0]][0])
        h, w, c = vinfo["height"], vinfo["width"], 3
        max_len = max(vinfo["frames"] for ep in episodes.values() for v in ep.values())

        STATE.replay_buffer = ReplayBuffer(
            str(tmp_dir),
            max_episodes = len(ep_names),
            max_timesteps = max_len,
            fields = {
                "images": ("float", (c, 1, h, w)),
                "actions": ("float", (16, 6)),
                "reward": "float",
                "returns": ("float", (), float("nan")),
                "value": ("float", (), float("nan")),
                "advantages": ("float", (), float("nan")),
                "advantage_ids": ("int", (), -1),
                "text": ("int", (32,)),
                "proprioception": ("float", (16,)),
                "expert_mask": ("bool", (), False)
            },
            meta_fields = {
                "task_id": ("int", (), -1),
                "marked_timestep": ("int", (), -1),
                "is_expert_annotated": ("bool", (), False)
            }
        )

        STATE.conversion_status["total"] = len(ep_names)
        for i, name in enumerate(ep_names):
            STATE.conversion_status["current_video"] = name
            STATE.conversion_status["progress"] = i
            STATE.video_map[name] = i
            
            # Fast mock or real load
            with STATE.replay_buffer.one_episode():
                for t in range(32 if FAST_MOCK else vinfo["frames"]):
                    # Generate some interesting mock values for the charts
                    v = -1.0 + 0.5 * np.sin(t / 5.0) + 0.1 * np.random.randn()
                    a = 0.2 * np.cos(t / 3.0) + 0.05 * np.random.randn()
                    r = -1.0 + (1.0 if t > 25 else 0.0)
                    # Mock binarized advantages (e.g. green for pos, red for neg)
                    adv_id = 1 if a > 0.1 else (2 if a < -0.1 else -1)
                    
                    STATE.replay_buffer.store(
                        images = torch.randn(c, 1, h, w),
                        actions = torch.randn(16, 6),
                        reward = 0.0,
                        returns = float(r),
                        value = float(v),
                        advantages = float(a),
                        advantage_ids = int(adv_id),
                        text = torch.zeros(32, dtype=torch.long),
                        proprioception = torch.randn(16),
                        expert_mask = False
                    )
    finally:
        STATE.conversion_status["is_converting"] = False

# --- API Endpoints ---

@app.get("/api/status")
async def get_status():
    return STATE.conversion_status

@app.get("/api/recap/state")
async def get_recap_state():
    if not STATE.workspace: return {"enabled": False}
    tasks = []
    for tname, tcfg in RECAP_CONFIG.get("tasks", {}).items():
        tdir = STATE.workspace / tname
        iterations = []
        # Even if directory doesn't exist, we show the task from config
        if tdir.exists():
            for idir in sorted(tdir.iterdir()):
                if idir.is_dir() and idir.name.isdigit():
                    iterations.append({
                        "id": int(idir.name),
                        "actor": (idir / "actor.pt").exists(),
                        "data": [{"id": d.name, "video_count": len(list(d.glob('*.mp4')))} for d in idir.glob("data.*")]
                    })
        tasks.append({"name": tname, "iterations": iterations, "exists": True})
    return {"enabled": True, "tasks": tasks, "pretrained_data": {"video_count": len(list((STATE.workspace / "pretrained_data").glob('*.mp4'))) if (STATE.workspace / "pretrained_data").exists() else 0}}

@app.get("/api/videos")
async def list_videos():
    if not STATE.replay_buffer: return []
    res = []
    for name, idx in STATE.video_map.items():
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][idx])
        num_views = len([k for k, v in STATE.path_map.items() if k.startswith(name + ".")]) // 2 # filename and stem
        # Actually a better way to get view count is from STATE.episodes if we kept it
        # Let's just assume we can find it
        num_views = 0
        while True:
            if f"{name}.{num_views}" in STATE.path_map or f"{name}.{num_views}.mp4" in STATE.path_map:
                num_views += 1
            else:
                break
        if num_views == 0: num_views = 1
        
        res.append({
            "filename": name,
            "frames": ep_len,
            "url": f"/videos/{name}",
            "views": num_views
        })
    return res

@app.get("/videos/{filename}")
async def serve_video(filename: str):
    # Try direct name
    path = STATE.path_map.get(filename)
    # Try stem (without .mp4)
    if not path:
        path = STATE.path_map.get(filename.split('.')[0])
    
    if path and path.exists():
        media_type = "video/mp4"
        if path.suffix == ".webm": media_type = "video/webm"
        return FileResponse(path, media_type=media_type)
    return JSONResponse({"error": f"Video {filename} not found"}, 404)

@app.get("/api/frame/{filename}/{idx}")
async def get_frame(filename: str, idx: int):
    path = STATE.path_map.get(filename)
    if not path: return JSONResponse({"error": "Video not found"}, 404)
    # Move blocking extraction to a thread to keep the event loop responsive
    frame_data = await asyncio.to_thread(VideoUtil.extract_frame_to_buffer, path, idx)
    return HTMLResponse(content=frame_data, media_type="image/jpeg") if frame_data else JSONResponse({"error": "Frame not found"}, 404)

@app.get("/api/metadata/{filename}")
async def get_metadata(filename: str):
    if not STATE.replay_buffer: return JSONResponse({"error": "No buffer"}, 400)
    eid = STATE.video_map.get(filename)
    if eid is None: return JSONResponse({"error": "Not found"}, 404)
    
    ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
    
    def process_metadata():
        KEEP_KEYS = {"returns", "value", "advantages", "advantage_ids", "expert_mask", "actions", "proprioception"}
        res = {}
        
        def clean_json(obj):
            if isinstance(obj, list):
                return [clean_json(x) for x in obj]
            if isinstance(obj, np.ndarray):
                return clean_json(obj.tolist())
            if isinstance(obj, float) and np.isnan(obj):
                return None
            if isinstance(obj, (np.float32, np.float64)) and np.isnan(obj):
                return None
            return obj

        for key in KEEP_KEYS:
            if key not in STATE.replay_buffer.data: continue
            data = STATE.replay_buffer.data[key][eid, :ep_len]
            res[key] = clean_json(data)
        return res

    res = await asyncio.to_thread(process_metadata)
    
    return {
        **res,
        "filename": filename,
        "frames": ep_len,
        "marked_timestep": int(STATE.replay_buffer.meta_data["marked_timestep"][eid]),
        "task_id": int(STATE.replay_buffer.meta_data["task_id"][eid])
    }

@app.post("/api/recap/pretrain")
async def pretrain():
    actor = STATE.workspace / "pretrained-actor.pt"
    torch.save(SmallPiZero(dim=4).state_dict(), str(actor))
    return {"status": "ok"}

@app.post("/api/recap/specialize")
async def specialize(req: dict):
    tdir = STATE.workspace / req["task_name"] / "0"
    tdir.mkdir(parents=True, exist_ok=True)
    torch.save({"sim": True}, str(tdir / "actor.pt"))
    return {"status": "ok"}

@app.post("/api/recap/collect")
async def collect(req: dict):
    idir = STATE.workspace / req["task_name"] / str(req.get("iter_id", 0))
    ddir = idir / f"data.{len(list(idir.glob('data.*')))}"
    ddir.mkdir(parents=True, exist_ok=True)
    # Mock trajectories
    from pi_zero_pytorch.trajectory_labeller_v1.recap_sim_engine import generate_trajectories
    generate_trajectories(ddir, num_episodes=2)
    return {"status": "ok"}

@app.post("/api/recap/load_data")
async def load_data(req: dict):
    if req.get("is_pretrained"): path = STATE.workspace / "pretrained_data"
    else: path = STATE.workspace / req["task_name"] / str(req["iter_id"]) / req["data_id"]
    STATE.video_dirs = [path]
    STATE.conversion_status["is_converting"] = True
    STATE.conversion_status["progress"] = 0
    threading.Thread(target=init_buffer, args=([path],), daemon=True).start()
    return {"status": "ok"}

@app.get("/api/tasks")
async def get_tasks():
    if not RECAP_CONFIG: return []
    return [{"id": name, "name": name.replace('_', ' ').title()} for name in RECAP_CONFIG.get("tasks", {}).keys()]

@app.post("/api/recap/calc_returns")
async def calc_returns():
    return {"status": "ok"}

# V1 Parity: Returns Calculation endpoint
@app.post("/api/returns/calculate") 
async def calculate_returns(req: dict):
    filename = req.get("filename")
    if not STATE.replay_buffer:
        return {"error": "No buffer initialized"}
    
    eid = STATE.video_map.get(filename)
    if eid is None:
        return {"error": "Video not found"}
    
    def run_calc():
        start_time = time.time()
        print(f"[RECAP] calculate_returns START for {filename}")
        marked_timestep = int(STATE.replay_buffer.meta_data["marked_timestep"][eid])
        if marked_timestep == -1:
            return {"error": "Video not labelled yet"}
        
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
        max_duration = 100.0
        
        task_idx = int(STATE.replay_buffer.meta_data.get("task_id", {eid: -1})[eid])
        task_keys = list(RECAP_CONFIG.get("tasks", {}).keys())
        if 0 <= task_idx < len(task_keys):
            task_key = task_keys[task_idx]
            max_duration = RECAP_CONFIG["tasks"][task_key].get("max_episode_length", 100.0)
        
        returns = torch.full((ep_len,), float("nan"))
        for t in range(min(marked_timestep + 1, ep_len)):
            returns[t] = float(t - marked_timestep) / max_duration
        
        STATE.replay_buffer.data["returns"][eid, :ep_len] = returns.numpy()
        STATE.replay_buffer.data["value"][eid] = float("nan")
        STATE.replay_buffer.data["advantages"][eid] = float("nan")
        STATE.replay_buffer.flush()
        
        duration = time.time() - start_time
        print(f"[RECAP] calculate_returns END (took {duration:.2f}s)")
        return {"status": "ok", "returns": [r if not np.isnan(r) else None for r in returns.tolist()]}

    return await asyncio.to_thread(run_calc)

# V1 Parity: Value Network Inference
@app.post("/api/episode/value/calculate")
async def calculate_episode_value(req: dict):
    filename = req.get("filename")
    if not STATE.replay_buffer:
        return {"error": "No buffer initialized"}
    
    eid = STATE.video_map.get(filename)
    if eid is None:
        return {"error": "Video not found"}

    def run_calc():
        start_time = time.time()
        print(f"[RECAP] calculate_episode_value START for {filename}")
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
        marked_timestep = int(STATE.replay_buffer.meta_data["marked_timestep"][eid])
        max_t = min(marked_timestep + 1, ep_len) if marked_timestep != -1 else ep_len
        
        if STATE.value_network is None:
            config = VALUE_NETWORK_CONFIGS.get("mock" if FAST_MOCK else "small", VALUE_NETWORK_CONFIGS["mock"])
            STATE.value_network = SmallValueNetwork(**config).to(DEVICE)
        
        values = []
        with torch.no_grad():
            for t in range(max_t):
                returns_val = STATE.replay_buffer.data["returns"][eid, t]
                if np.isnan(returns_val):
                    v = -0.5 + 0.1 * np.random.randn()
                else:
                    v = returns_val + 0.05 * np.random.randn()
                values.append(float(v))
        
        value_arr = np.full((STATE.replay_buffer.data["value"].shape[1],), float("nan"))
        value_arr[:len(values)] = values
        STATE.replay_buffer.data["value"][eid] = value_arr
        STATE.replay_buffer.flush()
        duration = time.time() - start_time
        print(f"[RECAP] calculate_episode_value END (took {duration:.2f}s)")
        return {"status": "ok", "value": values}

    return await asyncio.to_thread(run_calc)

# V1 Parity: GAE Advantage Calculation
@app.post("/api/episode/advantage/calculate")
async def calculate_episode_advantage(req: dict):
    filename = req.get("filename")
    gamma = req.get("gamma", 0.99)
    lam = req.get("lam", 0.95)
    
    if not STATE.replay_buffer:
        return {"error": "No buffer initialized"}
    
    eid = STATE.video_map.get(filename)
    if eid is None:
        return {"error": "Video not found"}

    def run_calc():
        start_time = time.time()
        print(f"[RECAP] calculate_episode_advantage START for {filename}")
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
        marked_timestep = int(STATE.replay_buffer.meta_data["marked_timestep"][eid])
        num_frames = min(marked_timestep + 1, ep_len) if marked_timestep != -1 else ep_len
        
        # Check if values exist
        values_np = STATE.replay_buffer.data["value"][eid][:num_frames]
        if np.isnan(values_np).any():
            return {"error": "Values not calculated yet"}
        
        # Prepare GAE inputs
        rewards = torch.from_numpy(STATE.replay_buffer.data["reward"][eid][:num_frames]).float()
        values = torch.from_numpy(values_np).float()
        masks = torch.ones_like(rewards)
        
        # Calculate GAE
        gae_result = calc_generalized_advantage_estimate(
            rewards=rewards,
            values=values,
            masks=masks,
            gamma=gamma,
            lam=lam
        )
        
        advantages = gae_result.advantages.tolist()
        
        # Store advantages
        adv_arr = np.full((STATE.replay_buffer.data["advantages"].shape[1],), float("nan"))
        adv_arr[:len(advantages)] = advantages
        STATE.replay_buffer.data["advantages"][eid] = adv_arr
        
        # Binarize
        expert_mask = STATE.replay_buffer.data["expert_mask"][eid][:num_frames]
        adv_ids = np.full((STATE.replay_buffer.data["advantage_ids"].shape[1],), -1, dtype=np.int32)
        for i, a in enumerate(advantages):
            if expert_mask[i]:
                adv_ids[i] = 1
            elif a > 0:
                adv_ids[i] = 1
            else:
                adv_ids[i] = 0
        STATE.replay_buffer.data["advantage_ids"][eid] = adv_ids
        STATE.replay_buffer.flush()
        
        duration = time.time() - start_time
        print(f"[RECAP] calculate_episode_advantage END (took {duration:.2f}s)")
        return {
            "status": "ok",
            "advantages": advantages,
            "value": values_np.tolist(),
            "advantage_ids": adv_ids[:num_frames].tolist()
        }

    return await asyncio.to_thread(run_calc)

# V1 Parity: Global Advantage Statistics
@app.post("/api/advantage/stats")
async def calculate_advantage_stats(req: dict):
    if not STATE.replay_buffer:
        return {"error": "No buffer initialized"}
    
    quantile = req.get("quantile", 0.5)
    all_advs = []
    
    for eid in range(len(STATE.video_map)):
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
        advs = STATE.replay_buffer.data["advantages"][eid, :ep_len]
        valid = advs[~np.isnan(advs)]
        all_advs.extend(valid.tolist())
    
    if not all_advs:
        return {"error": "No advantage data available"}
    
    cutoff = float(np.quantile(all_advs, quantile))
    return {"status": "ok", "cutoff": cutoff, "count": len(all_advs)}

# V1 Parity: Binarize Advantages
@app.post("/api/advantage/binarize")
async def binarize_advantages(req: dict):
    if not STATE.replay_buffer:
        return {"error": "No buffer initialized"}
    
    cutoff = req.get("cutoff", 0.0)
    updated = 0
    
    for eid in range(len(STATE.video_map)):
        ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
        advs = STATE.replay_buffer.data["advantages"][eid, :ep_len]
        expert_mask = STATE.replay_buffer.data["expert_mask"][eid, :ep_len]
        adv_ids = STATE.replay_buffer.data["advantage_ids"][eid]
        
        for t in range(ep_len):
            if expert_mask[t]:
                adv_ids[t] = 1  # Expert always positive
            elif not np.isnan(advs[t]):
                adv_ids[t] = 1 if advs[t] >= cutoff else 0
                updated += 1
        
        STATE.replay_buffer.data["advantage_ids"][eid] = adv_ids
    
    STATE.replay_buffer.flush()
    return {"status": "ok", "updated": updated}

@app.post("/api/label")
async def label(req: dict):
    eid = STATE.video_map[req["filename"]]
    t = req["timestep"]
    is_success = req.get("success", True)
    
    # Store label meta
    STATE.replay_buffer.store_meta_datapoint(eid, "marked_timestep", torch.tensor(t))
    # Reset stale values
    STATE.replay_buffer.data['value'][eid] = float('nan')
    STATE.replay_buffer.data['advantages'][eid] = float('nan')
    
    # Calculate returns (normalized by nominal ep length or max_duration if available)
    ep_len = int(STATE.replay_buffer.meta_data["episode_lens"][eid])
    returns = torch.full((ep_len,), float('nan'))
    
    # Simple linear returns for now, matching V1
    max_duration = 100.0 # Default if unknown
    for step in range(t + 1):
        returns[step] = float(step - t) / max_duration
    
    STATE.replay_buffer.data['returns'][eid, :ep_len] = returns
    STATE.replay_buffer.flush()
    
    def clean_json(obj):
        if isinstance(obj, list): return [clean_json(x) for x in obj]
        if isinstance(obj, float) and np.isnan(obj): return None
        return obj

    return {"status": "ok", "returns": clean_json(returns.tolist())}

@app.post("/api/expert/save")
async def save_expert_annotation(req: dict):
    eid = STATE.video_map[req["filename"]]
    t = req["timestep"]
    
    # Match V1 logic for expert intervention
    STATE.replay_buffer.store_meta_datapoint(eid, "is_expert_annotated", torch.tensor(True))
    
    # Set expert mask for segment up to t
    expert_mask = STATE.replay_buffer.data['expert_mask'][eid]
    expert_mask[:t + 1] = True
    STATE.replay_buffer.data['expert_mask'][eid] = expert_mask
    
    # Force advantage_ids to 1 (Positive) for expert segment
    adv_ids = STATE.replay_buffer.data['advantage_ids'][eid]
    adv_ids[:t + 1] = 1
    STATE.replay_buffer.data['advantage_ids'][eid] = adv_ids
    
    # Store the specific action/proprio corrected at t
    STATE.replay_buffer.data["actions"][eid, t] = np.array(req["actions"])
    STATE.replay_buffer.data["proprioception"][eid, t] = np.array(req["proprioception"])
    
    STATE.replay_buffer.flush()
    return {"status": "ok"}

# --- Training Threads (Placeholder Skeletons) ---

def train_thread(name, loop):
    STATE.training_state["is_training"] = True
    time.sleep(2)
    STATE.training_state["is_training"] = False

@app.post("/api/value/train")
async def train_value(req: dict):
    # Use to_thread for these since they are currently just mocks with sleep
    # In a real app, these would be heavy training loops
    await asyncio.to_thread(time.sleep, 2)
    return {"status": "ok"}

@app.post("/api/recap/finetune")
async def finetune(req: dict):
    start = time.time()
    print("[RECAP] finetune START")
    await asyncio.to_thread(time.sleep, 2)
    print(f"[RECAP] finetune END (took {time.time() - start:.2f}s)")
    return {"status": "ok"}

# --- Start ---

@click.command()
@click.option("--port", default=8000)
@click.option("--folder", multiple=True)
@click.option("--recap-workspace")
def main(port, folder, recap_workspace):
    if recap_workspace: STATE.workspace = Path(recap_workspace)
    if folder:
        STATE.video_dirs = [Path(f) for f in folder]
        threading.Thread(target=init_buffer, args=(STATE.video_dirs,), daemon=True).start()
    
    app.mount("/ui", StaticFiles(directory=Path(__file__).parent / "web_ui"), name="ui")
    uvicorn.run(app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    main()
