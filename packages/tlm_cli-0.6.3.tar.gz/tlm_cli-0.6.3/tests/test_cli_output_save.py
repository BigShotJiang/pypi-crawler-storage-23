"""Tests for CLI output saving — decorator integration with commands."""

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from tlm.cli import main


class TestOutputSaveDecorator:
    """The _save_output decorator should save CLI output to .tlm/output/."""

    def test_status_saves_output_file(self, tmp_path):
        """tlm status creates .tlm/output/status_*.txt with table content."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_name": "myapp",
            "project_id": 42,
            "quality_control": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
        (tlm_dir / "gaps.json").write_text("[]")

        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        output_dir = tlm_dir / "output"
        assert output_dir.exists()
        files = list(output_dir.glob("status_*.txt"))
        assert len(files) == 1
        content = files[0].read_text()
        assert "myapp" in content

    def test_gaps_saves_output_file(self, tmp_path):
        """tlm gaps creates .tlm/output/gaps_*.txt."""
        from tlm.gaps import add_gap
        from tlm.state import write_state

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        files = list((tlm_dir / "output").glob("gaps_*.txt"))
        assert len(files) == 1
        content = files[0].read_text()
        assert "CI/CD" in content or "cicd" in content

    def test_output_path_printed_dim(self, tmp_path):
        """Command output includes the saved file path."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_name": "testproj",
            "project_id": 1,
            "quality_control": "standard",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
        (tlm_dir / "gaps.json").write_text("[]")

        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "Output saved to" in result.output
        assert ".tlm/output/status_" in result.output

    def test_no_file_when_tlm_dir_missing(self, tmp_path):
        """If .tlm/ doesn't exist, no output file is created (no crash)."""
        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert not (tmp_path / ".tlm" / "output").exists()

    def test_output_saved_on_error(self, tmp_path):
        """Output is saved even when command exits with error (via finally)."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        # scan requires auth — will fail with "Not authenticated"
        # but _handle_api_errors converts to SystemExit

        runner = CliRunner()
        with patch("tlm.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        # Command fails but output should still be saved
        assert result.exit_code != 0
        files = list((tlm_dir / "output").glob("scan_*.txt"))
        assert len(files) == 1
        content = files[0].read_text()
        assert "auth" in content.lower()

    def test_gaps_no_output_when_empty(self, tmp_path):
        """tlm gaps with no gaps still saves output (has the 'clean' message)."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        # Even "No active gaps" is substantive output
        files = list((tlm_dir / "output").glob("gaps_*.txt"))
        assert len(files) == 1
