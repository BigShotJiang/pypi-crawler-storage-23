"""Tests for output recording and saving to .tlm/output/."""

import os
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest
from rich.console import Console


from tlm.output import start_recording, save_output


class TestStartRecording:
    def test_enables_record_mode(self):
        """start_recording sets console.record = True."""
        c = Console(record=False)
        assert c.record is False
        start_recording(c)
        assert c.record is True

    def test_idempotent(self):
        """Calling start_recording twice doesn't break anything."""
        c = Console(record=True)
        start_recording(c)
        assert c.record is True


class TestSaveOutput:
    def test_saves_file_with_content(self, tmp_path):
        """Output is saved to .tlm/output/{command}_{timestamp}.txt."""
        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        c.print("Hello from scan")

        path_str = save_output(c, "scan", str(tmp_path))

        assert path_str is not None
        assert path_str.endswith(".txt")
        output_dir = tmp_path / ".tlm" / "output"
        assert output_dir.exists()
        files = list(output_dir.glob("scan_*.txt"))
        assert len(files) == 1
        content = files[0].read_text()
        assert "Hello from scan" in content

    def test_filename_format(self, tmp_path):
        """File is named {command}_{YYYYMMDD_HHMMSS}.txt."""
        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        c.print("test")

        path_str = save_output(c, "gaps", str(tmp_path))

        filename = Path(path_str).name
        # gaps_YYYYMMDD_HHMMSS.txt
        assert filename.startswith("gaps_")
        assert filename.endswith(".txt")
        # Extract timestamp part
        ts_part = filename[len("gaps_"):-len(".txt")]
        # Should be parseable as datetime
        datetime.strptime(ts_part, "%Y%m%d_%H%M%S")

    def test_returns_relative_path(self, tmp_path):
        """Returned path starts with .tlm/output/ (relative style)."""
        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        c.print("data")

        path_str = save_output(c, "status", str(tmp_path))

        assert ".tlm/output/status_" in path_str

    def test_skips_when_no_tlm_dir(self, tmp_path):
        """If .tlm/ doesn't exist, silently returns None."""
        c = Console(record=True, width=80)
        c.print("some output")

        result = save_output(c, "scan", str(tmp_path))

        assert result is None
        assert not (tmp_path / ".tlm" / "output").exists()

    def test_skips_empty_output(self, tmp_path):
        """If recorded output is empty/whitespace, don't create a file."""
        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        # Don't print anything — export_text() returns empty/whitespace

        result = save_output(c, "scan", str(tmp_path))

        assert result is None
        output_dir = tmp_path / ".tlm" / "output"
        if output_dir.exists():
            assert list(output_dir.glob("*.txt")) == []

    def test_never_raises_on_write_error(self, tmp_path):
        """Errors during file write are swallowed — never raises."""
        (tmp_path / ".tlm").mkdir()
        # Make output dir a file so mkdir fails
        (tmp_path / ".tlm" / "output").write_text("blocker")

        c = Console(record=True, width=80)
        c.print("some output")

        # Should not raise
        result = save_output(c, "scan", str(tmp_path))
        assert result is None

    def test_creates_output_dir_if_missing(self, tmp_path):
        """.tlm/output/ dir is auto-created if .tlm/ exists but output/ doesn't."""
        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        c.print("content")

        save_output(c, "scan", str(tmp_path))

        assert (tmp_path / ".tlm" / "output").is_dir()

    def test_rich_tables_rendered_as_text(self, tmp_path):
        """Rich tables should be exported as ASCII text."""
        from rich.table import Table

        (tmp_path / ".tlm").mkdir()
        c = Console(record=True, width=80)
        table = Table(title="Test")
        table.add_column("Col")
        table.add_row("value")
        c.print(table)

        path_str = save_output(c, "status", str(tmp_path))

        content = Path(path_str).read_text()
        assert "Col" in content
        assert "value" in content

    def test_multiple_saves_create_separate_files(self, tmp_path):
        """Two calls with different timestamps create separate files."""
        (tmp_path / ".tlm").mkdir()

        c1 = Console(record=True, width=80)
        c1.print("first")
        save_output(c1, "scan", str(tmp_path))

        # Force a different timestamp
        with patch("tlm.output.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2099, 12, 31, 23, 59, 59)
            c2 = Console(record=True, width=80)
            c2.print("second")
            save_output(c2, "scan", str(tmp_path))

        files = list((tmp_path / ".tlm" / "output").glob("scan_*.txt"))
        assert len(files) == 2
