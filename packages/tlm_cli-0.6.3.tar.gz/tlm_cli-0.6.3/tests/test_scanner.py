"""Tests for scanner — dynamic file categorization and sampling."""

import pytest
from tlm.scanner import scan_project, _categorize_file


class TestScanProject:
    def test_scan_returns_file_tree(self, temp_project):
        result = scan_project(str(temp_project))
        assert "file_tree" in result
        assert isinstance(result["file_tree"], str)
        assert len(result["file_tree"]) > 0

    def test_scan_returns_samples(self, temp_project):
        result = scan_project(str(temp_project))
        assert "samples" in result
        assert isinstance(result["samples"], str)

    def test_scan_returns_summary(self, temp_project):
        result = scan_project(str(temp_project))
        assert "summary" in result
        summary = result["summary"]
        assert "total_files" in summary
        assert isinstance(summary["total_files"], int)
        assert summary["total_files"] > 0
        for key in ("manifests", "ci_configs", "deploy_scripts", "test_files",
                     "dockerfiles", "infra", "env_files", "custom_scripts"):
            assert key in summary
            assert isinstance(summary[key], list)

    def test_file_tree_contains_files(self, temp_project):
        result = scan_project(str(temp_project))
        assert "app.py" in result["file_tree"]
        assert "requirements.txt" in result["file_tree"]
        assert "README.md" in result["file_tree"]

    def test_scan_excludes_hidden_dirs(self, temp_project):
        (temp_project / ".git").mkdir()
        (temp_project / ".git" / "config").write_text("gitconfig")
        result = scan_project(str(temp_project))
        assert ".git/config" not in result["file_tree"]

    def test_scan_excludes_node_modules(self, temp_project):
        (temp_project / "node_modules").mkdir()
        (temp_project / "node_modules" / "pkg").mkdir()
        (temp_project / "node_modules" / "pkg" / "index.js").write_text("module.exports = {}")
        result = scan_project(str(temp_project))
        assert "node_modules" not in result["file_tree"]

    def test_scan_handles_empty_dir(self, tmp_path):
        result = scan_project(str(tmp_path))
        assert "file_tree" in result
        assert "samples" in result
        assert "summary" in result
        assert result["summary"]["total_files"] == 0

    def test_scan_limits_file_tree_depth(self, temp_project):
        d = temp_project
        for i in range(20):
            d = d / f"level{i}"
            d.mkdir()
            (d / "file.py").write_text(f"# level {i}")
        result = scan_project(str(temp_project))
        assert isinstance(result["file_tree"], str)

    def test_samples_contain_categorized_files(self, temp_project):
        result = scan_project(str(temp_project))
        # Dockerfile, requirements.txt, deploy.sh should be sampled
        assert "=== Dockerfile ===" in result["samples"]
        assert "=== requirements.txt ===" in result["samples"]


class TestCategorizeByDirectory:
    def test_github_workflows_are_ci_configs(self, tmp_path):
        result = _categorize_file(".github/workflows/ci.yml", str(tmp_path))
        assert result == "ci_configs"

    def test_circleci_is_ci_config(self, tmp_path):
        result = _categorize_file(".circleci/config.yml", str(tmp_path))
        assert result == "ci_configs"

    def test_buildkite_is_ci_config(self, tmp_path):
        result = _categorize_file(".buildkite/pipeline.yml", str(tmp_path))
        assert result == "ci_configs"

    def test_gitlab_ci_is_ci_config(self, tmp_path):
        result = _categorize_file(".gitlab-ci.yml", str(tmp_path))
        assert result == "ci_configs"

    def test_jenkinsfile_is_ci_config(self, tmp_path):
        result = _categorize_file("Jenkinsfile", str(tmp_path))
        assert result == "ci_configs"

    def test_tests_dir_is_test_files(self, tmp_path):
        result = _categorize_file("tests/test_api.py", str(tmp_path))
        assert result == "test_files"

    def test_test_dir_is_test_files(self, tmp_path):
        result = _categorize_file("test/unit/helper_test.js", str(tmp_path))
        assert result == "test_files"

    def test_dunder_tests_is_test_files(self, tmp_path):
        result = _categorize_file("src/__tests__/App.test.tsx", str(tmp_path))
        assert result == "test_files"

    def test_spec_dir_is_test_files(self, tmp_path):
        result = _categorize_file("spec/models/user_spec.rb", str(tmp_path))
        assert result == "test_files"


class TestCategorizeByFilename:
    def test_dockerfile(self, tmp_path):
        assert _categorize_file("Dockerfile", str(tmp_path)) == "dockerfiles"

    def test_dockerfile_with_suffix(self, tmp_path):
        assert _categorize_file("Dockerfile.prod", str(tmp_path)) == "dockerfiles"

    def test_docker_compose(self, tmp_path):
        assert _categorize_file("docker-compose.yml", str(tmp_path)) == "dockerfiles"

    def test_docker_compose_yaml(self, tmp_path):
        assert _categorize_file("docker-compose.yaml", str(tmp_path)) == "dockerfiles"

    def test_package_json_is_manifest(self, tmp_path):
        assert _categorize_file("package.json", str(tmp_path)) == "manifests"

    def test_requirements_txt_is_manifest(self, tmp_path):
        assert _categorize_file("requirements.txt", str(tmp_path)) == "manifests"

    def test_requirements_dev_txt_is_manifest(self, tmp_path):
        assert _categorize_file("requirements-dev.txt", str(tmp_path)) == "manifests"

    def test_pyproject_toml_is_manifest(self, tmp_path):
        assert _categorize_file("pyproject.toml", str(tmp_path)) == "manifests"

    def test_go_mod_is_manifest(self, tmp_path):
        assert _categorize_file("go.mod", str(tmp_path)) == "manifests"

    def test_cargo_toml_is_manifest(self, tmp_path):
        assert _categorize_file("Cargo.toml", str(tmp_path)) == "manifests"

    def test_nested_manifest(self, tmp_path):
        assert _categorize_file("backend/requirements.txt", str(tmp_path)) == "manifests"

    def test_env_file(self, tmp_path):
        assert _categorize_file(".env", str(tmp_path)) == "env_files"

    def test_env_example(self, tmp_path):
        assert _categorize_file(".env.example", str(tmp_path)) == "env_files"

    def test_env_local(self, tmp_path):
        assert _categorize_file(".env.local", str(tmp_path)) == "env_files"

    def test_terraform_is_infra(self, tmp_path):
        assert _categorize_file("main.tf", str(tmp_path)) == "infra"

    def test_tfvars_is_infra(self, tmp_path):
        assert _categorize_file("prod.tfvars", str(tmp_path)) == "infra"

    def test_test_prefix_is_test(self, tmp_path):
        assert _categorize_file("test_auth.py", str(tmp_path)) == "test_files"

    def test_dot_test_is_test(self, tmp_path):
        assert _categorize_file("auth.test.ts", str(tmp_path)) == "test_files"

    def test_underscore_test_is_test(self, tmp_path):
        assert _categorize_file("auth_test.go", str(tmp_path)) == "test_files"

    def test_deploy_name_is_deploy_script(self, tmp_path):
        assert _categorize_file("deploy.sh", str(tmp_path)) == "deploy_scripts"

    def test_release_name_is_deploy_script(self, tmp_path):
        assert _categorize_file("release-apk.sh", str(tmp_path)) == "deploy_scripts"


class TestCategorizeByContent:
    def test_sh_in_scripts_with_deploy_keyword(self, tmp_path):
        (tmp_path / "scripts").mkdir()
        (tmp_path / "scripts" / "run.sh").write_text("#!/bin/bash\nfirebase deploy\n")
        result = _categorize_file("scripts/run.sh", str(tmp_path))
        assert result == "deploy_scripts"

    def test_sh_in_scripts_without_deploy_keyword(self, tmp_path):
        (tmp_path / "scripts").mkdir()
        (tmp_path / "scripts" / "lint.sh").write_text("#!/bin/bash\nflake8 .\n")
        result = _categorize_file("scripts/lint.sh", str(tmp_path))
        assert result == "custom_scripts"

    def test_py_in_scripts_is_custom_script(self, tmp_path):
        (tmp_path / "scripts").mkdir()
        (tmp_path / "scripts" / "migrate.py").write_text("import db\n")
        result = _categorize_file("scripts/migrate.py", str(tmp_path))
        assert result == "custom_scripts"

    def test_sh_in_bin_with_release(self, tmp_path):
        (tmp_path / "bin").mkdir()
        (tmp_path / "bin" / "go.sh").write_text("#!/bin/bash\nrelease to prod\n")
        result = _categorize_file("bin/go.sh", str(tmp_path))
        assert result == "deploy_scripts"


class TestCategorizeUncategorized:
    def test_random_source_file(self, tmp_path):
        assert _categorize_file("src/utils.py", str(tmp_path)) is None

    def test_readme(self, tmp_path):
        assert _categorize_file("README.md", str(tmp_path)) is None

    def test_random_config(self, tmp_path):
        assert _categorize_file("config.yaml", str(tmp_path)) is None


class TestScanSummary:
    def test_summary_finds_manifests(self, temp_project):
        result = scan_project(str(temp_project))
        assert "requirements.txt" in result["summary"]["manifests"]

    def test_summary_finds_test_files(self, temp_project):
        result = scan_project(str(temp_project))
        found = [f for f in result["summary"]["test_files"] if "test_app" in f]
        assert len(found) > 0

    def test_summary_finds_deploy_scripts(self, temp_project):
        result = scan_project(str(temp_project))
        found = [f for f in result["summary"]["deploy_scripts"] if "deploy" in f]
        assert len(found) > 0

    def test_summary_finds_dockerfiles(self, temp_project):
        result = scan_project(str(temp_project))
        assert any("Dockerfile" in f for f in result["summary"]["dockerfiles"])

    def test_summary_finds_custom_scripts(self, temp_project):
        result = scan_project(str(temp_project))
        found = [f for f in result["summary"]["custom_scripts"] if "run_tests" in f]
        assert len(found) > 0

    def test_ci_configs_empty_when_no_ci(self, temp_project):
        result = scan_project(str(temp_project))
        assert result["summary"]["ci_configs"] == []

    def test_ci_configs_detected(self, project_with_ci):
        result = scan_project(str(project_with_ci))
        assert len(result["summary"]["ci_configs"]) > 0

    def test_no_sample_cap(self, tmp_path):
        """All categorized files should be sampled, not just 10."""
        (tmp_path / "tests").mkdir()
        for i in range(15):
            (tmp_path / "tests" / f"test_{i}.py").write_text(f"def test_{i}(): pass\n")
        result = scan_project(str(tmp_path))
        assert len(result["summary"]["test_files"]) == 15
        # All should be sampled
        for i in range(15):
            assert f"test_{i}.py" in result["samples"]
