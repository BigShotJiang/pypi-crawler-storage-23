"""Tests for prompts/rules.py — CLAUDE.md and rule file generation."""

import pytest

from tlm.prompts.rules import build_claude_md, build_rule_files, _extract_test_command


SAMPLE_CONFIG = {
    "checks": [
        {"name": "Tests", "command": "pytest tests/ -v", "blocker": True, "category": "testing"},
        {"name": "Lint", "command": "flake8 .", "blocker": False, "category": "linting"},
    ],
    "environments": {
        "staging": {"deploy_command": "deploy staging", "verify_command": "curl staging"},
        "production": {"deploy_command": "deploy prod", "verify_command": "curl prod"},
    },
    "coverage": {"command": "pytest --cov", "min_line_coverage": 70},
}


class TestBuildClaudeMd:
    def test_returns_string_with_tdd_section(self):
        """build_claude_md should include TDD protocol section."""
        result = build_claude_md(SAMPLE_CONFIG)
        assert isinstance(result, str)
        assert "TDD Protocol" in result

    def test_returns_string_with_deployment_section(self):
        """build_claude_md should include deployment protocol section."""
        result = build_claude_md(SAMPLE_CONFIG)
        assert "Deployment Protocol" in result
        assert "deploy staging" in result
        assert "deploy prod" in result

    def test_returns_string_with_project_commands(self):
        """build_claude_md should include project commands section."""
        result = build_claude_md(SAMPLE_CONFIG)
        assert "Project Commands" in result
        assert "pytest tests/ -v" in result

    def test_includes_quality_checks(self):
        """build_claude_md should list quality checks from config."""
        result = build_claude_md(SAMPLE_CONFIG)
        assert "Tests" in result
        assert "Lint" in result
        assert "BLOCKER" in result

    def test_includes_test_command_in_tdd(self):
        """TDD section should reference the extracted test command."""
        result = build_claude_md(SAMPLE_CONFIG)
        # The TDD protocol template inserts the test command
        assert "pytest tests/ -v" in result

    def test_empty_config_graceful(self):
        """build_claude_md({}) should handle empty config without errors."""
        result = build_claude_md({})
        assert isinstance(result, str)
        assert "TDD Protocol" in result
        # Should show default fallback for missing sections
        assert "No deployment environments configured" in result
        assert "No test command configured" in result

    def test_empty_config_has_state_management(self):
        """Even empty config should produce state management section."""
        result = build_claude_md({})
        assert "State Management" in result

    def test_environment_ordering(self):
        """Environments should appear as numbered steps."""
        result = build_claude_md(SAMPLE_CONFIG)
        assert "1. **staging**" in result
        assert "2. **production**" in result


class TestBuildRuleFiles:
    def test_returns_dict_with_tdd_key(self):
        """build_rule_files should always include tlm-tdd.md."""
        rules = build_rule_files(SAMPLE_CONFIG)
        assert isinstance(rules, dict)
        assert "tlm-tdd.md" in rules

    def test_tdd_rule_contains_test_command(self):
        """TDD rule file should contain the project's test command."""
        rules = build_rule_files(SAMPLE_CONFIG)
        assert "pytest tests/ -v" in rules["tlm-tdd.md"]

    def test_tdd_rule_mentions_tdd(self):
        """TDD rule should mention TDD enforcement."""
        rules = build_rule_files(SAMPLE_CONFIG)
        assert "TDD" in rules["tlm-tdd.md"]

    def test_includes_deploy_rule_when_environments_exist(self):
        """build_rule_files should include tlm-deploy.md when environments are configured."""
        rules = build_rule_files(SAMPLE_CONFIG)
        assert "tlm-deploy.md" in rules

    def test_deploy_rule_lists_environments(self):
        """Deploy rule should list all configured environments."""
        rules = build_rule_files(SAMPLE_CONFIG)
        deploy_content = rules["tlm-deploy.md"]
        assert "staging" in deploy_content
        assert "production" in deploy_content
        assert "deploy staging" in deploy_content
        assert "deploy prod" in deploy_content

    def test_no_deploy_rule_when_no_environments(self):
        """build_rule_files({}) should not have deploy rule when no environments."""
        rules = build_rule_files({})
        assert "tlm-deploy.md" not in rules

    def test_no_deploy_rule_with_empty_environments(self):
        """build_rule_files should not have deploy rule when environments dict is empty."""
        rules = build_rule_files({"environments": {}})
        assert "tlm-deploy.md" not in rules

    def test_still_has_tdd_when_no_environments(self):
        """TDD rule should always be present even without environments."""
        rules = build_rule_files({})
        assert "tlm-tdd.md" in rules


class TestExtractTestCommand:
    def test_finds_testing_category(self):
        """Should find command from check with category 'testing'."""
        result = _extract_test_command(SAMPLE_CONFIG)
        assert result == "pytest tests/ -v"

    def test_ignores_non_testing_categories(self):
        """Should not pick up linting or other categories."""
        config = {
            "checks": [
                {"name": "Lint", "command": "flake8 .", "blocker": False, "category": "linting"},
            ],
        }
        result = _extract_test_command(config)
        # No testing category, no coverage -> default
        assert result == "echo 'No test command configured'"

    def test_falls_back_to_coverage_command(self):
        """Should fall back to coverage command when no testing category exists."""
        config = {
            "checks": [
                {"name": "Lint", "command": "flake8 .", "blocker": False, "category": "linting"},
            ],
            "coverage": {"command": "pytest --cov", "min_line_coverage": 70},
        }
        result = _extract_test_command(config)
        assert result == "pytest --cov"

    def test_returns_default_when_nothing_configured(self):
        """Should return default message when no test command is found anywhere."""
        result = _extract_test_command({})
        assert result == "echo 'No test command configured'"

    def test_testing_category_takes_priority_over_coverage(self):
        """Testing category check should be preferred over coverage fallback."""
        result = _extract_test_command(SAMPLE_CONFIG)
        # SAMPLE_CONFIG has both testing category and coverage
        # Testing category should win
        assert result == "pytest tests/ -v"
        assert result != "pytest --cov"

    def test_empty_checks_list(self):
        """Should handle empty checks list gracefully."""
        config = {"checks": []}
        result = _extract_test_command(config)
        assert result == "echo 'No test command configured'"

    def test_coverage_without_command_key(self):
        """Should handle coverage dict that has no 'command' key."""
        config = {"coverage": {"min_line_coverage": 70}}
        result = _extract_test_command(config)
        assert result == "echo 'No test command configured'"
