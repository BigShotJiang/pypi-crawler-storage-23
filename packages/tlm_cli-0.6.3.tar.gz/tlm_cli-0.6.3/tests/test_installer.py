"""Tests for installer — full install flow."""

import json
import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path

from tlm.installer import Installer
from tlm.gaps import load_gaps, GapStatus
from tlm.state import read_state
from tlm.config import load_project_config


MOCK_ASSESS_RESULT = {
    "recommendations": [
        {"id": "cicd", "type": "cicd", "category": "CI/CD",
         "severity": "critical", "description": "No CI/CD pipeline", "fixable": True},
        {"id": "testing", "type": "testing", "category": "Testing",
         "severity": "critical", "description": "No tests", "fixable": True},
        {"id": "monitoring", "type": "monitoring", "category": "Ops",
         "severity": "medium", "description": "No monitoring", "fixable": True},
    ],
    "profile": {"stack": "Python Flask", "has_ci": False},
}


class TestInstallerInit:
    def test_creates_tlm_dir(self, tmp_path):
        """Installer should create .tlm/ directory."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        assert (tmp_path / ".tlm").is_dir()
        assert (tmp_path / ".tlm" / "specs").is_dir()
        assert (tmp_path / ".tlm" / "cache").is_dir()

    def test_init_is_idempotent(self, tmp_path):
        """Calling init twice should not error."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.init_project_dir()
        assert (tmp_path / ".tlm").is_dir()


class TestInstallerScan:
    def test_scan_caches_results_locally(self, tmp_path):
        """Scan results should be cached in .tlm/cache/scan_result.json."""
        (tmp_path / "app.py").write_text("print('hello')")

        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        scan_data = installer.scan_project()

        cache_file = tmp_path / ".tlm" / "cache" / "scan_result.json"
        assert cache_file.exists()

        cached = json.loads(cache_file.read_text())
        assert "file_tree" in cached
        assert "samples" in cached

    def test_scan_returns_file_tree_and_samples(self, tmp_path):
        """Scan should return dict with file_tree and samples."""
        (tmp_path / "app.py").write_text("print('hello')")
        (tmp_path / "requirements.txt").write_text("flask==3.0.0")

        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        result = installer.scan_project()

        assert "file_tree" in result
        assert "samples" in result
        assert "app.py" in result["file_tree"]


class TestInstallerAssess:
    @patch("tlm.installer.TLMClient")
    def test_assess_calls_server_and_caches(self, mock_client_cls, tmp_path):
        """assess() should call server and cache the result."""
        mock_client = MagicMock()
        mock_client.assess = MagicMock(return_value=MOCK_ASSESS_RESULT)
        mock_client_cls.return_value = mock_client

        (tmp_path / "app.py").write_text("print('hello')")

        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        scan_data = installer.scan_project()
        result = installer.assess(scan_data)

        assert "recommendations" in result
        assert len(result["recommendations"]) == 3

        # Should be cached
        cache_file = tmp_path / ".tlm" / "cache" / "assess_result.json"
        assert cache_file.exists()

    @patch("tlm.installer.TLMClient")
    def test_assess_uses_cache_if_available(self, mock_client_cls, tmp_path):
        """assess() should use cached result if scan data hasn't changed."""
        mock_client = MagicMock()
        mock_client.assess = MagicMock(return_value=MOCK_ASSESS_RESULT)
        mock_client_cls.return_value = mock_client

        (tmp_path / "app.py").write_text("print('hello')")

        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        scan_data = installer.scan_project()

        # First call → server
        installer.assess(scan_data)
        assert mock_client.assess.call_count == 1

        # Second call with same scan_data → cache
        installer.assess(scan_data)
        assert mock_client.assess.call_count == 1


class TestInstallerGaps:
    def test_populate_gaps_from_recommendations(self, tmp_path):
        """populate_gaps() should create gap entries from recommendations."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.populate_gaps(MOCK_ASSESS_RESULT["recommendations"])

        gaps = load_gaps(str(tmp_path))
        assert len(gaps) == 3
        assert gaps[0]["id"] == "cicd"
        assert gaps[0]["status"] == GapStatus.DETECTED.value


class TestInstallerQuality:
    def test_save_quality_tier(self, tmp_path):
        """save_quality_tier() should persist to config."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.save_quality_tier("high")

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "high"

    def test_save_quality_tier_standard(self, tmp_path):
        """Should accept standard tier."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.save_quality_tier("standard")

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "standard"


class TestInstallerHooks:
    def test_install_hooks_creates_settings(self, tmp_path):
        """install_hooks() should create .claude/settings.json with hooks."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.install_hooks()

        settings_path = tmp_path / ".claude" / "settings.json"
        assert settings_path.exists()

        settings = json.loads(settings_path.read_text())
        assert "hooks" in settings

    def test_install_hooks_has_all_hook_types(self, tmp_path):
        """Installed hooks should cover all 3 event types."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.install_hooks()

        settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
        hooks = settings["hooks"]

        assert isinstance(hooks, dict)
        assert "PreToolUse" in hooks
        assert "PostToolUse" in hooks
        assert "Stop" in hooks

    def test_install_hooks_preserves_existing_settings(self, tmp_path):
        """install_hooks() should merge with existing settings."""
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir(parents=True)
        (claude_dir / "settings.json").write_text(json.dumps({
            "permissions": {"allow": ["Read"]},
        }))

        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.install_hooks()

        settings = json.loads((claude_dir / "settings.json").read_text())
        assert "permissions" in settings
        assert "hooks" in settings


class TestInstallerFinalize:
    def test_finalize_sets_idle_state(self, tmp_path):
        """finalize() should set state to idle."""
        installer = Installer(str(tmp_path), server_url="http://test:8000", api_key="key")
        installer.init_project_dir()
        installer.finalize()

        state = read_state(str(tmp_path))
        assert state["phase"] == "idle"
