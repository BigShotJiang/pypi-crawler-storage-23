"""HTTP client for TLM server endpoints (V1 + V2).

Synchronous client with proper error handling and exception mapping.
Ported from MVP's api_client.py pattern, keeping V2's endpoint coverage.
"""

import httpx
from httpx import ConnectError as _HttpxConnectError
from httpx import TimeoutException as _HttpxTimeoutException


# ── Exceptions ───────────────────────────────────────────────

class TLMAuthError(Exception):
    """Authentication failed (401/403)."""
    pass


class TLMCreditsError(Exception):
    """Credits exhausted (402)."""
    pass


class TLMProjectLimitError(Exception):
    """Project limit reached (403 with project_limit_reached)."""
    pass


class TLMServerError(Exception):
    """Server returned an error (4xx/5xx)."""
    pass


class TLMConnectionError(Exception):
    """Cannot reach TLM server."""
    pass


# ── Client ───────────────────────────────────────────────────

class TLMClient:
    """Synchronous HTTP client for TLM server API."""

    def __init__(self, server_url: str, api_key: str):
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _url(self, path: str) -> str:
        return f"{self.server_url}/api/v1{path}"

    def _url_v2(self, path: str) -> str:
        return f"{self.server_url}/api/v2{path}"

    def _handle_response(self, resp) -> dict:
        """Map HTTP status codes to typed exceptions."""
        if resp.status_code == 402:
            detail = {}
            try:
                detail = resp.json().get("detail", {})
            except KeyboardInterrupt:
                raise
            except Exception:
                pass
            raise TLMCreditsError(detail)

        if resp.status_code == 403:
            detail = {}
            try:
                detail = resp.json().get("detail", {})
            except KeyboardInterrupt:
                raise
            except Exception:
                detail = resp.text
            if isinstance(detail, dict) and detail.get("error") == "project_limit_reached":
                raise TLMProjectLimitError(detail)
            raise TLMAuthError(f"Authentication failed: {detail}")

        if resp.status_code == 401:
            detail = ""
            try:
                detail = resp.json().get("detail", "")
            except KeyboardInterrupt:
                raise
            except Exception:
                detail = resp.text
            raise TLMAuthError(f"Authentication failed: {detail}")

        if resp.status_code >= 400:
            detail = ""
            try:
                detail = resp.json().get("detail", "")
            except KeyboardInterrupt:
                raise
            except Exception:
                detail = resp.text
            raise TLMServerError(f"Server error ({resp.status_code}): {detail}")

        return resp.json()

    def _post(self, path: str, data: dict, timeout: float = 60.0) -> dict:
        try:
            resp = httpx.post(self._url(path), json=data, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _post_v2(self, path: str, data: dict, timeout: float = 120.0) -> dict:
        try:
            resp = httpx.post(self._url_v2(path), json=data, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _get(self, path: str, params: dict = None, timeout: float = 30.0) -> dict:
        try:
            resp = httpx.get(self._url(path), params=params, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _delete(self, path: str, timeout: float = 30.0) -> dict:
        try:
            resp = httpx.delete(self._url(path), headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    # ── Auth ─────────────────────────────────────────

    def me(self) -> dict:
        """GET /api/v1/auth/me"""
        return self._get("/auth/me")

    def exchange_firebase_token(self, firebase_token: str) -> dict:
        """POST /api/v1/auth/firebase — exchange Firebase token for TLM API key."""
        return self._post("/auth/firebase", {"firebase_token": firebase_token})

    # ── Projects ─────────────────────────────────────

    def create_project(self, name: str, fingerprint: str) -> dict:
        """POST /api/v1/projects"""
        return self._post("/projects", {"name": name, "fingerprint": fingerprint})

    def list_projects(self) -> dict:
        """GET /api/v1/projects"""
        return self._get("/projects")

    def delete_project(self, project_id: str) -> dict:
        """DELETE /api/v1/projects/{id}"""
        return self._delete(f"/projects/{project_id}")

    # ── Intelligence ─────────────────────────────────

    def scan(self, project_id, file_tree: str, samples: str, *, local_analysis: str = None) -> dict:
        """POST /api/v1/projects/{id}/scan — with retry on timeout."""
        payload = {"file_tree": file_tree, "samples": samples}
        if local_analysis is not None:
            payload["local_analysis"] = local_analysis
        path = f"/projects/{project_id}/scan"
        for attempt in range(3):
            try:
                return self._post(path, payload, timeout=30.0)
            except TLMConnectionError as e:
                if "timed out" in str(e).lower() and attempt < 2:
                    continue
                raise

    def generate_config(self, project_id: str, profile: str, file_tree: str, samples: str, *, local_config=None) -> dict:
        """POST /api/v1/projects/{id}/generate-config"""
        payload = {"profile": profile, "file_tree": file_tree, "samples": samples}
        if local_config is not None:
            payload["local_config"] = local_config
        return self._post(f"/projects/{project_id}/generate-config", payload, timeout=120.0)

    def update_config(self, project_id: str, current_config: dict, feedback: str, profile: str) -> dict:
        """POST /api/v1/projects/{id}/update-config"""
        return self._post(f"/projects/{project_id}/update-config", {
            "current_config": current_config, "feedback": feedback, "profile": profile,
        }, timeout=120.0)

    def approve_config(self, project_id: str, config: dict) -> dict:
        """POST /api/v1/projects/{id}/approve-config"""
        return self._post(f"/projects/{project_id}/approve-config", {"config": config})

    def check_drift(self, project_id: str, config: dict, changed_files: dict, file_contents: dict) -> dict:
        """POST /api/v1/projects/{id}/check-drift"""
        return self._post(f"/projects/{project_id}/check-drift", {
            "config": config, "changed_files": changed_files, "file_contents": file_contents,
        })

    def compliance_check(self, project_id: str, spec: str, diff: str, profile: str, enforcement_config: str) -> dict:
        """POST /api/v1/projects/{id}/compliance-check"""
        return self._post(f"/projects/{project_id}/compliance-check", {
            "spec": spec, "diff": diff, "profile": profile, "enforcement_config": enforcement_config,
        })

    # ── Discovery ────────────────────────────────────

    def discovery_start(self, project_id: str, feature_request: str) -> dict:
        """POST /api/v1/projects/{id}/discovery/start"""
        return self._post(f"/projects/{project_id}/discovery/start", {"feature_request": feature_request})

    def discovery_respond(self, project_id: str, session_id: str, user_input: str) -> dict:
        """POST /api/v1/projects/{id}/discovery/{session_id}/respond"""
        return self._post(f"/projects/{project_id}/discovery/{session_id}/respond", {"user_input": user_input})

    def discovery_generate(self, project_id: str, session_id: str) -> dict:
        """POST /api/v1/projects/{id}/discovery/{session_id}/generate"""
        return self._post(f"/projects/{project_id}/discovery/{session_id}/generate", {})

    # ── Learning ─────────────────────────────────────

    def analyze_commit(self, project_id: str, commit: dict) -> dict:
        """POST /api/v1/projects/{id}/analyze-commit"""
        return self._post(f"/projects/{project_id}/analyze-commit", {"commit": commit}, timeout=180.0)

    def synthesize(self, project_id: str, analyzed_commits: list) -> dict:
        """POST /api/v1/projects/{id}/synthesize"""
        return self._post(f"/projects/{project_id}/synthesize", {"analyzed_commits": analyzed_commits}, timeout=180.0)

    def learning_status(self, project_id: str) -> dict:
        """GET /api/v1/projects/{id}/learning-status"""
        return self._get(f"/projects/{project_id}/learning-status")

    # ── Usage ────────────────────────────────────────

    def usage(self) -> dict:
        """GET /api/v1/usage"""
        return self._get("/usage")

    # ── Sync ─────────────────────────────────────────

    def sync(self, project_id: str, timeout: float = 3.0) -> dict:
        """GET /api/v1/projects/{id}/sync"""
        return self._get(f"/projects/{project_id}/sync", timeout=timeout)

    # ── V2: Assess + Gap Remediation ─────────────────

    def assess(self, project_id: int, file_tree: str, samples: str) -> dict:
        """POST /api/v2/projects/{id}/assess"""
        return self._post_v2(
            f"/projects/{project_id}/assess",
            {"file_tree": file_tree, "samples": samples},
        )

    def get_interview(self, project_id: int, rec_id: str, project_state: dict, quality_tier: str) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/interview"""
        return self._post_v2(
            f"/projects/{project_id}/recommendations/{rec_id}/interview",
            {"project_state": project_state, "quality_tier": quality_tier},
        )

    def build_context(self, project_id: int, rec_id: str, answers: dict, project_state: dict, quality_tier: str) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/context"""
        return self._post_v2(
            f"/projects/{project_id}/recommendations/{rec_id}/context",
            {"answers": answers, "project_state": project_state, "quality_tier": quality_tier},
        )

    def review_plan(self, project_id: int, rec_id: str, plan_output: str, project_state: dict, quality_tier: str) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/review"""
        return self._post_v2(
            f"/projects/{project_id}/recommendations/{rec_id}/review",
            {"plan_output": plan_output, "project_state": project_state, "quality_tier": quality_tier},
        )

    # ── V2: Review ───────────────────────────────────

    def review_code(self, project_id: int, spec: str, code: str, files_changed: list[str],
                    project_knowledge: str = "", timeout: int = 120) -> dict:
        """POST /api/v2/review/code"""
        return self._post_v2("/review/code", {
            "project_id": project_id, "spec": spec, "code": code,
            "files_changed": files_changed, "project_knowledge": project_knowledge,
        }, timeout=timeout)

    def review_spec(self, project_id: int, spec: str, project_knowledge: str,
                    quality_level: str, timeout: int = 120) -> dict:
        """POST /api/v2/review/spec"""
        return self._post_v2("/review/spec", {
            "project_id": project_id, "spec": spec,
            "project_knowledge": project_knowledge, "quality_level": quality_level,
        }, timeout=timeout)

    # ── V2: Embedding ────────────────────────────────

    def embed(self, texts: list) -> dict:
        """POST /api/v2/embed"""
        return self._post_v2("/embed", {"texts": texts})

    # ── V2: Session Learning ─────────────────────────

    def learn_session(self, session_summary: dict, project_knowledge: str = "") -> dict:
        """POST /api/v2/learn/session"""
        return self._post_v2("/learn/session", {
            "session_summary": session_summary, "project_knowledge": project_knowledge,
        })

    # ── V2: Interceptor Reviews ────────────────────────

    def review_plan_or_diff(self, project_id: int, content: str, review_type: str, timeout: float = 10.0) -> dict:
        """POST /api/v2/projects/{id}/review — review a plan or diff."""
        return self._post_v2(
            f"/projects/{project_id}/review",
            {"content": content, "review_type": review_type},
            timeout=timeout,
        )

    def review_command(self, project_id: int, command: str, timeout: float = 10.0) -> dict:
        """POST /api/v2/projects/{id}/review-command — review a risky bash command."""
        return self._post_v2(
            f"/projects/{project_id}/review-command",
            {"command": command},
            timeout=timeout,
        )

    # ── V2: Session Sync + Rules ────────────────────────

    def sync_session(self, project_id: int, summary: str, timeout: float = 10.0) -> dict:
        """POST /api/v2/projects/{id}/sync-session — send session transcript for learning."""
        return self._post_v2(
            f"/projects/{project_id}/sync-session",
            {"summary": summary},
            timeout=timeout,
        )

    def get_rules(self, project_id: int) -> dict:
        """GET /api/v2/projects/{id}/rules — list active rules."""
        try:
            resp = httpx.get(
                self._url_v2(f"/projects/{project_id}/rules"),
                headers=self._headers(),
                timeout=10.0,
            )
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def delete_rule(self, project_id: int, rule_id: int) -> dict:
        """DELETE /api/v2/projects/{id}/rules/{rule_id} — soft-delete a rule."""
        try:
            resp = httpx.delete(
                self._url_v2(f"/projects/{project_id}/rules/{rule_id}"),
                headers=self._headers(),
                timeout=10.0,
            )
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    # ── Error Reporting ──────────────────────────────

    def report_error(self, project_id: str, error_type: str, error_detail: str, context: str = ""):
        """Fire-and-forget error report. Swallows all exceptions."""
        try:
            httpx.post(
                self._url(f"/projects/{project_id}/error-report"),
                json={"error_type": error_type, "error_detail": error_detail, "context": context},
                headers=self._headers(),
                timeout=3.0,
            )
        except KeyboardInterrupt:
            raise
        except Exception:
            pass
