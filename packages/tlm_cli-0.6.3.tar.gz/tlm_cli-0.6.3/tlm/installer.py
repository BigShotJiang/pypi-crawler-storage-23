"""Installer — full install flow: scan → assess → quality → gaps → hooks → finalize.

Also handles CLAUDE.md generation, .claude/rules/ and .claude/hooks/ creation,
git post-commit hook for background learning, and uninstall.

All computed data (scan results, server responses) is cached in .tlm/cache/
so retries don't recompute.
"""

import hashlib
import json
import stat
from pathlib import Path

from tlm.client import TLMClient
from tlm.config import save_project_config, load_project_config
from tlm.gaps import add_gap
from tlm.hooks_format import build_all_hooks
from tlm.prompts.rules import build_claude_md, build_rule_files
from tlm.scanner import scan_project
from tlm.state import write_state, DEFAULT_STATE


# TLM markers used to identify TLM content in CLAUDE.md
TLM_MARKER_START = "<!-- TLM:START -->"
TLM_MARKER_END = "<!-- TLM:END -->"


class Installer:
    """Manages the full TLM install flow for a project."""

    def __init__(self, project_root: str, server_url: str = "", api_key: str = ""):
        self.root = Path(project_root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.cache_dir = self.tlm_dir / "cache"
        self.claude_dir = self.root / ".claude"
        self.hooks_dir = self.claude_dir / "hooks"
        self.rules_dir = self.claude_dir / "rules"
        self.settings_file = self.claude_dir / "settings.json"
        self.claude_md = self.root / "CLAUDE.md"
        self.server_url = server_url
        self.api_key = api_key

    def _get_client(self) -> TLMClient:
        return TLMClient(server_url=self.server_url, api_key=self.api_key)

    # ── Phase 1: Init ────────────────────────────────────────

    def init_project_dir(self):
        """Create .tlm/ directory structure."""
        self.tlm_dir.mkdir(parents=True, exist_ok=True)
        (self.tlm_dir / "specs").mkdir(exist_ok=True)
        (self.tlm_dir / "cache").mkdir(exist_ok=True)

    # ── Phase 1b: Create/get project on server ──────────────

    def ensure_project(self) -> int:
        """Create or get project on server. Returns project_id."""
        config = load_project_config(str(self.root))
        if config.get("project_id"):
            return int(config["project_id"])

        name = self.root.resolve().name
        fingerprint = hashlib.sha256(
            str(self.root.resolve()).encode()
        ).hexdigest()[:16]

        client = self._get_client()
        result = client.create_project(name, fingerprint)
        project_id = result["project_id"]

        save_project_config(str(self.root), {"project_id": project_id})
        return project_id

    # ── Phase 2: Scan ────────────────────────────────────────

    def scan_project(self) -> dict:
        """Scan project and cache results in .tlm/cache/scan_result.json."""
        result = scan_project(str(self.root))

        cache_file = self.cache_dir / "scan_result.json"
        cache_file.write_text(json.dumps(result, indent=2))

        return result

    # ── Phase 3: Assess ──────────────────────────────────────

    def assess(self, scan_data: dict) -> dict:
        """Send scan data to server for assessment. Caches result."""
        scan_hash = hashlib.sha256(
            json.dumps(scan_data, sort_keys=True).encode()
        ).hexdigest()[:16]

        cache_file = self.cache_dir / "assess_result.json"

        if cache_file.exists():
            try:
                cached = json.loads(cache_file.read_text())
                if cached.get("_scan_hash") == scan_hash:
                    return cached["result"]
            except (json.JSONDecodeError, OSError):
                pass

        config = load_project_config(str(self.root))
        project_id = config.get("project_id", 0)

        client = self._get_client()
        result = client.assess(
            project_id,
            scan_data["file_tree"],
            scan_data["samples"],
        )

        # Only cache successful results (not parse errors)
        if not result.get("profile", {}).get("parse_error"):
            cache_file.write_text(json.dumps({
                "_scan_hash": scan_hash,
                "result": result,
            }, indent=2))

        return result

    def clear_assess_cache(self):
        """Delete cached assess result so next assess() call hits the server."""
        cache_file = self.cache_dir / "assess_result.json"
        if cache_file.exists():
            cache_file.unlink()

    # ── Phase 4: Quality tier ────────────────────────────────

    def save_quality_tier(self, tier: str):
        """Save quality tier to project config."""
        save_project_config(str(self.root), {"quality_control": tier})

    # ── Phase 5: Gaps ────────────────────────────────────────

    def populate_gaps(self, recommendations: list[dict]):
        """Create gap entries from server recommendations."""
        for rec in recommendations:
            add_gap(str(self.root), {
                "id": rec["id"],
                "type": rec.get("type", rec["id"]),
                "category": rec.get("category", ""),
                "severity": rec.get("severity", "medium"),
                "description": rec.get("description", ""),
            })

    # ── Phase 6: CLAUDE.md + Rules ──────────────────────────

    def generate_claude_md(self):
        """Generate or update CLAUDE.md with TLM rules."""
        enforcement_config = self._load_enforcement_config()
        tlm_content = (
            f"{TLM_MARKER_START}\n"
            f"{build_claude_md(enforcement_config)}\n"
            f"{TLM_MARKER_END}"
        )

        if self.claude_md.exists():
            existing = self.claude_md.read_text()

            if TLM_MARKER_START in existing:
                start = existing.index(TLM_MARKER_START)
                end = existing.index(TLM_MARKER_END) + len(TLM_MARKER_END)
                new_content = existing[:start] + tlm_content + existing[end:]
            elif "# TLM Engineering Rules" in existing:
                marker = "# TLM Engineering Rules"
                new_content = existing[:existing.index(marker)].rstrip() + "\n\n" + tlm_content
            else:
                new_content = existing.rstrip() + "\n\n" + tlm_content
            self.claude_md.write_text(new_content + "\n")
        else:
            self.claude_md.write_text(tlm_content + "\n")

    def create_rule_files(self):
        """Create .claude/rules/tlm-*.md files."""
        enforcement_config = self._load_enforcement_config()
        self.rules_dir.mkdir(parents=True, exist_ok=True)
        rules = build_rule_files(enforcement_config)
        for filename, content in rules.items():
            (self.rules_dir / filename).write_text(content + "\n")

    # ── Phase 7: Hooks ───────────────────────────────────────

    def install_hooks(self):
        """Install Claude Code hooks into .claude/settings.json."""
        self.settings_file.parent.mkdir(parents=True, exist_ok=True)

        existing = {}
        if self.settings_file.exists():
            try:
                existing = json.loads(self.settings_file.read_text())
            except (json.JSONDecodeError, OSError):
                pass

        existing["hooks"] = build_all_hooks()
        self.settings_file.write_text(json.dumps(existing, indent=2))

    def create_hook_scripts(self):
        """Create thin wrapper scripts in .claude/hooks/."""
        self.hooks_dir.mkdir(parents=True, exist_ok=True)

        for name, content in _HOOK_SCRIPTS.items():
            script_path = self.hooks_dir / name
            script_path.write_text(content)
            script_path.chmod(
                script_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH
            )

    # ── Phase 7b: Git Hooks ──────────────────────────────────

    def install_git_hooks(self):
        """Install git post-commit hook for background learning."""
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return

        hooks_dir = git_dir / "hooks"
        hooks_dir.mkdir(exist_ok=True)

        hook_path = hooks_dir / "post-commit"
        if hook_path.exists():
            existing = hook_path.read_text()
            if "TLM" in existing:
                return  # Already installed
            backup = hooks_dir / "post-commit.backup"
            hook_path.rename(backup)

        hook_path.write_text(_GIT_POST_COMMIT_HOOK)
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC)

    # ── Phase 8: Finalize ────────────────────────────────────

    def finalize(self):
        """Set state to idle. Install complete."""
        write_state(str(self.root), {"phase": "idle"})

    # ── Full install ─────────────────────────────────────────

    def install_full(self):
        """Full TLM installation (after scan/assess/quality/gaps are done).

        1. Create rule files (.claude/rules/tlm-*.md)
        2. Install Claude Code hooks (.claude/settings.json)
        3. Create hook wrapper scripts (.claude/hooks/tlm-*)
        4. Install git post-commit hook
        5. Initialize state
        """
        self.create_rule_files()
        self.install_hooks()
        self.create_hook_scripts()
        self.install_git_hooks()
        self.finalize()

    # ── Uninstall ────────────────────────────────────────────

    def uninstall(self):
        """Remove TLM completely from project.

        Removes: TLM section from CLAUDE.md, hooks from settings.json,
                 hook scripts, rule files, git hooks, and .tlm/ directory.
        """
        self._remove_claude_md_section()
        self._remove_settings_hooks()
        self._remove_hook_scripts()
        self._remove_rule_files()
        self._remove_git_hooks()
        self._remove_tlm_dir()

    def _remove_settings_hooks(self):
        """Remove TLM hook entries from .claude/settings.json."""
        if not self.settings_file.exists():
            return
        try:
            settings = json.loads(self.settings_file.read_text())
        except (json.JSONDecodeError, OSError):
            return
        if "hooks" not in settings:
            return
        settings.pop("hooks")
        self.settings_file.write_text(json.dumps(settings, indent=2))

    def _remove_tlm_dir(self):
        """Remove the entire .tlm/ directory for a clean uninstall."""
        if self.tlm_dir.exists():
            import shutil
            shutil.rmtree(self.tlm_dir)

    def _remove_claude_md_section(self):
        """Remove TLM section from CLAUDE.md, keep the rest."""
        if not self.claude_md.exists():
            return

        content = self.claude_md.read_text()

        if TLM_MARKER_START in content and TLM_MARKER_END in content:
            start = content.index(TLM_MARKER_START)
            end = content.index(TLM_MARKER_END) + len(TLM_MARKER_END)
            remaining = (content[:start] + content[end:]).strip()
            if remaining:
                self.claude_md.write_text(remaining + "\n")
            else:
                self.claude_md.unlink()
        elif "# TLM" in content:
            idx = content.index("# TLM")
            remaining = content[:idx].strip()
            if remaining:
                self.claude_md.write_text(remaining + "\n")
            else:
                self.claude_md.unlink()

    def _remove_hook_scripts(self):
        """Remove TLM hook wrapper scripts."""
        if not self.hooks_dir.exists():
            return
        for script in self.hooks_dir.glob("tlm-*"):
            script.unlink()

    def _remove_rule_files(self):
        """Remove TLM rule files."""
        if not self.rules_dir.exists():
            return
        for rule_file in self.rules_dir.glob("tlm-*.md"):
            rule_file.unlink()

    def _remove_git_hooks(self):
        """Remove TLM git hooks, restore backups."""
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return

        hooks_dir = git_dir / "hooks"
        for hook_name in ("post-commit",):
            hook_path = hooks_dir / hook_name
            if hook_path.exists() and "TLM" in hook_path.read_text():
                hook_path.unlink()
                backup = hooks_dir / f"{hook_name}.backup"
                if backup.exists():
                    backup.rename(hook_path)

    # ── Internal ─────────────────────────────────────────────

    def _load_enforcement_config(self) -> dict:
        """Load the approved enforcement config."""
        config_file = self.tlm_dir / "enforcement.json"
        if not config_file.exists():
            return {}
        try:
            return json.loads(config_file.read_text())
        except json.JSONDecodeError:
            return {}


# =============================================================================
# Hook Wrapper Scripts
# =============================================================================

_HOOK_SCRIPTS = {
    "tlm-bash-firewall": """#!/bin/sh
# TLM Hook B — Execution Firewall (regex + server review for risky commands)
tlm _hook bash_firewall 2>/dev/null || true
""",
    "tlm-auto-interviewer": """#!/bin/sh
# TLM Hook A — Auto-Interviewer (plan review on ExitPlanMode)
tlm _hook auto_interviewer 2>/dev/null || true
""",
    "tlm-stop": """#!/bin/sh
# TLM Stop Hook — session sync when Claude session ends
tlm _hook stop 2>/dev/null || true
""",
}


# =============================================================================
# Git Hook Content
# =============================================================================

_GIT_POST_COMMIT_HOOK = """#!/bin/sh
# TLM Post-Commit Learner — analyzes commits in background
# This runs silently after every commit. Never blocks git.

if ! command -v tlm &> /dev/null; then
    exit 0
fi

if [ -z "$ANTHROPIC_API_KEY" ]; then
    exit 0
fi

if [ ! -d ".tlm" ]; then
    exit 0
fi

# Run analysis in background — never block the developer
nohup tlm _analyze-last-commit > /dev/null 2>&1 &
"""
