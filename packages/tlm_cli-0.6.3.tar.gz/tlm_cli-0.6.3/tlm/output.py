"""Record and save CLI output to .tlm/output/ for later reference."""

from datetime import datetime
from pathlib import Path

from rich.console import Console


def start_recording(console: Console) -> None:
    """Enable recording on a Rich Console so all print() calls are captured."""
    console.record = True


def save_output(console: Console, command_name: str, project_path: str) -> str | None:
    """Export recorded console output to .tlm/output/{command}_{timestamp}.txt.

    Returns the file path (relative to project_path) on success, None on skip/error.
    Silently skips if .tlm/ doesn't exist or output is empty. Never raises.
    """
    try:
        tlm_dir = Path(project_path) / ".tlm"
        if not tlm_dir.exists():
            return None

        text = console.export_text()
        if not text.strip():
            return None

        output_dir = tlm_dir / "output"
        output_dir.mkdir(exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{command_name}_{timestamp}.txt"
        filepath = output_dir / filename

        filepath.write_text(text)

        rel_path = f".tlm/output/{filename}"
        console.print(f"[dim]Output saved to {rel_path}[/dim]")
        return str(filepath)
    except Exception:
        return None
