---
template = "base.jinja.html"
footnote = "Generated with Anchovy!"
---

# Photo Gallery

<div class="gallery">
    <a href="static/images/home-sweet-home-cdk.jpg"><img src="static/images/home-sweet-home-cdk.jpg?thumb" alt="A Vintage Automobile"></a>
    <a href="static/images/nice-wheels-cdk.jpg"><img src="static/images/nice-wheels-cdk.jpg?thumb" alt="A Old Wood-Sided House"></a>
    <a href="static/images/stormy-cdk.jpg"><img src="static/images/stormy-cdk.jpg?thumb" alt="A Boardwalk and Damaged Pines During a Storm"></a>
    <a href="static/images/quayside-newcastle.jpg"><img src="static/images/quayside-newcastle.jpg?thumb" alt="A Quay in Newcastle, England"></a>
</div>
