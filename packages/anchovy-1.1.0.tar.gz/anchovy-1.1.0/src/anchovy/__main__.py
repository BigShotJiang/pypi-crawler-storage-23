"""
Provides `python -m anchovy`.
"""
from .cli import main

main()
