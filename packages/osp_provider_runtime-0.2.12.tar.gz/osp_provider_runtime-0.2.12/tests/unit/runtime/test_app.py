from __future__ import annotations

import pytest
from osp_provider_contracts import ProviderRequest, ProviderResult, RequestContext

from osp_provider_runtime.app import run_provider_with_config
from osp_provider_runtime.config import RuntimeConfig


class _DummyProvider:
    def capabilities(self) -> dict[str, object]:
        return {"provider": "dummy", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        _ = (action, request, context)
        return ProviderResult(success=True, message="ok")


class _FakeRuntime:
    instances: list[_FakeRuntime] = []

    def __init__(self, provider: object, config: RuntimeConfig) -> None:
        _ = (provider, config)
        self.closed = False
        type(self).instances.append(self)

    def handle_delivery(self, delivery: object) -> object:
        _ = delivery
        return object()

    def close(self) -> None:
        self.closed = True


class _FakeRunner:
    def __init__(self, config: RuntimeConfig) -> None:
        _ = config

    def run(self, handler: object) -> None:
        _ = handler
        raise RuntimeError("boom")


def test_run_provider_with_config_closes_runtime_on_runner_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _FakeRuntime.instances = []
    monkeypatch.setattr("osp_provider_runtime.app.ProviderRuntime", _FakeRuntime)
    monkeypatch.setattr("osp_provider_runtime.app.RabbitMQRunner", _FakeRunner)

    with pytest.raises(RuntimeError):
        run_provider_with_config(
            _DummyProvider(),
            RuntimeConfig(
                rabbitmq_url="amqp://guest:guest@localhost:5672/",
                request_queue="q",
                provider_name="p",
                updates_routing_key="p",
            ),
        )

    assert _FakeRuntime.instances
    assert _FakeRuntime.instances[0].closed is True
