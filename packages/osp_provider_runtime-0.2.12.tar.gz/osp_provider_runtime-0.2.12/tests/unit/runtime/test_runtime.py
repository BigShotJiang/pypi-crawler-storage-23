import concurrent.futures
import json
import time
from typing import Any

from loguru import logger
from osp_provider_contracts import ProviderError, ProviderRequest, ProviderResult, RequestContext
from osp_provider_contracts.errors import ValidationError

from osp_provider_runtime.config import RuntimeConfig
from osp_provider_runtime.runtime import ProviderRuntime
from osp_provider_runtime.transport import AckAction, Delivery


def _envelope(attempt: int = 1) -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "task_ref": "task-1",
            "task_id": "1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": attempt,
        }
    ).encode()


def _envelope_with_task_id(task_id: str) -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "task_ref": f"task-{task_id}",
            "task_id": task_id,
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": 1,
        }
    ).encode()


def _capabilities_envelope(provider: str = "p") -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "cap-1",
            "task_ref": "capabilities:p",
            "task_id": f"capabilities:{provider}",
            "provider": provider,
            "action": "capabilities",
            "resource_kind": "provider",
            "payload": {},
            "attempt": 1,
        }
    ).encode()


class OkProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "ok", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True, message="done")


class FailingProvider:
    def __init__(self, exc: ProviderError):
        self.exc = exc

    def capabilities(self) -> dict[str, Any]:
        return {"provider": "fail", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise self.exc


class SlowProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "slow", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        time.sleep(0.05)
        return ProviderResult(success=True, message="done")


class ApprovalProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "approval", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise ValidationError(
            "Manual approval required",
            detail="approval_required",
            extra={
                "gate_reason": "provider_approval_required",
                "importance": 2,
                "reason": "policy_violation",
                "details": {"scope": "network"},
                "progress_events": [{"message": "placement|cluster-a|42|-|-"}],
            },
        )


class ApprovalNoProgressProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "approval-no-progress", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise ValidationError(
            "Manual approval required",
            detail="approval_required",
            extra={
                "gate_reason": "provider_approval_required",
                "importance": 2,
                "reason": "policy_violation",
                "details": {"scope": "network"},
            },
        )


class InvalidRequestProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "invalid-request", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise ValidationError(
            "Requested vcenter does not exist",
            detail="request_invalid",
            extra={
                "gate_reason": "requested_state_invalid",
                "status_code": 900,
                "reason": "vcenter_not_in_inventory",
                "reason_code": "GATE_425_VCENTER_NOT_IN_INVENTORY",
                "details": {"path": "vcenter", "actual": "prod99"},
            },
        )


class JsonUnsafeProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "unsafe", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        class _ResolvedItem:
            def __init__(self) -> None:
                self.value = {"cpu_cores": 4}
                self.source = "policy_default"
                self.context_id = None

        return ProviderResult(
            success=True,
            message="done",
            data={"provenance": {"cpu_cores": _ResolvedItem()}},
        )


class ProgressProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "progress", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(
            success=True,
            message="done",
            data={
                "hostname": "web01.uio.no",
                "progress_events": [
                    {
                        "message": "Registered host in MREG",
                        "payload": {"stage": "mreg_register"},
                    }
                ],
            },
        )


class _TrackingExecutor:
    created = 0
    submitted = 0
    shutdowns = 0

    def __init__(self, max_workers: int) -> None:
        _ = max_workers
        type(self).created += 1

    def submit(
        self,
        fn: Any,
        *args: Any,
        **kwargs: Any,
    ) -> concurrent.futures.Future[ProviderResult]:
        type(self).submitted += 1
        fut: concurrent.futures.Future[ProviderResult] = concurrent.futures.Future()
        fut.set_result(fn(*args, **kwargs))
        return fut

    def shutdown(self, wait: bool = False, cancel_futures: bool = False) -> None:
        _ = (wait, cancel_futures)
        type(self).shutdowns += 1


def test_success_ack_and_response() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None
    assert result.response_routing_key == "reply.q"
    assert result.update_body is not None


def test_legacy_capabilities_rpc_message_is_dead_lettered() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(
        Delivery(
            body=b'{"op":"capabilities"}',
            reply_to="reply.q",
            routing_key="demo.capabilities.rpc",
            correlation_id="corr-123",
        )
    )

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is None
    assert result.response_routing_key is None
    assert result.response_correlation_id is None
    assert result.update_body is None


def test_contract_capabilities_rpc_message_is_supported() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(
        Delivery(
            body=_capabilities_envelope("p"),
            reply_to="reply.q",
            routing_key="demo.capabilities.rpc",
            correlation_id="amqp-corr-xyz",
        )
    )

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None
    assert json.loads(result.response_body) == {
        "provider": "ok",
        "version": "0.1",
        "resources": [],
    }
    assert result.response_routing_key == "reply.q"
    assert result.response_correlation_id == "amqp-corr-xyz"
    assert result.update_body is None


def test_contract_message_emits_update_when_task_id_is_numeric() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            updates_exchange="osp.to_orch",
            updates_routing_key="p",
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q"))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert "task_id" not in decoded
    assert decoded["payload"]["status_code"] == 200
    assert result.update_exchange == "osp.to_orch"
    assert result.update_routing_key == "p"


def test_contract_message_with_non_numeric_task_id_suppresses_update() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            updates_exchange="osp.to_orch",
            updates_routing_key="p",
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("task-non-numeric"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is None


def test_success_update_extracts_progress_events() -> None:
    runtime = ProviderRuntime(
        provider=ProgressProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            updates_exchange="osp.to_orch",
            updates_routing_key="p",
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q"))
    assert result.update_body is not None
    body = json.loads(result.update_body.decode("utf-8"))
    payload = (body.get("payload") or {}).get("payload") or {}
    assert isinstance(payload.get("progress_events"), list)
    assert payload["progress_events"][0]["message"] == "Registered host in MREG"
    assert "progress_events" not in (payload.get("resolved") or {})


def test_approval_required_maps_to_waiting_approval_update() -> None:
    runtime = ProviderRuntime(
        provider=ApprovalProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("9"), reply_to="reply.q"))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    event = decoded["payload"]
    assert "task_id" not in decoded
    assert event["status_code"] == 301
    assert event["severity"] == 30
    assert event["payload"]["approval"]["gate_reason"] == "provider_approval_required"
    assert event["payload"]["approval"]["importance"] == 2
    assert isinstance(event["payload"].get("progress_events"), list)


def test_approval_required_without_progress_events_omits_progress_events() -> None:
    runtime = ProviderRuntime(
        provider=ApprovalNoProgressProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("9"), reply_to="reply.q"))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert decoded["payload"]["status_code"] == 301
    assert "progress_events" not in decoded["payload"]["payload"]


def test_request_invalid_maps_to_rejected_update() -> None:
    runtime = ProviderRuntime(
        provider=InvalidRequestProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("12"), reply_to="reply.q"))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    event = decoded["payload"]
    assert event["status_code"] == 900
    assert event["payload"]["reason_code"] == "GATE_425_VCENTER_NOT_IN_INVENTORY"


def test_update_payload_is_json_safe() -> None:
    runtime = ProviderRuntime(
        provider=JsonUnsafeProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("11"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert "task_id" not in decoded
    resolved = decoded["payload"]["payload"]["resolved"]
    assert resolved["provenance"]["cpu_cores"]["value"]["cpu_cores"] == 4
    assert resolved["provenance"]["cpu_cores"]["source"] == "policy_default"


def test_retryable_error_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_retryable_error_dead_letters_on_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=3), reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is not None


def test_non_retryable_error_acks() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("bad", retryable=False, code="bad")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None


def test_malformed_envelope_dead_letters() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=b"not-json", reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is None


def test_handler_timeout_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=SlowProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            handler_timeout_seconds=0.001,
            max_attempts=3,
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))
    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_handler_timeout_returns_quickly() -> None:
    runtime = ProviderRuntime(
        provider=SlowProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            handler_timeout_seconds=0.001,
            max_attempts=3,
        ),
    )
    started = time.perf_counter()
    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))
    elapsed = time.perf_counter() - started

    assert result.ack_action == AckAction.REQUEUE
    assert elapsed < 0.03


def test_legacy_message_is_dead_lettered() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="nrec",
            updates_exchange="osp.to_orch",
            updates_routing_key="nrec",
        ),
    )
    legacy = json.dumps({"id": 7, "action": "create", "name": "x"}).encode()
    result = runtime.handle_delivery(Delivery(body=legacy, reply_to=None))
    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.update_body is None
    assert result.update_exchange is None
    assert result.update_routing_key is None


def test_processed_message_log_includes_correlation_and_event_id() -> None:
    records: list[dict[str, Any]] = []

    def _sink(message: Any) -> None:
        records.append(message.record)

    sink_id = logger.add(_sink, level="INFO")
    try:
        runtime = ProviderRuntime(
            provider=OkProvider(),
            config=RuntimeConfig(
                "amqp://guest:guest@localhost:5672/",
                "q",
                provider_name="p",
                updates_exchange="osp.to_orch",
                updates_routing_key="p",
            ),
        )
        _ = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q"))
    finally:
        logger.remove(sink_id)

    processed = [r for r in records if r.get("message") == "Processed message"]
    assert processed, "Expected runtime to emit 'Processed message' log"
    extra = processed[-1]["extra"]
    assert extra.get("task_id") == "7"
    assert extra.get("task_ref") == "task-7"
    assert isinstance(extra.get("update_event_id"), str) and extra["update_event_id"]


def test_timeout_executor_is_reused_across_deliveries(monkeypatch: Any) -> None:
    _TrackingExecutor.created = 0
    _TrackingExecutor.submitted = 0
    _TrackingExecutor.shutdowns = 0
    monkeypatch.setattr(
        "osp_provider_runtime.runtime.concurrent.futures.ThreadPoolExecutor",
        _TrackingExecutor,
    )
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            handler_timeout_seconds=1.0,
        ),
    )
    try:
        first = runtime.handle_delivery(Delivery(body=_envelope(), reply_to="reply.q"))
        second = runtime.handle_delivery(Delivery(body=_envelope(), reply_to="reply.q"))
    finally:
        runtime.close()

    assert first.ack_action == AckAction.ACK
    assert second.ack_action == AckAction.ACK
    assert _TrackingExecutor.created == 1
    assert _TrackingExecutor.submitted == 2
    assert _TrackingExecutor.shutdowns == 1
