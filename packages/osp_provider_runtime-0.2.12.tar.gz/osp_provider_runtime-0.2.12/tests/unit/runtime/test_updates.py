from __future__ import annotations

import json

from osp_provider_runtime.updates import TaskReporter


def test_update_keeps_metadata_in_envelope() -> None:
    reporter = TaskReporter(task_id=42, task_ref="task-42")
    update = reporter.update(
        status_code=160,
        severity=20,
        message="Running",
        payload={"step": "clone"},
        event_id="evt-1",
    )
    body = update.to_transport_body()
    assert body["envelope_version"] == "1.0"
    assert body["contract_version"] == "1.0"
    assert body["message_id"] == "evt-1"
    assert body["task_ref"] == "task-42"
    assert "task_id" not in body
    assert body["kind"] == "task_event"
    event = body["payload"]
    assert event["status_code"] == 160
    assert event["severity"] == 20
    assert event["message"] == "Running"
    assert event["payload"]["step"] == "clone"
    assert "event_id" not in event["payload"]
    assert "task_ref" not in event["payload"]
    assert "task_id" not in event["payload"]


def test_require_approval_uses_reserved_approval_block() -> None:
    reporter = TaskReporter(task_id=7, task_ref="task-7")
    update = reporter.require_approval(
        gate_reason="provider_approval_required",
        importance=2,
        reason="policy_violation",
        details={"scope": "network"},
        message="Need approval",
    )
    body = update.to_transport_body()
    event = body["payload"]
    assert event["status_code"] == 301
    assert event["severity"] == 30
    approval = event["payload"]["approval"]
    assert approval["gate_reason"] == "provider_approval_required"
    assert approval["importance"] == 2
    assert approval["reason"] == "policy_violation"


def test_require_approval_can_emit_progress_events() -> None:
    reporter = TaskReporter(task_id=7, task_ref="task-7")
    update = reporter.require_approval(
        gate_reason="provider_approval_required",
        importance=2,
        reason="policy_violation",
        progress_events=[{"message": "placement|cluster-a|42|-|-"}],
    )
    body = update.to_transport_body()
    payload = body["payload"]["payload"]
    assert isinstance(payload.get("progress_events"), list)
    assert payload["progress_events"][0]["message"] == "placement|cluster-a|42|-|-"


def test_progress_uses_standard_payload_shape() -> None:
    reporter = TaskReporter(task_id=5, task_ref="task-5")
    body = reporter.progress(message="Halfway", current=5, total=10).to_transport_body()
    event = body["payload"]
    assert event["status_code"] == 160
    assert event["severity"] == 20
    assert event["payload"]["progress"] == {"current": 5, "total": 10}


def test_transport_bytes_is_json_safe() -> None:
    reporter = TaskReporter(task_id=8, task_ref="task-8")

    class _ResolvedItem:
        def __init__(self) -> None:
            self.value = {"cpu_cores": 4}
            self.source = "policy_default"
            self.context_id = None

    raw = reporter.completed(
        message="Done",
        payload={"resolved": {"cpu_cores": _ResolvedItem()}},
    ).to_transport_bytes()
    decoded = json.loads(raw.decode("utf-8"))
    resolved = decoded["payload"]["payload"]["resolved"]
    assert resolved["cpu_cores"]["value"]["cpu_cores"] == 4
    assert resolved["cpu_cores"]["source"] == "policy_default"


def test_deny_uses_rejected_status_and_reason_code() -> None:
    reporter = TaskReporter(task_id=9, task_ref="task-9")
    body = reporter.deny(
        message="Denied by policy",
        reason_code="owner_missing",
        details={"field": "owner"},
    ).to_transport_body()
    event = body["payload"]
    assert event["status_code"] == 900
    assert event["severity"] == 40
    assert event["payload"]["reason_code"] == "owner_missing"
    assert event["payload"]["details"] == {"field": "owner"}


def test_failed_embeds_error_payload_shape() -> None:
    reporter = TaskReporter(task_id=10, task_ref="task-10")
    body = reporter.failed(
        message="Upstream unavailable",
        code="dependency_error",
        detail="timeout",
        retryable=True,
        extra={"service": "nrec"},
    ).to_transport_body()
    event = body["payload"]
    assert event["status_code"] == 580
    assert event["severity"] == 40
    assert event["payload"]["error"] == {
        "code": "dependency_error",
        "detail": "timeout",
        "retryable": True,
        "extra": {"service": "nrec"},
    }
