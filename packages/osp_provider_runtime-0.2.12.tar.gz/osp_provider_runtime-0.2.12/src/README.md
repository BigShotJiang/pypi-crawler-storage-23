# Source Tree Overview

This directory contains the `osp_provider_runtime` package. All runtime
plumbing lives in `src/osp_provider_runtime/`.

## Audience

Maintainers and contributors working on runtime internals.

## TL;DR (Critical Invariants)

- Keep business logic in `ProviderRuntime`; keep transport/pika logic in `RabbitMQRunner`.
- Never perform channel operations off the connection thread.
- Retry semantics are republish-with-backoff, not `nack(requeue=True)`.
- Timeout cancellation is best-effort; blocked worker threads may keep running.

## Structure

- `src/osp_provider_runtime/app.py`
  - Entry point: `run_provider_with_config()`. Wires `ProviderRuntime` and
    `RabbitMQRunner` and blocks until interrupted.
- `src/osp_provider_runtime/config.py`
  - `RuntimeConfig` — frozen dataclass with all runtime knobs: concurrency,
    timeouts, backoff, queues, update emission flags.
- `src/osp_provider_runtime/runtime.py`
  - `ProviderRuntime` — testable business logic: envelope dispatch, provider
    execution with timeout, retry decisions, response and update building.
- `src/osp_provider_runtime/rabbitmq.py`
  - `RabbitMQRunner` — pika transport: connection retries, channel setup,
    thread-safe ack/nack/publish, exponential backoff requeue.
- `src/osp_provider_runtime/transport.py`
  - `AckAction`, `Delivery`, `DeliveryResult` — transport-agnostic interface
    between `ProviderRuntime` and `RabbitMQRunner`.
- `src/osp_provider_runtime/envelope.py`
  - `parse_request_envelope()`, `dump_response_envelope()` — contract envelope
    parsing/serialization for `contract_v1` requests and responses.
- `src/osp_provider_runtime/updates.py`
  - `TaskReporter`, `ProviderUpdate`, `json_safe()` — task lifecycle update
    emission with legacy orchestrator wire format compatibility.

## Tutorial: run a provider

```python
from osp_provider_runtime import RuntimeConfig, run_provider_with_config
from my_provider import MyProvider

config = RuntimeConfig(
    rabbitmq_url="amqp://guest:guest@localhost:5672/",
    request_queue="provider.my.tasks",
    request_binding="provider.my",
    provider_name="my-provider",
    updates_routing_key="my-provider",
    concurrency=4,
    handler_timeout_seconds=120.0,
)
run_provider_with_config(MyProvider(), config)
```

`run_provider_with_config` blocks until interruption and then runs shutdown
cleanup (`runtime.close()` and RabbitMQ connection close) before exit.

## Tutorial: test provider logic without RabbitMQ

`ProviderRuntime` is testable in isolation — no pika, no RabbitMQ connection:

```python
import json
from osp_provider_runtime import ProviderRuntime, RuntimeConfig
from osp_provider_runtime.transport import AckAction, Delivery

config = RuntimeConfig(
    rabbitmq_url="amqp://localhost/",  # not used in tests
    request_queue="test.queue",
    provider_name="my-provider",
    updates_routing_key="my-provider",
)
runtime = ProviderRuntime(provider=MyProvider(), config=config)

body = json.dumps({
    "envelope_version": "1.0",
    "contract_version": "1.0",
    "message_id": "msg-1",
    "task_ref": "task-1",
    "action": "create",
    "resource_kind": "vm",
    "payload": {"hostname": "test-01"},
}).encode()

result = runtime.handle_delivery(Delivery(body=body, reply_to=None))
assert result.ack_action == AckAction.ACK

runtime.close()
```

For deep dives on each module, see `src/osp_provider_runtime/README.md`.
