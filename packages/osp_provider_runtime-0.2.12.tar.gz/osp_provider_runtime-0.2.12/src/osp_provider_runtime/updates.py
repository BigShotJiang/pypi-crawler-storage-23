"""Task update emission helpers using contract envelope format.

TaskReporter provides a fluent API for emitting task lifecycle updates
(accepted, running, completed, failed, require_approval) in a contract
update envelope consumed by orchestrator.

Why TaskReporter:
    - Encapsulates update format knowledge (status codes, severity levels, payload structure)
    - Providers call reporter methods without knowing transport details
    - Runtime serializes ProviderUpdate to JSON bytes for RabbitMQ publish

Why json_safe:
    - Providers may include complex objects in result.data (dataclasses, enums, dates)
    - JSON serialization fails on non-serializable types
    - json_safe recursively converts to JSON-safe primitives

Contracts:
    - Status codes match orchestrator semantics (105=ACCEPTED, 160=RUNNING, 200=COMPLETED, etc.)
    - event_id is UUID4 for idempotency (one update = one TaskEvent row)
    - Severity controls log level in orchestrator (20=INFO, 30=WARNING, 40=ERROR)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from osp_provider_contracts import (
    ProviderUpdateEnvelope,
    build_provider_update_envelope,
)


def json_safe(value: Any) -> Any:
    """Recursively convert value to JSON-serializable primitive.

    Why needed:
        - Providers may return complex objects (dataclasses, Enums, dates, custom classes)
        - json.dumps() raises TypeError on non-serializable types
        - json_safe makes best-effort conversion (isoformat for dates, str() fallback)

    Conversion rules:
        - None, str, int, float, bool → pass through
        - dict → recursively convert values (keys coerced to str)
        - list/tuple → recursively convert elements
        - datetime-like (has isoformat) → .isoformat()
        - TrackedValue-like (has value/source) → {"value": ..., "source": ..., "context_id": ...}
        - Everything else → str(value)

    Why TrackedValue special case:
        - Some providers use TrackedValue wrapper for audit provenance
        - Orchestrator expects {"value": X, "source": "provider", ...} format

    Returns:
        JSON-serializable value (None, str, int, float, bool, dict, or list).
    """
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:  # noqa: BLE001
            pass
    if hasattr(value, "value") and hasattr(value, "source"):
        return {
            "value": json_safe(getattr(value, "value", None)),
            "source": str(getattr(value, "source", "")),
            "context_id": json_safe(getattr(value, "context_id", None)),
        }
    return str(value)


@dataclass(frozen=True, slots=True)
class ProviderUpdate:
    """Single task lifecycle update message.

    Immutable update record that gets serialized to JSON and published to
    updates exchange (osp.to_orch) for orchestrator consumption.

    Why event_id:
        - Orchestrator uses event_id for idempotency (one event = one TaskEvent row)
        - UUID4 ensures global uniqueness across providers and retries

    Attributes:
        event_id: Unique update identifier (UUID4 string).
    task_id: Task identifier.
        task_ref: Task correlation reference.
        status_code: Orchestrator status code (105=ACCEPTED, 160=RUNNING, etc.).
        severity: Log severity (20=INFO, 30=WARNING, 40=ERROR).
        message: Human-readable status message.
        payload: Optional structured data (requested, resolved, error, approval, etc.).
    """

    event_id: str
    task_id: int
    task_ref: str
    status_code: int
    severity: int
    message: str
    payload: dict[str, Any] | None = None

    def to_transport_body(self) -> ProviderUpdateEnvelope:
        """Build contract update envelope for orchestrator update consumer."""
        payload = dict(self.payload or {})
        return build_provider_update_envelope(
            envelope_version="1.0",
            contract_version="1.0",
            message_id=self.event_id,
            task_ref=self.task_ref,
            status_code=self.status_code,
            severity=self.severity,
            message=self.message,
            payload=payload,
        )

    def to_transport_bytes(self) -> bytes:
        """Serialize update to compact JSON bytes for RabbitMQ publish.

        Why two-phase json_safe:
            - First attempt: serialize as-is (fast path for simple payloads)
            - Second attempt: recursively json_safe() and retry (handles complex objects)

        Returns:
            UTF-8 encoded JSON bytes ready for transport.
        """
        body = self.to_transport_body()
        try:
            return json.dumps(body, separators=(",", ":")).encode("utf-8")
        except TypeError:
            return json.dumps(json_safe(body), separators=(",", ":")).encode("utf-8")


class TaskReporter:
    """Fluent API for emitting task lifecycle updates.

    Providers use TaskReporter to emit updates without knowing transport details.
    Each method returns ProviderUpdate; runtime serializes and publishes to RabbitMQ.

    Why fluent API:
        - Providers call reporter.running("Processing...").to_transport_bytes()
        - Runtime handles serialization and publish
        - Separation of concerns (provider = business logic, runtime = transport)

    Status code semantics (match orchestrator):
        - 105 ACCEPTED: Provider acknowledged task
        - 160 RUNNING: Task in progress
        - 200 COMPLETED: Success
        - 301 WAITING_APPROVAL: Human approval required
        - 580 PROVIDER_ERROR: Provider error (retryable or not)
        - 900 REJECTED: Provider denied task (policy violation)

    Usage:
        reporter = TaskReporter(task_id=123, task_ref="task-123")
        update = reporter.running("Deploying VM...")
        publish(update.to_transport_bytes())
    """

    # Runtime-local defaults matching current orchestrator semantics.
    STATUS_ACCEPTED = 105
    STATUS_RUNNING = 160
    STATUS_COMPLETED = 200
    STATUS_WAITING_APPROVAL = 301
    STATUS_PROVIDER_ERROR = 580
    STATUS_REJECTED = 900

    SEVERITY_INFO = 20
    SEVERITY_WARNING = 30
    SEVERITY_ERROR = 40

    def __init__(self, *, task_id: int, task_ref: str) -> None:
        """Initialize reporter with task context.

        Args:
            task_id: Task identifier.
            task_ref: Task correlation reference.
        """
        self.task_id = int(task_id)
        self.task_ref = task_ref

    def update(
        self,
        *,
        status_code: int,
        severity: int,
        message: str,
        payload: dict[str, Any] | None = None,
        event_id: str | None = None,
    ) -> ProviderUpdate:
        """Build generic update with specified status/severity.

        Args:
            status_code: Orchestrator status code (e.g., STATUS_RUNNING).
            severity: Log severity (e.g., SEVERITY_INFO).
            message: Human-readable status message.
            payload: Optional structured data.
            event_id: Optional explicit event_id (defaults to UUID4).

        Returns:
            Immutable ProviderUpdate ready for serialization.
        """
        resolved_event_id = event_id or str(uuid4())
        return ProviderUpdate(
            event_id=resolved_event_id,
            task_id=self.task_id,
            task_ref=self.task_ref,
            status_code=int(status_code),
            severity=int(severity),
            message=message,
            payload=payload,
        )

    def accepted(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        """Emit ACCEPTED status (provider acknowledged task)."""
        return self.update(
            status_code=self.STATUS_ACCEPTED,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def running(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        """Emit RUNNING status (task in progress)."""
        return self.update(
            status_code=self.STATUS_RUNNING,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def progress(
        self,
        *,
        message: str,
        current: int,
        total: int,
        payload: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        """Emit RUNNING status with progress indicator.

        Adds {"progress": {"current": X, "total": Y}} to payload.
        Orchestrator UI renders progress bar.
        """
        data = dict(payload or {})
        data["progress"] = {"current": int(current), "total": int(total)}
        return self.update(
            status_code=self.STATUS_RUNNING,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=data,
        )

    def require_approval(
        self,
        *,
        gate_reason: str,
        importance: int,
        reason: str,
        details: dict[str, Any] | None = None,
        progress_events: list[dict[str, Any]] | None = None,
        message: str = "Provider requires approval",
    ) -> ProviderUpdate:
        """Emit WAITING_APPROVAL status with gate metadata.

        Triggers orchestrator approval flow. Orchestrator routes to approval authority
        based on gate_reason and importance.

        Args:
            gate_reason: Stable reason key, e.g. "policy_exception_required".
            importance: Approval urgency/risk (1=VERY_HIGH requires 2 approvers, 2-5 requires 1).
            reason: Stable machine-readable reason string.
            details: Optional approval details (violations, targets, etc.).
            progress_events: Optional progress events emitted during gate check.
            message: Human-readable approval reason.

        Returns:
            ProviderUpdate with approval payload structure.
        """
        resolved_gate_reason = str(gate_reason or "").strip().lower()
        if not resolved_gate_reason:
            raise ValueError("gate_reason is required")

        approval: dict[str, Any] = {
            "importance": int(importance),
            "reason": reason,
            "gated_at": datetime.now(UTC).isoformat(),
        }
        approval["gate_reason"] = resolved_gate_reason
        if details:
            approval["details"] = details
        payload: dict[str, Any] = {"approval": approval}
        if isinstance(progress_events, list) and progress_events:
            payload["progress_events"] = progress_events
        return self.update(
            status_code=self.STATUS_WAITING_APPROVAL,
            severity=self.SEVERITY_WARNING,
            message=message,
            payload=payload,
        )

    def deny(
        self,
        *,
        message: str,
        reason_code: str,
        details: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        """Emit REJECTED status (provider denied task).

        Use when provider rejects task due to policy violation (not a failure).
        Orchestrator moves task to REJECTED state (terminal, not retryable).
        """
        payload: dict[str, Any] = {"reason_code": reason_code}
        if details:
            payload["details"] = details
        return self.update(
            status_code=self.STATUS_REJECTED,
            severity=self.SEVERITY_ERROR,
            message=message,
            payload=payload,
        )

    def completed(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        """Emit COMPLETED status (success)."""
        return self.update(
            status_code=self.STATUS_COMPLETED,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def failed(
        self,
        *,
        message: str,
        code: str,
        detail: str | None = None,
        retryable: bool = False,
        extra: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        """Emit PROVIDER_ERROR status with error details.

        Includes error structure in payload: {"error": {"code": ..., "detail": ..., ...}}

        Args:
            message: Human-readable error message.
            code: Error code (e.g., "auth_error", "transient_error").
            detail: Optional additional context.
            retryable: Whether error is retryable (for orchestrator UI).
            extra: Optional error metadata.
            payload: Optional additional payload data.

        Returns:
            ProviderUpdate with error structure.
        """
        data = dict(payload or {})
        data["error"] = {
            "code": code,
            "detail": detail,
            "retryable": retryable,
            "extra": dict(extra or {}),
        }
        return self.update(
            status_code=self.STATUS_PROVIDER_ERROR,
            severity=self.SEVERITY_ERROR,
            message=message,
            payload=data,
        )
