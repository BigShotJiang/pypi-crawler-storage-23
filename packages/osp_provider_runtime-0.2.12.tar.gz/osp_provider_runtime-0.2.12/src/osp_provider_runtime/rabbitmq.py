"""RabbitMQ transport layer with thread-safe channel usage and exponential backoff.

This module contains the trickiest parts of the runtime: pika channel thread safety,
exponential backoff, and requeue mechanics. Read carefully!

Threading model:
    - Pika BlockingConnection runs on main thread (connection thread)
    - Handler (ProviderRuntime.handle_delivery) runs on ThreadPoolExecutor (worker threads)
    - Channel operations (publish, ack, nack) MUST run on connection thread
    - add_callback_threadsafe() bridges worker threads → connection thread

Why add_callback_threadsafe:
    - pika channels are NOT thread-safe (cannot publish/ack from worker threads)
    - Worker thread cannot call channel.basic_ack() directly
    - add_callback_threadsafe() schedules callback on connection thread's event loop

Requeue mechanics (CRITICAL):
    - AckAction.REQUEUE means "retry with exponential backoff"
    - Cannot use basic_nack(requeue=True) because it re-delivers immediately (no backoff)
    - Instead: sleep(backoff), republish with incremented attempt, then basic_ack original
    - Republish targets original routing_key (or request_queue if routing_key missing)

Why increment attempt in message body:
    - Orchestrator envelope has "attempt" field (1-indexed)
    - Runtime increments attempt before requeue
    - Max attempts check prevents infinite retry loop

Exponential backoff with jitter:
    - Base delay * 2^(attempt-1), capped at max_seconds
    - Jitter = random ±20% (default) to avoid thundering herd
    - Applied to both connection retries and task requeues

Contracts:
    - Prefetch = max(prefetch_count, concurrency) to avoid worker starvation
    - Exchanges are durable topic exchanges (survive broker restart)
    - Queues are durable with optional dead-letter routing
    - Connection retries forever by default (connect_max_attempts=0)
"""

from __future__ import annotations

import concurrent.futures
import json
import random
import time
from collections.abc import Callable
from typing import Any, cast

import pika  # type: ignore[import-untyped]
from loguru import logger

from .config import RuntimeConfig
from .transport import AckAction, Delivery, DeliveryResult


class RabbitMQRunner:
    """RabbitMQ transport orchestrating connection, channels, and delivery lifecycle.

    Why separate from ProviderRuntime:
        - RabbitMQRunner = pika-specific transport (not testable without RabbitMQ)
        - ProviderRuntime = business logic (testable with fake transport)
    """

    def __init__(self, config: RuntimeConfig) -> None:
        """Initialize RabbitMQ runner with configuration.

        Args:
            config: Runtime configuration (URL, queue, prefetch, concurrency, etc.).
        """
        self.config = config

    @staticmethod
    def _backoff_with_jitter(
        *,
        attempt: int,
        base_seconds: float,
        max_seconds: float,
        jitter_factor: float,
    ) -> float:
        """Calculate exponential backoff delay with jitter.

        Formula:
            base_delay = min(max_seconds, base_seconds * 2^(attempt-1))
            jitter_range = ±(jitter_factor * base_delay)
            result = random.uniform(base_delay - jitter, base_delay + jitter)

        Why jitter:
            - Avoids thundering herd when multiple providers retry simultaneously
            - Default jitter_factor=0.2 means ±20% randomization
            - Example: base_delay=10s, jitter=±2s, result ∈ [8s, 12s]

        Args:
            attempt: Retry attempt number (1-indexed).
            base_seconds: Initial delay (e.g., 1.0 for 1 second).
            max_seconds: Cap on exponential growth (e.g., 30.0 for 30 seconds).
            jitter_factor: Jitter as fraction of delay (e.g., 0.2 for ±20%).

        Returns:
            Computed delay in seconds (always >= 0).
        """
        bounded_attempt = max(1, attempt)
        base_delay = float(min(max_seconds, base_seconds * (2 ** (bounded_attempt - 1))))
        jitter = float(max(0.0, min(1.0, jitter_factor)) * base_delay)
        if jitter <= 0:
            return base_delay
        sampled = random.uniform(max(0.0, base_delay - jitter), base_delay + jitter)
        return cast(float, sampled)

    def _connect_with_retries(self, params: Any) -> Any:
        """Connect to RabbitMQ with exponential backoff retries.

        Why retry forever by default (connect_max_attempts=0):
            - Providers are daemons; they should keep trying to reconnect
            - Kubernetes will restart pod if connection never succeeds
            - Better to retry locally than crash-loop

        Raises:
            Exception: Connection failure after max_attempts (if max_attempts > 0).
        """
        attempt = 1
        max_attempts = self.config.connect_max_attempts
        while True:
            try:
                return pika.BlockingConnection(params)
            except Exception:
                if max_attempts > 0 and attempt >= max_attempts:
                    raise
                delay = self._backoff_with_jitter(
                    attempt=attempt,
                    base_seconds=self.config.connect_backoff_base_seconds,
                    max_seconds=self.config.connect_backoff_max_seconds,
                    jitter_factor=self.config.connect_backoff_jitter_factor,
                )
                logger.warning(
                    "RabbitMQ connect failed; retrying",
                    attempt=attempt,
                    delay_seconds=round(delay, 3),
                    max_attempts=max_attempts,
                )
                time.sleep(delay)
                attempt += 1

    @staticmethod
    def _increment_retry_attempt(body: bytes) -> tuple[bytes | None, int]:
        """Parse envelope, increment attempt field, reserialize.

        Why needed:
            - Requeue logic needs to track delivery attempts
            - Runtime checks attempt < max_attempts to decide REQUEUE vs DEAD_LETTER
            - Increment happens in transport layer (not ProviderRuntime)

        Returns:
            Tuple of (modified body bytes, current attempt before increment).
            Returns (None, 1) if parsing fails (dead-letter these).

        Notes:
            - Best-effort parsing (graceful degradation on malformed JSON)
            - Current attempt is returned for backoff calculation
        """
        try:
            parsed = json.loads(body.decode("utf-8"))
        except Exception:
            return None, 1
        if not isinstance(parsed, dict):
            return None, 1
        current = parsed.get("attempt", 1)
        if not isinstance(current, int) or current < 1:
            current = 1
        parsed["attempt"] = current + 1
        try:
            return json.dumps(parsed, separators=(",", ":")).encode("utf-8"), current
        except Exception:
            return None, current

    def run(self, handler: Callable[[Delivery], DeliveryResult]) -> None:
        """Start consuming messages and dispatch to handler.

        This is the main event loop. Runs until interrupted (KeyboardInterrupt, SIGTERM).

        Threading breakdown:
            1. Main thread: pika BlockingConnection event loop (channel operations)
            2. Worker threads: ThreadPoolExecutor runs handler() for each delivery
            3. Callbacks: add_callback_threadsafe() schedules publish/ack on main thread

        Critical sections:
            - _on_message: Runs on main thread, schedules handler on worker thread
            - _finalize: Runs on worker thread, schedules _on_connection_thread callback
            - _on_connection_thread: Runs on main thread, performs channel operations

        Why this architecture:
            - Pika channels are not thread-safe (channel ops must run on connection thread)
            - Handler may block (network I/O, CPU-intensive), so runs on worker thread
            - Prefetch allows multiple in-flight messages for concurrency

        Args:
            handler: Callable taking Delivery and returning DeliveryResult.
                Usually ProviderRuntime.handle_delivery.

        Raises:
            ValueError: If concurrency < 1 or provider_name/updates_routing_key not set.

        Notes:
            - Executor.shutdown(wait=True) waits for in-flight handlers before exit
            - Connection.close() is best-effort (exception logged but not raised)
        """
        if self.config.concurrency < 1:
            raise ValueError("RuntimeConfig.concurrency must be >= 1")
        if self.config.provider_name == "unknown-provider":
            logger.warning("RuntimeConfig.provider_name is still default 'unknown-provider'")
        if self.config.updates_routing_key == "unknown-provider":
            logger.warning("RuntimeConfig.updates_routing_key is still default 'unknown-provider'")
        params = pika.URLParameters(self.config.rabbitmq_url)
        params.heartbeat = self.config.heartbeat_seconds
        params.blocked_connection_timeout = self.config.blocked_connection_timeout_seconds
        connection = self._connect_with_retries(params)
        channel = connection.channel()
        prefetch = max(self.config.prefetch_count, self.config.concurrency)
        channel.basic_qos(prefetch_count=prefetch)
        channel.exchange_declare(
            exchange=self.config.request_exchange,
            exchange_type="topic",
            durable=True,
        )
        channel.exchange_declare(
            exchange=self.config.updates_exchange,
            exchange_type="topic",
            durable=True,
        )
        queue_arguments: dict[str, Any] = {}
        if self.config.dead_letter_exchange:
            queue_arguments["x-dead-letter-exchange"] = self.config.dead_letter_exchange
        if self.config.dead_letter_routing_key:
            queue_arguments["x-dead-letter-routing-key"] = self.config.dead_letter_routing_key
        channel.queue_declare(
            queue=self.config.request_queue,
            durable=True,
            arguments=queue_arguments or None,
        )
        if self.config.request_binding:
            bindings = [
                item.strip() for item in self.config.request_binding.split(",") if item.strip()
            ]
            for binding in bindings:
                channel.queue_bind(
                    queue=self.config.request_queue,
                    exchange=self.config.request_exchange,
                    routing_key=binding,
                )

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.config.concurrency)

        def _publish_result(result: DeliveryResult) -> None:
            if result.response_body and result.response_routing_key:
                channel.basic_publish(
                    exchange="",
                    routing_key=result.response_routing_key,
                    body=result.response_body,
                    properties=pika.BasicProperties(
                        content_type="application/json",
                        correlation_id=result.response_correlation_id,
                    ),
                )
            if result.update_body and result.update_exchange and result.update_routing_key:
                channel.basic_publish(
                    exchange=result.update_exchange,
                    routing_key=result.update_routing_key,
                    body=result.update_body,
                    properties=pika.BasicProperties(
                        content_type="application/json",
                    ),
                )

        def _on_message(ch: Any, method: Any, properties: Any, body: bytes) -> None:
            delivery = Delivery(
                body=body,
                reply_to=properties.reply_to,
                routing_key=getattr(method, "routing_key", None),
                correlation_id=getattr(properties, "correlation_id", None),
            )

            def _finalize(future: concurrent.futures.Future[DeliveryResult]) -> None:
                try:
                    result = future.result()
                except Exception:
                    logger.exception(
                        "Unhandled exception in delivery handler",
                        routing_key=delivery.routing_key,
                    )
                    result = DeliveryResult(ack_action=AckAction.DEAD_LETTER)
                retry_body: bytes | None = None
                retry_delay = 0.0
                if result.ack_action == AckAction.REQUEUE:
                    retry_body, current_attempt = self._increment_retry_attempt(delivery.body)
                    if retry_body is not None:
                        retry_delay = self._backoff_with_jitter(
                            attempt=current_attempt,
                            base_seconds=self.config.retry_backoff_base_seconds,
                            max_seconds=self.config.retry_backoff_max_seconds,
                            jitter_factor=self.config.retry_backoff_jitter_factor,
                        )
                        if retry_delay > 0:
                            time.sleep(retry_delay)

                def _on_connection_thread() -> None:
                    # Pika channels are not thread-safe; publish and ack/nack on
                    # the connection thread.
                    _publish_result(result)
                    if result.ack_action == AckAction.ACK:
                        ch.basic_ack(delivery_tag=method.delivery_tag)
                    elif result.ack_action == AckAction.REQUEUE:
                        if retry_body is None:
                            logger.error(
                                "Failed to schedule retry; dead-lettering",
                                routing_key=delivery.routing_key,
                            )
                            ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                        else:
                            if delivery.routing_key:
                                ch.basic_publish(
                                    exchange=self.config.request_exchange,
                                    routing_key=delivery.routing_key,
                                    body=retry_body,
                                    properties=pika.BasicProperties(
                                        content_type="application/json",
                                        correlation_id=delivery.correlation_id,
                                        reply_to=delivery.reply_to,
                                    ),
                                )
                            else:
                                ch.basic_publish(
                                    exchange="",
                                    routing_key=self.config.request_queue,
                                    body=retry_body,
                                    properties=pika.BasicProperties(
                                        content_type="application/json",
                                        correlation_id=delivery.correlation_id,
                                        reply_to=delivery.reply_to,
                                    ),
                                )
                            ch.basic_ack(delivery_tag=method.delivery_tag)
                    else:
                        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                    logger.info(
                        "Delivery finalized",
                        routing_key=delivery.routing_key,
                        ack_action=result.ack_action.value,
                    )

                connection.add_callback_threadsafe(_on_connection_thread)

            future = executor.submit(handler, delivery)
            future.add_done_callback(_finalize)

        channel.basic_consume(queue=self.config.request_queue, on_message_callback=_on_message)
        logger.info(
            "Starting runtime consumer",
            queue=self.config.request_queue,
            exchange=self.config.request_exchange,
            binding=self.config.request_binding,
            updates_exchange=self.config.updates_exchange,
            updates_routing_key=self.config.updates_routing_key,
            prefetch=prefetch,
            concurrency=self.config.concurrency,
            handler_timeout_seconds=self.config.handler_timeout_seconds,
            dead_letter_exchange=self.config.dead_letter_exchange,
            dead_letter_routing_key=self.config.dead_letter_routing_key,
        )
        try:
            channel.start_consuming()
        finally:
            executor.shutdown(wait=True)
            try:
                if connection.is_open:
                    connection.close()
            except Exception:
                logger.exception("Failed to close RabbitMQ connection cleanly")
