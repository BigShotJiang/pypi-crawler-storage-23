# Package Structure

This document outlines `osp-provider-runtime` architecture, threading model,
and design principles so transport plumbing stays isolated from provider
business logic.

## Audience

Maintainers and contributors working on runtime internals.

## TL;DR (Critical Invariants)

- `ProviderRuntime` contains business logic and must stay free of pika/channel calls.
- `RabbitMQRunner` contains transport logic and must not contain provider/envelope logic.
- Channel operations (`basic_ack`, `basic_nack`, `basic_publish`) run only on the
  connection thread.
- `REQUEUE` means republish with incremented `attempt`, then ACK the original.
- Malformed envelopes are dead-lettered immediately.

## Caveats (Signals and Timeouts)

- Timeout handling is best-effort: `future.cancel()` cannot forcibly stop a Python
  thread blocked in C/IO. A timed-out handler may continue running in the background.
- `run_provider_with_config()` performs cleanup on exit, but SIGKILL or process
  crashes bypass graceful shutdown.
- Signal delivery timing depends on the host/runtime environment; in-flight work may
  finish after shutdown begins.

## Quick Start

- **`app.py`**: Entry point — `run_provider_with_config()` wires Runtime + Runner and blocks until interrupted
- **`config.py`**: `RuntimeConfig` — all runtime knobs in one frozen dataclass (queues, concurrency, timeouts, backoff, update flags)
- **`runtime.py`**: `ProviderRuntime` — testable business logic (envelope dispatch, timeout, retry decisions, update building)
- **`rabbitmq.py`**: `RabbitMQRunner` — pika transport (connection retries, thread-safe ack/nack/publish, backoff requeue)
- **`transport.py`**: `AckAction`, `Delivery`, `DeliveryResult` — transport-agnostic interface between Runtime and Runner
- **`envelope.py`**: `parse_request_envelope()`, `dump_response_envelope()` — request/response envelope parsing for `contract_v1`
- **`updates.py`**: `TaskReporter`, `ProviderUpdate`, `json_safe()` — task lifecycle update emission in the shared provider-update contract envelope

## Architecture Principles

- **Runtime/Runner split**: `ProviderRuntime` is pure business logic with no pika imports. `RabbitMQRunner` is pure transport with no Provider/envelope logic. This makes the runtime testable without a RabbitMQ connection.
- **Transport interface**: `transport.py` defines the only shared contract (`Delivery` in, `DeliveryResult` out). Neither side knows the other's internals.
- **Channel ops on connection thread only**: pika channels are not thread-safe. All `basic_ack`, `basic_nack`, `basic_publish` calls run on the connection thread via `add_callback_threadsafe()`.
- **REQUEUE means republish**: `basic_nack(requeue=True)` re-delivers immediately with no backoff. REQUEUE republishes with an incremented `attempt` field after sleeping the backoff delay on the worker thread.
- **Malformed envelopes go to dead-letter**: parsing errors cannot be fixed by retrying. Dead-letter immediately.
- **Non-retryable errors get ACKed**: ACK removes the message; orchestrator marks the task `FAILED`. Never dead-letter a `ValidationError` or `AuthError`.

**Import rules (inner → outer):**

- `transport.py` — no intra-package imports (pure interface types)
- `config.py` — no intra-package imports (pure frozen config)
- `envelope.py` — no intra-package imports (pure parsing, stdlib only)
- `updates.py` — imports provider update envelope helper from `osp_provider_contracts`
- `runtime.py` — imports `config`, `envelope`, `transport`, `updates` (no pika)
- `rabbitmq.py` — imports `config`, `transport` (no runtime, no envelope)
- `app.py` — imports `config`, `runtime`, `rabbitmq`

```mermaid
flowchart TD
    app --> runtime
    app --> rabbitmq
    runtime --> config
    runtime --> envelope
    runtime --> transport
    runtime --> updates
    rabbitmq --> config
    rabbitmq --> transport
```

---

## Layer Guides

### `config.py` (RuntimeConfig)

**Purpose:** Single frozen dataclass holding all runtime knobs. Providers
construct it once in `runtime_app.py` and pass it to
`run_provider_with_config()`. Nothing reads env vars or config files — all
values are explicit.

**Contains:**
- `RuntimeConfig` — frozen, slotted dataclass with every tunable.

**Key fields:**

| Field | Default | Notes |
|---|---|---|
| `rabbitmq_url` | required | AMQP URL including credentials |
| `request_queue` | required | Durable queue name |
| `request_exchange` | `"osp.from_orch"` | Topic exchange for task routing |
| `request_binding` | `None` | Comma-separated routing keys (e.g. `"provider.vmware"`) |
| `prefetch_count` | `1` | Actual prefetch = `max(prefetch_count, concurrency)` |
| `concurrency` | `1` | ThreadPoolExecutor worker count for `execute()` |
| `max_attempts` | `5` | Delivery attempts before dead-lettering |
| `handler_timeout_seconds` | `None` | Per-task timeout; `None` disables it |
| `dead_letter_exchange` | `None` | Optional DLX for exhausted retries |
| `connect_max_attempts` | `0` | `0` = retry forever (daemon behavior) |
| `connect_backoff_base_seconds` | `1.0` | Initial connection retry delay |
| `connect_backoff_max_seconds` | `30.0` | Cap on connection retry delay |
| `connect_backoff_jitter_factor` | `0.2` | ±20% jitter to avoid thundering herd |
| `retry_backoff_base_seconds` | `1.0` | Initial task retry delay |
| `retry_backoff_max_seconds` | `30.0` | Cap on task retry delay |
| `retry_backoff_jitter_factor` | `0.2` | ±20% jitter for task retries |
| `provider_name` | `"unknown-provider"` | **Set this.** Provider ID in responses |
| `updates_exchange` | `"osp.to_orch"` | Exchange for task update events |
| `updates_routing_key` | `"unknown-provider"` | **Set this.** Routing key for updates |

**Design Rules:**
- Frozen: configuration must not change after startup. Frozen dataclasses are hashable and safe to share across threads.
- All defaults are conservative (`concurrency=1`, `prefetch_count=1`). Size up explicitly.

**Avoids:** env var parsing, business logic, pika imports.

---

### `transport.py` (Delivery Interface)

**Purpose:** Transport-agnostic types that decouple `ProviderRuntime` from
pika. The runtime speaks only `Delivery` and `DeliveryResult`. The runner
translates those to pika calls.

**Contains:**
- `AckAction` — ack decision (StrEnum): `ACK`, `REQUEUE`, `DEAD_LETTER`.
- `Delivery` — inbound message: `body`, `reply_to`, `routing_key`, `correlation_id`.
- `DeliveryResult` — handler output: `ack_action`, optional `response_*` fields (RPC reply), optional `update_*` fields (task event publish).

**Ack semantics:**

| `AckAction` | pika call | When |
|---|---|---|
| `ACK` | `basic_ack` | Success, or non-retryable error |
| `REQUEUE` | republish + `basic_ack` | Retryable error with attempts remaining |
| `DEAD_LETTER` | `basic_nack(requeue=False)` | Retryable exhausted, or malformed envelope |

**Design Rules:**
- `Delivery` and `DeliveryResult` are frozen dataclasses — safe to pass across thread boundaries.
- Tests construct `Delivery` directly and call `runtime.handle_delivery()` — no pika needed.

**Avoids:** pika imports, provider logic, envelope knowledge.

---

### `envelope.py` (Envelope Parsing)

**Purpose:** Parse inbound JSON bytes into `RequestEnvelope` and serialize
`ResponseEnvelope` back to bytes for contract_v1 messages.

**Contains:**
- `RequestEnvelope` — parsed contract request.
- `ResponseEnvelope` — always contract_v1 format.
- `parse_request_envelope(raw_body)` — strict contract_v1 parsing.
- `dump_response_envelope(envelope)` — compact JSON bytes.

**Request format:**

| Format | `source_format` | Shape |
|---|---|---|
| `contract_v1` | `"contract_v1"` | `{"envelope_version": "1.0", "payload": {...}, ...}` |

**Parsing strategy:**
1. JSON decode — non-dict → `ValueError` → caller dead-letters.
2. All `REQUIRED_REQUEST_FIELDS` present → contract_v1 path.
3. Missing required fields → `ValueError`.

**Design Rules:**
- `task_ref` is required; `task_id` is derived from `task_ref` when omitted.
- `task_id` is always stored as `str`.
- `attempt` defaults to `1` if missing; validated to be an integer ≥ 1.
- Malformed envelopes raise `ValueError` — caller is responsible for dead-lettering.

**Avoids:** RabbitMQ, provider calls, update logic.

---

### `runtime.py` (ProviderRuntime)

**Purpose:** Full delivery lifecycle as testable business logic — no pika
dependency, no channel operations anywhere.

**Contains:**
- `ProviderRuntime` — orchestrates envelope parsing, provider dispatch, timeout, response/update building, and ack decisions.

**Lifecycle (`handle_delivery`):**

```
Delivery
  ├── parse_request_envelope() → ValueError → DEAD_LETTER
  ├── action == "capabilities"?
  │     → ACK + raw capabilities dict (contract RPC)
  ├── _execute_provider()
  │   ├── timeout=None → provider.execute() called directly
  │   └── timeout set → submit to timeout_executor → future.result(timeout)
  │         └── TimeoutError → TransientError → REQUEUE
  ├── success → ResponseEnvelope + task update → ACK
  └── ProviderError
        ├── retryable + attempt < max_attempts → REQUEUE
        ├── retryable + attempt ≥ max_attempts → DEAD_LETTER + error update
        └── non-retryable → ACK + error update (task → FAILED)
```

**Retry decision matrix:**

| Error type | Attempts | Action |
|---|---|---|
| Non-retryable (`AuthError`, `ValidationError`, ...) | any | ACK (task → FAILED) |
| Retryable (`TransientError`, `RateLimitError`, ...) | < `max_attempts` | REQUEUE |
| Retryable | ≥ `max_attempts` | DEAD_LETTER |
| Malformed envelope | any | DEAD_LETTER |
| Handler timeout | < `max_attempts` | REQUEUE (as `TransientError`) |

**Design Rules:**
- Approval detection (`_is_approval_required`): both `exc.detail == "approval_required"` AND `exc.extra["gate_reason"]` in 400–499 must hold. Emits status 301 update instead of 580.
- Capabilities responses are advisory hints for UIs/CLIs and may be stale. Providers
  must validate payloads independently; orchestrator/portal should not enforce them.
- Progress events in `result.data["progress_events"]` are stripped from the resolved payload before building the update, to avoid duplicating data in TaskEvent rows.
- Timeout executor is single-threaded and used only for monitoring. Actual `execute()` runs on RabbitMQRunner's pool. `future.cancel()` is best-effort — Python threads blocked in C extensions cannot be interrupted.
- `close()` must be called to release the timeout executor. `run_provider_with_config` does this in its `finally` block.

**Avoids:** pika imports, channel/connection operations.

---

### `rabbitmq.py` (RabbitMQRunner) ⚠️

**Purpose:** pika-specific transport. Contains the most complex threading code
in the runtime. Understand the threading model before modifying.

**Contains:**
- `RabbitMQRunner` — connection, channel setup, `basic_consume` loop, thread-safe finalization.

**Threading model:**

```
Main thread (pika connection event loop)
  ├── _on_message()               Runs on connection thread; dispatches to executor
  └── _on_connection_thread()     Runs on connection thread; performs channel ops
        ↑ scheduled via connection.add_callback_threadsafe()
        ↑ posted by _finalize() done callback (runs on worker thread)

Worker threads (ThreadPoolExecutor, N = concurrency)
  └── handler(delivery) → DeliveryResult
        └── _finalize() done callback
              ├── _increment_retry_attempt() + time.sleep(backoff)
              └── add_callback_threadsafe(_on_connection_thread)
```

**Design Rules:**
- `basic_ack`, `basic_nack`, `basic_publish` are called only inside `_on_connection_thread`. Never from a worker thread directly.
- Backoff sleep runs on the worker thread — the connection event loop is never blocked by a retry delay.
- REQUEUE publishes to `delivery.routing_key` (or falls back to `request_queue` if missing), then ACKs the original.
- `executor.shutdown(wait=True)` in the `finally` block ensures in-flight handlers complete before the connection closes.

**Exponential backoff formula:**
```
base_delay = min(max_seconds, base_seconds × 2^(attempt-1))
jitter     = uniform(-jitter_factor × base_delay, +jitter_factor × base_delay)
delay      = base_delay + jitter
```
Used for both connection retries and task retries with separate config parameters.

**Startup sequence:**
1. Connect with retries.
2. Declare `request_exchange` and `updates_exchange` (durable topic).
3. Declare `request_queue` (durable; optional DLX arguments).
4. Bind queue to all routing keys from `request_binding` (comma-separated).
5. `basic_qos(prefetch_count=max(prefetch_count, concurrency))`.
6. `basic_consume` → `channel.start_consuming()`.

**Avoids:** business logic, envelope parsing, provider calls.

---

### `updates.py` (TaskReporter and ProviderUpdate)

**Purpose:** Task lifecycle update emission. Encapsulates wire format
knowledge so providers and `ProviderRuntime` emit updates without knowing the
orchestrator consumer's expected JSON shape.

**Contains:**
- `TaskReporter` — fluent builder instantiated with `task_id` + `task_ref`.
- `ProviderUpdate` — immutable frozen dataclass; call `.to_transport_bytes()` for RabbitMQ publish.
- `json_safe()` — recursive JSON-safe conversion for complex provider objects.

**`TaskReporter` methods:**

| Method | Status code | Severity | Use when |
|---|---|---|---|
| `accepted(message)` | 105 ACCEPTED | INFO | Provider acknowledged task |
| `running(message)` | 160 RUNNING | INFO | Task in progress |
| `progress(message, current, total)` | 160 RUNNING | INFO | In-progress with `{"progress": {"current": X, "total": Y}}` |
| `completed(message, payload)` | 200 COMPLETED | INFO | Success |
| `require_approval(gate_reason, importance, reason, ...)` | 301 WAITING_APPROVAL | WARNING | Approval flow triggered |
| `failed(message, code, ...)` | 580 PROVIDER_ERROR | ERROR | Provider error |
| `deny(message, reason_code)` | 900 REJECTED | ERROR | Provider rejected task (policy) |

**Wire format (contract envelope):**
```json
{
  "envelope_version": "1.0",
  "contract_version": "1.0",
  "message_id": "uuid4",
  "task_ref": "task-123",
  "kind": "task_event",
  "payload": {
    "status_code": 200,
    "severity": 20,
    "message": "Completed",
    "payload": {
      "requested": { "hostname": "foo" },
      "resolved": { "external_id": "vm-abc123" }
    }
  }
}
```
`message_id` (UUID4) is the update idempotency key — one message_id = one TaskEvent row.

**Why this shape (so we don't redesign it again):**
- **Single source of identity per layer.** `task_ref` is the canonical task
  identity on the wire; it’s stable across services and avoids mixing numeric
  DB ids into provider payloads. The orchestrator derives `task_id` from it.
- **Event identity lives at the envelope.** `message_id` is the update id,
  keeping dedupe consistent and preventing conflicts between transport ids and
  provider payload keys. If a custom sender includes `payload.event_id`,
  orchestrator will honor it; otherwise it falls back to `message_id`.
- **Payload stays business-only.** Providers send only domain data
  (`requested`, `resolved`, `approval`, `progress`, `error`). Orchestrator
  enriches stored events with `task_ref`/`task_id` so UIs (like osp-portal)
  see consistent metadata without requiring providers to repeat it.
- **Gates remain explicit and portable.** Approval details live under
  `payload.approval` with a string `gate_reason`, which is stable across
  providers and does not rely on legacy 4xx gate codes.

**`json_safe()` conversion rules:**

| Input | Output |
|---|---|
| `None`, `str`, `int`, `float`, `bool` | pass through |
| `dict` | recursively convert values |
| `list` / `tuple` | recursively convert elements |
| has `isoformat` (datetime) | `.isoformat()` |
| has `value` + `source` (TrackedValue) | `{"value": ..., "source": ..., "context_id": ...}` |
| anything else | `str(value)` |

**Design Rules:**
- `to_transport_bytes()` tries `json.dumps` first (fast path), catches `TypeError`, retries with `json_safe()` applied (handles complex provider objects).

**Avoids:** RabbitMQ imports, envelope knowledge, retry logic.

---

## Wire Formats

### Request envelope (contract_v1)

Sent by the orchestrator to `osp.from_orch`. Fields the runtime reads:

```json
{
  "envelope_version": "1.0",
  "contract_version": "1.0",
  "message_id": "uuid",
  "task_ref": "task-123",
  "action": "create",
  "resource_kind": "vm",
  "payload": { "hostname": "foo", "cpus": 4 },
  "attempt": 1,
  "idempotency_key": "optional-precomputed-sha256",
  "provider": "vmware"
}
```

### Response envelope (always contract_v1)

Sent back to `reply_to` queue. `result` present on success, `error` on failure:

```json
{
  "envelope_version": "1.0",
  "contract_version": "1.0",
  "message_id": "echoed",
  "task_ref": "task-123",
  "task_id": "123",
  "ok": true,
  "provider": "vmware",
  "action": "create",
  "result": {
    "success": true,
    "external_id": "vm-abc123",
    "message": "VM created",
    "data": {}
  }
}
```

Error shape when `ok=false`:

```json
{
  "error": {
    "code": "transient_error",
    "detail": "API timeout",
    "retryable": true,
    "extra": {}
  }
}
```

### Task update wire format (osp.to_orch)

Published to `updates_exchange` with `updates_routing_key`. The orchestrator
consumer creates one `TaskEvent` row per `message_id` (or `payload.event_id`
if provided by a custom sender):

```json
{
  "envelope_version": "1.0",
  "contract_version": "1.0",
  "message_id": "uuid4",
  "task_ref": "task-123",
  "kind": "task_event",
  "payload": {
    "status_code": 200,
    "severity": 20,
    "message": "VM created",
    "payload": {
      "requested": { "hostname": "foo" },
      "resolved": { "external_id": "vm-abc123" }
    }
  }
}
```

**Status codes:**

| Code | Name | Triggered by |
|---|---|---|
| 105 | ACCEPTED | `reporter.accepted()` |
| 160 | RUNNING | `reporter.running()` / `reporter.progress()` |
| 200 | COMPLETED | `reporter.completed()` |
| 301 | WAITING_APPROVAL | `reporter.require_approval()` |
| 580 | PROVIDER_ERROR | `reporter.failed()` |
| 900 | REJECTED | `reporter.deny()` |

**Severity levels:**

| Value | Name | Used for |
|---|---|---|
| 20 | INFO | Normal lifecycle events |
| 30 | WARNING | Approval required |
| 40 | ERROR | Failures and rejections |

**Reserved payload keys** (handled specially by orchestrator consumer):
- `event_id` — optional; if omitted, `message_id` is used for dedupe
- `approval` — gate payload block (`gate_reason`, `importance`, `reason`, `details`)
- `progress` — progress block (`current`, `total`)
- `progress_events` — list of intermediate progress events to expand into rows
- `error` — structured error block (`code`, `detail`, `retryable`, `extra`)

---

## RuntimeConfig by Concern

**Queue and topology:**
- `rabbitmq_url` — AMQP URL including credentials
- `request_queue` — durable queue name for incoming tasks
- `request_exchange` — topic exchange for task routing (default `"osp.from_orch"`)
- `request_binding` — comma-separated routing keys to bind (e.g. `"provider.vmware,provider.vmware.#"`)
- `updates_exchange` — exchange for outbound task events (default `"osp.to_orch"`)
- `updates_routing_key` — routing key for updates; **must match provider name**
- `dead_letter_exchange` — optional DLX for exhausted retries and malformed envelopes
- `dead_letter_routing_key` — optional DLX routing key

**Concurrency and prefetch:**
- `concurrency` — ThreadPoolExecutor worker count; controls how many `execute()` calls run in parallel (default `1`)
- `prefetch_count` — RabbitMQ prefetch hint; effective value is `max(prefetch_count, concurrency)` (default `1`)

**Retry and dead-letter:**
- `max_attempts` — delivery attempts before a retryable error is dead-lettered (default `5`)
- `retry_backoff_base_seconds` — initial delay for task retries (default `1.0`)
- `retry_backoff_max_seconds` — cap on task retry delay (default `30.0`)
- `retry_backoff_jitter_factor` — ±fraction of delay as jitter, default `0.2` (±20%)

**Timeouts:**
- `handler_timeout_seconds` — per-task timeout for `execute()`; `None` disables (default `None`)
- `heartbeat_seconds` — RabbitMQ heartbeat interval (default `60`)
- `blocked_connection_timeout_seconds` — abort if broker flow-controls the connection for this long (default `30`)

**Connection retries:**
- `connect_max_attempts` — `0` = retry forever; set > 0 to fail after N attempts (default `0`)
- `connect_backoff_base_seconds` — initial connection retry delay (default `1.0`)
- `connect_backoff_max_seconds` — cap on connection retry delay (default `30.0`)
- `connect_backoff_jitter_factor` — jitter for connection retries (default `0.2`)

**Update emission:**
- Updates are emitted for contract_v1 requests when `task_id` resolves to an integer.
- Ensure `updates_exchange` and `updates_routing_key` are set for delivery.

**Provider identity:**
- `provider_name` — provider ID embedded in response envelopes; **must be set**
- (see also `updates_routing_key` above)

---

## Data Flow

```mermaid
flowchart TD
    mq["RabbitMQ\nosp.from_orch exchange"]
    runner["RabbitMQRunner\n_on_message (connection thread)"]
    executor["ThreadPoolExecutor\nN = concurrency"]
    runtime["ProviderRuntime\nhandle_delivery()"]
    parse["parse_request_envelope()"]
    provider["Provider.execute()"]
    result["DeliveryResult\n(ack_action, response, update)"]
    callback["add_callback_threadsafe\n_on_connection_thread"]
    ack["basic_ack / nack\nor republish (REQUEUE)"]
    response["RPC response → reply_to queue"]
    update["Task update → osp.to_orch"]

    mq --> runner --> executor --> runtime
    runtime --> parse --> provider --> result
    result --> callback --> ack
    callback --> response
    callback --> update
```

---

## Threading Safety Rules

1. **Channel ops are connection-thread-only.** `basic_ack`, `basic_nack`, `basic_publish` are called only inside `_on_connection_thread`, always scheduled via `add_callback_threadsafe`.
2. **Backoff sleep is on the worker thread.** `time.sleep(retry_delay)` in `_finalize` blocks the worker, not the connection event loop.
3. **Executor drains before connection closes.** `executor.shutdown(wait=True)` in the `finally` block ensures all in-flight handlers complete before the connection closes.
4. **Timeout executor is single-threaded.** Its sole purpose is timeout monitoring. Actual `execute()` runs on RabbitMQRunner's pool.

---

## Design Recipes

### Testing without RabbitMQ

**Why:** `RabbitMQRunner` requires a live connection. Provider dispatch logic shouldn't need one.

**How:** Construct `Delivery` directly and call `runtime.handle_delivery()`:

```python
runtime = ProviderRuntime(provider=MyProvider(), config=config)
body = json.dumps({"envelope_version": "1.0", ..., "action": "create", "payload": {}}).encode()
result = runtime.handle_delivery(Delivery(body=body, reply_to=None))
assert result.ack_action == AckAction.ACK
runtime.close()
```

### Requeue with backoff

**Why:** `basic_nack(requeue=True)` re-delivers immediately. Transient errors
(rate limits, timeouts, flapping dependencies) need exponential delay.

**How:** Return `AckAction.REQUEUE`. `_finalize` increments `attempt`, sleeps
the backoff delay, then `_on_connection_thread` republishes with the modified
body and ACKs the original. `max_attempts` prevents infinite loops.

### Update emission

**Why:** Orchestrator consumes update events on `osp.to_orch`.

**How:** Updates are emitted for contract_v1 requests when `task_id` resolves
to an integer. Ensure `updates_exchange` and `updates_routing_key` are set.

---

## Extending the Runtime

### Adding a new ack action

1. Add a value to `AckAction` in `transport.py`:
   ```python
   class AckAction(StrEnum):
       ACK = "ack"
       REQUEUE = "requeue"
       DEAD_LETTER = "dead_letter"
       MY_ACTION = "my_action"
   ```
2. Handle it in `RabbitMQRunner._on_connection_thread` with the correct pika call.
3. Update `ProviderRuntime._handle_provider_error` to return the new action where needed.
4. Add tests covering the new action path in `ProviderRuntime`.

### Adding a new TaskReporter status

1. Add constants to `TaskReporter` in `updates.py`:
   ```python
   STATUS_MY_STATUS = 170
   SEVERITY_MY_SEVERITY = 20
   ```
2. Add a method following the existing pattern:
   ```python
   def my_status(self, *, message: str, payload: dict | None = None) -> ProviderUpdate:
       return self.update(
           status_code=self.STATUS_MY_STATUS,
           severity=self.SEVERITY_MY_SEVERITY,
           message=message,
           payload=payload,
       )
   ```
3. Update the orchestrator consumer to handle the new status code if it is a new value.

### Adding a new envelope field

1. Add the field to `RequestEnvelope` or `ResponseEnvelope` in `envelope.py`:
   ```python
   @dataclass(frozen=True, slots=True)
   class RequestEnvelope:
       ...
       my_field: str | None = None
   ```
2. Extract it in `parse_request_envelope`:
   ```python
   my_field=str(data["my_field"]) if "my_field" in data else None,
   ```
3. If it belongs in `ResponseEnvelope`, update `dump_response_envelope` (it uses `asdict()` so it will serialize automatically).
4. Bump `envelope_version` if the change is breaking for consumers.

### Tuning backoff for a specific provider

Override just the parameters you need in `RuntimeConfig`:
```python
config = RuntimeConfig(
    ...,
    # Longer initial delay for an API that needs time to recover
    retry_backoff_base_seconds=5.0,
    retry_backoff_max_seconds=120.0,
    # Less jitter if tasks are independent
    retry_backoff_jitter_factor=0.1,
    # More attempts before dead-lettering
    max_attempts=10,
)
```

---

## Common Issues

- **Messages requeued immediately without delay**: `basic_nack(requeue=True)` was used directly. Always use `AckAction.REQUEUE` and let `RabbitMQRunner` handle the republish with backoff.
- **pika `StreamLostError` from worker thread**: channel ops were called outside `add_callback_threadsafe`. Move all `basic_ack/nack/publish` into `_on_connection_thread`.
- **`provider_name` still `"unknown-provider"`**: set `provider_name` and `updates_routing_key` in `RuntimeConfig`. The runner logs a warning on startup if either is left at the default.
- **Approval gate not triggering**: `ValidationError` must have both `detail="approval_required"` and `extra["gate_reason"]` in 400–499. Both conditions required.
- **Task update not appearing in orchestrator**: ensure `task_id` resolves to an integer — contract UUIDs cannot be coerced and skip emission.
- **Timeout not firing**: `handler_timeout_seconds=None` (default) disables it entirely. Set to a float to enable. Note `future.cancel()` is best-effort.
- **Dead-letter exchange not routing**: DLX must be declared before the queue. RabbitMQ requires the exchange to exist when the queue is declared with `x-dead-letter-exchange`.
- **Worker starvation**: if `concurrency=4` but `prefetch_count=1`, only one message is in-flight. Set `prefetch_count >= concurrency` or rely on the automatic `max(prefetch_count, concurrency)`.

---

## Mini Cheat Sheet

- **Start a provider?** Call `run_provider_with_config(provider, config)`.
- **Test without RabbitMQ?** Construct `Delivery`, call `runtime.handle_delivery()`.
- **Change retry limit?** Set `config.max_attempts`.
- **Add per-task timeout?** Set `config.handler_timeout_seconds = 120.0`.
- **Route failures to a DLQ?** Set `config.dead_letter_exchange`.
- **Emit a progress update?** `reporter.progress(message="...", current=3, total=10)`.
- **Debug retry decisions?** Look for `decision=requeue/dead_letter` in structured logs.
- **Debug threading issues?** All channel ops must go through `add_callback_threadsafe`.
- **Decode approval gate?** Check `exc.detail == "approval_required"` and `exc.extra["gate_reason"]`.
