"""Package version identifier following semver."""

__version__ = "0.2.10"
