# Release Guide

Automated on tag `vX.Y.Z`:
- run lint, type-check, tests
- build sdist + wheel
- run `twine check dist/*`
- attach artifacts to GitHub Release

Manual/gated publish:

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run check
hatch run dev:publish
```

Pre-publish note:
- `osp-provider-runtime` depends on `osp-provider-contracts`.
- Publish contracts first (or use local `uv` checks in monorepo before publish).

For internal index or other repository:

```bash
hatch run dev:publish -- -r <repo-name>
```

`dev:publish` behavior:
- removes `dist/` first (no stale artifact uploads)
- builds fresh wheel + sdist for the current version
- runs `twine check` before upload
- disables keyring backend to avoid locked desktop keyring failures

Credentials should be stored in `~/.pypirc` (or keyring), not committed.

TestPyPI dry run publish:

```bash
hatch run dev:publish-test
```
