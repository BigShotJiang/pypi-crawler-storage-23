# Runtime Messaging Contract (v0.1)

Request envelope required fields:
- `envelope_version` (string)
- `contract_version` (string)
- `message_id` (string)
- `task_ref` (string, e.g. `task-123`)
- `action` (string)
- `resource_kind` (string)
- `payload` (object)

Optional fields:
- `task_id` (string, must match `task_ref` if provided)
- `attempt` (int, defaults to 1)
- `idempotency_key` (string)
- `provider` (string)

Response envelope:
- `envelope_version`
- `contract_version`
- `message_id`
- `task_ref`
- `task_id`
- `ok` (bool)
- `provider` (string)
- `action` (string)
- `result` (object, only when `ok=true`)
- `error` (object, only when `ok=false`)

Error object shape:
- `code` (string)
- `detail` (string | null)
- `retryable` (bool)
- `extra` (object)

Ack policy:
- Success: `ack`.
- `ProviderError(retryable=false)`: `ack`.
- `ProviderError(retryable=true)`: `requeue` until max attempts; then dead-letter.
- Unknown exception: treat as retryable transient error with same attempt policy.

Update emission:
- Runtime emits provider updates on `osp.to_orch` using the contract update envelope.
- Envelope fields: `envelope_version`, `contract_version`, `message_id`, `task_ref`, `kind` ("task_event"), `payload`.
- Event payload fields: `status_code`, `severity`, `message`, `payload`.
- `message_id` is the update id; if a custom sender includes `payload.event_id`,
  the orchestrator will honor it, otherwise it falls back to `message_id`.

Reserved payload keys:
- `approval`: gate payload block (for approval-required flow)
- `progress`: informational progress block (`current`, `total`)

Runtime topology behavior:
- Runtime declares and binds its request queue on startup.
- Default request exchange: `osp.from_orch` (topic).
- Default request binding: `<provider_name>.#`.
- Default updates exchange: `osp.to_orch` (topic).
