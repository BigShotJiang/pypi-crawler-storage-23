# Release Notes: osp-provider-runtime 0.2.6

Date: 2026-02-13

## Summary

This patch release fixes capabilities RPC reply correlation for canonical
contract-envelope requests.

## Changes

- Capabilities reply now uses inbound AMQP `correlation_id` for response
  correlation matching.
- Added regression test coverage for capabilities correlation behavior.

## Operational Impact

- Fixes orchestrator capability RPC timeouts caused by correlation mismatch.
- No change to task execution/update contract behavior.

## Upgrade Guidance

1. Publish runtime `0.2.6` to PyPI.
2. Rebuild provider images (`vmware`, `nrec`) so they resolve `0.2.6`.
3. Roll out provider containers and verify capabilities endpoints.
