# Release Notes: osp-provider-runtime 0.2.4

Date: 2026-02-13

## Summary

This patch release restores runtime compatibility with orchestrator capability
RPC requests that still use the legacy message shape:

```json
{"op":"capabilities"}
```

Without this fix, providers on runtime `0.2.3` could reject capability RPC
calls as malformed envelopes.

## Changes

- Added legacy capabilities RPC handling in `ProviderRuntime.handle_delivery`.
- Added `correlation_id` to runtime `Delivery` transport model.
- Wired AMQP `properties.correlation_id` into delivery transport.
- Echoed correlation id in legacy capabilities RPC responses.
- Added regression test for legacy capabilities RPC.

## Operational Impact

- Provider images using runtime `0.2.3` may log repeated
  `Malformed request envelope` errors for capabilities RPC.
- Upgrading to `0.2.4` removes those errors and restores compatibility while
  preserving contract-envelope behavior for normal task requests.

## Upgrade Guidance

1. Publish runtime `0.2.4` to PyPI.
2. Rebuild provider images (`vmware`, `nrec`) so they resolve `0.2.4`.
3. Roll out provider containers and verify `/v1/capabilities` calls succeed.
