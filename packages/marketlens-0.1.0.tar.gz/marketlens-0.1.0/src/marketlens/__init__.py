"""MarketLens Python SDK — prediction market data for researchers and quant traders."""

from marketlens._client import AsyncMarketLens, MarketLens
from marketlens._constants import VERSION
from marketlens.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    ForbiddenError,
    InvalidParameterError,
    MarketLensError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
)
from marketlens.helpers.replay import AsyncOrderBookReplay, OrderBookReplay
from marketlens.helpers.walk import AsyncMarketSlot, MarketSlot
from marketlens.types import (
    BookMetrics,
    Candle,
    DeltaEvent,
    Event,
    Market,
    MarketStatus,
    OrderBook,
    Outcome,
    Platform,
    PriceLevel,
    Resolution,
    Series,
    Side,
    SnapshotEvent,
    Trade,
    TradeEvent,
)

__version__ = VERSION

__all__ = [
    # Clients
    "MarketLens",
    "AsyncMarketLens",
    # Types
    "Market",
    "Outcome",
    "Event",
    "Series",
    "Trade",
    "Candle",
    "OrderBook",
    "PriceLevel",
    "BookMetrics",
    "SnapshotEvent",
    "DeltaEvent",
    "TradeEvent",
    # Enums
    "MarketStatus",
    "Side",
    "Platform",
    "Resolution",
    # Helpers
    "OrderBookReplay",
    "AsyncOrderBookReplay",
    "MarketSlot",
    "AsyncMarketSlot",
    # Exceptions
    "MarketLensError",
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "InvalidParameterError",
    "RateLimitError",
    "ConnectionError",
    "TimeoutError",
    # Version
    "__version__",
]
