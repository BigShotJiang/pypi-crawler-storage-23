import click

@click.command()
def main():
    """Main entry point for biz-proj CLI."""
    click.echo("Biz Project CLI is running!")