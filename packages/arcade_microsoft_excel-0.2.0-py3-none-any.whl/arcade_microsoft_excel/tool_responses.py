"""TypedDict models for Microsoft Excel tool responses."""

from typing_extensions import TypedDict

# Re-export WhoAmIResponse for consistency
from arcade_microsoft_excel.who_am_i_util import WhoAmIResponse

__all__ = [
    "AddWorksheetResponse",
    "CreateWorkbookResponse",
    "DeleteWorksheetResponse",
    "GetWorkbookMetadataResponse",
    "GetWorksheetDataResponse",
    "PaginationInfo",
    "PaginationRange",
    "RangeInfo",
    "RenameWorksheetResponse",
    "UpdateCellResponse",
    "UpdateRangeResponse",
    "WhoAmIResponse",
    "WorkbookItemData",
    "WorkbookItemSize",
    "WorksheetInfo",
]


class WorkbookItemSize(TypedDict, total=False):
    """Size information for a workbook."""

    bytes: int
    formatted: str


class WorkbookItemData(TypedDict, total=False):
    """Serialized Excel workbook metadata."""

    object_type: str
    item_id: str
    name: str
    parent_folder_id: str
    size: WorkbookItemSize
    web_url: str
    etag: str


class WorksheetInfo(TypedDict):
    """Basic worksheet information."""

    id: str
    name: str
    position: int
    visibility: str


class RangeInfo(TypedDict):
    """Information about the returned range."""

    start_row: int
    start_col: str
    end_row: int
    end_col: str


class PaginationRange(TypedDict, total=False):
    """Parameters to use for fetching more data."""

    start_row: int
    start_col: str


class PaginationInfo(TypedDict, total=False):
    """Pagination hints for fetching additional data.

    Only present if more data exists in that direction.
    """

    next_rows: PaginationRange
    next_cols: PaginationRange


class CreateWorkbookResponse(TypedDict):
    """Response from create_workbook tool."""

    item: WorkbookItemData
    session_id: str
    message: str


class GetWorkbookMetadataResponse(TypedDict):
    """Response from get_workbook_metadata tool."""

    item_id: str
    name: str
    web_url: str
    worksheets: list[WorksheetInfo]
    worksheet_count: int
    session_id: str


class GetWorksheetDataResponse(TypedDict):
    """Response from get_worksheet_data tool."""

    item_id: str
    worksheet: str
    range: RangeInfo
    total_rows: int
    total_columns: int
    pagination: PaginationInfo
    data: dict
    session_id: str


class UpdateCellResponse(TypedDict):
    """Response from update_cell tool."""

    item_id: str
    worksheet: str
    cell: str
    value: str
    session_id: str
    message: str


class UpdateRangeResponse(TypedDict):
    """Response from update_range tool."""

    item_id: str
    worksheet: str
    cells_updated: int
    session_id: str
    message: str


class AddWorksheetResponse(TypedDict):
    """Response from add_worksheet tool."""

    item_id: str
    worksheet: WorksheetInfo
    session_id: str
    message: str


class RenameWorksheetResponse(TypedDict):
    """Response from rename_worksheet tool."""

    item_id: str
    worksheet: WorksheetInfo
    previous_name: str
    session_id: str
    message: str


class DeleteWorksheetResponse(TypedDict):
    """Response from delete_worksheet tool."""

    item_id: str
    deleted_worksheet: str
    session_id: str
    message: str
