"""Excel session management utilities.

Re-exports session helpers from arcade_microsoft_utils.excel_utils so that
both the OneDrive Excel toolkit and SharePoint Excel tools share the same
session logic without cross-package dependencies.
"""

from arcade_microsoft_utils.excel_utils import (
    _close_excel_session as close_session,
)
from arcade_microsoft_utils.excel_utils import (
    _create_excel_session as create_session,
)
from arcade_microsoft_utils.excel_utils import (
    _ensure_excel_session as ensure_session,
)
from arcade_microsoft_utils.excel_utils import (
    _execute_with_session_retry as execute_with_session_retry,
)
from arcade_microsoft_utils.excel_utils import (
    _is_session_expired_error,
)

__all__ = [
    "create_session",
    "close_session",
    "ensure_session",
    "execute_with_session_retry",
    "_is_session_expired_error",
]


def get_session_header(session_id: str | None) -> dict[str, str]:
    """Get headers dict with session ID if provided."""
    if session_id:
        return {"workbook-session-id": session_id}
    return {}
