"""Worksheet-level Excel operations: update cells, manage worksheets."""

import logging
from typing import Annotated, Any

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_microsoft_utils.excel_utils import (
    _build_drive_base_path,
    _build_workbook_worksheets_path,
    _cell_address,
    _graph_request,
    _is_last_worksheet_error,
    _list_worksheets,
    _parse_sparse_dict,
    _resolve_worksheet_name_and_id,
    _sparse_dict_to_bounding_box_patch,
)
from arcade_microsoft_utils.exceptions import (
    CannotDeleteLastWorksheetError,
    MicrosoftToolExecutionError,
)

from arcade_microsoft_excel.client import get_client
from arcade_microsoft_excel.serializers import serialize_worksheet
from arcade_microsoft_excel.session import execute_with_session_retry
from arcade_microsoft_excel.tool_responses import (
    AddWorksheetResponse,
    DeleteWorksheetResponse,
    RenameWorksheetResponse,
    UpdateCellResponse,
    UpdateRangeResponse,
)

logger = logging.getLogger(__name__)


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_cell(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    column: Annotated[str, "Column letter or letters (e.g., 'A', 'BC')."],
    row: Annotated[int, "Row number (1-indexed)."],
    value: Annotated[
        str,
        "The value to set. Supports strings, numbers, booleans, and formulas (e.g., '=SUM(A1:A10)').",
    ],
    worksheet: Annotated[
        str | None,
        "Worksheet name to update. If omitted, updates the first worksheet.",
    ] = None,
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[UpdateCellResponse, "Confirmation of the cell update."]:
    """Update a single cell value in an Excel workbook.

    Supports strings, numbers, booleans, and formulas (values starting with '=').

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    cell_addr = _cell_address(column, row)

    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_update(sid: str) -> None:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        # Always use 'formulas' field — it accepts both plain values and formulas
        await _graph_request(
            token,
            method="PATCH",
            path=f"{ws_path}/range(address='{cell_addr}')",
            session_id=sid,
            body={"formulas": [[value]]},
        )

    _, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _do_update
    )

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "cell": cell_addr,
        "value": value,
        "session_id": sid,
        "message": f"Cell {cell_addr} updated to '{value}' in worksheet '{ws_name}'.",
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_range(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    data: Annotated[
        str,
        "JSON string where data[ROW][COL] = VALUE. "
        "ROW is a row number as string, COL is a column letter (uppercase), "
        "VALUE is string/number/boolean/null. "
        "Type: dict[str, dict[str, str | int | float | bool | None]].",
    ],
    worksheet: Annotated[
        str | None,
        "Worksheet name to update. If omitted, updates the first worksheet.",
    ] = None,
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[
    UpdateRangeResponse, "Confirmation of the range update with cell count."
]:
    """Update multiple cells in a worksheet using sparse dict format.

    Only specified cells are updated; unspecified cells remain unchanged.
    The data format is the same as Google Sheets update_cells.

    Internally, a single PATCH request is sent covering the bounding box
    of all specified cells.  Cells within the box that are not in the
    input are sent as ``null``, which the Graph API treats as "skip".

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    # Parse and validate the sparse dict
    parsed_data = _parse_sparse_dict(data)
    if not parsed_data:
        raise MicrosoftToolExecutionError("No data provided to update.")

    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    # Build a single bounding-box patch (null = skip unchanged cells)
    patch = _sparse_dict_to_bounding_box_patch(parsed_data)

    # Count actual cells being updated (non-null entries)
    cells_updated = sum(len(cols) for cols in parsed_data.values())

    async def _do_update(sid: str) -> None:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        await _graph_request(
            token,
            method="PATCH",
            path=f"{ws_path}/range(address='{patch.address}')",
            session_id=sid,
            body={"formulas": patch.formulas},
        )

    _, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _do_update
    )

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "cells_updated": cells_updated,
        "session_id": sid,
        "message": f"Updated {cells_updated} cells in worksheet '{ws_name}'.",
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def add_worksheet(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    name: Annotated[
        str | None,
        "Name for the new worksheet. If omitted, Excel generates a default name.",
    ] = None,
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[AddWorksheetResponse, "The created worksheet info."]:
    """Add a new worksheet to the workbook.

    Note: The new worksheet name may not be immediately visible to other
    tools due to a brief Graph API propagation delay (up to ~10 s). Pass
    the returned ``session_id`` to subsequent calls that reference the new
    worksheet to mitigate this.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    async def _do_add(sid: str) -> dict[str, Any]:
        drive_base = _build_drive_base_path(drive_id)
        path = f"{drive_base}/items/{item_id}/workbook/worksheets/add"
        body: dict[str, Any] = {}
        if name:
            body["name"] = name
        resp = await _graph_request(token, "POST", path, session_id=sid, body=body)
        return dict(resp)

    result, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _do_add
    )

    ws_info = serialize_worksheet(result)
    ws_name_display = ws_info["name"]

    return {
        "item_id": item_id,
        "worksheet": ws_info,
        "session_id": sid,
        "message": f"Worksheet '{ws_name_display}' added to the workbook.",
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def rename_worksheet(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[str, "Current name of the worksheet to rename."],
    new_name: Annotated[str, "New name for the worksheet."],
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[RenameWorksheetResponse, "The renamed worksheet info."]:
    """Rename an existing worksheet in the workbook.

    Note: The new name may not be immediately visible to other tools due
    to a brief Graph API propagation delay (up to ~10 s). Pass the returned
    ``session_id`` to subsequent calls that reference the renamed worksheet
    to mitigate this. If referencing a recently added worksheet as the source,
    the same delay applies; retry with the ``session_id`` if a
    WorksheetNotFoundError occurs.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    previous_name = worksheet

    # Resolve current worksheet name to ID before the session callback.
    # Session-aware when session_id is provided (the typical agent pattern).
    _, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_rename(sid: str) -> dict[str, Any]:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        resp = await _graph_request(
            token, "PATCH", ws_path, session_id=sid, body={"name": new_name}
        )
        return dict(resp)

    result, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _do_rename
    )

    ws_info = serialize_worksheet(result)

    return {
        "item_id": item_id,
        "worksheet": ws_info,
        "previous_name": previous_name,
        "session_id": sid,
        "message": f"Worksheet renamed from '{previous_name}' to '{new_name}'.",
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.DELETE],
            read_only=False,
            destructive=True,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def delete_worksheet(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[str, "Name of the worksheet to delete."],
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[DeleteWorksheetResponse, "Confirmation of the worksheet deletion."]:
    """Delete a worksheet from the workbook.

    Cannot delete the last worksheet in a workbook.

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    # Session-aware worksheet listing for accurate count check
    ws_items = await _list_worksheets(token, item_id, drive_id, session_id)
    if len(ws_items) <= 1:
        raise CannotDeleteLastWorksheetError()

    _, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_delete(sid: str) -> dict[str, Any]:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        resp = await _graph_request(token, "DELETE", ws_path, session_id=sid)
        return dict(resp)

    try:
        _, sid = await execute_with_session_retry(
            client, item_id, session_id, drive_id, _do_delete
        )
    except httpx.HTTPStatusError as exc:
        if _is_last_worksheet_error(exc):
            logger.warning(
                "delete_worksheet got last-worksheet 400: %s", exc.response.text
            )
            raise CannotDeleteLastWorksheetError() from exc
        raise

    return {
        "item_id": item_id,
        "deleted_worksheet": worksheet,
        "session_id": sid,
        "message": f"Worksheet '{worksheet}' deleted from the workbook.",
    }
