from typing import Annotated

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft

from arcade_microsoft_excel.client import get_client
from arcade_microsoft_excel.who_am_i_util import WhoAmIResponse, build_who_am_i_response


@tool(
    requires_auth=Microsoft(scopes=["User.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: Context,
) -> Annotated[
    WhoAmIResponse,
    "Get comprehensive user profile and Microsoft Excel environment information.",
]:
    """
    Get information about the current user and their Microsoft Excel environment.
    """
    client = get_client(context.get_auth_token_or_empty())
    return await build_who_am_i_response(client)
