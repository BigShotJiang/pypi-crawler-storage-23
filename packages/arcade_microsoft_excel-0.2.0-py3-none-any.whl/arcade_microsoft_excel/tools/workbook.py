"""Workbook-level Excel operations: create, metadata, read data."""

from typing import Annotated

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import UpstreamError
from arcade_microsoft_utils.excel_utils import (
    _build_batch_request,
    _build_drive_base_path,
    _build_xlsx_bytes,
    _col_index_to_letter,
    _col_letter_to_index,
    _compute_range_address,
    _ensure_xlsx_payload_under_limit,
    _execute_batch,
    _get_batch_response,
    _normalize_xlsx_filename,
    _parse_range_address,
    _range_response_to_sparse_dict,
    _resolve_worksheet_name_and_id,
    _upload_xlsx_content,
)

from arcade_microsoft_excel.client import get_client
from arcade_microsoft_excel.serializers import (
    serialize_workbook_item,
    serialize_worksheet,
)
from arcade_microsoft_excel.session import create_session, execute_with_session_retry
from arcade_microsoft_excel.tool_responses import (
    CreateWorkbookResponse,
    GetWorkbookMetadataResponse,
    GetWorksheetDataResponse,
    PaginationInfo,
    RangeInfo,
)


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_workbook(
    context: Context,
    filename: Annotated[
        str,
        "File name for the new workbook. The .xlsx extension is added automatically if not provided.",
    ],
    parent_folder_id: Annotated[
        str | None,
        "Parent folder ID. If omitted, the workbook is created in the root of OneDrive.",
    ] = None,
    initial_data: Annotated[
        str | None,
        "Optional JSON string for initial data in the first worksheet. "
        "Format: data[ROW][COL] = VALUE where ROW is a row number as string, "
        "COL is a column letter (uppercase), VALUE is string/number/boolean/null. "
        "Type: dict[str, dict[str, str | int | float | bool | None]].",
    ] = None,
) -> Annotated[
    CreateWorkbookResponse, "The created Excel workbook metadata with session ID."
]:
    """Create a new Excel workbook (.xlsx) in OneDrive for Business.

    Only .xlsx files are supported. OneDrive Consumer (personal accounts) is NOT supported.
    """
    filename = _normalize_xlsx_filename(filename)
    token = context.get_auth_token_or_empty()

    # Build the .xlsx file bytes (with optional initial data)
    xlsx_bytes = _build_xlsx_bytes(initial_data)
    _ensure_xlsx_payload_under_limit(xlsx_bytes)

    # Build upload URL path with conflict=fail to prevent overwriting existing files
    drive_base = _build_drive_base_path(None)
    if parent_folder_id:
        upload_path = (
            f"{drive_base}/items/{parent_folder_id}:/{filename}:"
            f"/content?@microsoft.graph.conflictBehavior=fail"
        )
    else:
        upload_path = f"{drive_base}/root:/{filename}:/content?@microsoft.graph.conflictBehavior=fail"

    # Upload the file (raises FileAlreadyExistsError on 409 Conflict)
    item_response = await _upload_xlsx_content(
        token, upload_path, xlsx_bytes, filename=filename
    )
    item_id = item_response.get("id", "")

    # Create a session for follow-up operations
    client = get_client(token)
    session_id = await create_session(client, item_id)

    return {
        "item": serialize_workbook_item(item_response),
        "session_id": session_id,
        "message": f"Workbook '{filename}' created successfully.",
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_workbook_metadata(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[
    GetWorkbookMetadataResponse, "Workbook metadata including worksheet list."
]:
    """Get metadata about an Excel workbook including worksheet list.

    Returns workbook name, URL, and all worksheets with their names, positions, and visibility.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    async def _fetch_metadata(sid: str) -> dict:
        drive_base = _build_drive_base_path(drive_id)

        # Batch: DriveItem metadata + worksheet list
        requests = [
            _build_batch_request(
                request_id="drive_item",
                method="GET",
                url=f"{drive_base}/items/{item_id}",
            ),
            _build_batch_request(
                request_id="worksheets",
                method="GET",
                url=f"{drive_base}/items/{item_id}/workbook/worksheets",
                session_id=sid,
            ),
        ]

        responses = await _execute_batch(token, requests)

        drive_item_resp = _get_batch_response(responses, "drive_item")
        worksheets_resp = _get_batch_response(responses, "worksheets")

        if drive_item_resp.get("status") != 200:
            status = drive_item_resp.get("status", 500)
            error = drive_item_resp.get("body", {}).get("error", {})
            raise UpstreamError(
                f"Failed to get workbook metadata: {error.get('message', 'Unknown error')}",
                status_code=status,
            )

        if worksheets_resp.get("status") != 200:
            status = worksheets_resp.get("status", 500)
            error = worksheets_resp.get("body", {}).get("error", {})
            raise UpstreamError(
                f"Failed to list worksheets: {error.get('message', 'Unknown error')}",
                status_code=status,
            )

        return {
            "drive_item": drive_item_resp.get("body", {}),
            "worksheets": worksheets_resp.get("body", {}).get("value", []),
        }

    result, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _fetch_metadata
    )

    drive_item = result["drive_item"]
    worksheets_raw = result["worksheets"]

    worksheets = [serialize_worksheet(ws) for ws in worksheets_raw]

    return {
        "item_id": item_id,
        "name": drive_item.get("name", ""),
        "web_url": drive_item.get("webUrl", ""),
        "worksheets": worksheets,
        "worksheet_count": len(worksheets),
        "session_id": sid,
    }


@tool(
    requires_auth=Microsoft(scopes=["Files.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SPREADSHEETS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_worksheet_data(
    context: Context,
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[
        str | None,
        "Worksheet name to read from. If omitted, reads from the first worksheet.",
    ] = None,
    start_row: Annotated[int, "Starting row number (1-indexed). Defaults to 1."] = 1,
    start_col: Annotated[str, "Starting column letter. Defaults to A."] = "A",
    max_rows: Annotated[
        int,
        "Maximum rows to return. Defaults to 1000, maximum allowed is 1000.",
    ] = 1000,
    max_cols: Annotated[
        int,
        "Maximum columns to return. Defaults to 100, maximum allowed is 100.",
    ] = 100,
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default OneDrive.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[
    GetWorksheetDataResponse, "Worksheet data in sparse dict format with pagination."
]:
    """Read cell values from a worksheet.

    Returns data in sparse dict format where data[ROW][COL] has userEnteredValue
    and formattedValue for each non-empty cell. Includes pagination hints if more
    data exists beyond the requested range.

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    # Enforce scale limits
    max_rows = min(max_rows, 1000)
    max_cols = min(max_cols, 100)

    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _fetch_data(sid: str) -> dict:
        drive_base = _build_drive_base_path(drive_id)
        ws_path = f"{drive_base}/items/{item_id}/workbook/worksheets/{ws_id}"

        # Compute the range address
        range_address = _compute_range_address(start_col, start_row, max_cols, max_rows)

        # Batch: range data + usedRange
        requests = [
            _build_batch_request(
                request_id="range_data",
                method="GET",
                url=f"{ws_path}/range(address='{range_address}')",
                session_id=sid,
            ),
            _build_batch_request(
                request_id="used_range",
                method="GET",
                url=f"{ws_path}/usedRange",
                session_id=sid,
            ),
        ]

        responses = await _execute_batch(token, requests)

        range_resp = _get_batch_response(responses, "range_data")
        used_resp = _get_batch_response(responses, "used_range")

        if range_resp.get("status") != 200:
            status = range_resp.get("status", 500)
            error = range_resp.get("body", {}).get("error", {})
            raise UpstreamError(
                f"Failed to read range data: {error.get('message', 'Unknown error')}",
                status_code=status,
            )

        # usedRange is best-effort: if it fails, degrade gracefully
        # by returning an empty body (pagination hints will be omitted)
        used_body = used_resp.get("body", {}) if used_resp.get("status") == 200 else {}

        return {
            "range_body": range_resp.get("body", {}),
            "used_body": used_body,
        }

    result, sid = await execute_with_session_retry(
        client, item_id, session_id, drive_id, _fetch_data
    )

    range_body = result["range_body"]
    used_body = result["used_body"]

    # Parse the range address to get actual bounds
    range_address = range_body.get("address", "")
    actual_start_col, actual_start_row, actual_end_col, actual_end_row = (
        _parse_range_address(range_address)
    )

    # Convert to sparse dict
    data = _range_response_to_sparse_dict(
        range_body, actual_start_col, actual_start_row
    )

    # Derive total dimensions from usedRange
    used_address = used_body.get("address", "")
    if used_address and "!" in used_address:
        _, _, used_end_col_str, used_end_row = _parse_range_address(used_address)
        total_rows = used_end_row
        total_columns = _col_letter_to_index(used_end_col_str)
    else:
        total_rows = used_body.get("rowCount", 0)
        total_columns = used_body.get("columnCount", 0)

    # Compute pagination hints
    pagination: PaginationInfo = {}
    actual_end_row_idx = actual_end_row
    actual_end_col_idx = _col_letter_to_index(actual_end_col)

    if actual_end_row_idx < total_rows:
        pagination["next_rows"] = {
            "start_row": actual_end_row_idx + 1,
            "start_col": start_col,
        }

    if actual_end_col_idx < total_columns:
        pagination["next_cols"] = {
            "start_row": start_row,
            "start_col": _col_index_to_letter(actual_end_col_idx + 1),
        }

    range_info: RangeInfo = {
        "start_row": actual_start_row,
        "start_col": actual_start_col,
        "end_row": actual_end_row,
        "end_col": actual_end_col,
    }

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "range": range_info,
        "total_rows": total_rows,
        "total_columns": total_columns,
        "pagination": pagination,
        "data": data,
        "session_id": sid,
    }
