"""Setup configuration for GPU Memory Profiler."""

from setuptools import setup

if __name__ == "__main__":
    setup()
