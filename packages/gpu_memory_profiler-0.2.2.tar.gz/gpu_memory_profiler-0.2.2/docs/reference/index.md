[← Back to main docs](../index.md)

# API Reference (Generated)

This section contains API pages generated from code and docstrings.

```{toctree}
:maxdepth: 2

api
```

---

[← Back to main docs](../index.md)
