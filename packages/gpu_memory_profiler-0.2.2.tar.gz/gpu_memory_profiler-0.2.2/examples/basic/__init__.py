"""Curated basic demos for PyTorch and TensorFlow."""
