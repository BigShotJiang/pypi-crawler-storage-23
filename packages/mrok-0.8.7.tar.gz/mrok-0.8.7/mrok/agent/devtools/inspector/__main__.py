import sys

from mrok.agent.devtools.inspector.app import module_main

module_main(sys.argv[1:])
