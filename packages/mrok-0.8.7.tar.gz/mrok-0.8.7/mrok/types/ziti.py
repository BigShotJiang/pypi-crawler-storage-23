Tags = dict[str, str | bool | None]
