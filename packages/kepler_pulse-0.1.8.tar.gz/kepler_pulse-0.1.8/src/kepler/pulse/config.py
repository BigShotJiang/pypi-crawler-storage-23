"""
Configuration module for kepler-pulse.
"""

# Date range constants
DEFAULT_BEGIN_DATE: str = '19900101'
DEFAULT_END_DATE: str = '20990101'
MAX_STEP_FORWARD: int = 600

# Frequency search steps
DAILY_SEARCH_STEPS: int = 600
WEEKLY_OFFSET: int = 20
MONTHLY_OFFSET: int = 40
QUARTERLY_OFFSET: int = 120
YEARLY_OFFSET: int = 300

# Futures configuration
FUTURES_START_DATE: str = '20150501'
TREASURY_START_DATE: str = '20151231'
CONTRACT_SWITCH_DAYS: int = 4
YEARS_FORWARD: int = 2
