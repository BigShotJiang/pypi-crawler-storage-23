"""
Utility functions for kepler-pulse.
"""

import re

# 日期格式验证
DATE_PATTERN = re.compile(r'^\d{8}$')


def validate_date(date) -> str:
    """
    验证并规范化日期为 YYYYMMDD 字符串.

    Args:
        date: 日期，只接受 int 或 str（YYYYMMDD 格式）

    Returns:
        YYYYMMDD 格式的日期字符串

    Raises:
        ValueError: 如果日期格式无效
    """
    s = str(date)
    if not DATE_PATTERN.match(s):
        raise ValueError(f"Invalid date format: {date!r}. Expected YYYYMMDD format.")
    return s
