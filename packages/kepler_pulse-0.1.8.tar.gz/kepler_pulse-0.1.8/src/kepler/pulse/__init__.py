"""
Kepler Pulse - Trading Calendar.

Examples:
    >>> from kepler.pulse import Calendar
    >>> cal = Calendar(trade_dates)
    >>>
    >>> # 基础
    >>> cal.range('20240101', '20240131')
    >>> cal.adjust('20240106', 'next')
    >>> cal.step('20240101', 3)
    >>>
    >>> # 频率
    >>> cal.monthly.first('20240101', '20241231')    # 月初序列
    >>> cal.monthly.first.next('20240115')           # 下一个月初
    >>> cal.monthly.last('20240101', '20241231')     # 月末序列
    >>> cal.monthly.last.next('20240115')            # 下一个月末
    >>> cal.monthly.both('20240101', '20241231')     # 月初+月末
    >>>
    >>> # 期货
    >>> cal.futures.stock('20240115')
    >>> cal.futures.stock(all=True)
    >>> cal.futures.treasury()
    >>> cal.futures.contracts('20240115')
"""

from .core.trading_calendar import Calendar, CalendarError

__version__ = '2.0.0'
__author__ = 'liubola'

__all__ = [
    'Calendar',
    'CalendarError',
]
