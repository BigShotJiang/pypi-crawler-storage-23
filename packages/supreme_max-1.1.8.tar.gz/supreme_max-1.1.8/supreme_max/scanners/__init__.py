"""
Supreme 2 MAX Scanner Heads
74 independent security scanner implementations
"""

from supreme_max.scanners.base import (
    BaseScanner,
    ScannerRegistry,
    ScannerResult,
    ScannerIssue,
    Severity
)
from supreme_max.scanners.python_scanner import PythonScanner
from supreme_max.scanners.bash_scanner import BashScanner
from supreme_max.scanners.bat_scanner import BatScanner
from supreme_max.scanners.yaml_scanner import YAMLScanner
from supreme_max.scanners.docker_scanner import DockerScanner
from supreme_max.scanners.docker_compose_scanner import DockerComposeScanner
from supreme_max.scanners.markdown_scanner import MarkdownScanner
from supreme_max.scanners.javascript_scanner import JavaScriptScanner
from supreme_max.scanners.terraform_scanner import TerraformScanner
from supreme_max.scanners.go_scanner import GoScanner
from supreme_max.scanners.json_scanner import JSONScanner
from supreme_max.scanners.ruby_scanner import RubyScanner
from supreme_max.scanners.php_scanner import PHPScanner
from supreme_max.scanners.rust_scanner import RustScanner
from supreme_max.scanners.sql_scanner import SQLScanner
from supreme_max.scanners.css_scanner import CSSScanner
from supreme_max.scanners.html_scanner import HTMLScanner
from supreme_max.scanners.kotlin_scanner import KotlinScanner
from supreme_max.scanners.swift_scanner import SwiftScanner
from supreme_max.scanners.cpp_scanner import CppScanner
from supreme_max.scanners.java_scanner import JavaScanner
from supreme_max.scanners.typescript_scanner import TypeScriptScanner
from supreme_max.scanners.scala_scanner import ScalaScanner
from supreme_max.scanners.perl_scanner import PerlScanner
from supreme_max.scanners.powershell_scanner import PowerShellScanner
from supreme_max.scanners.r_scanner import RScanner
from supreme_max.scanners.ansible_scanner import AnsibleScanner
from supreme_max.scanners.kubernetes_scanner import KubernetesScanner
from supreme_max.scanners.toml_scanner import TOMLScanner
from supreme_max.scanners.xml_scanner import XMLScanner
from supreme_max.scanners.protobuf_scanner import ProtobufScanner
from supreme_max.scanners.graphql_scanner import GraphQLScanner
from supreme_max.scanners.solidity_scanner import SolidityScanner
from supreme_max.scanners.lua_scanner import LuaScanner
from supreme_max.scanners.elixir_scanner import ElixirScanner
from supreme_max.scanners.haskell_scanner import HaskellScanner
from supreme_max.scanners.clojure_scanner import ClojureScanner
from supreme_max.scanners.dart_scanner import DartScanner
from supreme_max.scanners.groovy_scanner import GroovyScanner
from supreme_max.scanners.vim_scanner import VimScanner
from supreme_max.scanners.cmake_scanner import CMakeScanner
from supreme_max.scanners.make_scanner import MakeScanner
from supreme_max.scanners.nginx_scanner import NginxScanner
from supreme_max.scanners.zig_scanner import ZigScanner
from supreme_max.scanners.env_scanner import EnvScanner
from supreme_max.scanners.mcp_config_scanner import MCPConfigScanner
from supreme_max.scanners.mcp_server_scanner import MCPServerScanner
from supreme_max.scanners.ai_context_scanner import AIContextScanner
from supreme_max.scanners.agent_memory_scanner import AgentMemoryScanner
from supreme_max.scanners.rag_security_scanner import RAGSecurityScanner
from supreme_max.scanners.a2a_scanner import A2AScanner
from supreme_max.scanners.prompt_leakage_scanner import PromptLeakageScanner
from supreme_max.scanners.tool_callback_scanner import ToolCallbackScanner
from supreme_max.scanners.agent_reflection_scanner import AgentReflectionScanner
from supreme_max.scanners.agent_planning_scanner import AgentPlanningScanner
from supreme_max.scanners.multi_agent_scanner import MultiAgentScanner
from supreme_max.scanners.owasp_llm_scanner import OWASPLLMScanner
from supreme_max.scanners.model_attack_scanner import ModelAttackScanner
from supreme_max.scanners.llmops_scanner import LLMOpsScanner
from supreme_max.scanners.vector_db_scanner import VectorDBScanner
from supreme_max.scanners.modelscan_scanner import ModelScanScanner
from supreme_max.scanners.garak_scanner import GarakScanner
from supreme_max.scanners.llm_guard_scanner import LLMGuardScanner
from supreme_max.scanners.react2shell_scanner import React2ShellScanner
from supreme_max.scanners.mcp_remote_rce_scanner import MCPRemoteRCEScanner
from supreme_max.scanners.docker_mcp_scanner import DockerMCPScanner
from supreme_max.scanners.post_quantum_scanner import PostQuantumScanner
from supreme_max.scanners.steganography_scanner import SteganographyScanner
from supreme_max.scanners.hyperparameter_scanner import HyperparameterScanner
from supreme_max.scanners.plugin_security_scanner import PluginSecurityScanner
from supreme_max.scanners.excessive_agency_scanner import ExcessiveAgencyScanner
from supreme_max.scanners.gitleaks_scanner import GitLeaksScanner
from supreme_max.scanners.semgrep_scanner import SemgrepScanner
from supreme_max.scanners.trivy_scanner import TrivyScanner

# Create global scanner registry
registry = ScannerRegistry()

# Register all available scanners
registry.register(PythonScanner())
registry.register(BashScanner())
registry.register(BatScanner())
registry.register(YAMLScanner())
registry.register(DockerScanner())
registry.register(DockerComposeScanner())
registry.register(MarkdownScanner())
registry.register(JavaScriptScanner())
registry.register(TerraformScanner())
registry.register(GoScanner())
registry.register(JSONScanner())
registry.register(RubyScanner())
registry.register(PHPScanner())
registry.register(RustScanner())
registry.register(SQLScanner())
registry.register(CSSScanner())
registry.register(HTMLScanner())
registry.register(KotlinScanner())
registry.register(SwiftScanner())
registry.register(CppScanner())
registry.register(JavaScanner())
registry.register(TypeScriptScanner())
registry.register(ScalaScanner())
registry.register(PerlScanner())
registry.register(PowerShellScanner())
registry.register(RScanner())
registry.register(AnsibleScanner())
registry.register(KubernetesScanner())
registry.register(TOMLScanner())
registry.register(XMLScanner())
registry.register(ProtobufScanner())
registry.register(GraphQLScanner())
registry.register(SolidityScanner())
registry.register(LuaScanner())
registry.register(ElixirScanner())
registry.register(HaskellScanner())
registry.register(ClojureScanner())
registry.register(DartScanner())
registry.register(GroovyScanner())
registry.register(VimScanner())
registry.register(CMakeScanner())
registry.register(MakeScanner())
registry.register(NginxScanner())
registry.register(ZigScanner())
registry.register(EnvScanner())
registry.register(MCPConfigScanner())
registry.register(MCPServerScanner())
registry.register(AIContextScanner())
registry.register(AgentMemoryScanner())
registry.register(RAGSecurityScanner())
registry.register(A2AScanner())
registry.register(PromptLeakageScanner())
registry.register(ToolCallbackScanner())
registry.register(AgentReflectionScanner())
registry.register(AgentPlanningScanner())
registry.register(MultiAgentScanner())
registry.register(OWASPLLMScanner())
registry.register(ModelAttackScanner())
registry.register(LLMOpsScanner())
registry.register(VectorDBScanner())
registry.register(ModelScanScanner())
registry.register(GarakScanner())
registry.register(LLMGuardScanner())
registry.register(React2ShellScanner())
registry.register(MCPRemoteRCEScanner())
registry.register(DockerMCPScanner())
registry.register(PostQuantumScanner())
registry.register(SteganographyScanner())
registry.register(HyperparameterScanner())
registry.register(PluginSecurityScanner())
registry.register(ExcessiveAgencyScanner())
registry.register(GitLeaksScanner())
registry.register(SemgrepScanner())
registry.register(TrivyScanner())

__all__ = [
    'BaseScanner',
    'ScannerRegistry',
    'ScannerResult',
    'ScannerIssue',
    'Severity',
    'PythonScanner',
    'BashScanner',
    'BatScanner',
    'YAMLScanner',
    'DockerScanner',
    'DockerComposeScanner',
    'MarkdownScanner',
    'JavaScriptScanner',
    'TerraformScanner',
    'GoScanner',
    'JSONScanner',
    'RubyScanner',
    'PHPScanner',
    'RustScanner',
    'SQLScanner',
    'CSSScanner',
    'HTMLScanner',
    'KotlinScanner',
    'SwiftScanner',
    'CppScanner',
    'JavaScanner',
    'TypeScriptScanner',
    'ScalaScanner',
    'PerlScanner',
    'PowerShellScanner',
    'RScanner',
    'AnsibleScanner',
    'KubernetesScanner',
    'TOMLScanner',
    'XMLScanner',
    'ProtobufScanner',
    'GraphQLScanner',
    'SolidityScanner',
    'LuaScanner',
    'ElixirScanner',
    'HaskellScanner',
    'ClojureScanner',
    'DartScanner',
    'GroovyScanner',
    'VimScanner',
    'CMakeScanner',
    'MakeScanner',
    'NginxScanner',
    'ZigScanner',
    'EnvScanner',
    'MCPConfigScanner',
    'MCPServerScanner',
    'AIContextScanner',
    'AgentMemoryScanner',
    'RAGSecurityScanner',
    'A2AScanner',
    'PromptLeakageScanner',
    'ToolCallbackScanner',
    'AgentReflectionScanner',
    'AgentPlanningScanner',
    'MultiAgentScanner',
    'OWASPLLMScanner',
    'ModelAttackScanner',
    'LLMOpsScanner',
    'VectorDBScanner',
    'ModelScanScanner',
    'GarakScanner',
    'LLMGuardScanner',
    'React2ShellScanner',
    'MCPRemoteRCEScanner',
    'DockerMCPScanner',
    'PostQuantumScanner',
    'SteganographyScanner',
    'HyperparameterScanner',
    'PluginSecurityScanner',
    'ExcessiveAgencyScanner',
    'GitLeaksScanner',
    'SemgrepScanner',
    'TrivyScanner',
    'registry',
]
