"""
Supreme 2 MAX Core Module
Core scanning engine, parallel execution, and reporting
"""

from supreme_max.core.parallel import SupremeMaxParallelScanner
from supreme_max.core.reporter import SupremeMaxReportGenerator

__all__ = ["SupremeMaxParallelScanner", "SupremeMaxReportGenerator"]
