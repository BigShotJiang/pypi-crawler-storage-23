"""
Graph Metadata Management

Gestiona la metadata de los grafos, incluyendo información sobre
la rama Git, commit SHA, y estado de sincronización.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class GraphMetadata:
    """
    Gestiona la metadata de los grafos de código.
    
    La metadata incluye:
    - git_branch: Rama de Git actual
    - git_commit: SHA del commit actual
    - last_updated: Última vez que se actualizó el grafo
    - last_sync_backend: Última vez que se sincronizó con el backend
    - graph_version: Versión del formato del grafo
    - total_files: Número total de archivos en el grafo
    - supported_languages: Lenguajes soportados
    """
    
    def __init__(self, project_root: str):
        """
        Inicializa el gestor de metadata.
        
        Args:
            project_root: Ruta raíz del proyecto
        """
        self.project_root = Path(project_root)
        self.metadata_file = self.project_root / ".hacki" / "graph_metadata.json"
        self._metadata: Optional[Dict[str, Any]] = None
    
    def load(self) -> Dict[str, Any]:
        """
        Carga la metadata desde el archivo.
        
        Returns:
            Diccionario con la metadata, o metadata por defecto si no existe
        """
        if self._metadata is not None:
            return self._metadata
        
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, "r", encoding="utf-8") as f:
                    self._metadata = json.load(f)
                logger.debug(f"Metadata cargada desde {self.metadata_file}")
                return self._metadata
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Error cargando metadata: {e}. Usando valores por defecto.")
        
        # Metadata por defecto
        self._metadata = self._default_metadata()
        return self._metadata
    
    def save(self) -> bool:
        """
        Guarda la metadata en el archivo.
        
        Returns:
            True si se guardó correctamente, False en caso contrario
        """
        if self._metadata is None:
            self._metadata = self._default_metadata()
        
        try:
            # Asegurar que el directorio existe
            self.metadata_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Actualizar timestamp
            self._metadata["last_updated"] = datetime.utcnow().isoformat()
            
            with open(self.metadata_file, "w", encoding="utf-8") as f:
                json.dump(self._metadata, f, indent=2)
            
            logger.debug(f"Metadata guardada en {self.metadata_file}")
            return True
        except IOError as e:
            logger.error(f"Error guardando metadata: {e}")
            return False
    
    def update_branch(self, branch: str) -> bool:
        """
        Actualiza la rama de Git en la metadata.
        
        Args:
            branch: Nombre de la rama de Git
            
        Returns:
            True si se actualizó correctamente
        """
        if self._metadata is None:
            self.load()
        
        old_branch = self._metadata.get("git_branch")
        if old_branch != branch:
            self._metadata["git_branch"] = branch
            logger.info(f"Rama actualizada: {old_branch} -> {branch}")
            return self.save()
        return True
    
    def update_commit(self, commit_sha: str) -> bool:
        """
        Actualiza el SHA del commit en la metadata.
        
        Args:
            commit_sha: SHA del commit de Git
            
        Returns:
            True si se actualizó correctamente
        """
        if self._metadata is None:
            self.load()
        
        old_commit = self._metadata.get("git_commit")
        if old_commit != commit_sha:
            self._metadata["git_commit"] = commit_sha
            logger.info(f"Commit actualizado: {old_commit} -> {commit_sha}")
            return self.save()
        return True
    
    def update_sync_backend(self, sync_time: Optional[str] = None) -> bool:
        """
        Actualiza el timestamp de última sincronización con el backend.
        
        Args:
            sync_time: Timestamp ISO (opcional, usa tiempo actual si no se proporciona)
            
        Returns:
            True si se actualizó correctamente
        """
        if self._metadata is None:
            self.load()
        
        if sync_time is None:
            sync_time = datetime.utcnow().isoformat()
        
        self._metadata["last_sync_backend"] = sync_time
        logger.debug(f"Sincronización con backend actualizada: {sync_time}")
        return self.save()
    
    def update_total_files(self, total_files: int) -> bool:
        """
        Actualiza el número total de archivos en el grafo.
        
        Args:
            total_files: Número total de archivos
            
        Returns:
            True si se actualizó correctamente
        """
        if self._metadata is None:
            self.load()
        
        self._metadata["total_files"] = total_files
        return self.save()
    
    def update_supported_languages(self, languages: list[str]) -> bool:
        """
        Actualiza la lista de lenguajes soportados.
        
        Args:
            languages: Lista de nombres de lenguajes
            
        Returns:
            True si se actualizó correctamente
        """
        if self._metadata is None:
            self.load()
        
        self._metadata["supported_languages"] = languages
        return self.save()
    
    def get_branch(self) -> Optional[str]:
        """
        Obtiene la rama de Git actual.
        
        Returns:
            Nombre de la rama o None si no está configurada
        """
        if self._metadata is None:
            self.load()
        return self._metadata.get("git_branch")
    
    def get_commit(self) -> Optional[str]:
        """
        Obtiene el SHA del commit actual.
        
        Returns:
            SHA del commit o None si no está configurado
        """
        if self._metadata is None:
            self.load()
        return self._metadata.get("git_commit")
    
    def is_branch_changed(self, current_branch: str) -> bool:
        """
        Verifica si la rama ha cambiado desde la última actualización.
        
        Args:
            current_branch: Rama actual de Git
            
        Returns:
            True si la rama ha cambiado
        """
        stored_branch = self.get_branch()
        return stored_branch is not None and stored_branch != current_branch
    
    def validate_format(self) -> bool:
        """
        Valida que el formato de la metadata sea correcto.
        
        Returns:
            True si el formato es válido
        """
        if self._metadata is None:
            self.load()
        
        required_fields = ["git_branch", "git_commit", "last_updated"]
        for field in required_fields:
            if field not in self._metadata:
                logger.warning(f"Campo requerido faltante en metadata: {field}")
                return False
        
        return True
    
    def _default_metadata(self) -> Dict[str, Any]:
        """
        Retorna metadata por defecto.
        
        Returns:
            Diccionario con metadata por defecto
        """
        return {
            "git_branch": None,
            "git_commit": None,
            "last_updated": datetime.utcnow().isoformat(),
            "last_sync_backend": None,
            "graph_version": "1.0",
            "total_files": 0,
            "supported_languages": []
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Retorna la metadata como diccionario.
        
        Returns:
            Diccionario con toda la metadata
        """
        if self._metadata is None:
            self.load()
        return self._metadata.copy()

