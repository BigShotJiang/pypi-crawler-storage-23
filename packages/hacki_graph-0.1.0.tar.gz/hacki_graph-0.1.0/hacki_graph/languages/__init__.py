"""
Language Specifications (Nuevo Sistema)

Este paquete contiene el sistema nuevo de especificaciones de lenguajes.
Para compatibilidad, re-exporta funciones del sistema language_specs.
"""

# Definir LanguageConfig localmente para evitar import circular
from dataclasses import dataclass
from typing import Set, List

@dataclass
class LanguageConfig:
    """Configuración de un lenguaje soportado."""
    name: str
    extensions: Set[str]
    tree_sitter_name: str
    import_patterns: List[str]
    function_patterns: List[str]
    class_patterns: List[str]
    call_patterns: List[str]

# Crear un registry simple para compatibilidad
class SimpleLanguageRegistry:
    def __init__(self):
        # Usar LanguageConfig del sistema original
        python_config = LanguageConfig(
            name="python",
            extensions={".py", ".pyx", ".pyi"},
            tree_sitter_name="python",
            import_patterns=[
                "(import_statement) @import",
                "(import_from_statement) @import",
                "(future_import_statement) @import"
            ],
            function_patterns=[
                "(function_definition) @function",
                "(async_function_definition) @function"
            ],
            class_patterns=[
                "(class_definition) @class"
            ],
            call_patterns=[
                "(call) @call"
            ]
        )
        
        self._registry = {
            '.py': python_config,
            '.pyw': python_config,
            '.pyi': python_config
        }
    
    def get_language_by_file(self, file_path):
        """Obtiene la especificación de lenguaje por archivo."""
        from pathlib import Path
        extension = Path(file_path).suffix.lower()
        return self._registry.get(extension)
    
    def register_language(self, extensions, spec):
        """Registra un lenguaje."""
        for ext in extensions:
            self._registry[ext.lower()] = spec
    
    def get_supported_extensions(self):
        """Obtiene el conjunto de extensiones soportadas."""
        return set(self._registry.keys())
    
    def is_file_supported(self, file_path):
        """Verifica si un archivo está soportado."""
        from pathlib import Path
        extension = Path(file_path).suffix.lower()
        return extension in self._registry
    
    def get_supported_languages(self):
        """Obtiene la lista de lenguajes soportados."""
        return list(set(type(spec).__name__ for spec in self._registry.values()))

_registry_instance = None

def get_language_registry():
    """Devuelve la instancia del registry."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = SimpleLanguageRegistry()
    return _registry_instance

def register_language(extensions, spec):
    """Registra un lenguaje en el registry."""
    registry = get_language_registry()
    registry.register_language(extensions, spec)

__all__ = [
    'LanguageConfig',
    'SimpleLanguageRegistry',
    'LanguageRegistry',
    'get_language_registry',
    'register_language'
]

# Alias para compatibilidad
LanguageRegistry = SimpleLanguageRegistry
