"""
hacki-graph — Code Graph Analysis Package

Implements a Tree-sitter-based code analysis system that builds and maintains
a dependency graph of source code.

Main features:
- Full graph construction
- Incremental updates based on file hashes
- Multi-language support
- JSON export for LLM analysis

Usage:
    from hacki_graph import GraphManager

    manager = GraphManager()
    graph = manager.build_full_graph()
    manager.save_graph(graph)
"""

from .graph_builder import GraphBuilder
from .incremental import IncrementalUpdater
from .file_hashing import FileHashManager
from .tree_sitter_loader import TreeSitterLoader
from .languages import LanguageRegistry, get_language_registry
from .language_specs.base import LanguageSpec
from .manager import EnhancedGraphManager, StaticAnalysisManager
from .metadata import GraphMetadata
from .sync import SnapshotSync
from .validator import GraphValidator
from .orchestrator import GraphOrchestrator

__all__ = [
    'GraphBuilder',
    'IncrementalUpdater', 
    'FileHashManager',
    'TreeSitterLoader',
    'LanguageSpec',
    'LanguageRegistry',
    'get_language_registry',
    'EnhancedGraphManager',
    'StaticAnalysisManager',
    'GraphMetadata',
    'SnapshotSync',
    'GraphValidator',
    'GraphOrchestrator',
]

# Alias para compatibilidad - usar EnhancedGraphManager como GraphManager por defecto
GraphManager = EnhancedGraphManager

