"""
File Hashing Module

Gestiona el cálculo y almacenamiento de hashes SHA-1 de archivos
para detectar cambios incrementalmente en el grafo de código.
"""

import os
import json
import hashlib
import logging
from typing import Dict, Set, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

class FileHashManager:
    """
    Gestiona los hashes de archivos para detección incremental de cambios.
    """
    
    def __init__(self, project_root: str = "."):
        self.project_root = Path(project_root).resolve()
        self.hacki_dir = self.project_root / ".hacki"
        self.hashes_file = self.hacki_dir / "hashes.json"
        self._current_hashes: Dict[str, str] = {}
        self._stored_hashes: Dict[str, str] = {}
    
    def ensure_hacki_dir(self) -> None:
        """Asegura que el directorio .hacki existe."""
        self.hacki_dir.mkdir(exist_ok=True)
    
    def calculate_file_hash(self, file_path: str) -> Optional[str]:
        """
        Calcula el hash SHA-1 de un archivo.
        
        Args:
            file_path: Ruta del archivo
            
        Returns:
            Hash SHA-1 del archivo o None si hay error
        """
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
                return hashlib.sha1(content).hexdigest()
        except Exception as e:
            logger.error(f"Error calculando hash de {file_path}: {e}")
            return None
    
    def calculate_sha1(self, file_path) -> Optional[str]:
        """
        Alias para calculate_file_hash() para compatibilidad.
        Acepta Path o str.
        
        Args:
            file_path: Ruta del archivo (Path o str)
            
        Returns:
            Hash SHA-1 del archivo o None si hay error
        """
        # Convertir Path a str si es necesario
        file_path_str = str(file_path) if hasattr(file_path, '__str__') else file_path
        return self.calculate_file_hash(file_path_str)
    
    def calculate_directory_hashes(self, directory: str, extensions: Set[str]) -> Dict[str, str]:
        """
        Calcula hashes para todos los archivos soportados en un directorio.
        
        Args:
            directory: Directorio a escanear
            extensions: Extensiones de archivo a incluir
            
        Returns:
            Diccionario con rutas relativas como claves y hashes como valores
        """
        hashes = {}
        directory_path = Path(directory).resolve()
        
        # Patrones a ignorar
        ignore_patterns = {
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.env', 'dist', 'build', '.hacki', '.pytest_cache',
            '.mypy_cache', '.tox', 'coverage'
        }
        
        for file_path in directory_path.rglob('*'):
            # Ignorar directorios y archivos en patrones ignorados
            if any(part in ignore_patterns for part in file_path.parts):
                continue
                
            # Solo procesar archivos con extensiones soportadas
            if file_path.is_file() and file_path.suffix.lower() in extensions:
                try:
                    relative_path = str(file_path.relative_to(self.project_root))
                    file_hash = self.calculate_file_hash(str(file_path))
                    if file_hash:
                        hashes[relative_path] = file_hash
                except ValueError:
                    # El archivo está fuera del proyecto root
                    continue
                except Exception as e:
                    logger.warning(f"Error procesando {file_path}: {e}")
                    continue
        
        return hashes
    
    def load_stored_hashes(self) -> Dict[str, str]:
        """
        Carga los hashes almacenados desde .hacki/hashes.json.
        
        Returns:
            Diccionario con los hashes almacenados
        """
        if not self.hashes_file.exists():
            return {}
        
        try:
            with open(self.hashes_file, 'r', encoding='utf-8') as f:
                self._stored_hashes = json.load(f)
                return self._stored_hashes
        except Exception as e:
            logger.error(f"Error cargando hashes almacenados: {e}")
            return {}
    
    def load_hashes(self) -> Dict[str, str]:
        """
        Alias para load_stored_hashes() para compatibilidad.
        
        Returns:
            Diccionario con los hashes almacenados
        """
        return self.load_stored_hashes()
    
    def save_hashes(self, hashes: Dict[str, str]) -> bool:
        """
        Guarda los hashes en .hacki/hashes.json.
        
        Args:
            hashes: Diccionario de hashes a guardar
            
        Returns:
            bool: True si se guardó correctamente
        """
        try:
            self.ensure_hacki_dir()
            with open(self.hashes_file, 'w', encoding='utf-8') as f:
                json.dump(hashes, f, indent=2, sort_keys=True)
            self._stored_hashes = hashes.copy()
            logger.info(f"Hashes guardados para {len(hashes)} archivos")
            return True
        except Exception as e:
            logger.error(f"Error guardando hashes: {e}")
            return False
    
    def detect_changes(self, current_hashes: Dict[str, str]) -> Tuple[Set[str], Set[str], Set[str]]:
        """
        Detecta cambios comparando hashes actuales con los almacenados.
        
        Args:
            current_hashes: Hashes actuales de los archivos
            
        Returns:
            Tupla con (archivos_nuevos, archivos_modificados, archivos_eliminados)
        """
        stored_hashes = self.load_stored_hashes()
        
        current_files = set(current_hashes.keys())
        stored_files = set(stored_hashes.keys())
        
        # Archivos nuevos: están en current pero no en stored
        new_files = current_files - stored_files
        
        # Archivos eliminados: están en stored pero no en current
        deleted_files = stored_files - current_files
        
        # Archivos modificados: están en ambos pero con hash diferente
        modified_files = set()
        for file_path in current_files & stored_files:
            if current_hashes[file_path] != stored_hashes[file_path]:
                modified_files.add(file_path)
        
        logger.info(
            f"Cambios detectados: {len(new_files)} nuevos, "
            f"{len(modified_files)} modificados, {len(deleted_files)} eliminados"
        )
        
        return new_files, modified_files, deleted_files
    
    def get_changed_files(self, extensions: Set[str]) -> Tuple[Set[str], Set[str], Set[str]]:
        """
        Obtiene los archivos que han cambiado desde la última actualización.
        
        Args:
            extensions: Extensiones de archivo a considerar
            
        Returns:
            Tupla con (archivos_nuevos, archivos_modificados, archivos_eliminados)
        """
        current_hashes = self.calculate_directory_hashes(str(self.project_root), extensions)
        return self.detect_changes(current_hashes)
    
    def update_hashes(self, extensions: Set[str]) -> bool:
        """
        Actualiza los hashes almacenados con los valores actuales.
        
        Args:
            extensions: Extensiones de archivo a considerar
            
        Returns:
            bool: True si se actualizó correctamente
        """
        current_hashes = self.calculate_directory_hashes(str(self.project_root), extensions)
        return self.save_hashes(current_hashes)
    
    def get_file_hash(self, file_path: str) -> Optional[str]:
        """
        Obtiene el hash almacenado de un archivo específico.
        
        Args:
            file_path: Ruta relativa del archivo
            
        Returns:
            Hash del archivo o None si no existe
        """
        if not self._stored_hashes:
            self.load_stored_hashes()
        return self._stored_hashes.get(file_path)
    
    def is_file_changed(self, file_path: str) -> bool:
        """
        Verifica si un archivo ha cambiado desde la última actualización.
        
        Args:
            file_path: Ruta del archivo a verificar
            
        Returns:
            bool: True si el archivo ha cambiado
        """
        try:
            # Convertir a ruta relativa si es necesario
            file_path_obj = Path(file_path)
            if file_path_obj.is_absolute():
                relative_path = str(file_path_obj.relative_to(self.project_root))
            else:
                relative_path = file_path
            
            stored_hash = self.get_file_hash(relative_path)
            if stored_hash is None:
                # Archivo nuevo
                return True
            
            current_hash = self.calculate_file_hash(str(self.project_root / relative_path))
            return current_hash != stored_hash
            
        except Exception as e:
            logger.error(f"Error verificando cambios en {file_path}: {e}")
            return True  # Asumir que cambió si hay error
    
    def clear_hashes(self) -> bool:
        """
        Elimina el archivo de hashes almacenados.
        
        Returns:
            bool: True si se eliminó correctamente
        """
        try:
            if self.hashes_file.exists():
                self.hashes_file.unlink()
            self._stored_hashes.clear()
            logger.info("Hashes almacenados eliminados")
            return True
        except Exception as e:
            logger.error(f"Error eliminando hashes: {e}")
            return False
