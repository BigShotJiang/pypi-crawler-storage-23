"""
Graph Builder Module

Construye el grafo de código completo analizando archivos fuente
con Tree-sitter y extrayendo nodos y relaciones importantes.
"""

import os
import json
import logging
import re
from typing import Dict, List, Set, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
from datetime import datetime

from .tree_sitter_loader import get_tree_sitter_loader
from .languages import get_language_registry
from .file_hashing import FileHashManager

logger = logging.getLogger(__name__)

# Try to import Rich for progress bars, but make it optional
try:
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.console import Console
    RICH_AVAILABLE = True
    rich_console = Console()
except ImportError:
    RICH_AVAILABLE = False
    rich_console = None

@dataclass
class GraphNode:
    """Representa un nodo en el grafo de código."""
    id: str
    type: str  # 'function', 'class', 'import', 'file'
    name: str
    file_path: str
    line_start: int
    line_end: int
    metadata: Dict[str, Any]

@dataclass
class GraphEdge:
    """Representa una relación en el grafo de código."""
    id: str
    source: str  # ID del nodo origen
    target: str  # ID del nodo destino
    type: str    # 'calls', 'imports', 'defines', 'contains'
    metadata: Dict[str, Any]

class GraphBuilder:
    """
    Construye el grafo completo de código analizando archivos fuente.
    """
    
    def __init__(self, project_root: str = "."):
        self.project_root = Path(project_root).resolve()
        self.hacki_dir = self.project_root / ".hacki"
        self.graph_file = self.hacki_dir / "graph.json"
        
        self.tree_sitter_loader = get_tree_sitter_loader()
        self.language_registry = get_language_registry()
        self.hash_manager = FileHashManager(str(project_root))
        
        # Contadores para IDs únicos
        self._node_counter = 0
        self._edge_counter = 0
        
        # Cache de nodos y edges
        self._nodes: Dict[str, GraphNode] = {}
        self._edges: Dict[str, GraphEdge] = {}
        
        # Índices para resolución de llamadas
        self._function_index: Dict[str, List[GraphNode]] = {}  # name -> [functions]
        self._function_by_file: Dict[str, List[GraphNode]] = {}  # file_path -> [functions]
        self._class_index: Dict[str, List[GraphNode]] = {}  # name -> [classes]
        self._import_index: Dict[str, Dict[str, str]] = {}  # file_path -> {imported_name -> source_file}
        self._class_containment: Dict[str, str] = {}  # function_id -> class_id
    
    def ensure_hacki_dir(self) -> None:
        """Asegura que el directorio .hacki existe."""
        self.hacki_dir.mkdir(exist_ok=True)
    
    def _generate_node_id(self) -> str:
        """Genera un ID único para un nodo."""
        self._node_counter += 1
        return f"node_{self._node_counter}"
    
    def _generate_edge_id(self) -> str:
        """Genera un ID único para una edge."""
        self._edge_counter += 1
        return f"edge_{self._edge_counter}"
    
    def _create_file_node(self, file_path: str) -> GraphNode:
        """
        Crea un nodo para un archivo.
        
        Args:
            file_path: Ruta relativa del archivo
            
        Returns:
            Nodo del archivo
        """
        return GraphNode(
            id=self._generate_node_id(),
            type="file",
            name=Path(file_path).name,
            file_path=file_path,
            line_start=1,
            line_end=1,
            metadata={"full_path": file_path}
        )
    
    def _extract_node_info(self, node: Any, file_path: str) -> Optional[Tuple[str, str, int, int]]:
        """
        Extrae información básica de un nodo Tree-sitter.
        
        Args:
            node: Nodo de Tree-sitter
            file_path: Ruta del archivo
            
        Returns:
            Tupla con (tipo, nombre, línea_inicio, línea_fin) o None
        """
        try:
            node_type = node.type
            start_line = node.start_point[0] + 1
            end_line = node.end_point[0] + 1
            
            # Intentar extraer el nombre del nodo
            name = ""
            if hasattr(node, 'children') and node.children:
                for child in node.children:
                    if child.type == "identifier" or child.type == "name":
                        name = child.text.decode('utf-8') if hasattr(child, 'text') else ""
                        break
            
            if not name:
                name = f"{node_type}_{start_line}"
            
            return node_type, name, start_line, end_line
            
        except Exception as e:
            logger.debug(f"Error extrayendo info del nodo en {file_path}: {e}")
            return None
    
    def _query_tree_sitter(self, tree: Any, query_string: str, language: Any) -> List[Any]:
        """
        Ejecuta una query en un árbol Tree-sitter.
        
        Args:
            tree: Árbol de Tree-sitter
            query_string: Query a ejecutar
            language: Gramática del lenguaje (objeto Language de tree-sitter)
            
        Returns:
            Lista de matches encontrados
        """
        try:
            # Usar language.query() que es el método correcto en tree-sitter
            query = language.query(query_string)
            captures = query.captures(tree.root_node)
            return captures
        except AttributeError:
            # Fallback: intentar con tree_sitter.Query si language.query() no existe
            try:
                import tree_sitter
                query = tree_sitter.Query(language, query_string)
                captures = query.captures(tree.root_node)
                return captures
            except Exception as e:
                logger.debug(f"Error ejecutando query (fallback): {e}")
                return []
        except Exception as e:
            logger.debug(f"Error ejecutando query: {e}")
            return []
    
    def _parse_file_nodes(self, file_path: str, tree: Any, language_config: Any) -> Tuple[List[GraphNode], List[GraphEdge]]:
        """
        Parsea un archivo y extrae nodos y edges.
        
        Args:
            file_path: Ruta relativa del archivo
            tree: Árbol Tree-sitter del archivo
            language_config: Configuración del lenguaje
            
        Returns:
            Tupla con (nodos, edges) encontrados
        """
        nodes = []
        edges = []
        
        # Crear nodo del archivo
        file_node = self._create_file_node(file_path)
        nodes.append(file_node)
        
        # Obtener la gramática del lenguaje
        language = self.tree_sitter_loader.get_language(language_config.tree_sitter_name)
        if not language:
            logger.warning(f"No se pudo obtener gramática para {language_config.name}")
            return nodes, edges
        
        # Extraer imports
        for pattern in language_config.import_patterns:
            try:
                captures = self._query_tree_sitter(tree, pattern, language)
                for node, capture_name in captures:
                    node_info = self._extract_node_info(node, file_path)
                    if node_info:
                        node_type, name, start_line, end_line = node_info
                        import_node = GraphNode(
                            id=self._generate_node_id(),
                            type="import",
                            name=name,
                            file_path=file_path,
                            line_start=start_line,
                            line_end=end_line,
                            metadata={"import_text": node.text.decode('utf-8') if hasattr(node, 'text') else ""}
                        )
                        nodes.append(import_node)
                        
                        # Edge: archivo contiene import
                        edge = GraphEdge(
                            id=self._generate_edge_id(),
                            source=file_node.id,
                            target=import_node.id,
                            type="contains",
                            metadata={}
                        )
                        edges.append(edge)
            except Exception as e:
                logger.debug(f"Error parseando imports en {file_path}: {e}")
        
        # Extraer funciones
        for pattern in language_config.function_patterns:
            try:
                captures = self._query_tree_sitter(tree, pattern, language)
                for node, capture_name in captures:
                    node_info = self._extract_node_info(node, file_path)
                    if node_info:
                        node_type, name, start_line, end_line = node_info
                        # Extraer metadata completa
                        function_metadata = self._extract_function_metadata(node, file_path, language_config, tree)
                        function_node = GraphNode(
                            id=self._generate_node_id(),
                            type="function",
                            name=name,
                            file_path=file_path,
                            line_start=start_line,
                            line_end=end_line,
                            metadata=function_metadata
                        )
                        nodes.append(function_node)
                        
                        # Edge: archivo contiene función
                        edge = GraphEdge(
                            id=self._generate_edge_id(),
                            source=file_node.id,
                            target=function_node.id,
                            type="contains",
                            metadata={}
                        )
                        edges.append(edge)
            except Exception as e:
                logger.debug(f"Error parseando funciones en {file_path}: {e}")
        
        # Extraer clases
        for pattern in language_config.class_patterns:
            try:
                captures = self._query_tree_sitter(tree, pattern, language)
                for node, capture_name in captures:
                    node_info = self._extract_node_info(node, file_path)
                    if node_info:
                        node_type, name, start_line, end_line = node_info
                        class_node = GraphNode(
                            id=self._generate_node_id(),
                            type="class",
                            name=name,
                            file_path=file_path,
                            line_start=start_line,
                            line_end=end_line,
                            metadata={"definition": node.text.decode('utf-8')[:200] if hasattr(node, 'text') else ""}
                        )
                        nodes.append(class_node)
                        
                        # Edge: archivo contiene clase
                        edge = GraphEdge(
                            id=self._generate_edge_id(),
                            source=file_node.id,
                            target=class_node.id,
                            type="contains",
                            metadata={}
                        )
                        edges.append(edge)
            except Exception as e:
                logger.debug(f"Error parseando clases en {file_path}: {e}")
        
        # Extraer llamadas a funciones
        for pattern in language_config.call_patterns:
            try:
                captures = self._query_tree_sitter(tree, pattern, language)
                for node, capture_name in captures:
                    node_info = self._extract_node_info(node, file_path)
                    if node_info:
                        node_type, name, start_line, end_line = node_info
                        # Extraer metadata completa
                        call_metadata = self._extract_call_metadata(node, file_path, language_config)
                        call_node = GraphNode(
                            id=self._generate_node_id(),
                            type="call",
                            name=name,
                            file_path=file_path,
                            line_start=start_line,
                            line_end=end_line,
                            metadata=call_metadata
                        )
                        nodes.append(call_node)
                        
                        # Edge: archivo contiene llamada
                        edge = GraphEdge(
                            id=self._generate_edge_id(),
                            source=file_node.id,
                            target=call_node.id,
                            type="contains",
                            metadata={}
                        )
                        edges.append(edge)
            except Exception as e:
                logger.debug(f"Error parseando llamadas en {file_path}: {e}")
        
        return nodes, edges
    
    def _extract_function_metadata(self, node: Any, file_path: str, language_config: Any, tree: Any) -> Dict[str, Any]:
        """
        Extrae metadata completa de una función.
        
        Args:
            node: Nodo Tree-sitter de la función
            file_path: Ruta del archivo
            language_config: Configuración del lenguaje
            tree: Árbol Tree-sitter completo
            
        Returns:
            Dict con metadata completa de la función
        """
        metadata = {
            "signature": node.text.decode('utf-8') if hasattr(node, 'text') else "",
            "parameters": [],
            "return_type": None,
            "is_async": False,
            "is_class_method": False,
            "class_name": None,
            "visibility": "public"
        }
        
        try:
            # Detectar si es async
            if language_config.name == "python":
                metadata["is_async"] = node.type == "async_function_definition"
                
                # Extraer parámetros
                for child in node.children:
                    if child.type == "parameters":
                        for param_child in child.children:
                            if param_child.type == "identifier":
                                param_name = param_child.text.decode('utf-8') if hasattr(param_child, 'text') else ""
                                if param_name and param_name not in ["self", "cls"]:
                                    metadata["parameters"].append(param_name)
                            elif param_child.type == "typed_parameter":
                                # Parámetro con tipo: name: type
                                for typed_child in param_child.children:
                                    if typed_child.type == "identifier":
                                        param_name = typed_child.text.decode('utf-8') if hasattr(typed_child, 'text') else ""
                                        if param_name and param_name not in ["self", "cls"]:
                                            metadata["parameters"].append(param_name)
                                        break
                
                # Extraer return type
                for child in node.children:
                    if child.type == "type":
                        metadata["return_type"] = child.text.decode('utf-8') if hasattr(child, 'text') else None
                        break
                    elif child.type == "->":
                        # Buscar el siguiente nodo que sea el tipo
                        idx = node.children.index(child)
                        if idx + 1 < len(node.children):
                            next_child = node.children[idx + 1]
                            if next_child.type in ["type", "identifier"]:
                                metadata["return_type"] = next_child.text.decode('utf-8') if hasattr(next_child, 'text') else None
                
                # Detectar si es método de clase
                # Buscar si hay una clase que contenga esta función
                current = node.parent
                while current:
                    if current.type == "class_definition":
                        for class_child in current.children:
                            if class_child.type == "identifier":
                                metadata["class_name"] = class_child.text.decode('utf-8') if hasattr(class_child, 'text') else None
                                metadata["is_class_method"] = True
                                break
                        break
                    current = current.parent
                
                # Detectar visibilidad (Python usa _ para privado)
                if node.type == "function_definition" or node.type == "async_function_definition":
                    for child in node.children:
                        if child.type == "identifier":
                            func_name = child.text.decode('utf-8') if hasattr(child, 'text') else ""
                            if func_name.startswith("_"):
                                metadata["visibility"] = "private" if not func_name.startswith("__") else "protected"
                            break
            
            elif language_config.name in ["javascript", "typescript"]:
                # Similar lógica para JS/TS
                if node.type == "method_definition":
                    metadata["is_class_method"] = True
                    # Buscar clase contenedora
                    current = node.parent
                    while current:
                        if current.type == "class_declaration":
                            for class_child in current.children:
                                if class_child.type == "identifier" or class_child.type == "property_identifier":
                                    metadata["class_name"] = class_child.text.decode('utf-8') if hasattr(class_child, 'text') else None
                                    break
                            break
                        current = current.parent
                
                # Extraer parámetros
                for child in node.children:
                    if child.type == "formal_parameters":
                        for param_child in child.children:
                            if param_child.type == "identifier":
                                param_name = param_child.text.decode('utf-8') if hasattr(param_child, 'text') else ""
                                if param_name:
                                    metadata["parameters"].append(param_name)
            
            elif language_config.name == "java":
                # Java tiene modificadores de visibilidad explícitos
                for child in node.children:
                    if child.type == "modifiers":
                        for mod_child in child.children:
                            mod_text = mod_child.text.decode('utf-8') if hasattr(mod_child, 'text') else ""
                            if "private" in mod_text:
                                metadata["visibility"] = "private"
                            elif "protected" in mod_text:
                                metadata["visibility"] = "protected"
                            elif "public" in mod_text:
                                metadata["visibility"] = "public"
                
                # Extraer parámetros
                for child in node.children:
                    if child.type == "formal_parameters":
                        for param_child in child.children:
                            if param_child.type == "identifier":
                                param_name = param_child.text.decode('utf-8') if hasattr(param_child, 'text') else ""
                                if param_name:
                                    metadata["parameters"].append(param_name)
        
        except Exception as e:
            logger.debug(f"Error extrayendo metadata de función en {file_path}: {e}")
        
        return metadata
    
    def _extract_call_metadata(self, node: Any, file_path: str, language_config: Any) -> Dict[str, Any]:
        """
        Extrae metadata completa de una llamada.
        
        Args:
            node: Nodo Tree-sitter de la llamada
            file_path: Ruta del archivo
            language_config: Configuración del lenguaje
            
        Returns:
            Dict con metadata completa de la llamada
        """
        metadata = {
            "call_text": node.text.decode('utf-8') if hasattr(node, 'text') else "",
            "resolved_function_id": None,
            "is_imported": False,
            "import_path": None
        }
        
        return metadata
    
    def _parse_import_statement(self, import_text: str, file_path: str) -> Dict[str, str]:
        """
        Parsea un statement de import y retorna un mapeo de nombres importados a módulos.
        
        Args:
            import_text: Texto del import
            file_path: Ruta del archivo que contiene el import
            
        Returns:
            Dict con {imported_name: source_module}
        """
        imports_map = {}
        
        try:
            if not import_text:
                return imports_map
            
            # Python: from module import func, from module import func as alias
            if "from" in import_text and "import" in import_text:
                match = re.match(r'from\s+([^\s]+)\s+import\s+(.+)', import_text)
                if match:
                    module = match.group(1).strip()
                    imports = match.group(2).strip()
                    
                    # Resolver módulo a ruta de archivo
                    source_file = self._resolve_module_to_file(module, file_path)
                    
                    # Parsear lista de imports (puede tener alias)
                    for item in imports.split(','):
                        item = item.strip()
                        if " as " in item:
                            # from module import func as alias
                            original, alias = item.split(" as ", 1)
                            imports_map[alias.strip()] = source_file or module
                        else:
                            # from module import func
                            imports_map[item.strip()] = source_file or module
            
            # Python: import module, import module as alias
            elif import_text.startswith("import "):
                module_part = import_text.replace("import ", "").strip()
                for item in module_part.split(','):
                    item = item.strip()
                    if " as " in item:
                        module, alias = item.split(" as ", 1)
                        source_file = self._resolve_module_to_file(module.strip(), file_path)
                        imports_map[alias.strip()] = source_file or module.strip()
                    else:
                        source_file = self._resolve_module_to_file(item, file_path)
                        # Para imports de módulos, el nombre es el último componente
                        module_name = item.split('.')[-1]
                        imports_map[module_name] = source_file or item
        
        except Exception as e:
            logger.debug(f"Error parseando import '{import_text}' en {file_path}: {e}")
        
        return imports_map
    
    def _resolve_module_to_file(self, module: str, current_file: str) -> Optional[str]:
        """
        Resuelve un nombre de módulo a una ruta de archivo relativa.
        
        Args:
            module: Nombre del módulo (ej: "hacki.cli.commands")
            current_file: Archivo actual (ej: "hacki/start.py")
            
        Returns:
            Ruta relativa del archivo o None si no se puede resolver
        """
        try:
            # Convertir módulo a ruta de archivo
            # hacki.cli.commands -> hacki/cli/commands.py
            module_path = module.replace('.', '/')
            
            # Buscar archivo en el proyecto
            possible_paths = [
                f"{module_path}.py",
                f"{module_path}/__init__.py",
            ]
            
            for path in possible_paths:
                full_path = self.project_root / path
                if full_path.exists():
                    return str(Path(path).as_posix())
            
            # Si no se encuentra, retornar None (puede ser módulo externo)
            return None
        
        except Exception as e:
            logger.debug(f"Error resolviendo módulo '{module}' desde {current_file}: {e}")
            return None
    
    def _resolve_function_call(self, call_node: GraphNode, all_nodes_dict: Dict[str, GraphNode]) -> Tuple[Optional[str], Dict[str, Any]]:
        """
        Resuelve una llamada a función y retorna el ID de la función objetivo y metadata actualizada.
        
        Args:
            call_node: Nodo de la llamada
            all_nodes_dict: Dict de todos los nodos por ID
            
        Returns:
            Tupla (ID de función objetivo o None, metadata actualizada)
        """
        call_name = call_node.name
        call_file = call_node.file_path
        updated_metadata = call_node.metadata.copy()
        
        # 1. Buscar en el mismo archivo
        same_file_functions = [
            n for n in all_nodes_dict.values()
            if n.type == "function" and n.file_path == call_file and n.name == call_name
        ]
        if same_file_functions:
            # Si hay múltiples, tomar la más cercana en línea
            same_file_functions.sort(key=lambda f: abs(f.line_start - call_node.line_start))
            target_id = same_file_functions[0].id
            updated_metadata["resolved_function_id"] = target_id
            updated_metadata["is_imported"] = False
            return target_id, updated_metadata
        
        # 2. Buscar en imports del archivo
        file_imports = self._import_index.get(call_file, {})
        if call_name in file_imports:
            source_file = file_imports[call_name]
            # Buscar función en el archivo fuente
            imported_functions = [
                n for n in all_nodes_dict.values()
                if n.type == "function" and n.file_path == source_file and n.name == call_name
            ]
            if imported_functions:
                target_id = imported_functions[0].id
                updated_metadata["resolved_function_id"] = target_id
                updated_metadata["is_imported"] = True
                updated_metadata["import_path"] = source_file
                return target_id, updated_metadata
        
        # 3. Buscar métodos de clase (obj.method())
        # Esto requiere análisis más complejo del AST, por ahora retornamos None
        
        # 4. No se pudo resolver
        updated_metadata["resolved_function_id"] = None
        updated_metadata["is_imported"] = False
        return None, updated_metadata
    
    def _resolve_calls(self, all_nodes: List[GraphNode], progress_callback=None) -> Tuple[List[GraphEdge], Dict[str, GraphNode]]:
        """
        Resuelve todas las llamadas y crea edges de tipo "calls".
        
        Args:
            all_nodes: Lista de todos los nodos
            progress_callback: Función callback para actualizar progreso (opcional)
            
        Returns:
            Tupla (lista de edges "calls" creadas, dict de nodos actualizados)
        """
        # Construir índices
        if progress_callback:
            progress_callback("Construyendo índices...")
        
        # Crear dict de nodos por ID para acceso rápido
        all_nodes_dict = {node.id: node for node in all_nodes}
        
        # Índice de funciones por nombre
        for node in all_nodes:
            if node.type == "function":
                if node.name not in self._function_index:
                    self._function_index[node.name] = []
                self._function_index[node.name].append(node)
                
                if node.file_path not in self._function_by_file:
                    self._function_by_file[node.file_path] = []
                self._function_by_file[node.file_path].append(node)
        
        # Índice de clases
        for node in all_nodes:
            if node.type == "class":
                if node.name not in self._class_index:
                    self._class_index[node.name] = []
                self._class_index[node.name].append(node)
        
        # Índice de imports
        for node in all_nodes:
            if node.type == "import":
                import_text = node.metadata.get("import_text", "")
                if import_text:
                    imports_map = self._parse_import_statement(import_text, node.file_path)
                    if node.file_path not in self._import_index:
                        self._import_index[node.file_path] = {}
                    self._import_index[node.file_path].update(imports_map)
        
        # Resolver llamadas
        call_edges = []
        call_nodes = [n for n in all_nodes if n.type == "call"]
        updated_nodes = {}
        
        if progress_callback:
            progress_callback(f"Resolviendo {len(call_nodes)} llamadas...")
        
        for i, call_node in enumerate(call_nodes):
            if progress_callback and i % 100 == 0:
                progress_callback(f"Resolviendo llamadas... ({i}/{len(call_nodes)})")
            
            resolved_id, updated_metadata = self._resolve_function_call(call_node, all_nodes_dict)
            
            # Actualizar nodo con nueva metadata
            updated_node = GraphNode(
                id=call_node.id,
                type=call_node.type,
                name=call_node.name,
                file_path=call_node.file_path,
                line_start=call_node.line_start,
                line_end=call_node.line_end,
                metadata=updated_metadata
            )
            updated_nodes[call_node.id] = updated_node
            
            if resolved_id:
                # Crear edge "calls"
                call_edge = GraphEdge(
                    id=self._generate_edge_id(),
                    source=call_node.id,
                    target=resolved_id,
                    type="calls",
                    metadata={"resolved": True}
                )
                call_edges.append(call_edge)
        
        return call_edges, updated_nodes
    
    def _parse_single_file(self, file_path: str) -> Tuple[List[GraphNode], List[GraphEdge]]:
        """
        Parsea un archivo individual y extrae nodos y edges.
        
        Args:
            file_path: Ruta relativa del archivo
            
        Returns:
            Tupla con (nodos, edges) del archivo
        """
        # Obtener configuración del lenguaje
        language_config = self.language_registry.get_language_by_file(file_path)
        if not language_config:
            logger.debug(f"Lenguaje no soportado para {file_path}")
            return [], []
        
        # Parsear archivo con Tree-sitter
        full_path = self.project_root / file_path
        tree = self.tree_sitter_loader.parse_file(str(full_path), language_config.tree_sitter_name)
        if not tree:
            logger.warning(f"No se pudo parsear {file_path}")
            return [], []
        
        # Extraer nodos y edges
        return self._parse_file_nodes(file_path, tree, language_config)
    
    def build_full_graph(self, show_progress: bool = True) -> Dict[str, Any]:
        """
        Construye el grafo completo del proyecto con resolución de llamadas.
        
        Args:
            show_progress: Si mostrar barra de progreso (requiere Rich)
        
        Returns:
            Diccionario con el grafo completo
        """
        logger.info("Iniciando construcción del grafo completo")
        
        # Reiniciar contadores y cache
        self._node_counter = 0
        self._edge_counter = 0
        self._nodes.clear()
        self._edges.clear()
        self._function_index.clear()
        self._function_by_file.clear()
        self._class_index.clear()
        self._import_index.clear()
        self._class_containment.clear()
        
        # Obtener extensiones soportadas
        supported_extensions = self.language_registry.get_supported_extensions()
        
        # Calcular hashes de archivos
        current_hashes = self.hash_manager.calculate_directory_hashes(
            str(self.project_root), supported_extensions
        )
        
        all_nodes = []
        all_edges = []
        call_edges = []  # Inicializar para evitar errores
        
        # Configurar progreso
        use_progress = show_progress and RICH_AVAILABLE
        progress = None
        task1 = None
        task2 = None
        
        if use_progress:
            progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=rich_console,
            )
            progress.start()
            task1 = progress.add_task("Parseando archivos...", total=len(current_hashes))
        
        # Fase 1: Procesar cada archivo y construir grafo base
        try:
            for file_path in current_hashes.keys():
                try:
                    nodes, edges = self._parse_single_file(file_path)
                    all_nodes.extend(nodes)
                    all_edges.extend(edges)
                    
                    # Guardar en cache
                    for node in nodes:
                        self._nodes[node.id] = node
                    for edge in edges:
                        self._edges[edge.id] = edge
                    
                    if use_progress:
                        progress.update(task1, advance=1)
                        
                except Exception as e:
                    logger.error(f"Error procesando {file_path}: {e}")
                    continue
            
            if use_progress:
                progress.update(task1, completed=len(current_hashes))
                task2 = progress.add_task("Resolviendo llamadas entre funciones...", total=None)
            
            # Fase 2: Resolver llamadas
            def update_progress(msg: str):
                if use_progress and task2:
                    progress.update(task2, description=msg)
            
            call_edges, updated_call_nodes = self._resolve_calls(all_nodes, update_progress)
            all_edges.extend(call_edges)
            
            # Actualizar nodos call con metadata resuelta
            for call_node_id, updated_node in updated_call_nodes.items():
                # Reemplazar el nodo en all_nodes
                for i, node in enumerate(all_nodes):
                    if node.id == call_node_id:
                        all_nodes[i] = updated_node
                        self._nodes[node.id] = updated_node
                        break
            
            if use_progress:
                progress.update(task2, completed=1)
        
        finally:
            if use_progress and progress:
                progress.stop()
        
        # Obtener información de Git para metadata de temporalidad
        git_branch = None
        git_commit = None
        try:
            import subprocess
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                check=True
            )
            git_branch = result.stdout.strip()
            
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                check=True
            )
            git_commit = result.stdout.strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass  # Git no disponible, continuar sin metadata de Git
        
        # Crear grafo final
        graph = {
            "metadata": {
                "project_root": str(self.project_root),
                "total_files": len(current_hashes),
                "total_nodes": len(all_nodes),
                "total_edges": len(all_edges),
                "total_call_edges": len(call_edges),
                "supported_languages": self.language_registry.get_supported_languages(),
                "is_temporary": True,  # Los grafos generados localmente son temporales
                "branch": git_branch,
                "commit_sha": git_commit,
                "generated_at": datetime.now().isoformat()
            },
            "nodes": [asdict(node) for node in all_nodes],
            "edges": [asdict(edge) for edge in all_edges]
        }
        
        # Actualizar hashes
        self.hash_manager.save_hashes(current_hashes)
        
        logger.info(
            f"Grafo construido: {len(all_nodes)} nodos, {len(all_edges)} edges "
            f"({len(call_edges)} edges de llamadas), {len(current_hashes)} archivos"
        )
        
        return graph
    
    def save_graph(self, graph: Dict[str, Any]) -> bool:
        """
        Guarda el grafo en .hacki/graph.json.
        
        Args:
            graph: Grafo a guardar
            
        Returns:
            bool: True si se guardó correctamente
        """
        try:
            self.ensure_hacki_dir()
            with open(self.graph_file, 'w', encoding='utf-8') as f:
                json.dump(graph, f, indent=2, ensure_ascii=False)
            logger.info(f"Grafo guardado en {self.graph_file}")
            return True
        except Exception as e:
            logger.error(f"Error guardando grafo: {e}")
            return False
    
    def load_graph(self) -> Optional[Dict[str, Any]]:
        """
        Carga el grafo desde .hacki/graph.json.
        
        Returns:
            Grafo cargado o None si hay error
        """
        if not self.graph_file.exists():
            return None
        
        try:
            with open(self.graph_file, 'r', encoding='utf-8') as f:
                graph = json.load(f)
            logger.info(f"Grafo cargado desde {self.graph_file}")
            return graph
        except Exception as e:
            logger.error(f"Error cargando grafo: {e}")
            return None
    
    def graph_exists(self) -> bool:
        """
        Verifica si existe un grafo guardado.
        
        Returns:
            bool: True si existe el grafo
        """
        return self.graph_file.exists()
    
    def get_file_subgraph(self, file_path: str, graph: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extrae un subgrafo relevante para un archivo específico.
        
        Args:
            file_path: Ruta del archivo
            graph: Grafo completo
            
        Returns:
            Subgrafo relevante para el archivo
        """
        # Normalizar ruta del archivo
        file_path = str(Path(file_path).as_posix())
        
        relevant_nodes = []
        relevant_edges = []
        
        # Encontrar nodos del archivo
        file_node_ids = set()
        for node in graph.get("nodes", []):
            if node.get("file_path") == file_path:
                relevant_nodes.append(node)
                file_node_ids.add(node["id"])
        
        # Encontrar edges relacionadas
        for edge in graph.get("edges", []):
            if edge.get("source") in file_node_ids or edge.get("target") in file_node_ids:
                relevant_edges.append(edge)
        
        # Encontrar nodos conectados
        connected_node_ids = set()
        for edge in relevant_edges:
            connected_node_ids.add(edge["source"])
            connected_node_ids.add(edge["target"])
        
        # Agregar nodos conectados que no están ya incluidos
        for node in graph.get("nodes", []):
            if node["id"] in connected_node_ids and node not in relevant_nodes:
                relevant_nodes.append(node)
        
        subgraph = {
            "metadata": {
                "file_path": file_path,
                "total_nodes": len(relevant_nodes),
                "total_edges": len(relevant_edges)
            },
            "nodes": relevant_nodes,
            "edges": relevant_edges
        }
        
        return subgraph
