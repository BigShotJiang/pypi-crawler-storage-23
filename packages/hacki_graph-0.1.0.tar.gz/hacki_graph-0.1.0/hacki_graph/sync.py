"""
Snapshot Synchronization

Gestiona la sincronización de snapshots canonical con el backend.
"""

import json
import logging
import requests
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

DEFAULT_API_URL = "https://api.hacki.ai"

logger = logging.getLogger(__name__)


class SnapshotSync:
    """
    Gestiona la sincronización de snapshots canonical con el backend.

    Funcionalidades:
    - Sincronizar snapshot desde el backend
    - Validar que el snapshot coincide con el commit actual
    - Cargar snapshot canonical local
    """

    def __init__(self, project_root: str, api_key: Optional[str] = None, api_url: Optional[str] = None):
        """
        Inicializa el gestor de sincronización.
        
        Args:
            project_root: Ruta raíz del proyecto
            api_key: API key para autenticación (opcional)
        """
        self.project_root = Path(project_root)
        self.api_key = api_key
        self.api_url = api_url or DEFAULT_API_URL
        self.snapshot_file = self.project_root / ".hacki" / "snapshot_canonical.json"
        self.metadata_file = self.project_root / ".hacki" / "snapshot_metadata.json"
    
    def sync_from_backend(self, job_id: str, branch: str, 
                         commit_sha: Optional[str] = None) -> Dict[str, Any]:
        """
        Sincroniza snapshot canonical desde el backend.
        
        Args:
            job_id: ID del job del proyecto
            branch: Rama de Git (main o develop)
            commit_sha: SHA del commit (opcional, para validación)
            
        Returns:
            Diccionario con el resultado de la sincronización:
            {
                "success": bool,
                "snapshot": dict (si success=True),
                "error": str (si success=False)
            }
        """
        if not self.api_key:
            return {
                "success": False,
                "error": "API key no proporcionada"
            }
        
        try:
            # Construir URL del endpoint
            url = f"{self.api_url}/analisis/snapshot/{job_id}"
            params = {"branch": branch}
            if commit_sha:
                params["commit_sha"] = commit_sha
            
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json"
            }
            
            logger.info(f"Sincronizando snapshot desde backend: {url}")
            response = requests.get(url, params=params, headers=headers, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                snapshot = data.get("snapshot", {})
                metadata = data.get("metadata", {})
                
                # Guardar snapshot localmente
                if self._save_snapshot(snapshot, metadata, branch, commit_sha, job_id):
                    logger.info("Snapshot sincronizado y guardado correctamente")
                    return {
                        "success": True,
                        "snapshot": snapshot,
                        "metadata": metadata
                    }
                else:
                    return {
                        "success": False,
                        "error": "Error guardando snapshot localmente"
                    }
            elif response.status_code == 404:
                return {
                    "success": False,
                    "error": f"Snapshot no encontrado para job_id={job_id}, branch={branch}"
                }
            else:
                error_msg = f"Error del backend: {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_msg)
                except:
                    pass
                
                return {
                    "success": False,
                    "error": error_msg
                }
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error de conexión al sincronizar snapshot: {e}")
            return {
                "success": False,
                "error": f"Error de conexión: {str(e)}"
            }
        except Exception as e:
            logger.error(f"Error inesperado al sincronizar snapshot: {e}")
            return {
                "success": False,
                "error": f"Error inesperado: {str(e)}"
            }
    
    def validate_snapshot(self, commit_sha: str) -> bool:
        """
        Valida que el snapshot coincide con el commit actual.
        
        Args:
            commit_sha: SHA del commit actual
            
        Returns:
            True si el snapshot es válido para este commit
        """
        metadata = self.load_snapshot_metadata()
        if not metadata:
            return False
        
        snapshot_commit = metadata.get("commit_sha")
        if snapshot_commit is None:
            logger.warning("Snapshot no tiene commit_sha, considerando inválido")
            return False
        
        # Permitir coincidencia exacta o compatibilidad (puede ser más reciente)
        is_valid = snapshot_commit == commit_sha
        if not is_valid:
            logger.warning(f"Commit SHA no coincide: snapshot={snapshot_commit}, local={commit_sha}")
        
        return is_valid
    
    def save_canonical_snapshot(self, snapshot_data: Dict[str, Any], metadata: Dict[str, Any]) -> None:
        """
        Guarda snapshot canonical y su metadata localmente.
        
        Args:
            snapshot_data: Diccionario con el snapshot completo
            metadata: Metadata del snapshot
        """
        try:
            # Asegurar que el directorio existe
            self.snapshot_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Guardar snapshot
            with open(self.snapshot_file, "w", encoding="utf-8") as f:
                json.dump(snapshot_data, f, indent=2, ensure_ascii=False)
            
            # Guardar metadata
            with open(self.metadata_file, "w", encoding="utf-8") as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Snapshot canonical guardado en {self.snapshot_file}")
            
        except IOError as e:
            logger.error(f"Error guardando snapshot canonical: {e}")
            raise
    
    def load_canonical_snapshot(self) -> Optional[Dict[str, Any]]:
        """
        Carga snapshot canonical local.
        
        Returns:
            Diccionario con el snapshot o None si no existe
        """
        if not self.snapshot_file.exists():
            logger.debug("Snapshot canonical no existe localmente")
            return None
        
        try:
            with open(self.snapshot_file, "r", encoding="utf-8") as f:
                snapshot = json.load(f)
            logger.debug("Snapshot canonical cargado desde archivo local")
            return snapshot
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error cargando snapshot canonical: {e}")
            return None
    
    def load_snapshot_metadata(self) -> Optional[Dict[str, Any]]:
        """
        Carga metadata del snapshot canonical.
        
        Returns:
            Diccionario con la metadata o None si no existe
        """
        if not self.metadata_file.exists():
            return None
        
        try:
            with open(self.metadata_file, "r", encoding="utf-8") as f:
                metadata = json.load(f)
            return metadata
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error cargando metadata del snapshot: {e}")
            return None
    
    def needs_sync(self, current_branch: str, current_commit: str) -> bool:
        """
        Verifica si el snapshot necesita sincronización.
        
        Args:
            current_branch: Rama actual de Git
            current_branch: SHA del commit actual
            
        Returns:
            True si necesita sincronización
        """
        metadata = self.load_snapshot_metadata()
        if not metadata:
            logger.debug("No hay metadata de snapshot, necesita sincronización")
            return True
        
        # Verificar rama
        snapshot_branch = metadata.get("branch")
        if snapshot_branch != current_branch:
            logger.debug(f"Rama cambió: {snapshot_branch} -> {current_branch}")
            return True
        
        # Verificar commit
        snapshot_commit = metadata.get("commit_sha")
        if snapshot_commit != current_commit:
            logger.debug(f"Commit cambió: {snapshot_commit} -> {current_commit}")
            return True
        
        return False
    
    def _save_snapshot(self, snapshot: Dict[str, Any], metadata: Dict[str, Any],
                      branch: str, commit_sha: Optional[str], job_id: str) -> bool:
        """
        Guarda snapshot canonical localmente.
        
        Args:
            snapshot: Diccionario con el snapshot
            metadata: Metadata del snapshot del backend
            branch: Rama de Git
            commit_sha: SHA del commit
            job_id: ID del job
            
        Returns:
            True si se guardó correctamente
        """
        try:
            # Asegurar que el directorio existe
            self.snapshot_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Guardar snapshot
            with open(self.snapshot_file, "w", encoding="utf-8") as f:
                json.dump(snapshot, f, indent=2)
            
            # Guardar metadata
            snapshot_metadata = {
                "branch": branch,
                "commit_sha": commit_sha or metadata.get("commit_sha"),
                "last_sync": datetime.utcnow().isoformat(),
                "job_id": job_id,
                "is_canonical": True,
                "source": "backend",
                "total_files": metadata.get("total_files", 0),
                "last_updated": metadata.get("last_updated")
            }
            
            with open(self.metadata_file, "w", encoding="utf-8") as f:
                json.dump(snapshot_metadata, f, indent=2)
            
            logger.debug(f"Snapshot guardado en {self.snapshot_file}")
            return True
            
        except IOError as e:
            logger.error(f"Error guardando snapshot: {e}")
            return False

