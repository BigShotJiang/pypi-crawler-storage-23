"""
Graph Orchestrator

Orquestador centralizado que coordina la construcción y actualización
de grafos de código, detectando cambios automáticamente y validando
consistencia antes de usar archivos existentes.
"""

import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional, Set
from datetime import datetime

from .metadata import GraphMetadata
from .validator import GraphValidator
from .manager import EnhancedGraphManager, StaticAnalysisManager
from .utils.incremental import IncrementalAnalysisManager

logger = logging.getLogger(__name__)


class GraphOrchestrator:
    """
    Orquestador centralizado para gestión de grafos de código.
    
    Responsabilidades:
    1. Detectar automáticamente si necesita construir/actualizar
    2. Gestionar sincronización con backend (futuro)
    3. Manejar cambios de rama Git
    4. Coordinar actualizaciones incrementales
    5. Validar consistencia de archivos
    """
    
    def __init__(self, project_root: str):
        """
        Inicializa el orquestador.
        
        Args:
            project_root: Ruta raíz del proyecto
        """
        self.project_root = Path(project_root)
        self.graph_manager = EnhancedGraphManager(str(project_root))
        self.metadata = GraphMetadata(str(project_root))
        self.validator = GraphValidator(str(project_root))
        
        # Cargar metadata
        self.metadata.load()
    
    def ensure_analysis_ready(self, file_paths: List[str]) -> Dict[str, Any]:
        """
        Asegura que el análisis esté listo para los archivos especificados.
        
        Este método es el punto de entrada principal para obtener análisis de código.
        Maneja automáticamente:
        - Detección de cambios de rama Git (invalida cache si cambió)
        - Validación de consistencia de archivos existentes
        - Construcción incremental o completa según necesidad
        - Validación de grafos temporales (si branch cambió, regenera)
        
        Args:
            file_paths: Lista de rutas de archivos (relativas o absolutas) que necesitan análisis
            
        Returns:
            Diccionario con análisis completo:
            {
                "tree_sitter_graph": {
                    "nodes": [...],
                    "edges": [...],
                    "metadata": {...}
                },
                "static_analysis": {
                    "ir_files": {...},
                    "cfg_files": {...},
                    "dfg_files": {...},
                    "stats": {...}
                },
                "metadata": {
                    "branch": "main",
                    "commit": "abc123",
                    ...
                },
                "validation": {
                    "is_valid": bool,
                    "errors": [...],
                    "warnings": [...]
                },
                "actions_taken": [
                    "Construyendo graph.json completo",
                    "Actualizando análisis estático: 3 archivos nuevos",
                    ...
                ]
            }
        
        Example:
            >>> orchestrator = GraphOrchestrator(".")
            >>> results = orchestrator.ensure_analysis_ready(["src/main.py", "src/utils.py"])
            >>> graph = results["tree_sitter_graph"]
            >>> print(f"Analizados {len(graph['nodes'])} nodos")
        """
        actions_taken = []
        results = {
            "tree_sitter_graph": {},
            "static_analysis": {},
            "metadata": {},
            "validation": {},
            "actions_taken": actions_taken
        }
        
        try:
            # 1. Verificar rama Git actual
            current_branch = self._get_current_git_branch()
            current_commit = self._get_current_git_commit()
            
            if current_branch:
                stored_branch = self.metadata.get_branch()
                if stored_branch and stored_branch != current_branch:
                    logger.info(f"Rama Git cambió: {stored_branch} -> {current_branch}")
                    actions_taken.append(f"Rama cambió: {stored_branch} -> {current_branch}")
                    # Invalidar cache si cambió la rama
                    self._invalidate_cache()
                    actions_taken.append("Cache invalidado por cambio de rama")
                
                # Actualizar metadata con rama y commit actuales
                self.metadata.update_branch(current_branch)
                if current_commit:
                    self.metadata.update_commit(current_commit)
            
            # 2. Validar consistencia de archivos existentes
            validation_result = self.validator.validate_consistency()
            results["validation"] = validation_result
            
            if not validation_result.get("is_valid", True):
                logger.warning("Validación de consistencia falló, reconstruyendo...")
                actions_taken.append("Validación falló, reconstruyendo análisis")
                # Si hay errores críticos, reconstruir
                if validation_result.get("errors"):
                    self._invalidate_cache()
            
            # 3. Verificar si graph.json existe y es válido
            # También validar que el branch del grafo coincide con el actual (si es temporal)
            graph_needs_rebuild = False
            if self.graph_manager.graph_exists():
                existing_graph = self.graph_manager.graph_builder.load_graph()
                if existing_graph:
                    graph_metadata = existing_graph.get("metadata", {})
                    graph_branch = graph_metadata.get("branch")
                    graph_is_temporary = graph_metadata.get("is_temporary", False)
                    
                    # Si el grafo es temporal y el branch cambió, invalidar
                    if graph_is_temporary and graph_branch and graph_branch != current_branch:
                        logger.info(f"Grafo temporal de branch diferente ({graph_branch} vs {current_branch}), invalidando")
                        graph_needs_rebuild = True
                        actions_taken.append(f"Grafo temporal invalidado: branch cambió ({graph_branch} -> {current_branch})")
            
            if not self.graph_manager.graph_exists() or not validation_result.get("graph_valid", True) or graph_needs_rebuild:
                logger.info("Construyendo graph.json desde cero")
                actions_taken.append("Construyendo graph.json completo")
                tree_sitter_graph = self.graph_manager.build_full_graph()
                self.graph_manager.save_graph(tree_sitter_graph)
                results["tree_sitter_graph"] = tree_sitter_graph
            else:
                # Verificar si los archivos solicitados están en el grafo
                missing_files = self._get_missing_files_in_graph(file_paths)
                if missing_files:
                    logger.info(f"Actualizando graph.json con {len(missing_files)} archivos nuevos")
                    actions_taken.append(f"Actualizando graph.json: {len(missing_files)} archivos nuevos")
                    tree_sitter_graph = self.graph_manager.update_incremental_graph()
                    self.graph_manager.save_graph(tree_sitter_graph)
                    results["tree_sitter_graph"] = tree_sitter_graph
                else:
                    # Cargar grafo existente
                    logger.debug("Usando graph.json existente")
                    results["tree_sitter_graph"] = self.graph_manager.graph_builder.load_graph()
            
            # 4. Verificar si análisis estático existe y es válido
            if not self.graph_manager.static_analysis_exists() or not validation_result.get("ir_valid", True):
                logger.info("Construyendo análisis estático completo")
                actions_taken.append("Construyendo análisis estático completo")
                static_analysis = self.graph_manager.build_full_static_analysis(file_paths)
                results["static_analysis"] = static_analysis
            else:
                # Verificar si los archivos solicitados están en el análisis estático
                missing_files = self._get_missing_files_in_static_analysis(file_paths)
                if missing_files:
                    logger.info(f"Actualizando análisis estático con {len(missing_files)} archivos nuevos")
                    actions_taken.append(f"Actualizando análisis estático: {len(missing_files)} archivos nuevos")
                    static_analysis = self.graph_manager.update_incremental_static_analysis(file_paths)
                    results["static_analysis"] = static_analysis
                else:
                    # Usar análisis existente (cargar desde archivos)
                    logger.debug("Usando análisis estático existente")
                    results["static_analysis"] = self._load_existing_static_analysis()
            
            # 5. Actualizar metadata con información actualizada
            if results.get("tree_sitter_graph"):
                nodes = results["tree_sitter_graph"].get("nodes", [])
                self.metadata.update_total_files(len(set(n.get("file_path") for n in nodes if n.get("file_path"))))
            
            self.metadata.save()
            results["metadata"] = self.metadata.to_dict()
            
            logger.info(f"Análisis listo: {len(actions_taken)} acciones realizadas")
            
        except Exception as e:
            logger.error(f"Error en ensure_analysis_ready: {e}")
            results["error"] = str(e)
            actions_taken.append(f"Error: {str(e)}")
        
        return results
    
    def _get_current_git_branch(self) -> Optional[str]:
        """
        Obtiene la rama actual de Git.
        
        Returns:
            Nombre de la rama o None si no es un repo Git
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                check=True,
                timeout=5
            )
            branch = result.stdout.strip()
            return branch if branch else None
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return None
    
    def _get_current_git_commit(self) -> Optional[str]:
        """
        Obtiene el SHA del commit actual de Git.
        
        Returns:
            SHA completo del commit (ej: "abc123def456...") 
            o None si no es un repo Git o hay error
            
        Example:
            >>> orchestrator = GraphOrchestrator(".")
            >>> commit = orchestrator._get_current_git_commit()
            >>> print(f"Commit actual: {commit[:8]}...")
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                check=True,
                timeout=5
            )
            commit = result.stdout.strip()
            return commit if commit else None
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return None
    
    def _invalidate_cache(self):
        """
        Invalida el cache de grafos y análisis.
        
        Esto no elimina los archivos físicos, pero marca en la metadata
        que deben ser reconstruidos en la próxima operación.
        
        Se llama automáticamente cuando:
        - Cambia la rama Git
        - Se detectan inconsistencias críticas
        - El usuario solicita reconstrucción completa
        
        Note:
            Los archivos no se eliminan, solo se marca que deben regenerarse.
            Esto permite recuperación si hay errores durante la reconstrucción.
        """
        logger.info("Invalidando cache de grafos")
        # Por ahora, solo actualizamos metadata
        # En el futuro, podríamos eliminar archivos específicos
        self.metadata.update_branch(None)
        self.metadata.update_commit(None)
        self.metadata.save()
    
    def _get_missing_files_in_graph(self, file_paths: List[str]) -> List[str]:
        """
        Identifica archivos que no están en graph.json.
        
        Args:
            file_paths: Lista de archivos a verificar
            
        Returns:
            Lista de archivos que faltan en graph.json
        """
        if not self.graph_manager.graph_exists():
            return file_paths
        
        try:
            graph = self.graph_manager.load_graph()
            nodes = graph.get("nodes", [])
            
            # Obtener archivos únicos del grafo
            files_in_graph = set()
            for node in nodes:
                file_path = node.get("file_path")
                if file_path:
                    # Normalizar rutas para comparación
                    files_in_graph.add(str(Path(file_path).resolve()))
            
            # Verificar qué archivos faltan
            missing = []
            for file_path in file_paths:
                normalized = str(Path(file_path).resolve())
                if normalized not in files_in_graph:
                    missing.append(file_path)
            
            return missing
        except Exception as e:
            logger.warning(f"Error verificando archivos en graph.json: {e}")
            # Si hay error, asumir que todos faltan
            return file_paths
    
    def _get_missing_files_in_static_analysis(self, file_paths: List[str]) -> List[str]:
        """
        Identifica archivos que no están en el análisis estático.
        
        Args:
            file_paths: Lista de archivos a verificar
            
        Returns:
            Lista de archivos que faltan en el análisis estático
        """
        if not self.graph_manager.static_analysis_exists():
            return file_paths
        
        try:
            static_analysis = self.graph_manager.static_analysis
            ir_file = static_analysis.ir_file
            
            if not ir_file.exists():
                return file_paths
            
            import json
            with open(ir_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            files_in_analysis = set(data.get("files", {}).keys())
            
            # Verificar qué archivos faltan
            missing = []
            for file_path in file_paths:
                file_path_obj = Path(file_path)
                normalized = str(file_path_obj.resolve())
                
                # Intentar diferentes formas de comparación
                found = False
                for analysis_file in files_in_analysis:
                    analysis_path = Path(analysis_file)
                    # Comparar rutas absolutas
                    if str(analysis_path.resolve()) == normalized:
                        found = True
                        break
                    # Comparar rutas relativas
                    try:
                        rel_path = str(file_path_obj.relative_to(self.project_root))
                        if str(analysis_path) == rel_path or str(analysis_path) == file_path:
                            found = True
                            break
                    except ValueError:
                        pass
                
                if not found:
                    missing.append(file_path)
            
            return missing
        except Exception as e:
            logger.warning(f"Error verificando archivos en análisis estático: {e}")
            # Si hay error, asumir que todos faltan
            return file_paths
    
    def _load_existing_static_analysis(self) -> Dict[str, Any]:
        """
        Carga análisis estático existente desde archivos.
        
        Returns:
            Diccionario con análisis estático cargado
        """
        try:
            static_analysis = self.graph_manager.static_analysis
            results = {
                "ir_files": {},
                "cfg_files": {},
                "dfg_files": {},
                "stats": {}
            }
            
            # Cargar IR
            if static_analysis.ir_file.exists():
                import json
                with open(static_analysis.ir_file, "r", encoding="utf-8") as f:
                    ir_data = json.load(f)
                results["ir_files"] = ir_data.get("files", {})
                results["stats"]["ir_files"] = len(results["ir_files"])
            
            # Cargar CFG
            if static_analysis.cfg_file.exists():
                import json
                with open(static_analysis.cfg_file, "r", encoding="utf-8") as f:
                    cfg_data = json.load(f)
                results["cfg_files"] = cfg_data.get("files", {})
                results["stats"]["cfg_files"] = len(results["cfg_files"])
            
            # Cargar DFG
            if static_analysis.dfg_file.exists():
                import json
                with open(static_analysis.dfg_file, "r", encoding="utf-8") as f:
                    dfg_data = json.load(f)
                results["dfg_files"] = dfg_data.get("files", {})
                results["stats"]["dfg_files"] = len(results["dfg_files"])
            
            return results
        except Exception as e:
            logger.error(f"Error cargando análisis estático existente: {e}")
            return {}

