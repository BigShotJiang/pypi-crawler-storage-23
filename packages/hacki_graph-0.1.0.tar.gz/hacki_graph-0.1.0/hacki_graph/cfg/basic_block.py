"""
Basic Block Implementation

Define la estructura de bloques básicos para el Control Flow Graph (CFG).
Un bloque básico es una secuencia de instrucciones que se ejecutan secuencialmente
sin saltos internos.
"""

from typing import List, Set, Dict, Any, Optional
from dataclasses import dataclass, field
import json

@dataclass
class BasicBlock:
    """
    Representa un bloque básico en el CFG.
    
    Un bloque básico contiene una secuencia de statements IR que se ejecutan
    secuencialmente sin bifurcaciones internas.
    """
    id: str
    statements: List[str] = field(default_factory=list)  # IDs de nodos IR
    predecessors: Set[str] = field(default_factory=set)  # IDs de bloques predecesores
    successors: Set[str] = field(default_factory=set)    # IDs de bloques sucesores
    start_line: int = 0
    end_line: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_statement(self, statement_id: str):
        """Agrega un statement al bloque."""
        if statement_id not in self.statements:
            self.statements.append(statement_id)
    
    def add_predecessor(self, block_id: str):
        """Agrega un bloque predecesor."""
        self.predecessors.add(block_id)
    
    def add_successor(self, block_id: str):
        """Agrega un bloque sucesor."""
        self.successors.add(block_id)
    
    def remove_predecessor(self, block_id: str):
        """Remueve un bloque predecesor."""
        self.predecessors.discard(block_id)
    
    def remove_successor(self, block_id: str):
        """Remueve un bloque sucesor."""
        self.successors.discard(block_id)
    
    def is_empty(self) -> bool:
        """Verifica si el bloque está vacío."""
        return len(self.statements) == 0
    
    def is_entry_block(self) -> bool:
        """Verifica si es un bloque de entrada (sin predecesores)."""
        return len(self.predecessors) == 0
    
    def is_exit_block(self) -> bool:
        """Verifica si es un bloque de salida (sin sucesores)."""
        return len(self.successors) == 0
    
    def get_first_statement(self) -> Optional[str]:
        """Obtiene el primer statement del bloque."""
        return self.statements[0] if self.statements else None
    
    def get_last_statement(self) -> Optional[str]:
        """Obtiene el último statement del bloque."""
        return self.statements[-1] if self.statements else None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el bloque a diccionario para serialización."""
        return {
            "id": self.id,
            "statements": self.statements,
            "predecessors": list(self.predecessors),
            "successors": list(self.successors),
            "start_line": self.start_line,
            "end_line": self.end_line,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BasicBlock':
        """Crea un bloque desde un diccionario."""
        return cls(
            id=data["id"],
            statements=data.get("statements", []),
            predecessors=set(data.get("predecessors", [])),
            successors=set(data.get("successors", [])),
            start_line=data.get("start_line", 0),
            end_line=data.get("end_line", 0),
            metadata=data.get("metadata", {})
        )
    
    def __str__(self) -> str:
        return f"BasicBlock({self.id}, {len(self.statements)} statements)"
    
    def __repr__(self) -> str:
        return self.__str__()

class CFGEdge:
    """
    Representa una arista en el CFG.
    
    Una arista conecta dos bloques básicos y puede tener información
    adicional sobre el tipo de conexión.
    """
    
    def __init__(self, source: str, target: str, edge_type: str = "normal", 
                 condition: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None):
        self.source = source
        self.target = target
        self.edge_type = edge_type  # "normal", "true", "false", "exception", "break", "continue"
        self.condition = condition  # Condición para aristas condicionales
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte la arista a diccionario."""
        return {
            "source": self.source,
            "target": self.target,
            "type": self.edge_type,
            "condition": self.condition,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CFGEdge':
        """Crea una arista desde un diccionario."""
        return cls(
            source=data["source"],
            target=data["target"],
            edge_type=data.get("type", "normal"),
            condition=data.get("condition"),
            metadata=data.get("metadata", {})
        )
    
    def __str__(self) -> str:
        condition_str = f" ({self.condition})" if self.condition else ""
        return f"{self.source} -> {self.target} [{self.edge_type}]{condition_str}"
    
    def __repr__(self) -> str:
        return self.__str__()

class CFGBuilder:
    """
    Constructor de Control Flow Graph.
    
    Construye el CFG a partir de nodos IR, identificando bloques básicos
    y las conexiones entre ellos.
    """
    
    def __init__(self):
        self.block_counter = 0
        self.blocks: Dict[str, BasicBlock] = {}
        self.edges: List[CFGEdge] = []
        self.entry_block: Optional[str] = None
        self.exit_blocks: Set[str] = set()
    
    def _generate_block_id(self) -> str:
        """Genera un ID único para un bloque básico."""
        self.block_counter += 1
        return f"bb_{self.block_counter}"
    
    def create_block(self, block_id: Optional[str] = None) -> BasicBlock:
        """Crea un nuevo bloque básico."""
        if block_id is None:
            block_id = self._generate_block_id()
        
        block = BasicBlock(id=block_id)
        self.blocks[block_id] = block
        return block
    
    def add_edge(self, source_id: str, target_id: str, edge_type: str = "normal", 
                 condition: Optional[str] = None) -> CFGEdge:
        """Agrega una arista entre dos bloques."""
        edge = CFGEdge(source_id, target_id, edge_type, condition)
        self.edges.append(edge)
        
        # Actualizar predecesores y sucesores
        if source_id in self.blocks:
            self.blocks[source_id].add_successor(target_id)
        if target_id in self.blocks:
            self.blocks[target_id].add_predecessor(source_id)
        
        return edge
    
    def set_entry_block(self, block_id: str):
        """Establece el bloque de entrada."""
        self.entry_block = block_id
    
    def add_exit_block(self, block_id: str):
        """Agrega un bloque de salida."""
        self.exit_blocks.add(block_id)
    
    def get_block(self, block_id: str) -> Optional[BasicBlock]:
        """Obtiene un bloque por su ID."""
        return self.blocks.get(block_id)
    
    def get_entry_block(self) -> Optional[BasicBlock]:
        """Obtiene el bloque de entrada."""
        if self.entry_block:
            return self.blocks.get(self.entry_block)
        return None
    
    def get_exit_blocks(self) -> List[BasicBlock]:
        """Obtiene todos los bloques de salida."""
        return [self.blocks[block_id] for block_id in self.exit_blocks if block_id in self.blocks]
    
    def remove_empty_blocks(self):
        """Remueve bloques vacíos y reconecta el grafo."""
        empty_blocks = [block_id for block_id, block in self.blocks.items() if block.is_empty()]
        
        for block_id in empty_blocks:
            block = self.blocks[block_id]
            
            # Reconectar predecesores con sucesores
            for pred_id in block.predecessors:
                for succ_id in block.successors:
                    # Encontrar la arista original para preservar el tipo
                    edge_type = "normal"
                    condition = None
                    
                    for edge in self.edges:
                        if edge.source == block_id and edge.target == succ_id:
                            edge_type = edge.edge_type
                            condition = edge.condition
                            break
                    
                    self.add_edge(pred_id, succ_id, edge_type, condition)
            
            # Remover aristas que involucran el bloque vacío
            self.edges = [edge for edge in self.edges 
                         if edge.source != block_id and edge.target != block_id]
            
            # Actualizar entry y exit blocks
            if self.entry_block == block_id and block.successors:
                self.entry_block = next(iter(block.successors))
            
            if block_id in self.exit_blocks:
                self.exit_blocks.remove(block_id)
                self.exit_blocks.update(block.predecessors)
            
            # Remover el bloque
            del self.blocks[block_id]
    
    def optimize(self):
        """Optimiza el CFG removiendo bloques innecesarios."""
        self.remove_empty_blocks()
        self._merge_sequential_blocks()
    
    def _merge_sequential_blocks(self):
        """Fusiona bloques que se ejecutan secuencialmente."""
        merged = True
        while merged:
            merged = False
            
            for block_id, block in list(self.blocks.items()):
                # Un bloque puede fusionarse con su sucesor si:
                # 1. Tiene exactamente un sucesor
                # 2. Su sucesor tiene exactamente un predecesor
                # 3. No hay aristas condicionales
                
                if (len(block.successors) == 1 and 
                    not any(edge.edge_type != "normal" for edge in self.edges 
                           if edge.source == block_id)):
                    
                    successor_id = next(iter(block.successors))
                    successor = self.blocks.get(successor_id)
                    
                    if (successor and len(successor.predecessors) == 1 and
                        successor_id != self.entry_block):
                        
                        # Fusionar bloques
                        block.statements.extend(successor.statements)
                        block.successors = successor.successors
                        block.end_line = successor.end_line
                        
                        # Actualizar aristas
                        for edge in self.edges:
                            if edge.source == successor_id:
                                edge.source = block_id
                            if edge.target == successor_id:
                                edge.target = block_id
                        
                        # Actualizar predecesores/sucesores de otros bloques
                        for succ_id in successor.successors:
                            if succ_id in self.blocks:
                                self.blocks[succ_id].predecessors.discard(successor_id)
                                self.blocks[succ_id].predecessors.add(block_id)
                        
                        # Remover aristas del bloque fusionado
                        self.edges = [edge for edge in self.edges 
                                     if not (edge.source == block_id and edge.target == successor_id)]
                        
                        # Actualizar exit blocks
                        if successor_id in self.exit_blocks:
                            self.exit_blocks.remove(successor_id)
                            self.exit_blocks.add(block_id)
                        
                        # Remover el bloque fusionado
                        del self.blocks[successor_id]
                        merged = True
                        break
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el CFG a diccionario para serialización."""
        return {
            "entry_block": self.entry_block,
            "exit_blocks": list(self.exit_blocks),
            "blocks": {block_id: block.to_dict() for block_id, block in self.blocks.items()},
            "edges": [edge.to_dict() for edge in self.edges],
            "metadata": {
                "total_blocks": len(self.blocks),
                "total_edges": len(self.edges)
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CFGBuilder':
        """Crea un CFG desde un diccionario."""
        cfg = cls()
        
        cfg.entry_block = data.get("entry_block")
        cfg.exit_blocks = set(data.get("exit_blocks", []))
        
        # Cargar bloques
        for block_id, block_data in data.get("blocks", {}).items():
            cfg.blocks[block_id] = BasicBlock.from_dict(block_data)
        
        # Cargar aristas
        cfg.edges = [CFGEdge.from_dict(edge_data) for edge_data in data.get("edges", [])]
        
        return cfg
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del CFG."""
        return {
            "total_blocks": len(self.blocks),
            "total_edges": len(self.edges),
            "entry_block": self.entry_block,
            "exit_blocks": len(self.exit_blocks),
            "empty_blocks": sum(1 for block in self.blocks.values() if block.is_empty()),
            "max_statements_per_block": max((len(block.statements) for block in self.blocks.values()), default=0),
            "avg_statements_per_block": sum(len(block.statements) for block in self.blocks.values()) / len(self.blocks) if self.blocks else 0
        }
