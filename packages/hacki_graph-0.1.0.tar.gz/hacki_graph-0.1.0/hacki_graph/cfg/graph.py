"""
CFG Graph Container

Contiene y gestiona múltiples CFGs para un proyecto completo.
Proporciona funcionalidades para guardar, cargar y analizar CFGs.
"""

import logging
import json
from typing import Dict, List, Any, Optional
from pathlib import Path
from ..ir.base import IRFile
from .builder import FileCFGBuilder
from ..language_specs.base import LanguageSpec

logger = logging.getLogger(__name__)

class ProjectCFG:
    """
    Gestiona CFGs para un proyecto completo.
    
    Contiene CFGs para múltiples archivos y proporciona
    funcionalidades para análisis a nivel de proyecto.
    """
    
    def __init__(self):
        self.file_cfgs: Dict[str, FileCFGBuilder] = {}  # file_path -> FileCFGBuilder
        self.metadata: Dict[str, Any] = {}
    
    def add_file_cfg(self, file_path: str, file_cfg: FileCFGBuilder):
        """Agrega un CFG de archivo al proyecto."""
        self.file_cfgs[file_path] = file_cfg
        logger.debug(f"CFG agregado para archivo {file_path}")
    
    def get_file_cfg(self, file_path: str) -> Optional[FileCFGBuilder]:
        """Obtiene el CFG de un archivo específico."""
        return self.file_cfgs.get(file_path)
    
    def get_function_cfg(self, file_path: str, function_name: str):
        """Obtiene el CFG de una función específica."""
        file_cfg = self.get_file_cfg(file_path)
        if file_cfg:
            return file_cfg.function_cfgs.get(function_name)
        return None
    
    def get_all_functions(self) -> List[Dict[str, str]]:
        """Obtiene lista de todas las funciones con CFG."""
        functions = []
        
        for file_path, file_cfg in self.file_cfgs.items():
            for function_name in file_cfg.function_cfgs.keys():
                functions.append({
                    "file_path": file_path,
                    "function_name": function_name,
                    "id": f"{file_path}:{function_name}"
                })
        
        return functions
    
    def save_to_json(self, output_path: str) -> bool:
        """
        Guarda todos los CFGs en formato JSON.
        
        Args:
            output_path: Ruta del archivo JSON de salida
            
        Returns:
            True si se guardó correctamente
        """
        try:
            # Preparar datos para JSON
            json_data = {
                "metadata": {
                    "total_files": len(self.file_cfgs),
                    "total_functions": sum(len(file_cfg.function_cfgs) for file_cfg in self.file_cfgs.values()),
                    "total_blocks": sum(
                        sum(len(cfg.blocks) for cfg in file_cfg.function_cfgs.values())
                        for file_cfg in self.file_cfgs.values()
                    ),
                    "total_edges": sum(
                        sum(len(cfg.edges) for cfg in file_cfg.function_cfgs.values())
                        for file_cfg in self.file_cfgs.values()
                    )
                },
                "files": {}
            }
            
            # Agregar CFGs de archivos
            for file_path, file_cfg in self.file_cfgs.items():
                json_data["files"][file_path] = file_cfg.to_dict()
            
            # Guardar archivo
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"CFGs guardados en {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error guardando CFGs: {e}")
            return False
    
    def load_from_json(self, input_path: str, language_specs: Dict[str, LanguageSpec]) -> bool:
        """
        Carga CFGs desde un archivo JSON.
        
        Args:
            input_path: Ruta del archivo JSON
            language_specs: Diccionario de especificaciones de lenguajes
            
        Returns:
            True si se cargó correctamente
        """
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            
            self.file_cfgs.clear()
            self.metadata = json_data.get("metadata", {})
            
            # Cargar CFGs de archivos
            for file_path, file_data in json_data.get("files", {}).items():
                # Determinar lenguaje del archivo
                language_spec = self._get_language_spec_for_file(file_path, language_specs)
                if language_spec:
                    file_cfg = FileCFGBuilder.from_dict(file_data, language_spec)
                    self.file_cfgs[file_path] = file_cfg
            
            logger.info(f"CFGs cargados desde {input_path}: {len(self.file_cfgs)} archivos")
            return True
            
        except Exception as e:
            logger.error(f"Error cargando CFGs: {e}")
            return False
    
    def _get_language_spec_for_file(self, file_path: str, language_specs: Dict[str, LanguageSpec]) -> Optional[LanguageSpec]:
        """Determina la especificación de lenguaje para un archivo."""
        file_extension = Path(file_path).suffix.lower()
        
        for spec in language_specs.values():
            if file_extension in spec.file_extensions:
                return spec
        
        return None
    
    def get_project_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del proyecto completo."""
        total_functions = 0
        total_blocks = 0
        total_edges = 0
        language_stats = {}
        file_stats = {}
        
        for file_path, file_cfg in self.file_cfgs.items():
            stats = file_cfg.get_stats()
            file_stats[file_path] = stats
            
            total_functions += stats["total_functions"]
            total_blocks += stats["total_blocks"]
            total_edges += stats["total_edges"]
            
            # Estadísticas por lenguaje
            file_extension = Path(file_path).suffix.lower()
            if file_extension not in language_stats:
                language_stats[file_extension] = {
                    "files": 0,
                    "functions": 0,
                    "blocks": 0,
                    "edges": 0
                }
            
            language_stats[file_extension]["files"] += 1
            language_stats[file_extension]["functions"] += stats["total_functions"]
            language_stats[file_extension]["blocks"] += stats["total_blocks"]
            language_stats[file_extension]["edges"] += stats["total_edges"]
        
        return {
            "total_files": len(self.file_cfgs),
            "total_functions": total_functions,
            "total_blocks": total_blocks,
            "total_edges": total_edges,
            "avg_functions_per_file": total_functions / len(self.file_cfgs) if self.file_cfgs else 0,
            "avg_blocks_per_function": total_blocks / total_functions if total_functions else 0,
            "avg_edges_per_function": total_edges / total_functions if total_functions else 0,
            "languages": language_stats,
            "files": file_stats
        }
    
    def find_functions_with_complexity(self, min_blocks: int = 10) -> List[Dict[str, Any]]:
        """
        Encuentra funciones con alta complejidad ciclomática.
        
        Args:
            min_blocks: Número mínimo de bloques para considerar compleja
            
        Returns:
            Lista de funciones complejas con sus estadísticas
        """
        complex_functions = []
        
        for file_path, file_cfg in self.file_cfgs.items():
            for function_name, cfg in file_cfg.function_cfgs.items():
                stats = cfg.get_stats()
                
                if stats["total_blocks"] >= min_blocks:
                    complex_functions.append({
                        "file_path": file_path,
                        "function_name": function_name,
                        "blocks": stats["total_blocks"],
                        "edges": stats["total_edges"],
                        "cyclomatic_complexity": self._calculate_cyclomatic_complexity(cfg),
                        "max_statements_per_block": stats["max_statements_per_block"]
                    })
        
        # Ordenar por complejidad descendente
        complex_functions.sort(key=lambda x: x["cyclomatic_complexity"], reverse=True)
        return complex_functions
    
    def _calculate_cyclomatic_complexity(self, cfg) -> int:
        """
        Calcula la complejidad ciclomática de un CFG.
        
        Fórmula: M = E - N + 2P
        donde E = aristas, N = nodos, P = componentes conectados (normalmente 1)
        """
        edges = len(cfg.edges)
        nodes = len(cfg.blocks)
        components = 1  # Asumimos un componente conectado
        
        return edges - nodes + 2 * components
    
    def find_unreachable_blocks(self) -> List[Dict[str, Any]]:
        """Encuentra bloques inalcanzables en todos los CFGs."""
        unreachable = []
        
        for file_path, file_cfg in self.file_cfgs.items():
            for function_name, cfg in file_cfg.function_cfgs.items():
                # Encontrar bloques inalcanzables usando DFS desde entry
                reachable = set()
                if cfg.entry_block:
                    self._dfs_reachable(cfg, cfg.entry_block, reachable)
                
                for block_id, block in cfg.blocks.items():
                    if block_id not in reachable:
                        unreachable.append({
                            "file_path": file_path,
                            "function_name": function_name,
                            "block_id": block_id,
                            "statements": len(block.statements)
                        })
        
        return unreachable
    
    def _dfs_reachable(self, cfg, block_id: str, reachable: set):
        """DFS para encontrar bloques alcanzables."""
        if block_id in reachable or block_id not in cfg.blocks:
            return
        
        reachable.add(block_id)
        
        # Visitar sucesores
        block = cfg.blocks[block_id]
        for successor_id in block.successors:
            self._dfs_reachable(cfg, successor_id, reachable)
    
    def get_function_call_graph(self) -> Dict[str, List[str]]:
        """
        Construye un grafo de llamadas entre funciones.
        
        Returns:
            Diccionario con function_id -> [called_functions]
        """
        call_graph = {}
        
        for file_path, file_cfg in self.file_cfgs.items():
            for function_name, cfg in file_cfg.function_cfgs.items():
                function_id = f"{file_path}:{function_name}"
                calls = []
                
                # Buscar llamadas a funciones en los bloques
                for block in cfg.blocks.values():
                    for statement_id in block.statements:
                        # Aquí se necesitaría acceso a los nodos IR para determinar
                        # si un statement es una llamada a función
                        # Por simplicidad, se omite la implementación completa
                        pass
                
                call_graph[function_id] = calls
        
        return call_graph
