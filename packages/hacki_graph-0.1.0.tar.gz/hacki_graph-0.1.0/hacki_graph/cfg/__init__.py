"""
Control Flow Graph (CFG) Module

Contiene todas las clases y funcionalidades para construir y analizar
Control Flow Graphs a partir de código IR.
"""

from .basic_block import BasicBlock, CFGBuilder, CFGEdge
from .builder import FunctionCFGBuilder, FileCFGBuilder
from .graph import ProjectCFG

__all__ = [
    'BasicBlock',
    'CFGBuilder', 
    'CFGEdge',
    'FunctionCFGBuilder',
    'FileCFGBuilder',
    'ProjectCFG'
]
