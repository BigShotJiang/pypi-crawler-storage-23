"""
CFG Builder Implementation

Construye Control Flow Graphs (CFG) a partir de nodos IR.
Maneja la construcción de bloques básicos y las conexiones entre ellos
para diferentes estructuras de control.
"""

import logging
from typing import Dict, List, Any, Optional, Set, Tuple
from ..ir.base import IRFunction, IRFile
from ..ir.nodes import *
from .basic_block import BasicBlock, CFGBuilder, CFGEdge
from ..language_specs.base import LanguageSpec

logger = logging.getLogger(__name__)

class FunctionCFGBuilder:
    """
    Construye CFG para una función específica.
    
    Analiza los nodos IR de una función y construye el grafo de flujo de control
    correspondiente, manejando estructuras como if, while, for, try/catch, etc.
    """
    
    def __init__(self, language_spec: LanguageSpec):
        self.language_spec = language_spec
        self.cfg = CFGBuilder()
        self.current_block: Optional[BasicBlock] = None
        self.break_targets: List[str] = []  # Stack de objetivos para break
        self.continue_targets: List[str] = []  # Stack de objetivos para continue
        self.return_blocks: Set[str] = set()  # Bloques que contienen return
    
    def build_cfg_for_function(self, ir_function: IRFunction) -> CFGBuilder:
        """
        Construye el CFG para una función IR.
        
        Args:
            ir_function: Función IR a procesar
            
        Returns:
            CFGBuilder con el CFG construido
        """
        logger.debug(f"Construyendo CFG para función {ir_function.name}")
        
        # Reiniciar estado
        self.cfg = CFGBuilder()
        self.current_block = None
        self.break_targets.clear()
        self.continue_targets.clear()
        self.return_blocks.clear()
        
        if not ir_function.nodes:
            # Función vacía - crear bloque básico vacío
            entry_block = self.cfg.create_block("entry")
            self.cfg.set_entry_block(entry_block.id)
            self.cfg.add_exit_block(entry_block.id)
            return self.cfg
        
        # Crear bloque de entrada
        entry_block = self.cfg.create_block("entry")
        self.cfg.set_entry_block(entry_block.id)
        self.current_block = entry_block
        
        # Procesar nodos IR
        for node in ir_function.nodes:
            self._process_ir_node(node)
        
        # Finalizar CFG
        self._finalize_cfg()
        
        # Optimizar CFG
        self.cfg.optimize()
        
        logger.debug(f"CFG construido: {len(self.cfg.blocks)} bloques, {len(self.cfg.edges)} aristas")
        return self.cfg
    
    def _process_ir_node(self, node: IRNode):
        """Procesa un nodo IR individual."""
        if not self.current_block:
            return
        
        # Agregar el nodo al bloque actual
        self.current_block.add_statement(node.id)
        
        # Manejar estructuras de control
        if isinstance(node, If):
            self._handle_if_statement(node)
        elif isinstance(node, While):
            self._handle_while_statement(node)
        elif isinstance(node, For):
            self._handle_for_statement(node)
        elif isinstance(node, Return):
            self._handle_return_statement(node)
        elif isinstance(node, Break):
            self._handle_break_statement(node)
        elif isinstance(node, Continue):
            self._handle_continue_statement(node)
        # Para otros nodos (Assign, FunctionCall, etc.), continuar en el mismo bloque
    
    def _handle_if_statement(self, if_node: If):
        """Maneja una declaración if."""
        if not self.current_block:
            return
        
        # El bloque actual termina con la condición del if
        condition_block = self.current_block
        
        # Crear bloques para then y else
        then_block = self.cfg.create_block()
        else_block = self.cfg.create_block()
        merge_block = self.cfg.create_block()
        
        # Conectar condición con then y else
        self.cfg.add_edge(condition_block.id, then_block.id, "true", "if_true")
        self.cfg.add_edge(condition_block.id, else_block.id, "false", "if_false")
        
        # Procesar rama then (simulado - en implementación real se procesarían los nodos del then)
        self.cfg.add_edge(then_block.id, merge_block.id, "normal")
        
        # Procesar rama else (simulado)
        self.cfg.add_edge(else_block.id, merge_block.id, "normal")
        
        # Continuar desde el bloque de merge
        self.current_block = merge_block
    
    def _handle_while_statement(self, while_node: While):
        """Maneja una declaración while."""
        if not self.current_block:
            return
        
        # Crear bloques para el bucle
        loop_header = self.cfg.create_block()
        loop_body = self.cfg.create_block()
        loop_exit = self.cfg.create_block()
        
        # Conectar bloque actual con header del bucle
        self.cfg.add_edge(self.current_block.id, loop_header.id, "normal")
        
        # Header evalúa la condición
        loop_header.add_statement(while_node.id)
        
        # Conectar header con body y exit
        self.cfg.add_edge(loop_header.id, loop_body.id, "true", "while_true")
        self.cfg.add_edge(loop_header.id, loop_exit.id, "false", "while_false")
        
        # Body regresa al header
        self.cfg.add_edge(loop_body.id, loop_header.id, "normal")
        
        # Configurar objetivos para break/continue
        self.break_targets.append(loop_exit.id)
        self.continue_targets.append(loop_header.id)
        
        # Continuar desde el bloque de salida
        self.current_block = loop_exit
        
        # Limpiar objetivos
        if self.break_targets and self.break_targets[-1] == loop_exit.id:
            self.break_targets.pop()
        if self.continue_targets and self.continue_targets[-1] == loop_header.id:
            self.continue_targets.pop()
    
    def _handle_for_statement(self, for_node: For):
        """Maneja una declaración for."""
        if not self.current_block:
            return
        
        # Crear bloques para el bucle for
        init_block = self.current_block
        condition_block = self.cfg.create_block()
        body_block = self.cfg.create_block()
        update_block = self.cfg.create_block()
        exit_block = self.cfg.create_block()
        
        # Agregar inicialización al bloque actual
        if for_node.init:
            init_block.add_statement(for_node.init.id if hasattr(for_node.init, 'id') else str(for_node.init))
        
        # Conectar init con condition
        self.cfg.add_edge(init_block.id, condition_block.id, "normal")
        
        # Condition evalúa la condición del for
        if for_node.condition:
            condition_block.add_statement(for_node.condition.id if hasattr(for_node.condition, 'id') else str(for_node.condition))
        
        # Conectar condition con body y exit
        self.cfg.add_edge(condition_block.id, body_block.id, "true", "for_true")
        self.cfg.add_edge(condition_block.id, exit_block.id, "false", "for_false")
        
        # Body se conecta con update
        self.cfg.add_edge(body_block.id, update_block.id, "normal")
        
        # Update regresa a condition
        if for_node.update:
            update_block.add_statement(for_node.update.id if hasattr(for_node.update, 'id') else str(for_node.update))
        self.cfg.add_edge(update_block.id, condition_block.id, "normal")
        
        # Configurar objetivos para break/continue
        self.break_targets.append(exit_block.id)
        self.continue_targets.append(update_block.id)
        
        # Continuar desde el bloque de salida
        self.current_block = exit_block
        
        # Limpiar objetivos
        if self.break_targets and self.break_targets[-1] == exit_block.id:
            self.break_targets.pop()
        if self.continue_targets and self.continue_targets[-1] == update_block.id:
            self.continue_targets.pop()
    
    def _handle_return_statement(self, return_node: Return):
        """Maneja una declaración return."""
        if not self.current_block:
            return
        
        # Marcar el bloque actual como bloque de retorno
        self.return_blocks.add(self.current_block.id)
        self.cfg.add_exit_block(self.current_block.id)
        
        # Crear nuevo bloque para código después del return (si existe)
        # En la práctica, el código después de return es inalcanzable
        self.current_block = self.cfg.create_block()
    
    def _handle_break_statement(self, break_node: Break):
        """Maneja una declaración break."""
        if not self.current_block or not self.break_targets:
            return
        
        # Conectar con el objetivo de break más cercano
        target_block_id = self.break_targets[-1]
        self.cfg.add_edge(self.current_block.id, target_block_id, "break")
        
        # Crear nuevo bloque para código después del break
        self.current_block = self.cfg.create_block()
    
    def _handle_continue_statement(self, continue_node: Continue):
        """Maneja una declaración continue."""
        if not self.current_block or not self.continue_targets:
            return
        
        # Conectar con el objetivo de continue más cercano
        target_block_id = self.continue_targets[-1]
        self.cfg.add_edge(self.current_block.id, target_block_id, "continue")
        
        # Crear nuevo bloque para código después del continue
        self.current_block = self.cfg.create_block()
    
    def _finalize_cfg(self):
        """Finaliza la construcción del CFG."""
        # Si el bloque actual no es un bloque de retorno, marcarlo como exit
        if (self.current_block and 
            self.current_block.id not in self.return_blocks and
            not self.current_block.is_empty()):
            self.cfg.add_exit_block(self.current_block.id)
        
        # Si no hay bloques de salida explícitos, el último bloque es exit
        if not self.cfg.exit_blocks and self.current_block:
            self.cfg.add_exit_block(self.current_block.id)

class FileCFGBuilder:
    """
    Construye CFGs para todas las funciones de un archivo.
    """
    
    def __init__(self, language_spec: LanguageSpec):
        self.language_spec = language_spec
        self.function_cfgs: Dict[str, CFGBuilder] = {}
    
    def build_cfgs_for_file(self, ir_file: IRFile) -> Dict[str, CFGBuilder]:
        """
        Construye CFGs para todas las funciones de un archivo IR.
        
        Args:
            ir_file: Archivo IR a procesar
            
        Returns:
            Diccionario con function_name -> CFGBuilder
        """
        logger.info(f"Construyendo CFGs para archivo {ir_file.file_path}")
        
        self.function_cfgs.clear()
        
        # Construir CFG para cada función
        for function_name, ir_function in ir_file.functions.items():
            try:
                function_builder = FunctionCFGBuilder(self.language_spec)
                cfg = function_builder.build_cfg_for_function(ir_function)
                self.function_cfgs[function_name] = cfg
                
                logger.debug(f"CFG construido para función {function_name}: "
                           f"{len(cfg.blocks)} bloques")
                
            except Exception as e:
                logger.error(f"Error construyendo CFG para función {function_name}: {e}")
                continue
        
        # Construir CFG para código a nivel módulo si existe
        if ir_file.module_nodes:
            try:
                module_function = IRFunction(
                    name="<module>",
                    file_path=ir_file.file_path,
                    start_line=1,
                    end_line=1,
                    parameters=[],
                    return_type=None,
                    nodes=ir_file.module_nodes
                )
                
                function_builder = FunctionCFGBuilder(self.language_spec)
                cfg = function_builder.build_cfg_for_function(module_function)
                self.function_cfgs["<module>"] = cfg
                
                logger.debug(f"CFG construido para código módulo: {len(cfg.blocks)} bloques")
                
            except Exception as e:
                logger.error(f"Error construyendo CFG para código módulo: {e}")
        
        logger.info(f"CFGs construidos para {len(self.function_cfgs)} funciones")
        return self.function_cfgs
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte todos los CFGs a diccionario."""
        return {
            "functions": {
                function_name: cfg.to_dict() 
                for function_name, cfg in self.function_cfgs.items()
            },
            "metadata": {
                "total_functions": len(self.function_cfgs),
                "total_blocks": sum(len(cfg.blocks) for cfg in self.function_cfgs.values()),
                "total_edges": sum(len(cfg.edges) for cfg in self.function_cfgs.values())
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], language_spec: LanguageSpec) -> 'FileCFGBuilder':
        """Crea FileCFGBuilder desde un diccionario."""
        builder = cls(language_spec)
        
        for function_name, cfg_data in data.get("functions", {}).items():
            builder.function_cfgs[function_name] = CFGBuilder.from_dict(cfg_data)
        
        return builder
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas de todos los CFGs."""
        total_blocks = 0
        total_edges = 0
        function_stats = {}
        
        for function_name, cfg in self.function_cfgs.items():
            stats = cfg.get_stats()
            function_stats[function_name] = stats
            total_blocks += stats["total_blocks"]
            total_edges += stats["total_edges"]
        
        return {
            "total_functions": len(self.function_cfgs),
            "total_blocks": total_blocks,
            "total_edges": total_edges,
            "avg_blocks_per_function": total_blocks / len(self.function_cfgs) if self.function_cfgs else 0,
            "avg_edges_per_function": total_edges / len(self.function_cfgs) if self.function_cfgs else 0,
            "functions": function_stats
        }
