"""
Language Specification Base

Define las clases base para especificaciones de lenguajes.
Cada lenguaje debe implementar estas interfaces para soportar
análisis estático uniforme.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass

@dataclass
class FunctionInfo:
    """Información sobre una función extraída del AST."""
    name: str
    start_line: int
    end_line: int
    parameters: List[str]
    return_type: Optional[str] = None
    is_method: bool = False
    class_name: Optional[str] = None
    visibility: Optional[str] = None  # public, private, protected
    is_static: bool = False
    is_async: bool = False

@dataclass
class ControlStructure:
    """Información sobre una estructura de control."""
    type: str  # "if", "while", "for", "try", "switch"
    start_line: int
    end_line: int
    condition_node: Optional[Any] = None
    has_else: bool = False
    has_finally: bool = False

class LanguageSpec(ABC):
    """
    Especificación base para un lenguaje.
    
    Define la interfaz que debe implementar cada lenguaje
    para soportar análisis estático uniforme.
    """
    
    @property
    @abstractmethod
    def language_name(self) -> str:
        """Nombre del lenguaje."""
        pass
    
    @property
    @abstractmethod
    def file_extensions(self) -> Set[str]:
        """Extensiones de archivo soportadas."""
        pass
    
    @property
    @abstractmethod
    def tree_sitter_language(self) -> str:
        """Nombre del lenguaje en Tree-sitter."""
        pass
    
    # ========================================================================
    # EXTRACTION METHODS
    # ========================================================================
    
    @abstractmethod
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """
        Extrae información de todas las funciones del AST.
        
        Args:
            ast_tree: Árbol AST de Tree-sitter
            
        Returns:
            Lista de FunctionInfo
        """
        pass
    
    @abstractmethod
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        """
        Extrae estructuras de control de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de ControlStructure
        """
        pass
    
    @abstractmethod
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        """
        Extrae asignaciones de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de diccionarios con información de asignaciones
        """
        pass
    
    @abstractmethod
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        """
        Extrae llamadas a funciones de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de diccionarios con información de llamadas
        """
        pass
    
    @abstractmethod
    def extract_variable_references(self, node: Any) -> List[str]:
        """
        Extrae referencias a variables de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de nombres de variables
        """
        pass
    
    # ========================================================================
    # NORMALIZATION METHODS
    # ========================================================================
    
    @abstractmethod
    def normalize_identifier(self, identifier: str) -> str:
        """
        Normaliza un identificador según las reglas del lenguaje.
        
        Args:
            identifier: Identificador original
            
        Returns:
            Identificador normalizado
        """
        pass
    
    @abstractmethod
    def normalize_operator(self, operator: str) -> str:
        """
        Normaliza un operador a forma estándar.
        
        Args:
            operator: Operador original
            
        Returns:
            Operador normalizado
        """
        pass
    
    @abstractmethod
    def get_assignment_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores de asignación."""
        pass
    
    @abstractmethod
    def get_binary_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores binarios."""
        pass
    
    @abstractmethod
    def get_unary_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores unarios."""
        pass
    
    # ========================================================================
    # AST NODE TYPE METHODS
    # ========================================================================
    
    @abstractmethod
    def is_function_definition(self, node: Any) -> bool:
        """Verifica si un nodo es una definición de función."""
        pass
    
    @abstractmethod
    def is_class_definition(self, node: Any) -> bool:
        """Verifica si un nodo es una definición de clase."""
        pass
    
    @abstractmethod
    def is_assignment(self, node: Any) -> bool:
        """Verifica si un nodo es una asignación."""
        pass
    
    @abstractmethod
    def is_function_call(self, node: Any) -> bool:
        """Verifica si un nodo es una llamada a función."""
        pass
    
    @abstractmethod
    def is_control_flow(self, node: Any) -> bool:
        """Verifica si un nodo es una estructura de control de flujo."""
        pass
    
    @abstractmethod
    def is_loop(self, node: Any) -> bool:
        """Verifica si un nodo es un bucle."""
        pass
    
    @abstractmethod
    def is_conditional(self, node: Any) -> bool:
        """Verifica si un nodo es una estructura condicional."""
        pass
    
    @abstractmethod
    def is_return_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un return."""
        pass
    
    @abstractmethod
    def is_break_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un break."""
        pass
    
    @abstractmethod
    def is_continue_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un continue."""
        pass
    
    # ========================================================================
    # CFG BUILDING HELPERS
    # ========================================================================
    
    @abstractmethod
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        """
        Identifica las líneas que marcan límites de bloques básicos.
        
        Args:
            function_node: Nodo AST de la función
            
        Returns:
            Lista de números de línea que son límites de bloques
        """
        pass
    
    @abstractmethod
    def get_branch_targets(self, node: Any) -> List[int]:
        """
        Obtiene los objetivos de salto de una estructura de control.
        
        Args:
            node: Nodo AST de estructura de control
            
        Returns:
            Lista de líneas objetivo
        """
        pass
    
    @abstractmethod
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        """
        Extrae información detallada de un bucle.
        
        Args:
            node: Nodo AST del bucle
            
        Returns:
            Diccionario con información del bucle
        """
        pass
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_node_text(self, node: Any) -> str:
        """
        Obtiene el texto de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Texto del nodo
        """
        try:
            if hasattr(node, 'text'):
                return node.text.decode('utf-8')
            return str(node)
        except Exception:
            return ""
    
    def get_node_line(self, node: Any) -> int:
        """
        Obtiene el número de línea de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Número de línea (1-based)
        """
        try:
            if hasattr(node, 'start_point'):
                return node.start_point[0] + 1
            return 0
        except Exception:
            return 0
    
    def get_node_column(self, node: Any) -> int:
        """
        Obtiene el número de columna de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Número de columna (0-based)
        """
        try:
            if hasattr(node, 'start_point'):
                return node.start_point[1]
            return 0
        except Exception:
            return 0
    
    def find_nodes_by_type(self, root_node: Any, node_types: List[str]) -> List[Any]:
        """
        Encuentra todos los nodos de tipos específicos en un árbol.
        
        Args:
            root_node: Nodo raíz del árbol
            node_types: Lista de tipos de nodo a buscar
            
        Returns:
            Lista de nodos encontrados
        """
        found_nodes = []
        
        def traverse(node):
            if hasattr(node, 'type') and node.type in node_types:
                found_nodes.append(node)
            
            if hasattr(node, 'children'):
                for child in node.children:
                    traverse(child)
        
        traverse(root_node)
        return found_nodes
    
    def get_function_body_nodes(self, function_node: Any) -> List[Any]:
        """
        Obtiene todos los nodos del cuerpo de una función.
        
        Args:
            function_node: Nodo AST de la función
            
        Returns:
            Lista de nodos del cuerpo
        """
        # Implementación por defecto - cada lenguaje puede sobrescribir
        body_nodes = []
        
        def traverse(node):
            if hasattr(node, 'children'):
                for child in node.children:
                    body_nodes.append(child)
                    traverse(child)
        
        traverse(function_node)
        return body_nodes


# Registry global para las especificaciones de lenguajes
_language_registry: Dict[str, LanguageSpec] = {}


def register_language(extensions: List[str], spec: LanguageSpec):
    """
    Registra una especificación de lenguaje para las extensiones dadas.
    
    Args:
        extensions: Lista de extensiones de archivo (ej: ['.py', '.pyw'])
        spec: Instancia de LanguageSpec
    """
    for ext in extensions:
        _language_registry[ext.lower()] = spec


def get_language_registry() -> Dict[str, LanguageSpec]:
    """
    Obtiene el registry completo de especificaciones de lenguajes.
    
    Returns:
        Diccionario con extensiones como claves y LanguageSpec como valores
    """
    return _language_registry.copy()


def get_language_spec(file_extension: str) -> Optional[LanguageSpec]:
    """
    Obtiene la especificación de lenguaje para una extensión de archivo.
    
    Args:
        file_extension: Extensión del archivo (ej: '.py')
        
    Returns:
        LanguageSpec si está registrada, None en caso contrario
    """
    return _language_registry.get(file_extension.lower())
    """
    Especificación base para un lenguaje.
    
    Define la interfaz que debe implementar cada lenguaje
    para soportar análisis estático uniforme.
    """
    
    @property
    @abstractmethod
    def language_name(self) -> str:
        """Nombre del lenguaje."""
        pass
    
    @property
    @abstractmethod
    def file_extensions(self) -> Set[str]:
        """Extensiones de archivo soportadas."""
        pass
    
    @property
    @abstractmethod
    def tree_sitter_language(self) -> str:
        """Nombre del lenguaje en Tree-sitter."""
        pass
    
    # ========================================================================
    # EXTRACTION METHODS
    # ========================================================================
    
    @abstractmethod
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """
        Extrae información de todas las funciones del AST.
        
        Args:
            ast_tree: Árbol AST de Tree-sitter
            
        Returns:
            Lista de FunctionInfo
        """
        pass
    
    @abstractmethod
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        """
        Extrae estructuras de control de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de ControlStructure
        """
        pass
    
    @abstractmethod
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        """
        Extrae asignaciones de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de diccionarios con información de asignaciones
        """
        pass
    
    @abstractmethod
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        """
        Extrae llamadas a funciones de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de diccionarios con información de llamadas
        """
        pass
    
    @abstractmethod
    def extract_variable_references(self, node: Any) -> List[str]:
        """
        Extrae referencias a variables de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Lista de nombres de variables
        """
        pass
    
    # ========================================================================
    # NORMALIZATION METHODS
    # ========================================================================
    
    @abstractmethod
    def normalize_identifier(self, identifier: str) -> str:
        """
        Normaliza un identificador según las reglas del lenguaje.
        
        Args:
            identifier: Identificador original
            
        Returns:
            Identificador normalizado
        """
        pass
    
    @abstractmethod
    def normalize_operator(self, operator: str) -> str:
        """
        Normaliza un operador a forma estándar.
        
        Args:
            operator: Operador original
            
        Returns:
            Operador normalizado
        """
        pass
    
    @abstractmethod
    def get_assignment_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores de asignación."""
        pass
    
    @abstractmethod
    def get_binary_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores binarios."""
        pass
    
    @abstractmethod
    def get_unary_operators(self) -> Set[str]:
        """Retorna el conjunto de operadores unarios."""
        pass
    
    # ========================================================================
    # AST NODE TYPE METHODS
    # ========================================================================
    
    @abstractmethod
    def is_function_definition(self, node: Any) -> bool:
        """Verifica si un nodo es una definición de función."""
        pass
    
    @abstractmethod
    def is_class_definition(self, node: Any) -> bool:
        """Verifica si un nodo es una definición de clase."""
        pass
    
    @abstractmethod
    def is_assignment(self, node: Any) -> bool:
        """Verifica si un nodo es una asignación."""
        pass
    
    @abstractmethod
    def is_function_call(self, node: Any) -> bool:
        """Verifica si un nodo es una llamada a función."""
        pass
    
    @abstractmethod
    def is_control_flow(self, node: Any) -> bool:
        """Verifica si un nodo es una estructura de control de flujo."""
        pass
    
    @abstractmethod
    def is_loop(self, node: Any) -> bool:
        """Verifica si un nodo es un bucle."""
        pass
    
    @abstractmethod
    def is_conditional(self, node: Any) -> bool:
        """Verifica si un nodo es una estructura condicional."""
        pass
    
    @abstractmethod
    def is_return_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un return."""
        pass
    
    @abstractmethod
    def is_break_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un break."""
        pass
    
    @abstractmethod
    def is_continue_statement(self, node: Any) -> bool:
        """Verifica si un nodo es un continue."""
        pass
    
    # ========================================================================
    # CFG BUILDING HELPERS
    # ========================================================================
    
    @abstractmethod
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        """
        Identifica las líneas que marcan límites de bloques básicos.
        
        Args:
            function_node: Nodo AST de la función
            
        Returns:
            Lista de números de línea que son límites de bloques
        """
        pass
    
    @abstractmethod
    def get_branch_targets(self, node: Any) -> List[int]:
        """
        Obtiene los objetivos de salto de una estructura de control.
        
        Args:
            node: Nodo AST de estructura de control
            
        Returns:
            Lista de líneas objetivo
        """
        pass
    
    @abstractmethod
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        """
        Extrae información detallada de un bucle.
        
        Args:
            node: Nodo AST del bucle
            
        Returns:
            Diccionario con información del bucle
        """
        pass
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_node_text(self, node: Any) -> str:
        """
        Obtiene el texto de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Texto del nodo
        """
        try:
            if hasattr(node, 'text'):
                return node.text.decode('utf-8')
            return str(node)
        except Exception:
            return ""
    
    def get_node_line(self, node: Any) -> int:
        """
        Obtiene el número de línea de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Número de línea (1-based)
        """
        try:
            if hasattr(node, 'start_point'):
                return node.start_point[0] + 1
            return 0
        except Exception:
            return 0
    
    def get_node_column(self, node: Any) -> int:
        """
        Obtiene el número de columna de un nodo AST.
        
        Args:
            node: Nodo AST
            
        Returns:
            Número de columna (0-based)
        """
        try:
            if hasattr(node, 'start_point'):
                return node.start_point[1]
            return 0
        except Exception:
            return 0
    
    def find_nodes_by_type(self, root_node: Any, node_types: List[str]) -> List[Any]:
        """
        Encuentra todos los nodos de tipos específicos en un árbol.
        
        Args:
            root_node: Nodo raíz del árbol
            node_types: Lista de tipos de nodo a buscar
            
        Returns:
            Lista de nodos encontrados
        """
        found_nodes = []
        
        def traverse(node):
            if hasattr(node, 'type') and node.type in node_types:
                found_nodes.append(node)
            
            if hasattr(node, 'children'):
                for child in node.children:
                    traverse(child)
        
        traverse(root_node)
        return found_nodes
    
    def get_function_body_nodes(self, function_node: Any) -> List[Any]:
        """
        Obtiene todos los nodos del cuerpo de una función.
        
        Args:
            function_node: Nodo AST de la función
            
        Returns:
            Lista de nodos del cuerpo
        """
        # Implementación por defecto - cada lenguaje puede sobrescribir
        body_nodes = []
        
        def traverse(node):
            if hasattr(node, 'children'):
                for child in node.children:
                    body_nodes.append(child)
                    traverse(child)
        
        traverse(function_node)
        return body_nodes
