"""
Java Language Specification and IR Builder

Implementa soporte básico para Java.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from ..ir.base import IRBuilder, IRFile, IRFunction
from ..ir.nodes import *
from .base import LanguageSpec, FunctionInfo, ControlStructure

logger = logging.getLogger(__name__)

class JavaLanguageSpec(LanguageSpec):
    """Especificación del lenguaje Java."""
    
    @property
    def language_name(self) -> str:
        return "java"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".java"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "java"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """Extrae funciones del AST de Java."""
        functions = []
        
        function_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "method_declaration", 
            "constructor_declaration"
        ])
        
        for node in function_nodes:
            try:
                name = self._extract_java_function_name(node)
                if name:
                    functions.append(FunctionInfo(
                        name=name,
                        start_line=self.get_node_line(node),
                        end_line=node.end_point[0] + 1 if hasattr(node, 'end_point') else self.get_node_line(node),
                        parameters=self._extract_java_parameters(node),
                        is_method=True
                    ))
            except Exception as e:
                logger.warning(f"Error extrayendo función Java: {e}")
        
        return functions
    
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        """Extrae estructuras de control de Java."""
        structures = []
        
        control_types = {
            "if_statement": "if",
            "while_statement": "while",
            "for_statement": "for",
            "enhanced_for_statement": "for_each",
            "try_statement": "try",
            "switch_expression": "switch"
        }
        
        for child in node.children if hasattr(node, 'children') else []:
            if child.type in control_types:
                structures.append(ControlStructure(
                    type=control_types[child.type],
                    start_line=self.get_node_line(child),
                    end_line=child.end_point[0] + 1 if hasattr(child, 'end_point') else self.get_node_line(child)
                ))
            structures.extend(self.extract_control_structures(child))
        
        return structures
    
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae asignaciones de Java."""
        assignments = []
        
        if node.type == "assignment_expression":
            try:
                children = list(node.children)
                if len(children) >= 3:
                    target = self.get_node_text(children[0])
                    value = children[2]
                    assignments.append({
                        "target": target,
                        "value": value,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo asignación Java: {e}")
        
        if hasattr(node, 'children'):
            for child in node.children:
                assignments.extend(self.extract_assignments(child))
        
        return assignments
    
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae llamadas a funciones de Java."""
        calls = []
        
        if node.type == "method_invocation":
            try:
                function_name = ""
                arguments = []
                
                for child in node.children:
                    if child.type == "identifier":
                        function_name = self.get_node_text(child)
                    elif child.type == "argument_list":
                        arguments = [arg for arg in child.children if arg.type != ","]
                
                if function_name:
                    calls.append({
                        "function": function_name,
                        "arguments": arguments,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo llamada Java: {e}")
        
        if hasattr(node, 'children'):
            for child in node.children:
                calls.extend(self.extract_function_calls(child))
        
        return calls
    
    def extract_variable_references(self, node: Any) -> List[str]:
        """Extrae referencias a variables de Java."""
        variables = []
        
        if node.type == "identifier":
            var_name = self.get_node_text(node)
            if var_name and not self._is_java_keyword(var_name):
                variables.append(var_name)
        
        if hasattr(node, 'children'):
            for child in node.children:
                variables.extend(self.extract_variable_references(child))
        
        return variables
    
    def normalize_identifier(self, identifier: str) -> str:
        return identifier.strip()
    
    def normalize_operator(self, operator: str) -> str:
        return operator
    
    def get_assignment_operators(self) -> Set[str]:
        return {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=", ">>>="}
    
    def get_binary_operators(self) -> Set[str]:
        return {"+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>", ">>>",
                "==", "!=", "<", ">", "<=", ">=", "&&", "||", "instanceof"}
    
    def get_unary_operators(self) -> Set[str]:
        return {"!", "-", "+", "~", "++", "--"}
    
    # Node type checking methods
    def is_function_definition(self, node: Any) -> bool:
        return node.type in ["method_declaration", "constructor_declaration"]
    
    def is_class_definition(self, node: Any) -> bool:
        return node.type == "class_declaration"
    
    def is_assignment(self, node: Any) -> bool:
        return node.type == "assignment_expression"
    
    def is_function_call(self, node: Any) -> bool:
        return node.type == "method_invocation"
    
    def is_control_flow(self, node: Any) -> bool:
        return node.type in ["if_statement", "while_statement", "for_statement", 
                           "enhanced_for_statement", "try_statement", "switch_expression"]
    
    def is_loop(self, node: Any) -> bool:
        return node.type in ["while_statement", "for_statement", "enhanced_for_statement"]
    
    def is_conditional(self, node: Any) -> bool:
        return node.type == "if_statement"
    
    def is_return_statement(self, node: Any) -> bool:
        return node.type == "return_statement"
    
    def is_break_statement(self, node: Any) -> bool:
        return node.type == "break_statement"
    
    def is_continue_statement(self, node: Any) -> bool:
        return node.type == "continue_statement"
    
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        boundaries = [self.get_node_line(function_node)]
        
        control_nodes = self.find_nodes_by_type(function_node, [
            "if_statement", "while_statement", "for_statement", "enhanced_for_statement",
            "try_statement", "switch_expression", "return_statement", "break_statement", "continue_statement"
        ])
        
        for node in control_nodes:
            boundaries.append(self.get_node_line(node))
        
        return sorted(list(set(boundaries)))
    
    def get_branch_targets(self, node: Any) -> List[int]:
        return []
    
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        return {
            "type": node.type,
            "line": self.get_node_line(node)
        }
    
    # Helper methods
    def _extract_java_function_name(self, node: Any) -> Optional[str]:
        """Extrae el nombre de una función Java."""
        for child in node.children:
            if child.type == "identifier":
                return self.get_node_text(child)
        return None
    
    def _extract_java_parameters(self, node: Any) -> List[str]:
        """Extrae parámetros de una función Java."""
        parameters = []
        
        for child in node.children:
            if child.type == "formal_parameters":
                for param in child.children:
                    if param.type == "formal_parameter":
                        for grandchild in param.children:
                            if grandchild.type == "identifier":
                                parameters.append(self.get_node_text(grandchild))
                                break
                break
        
        return parameters
    
    def _is_java_keyword(self, identifier: str) -> bool:
        """Verifica si un identificador es una palabra clave de Java."""
        java_keywords = {
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
            "class", "const", "continue", "default", "do", "double", "else", "enum",
            "extends", "final", "finally", "float", "for", "goto", "if", "implements",
            "import", "instanceof", "int", "interface", "long", "native", "new", "package",
            "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient",
            "try", "void", "volatile", "while"
        }
        return identifier in java_keywords

class JavaIRBuilder(IRBuilder):
    """Constructor de IR para Java."""
    
    def __init__(self, language: str = "java"):
        super().__init__(language)
        self.spec = JavaLanguageSpec()
    
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        """Construye IR desde AST de Java."""
        ir_file = IRFile(file_path=file_path, language=self.language)
        
        functions_info = self.spec.extract_functions(ast_tree)
        
        for func_info in functions_info:
            function_nodes = self.spec.find_nodes_by_type(ast_tree.root_node, [
                "method_declaration", "constructor_declaration"
            ])
            
            function_node = None
            for node in function_nodes:
                if self.spec.get_node_line(node) == func_info.start_line:
                    function_node = node
                    break
            
            if function_node:
                ir_function = IRFunction(
                    name=func_info.name,
                    file_path=file_path,
                    start_line=func_info.start_line,
                    end_line=func_info.end_line,
                    parameters=func_info.parameters,
                    return_type=func_info.return_type
                )
                ir_file.functions[func_info.name] = ir_function
        
        return ir_file
    
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        functions_info = self.spec.extract_functions(ast_tree)
        return [
            {
                "name": func.name,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "parameters": func.parameters,
                "is_method": func.is_method
            }
            for func in functions_info
        ]
    
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte un nodo AST de Java a IR."""
        # Implementación básica - se puede expandir
        return None
