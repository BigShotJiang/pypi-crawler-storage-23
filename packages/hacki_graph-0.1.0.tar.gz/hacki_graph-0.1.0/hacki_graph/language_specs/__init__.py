"""
Language Specifications

Contiene las especificaciones e IR builders para todos los lenguajes soportados.
"""

from .base import LanguageSpec, FunctionInfo, ControlStructure, get_language_registry, register_language, get_language_spec
from .python import PythonLanguageSpec, PythonIRBuilder

# Registrar lenguajes soportados
register_language(['.py', '.pyw'], PythonLanguageSpec())

__all__ = [
    'LanguageSpec',
    'FunctionInfo', 
    'ControlStructure',
    'PythonLanguageSpec',
    'PythonIRBuilder',
    'get_language_registry',
    'register_language',
    'get_language_spec'
]
