"""
C# Language Specification and IR Builder

Implementa soporte básico para C#.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from ..ir.base import IRBuilder, IRFile, IRFunction
from ..ir.nodes import *
from .base import LanguageSpec, FunctionInfo, ControlStructure

logger = logging.getLogger(__name__)

class CSharpLanguageSpec(LanguageSpec):
    """Especificación del lenguaje C#."""
    
    @property
    def language_name(self) -> str:
        return "csharp"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".cs"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "c_sharp"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        functions = []
        
        function_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "method_declaration", 
            "constructor_declaration"
        ])
        
        for node in function_nodes:
            try:
                name = self._extract_csharp_function_name(node)
                if name:
                    functions.append(FunctionInfo(
                        name=name,
                        start_line=self.get_node_line(node),
                        end_line=node.end_point[0] + 1 if hasattr(node, 'end_point') else self.get_node_line(node),
                        parameters=self._extract_csharp_parameters(node),
                        is_method=True
                    ))
            except Exception as e:
                logger.warning(f"Error extrayendo función C#: {e}")
        
        return functions
    
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        return []  # Implementación básica
    
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        return []  # Implementación básica
    
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        return []  # Implementación básica
    
    def extract_variable_references(self, node: Any) -> List[str]:
        return []  # Implementación básica
    
    def normalize_identifier(self, identifier: str) -> str:
        return identifier.strip()
    
    def normalize_operator(self, operator: str) -> str:
        return operator
    
    def get_assignment_operators(self) -> Set[str]:
        return {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>="}
    
    def get_binary_operators(self) -> Set[str]:
        return {"+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>",
                "==", "!=", "<", ">", "<=", ">=", "&&", "||", "is", "as"}
    
    def get_unary_operators(self) -> Set[str]:
        return {"!", "-", "+", "~", "++", "--", "typeof", "sizeof"}
    
    def is_function_definition(self, node: Any) -> bool:
        return node.type in ["method_declaration", "constructor_declaration"]
    
    def is_class_definition(self, node: Any) -> bool:
        return node.type == "class_declaration"
    
    def is_assignment(self, node: Any) -> bool:
        return node.type == "assignment_expression"
    
    def is_function_call(self, node: Any) -> bool:
        return node.type == "invocation_expression"
    
    def is_control_flow(self, node: Any) -> bool:
        return node.type in ["if_statement", "while_statement", "for_statement", "foreach_statement"]
    
    def is_loop(self, node: Any) -> bool:
        return node.type in ["while_statement", "for_statement", "foreach_statement"]
    
    def is_conditional(self, node: Any) -> bool:
        return node.type == "if_statement"
    
    def is_return_statement(self, node: Any) -> bool:
        return node.type == "return_statement"
    
    def is_break_statement(self, node: Any) -> bool:
        return node.type == "break_statement"
    
    def is_continue_statement(self, node: Any) -> bool:
        return node.type == "continue_statement"
    
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        return [self.get_node_line(function_node)]
    
    def get_branch_targets(self, node: Any) -> List[int]:
        return []
    
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        return {"type": node.type, "line": self.get_node_line(node)}
    
    def _extract_csharp_function_name(self, node: Any) -> Optional[str]:
        for child in node.children:
            if child.type == "identifier":
                return self.get_node_text(child)
        return None
    
    def _extract_csharp_parameters(self, node: Any) -> List[str]:
        return []  # Implementación básica

class CSharpIRBuilder(IRBuilder):
    """Constructor de IR para C#."""
    
    def __init__(self, language: str = "csharp"):
        super().__init__(language)
        self.spec = CSharpLanguageSpec()
    
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        ir_file = IRFile(file_path=file_path, language=self.language)
        
        functions_info = self.spec.extract_functions(ast_tree)
        
        for func_info in functions_info:
            ir_function = IRFunction(
                name=func_info.name,
                file_path=file_path,
                start_line=func_info.start_line,
                end_line=func_info.end_line,
                parameters=func_info.parameters,
                return_type=func_info.return_type
            )
            ir_file.functions[func_info.name] = ir_function
        
        return ir_file
    
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        functions_info = self.spec.extract_functions(ast_tree)
        return [
            {
                "name": func.name,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "parameters": func.parameters
            }
            for func in functions_info
        ]
    
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        return None  # Implementación básica
