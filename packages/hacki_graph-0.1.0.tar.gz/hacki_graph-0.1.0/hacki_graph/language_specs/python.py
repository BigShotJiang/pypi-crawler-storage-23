"""
Python Language Specification and IR Builder

Implementa el soporte completo para Python en el sistema de análisis estático.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from ..ir.base import IRBuilder, IRFile, IRFunction
from ..ir.nodes import *
from .base import LanguageSpec, FunctionInfo, ControlStructure

logger = logging.getLogger(__name__)

class PythonLanguageSpec(LanguageSpec):
    """Especificación del lenguaje Python."""
    
    @property
    def language_name(self) -> str:
        return "python"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".py", ".pyx", ".pyi"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "python"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """Extrae funciones del AST de Python."""
        functions = []
        
        # Buscar definiciones de función
        function_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "function_definition", 
            "async_function_definition"
        ])
        
        for node in function_nodes:
            try:
                # Extraer nombre de la función
                name_node = None
                for child in node.children:
                    if child.type == "identifier":
                        name_node = child
                        break
                
                if not name_node:
                    continue
                
                name = self.get_node_text(name_node)
                start_line = self.get_node_line(node)
                end_line = node.end_point[0] + 1 if hasattr(node, 'end_point') else start_line
                
                # Extraer parámetros
                parameters = []
                for child in node.children:
                    if child.type == "parameters":
                        parameters = self._extract_parameters(child)
                        break
                
                # Determinar si es método (dentro de una clase)
                is_method = self._is_inside_class(node)
                class_name = self._get_containing_class_name(node) if is_method else None
                
                # Determinar si es async
                is_async = node.type == "async_function_definition"
                
                functions.append(FunctionInfo(
                    name=name,
                    start_line=start_line,
                    end_line=end_line,
                    parameters=parameters,
                    is_method=is_method,
                    class_name=class_name,
                    is_async=is_async
                ))
                
            except Exception as e:
                logger.warning(f"Error extrayendo función Python: {e}")
                continue
        
        return functions
    
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        """Extrae estructuras de control de Python."""
        structures = []
        
        control_types = {
            "if_statement": "if",
            "while_statement": "while", 
            "for_statement": "for",
            "try_statement": "try",
            "with_statement": "with"
        }
        
        for child in node.children if hasattr(node, 'children') else []:
            if child.type in control_types:
                structure_type = control_types[child.type]
                start_line = self.get_node_line(child)
                end_line = child.end_point[0] + 1 if hasattr(child, 'end_point') else start_line
                
                # Buscar condición
                condition_node = None
                has_else = False
                has_finally = False
                
                for grandchild in child.children:
                    if grandchild.type in ["condition", "expression"]:
                        condition_node = grandchild
                    elif grandchild.type == "else_clause":
                        has_else = True
                    elif grandchild.type == "finally_clause":
                        has_finally = True
                
                structures.append(ControlStructure(
                    type=structure_type,
                    start_line=start_line,
                    end_line=end_line,
                    condition_node=condition_node,
                    has_else=has_else,
                    has_finally=has_finally
                ))
            
            # Recursión
            structures.extend(self.extract_control_structures(child))
        
        return structures
    
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae asignaciones de Python."""
        assignments = []
        
        if node.type == "assignment":
            try:
                # Obtener target y value
                target = None
                value = None
                
                for child in node.children:
                    if child.type == "identifier" and target is None:
                        target = self.get_node_text(child)
                    elif child.type not in ["=", "identifier"] and target is not None:
                        value = child
                        break
                
                if target and value:
                    assignments.append({
                        "target": target,
                        "value": value,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo asignación Python: {e}")
        
        # Recursión
        if hasattr(node, 'children'):
            for child in node.children:
                assignments.extend(self.extract_assignments(child))
        
        return assignments
    
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae llamadas a funciones de Python."""
        calls = []
        
        if node.type == "call":
            try:
                # Obtener función y argumentos
                function_name = None
                arguments = []
                
                for child in node.children:
                    if child.type == "identifier":
                        function_name = self.get_node_text(child)
                    elif child.type == "attribute":
                        function_name = self.get_node_text(child)
                    elif child.type == "argument_list":
                        arguments = [arg for arg in child.children if arg.type != ","]
                
                if function_name:
                    calls.append({
                        "function": function_name,
                        "arguments": arguments,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo llamada Python: {e}")
        
        # Recursión
        if hasattr(node, 'children'):
            for child in node.children:
                calls.extend(self.extract_function_calls(child))
        
        return calls
    
    def extract_variable_references(self, node: Any) -> List[str]:
        """Extrae referencias a variables de Python."""
        variables = []
        
        if node.type == "identifier":
            var_name = self.get_node_text(node)
            if var_name and not self._is_keyword(var_name):
                variables.append(var_name)
        
        # Recursión
        if hasattr(node, 'children'):
            for child in node.children:
                variables.extend(self.extract_variable_references(child))
        
        return variables
    
    def normalize_identifier(self, identifier: str) -> str:
        """Normaliza identificadores Python."""
        return identifier.strip()
    
    def normalize_operator(self, operator: str) -> str:
        """Normaliza operadores Python."""
        operator_map = {
            "and": "&&",
            "or": "||",
            "not": "!",
            "is": "==",
            "is not": "!=",
            "in": "contains"
        }
        return operator_map.get(operator, operator)
    
    def get_assignment_operators(self) -> Set[str]:
        return {"=", "+=", "-=", "*=", "/=", "//=", "%=", "**=", "&=", "|=", "^=", "<<=", ">>="}
    
    def get_binary_operators(self) -> Set[str]:
        return {"+", "-", "*", "/", "//", "%", "**", "&", "|", "^", "<<", ">>", 
                "==", "!=", "<", ">", "<=", ">=", "and", "or", "in", "not in", "is", "is not"}
    
    def get_unary_operators(self) -> Set[str]:
        return {"not", "-", "+", "~"}
    
    # Node type checking methods
    def is_function_definition(self, node: Any) -> bool:
        return node.type in ["function_definition", "async_function_definition"]
    
    def is_class_definition(self, node: Any) -> bool:
        return node.type == "class_definition"
    
    def is_assignment(self, node: Any) -> bool:
        return node.type == "assignment"
    
    def is_function_call(self, node: Any) -> bool:
        return node.type == "call"
    
    def is_control_flow(self, node: Any) -> bool:
        return node.type in ["if_statement", "while_statement", "for_statement", 
                           "try_statement", "with_statement", "match_statement"]
    
    def is_loop(self, node: Any) -> bool:
        return node.type in ["while_statement", "for_statement"]
    
    def is_conditional(self, node: Any) -> bool:
        return node.type in ["if_statement", "conditional_expression"]
    
    def is_return_statement(self, node: Any) -> bool:
        return node.type == "return_statement"
    
    def is_break_statement(self, node: Any) -> bool:
        return node.type == "break_statement"
    
    def is_continue_statement(self, node: Any) -> bool:
        return node.type == "continue_statement"
    
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        """Identifica límites de bloques básicos en Python."""
        boundaries = []
        
        # Inicio de la función
        boundaries.append(self.get_node_line(function_node))
        
        # Buscar estructuras de control
        control_nodes = self.find_nodes_by_type(function_node, [
            "if_statement", "while_statement", "for_statement", "try_statement",
            "return_statement", "break_statement", "continue_statement"
        ])
        
        for node in control_nodes:
            boundaries.append(self.get_node_line(node))
            
            # Agregar líneas de else, elif, except, finally
            for child in node.children if hasattr(node, 'children') else []:
                if child.type in ["else_clause", "elif_clause", "except_clause", "finally_clause"]:
                    boundaries.append(self.get_node_line(child))
        
        return sorted(list(set(boundaries)))
    
    def get_branch_targets(self, node: Any) -> List[int]:
        """Obtiene objetivos de salto para estructuras de control Python."""
        targets = []
        
        if node.type == "if_statement":
            # Objetivo del then
            for child in node.children:
                if child.type == "block":
                    targets.append(self.get_node_line(child))
                    break
            
            # Objetivo del else
            for child in node.children:
                if child.type == "else_clause":
                    targets.append(self.get_node_line(child))
                    break
        
        elif node.type in ["while_statement", "for_statement"]:
            # Objetivo del cuerpo del bucle
            for child in node.children:
                if child.type == "block":
                    targets.append(self.get_node_line(child))
                    break
        
        return targets
    
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        """Extrae información de bucles Python."""
        info = {
            "type": node.type,
            "line": self.get_node_line(node)
        }
        
        if node.type == "for_statement":
            # Extraer variable iteradora y objeto iterable
            for child in node.children:
                if child.type == "identifier":
                    info["iterator"] = self.get_node_text(child)
                elif child.type == "expression":
                    info["iterable"] = self.get_node_text(child)
        
        elif node.type == "while_statement":
            # Extraer condición
            for child in node.children:
                if child.type == "expression":
                    info["condition"] = self.get_node_text(child)
                    break
        
        return info
    
    # Helper methods
    def _extract_parameters(self, params_node: Any) -> List[str]:
        """Extrae parámetros de un nodo de parámetros."""
        parameters = []
        
        for child in params_node.children:
            if child.type == "identifier":
                parameters.append(self.get_node_text(child))
            elif child.type == "typed_parameter":
                # Buscar el identificador dentro del parámetro tipado
                for grandchild in child.children:
                    if grandchild.type == "identifier":
                        parameters.append(self.get_node_text(grandchild))
                        break
        
        return parameters
    
    def _is_inside_class(self, node: Any) -> bool:
        """Verifica si un nodo está dentro de una clase."""
        current = node.parent if hasattr(node, 'parent') else None
        while current:
            if current.type == "class_definition":
                return True
            current = current.parent if hasattr(current, 'parent') else None
        return False
    
    def _get_containing_class_name(self, node: Any) -> Optional[str]:
        """Obtiene el nombre de la clase que contiene un nodo."""
        current = node.parent if hasattr(node, 'parent') else None
        while current:
            if current.type == "class_definition":
                for child in current.children:
                    if child.type == "identifier":
                        return self.get_node_text(child)
            current = current.parent if hasattr(current, 'parent') else None
        return None
    
    def _is_keyword(self, identifier: str) -> bool:
        """Verifica si un identificador es una palabra clave de Python."""
        python_keywords = {
            "False", "None", "True", "and", "as", "assert", "async", "await",
            "break", "class", "continue", "def", "del", "elif", "else", "except",
            "finally", "for", "from", "global", "if", "import", "in", "is",
            "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try",
            "while", "with", "yield"
        }
        return identifier in python_keywords

class PythonIRBuilder(IRBuilder):
    """Constructor de IR para Python."""
    
    def __init__(self, language: str = "python"):
        super().__init__(language)
        self.spec = PythonLanguageSpec()
    
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        """Construye IR desde AST de Python."""
        ir_file = IRFile(file_path=file_path, language=self.language)
        
        # Extraer funciones
        functions_info = self.spec.extract_functions(ast_tree)
        
        for func_info in functions_info:
            # Encontrar el nodo de la función
            function_nodes = self.spec.find_nodes_by_type(ast_tree.root_node, [
                "function_definition", "async_function_definition"
            ])
            
            function_node = None
            for node in function_nodes:
                if self.spec.get_node_line(node) == func_info.start_line:
                    function_node = node
                    break
            
            if function_node:
                ir_function = self._build_function_ir(function_node, func_info, file_path)
                ir_file.functions[func_info.name] = ir_function
        
        # Procesar código a nivel módulo
        ir_file.module_nodes = self._build_module_ir(ast_tree.root_node, file_path)
        
        return ir_file
    
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        """Extrae funciones usando la spec."""
        functions_info = self.spec.extract_functions(ast_tree)
        return [
            {
                "name": func.name,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "parameters": func.parameters,
                "is_method": func.is_method,
                "class_name": func.class_name,
                "is_async": func.is_async
            }
            for func in functions_info
        ]
    
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte un nodo AST de Python a IR."""
        line = self.spec.get_node_line(node)
        column = self.spec.get_node_column(node)
        node_id = self._generate_ir_id(file_path, line, column)
        source_node_id = f"{file_path}:{line}:{column}"
        
        # Assignment
        if self.spec.is_assignment(node):
            return self._convert_assignment(node, node_id, source_node_id, line, column, file_path)
        
        # Function call
        elif self.spec.is_function_call(node):
            return self._convert_function_call(node, node_id, source_node_id, line, column, file_path)
        
        # Return statement
        elif self.spec.is_return_statement(node):
            return self._convert_return(node, node_id, source_node_id, line, column, file_path)
        
        # Control flow
        elif self.spec.is_conditional(node):
            return self._convert_if(node, node_id, source_node_id, line, column, file_path)
        
        elif node.type == "while_statement":
            return self._convert_while(node, node_id, source_node_id, line, column, file_path)
        
        elif node.type == "for_statement":
            return self._convert_for(node, node_id, source_node_id, line, column, file_path)
        
        # Break/Continue
        elif self.spec.is_break_statement(node):
            return Break(node_id, source_node_id, line, column, file_path)
        
        elif self.spec.is_continue_statement(node):
            return Continue(node_id, source_node_id, line, column, file_path)
        
        return None
    
    def _build_function_ir(self, function_node: Any, func_info: FunctionInfo, file_path: str) -> IRFunction:
        """Construye IR para una función específica."""
        ir_function = IRFunction(
            name=func_info.name,
            file_path=file_path,
            start_line=func_info.start_line,
            end_line=func_info.end_line,
            parameters=func_info.parameters,
            return_type=func_info.return_type,
            metadata={
                "is_method": func_info.is_method,
                "class_name": func_info.class_name,
                "is_async": func_info.is_async
            }
        )
        
        # Convertir nodos del cuerpo de la función
        body_nodes = self.spec.get_function_body_nodes(function_node)
        for node in body_nodes:
            ir_node = self.convert_node_to_ir(node, file_path)
            if ir_node:
                ir_function.nodes.append(ir_node)
        
        return ir_function
    
    def _build_module_ir(self, root_node: Any, file_path: str) -> List[IRNode]:
        """Construye IR para código a nivel módulo."""
        module_nodes = []
        
        # Buscar statements a nivel módulo (fuera de funciones/clases)
        for child in root_node.children:
            if child.type not in ["function_definition", "async_function_definition", "class_definition"]:
                ir_node = self.convert_node_to_ir(child, file_path)
                if ir_node:
                    module_nodes.append(ir_node)
        
        return module_nodes
    
    def _convert_assignment(self, node: Any, node_id: str, source_node_id: str, 
                          line: int, column: int, file_path: str) -> Assign:
        """Convierte una asignación Python a IR."""
        target = ""
        value_node = None
        
        for child in node.children:
            if child.type == "identifier" and not target:
                target = self.spec.get_node_text(child)
            elif child.type not in ["=", "identifier"] and target:
                value_node = child
                break
        
        # Convertir valor a IR
        value_ir = self._convert_expression_to_ir(value_node, file_path) if value_node else None
        
        return Assign(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            target=target,
            value=value_ir or Literal(
                id=f"{node_id}_literal",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=None,
                literal_type="null"
            )
        )
    
    def _convert_function_call(self, node: Any, node_id: str, source_node_id: str,
                             line: int, column: int, file_path: str) -> FunctionCall:
        """Convierte una llamada a función Python a IR."""
        function_name = ""
        arguments = []
        
        for child in node.children:
            if child.type in ["identifier", "attribute"]:
                function_name = self.spec.get_node_text(child)
            elif child.type == "argument_list":
                for arg in child.children:
                    if arg.type != ",":
                        arg_ir = self._convert_expression_to_ir(arg, file_path)
                        if arg_ir:
                            arguments.append(arg_ir)
        
        return FunctionCall(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            function_name=function_name,
            arguments=arguments
        )
    
    def _convert_return(self, node: Any, node_id: str, source_node_id: str,
                       line: int, column: int, file_path: str) -> Return:
        """Convierte un return Python a IR."""
        value_ir = None
        
        for child in node.children:
            if child.type not in ["return"]:
                value_ir = self._convert_expression_to_ir(child, file_path)
                break
        
        return Return(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            value=value_ir
        )
    
    def _convert_if(self, node: Any, node_id: str, source_node_id: str,
                   line: int, column: int, file_path: str) -> If:
        """Convierte un if Python a IR."""
        condition_ir = None
        
        for child in node.children:
            if child.type == "expression":
                condition_ir = self._convert_expression_to_ir(child, file_path)
                break
        
        return If(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            condition=condition_ir or Literal(
                id=f"{node_id}_condition",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=True,
                literal_type="bool"
            )
        )
    
    def _convert_while(self, node: Any, node_id: str, source_node_id: str,
                      line: int, column: int, file_path: str) -> While:
        """Convierte un while Python a IR."""
        condition_ir = None
        
        for child in node.children:
            if child.type == "expression":
                condition_ir = self._convert_expression_to_ir(child, file_path)
                break
        
        return While(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            condition=condition_ir or Literal(
                id=f"{node_id}_condition",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=True,
                literal_type="bool"
            )
        )
    
    def _convert_for(self, node: Any, node_id: str, source_node_id: str,
                    line: int, column: int, file_path: str) -> For:
        """Convierte un for Python a IR."""
        iterator = ""
        iterable_ir = None
        
        for child in node.children:
            if child.type == "identifier" and not iterator:
                iterator = self.spec.get_node_text(child)
            elif child.type == "expression" and iterator:
                iterable_ir = self._convert_expression_to_ir(child, file_path)
                break
        
        return For(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            iterator=iterator,
            iterable=iterable_ir
        )
    
    def _convert_expression_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte una expresión Python a IR."""
        if not node:
            return None
        
        line = self.spec.get_node_line(node)
        column = self.spec.get_node_column(node)
        node_id = self._generate_ir_id(file_path, line, column)
        source_node_id = f"{file_path}:{line}:{column}"
        
        # Literal
        if node.type in ["integer", "float", "string", "true", "false", "none"]:
            value = self.spec.get_node_text(node)
            literal_type = node.type
            
            # Convertir valor
            if node.type == "integer":
                value = int(value) if value.isdigit() else 0
            elif node.type == "float":
                try:
                    value = float(value)
                except ValueError:
                    value = 0.0
            elif node.type in ["true", "false"]:
                value = node.type == "true"
                literal_type = "bool"
            elif node.type == "none":
                value = None
                literal_type = "null"
            
            return Literal(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=value,
                literal_type=literal_type
            )
        
        # Variable reference
        elif node.type == "identifier":
            variable = self.spec.get_node_text(node)
            return VarRef(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                variable=variable
            )
        
        # Binary operation
        elif node.type == "binary_operator":
            left_node = None
            operator = ""
            right_node = None
            
            children = list(node.children)
            if len(children) >= 3:
                left_node = children[0]
                operator = self.spec.get_node_text(children[1])
                right_node = children[2]
            
            left_ir = self._convert_expression_to_ir(left_node, file_path)
            right_ir = self._convert_expression_to_ir(right_node, file_path)
            
            if left_ir and right_ir:
                return BinaryOp(
                    id=node_id,
                    source_node_id=source_node_id,
                    line=line,
                    column=column,
                    file_path=file_path,
                    left=left_ir,
                    operator=self.spec.normalize_operator(operator),
                    right=right_ir
                )
        
        # Function call
        elif node.type == "call":
            return self._convert_function_call(node, node_id, source_node_id, line, column, file_path)
        
        # Member access
        elif node.type == "attribute":
            object_node = None
            member = ""
            
            for child in node.children:
                if child.type == "identifier" and not object_node:
                    object_node = child
                elif child.type == "identifier" and object_node:
                    member = self.spec.get_node_text(child)
                    break
            
            object_ir = self._convert_expression_to_ir(object_node, file_path)
            if object_ir and member:
                return MemberAccess(
                    id=node_id,
                    source_node_id=source_node_id,
                    line=line,
                    column=column,
                    file_path=file_path,
                    object=object_ir,
                    member=member
                )
        
        return None
