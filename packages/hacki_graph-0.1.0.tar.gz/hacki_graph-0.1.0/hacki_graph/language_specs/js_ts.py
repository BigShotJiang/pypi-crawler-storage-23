"""
JavaScript/TypeScript Language Specifications and IR Builders

Implementa soporte para JavaScript y TypeScript.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from ..ir.base import IRBuilder, IRFile, IRFunction
from ..ir.nodes import *
from .base import LanguageSpec, FunctionInfo, ControlStructure

logger = logging.getLogger(__name__)

class JavaScriptLanguageSpec(LanguageSpec):
    """Especificación del lenguaje JavaScript."""
    
    @property
    def language_name(self) -> str:
        return "javascript"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".js", ".jsx", ".mjs"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "javascript"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """Extrae funciones del AST de JavaScript."""
        functions = []
        
        function_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "function_declaration", 
            "arrow_function",
            "method_definition",
            "function_expression"
        ])
        
        for node in function_nodes:
            try:
                name = self._extract_function_name(node)
                if not name:
                    name = f"anonymous_{self.get_node_line(node)}"
                
                start_line = self.get_node_line(node)
                end_line = node.end_point[0] + 1 if hasattr(node, 'end_point') else start_line
                parameters = self._extract_js_parameters(node)
                
                is_method = node.type == "method_definition"
                is_async = self._is_async_function(node)
                
                functions.append(FunctionInfo(
                    name=name,
                    start_line=start_line,
                    end_line=end_line,
                    parameters=parameters,
                    is_method=is_method,
                    is_async=is_async
                ))
                
            except Exception as e:
                logger.warning(f"Error extrayendo función JavaScript: {e}")
                continue
        
        return functions
    
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        """Extrae estructuras de control de JavaScript."""
        structures = []
        
        control_types = {
            "if_statement": "if",
            "while_statement": "while",
            "for_statement": "for",
            "for_in_statement": "for_in",
            "try_statement": "try",
            "switch_statement": "switch"
        }
        
        for child in node.children if hasattr(node, 'children') else []:
            if child.type in control_types:
                structure_type = control_types[child.type]
                start_line = self.get_node_line(child)
                end_line = child.end_point[0] + 1 if hasattr(child, 'end_point') else start_line
                
                has_else = any(grandchild.type == "else_clause" for grandchild in child.children)
                has_finally = any(grandchild.type == "finally_clause" for grandchild in child.children)
                
                structures.append(ControlStructure(
                    type=structure_type,
                    start_line=start_line,
                    end_line=end_line,
                    has_else=has_else,
                    has_finally=has_finally
                ))
            
            structures.extend(self.extract_control_structures(child))
        
        return structures
    
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae asignaciones de JavaScript."""
        assignments = []
        
        if node.type in ["assignment_expression", "variable_declarator"]:
            try:
                target = None
                value = None
                
                for child in node.children:
                    if child.type == "identifier" and target is None:
                        target = self.get_node_text(child)
                    elif child.type not in ["=", "identifier", "var", "let", "const"] and target:
                        value = child
                        break
                
                if target and value:
                    assignments.append({
                        "target": target,
                        "value": value,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo asignación JavaScript: {e}")
        
        if hasattr(node, 'children'):
            for child in node.children:
                assignments.extend(self.extract_assignments(child))
        
        return assignments
    
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        """Extrae llamadas a funciones de JavaScript."""
        calls = []
        
        if node.type == "call_expression":
            try:
                function_name = None
                arguments = []
                
                for child in node.children:
                    if child.type in ["identifier", "member_expression"]:
                        function_name = self.get_node_text(child)
                    elif child.type == "arguments":
                        arguments = [arg for arg in child.children if arg.type != ","]
                
                if function_name:
                    calls.append({
                        "function": function_name,
                        "arguments": arguments,
                        "line": self.get_node_line(node),
                        "column": self.get_node_column(node)
                    })
            except Exception as e:
                logger.debug(f"Error extrayendo llamada JavaScript: {e}")
        
        if hasattr(node, 'children'):
            for child in node.children:
                calls.extend(self.extract_function_calls(child))
        
        return calls
    
    def extract_variable_references(self, node: Any) -> List[str]:
        """Extrae referencias a variables de JavaScript."""
        variables = []
        
        if node.type == "identifier":
            var_name = self.get_node_text(node)
            if var_name and not self._is_js_keyword(var_name):
                variables.append(var_name)
        
        if hasattr(node, 'children'):
            for child in node.children:
                variables.extend(self.extract_variable_references(child))
        
        return variables
    
    def normalize_identifier(self, identifier: str) -> str:
        return identifier.strip()
    
    def normalize_operator(self, operator: str) -> str:
        operator_map = {
            "===": "==",
            "!==": "!=",
            "&&": "and",
            "||": "or"
        }
        return operator_map.get(operator, operator)
    
    def get_assignment_operators(self) -> Set[str]:
        return {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=", ">>>=", "**="}
    
    def get_binary_operators(self) -> Set[str]:
        return {"+", "-", "*", "/", "%", "**", "&", "|", "^", "<<", ">>", ">>>",
                "==", "!=", "===", "!==", "<", ">", "<=", ">=", "&&", "||", "in", "instanceof"}
    
    def get_unary_operators(self) -> Set[str]:
        return {"!", "-", "+", "~", "typeof", "void", "delete", "++", "--"}
    
    # Node type checking methods
    def is_function_definition(self, node: Any) -> bool:
        return node.type in ["function_declaration", "arrow_function", "method_definition", "function_expression"]
    
    def is_class_definition(self, node: Any) -> bool:
        return node.type == "class_declaration"
    
    def is_assignment(self, node: Any) -> bool:
        return node.type in ["assignment_expression", "variable_declarator"]
    
    def is_function_call(self, node: Any) -> bool:
        return node.type == "call_expression"
    
    def is_control_flow(self, node: Any) -> bool:
        return node.type in ["if_statement", "while_statement", "for_statement", 
                           "for_in_statement", "try_statement", "switch_statement"]
    
    def is_loop(self, node: Any) -> bool:
        return node.type in ["while_statement", "for_statement", "for_in_statement"]
    
    def is_conditional(self, node: Any) -> bool:
        return node.type in ["if_statement", "conditional_expression"]
    
    def is_return_statement(self, node: Any) -> bool:
        return node.type == "return_statement"
    
    def is_break_statement(self, node: Any) -> bool:
        return node.type == "break_statement"
    
    def is_continue_statement(self, node: Any) -> bool:
        return node.type == "continue_statement"
    
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        boundaries = [self.get_node_line(function_node)]
        
        control_nodes = self.find_nodes_by_type(function_node, [
            "if_statement", "while_statement", "for_statement", "for_in_statement",
            "try_statement", "switch_statement", "return_statement", "break_statement", "continue_statement"
        ])
        
        for node in control_nodes:
            boundaries.append(self.get_node_line(node))
        
        return sorted(list(set(boundaries)))
    
    def get_branch_targets(self, node: Any) -> List[int]:
        targets = []
        
        if node.type == "if_statement":
            for child in node.children:
                if child.type in ["statement_block", "expression_statement"]:
                    targets.append(self.get_node_line(child))
        
        return targets
    
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        info = {
            "type": node.type,
            "line": self.get_node_line(node)
        }
        
        if node.type == "for_statement":
            # Extraer init, condition, update
            children = list(node.children)
            if len(children) >= 4:  # for ( init ; condition ; update )
                info["init"] = self.get_node_text(children[1]) if len(children) > 1 else None
                info["condition"] = self.get_node_text(children[2]) if len(children) > 2 else None
                info["update"] = self.get_node_text(children[3]) if len(children) > 3 else None
        
        elif node.type == "for_in_statement":
            # for (variable in object)
            for child in node.children:
                if child.type == "identifier":
                    info["iterator"] = self.get_node_text(child)
                    break
        
        return info
    
    # Helper methods
    def _extract_function_name(self, node: Any) -> Optional[str]:
        """Extrae el nombre de una función."""
        if node.type == "function_declaration":
            for child in node.children:
                if child.type == "identifier":
                    return self.get_node_text(child)
        elif node.type == "method_definition":
            for child in node.children:
                if child.type in ["identifier", "property_identifier"]:
                    return self.get_node_text(child)
        return None
    
    def _extract_js_parameters(self, node: Any) -> List[str]:
        """Extrae parámetros de una función JavaScript."""
        parameters = []
        
        for child in node.children:
            if child.type == "formal_parameters":
                for param in child.children:
                    if param.type == "identifier":
                        parameters.append(self.get_node_text(param))
                break
        
        return parameters
    
    def _is_async_function(self, node: Any) -> bool:
        """Verifica si una función es async."""
        for child in node.children:
            if child.type == "async" or self.get_node_text(child) == "async":
                return True
        return False
    
    def _is_js_keyword(self, identifier: str) -> bool:
        """Verifica si un identificador es una palabra clave de JavaScript."""
        js_keywords = {
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function",
            "if", "import", "in", "instanceof", "new", "return", "super", "switch",
            "this", "throw", "try", "typeof", "var", "void", "while", "with", "yield",
            "let", "static", "enum", "implements", "package", "protected", "interface",
            "private", "public", "await", "async"
        }
        return identifier in js_keywords

class TypeScriptLanguageSpec(JavaScriptLanguageSpec):
    """Especificación del lenguaje TypeScript (hereda de JavaScript)."""
    
    @property
    def language_name(self) -> str:
        return "typescript"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".ts", ".tsx"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "typescript"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        """Extrae funciones del AST de TypeScript."""
        functions = super().extract_functions(ast_tree)
        
        # Agregar interfaces y tipos específicos de TypeScript
        interface_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "interface_declaration",
            "type_alias_declaration"
        ])
        
        for node in interface_nodes:
            try:
                name = self._extract_function_name(node)
                if name:
                    functions.append(FunctionInfo(
                        name=name,
                        start_line=self.get_node_line(node),
                        end_line=node.end_point[0] + 1 if hasattr(node, 'end_point') else self.get_node_line(node),
                        parameters=[],
                        is_method=False
                    ))
            except Exception as e:
                logger.warning(f"Error extrayendo interface TypeScript: {e}")
        
        return functions

class JavaScriptIRBuilder(IRBuilder):
    """Constructor de IR para JavaScript."""
    
    def __init__(self, language: str = "javascript"):
        super().__init__(language)
        self.spec = JavaScriptLanguageSpec()
    
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        """Construye IR desde AST de JavaScript."""
        ir_file = IRFile(file_path=file_path, language=self.language)
        
        functions_info = self.spec.extract_functions(ast_tree)
        
        for func_info in functions_info:
            function_nodes = self.spec.find_nodes_by_type(ast_tree.root_node, [
                "function_declaration", "arrow_function", "method_definition", "function_expression"
            ])
            
            function_node = None
            for node in function_nodes:
                if self.spec.get_node_line(node) == func_info.start_line:
                    function_node = node
                    break
            
            if function_node:
                ir_function = self._build_function_ir(function_node, func_info, file_path)
                ir_file.functions[func_info.name] = ir_function
        
        ir_file.module_nodes = self._build_module_ir(ast_tree.root_node, file_path)
        return ir_file
    
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        functions_info = self.spec.extract_functions(ast_tree)
        return [
            {
                "name": func.name,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "parameters": func.parameters,
                "is_method": func.is_method,
                "is_async": func.is_async
            }
            for func in functions_info
        ]
    
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte un nodo AST de JavaScript a IR."""
        line = self.spec.get_node_line(node)
        column = self.spec.get_node_column(node)
        node_id = self._generate_ir_id(file_path, line, column)
        source_node_id = f"{file_path}:{line}:{column}"
        
        # Assignment
        if self.spec.is_assignment(node):
            return self._convert_js_assignment(node, node_id, source_node_id, line, column, file_path)
        
        # Function call
        elif self.spec.is_function_call(node):
            return self._convert_js_function_call(node, node_id, source_node_id, line, column, file_path)
        
        # Return statement
        elif self.spec.is_return_statement(node):
            return self._convert_js_return(node, node_id, source_node_id, line, column, file_path)
        
        # Control flow
        elif self.spec.is_conditional(node):
            return self._convert_js_if(node, node_id, source_node_id, line, column, file_path)
        
        elif node.type == "while_statement":
            return self._convert_js_while(node, node_id, source_node_id, line, column, file_path)
        
        elif node.type in ["for_statement", "for_in_statement"]:
            return self._convert_js_for(node, node_id, source_node_id, line, column, file_path)
        
        # Break/Continue
        elif self.spec.is_break_statement(node):
            return Break(node_id, source_node_id, line, column, file_path)
        
        elif self.spec.is_continue_statement(node):
            return Continue(node_id, source_node_id, line, column, file_path)
        
        return None
    
    def _build_function_ir(self, function_node: Any, func_info: FunctionInfo, file_path: str) -> IRFunction:
        """Construye IR para una función JavaScript."""
        ir_function = IRFunction(
            name=func_info.name,
            file_path=file_path,
            start_line=func_info.start_line,
            end_line=func_info.end_line,
            parameters=func_info.parameters,
            return_type=func_info.return_type,
            metadata={
                "is_method": func_info.is_method,
                "is_async": func_info.is_async
            }
        )
        
        body_nodes = self.spec.get_function_body_nodes(function_node)
        for node in body_nodes:
            ir_node = self.convert_node_to_ir(node, file_path)
            if ir_node:
                ir_function.nodes.append(ir_node)
        
        return ir_function
    
    def _build_module_ir(self, root_node: Any, file_path: str) -> List[IRNode]:
        """Construye IR para código a nivel módulo."""
        module_nodes = []
        
        for child in root_node.children:
            if child.type not in ["function_declaration", "class_declaration"]:
                ir_node = self.convert_node_to_ir(child, file_path)
                if ir_node:
                    module_nodes.append(ir_node)
        
        return module_nodes
    
    def _convert_js_assignment(self, node: Any, node_id: str, source_node_id: str,
                              line: int, column: int, file_path: str) -> Assign:
        """Convierte una asignación JavaScript a IR."""
        target = ""
        value_node = None
        
        for child in node.children:
            if child.type == "identifier" and not target:
                target = self.spec.get_node_text(child)
            elif child.type not in ["=", "identifier", "var", "let", "const"] and target:
                value_node = child
                break
        
        value_ir = self._convert_js_expression_to_ir(value_node, file_path) if value_node else None
        
        return Assign(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            target=target,
            value=value_ir or Literal(
                id=f"{node_id}_literal",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=None,
                literal_type="null"
            )
        )
    
    def _convert_js_function_call(self, node: Any, node_id: str, source_node_id: str,
                                 line: int, column: int, file_path: str) -> FunctionCall:
        """Convierte una llamada a función JavaScript a IR."""
        function_name = ""
        arguments = []
        
        for child in node.children:
            if child.type in ["identifier", "member_expression"]:
                function_name = self.spec.get_node_text(child)
            elif child.type == "arguments":
                for arg in child.children:
                    if arg.type != ",":
                        arg_ir = self._convert_js_expression_to_ir(arg, file_path)
                        if arg_ir:
                            arguments.append(arg_ir)
        
        return FunctionCall(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            function_name=function_name,
            arguments=arguments
        )
    
    def _convert_js_return(self, node: Any, node_id: str, source_node_id: str,
                          line: int, column: int, file_path: str) -> Return:
        """Convierte un return JavaScript a IR."""
        value_ir = None
        
        for child in node.children:
            if child.type not in ["return"]:
                value_ir = self._convert_js_expression_to_ir(child, file_path)
                break
        
        return Return(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            value=value_ir
        )
    
    def _convert_js_if(self, node: Any, node_id: str, source_node_id: str,
                      line: int, column: int, file_path: str) -> If:
        """Convierte un if JavaScript a IR."""
        condition_ir = None
        
        for child in node.children:
            if child.type == "parenthesized_expression":
                # Buscar la expresión dentro de los paréntesis
                for grandchild in child.children:
                    if grandchild.type != "(" and grandchild.type != ")":
                        condition_ir = self._convert_js_expression_to_ir(grandchild, file_path)
                        break
                break
        
        return If(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            condition=condition_ir or Literal(
                id=f"{node_id}_condition",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=True,
                literal_type="bool"
            )
        )
    
    def _convert_js_while(self, node: Any, node_id: str, source_node_id: str,
                         line: int, column: int, file_path: str) -> While:
        """Convierte un while JavaScript a IR."""
        condition_ir = None
        
        for child in node.children:
            if child.type == "parenthesized_expression":
                for grandchild in child.children:
                    if grandchild.type != "(" and grandchild.type != ")":
                        condition_ir = self._convert_js_expression_to_ir(grandchild, file_path)
                        break
                break
        
        return While(
            id=node_id,
            source_node_id=source_node_id,
            line=line,
            column=column,
            file_path=file_path,
            condition=condition_ir or Literal(
                id=f"{node_id}_condition",
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=True,
                literal_type="bool"
            )
        )
    
    def _convert_js_for(self, node: Any, node_id: str, source_node_id: str,
                       line: int, column: int, file_path: str) -> For:
        """Convierte un for JavaScript a IR."""
        if node.type == "for_in_statement":
            # for (variable in object)
            iterator = ""
            iterable_ir = None
            
            for child in node.children:
                if child.type == "identifier" and not iterator:
                    iterator = self.spec.get_node_text(child)
                elif child.type != "identifier" and iterator and not iterable_ir:
                    iterable_ir = self._convert_js_expression_to_ir(child, file_path)
                    break
            
            return For(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                iterator=iterator,
                iterable=iterable_ir
            )
        
        else:  # for_statement
            # for (init; condition; update)
            init_ir = None
            condition_ir = None
            update_ir = None
            
            # Buscar los componentes del for
            for child in node.children:
                if child.type == "variable_declaration":
                    init_ir = self._convert_js_expression_to_ir(child, file_path)
                elif child.type == "binary_expression":
                    condition_ir = self._convert_js_expression_to_ir(child, file_path)
                elif child.type == "update_expression":
                    update_ir = self._convert_js_expression_to_ir(child, file_path)
            
            return For(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                init=init_ir,
                condition=condition_ir,
                update=update_ir
            )
    
    def _convert_js_expression_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte una expresión JavaScript a IR."""
        if not node:
            return None
        
        line = self.spec.get_node_line(node)
        column = self.spec.get_node_column(node)
        node_id = self._generate_ir_id(file_path, line, column)
        source_node_id = f"{file_path}:{line}:{column}"
        
        # Literal
        if node.type in ["number", "string", "true", "false", "null", "undefined"]:
            value = self.spec.get_node_text(node)
            literal_type = node.type
            
            if node.type == "number":
                try:
                    value = int(value) if '.' not in value else float(value)
                except ValueError:
                    value = 0
            elif node.type in ["true", "false"]:
                value = node.type == "true"
                literal_type = "bool"
            elif node.type in ["null", "undefined"]:
                value = None
                literal_type = "null"
            
            return Literal(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                value=value,
                literal_type=literal_type
            )
        
        # Variable reference
        elif node.type == "identifier":
            variable = self.spec.get_node_text(node)
            return VarRef(
                id=node_id,
                source_node_id=source_node_id,
                line=line,
                column=column,
                file_path=file_path,
                variable=variable
            )
        
        # Binary operation
        elif node.type == "binary_expression":
            children = list(node.children)
            if len(children) >= 3:
                left_ir = self._convert_js_expression_to_ir(children[0], file_path)
                operator = self.spec.get_node_text(children[1])
                right_ir = self._convert_js_expression_to_ir(children[2], file_path)
                
                if left_ir and right_ir:
                    return BinaryOp(
                        id=node_id,
                        source_node_id=source_node_id,
                        line=line,
                        column=column,
                        file_path=file_path,
                        left=left_ir,
                        operator=self.spec.normalize_operator(operator),
                        right=right_ir
                    )
        
        # Function call
        elif node.type == "call_expression":
            return self._convert_js_function_call(node, node_id, source_node_id, line, column, file_path)
        
        # Member access
        elif node.type == "member_expression":
            object_node = None
            member = ""
            
            children = list(node.children)
            if len(children) >= 3:  # object.member
                object_node = children[0]
                member = self.spec.get_node_text(children[2])
            
            object_ir = self._convert_js_expression_to_ir(object_node, file_path)
            if object_ir and member:
                return MemberAccess(
                    id=node_id,
                    source_node_id=source_node_id,
                    line=line,
                    column=column,
                    file_path=file_path,
                    object=object_ir,
                    member=member
                )
        
        return None

class TypeScriptIRBuilder(JavaScriptIRBuilder):
    """Constructor de IR para TypeScript (hereda de JavaScript)."""
    
    def __init__(self, language: str = "typescript"):
        super().__init__(language)
        self.spec = TypeScriptLanguageSpec()
