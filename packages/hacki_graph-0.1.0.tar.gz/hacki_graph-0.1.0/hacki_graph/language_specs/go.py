"""
Go Language Specification and IR Builder

Implementa soporte básico para Go.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from ..ir.base import IRBuilder, IRFile, IRFunction
from ..ir.nodes import *
from .base import LanguageSpec, FunctionInfo, ControlStructure

logger = logging.getLogger(__name__)

class GoLanguageSpec(LanguageSpec):
    """Especificación del lenguaje Go."""
    
    @property
    def language_name(self) -> str:
        return "go"
    
    @property
    def file_extensions(self) -> Set[str]:
        return {".go"}
    
    @property
    def tree_sitter_language(self) -> str:
        return "go"
    
    def extract_functions(self, ast_tree: Any) -> List[FunctionInfo]:
        functions = []
        
        function_nodes = self.find_nodes_by_type(ast_tree.root_node, [
            "function_declaration", 
            "method_declaration"
        ])
        
        for node in function_nodes:
            try:
                name = self._extract_go_function_name(node)
                if name:
                    functions.append(FunctionInfo(
                        name=name,
                        start_line=self.get_node_line(node),
                        end_line=node.end_point[0] + 1 if hasattr(node, 'end_point') else self.get_node_line(node),
                        parameters=self._extract_go_parameters(node),
                        is_method=node.type == "method_declaration"
                    ))
            except Exception as e:
                logger.warning(f"Error extrayendo función Go: {e}")
        
        return functions
    
    def extract_control_structures(self, node: Any) -> List[ControlStructure]:
        return []  # Implementación básica
    
    def extract_assignments(self, node: Any) -> List[Dict[str, Any]]:
        return []  # Implementación básica
    
    def extract_function_calls(self, node: Any) -> List[Dict[str, Any]]:
        return []  # Implementación básica
    
    def extract_variable_references(self, node: Any) -> List[str]:
        return []  # Implementación básica
    
    def normalize_identifier(self, identifier: str) -> str:
        return identifier.strip()
    
    def normalize_operator(self, operator: str) -> str:
        return operator
    
    def get_assignment_operators(self) -> Set[str]:
        return {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=", "&^="}
    
    def get_binary_operators(self) -> Set[str]:
        return {"+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>", "&^",
                "==", "!=", "<", ">", "<=", ">=", "&&", "||"}
    
    def get_unary_operators(self) -> Set[str]:
        return {"!", "-", "+", "^", "*", "&", "<-"}
    
    def is_function_definition(self, node: Any) -> bool:
        return node.type in ["function_declaration", "method_declaration"]
    
    def is_class_definition(self, node: Any) -> bool:
        return node.type == "type_declaration"
    
    def is_assignment(self, node: Any) -> bool:
        return node.type == "assignment_statement"
    
    def is_function_call(self, node: Any) -> bool:
        return node.type == "call_expression"
    
    def is_control_flow(self, node: Any) -> bool:
        return node.type in ["if_statement", "for_statement", "switch_statement"]
    
    def is_loop(self, node: Any) -> bool:
        return node.type == "for_statement"
    
    def is_conditional(self, node: Any) -> bool:
        return node.type == "if_statement"
    
    def is_return_statement(self, node: Any) -> bool:
        return node.type == "return_statement"
    
    def is_break_statement(self, node: Any) -> bool:
        return node.type == "break_statement"
    
    def is_continue_statement(self, node: Any) -> bool:
        return node.type == "continue_statement"
    
    def get_basic_block_boundaries(self, function_node: Any) -> List[int]:
        return [self.get_node_line(function_node)]
    
    def get_branch_targets(self, node: Any) -> List[int]:
        return []
    
    def get_loop_info(self, node: Any) -> Dict[str, Any]:
        return {"type": node.type, "line": self.get_node_line(node)}
    
    def _extract_go_function_name(self, node: Any) -> Optional[str]:
        for child in node.children:
            if child.type == "identifier":
                return self.get_node_text(child)
        return None
    
    def _extract_go_parameters(self, node: Any) -> List[str]:
        return []  # Implementación básica

class GoIRBuilder(IRBuilder):
    """Constructor de IR para Go."""
    
    def __init__(self, language: str = "go"):
        super().__init__(language)
        self.spec = GoLanguageSpec()
    
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        ir_file = IRFile(file_path=file_path, language=self.language)
        
        functions_info = self.spec.extract_functions(ast_tree)
        
        for func_info in functions_info:
            ir_function = IRFunction(
                name=func_info.name,
                file_path=file_path,
                start_line=func_info.start_line,
                end_line=func_info.end_line,
                parameters=func_info.parameters,
                return_type=func_info.return_type
            )
            ir_file.functions[func_info.name] = ir_function
        
        return ir_file
    
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        functions_info = self.spec.extract_functions(ast_tree)
        return [
            {
                "name": func.name,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "parameters": func.parameters
            }
            for func in functions_info
        ]
    
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        return None  # Implementación básica
