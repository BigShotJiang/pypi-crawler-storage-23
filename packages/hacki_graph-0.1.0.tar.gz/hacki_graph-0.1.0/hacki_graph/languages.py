"""
Language Configuration Module

Define las configuraciones específicas para cada lenguaje soportado,
incluyendo extensiones de archivo, patrones de nodos importantes,
y queries específicas de Tree-sitter.
"""

import logging
from typing import Dict, List, Set, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class LanguageConfig:
    """
    Configuración para un lenguaje específico.
    """
    name: str
    extensions: Set[str]
    tree_sitter_name: str
    import_patterns: List[str]
    function_patterns: List[str]
    class_patterns: List[str]
    call_patterns: List[str]
    
class LanguageRegistry:
    """
    Registro de configuraciones de lenguajes soportados.
    """
    
    def __init__(self):
        self._languages: Dict[str, LanguageConfig] = {}
        self._extension_map: Dict[str, str] = {}
        self._initialize_languages()
    
    def _initialize_languages(self):
        """Inicializa las configuraciones de lenguajes soportados."""
        
        # Python
        python_config = LanguageConfig(
            name="python",
            extensions={".py", ".pyx", ".pyi"},
            tree_sitter_name="python",
            import_patterns=[
                "(import_statement) @import",
                "(import_from_statement) @import",
                "(future_import_statement) @import"
            ],
            function_patterns=[
                "(function_definition name: (identifier) @function.name) @function.def",
                "(async_function_definition name: (identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_definition name: (identifier) @class.name) @class.def"
            ],
            call_patterns=[
                "(call function: (identifier) @call.function) @call",
                "(call function: (attribute) @call.method) @call"
            ]
        )
        self.register_language(python_config)
        
        # JavaScript
        javascript_config = LanguageConfig(
            name="javascript",
            extensions={".js", ".jsx", ".mjs"},
            tree_sitter_name="javascript",
            import_patterns=[
                "(import_statement) @import",
                "(import_clause) @import"
            ],
            function_patterns=[
                "(function_declaration name: (identifier) @function.name) @function.def",
                "(arrow_function) @function.def",
                "(method_definition name: (property_identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_declaration name: (identifier) @class.name) @class.def"
            ],
            call_patterns=[
                "(call_expression function: (identifier) @call.function) @call",
                "(call_expression function: (member_expression) @call.method) @call"
            ]
        )
        self.register_language(javascript_config)
        
        # TypeScript
        typescript_config = LanguageConfig(
            name="typescript",
            extensions={".ts", ".tsx"},
            tree_sitter_name="typescript",
            import_patterns=[
                "(import_statement) @import",
                "(import_clause) @import"
            ],
            function_patterns=[
                "(function_declaration name: (identifier) @function.name) @function.def",
                "(arrow_function) @function.def",
                "(method_definition name: (property_identifier) @function.name) @function.def",
                "(method_signature name: (property_identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_declaration name: (identifier) @class.name) @class.def",
                "(interface_declaration name: (type_identifier) @class.name) @class.def"
            ],
            call_patterns=[
                "(call_expression function: (identifier) @call.function) @call",
                "(call_expression function: (member_expression) @call.method) @call"
            ]
        )
        self.register_language(typescript_config)
        
        # Java
        java_config = LanguageConfig(
            name="java",
            extensions={".java"},
            tree_sitter_name="java",
            import_patterns=[
                "(import_declaration) @import"
            ],
            function_patterns=[
                "(method_declaration name: (identifier) @function.name) @function.def",
                "(constructor_declaration name: (identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_declaration name: (identifier) @class.name) @class.def",
                "(interface_declaration name: (identifier) @class.name) @class.def"
            ],
            call_patterns=[
                "(method_invocation name: (identifier) @call.function) @call",
                "(method_invocation object: (_) name: (identifier) @call.method) @call"
            ]
        )
        self.register_language(java_config)
        
        # C#
        csharp_config = LanguageConfig(
            name="csharp",
            extensions={".cs"},
            tree_sitter_name="c_sharp",
            import_patterns=[
                "(using_directive) @import"
            ],
            function_patterns=[
                "(method_declaration name: (identifier) @function.name) @function.def",
                "(constructor_declaration name: (identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_declaration name: (identifier) @class.name) @class.def",
                "(interface_declaration name: (identifier) @class.name) @class.def"
            ],
            call_patterns=[
                "(invocation_expression function: (identifier) @call.function) @call",
                "(invocation_expression function: (member_access_expression) @call.method) @call"
            ]
        )
        self.register_language(csharp_config)
        
        # PHP
        php_config = LanguageConfig(
            name="php",
            extensions={".php", ".phtml"},
            tree_sitter_name="php",
            import_patterns=[
                "(namespace_use_declaration) @import",
                "(include_expression) @import",
                "(require_expression) @import"
            ],
            function_patterns=[
                "(function_definition name: (name) @function.name) @function.def",
                "(method_declaration name: (name) @function.name) @function.def"
            ],
            class_patterns=[
                "(class_declaration name: (name) @class.name) @class.def",
                "(interface_declaration name: (name) @class.name) @class.def"
            ],
            call_patterns=[
                "(function_call_expression function: (name) @call.function) @call",
                "(member_call_expression name: (name) @call.method) @call"
            ]
        )
        self.register_language(php_config)
        
        # Go
        go_config = LanguageConfig(
            name="go",
            extensions={".go"},
            tree_sitter_name="go",
            import_patterns=[
                "(import_declaration) @import"
            ],
            function_patterns=[
                "(function_declaration name: (identifier) @function.name) @function.def",
                "(method_declaration name: (field_identifier) @function.name) @function.def"
            ],
            class_patterns=[
                "(type_declaration (type_spec name: (type_identifier) @class.name)) @class.def"
            ],
            call_patterns=[
                "(call_expression function: (identifier) @call.function) @call",
                "(call_expression function: (selector_expression) @call.method) @call"
            ]
        )
        self.register_language(go_config)
    
    def register_language(self, config: LanguageConfig):
        """
        Registra una configuración de lenguaje.
        
        Args:
            config: Configuración del lenguaje
        """
        self._languages[config.name] = config
        
        # Mapear extensiones al lenguaje
        for ext in config.extensions:
            self._extension_map[ext] = config.name
            
        logger.debug(f"Lenguaje {config.name} registrado con extensiones {config.extensions}")
    
    def get_language_by_name(self, name: str) -> Optional[LanguageConfig]:
        """
        Obtiene la configuración de un lenguaje por nombre.
        
        Args:
            name: Nombre del lenguaje
            
        Returns:
            Configuración del lenguaje o None si no existe
        """
        return self._languages.get(name)
    
    def get_language_by_extension(self, extension: str) -> Optional[LanguageConfig]:
        """
        Obtiene la configuración de un lenguaje por extensión de archivo.
        
        Args:
            extension: Extensión del archivo (ej: '.py', '.js')
            
        Returns:
            Configuración del lenguaje o None si no está soportado
        """
        language_name = self._extension_map.get(extension)
        if language_name:
            return self._languages.get(language_name)
        return None
    
    def get_language_by_file(self, file_path: str) -> Optional[LanguageConfig]:
        """
        Obtiene la configuración de un lenguaje por ruta de archivo.
        
        Args:
            file_path: Ruta del archivo
            
        Returns:
            Configuración del lenguaje o None si no está soportado
        """
        from pathlib import Path
        extension = Path(file_path).suffix.lower()
        return self.get_language_by_extension(extension)
    
    def get_supported_languages(self) -> List[str]:
        """
        Obtiene la lista de lenguajes soportados.
        
        Returns:
            Lista de nombres de lenguajes
        """
        return list(self._languages.keys())
    
    def get_supported_extensions(self) -> Set[str]:
        """
        Obtiene el conjunto de extensiones soportadas.
        
        Returns:
            Conjunto de extensiones de archivo
        """
        return set(self._extension_map.keys())
    
    def is_file_supported(self, file_path: str) -> bool:
        """
        Verifica si un archivo está soportado.
        
        Args:
            file_path: Ruta del archivo
            
        Returns:
            bool: True si el archivo está soportado
        """
        return self.get_language_by_file(file_path) is not None

# Instancia global del registro
_registry_instance = None

def get_language_registry() -> LanguageRegistry:
    """
    Obtiene la instancia global del registro de lenguajes.
    
    Returns:
        Instancia del LanguageRegistry
    """
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = LanguageRegistry()
    return _registry_instance
