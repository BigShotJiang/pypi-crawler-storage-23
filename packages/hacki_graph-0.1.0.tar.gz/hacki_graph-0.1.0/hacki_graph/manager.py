"""
Graph Manager - Sistema Completo de Análisis Estático

Coordina la construcción y gestión de IR, CFG y DFG para proyectos completos.
Integra el sistema original de Tree-sitter con el nuevo análisis estático.
"""

import logging
import json
from typing import Dict, List, Any, Optional, Set, Tuple
from pathlib import Path

# Imports del sistema original
from .graph_builder import GraphBuilder
from .incremental import IncrementalUpdater
from .file_hashing import FileHashManager
from .tree_sitter_loader import TreeSitterLoader
from .language_specs.base import get_language_spec

# Imports del nuevo sistema
from .ir.builder import get_ir_manager
from .cfg.builder import FileCFGBuilder
from .cfg.graph import ProjectCFG
from .dfg.builder import FileDFGBuilder
from .dfg.graph import ProjectDFG
from .language_specs.base import LanguageSpec
from .utils.incremental import IncrementalAnalysisManager

logger = logging.getLogger(__name__)

class StaticAnalysisManager:
    """
    Gestor completo de análisis estático.
    
    Coordina la construcción de IR, CFG y DFG para proyectos,
    manteniendo consistencia entre todos los niveles de análisis.
    """
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        # Usar el sistema de language_specs nuevo
        self.language_registry = None  # No necesitamos registry, usaremos get_language_spec directamente
        self.ir_manager = get_ir_manager()
        
        # Contenedores de grafos
        self.project_cfg = ProjectCFG()
        self.project_dfg = ProjectDFG()
        
        # Sistema incremental
        self.incremental_manager = IncrementalAnalysisManager(str(project_root))
        
        # Cache de especificaciones de lenguajes
        self._language_specs: Dict[str, LanguageSpec] = {}
        
        # Rutas de archivos de salida
        self.graphs_dir = self.project_root / ".hacki" / "graphs"
        self.ir_file = self.graphs_dir / "ir.json"
        self.cfg_file = self.graphs_dir / "cfg.json"
        self.dfg_file = self.graphs_dir / "dfg.json"
        self.graph_file = self.project_root / ".hacki" / "graph.json"
        
        # Cache de graph.json
        self._graph_data: Optional[Dict[str, Any]] = None
        self._graph_nodes_by_id: Dict[str, Dict[str, Any]] = {}
        self._graph_calls_by_location: Dict[Tuple[str, int], Dict[str, Any]] = {}  # (file_path, line) -> call_node
        self._graph_functions_by_name: Dict[str, List[Dict[str, Any]]] = {}  # function_name -> [function_nodes]
    
    def build_full_analysis(self, file_paths: List[str]) -> Dict[str, Any]:
        """
        Construye análisis estático completo para una lista de archivos.
        
        Si graph.json existe, usa los archivos de graph.json como fuente de verdad.
        Si no existe graph.json, usa la lista de archivos proporcionada.
        
        Args:
            file_paths: Lista de rutas de archivos a analizar (usada solo si graph.json no existe)
            
        Returns:
            Diccionario con resultados del análisis
        """
        # Usar graph.json como fuente de verdad si existe
        graph_files = self._get_files_from_graph_json()
        if graph_files:
            # Convertir rutas relativas a absolutas y verificar que existan
            from pathlib import Path
            valid_file_paths = []
            for f in graph_files:
                # Normalizar la ruta
                abs_path = self.project_root / Path(f)
                if abs_path.exists():
                    valid_file_paths.append(str(abs_path))
                else:
                    logger.warning(f"Archivo de graph.json no existe: {abs_path}")
            file_paths = valid_file_paths
            logger.info(f"Usando {len(file_paths)} archivos válidos de graph.json (de {len(graph_files)} totales)")
        else:
            logger.info(f"graph.json no disponible, usando {len(file_paths)} archivos proporcionados")
        
        logger.info(f"Iniciando análisis estático completo para {len(file_paths)} archivos")
        
        results = {
            "ir_files": {},
            "cfg_files": {},
            "dfg_files": {},
            "stats": {},
            "errors": []
        }
        
        try:
            # Paso 1: Construir IR para todos los archivos
            logger.info(f"Paso 1: Construyendo Intermediate Representation (IR) para {len(file_paths)} archivos")
            ir_files = self.ir_manager.build_ir_for_project(str(self.project_root), file_paths)
            logger.info(f"✓ IR completada: {len(ir_files)} archivos procesados exitosamente")
            
            # Paso 1.5: Resolver llamadas usando graph.json
            logger.info("Paso 1.5: Resolviendo llamadas usando graph.json")
            self._load_graph_data()
            self._resolve_function_calls_in_ir(ir_files)
            
            results["ir_files"] = {path: ir_file.to_dict() for path, ir_file in ir_files.items()}
            
            # Paso 2: Construir CFGs basándose en IR
            logger.info("Paso 2: Construyendo Control Flow Graphs (CFG)")
            for file_path, ir_file in ir_files.items():
                try:
                    language_spec = self._get_language_spec_for_file(file_path)
                    if language_spec:
                        cfg_builder = FileCFGBuilder(language_spec)
                        file_cfgs = cfg_builder.build_cfgs_for_file(ir_file)
                        self.project_cfg.add_file_cfg(file_path, cfg_builder)
                        results["cfg_files"][file_path] = cfg_builder.to_dict()
                    
                except Exception as e:
                    error_msg = f"Error construyendo CFG para {file_path}: {e}"
                    logger.error(error_msg)
                    results["errors"].append(error_msg)
            
            # Paso 3: Construir DFGs basándose en IR y CFG
            logger.info("Paso 3: Construyendo Data Flow Graphs (DFG)")
            for file_path, ir_file in ir_files.items():
                try:
                    file_cfg_builder = self.project_cfg.get_file_cfg(file_path)
                    if file_cfg_builder:
                        dfg_builder = FileDFGBuilder()
                        file_dfgs = dfg_builder.build_dfgs_for_file(ir_file, file_cfg_builder.function_cfgs)
                        self.project_dfg.add_file_dfgs(file_path, file_dfgs)
                        results["dfg_files"][file_path] = dfg_builder.to_dict()
                    
                except Exception as e:
                    error_msg = f"Error construyendo DFG para {file_path}: {e}"
                    logger.error(error_msg)
                    results["errors"].append(error_msg)
            
            # Paso 4: Generar estadísticas
            results["stats"] = self._generate_analysis_stats(ir_files)
            
            # Paso 5: Guardar resultados (incluyendo IR)
            self._save_analysis_results(ir_files)
            
            logger.info("Análisis estático completo finalizado exitosamente")
            
        except Exception as e:
            import traceback
            error_msg = f"Error en análisis estático completo: {e}"
            traceback_msg = traceback.format_exc()
            logger.error(f"{error_msg}\n{traceback_msg}")
            results["errors"].append(error_msg)
        
        return results
    
    def _load_graph_data(self) -> None:
        """
        Carga graph.json y construye índices para resolución rápida de llamadas.
        """
        if self._graph_data is not None:
            return  # Ya está cargado
        
        if not self.graph_file.exists():
            logger.warning(f"graph.json no encontrado en {self.graph_file}")
            self._graph_data = {}
            return
        
        try:
            with open(self.graph_file, 'r', encoding='utf-8') as f:
                self._graph_data = json.load(f)
            
            # Construir índices
            self._graph_nodes_by_id.clear()
            self._graph_calls_by_location.clear()
            self._graph_functions_by_name.clear()
            
            for node in self._graph_data.get("nodes", []):
                node_id = node.get("id")
                node_type = node.get("type")
                file_path = node.get("file_path", "")
                line = node.get("line_start", 0)
                
                # Índice por ID
                self._graph_nodes_by_id[node_id] = node
                
                # Índice de llamadas por ubicación
                if node_type == "call":
                    key = (file_path, line)
                    self._graph_calls_by_location[key] = node
                
                # Índice de funciones por nombre
                if node_type == "function":
                    func_name = node.get("name", "")
                    if func_name:
                        if func_name not in self._graph_functions_by_name:
                            self._graph_functions_by_name[func_name] = []
                        self._graph_functions_by_name[func_name].append(node)
            
            logger.info(f"graph.json cargado: {len(self._graph_nodes_by_id)} nodos, "
                       f"{len(self._graph_calls_by_location)} llamadas, "
                       f"{len(self._graph_functions_by_name)} funciones únicas")
        
        except Exception as e:
            logger.error(f"Error cargando graph.json: {e}")
            self._graph_data = {}
    
    def _get_files_from_graph_json(self) -> List[str]:
        """
        Extrae la lista de archivos únicos de graph.json.
        
        Returns:
            Lista de rutas de archivos (relativas al project_root)
        """
        if not self.graph_file.exists():
            logger.warning(f"graph.json no encontrado en {self.graph_file}")
            return []
        
        try:
            if self._graph_data is None:
                with open(self.graph_file, 'r', encoding='utf-8') as f:
                    self._graph_data = json.load(f)
            
            # Extraer archivos únicos de los nodos
            files_set = set()
            for node in self._graph_data.get("nodes", []):
                file_path = node.get("file_path", "")
                if file_path and node.get("type") == "file":
                    # Normalizar ruta
                    files_set.add(file_path)
            
            # También buscar en nodos que no son "file" pero tienen file_path
            for node in self._graph_data.get("nodes", []):
                file_path = node.get("file_path", "")
                if file_path:
                    files_set.add(file_path)
            
            files_list = sorted(list(files_set))
            logger.info(f"Extraídos {len(files_list)} archivos de graph.json")
            return files_list
        
        except Exception as e:
            logger.error(f"Error extrayendo archivos de graph.json: {e}")
            return []
    
    def _resolve_function_calls_in_ir(self, ir_files: Dict[str, Any]) -> None:
        """
        Resuelve llamadas de función en IR usando graph.json.
        
        Args:
            ir_files: Diccionario de IRFile por ruta de archivo
        """
        if not self._graph_data:
            logger.debug("graph.json no disponible, saltando resolución de llamadas")
            return
        
        from hacki_graph.ir.nodes import FunctionCall
        from pathlib import Path
        
        resolved_count = 0
        total_calls = 0
        
        # Construir índice de edges "calls" del graph.json
        call_edges = {}
        for edge in self._graph_data.get("edges", []):
            if edge.get("type") == "calls":
                source_id = edge.get("source")
                target_id = edge.get("target")
                if source_id and target_id:
                    call_edges[source_id] = target_id
        
        # Procesar cada archivo IR
        for file_path, ir_file in ir_files.items():
            # Normalizar ruta para comparación
            rel_path = str(Path(file_path).relative_to(self.project_root).as_posix())
            
            # Procesar funciones
            for func_name, ir_function in ir_file.functions.items():
                for node in ir_function.nodes:
                    if isinstance(node, FunctionCall):
                        total_calls += 1
                        
                        # Buscar nodo "call" en graph.json por ubicación
                        call_key = (rel_path, node.line)
                        graph_call_node = self._graph_calls_by_location.get(call_key)
                        
                        if graph_call_node:
                            # Encontrar edge "calls" que apunta a la función objetivo
                            call_node_id = graph_call_node.get("id")
                            target_function_id = call_edges.get(call_node_id)
                            
                            if target_function_id:
                                # Verificar que el target es realmente una función
                                target_node = self._graph_nodes_by_id.get(target_function_id)
                                if target_node and target_node.get("type") == "function":
                                    node.target_function_id = target_function_id
                                    node.graph_call_node_id = call_node_id
                                    resolved_count += 1
                                    logger.debug(
                                        f"Resuelta llamada {node.function_name} en {file_path}:{node.line} "
                                        f"-> función {target_function_id}"
                                    )
        
        logger.info(f"Resolución de llamadas: {resolved_count}/{total_calls} llamadas resueltas")
    
    def build_incremental_analysis(self, file_paths: List[str]) -> Dict[str, Any]:
        """
        Construye análisis estático incremental usando detección automática de cambios.
        
        Args:
            file_paths: Lista de todos los archivos del proyecto
            
        Returns:
            Diccionario con resultados del análisis incremental
        """
        logger.info(f"Iniciando análisis estático incremental para {len(file_paths)} archivos")
        
        try:
            # Usar el sistema incremental avanzado
            results = self.incremental_manager.update_analysis_incremental(
                file_paths, 
                self._language_specs
            )
            
            # Recargar análisis actualizado en memoria
            self._load_analysis_results()
            
            # Agregar estadísticas adicionales
            if "stats" not in results:
                results["stats"] = {}
            
            results["stats"].update({
                "total_functions": len(self.project_cfg.get_all_functions()),
                "cfg_stats": self.project_cfg.get_project_stats(),
                "dfg_stats": self.project_dfg.get_project_stats(),
                "incremental_stats": self.incremental_manager.get_incremental_stats()
            })
            
            logger.info(f"Análisis incremental completado: {len(results.get('updated_files', []))} archivos actualizados")
            
            return results
            
        except Exception as e:
            error_msg = f"Error en análisis incremental: {e}"
            logger.error(error_msg)
            return {
                "updated_files": [],
                "stats": {},
                "errors": [error_msg],
                "changes_detected": {}
            }
    
    def get_function_analysis(self, file_path: str, function_name: str) -> Optional[Dict[str, Any]]:
        """
        Obtiene análisis completo de una función específica.
        
        Args:
            file_path: Ruta del archivo
            function_name: Nombre de la función
            
        Returns:
            Diccionario con IR, CFG y DFG de la función
        """
        try:
            # Cargar análisis si no está en memoria
            if not self.project_cfg.file_cfgs and not self.project_dfg.file_dfgs:
                self._load_analysis_results()
            
            # Obtener CFG
            cfg = self.project_cfg.get_function_cfg(file_path, function_name)
            cfg_dict = cfg.to_dict() if cfg else None
            
            # Obtener DFG
            dfg = self.project_dfg.get_function_dfg(file_path, function_name)
            dfg_dict = dfg.to_dict() if dfg else None
            
            if cfg_dict or dfg_dict:
                return {
                    "file_path": file_path,
                    "function_name": function_name,
                    "cfg": cfg_dict,
                    "dfg": dfg_dict,
                    "stats": {
                        "cfg_blocks": len(cfg.blocks) if cfg else 0,
                        "cfg_edges": len(cfg.edges) if cfg else 0,
                        "dfg_nodes": len(dfg.nodes) if dfg else 0,
                        "dfg_edges": len(dfg.edges) if dfg else 0
                    }
                }
            
        except Exception as e:
            logger.error(f"Error obteniendo análisis de función {file_path}:{function_name}: {e}")
        
        return None
    
    def get_project_analysis_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas completas del análisis del proyecto."""
        try:
            # Cargar análisis si no está en memoria
            if not self.project_cfg.file_cfgs and not self.project_dfg.file_dfgs:
                self._load_analysis_results()
            
            cfg_stats = self.project_cfg.get_project_stats()
            dfg_stats = self.project_dfg.get_project_stats()
            
            return {
                "cfg": cfg_stats,
                "dfg": dfg_stats,
                "combined": {
                    "total_files": max(cfg_stats.get("total_files", 0), dfg_stats.get("total_files", 0)),
                    "total_functions": max(cfg_stats.get("total_functions", 0), dfg_stats.get("total_functions", 0)),
                    "analysis_coverage": {
                        "cfg_coverage": len(self.project_cfg.file_cfgs),
                        "dfg_coverage": len(self.project_dfg.file_dfgs)
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Error obteniendo estadísticas del proyecto: {e}")
            return {}
    
    def find_complex_functions(self, min_blocks: int = 10) -> List[Dict[str, Any]]:
        """Encuentra funciones con alta complejidad."""
        try:
            if not self.project_cfg.file_cfgs:
                self._load_analysis_results()
            
            return self.project_cfg.find_functions_with_complexity(min_blocks)
            
        except Exception as e:
            logger.error(f"Error buscando funciones complejas: {e}")
            return []
    
    def find_data_flow_issues(self) -> Dict[str, List[Dict[str, Any]]]:
        """Encuentra problemas potenciales en el flujo de datos."""
        issues = {
            "unused_definitions": [],
            "uninitialized_uses": [],
            "circular_dependencies": []
        }
        
        try:
            if not self.project_dfg.file_dfgs:
                self._load_analysis_results()
            
            for file_path, file_dfgs in self.project_dfg.file_dfgs.items():
                for function_name, dfg in file_dfgs.items():
                    # Definiciones no usadas
                    unused = dfg.find_unused_definitions()
                    for node in unused:
                        issues["unused_definitions"].append({
                            "file_path": file_path,
                            "function_name": function_name,
                            "node_id": node.id,
                            "variables": node.writes,
                            "line": node.line
                        })
                    
                    # Usos no inicializados
                    uninitialized = dfg.find_uninitialized_uses()
                    for node, variable in uninitialized:
                        issues["uninitialized_uses"].append({
                            "file_path": file_path,
                            "function_name": function_name,
                            "node_id": node.id,
                            "variable": variable,
                            "line": node.line
                        })
                    
                    # Componentes fuertemente conectados (dependencias circulares)
                    components = dfg.get_strongly_connected_components()
                    for component in components:
                        if len(component) > 1:
                            issues["circular_dependencies"].append({
                                "file_path": file_path,
                                "function_name": function_name,
                                "nodes": component
                            })
            
        except Exception as e:
            logger.error(f"Error buscando problemas de flujo de datos: {e}")
        
        return issues
    
    def _get_language_spec_for_file(self, file_path: str) -> Optional[LanguageSpec]:
        """Obtiene la especificación de lenguaje para un archivo."""
        from pathlib import Path
        file_extension = Path(file_path).suffix.lower()
        
        # Usar el sistema nuevo directamente
        language_spec = get_language_spec(file_extension)
        if language_spec:
            return language_spec
        
        # Si no está en el registry nuevo, crear dinámicamente
        language_name = self._get_language_name_from_extension(file_extension)
        if not language_name:
            return None
        
        if language_name not in self._language_specs:
            # Importar dinámicamente la especificación
            try:
                if language_name == "python":
                    from .language_specs.python import PythonLanguageSpec
                    self._language_specs[language_name] = PythonLanguageSpec()
                elif language_name == "javascript":
                    from .language_specs.js_ts import JavaScriptLanguageSpec
                    self._language_specs[language_name] = JavaScriptLanguageSpec()
                elif language_name == "typescript":
                    from .language_specs.js_ts import TypeScriptLanguageSpec
                    self._language_specs[language_name] = TypeScriptLanguageSpec()
                elif language_name == "java":
                    from .language_specs.java import JavaLanguageSpec
                    self._language_specs[language_name] = JavaLanguageSpec()
                elif language_name == "c_sharp":
                    from .language_specs.csharp import CSharpLanguageSpec
                    self._language_specs[language_name] = CSharpLanguageSpec()
                elif language_name == "go":
                    from .language_specs.go import GoLanguageSpec
                    self._language_specs[language_name] = GoLanguageSpec()
                elif language_name == "php":
                    from .language_specs.php import PHPLanguageSpec
                    self._language_specs[language_name] = PHPLanguageSpec()
                else:
                    logger.warning(f"Especificación de lenguaje no encontrada para {language_name}")
                    return None
                    
            except ImportError as e:
                logger.error(f"Error importando especificación para {language_name}: {e}")
                return None
        
        return self._language_specs.get(language_name)
    
    def _get_language_name_from_extension(self, file_extension: str) -> Optional[str]:
        """Mapea extensiones de archivo a nombres de lenguaje."""
        extension_map = {
            '.py': 'python',
            '.pyw': 'python',
            '.js': 'javascript',
            '.jsx': 'javascript',
            '.ts': 'typescript',
            '.tsx': 'typescript',
            '.java': 'java',
            '.cs': 'csharp',
            '.go': 'go',
            '.php': 'php'
        }
        return extension_map.get(file_extension.lower())
    
    def _generate_analysis_stats(self, ir_files: Dict[str, Any]) -> Dict[str, Any]:
        """Genera estadísticas del análisis."""
        ir_stats = self.ir_manager.get_ir_stats(ir_files)
        cfg_stats = self.project_cfg.get_project_stats()
        dfg_stats = self.project_dfg.get_project_stats()
        
        return {
            "ir": ir_stats,
            "cfg": cfg_stats,
            "dfg": dfg_stats,
            "summary": {
                "total_files_analyzed": len(ir_files),
                "total_functions": ir_stats.get("total_functions", 0),
                "total_ir_nodes": ir_stats.get("total_nodes", 0),
                "total_cfg_blocks": cfg_stats.get("total_blocks", 0),
                "total_dfg_nodes": dfg_stats.get("total_nodes", 0)
            }
        }
    
    def _save_analysis_results(self, ir_files: Optional[Dict[str, Any]] = None):
        """
        Guarda todos los resultados del análisis.
        
        Args:
            ir_files: Diccionario de archivos IR a guardar (opcional)
        """
        try:
            # Crear directorio si no existe
            self.graphs_dir.mkdir(parents=True, exist_ok=True)
            
            # Guardar IR si se proporciona
            if ir_files is not None:
                self.ir_manager.save_ir_to_json(ir_files, str(self.ir_file))
            
            # Guardar CFGs
            self.project_cfg.save_to_json(str(self.cfg_file))
            
            # Guardar DFGs
            self.project_dfg.save_to_json(str(self.dfg_file))
            
            logger.debug("Resultados de análisis guardados exitosamente")
            
        except Exception as e:
            logger.error(f"Error guardando resultados de análisis: {e}")
    
    def _load_analysis_results(self):
        """Carga resultados de análisis existentes."""
        try:
            # Cargar CFGs
            if self.cfg_file.exists():
                self.project_cfg.load_from_json(str(self.cfg_file), self._language_specs)
            
            # Cargar DFGs
            if self.dfg_file.exists():
                self.project_dfg.load_from_json(str(self.dfg_file))
            
            logger.debug("Resultados de análisis cargados exitosamente")
            
        except Exception as e:
            logger.error(f"Error cargando resultados de análisis: {e}")
    
    def analysis_exists(self) -> bool:
        """Verifica si existe análisis previo válido (no vacío)."""
        # Verificar si hay datos en memoria
        if bool(self.project_cfg.file_cfgs) or bool(self.project_dfg.file_dfgs):
            return True
        
        # Verificar archivos en disco y que tengan contenido válido
        if self.cfg_file.exists():
            try:
                with open(self.cfg_file, 'r', encoding='utf-8') as f:
                    cfg_data = json.load(f)
                    if cfg_data.get("metadata", {}).get("total_files", 0) > 0:
                        return True
                    if cfg_data.get("files", {}):
                        return True
            except Exception:
                pass
        
        if self.dfg_file.exists():
            try:
                with open(self.dfg_file, 'r', encoding='utf-8') as f:
                    dfg_data = json.load(f)
                    if dfg_data.get("metadata", {}).get("total_files", 0) > 0:
                        return True
                    if dfg_data.get("files", {}):
                        return True
            except Exception:
                pass
        
        if self.ir_file.exists():
            try:
                with open(self.ir_file, 'r', encoding='utf-8') as f:
                    ir_data = json.load(f)
                    if ir_data.get("metadata", {}).get("total_files", 0) > 0:
                        return True
                    if ir_data.get("files", {}):
                        return True
            except Exception:
                pass
        
        return False
    
    def detect_file_changes(self, file_paths: List[str]) -> Dict[str, List[str]]:
        """
        Detecta cambios en archivos sin actualizar el análisis.
        
        Args:
            file_paths: Lista de archivos a verificar
            
        Returns:
            Diccionario con cambios detectados
        """
        return self.incremental_manager.detect_changes(file_paths)
    
    def get_dependency_graph(self, file_paths: List[str]) -> Dict[str, Set[str]]:
        """Obtiene grafo de dependencias entre archivos."""
        return self.incremental_manager.get_dependency_graph(file_paths)
    
    def find_affected_files(self, changed_files: List[str], file_paths: List[str]) -> Set[str]:
        """
        Encuentra archivos que podrían verse afectados por cambios.
        
        Args:
            changed_files: Lista de archivos modificados
            file_paths: Lista de todos los archivos del proyecto
            
        Returns:
            Set de archivos potencialmente afectados
        """
        dependency_graph = self.get_dependency_graph(file_paths)
        return self.incremental_manager.find_affected_files(changed_files, dependency_graph)
    
    def get_incremental_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del sistema incremental."""
        return self.incremental_manager.get_incremental_stats()
    
    def force_rebuild_file(self, file_path: str) -> Dict[str, Any]:
        """
        Fuerza la reconstrucción del análisis para un archivo específico.
        
        Args:
            file_path: Ruta del archivo a reconstruir
            
        Returns:
            Diccionario con resultados de la reconstrucción
        """
        logger.info(f"Forzando reconstrucción para {file_path}")
        
        try:
            # Determinar lenguaje
            language_spec = self._get_language_spec_for_file(file_path)
            if not language_spec:
                return {
                    "success": False,
                    "error": f"Lenguaje no soportado para {file_path}"
                }
            
            # Construir IR
            ir_file = self.ir_manager.build_ir_for_file(file_path, language_spec.tree_sitter_language)
            if not ir_file:
                return {
                    "success": False,
                    "error": f"No se pudo construir IR para {file_path}"
                }
            
            # Construir CFG
            cfg_builder = FileCFGBuilder(language_spec)
            file_cfgs = cfg_builder.build_cfgs_for_file(ir_file)
            self.project_cfg.add_file_cfg(file_path, cfg_builder)
            
            # Construir DFG
            dfg_builder = FileDFGBuilder()
            file_dfgs = dfg_builder.build_dfgs_for_file(ir_file, file_cfgs)
            self.project_dfg.add_file_dfgs(file_path, file_dfgs)
            
            # Guardar resultados
            self._save_analysis_results()
            
            # Actualizar hash del archivo
            from pathlib import Path
            if Path(file_path).exists():
                current_hash = self.incremental_manager.hash_manager.calculate_sha1(Path(file_path))
                hashes = self.incremental_manager.hash_manager.load_hashes()
                hashes[file_path] = current_hash
                self.incremental_manager.hash_manager.save_hashes(hashes)
            
            return {
                "success": True,
                "functions_analyzed": len(file_cfgs),
                "ir_nodes": len(ir_file.module_nodes) + sum(len(f.nodes) for f in ir_file.functions.values())
            }
            
        except Exception as e:
            error_msg = f"Error reconstruyendo {file_path}: {e}"
            logger.error(error_msg)
            return {
                "success": False,
                "error": error_msg
            }

class EnhancedGraphManager:
    """
    GraphManager mejorado que integra el sistema original con análisis estático.
    
    Mantiene compatibilidad con la API existente mientras agrega nuevas capacidades.
    """
    
    def __init__(self, project_root: str = "."):
        self.project_root = Path(project_root)
        
        # Sistema original
        self.graph_builder = GraphBuilder(str(project_root))
        self.incremental_updater = IncrementalUpdater(str(project_root))
        self.hash_manager = FileHashManager(str(project_root))
        
        # Nuevo sistema de análisis estático
        self.static_analysis = StaticAnalysisManager(str(project_root))
    
    # API original (compatibilidad)
    def build_full_graph(self) -> dict:
        """Construye el grafo completo desde cero (Tree-sitter)."""
        return self.graph_builder.build_full_graph()
    
    def update_incremental_graph(self, files_to_review: Optional[List[Path]] = None) -> dict:
        """Actualiza el grafo de forma incremental."""
        return self.incremental_updater.update_graph()
    
    def save_graph(self, graph: dict) -> None:
        """Guarda el grafo en .hacki/graph.json."""
        self.graph_builder.save_graph(graph)
    
    def load_graph(self) -> dict:
        """Carga el grafo desde .hacki/graph.json."""
        return self.graph_builder.load_graph()
    
    def graph_exists(self) -> bool:
        """Verifica si existe un grafo guardado."""
        return self.graph_builder.graph_exists()
    
    # Nueva API de análisis estático
    def build_full_static_analysis(self, file_paths: List[str]) -> Dict[str, Any]:
        """Construye análisis estático completo (IR, CFG, DFG)."""
        return self.static_analysis.build_full_analysis(file_paths)
    
    def update_incremental_static_analysis(self, file_paths: List[str]) -> Dict[str, Any]:
        """Actualiza análisis estático de forma incremental con detección automática de cambios."""
        return self.static_analysis.build_incremental_analysis(file_paths)
    
    def get_function_analysis(self, file_path: str, function_name: str) -> Optional[Dict[str, Any]]:
        """Obtiene análisis completo de una función."""
        return self.static_analysis.get_function_analysis(file_path, function_name)
    
    def get_analysis_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del análisis estático."""
        return self.static_analysis.get_project_analysis_stats()
    
    def find_complex_functions(self, min_blocks: int = 10) -> List[Dict[str, Any]]:
        """Encuentra funciones complejas."""
        return self.static_analysis.find_complex_functions(min_blocks)
    
    def find_data_flow_issues(self) -> Dict[str, List[Dict[str, Any]]]:
        """Encuentra problemas de flujo de datos."""
        return self.static_analysis.find_data_flow_issues()
    
    def static_analysis_exists(self) -> bool:
        """Verifica si existe análisis estático previo."""
        return self.static_analysis.analysis_exists()
    
    # Nuevas funcionalidades incrementales
    def detect_file_changes(self, file_paths: List[str]) -> Dict[str, List[str]]:
        """Detecta cambios en archivos."""
        return self.static_analysis.detect_file_changes(file_paths)
    
    def get_dependency_graph(self, file_paths: List[str]) -> Dict[str, Set[str]]:
        """Obtiene grafo de dependencias entre archivos."""
        return self.static_analysis.get_dependency_graph(file_paths)
    
    def find_affected_files(self, changed_files: List[str], file_paths: List[str]) -> Set[str]:
        """Encuentra archivos afectados por cambios."""
        return self.static_analysis.find_affected_files(changed_files, file_paths)
    
    def get_incremental_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del sistema incremental."""
        return self.static_analysis.get_incremental_stats()
    
    def force_rebuild_file(self, file_path: str) -> Dict[str, Any]:
        """Fuerza reconstrucción de análisis para un archivo."""
        return self.static_analysis.force_rebuild_file(file_path)
    
    # API combinada
    def build_complete_analysis(self, file_paths: List[str]) -> Dict[str, Any]:
        """
        Construye análisis completo: Tree-sitter + análisis estático.
        
        Args:
            file_paths: Lista de archivos a analizar
            
        Returns:
            Diccionario con ambos tipos de análisis
        """
        results = {
            "tree_sitter_graph": {},
            "static_analysis": {},
            "combined_stats": {},
            "errors": []
        }
        
        try:
            # Construir grafo Tree-sitter
            logger.info("Construyendo grafo Tree-sitter")
            tree_sitter_graph = self.build_full_graph()
            results["tree_sitter_graph"] = tree_sitter_graph
            
            # Construir análisis estático
            logger.info("Construyendo análisis estático")
            static_analysis = self.build_full_static_analysis(file_paths)
            results["static_analysis"] = static_analysis
            
            # Combinar estadísticas
            results["combined_stats"] = {
                "tree_sitter": {
                    "nodes": len(tree_sitter_graph.get("nodes", [])),
                    "edges": len(tree_sitter_graph.get("edges", []))
                },
                "static_analysis": static_analysis.get("stats", {}),
                "total_files": len(file_paths)
            }
            
            logger.info("Análisis completo finalizado exitosamente")
            
        except Exception as e:
            error_msg = f"Error en análisis completo: {e}"
            logger.error(error_msg)
            results["errors"].append(error_msg)
        
        return results
