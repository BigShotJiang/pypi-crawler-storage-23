"""
Incremental Analysis System

Sistema para análisis incremental que detecta cambios en archivos
y actualiza solo las partes necesarias del análisis estático.
"""

import logging
import json
from typing import Dict, List, Any, Optional, Set, Tuple
from pathlib import Path
from datetime import datetime

from ..file_hashing import FileHashManager
from ..ir.builder import get_ir_manager
from ..cfg.builder import FileCFGBuilder
from ..dfg.builder import FileDFGBuilder
from ..language_specs.base import LanguageSpec

logger = logging.getLogger(__name__)

class IncrementalAnalysisManager:
    """
    Gestor de análisis incremental.
    
    Detecta cambios en archivos y actualiza solo las partes necesarias
    del análisis estático (IR, CFG, DFG).
    """
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.hash_manager = FileHashManager(str(project_root))
        self.ir_manager = get_ir_manager()
        
        # Rutas de archivos de análisis
        self.graphs_dir = self.project_root / ".hacki" / "graphs"
        self.incremental_state_file = self.graphs_dir / "incremental_state.json"
        
        # Estado incremental
        self.incremental_state = self._load_incremental_state()
    
    def detect_changes(self, file_paths: List[str]) -> Dict[str, List[str]]:
        """
        Detecta cambios en archivos comparando con hashes previos.
        
        Args:
            file_paths: Lista de archivos a verificar
            
        Returns:
            Diccionario con listas de archivos: added, modified, deleted
        """
        logger.info(f"Detectando cambios en {len(file_paths)} archivos")
        
        # Cargar hashes previos
        previous_hashes = self.hash_manager.load_hashes()
        
        # Calcular hashes actuales
        current_hashes = {}
        for file_path in file_paths:
            try:
                if Path(file_path).exists():
                    current_hashes[file_path] = self.hash_manager.calculate_sha1(Path(file_path))
            except Exception as e:
                logger.warning(f"Error calculando hash para {file_path}: {e}")
        
        # Detectar cambios
        added_files = []
        modified_files = []
        deleted_files = []
        
        # Archivos nuevos o modificados
        for file_path, current_hash in current_hashes.items():
            if file_path not in previous_hashes:
                added_files.append(file_path)
            elif previous_hashes[file_path] != current_hash:
                modified_files.append(file_path)
        
        # Archivos eliminados
        for file_path in previous_hashes:
            if file_path not in current_hashes:
                deleted_files.append(file_path)
        
        changes = {
            "added": added_files,
            "modified": modified_files,
            "deleted": deleted_files
        }
        
        logger.info(f"Cambios detectados: {len(added_files)} nuevos, "
                   f"{len(modified_files)} modificados, {len(deleted_files)} eliminados")
        
        return changes
    
    def update_analysis_incremental(self, file_paths: List[str], 
                                   language_specs: Dict[str, LanguageSpec]) -> Dict[str, Any]:
        """
        Actualiza análisis de forma incremental.
        
        Args:
            file_paths: Lista de archivos del proyecto
            language_specs: Especificaciones de lenguajes
            
        Returns:
            Diccionario con resultados de la actualización
        """
        logger.info("Iniciando actualización incremental del análisis")
        
        results = {
            "changes_detected": {},
            "updated_files": [],
            "errors": [],
            "stats": {},
            "timestamp": datetime.now().isoformat()
        }
        
        try:
            # Detectar cambios
            changes = self.detect_changes(file_paths)
            results["changes_detected"] = changes
            
            # Archivos que necesitan actualización
            files_to_update = changes["added"] + changes["modified"]
            
            if not files_to_update and not changes["deleted"]:
                logger.info("No se detectaron cambios, análisis actualizado")
                results["stats"] = {"message": "No changes detected"}
                return results
            
            # Cargar análisis existente
            existing_ir = self._load_existing_ir()
            existing_cfg = self._load_existing_cfg()
            existing_dfg = self._load_existing_dfg()
            
            # Actualizar archivos modificados/nuevos
            updated_ir = existing_ir.copy()
            updated_cfg = existing_cfg.copy()
            updated_dfg = existing_dfg.copy()
            
            for file_path in files_to_update:
                try:
                    logger.debug(f"Actualizando análisis para {file_path}")
                    
                    # Determinar lenguaje
                    language_spec = self._get_language_spec_for_file(file_path, language_specs)
                    if not language_spec:
                        logger.warning(f"Lenguaje no soportado para {file_path}")
                        continue
                    
                    # Actualizar IR
                    ir_file = self.ir_manager.build_ir_for_file(file_path, language_spec.tree_sitter_language)
                    if ir_file:
                        updated_ir[file_path] = ir_file.to_dict()
                        
                        # Actualizar CFG
                        cfg_builder = FileCFGBuilder(language_spec)
                        file_cfgs = cfg_builder.build_cfgs_for_file(ir_file)
                        updated_cfg[file_path] = cfg_builder.to_dict()
                        
                        # Actualizar DFG
                        dfg_builder = FileDFGBuilder()
                        file_dfgs = dfg_builder.build_dfgs_for_file(ir_file, file_cfgs)
                        updated_dfg[file_path] = dfg_builder.to_dict()
                        
                        results["updated_files"].append(file_path)
                    
                except Exception as e:
                    error_msg = f"Error actualizando {file_path}: {e}"
                    logger.error(error_msg)
                    results["errors"].append(error_msg)
            
            # Remover archivos eliminados
            for file_path in changes["deleted"]:
                updated_ir.pop(file_path, None)
                updated_cfg.pop(file_path, None)
                updated_dfg.pop(file_path, None)
                logger.debug(f"Removido análisis para archivo eliminado: {file_path}")
            
            # Guardar análisis actualizado
            self._save_updated_analysis(updated_ir, updated_cfg, updated_dfg)
            
            # Actualizar hashes
            current_hashes = {}
            for file_path in file_paths:
                if Path(file_path).exists():
                    current_hashes[file_path] = self.hash_manager.calculate_sha1(Path(file_path))
            
            self.hash_manager.save_hashes(current_hashes)
            
            # Actualizar estado incremental
            self._update_incremental_state(results)
            
            # Generar estadísticas
            results["stats"] = {
                "total_files_analyzed": len(updated_ir),
                "files_updated": len(results["updated_files"]),
                "files_deleted": len(changes["deleted"]),
                "errors": len(results["errors"])
            }
            
            logger.info(f"Actualización incremental completada: "
                       f"{len(results['updated_files'])} archivos actualizados")
            
        except Exception as e:
            error_msg = f"Error en actualización incremental: {e}"
            logger.error(error_msg)
            results["errors"].append(error_msg)
        
        return results
    
    def ensure_file_in_analysis(self, file_path: str, 
                                language_specs: Dict[str, LanguageSpec]) -> bool:
        """
        Asegura que un archivo esté en el análisis.
        
        Si el archivo no está en el análisis, lo agrega incrementalmente
        sin regenerar todo el análisis.
        
        Args:
            file_path: Ruta del archivo a asegurar
            language_specs: Especificaciones de lenguajes
            
        Returns:
            True si el archivo ya estaba en el análisis,
            False si se agregó
        """
        logger.info(f"Asegurando que {file_path} esté en el análisis")
        
        # Verificar si el archivo ya está en el análisis
        existing_ir = self._load_existing_ir()
        if file_path in existing_ir:
            logger.debug(f"Archivo {file_path} ya está en el análisis")
            return True
        
        # El archivo no está en el análisis, agregarlo
        logger.info(f"Archivo {file_path} no está en el análisis, agregándolo...")
        
        try:
            # Determinar lenguaje
            language_spec = self._get_language_spec_for_file(file_path, language_specs)
            if not language_spec:
                logger.warning(f"Lenguaje no soportado para {file_path}")
                return False
            
            # Construir IR para este archivo
            ir_file = self.ir_manager.build_ir_for_file(file_path, language_spec.tree_sitter_language)
            if not ir_file:
                logger.warning(f"No se pudo construir IR para {file_path}")
                return False
            
            # Cargar análisis existente
            existing_ir = self._load_existing_ir()
            existing_cfg = self._load_existing_cfg()
            existing_dfg = self._load_existing_dfg()
            
            # Agregar IR del nuevo archivo
            existing_ir[file_path] = ir_file.to_dict()
            
            # Construir CFG para este archivo
            cfg_builder = FileCFGBuilder(language_spec)
            file_cfgs = cfg_builder.build_cfgs_for_file(ir_file)
            existing_cfg[file_path] = cfg_builder.to_dict()
            
            # Construir DFG para este archivo
            dfg_builder = FileDFGBuilder()
            file_dfgs = dfg_builder.build_dfgs_for_file(ir_file, file_cfgs)
            existing_dfg[file_path] = dfg_builder.to_dict()
            
            # Guardar análisis actualizado
            self._save_updated_analysis(existing_ir, existing_cfg, existing_dfg)
            
            # Actualizar hash del archivo
            if Path(file_path).exists():
                file_hash = self.hash_manager.calculate_sha1(Path(file_path))
                current_hashes = self.hash_manager.load_hashes()
                current_hashes[file_path] = file_hash
                self.hash_manager.save_hashes(current_hashes)
            
            logger.info(f"Archivo {file_path} agregado al análisis exitosamente")
            return False  # Se agregó, no estaba antes
            
        except Exception as e:
            logger.error(f"Error agregando archivo {file_path} al análisis: {e}")
            return False
    
    def get_dependency_graph(self, file_paths: List[str]) -> Dict[str, Set[str]]:
        """
        Construye grafo de dependencias entre archivos.
        
        Args:
            file_paths: Lista de archivos
            
        Returns:
            Diccionario con file_path -> set(dependencies)
        """
        dependencies = {}
        
        try:
            # Cargar análisis existente
            existing_ir = self._load_existing_ir()
            
            for file_path in file_paths:
                file_deps = set()
                
                # Analizar imports en el IR
                ir_data = existing_ir.get(file_path, {})
                functions = ir_data.get("functions", {})
                module_nodes = ir_data.get("module_nodes", [])
                
                # Buscar imports en funciones
                for function_data in functions.values():
                    nodes = function_data.get("nodes", [])
                    for node in nodes:
                        if node.get("type") == "FunctionCall":
                            # Analizar llamadas para detectar dependencias externas
                            function_name = node.get("function_name", "")
                            if "." in function_name:
                                # Posible import: module.function
                                module_name = function_name.split(".")[0]
                                file_deps.add(module_name)
                
                # Buscar imports a nivel módulo
                for node in module_nodes:
                    if node.get("type") in ["Import", "ImportFrom"]:
                        # Extraer información de import
                        # (simplificado - en implementación real se analizaría más detalladamente)
                        pass
                
                dependencies[file_path] = file_deps
        
        except Exception as e:
            logger.error(f"Error construyendo grafo de dependencias: {e}")
        
        return dependencies
    
    def find_affected_files(self, changed_files: List[str], 
                           dependency_graph: Dict[str, Set[str]]) -> Set[str]:
        """
        Encuentra archivos afectados por cambios usando el grafo de dependencias.
        
        Args:
            changed_files: Lista de archivos modificados
            dependency_graph: Grafo de dependencias
            
        Returns:
            Set de archivos que podrían verse afectados
        """
        affected = set(changed_files)
        
        # Propagación simple de dependencias
        for file_path, deps in dependency_graph.items():
            for changed_file in changed_files:
                # Si el archivo depende de un archivo modificado
                if any(changed_file.endswith(dep) for dep in deps):
                    affected.add(file_path)
        
        return affected
    
    def _get_language_spec_for_file(self, file_path: str, 
                                   language_specs: Dict[str, LanguageSpec]) -> Optional[LanguageSpec]:
        """Obtiene especificación de lenguaje para un archivo."""
        file_extension = Path(file_path).suffix.lower()
        
        for spec in language_specs.values():
            if file_extension in spec.file_extensions:
                return spec
        
        return None
    
    def _load_existing_ir(self) -> Dict[str, Any]:
        """Carga IR existente."""
        ir_file = self.graphs_dir / "ir.json"
        
        if ir_file.exists():
            try:
                with open(ir_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("files", {})
            except Exception as e:
                logger.warning(f"Error cargando IR existente: {e}")
        
        return {}
    
    def _load_existing_cfg(self) -> Dict[str, Any]:
        """Carga CFG existente."""
        cfg_file = self.graphs_dir / "cfg.json"
        
        if cfg_file.exists():
            try:
                with open(cfg_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("files", {})
            except Exception as e:
                logger.warning(f"Error cargando CFG existente: {e}")
        
        return {}
    
    def _load_existing_dfg(self) -> Dict[str, Any]:
        """Carga DFG existente."""
        dfg_file = self.graphs_dir / "dfg.json"
        
        if dfg_file.exists():
            try:
                with open(dfg_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("files", {})
            except Exception as e:
                logger.warning(f"Error cargando DFG existente: {e}")
        
        return {}
    
    def _save_updated_analysis(self, ir_data: Dict[str, Any], 
                              cfg_data: Dict[str, Any], 
                              dfg_data: Dict[str, Any]):
        """Guarda análisis actualizado."""
        try:
            # Crear directorio si no existe
            self.graphs_dir.mkdir(parents=True, exist_ok=True)
            
            # Guardar IR
            ir_file = self.graphs_dir / "ir.json"
            with open(ir_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "metadata": {
                        "total_files": len(ir_data),
                        "timestamp": datetime.now().isoformat()
                    },
                    "files": ir_data
                }, f, indent=2, ensure_ascii=False)
            
            # Guardar CFG
            cfg_file = self.graphs_dir / "cfg.json"
            with open(cfg_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "metadata": {
                        "total_files": len(cfg_data),
                        "timestamp": datetime.now().isoformat()
                    },
                    "files": cfg_data
                }, f, indent=2, ensure_ascii=False)
            
            # Guardar DFG
            dfg_file = self.graphs_dir / "dfg.json"
            with open(dfg_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "metadata": {
                        "total_files": len(dfg_data),
                        "timestamp": datetime.now().isoformat()
                    },
                    "files": dfg_data
                }, f, indent=2, ensure_ascii=False)
            
            logger.debug("Análisis actualizado guardado exitosamente")
            
        except Exception as e:
            logger.error(f"Error guardando análisis actualizado: {e}")
    
    def _load_incremental_state(self) -> Dict[str, Any]:
        """Carga estado incremental."""
        if self.incremental_state_file.exists():
            try:
                with open(self.incremental_state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Error cargando estado incremental: {e}")
        
        return {
            "last_update": None,
            "total_updates": 0,
            "last_changes": {}
        }
    
    def _update_incremental_state(self, update_results: Dict[str, Any]):
        """Actualiza estado incremental."""
        try:
            self.incremental_state.update({
                "last_update": datetime.now().isoformat(),
                "total_updates": self.incremental_state.get("total_updates", 0) + 1,
                "last_changes": update_results.get("changes_detected", {}),
                "last_stats": update_results.get("stats", {})
            })
            
            # Guardar estado
            self.graphs_dir.mkdir(parents=True, exist_ok=True)
            with open(self.incremental_state_file, 'w', encoding='utf-8') as f:
                json.dump(self.incremental_state, f, indent=2, ensure_ascii=False)
            
        except Exception as e:
            logger.error(f"Error actualizando estado incremental: {e}")
    
    def get_incremental_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del sistema incremental."""
        return {
            "state": self.incremental_state,
            "files_tracked": len(self.hash_manager.load_hashes()),
            "analysis_files_exist": {
                "ir": (self.graphs_dir / "ir.json").exists(),
                "cfg": (self.graphs_dir / "cfg.json").exists(),
                "dfg": (self.graphs_dir / "dfg.json").exists()
            }
        }
