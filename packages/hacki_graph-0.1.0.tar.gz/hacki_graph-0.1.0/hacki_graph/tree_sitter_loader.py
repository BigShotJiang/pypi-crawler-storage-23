"""
Tree-sitter Loader Module

Maneja la carga y configuración de gramáticas Tree-sitter para diferentes lenguajes.
Proporciona una interfaz unificada para parsear código en múltiples lenguajes.
"""

import os
import sys
import logging
from typing import Dict, Optional, Any
from pathlib import Path

logger = logging.getLogger(__name__)

class TreeSitterLoader:
    """
    Carga y gestiona las gramáticas Tree-sitter para diferentes lenguajes.
    """
    
    def __init__(self):
        self._parsers: Dict[str, Any] = {}
        self._languages: Dict[str, Any] = {}
        self._initialized = False
        
    def initialize(self) -> bool:
        """
        Inicializa Tree-sitter y carga las gramáticas disponibles.
        
        Returns:
            bool: True si se inicializó correctamente, False en caso contrario
        """
        if self._initialized:
            return True
            
        try:
            import tree_sitter_languages
            self._tree_sitter_languages = tree_sitter_languages
            self._initialized = True
            logger.info("Tree-sitter inicializado correctamente")
            
            # Verificar si estamos en un ejecutable empaquetado
            if hasattr(sys, "_MEIPASS"):
                logger.debug(f"Ejecutable empaquetado detectado, _MEIPASS: {sys._MEIPASS}")
                # Verificar si tree-sitter-languages está disponible
                try:
                    # Intentar cargar un parser de prueba para verificar que funciona
                    test_parser = tree_sitter_languages.get_parser("python")
                    if test_parser:
                        logger.debug("Parser de prueba (python) cargado correctamente en ejecutable empaquetado")
                    else:
                        logger.warning("Parser de prueba (python) retornó None en ejecutable empaquetado")
                except Exception as e:
                    logger.warning(f"Error al cargar parser de prueba en ejecutable empaquetado: {e}")
            
            return True
        except ImportError as e:
            logger.error(
                f"tree_sitter_languages no está instalado o no se puede importar: {e}. "
                "Instala con: pip install tree-sitter-languages"
            )
            if hasattr(sys, "_MEIPASS"):
                logger.error(
                    "Ejecutable empaquetado detectado. "
                    "tree-sitter-languages puede no estar incluido en el empaquetado. "
                    "Verifica el spec file."
                )
            return False
    
    def get_parser(self, language: str) -> Optional[Any]:
        """
        Obtiene un parser para el lenguaje especificado.
        
        Args:
            language: Nombre del lenguaje (python, javascript, typescript, etc.)
            
        Returns:
            Parser de Tree-sitter o None si no está disponible
        """
        if not self._initialized:
            if not self.initialize():
                return None
                
        if language in self._parsers:
            return self._parsers[language]
            
        try:
            # Intentar múltiples métodos para obtener el parser
            
            # Método 1: get_parser() directo (puede funcionar en algunas versiones)
            try:
                parser = self._tree_sitter_languages.get_parser(language)
                if parser and hasattr(parser, 'parse'):
                    self._parsers[language] = parser
                    logger.debug(f"Parser para {language} cargado correctamente (método directo)")
                    return parser
            except Exception as e1:
                logger.debug(f"get_parser() directo falló: {e1}")
            
            # Método 2: Obtener lenguaje y crear parser manualmente
            try:
                lang = self.get_language(language)
                if lang:
                    import tree_sitter
                    parser = tree_sitter.Parser()
                    parser.set_language(lang)
                    if parser:
                        self._parsers[language] = parser
                        logger.debug(f"Parser para {language} cargado correctamente (método manual)")
                        return parser
            except Exception as e2:
                logger.debug(f"Crear parser manualmente falló: {e2}")
            
            # Si ambos métodos fallan
            logger.warning(f"No se pudo cargar el parser para {language} con ningún método")
            return None
            
        except Exception as e:
            logger.warning(f"No se pudo cargar el parser para {language}: {e}")
            import traceback
            logger.debug(f"Traceback completo: {traceback.format_exc()}")
            return None
    
    def get_language(self, language: str) -> Optional[Any]:
        """
        Obtiene la gramática del lenguaje especificado.
        
        Args:
            language: Nombre del lenguaje
            
        Returns:
            Gramática de Tree-sitter o None si no está disponible
        """
        if not self._initialized:
            if not self.initialize():
                return None
                
        if language in self._languages:
            return self._languages[language]
            
        try:
            # Intentar múltiples formas de obtener el lenguaje
            lang = None
            
            # Método 1: Importar directamente el módulo del lenguaje (más confiable)
            # tree-sitter-languages tiene módulos como tree_sitter_python, tree_sitter_javascript, etc.
            try:
                import importlib
                # Mapeo de nombres de lenguaje a nombres de módulo
                module_map = {
                    'python': 'tree_sitter_python',
                    'javascript': 'tree_sitter_javascript',
                    'typescript': 'tree_sitter_typescript',
                    'java': 'tree_sitter_java',
                    'c_sharp': 'tree_sitter_c_sharp',
                    'php': 'tree_sitter_php',
                    'go': 'tree_sitter_go',
                    'rust': 'tree_sitter_rust',
                    'cpp': 'tree_sitter_cpp',
                    'c': 'tree_sitter_c',
                }
                
                module_name = module_map.get(language)
                if module_name:
                    lang_module = importlib.import_module(module_name)
                    if hasattr(lang_module, 'language'):
                        lang_attr = getattr(lang_module, 'language')
                        # language puede ser una función o un atributo
                        if callable(lang_attr):
                            lang = lang_attr()
                        else:
                            lang = lang_attr
            except Exception as e1:
                logger.debug(f"Importar módulo directamente falló: {e1}")
            
            # Método 2: get_parser() directo y extraer language del parser
            if not lang:
                try:
                    parser = self._tree_sitter_languages.get_parser(language)
                    if parser and hasattr(parser, 'language'):
                        lang = parser.language
                except Exception as e2:
                    logger.debug(f"Obtener language del parser falló: {e2}")
            
            # Método 3: get_language() directo (puede fallar en algunas versiones)
            if not lang:
                try:
                    lang = self._tree_sitter_languages.get_language(language)
                except Exception as e3:
                    logger.debug(f"get_language() directo falló: {e3}")
            
            if lang:
                self._languages[language] = lang
                logger.debug(f"Gramática para {language} cargada correctamente")
                return lang
            else:
                logger.warning(f"No se pudo obtener el lenguaje para {language} con ningún método")
                return None
        except Exception as e:
            logger.warning(f"No se pudo cargar la gramática para {language}: {e}")
            import traceback
            logger.debug(f"Traceback completo: {traceback.format_exc()}")
            return None
    
    def is_language_supported(self, language: str) -> bool:
        """
        Verifica si un lenguaje está soportado.
        
        Args:
            language: Nombre del lenguaje
            
        Returns:
            bool: True si el lenguaje está soportado
        """
        try:
            lang = self.get_language(language)
            return lang is not None
        except Exception:
            return False
    
    def get_supported_languages(self) -> list:
        """
        Obtiene la lista de lenguajes soportados.
        
        Returns:
            Lista de nombres de lenguajes soportados
        """
        if not self._initialized:
            if not self.initialize():
                return []
                
        # Lista de lenguajes que queremos soportar inicialmente
        target_languages = [
            'python', 'javascript', 'typescript', 'java', 
            'c_sharp', 'php', 'go', 'rust', 'cpp', 'c'
        ]
        
        supported = []
        for lang in target_languages:
            if self.is_language_supported(lang):
                supported.append(lang)
                
        return supported
    
    def parse_code(self, code: str, language: str) -> Optional[Any]:
        """
        Parsea código usando Tree-sitter.
        
        Args:
            code: Código fuente a parsear
            language: Lenguaje del código
            
        Returns:
            Árbol de sintaxis abstracta o None si hay error
        """
        parser = self.get_parser(language)
        if not parser:
            return None
            
        try:
            tree = parser.parse(bytes(code, 'utf8'))
            return tree
        except Exception as e:
            logger.error(f"Error parseando código {language}: {e}")
            return None
    
    def parse_file(self, file_path: str, language: str) -> Optional[Any]:
        """
        Parsea un archivo usando Tree-sitter.
        
        Args:
            file_path: Ruta del archivo a parsear
            language: Lenguaje del archivo
            
        Returns:
            Árbol de sintaxis abstracta o None si hay error
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()
            return self.parse_code(code, language)
        except Exception as e:
            logger.error(f"Error leyendo archivo {file_path}: {e}")
            return None

# Instancia global del loader
_loader_instance = None

def get_tree_sitter_loader() -> TreeSitterLoader:
    """
    Obtiene la instancia global del TreeSitterLoader.
    
    Returns:
        Instancia del TreeSitterLoader
    """
    global _loader_instance
    if _loader_instance is None:
        _loader_instance = TreeSitterLoader()
    return _loader_instance
