"""
Incremental Update Module

Maneja las actualizaciones incrementales del grafo de código,
procesando solo los archivos que han cambiado desde la última actualización.
"""

import logging
from typing import Dict, List, Set, Optional, Any, Tuple
from pathlib import Path

from .graph_builder import GraphBuilder, GraphNode, GraphEdge
from .file_hashing import FileHashManager
from .languages import get_language_registry

logger = logging.getLogger(__name__)

class IncrementalUpdater:
    """
    Actualiza el grafo de código de forma incremental.
    """
    
    def __init__(self, project_root: str = "."):
        self.project_root = Path(project_root).resolve()
        self.graph_builder = GraphBuilder(str(project_root))
        self.hash_manager = FileHashManager(str(project_root))
        self.language_registry = get_language_registry()
    
    def _remove_file_nodes(self, graph: Dict[str, Any], file_paths: Set[str]) -> Dict[str, Any]:
        """
        Elimina todos los nodos y edges relacionados con archivos específicos.
        
        Args:
            graph: Grafo actual
            file_paths: Conjunto de rutas de archivos a eliminar
            
        Returns:
            Grafo actualizado sin los nodos de los archivos eliminados
        """
        if not file_paths:
            return graph
        
        # Normalizar rutas de archivos
        normalized_paths = {str(Path(fp).as_posix()) for fp in file_paths}
        
        # Encontrar nodos a eliminar
        nodes_to_remove = set()
        remaining_nodes = []
        
        for node in graph.get("nodes", []):
            node_file_path = str(Path(node.get("file_path", "")).as_posix())
            if node_file_path in normalized_paths:
                nodes_to_remove.add(node["id"])
            else:
                remaining_nodes.append(node)
        
        # Encontrar edges a eliminar
        remaining_edges = []
        for edge in graph.get("edges", []):
            if edge.get("source") not in nodes_to_remove and edge.get("target") not in nodes_to_remove:
                remaining_edges.append(edge)
        
        # Actualizar metadata
        updated_graph = graph.copy()
        updated_graph["nodes"] = remaining_nodes
        updated_graph["edges"] = remaining_edges
        
        if "metadata" in updated_graph:
            updated_graph["metadata"]["total_nodes"] = len(remaining_nodes)
            updated_graph["metadata"]["total_edges"] = len(remaining_edges)
        
        logger.info(f"Eliminados {len(nodes_to_remove)} nodos de {len(file_paths)} archivos")
        
        return updated_graph
    
    def _add_file_nodes(self, graph: Dict[str, Any], file_paths: Set[str]) -> Dict[str, Any]:
        """
        Agrega nodos y edges para archivos nuevos o modificados.
        
        Args:
            graph: Grafo actual
            file_paths: Conjunto de rutas de archivos a agregar
            
        Returns:
            Grafo actualizado con los nuevos nodos
        """
        if not file_paths:
            return graph
        
        # Obtener el contador más alto de nodos y edges existentes
        max_node_counter = 0
        max_edge_counter = 0
        
        for node in graph.get("nodes", []):
            node_id = node.get("id", "")
            if node_id.startswith("node_"):
                try:
                    counter = int(node_id.split("_")[1])
                    max_node_counter = max(max_node_counter, counter)
                except (IndexError, ValueError):
                    pass
        
        for edge in graph.get("edges", []):
            edge_id = edge.get("id", "")
            if edge_id.startswith("edge_"):
                try:
                    counter = int(edge_id.split("_")[1])
                    max_edge_counter = max(max_edge_counter, counter)
                except (IndexError, ValueError):
                    pass
        
        # Configurar el graph_builder con los contadores correctos
        self.graph_builder._node_counter = max_node_counter
        self.graph_builder._edge_counter = max_edge_counter
        
        new_nodes = []
        new_edges = []
        
        # Procesar cada archivo
        for file_path in file_paths:
            try:
                nodes, edges = self.graph_builder._parse_single_file(file_path)
                new_nodes.extend(nodes)
                new_edges.extend(edges)
            except Exception as e:
                logger.error(f"Error procesando archivo {file_path}: {e}")
                continue
        
        # Combinar con el grafo existente
        updated_graph = graph.copy()
        updated_graph["nodes"] = graph.get("nodes", []) + [node.__dict__ if hasattr(node, '__dict__') else node for node in new_nodes]
        updated_graph["edges"] = graph.get("edges", []) + [edge.__dict__ if hasattr(edge, '__dict__') else edge for edge in new_edges]
        
        # Actualizar metadata
        if "metadata" in updated_graph:
            updated_graph["metadata"]["total_nodes"] = len(updated_graph["nodes"])
            updated_graph["metadata"]["total_edges"] = len(updated_graph["edges"])
        
        logger.info(f"Agregados {len(new_nodes)} nodos de {len(file_paths)} archivos")
        
        return updated_graph
    
    def _convert_nodes_to_dict(self, nodes: List[Any]) -> List[Dict[str, Any]]:
        """
        Convierte nodos a diccionarios si son objetos dataclass.
        
        Args:
            nodes: Lista de nodos
            
        Returns:
            Lista de nodos como diccionarios
        """
        result = []
        for node in nodes:
            if hasattr(node, '__dict__'):
                # Es un objeto dataclass
                result.append(node.__dict__)
            elif isinstance(node, dict):
                # Ya es un diccionario
                result.append(node)
            else:
                # Intentar convertir usando asdict si es posible
                try:
                    from dataclasses import asdict
                    result.append(asdict(node))
                except Exception:
                    logger.warning(f"No se pudo convertir nodo: {type(node)}")
                    continue
        return result
    
    def _convert_edges_to_dict(self, edges: List[Any]) -> List[Dict[str, Any]]:
        """
        Convierte edges a diccionarios si son objetos dataclass.
        
        Args:
            edges: Lista de edges
            
        Returns:
            Lista de edges como diccionarios
        """
        result = []
        for edge in edges:
            if hasattr(edge, '__dict__'):
                # Es un objeto dataclass
                result.append(edge.__dict__)
            elif isinstance(edge, dict):
                # Ya es un diccionario
                result.append(edge)
            else:
                # Intentar convertir usando asdict si es posible
                try:
                    from dataclasses import asdict
                    result.append(asdict(edge))
                except Exception:
                    logger.warning(f"No se pudo convertir edge: {type(edge)}")
                    continue
        return result
    
    def update_graph(self) -> Optional[Dict[str, Any]]:
        """
        Actualiza el grafo de forma incremental.
        
        Returns:
            Grafo actualizado o None si hay error
        """
        logger.info("Iniciando actualización incremental del grafo")
        
        # Cargar grafo existente
        current_graph = self.graph_builder.load_graph()
        if not current_graph:
            logger.warning("No se encontró grafo existente, construyendo desde cero")
            return self.graph_builder.build_full_graph()
        
        # Obtener extensiones soportadas
        supported_extensions = self.language_registry.get_supported_extensions()
        
        # Detectar cambios
        new_files, modified_files, deleted_files = self.hash_manager.get_changed_files(supported_extensions)
        
        if not new_files and not modified_files and not deleted_files:
            logger.info("No se detectaron cambios en los archivos")
            return current_graph
        
        logger.info(
            f"Cambios detectados: {len(new_files)} nuevos, "
            f"{len(modified_files)} modificados, {len(deleted_files)} eliminados"
        )
        
        # Aplicar cambios al grafo
        updated_graph = current_graph
        
        # 1. Eliminar archivos eliminados
        if deleted_files:
            updated_graph = self._remove_file_nodes(updated_graph, deleted_files)
        
        # 2. Eliminar archivos modificados (para reemplazarlos)
        if modified_files:
            updated_graph = self._remove_file_nodes(updated_graph, modified_files)
        
        # 3. Agregar archivos nuevos y modificados
        files_to_add = new_files | modified_files
        if files_to_add:
            updated_graph = self._add_file_nodes(updated_graph, files_to_add)
        
        # Asegurar que los nodos y edges sean diccionarios
        if "nodes" in updated_graph:
            updated_graph["nodes"] = self._convert_nodes_to_dict(updated_graph["nodes"])
        if "edges" in updated_graph:
            updated_graph["edges"] = self._convert_edges_to_dict(updated_graph["edges"])
        
        # Actualizar hashes
        current_hashes = self.hash_manager.calculate_directory_hashes(
            str(self.project_root), supported_extensions
        )
        self.hash_manager.save_hashes(current_hashes)
        
        # Actualizar metadata del grafo
        if "metadata" not in updated_graph:
            updated_graph["metadata"] = {}
        
        updated_graph["metadata"].update({
            "total_files": len(current_hashes),
            "total_nodes": len(updated_graph.get("nodes", [])),
            "total_edges": len(updated_graph.get("edges", [])),
            "last_update": "incremental"
        })
        
        logger.info(
            f"Grafo actualizado: {len(updated_graph.get('nodes', []))} nodos, "
            f"{len(updated_graph.get('edges', []))} edges"
        )
        
        return updated_graph
    
    def force_rebuild_file(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Fuerza la reconstrucción de un archivo específico en el grafo.
        
        Args:
            file_path: Ruta del archivo a reconstruir
            
        Returns:
            Grafo actualizado o None si hay error
        """
        logger.info(f"Forzando reconstrucción de {file_path}")
        
        # Cargar grafo existente
        current_graph = self.graph_builder.load_graph()
        if not current_graph:
            logger.warning("No se encontró grafo existente")
            return None
        
        # Normalizar ruta del archivo
        file_path = str(Path(file_path).as_posix())
        
        # Eliminar nodos del archivo
        updated_graph = self._remove_file_nodes(current_graph, {file_path})
        
        # Agregar el archivo nuevamente
        updated_graph = self._add_file_nodes(updated_graph, {file_path})
        
        # Asegurar que los nodos y edges sean diccionarios
        if "nodes" in updated_graph:
            updated_graph["nodes"] = self._convert_nodes_to_dict(updated_graph["nodes"])
        if "edges" in updated_graph:
            updated_graph["edges"] = self._convert_edges_to_dict(updated_graph["edges"])
        
        logger.info(f"Archivo {file_path} reconstruido en el grafo")
        
        return updated_graph
    
    def get_incremental_stats(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas sobre los cambios incrementales disponibles.
        
        Returns:
            Diccionario con estadísticas de cambios
        """
        supported_extensions = self.language_registry.get_supported_extensions()
        new_files, modified_files, deleted_files = self.hash_manager.get_changed_files(supported_extensions)
        
        return {
            "new_files": len(new_files),
            "modified_files": len(modified_files),
            "deleted_files": len(deleted_files),
            "total_changes": len(new_files) + len(modified_files) + len(deleted_files),
            "files": {
                "new": list(new_files),
                "modified": list(modified_files),
                "deleted": list(deleted_files)
            }
        }
