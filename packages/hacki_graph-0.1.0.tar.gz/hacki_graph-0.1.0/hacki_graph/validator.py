"""
Graph Validation

Valida la consistencia entre archivos de análisis y el filesystem.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple
from .file_hashing import FileHashManager

logger = logging.getLogger(__name__)


class GraphValidator:
    """
    Valida la consistencia de los archivos de análisis.
    
    Funcionalidades:
    - Validar que archivos en análisis existan en filesystem
    - Validar que hashes coincidan con contenido real
    - Validar consistencia entre graph.json y análisis estático
    """
    
    def __init__(self, project_root: str):
        """
        Inicializa el validador.
        
        Args:
            project_root: Ruta raíz del proyecto
        """
        self.project_root = Path(project_root)
        self.hash_manager = FileHashManager(str(project_root))
        
        # Rutas de archivos
        self.graph_file = self.project_root / ".hacki" / "graph.json"
        self.graphs_dir = self.project_root / ".hacki" / "graphs"
        self.ir_file = self.graphs_dir / "ir.json"
        self.cfg_file = self.graphs_dir / "cfg.json"
        self.dfg_file = self.graphs_dir / "dfg.json"
    
    def validate_consistency(self) -> Dict[str, Any]:
        """
        Valida consistencia entre archivos de análisis.
        
        Returns:
            Diccionario con resultados de validación:
            {
                "is_valid": bool,
                "graph_valid": bool,
                "ir_valid": bool,
                "cfg_valid": bool,
                "dfg_valid": bool,
                "files_valid": bool,
                "hashes_valid": bool,
                "errors": List[str],
                "warnings": List[str]
            }
        """
        results = {
            "is_valid": True,
            "graph_valid": True,
            "ir_valid": True,
            "cfg_valid": True,
            "dfg_valid": True,
            "files_valid": True,
            "hashes_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validar existencia de archivos
        if not self.graph_file.exists():
            results["graph_valid"] = False
            results["errors"].append("graph.json no existe")
            results["is_valid"] = False
        
        if not self.ir_file.exists():
            results["ir_valid"] = False
            results["warnings"].append("ir.json no existe")
        
        if not self.cfg_file.exists():
            results["cfg_valid"] = False
            results["warnings"].append("cfg.json no existe")
        
        if not self.dfg_file.exists():
            results["dfg_valid"] = False
            results["warnings"].append("dfg.json no existe")
        
        # Validar formato de archivos existentes
        if self.graph_file.exists():
            if not self._validate_graph_format():
                results["graph_valid"] = False
                results["errors"].append("graph.json tiene formato inválido")
                results["is_valid"] = False
        
        if self.ir_file.exists():
            if not self._validate_ir_format():
                results["ir_valid"] = False
                results["errors"].append("ir.json tiene formato inválido")
                results["is_valid"] = False
        
        # Validar archivos en filesystem
        files_validation = self.validate_files_exist()
        if not files_validation["is_valid"]:
            results["files_valid"] = False
            results["errors"].extend(files_validation["errors"])
            results["is_valid"] = False
        
        # Validar hashes
        hashes_validation = self.validate_hashes()
        if not hashes_validation["is_valid"]:
            results["hashes_valid"] = False
            results["warnings"].extend(hashes_validation["warnings"])
            # No marcamos como inválido por hashes, solo advertencia
        
        # Validar consistencia entre archivos
        consistency_validation = self._validate_cross_file_consistency()
        if not consistency_validation["is_valid"]:
            results["errors"].extend(consistency_validation["errors"])
            results["is_valid"] = False
        
        return results
    
    def validate_files_exist(self) -> Dict[str, Any]:
        """
        Valida que los archivos referenciados en el análisis existan en el filesystem.
        
        Returns:
            Diccionario con resultados:
            {
                "is_valid": bool,
                "missing_files": List[str],
                "errors": List[str]
            }
        """
        missing_files = []
        errors = []
        
        try:
            # Obtener archivos de graph.json
            graph_files = self._get_files_from_graph()
            
            # Obtener archivos de ir.json
            ir_files = self._get_files_from_ir()
            
            # Combinar y verificar
            all_files = set(graph_files) | set(ir_files)
            
            for file_path in all_files:
                full_path = self.project_root / file_path
                if not full_path.exists():
                    missing_files.append(file_path)
            
            is_valid = len(missing_files) == 0
            
            if not is_valid:
                errors.append(f"{len(missing_files)} archivos referenciados no existen en filesystem")
            
            return {
                "is_valid": is_valid,
                "missing_files": missing_files,
                "errors": errors
            }
            
        except Exception as e:
            logger.error(f"Error validando existencia de archivos: {e}")
            return {
                "is_valid": False,
                "missing_files": [],
                "errors": [f"Error validando archivos: {str(e)}"]
            }
    
    def validate_hashes(self) -> Dict[str, Any]:
        """
        Valida que los hashes de archivos coincidan con el contenido real.
        
        Returns:
            Diccionario con resultados:
            {
                "is_valid": bool,
                "mismatched_files": List[str],
                "warnings": List[str]
            }
        """
        mismatched_files = []
        warnings = []
        
        try:
            # Cargar hashes guardados
            saved_hashes = self.hash_manager.load_hashes()
            
            if not saved_hashes:
                warnings.append("No hay hashes guardados para validar")
                return {
                    "is_valid": True,
                    "mismatched_files": [],
                    "warnings": warnings
                }
            
            # Calcular hashes actuales y comparar
            for file_path, saved_hash in saved_hashes.items():
                full_path = self.project_root / file_path
                
                if not full_path.exists():
                    # Archivo eliminado, no validar hash
                    continue
                
                try:
                    current_hash = self.hash_manager.calculate_sha1(full_path)
                    if current_hash != saved_hash:
                        mismatched_files.append(file_path)
                except Exception as e:
                    warnings.append(f"Error calculando hash para {file_path}: {e}")
            
            is_valid = len(mismatched_files) == 0
            
            if not is_valid:
                warnings.append(f"{len(mismatched_files)} archivos tienen hashes desactualizados")
            
            return {
                "is_valid": is_valid,
                "mismatched_files": mismatched_files,
                "warnings": warnings
            }
            
        except Exception as e:
            logger.error(f"Error validando hashes: {e}")
            return {
                "is_valid": False,
                "mismatched_files": [],
                "warnings": [f"Error validando hashes: {str(e)}"]
            }
    
    def _validate_graph_format(self) -> bool:
        """Valida el formato de graph.json"""
        try:
            with open(self.graph_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # Validar estructura básica
            if not isinstance(data, dict):
                return False
            
            if "metadata" not in data or "nodes" not in data or "edges" not in data:
                return False
            
            return True
        except (json.JSONDecodeError, IOError):
            return False
    
    def _validate_ir_format(self) -> bool:
        """Valida el formato de ir.json"""
        try:
            with open(self.ir_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # Validar estructura básica
            if not isinstance(data, dict):
                return False
            
            if "metadata" not in data or "files" not in data:
                return False
            
            return True
        except (json.JSONDecodeError, IOError):
            return False
    
    def _validate_cross_file_consistency(self) -> Dict[str, Any]:
        """
        Valida consistencia entre graph.json y análisis estático.
        
        Returns:
            Diccionario con resultados de validación
        """
        errors = []
        
        try:
            # Obtener archivos de graph.json
            graph_files = set(self._get_files_from_graph())
            
            # Obtener archivos de ir.json
            ir_files = set(self._get_files_from_ir())
            
            # Verificar que archivos en IR estén en graph.json
            files_in_ir_not_in_graph = ir_files - graph_files
            if files_in_ir_not_in_graph:
                errors.append(
                    f"{len(files_in_ir_not_in_graph)} archivos en IR no están en graph.json"
                )
            
            # Advertencia si hay archivos en graph.json que no están en IR
            # (esto puede ser normal si el análisis estático no se ha generado)
            files_in_graph_not_in_ir = graph_files - ir_files
            if files_in_graph_not_in_ir:
                logger.debug(
                    f"{len(files_in_graph_not_in_ir)} archivos en graph.json no están en IR "
                    "(puede ser normal si el análisis estático no está completo)"
                )
            
            return {
                "is_valid": len(errors) == 0,
                "errors": errors
            }
            
        except Exception as e:
            logger.error(f"Error validando consistencia entre archivos: {e}")
            return {
                "is_valid": False,
                "errors": [f"Error validando consistencia: {str(e)}"]
            }
    
    def _get_files_from_graph(self) -> List[str]:
        """Obtiene lista de archivos desde graph.json"""
        if not self.graph_file.exists():
            return []
        
        try:
            with open(self.graph_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # Extraer archivos únicos de los nodos
            files = set()
            nodes = data.get("nodes", [])
            for node in nodes:
                file_path = node.get("file_path")
                if file_path:
                    files.add(file_path)
            
            return list(files)
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error leyendo graph.json: {e}")
            return []
    
    def _get_files_from_ir(self) -> List[str]:
        """Obtiene lista de archivos desde ir.json"""
        if not self.ir_file.exists():
            return []
        
        try:
            with open(self.ir_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            files = data.get("files", {})
            return list(files.keys())
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error leyendo ir.json: {e}")
            return []

