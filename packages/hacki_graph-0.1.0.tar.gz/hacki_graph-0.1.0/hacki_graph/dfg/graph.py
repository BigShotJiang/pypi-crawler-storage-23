"""
Data Flow Graph (DFG) Structure

Define las estructuras de datos para representar grafos de flujo de datos.
Incluye nodos, aristas y el grafo completo con funcionalidades de análisis.
"""

import logging
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
import json

logger = logging.getLogger(__name__)

@dataclass
class DFGNode:
    """
    Nodo en el Data Flow Graph.
    
    Representa un statement o expresión que lee o escribe variables.
    """
    id: str
    ir_node_id: str  # ID del nodo IR correspondiente
    node_type: str   # Tipo del nodo IR (Assign, FunctionCall, etc.)
    reads: List[str] = field(default_factory=list)   # Variables leídas
    writes: List[str] = field(default_factory=list)  # Variables escritas
    calls: List[str] = field(default_factory=list)   # Funciones llamadas
    line: int = 0
    column: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el nodo a diccionario."""
        return {
            "id": self.id,
            "ir_node_id": self.ir_node_id,
            "node_type": self.node_type,
            "reads": self.reads,
            "writes": self.writes,
            "calls": self.calls,
            "line": self.line,
            "column": self.column,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DFGNode':
        """Crea un nodo desde un diccionario."""
        return cls(
            id=data["id"],
            ir_node_id=data["ir_node_id"],
            node_type=data["node_type"],
            reads=data.get("reads", []),
            writes=data.get("writes", []),
            calls=data.get("calls", []),
            line=data.get("line", 0),
            column=data.get("column", 0),
            metadata=data.get("metadata", {})
        )
    
    def is_definition(self) -> bool:
        """Verifica si el nodo define variables."""
        return len(self.writes) > 0
    
    def is_use(self) -> bool:
        """Verifica si el nodo usa variables."""
        return len(self.reads) > 0
    
    def is_call(self) -> bool:
        """Verifica si el nodo es una llamada a función."""
        return len(self.calls) > 0
    
    def get_all_variables(self) -> Set[str]:
        """Obtiene todas las variables involucradas (leídas o escritas)."""
        return set(self.reads + self.writes)

@dataclass
class DFGEdge:
    """
    Arista en el Data Flow Graph.
    
    Representa una dependencia de datos o control entre dos nodos.
    """
    source: str  # ID del nodo fuente
    target: str  # ID del nodo objetivo
    edge_type: str  # "data_flow", "control_flow", "call_flow"
    variable: Optional[str] = None  # Variable involucrada (para data_flow)
    condition: Optional[str] = None  # Condición (para control_flow)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte la arista a diccionario."""
        return {
            "source": self.source,
            "target": self.target,
            "edge_type": self.edge_type,
            "variable": self.variable,
            "condition": self.condition,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DFGEdge':
        """Crea una arista desde un diccionario."""
        return cls(
            source=data["source"],
            target=data["target"],
            edge_type=data["edge_type"],
            variable=data.get("variable"),
            condition=data.get("condition"),
            metadata=data.get("metadata", {})
        )
    
    def is_data_dependency(self) -> bool:
        """Verifica si es una dependencia de datos."""
        return self.edge_type == "data_flow"
    
    def is_control_dependency(self) -> bool:
        """Verifica si es una dependencia de control."""
        return self.edge_type == "control_flow"
    
    def is_call_dependency(self) -> bool:
        """Verifica si es una dependencia de llamada."""
        return self.edge_type == "call_flow"

class DataFlowGraph:
    """
    Grafo de Flujo de Datos completo.
    
    Contiene nodos y aristas que representan las dependencias de datos
    y control en una función o módulo.
    """
    
    def __init__(self):
        self.nodes: Dict[str, DFGNode] = {}
        self.edges: List[DFGEdge] = []
        self.metadata: Dict[str, Any] = {}
    
    def add_node(self, node: DFGNode):
        """Agrega un nodo al grafo."""
        self.nodes[node.id] = node
    
    def add_edge(self, edge: DFGEdge):
        """Agrega una arista al grafo."""
        # Verificar que los nodos existen
        if edge.source in self.nodes and edge.target in self.nodes:
            self.edges.append(edge)
        else:
            logger.warning(f"Intento de agregar arista con nodos inexistentes: {edge.source} -> {edge.target}")
    
    def get_node(self, node_id: str) -> Optional[DFGNode]:
        """Obtiene un nodo por su ID."""
        return self.nodes.get(node_id)
    
    def get_predecessors(self, node_id: str) -> List[DFGNode]:
        """Obtiene los nodos predecesores de un nodo."""
        predecessors = []
        for edge in self.edges:
            if edge.target == node_id and edge.source in self.nodes:
                predecessors.append(self.nodes[edge.source])
        return predecessors
    
    def get_successors(self, node_id: str) -> List[DFGNode]:
        """Obtiene los nodos sucesores de un nodo."""
        successors = []
        for edge in self.edges:
            if edge.source == node_id and edge.target in self.nodes:
                successors.append(self.nodes[edge.target])
        return successors
    
    def get_data_dependencies(self, node_id: str) -> List[DFGEdge]:
        """Obtiene las dependencias de datos de un nodo."""
        return [edge for edge in self.edges 
                if edge.target == node_id and edge.is_data_dependency()]
    
    def get_control_dependencies(self, node_id: str) -> List[DFGEdge]:
        """Obtiene las dependencias de control de un nodo."""
        return [edge for edge in self.edges 
                if edge.target == node_id and edge.is_control_dependency()]
    
    def get_variable_definitions(self, variable: str) -> List[DFGNode]:
        """Obtiene todos los nodos que definen una variable."""
        definitions = []
        for node in self.nodes.values():
            if variable in node.writes:
                definitions.append(node)
        return definitions
    
    def get_variable_uses(self, variable: str) -> List[DFGNode]:
        """Obtiene todos los nodos que usan una variable."""
        uses = []
        for node in self.nodes.values():
            if variable in node.reads:
                uses.append(node)
        return uses
    
    def get_def_use_chains(self, variable: str) -> List[Tuple[DFGNode, List[DFGNode]]]:
        """
        Obtiene cadenas def-use para una variable.
        
        Returns:
            Lista de tuplas (definición, [usos])
        """
        chains = []
        definitions = self.get_variable_definitions(variable)
        
        for definition in definitions:
            # Encontrar usos alcanzados por esta definición
            reachable_uses = []
            
            for edge in self.edges:
                if (edge.source == definition.id and 
                    edge.is_data_dependency() and 
                    edge.variable == variable):
                    
                    target_node = self.nodes.get(edge.target)
                    if target_node and variable in target_node.reads:
                        reachable_uses.append(target_node)
            
            chains.append((definition, reachable_uses))
        
        return chains
    
    def find_unused_definitions(self) -> List[DFGNode]:
        """Encuentra definiciones de variables que nunca se usan."""
        unused = []
        
        for node in self.nodes.values():
            if node.is_definition():
                for variable in node.writes:
                    # Verificar si esta definición tiene usos
                    has_uses = any(
                        edge.source == node.id and 
                        edge.is_data_dependency() and 
                        edge.variable == variable
                        for edge in self.edges
                    )
                    
                    if not has_uses:
                        unused.append(node)
                        break  # Un nodo puede tener múltiples definiciones no usadas
        
        return unused
    
    def find_uninitialized_uses(self) -> List[Tuple[DFGNode, str]]:
        """Encuentra usos de variables que pueden no estar inicializadas."""
        uninitialized = []
        
        for node in self.nodes.values():
            if node.is_use():
                for variable in node.reads:
                    # Verificar si hay una definición que alcance este uso
                    has_definition = any(
                        edge.target == node.id and 
                        edge.is_data_dependency() and 
                        edge.variable == variable
                        for edge in self.edges
                    )
                    
                    if not has_definition:
                        uninitialized.append((node, variable))
        
        return uninitialized
    
    def get_strongly_connected_components(self) -> List[List[str]]:
        """
        Encuentra componentes fuertemente conectados en el DFG.
        Útil para detectar dependencias circulares.
        """
        # Implementación simplificada usando DFS
        visited = set()
        finished = set()
        components = []
        
        def dfs1(node_id: str, stack: List[str]):
            if node_id in visited:
                return
            
            visited.add(node_id)
            
            # Visitar sucesores
            for edge in self.edges:
                if edge.source == node_id:
                    dfs1(edge.target, stack)
            
            stack.append(node_id)
        
        def dfs2(node_id: str, component: List[str]):
            if node_id in finished:
                return
            
            finished.add(node_id)
            component.append(node_id)
            
            # Visitar predecesores en el grafo transpuesto
            for edge in self.edges:
                if edge.target == node_id:
                    dfs2(edge.source, component)
        
        # Primer DFS para obtener orden de finalización
        stack = []
        for node_id in self.nodes.keys():
            if node_id not in visited:
                dfs1(node_id, stack)
        
        # Segundo DFS en orden inverso
        while stack:
            node_id = stack.pop()
            if node_id not in finished:
                component = []
                dfs2(node_id, component)
                if len(component) > 1:  # Solo componentes con más de un nodo
                    components.append(component)
        
        return components
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el grafo a diccionario."""
        return {
            "nodes": {node_id: node.to_dict() for node_id, node in self.nodes.items()},
            "edges": [edge.to_dict() for edge in self.edges],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DataFlowGraph':
        """Crea un grafo desde un diccionario."""
        dfg = cls()
        
        # Cargar nodos
        for node_id, node_data in data.get("nodes", {}).items():
            dfg.nodes[node_id] = DFGNode.from_dict(node_data)
        
        # Cargar aristas
        for edge_data in data.get("edges", []):
            dfg.edges.append(DFGEdge.from_dict(edge_data))
        
        dfg.metadata = data.get("metadata", {})
        return dfg
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del grafo."""
        data_flow_edges = sum(1 for edge in self.edges if edge.is_data_dependency())
        control_flow_edges = sum(1 for edge in self.edges if edge.is_control_dependency())
        call_flow_edges = sum(1 for edge in self.edges if edge.is_call_dependency())
        
        definition_nodes = sum(1 for node in self.nodes.values() if node.is_definition())
        use_nodes = sum(1 for node in self.nodes.values() if node.is_use())
        call_nodes = sum(1 for node in self.nodes.values() if node.is_call())
        
        # Variables involucradas
        all_variables = set()
        for node in self.nodes.values():
            all_variables.update(node.get_all_variables())
        
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "data_flow_edges": data_flow_edges,
            "control_flow_edges": control_flow_edges,
            "call_flow_edges": call_flow_edges,
            "definition_nodes": definition_nodes,
            "use_nodes": use_nodes,
            "call_nodes": call_nodes,
            "total_variables": len(all_variables),
            "unused_definitions": len(self.find_unused_definitions()),
            "uninitialized_uses": len(self.find_uninitialized_uses()),
            "strongly_connected_components": len(self.get_strongly_connected_components())
        }

class ProjectDFG:
    """
    Gestiona DFGs para un proyecto completo.
    
    Contiene DFGs para múltiples archivos y funciones,
    y proporciona análisis a nivel de proyecto.
    """
    
    def __init__(self):
        self.file_dfgs: Dict[str, Dict[str, DataFlowGraph]] = {}  # file_path -> {function_name -> DFG}
        self.metadata: Dict[str, Any] = {}
    
    def add_file_dfgs(self, file_path: str, function_dfgs: Dict[str, DataFlowGraph]):
        """Agrega DFGs de un archivo al proyecto."""
        self.file_dfgs[file_path] = function_dfgs
        logger.debug(f"DFGs agregados para archivo {file_path}: {len(function_dfgs)} funciones")
    
    def get_function_dfg(self, file_path: str, function_name: str) -> Optional[DataFlowGraph]:
        """Obtiene el DFG de una función específica."""
        file_dfgs = self.file_dfgs.get(file_path, {})
        return file_dfgs.get(function_name)
    
    def get_all_functions(self) -> List[Dict[str, str]]:
        """Obtiene lista de todas las funciones con DFG."""
        functions = []
        
        for file_path, file_dfgs in self.file_dfgs.items():
            for function_name in file_dfgs.keys():
                functions.append({
                    "file_path": file_path,
                    "function_name": function_name,
                    "id": f"{file_path}:{function_name}"
                })
        
        return functions
    
    def save_to_json(self, output_path: str) -> bool:
        """Guarda todos los DFGs en formato JSON."""
        try:
            json_data = {
                "metadata": {
                    "total_files": len(self.file_dfgs),
                    "total_functions": sum(len(file_dfgs) for file_dfgs in self.file_dfgs.values())
                },
                "files": {}
            }
            
            for file_path, file_dfgs in self.file_dfgs.items():
                json_data["files"][file_path] = {
                    "functions": {
                        function_name: dfg.to_dict() 
                        for function_name, dfg in file_dfgs.items()
                    }
                }
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"DFGs guardados en {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error guardando DFGs: {e}")
            return False
    
    def load_from_json(self, input_path: str) -> bool:
        """Carga DFGs desde un archivo JSON."""
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            
            self.file_dfgs.clear()
            self.metadata = json_data.get("metadata", {})
            
            for file_path, file_data in json_data.get("files", {}).items():
                file_dfgs = {}
                for function_name, dfg_data in file_data.get("functions", {}).items():
                    file_dfgs[function_name] = DataFlowGraph.from_dict(dfg_data)
                
                self.file_dfgs[file_path] = file_dfgs
            
            logger.info(f"DFGs cargados desde {input_path}: {len(self.file_dfgs)} archivos")
            return True
            
        except Exception as e:
            logger.error(f"Error cargando DFGs: {e}")
            return False
    
    def get_project_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del proyecto completo."""
        total_functions = 0
        total_nodes = 0
        total_edges = 0
        total_variables = set()
        
        file_stats = {}
        
        for file_path, file_dfgs in self.file_dfgs.items():
            file_total_nodes = 0
            file_total_edges = 0
            
            for function_name, dfg in file_dfgs.items():
                stats = dfg.get_stats()
                file_total_nodes += stats["total_nodes"]
                file_total_edges += stats["total_edges"]
                
                # Agregar variables del archivo
                for node in dfg.nodes.values():
                    total_variables.update(node.get_all_variables())
            
            file_stats[file_path] = {
                "functions": len(file_dfgs),
                "nodes": file_total_nodes,
                "edges": file_total_edges
            }
            
            total_functions += len(file_dfgs)
            total_nodes += file_total_nodes
            total_edges += file_total_edges
        
        return {
            "total_files": len(self.file_dfgs),
            "total_functions": total_functions,
            "total_nodes": total_nodes,
            "total_edges": total_edges,
            "total_variables": len(total_variables),
            "avg_nodes_per_function": total_nodes / total_functions if total_functions else 0,
            "avg_edges_per_function": total_edges / total_functions if total_functions else 0,
            "files": file_stats
        }
