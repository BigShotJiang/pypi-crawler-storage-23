"""
Data Flow Graph (DFG) Builder

Construye grafos de flujo de datos a partir de CFGs y nodos IR.
Analiza definiciones y usos de variables para crear dependencias de datos.
"""

import logging
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from ..ir.base import IRFunction, IRFile
from ..ir.nodes import *
from ..cfg.basic_block import BasicBlock, CFGBuilder
from .graph import DataFlowGraph, DFGNode, DFGEdge

logger = logging.getLogger(__name__)

@dataclass
class VariableState:
    """
    Estado de una variable en un punto específico del programa.
    """
    name: str
    definition_id: Optional[str] = None  # ID del nodo IR que define la variable
    definition_block: Optional[str] = None  # ID del bloque donde se define
    is_parameter: bool = False
    is_global: bool = False
    last_use_id: Optional[str] = None  # ID del último uso
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class BlockState:
    """
    Estado de variables al inicio y final de un bloque básico.
    """
    block_id: str
    entry_state: Dict[str, VariableState] = field(default_factory=dict)  # Estado al entrar
    exit_state: Dict[str, VariableState] = field(default_factory=dict)   # Estado al salir
    gen_set: Set[str] = field(default_factory=set)  # Variables definidas en el bloque
    kill_set: Set[str] = field(default_factory=set)  # Variables redefinidas en el bloque
    use_set: Set[str] = field(default_factory=set)   # Variables usadas antes de ser definidas

class FunctionDFGBuilder:
    """
    Construye DFG para una función específica basándose en su CFG.
    """
    
    def __init__(self):
        self.dfg = DataFlowGraph()
        self.cfg: Optional[CFGBuilder] = None
        self.ir_nodes: Dict[str, IRNode] = {}  # node_id -> IRNode
        self.block_states: Dict[str, BlockState] = {}
        self.variable_definitions: Dict[str, List[str]] = {}  # variable -> [definition_ids]
        self.variable_uses: Dict[str, List[str]] = {}  # variable -> [use_ids]
    
    def build_dfg_for_function(self, ir_function: IRFunction, cfg: CFGBuilder) -> DataFlowGraph:
        """
        Construye el DFG para una función IR usando su CFG.
        
        Args:
            ir_function: Función IR
            cfg: CFG de la función
            
        Returns:
            DataFlowGraph construido
        """
        logger.debug(f"Construyendo DFG para función {ir_function.name}")
        
        self.dfg = DataFlowGraph()
        self.cfg = cfg
        self.ir_nodes.clear()
        self.block_states.clear()
        self.variable_definitions.clear()
        self.variable_uses.clear()
        
        # Indexar nodos IR por ID
        for node in ir_function.nodes:
            self.ir_nodes[node.id] = node
        
        # Paso 1: Análisis local de bloques
        self._analyze_blocks()
        
        # Paso 2: Análisis de flujo de datos (reaching definitions)
        self._compute_reaching_definitions()
        
        # Paso 3: Construir nodos y aristas del DFG
        self._build_dfg_nodes_and_edges()
        
        # Paso 4: Agregar dependencias de control
        self._add_control_dependencies()
        
        logger.debug(f"DFG construido: {len(self.dfg.nodes)} nodos, {len(self.dfg.edges)} aristas")
        return self.dfg
    
    def _analyze_blocks(self):
        """Analiza cada bloque básico para determinar gen, kill y use sets."""
        if not self.cfg:
            return
        
        for block_id, block in self.cfg.blocks.items():
            block_state = BlockState(block_id)
            
            # Analizar statements en el bloque
            for statement_id in block.statements:
                ir_node = self.ir_nodes.get(statement_id)
                if not ir_node:
                    continue
                
                # Obtener variables leídas y escritas
                reads = ir_node.get_reads()
                writes = ir_node.get_writes()
                
                # Variables usadas (antes de ser definidas en este bloque)
                for var in reads:
                    if var not in block_state.gen_set:
                        block_state.use_set.add(var)
                    
                    # Registrar uso
                    if var not in self.variable_uses:
                        self.variable_uses[var] = []
                    self.variable_uses[var].append(statement_id)
                
                # Variables definidas
                for var in writes:
                    if var in block_state.gen_set:
                        # Redefinición dentro del mismo bloque
                        block_state.kill_set.add(var)
                    
                    block_state.gen_set.add(var)
                    
                    # Registrar definición
                    if var not in self.variable_definitions:
                        self.variable_definitions[var] = []
                    self.variable_definitions[var].append(statement_id)
            
            self.block_states[block_id] = block_state
    
    def _compute_reaching_definitions(self):
        """Computa reaching definitions usando análisis de flujo de datos."""
        if not self.cfg:
            return
        
        # Inicializar estados de entrada y salida
        for block_id in self.cfg.blocks.keys():
            block_state = self.block_states[block_id]
            
            # Estado de entrada: vacío inicialmente
            block_state.entry_state = {}
            
            # Estado de salida: aplicar gen y kill del bloque
            block_state.exit_state = {}
        
        # Algoritmo de punto fijo para reaching definitions
        changed = True
        iterations = 0
        max_iterations = 100  # Prevenir bucles infinitos
        
        while changed and iterations < max_iterations:
            changed = False
            iterations += 1
            
            for block_id, block in self.cfg.blocks.items():
                block_state = self.block_states[block_id]
                old_entry_state = block_state.entry_state.copy()
                
                # Unir estados de salida de predecesores
                new_entry_state = {}
                for pred_id in block.predecessors:
                    if pred_id in self.block_states:
                        pred_exit_state = self.block_states[pred_id].exit_state
                        
                        for var, var_state in pred_exit_state.items():
                            if var not in new_entry_state:
                                new_entry_state[var] = var_state
                            # En caso de múltiples definiciones, mantener la más reciente
                            # (simplificación - en análisis completo se mantienen todas)
                
                block_state.entry_state = new_entry_state
                
                # Actualizar estado de salida
                new_exit_state = new_entry_state.copy()
                
                # Aplicar gen set (nuevas definiciones)
                for statement_id in block.statements:
                    ir_node = self.ir_nodes.get(statement_id)
                    if not ir_node:
                        continue
                    
                    for var in ir_node.get_writes():
                        new_exit_state[var] = VariableState(
                            name=var,
                            definition_id=statement_id,
                            definition_block=block_id
                        )
                
                block_state.exit_state = new_exit_state
                
                # Verificar si hubo cambios
                if old_entry_state != block_state.entry_state:
                    changed = True
        
        if iterations >= max_iterations:
            logger.warning(f"Análisis de reaching definitions no convergió después de {max_iterations} iteraciones")
    
    def _build_dfg_nodes_and_edges(self):
        """Construye nodos y aristas del DFG basándose en el análisis de flujo."""
        # Crear nodos DFG para cada statement IR
        for statement_id, ir_node in self.ir_nodes.items():
            dfg_node = DFGNode(
                id=statement_id,
                ir_node_id=statement_id,
                node_type=type(ir_node).__name__,
                reads=ir_node.get_reads(),
                writes=ir_node.get_writes(),
                calls=ir_node.get_calls()
            )
            self.dfg.add_node(dfg_node)
        
        # Crear aristas de dependencia de datos
        for block_id, block_state in self.block_states.items():
            for statement_id in self.cfg.blocks[block_id].statements:
                ir_node = self.ir_nodes.get(statement_id)
                if not ir_node:
                    continue
                
                # Para cada variable leída, encontrar su definición
                for var in ir_node.get_reads():
                    # Buscar definición en el estado de entrada del bloque
                    if var in block_state.entry_state:
                        def_state = block_state.entry_state[var]
                        if def_state.definition_id and def_state.definition_id != statement_id:
                            # Crear arista de dependencia de datos
                            edge = DFGEdge(
                                source=def_state.definition_id,
                                target=statement_id,
                                edge_type="data_flow",
                                variable=var
                            )
                            self.dfg.add_edge(edge)
                    
                    # También buscar definiciones dentro del mismo bloque
                    for prev_statement_id in self.cfg.blocks[block_id].statements:
                        if prev_statement_id == statement_id:
                            break
                        
                        prev_ir_node = self.ir_nodes.get(prev_statement_id)
                        if prev_ir_node and var in prev_ir_node.get_writes():
                            edge = DFGEdge(
                                source=prev_statement_id,
                                target=statement_id,
                                edge_type="data_flow",
                                variable=var
                            )
                            self.dfg.add_edge(edge)
                            break  # Usar la definición más reciente
    
    def _add_control_dependencies(self):
        """Agrega dependencias de control basándose en el CFG."""
        if not self.cfg:
            return
        
        # Para cada arista condicional en el CFG, agregar dependencias de control
        for edge in self.cfg.edges:
            if edge.edge_type in ["true", "false"]:
                source_block = self.cfg.blocks.get(edge.source)
                target_block = self.cfg.blocks.get(edge.target)
                
                if source_block and target_block:
                    # El último statement del bloque fuente controla el bloque objetivo
                    control_statement = source_block.get_last_statement()
                    
                    if control_statement:
                        # Agregar dependencia de control a todos los statements del bloque objetivo
                        for controlled_statement in target_block.statements:
                            if control_statement != controlled_statement:
                                control_edge = DFGEdge(
                                    source=control_statement,
                                    target=controlled_statement,
                                    edge_type="control_flow",
                                    condition=edge.condition
                                )
                                self.dfg.add_edge(control_edge)

class FileDFGBuilder:
    """
    Construye DFGs para todas las funciones de un archivo.
    """
    
    def __init__(self):
        self.function_dfgs: Dict[str, DataFlowGraph] = {}
    
    def build_dfgs_for_file(self, ir_file: IRFile, file_cfgs: Dict[str, CFGBuilder]) -> Dict[str, DataFlowGraph]:
        """
        Construye DFGs para todas las funciones de un archivo.
        
        Args:
            ir_file: Archivo IR
            file_cfgs: CFGs de las funciones del archivo
            
        Returns:
            Diccionario con function_name -> DataFlowGraph
        """
        logger.info(f"Construyendo DFGs para archivo {ir_file.file_path}")
        
        self.function_dfgs.clear()
        
        # Construir DFG para cada función
        for function_name, ir_function in ir_file.functions.items():
            if function_name in file_cfgs:
                try:
                    cfg = file_cfgs[function_name]
                    function_builder = FunctionDFGBuilder()
                    dfg = function_builder.build_dfg_for_function(ir_function, cfg)
                    self.function_dfgs[function_name] = dfg
                    
                    logger.debug(f"DFG construido para función {function_name}: "
                               f"{len(dfg.nodes)} nodos, {len(dfg.edges)} aristas")
                    
                except Exception as e:
                    logger.error(f"Error construyendo DFG para función {function_name}: {e}")
                    continue
        
        # Construir DFG para código a nivel módulo si existe
        if "<module>" in file_cfgs and ir_file.module_nodes:
            try:
                module_function = IRFunction(
                    name="<module>",
                    file_path=ir_file.file_path,
                    start_line=1,
                    end_line=1,
                    parameters=[],
                    return_type=None,
                    nodes=ir_file.module_nodes
                )
                
                cfg = file_cfgs["<module>"]
                function_builder = FunctionDFGBuilder()
                dfg = function_builder.build_dfg_for_function(module_function, cfg)
                self.function_dfgs["<module>"] = dfg
                
                logger.debug(f"DFG construido para código módulo: {len(dfg.nodes)} nodos")
                
            except Exception as e:
                logger.error(f"Error construyendo DFG para código módulo: {e}")
        
        logger.info(f"DFGs construidos para {len(self.function_dfgs)} funciones")
        return self.function_dfgs
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte todos los DFGs a diccionario."""
        return {
            "functions": {
                function_name: dfg.to_dict() 
                for function_name, dfg in self.function_dfgs.items()
            },
            "metadata": {
                "total_functions": len(self.function_dfgs),
                "total_nodes": sum(len(dfg.nodes) for dfg in self.function_dfgs.values()),
                "total_edges": sum(len(dfg.edges) for dfg in self.function_dfgs.values())
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FileDFGBuilder':
        """Crea FileDFGBuilder desde un diccionario."""
        builder = cls()
        
        for function_name, dfg_data in data.get("functions", {}).items():
            builder.function_dfgs[function_name] = DataFlowGraph.from_dict(dfg_data)
        
        return builder
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas de todos los DFGs."""
        total_nodes = 0
        total_edges = 0
        data_flow_edges = 0
        control_flow_edges = 0
        function_stats = {}
        
        for function_name, dfg in self.function_dfgs.items():
            stats = dfg.get_stats()
            function_stats[function_name] = stats
            total_nodes += stats["total_nodes"]
            total_edges += stats["total_edges"]
            data_flow_edges += stats.get("data_flow_edges", 0)
            control_flow_edges += stats.get("control_flow_edges", 0)
        
        return {
            "total_functions": len(self.function_dfgs),
            "total_nodes": total_nodes,
            "total_edges": total_edges,
            "data_flow_edges": data_flow_edges,
            "control_flow_edges": control_flow_edges,
            "avg_nodes_per_function": total_nodes / len(self.function_dfgs) if self.function_dfgs else 0,
            "avg_edges_per_function": total_edges / len(self.function_dfgs) if self.function_dfgs else 0,
            "functions": function_stats
        }
