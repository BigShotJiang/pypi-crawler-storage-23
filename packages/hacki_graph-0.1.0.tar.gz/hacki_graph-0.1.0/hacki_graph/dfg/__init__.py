"""
Data Flow Graph (DFG) Module

Contiene todas las clases y funcionalidades para construir y analizar
Data Flow Graphs a partir de código IR y CFGs.
"""

from .graph import DataFlowGraph, DFGNode, DFGEdge, ProjectDFG
from .builder import FunctionDFGBuilder, FileDFGBuilder

__all__ = [
    'DataFlowGraph',
    'DFGNode', 
    'DFGEdge',
    'ProjectDFG',
    'FunctionDFGBuilder',
    'FileDFGBuilder'
]
