"""
IR Nodes Implementation

Implementa todos los tipos de nodos IR específicos para el análisis estático.
Cada nodo representa una operación o estructura específica del código.
"""

from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from .base import IRNode

# ============================================================================
# ASSIGNMENT NODES
# ============================================================================

@dataclass
class Assign(IRNode):
    """Nodo de asignación: target = value"""
    target: str = ""  # Variable de destino
    value: Optional['IRNode'] = None  # Expresión del valor
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Assign",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "target": self.target,
            "value": self.value.to_dict() if isinstance(self.value, IRNode) else self.value,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Assign':
        value_data = data["value"]
        value = create_node_from_dict(value_data) if isinstance(value_data, dict) else value_data
        
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            target=data["target"],
            value=value,
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        if isinstance(self.value, IRNode):
            return self.value.get_reads()
        return []
    
    def get_writes(self) -> List[str]:
        return [self.target]

@dataclass
class Declaration(IRNode):
    """Declaración de variable: var x = value"""
    variable: str = ""
    var_type: Optional[str] = None
    initial_value: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Declaration",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "variable": self.variable,
            "var_type": self.var_type,
            "initial_value": self.initial_value.to_dict() if self.initial_value else None,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Declaration':
        initial_value = None
        if data.get("initial_value"):
            initial_value = create_node_from_dict(data["initial_value"])
        
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            variable=data["variable"],
            var_type=data.get("var_type"),
            initial_value=initial_value,
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        if self.initial_value:
            return self.initial_value.get_reads()
        return []
    
    def get_writes(self) -> List[str]:
        return [self.variable]

# ============================================================================
# EXPRESSION NODES
# ============================================================================

@dataclass
class VarRef(IRNode):
    """Referencia a variable: x"""
    variable: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "VarRef",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "variable": self.variable,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'VarRef':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            variable=data["variable"],
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        return [self.variable]

@dataclass
class Literal(IRNode):
    """Literal: 42, "hello", true, null"""
    value: Any = None
    literal_type: str = "null"  # "int", "string", "bool", "null", etc.
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Literal",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "value": self.value,
            "literal_type": self.literal_type,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Literal':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            value=data["value"],
            literal_type=data["literal_type"],
            metadata=data.get("metadata", {})
        )

@dataclass
class BinaryOp(IRNode):
    """Operación binaria: left op right"""
    left: Optional['IRNode'] = None
    operator: str = ""
    right: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "BinaryOp",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "left": self.left.to_dict(),
            "operator": self.operator,
            "right": self.right.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BinaryOp':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            left=create_node_from_dict(data["left"]),
            operator=data["operator"],
            right=create_node_from_dict(data["right"]),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        reads = []
        reads.extend(self.left.get_reads())
        reads.extend(self.right.get_reads())
        return reads

@dataclass
class UnaryOp(IRNode):
    """Operación unaria: op operand"""
    operator: str = ""
    operand: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "UnaryOp",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "operator": self.operator,
            "operand": self.operand.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UnaryOp':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            operator=data["operator"],
            operand=create_node_from_dict(data["operand"]),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        return self.operand.get_reads()

# ============================================================================
# FUNCTION CALL NODES
# ============================================================================

@dataclass
class FunctionCall(IRNode):
    """Llamada a función: func(args)"""
    function_name: str = ""
    arguments: List['IRNode'] = field(default_factory=list)
    receiver: Optional['IRNode'] = None  # Para métodos: obj.method()
    target_function_id: Optional[str] = None  # ID del nodo "function" en graph.json (si se resolvió)
    graph_call_node_id: Optional[str] = None  # ID del nodo "call" en graph.json
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "FunctionCall",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "function_name": self.function_name,
            "arguments": [arg.to_dict() for arg in self.arguments],
            "receiver": self.receiver.to_dict() if self.receiver else None,
            "target_function_id": self.target_function_id,
            "graph_call_node_id": self.graph_call_node_id,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FunctionCall':
        arguments = [create_node_from_dict(arg) for arg in data["arguments"]]
        receiver = create_node_from_dict(data["receiver"]) if data.get("receiver") else None
        
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            function_name=data["function_name"],
            arguments=arguments,
            receiver=receiver,
            target_function_id=data.get("target_function_id"),
            graph_call_node_id=data.get("graph_call_node_id"),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        reads = []
        for arg in self.arguments:
            reads.extend(arg.get_reads())
        if self.receiver:
            reads.extend(self.receiver.get_reads())
        return reads
    
    def get_calls(self) -> List[str]:
        return [self.function_name]

@dataclass
class MemberAccess(IRNode):
    """Acceso a miembro: obj.member"""
    object: Optional['IRNode'] = None
    member: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "MemberAccess",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "object": self.object.to_dict(),
            "member": self.member,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemberAccess':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            object=create_node_from_dict(data["object"]),
            member=data["member"],
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        return self.object.get_reads()

@dataclass
class IndexAccess(IRNode):
    """Acceso por índice: obj[index]"""
    object: Optional['IRNode'] = None
    index: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "IndexAccess",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "object": self.object.to_dict(),
            "index": self.index.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'IndexAccess':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            object=create_node_from_dict(data["object"]),
            index=create_node_from_dict(data["index"]),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        reads = []
        reads.extend(self.object.get_reads())
        reads.extend(self.index.get_reads())
        return reads

# ============================================================================
# CONTROL FLOW NODES
# ============================================================================

@dataclass
class Return(IRNode):
    """Return statement: return value"""
    value: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Return",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "value": self.value.to_dict() if self.value else None,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Return':
        value = create_node_from_dict(data["value"]) if data.get("value") else None
        
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            value=value,
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        if self.value:
            return self.value.get_reads()
        return []

@dataclass
class If(IRNode):
    """If statement: if condition"""
    condition: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "If",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "condition": self.condition.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'If':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            condition=create_node_from_dict(data["condition"]),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        return self.condition.get_reads()

@dataclass
class While(IRNode):
    """While loop: while condition"""
    condition: Optional['IRNode'] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "While",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "condition": self.condition.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'While':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            condition=create_node_from_dict(data["condition"]),
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        return self.condition.get_reads()

@dataclass
class For(IRNode):
    """For loop: for init; condition; update"""
    init: Optional['IRNode'] = None
    condition: Optional['IRNode'] = None
    update: Optional['IRNode'] = None
    iterator: Optional[str] = None  # Para for-each loops
    iterable: Optional['IRNode'] = None  # Para for-each loops
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "For",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "init": self.init.to_dict() if self.init else None,
            "condition": self.condition.to_dict() if self.condition else None,
            "update": self.update.to_dict() if self.update else None,
            "iterator": self.iterator,
            "iterable": self.iterable.to_dict() if self.iterable else None,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'For':
        init = create_node_from_dict(data["init"]) if data.get("init") else None
        condition = create_node_from_dict(data["condition"]) if data.get("condition") else None
        update = create_node_from_dict(data["update"]) if data.get("update") else None
        iterable = create_node_from_dict(data["iterable"]) if data.get("iterable") else None
        
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            init=init,
            condition=condition,
            update=update,
            iterator=data.get("iterator"),
            iterable=iterable,
            metadata=data.get("metadata", {})
        )
    
    def get_reads(self) -> List[str]:
        reads = []
        if self.init:
            reads.extend(self.init.get_reads())
        if self.condition:
            reads.extend(self.condition.get_reads())
        if self.update:
            reads.extend(self.update.get_reads())
        if self.iterable:
            reads.extend(self.iterable.get_reads())
        return reads
    
    def get_writes(self) -> List[str]:
        writes = []
        if self.init:
            writes.extend(self.init.get_writes())
        if self.update:
            writes.extend(self.update.get_writes())
        if self.iterator:
            writes.append(self.iterator)
        return writes

@dataclass
class Break(IRNode):
    """Break statement"""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Break",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Break':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            metadata=data.get("metadata", {})
        )

@dataclass
class Continue(IRNode):
    """Continue statement"""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "Continue",
            "id": self.id,
            "source_node_id": self.source_node_id,
            "line": self.line,
            "column": self.column,
            "file_path": self.file_path,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Continue':
        return cls(
            id=data["id"],
            source_node_id=data["source_node_id"],
            line=data["line"],
            column=data["column"],
            file_path=data["file_path"],
            metadata=data.get("metadata", {})
        )

# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def create_node_from_dict(data: Dict[str, Any]) -> IRNode:
    """
    Factory function para crear nodos IR desde diccionarios.
    
    Args:
        data: Diccionario con los datos del nodo
        
    Returns:
        IRNode del tipo apropiado
    """
    node_type = data["type"]
    
    node_classes = {
        "Assign": Assign,
        "Declaration": Declaration,
        "VarRef": VarRef,
        "Literal": Literal,
        "BinaryOp": BinaryOp,
        "UnaryOp": UnaryOp,
        "FunctionCall": FunctionCall,
        "MemberAccess": MemberAccess,
        "IndexAccess": IndexAccess,
        "Return": Return,
        "If": If,
        "While": While,
        "For": For,
        "Break": Break,
        "Continue": Continue,
    }
    
    if node_type not in node_classes:
        raise ValueError(f"Unknown IR node type: {node_type}")
    
    return node_classes[node_type].from_dict(data)
