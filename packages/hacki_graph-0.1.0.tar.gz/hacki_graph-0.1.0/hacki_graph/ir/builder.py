"""
IR Builder

Construye la Intermediate Representation (IR) desde árboles AST de Tree-sitter.
Coordina la construcción de IR para diferentes lenguajes.
"""

import logging
from typing import Dict, List, Any, Optional, Type
from pathlib import Path

from .base import IRBuilder, IRFile
from ..language_specs.base import LanguageSpec
from ..tree_sitter_loader import get_tree_sitter_loader

logger = logging.getLogger(__name__)

class IRManager:
    """
    Gestor principal para la construcción de IR.
    
    Coordina la construcción de IR para múltiples archivos y lenguajes,
    manteniendo consistencia y eficiencia en el proceso.
    """
    
    def __init__(self):
        self.tree_sitter_loader = get_tree_sitter_loader()
        self._language_builders: Dict[str, IRBuilder] = {}
        self._language_specs: Dict[str, LanguageSpec] = {}
    
    def register_language(self, language: str, builder_class: Type[IRBuilder], spec_class: Type[LanguageSpec]):
        """
        Registra un lenguaje con su builder y spec.
        
        Args:
            language: Nombre del lenguaje
            builder_class: Clase del IRBuilder para el lenguaje
            spec_class: Clase del LanguageSpec para el lenguaje
        """
        self._language_builders[language] = builder_class(language)
        self._language_specs[language] = spec_class()
        logger.debug(f"Lenguaje {language} registrado para IR")
    
    def build_ir_for_file(self, file_path: str, language: str) -> Optional[IRFile]:
        """
        Construye la IR para un archivo específico.
        
        Args:
            file_path: Ruta del archivo
            language: Lenguaje del archivo
            
        Returns:
            IRFile con la IR del archivo o None si hay error
        """
        if language not in self._language_builders:
            logger.warning(f"Lenguaje {language} no soportado para IR")
            return None
        
        try:
            # Parsear archivo con Tree-sitter
            tree = self.tree_sitter_loader.parse_file(file_path, language)
            if not tree:
                logger.error(f"❌ No se pudo parsear {file_path} con Tree-sitter")
                import traceback
                logger.debug(traceback.format_exc())
                return None
            
            # Construir IR
            builder = self._language_builders[language]
            ir_file = builder.build_ir_from_ast(tree, file_path)
            
            if ir_file:
                logger.debug(f"✓ IR construida para {file_path}: {len(ir_file.functions)} funciones, {len(ir_file.module_nodes)} nodos módulo")
            else:
                logger.warning(f"⚠ IR builder retornó None para {file_path}")
            
            return ir_file
            
        except Exception as e:
            logger.error(f"❌ Error construyendo IR para {file_path}: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            return None
    
    def build_ir_for_project(self, project_root: str, file_paths: List[str]) -> Dict[str, IRFile]:
        """
        Construye la IR para múltiples archivos de un proyecto.
        
        Args:
            project_root: Directorio raíz del proyecto
            file_paths: Lista de rutas de archivos a procesar
            
        Returns:
            Diccionario con file_path -> IRFile
        """
        from ..language_specs.base import get_language_spec
        from pathlib import Path
        ir_files = {}
        skipped_files = []
        error_files = []
        
        logger.info(f"Procesando {len(file_paths)} archivos para IR")
        
        for file_path in file_paths:
            # Verificar que el archivo existe
            path_obj = Path(file_path)
            if not path_obj.exists():
                logger.warning(f"Archivo no existe: {file_path}")
                error_files.append(f"{file_path}: archivo no existe")
                continue
            
            # Detectar lenguaje usando el sistema nuevo
            file_extension = path_obj.suffix.lower()
            language_spec = get_language_spec(file_extension)
            if not language_spec:
                logger.debug(f"Lenguaje no soportado para {file_path} (extensión: {file_extension})")
                skipped_files.append(file_path)
                continue
            
            # Mapear extensión a nombre de lenguaje Tree-sitter
            extension_to_language = {
                '.py': 'python', '.pyw': 'python',
                '.js': 'javascript', '.jsx': 'javascript',
                '.ts': 'typescript', '.tsx': 'typescript',
                '.java': 'java',
                '.cs': 'csharp',
                '.go': 'go',
                '.php': 'php'
            }
            language = extension_to_language.get(file_extension, 'unknown')
            
            # Construir IR
            try:
                ir_file = self.build_ir_for_file(file_path, language)
                if ir_file:
                    ir_files[file_path] = ir_file
                else:
                    error_files.append(f"{file_path}: build_ir_for_file retornó None")
            except Exception as e:
                logger.error(f"Excepción construyendo IR para {file_path}: {e}")
                error_files.append(f"{file_path}: {e}")
        
        logger.info(f"IR construida para {len(ir_files)}/{len(file_paths)} archivos del proyecto")
        if skipped_files:
            logger.warning(f"⚠ Archivos omitidos (lenguaje no soportado): {len(skipped_files)}")
            if len(skipped_files) <= 20:
                for f in skipped_files:
                    logger.debug(f"  - {f}")
        if error_files:
            logger.error(f"❌ Archivos con errores: {len(error_files)}")
            # Mostrar todos los errores, no solo los primeros 10
            for error in error_files:
                logger.error(f"  - {error}")
            # Si hay muchos errores, mostrar un resumen
            if len(error_files) > 20:
                logger.error(f"  ... y {len(error_files) - 20} errores más")
        
        return ir_files
    
    def save_ir_to_json(self, ir_files: Dict[str, IRFile], output_path: str) -> bool:
        """
        Guarda la IR en formato JSON.
        
        Args:
            ir_files: Diccionario de archivos IR
            output_path: Ruta del archivo JSON de salida
            
        Returns:
            True si se guardó correctamente
        """
        try:
            import json
            from pathlib import Path
            
            # Normalizar rutas a relativas para el JSON
            # Si las rutas son absolutas, convertirlas a relativas basándose en el directorio del output
            output_dir = Path(output_path).parent.parent.parent  # .hacki/graphs -> .hacki -> project_root
            
            normalized_files = {}
            for file_path, ir_file in ir_files.items():
                # Normalizar la ruta
                path_obj = Path(file_path)
                if path_obj.is_absolute():
                    try:
                        # Intentar hacer la ruta relativa al project_root
                        rel_path = path_obj.relative_to(output_dir)
                        normalized_key = str(rel_path).replace('\\', '/')  # Normalizar separadores
                    except ValueError:
                        # Si no se puede hacer relativa, usar el nombre del archivo
                        normalized_key = path_obj.name
                else:
                    normalized_key = str(path_obj).replace('\\', '/')
                
                normalized_files[normalized_key] = ir_file.to_dict()
            
            # Convertir a formato JSON
            json_data = {
                "metadata": {
                    "total_files": len(ir_files),
                    "languages": list(set(ir_file.language for ir_file in ir_files.values()))
                },
                "files": normalized_files
            }
            
            # Guardar archivo
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"IR guardada en {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error guardando IR: {e}")
            return False
    
    def load_ir_from_json(self, input_path: str) -> Dict[str, IRFile]:
        """
        Carga la IR desde un archivo JSON.
        
        Args:
            input_path: Ruta del archivo JSON
            
        Returns:
            Diccionario de archivos IR
        """
        try:
            import json
            
            with open(input_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            
            ir_files = {}
            for file_path, file_data in json_data.get("files", {}).items():
                ir_files[file_path] = IRFile.from_dict(file_data)
            
            logger.info(f"IR cargada desde {input_path}: {len(ir_files)} archivos")
            return ir_files
            
        except Exception as e:
            logger.error(f"Error cargando IR: {e}")
            return {}
    
    def get_supported_languages(self) -> List[str]:
        """Retorna la lista de lenguajes soportados para IR."""
        return list(self._language_builders.keys())
    
    def get_ir_stats(self, ir_files: Dict[str, IRFile]) -> Dict[str, Any]:
        """
        Obtiene estadísticas de la IR.
        
        Args:
            ir_files: Diccionario de archivos IR
            
        Returns:
            Diccionario con estadísticas
        """
        total_functions = 0
        total_nodes = 0
        languages = set()
        node_types = {}
        
        for ir_file in ir_files.values():
            languages.add(ir_file.language)
            total_functions += len(ir_file.functions)
            total_nodes += len(ir_file.module_nodes)
            
            # Contar nodos por función
            for function in ir_file.functions.values():
                total_nodes += len(function.nodes)
                
                # Contar tipos de nodos
                for node in function.nodes:
                    node_type = type(node).__name__
                    node_types[node_type] = node_types.get(node_type, 0) + 1
            
            # Contar nodos a nivel módulo
            for node in ir_file.module_nodes:
                node_type = type(node).__name__
                node_types[node_type] = node_types.get(node_type, 0) + 1
        
        return {
            "total_files": len(ir_files),
            "total_functions": total_functions,
            "total_nodes": total_nodes,
            "languages": list(languages),
            "node_types": node_types
        }

# Instancia global del manager
_ir_manager_instance = None

def get_ir_manager() -> IRManager:
    """
    Obtiene la instancia global del IRManager.
    
    Returns:
        Instancia del IRManager
    """
    global _ir_manager_instance
    if _ir_manager_instance is None:
        _ir_manager_instance = IRManager()
        _register_default_languages()
    return _ir_manager_instance

def _register_default_languages():
    """Registra los lenguajes por defecto en el IRManager."""
    manager = _ir_manager_instance
    
    try:
        # Importar builders de lenguajes
        from ..language_specs.python import PythonIRBuilder, PythonLanguageSpec
        from ..language_specs.js_ts import JavaScriptIRBuilder, JavaScriptLanguageSpec, TypeScriptIRBuilder, TypeScriptLanguageSpec
        from ..language_specs.java import JavaIRBuilder, JavaLanguageSpec
        from ..language_specs.csharp import CSharpIRBuilder, CSharpLanguageSpec
        from ..language_specs.go import GoIRBuilder, GoLanguageSpec
        from ..language_specs.php import PHPIRBuilder, PHPLanguageSpec
        
        # Registrar lenguajes
        manager.register_language("python", PythonIRBuilder, PythonLanguageSpec)
        manager.register_language("javascript", JavaScriptIRBuilder, JavaScriptLanguageSpec)
        manager.register_language("typescript", TypeScriptIRBuilder, TypeScriptLanguageSpec)
        manager.register_language("java", JavaIRBuilder, JavaLanguageSpec)
        manager.register_language("c_sharp", CSharpIRBuilder, CSharpLanguageSpec)
        manager.register_language("go", GoIRBuilder, GoLanguageSpec)
        manager.register_language("php", PHPIRBuilder, PHPLanguageSpec)
        
        logger.info("Lenguajes por defecto registrados en IRManager")
        
    except ImportError as e:
        logger.warning(f"No se pudieron registrar todos los lenguajes: {e}")
