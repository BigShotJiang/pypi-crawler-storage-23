"""
IR Base Classes

Define las clases base para la Intermediate Representation (IR) de HackiAI.
La IR es una representación uniforme del código que abstrae las diferencias
entre lenguajes para facilitar el análisis estático.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
import json

@dataclass
class IRNode(ABC):
    """
    Clase base para todos los nodos de la IR.
    
    Cada nodo IR representa una operación o estructura de control
    en el código fuente, independiente del lenguaje original.
    """
    id: str
    source_node_id: str  # ID del nodo Tree-sitter original
    line: int
    column: int
    file_path: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el nodo a diccionario para serialización JSON."""
        pass
    
    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'IRNode':
        """Crea un nodo desde un diccionario."""
        pass
    
    def get_reads(self) -> List[str]:
        """Retorna las variables que este nodo lee."""
        return []
    
    def get_writes(self) -> List[str]:
        """Retorna las variables que este nodo escribe."""
        return []
    
    def get_calls(self) -> List[str]:
        """Retorna las funciones que este nodo llama."""
        return []

@dataclass
class IRFunction:
    """
    Representa una función completa en la IR.
    
    Contiene todos los nodos IR que pertenecen a una función,
    junto con metadatos sobre la función.
    """
    name: str
    file_path: str
    start_line: int
    end_line: int
    parameters: List[str]
    return_type: Optional[str]
    nodes: List[IRNode] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte la función a diccionario."""
        return {
            "name": self.name,
            "file_path": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "parameters": self.parameters,
            "return_type": self.return_type,
            "nodes": [node.to_dict() for node in self.nodes],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'IRFunction':
        """Crea una función desde un diccionario."""
        from .nodes import create_node_from_dict
        
        nodes = [create_node_from_dict(node_data) for node_data in data.get("nodes", [])]
        
        return cls(
            name=data["name"],
            file_path=data["file_path"],
            start_line=data["start_line"],
            end_line=data["end_line"],
            parameters=data.get("parameters", []),
            return_type=data.get("return_type"),
            nodes=nodes,
            metadata=data.get("metadata", {})
        )

@dataclass
class IRFile:
    """
    Representa un archivo completo en la IR.
    
    Contiene todas las funciones del archivo y el código a nivel módulo.
    """
    file_path: str
    language: str
    functions: Dict[str, IRFunction] = field(default_factory=dict)
    module_nodes: List[IRNode] = field(default_factory=list)  # Código a nivel módulo
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el archivo a diccionario."""
        return {
            "file_path": self.file_path,
            "language": self.language,
            "functions": {name: func.to_dict() for name, func in self.functions.items()},
            "module_nodes": [node.to_dict() for node in self.module_nodes],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'IRFile':
        """Crea un archivo desde un diccionario."""
        from .nodes import create_node_from_dict
        
        functions = {
            name: IRFunction.from_dict(func_data) 
            for name, func_data in data.get("functions", {}).items()
        }
        
        module_nodes = [
            create_node_from_dict(node_data) 
            for node_data in data.get("module_nodes", [])
        ]
        
        return cls(
            file_path=data["file_path"],
            language=data["language"],
            functions=functions,
            module_nodes=module_nodes,
            metadata=data.get("metadata", {})
        )

class IRBuilder(ABC):
    """
    Clase base para constructores de IR específicos por lenguaje.
    
    Cada lenguaje debe implementar su propio IRBuilder que convierta
    nodos Tree-sitter a nodos IR.
    """
    
    def __init__(self, language: str):
        self.language = language
        self._node_counter = 0
    
    def _generate_ir_id(self, file_path: str, line: int, column: int) -> str:
        """Genera un ID único para un nodo IR."""
        self._node_counter += 1
        return f"{file_path}:{line}:{column}:ir{self._node_counter}"
    
    @abstractmethod
    def build_ir_from_ast(self, ast_tree: Any, file_path: str) -> IRFile:
        """
        Construye la IR desde un árbol AST de Tree-sitter.
        
        Args:
            ast_tree: Árbol AST de Tree-sitter
            file_path: Ruta del archivo fuente
            
        Returns:
            IRFile con toda la IR del archivo
        """
        pass
    
    @abstractmethod
    def extract_functions(self, ast_tree: Any) -> List[Dict[str, Any]]:
        """Extrae información de funciones del AST."""
        pass
    
    @abstractmethod
    def convert_node_to_ir(self, node: Any, file_path: str) -> Optional[IRNode]:
        """Convierte un nodo Tree-sitter individual a IR."""
        pass
