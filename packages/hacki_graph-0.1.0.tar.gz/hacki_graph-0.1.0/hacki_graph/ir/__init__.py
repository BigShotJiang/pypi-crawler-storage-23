"""
Intermediate Representation (IR) Module

Contiene todas las clases y funcionalidades para la IR de HackiAI.
"""

from .base import IRNode, IRFunction, IRFile, IRBuilder
from .nodes import *
from .builder import IRManager, get_ir_manager

__all__ = [
    'IRNode',
    'IRFunction', 
    'IRFile',
    'IRBuilder',
    'IRManager',
    'get_ir_manager',
    # Nodes
    'Assign',
    'Declaration',
    'VarRef',
    'Literal',
    'BinaryOp',
    'UnaryOp',
    'FunctionCall',
    'MemberAccess',
    'IndexAccess',
    'Return',
    'If',
    'While',
    'For',
    'Break',
    'Continue'
]
