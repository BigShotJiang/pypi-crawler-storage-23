from __future__ import annotations

from pathlib import Path

import pytest

from suvra.core.policy import PolicyEngine

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "docs" / "policies" / "templates" / "openclaw"
TEMPLATE_FILES = [
    "openclaw-monitor-safe.yaml",
    "openclaw-dev-lite.yaml",
    "openclaw-research.yaml",
    "openclaw-ci.yaml",
]


def _load_yaml(path: Path) -> dict:
    yaml = pytest.importorskip("yaml")
    data = yaml.safe_load(path.read_text()) or {}
    assert isinstance(data, dict)
    return data


@pytest.mark.parametrize("template_name", TEMPLATE_FILES)
def test_openclaw_templates_parse_and_normalize(template_name: str) -> None:
    policy_data = _load_yaml(TEMPLATE_DIR / template_name)
    engine = PolicyEngine.from_policy_data(policy_data)
    assert isinstance(engine.policy, dict)
    assert isinstance(engine.policy.get("rules"), list)
    assert engine.policy.get("defaults", {}).get("mode") in {"allow", "deny"}


def test_openclaw_monitor_safe_decisions() -> None:
    policy_data = _load_yaml(TEMPLATE_DIR / "openclaw-monitor-safe.yaml")
    engine = PolicyEngine.from_policy_data(policy_data)

    write = engine.evaluate(
        {"type": "fs.write_file", "params": {"path": "workspace/ok.txt", "content": "hello"}, "meta": {"actor": "t"}}
    )
    delete = engine.evaluate({"type": "fs.delete_file", "params": {"path": "workspace/ok.txt"}, "meta": {"actor": "t"}})
    shell = engine.evaluate({"type": "shell.exec", "params": {"command": "git status", "cwd": "workspace/"}})

    assert write.decision == "allow"
    assert delete.decision == "needs_approval"
    assert shell.decision == "needs_approval"


def test_openclaw_dev_lite_decisions() -> None:
    policy_data = _load_yaml(TEMPLATE_DIR / "openclaw-dev-lite.yaml")
    engine = PolicyEngine.from_policy_data(policy_data)

    write = engine.evaluate(
        {"type": "fs.write_file", "params": {"path": "workspace/ok.txt", "content": "hello"}, "meta": {"actor": "t"}}
    )
    http = engine.evaluate({"type": "http.request", "params": {"method": "GET", "url": "https://github.com"}})
    secrets = engine.evaluate({"type": "secrets.read", "params": {"name": "OPENAI_API_KEY"}})

    assert write.decision == "allow"
    assert http.decision == "allow"
    assert secrets.decision == "needs_approval"


def test_openclaw_research_decisions() -> None:
    policy_data = _load_yaml(TEMPLATE_DIR / "openclaw-research.yaml")
    engine = PolicyEngine.from_policy_data(policy_data)

    write = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/notes/findings.md", "content": "hello"},
            "meta": {"actor": "t"},
        }
    )
    delete = engine.evaluate(
        {"type": "fs.delete_file", "params": {"path": "workspace/notes/findings.md"}, "meta": {"actor": "t"}}
    )
    http = engine.evaluate({"type": "http.request", "params": {"method": "GET", "url": "https://docs.python.org/3/"}})
    shell = engine.evaluate({"type": "shell.exec", "params": {"command": "git status"}})

    assert write.decision == "allow"
    assert delete.decision == "deny"
    assert http.decision == "allow"
    assert shell.decision == "deny"


def test_openclaw_ci_decisions() -> None:
    policy_data = _load_yaml(TEMPLATE_DIR / "openclaw-ci.yaml")
    engine = PolicyEngine.from_policy_data(policy_data)

    write = engine.evaluate(
        {"type": "fs.write_file", "params": {"path": "workspace/logs/build.log", "content": "ok"}, "meta": {"actor": "t"}}
    )
    delete = engine.evaluate({"type": "fs.delete_file", "params": {"path": "workspace/logs/build.log"}, "meta": {"actor": "t"}})
    http = engine.evaluate({"type": "http.request", "params": {"method": "GET", "url": "https://pypi.org/project/fastapi"}})
    secrets = engine.evaluate({"type": "secrets.read", "params": {"name": "GITHUB_TOKEN"}})

    assert write.decision == "allow"
    assert delete.decision == "needs_approval"
    assert http.decision == "allow"
    assert secrets.decision == "needs_approval"
