from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_default_deny_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(json.dumps({"defaults": {"mode": "deny"}, "rules": []}))


def _get_audit_row(engine: EnforcementEngine, action_id: str) -> dict[str, str]:
    with sqlite3.connect(engine.audit.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT decision, status, result_summary FROM audit_events WHERE action_id = ? ORDER BY event_id DESC LIMIT 1",
            (action_id,),
        ).fetchone()
    return dict(row) if row else {}


def test_execute_monitor_mode_runs_without_blocking_and_without_approvals(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_MODE", "monitor")
    _write_default_deny_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "mode-monitor-exec-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/monitor.txt", "content": "monitor"},
                    "meta": {"actor": "mode"},
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "monitor"
        assert payload["status"] == "executed"
        assert (tmp_path / "workspace" / "monitor.txt").exists()
        assert app_main.engine.audit.approval_counts()["total"] == 0

        row = _get_audit_row(app_main.engine, "mode-monitor-exec-1")
        assert row["decision"] == "monitor"
        assert row["status"] == "executed"
        assert "policy_decision=deny" in (row["result_summary"] or "")
    finally:
        app_main.engine = old_engine


def test_execute_disabled_mode_runs_without_policy_or_approvals(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_MODE", "disabled")
    _write_default_deny_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "mode-disabled-exec-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/disabled.txt", "content": "disabled"},
                    "meta": {"actor": "mode"},
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "disabled"
        assert payload["status"] == "executed"
        assert (tmp_path / "workspace" / "disabled.txt").exists()
        assert app_main.engine.audit.approval_counts()["total"] == 0

        row = _get_audit_row(app_main.engine, "mode-disabled-exec-1")
        assert row["decision"] == "disabled"
        assert row["status"] == "executed"
        assert row["result_summary"] == "enforcement disabled"
    finally:
        app_main.engine = old_engine


def test_simulate_ignores_mode_and_remains_strict(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_MODE", "monitor")
    _write_default_deny_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "mode-sim-strict-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/sim.txt", "content": "simulate"},
                        "meta": {"actor": "mode"},
                    }
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "deny"
        assert not (tmp_path / "workspace" / "sim.txt").exists()
        assert app_main.engine.audit.approval_counts()["total"] == 0
    finally:
        app_main.engine = old_engine
