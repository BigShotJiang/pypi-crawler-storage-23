from __future__ import annotations

import json
from pathlib import Path

import pytest

from suvra.sdk.decorators import guarded_tool
from suvra.sdk.guard import Guard


def _write_allow_write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    }
                ],
            }
        )
    )


def _write_delete_needs_approval_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    }
                ],
            }
        )
    )


def test_guarded_tool_writes_file_when_allowed(tmp_path: Path) -> None:
    _write_allow_write_policy(tmp_path)
    guard = Guard(policy=str(tmp_path / "policy.yaml"), db_path="audit.db")

    @guarded_tool(guard, "fs.write_file")
    def write_file(path: str, content: str) -> str:
        return "ok"

    result = write_file(path="workspace/decorated.txt", content="decorator write")
    assert result == "ok"
    assert tmp_path.joinpath("workspace/decorated.txt").read_text() == "decorator write"


def test_guarded_tool_raises_when_action_needs_approval(tmp_path: Path) -> None:
    _write_delete_needs_approval_policy(tmp_path)
    guard = Guard(policy=str(tmp_path / "policy.yaml"), db_path="audit.db")
    target = tmp_path.joinpath("workspace/demo/delete_me.txt")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("keep me")
    called = {"value": False}

    @guarded_tool(guard, "fs.delete_file")
    def delete_file(path: str) -> str:
        called["value"] = True
        return "deleted"

    with pytest.raises(RuntimeError) as exc:
        delete_file(path="workspace/demo/delete_me.txt")

    assert "needs_approval" in str(exc.value)
    assert target.exists()
    assert called["value"] is False

