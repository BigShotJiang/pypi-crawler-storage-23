from __future__ import annotations

import importlib

from fastapi.testclient import TestClient

from suvra.app import main as app_main


def _reload_app() -> object:
    return importlib.reload(app_main)


def test_cors_headers_absent_when_env_unset(monkeypatch) -> None:
    monkeypatch.delenv("SUVRA_CORS_ORIGINS", raising=False)
    module = _reload_app()
    with TestClient(module.app) as client:
        resp = client.get("/health")
        assert resp.status_code == 200
        assert "access-control-allow-origin" not in {k.lower(): v for k, v in resp.headers.items()}


def test_cors_preflight_allowed_when_env_set(monkeypatch) -> None:
    monkeypatch.setenv("SUVRA_CORS_ORIGINS", "http://localhost:3000")
    monkeypatch.setenv("SUVRA_AUTH_TOKEN", "devtoken")
    module = _reload_app()
    with TestClient(module.app) as client:
        allowed = client.options(
            "/actions/validate",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "Content-Type, X-Suvra-Token",
            },
        )
        assert allowed.status_code in (200, 204)
        assert allowed.headers.get("access-control-allow-origin") == "http://localhost:3000"
        assert allowed.headers.get("access-control-allow-credentials") == "true"

        disallowed = client.options(
            "/actions/validate",
            headers={
                "Origin": "http://evil.example",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "Content-Type, X-Suvra-Token",
            },
        )
        assert disallowed.status_code in (200, 204)
        assert disallowed.headers.get("access-control-allow-origin") is None

    monkeypatch.delenv("SUVRA_CORS_ORIGINS", raising=False)
    monkeypatch.delenv("SUVRA_AUTH_TOKEN", raising=False)
    _reload_app()
