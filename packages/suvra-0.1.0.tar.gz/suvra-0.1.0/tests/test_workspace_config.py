from __future__ import annotations

import json
from pathlib import Path

import pytest

from suvra.core.config import get_workspace_dir
from suvra.core.service import SuvraError, SuvraService


def _write_policy(root: Path, path_prefix: str) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_write",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": path_prefix, "max_bytes": 2048},
                    }
                ],
            }
        )
    )


def test_workspace_default_allows_workspace_paths(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_WORKSPACE_DIR", raising=False)
    _write_policy(tmp_path, path_prefix="workspace/")
    service = SuvraService(tmp_path)

    result = service.execute(
        {
            "action_id": "ws-default-1",
            "type": "fs.write_file",
            "params": {"path": "workspace/out.txt", "content": "ok"},
            "meta": {"actor": "test"},
        }
    )

    assert result["decision"] == "allow"
    assert tmp_path.joinpath("workspace/out.txt").read_text() == "ok"


def test_workspace_default_blocks_absolute_and_traversal(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_WORKSPACE_DIR", raising=False)
    _write_policy(tmp_path, path_prefix="")
    service = SuvraService(tmp_path)

    with pytest.raises(SuvraError, match="path must remain within workspace/"):
        service.execute(
            {
                "action_id": "ws-default-abs",
                "type": "fs.write_file",
                "params": {"path": "/tmp/out.txt", "content": "x"},
                "meta": {"actor": "test"},
            }
        )

    with pytest.raises(SuvraError, match="path traversal is not allowed; path must remain within workspace/"):
        service.execute(
            {
                "action_id": "ws-default-traversal",
                "type": "fs.write_file",
                "params": {"path": "workspace/../secrets.txt", "content": "x"},
                "meta": {"actor": "test"},
            }
        )


def test_workspace_dir_env_changes_jail_root(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SUVRA_WORKSPACE_DIR", "mywork")
    _write_policy(tmp_path, path_prefix="")
    service = SuvraService(tmp_path)

    allowed = service.execute(
        {
            "action_id": "ws-custom-allow",
            "type": "fs.write_file",
            "params": {"path": "mywork/ok.txt", "content": "ok"},
            "meta": {"actor": "test"},
        }
    )
    assert allowed["decision"] == "allow"
    assert tmp_path.joinpath("mywork/ok.txt").read_text() == "ok"

    with pytest.raises(SuvraError, match="path must remain within mywork/"):
        service.execute(
            {
                "action_id": "ws-custom-block-workspace",
                "type": "fs.write_file",
                "params": {"path": "workspace/not_allowed.txt", "content": "x"},
                "meta": {"actor": "test"},
            }
        )

    with pytest.raises(SuvraError, match="path traversal is not allowed; path must remain within mywork/"):
        service.execute(
            {
                "action_id": "ws-custom-traversal",
                "type": "fs.write_file",
                "params": {"path": "mywork/../secrets.txt", "content": "x"},
                "meta": {"actor": "test"},
            }
        )


@pytest.mark.parametrize(
    "raw_value",
    ["", "   ", "/tmp", "../tmp", "mywork/../escape", "..\\escape"],
)
def test_invalid_workspace_dir_values_raise_clear_error(monkeypatch, raw_value: str) -> None:
    monkeypatch.setenv("SUVRA_WORKSPACE_DIR", raw_value)
    with pytest.raises(ValueError, match="SUVRA_WORKSPACE_DIR"):
        get_workspace_dir()
