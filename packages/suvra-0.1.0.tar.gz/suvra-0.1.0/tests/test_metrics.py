from __future__ import annotations

import json
import re
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )


def _reset_metrics() -> None:
    for series in app_main.app.state.metrics.values():
        series.clear()


def _simulation_counter(text: str, decision: str) -> int:
    pattern = re.compile(
        rf'^suvra_simulations_total\{{[^}}]*decision="{re.escape(decision)}"[^}}]*\}}\s+(\d+)$',
        re.MULTILINE,
    )
    match = pattern.search(text)
    return int(match.group(1)) if match else 0


def test_metrics_endpoint_returns_200(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/metrics")
        assert response.status_code == 200
        assert response.headers.get("content-type", "").startswith("text/plain")
        body = response.text
        assert "# TYPE suvra_requests_total counter" in body
        assert "# TYPE suvra_policy_decisions_total counter" in body
        assert "# TYPE suvra_simulations_total counter" in body
    finally:
        app_main.engine = old_engine


def test_metrics_simulation_counter_increments_after_simulate_call(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    try:
        with TestClient(app_main.app) as client:
            before = client.get("/metrics")
            before_count = _simulation_counter(before.text, "allow")

            sim = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "metrics-sim-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/metrics.txt", "content": "hello"},
                        "meta": {"actor": "metrics"},
                    }
                },
            )
            assert sim.status_code == 200

            after = client.get("/metrics")
            after_count = _simulation_counter(after.text, "allow")

        assert after_count >= before_count + 1
    finally:
        app_main.engine = old_engine


def test_metrics_bypasses_auth(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    _reset_metrics()
    monkeypatch.setenv("SUVRA_AUTH_TOKEN", "devtoken")
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/metrics")
        assert response.status_code == 200
    finally:
        app_main.engine = old_engine
