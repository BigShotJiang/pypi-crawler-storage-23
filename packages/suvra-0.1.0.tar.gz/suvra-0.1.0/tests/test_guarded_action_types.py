from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_allow_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {"id": "allow_shell_exec", "effect": "allow", "type": "shell.exec", "constraints": {}},
                    {"id": "allow_email_delete", "effect": "allow", "type": "email.delete", "constraints": {}},
                    {"id": "allow_secrets_read", "effect": "allow", "type": "secrets.read", "constraints": {}},
                ],
            }
        )
    )


def _latest_audit_status(engine: EnforcementEngine, action_id: str) -> str | None:
    with sqlite3.connect(engine.audit.db_path) as conn:
        row = conn.execute(
            "SELECT status FROM audit_events WHERE action_id = ? ORDER BY event_id DESC LIMIT 1",
            (action_id,),
        ).fetchone()
    if row is None:
        return None
    return str(row[0])


@pytest.mark.parametrize(
    ("action_type", "params", "rule_id"),
    [
        ("shell.exec", {"command": "git status", "args": [], "cwd": "workspace/"}, "sim-shell"),
        ("email.delete", {"provider": "gmail", "message_id": "m-1", "mailbox": "INBOX"}, "sim-email"),
        ("secrets.read", {"name": "OPENAI_API_KEY", "purpose": "simulation"}, "sim-secrets"),
    ],
)
def test_simulate_supports_guarded_action_types_with_policy_override(
    tmp_path: Path,
    action_type: str,
    params: dict[str, object],
    rule_id: str,
) -> None:
    _write_allow_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": f"sim-{action_type}",
                        "type": action_type,
                        "params": params,
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [{"id": rule_id, "effect": "allow", "type": action_type, "constraints": {}}],
                    },
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert payload["matched_rule_id"] == rule_id
        assert payload["dry_run"] is True
    finally:
        app_main.engine = old_engine


@pytest.mark.parametrize(
    ("action_type", "params"),
    [
        ("shell.exec", {"command": "git status", "args": [], "cwd": "workspace/"}),
        ("email.delete", {"provider": "gmail", "message_id": "m-1", "mailbox": "INBOX"}),
        ("secrets.read", {"name": "OPENAI_API_KEY"}),
    ],
)
def test_execute_fails_closed_for_guarded_action_types_even_if_policy_allows(
    tmp_path: Path,
    action_type: str,
    params: dict[str, object],
) -> None:
    _write_allow_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    action_id = f"exec-{action_type}"
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": action_id,
                    "type": action_type,
                    "params": params,
                    "meta": {"actor": "exec"},
                },
            )
        assert response.status_code == 400
        detail = response.json()["detail"]
        assert detail["code"] == "EXECUTION_ERROR"
        assert detail["message"] == f"unsupported action type: {action_type}"
        assert _latest_audit_status(app_main.engine, action_id) == "execution_error"
    finally:
        app_main.engine = old_engine


def test_execute_guarded_needs_approval_does_not_create_approvals(tmp_path: Path) -> None:
    tmp_path.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "email_delete_needs_approval",
                        "effect": "needs_approval",
                        "type": "email.delete",
                        "constraints": {"allow_providers": ["gmail"], "allow_mailboxes": ["INBOX"]},
                    }
                ],
            }
        )
    )
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "exec-email-needs-approval",
                    "type": "email.delete",
                    "params": {"provider": "gmail", "message_id": "m-1", "mailbox": "INBOX"},
                    "meta": {"actor": "exec"},
                },
            )
        assert response.status_code == 400
        assert app_main.engine.audit.approval_counts()["total"] == 0
    finally:
        app_main.engine = old_engine


@pytest.mark.parametrize("mode", ["monitor", "disabled"])
def test_execute_guarded_types_fail_closed_in_monitor_and_disabled(monkeypatch, tmp_path: Path, mode: str) -> None:
    monkeypatch.setenv("SUVRA_MODE", mode)
    _write_allow_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": f"exec-shell-{mode}",
                    "type": "shell.exec",
                    "params": {"command": "git status", "args": [], "cwd": "workspace/"},
                    "meta": {"actor": "mode"},
                },
            )
        assert response.status_code == 400
        detail = response.json()["detail"]
        assert detail["code"] == "EXECUTION_ERROR"
        assert detail["message"] == "unsupported action type: shell.exec"
    finally:
        app_main.engine = old_engine


def test_email_delete_constraints_allow_providers_and_allow_mailboxes(tmp_path: Path) -> None:
    _write_allow_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            allowed = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-email-constraint-ok",
                        "type": "email.delete",
                        "params": {"provider": "GMAIL", "message_id": "m-1", "mailbox": "inbox"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "email-constraint",
                                "effect": "allow",
                                "type": "email.delete",
                                "constraints": {
                                    "allow_providers": ["gmail"],
                                    "allow_mailboxes": ["INBOX"],
                                },
                            }
                        ],
                    },
                },
            )
            denied = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-email-constraint-bad-provider",
                        "type": "email.delete",
                        "params": {"provider": "outlook", "message_id": "m-2", "mailbox": "inbox"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "email-constraint",
                                "effect": "allow",
                                "type": "email.delete",
                                "constraints": {
                                    "allow_providers": ["gmail"],
                                    "allow_mailboxes": ["INBOX"],
                                },
                            }
                        ],
                    },
                },
            )
        assert allowed.status_code == 200
        assert allowed.json()["decision"] == "allow"
        assert denied.status_code == 200
        assert denied.json()["decision"] == "deny"
    finally:
        app_main.engine = old_engine


def test_secrets_read_constraints_allow_names(tmp_path: Path) -> None:
    _write_allow_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            allowed = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-secrets-constraint-ok",
                        "type": "secrets.read",
                        "params": {"name": "OPENAI_API_KEY"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "allow-key",
                                "effect": "allow",
                                "type": "secrets.read",
                                "constraints": {"allow_names": ["OPENAI_API_KEY"]},
                            }
                        ],
                    },
                },
            )
            denied = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-secrets-constraint-bad-name",
                        "type": "secrets.read",
                        "params": {"name": "OTHER_KEY"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "allow-key",
                                "effect": "allow",
                                "type": "secrets.read",
                                "constraints": {"allow_names": ["OPENAI_API_KEY"]},
                            }
                        ],
                    },
                },
            )
        assert allowed.status_code == 200
        assert allowed.json()["decision"] == "allow"
        assert denied.status_code == 200
        assert denied.json()["decision"] == "deny"
    finally:
        app_main.engine = old_engine
