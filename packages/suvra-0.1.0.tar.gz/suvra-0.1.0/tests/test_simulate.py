from __future__ import annotations

import json
import re
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    },
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def test_simulate_api_write_returns_allow(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-write-1",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/sim-api.txt", "content": "hello"},
                        "meta": {"actor": "sim"},
                        "dry_run": False,
                    }
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert payload["dry_run"] is True
        assert payload["matched_rule_id"] == "allow_workspace_writes"
        assert payload["checks"]
        assert all(check["ok"] for check in payload["checks"])
    finally:
        app_main.engine = old_engine


def test_simulate_type_match_with_constraint_failure_returns_checks(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-constraint-fail-1",
                        "type": "fs.write_file",
                        "params": {"path": "data/out.txt", "content": "small"},
                        "meta": {"actor": "sim"},
                    }
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "deny"
        assert payload["matched_rule_id"] == "allow_workspace_writes"
        checks = {row["name"]: row for row in payload["checks"]}
        assert checks["path_prefix"]["ok"] is False
        assert "expected prefix workspace/" in checks["path_prefix"]["detail"]
        assert checks["max_bytes"]["ok"] is True
    finally:
        app_main.engine = old_engine


def test_simulate_default_deny_when_no_rule_for_action_type(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-default-deny-1",
                        "type": "unknown.action",
                        "params": {},
                        "meta": {"actor": "sim"},
                    }
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "deny"
        assert payload["matched_rule_id"] is None
        assert "no rule for action type" in payload["reasons"]
    finally:
        app_main.engine = old_engine


def test_simulate_api_delete_needs_approval_without_creating_approvals(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-delete-1",
                        "type": "fs.delete_file",
                        "params": {"path": "workspace/sim-api.txt"},
                        "meta": {"actor": "sim"},
                    }
                },
            )
        assert response.status_code == 200
        assert response.json()["decision"] == "needs_approval"
        assert app_main.engine.audit.approval_counts()["total"] == 0
    finally:
        app_main.engine = old_engine


def test_simulate_api_policy_override_can_deny_write(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-write-override-deny",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/sim-api.txt", "content": "hello"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "deny_writes",
                                "effect": "deny",
                                "type": "fs.write_file",
                                "constraints": {"path_prefix": "workspace/"},
                            }
                        ],
                    },
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "deny"
        assert payload["matched_rule_id"] == "deny_writes"
    finally:
        app_main.engine = old_engine


def test_simulate_api_policy_override_can_allow_delete_without_approvals(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-api-delete-override-allow",
                        "type": "fs.delete_file",
                        "params": {"path": "workspace/sim-api.txt"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "allow_delete",
                                "effect": "allow",
                                "type": "fs.delete_file",
                                "constraints": {"path_prefix": "workspace/"},
                            }
                        ],
                    },
                },
            )
        assert response.status_code == 200
        assert response.json()["decision"] == "allow"
        assert app_main.engine.audit.approval_counts()["total"] == 0
    finally:
        app_main.engine = old_engine


def test_dashboard_simulate_get_returns_200(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/simulate")
        assert response.status_code == 200
        assert "Policy Simulator" in response.text
        assert '"path": "workspace/hello.txt"' in response.text
        assert '"url": "https://example.com/"' in response.text
        assert '"timeout_seconds": 5' in response.text
        assert '"type": "shell.exec"' in response.text
        assert '"type": "email.delete"' in response.text
        assert '"type": "secrets.read"' in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_simulate_presets_render_valid_json_and_write_simulates_allow(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            page = client.get("/dashboard/simulate")
            assert page.status_code == 200
            match = re.search(r"const examples = (\{.*?\});", page.text, flags=re.S)
            assert match is not None
            examples = json.loads(match.group(1))
            write_example = examples["write_ok"]
            json.dumps(write_example)

            sim = client.post(
                "/simulate",
                json={"action": write_example},
            )
            assert sim.status_code == 200
            assert sim.json()["decision"] == "allow"
    finally:
        app_main.engine = old_engine


def test_dashboard_simulate_post_renders_decision(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/dashboard/simulate",
                data={
                    "action_json": json.dumps(
                        {
                            "action_id": "sim-ui-write-1",
                            "type": "fs.write_file",
                            "params": {"path": "workspace/ui.txt", "content": "ok"},
                            "meta": {"actor": "ui"},
                        }
                    ),
                    "policy_override_json": "",
                    "csrf": "1",
                },
            )
        assert response.status_code == 200
        assert "Decision" in response.text
        assert "allow" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_simulate_post_with_override_changes_decision(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/dashboard/simulate",
                data={
                    "action_json": json.dumps(
                        {
                            "action_id": "sim-ui-write-override",
                            "type": "fs.write_file",
                            "params": {"path": "workspace/ui.txt", "content": "ok"},
                            "meta": {"actor": "ui"},
                        }
                    ),
                    "policy_override_json": json.dumps(
                        {
                            "defaults": {"mode": "deny"},
                            "rules": [
                                {
                                    "id": "deny_all_writes",
                                    "effect": "deny",
                                    "type": "fs.write_file",
                                    "constraints": {"path_prefix": "workspace/"},
                                }
                            ],
                        }
                    ),
                    "csrf": "1",
                },
            )
        assert response.status_code == 200
        assert "deny" in response.text
        assert "deny_all_writes" in response.text
    finally:
        app_main.engine = old_engine


def test_simulate_http_request_defaults_method_to_get_when_missing(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-http-default-method",
                        "type": "http.request",
                        "params": {"url": "https://example.com"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "allow_http_get_example",
                                "effect": "allow",
                                "type": "http.request",
                                "constraints": {
                                    "method": "GET",
                                    "allow_domains": ["example.com"],
                                },
                            }
                        ],
                    },
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert payload["matched_rule_id"] == "allow_http_get_example"
        assert "method was not provided; defaulted to GET for simulation" in payload["reasons"]
    finally:
        app_main.engine = old_engine


def test_simulate_http_request_warns_when_timeout_missing_and_policy_requires_it(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/simulate",
                json={
                    "action": {
                        "action_id": "sim-http-timeout-warning",
                        "type": "http.request",
                        "params": {"url": "https://example.com"},
                        "meta": {"actor": "sim"},
                    },
                    "policy_override": {
                        "defaults": {"mode": "deny"},
                        "rules": [
                            {
                                "id": "allow_http_get_with_timeout_policy",
                                "effect": "allow",
                                "type": "http.request",
                                "constraints": {
                                    "method": "GET",
                                    "allow_domains": ["example.com"],
                                    "timeout_seconds": 5,
                                },
                            }
                        ],
                    },
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert "timeout_seconds not provided; policy contains timeout_seconds constraint" in payload["reasons"]
    finally:
        app_main.engine = old_engine
