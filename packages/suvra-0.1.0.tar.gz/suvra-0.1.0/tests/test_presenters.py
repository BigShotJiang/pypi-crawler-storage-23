from __future__ import annotations

from suvra.web.presenters import event_view_model, parse_json_maybe


def test_event_view_model_write_file_summary_fields() -> None:
    row = {
        "event_id": 1,
        "action_id": "act-write-1",
        "actor": "agent",
        "action_type": "fs.write_file",
        "decision": "allow",
        "status": "executed",
        "created_at": "2026-02-15T00:00:00Z",
        "dry_run": 0,
        "result_summary": "{'status': 'executed', 'summary': 'wrote 12 bytes to /tmp/workspace/demo.txt'}",
        "rollback_payload": '{"type":"fs.write_file","path":"workspace/demo.txt","delete_on_rollback":true}',
        "rollback_available": 1,
    }

    vm = event_view_model(row)
    assert vm["title"] == "Write file"
    assert vm["target"] == "workspace/demo.txt"
    assert vm["risk_level"] == "medium"
    assert "wrote 12 bytes" in vm["summary"]
    assert vm["result_summary_short"]


def test_event_view_model_delete_file_summary_fields() -> None:
    row = {
        "event_id": 2,
        "action_id": "act-del-1",
        "actor": "agent",
        "action_type": "fs.delete_file",
        "decision": "needs_approval",
        "status": "awaiting_approval",
        "created_at": "2026-02-15T00:00:00Z",
        "dry_run": 0,
        "result_summary": "delete request queued",
        "rollback_payload": '{"type":"fs.delete_file","path":"workspace/old.txt","restore_mode":420}',
        "rollback_available": 1,
    }

    vm = event_view_model(row)
    assert vm["title"] == "Delete file"
    assert vm["target"] == "workspace/old.txt"
    assert vm["risk_level"] == "high"
    assert vm["summary"]


def test_parse_json_maybe_handles_json_string() -> None:
    parsed = parse_json_maybe('{"type":"fs.write_file","path":"workspace/x.txt"}')
    assert parsed is not None
    assert parsed["path"] == "workspace/x.txt"
