from __future__ import annotations

from pathlib import Path

from suvra.integrations.openclaw import SuvraExecutor
from suvra.sdk.guard import Guard


def test_openclaw_adapter_execute_and_validate() -> None:
    guard = Guard(policy="policy.yaml", db_path="audit.db")
    executor = SuvraExecutor(guard)

    execute_result = executor.execute(
        action_type="fs.write_file",
        params={"path": "workspace/demo/oc_adapter.txt", "content": "openclaw adapter"},
    )
    assert execute_result["decision"] == "allow"
    assert execute_result["status"] == "executed"
    assert Path("workspace/demo/oc_adapter.txt").exists()

    validate_result = executor.validate(
        action_type="fs.write_file",
        params={"path": "workspace/demo/oc_adapter.txt", "content": "openclaw adapter"},
    )
    assert validate_result["decision"] == "allow"

