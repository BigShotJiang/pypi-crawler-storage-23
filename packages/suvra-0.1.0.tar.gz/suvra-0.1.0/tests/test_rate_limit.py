from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        '{"defaults":{"mode":"deny"},"rules":[{"id":"allow_workspace_writes","effect":"allow","type":"fs.write_file","constraints":{"path_prefix":"workspace/","max_bytes":1024}}]}'
    )


def test_actions_rate_limit_hits_429(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_AUTH_TOKEN", raising=False)
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    app_main.app.state.rate_limit_store.clear()
    try:
        with TestClient(app_main.app) as client:
            final = None
            for idx in range(61):
                final = client.post(
                    "/actions/validate",
                    json={
                        "action_id": f"rl-{idx}",
                        "type": "fs.write_file",
                        "params": {"path": "workspace/rl.txt", "content": "x"},
                        "meta": {"actor": "rl"},
                    },
                )
            assert final is not None
            assert final.status_code == 429
            assert final.json() == {"code": "RATE_LIMITED", "message": "Too many requests"}
    finally:
        app_main.engine = old_engine


def test_health_is_never_rate_limited(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SUVRA_AUTH_TOKEN", raising=False)
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    app_main.app.state.rate_limit_store.clear()
    try:
        with TestClient(app_main.app) as client:
            for _ in range(200):
                resp = client.get("/health")
                assert resp.status_code == 200
    finally:
        app_main.engine = old_engine
