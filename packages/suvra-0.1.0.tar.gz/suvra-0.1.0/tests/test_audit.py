from __future__ import annotations

import sqlite3

import pytest

from suvra.core.audit import AuditLog


def test_auditlog_creates_parent_dir_for_db_path(tmp_path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    try:
        AuditLog(db_path="data/test_audit.db")
    except sqlite3.OperationalError as exc:
        pytest.fail(f"AuditLog should create parent directory before sqlite connect: {exc}")

