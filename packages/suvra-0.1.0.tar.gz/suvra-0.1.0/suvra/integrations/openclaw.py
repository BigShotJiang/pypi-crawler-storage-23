from __future__ import annotations

from typing import Any
from uuid import uuid4


class SuvraExecutor:
    def __init__(self, guard: Any, default_actor: str = "openclaw"):
        self.guard = guard
        self.default_actor = default_actor

    def execute(
        self,
        action_type: str,
        params: dict[str, Any],
        action_id: str | None = None,
        actor: str | None = None,
        dry_run: bool = False,
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        action = {
            "action_id": action_id or f"oc-{uuid4()}",
            "type": action_type,
            "params": params,
            "meta": {"actor": actor or self.default_actor, **(meta or {})},
            "dry_run": dry_run,
        }
        return self.guard.execute(action)

    def validate(
        self,
        action_type: str,
        params: dict[str, Any],
        action_id: str | None = None,
        actor: str | None = None,
        dry_run: bool = True,
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        action = {
            "action_id": action_id or f"oc-{uuid4()}",
            "type": action_type,
            "params": params,
            "meta": {"actor": actor or self.default_actor, **(meta or {})},
            "dry_run": dry_run,
        }
        return self.guard.validate(action)

