from __future__ import annotations

import inspect
from functools import wraps
from typing import Any, Callable
from uuid import uuid4


def guarded_tool(guard: Any, action_type: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        signature = inspect.signature(func)

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            bound = signature.bind(*args, **kwargs)
            bound.apply_defaults()
            params = dict(bound.arguments)
            action = {
                "action_id": str(uuid4()),
                "type": action_type,
                "params": params,
                "meta": {"actor": "python_tool"},
                "dry_run": False,
            }
            decision = guard.execute(action)
            if decision.get("decision") != "allow":
                raise RuntimeError(f"guard denied tool execution: {decision}")
            return func(*args, **kwargs)

        return wrapper

    return decorator

