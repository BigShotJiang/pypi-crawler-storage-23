from __future__ import annotations

import ast
import json
import re
from typing import Any
from urllib.parse import urlparse

from suvra.core.config import workspace_prefix


def _truncate(value: Any, limit: int = 140) -> str:
    text = "" if value is None else str(value)
    if len(text) <= limit:
        return text
    return f"{text[: limit - 3]}..."


def parse_json_maybe(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None
        return parsed if isinstance(parsed, dict) else None
    return None


def _parse_mapping_maybe(value: Any) -> dict[str, Any] | None:
    parsed = parse_json_maybe(value)
    if parsed is not None:
        return parsed
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            literal = ast.literal_eval(raw)
        except (ValueError, SyntaxError):
            return None
        return literal if isinstance(literal, dict) else None
    return None


def _extract_path_from_summary_text(summary: str) -> str | None:
    match = re.search(r"(?:to|delete)\s+([^\s]+)$", summary.strip())
    if not match:
        return None
    return match.group(1)


def infer_target(action_type: str, params: dict[str, Any] | None, rollback_payload: dict[str, Any] | None) -> str:
    params = params or {}
    rollback_payload = rollback_payload or {}

    if action_type in {"fs.write_file", "fs.delete_file"}:
        return _truncate(rollback_payload.get("path") or params.get("path") or f"{workspace_prefix()}*")

    if action_type == "http.request":
        url = str(params.get("url") or "")
        host = urlparse(url).hostname if url else None
        return _truncate(host or "external host")

    if action_type == "rollback":
        return _truncate(
            params.get("action_id")
            or rollback_payload.get("action_id")
            or rollback_payload.get("path")
            or "previous action"
        )

    return _truncate(str(params.get("path") or params.get("url") or "n/a"))


def infer_risk(action_type: str, decision: str) -> str:
    base = {
        "fs.write_file": "medium",
        "fs.delete_file": "high",
        "http.request": "medium",
        "rollback": "low",
    }.get(action_type, "medium")

    if decision in {"deny", "needs_approval"}:
        return "high" if base != "low" else "medium"
    return base


def _title_for_action(action_type: str, summary_obj: dict[str, Any] | None) -> str:
    if action_type == "fs.write_file":
        return "Write file"
    if action_type == "fs.delete_file":
        return "Delete file"
    if action_type == "http.request":
        method = "GET"
        if summary_obj and isinstance(summary_obj.get("summary"), str):
            match = re.match(r"\s*([A-Z]+)\s+", summary_obj["summary"])
            if match:
                method = match.group(1)
        return f"HTTP {method}"
    if action_type == "rollback":
        return "Rollback"
    return action_type.replace(".", " ").title()


def _extract_bytes(summary_obj: dict[str, Any] | None) -> str | None:
    if not summary_obj:
        return None
    summary = str(summary_obj.get("summary") or "")
    match = re.search(r"(\d+)\s+bytes", summary)
    if not match:
        return None
    return match.group(1)


def _build_key_fields(
    action_type: str,
    event_row: dict[str, Any],
    target: str,
    summary_obj: dict[str, Any] | None,
    rollback_payload: dict[str, Any] | None,
) -> list[tuple[str, str]]:
    rollback_payload = rollback_payload or {}
    fields: list[tuple[str, str]] = []

    if action_type == "fs.write_file":
        fields.append(("Path", target))
        bytes_value = _extract_bytes(summary_obj)
        if bytes_value:
            fields.append(("Bytes", bytes_value))
        elif rollback_payload.get("restore_content") is not None:
            fields.append(("Bytes", str(len(str(rollback_payload.get("restore_content")).encode("utf-8")))))
        fields.append(("Dry run", "yes" if event_row.get("dry_run") else "no"))
    elif action_type == "fs.delete_file":
        fields.append(("Path", target))
        fields.append(("Dry run", "yes" if event_row.get("dry_run") else "no"))
    elif action_type == "http.request":
        summary_text = str((summary_obj or {}).get("summary") or "")
        method = "GET" if "GET " in summary_text or action_type == "http.request" else "n/a"
        fields.append(("Method", method))
        fields.append(("Target", target))
        timeout_value = (summary_obj or {}).get("timeout")
        if timeout_value is not None:
            fields.append(("Timeout", _truncate(timeout_value)))
    elif action_type == "rollback":
        fields.append(("Action", _truncate(event_row.get("action_id") or "-")))
        if rollback_payload.get("path"):
            fields.append(("Path", _truncate(rollback_payload.get("path"))))
        if rollback_payload.get("restore_mode") is not None:
            fields.append(("Mode", _truncate(rollback_payload.get("restore_mode"))))
    else:
        fields.append(("Action", _truncate(event_row.get("action_id") or "-")))

    for key in ("path", "restore_mode", "delete_on_rollback"):
        if key in rollback_payload and all(label.lower() != key.replace("_", " ") for label, _ in fields):
            label = key.replace("_", " ").title()
            fields.append((label, _truncate(rollback_payload.get(key))))

    return [(label, _truncate(value)) for label, value in fields if str(value).strip()]


def event_view_model(event_row: dict[str, Any]) -> dict[str, Any]:
    action_type = str(event_row.get("action_type") or "unknown")
    decision = str(event_row.get("decision") or "")
    rollback_payload = parse_json_maybe(event_row.get("rollback_payload"))
    summary_obj = _parse_mapping_maybe(event_row.get("result_summary"))

    params = (summary_obj or {}).get("params") if isinstance((summary_obj or {}).get("params"), dict) else {}
    summary_text = str((summary_obj or {}).get("summary") or event_row.get("result_summary") or "")
    if action_type in {"fs.write_file", "fs.delete_file"} and "path" not in params:
        inferred_path = _extract_path_from_summary_text(summary_text)
        if inferred_path:
            params = {**params, "path": inferred_path}
    target = infer_target(action_type, params, rollback_payload)
    title = _title_for_action(action_type, summary_obj)

    raw_summary = summary_text
    summary = _truncate(raw_summary or f"{title} processed for {target}.")

    reasons_raw = (summary_obj or {}).get("reasons")
    reasons = [
        _truncate(reason)
        for reason in reasons_raw
        if isinstance(reason, str)
    ] if isinstance(reasons_raw, list) else []

    rollback_summary = "Rollback available" if bool(event_row.get("rollback_available") or rollback_payload) else "No rollback"
    if rollback_payload and rollback_payload.get("path"):
        rollback_summary = f"Rollback target: {rollback_payload.get('path')}"

    return {
        "id": event_row.get("event_id"),
        "action_id": _truncate(event_row.get("action_id") or "-"),
        "action_id_raw": str(event_row.get("action_id") or ""),
        "actor": _truncate(event_row.get("actor") or "unknown"),
        "action_type": action_type,
        "decision": decision,
        "status": str(event_row.get("status") or "unknown"),
        "created_at": str(event_row.get("created_at") or "-"),
        "title": title,
        "target": target,
        "summary": summary,
        "key_fields": _build_key_fields(action_type, event_row, target, summary_obj, rollback_payload),
        "reasons": reasons,
        "rollback_available": bool(event_row.get("rollback_available") or rollback_payload),
        "rollback_summary": _truncate(rollback_summary),
        "risk_level": infer_risk(action_type, decision),
        "result_summary_short": summary,
    }


def approval_view_model(approval_row: dict[str, Any]) -> dict[str, Any]:
    action_type = str(approval_row.get("action_type") or "unknown")
    status = str(approval_row.get("status") or "pending")
    action_payload = parse_json_maybe(approval_row.get("action_json")) or {}
    params = action_payload.get("params") if isinstance(action_payload.get("params"), dict) else {}
    target = infer_target(action_type, params, None)
    title = _title_for_action(action_type, None)

    summary = _truncate(f"{title} requested by {approval_row.get('actor') or 'unknown'}")
    risk_level = infer_risk(action_type, "needs_approval" if status == "pending" else "allow")

    key_fields = [
        ("Approval", _truncate(approval_row.get("approval_id") or "-")),
        ("Action ID", _truncate(approval_row.get("action_id") or "-")),
    ]
    if approval_row.get("decided_by"):
        key_fields.append(("Decided by", _truncate(approval_row.get("decided_by"))))
    if approval_row.get("note"):
        key_fields.append(("Note", _truncate(approval_row.get("note"))))

    return {
        "approval_id": _truncate(approval_row.get("approval_id") or "-"),
        "status": status,
        "actor": _truncate(approval_row.get("actor") or "unknown"),
        "action_type": action_type,
        "created_at": str(approval_row.get("created_at") or "-"),
        "title": title,
        "target": target,
        "summary": summary,
        "risk_level": risk_level,
        "key_fields": key_fields,
    }
