from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, urlencode

from fastapi import APIRouter, Query, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from suvra.core.config import get_workspace_dir, resolve_workspace_root, workspace_prefix
from suvra.core.engine import EnforcementEngine, SuvraError
from suvra.core.mode import get_suvra_mode
from suvra.core.policy import PolicyEngine
from suvra.web.presenters import approval_view_model, event_view_model

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
OPENCLAW_TEMPLATE_DIR = Path(__file__).resolve().parents[2] / "docs" / "policies" / "templates" / "openclaw"


def _sim_examples() -> dict[str, dict[str, object]]:
    prefix = workspace_prefix()
    return {
        "write_ok": {
            "action_id": "sim-write-1",
            "type": "fs.write_file",
            "params": {"path": f"{prefix}hello.txt", "content": "hello from simulator"},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
        "delete": {
            "action_id": "sim-delete-1",
            "type": "fs.delete_file",
            "params": {"path": f"{prefix}hello.txt"},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
        "http_ok": {
            "action_id": "sim-http-1",
            "type": "http.request",
            "params": {"method": "GET", "url": "https://example.com/", "timeout_seconds": 5},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
        "shell_exec": {
            "action_id": "sim-shell-1",
            "type": "shell.exec",
            "params": {"command": "git status", "args": [], "cwd": f"{prefix}"},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
        "email_delete": {
            "action_id": "sim-email-delete-1",
            "type": "email.delete",
            "params": {"provider": "gmail", "message_id": "abc123", "mailbox": "INBOX"},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
        "secrets_read": {
            "action_id": "sim-secrets-read-1",
            "type": "secrets.read",
            "params": {"name": "OPENAI_API_KEY", "purpose": "send request"},
            "meta": {"actor": "demo", "reason": "sim"},
            "dry_run": True,
        },
    }


def _format_json(value: object) -> str:
    return json.dumps(value, indent=2, sort_keys=True)


def _dashboard_mode() -> str:
    return get_suvra_mode()


def _openclaw_templates() -> list[dict[str, str]]:
    if not OPENCLAW_TEMPLATE_DIR.exists():
        return []
    rows: list[dict[str, str]] = []
    for path in sorted(OPENCLAW_TEMPLATE_DIR.glob("*.yaml")):
        rows.append({"name": path.stem, "path": str(path)})
    return rows


def create_dashboard_router(get_engine: Callable[[], EnforcementEngine]) -> APIRouter:
    router = APIRouter(tags=["dashboard"])
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

    @router.get("/dashboard")
    def dashboard_index(request: Request) -> object:
        engine = get_engine()
        counts = engine.audit.overview_counts()
        recent_events = [event_view_model(row) for row in engine.list_audit(limit=10)]
        auto_created_template = getattr(engine.policy_engine, "auto_created_template", None)
        onboarding_banner = None
        if auto_created_template == "local_sandbox":
            prefix = workspace_prefix()
            onboarding_banner = (
                "Policy created from template: local_sandbox. "
                f"Writes allowed only to {prefix}. Deletes require approval."
            )
        return templates.TemplateResponse(
            request,
            "index.html",
            {
                "counts": counts,
                "recent_events": recent_events,
                "onboarding_banner": onboarding_banner,
                "dashboard_mode": _dashboard_mode(),
                "active_tab": "overview",
            },
        )

    @router.get("/dashboard/policy")
    def dashboard_policy(request: Request) -> object:
        engine = get_engine()
        policy_path = engine.policy_engine.policy_path
        policy_exists = policy_path.exists()
        policy_text = policy_path.read_text() if policy_exists else "# policy file not found"
        modified_at = policy_path.stat().st_mtime if policy_exists else None
        modified_label = datetime.fromtimestamp(modified_at).isoformat(timespec="seconds") if modified_at else "N/A"
        policy_templates = PolicyEngine.available_templates()
        openclaw_templates = _openclaw_templates()
        current_workspace_dir = get_workspace_dir()
        current_workspace_root = resolve_workspace_root(engine.root)
        return templates.TemplateResponse(
            request,
            "policy.html",
            {
                "active_environment": getattr(engine, "active_environment", "dev"),
                "policy_path": str(policy_path),
                "modified_at": modified_label,
                "workspace_dir": current_workspace_dir,
                "workspace_prefix": workspace_prefix(current_workspace_dir),
                "workspace_root": str(current_workspace_root),
                "policy_content": policy_text,
                "templates": policy_templates,
                "openclaw_templates": openclaw_templates,
                "dashboard_mode": _dashboard_mode(),
                "active_tab": "policy",
            },
        )

    @router.get("/dashboard/simulate")
    def dashboard_simulate_get(request: Request) -> object:
        examples = _sim_examples()
        default_action = _format_json(examples["write_ok"])
        return templates.TemplateResponse(
            request,
            "simulate.html",
            {
                "active_tab": "simulate",
                "action_json": default_action,
                "policy_override_json": "",
                "result": None,
                "error_message": None,
                "workspace_prefix": workspace_prefix(),
                "examples_json": _format_json(examples),
                "dashboard_mode": _dashboard_mode(),
            },
        )

    @router.post("/dashboard/simulate")
    async def dashboard_simulate_post(request: Request) -> object:
        engine = get_engine()
        body = (await request.body()).decode("utf-8")
        data = parse_qs(body)
        action_json = (data.get("action_json") or [""])[0].strip()
        policy_override_json = (data.get("policy_override_json") or [""])[0].strip()

        error_message: str | None = None
        result: dict[str, object] | None = None
        try:
            action = json.loads(action_json)
            if not isinstance(action, dict):
                raise ValueError("Action JSON must be an object.")
            policy_override = None
            if policy_override_json:
                policy_override = json.loads(policy_override_json)
                if not isinstance(policy_override, dict):
                    raise ValueError("Policy override JSON must be an object.")
            result = engine.simulate(action=action, policy_override=policy_override)
        except json.JSONDecodeError as exc:
            error_message = f"Invalid JSON: {exc.msg}"
        except (ValueError, SuvraError) as exc:
            error_message = str(exc)

        examples = _sim_examples()
        return templates.TemplateResponse(
            request,
            "simulate.html",
            {
                "active_tab": "simulate",
                "action_json": action_json or _format_json(examples["write_ok"]),
                "policy_override_json": policy_override_json,
                "result": result,
                "error_message": error_message,
                "workspace_prefix": workspace_prefix(),
                "examples_json": _format_json(examples),
                "dashboard_mode": _dashboard_mode(),
            },
        )

    @router.get("/dashboard/approvals")
    def dashboard_approvals(
        request: Request,
        status: str = Query(default="pending"),
        limit: int = Query(default=100, ge=1, le=500),
        q: str = Query(default=""),
        msg: str | None = None,
        error: str | None = None,
    ) -> object:
        engine = get_engine()
        normalized_status = status if status in {"pending", "approved", "denied", "all"} else "pending"
        filter_status = None if normalized_status == "all" else normalized_status
        normalized_q = q.strip()
        approvals = engine.audit.list_approvals(status=filter_status, limit=limit, q=normalized_q)
        counts = engine.audit.approval_counts()
        view_models = [approval_view_model(row) for row in approvals]
        return templates.TemplateResponse(
            request,
            "approvals.html",
            {
                "approvals": view_models,
                "selected_status": normalized_status,
                "current_status": normalized_status,
                "counts": counts,
                "limit": limit,
                "current_query": normalized_q,
                "result_count": len(view_models),
                "message": msg,
                "error_message": error,
                "dashboard_mode": _dashboard_mode(),
                "active_tab": "approvals",
            },
        )

    @router.post("/dashboard/approvals/{approval_id}/approve")
    async def dashboard_approve(
        request: Request,
        approval_id: str,
    ) -> RedirectResponse:
        engine = get_engine()
        body = (await request.body()).decode("utf-8")
        data = parse_qs(body)
        decided_by = (data.get("decided_by") or [""])[0].strip()
        note = (data.get("note") or [""])[0].strip()
        status = (data.get("status") or [request.query_params.get("status", "pending")])[0]
        limit = (data.get("limit") or [request.query_params.get("limit", "100")])[0]
        q = (data.get("q") or [request.query_params.get("q", "")])[0]
        if not decided_by:
            query = urlencode(
                {"status": status, "limit": limit, "q": q, "msg": "error", "error": "decided_by is required"}
            )
            return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)
        try:
            engine.approve(approval_id=approval_id, decided_by=decided_by, note=note or None)
            query = urlencode({"status": status, "limit": limit, "q": q, "msg": "approved"})
        except SuvraError as exc:
            query = urlencode({"status": status, "limit": limit, "q": q, "msg": "error", "error": exc.message})
        return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)

    @router.post("/dashboard/approvals/{approval_id}/deny")
    async def dashboard_deny(
        request: Request,
        approval_id: str,
    ) -> RedirectResponse:
        engine = get_engine()
        body = (await request.body()).decode("utf-8")
        data = parse_qs(body)
        decided_by = (data.get("decided_by") or [""])[0].strip()
        note = (data.get("note") or [""])[0].strip()
        status = (data.get("status") or [request.query_params.get("status", "pending")])[0]
        limit = (data.get("limit") or [request.query_params.get("limit", "100")])[0]
        q = (data.get("q") or [request.query_params.get("q", "")])[0]
        if not decided_by:
            query = urlencode(
                {"status": status, "limit": limit, "q": q, "msg": "error", "error": "decided_by is required"}
            )
            return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)
        try:
            engine.deny(approval_id=approval_id, decided_by=decided_by, note=note or None)
            query = urlencode({"status": status, "limit": limit, "q": q, "msg": "denied"})
        except SuvraError as exc:
            query = urlencode({"status": status, "limit": limit, "q": q, "msg": "error", "error": exc.message})
        return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)

    @router.post("/dashboard/approvals/{approval_id}/approve_execute")
    async def dashboard_approve_execute(request: Request, approval_id: str) -> RedirectResponse:
        engine = get_engine()
        body = (await request.body()).decode("utf-8")
        data = parse_qs(body)
        decided_by = (data.get("decided_by") or [""])[0].strip()
        note = (data.get("note") or [""])[0].strip()
        status = (data.get("status") or [request.query_params.get("status", "pending")])[0]
        limit = (data.get("limit") or [request.query_params.get("limit", "100")])[0]
        q = (data.get("q") or [request.query_params.get("q", "")])[0]
        if not decided_by:
            query = urlencode(
                {"status": status, "limit": limit, "q": q, "msg": "error", "error": "decided_by is required"}
            )
            return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)

        try:
            engine.approve(approval_id=approval_id, decided_by=decided_by, note=note or None)
            action = engine.audit.get_approval_action(approval_id)
            if action is None:
                query = urlencode(
                    {"status": status, "limit": limit, "q": q, "msg": "error", "error": "stored action not found"}
                )
                return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)
            meta = dict(action.get("meta") or {})
            meta["approval_id"] = approval_id
            action["meta"] = meta
            action["dry_run"] = False
            result = engine.execute(action)
            if result.get("decision") == "allow" and result.get("status") == "executed":
                query = urlencode({"status": status, "limit": limit, "q": q, "msg": "executed"})
            else:
                query = urlencode(
                    {
                        "status": status,
                        "limit": limit,
                        "q": q,
                        "msg": "error",
                        "error": str(result.get("message") or result.get("status") or "execute failed"),
                    }
                )
        except SuvraError as exc:
            query = urlencode({"status": status, "limit": limit, "q": q, "msg": "error", "error": exc.message})

        return RedirectResponse(url=f"/dashboard/approvals?{query}", status_code=303)

    @router.get("/dashboard/audit")
    def dashboard_audit(
        request: Request,
        actor: str | None = None,
        action_type: str | None = None,
        decision: str | None = None,
        status: str | None = None,
        q: str = Query(default=""),
        page: int = Query(default=1, ge=1),
        page_size: int = Query(default=50, ge=1, le=200),
        msg: str | None = None,
        error: str | None = None,
    ) -> object:
        engine = get_engine()
        normalized_q = q.strip()
        count_filters = {
            "actor": actor,
            "action_type": action_type,
            "decision": decision,
            "status": status,
            "q": normalized_q,
        }
        total_count = engine.audit.count_events(count_filters)
        total_pages = max(1, (total_count + page_size - 1) // page_size)
        page = min(page, total_pages)
        offset = (page - 1) * page_size
        filters = {
            **count_filters,
            "limit": page_size,
            "offset": offset,
        }
        events = [event_view_model(row) for row in engine.list_audit(**filters)]
        base_params = {
            "actor": actor or "",
            "action_type": action_type or "",
            "decision": decision or "",
            "status": status or "",
            "q": normalized_q,
            "page_size": page_size,
        }
        prev_params = {**base_params, "page": max(1, page - 1)}
        next_params = {**base_params, "page": min(total_pages, page + 1)}
        export_params = {**base_params, "limit": 5000}
        return templates.TemplateResponse(
            request,
            "audit.html",
            {
                "events": events,
                "filters": {
                    "actor": actor,
                    "action_type": action_type,
                    "decision": decision,
                    "status": status,
                    "q": normalized_q,
                    "page": page,
                    "page_size": page_size,
                },
                "pagination": {
                    "total_count": total_count,
                    "total_pages": total_pages,
                    "page": page,
                    "page_size": page_size,
                    "has_prev": page > 1,
                    "has_next": page < total_pages,
                    "prev_url": "/dashboard/audit?" + urlencode(prev_params),
                    "next_url": "/dashboard/audit?" + urlencode(next_params),
                },
                "export_csv_url": "/audit.csv?" + urlencode(export_params),
                "message": msg,
                "error_message": error,
                "dashboard_mode": _dashboard_mode(),
                "active_tab": "audit",
            },
        )

    @router.post("/dashboard/rollback/{action_id}")
    async def dashboard_rollback(request: Request, action_id: str) -> RedirectResponse:
        del request
        engine = get_engine()
        try:
            result = engine.rollback(action_id)
            if result.get("status") == "rolled_back":
                query = urlencode({"msg": "rolled_back"})
            else:
                query = urlencode(
                    {"msg": "error", "error": str(result.get("summary") or result.get("status") or "rollback failed")}
                )
        except SuvraError as exc:
            query = urlencode({"msg": "error", "error": exc.message})
        return RedirectResponse(url=f"/dashboard/audit?{query}", status_code=303)

    return router
