from __future__ import annotations

import json
import sqlite3
from datetime import datetime, UTC
from pathlib import Path
from typing import Any


class AuditLog:
    def __init__(self, db_path: str | Path = "data/audit.db") -> None:
        self.db_path = Path(db_path)
        parent = self.db_path.parent
        if parent != Path("."):
            parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS audit_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT,
                    action_id TEXT,
                    actor TEXT,
                    action_type TEXT,
                    decision TEXT,
                    dry_run INTEGER,
                    params_hash TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    status TEXT,
                    result_summary TEXT,
                    rollback_payload TEXT,
                    rollback_available INTEGER
                )
                """
            )
            columns = {
                row[1]
                for row in conn.execute("PRAGMA table_info(audit_events)").fetchall()
            }
            if "rollback_payload" not in columns:
                conn.execute("ALTER TABLE audit_events ADD COLUMN rollback_payload TEXT")
            if "request_id" not in columns:
                conn.execute("ALTER TABLE audit_events ADD COLUMN request_id TEXT")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS approvals (
                    approval_id TEXT PRIMARY KEY,
                    action_id TEXT,
                    actor TEXT,
                    action_type TEXT,
                    action_json TEXT,
                    params_hash TEXT,
                    status TEXT,
                    created_at TEXT,
                    decided_at TEXT,
                    decided_by TEXT,
                    note TEXT
                )
                """
            )
            approval_columns = {
                row[1]
                for row in conn.execute("PRAGMA table_info(approvals)").fetchall()
            }
            if "action_json" not in approval_columns:
                conn.execute("ALTER TABLE approvals ADD COLUMN action_json TEXT")

    def log_event(self, event: dict[str, Any]) -> int:
        rollback_payload = event.get("rollback_payload")
        if isinstance(rollback_payload, (dict, list)):
            rollback_payload_value = json.dumps(rollback_payload, sort_keys=True, separators=(",", ":"))
        elif rollback_payload is None:
            rollback_payload_value = None
        else:
            rollback_payload_value = str(rollback_payload)

        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO audit_events (
                    request_id, action_id, actor, action_type, decision, dry_run, params_hash,
                    status, result_summary, rollback_payload, rollback_available
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.get("request_id"),
                    event.get("action_id"),
                    event.get("actor"),
                    event.get("action_type"),
                    event.get("decision"),
                    1 if event.get("dry_run") else 0,
                    event.get("params_hash"),
                    event.get("status"),
                    event.get("result_summary"),
                    rollback_payload_value,
                    1 if event.get("rollback_available") else 0,
                ),
            )
            return int(cur.lastrowid)

    def query_events(self, filters: dict[str, Any]) -> list[dict[str, Any]]:
        clauses, values = self._build_event_where(filters)
        query = "SELECT * FROM audit_events"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY event_id DESC"
        limit = int(filters.get("limit", 100))
        offset = int(filters.get("offset", 0))
        query += " LIMIT ?"
        values.append(limit)
        if offset > 0:
            query += " OFFSET ?"
            values.append(offset)

        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, values).fetchall()
            return [dict(row) for row in rows]

    def count_events(self, filters: dict[str, Any]) -> int:
        clauses, values = self._build_event_where(filters)
        query = "SELECT COUNT(*) FROM audit_events"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        with self._connect() as conn:
            row = conn.execute(query, values).fetchone()
            return int(row[0]) if row else 0

    def _build_event_where(self, filters: dict[str, Any]) -> tuple[list[str], list[Any]]:
        clauses: list[str] = []
        values: list[Any] = []

        for key in ["actor", "action_type", "decision", "status"]:
            if filters.get(key):
                clauses.append(f"{key} = ?")
                values.append(filters[key])

        q = str(filters.get("q", "")).strip().lower()
        if q:
            pattern = f"%{q}%"
            clauses.append(
                "("
                "LOWER(COALESCE(actor, '')) LIKE ? OR "
                "LOWER(COALESCE(action_type, '')) LIKE ? OR "
                "LOWER(COALESCE(action_id, '')) LIKE ? OR "
                "LOWER(COALESCE(decision, '')) LIKE ? OR "
                "LOWER(COALESCE(status, '')) LIKE ? OR "
                "LOWER(COALESCE(result_summary, '')) LIKE ? OR "
                "LOWER(COALESCE(rollback_payload, '')) LIKE ?"
                ")"
            )
            values.extend([pattern, pattern, pattern, pattern, pattern, pattern, pattern])

        return clauses, values

    def list_approvals(self, status: str | None = None, limit: int = 100, q: str = "") -> list[dict[str, Any]]:
        query = "SELECT * FROM approvals"
        values: list[Any] = []
        clauses: list[str] = []
        if status:
            clauses.append("status = ?")
            values.append(status)
        normalized_q = q.strip().lower()
        if normalized_q:
            pattern = f"%{normalized_q}%"
            clauses.append(
                "(LOWER(actor) LIKE ? OR LOWER(action_type) LIKE ? OR LOWER(approval_id) LIKE ? OR LOWER(COALESCE(action_json, '')) LIKE ?)"
            )
            values.extend([pattern, pattern, pattern, pattern])
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY created_at DESC LIMIT ?"
        values.append(limit)
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, values).fetchall()
            return [dict(row) for row in rows]

    def approval_counts(self) -> dict[str, int]:
        counts = {"pending": 0, "approved": 0, "denied": 0, "total": 0}
        with self._connect() as conn:
            for status, count in conn.execute(
                "SELECT status, COUNT(*) FROM approvals GROUP BY status"
            ).fetchall():
                key = str(status)
                if key in counts:
                    counts[key] = int(count)
            row = conn.execute("SELECT COUNT(*) FROM approvals").fetchone()
            counts["total"] = int(row[0]) if row else 0
        return counts

    def overview_counts(self) -> dict[str, int]:
        with self._connect() as conn:
            row = conn.execute("SELECT COUNT(*) FROM audit_events").fetchone()
            total_events = int(row[0]) if row else 0

            row = conn.execute("SELECT COUNT(*) FROM approvals WHERE status = 'pending'").fetchone()
            pending_approvals = int(row[0]) if row else 0

            decision_counts = {"allow": 0, "deny": 0, "needs_approval": 0}
            for decision, count in conn.execute(
                """
                SELECT decision, COUNT(*)
                FROM audit_events
                WHERE decision IN ('allow', 'deny', 'needs_approval')
                GROUP BY decision
                """
            ).fetchall():
                decision_counts[str(decision)] = int(count)

            row = conn.execute(
                "SELECT COUNT(*) FROM audit_events WHERE action_type = 'rollback' AND status = 'rolled_back'"
            ).fetchone()
            rollbacks = int(row[0]) if row else 0

        return {
            "total_events": total_events,
            "pending_approvals": pending_approvals,
            "allow": decision_counts["allow"],
            "deny": decision_counts["deny"],
            "needs_approval": decision_counts["needs_approval"],
            "rollbacks": rollbacks,
        }

    def create_approval(self, approval: dict[str, Any]) -> dict[str, Any]:
        created_at = approval.get("created_at") or datetime.now(UTC).isoformat()
        payload = {
            "approval_id": approval["approval_id"],
            "action_id": approval.get("action_id"),
            "actor": approval.get("actor"),
            "action_type": approval.get("action_type"),
            "action_json": approval.get("action_json"),
            "params_hash": approval.get("params_hash"),
            "status": approval.get("status", "pending"),
            "created_at": created_at,
            "decided_at": approval.get("decided_at"),
            "decided_by": approval.get("decided_by"),
            "note": approval.get("note"),
        }

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO approvals (
                    approval_id, action_id, actor, action_type, action_json, params_hash, status,
                    created_at, decided_at, decided_by, note
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    payload["approval_id"],
                    payload["action_id"],
                    payload["actor"],
                    payload["action_type"],
                    payload["action_json"],
                    payload["params_hash"],
                    payload["status"],
                    payload["created_at"],
                    payload["decided_at"],
                    payload["decided_by"],
                    payload["note"],
                ),
            )
        return payload

    def get_approval(self, approval_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM approvals WHERE approval_id = ?",
                (approval_id,),
            ).fetchone()
            return dict(row) if row else None

    def get_approval_action(self, approval_id: str) -> dict[str, Any] | None:
        approval = self.get_approval(approval_id)
        if not approval:
            return None
        raw = approval.get("action_json")
        if raw is None:
            return None
        try:
            payload = json.loads(str(raw))
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None

    def find_pending_approval(self, actor: str, action_type: str, params_hash: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                """
                SELECT * FROM approvals
                WHERE actor = ? AND action_type = ? AND params_hash = ? AND status = 'pending'
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (actor, action_type, params_hash),
            ).fetchone()
            return dict(row) if row else None

    def find_latest_approval(
        self,
        actor: str,
        action_type: str,
        params_hash: str,
        status: str,
    ) -> dict[str, Any] | None:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                """
                SELECT * FROM approvals
                WHERE actor = ? AND action_type = ? AND params_hash = ? AND status = ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (actor, action_type, params_hash, status),
            ).fetchone()
            return dict(row) if row else None

    def decide_approval(
        self,
        approval_id: str,
        status: str,
        decided_by: str,
        note: str | None = None,
    ) -> dict[str, Any] | None:
        decided_at = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                """
                UPDATE approvals
                SET status = ?, decided_at = ?, decided_by = ?, note = ?
                WHERE approval_id = ?
                """,
                (status, decided_at, decided_by, note, approval_id),
            )
            if cur.rowcount == 0:
                return None

        return self.get_approval(approval_id)
