from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any
from uuid import uuid4
from urllib.parse import urlparse

from suvra.core.action_utils import is_dry_run, resolve_dry_run
from suvra.core.audit import AuditLog
from suvra.core.config import workspace_prefix
from suvra.core.executors.fs import FileSystemExecutor
from suvra.core.executors.http import HttpExecutor
from suvra.core.mode import get_suvra_mode
from suvra.core.policy import Decision, PolicyEngine
from suvra.core.request_context import get_request_id


class SuvraError(Exception):
    def __init__(self, status_code: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message


class EnforcementEngine:
    UNSUPPORTED_EXECUTE_ACTION_TYPES = {"shell.exec", "email.delete", "secrets.read"}

    def __init__(
        self,
        root: str | Path = ".",
        policy_path: str | Path | None = None,
        db_path: str | Path | None = None,
    ) -> None:
        self.root = Path(root)
        db_value = db_path if db_path is not None else os.getenv("SUVRA_DB_PATH")
        resolved_policy_path = self._resolve_policy_path(policy_path)
        resolved_db_path = self._resolve_path(db_value, default_name="data/audit.db")
        self.active_environment = (os.getenv("SUVRA_ENV", "dev").strip() or "dev")
        self.active_policy_path = resolved_policy_path
        self.policy_engine = PolicyEngine(resolved_policy_path)
        self.audit = AuditLog(resolved_db_path)
        self.fs_executor = FileSystemExecutor(self.root)
        self.http_executor = HttpExecutor()
        self._rollback_store: dict[str, dict[str, Any]] = {}
        self._logger = logging.getLogger(__name__)

    def _resolve_path(self, value: str | Path | None, default_name: str) -> Path:
        if value is None:
            return self.root / default_name
        path = Path(value)
        if path.is_absolute():
            return path
        return self.root / path

    def _resolve_policy_path(self, policy_path: str | Path | None) -> Path:
        explicit = policy_path if policy_path is not None else os.getenv("SUVRA_POLICY_PATH")
        if explicit is not None and str(explicit).strip():
            return self._resolve_path(explicit, default_name="policy.yaml")

        env = os.getenv("SUVRA_ENV", "dev").strip() or "dev"
        env_candidate = self.root / "policies" / env / "policy.yaml"
        fallback = self.root / "policy.yaml"
        if env_candidate.exists() or not fallback.exists():
            return env_candidate
        return fallback

    @staticmethod
    def _canonical_hash_payload(action: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": action.get("type"),
            "params": action.get("params", {}) or {},
        }

    def _params_hash(self, action: dict[str, Any]) -> str:
        payload = json.dumps(self._canonical_hash_payload(action), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _normalize_action(self, action: dict[str, Any]) -> dict[str, Any]:
        normalized = dict(action)
        meta = dict(normalized.get("meta") or {})

        if "actor" in normalized and "actor" not in meta:
            meta["actor"] = normalized.get("actor")
            self._logger.warning("deprecated_field_used: actor")
        if "approval_id" in normalized and "approval_id" not in meta:
            meta["approval_id"] = normalized.get("approval_id")
            self._logger.warning("deprecated_field_used: approval_id")

        if "actor" not in meta:
            meta["actor"] = "unknown"

        normalized["meta"] = meta
        return normalized

    @staticmethod
    def _actor(action: dict[str, Any]) -> str:
        meta = action.get("meta") or {}
        return str(meta.get("actor") or "unknown")

    @staticmethod
    def _request_id() -> str | None:
        return get_request_id()

    @staticmethod
    def _derive_target(action: dict[str, Any]) -> str:
        action_type = str(action.get("type") or "")
        params = action.get("params") or {}
        if action_type in {"fs.write_file", "fs.delete_file"}:
            return str(params.get("path") or f"{workspace_prefix()}*")
        if action_type == "http.request":
            url = str(params.get("url") or "")
            if not url:
                return "external host"
            return str(urlparse(url).hostname or url)
        if action_type == "rollback":
            return str(params.get("action_id") or "previous action")
        return str(params.get("path") or params.get("url") or "n/a")

    def _evaluate_policy(self, action: dict[str, Any], policy_override: dict[str, Any] | None = None) -> Decision:
        if policy_override is None:
            return self.policy_engine.evaluate(action)
        override_engine = PolicyEngine.from_policy_data(policy_override)
        return override_engine.evaluate(action)

    def _policy_requires_timeout(self, action_type: str, policy_override: dict[str, Any] | None) -> bool:
        policy = policy_override if policy_override is not None else self.policy_engine.policy
        rules = policy.get("rules", []) if isinstance(policy, dict) else []
        for rule in rules:
            if not isinstance(rule, dict):
                continue
            if rule.get("type") != action_type:
                continue
            constraints = rule.get("constraints", {})
            if isinstance(constraints, dict) and "timeout_seconds" in constraints:
                return True
        return False

    def _normalize_simulation_action(
        self,
        action: dict[str, Any],
        policy_override: dict[str, Any] | None,
    ) -> tuple[dict[str, Any], list[str]]:
        normalized = dict(action)
        warnings: list[str] = []

        if str(normalized.get("type")) == "http.request":
            params = dict(normalized.get("params") or {})
            method = str(params.get("method") or "").strip()
            if not method:
                params["method"] = "GET"
                warnings.append("method was not provided; defaulted to GET for simulation")
            if "timeout_seconds" not in params and self._policy_requires_timeout("http.request", policy_override):
                warnings.append("timeout_seconds not provided; policy contains timeout_seconds constraint")
            normalized["params"] = params

        return normalized, warnings

    def simulate(self, action: dict[str, Any], policy_override: dict[str, Any] | None = None) -> dict[str, Any]:
        action = self._normalize_action(action)
        action, sim_warnings = self._normalize_simulation_action(action, policy_override)
        try:
            decision = self._evaluate_policy(action, policy_override=policy_override)
        except ValueError as exc:
            raise SuvraError(400, "VALIDATION_ERROR", str(exc)) from exc

        reasons = [*decision.reasons, *sim_warnings]
        result: dict[str, Any] = {
            "action_id": action.get("action_id"),
            "decision": decision.decision,
            "matched_rule_id": decision.rule_id,
            "reasons": reasons,
            "checks": decision.checks or [],
            "dry_run": True,
            "summary": {
                "actor": self._actor(action),
                "action_type": action.get("type"),
                "target": self._derive_target(action),
            },
        }
        if decision.decision == "deny":
            result["code"] = "POLICY_DENY"
            result["message"] = "Action denied by policy"
        elif decision.decision == "needs_approval":
            result["code"] = "POLICY_NEEDS_APPROVAL"
            result["message"] = "Action requires approval by policy"

        matched_rule = decision.rule_id or "none"
        reason_text = "; ".join(reasons)[:420]
        summary_text = f"matched rule {matched_rule}; {reason_text}".strip("; ")
        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": action.get("action_id"),
                "actor": self._actor(action),
                "action_type": "simulate",
                "decision": decision.decision,
                "dry_run": True,
                "params_hash": self._params_hash(action),
                "status": "simulated",
                "result_summary": summary_text[:500],
                "rollback_available": False,
            }
        )
        return result

    def validate(self, action: dict[str, Any]) -> dict[str, Any]:
        action = self._normalize_action(action)
        decision = self.policy_engine.evaluate(action)
        result = {
            "action_id": action.get("action_id"),
            "decision": decision.decision,
            "reasons": decision.reasons,
            "dry_run": True,
        }
        if decision.decision == "deny":
            result["code"] = "POLICY_DENY"
            result["message"] = "Action denied by policy"
        elif decision.decision == "needs_approval":
            result["code"] = "POLICY_NEEDS_APPROVAL"
            result["message"] = "Action requires approval by policy"

        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": action.get("action_id"),
                "actor": self._actor(action),
                "action_type": action.get("type"),
                "decision": decision.decision,
                "dry_run": True,
                "params_hash": self._params_hash(action),
                "status": "validated",
                "result_summary": "; ".join(decision.reasons),
                "rollback_available": False,
            }
        )
        return result

    def request_approval(self, action: dict[str, Any]) -> dict[str, Any]:
        action = self._normalize_action(action)
        params_hash = self._params_hash(action)
        actor = self._actor(action)
        action_type = action.get("type")

        existing_pending = self.audit.find_pending_approval(
            actor=actor,
            action_type=action_type,
            params_hash=params_hash,
        )
        if existing_pending:
            return {"approval_id": existing_pending["approval_id"], "status": existing_pending["status"]}

        approval_id = str(uuid4())
        approval_action = {
            "action_id": action.get("action_id"),
            "type": action.get("type"),
            "params": action.get("params", {}),
            "meta": action.get("meta", {}),
            "dry_run": is_dry_run(action),
        }
        approval = self.audit.create_approval(
            {
                "approval_id": approval_id,
                "action_id": action.get("action_id"),
                "actor": actor,
                "action_type": action_type,
                "action_json": json.dumps(approval_action, sort_keys=True),
                "params_hash": params_hash,
                "status": "pending",
            }
        )
        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": action.get("action_id"),
                "actor": actor,
                "action_type": action_type,
                "decision": "needs_approval",
                "dry_run": True,
                "params_hash": params_hash,
                "status": "approval_requested",
                "result_summary": f"approval_id={approval_id}",
                "rollback_available": False,
            }
        )
        return {"approval_id": approval["approval_id"], "status": approval["status"]}

    def get_approval(self, approval_id: str) -> dict[str, Any]:
        approval = self.audit.get_approval(approval_id)
        if not approval:
            raise SuvraError(404, "VALIDATION_ERROR", f"approval_id '{approval_id}' not found")
        return approval

    def approve(self, approval_id: str, decided_by: str, note: str | None = None) -> dict[str, Any]:
        approval = self.audit.decide_approval(
            approval_id=approval_id,
            status="approved",
            decided_by=decided_by,
            note=note,
        )
        if not approval:
            raise SuvraError(404, "VALIDATION_ERROR", f"approval_id '{approval_id}' not found")

        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": approval.get("action_id"),
                "actor": approval.get("actor"),
                "action_type": approval.get("action_type"),
                "decision": "allow",
                "dry_run": True,
                "params_hash": approval.get("params_hash"),
                "status": "approved",
                "result_summary": f"approval_id={approval_id}; decided_by={decided_by}",
                "rollback_available": False,
            }
        )
        return approval

    def deny(self, approval_id: str, decided_by: str, note: str | None = None) -> dict[str, Any]:
        approval = self.audit.decide_approval(
            approval_id=approval_id,
            status="denied",
            decided_by=decided_by,
            note=note,
        )
        if not approval:
            raise SuvraError(404, "VALIDATION_ERROR", f"approval_id '{approval_id}' not found")

        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": approval.get("action_id"),
                "actor": approval.get("actor"),
                "action_type": approval.get("action_type"),
                "decision": "deny",
                "dry_run": True,
                "params_hash": approval.get("params_hash"),
                "status": "denied",
                "result_summary": f"approval_id={approval_id}; decided_by={decided_by}",
                "rollback_available": False,
            }
        )
        return approval

    def execute(self, action: dict[str, Any], dry_run: bool | None = None) -> dict[str, Any]:
        action = self._normalize_action(action)
        effective_dry_run = resolve_dry_run(action, override=dry_run)
        action_type = str(action.get("type") or "")
        if action_type in self.UNSUPPORTED_EXECUTE_ACTION_TYPES:
            message = f"unsupported action type: {action_type}"
            result = {
                "action_id": action.get("action_id"),
                "decision": "deny",
                "status": "execution_error",
                "dry_run": effective_dry_run,
                "code": "EXECUTION_ERROR",
                "message": message,
                "reasons": [message],
            }
            self._log_execute(action, effective_dry_run, result, rollback=None, result_summary=message)
            raise SuvraError(400, "EXECUTION_ERROR", message)

        mode = get_suvra_mode()
        if mode == "monitor":
            return self._execute_monitor(action, effective_dry_run)
        if mode == "disabled":
            return self._execute_disabled(action, effective_dry_run)

        decision = self.policy_engine.evaluate(action)
        if decision.decision == "deny":
            result = {
                "action_id": action.get("action_id"),
                "decision": "deny",
                "reasons": decision.reasons,
                "status": "blocked",
                "dry_run": effective_dry_run,
                "code": "POLICY_DENY",
                "message": "Action denied by policy",
            }
            self._log_execute(action, effective_dry_run, result, rollback=None)
            return result

        if decision.decision == "needs_approval":
            return self._execute_with_approval_gate(action, effective_dry_run, decision)

        return self._execute_allowed(action, effective_dry_run, decision)

    def _run_executor(
        self,
        action: dict[str, Any],
        dry_run: bool,
        constraints: dict[str, Any] | None,
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        action_type = action.get("type")
        params = action.get("params", {})

        try:
            if action_type == "fs.write_file":
                exec_result = self.fs_executor.execute_write_file(params, constraints, dry_run=dry_run)
            elif action_type == "fs.delete_file":
                exec_result = self.fs_executor.execute_delete_file(params, constraints, dry_run=dry_run)
            elif action_type == "http.request":
                exec_result = self.http_executor.execute_request(params, constraints, dry_run=dry_run)
            else:
                raise SuvraError(400, "EXECUTION_ERROR", f"unsupported action type: {action_type}")
        except SuvraError:
            raise
        except ValueError as exc:
            raise SuvraError(400, "EXECUTION_ERROR", str(exc)) from exc

        rollback = exec_result.get("rollback")
        if rollback and not dry_run:
            self._rollback_store[str(action.get("action_id"))] = rollback
        return exec_result, rollback

    def _execute_allowed(self, action: dict[str, Any], dry_run: bool, decision: Decision) -> dict[str, Any]:
        exec_result, rollback = self._run_executor(action, dry_run, decision.constraints or {})

        result = {
            "action_id": action.get("action_id"),
            "decision": "allow",
            "status": exec_result.get("status", "executed"),
            "dry_run": dry_run,
            "result": exec_result,
            "reasons": decision.reasons,
        }
        self._log_execute(action, dry_run, result, rollback=rollback)
        return result

    def _execute_monitor(self, action: dict[str, Any], dry_run: bool) -> dict[str, Any]:
        decision = self.policy_engine.evaluate(action)
        exec_result, rollback = self._run_executor(action, dry_run, constraints={})
        compact_reason = decision.reasons[0] if decision.reasons else "none"
        summary = (
            f"policy_decision={decision.decision}; "
            f"matched_rule_id={decision.rule_id or 'none'}; "
            f"reason={compact_reason}"
        )[:500]
        result = {
            "action_id": action.get("action_id"),
            "decision": "monitor",
            "status": exec_result.get("status", "executed"),
            "dry_run": dry_run,
            "result": exec_result,
            "policy_decision": decision.decision,
            "matched_rule_id": decision.rule_id,
            "reasons": decision.reasons,
            "checks": decision.checks or [],
        }
        self._log_execute(action, dry_run, result, rollback=rollback, result_summary=summary)
        return result

    def _execute_disabled(self, action: dict[str, Any], dry_run: bool) -> dict[str, Any]:
        exec_result, rollback = self._run_executor(action, dry_run, constraints={})
        result = {
            "action_id": action.get("action_id"),
            "decision": "disabled",
            "status": exec_result.get("status", "executed"),
            "dry_run": dry_run,
            "result": exec_result,
            "reasons": ["enforcement disabled"],
        }
        self._log_execute(action, dry_run, result, rollback=rollback, result_summary="enforcement disabled")
        return result

    def _execute_with_approval_gate(
        self,
        action: dict[str, Any],
        dry_run: bool,
        decision: Decision,
    ) -> dict[str, Any]:
        if dry_run:
            result = {
                "action_id": action.get("action_id"),
                "decision": "needs_approval",
                "reasons": decision.reasons,
                "status": "awaiting_approval",
                "dry_run": True,
                "code": "POLICY_NEEDS_APPROVAL",
                "message": "Action would require approval before execution",
            }
            self._log_execute(action, dry_run, result, rollback=None)
            return result

        meta = action.get("meta") or {}
        approval_id = meta.get("approval_id")

        if approval_id:
            approval = self.audit.get_approval(str(approval_id))
            if approval:
                if not self._approval_matches(action, approval):
                    raise SuvraError(
                        403,
                        "APPROVAL_MISMATCH",
                        "approval does not match actor/action_type/params_hash",
                    )
                if approval.get("status") == "approved":
                    return self._execute_allowed(action, dry_run, decision)

        actor = self._actor(action)
        action_type = str(action.get("type"))
        params_hash = self._params_hash(action)
        pending_approval = self.audit.find_pending_approval(
            actor=actor,
            action_type=action_type,
            params_hash=params_hash,
        )
        if pending_approval:
            result = {
                "action_id": action.get("action_id"),
                "decision": "needs_approval",
                "reasons": decision.reasons,
                "status": "awaiting_approval",
                "dry_run": dry_run,
                "approval_id": pending_approval["approval_id"],
                "code": "APPROVAL_PENDING",
                "message": "Approval required before execution",
            }
            self._log_execute(action, dry_run, result, rollback=None)
            return result

        approved_approval = self.audit.find_latest_approval(
            actor=actor,
            action_type=action_type,
            params_hash=params_hash,
            status="approved",
        )
        if approved_approval:
            result = {
                "action_id": action.get("action_id"),
                "decision": "needs_approval",
                "reasons": [*decision.reasons, "provide meta.approval_id to execute with approved request"],
                "status": "awaiting_approval",
                "dry_run": dry_run,
                "approved_approval_id": approved_approval["approval_id"],
                "code": "APPROVAL_PENDING",
                "message": "Approval required before execution",
            }
            self._log_execute(action, dry_run, result, rollback=None)
            return result

        auto_approval = self.request_approval(action)
        result = {
            "action_id": action.get("action_id"),
            "decision": "needs_approval",
            "reasons": decision.reasons,
            "status": "awaiting_approval",
            "dry_run": dry_run,
            "approval_id": auto_approval["approval_id"],
            "code": "APPROVAL_PENDING",
            "message": "Approval required before execution",
        }
        self._log_execute(action, dry_run, result, rollback=None)
        return result

    def _approval_matches(self, action: dict[str, Any], approval: dict[str, Any]) -> bool:
        return (
            approval.get("actor") == self._actor(action)
            and approval.get("action_type") == action.get("type")
            and approval.get("params_hash") == self._params_hash(action)
        )

    def rollback(self, action_id: str, dry_run: bool = False) -> dict[str, Any]:
        payload = self._rollback_store.get(action_id)
        if not payload:
            result = {
                "action_id": action_id,
                "status": "not_found",
                "summary": "no rollback payload available",
                "dry_run": dry_run,
            }
            self.audit.log_event(
                {
                    "request_id": self._request_id(),
                    "action_id": action_id,
                    "actor": "system",
                    "action_type": "rollback",
                    "decision": "deny",
                    "dry_run": dry_run,
                    "params_hash": "",
                    "status": "not_found",
                    "result_summary": result["summary"],
                    "rollback_available": False,
                }
            )
            return result

        if payload.get("type") == "fs.write_file":
            rollback_fn = self.fs_executor.rollback_write_file
        elif payload.get("type") == "fs.delete_file":
            rollback_fn = self.fs_executor.rollback_delete_file
        else:
            rollback_fn = None

        if rollback_fn is None:
            rollback_result = {"status": "rollback_failed", "summary": "unsupported rollback payload"}
        else:
            try:
                rollback_result = rollback_fn(payload, dry_run=dry_run)
            except (ValueError, OSError) as exc:
                rollback_result = {"status": "rollback_failed", "summary": str(exc)}

        if not dry_run and rollback_result.get("status") == "rolled_back":
            self._rollback_store.pop(action_id, None)

        result = {"action_id": action_id, "dry_run": dry_run, **rollback_result}
        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": action_id,
                "actor": "system",
                "action_type": "rollback",
                "decision": "allow" if rollback_result.get("status") != "rollback_failed" else "deny",
                "dry_run": dry_run,
                "params_hash": "",
                "status": rollback_result.get("status"),
                "result_summary": rollback_result.get("summary"),
                "rollback_available": False,
            }
        )
        return result

    def list_audit(self, **filters: Any) -> list[dict[str, Any]]:
        return self.audit.query_events(filters)

    def _log_execute(
        self,
        action: dict[str, Any],
        dry_run: bool,
        result: dict[str, Any],
        rollback: dict[str, Any] | None,
        result_summary: str | None = None,
    ) -> None:
        summary = result_summary
        if summary is None:
            summary = str(result.get("result", result.get("reasons", "")))[:500]
        self.audit.log_event(
            {
                "request_id": self._request_id(),
                "action_id": action.get("action_id"),
                "actor": self._actor(action),
                "action_type": action.get("type"),
                "decision": result.get("decision", "deny"),
                "dry_run": dry_run,
                "params_hash": self._params_hash(action),
                "status": result.get("status", "unknown"),
                "result_summary": summary,
                "rollback_payload": rollback,
                "rollback_available": rollback is not None,
            }
        )
