from __future__ import annotations

import os

_VALID_MODES = {"strict", "monitor", "disabled"}


def get_suvra_mode() -> str:
    mode = (os.getenv("SUVRA_MODE", "strict") or "strict").strip().lower()
    if mode in _VALID_MODES:
        return mode
    return "strict"
