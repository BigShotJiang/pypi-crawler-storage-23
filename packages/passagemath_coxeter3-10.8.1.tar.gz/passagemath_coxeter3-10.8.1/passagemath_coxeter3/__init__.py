# sage_setup: distribution = sagemath-coxeter3

from sage.all__sagemath_coxeter3 import *
