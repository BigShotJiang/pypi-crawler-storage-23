# sage_setup: distribution = sagemath-coxeter3
# delvewheel: patch
