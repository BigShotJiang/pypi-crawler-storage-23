# sage_setup: distribution = sagemath-coxeter3
