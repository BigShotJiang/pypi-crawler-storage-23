"""Tests for the aurora-governor integration bridge.

governance module is always available: real unified_rns_system if installed,
in-tree mock (tests/governance_mock/) otherwise. conftest.py handles injection.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

# governance is always available: real package if installed, in-tree mock otherwise.
# conftest.py handles injection — no local path manipulation needed here.
import governance  # noqa: F401

from aurora_lens.govern.governor_bridge import AuroraGovernorBridge, _GOVERNOR_AVAILABLE
from aurora_lens.govern.decision import GovernanceDecision, InterventionAction
from aurora_lens.govern.policy import DEFAULT_STRICT, DEFAULT_MODERATE, InterventionPolicy, PolicyRule
from aurora_lens.verify.flags import Flag, FlagType
from aurora_lens.pef.state import PEFState
from aurora_lens.pef.span import Span
from aurora_lens.adapters.base import LLMAdapter, AdapterResponse
from aurora_lens.interpret.base import ExtractionBackend
from aurora_lens.interpret.schema import ExtractedClaim, ExtractionResult
from aurora_lens.config import LensConfig
from aurora_lens.lens import Lens

from governance.attestation import verify_governed_output


# ── Helpers ─────────────────────────────────────────────────────────

class MockAdapter(LLMAdapter):
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self._index = 0

    async def generate(self, messages: list[dict[str, str]], **kwargs) -> AdapterResponse:
        text = self._responses[min(self._index, len(self._responses) - 1)]
        self._index += 1
        return AdapterResponse(text=text, model="mock")


class MockBackend(ExtractionBackend):
    def __init__(self, claims_sequence: list[list[ExtractedClaim]]):
        self._sequence = list(claims_sequence)
        self._index = 0

    async def extract(self, text, pef):
        claims = self._sequence[min(self._index, len(self._sequence) - 1)]
        self._index += 1
        return ExtractionResult(claims=claims)


def _make_flags(types_and_severities: list[tuple[FlagType, str]]) -> list[Flag]:
    return [
        Flag(
            flag_type=ft,
            entity_name="Test",
            claim=f"Test {ft.name}",
            evidence="test evidence",
            severity=sev,
        )
        for ft, sev in types_and_severities
    ]


# ── Bridge Construction Tests ───────────────────────────────────────

class TestBridgeConstruction:

    def test_creates_without_audit(self):
        bridge = AuroraGovernorBridge()
        assert bridge._ledger is None
        assert bridge._secret_key is None

    def test_creates_with_audit(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))
        assert bridge._ledger is not None
        assert bridge.ledger_stats is not None

    def test_creates_with_secret_key(self):
        bridge = AuroraGovernorBridge(secret_key=b"test-key-123")
        assert bridge._secret_key == b"test-key-123"

    def test_creates_with_constraints(self):
        bridge = AuroraGovernorBridge(
            constraints={"forbidden_actions": ["danger"]}
        )
        assert bridge._constraints == {"forbidden_actions": ["danger"]}

    def test_kernel_stats_accessible(self):
        bridge = AuroraGovernorBridge()
        stats = bridge.kernel_stats
        assert "turn_index" in stats
        assert stats["turn_index"] == 0

    def test_verify_ledger_no_ledger(self):
        bridge = AuroraGovernorBridge()
        assert bridge.verify_ledger() is True


# ── Decision Tests ──────────────────────────────────────────────────

class TestGovernorDecide:

    @pytest.mark.asyncio
    async def test_no_flags_passes(self):
        bridge = AuroraGovernorBridge()
        pef = PEFState()
        decision = await bridge.decide([], "Clean response.", pef)
        assert decision.action == InterventionAction.PASS

    @pytest.mark.asyncio
    async def test_contradiction_error_hard_stop(self):
        bridge = AuroraGovernorBridge()
        pef = PEFState()
        flags = _make_flags([(FlagType.CONTRADICTED_FACT, "error")])
        decision = await bridge.decide(flags, "Bad response.", pef)
        assert decision.action == InterventionAction.HARD_STOP
        assert decision.cid is not None

    @pytest.mark.asyncio
    async def test_hallucinated_attribute_soft_correct(self):
        bridge = AuroraGovernorBridge()
        pef = PEFState()
        flags = _make_flags([(FlagType.HALLUCINATED_ATTRIBUTE, "warning")])
        decision = await bridge.decide(flags, "Dubious response.", pef)
        assert decision.action == InterventionAction.SOFT_CORRECT
        assert decision.governance_note is not None

    @pytest.mark.asyncio
    async def test_decision_carries_cid(self):
        bridge = AuroraGovernorBridge()
        pef = PEFState()
        flags = _make_flags([(FlagType.TIME_SMEAR, "warning")])
        decision = await bridge.decide(flags, "Response.", pef)
        assert decision.cid is not None
        assert decision.cid.startswith("cid:")

    @pytest.mark.asyncio
    async def test_decision_carries_policy_name(self):
        bridge = AuroraGovernorBridge(policy=DEFAULT_MODERATE)
        pef = PEFState()
        flags = _make_flags([(FlagType.CONTRADICTED_FACT, "error")])
        decision = await bridge.decide(flags, "Bad.", pef)
        assert decision.policy == "moderate"

    @pytest.mark.asyncio
    async def test_kernel_escalation(self):
        """Kernel with forbidden_actions can escalate SOFT_CORRECT → HARD_STOP."""
        bridge = AuroraGovernorBridge(
            constraints={"forbidden_actions": ["evaluate_output"]}
        )
        pef = PEFState()
        flags = _make_flags([(FlagType.HALLUCINATED_ATTRIBUTE, "warning")])
        decision = await bridge.decide(flags, "Response.", pef)
        # Kernel REFUSE → HARD_STOP (escalated from SOFT_CORRECT)
        assert decision.action == InterventionAction.HARD_STOP


# ── Intervention Tests ──────────────────────────────────────────────

class TestGovernorIntervene:

    @pytest.mark.asyncio
    async def test_hard_stop_blocks(self):
        bridge = AuroraGovernorBridge()
        decision = GovernanceDecision(
            action=InterventionAction.HARD_STOP,
            flags=[],
            rationale="test block",
        )
        adapter = MockAdapter(["should not be called"])
        result = await bridge.intervene(decision, adapter, "test", "context")
        assert "can't help" in result.lower()

    @pytest.mark.asyncio
    async def test_soft_correct_keeps_original(self):
        bridge = AuroraGovernorBridge()
        decision = GovernanceDecision(
            action=InterventionAction.SOFT_CORRECT,
            flags=[],
            rationale="minor",
            original_response="Original text.",
        )
        adapter = MockAdapter(["should not be called"])
        result = await bridge.intervene(decision, adapter, "test", "context")
        assert result == "Original text."

    @pytest.mark.asyncio
    async def test_force_revise_uses_refuse_template_no_adapter_call(self):
        """FORCE_REVISE uses refuse template — no LLM retry."""
        bridge = AuroraGovernorBridge()
        decision = GovernanceDecision(
            action=InterventionAction.FORCE_REVISE,
            flags=_make_flags([(FlagType.HALLUCINATED_ENTITY, "warning")]),
            rationale="hallucinated entity",
            original_response="Bob has a cat.",
        )
        adapter = MockAdapter(["should not be called"])
        result = await bridge.intervene(decision, adapter, "input", "context")
        assert "context" in result.lower()
        assert adapter._index == 0


# ── Forensic Ledger Tests ───────────────────────────────────────────

class TestForensicLedger:

    def test_log_decision_writes_afl(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        decision = GovernanceDecision(
            action=InterventionAction.HARD_STOP,
            flags=_make_flags([(FlagType.CONTRADICTED_FACT, "error")]),
            rationale="test hard stop",
            policy="strict",
            original_response="Bad.",
            corrected_response="Blocked.",
        )
        bridge.log_decision(decision, turn=1)

        # Read ledger
        entries = audit_file.read_text().strip().split("\n")
        assert len(entries) == 1

        envelope = json.loads(entries[0])
        assert envelope["v"] == 1
        assert envelope["kind"] == "aurora.event"
        assert envelope["op"] == "HARD_STOP"
        assert "hash" in envelope
        assert "prev" in envelope
        assert "cid" in envelope
        assert envelope["payload"]["data"]["action"] == "HARD_STOP"
        assert envelope["payload"]["data"]["flags"][0]["type"] == "CONTRADICTED_FACT"

    @pytest.mark.asyncio
    async def test_forensic_envelope_emitted_for_extraction_empty_contain(self, tmp_path):
        """EXTRACTION_EMPTY + CONTAIN emits forensic envelope via intervene."""
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file), policy=DEFAULT_MODERATE)

        flags = _make_flags([(FlagType.EXTRACTION_EMPTY, "error")])
        decision = await bridge.decide(flags, "some response", PEFState())
        assert decision.action == InterventionAction.CONTAIN

        decision.original_response = "some response"
        adapter = MockAdapter(["should not be called"])
        pef_context = "Emma HAS red book"
        result = await bridge.intervene(decision, adapter, "input", pef_context)

        assert "can't extract any admissible structure" in result

        entries = audit_file.read_text().strip().split("\n")
        assert len(entries) >= 1

        envelope_entries = [json.loads(e) for e in entries if json.loads(e).get("op") == "forensic_envelope"]
        assert len(envelope_entries) >= 1, f"Expected forensic_envelope op, got: {[json.loads(e).get('op') for e in entries]}"

        env = envelope_entries[-1]["payload"]["data"]
        assert env["type"] == "forensic_envelope"
        assert "trace_id" in env
        assert "timestamp" in env
        assert env["domain"] == "governance"
        assert env["attempted_action"] == "CONTAIN"
        assert "EXTRACTION_EMPTY" in env["failed_constraints"]
        assert "state_hash" in env

    @pytest.mark.asyncio
    async def test_forensic_envelope_emitted_for_hard_stop(self, tmp_path):
        """HARD_STOP (non-ADMIT) must emit forensic envelope."""
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        flags = _make_flags([(FlagType.CONTRADICTED_FACT, "error")])
        decision = await bridge.decide(flags, "dangerous", PEFState())
        assert decision.action == InterventionAction.HARD_STOP

        decision.original_response = "dangerous"
        adapter = MockAdapter(["should not be called"])
        result = await bridge.intervene(decision, adapter, "input", "pef ctx")

        assert "can't help" in result.lower()

        entries = audit_file.read_text().strip().split("\n")
        envelope_entries = [json.loads(e) for e in entries if json.loads(e).get("op") == "forensic_envelope"]
        assert len(envelope_entries) >= 1

        env = envelope_entries[-1]["payload"]["data"]
        assert env["attempted_action"] == "HARD_STOP"
        assert "CONTRADICTED_FACT" in env["failed_constraints"]

    def test_multiple_entries_hash_chain(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        for i in range(3):
            decision = GovernanceDecision(
                action=InterventionAction.SOFT_CORRECT,
                flags=_make_flags([(FlagType.TIME_SMEAR, "warning")]),
                rationale=f"entry {i}",
                policy="strict",
            )
            bridge.log_decision(decision, turn=i + 1)

        entries = audit_file.read_text().strip().split("\n")
        assert len(entries) == 3

        # Verify hash chain
        envelopes = [json.loads(line) for line in entries]
        assert envelopes[0]["prev"] == "h:null"
        assert envelopes[1]["prev"] == envelopes[0]["hash"]
        assert envelopes[2]["prev"] == envelopes[1]["hash"]

    def test_ledger_verify_passes(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        for i in range(5):
            decision = GovernanceDecision(
                action=InterventionAction.PASS,
                flags=[],
                rationale="clean",
                policy="strict",
            )
            bridge.log_decision(decision, turn=i + 1)

        assert bridge.verify_ledger() is True

    def test_ledger_tamper_detected(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        decision = GovernanceDecision(
            action=InterventionAction.HARD_STOP,
            flags=[],
            rationale="original",
            policy="strict",
        )
        bridge.log_decision(decision, turn=1)

        # Tamper with the ledger
        content = audit_file.read_text()
        tampered = content.replace('"original"', '"tampered"')
        audit_file.write_text(tampered)

        assert bridge.verify_ledger() is False

    def test_pef_continuity_in_entries(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        for i in range(3):
            decision = GovernanceDecision(
                action=InterventionAction.PASS,
                flags=[],
                rationale="clean",
            )
            bridge.log_decision(decision, turn=i + 1)

        entries = audit_file.read_text().strip().split("\n")
        for entry in entries:
            envelope = json.loads(entry)
            # Every entry has a PEF continuity value
            assert "pef" in envelope.get("ext", {})
            assert len(envelope["ext"]["pef"]) == 64  # SHA-256 hex


# ── Attestation Tests ───────────────────────────────────────────────

class TestAttestation:

    def test_attestation_produced(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(
            audit_path=str(audit_file),
            secret_key=b"test-secret-key",
        )

        decision = GovernanceDecision(
            action=InterventionAction.HARD_STOP,
            flags=[],
            rationale="blocked",
            policy="strict",
            original_response="Bad.",
            corrected_response="Blocked.",
        )
        bridge.log_decision(decision, turn=1)

        attested = bridge.last_attestation
        assert attested is not None
        assert attested.decision == "HARD_STOP"
        assert attested.content == "Blocked."
        assert attested.policy_cid == "policy:strict"
        assert attested.signature != ""

    def test_attestation_verifies(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        secret = b"verify-me-123"
        bridge = AuroraGovernorBridge(
            audit_path=str(audit_file),
            secret_key=secret,
        )

        decision = GovernanceDecision(
            action=InterventionAction.SOFT_CORRECT,
            flags=[],
            rationale="minor",
            policy="strict",
            corrected_response="Clean output.",
        )
        bridge.log_decision(decision, turn=1)

        # Verify via bridge method
        assert bridge.verify_attestation() is True

        # Verify via governance module directly
        attested = bridge.last_attestation
        assert verify_governed_output(attested, secret) is True

    def test_attestation_fails_wrong_key(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(
            audit_path=str(audit_file),
            secret_key=b"correct-key",
        )

        decision = GovernanceDecision(
            action=InterventionAction.HARD_STOP,
            flags=[],
            rationale="blocked",
            corrected_response="Blocked.",
        )
        bridge.log_decision(decision, turn=1)

        attested = bridge.last_attestation
        assert attested is not None
        # Wrong key → verification fails
        assert verify_governed_output(attested, b"wrong-key") is False

    def test_no_attestation_without_key(self, tmp_path):
        audit_file = tmp_path / "audit.jsonl"
        bridge = AuroraGovernorBridge(audit_path=str(audit_file))

        decision = GovernanceDecision(
            action=InterventionAction.PASS,
            flags=[],
            rationale="clean",
        )
        bridge.log_decision(decision, turn=1)
        assert bridge.last_attestation is None


# ── End-to-End with Lens ────────────────────────────────────────────

class TestLensWithGovernorBridge:

    @pytest.mark.asyncio
    async def test_full_pipeline_hard_stop(self, tmp_path):
        """Full pipeline: flag→kernel→HARD_STOP, forensic log, attestation."""
        audit_file = tmp_path / "audit.jsonl"
        secret = b"e2e-secret"

        adapter = MockAdapter(["Patient has myocardial infarction."])
        backend = MockBackend([
            # User input: establish negated fact
            [ExtractedClaim(
                subject="Patient", relation="HAS", obj="myocardial infarction",
                span=Span.PRESENT, negated=True, evidence="No ECG.",
            )],
            # LLM response: asserts MI → contradicts PEF
            [ExtractedClaim(
                subject="Patient", relation="HAS", obj="myocardial infarction",
                span=Span.PRESENT, negated=False, evidence="MI diagnosis.",
            )],
        ])
        bridge = AuroraGovernorBridge(
            audit_path=str(audit_file),
            secret_key=secret,
        )
        config = LensConfig(
            adapter=adapter,
            extraction_backend=backend,
            governance_bridge=bridge,
        )
        lens = Lens(config)

        result = await lens.process("Patient with no ECG. Diagnose.")

        # Governance: HARD_STOP
        assert result.action == InterventionAction.HARD_STOP
        assert "can't help" in result.response.lower()

        # Forensic ledger: hash-chained entry
        assert audit_file.exists()
        entries = audit_file.read_text().strip().split("\n")
        assert len(entries) >= 1
        envelope = json.loads(entries[-1])
        assert envelope["op"] == "HARD_STOP"
        assert "hash" in envelope

        # Attestation: signed
        assert bridge.last_attestation is not None
        assert bridge.verify_attestation() is True

        # Ledger: tamper-evident
        assert bridge.verify_ledger() is True

    @pytest.mark.asyncio
    async def test_full_pipeline_clean_pass(self, tmp_path):
        """Clean response → PASS, no attestation needed."""
        audit_file = tmp_path / "audit.jsonl"

        adapter = MockAdapter(["Emma has a red book."])
        backend = MockBackend([
            [ExtractedClaim(
                subject="Emma", relation="HAS", obj="red book",
                span=Span.PRESENT, negated=False, evidence="input",
            )],
            [ExtractedClaim(
                subject="Emma", relation="HAS", obj="red book",
                span=Span.PRESENT, negated=False, evidence="response",
            )],
        ])
        bridge = AuroraGovernorBridge(
            audit_path=str(audit_file),
            secret_key=b"key",
        )
        config = LensConfig(
            adapter=adapter,
            extraction_backend=backend,
            governance_bridge=bridge,
        )
        lens = Lens(config)

        result = await lens.process("Emma has a red book.")

        assert result.action == InterventionAction.PASS
        assert result.response == "Emma has a red book."


# ── J.1: Verify endpoint wired to ledger backend ─────────────────────

class TestVerifyEndpointLedgerBackend:
    """J.1: GET /v1/audit/verify works for the ledger (AuroraGovernorBridge) backend."""

    def test_verify_endpoint_ledger_backend(self, monkeypatch, tmp_path):
        """Verify endpoint returns verified:true when audit_backend is ledger."""
        try:
            from starlette.testclient import TestClient
        except ImportError:
            pytest.skip("Starlette not installed")

        audit_file = tmp_path / "audit.jsonl"

        monkeypatch.setattr(
            "aurora_lens.proxy.app._build_provider_adapters",
            lambda cfg: (MockAdapter(["Hello!"]), MockAdapter(["Hello!"])),
        )

        from aurora_lens.proxy.config import ProxyConfig
        from aurora_lens.proxy.app import create_app

        cfg = ProxyConfig.from_mapping({
            "upstream": {"provider": "openai", "api_key": "sk-test", "model": "gpt-4"},
            "governance": {
                "audit_log": str(audit_file),
                "audit_backend": "ledger",
            },
            "extraction": {"backend": "llm"},
        })
        app = create_app(cfg)
        client = TestClient(app)

        # Make a request to write ledger entries
        r = client.post(
            "/v1/chat/completions",
            json={"model": "gpt-4", "messages": [{"role": "user", "content": "Hello"}]},
        )
        assert r.status_code == 200

        # Verify endpoint should delegate to ForensicLedger.verify()
        r = client.get("/v1/audit/verify")
        assert r.status_code == 200
        data = r.json()
        assert data["verified"] is True
        assert data["chain_verified"] is True
        assert data["backend"] == "ledger"
        assert isinstance(data["entries"], int)

    def test_verify_endpoint_ledger_no_signing_key_required(self, monkeypatch, tmp_path):
        """Ledger verify does not require audit_signing_key (unlike JSONL path)."""
        try:
            from starlette.testclient import TestClient
        except ImportError:
            pytest.skip("Starlette not installed")

        audit_file = tmp_path / "audit.jsonl"

        monkeypatch.setattr(
            "aurora_lens.proxy.app._build_provider_adapters",
            lambda cfg: (MockAdapter(["ok"]), MockAdapter(["ok"])),
        )

        from aurora_lens.proxy.config import ProxyConfig
        from aurora_lens.proxy.app import create_app

        cfg = ProxyConfig.from_mapping({
            "upstream": {"provider": "openai", "api_key": "sk-test", "model": "gpt-4"},
            "governance": {
                "audit_log": str(audit_file),
                "audit_backend": "ledger",
                # No audit_signing_key — ledger verify should still work
            },
            "extraction": {"backend": "llm"},
        })
        app = create_app(cfg)
        client = TestClient(app)

        r = client.get("/v1/audit/verify")
        assert r.status_code == 200
        data = r.json()
        assert data["verified"] is True
        assert data["backend"] == "ledger"
