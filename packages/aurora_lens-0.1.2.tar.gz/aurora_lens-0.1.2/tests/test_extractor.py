"""Tests for the spaCy extraction backend."""

import asyncio

import pytest
import spacy

from aurora_lens.pef.span import Span
from aurora_lens.pef.state import PEFState
from aurora_lens.interpret.spacy_backend import SpacyBackend, detect_span
from aurora_lens.interpret.pef_updater import update_pef


@pytest.fixture(scope="module")
def nlp():
    return spacy.load("en_core_web_sm")


@pytest.fixture
def backend(nlp):
    return SpacyBackend(nlp=nlp)


@pytest.fixture
def pef():
    return PEFState()


# ── Span detection ───────────────────────────────────────────────────

class TestSpanDetection:
    def test_present_tense(self, nlp):
        doc = nlp("Emma has a red book.")
        assert detect_span(doc) == Span.PRESENT

    def test_past_tense(self, nlp):
        doc = nlp("Emma had a red book.")
        assert detect_span(doc) == Span.PAST

    def test_used_to_pattern(self, nlp):
        doc = nlp("Emma used to live in London.")
        assert detect_span(doc) == Span.PAST

    def test_present_signal_words(self, nlp):
        doc = nlp("Emma currently lives in Melbourne.")
        assert detect_span(doc) == Span.PRESENT


# ── Entity extraction ────────────────────────────────────────────────

class TestEntityExtraction:
    def test_named_entity(self, backend, pef):
        result = asyncio.run(backend.extract("Emma has a red book.", pef))
        # "Emma" should appear in entity mentions
        names_lower = [m.lower() for m in result.entity_mentions]
        assert "emma" in names_lower

    def test_multiple_entities(self, backend, pef):
        result = asyncio.run(backend.extract("Emma gave Lucy a book.", pef))
        names_lower = [m.lower() for m in result.entity_mentions]
        # At least one proper noun should be caught
        assert len(result.entity_mentions) >= 1


# ── Claim extraction ─────────────────────────────────────────────────

class TestClaimExtraction:
    def test_simple_has(self, backend, pef):
        result = asyncio.run(backend.extract("Emma has a red book.", pef))
        # Should extract at least one claim
        assert len(result.claims) >= 1
        has_claims = [c for c in result.claims if c.relation == "HAS"]
        assert len(has_claims) >= 1

    def test_negated_claim(self, backend, pef):
        result = asyncio.run(backend.extract("Emma does not have a key.", pef))
        negated = [c for c in result.claims if c.negated]
        # spaCy should detect the negation
        assert len(negated) >= 1 or len(result.claims) >= 1

    def test_claim_span_detection(self, backend, pef):
        result = asyncio.run(backend.extract("Emma had a blue car.", pef))
        assert result.span == Span.PAST
        for claim in result.claims:
            assert claim.span == Span.PAST


# ── PEF state updates ───────────────────────────────────────────────

class TestPEFUpdate:
    def test_entity_creation(self, backend, pef):
        result = asyncio.run(backend.extract("Emma has a red book.", pef))
        update_pef(result, pef)
        entity = pef.find_entity_by_name("Emma")
        # Entity should be created (either from claims or mentions)
        assert entity is not None or len(pef.entities) >= 0

    def test_relationship_creation(self, backend, pef):
        result = asyncio.run(backend.extract("Emma has a red book.", pef))
        update_pef(result, pef)
        # If claims were extracted, relationships should exist
        if result.claims:
            assert len(pef.relationships) >= 1

    def test_multiple_turns(self, backend, pef):
        r1 = asyncio.run(backend.extract("Emma has a red book.", pef))
        update_pef(r1, pef)
        pef.advance_turn()

        r2 = asyncio.run(backend.extract("Emma is a teacher.", pef))
        update_pef(r2, pef)

        emma = pef.find_entity_by_name("Emma")
        if emma:
            rels = pef.get_relationships_for_subject(emma.id)
            # Should accumulate relationships across turns
            assert len(rels) >= 1


# ── Ambiguous referent detection ──────────────────────────────────────

class TestAmbiguousReferentDetection:
    """Verify that possessive pronouns are flagged when 2+ PERSON entities
    appear in the same text — the PEF no-premature-binding axiom."""

    def test_her_sister_ambiguous_two_persons(self, backend, pef):
        # Classic case: "her" could be Emma's or Anna's sister
        result = asyncio.run(
            backend.extract("Emma told Anna her sister was overseas.", pef)
        )
        assert "her" in result.ambiguous_referents

    def test_full_emma_anna_question(self, backend, pef):
        # Mirrors the live proxy test case exactly
        result = asyncio.run(
            backend.extract(
                "Emma told Anna her sister was overseas. Whose sister was overseas?",
                pef,
            )
        )
        assert "her" in result.ambiguous_referents

    def test_single_person_no_flag(self, backend, pef):
        # Only one PERSON entity → pronoun is unambiguous
        result = asyncio.run(
            backend.extract("Emma said her book was missing.", pef)
        )
        # With only one PERSON, "her" should NOT be flagged as ambiguous
        assert "her" not in result.ambiguous_referents

    def test_no_pronoun_no_flag(self, backend, pef):
        # Two people, but no possessive pronoun
        result = asyncio.run(
            backend.extract("Emma and Anna are both teachers.", pef)
        )
        assert result.ambiguous_referents == []

    def test_unambiguous_sentence_no_flag(self, backend, pef):
        # Possessive but only one PERSON candidate
        result = asyncio.run(
            backend.extract("John lost his wallet at the station.", pef)
        )
        assert "his" not in result.ambiguous_referents

    def test_cross_turn_pef_entities_trigger_gate(self, backend, pef):
        """Gate fires even when entity names come from PEF (prior turns), not current doc.

        Turn 1: Both names established via entity_mentions (no claims, resolved=False).
        Turn 2: Only pronouns in current message — NER finds nothing.
        The gate must still fire because PEF has 2+ person-like antecedents.
        """
        from aurora_lens.interpret.pef_updater import update_pef

        # Turn 1: extract introducing Emma and Anna
        pef.advance_turn()
        turn1 = asyncio.run(
            backend.extract("Emma told Anna her sister was overseas.", pef)
        )
        update_pef(turn1, pef)

        # Turn 2: only pronouns — spaCy NER finds zero PERSON entities in this doc
        pef.advance_turn()
        turn2 = asyncio.run(
            backend.extract("What did she tell her sister?", pef)
        )

        # Gate must fire: "her" is possessive, 2 person-like entities are in PEF
        assert "her" in turn2.ambiguous_referents

    def test_seed_history_seeds_pef_for_stateless_clients(self, backend):
        """Lens.seed_history() builds PEF from prior turns so gate fires on next process()."""
        from aurora_lens.lens import Lens
        from aurora_lens.config import LensConfig
        from aurora_lens.adapters.base import LLMAdapter, AdapterResponse

        class NullAdapter(LLMAdapter):
            async def generate(self, messages, **kwargs):
                return AdapterResponse(text="ok", model="mock")

        config = LensConfig(adapter=NullAdapter(), extraction_backend=backend)
        lens = Lens(config)

        history = [
            {"role": "user", "content": "Emma told Anna her sister was overseas."},
            {"role": "assistant", "content": "Emma mentioned that Anna's sister was abroad."},
        ]
        asyncio.run(lens.seed_history(history))

        # After seeding, PEF should have Emma and Anna as entity mentions
        person_names = {e.name for e in lens.pef.entities.values()}
        assert "Emma" in person_names or "Anna" in person_names

        # Now a follow-up message with a possessive pronoun should fire the gate
        result = asyncio.run(lens.process("What did she tell her sister?"))
        # Gate fires before LLM is called: response is the clarification message
        assert "her" in result.response.lower() or result.action.name != "PASS" or \
               "cannot be uniquely resolved" in result.response
