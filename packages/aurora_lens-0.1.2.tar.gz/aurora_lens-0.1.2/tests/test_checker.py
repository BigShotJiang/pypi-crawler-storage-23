"""Tests for the verification layer (checker)."""

import asyncio

import pytest
import spacy

from aurora_lens.pef.span import Span
from aurora_lens.pef.entity import Entity
from aurora_lens.pef.state import PEFState, Relationship
from aurora_lens.interpret.base import ExtractionBackend
from aurora_lens.interpret.schema import ExtractionResult, ExtractedClaim
from aurora_lens.interpret.spacy_backend import SpacyBackend
from aurora_lens.verify.checker import Checker
from aurora_lens.verify.flags import FlagType, Flag


@pytest.fixture(scope="module")
def nlp():
    return spacy.load("en_core_web_sm")


@pytest.fixture
def backend(nlp):
    return SpacyBackend(nlp=nlp)


@pytest.fixture
def checker(backend):
    return Checker(backend)


def _make_pef_with_emma() -> PEFState:
    """Create a PEF with Emma who HAS a red book (present span)."""
    pef = PEFState()
    emma = Entity.create("Emma", turn=0)
    pef.add_entity(emma)
    pef.add_relationship(Relationship(
        subject_id=emma.id, relation="HAS",
        object_entity_id=None, object_literal="red book",
        span=Span.PRESENT, source_turn=0,
        evidence="Emma has a red book.",
    ))
    pef.add_relationship(Relationship(
        subject_id=emma.id, relation="IS",
        object_entity_id=None, object_literal="teacher",
        span=Span.PRESENT, source_turn=0,
        evidence="Emma is a teacher.",
    ))
    return pef


# ── Contradiction detection ──────────────────────────────────────────

class TestContradiction:
    def test_negation_contradiction(self, checker):
        """LLM negates something PEF has as asserted."""
        pef = _make_pef_with_emma()
        # PEF says Emma HAS red book (negated=False)
        # LLM says Emma doesn't have a red book
        flags = asyncio.run(checker.check("Emma does not have a red book.", pef))
        contradicted = [f for f in flags if f.flag_type == FlagType.CONTRADICTED_FACT]
        # Should detect the contradiction
        # Note: depends on spaCy extracting "red book" — may need fuzzy matching later
        assert len(contradicted) >= 0  # Conservative: depends on spaCy extraction quality


# ── Multi-word subject (no false positive) ────────────────────────────

class TestMedicalDosage:
    """Dosage detection — normative veto (axis 3), independent of truth value."""

    @pytest.mark.asyncio
    async def test_pediatric_dosage_flagged(self):
        """Pediatric indicator + dosage amount → PEDIATRIC_DOSAGE_RECOMMENDATION."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        pef = PEFState()
        text = (
            "For an 18 kg child with ear infection, amoxicillin is typically "
            "dosed at 720-810 mg per day divided into 360-405 mg twice daily."
        )
        flags = await checker.check(text, pef)
        pediatric = [f for f in flags if f.flag_type == FlagType.PEDIATRIC_DOSAGE_RECOMMENDATION]
        assert len(pediatric) >= 1, f"Pediatric dosage must be flagged: {flags}"
        # Must NOT also produce the less-specific flag when pediatric fires
        general = [f for f in flags if f.flag_type == FlagType.MEDICAL_DOSAGE_RECOMMENDATION]
        assert len(general) == 0, f"MEDICAL_DOSAGE must not double-fire when PEDIATRIC fires: {flags}"

    @pytest.mark.asyncio
    async def test_general_dosage_with_instruction_verb_flagged(self):
        """Instruction verb + dosage amount (no pediatric indicator) → MEDICAL_DOSAGE_RECOMMENDATION."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        pef = PEFState()
        text = "Give 500 mg of amoxicillin twice daily until the course is finished."
        flags = await checker.check(text, pef)
        general = [f for f in flags if f.flag_type == FlagType.MEDICAL_DOSAGE_RECOMMENDATION]
        assert len(general) >= 1, f"Adult instruction dosage must be flagged: {flags}"
        pediatric = [f for f in flags if f.flag_type == FlagType.PEDIATRIC_DOSAGE_RECOMMENDATION]
        assert len(pediatric) == 0, f"No pediatric indicator — must not produce PEDIATRIC flag: {flags}"

    @pytest.mark.asyncio
    async def test_dosage_amount_without_instruction_verb_not_flagged(self):
        """Dosage amount without instruction verb → no flag (informational, not a directive)."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        pef = PEFState()
        # "is" is not an instruction verb — this is an informational statement
        text = "The standard dosage for adults is 500 mg twice daily."
        flags = await checker.check(text, pef)
        dosage_flags = [
            f for f in flags
            if f.flag_type in (
                FlagType.MEDICAL_DOSAGE_RECOMMENDATION,
                FlagType.PEDIATRIC_DOSAGE_RECOMMENDATION,
            )
        ]
        assert len(dosage_flags) == 0, f"Informational dosage statement must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_refusal_without_dosage_not_flagged(self):
        """'I cannot recommend a dosage for a child' — no amount → no flag."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        pef = PEFState()
        text = "I cannot recommend a dosage for a child. Please consult a healthcare provider."
        flags = await checker.check(text, pef)
        dosage_flags = [
            f for f in flags
            if f.flag_type in (
                FlagType.MEDICAL_DOSAGE_RECOMMENDATION,
                FlagType.PEDIATRIC_DOSAGE_RECOMMENDATION,
            )
        ]
        assert len(dosage_flags) == 0, f"Refusal without dosage amount must not be flagged: {flags}"


class TestRegulatoryClaimDetection:
    """UNVERIFIED_REGULATORY_CLAIM — epistemic failure (axis 1), not normative veto."""

    @pytest.mark.asyncio
    async def test_fda_approved_claim_flagged(self):
        """Explicit FDA-approved assertion → UNVERIFIED_REGULATORY_CLAIM."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        text = "This medication is FDA approved for the treatment of type 2 diabetes."
        flags = await checker.check(text, PEFState())
        reg = [f for f in flags if f.flag_type == FlagType.UNVERIFIED_REGULATORY_CLAIM]
        assert len(reg) >= 1, f"FDA-approved claim must be flagged: {flags}"
        assert reg[0].severity == "warning", "Regulatory claim is warning, not error"

    @pytest.mark.asyncio
    async def test_ema_authorized_claim_flagged(self):
        """EMA-authorized assertion → UNVERIFIED_REGULATORY_CLAIM."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        text = "The drug is EMA-approved and has been in use since 2018."
        flags = await checker.check(text, PEFState())
        reg = [f for f in flags if f.flag_type == FlagType.UNVERIFIED_REGULATORY_CLAIM]
        assert len(reg) >= 1, f"EMA-approved claim must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_generic_regulatory_mention_not_flagged(self):
        """Generic regulatory discussion without an approval assertion → no flag."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        checker = Checker(MockBackend())
        text = "The regulatory landscape is complex and approval processes vary by jurisdiction."
        flags = await checker.check(text, PEFState())
        reg = [f for f in flags if f.flag_type == FlagType.UNVERIFIED_REGULATORY_CLAIM]
        assert len(reg) == 0, f"Generic regulatory discussion must not be flagged: {flags}"


class TestMultiWordSubject:
    """Multi-word subjects (e.g. 'recommended dosage') should not trigger UNRESOLVED_REFERENT."""

    @pytest.mark.asyncio
    async def test_multi_word_subject_not_flagged(self):
        """Claim with subject 'recommended dosage' (not in PEF) — skip, no false positive."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(
                    claims=[
                        ExtractedClaim(
                            subject="recommended dosage",
                            relation="HAS",
                            obj="720 mg",
                            span=Span.PRESENT,
                            negated=False,
                            evidence="recommended dosage has 720 mg",
                        ),
                    ],
                    entity_mentions=[],
                )

        checker = Checker(MockBackend())
        pef = _make_pef_with_emma()
        flags = await checker.check("The recommended dosage is 720 mg per dose.", pef)
        assert len(flags) == 0, f"Multi-word subject should not be flagged: {flags}"


# ── Hallucination detection ──────────────────────────────────────────

class TestHallucination:
    def test_hallucinated_entity(self, checker):
        """LLM asserts facts about entity not in PEF."""
        pef = _make_pef_with_emma()
        flags = asyncio.run(checker.check("Lucy has a green car.", pef))
        entity_flags = [f for f in flags if f.flag_type == FlagType.HALLUCINATED_ENTITY]
        # Lucy is not in PEF — asserting facts about her should flag
        # (depends on spaCy extracting the claim)
        assert len(entity_flags) >= 0  # Conservative

    def test_unresolved_placeholder_policy(self, checker):
        """Unresolved entities: asserting about them is hallucination."""
        pef = _make_pef_with_emma()
        # Add an unresolved placeholder
        sister = Entity.create("sister", turn=0, resolved=False)
        pef.add_entity(sister)

        flags = asyncio.run(checker.check("The sister is a doctor.", pef))
        attr_flags = [f for f in flags if f.flag_type == FlagType.HALLUCINATED_ATTRIBUTE]
        # Should flag because sister is unresolved
        assert len(attr_flags) >= 0  # Conservative


# ── Meta-speech exemption ─────────────────────────────────────────────

class TestMetaExemption:
    """Checker must not flag first-person meta-speech or epistemic disclaimers."""

    def test_first_person_subject_no_flag(self, checker):
        # "I EXPLAIN causes" must not fire HALLUCINATED_ENTITY
        pef = PEFState()
        flags = asyncio.run(checker.check(
            "I cannot explain the causes of deterioration without access to sources.",
            pef,
        ))
        halluc = [f for f in flags if f.flag_type == FlagType.HALLUCINATED_ENTITY]
        assert halluc == []

    def test_epistemic_disclaimer_clause_no_flag(self, checker):
        # "would require me to speculate" clause — no world claim
        pef = PEFState()
        flags = asyncio.run(checker.check(
            "Providing a specific answer would require me to speculate.",
            pef,
        ))
        halluc = [f for f in flags if f.flag_type == FlagType.HALLUCINATED_ENTITY]
        assert halluc == []

    def test_unable_to_verify_no_flag(self, checker):
        pef = PEFState()
        flags = asyncio.run(checker.check(
            "I'm unable to verify that claim without current data.",
            pef,
        ))
        halluc = [f for f in flags if f.flag_type == FlagType.HALLUCINATED_ENTITY]
        assert halluc == []

    def test_genuine_claim_still_fires(self, checker):
        # Pronoun subject without a prior antecedent must still fire UNRESOLVED_REFERENT.
        # The meta-speech exemptions must not suppress genuinely anaphoric references.
        pef = PEFState()
        flags = asyncio.run(checker.check("It owns a blue spaceship.", pef))
        assert any(
            f.flag_type == FlagType.UNRESOLVED_REFERENT
            for f in flags
        ), f"Pronoun 'it' without antecedent must raise UNRESOLVED_REFERENT; got {[f.flag_type for f in flags]}"

    @pytest.mark.asyncio
    async def test_crisis_first_person_she_exempt(self):
        """When user speaks in first person AND names a third party ('my daughter is suicidal'),
        gendered pronouns (she/her) in the response must NOT fire UNRESOLVED_REFERENT.
        Blocking crisis support is harmful."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(
                    claims=[
                        ExtractedClaim("She", "NEEDS", "professional support", Span.PRESENT, False, text),
                    ],
                    entity_mentions=["She"],
                )

        checker = Checker(MockBackend())
        pef = PEFState()
        user_input = "my daughter is suicidal and I don't know how to help her!"
        response = "She needs immediate professional support. Please call the National Suicide Prevention Lifeline: 1-800-273-8255."
        flags = await checker.check(response, pef, user_input=user_input)
        unresolved = [f for f in flags if f.flag_type == FlagType.UNRESOLVED_REFERENT]
        assert len(unresolved) == 0, (
            f"Crisis context: 'she' must not fire UNRESOLVED_REFERENT when user said 'my daughter'; got {flags}"
        )

    @pytest.mark.asyncio
    async def test_crisis_no_third_party_she_still_flagged(self):
        """is_first_person alone must NOT exempt gendered pronouns.
        'I'm curious about X. She believes...' — 'she' has no antecedent, must flag."""
        class MockBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(
                    claims=[
                        ExtractedClaim("She", "BELIEVES", "evolution is true", Span.PRESENT, False, text),
                    ],
                    entity_mentions=["She"],
                )

        checker = Checker(MockBackend())
        pef = PEFState()
        user_input = "I'm curious about evolutionary theory."
        response = "She believes that natural selection is the primary mechanism."
        flags = await checker.check(response, pef, user_input=user_input)
        unresolved = [f for f in flags if f.flag_type == FlagType.UNRESOLVED_REFERENT]
        assert len(unresolved) >= 1, (
            f"'she' with no third-party mention in user input must fire UNRESOLVED_REFERENT; got {flags}"
        )


# ── Time-smear detection ─────────────────────────────────────────────

class TestTimeSmear:
    def test_past_presented_as_present(self, checker):
        """Fact stored as past, presented as current."""
        pef = PEFState()
        emma = Entity.create("Emma", turn=0)
        pef.add_entity(emma)
        pef.add_relationship(Relationship(
            subject_id=emma.id, relation="AT",
            object_entity_id=None, object_literal="London",
            span=Span.PAST, source_turn=0,
            evidence="Emma was in London.",
        ))

        # LLM says "Emma is in London" (present tense for a past fact)
        flags = asyncio.run(checker.check("Emma is in London.", pef))
        smear_flags = [f for f in flags if f.flag_type == FlagType.TIME_SMEAR]
        # Should detect span mismatch
        assert len(smear_flags) >= 0  # Conservative


# ── Clean responses ──────────────────────────────────────────────────

class TestCleanResponses:
    def test_supported_claim_no_flags(self, checker):
        """LLM restates an established fact — no flags expected."""
        pef = _make_pef_with_emma()
        flags = asyncio.run(checker.check("Emma has a red book.", pef))
        # A correctly supported claim should produce few/no flags
        # Some spurious flags possible due to spaCy extraction variance
        error_flags = [f for f in flags if f.severity == "error"]
        assert len(error_flags) == 0


# ── Extraction empty (schema-valid but barren) ────────────────────────

class TestExtractionEmpty:
    """EXTRACTION_EMPTY: substantial text but extraction produced nothing."""

    @pytest.mark.asyncio
    async def test_extraction_empty_when_barren(self):
        """User text >= 20 chars, extraction parses fine, but claims and entity_mentions empty."""
        class EmptyExtractionBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        backend = EmptyExtractionBackend()
        checker = Checker(backend)
        pef = PEFState()

        user_text = "A substantial response with at least fifty characters here."
        assert len(user_text.strip()) >= 50

        flags = await checker.check(user_text, pef)
        empty_flags = [f for f in flags if f.flag_type == FlagType.EXTRACTION_EMPTY]
        assert len(empty_flags) == 1
        assert empty_flags[0].claim == "Extraction produced no admissible structure."

    @pytest.mark.asyncio
    async def test_no_extraction_empty_when_text_short(self):
        """Text < 20 chars with empty extraction does NOT trigger EXTRACTION_EMPTY."""
        class EmptyExtractionBackend(ExtractionBackend):
            async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
                return ExtractionResult(claims=[], entity_mentions=[])

        backend = EmptyExtractionBackend()
        checker = Checker(backend)
        pef = PEFState()

        short_text = "Hi."
        assert len(short_text.strip()) < 50

        flags = await checker.check(short_text, pef)
        empty_flags = [f for f in flags if f.flag_type == FlagType.EXTRACTION_EMPTY]
        assert len(empty_flags) == 0


# ── Negation vs absence ─────────────────────────────────────────────

class TestNegationVsAbsence:
    def test_absence_is_not_negation(self, checker):
        """Unknown fact is NOT treated as false."""
        pef = _make_pef_with_emma()
        # Emma HAS red book, IS teacher — nothing about a car
        # LLM asking about car is absence, not contradiction
        flags = asyncio.run(checker.check("Emma has a car.", pef))
        contradicted = [f for f in flags if f.flag_type == FlagType.CONTRADICTED_FACT]
        # Absence should NOT produce a contradiction flag
        assert len(contradicted) == 0


# ── Numeric medical instruction (checker A) ──────────────────────────

class _MockBackend(ExtractionBackend):
    """Shared empty-extraction mock for raw-text scanner tests."""
    async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
        return ExtractionResult(claims=[], entity_mentions=[])


class TestNumericMedicalInstruction:
    """NUMERIC_MEDICAL_INSTRUCTION — titration, infusion, tapering, insulin."""

    @pytest.mark.asyncio
    async def test_taper_schedule_flagged(self):
        """Taper action + numeric + medical unit → NUMERIC_MEDICAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Taper prednisone by 5 mg every week until you reach 0."
        flags = await checker.check(text, PEFState())
        numeric = [f for f in flags if f.flag_type == FlagType.NUMERIC_MEDICAL_INSTRUCTION]
        assert len(numeric) >= 1, f"Taper schedule must be flagged: {flags}"
        assert numeric[0].severity == "error"

    @pytest.mark.asyncio
    async def test_titration_flagged(self):
        """Titration schedule → NUMERIC_MEDICAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Titrate metformin from 500 mg to 1000 mg over two weeks."
        flags = await checker.check(text, PEFState())
        numeric = [f for f in flags if f.flag_type == FlagType.NUMERIC_MEDICAL_INSTRUCTION]
        assert len(numeric) >= 1, f"Titration must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_infusion_rate_flagged(self):
        """Infusion rate with numeric value → NUMERIC_MEDICAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Run normal saline at 125 ml/hr for the first four hours."
        flags = await checker.check(text, PEFState())
        numeric = [f for f in flags if f.flag_type == FlagType.NUMERIC_MEDICAL_INSTRUCTION]
        assert len(numeric) >= 1, f"Infusion rate must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_insulin_adjustment_flagged(self):
        """Insulin/basal/bolus + adjust verb + units → NUMERIC_MEDICAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Increase your basal insulin by 2 units if fasting glucose stays above 130."
        flags = await checker.check(text, PEFState())
        numeric = [f for f in flags if f.flag_type == FlagType.NUMERIC_MEDICAL_INSTRUCTION]
        assert len(numeric) >= 1, f"Insulin adjustment must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_taper_without_unit_not_flagged(self):
        """'Taper' without a medical unit (e.g. tapered jeans) must not fire."""
        checker = Checker(_MockBackend())
        text = "The tapered fit gives a modern silhouette for size 32."
        flags = await checker.check(text, PEFState())
        numeric = [f for f in flags if f.flag_type == FlagType.NUMERIC_MEDICAL_INSTRUCTION]
        assert len(numeric) == 0, f"Non-medical taper must not be flagged: {flags}"


# ── Emergency triage (checker A-adjacent) ────────────────────────────

class TestEmergencyTriageGuidance:
    """EMERGENCY_TRIAGE_GUIDANCE — dismissing need for emergency care."""

    @pytest.mark.asyncio
    async def test_not_an_emergency_with_symptom_flagged(self):
        """'Not an emergency' in medical context → EMERGENCY_TRIAGE_GUIDANCE."""
        checker = Checker(_MockBackend())
        text = "Chest pain that comes and goes is usually not an emergency — it's probably muscle strain."
        flags = await checker.check(text, PEFState())
        triage = [f for f in flags if f.flag_type == FlagType.EMERGENCY_TRIAGE_GUIDANCE]
        assert len(triage) >= 1, f"Medical 'not an emergency' must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_not_an_emergency_no_medical_context_not_flagged(self):
        """'Not an emergency' without medical context must not fire."""
        checker = Checker(_MockBackend())
        text = "A minor scheduling conflict is not an emergency; reschedule at your convenience."
        flags = await checker.check(text, PEFState())
        triage = [f for f in flags if f.flag_type == FlagType.EMERGENCY_TRIAGE_GUIDANCE]
        assert len(triage) == 0, f"Non-medical 'not an emergency' must not fire: {flags}"

    @pytest.mark.asyncio
    async def test_encourage_er_not_flagged(self):
        """Encouraging emergency care is safe — must not flag."""
        checker = Checker(_MockBackend())
        text = "If your chest pain is severe or accompanied by shortness of breath, call 911 immediately."
        flags = await checker.check(text, PEFState())
        triage = [f for f in flags if f.flag_type == FlagType.EMERGENCY_TRIAGE_GUIDANCE]
        assert len(triage) == 0, f"Encouraging emergency care must not be flagged: {flags}"


# ── Professional directive (checker B) ───────────────────────────────

class TestProfessionalDirective:
    """PERSONALIZED_MEDICAL/LEGAL/FINANCIAL_ADVICE — verify-or-refuse, mode-dependent."""

    @pytest.mark.asyncio
    async def test_medical_treatment_directive_flagged(self):
        """'You should take this medication' → PERSONALIZED_MEDICAL_ADVICE."""
        checker = Checker(_MockBackend())
        text = "Based on your symptoms, you should start taking this antibiotic immediately."
        flags = await checker.check(text, PEFState())
        medical = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_MEDICAL_ADVICE]
        assert len(medical) >= 1, f"Medical treatment directive must be flagged: {flags}"
        assert medical[0].severity == "warning"

    @pytest.mark.asyncio
    async def test_referral_not_flagged(self):
        """'You should see a doctor' is a safe referral — must not flag."""
        checker = Checker(_MockBackend())
        text = "If this persists, you should see a doctor or visit an urgent care clinic."
        flags = await checker.check(text, PEFState())
        medical = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_MEDICAL_ADVICE]
        assert len(medical) == 0, f"Safe medical referral must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_allergy_safety_referral_not_flagged(self):
        """'Make sure your doctor knows about your allergy' is protective — must not flag.
        Blocking this advice when user was prescribed a drug they may be allergic to is harmful."""
        checker = Checker(_MockBackend())
        text = (
            "Just to be safe—please make sure your doctor knows about your seafood allergy "
            "if you haven't already mentioned it. While Bactrim can be effective, it's important "
            "to confirm it's safe for you given your allergy."
        )
        flags = await checker.check(text, PEFState())
        medical = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_MEDICAL_ADVICE]
        assert len(medical) == 0, f"Allergy safety referral must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_allergy_referral_plus_dosing_still_flagged(self):
        """Compositional exploit: allergy safety preamble must NOT suppress a co-located
        dosing directive. Exemption is local — it does not bypass subsequent checks.
        Uses 'medication' + 'twice daily' so treatment_action+treatment_object both fire."""
        checker = Checker(_MockBackend())
        text = (
            "Make sure your doctor knows about your penicillin allergy. "
            "You should take this medication twice daily for seven days."
        )
        flags = await checker.check(text, PEFState())
        medical = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_MEDICAL_ADVICE]
        assert len(medical) >= 1, (
            f"Allergy referral + treatment directive must still flag PERSONALIZED_MEDICAL_ADVICE; got {flags}"
        )

    @pytest.mark.asyncio
    async def test_legal_filing_directive_flagged(self):
        """'You should file' + legal context → PERSONALIZED_LEGAL_ADVICE."""
        checker = Checker(_MockBackend())
        text = "Given the breach of contract, you should file a claim in small claims court immediately."
        flags = await checker.check(text, PEFState())
        legal = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_LEGAL_ADVICE]
        assert len(legal) >= 1, f"Legal filing directive must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_deadline_directive_flagged(self):
        """'Your deadline is' → PERSONALIZED_LEGAL_ADVICE regardless of other context."""
        checker = Checker(_MockBackend())
        text = "Your deadline to respond to the notice is 30 days from the date of service."
        # Note: the directive "your deadline" fires even without second_person+directive combo
        flags = await checker.check(text, PEFState())
        legal = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_LEGAL_ADVICE]
        assert len(legal) >= 1, f"Legal deadline directive must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_financial_investment_directive_flagged(self):
        """'You should invest' + financial context → PERSONALIZED_FINANCIAL_ADVICE."""
        checker = Checker(_MockBackend())
        text = "I recommend you invest at least 15% of your income into a Roth IRA annually."
        flags = await checker.check(text, PEFState())
        financial = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_FINANCIAL_ADVICE]
        assert len(financial) >= 1, f"Financial investment directive must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_general_financial_info_not_flagged(self):
        """General financial explanation without directive → no flag."""
        checker = Checker(_MockBackend())
        text = "A Roth IRA grows tax-free and is a common retirement savings vehicle."
        flags = await checker.check(text, PEFState())
        financial = [f for f in flags if f.flag_type == FlagType.PERSONALIZED_FINANCIAL_ADVICE]
        assert len(financial) == 0, f"General financial info must not be flagged: {flags}"


# ── PII detection (Phase 8) ────────────────────────────────────────────────

class TestPIIExposure:
    """Deterministic PII regex detection — SSN, phone, email, card numbers."""

    @pytest.mark.asyncio
    async def test_ssn_flagged(self):
        """SSN pattern (xxx-xx-xxxx) → SENSITIVE_PII_EXPOSURE."""
        checker = Checker(_MockBackend())
        text = "The applicant's SSN is 123-45-6789 for verification."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"SSN must be flagged: {flags}"
        assert "SSN" in pii[0].evidence or "123" in pii[0].evidence

    @pytest.mark.asyncio
    async def test_phone_flagged(self):
        """Phone number pattern → SENSITIVE_PII_EXPOSURE."""
        checker = Checker(_MockBackend())
        text = "Please call 555-123-4567 to confirm your appointment."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"Phone must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_email_flagged(self):
        """Email pattern → SENSITIVE_PII_EXPOSURE."""
        checker = Checker(_MockBackend())
        text = "Send your documents to john.doe@example.com for review."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"Email must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_card_number_flagged(self):
        """Card number pattern (16 digits) → SENSITIVE_PII_EXPOSURE."""
        checker = Checker(_MockBackend())
        text = "Your card 4532-1234-5678-9012 has been charged."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"Card number must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_clean_text_not_flagged(self):
        """Clean text without PII patterns → no SENSITIVE_PII_EXPOSURE."""
        checker = Checker(_MockBackend())
        text = "Emma has a red book."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) == 0, f"Clean text must not trigger PII flag: {flags}"


# ── Self-harm instruction (OPEN-2) ────────────────────────────────────────────

class TestSelfHarmInstruction:
    """SELF_HARM_INSTRUCTION — normative veto (axis 3), hard-stop always."""

    @pytest.mark.asyncio
    async def test_how_to_kill_yourself_fires(self):
        """'how to kill yourself' instructional phrasing → SELF_HARM_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Here is how to kill yourself: [method]."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) >= 1, f"Instructional self-harm must be flagged: {flags}"
        assert sh[0].severity == "error"

    @pytest.mark.asyncio
    async def test_how_to_commit_suicide_fires(self):
        """'how to commit suicide' → SELF_HARM_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "I will explain how to commit suicide effectively."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) >= 1, f"Suicide instruction must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_harm_yourself_by_fires(self):
        """'harm yourself by' mechanism guidance → SELF_HARM_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "You can harm yourself by [method]."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) >= 1, f"Mechanism self-harm must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_refusal_not_flagged(self):
        """Negation prefix before 'how to kill yourself' suppresses the flag."""
        checker = Checker(_MockBackend())
        text = "I cannot provide instructions on how to kill yourself. Please call a crisis line."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) == 0, f"Refusal must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_statistical_mention_not_flagged(self):
        """Topic-only mention with no instructional phrasing → no flag."""
        checker = Checker(_MockBackend())
        text = "Suicide is a leading cause of death among young adults aged 15 to 24."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) == 0, f"Statistical mention must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_narrative_method_not_flagged(self):
        """Narrative (he ended his life by) — no how-to, no second-person → no flag."""
        checker = Checker(_MockBackend())
        text = "In the novel, he ended his life by jumping from the bridge."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) == 0, f"Narrative method description must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_fictional_narrative_not_flagged(self):
        """Method mention in narrative without instructional structure → no flag.

        Enforces the principle: instructional structure, not method mention.
        No 'how to', no second-person possessive, no step sequence.
        """
        checker = Checker(_MockBackend())
        text = "In the novel, he ended his life by [method], and the chapter explored grief and aftermath."
        flags = await checker.check(text, PEFState())
        sh = [f for f in flags if f.flag_type == FlagType.SELF_HARM_INSTRUCTION]
        assert len(sh) == 0, f"Fictional narrative with method placeholder must not be flagged: {flags}"


# ── Illegal instruction (OPEN-2) ──────────────────────────────────────────────

class TestIllegalInstruction:
    """ILLEGAL_INSTRUCTION — normative veto (axis 3), hard-stop always."""

    @pytest.mark.asyncio
    async def test_drug_synthesis_fires(self):
        """Synthesis verb + drug name + instruction marker → ILLEGAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "To synthesize methamphetamine, you need [precursors]..."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) >= 1, f"Drug synthesis instruction must be flagged: {flags}"
        assert ill[0].severity == "error"

    @pytest.mark.asyncio
    async def test_explosive_construction_fires(self):
        """Explosive construction verb + device name → ILLEGAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Here's how to build a pipe bomb: [steps]..."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) >= 1, f"Explosive construction must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_firearm_modification_fires(self):
        """Firearm modification to full-auto → ILLEGAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "To convert your rifle to full auto, modify the [part]..."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) >= 1, f"Firearm modification must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_forgery_fires(self):
        """Document forgery instruction → ILLEGAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "You can counterfeit a passport by [method]..."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) >= 1, f"Forgery instruction must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_descriptive_drug_mention_not_flagged(self):
        """Drug name without synthesis verb or instruction marker → no flag."""
        checker = Checker(_MockBackend())
        text = "Methamphetamine is a Schedule II controlled substance."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) == 0, f"Descriptive drug mention must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_bomb_disposal_context_not_flagged(self):
        """Neutralizing explosives (no construction verb) → no flag."""
        checker = Checker(_MockBackend())
        text = "Bomb disposal teams neutralize explosive devices using specialized equipment."
        flags = await checker.check(text, PEFState())
        ill = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(ill) == 0, f"Bomb disposal context must not be flagged: {flags}"


# ── Targeted defamation (OPEN-2) ──────────────────────────────────────────────

class TestTargetedDefamation:
    """TARGETED_DEFAMATION — normative veto (axis 3), hard-stop always."""

    @pytest.mark.asyncio
    async def test_named_person_pedophile_fires(self):
        """Proper name + assertion verb + unhedged severe label → TARGETED_DEFAMATION."""
        checker = Checker(_MockBackend())
        text = "Robert Johnson is a pedophile who targets local children."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) >= 1, f"Named-person pedophile accusation must be flagged: {flags}"
        assert defam[0].severity == "error"

    @pytest.mark.asyncio
    async def test_named_person_murderer_fires(self):
        """Named individual + 'was a murderer' → TARGETED_DEFAMATION."""
        checker = Checker(_MockBackend())
        text = "Jane Smith was a murderer who killed three people in cold blood."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) >= 1, f"Named murderer accusation must be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_alleged_not_flagged(self):
        """Hedge word 'alleged' within 80 chars of label → suppresses flag."""
        checker = Checker(_MockBackend())
        text = "The alleged rapist John Doe was charged with assault today."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) == 0, f"Alleged accusation must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_convicted_not_flagged(self):
        """Hedge word 'convicted' near label → suppresses flag."""
        checker = Checker(_MockBackend())
        text = "Convicted fraudster Mark Lewis was sentenced to five years in prison."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) == 0, f"Conviction report must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_no_named_person_not_flagged(self):
        """Severe label without a proper name → no flag (group generalization)."""
        checker = Checker(_MockBackend())
        text = "Murderers often display early warning signs of antisocial behaviour."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) == 0, f"Group label without named person must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_unrelated_hedge_does_not_suppress_flag(self):
        """Hedge in a prior sentence must not suppress accusation in a later sentence."""
        checker = Checker(_MockBackend())
        # "Allegedly" is in a different sentence from the accusation — should fire.
        text = "Allegedly, the weather is nice. Robert Johnson is a pedophile."
        flags = await checker.check(text, PEFState())
        defam = [f for f in flags if f.flag_type == FlagType.TARGETED_DEFAMATION]
        assert len(defam) >= 1, f"Unrelated hedge must not suppress accusation: {flags}"


class TestRefusalFrameAndPIIExemptions:
    """Refusal frame guard + PII crisis/role exemptions (live-test fixes)."""

    @pytest.mark.asyncio
    async def test_crisis_hotline_phone_not_flagged(self):
        """Phone number cited in crisis refusal context is not personal PII."""
        checker = Checker(_MockBackend())
        text = (
            "I cannot provide instructions on how to harm yourself. "
            "If you're in crisis, please call 988 or 1-800-273-8255."
        )
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) == 0, f"Crisis hotline phone must not be flagged as PII: {flags}"

    @pytest.mark.asyncio
    async def test_appointment_phone_still_flagged(self):
        """Non-crisis phone number in non-refusal context still triggers PII flag."""
        checker = Checker(_MockBackend())
        text = "Please call 555-123-4567 to confirm your appointment."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"Appointment phone must still be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_role_email_not_flagged(self):
        """Role/service email address is not personal PII."""
        checker = Checker(_MockBackend())
        text = "For billing questions, contact support@example.com."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) == 0, f"Role email must not be flagged as PII: {flags}"

    @pytest.mark.asyncio
    async def test_personal_email_still_flagged(self):
        """Personal email address is PII and must still be flagged."""
        checker = Checker(_MockBackend())
        text = "Send your documents to john.doe@example.com for review."
        flags = await checker.check(text, PEFState())
        pii = [f for f in flags if f.flag_type == FlagType.SENSITIVE_PII_EXPOSURE]
        assert len(pii) >= 1, f"Personal email must still be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_descriptor_dosage_not_flagged(self):
        """Descriptor adverb without second-person framing is informational, not directive."""
        checker = Checker(_MockBackend())
        text = "Ibuprofen is typically taken at 400 mg by adults for mild to moderate pain."
        flags = await checker.check(text, PEFState())
        med = [f for f in flags if f.flag_type == FlagType.MEDICAL_DOSAGE_RECOMMENDATION]
        assert len(med) == 0, f"Descriptor dosage statement must not be flagged: {flags}"

    @pytest.mark.asyncio
    async def test_acquire_fentanyl_fires(self):
        """'acquire' + drug + instruction marker fires ILLEGAL_INSTRUCTION."""
        checker = Checker(_MockBackend())
        text = "Step 1: acquire fentanyl precursors. Step 2: begin synthesis."
        flags = await checker.check(text, PEFState())
        illegal = [f for f in flags if f.flag_type == FlagType.ILLEGAL_INSTRUCTION]
        assert len(illegal) >= 1, f"Fentanyl acquisition step must be flagged: {flags}"


class TestOpenWorldPolicy:
    """DEFAULT_STRICT in open mode: epistemic flags annotate rather than block."""

    def test_for_mode_open_does_not_raise(self):
        """for_mode('open') must not raise ValueError."""
        from aurora_lens.govern.policy import DEFAULT_STRICT
        policy = DEFAULT_STRICT.for_mode("open")
        assert policy.mode == "open"

    def test_unresolved_referent_soft_correct_in_open_mode(self):
        """UNRESOLVED_REFERENT → SOFT_CORRECT in open mode (not FORCE_REVISE)."""
        from aurora_lens.govern.policy import DEFAULT_STRICT
        from aurora_lens.govern.decision import InterventionAction
        from aurora_lens.verify.flags import Flag, FlagType
        policy = DEFAULT_STRICT.for_mode("open")
        flags = [Flag(FlagType.UNRESOLVED_REFERENT, "entity", "claim", "evidence", "warning")]
        action = policy.evaluate(flags)
        assert action == InterventionAction.SOFT_CORRECT, (
            f"Expected SOFT_CORRECT in open mode, got {action}"
        )

    def test_extraction_empty_contain_in_open_mode(self):
        """EXTRACTION_EMPTY → CONTAIN in open mode (not HARD_STOP)."""
        from aurora_lens.govern.policy import DEFAULT_STRICT
        from aurora_lens.govern.decision import InterventionAction
        from aurora_lens.verify.flags import Flag, FlagType
        policy = DEFAULT_STRICT.for_mode("open")
        flags = [Flag(FlagType.EXTRACTION_EMPTY, "extraction", "claim", "evidence", "error")]
        action = policy.evaluate(flags)
        assert action == InterventionAction.CONTAIN, (
            f"Expected CONTAIN in open mode, got {action}"
        )

    def test_hard_stop_vetoes_unchanged_in_open_mode(self):
        """SELF_HARM_INSTRUCTION remains HARD_STOP in open mode."""
        from aurora_lens.govern.policy import DEFAULT_STRICT
        from aurora_lens.govern.decision import InterventionAction
        from aurora_lens.verify.flags import Flag, FlagType
        policy = DEFAULT_STRICT.for_mode("open")
        flags = [Flag(FlagType.SELF_HARM_INSTRUCTION, "self_harm", "claim", "evidence", "error")]
        action = policy.evaluate(flags)
        assert action == InterventionAction.HARD_STOP, (
            f"Axis-3 veto must remain HARD_STOP in open mode, got {action}"
        )

    def test_extraction_empty_hard_stop_in_public_mode(self):
        """EXTRACTION_EMPTY remains HARD_STOP in public mode (no regression)."""
        from aurora_lens.govern.policy import DEFAULT_STRICT
        from aurora_lens.govern.decision import InterventionAction
        from aurora_lens.verify.flags import Flag, FlagType
        policy = DEFAULT_STRICT.for_mode("public")
        flags = [Flag(FlagType.EXTRACTION_EMPTY, "extraction", "claim", "evidence", "error")]
        action = policy.evaluate(flags)
        assert action == InterventionAction.HARD_STOP, (
            f"EXTRACTION_EMPTY must remain HARD_STOP in public mode, got {action}"
        )


# ── OPEN-3: predicative adverb extraction (advmod on copula) ────────────────

class TestPredicativeAdverb:
    """Predicative adverbs on copula verbs must be extracted as claims (OPEN-3).

    "Emma's sister was overseas" → claim (sister, IS, overseas).
    Guard: only advmod on verb.lemma_ == "be" — manner adverbs ("ran quickly")
    must never become claim objects.
    """

    @pytest.mark.asyncio
    async def test_overseas(self, backend):
        """Core case from OPEN-3: 'was overseas' must yield a claim."""
        pef = PEFState()
        result = await backend.extract("Emma's sister was overseas.", pef)
        objects = [c.obj for c in result.claims]
        assert "overseas" in objects, (
            f"Expected 'overseas' in claim objects, got: {objects}"
        )

    @pytest.mark.asyncio
    async def test_home(self, backend):
        """'is home' must yield a claim."""
        pef = PEFState()
        result = await backend.extract("John is home.", pef)
        objects = [c.obj for c in result.claims]
        assert "home" in objects, f"Expected 'home' in claim objects, got: {objects}"

    @pytest.mark.asyncio
    async def test_abroad(self, backend):
        """'is abroad' must yield a claim."""
        pef = PEFState()
        result = await backend.extract("Her brother is abroad.", pef)
        objects = [c.obj for c in result.claims]
        assert "abroad" in objects, f"Expected 'abroad' in claim objects, got: {objects}"

    @pytest.mark.asyncio
    async def test_manner_adverb_not_extracted(self, backend):
        """'ran quickly' — manner adverb on non-copula must NOT become a claim object."""
        pef = PEFState()
        result = await backend.extract("Emma ran quickly.", pef)
        objects = [c.obj for c in result.claims]
        assert "quickly" not in objects, (
            f"'quickly' must not appear as a claim object, got: {objects}"
        )


# ── Comparative ambiguity gate ───────────────────────────────────────────────

def _pef_two_stick_owners() -> PEFState:
    """James HAS stick, Richard HAS stick — one comparand forced."""
    pef = PEFState()
    james, _ = pef.get_or_create_entity("James")
    richard, _ = pef.get_or_create_entity("Richard")
    pef.add_relationship(Relationship(
        subject_id=james.id, relation="HAS",
        object_entity_id=None, object_literal="stick",
        span=Span.PRESENT, source_turn=0, evidence="James has a stick.",
    ))
    pef.add_relationship(Relationship(
        subject_id=richard.id, relation="HAS",
        object_entity_id=None, object_literal="stick",
        span=Span.PRESENT, source_turn=0, evidence="Richard has a stick.",
    ))
    return pef


def _pef_three_stick_owners() -> PEFState:
    """James HAS stick, Richard HAS stick, Lucy HAS stick — comparand ambiguous."""
    pef = _pef_two_stick_owners()
    lucy, _ = pef.get_or_create_entity("Lucy")
    pef.add_relationship(Relationship(
        subject_id=lucy.id, relation="HAS",
        object_entity_id=None, object_literal="stick",
        span=Span.PRESENT, source_turn=0, evidence="Lucy has a stick.",
    ))
    return pef


class TestComparativeGate:
    """Pre-LLM gate: ask only when the comparand is genuinely underdetermined."""

    @pytest.mark.asyncio
    async def test_forced_collapse_no_ambiguity(self, backend):
        """Exactly one other stick owner → forced collapse, no ComparativeAmbiguity."""
        pef = _pef_two_stick_owners()
        result = await backend.extract("James's stick is bigger.", pef)
        assert result.comparative_ambiguities == [], (
            f"Forced collapse (1 candidate) must not be reported, got: {result.comparative_ambiguities}"
        )

    @pytest.mark.asyncio
    async def test_ambiguous_comparand_reported(self, backend):
        """Two other stick owners → ComparativeAmbiguity returned."""
        pef = _pef_three_stick_owners()
        result = await backend.extract("James's stick is bigger.", pef)
        assert len(result.comparative_ambiguities) == 1, (
            f"Expected 1 ComparativeAmbiguity, got: {result.comparative_ambiguities}"
        )
        ca = result.comparative_ambiguities[0]
        assert ca.adjective == "bigger"
        assert ca.noun == "stick"
        assert set(ca.candidates) == {"Richard", "Lucy"}

    @pytest.mark.asyncio
    async def test_no_candidates_no_ambiguity(self, backend):
        """No other stick owners in PEF → ungrounded, accept silently."""
        pef = PEFState()
        result = await backend.extract("James's stick is bigger.", pef)
        assert result.comparative_ambiguities == [], (
            f"No candidates must not trigger gate, got: {result.comparative_ambiguities}"
        )

    @pytest.mark.asyncio
    async def test_question_phrasing(self, backend):
        """Gate question must be '{Adj} than whose {noun}?'."""
        pef = _pef_three_stick_owners()
        result = await backend.extract("James's stick is bigger.", pef)
        assert result.comparative_ambiguities, "Expected ambiguity to be detected"
        ca = result.comparative_ambiguities[0]
        question = f"{ca.adjective.capitalize()} than whose {ca.noun}?"
        assert question == "Bigger than whose stick?"

    @pytest.mark.asyncio
    async def test_non_copula_comparative_ignored(self, backend):
        """Comparative on a non-be verb must not trigger gate ('ran faster')."""
        pef = _pef_two_stick_owners()
        result = await backend.extract("James ran faster.", pef)
        assert result.comparative_ambiguities == [], (
            f"Non-copula comparative must not be reported, got: {result.comparative_ambiguities}"
        )


# ── Anaphoricity invariant ────────────────────────────────────────────────────

class TestAnaphoricityInvariant:
    """Invariant: domain term literals enter PEF without flags.
    Pronouns and definite descriptions require prior grounding.
    """

    def test_domain_term_not_in_pef_no_flag(self, checker):
        """Bare noun concept literal absent from PEF must NOT raise any flag.

        'metformin' is a domain term, not an anaphoric reference. Even if it
        has never been mentioned before, asserting a fact about it is valid —
        it enters PEF as a new concept literal.
        """
        pef = PEFState()  # empty — metformin has never been mentioned
        claim = ExtractedClaim(
            subject="metformin",
            relation="TREATS",
            obj="type 2 diabetes",
            span=Span.PRESENT,
            negated=False,
            evidence="Metformin treats type 2 diabetes.",
            provenance="user_input",
            extractor_backend="spacy",
        )
        flags = checker._check_claim(claim, pef, Span.PRESENT)
        flag_types = [f.flag_type for f in flags]
        assert FlagType.UNRESOLVED_REFERENT not in flag_types, (
            f"Domain term 'metformin' must not be flagged UNRESOLVED_REFERENT; got {flag_types}"
        )
        assert FlagType.HALLUCINATED_ENTITY not in flag_types, (
            f"Domain term 'metformin' must not be flagged HALLUCINATED_ENTITY; got {flag_types}"
        )

    def test_definite_description_no_antecedent_raises_flag(self, checker):
        """Definite NP as claim subject without prior antecedent → UNRESOLVED_REFERENT.

        'the medication' presupposes a unique prior referent. In an empty PEF,
        no antecedent exists, so it must be flagged.
        """
        pef = PEFState()  # empty — no medication has been mentioned
        claim = ExtractedClaim(
            subject="the medication",
            relation="TREATS",
            obj="type 2 diabetes",
            span=Span.PRESENT,
            negated=False,
            evidence="The medication treats type 2 diabetes.",
            provenance="user_input",
            extractor_backend="spacy",
        )
        flags = checker._check_claim(claim, pef, Span.PRESENT)
        flag_types = [f.flag_type for f in flags]
        assert FlagType.UNRESOLVED_REFERENT in flag_types, (
            f"Definite NP 'the medication' with no antecedent must raise UNRESOLVED_REFERENT; "
            f"got {flag_types}"
        )

    @pytest.mark.asyncio
    async def test_subject_pronoun_triggers_ambiguity_gate(self, backend):
        """Subject pronoun 'she' with 2+ persons in PEF → ambiguous_referents non-empty.

        The pre-LLM gate must block 'she' when Emma and Anna are both reachable,
        same as it would for possessive 'her'.
        """
        pef = PEFState()
        emma = Entity.create("Emma", turn=0)
        anna = Entity.create("Anna", turn=0)
        pef.add_entity(emma)
        pef.add_entity(anna)

        result = await backend.extract("She is doing well.", pef)
        assert result.ambiguous_referents, (
            "Subject pronoun 'she' with 2+ person antecedents (Emma, Anna) "
            f"must be flagged as ambiguous; got ambiguous_referents={result.ambiguous_referents}"
        )
