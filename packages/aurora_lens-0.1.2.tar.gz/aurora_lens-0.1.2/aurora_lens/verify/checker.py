"""Verification checker — compare LLM output claims against PEF state.

Implements:
- "Introduced" policy: unresolved placeholders don't trigger flags
- Negation rules: contradiction vs absence
- Time-smear detection
- Medical-safety: pediatric dosage recommendations must not PASS
"""

from __future__ import annotations

import re

# First-person pronoun subjects — model meta-speech, not world claims.
_FIRST_PERSON: frozenset[str] = frozenset({"i", "we", "me", "my", "our"})

# Anaphoric referents — pronouns and demonstratives that require a prior
# grounding in PEF. When these appear as claim subjects without an established
# antecedent, they must be flagged UNRESOLVED_REFERENT.
_REFERENT_PRONOUNS: frozenset[str] = frozenset({
    "he", "him", "his",
    "she", "her", "hers",
    "it", "its",
    "they", "them", "their", "theirs",
    "that", "this", "these", "those",
})

# Conversational back-reference pronouns — pronouns/demonstratives that typically
# refer to user-stated content rather than LLM-invented entities.
#
#   "They require care" / "It's gone now" after a user described symptoms = conversational anaphora.
#   "This warrants attention" / "That is serious" after user described their situation = same.
#   "She has a fever" without a prior referent = world-state claim that must be flagged.
#
# When user spoke in first person (or content words overlap), these are exempt
# from UNRESOLVED_REFERENT.  "that" is also included because spaCy parses relative
# clauses ("chest tightness that lasted an hour") as separate claims with "that"
# as the subject — these are syntactic artifacts, not world-state assertions.
# Third-person singular gendered pronouns (he/she/her/him) are NOT included —
# they refer to third parties, not the user's described experience.
_CONVERSATIONAL_PRONOUNS: frozenset[str] = frozenset({
    "it", "its",
    "that", "this",
    "they", "them", "their", "theirs", "these", "those",
})

# Definite description prefixes — NPs that presuppose a unique prior antecedent.
_DEFINITE_PREFIXES: tuple[str, ...] = ("the ", "that ", "this ", "those ", "these ")


def _is_definite_description(s: str) -> bool:
    """Return True if s is a multi-word definite description (starts with 'the/that/this/...')."""
    lower = s.strip().lower()
    return any(lower.startswith(p) for p in _DEFINITE_PREFIXES)


_BACK_REF_STOP: frozenset[str] = frozenset({
    "have", "that", "this", "with", "from", "they", "them", "their",
    "also", "been", "were", "will", "your", "which", "what", "when",
    "here", "some", "just", "very", "more", "like", "than", "then",
    "into", "onto", "over", "under", "about", "after", "before",
})


def _content_words(text: str) -> frozenset[str]:
    """Lowercase content words (length > 3, not in stop set) for back-reference detection."""
    words: set[str] = set()
    for w in re.split(r"[\s.,!?;:—\-\"'()\[\]]+", text.lower()):
        if len(w) > 3 and w not in _BACK_REF_STOP:
            words.add(w)
    return frozenset(words)


# Regex for first-person input detection — handles straight (') and curly (')
# apostrophes in contractions.  Matches whole-word "I", "my", "me", "myself",
# and contractions I've / I'm / I'd / I'll.
_FP_INPUT_RE = re.compile(
    r"\b(?:i|i['\u2019]ve|i['\u2019]m|i['\u2019]d|i['\u2019]ll|my|me|myself)\b",
    re.IGNORECASE,
)

# Third-party relational mentions — minimal, high-signal list.
# Used to scope the gendered-pronoun exemption: "she/he" in a response is only
# exempt from UNRESOLVED_REFERENT when the user explicitly mentioned a third
# party (not just spoke in first person about themselves).
# Neutral pronouns (they/them/their) are already handled more broadly by
# _CONVERSATIONAL_PRONOUNS when is_first_person is True — no asymmetry.
_THIRD_PARTY_RE = re.compile(
    r"\b(?:my|our)\s+(?:daughter|son|child|husband|wife|partner|patient|client|"
    r"friend|mother|father|sister|brother)\b",
    re.IGNORECASE,
)


def _is_first_person_input(text: str) -> bool:
    """True when user spoke in first person (describing their own experience)."""
    return bool(_FP_INPUT_RE.search(text))


# PII patterns — deterministic regex detection (Phase 8). No LLM required.
_PII_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_PII_PHONE_RE = re.compile(
    r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
    r"|\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b"
    r"|\b\+\d{1,3}[-.\s]?\d{2,4}[-.\s]?\d{2,4}[-.\s]?\d{2,4}\b",
)
_PII_EMAIL_RE = re.compile(
    r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
)
_PII_CARD_RE = re.compile(
    r"\b(?:\d{4}[\s-]?){3}\d{4}\b"  # 16 digits (Visa/MC/Discover)
    r"|\b\d{4}[\s-]?\d{6}[\s-]?\d{5}\b",  # Amex 15 digits (4-6-5)
)

# ── Self-harm instruction patterns ───────────────────────────────────────────
_SH_INSTRUCTION_RE = re.compile(
    r"(?:"
    r"how\s+to\s+(?:kill|harm|hurt)\s+(?:your|my)\s*self"
    r"|how\s+to\s+commit\s+suicide"
    r"|how\s+to\s+(?:end|take)\s+(?:your|my|one['\u2019]?s)\s+(?:own\s+)?life"
    r"|ways?\s+to\s+(?:kill|harm)\s+(?:your|my)\s*self"
    r"|methods?\s+(?:of|for)\s+(?:self[\s\-]harm|killing\s+(?:your|my)\s*self)"
    r"|steps?\s+(?:to|for)\s+(?:killing|harming)\s+(?:your|my)\s*self"
    r"|(?:most\s+(?:effective|reliable|lethal|painless)|least\s+painful)"
    r"\s+(?:method\s+(?:of|to)|way\s+to)\s+(?:suicide|kill(?:ing)?\s+(?:your|my)\s*self)"
    r"|(?:kill|harm)\s+(?:your|my)\s*self\s+by\b"
    r")",
    re.IGNORECASE,
)

# ── Illegal instruction patterns ─────────────────────────────────────────────
_ILLEGAL_SYNTH_VERB_RE = re.compile(
    r"\b(?:synthesize|manufacture|produce|cook|make|extract|prepare|acquire|mix|combine)\b",
    re.IGNORECASE,
)
_ILLEGAL_DRUG_RE = re.compile(
    r"\b(?:methamphetamine|meth|heroin|fentanyl|cocaine|crack\s+cocaine|"
    r"MDMA|ecstasy|LSD|ketamine|GHB)\b",
    re.IGNORECASE,
)
_ILLEGAL_INSTRUCTION_MARKER_RE = re.compile(
    r"\b(?:how\s+to|step[s]?\b|recipe\b|instruction[s]?\b|"
    r"you\s+(?:need|will\s+need|should|can|must)\b|"
    r"here['\u2019]?s\s+how|"
    r"first[,\s]|then[,\s]|next[,\s]|finally[,\s])\b"
    r"|\b\d+[.)]\s",
    re.IGNORECASE,
)
_ILLEGAL_EXPLOSIVE_RE = re.compile(
    r"(?:"
    r"\b(?:make|build|construct|assemble|create|craft)\b.{0,60}"
    r"\b(?:bomb|explosive|IED|molotov|pipe\s*bomb|grenade|C4|ANFO|TATP|detonator)\b"
    r"|\b(?:bomb|explosive|IED|pipe\s*bomb)\b.{0,60}"
    r"\b(?:make|build|construct|assemble)\b"
    r")",
    re.IGNORECASE | re.DOTALL,
)
_ILLEGAL_FIREARM_RE = re.compile(
    r"\b(?:convert|modify|alter|transform)\b.{0,60}"
    r"\b(?:full[\s\-]?auto(?:matic)?|select[\s\-]?fire|machine\s+gun|"
    r"giggle\s+switch|auto\s+sear)\b",
    re.IGNORECASE | re.DOTALL,
)
_ILLEGAL_FORGERY_RE = re.compile(
    r"\b(?:forge|forging|counterfeit|fabricate|falsify)\b.{0,60}"
    r"\b(?:passport|driver[\s'\u2019]?s?\s+licen[sc]e|ID\s+card|"
    r"identity\s+document|birth\s+certificate|social\s+security|"
    r"currency|banknote)\b",
    re.IGNORECASE | re.DOTALL,
)

# ── Targeted defamation patterns ──────────────────────────────────────────────
_DEFAM_LABEL_RE = re.compile(
    r"\b(?:pedophile|child\s+(?:molester|abuser|predator)|rapist|"
    r"sex\s+offender|murderer|serial\s+killer|terrorist|"
    r"fraudster|con\s+(?:man|artist))\b",
    re.IGNORECASE,
)
_DEFAM_ASSERTION_RE = re.compile(
    r"\b(?:is|was|has\s+been|remains?)\s+(?:a|an)\b",
    re.IGNORECASE,
)
_DEFAM_NAME_RE = re.compile(
    r"\b(?!(?:The|This|That|These|Those|An?)\s)[A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}\b",
)
_DEFAM_HEDGE_RE = re.compile(
    r"\b(?:alleged(?:ly)?|accused|charged|convicted|suspected|reportedly|"
    r"claimed|according\s+to|sources?|prosecutors?|court|authorities)\b",
    re.IGNORECASE,
)

# Shared negation prefix guard (self-harm + illegal instruction)
_NEGATION_PREFIX_RE = re.compile(
    r"\b(?:cannot|can['\u2019]?t|won['\u2019]?t|will\s+not|unable\s+to|"
    r"(?:do\s+not|don['\u2019]?t)\s+(?:provide|help|assist|give|share|tell)|"
    r"not\s+(?:able|going)\s+to\s+(?:provide|help|tell))\b",
    re.IGNORECASE,
)

# Refusal frame — LLM explicitly declining to help. Responses matching this
# pattern are meta-speech acts, not world claims: skip extraction-empty guard
# and claim loop to avoid false UNRESOLVED_REFERENT / HALLUCINATED_ENTITY flags.
_REFUSAL_FRAME_RE = re.compile(
    r"\b(?:i\s+(?:cannot|can['\u2019]?t|won['\u2019]?t|will\s+not|am\s+unable\s+to|"
    r"don['\u2019]?t\s+(?:provide|help|assist))|"
    r"i['\u2019]?m\s+unable\s+to|"
    r"i['\u2019]?m\s+not\s+(?:going|able)\s+to\s+(?:provide|help|share|give))\b",
    re.IGNORECASE,
)

# Crisis/safety context near a phone number — exempts it from PII detection.
# Hotlines and emergency numbers in refusal responses are not personal PII.
_CRISIS_PHONE_CONTEXT_RE = re.compile(
    r"\b(?:crisis|hotline|lifeline|prevention|text\s+line|helpline|"
    r"988|suicide|self.?harm|emergency\s+service|call\s+for\s+help)\b",
    re.IGNORECASE,
)

# Role/service email prefixes — not personal PII. Exempt from SENSITIVE_PII_EXPOSURE.
_ROLE_EMAIL_RE = re.compile(
    r"^(?:support|info|help|sales|admin|contact|noreply|no-reply|"
    r"hello|team|service|billing|abuse|postmaster|webmaster|"
    r"feedback|careers|press|media|security)@",
    re.IGNORECASE,
)

# Epistemic disclaimer patterns — sentences expressing the model's inability
# to verify or confirm. Claims extracted from these clauses are not world claims.
_EPISTEMIC_DISCLAIMER_RE = re.compile(
    r"\bi\s+can(?:not|'t)\b"
    r"|\bwithout\s+access\s+to\b"
    r"|\bwould\s+require\s+(?:me\s+to\s+)?speculate\b"
    r"|\bnot\s+(?:been\s+)?established\s+in\s+the\s+available\b"
    r"|\bi\s+(?:cannot|can't)\s+(?:confirm|provide|verify|explain|determine)\b"
    r"|\bi'?m\s+unable\s+to\b"
    r"|\bi\s+don'?t\s+have\s+enough\s+information\b",
    re.IGNORECASE,
)

from aurora_lens.pef.span import Span
from aurora_lens.pef.state import PEFState, Relationship
from aurora_lens.interpret.base import ExtractionBackend
from aurora_lens.interpret.schema import ExtractionResult, ExtractedClaim
from .flags import Flag, FlagType


class Checker:
    """Compare LLM response claims against PEF ground truth."""

    def __init__(self, backend: ExtractionBackend):
        self._backend = backend

    async def check(self, response_text: str, pef: PEFState, user_input: str | None = None) -> list[Flag]:
        """Extract claims from LLM response and verify against PEF state.

        Returns a list of flags (empty = clean response).
        When extraction fails (extraction_error), returns EXTRACTION_FAILED flag
        so governance can intervene instead of raising.
        """
        result = await self._backend.extract(response_text, pef)
        flags: list[Flag] = []

        # First-person detection: when user speaks in first person ("I've had chest
        # pain", "my arm hurts"), conversational pronouns in the LLM response
        # (it/its/they/them/their/these/those) are back-references to what the user
        # described — not LLM-invented world claims requiring PEF grounding.
        is_first_person: bool = _is_first_person_input(user_input) if user_input else False
        has_third_party: bool = bool(_THIRD_PARTY_RE.search(user_input)) if user_input else False

        # Words from user_input that also appear in the LLM response — secondary
        # back-reference signal when user did not speak in first person.
        user_echoed_words: frozenset[str] = frozenset()
        if user_input:
            user_echoed_words = _content_words(user_input) & _content_words(response_text)

        if result.extraction_error:
            err = result.extraction_error
            reason = err.get("reason", "UNKNOWN")
            snippet = err.get("raw_preview", "")[:100]
            flags.append(Flag(
                flag_type=FlagType.EXTRACTION_FAILED,
                entity_name="extraction",
                claim=f"Extraction backend returned invalid output: {reason}",
                evidence=snippet or str(err),
                severity="error",
                extraction_diagnostic=err,
            ))
            return flags

        # Raw-text scans — run before extraction-empty guard, independent of
        # claim extraction. Organized by flag axis.
        # Axis 3 (normative veto — hard-stop always):
        flags.extend(self._check_medical_dosage(response_text))
        flags.extend(self._check_numeric_medical_instruction(response_text))
        flags.extend(self._check_emergency_triage(response_text))
        flags.extend(self._check_self_harm_instruction(response_text))
        flags.extend(self._check_illegal_instruction(response_text))
        flags.extend(self._check_targeted_defamation(response_text))
        # Axis 3 (normative veto — verify-or-refuse, mode-dependent):
        flags.extend(self._check_professional_directive(response_text))
        # Axis 3: PII exposure — deterministic regex (Phase 8)
        flags.extend(self._check_pii_exposure(response_text))
        # Axis 1 (epistemic — regulatory):
        flags.extend(self._check_regulatory_claims(response_text))

        # Refusal frame guard: if the response is a meta-speech refusal, skip
        # extraction-empty and claim-level checks. Refusals are not world claims.
        if _REFUSAL_FRAME_RE.search(response_text):
            return flags

        MIN_LEN = 50  # Avoid flagging short refusals like "I don't know about Bob."
        text_len = len(response_text.strip())
        all_empty = not result.claims and not result.entity_mentions
        if text_len >= MIN_LEN and all_empty:
            flags.append(Flag(
                flag_type=FlagType.EXTRACTION_EMPTY,
                entity_name="extraction",
                claim="Extraction produced no admissible structure.",
                evidence="Extraction produced no admissible structure.",
                severity="error",
            ))
            return flags

        for claim in result.claims:
            claim_flags = self._check_claim(claim, pef, result.span, user_echoed_words, is_first_person, has_third_party)
            flags.extend(claim_flags)

        return flags

    def _check_claim(
        self,
        claim: ExtractedClaim,
        pef: PEFState,
        response_span: Span,
        user_echoed_words: frozenset[str] = frozenset(),
        is_first_person: bool = False,
        has_third_party: bool = False,
    ) -> list[Flag]:
        """Check a single claim against PEF state."""
        flags: list[Flag] = []

        # Skip first-person pronoun subjects — these are model meta-speech, not
        # world claims requiring PEF grounding.
        if claim.subject.lower() in _FIRST_PERSON:
            return []

        # Skip if the full clause is an epistemic disclaimer or capability statement.
        # Extraction often produces claims from sentences like "I cannot explain X"
        # that are not factual assertions about the world.
        if _EPISTEMIC_DISCLAIMER_RE.search(claim.evidence):
            return []

        # Look up subject entity
        entity = pef.find_entity_by_name(claim.subject)

        if entity is None:
            # Anaphoricity test: only block when the subject is a pronoun or
            # definite description that presupposes a prior PEF antecedent.
            # New concept literals (domain terms, bare nouns, proper nouns not
            # yet in PEF) enter cleanly — they are not anaphoric references.
            if claim.relation not in ("IS",):
                subj = (claim.subject or "").strip()
                subj_lower = subj.lower()

                # Multi-word bare NPs → new concept literal, skip.
                # Exception: definite descriptions do presuppose an antecedent.
                if " " in subj and not _is_definite_description(subj):
                    return []

                # Pronoun / demonstrative → requires prior PEF grounding.
                if subj_lower in _REFERENT_PRONOUNS:
                    # Back-reference exemption: conversational pronouns
                    # (it/its/they/them/their/these/those) are exempt when the user
                    # spoke in first person (describing their own experience) OR
                    # when the response echoes content words from user_input.
                    # Rationale: "I've had chest pain... it's gone now" → LLM's "it"
                    # refers to the pain the user described; "these symptoms" refers
                    # to what the user reported. These are conversational anaphora,
                    # not LLM-invented world claims requiring PEF grounding.
                    if subj_lower in _CONVERSATIONAL_PRONOUNS and (is_first_person or user_echoed_words):
                        return []
                    # Crisis/third-party exemption: gendered pronouns (she/her/he/him)
                    # are exempt only when the user (a) spoke in first person AND
                    # (b) explicitly mentioned a third party ("my daughter", "my patient",
                    # etc.). is_first_person alone is not enough — it fires on almost
                    # every message and would create broad pronoun amnesty.
                    # Neutral pronouns (they/them/their) are already handled above via
                    # _CONVERSATIONAL_PRONOUNS when is_first_person is True.
                    if subj_lower in ("she", "her", "he", "him", "his", "hers") \
                            and is_first_person \
                            and has_third_party:
                        return []
                    flags.append(Flag(
                        flag_type=FlagType.UNRESOLVED_REFERENT,
                        entity_name=subj,
                        claim=f"{subj} {claim.relation} {claim.obj}",
                        evidence=f"Unresolved referent: '{subj}'",
                    ))
                    return flags

                # Definite description → requires a unique prior antecedent.
                if _is_definite_description(subj):
                    # Back-reference exemption: when user spoke in first person,
                    # definite descriptions like "these symptoms" / "the chest pain"
                    # refer to what the user described — not LLM-invented entities.
                    # Also exempt when content words overlap with echoed user content.
                    if is_first_person or (user_echoed_words and (_content_words(subj) & user_echoed_words)):
                        return []
                    flags.append(Flag(
                        flag_type=FlagType.UNRESOLVED_REFERENT,
                        entity_name=subj,
                        claim=f"{subj} {claim.relation} {claim.obj}",
                        evidence=f"Unresolved definite description: '{subj}'",
                    ))
                    return flags

                # Bare noun / proper noun → new concept literal, admit cleanly.
                return []
            return flags

        # Entity exists — check if unresolved placeholder
        if not entity.resolved:
            # "Introduced" policy: unresolved placeholders were mentioned
            # but never asserted about. Asserting new facts about them
            # is a hallucination.
            flags.append(Flag(
                flag_type=FlagType.HALLUCINATED_ATTRIBUTE,
                entity_name=claim.subject,
                claim=f"{claim.subject} {claim.relation} {claim.obj}",
                evidence="Entity exists only as unresolved placeholder — no established facts",
            ))
            return flags

        # Entity is resolved — check claim against existing relationships
        subject_rels = pef.get_relationships_for_subject(entity.id)

        # Check for contradiction
        contradiction = self._check_contradiction(claim, subject_rels, pef)
        if contradiction:
            flags.append(contradiction)
            return flags

        # Check for time-smear
        time_smear = self._check_time_smear(claim, subject_rels, response_span)
        if time_smear:
            flags.append(time_smear)

        # Check for hallucinated attributes/events
        hallucination = self._check_hallucination(claim, subject_rels, pef)
        if hallucination:
            flags.append(hallucination)

        return flags

    def _check_contradiction(
        self,
        claim: ExtractedClaim,
        existing_rels: list[Relationship],
        pef: PEFState,
    ) -> Flag | None:
        """Check if the claim contradicts an established fact.

        Contradiction = asserted in PEF + negated in response (or vice versa).
        """
        for rel in existing_rels:
            if rel.relation != claim.relation:
                continue

            # Get the object text for comparison
            rel_obj = self._get_rel_object_text(rel, pef)
            if rel_obj is None:
                continue

            if rel_obj.lower() != claim.obj.lower():
                continue

            # Same subject, same relation, same object — check negation
            if rel.negated != claim.negated:
                neg_word = "negated" if claim.negated else "asserted"
                return Flag(
                    flag_type=FlagType.CONTRADICTED_FACT,
                    entity_name=claim.subject,
                    claim=f"{claim.subject} {'NOT ' if claim.negated else ''}{claim.relation} {claim.obj}",
                    evidence=f"PEF has this as {'negated' if rel.negated else 'asserted'}, "
                             f"but response {neg_word} it (turn {rel.source_turn})",
                    severity="error",
                )

        return None

    def _check_time_smear(
        self,
        claim: ExtractedClaim,
        existing_rels: list[Relationship],
        response_span: Span,
    ) -> Flag | None:
        """Check for time-smear: combining facts from different spans.

        A claim is TIME_SMEAR if it requires combining facts from different
        spans without an explicit span transition signal.
        """
        for rel in existing_rels:
            if rel.relation != claim.relation:
                continue
            # If PEF has this fact in PAST but the claim presents it as PRESENT
            if rel.span == Span.PAST and claim.span == Span.PRESENT:
                return Flag(
                    flag_type=FlagType.TIME_SMEAR,
                    entity_name=claim.subject,
                    claim=f"{claim.subject} {claim.relation} {claim.obj} (presented as present)",
                    evidence=f"Established as past-span fact (turn {rel.source_turn})",
                )
            # Vice versa: PEF has PRESENT but claim uses PAST
            if rel.span == Span.PRESENT and claim.span == Span.PAST:
                return Flag(
                    flag_type=FlagType.TIME_SMEAR,
                    entity_name=claim.subject,
                    claim=f"{claim.subject} {claim.relation} {claim.obj} (presented as past)",
                    evidence=f"Established as present-span fact (turn {rel.source_turn})",
                )

        return None

    def _check_hallucination(
        self,
        claim: ExtractedClaim,
        existing_rels: list[Relationship],
        pef: PEFState,
    ) -> Flag | None:
        """Check for hallucinated attributes/events.

        Only flags when the entity IS resolved (has established facts)
        but the specific claim has no PEF support.
        """
        # Check if ANY relationship supports this claim
        for rel in existing_rels:
            if rel.relation != claim.relation:
                continue

            rel_obj = self._get_rel_object_text(rel, pef)
            if rel_obj is None:
                continue

            if rel_obj.lower() == claim.obj.lower():
                # Found support — not hallucinated
                return None

        # No support found — determine flag type
        # Check if ANY relationship with this relation type exists
        has_same_relation = any(r.relation == claim.relation for r in existing_rels)

        if has_same_relation:
            # Entity has facts with this relation, but not this specific one
            return Flag(
                flag_type=FlagType.HALLUCINATED_ATTRIBUTE,
                entity_name=claim.subject,
                claim=f"{claim.subject} {claim.relation} {claim.obj}",
                evidence=f"No PEF support for this specific {claim.relation} fact",
            )

        # Entity has no facts with this relation type at all
        if existing_rels:
            return Flag(
                flag_type=FlagType.HALLUCINATED_EVENT,
                entity_name=claim.subject,
                claim=f"{claim.subject} {claim.relation} {claim.obj}",
                evidence=f"No {claim.relation} relationships established for this entity",
            )

        return None

    def _check_medical_dosage(self, text: str) -> list[Flag]:
        """Detect clinical dosage recommendations (normative veto — axis 3).

        Two sub-cases, both severity=error, both map to HARD_STOP via policy.
        Neither depends on PEF support — the claim being true is irrelevant.

        PEDIATRIC_DOSAGE_RECOMMENDATION
            Pediatric indicator + dosage amount.  Most severe sub-case.

        MEDICAL_DOSAGE_RECOMMENDATION
            Explicit patient instruction verb + dosage amount, no pediatric
            indicator.  "Recommended dosage is X mg" without an instruction
            verb does NOT fire (informational, not a patient directive).
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()

        # Pediatric indicators (presence of any is sufficient)
        pediatric = any(
            p in lower
            for p in (
                "child", "children", "pediatric", "infant", "toddler", "baby",
                "year-old", "month-old", "year old", "month old",
            )
        ) or bool(re.search(r"\d+\s*kg\b", lower))  # weight-based dosing

        # Dosage amount: numeric + medical unit
        dosage_amount = bool(
            re.search(r"\d+\s*(mg|ml|mg/kg|mcg)\b", lower, re.IGNORECASE)
            or re.search(r"\d+[-–]\d+\s*mg\b", lower)  # range: "720-810 mg"
        )

        if pediatric and dosage_amount:
            return [Flag(
                flag_type=FlagType.PEDIATRIC_DOSAGE_RECOMMENDATION,
                entity_name="medical",
                claim="Response contains specific dosing guidance for a pediatric patient",
                evidence="Pediatric indicator + dosage amount detected",
                severity="error",
            )]

        # General adult dosage — requires an explicit instruction verb so that
        # informational phrases like "the recommended dosage is 720 mg" don't fire.
        instruction_verb = bool(
            re.search(
                r"\b(take|give|administer|dosed?\s+at|prescribe[sd]?)\b",
                lower,
            )
        )
        # Descriptor guard: "typically/usually/commonly taken at X mg" is descriptive,
        # not a patient directive — exempt unless second-person framing is also present.
        descriptor_only = bool(
            re.search(r"\b(?:typically|usually|commonly|generally|often)\b", lower)
            and not re.search(r"\b(?:you|your|patient|the\s+patient)\b", lower)
        )
        if dosage_amount and instruction_verb and not descriptor_only:
            return [Flag(
                flag_type=FlagType.MEDICAL_DOSAGE_RECOMMENDATION,
                entity_name="medical",
                claim="Response contains an explicit patient dosing instruction",
                evidence="Instruction verb + dosage amount detected",
                severity="error",
            )]

        return []

    def _check_regulatory_claims(self, text: str) -> list[Flag]:
        """Detect unsupported regulatory/approval assertions (epistemic failure — axis 1).

        Asserting FDA/EMA/CE approval status is an epistemic claim that requires
        verifiable support (labeling data, approval records).  Without PEF or
        context evidence, these are UNVERIFIED_REGULATORY_CLAIM.

        This is NOT a normative veto: a sourced, hedged response is acceptable.
        Governance default: FORCE_REVISE (cite support or hedge).
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()

        regulatory = bool(
            re.search(r"\bfda[- ]?(?:approved|cleared|authorized|licensed)\b", lower)
            or re.search(r"\bce[- ]?(?:mark(?:ed)?|certified|approved)\b", lower)
            or re.search(r"\bema[- ]?(?:approved|authorized)\b", lower)
            or re.search(
                r"\b(?:approved|authorized|cleared)\s+by\s+(?:the\s+)?(?:fda|ema|who|cdc|mhra)\b",
                lower,
            )
        )

        if regulatory:
            return [Flag(
                flag_type=FlagType.UNVERIFIED_REGULATORY_CLAIM,
                entity_name="regulatory",
                claim="Response asserts regulatory/approval status",
                evidence="Regulatory claim (FDA/EMA/CE/WHO) detected without verifiable support",
                severity="warning",
            )]
        return []

    def _check_numeric_medical_instruction(self, text: str) -> list[Flag]:
        """Detect numeric clinical instructions beyond simple dosage (normative veto — axis 3).

        Catches: titration/taper/wean schedules, infusion and drip rates,
        insulin/basal/bolus adjustments.  All are 'numbers that cause action'
        in a medical domain — equivalent to dosage even when the word 'dose'
        is absent.  "How to taper" is dosage in a trench coat.

        Requires: action word + numeric value + medical unit/context.
        This prevents candle-taper, tapered jeans, etc. from false-firing.
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()

        medical_unit = bool(
            re.search(r"\b(mg|ml|mcg|units?|tablet|capsule|pill|dose)\b", lower)
        )

        # Titration / taper / wean schedules: action + numeric + medical unit
        taper_action = bool(re.search(r"\b(titrat\w*|taper\w*|wean\w*)\b", lower))
        if taper_action and re.search(r"\d+", lower) and medical_unit:
            return [Flag(
                flag_type=FlagType.NUMERIC_MEDICAL_INSTRUCTION,
                entity_name="medical",
                claim="Response contains a titration, taper, or wean schedule",
                evidence="Taper/titration action + numeric value + medical unit detected",
                severity="error",
            )]

        # Infusion / drip rates: explicit rate or rate expression
        infusion = bool(
            re.search(r"\d+\s*(?:ml/hr|ml\s+per\s+hour|units?/hr|mg/hr|mcg/hr)\b", lower)
            or re.search(r"\b(?:infusion|drip)\s+rate\b.{0,40}\d+", lower)
            or re.search(r"\d+.{0,10}\b(?:infusion|drip)\s+rate\b", lower)
        )
        if infusion:
            return [Flag(
                flag_type=FlagType.NUMERIC_MEDICAL_INSTRUCTION,
                entity_name="medical",
                claim="Response specifies an infusion or drip rate",
                evidence="Infusion/drip rate with numeric value detected",
                severity="error",
            )]

        # Insulin / basal / bolus adjustments: adjustment verb + insulin type + units
        insulin_type = bool(re.search(r"\b(insulin|basal|bolus)\b", lower))
        adjust_verb = bool(
            re.search(r"\b(adjust|increase|decrease|add|reduce|titrate|change)\b", lower)
        )
        insulin_units = bool(re.search(r"\d+\s*(?:units?|u)\b", lower))
        if insulin_type and adjust_verb and insulin_units:
            return [Flag(
                flag_type=FlagType.NUMERIC_MEDICAL_INSTRUCTION,
                entity_name="medical",
                claim="Response specifies an insulin dose adjustment",
                evidence="Insulin/basal/bolus adjustment + unit quantity detected",
                severity="error",
            )]

        return []

    def _check_emergency_triage(self, text: str) -> list[Flag]:
        """Detect definitive emergency triage or false reassurance (normative veto — axis 3).

        The model must never be the last voice someone listens to on
        whether to seek emergency care.  Allowed: encourage calling
        emergency services or seeking care.  Flagged: dismissing the
        need for emergency care or making a definitive triage call.
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()

        # Require medical/symptom context to suppress false positives
        # ("a power outage is not an emergency" should not fire)
        medical_context = bool(
            re.search(
                r"\b(symptom|pain|chest|breath\w*|bleed\w*|wound|injur\w*|fever|"
                r"dizzy|faint\w*|unconscious|stroke|heart|pulse|vomit\w*|seizure|"
                r"swollen|burn|allerg\w*|react\w*|overdos\w*)\b",
                lower,
            )
        )

        # "not an emergency" / "not a medical emergency" — categorical dismissal
        # an? matches both "a" and "an"
        not_emergency = bool(
            re.search(r"\bnot\s+(?:an?\s+)?(?:medical\s+)?emergency\b", lower)
        )

        # Dissuading from seeking emergency care
        dismissal = bool(
            re.search(
                r"\b(?:don['\u2019]?t|do\s+not|doesn['\u2019]?t|no\s+need\s+to)"
                r"\s+(?:need\s+to\s+)?(?:go|call|visit|see)\b"
                r".{0,60}\b(?:hospital|er\b|emergency\s+room|ambulance|"
                r"911|999|112|urgent\s+care|paramedic)\b",
                lower,
            )
            or re.search(
                r"\b(?:can|should)\s+wait\b.{0,40}"
                r"\b(?:hospital|doctor|emergency|urgent\s+care)\b",
                lower,
            )
        )

        if (not_emergency and medical_context) or dismissal:
            return [Flag(
                flag_type=FlagType.EMERGENCY_TRIAGE_GUIDANCE,
                entity_name="triage",
                claim="Response dismisses need for emergency care or makes definitive triage call",
                evidence="Reassurance or dismissal pattern in medical context detected",
                severity="error",
            )]

        return []

    def _check_professional_directive(self, text: str) -> list[Flag]:
        """Detect individualized professional directives in regulated domains (verify-or-refuse).

        Catches 'you should do X' in medical, legal, and financial contexts
        when it constitutes a personalized professional determination — not
        just general information.

        Governance default (public mode): HARD_STOP.
        Enterprise mode: FORCE_REVISE with verified/cited sources.

        Legal has its own dosage analogy: jurisdiction + procedure + deadline.
        A bad deadline is a legal overdose.
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()
        flags: list[Flag] = []

        # ── High-confidence standalone signals ────────────────────────────
        # These fire without requiring a directive verb because the phrasing
        # is unambiguously individualized.

        # "Your deadline is X" / "you have N days to …" — legal overdose risk
        deadline_directive = bool(
            re.search(r"\byour\s+deadline\b", lower)
            or re.search(r"\byou\s+have\s+\d+\s+days?\s+to\b", lower)
        )
        if deadline_directive:
            flags.append(Flag(
                flag_type=FlagType.PERSONALIZED_LEGAL_ADVICE,
                entity_name="legal",
                claim="Response specifies a personal legal deadline",
                evidence="Personalized deadline directive detected (your deadline / you have N days)",
                severity="warning",
            ))

        # "You qualify for the deduction/credit/benefit"
        qualifies_claim = bool(re.search(r"\byou\s+qualify\s+for\b", lower))
        if qualifies_claim:
            flags.append(Flag(
                flag_type=FlagType.PERSONALIZED_FINANCIAL_ADVICE,
                entity_name="financial",
                claim="Response asserts the user qualifies for a specific financial benefit",
                evidence="'You qualify for' detected",
                severity="warning",
            ))

        # ── Second-person + directive gate ────────────────────────────────
        # General action-based patterns require both a second-person address
        # and an explicit directive verb to avoid false positives.
        second_person = bool(re.search(r"\b(you|your)\b", lower))
        directive = bool(
            re.search(
                r"\b(should|need\s+to|must|have\s+to|ought\s+to|"
                r"i\s+recommend|i\s+advise|i\s+suggest)\b",
                lower,
            )
        )

        if not (second_person and directive):
            return flags  # return standalone signals collected above

        # ── Medical directive ──────────────────────────────────────────────
        # "You should take/start/stop this medication"
        # Safe referrals ("you should see a doctor") are NOT flagged —
        # they require treatment_object, not just treatment_action.
        #
        # Safety-referral exemption: advising to tell doctor about allergy, or
        # not take a drug due to allergy, is protective — not a treatment directive.
        # E.g. "make sure your doctor knows about your seafood allergy" before
        # taking Bactrim. Blocking that advice is harmful.
        _safety_referral = bool(
            re.search(
                r"\b(?:make\s+sure|tell|inform|let)\b.{0,40}"
                r"\b(?:doctor|physician|pharmacist)\b.{0,40}"
                r"\b(?:know|about|regarding)\b.{0,30}\b(?:allerg|allergic)\b",
                lower,
            )
            or re.search(
                r"\b(?:don['\u2019]?t|do\s+not)\s+(?:take|use)\b.{0,40}"
                r"\b(?:if|because|when)\b.{0,30}\b(?:allerg|allergic)\b",
                lower,
            )
            or re.search(
                r"\b(?:check|verify|confirm)\b.{0,30}"
                r"\b(?:with)\b.{0,30}\b(?:doctor|physician|pharmacist)\b"
                r".{0,30}\b(?:before)\b.{0,20}\b(?:taking|using)\b",
                lower,
            )
        )
        # Actionable dosing directive — catches specific instruction patterns
        # beyond the treatment_action+treatment_object pair. Used to prevent the
        # safety-referral exemption from suppressing a co-located dosing instruction.
        _dosing_directive = bool(
            re.search(r"\b\d+\s*(?:mg|mcg|ml|g)\b", lower)
            or re.search(r"\b(?:twice|three\s+times|once)\s+(?:a\s+)?(?:day|daily)\b", lower)
            or re.search(r"\bevery\s+\d+\s+hours?\b", lower)
            or re.search(r"\btake\s+(?:two|three|four|\d+)\s+(?:tablets?|pills?|capsules?)\b", lower)
            or re.search(r"\b(?:start\s+with|increase\s+to|titrate)\b", lower)
        )

        treatment_action = bool(
            re.search(r"\b(take|start|stop|discontinue|use|apply|avoid|try)\b", lower)
        )
        treatment_object = bool(
            re.search(
                r"\b(medication|drug|pill|tablet|capsule|antibiotic|medicine|"
                r"prescription|treatment|therapy|dose|steroid|insulin|cream|"
                r"ointment|injection|supplement|vaccine)\b",
                lower,
            )
        )
        # Exemption is local, not global: _safety_referral suppresses
        # PERSONALIZED_MEDICAL_ADVICE only when no actionable dosing instruction
        # appears in the same response. If both patterns co-occur (safety preamble
        # + dosing instruction), the treatment check wins — no compositional bypass.
        if treatment_action and treatment_object and not (_safety_referral and not _dosing_directive):
            flags.append(Flag(
                flag_type=FlagType.PERSONALIZED_MEDICAL_ADVICE,
                entity_name="medical",
                claim="Response issues a personalized medical treatment directive",
                evidence="Second-person directive + treatment action + treatment object detected",
                severity="warning",
            ))

        # ── Legal directive ────────────────────────────────────────────────
        # "You should file / you need to appeal" — legal action + legal context
        legal_action = bool(
            re.search(
                r"\b(file|submit|appeal|petition|sue|contest|apply|claim|"
                r"notify|sign|dispute|register|comply)\b",
                lower,
            )
        )
        legal_context = bool(
            re.search(
                r"\b(court|lawsuit|attorney|lawyer|statute|jurisdiction|"
                r"deadline|compliance|regulation|legal|case|contract|"
                r"breach|tort|liability|appeal|notice|filing)\b",
                lower,
            )
        )
        if legal_action and legal_context and not deadline_directive:
            # Skip if deadline_directive already produced a flag for this text
            flags.append(Flag(
                flag_type=FlagType.PERSONALIZED_LEGAL_ADVICE,
                entity_name="legal",
                claim="Response issues a personalized legal filing directive",
                evidence="Second-person directive + legal action + legal context detected",
                severity="warning",
            ))

        # ── Financial directive ────────────────────────────────────────────
        # "You should invest / buy / sell"
        financial_action = bool(
            re.search(
                r"\b(invest|buy|sell|contribute|withdraw|transfer|"
                r"deduct|put|move|allocate|diversify)\b",
                lower,
            )
        )
        financial_context = bool(
            re.search(
                r"\b(stock|bond|fund|portfolio|401k|ira|roth|tax|deduction|"
                r"credit|investment|broker|etf|dividend|mutual\s+fund|"
                r"retirement|annuity|capital\s+gain)\b",
                lower,
            )
        )
        if financial_action and financial_context and not qualifies_claim:
            flags.append(Flag(
                flag_type=FlagType.PERSONALIZED_FINANCIAL_ADVICE,
                entity_name="financial",
                claim="Response issues a personalized financial directive",
                evidence="Second-person directive + financial action + financial context detected",
                severity="warning",
            ))

        return flags

    def _check_self_harm_instruction(self, text: str) -> list[Flag]:
        """Axis 3 HARD_STOP: procedural self-harm guidance.

        Fires on instructional structure (how-to phrasing, step sequences,
        comparative optimization, or mechanism-level guidance) directed at
        self-harm or suicide.

        Does not fire on descriptive, academic, policy, legal, fictional,
        or refusal-framed content.

        Deterministic pattern matching; may conservatively over-trigger
        when instructional phrasing appears in quoted or narrative context.
        """
        if not text or len(text.strip()) < 20:
            return []

        m = _SH_INSTRUCTION_RE.search(text)
        if not m:
            return []

        prefix = text[max(0, m.start() - 120): m.start()]
        if _NEGATION_PREFIX_RE.search(prefix):
            return []

        return [Flag(
            flag_type=FlagType.SELF_HARM_INSTRUCTION,
            entity_name="self_harm",
            claim="Response contains procedural self-harm or suicide guidance",
            evidence=f"Instructional self-harm pattern detected: {m.group()!r}",
            severity="error",
        )]

    def _check_illegal_instruction(self, text: str) -> list[Flag]:
        """Axis 3 HARD_STOP: procedural enablement of serious criminal acts.

        Fires when output provides actionable guidance (materials, steps,
        tools, sequencing, optimization) for drug synthesis, explosive
        construction, illegal firearm modification, or document forgery.

        Does not fire on factual, legal, policy, historical, academic,
        defensive, or refusal-framed discussion.

        Deterministic structural matching; requires instruction markers
        for drug synthesis branch to avoid descriptive false positives.
        """
        if not text or len(text.strip()) < 20:
            return []

        def _negation_guard(m) -> bool:
            prefix = text[max(0, m.start() - 120): m.start()]
            return bool(_NEGATION_PREFIX_RE.search(prefix))

        # 1. Controlled substance synthesis: verb + drug proximity + instruction marker
        vm = _ILLEGAL_SYNTH_VERB_RE.search(text)
        dm = _ILLEGAL_DRUG_RE.search(text)
        if vm and dm and abs(vm.start() - dm.start()) <= 80 and not _negation_guard(vm):
            win_s = max(0, min(vm.start(), dm.start()) - 80)
            win_e = min(len(text), max(vm.end(), dm.end()) + 80)
            if _ILLEGAL_INSTRUCTION_MARKER_RE.search(text[win_s:win_e]):
                return [Flag(
                    flag_type=FlagType.ILLEGAL_INSTRUCTION,
                    entity_name="illegal",
                    claim="Response contains controlled substance synthesis instructions",
                    evidence=f"Synthesis verb {vm.group()!r} + drug {dm.group()!r} detected",
                    severity="error",
                )]

        # 2. Explosive / weapon construction
        em = _ILLEGAL_EXPLOSIVE_RE.search(text)
        if em and not _negation_guard(em):
            return [Flag(
                flag_type=FlagType.ILLEGAL_INSTRUCTION,
                entity_name="illegal",
                claim="Response contains explosive or weapon construction instructions",
                evidence=f"Explosive construction pattern detected: {em.group()[:60]!r}",
                severity="error",
            )]

        # 3. Illegal firearm modification
        fm = _ILLEGAL_FIREARM_RE.search(text)
        if fm and not _negation_guard(fm):
            return [Flag(
                flag_type=FlagType.ILLEGAL_INSTRUCTION,
                entity_name="illegal",
                claim="Response contains illegal firearm modification instructions",
                evidence=f"Firearm modification pattern detected: {fm.group()[:60]!r}",
                severity="error",
            )]

        # 4. Document forgery
        fgm = _ILLEGAL_FORGERY_RE.search(text)
        if fgm and not _negation_guard(fgm):
            return [Flag(
                flag_type=FlagType.ILLEGAL_INSTRUCTION,
                entity_name="illegal",
                claim="Response contains document forgery instructions",
                evidence=f"Forgery pattern detected: {fgm.group()[:60]!r}",
                severity="error",
            )]

        return []

    def _check_targeted_defamation(self, text: str) -> list[Flag]:
        """Axis 3 HARD_STOP: unhedged severe accusation against identifiable person.

        Fires when a severe criminal/moral label is directly attributed
        to a specific individual (name pattern + identity assertion),
        without local hedging language.

        Does not fire on reported allegations, convictions, policy debate,
        group generalizations, fiction, or criticism lacking criminal identity.

        Hedge exemption is local (same sentence or nearby window).
        Deterministic matching with sentence/window approximation.
        """
        if not text or len(text.strip()) < 20:
            return []

        lower = text.lower()

        label_m = _DEFAM_LABEL_RE.search(lower)
        if not label_m:
            return []

        # Local hedge check: same sentence as label only.
        # A hedge in a different sentence cannot sanitize an unhedged accusation.
        # (±80 char window removed — it allowed unrelated hedges in adjacent sentences
        # to suppress the flag when the hedge and label happened to be near each other.)
        sent_start = 0
        for i in range(label_m.start() - 1, -1, -1):
            if lower[i] in ".!?":
                sent_start = i + 1
                break
        sent_end = len(lower)
        for i in range(label_m.end(), len(lower)):
            if lower[i] in ".!?":
                sent_end = i + 1
                break
        if _DEFAM_HEDGE_RE.search(lower[sent_start:sent_end]):
            return []

        if not _DEFAM_ASSERTION_RE.search(lower):
            return []

        if not _DEFAM_NAME_RE.search(text):
            return []

        return [Flag(
            flag_type=FlagType.TARGETED_DEFAMATION,
            entity_name="defamation",
            claim=f"Response makes an unhedged defamatory accusation: {label_m.group()!r}",
            evidence="Named entity + assertion verb + unhedged severe accusation detected",
            severity="error",
        )]

    def _check_pii_exposure(self, text: str) -> list[Flag]:
        """Detect sensitive PII via regex (Phase 8). Deterministic, no LLM.

        Patterns: SSN (xxx-xx-xxxx), phone numbers, email addresses, card numbers.
        → SENSITIVE_PII_EXPOSURE. Policy: HARD_STOP (public) / FORCE_REVISE (enterprise).
        """
        if not text or len(text.strip()) < 10:
            return []

        matches: list[str] = []

        m = _PII_SSN_RE.search(text)
        if m:
            matches.append(f"SSN-like: {m.group()[:6]}***")

        m = _PII_PHONE_RE.search(text)
        if m:
            # Exempt crisis/safety hotline numbers cited in refusal context.
            ctx_start = max(0, m.start() - 100)
            ctx_end = min(len(text), m.end() + 100)
            if not _CRISIS_PHONE_CONTEXT_RE.search(text[ctx_start:ctx_end]):
                matches.append(f"phone: {m.group()[:10]}...")

        m = _PII_EMAIL_RE.search(text)
        if m:
            # Exempt role/service addresses (public contact points, not personal PII).
            if not _ROLE_EMAIL_RE.match(m.group()):
                matches.append(f"email: {m.group()[:15]}...")

        m = _PII_CARD_RE.search(text)
        if m:
            matches.append(f"card: ****{m.group()[-4:]}")

        if matches:
            return [Flag(
                flag_type=FlagType.SENSITIVE_PII_EXPOSURE,
                entity_name="pii",
                claim="Response contains sensitive PII (SSN, phone, email, or card number)",
                evidence="; ".join(matches),
                severity="warning",
            )]
        return []

    def _get_rel_object_text(self, rel: Relationship, pef: PEFState) -> str | None:
        """Get the textual representation of a relationship's object."""
        if rel.object_entity_id:
            obj_entity = pef.entities.get(rel.object_entity_id)
            return obj_entity.name if obj_entity else None
        if rel.object_literal is not None:
            return str(rel.object_literal)
        return None
