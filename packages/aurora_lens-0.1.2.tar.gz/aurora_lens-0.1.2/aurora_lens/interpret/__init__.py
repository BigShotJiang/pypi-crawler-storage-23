"""Interpretation layer — pluggable extraction backends."""

from .schema import ExtractedClaim, ExtractionResult
from .base import ExtractionBackend
from .pef_updater import update_pef, apply_prepopulated_claims

__all__ = [
    "ExtractedClaim",
    "ExtractionResult",
    "ExtractionBackend",
    "update_pef",
    "apply_prepopulated_claims",
]
