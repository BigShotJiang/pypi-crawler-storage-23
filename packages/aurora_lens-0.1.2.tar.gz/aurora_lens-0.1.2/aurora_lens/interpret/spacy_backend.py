"""spaCy-based extraction backend.

Deterministic, local NLP — independent of any LLM.
Implements ExtractionBackend using spaCy for entity/relationship extraction.

spaCy is imported lazily — this module is importable without spaCy installed.
Instantiating SpacyBackend without spaCy raises a clear runtime error.
"""

from __future__ import annotations

import asyncio
import re
from typing import Any, TYPE_CHECKING

from aurora_lens.pef.span import Span
from aurora_lens.pef.state import (
    PEFState,
    canonicalize_relation,
)
from aurora_lens.interpret.schema import ComparativeAmbiguity, ExtractedClaim, ExtractionResult
from aurora_lens.interpret.base import ExtractionBackend

if TYPE_CHECKING:
    import spacy
    from spacy.tokens import Doc, Token


# ── Span detection ───────────────────────────────────────────────────

_PAST_SIGNALS = {
    "was", "were", "had", "used to", "formerly", "previously",
    "once", "ago", "before", "back then",
}
_PRESENT_SIGNALS = {
    "is", "are", "has", "have", "now", "currently", "today",
}

# Patterns that strongly indicate past tense context
_PAST_PATTERNS = [
    re.compile(r"\bused\s+to\b", re.IGNORECASE),
    re.compile(r"\bback\s+then\b", re.IGNORECASE),
    re.compile(r"\b\w+\s+ago\b", re.IGNORECASE),
]


def detect_span(doc: Doc) -> Span:
    """Detect the dominant temporal span of a sentence.

    Uses verb tense morphology as primary signal, surface keywords as fallback.
    """
    past_score = 0
    present_score = 0

    for token in doc:
        if token.pos_ in ("VERB", "AUX"):
            morph = token.morph.get("Tense")
            if morph:
                if "Past" in morph:
                    past_score += 2
                elif "Pres" in morph:
                    present_score += 2

        lower = token.text.lower()
        if lower in _PAST_SIGNALS:
            past_score += 1
        elif lower in _PRESENT_SIGNALS:
            present_score += 1

    text = doc.text
    for pattern in _PAST_PATTERNS:
        if pattern.search(text):
            past_score += 3

    return Span.PAST if past_score > present_score else Span.PRESENT


# ── Pronoun detection ────────────────────────────────────────────────

_PRONOUNS = {"he", "she", "it", "they", "him", "her", "them", "his", "its", "their"}

# Possessive pronouns that can be ambiguous when multiple candidates exist
_POSSESSIVE_PRONOUNS = frozenset({"her", "his", "their", "its"})

# Subject- and object-position pronouns that can also be ambiguous
_SUBJECT_OBJECT_PRONOUNS: frozenset[str] = frozenset({
    "he", "him", "she", "her", "it",
    "they", "them", "that", "this", "these", "those",
})

# Determiners that mark definite NPs (presuppose a unique prior referent)
_DEFINITE_DETERMINERS: frozenset[str] = frozenset({"the", "that", "this", "those", "these"})


def _is_pronoun(token: Token) -> bool:
    return token.text.lower() in _PRONOUNS or token.pos_ == "PRON"


# ── Negation detection ───────────────────────────────────────────────

_NEGATION_DEPS = {"neg"}
_NEGATION_TOKENS = {"not", "n't", "never", "no", "neither", "nor", "doesn't", "don't", "didn't", "isn't", "aren't", "wasn't", "weren't", "hasn't", "haven't", "hadn't", "won't", "wouldn't", "couldn't", "shouldn't"}


def _is_negated(token: Token) -> bool:
    """Check if a token (typically a verb) is negated."""
    for child in token.children:
        if child.dep_ in _NEGATION_DEPS:
            return True
        if child.text.lower() in _NEGATION_TOKENS:
            return True
    return False


# ── SpacyBackend ────────────────────────────────────────────────────

class SpacyBackend(ExtractionBackend):
    """spaCy-based deterministic extraction backend.

    Requires spaCy to be installed: pip install aurora-lens[spacy]
    """

    def __init__(self, nlp: spacy.language.Language | None = None, model: str = "en_core_web_sm"):
        try:
            import spacy as _spacy
        except ImportError:
            raise ImportError(
                "SpacyBackend requires spaCy. Install it with: "
                "pip install aurora-lens[spacy]"
            ) from None

        if nlp is None:
            self._nlp = _spacy.load(model)
        else:
            self._nlp = nlp

    async def extract(self, text: str, pef: PEFState) -> ExtractionResult:
        """Extract entities, relationships, and span signals from text."""
        doc = await asyncio.to_thread(self._nlp, text)
        result = ExtractionResult()
        result.span = detect_span(doc)

        # Collect named entities and noun chunks
        result.entity_mentions = self._extract_entity_mentions(doc)

        # Extract SVO relationships from dependency parse
        result.claims = self._extract_claims(doc, result.span)

        # Resolve pronouns against the existing world
        result.pronoun_candidates = self._resolve_pronouns(doc, pef)

        # Detect possessive pronouns that cannot be uniquely resolved
        result.ambiguous_referents = self._detect_ambiguous_referents(doc, pef)

        # Detect comparative adjectives whose comparand is underdetermined
        result.comparative_ambiguities = self._detect_comparative_claims(doc, pef)

        return result

    def _extract_entity_mentions(self, doc: Doc) -> list[str]:
        """Extract named entities and proper noun chunks from spaCy doc."""
        mentions: list[str] = []

        # Named entities from NER
        for ent in doc.ents:
            if ent.label_ in ("PERSON", "ORG", "GPE", "LOC", "NORP", "FAC"):
                mentions.append(ent.text)

        # Proper nouns not caught by NER
        for token in doc:
            if token.pos_ == "PROPN" and token.text not in mentions:
                mentions.append(token.text)

        return mentions

    def _is_interrogative_sentence(self, sent: Any) -> bool:
        """Return True if this sentence is a question.

        Questions must not contribute claims to PEF state — they ask about
        the world rather than asserting facts about it.  Two heuristics:
        1. Sentence text ends with "?" (orthographic signal).
        2. Root verb has a WH-word (WP/WRB/WDT) as its subject (syntactic).
        """
        if sent.text.strip().endswith("?"):
            return True
        for token in sent:
            if token.dep_ == "ROOT":
                for child in token.children:
                    if child.dep_ in ("nsubj", "nsubjpass") and child.tag_ in ("WP", "WRB", "WDT"):
                        return True
        return False

    def _extract_claims(self, doc: Doc, span: Span) -> list[ExtractedClaim]:
        """Extract subject-verb-object claims from dependency parse.

        Interrogative sentences are skipped: questions do not assert facts
        and must not create PEF state entries.
        """
        claims: list[ExtractedClaim] = []

        # Build set of token indices that belong to interrogative sentences.
        interrogative_indices: set[int] = set()
        for sent in doc.sents:
            if self._is_interrogative_sentence(sent):
                for token in sent:
                    interrogative_indices.add(token.i)

        for token in doc:
            if token.i in interrogative_indices:
                continue
            if token.pos_ not in ("VERB", "AUX"):
                continue
            if token.dep_ == "aux":
                continue

            # Find subject
            subject = self._find_subject(token)
            if subject is None:
                continue

            # Find object
            obj = self._find_object(token)
            if obj is None:
                continue

            # Canonicalize relation
            relation = canonicalize_relation(token.lemma_)

            # Check negation
            negated = _is_negated(token)

            # Build evidence string
            evidence = self._get_clause_text(token, doc)

            claims.append(ExtractedClaim(
                subject=subject,
                relation=relation,
                obj=obj,
                span=span,
                negated=negated,
                evidence=evidence,
                provenance="user_input",
                extractor_backend="spacy",
            ))

        return claims

    def _find_subject(self, verb: Token) -> str | None:
        """Find the subject of a verb from its dependency children."""
        for child in verb.children:
            if child.dep_ in ("nsubj", "nsubjpass"):
                return self._get_span_text(child)
        # Check head for passives / aux chains
        if verb.dep_ in ("xcomp", "ccomp", "conj"):
            return self._find_subject(verb.head)
        return None

    def _find_object(self, verb: Token) -> str | None:
        """Find the direct object or attribute complement of a verb."""
        for child in verb.children:
            if child.dep_ in ("dobj", "attr", "oprd", "acomp"):
                return self._get_span_text(child)
            if child.dep_ == "prep":
                for grandchild in child.children:
                    if grandchild.dep_ == "pobj":
                        return self._get_span_text(grandchild)
            # Predicative adverbs on copula: "was overseas", "is home", "is abroad".
            # Guard: only accept advmod when the verb is a form of "be" — this
            # prevents manner adverbs ("ran quickly") from becoming claim objects.
            if child.dep_ == "advmod" and verb.lemma_ == "be":
                return child.text
        return None

    def _get_span_text(self, token: Token) -> str:
        """Get the full noun phrase text for a token (including children)."""
        # Use subtree for compound nouns and adjective modifiers
        subtree_tokens = sorted(token.subtree, key=lambda t: t.i)
        # Filter to meaningful tokens (skip determiners for cleaner output)
        meaningful = [
            t for t in subtree_tokens
            if t.dep_ not in ("det",) or t.pos_ == "PROPN"
        ]
        if meaningful:
            return " ".join(t.text for t in meaningful)
        return token.text

    def _get_clause_text(self, verb: Token, doc: Doc) -> str:
        """Get the approximate clause text around a verb."""
        subtree = sorted(verb.subtree, key=lambda t: t.i)
        if subtree:
            start = subtree[0].i
            end = subtree[-1].i + 1
            return doc[start:end].text
        return verb.text

    def _detect_ambiguous_referents(self, doc: Doc, pef: PEFState) -> list[str]:
        """Return pronouns and definite NPs that cannot be uniquely resolved.

        Detects three categories:
        1. Possessive pronouns (dep_==poss) when 2+ person antecedents exist.
        2. Subject/object pronouns (dep_ in nsubj/nsubjpass/dobj/pobj) when
           2+ person antecedents exist.
        3. Definite NPs ("the medication", "that condition") when 2+ PEF
           entities or object literals match the head noun.

        PEF axiom: binding without explicit grounding is not permitted.
        """
        doc_persons: set[str] = {ent.text for ent in doc.ents if ent.label_ == "PERSON"}

        # Include PEF-resident entities as additional antecedents.
        # Heuristic: short (≤2 tokens), capitalized → likely a person name.
        # Do NOT filter on resolved=True: entity mentions are added as resolved=False
        # (unresolved placeholder) when no claims are extracted about them, but they
        # are still valid pronoun antecedents for ambiguity purposes.
        pef_persons: set[str] = {
            ent.name for ent in pef.entities.values()
            if ent.name not in doc_persons
            and len(ent.name.split()) <= 2
            and ent.name[0].isupper()
        }

        all_persons = doc_persons | pef_persons
        has_multiple_persons = len(all_persons) >= 2

        ambiguous: list[str] = []
        seen: set[str] = set()
        for token in doc:
            lower = token.text.lower()

            # 1. Possessive pronouns (original behaviour)
            if lower in _POSSESSIVE_PRONOUNS and token.dep_ == "poss":
                if has_multiple_persons and lower not in seen:
                    seen.add(lower)
                    ambiguous.append(lower)
                continue

            # 2. Subject/object pronouns — same person-antecedent threshold
            if lower in _SUBJECT_OBJECT_PRONOUNS and token.dep_ in (
                "nsubj", "nsubjpass", "dobj", "pobj"
            ):
                if has_multiple_persons and lower not in seen:
                    seen.add(lower)
                    ambiguous.append(lower)
                continue

            # 3. Definite NP: determiner + NOUN/PROPN head
            # "the medication" is ambiguous when 2+ PEF entities or literals
            # match the noun, meaning the referent cannot be uniquely resolved.
            if lower in _DEFINITE_DETERMINERS and token.dep_ == "det":
                head = token.head
                if head.pos_ in ("NOUN", "PROPN"):
                    noun_lower = head.text.lower()
                    matching = [
                        ent.name for ent in pef.entities.values()
                        if noun_lower in ent.name.lower()
                        or any(
                            noun_lower in str(rel.object_literal or "").lower()
                            for rel in pef.get_relationships_for_subject(ent.id)
                        )
                    ]
                    key = f"{lower} {noun_lower}"
                    if len(matching) >= 2 and key not in seen:
                        seen.add(key)
                        ambiguous.append(key)

        return ambiguous

    def _detect_comparative_claims(
        self, doc: Doc, pef: PEFState
    ) -> list[ComparativeAmbiguity]:
        """Detect comparative adjectives whose comparand cannot be uniquely determined.

        Fires when a JJR/RBR token (comparative adjective/adverb) modifies "be"
        and 2+ eligible comparands exist in PEF.

        - 0 candidates: ungrounded assertion — accept silently (no gate).
        - 1 candidate: forced collapse — accept silently (exactly one referent).
        - 2+ candidates: returned for pre-LLM gate to ask one clarifying question.
        """
        ambiguities: list[ComparativeAmbiguity] = []
        for token in doc:
            if token.tag_ not in ("JJR", "RBR"):
                continue
            if token.dep_ not in ("acomp", "advmod"):
                continue
            verb = token.head
            if verb.lemma_ != "be":
                continue

            # Find the subject token
            subj_token = None
            for child in verb.children:
                if child.dep_ in ("nsubj", "nsubjpass"):
                    subj_token = child
                    break
            if subj_token is None:
                continue

            # The noun being compared is the nsubj head ("stick" in "James's stick")
            noun = subj_token.lemma_

            # Identify the possessor, if any ("James" in "James's stick")
            possessor: str | None = None
            for grandchild in subj_token.children:
                if grandchild.dep_ == "poss":
                    possessor = grandchild.text
                    break

            candidates = self._find_comparand_candidates(noun, possessor, pef)
            if len(candidates) >= 2:
                ambiguities.append(ComparativeAmbiguity(
                    adjective=token.text,
                    noun=noun,
                    candidates=candidates,
                ))

        return ambiguities

    def _find_comparand_candidates(
        self, noun: str, possessor: str | None, pef: PEFState
    ) -> list[str]:
        """Find PEF entities that are eligible comparands for a comparative claim.

        If possessor is given (e.g., "James" in "James's stick is bigger"):
            → find other entities that HAS an object containing the noun ("stick").
        If no possessor (e.g., "James is bigger"):
            → find other short, capitalised entities in PEF (likely persons).
        """
        candidates: list[str] = []
        noun_lower = noun.lower()

        if possessor is not None:
            possessor_lower = possessor.lower()
            for entity in pef.entities.values():
                if entity.name.lower() == possessor_lower:
                    continue
                for rel in pef.get_relationships_for_subject(entity.id):
                    if rel.relation == "HAS":
                        obj = str(rel.object_literal or "").lower()
                        if noun_lower in obj:
                            candidates.append(entity.name)
                            break
        else:
            for entity in pef.entities.values():
                if entity.name.lower() == noun_lower:
                    continue
                if len(entity.name.split()) <= 2 and entity.name[0].isupper():
                    candidates.append(entity.name)

        return candidates

    def _resolve_pronouns(
        self, doc: Doc, pef: PEFState
    ) -> dict[str, str]:
        """Attempt pronoun resolution using recency heuristic.

        Returns a dict of pronoun_key -> entity_name.
        """
        candidates: dict[str, str] = {}

        for token in doc:
            if not _is_pronoun(token):
                continue

            key = f"{token.text.lower()}@token_{token.i}"
            resolved = self._resolve_single_pronoun(token.text, pef)
            if resolved:
                candidates[key] = resolved

        return candidates

    def _resolve_single_pronoun(
        self, pronoun: str, pef: PEFState
    ) -> str | None:
        """Resolve a pronoun to the most recently active matching entity.

        Uses gender heuristic for he/she/him/her; recency for others.
        """
        resolved_entities = [
            e for e in pef.entities.values() if e.resolved
        ]
        if not resolved_entities:
            return None

        by_recency = sorted(
            resolved_entities,
            key=lambda e: e.turn_last_active,
            reverse=True,
        )

        if by_recency:
            return by_recency[0].name

        return None
