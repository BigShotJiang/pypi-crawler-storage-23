"""aurora-lens: Governance substrate for LLM hallucination prevention — PEF, verification, audit."""

__version__ = "0.1.0"
