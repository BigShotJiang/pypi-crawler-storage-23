"""CLI scripts for audit verification and anchoring."""
