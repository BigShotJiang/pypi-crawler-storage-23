"""aurora-lens proxy — OpenAI-compatible governed LLM endpoint."""
