"""LensConfig — configuration for the aurora-lens pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from aurora_lens.adapters.base import LLMAdapter

if TYPE_CHECKING:
    from aurora_lens.interpret.base import ExtractionBackend
    from aurora_lens.govern.bridge import GovernanceBridge


@dataclass
class LensConfig:
    """Configuration for the Lens pipeline."""

    adapter: LLMAdapter                 # Required: the LLM adapter to use

    # Extraction backend (defaults to SpacyBackend if None)
    extraction_backend: ExtractionBackend | None = None

    # Governance bridge (defaults to BuiltinBridge with DEFAULT_STRICT)
    governance_bridge: GovernanceBridge | None = None

    # Path for governance audit log (JSONL)
    audit_log_path: str | None = None

    # Whether to auto-update PEF state from user input
    auto_interpret: bool = True

    # Whether to verify LLM responses
    auto_verify: bool = True

    # Whether to include PEF context in LLM system prompt
    inject_pef_context: bool = True

    # Maximum conversation history turns to send to LLM
    max_history_turns: int = 10

    # spaCy model name (when extraction_backend is SpacyBackend default)
    spacy_model: str = "en_core_web_sm"

    # Stream accumulator cap in bytes (0 = no cap)
    max_stream_bytes: int = 512 * 1024  # 512 KiB

    # Two-plane output: when False (default), flags/rationale/governance_note stay in audit
    # log only and are never returned in the client response body. Set True only for
    # operator tooling or internal debugging.
    include_operator_detail: bool = False
