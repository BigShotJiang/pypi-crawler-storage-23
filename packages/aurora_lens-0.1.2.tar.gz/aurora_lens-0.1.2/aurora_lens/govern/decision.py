"""Governance decision types.

InterventionAction defines what the system does when verification flags fire.
GovernanceDecision is the full decision record — action, evidence, and audit fields.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto

from aurora_lens.verify.flags import Flag


class InterventionAction(Enum):
    """What the governance engine does with a flagged response."""
    PASS = auto()            # Clean — no flags, or flags below threshold
    SOFT_CORRECT = auto()    # Response delivered; correction in metadata only
    FORCE_REVISE = auto()    # Re-prompt LLM with flag context + PEF ground truth
    CONTAIN = auto()         # No determinations; acknowledge + ask intent (EXTRACTION_EMPTY)
    HARD_STOP = auto()       # Block response entirely


_ACTION_TO_ESCALATION = {
    InterventionAction.PASS: 0,         # ADMIT
    InterventionAction.CONTAIN: 1,       # CLARIFY
    InterventionAction.SOFT_CORRECT: 2,  # REFUSE
    InterventionAction.FORCE_REVISE: 2,  # REFUSE (deprecated, maps to 2)
    InterventionAction.HARD_STOP: 3,     # STOP
}


@dataclass
class GovernanceDecision:
    """Full governance decision record.

    Carries everything needed for audit: what happened, why, and context.
    escalation_level is derived from action — never from user input.
    forensic_event: canonical envelope for non-ADMIT outcomes; set by bridge when logging.
    """
    action: InterventionAction
    flags: list[Flag]
    rationale: str
    policy: str = "strict"                     # Policy that produced this decision
    rule_id: str | None = None                 # PolicyRule.rule_id that produced this action (audit)
    attempt: int = 0                           # Revision attempt (0 = first pass)
    original_response: str | None = None       # Pre-intervention response
    corrected_response: str | None = None      # Post-intervention response
    governance_note: str | None = None         # Human-readable note (for SOFT_CORRECT)
    cid: str | None = None                     # Content identifier (if available)
    safe_alt: str | None = None                # Phase 11: optional alternative for refuse template
    resource: str | None = None                # Phase 11/12: escalation resource (e.g. crisis support)
    forensic_event: dict | None = None         # Canonical forensic envelope (non-ADMIT only)

    @property
    def escalation_level(self) -> int:
        """0=ADMIT, 1=CLARIFY, 2=REFUSE, 3=STOP. Derived from action."""
        return _ACTION_TO_ESCALATION.get(self.action, 0)
