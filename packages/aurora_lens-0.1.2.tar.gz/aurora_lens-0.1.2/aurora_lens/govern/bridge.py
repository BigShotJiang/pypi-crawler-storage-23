"""Governance bridge — decides and executes interventions.

GovernanceBridge is the abstract interface.
BuiltinBridge is the lightweight built-in implementation.

Key design:
- escalation_level (0-3) is the enforcement switch. No revision loop.
- FORCE_REVISE is deprecated: maps to level 2, uses refuse template (no LLM retry).
- SOFT_CORRECT: pass-through with governance_note in metadata.
- Audit log is append-only JSONL with a stable, boring schema.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

from aurora_lens.context import (
    auth_label_var,
    auth_policy_var,
    get_lock_metadata,
    get_request_hash,
    session_id_var,
    trace_id_var,
)
from aurora_lens.govern.audit_io import CHAIN_GENESIS, append_audit_entry, append_checkpoint_entry
from aurora_lens.log_slice import consume_log_slice
from aurora_lens.govern.decision import GovernanceDecision, InterventionAction
from aurora_lens.govern.policy import InterventionPolicy, DEFAULT_STRICT, DEFAULT_MODERATE
from aurora_lens.verify.flags import Flag, FlagType

if TYPE_CHECKING:
    from aurora_lens.adapters.base import LLMAdapter
    from aurora_lens.pef.state import PEFState


# Audit log schema version (D1: canonical envelope)
_AUDIT_SCHEMA_VERSION = 2

# User-facing messages for each flag type at level 2 (refuse).
# These are shown to end users — plain language, no governance vocabulary.
# Operator-plane rationale (why it fired) goes to the audit log only.
_USER_MESSAGES: dict[FlagType, str] = {
    FlagType.HALLUCINATED_ENTITY: (
        "I don't have enough context here to answer that reliably. "
        "Could you provide more background?"
    ),
    FlagType.HALLUCINATED_ATTRIBUTE: (
        "I don't have enough context here to answer that reliably. "
        "Could you provide more background?"
    ),
    FlagType.HALLUCINATED_EVENT: (
        "I can't verify that with the information available in this conversation."
    ),
    FlagType.UNVERIFIED_FACT_ASSERTION: (
        "I can't confirm that claim with the information I have here."
    ),
    FlagType.UNRESOLVED_REFERENT: (
        "I'm not sure which entity you're referring to. Could you be more specific?"
    ),
    FlagType.IDENTITY_DRIFT: (
        "That seems to conflict with what was established earlier in our conversation."
    ),
    FlagType.CONTRADICTED_FACT: (
        "That seems to conflict with what was established earlier in our conversation."
    ),
    FlagType.UNVERIFIED_REGULATORY_CLAIM: (
        "I can't confirm regulatory status — please verify with official sources."
    ),
}

_DEFAULT_USER_MESSAGE = "I'm not able to respond to that reliably given the available context."

# Forensic event status: action → status string (schema: FORCE_REVISE | HARD_STOP | ASK | REFUSE | STOP)
_ACTION_TO_FORENSIC_STATUS: dict[InterventionAction, str] = {
    InterventionAction.CONTAIN: "ASK",
    InterventionAction.FORCE_REVISE: "REFUSE",
    InterventionAction.HARD_STOP: "STOP",
}


def build_forensic_event(
    decision: GovernanceDecision,
    *,
    pre_llm: bool,
    pef_snapshot: dict | None,
    trace_id: str = "",
    timestamp: str = "",
    audit_id: str | None = None,
) -> dict[str, object]:
    """Build canonical forensic_event envelope for non-ADMIT outcomes.
    Schema: trace_id, timestamp, status, attempted_action, domain, subdomain,
    failed_constraints, state_hash. pre_llm=True -> call_upstream, else respond.
    state_hash from stable JSON (sort_keys) of pef_snapshot."""
    status = _ACTION_TO_FORENSIC_STATUS.get(decision.action, "REFUSE")
    attempted_action = "call_upstream" if pre_llm else "respond"
    failed_constraints = [f.flag_type.name for f in decision.flags] if decision.flags else []
    if pef_snapshot is not None:
        state_hash = hashlib.sha256(
            json.dumps(pef_snapshot, separators=(",", ":"), sort_keys=True).encode()
        ).hexdigest()
    else:
        state_hash = None
    route = (
        ESCALATION_ROUTES.get(decision.flags[0].flag_type.name, (None, None, None, None))
        if decision.flags
        else (None, None, None, None)
    )
    domain, subdomain = route[0], route[1]
    return {
        "trace_id": trace_id or (audit_id or ""),
        "timestamp": timestamp,
        "status": status,
        "attempted_action": attempted_action,
        "domain": domain,
        "subdomain": subdomain,
        "failed_constraints": failed_constraints,
        "state_hash": state_hash,
    }

# Phase 7/12: Escalation routing — (domain, subdomain, requires_role, resource) per flag type
# domain: human_safety | security | legal | privacy | governance
# subdomain: content subdomain (self_harm, illegal, defamation, pii)
# requires_role: escalation target (clinical_escalation, security_ops, etc.)
ESCALATION_ROUTES: dict[str, tuple[str | None, str | None, str | None, str | None]] = {
    "SELF_HARM_INSTRUCTION": ("human_safety", "self_harm", "clinical_escalation", "crisis support resource"),
    "ILLEGAL_INSTRUCTION": ("security", "illegal", "security_ops", None),
    "TARGETED_DEFAMATION": ("legal", "defamation", "legal_compliance", None),
    "SENSITIVE_PII_EXPOSURE": ("privacy", "pii", "privacy_officer", None),
}


def enforce(decision: GovernanceDecision, model_output: str) -> str:
    """Deterministic enforcement: (policy_decision, model_output) → final response.

    No LLM re-prompting. No revision loop.
    escalation_level 0: pass-through | 1: clarify | 2: refuse | 3: stop
    """
    if decision.escalation_level == 0:
        return model_output
    if decision.escalation_level == 1:
        return _clarify_template(decision, model_output)
    if decision.escalation_level == 2:
        return _refuse_template(decision, model_output)
    if decision.escalation_level == 3:
        return _critical_template(decision)
    return model_output


def _clarify_template(decision: GovernanceDecision, model_output: str) -> str:
    """Level 1 — clarify. trigger_context = first trigger span if present."""
    if any(f.flag_type == FlagType.EXTRACTION_EMPTY for f in decision.flags):
        return (
            "I can't extract any admissible structure from that yet. "
            "Are you just chatting, or do you want me to make a specific determination? "
            "If you want a determination, tell me the key entities and the claim you want evaluated."
        )
    trigger_context = decision.flags[0].evidence[:200] if decision.flags else "that"
    return f"I may be misunderstanding. Can you clarify what you mean by {trigger_context}?"


def _refuse_template(decision: GovernanceDecision, model_output: str) -> str:
    """Level 2 — refuse. User-facing plain-language message.

    Operator-plane detail (which flag, which claim, policy rule) is in the audit log.
    The user sees only a clear, non-alarming explanation.
    """
    if decision.action == InterventionAction.SOFT_CORRECT:
        return model_output
    if not decision.flags:
        return _DEFAULT_USER_MESSAGE
    return _USER_MESSAGES.get(decision.flags[0].flag_type, _DEFAULT_USER_MESSAGE)


def _critical_template(decision: GovernanceDecision) -> str:
    """Level 3 — critical (HARD_STOP). Resource routing for safety categories."""
    if decision.resource:
        return (
            f"I can't assist with that. If you're feeling unsafe, "
            f"consider reaching out to {decision.resource}."
        )
    return "I can't help with that."


class GovernanceBridge(ABC):
    """Abstract interface for governance integration."""

    @abstractmethod
    async def decide(
        self,
        flags: list[Flag],
        response_text: str,
        pef: PEFState,
    ) -> GovernanceDecision:
        """Evaluate flags and produce a governance decision."""
        ...

    @abstractmethod
    async def intervene(
        self,
        decision: GovernanceDecision,
        adapter: LLMAdapter,
        user_input: str,
        pef_context: str,
        history: list[dict[str, str]] | None = None,
    ) -> str:
        """Execute the intervention. Returns the final response text."""
        ...

    def log_decision(
        self,
        decision: GovernanceDecision,
        turn: int = 0,
        *,
        stream: bool = False,
        stream_completed: bool = True,
        stream_abort_reason: str | None = None,
        stream_truncated: bool = False,
        stream_dropped_chars: int = 0,
        pef_context: str | None = None,
        pre_llm: bool = False,
        pef_snapshot: dict | None = None,
    ) -> None:
        """Log a governance decision. Override for audit trail.

        For streaming decisions, pass stream=True and:
        - stream_completed=True: include stream_truncated, stream_dropped_chars when applicable
        - stream_completed=False: include stream_abort_reason (e.g. "client_disconnect")
        pef_context: PEF state summary for state_hash (D1 spine).
        pre_llm: True for pre-LLM blocks (extraction failed, ambiguity gate, comparative ambiguity).
        pef_snapshot: Stable PEF state dict for state_hash; None if extraction failed before PEF.
        """
        pass


class BuiltinBridge(GovernanceBridge):
    """Lightweight built-in governance bridge.

    Uses InterventionPolicy for flag→action mapping.
    Logs every decision to append-only JSONL.
    Phase D: Optional HMAC signing, log rotation, hash chain (D2).
    """

    def __init__(
        self,
        policy: InterventionPolicy | None = None,
        audit_path: str | Path | None = None,
        audit_signing_key: str | bytes | None = None,
        audit_log_max_mb: int = 0,
        audit_checkpoint_interval: int = 0,
        mode: str = "public",
        policy_version: str = "1.0",
    ):
        self._policy = policy or DEFAULT_STRICT
        self._audit_path = Path(audit_path) if audit_path else None
        self._audit_signing_key = (
            audit_signing_key.encode("utf-8") if isinstance(audit_signing_key, str) else audit_signing_key
        ) if audit_signing_key else None
        self._audit_log_max_mb = max(0, audit_log_max_mb)
        self._audit_checkpoint_interval = max(0, audit_checkpoint_interval)
        self._mode = mode
        self._policy_version = policy_version
        self._chain_lock = threading.Lock()
        self._prev_cid = self._read_last_cid()
        self._entry_count = self._read_entry_count()
        if self._audit_path:
            self._audit_path.parent.mkdir(parents=True, exist_ok=True)

    def _read_last_cid(self) -> str:
        """Read last entry's cid from file for chain continuity. Genesis if empty or no cid."""
        if not self._audit_path or not self._audit_path.exists():
            return CHAIN_GENESIS
        try:
            lines = [ln for ln in self._audit_path.read_text(encoding="utf-8").strip().splitlines() if ln.strip()]
            if not lines:
                return CHAIN_GENESIS
            last = json.loads(lines[-1])
            return last.get("cid") or CHAIN_GENESIS
        except (OSError, json.JSONDecodeError, IndexError):
            return CHAIN_GENESIS

    def _read_entry_count(self) -> int:
        """Count decision entries (non-checkpoint) for D3 Option 2 checkpoint interval."""
        if not self._audit_path or not self._audit_path.exists():
            return 0
        try:
            lines = [ln for ln in self._audit_path.read_text(encoding="utf-8").strip().splitlines() if ln.strip()]
            count = 0
            for ln in lines:
                try:
                    entry = json.loads(ln)
                    if entry.get("type") != "checkpoint":
                        count += 1
                except json.JSONDecodeError:
                    pass
            return count
        except OSError:
            return 0

    def _maybe_checkpoint(self) -> None:
        """D3 Option 2: Write checkpoint every N decision entries."""
        if self._audit_checkpoint_interval <= 0 or not self._audit_path or not self._audit_signing_key:
            return
        if self._entry_count % self._audit_checkpoint_interval != 0:
            return
        new_cid = append_checkpoint_entry(
            self._audit_path,
            self._prev_cid,
            signing_key=self._audit_signing_key,
            max_mb=self._audit_log_max_mb,
        )
        if new_cid is not None:
            self._prev_cid = new_cid

    async def decide(
        self,
        flags: list[Flag],
        response_text: str,
        pef: PEFState,
    ) -> GovernanceDecision:
        action, rule = self._policy.evaluate_with_rule(flags)
        rule_id = rule.rule_id if rule else None

        rationale = self._build_rationale(flags, action)
        note = self._build_governance_note(flags) if action == InterventionAction.SOFT_CORRECT else None

        safe_alt = rule.safe_alt if rule else None
        resource = None
        if rule and action == InterventionAction.HARD_STOP:
            route = ESCALATION_ROUTES.get(rule.flag_type.name, (None, None, None, None))
            resource = route[3] if len(route) > 3 else None

        return GovernanceDecision(
            action=action,
            flags=flags,
            rationale=rationale,
            policy=self._policy.name,
            attempt=0,
            governance_note=note,
            rule_id=rule_id,
            safe_alt=safe_alt,
            resource=resource,
        )

    async def intervene(
        self,
        decision: GovernanceDecision,
        adapter: LLMAdapter,
        user_input: str,
        pef_context: str,
        history: list[dict[str, str]] | None = None,
    ) -> str:
        """Execute the intervention. Uses enforce() for deterministic output.
        D1: Logging is done by caller (Lens or tests) via log_decision."""
        model_output = decision.original_response or ""
        msg = enforce(decision, model_output)
        decision.corrected_response = msg
        return msg

    def _build_rationale(self, flags: list[Flag], action: InterventionAction) -> str:
        """Build a human-readable rationale from flags."""
        if not flags:
            return "No verification flags"

        flag_types = set(f.flag_type.name for f in flags)
        severities = set(f.severity for f in flags)
        worst_severity = "error" if "error" in severities else "warning"

        return (
            f"{action.name}: {len(flags)} flag(s) "
            f"[{', '.join(sorted(flag_types))}] "
            f"(worst severity: {worst_severity})"
        )

    def _build_governance_note(self, flags: list[Flag]) -> str:
        """Build a governance note for SOFT_CORRECT decisions."""
        parts = []
        for flag in flags:
            parts.append(f"{flag.flag_type.name}: {flag.claim} — {flag.evidence}")
        return "; ".join(parts)

    def _log_decision(
        self,
        decision: GovernanceDecision,
        final_response: str | None = None,
        turn: int = 0,
        *,
        stream: bool = False,
        stream_completed: bool = True,
        stream_abort_reason: str | None = None,
        stream_truncated: bool = False,
        stream_dropped_chars: int = 0,
        pef_context: str | None = None,
        pre_llm: bool = False,
        pef_snapshot: dict | None = None,
    ) -> None:
        """Append one canonical audit entry (D1). One record per governance event."""
        if self._audit_path is None:
            return

        ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
        trace_id = trace_id_var.get(None) or ""
        if decision.action not in (InterventionAction.PASS, InterventionAction.SOFT_CORRECT):
            forensic_event = build_forensic_event(
                decision,
                pre_llm=pre_llm,
                pef_snapshot=pef_snapshot,
                trace_id=trace_id,
                timestamp=ts,
                audit_id=decision.cid,
            )
            decision.forensic_event = forensic_event
        tenant_label = auth_label_var.get(None)
        request_hash = get_request_hash()
        ctx = pef_context or ""
        state_hash = hashlib.sha256(ctx.encode()).hexdigest()[:32] if ctx else None

        failed_constraints = [f.flag_type.name for f in decision.flags] if decision.flags else []

        entry: dict[str, object] = {
            "schema_version": _AUDIT_SCHEMA_VERSION,
            "trace_id": trace_id,
            "timestamp": ts,
            "session_id": session_id_var.get(None),
            "turn": turn,
            "tenant_label": tenant_label,
            "mode": self._mode,
            "policy_profile": decision.policy,
            "policy_version": self._policy_version,
            "outcome": decision.action.name,
            "failed_constraints": failed_constraints,
            "original_response": decision.original_response,
            "state_hash": state_hash,
            "request_hash": request_hash,
            "log_slice_present": False,
        }

        log_slice = consume_log_slice()
        if log_slice is not None:
            entry["log_slice_present"] = True
            entry.update(log_slice)

        if decision.action != InterventionAction.PASS:
            flag_list = decision.flags
            trigger_spans = [f.evidence[:200] for f in flag_list[:3]]
            _LEVEL_TO_ACTION = {1: "CLARIFY", 2: "REFUSE", 3: "STOP"}
            action_taken = _LEVEL_TO_ACTION.get(decision.escalation_level, "REFUSE")
            route = ESCALATION_ROUTES.get(flag_list[0].flag_type.name, (None, None, None, None)) if flag_list else (None, None, None, None)
            entry["escalation_level"] = decision.escalation_level
            entry["domain"] = route[0] if route[0] else "governance"
            entry["subdomain"] = route[1]
            if decision.forensic_event is not None:
                entry["forensic_event"] = decision.forensic_event
                if pef_snapshot is not None:
                    entry["pef_snapshot"] = pef_snapshot
            entry["requires_role"] = route[2]
            entry["action_taken"] = action_taken
            entry["trigger_spans"] = trigger_spans
            if decision.rule_id is not None:
                entry["policy_rule"] = decision.rule_id
            entry["rationale"] = decision.rationale
            entry["final_response"] = final_response or decision.corrected_response
            if decision.governance_note:
                entry["governance_note"] = decision.governance_note
            entry["flags"] = [
                {
                    "type": f.flag_type.name,
                    "severity": f.severity,
                    "claim": f.claim,
                    **({"extraction_diagnostic": f.extraction_diagnostic} if f.extraction_diagnostic else {}),
                }
                for f in decision.flags
            ]

        lock_meta = get_lock_metadata()
        if lock_meta is not None:
            entry["lock_wait_ms"] = lock_meta.get("lock_wait_ms")
            entry["lock_acquired"] = lock_meta.get("lock_acquired")
            if not lock_meta.get("lock_acquired"):
                entry["lock_timeout_ms"] = lock_meta.get("lock_timeout_ms")

        if stream:
            entry["stream"] = True
            entry["stream_completed"] = stream_completed
            if not stream_completed and stream_abort_reason:
                entry["stream_abort_reason"] = stream_abort_reason
            if stream_completed and stream_truncated:
                entry["stream_truncated"] = True
                entry["stream_dropped_chars"] = stream_dropped_chars

        with self._chain_lock:
            new_cid = append_audit_entry(
                self._audit_path,
                entry,
                signing_key=self._audit_signing_key,
                max_mb=self._audit_log_max_mb,
                prev_cid=self._prev_cid,
            )
            if new_cid is not None:
                self._prev_cid = new_cid
                decision.cid = new_cid
            self._entry_count += 1
            self._maybe_checkpoint()

    def log_decision(
        self,
        decision: GovernanceDecision,
        turn: int = 0,
        *,
        stream: bool = False,
        stream_completed: bool = True,
        stream_abort_reason: str | None = None,
        stream_truncated: bool = False,
        stream_dropped_chars: int = 0,
        pef_context: str | None = None,
        pre_llm: bool = False,
        pef_snapshot: dict | None = None,
    ) -> None:
        """Public interface for logging a governance decision (called by Lens)."""
        final = decision.corrected_response or decision.original_response
        self._log_decision(
            decision,
            final_response=final,
            turn=turn,
            stream=stream,
            stream_completed=stream_completed,
            stream_abort_reason=stream_abort_reason,
            stream_truncated=stream_truncated,
            stream_dropped_chars=stream_dropped_chars,
            pef_context=pef_context,
            pre_llm=pre_llm,
            pef_snapshot=pef_snapshot,
        )


class PolicySelectingBridge(GovernanceBridge):
    """Phase B: Wraps strict and moderate bridges; delegates based on per-key policy override.

    Policy selection (deterministic):
    - Key has policy: strict | moderate -> use that policy.
    - Key has no policy (None): use deployment default (governance.default_policy from config).
    - Auth disabled: use deployment default.
    """

    def __init__(
        self,
        strict_bridge: BuiltinBridge,
        moderate_bridge: BuiltinBridge,
        default_policy: str,
    ):
        self._strict = strict_bridge
        self._moderate = moderate_bridge
        self._default = default_policy if default_policy in ("strict", "moderate") else "strict"

    def _delegate(self) -> BuiltinBridge:
        override = auth_policy_var.get(None)
        if override == "moderate":
            return self._moderate
        if override == "strict":
            return self._strict
        return self._strict if self._default == "strict" else self._moderate

    async def decide(
        self,
        flags: list[Flag],
        response_text: str,
        pef: PEFState,
    ) -> GovernanceDecision:
        return await self._delegate().decide(flags, response_text, pef)

    async def intervene(
        self,
        decision: GovernanceDecision,
        adapter: LLMAdapter,
        user_input: str,
        pef_context: str,
        history: list[dict[str, str]] | None = None,
    ) -> str:
        return await self._delegate().intervene(
            decision, adapter, user_input, pef_context, history
        )

    def log_decision(
        self,
        decision: GovernanceDecision,
        turn: int = 0,
        *,
        stream: bool = False,
        stream_completed: bool = True,
        stream_abort_reason: str | None = None,
        stream_truncated: bool = False,
        stream_dropped_chars: int = 0,
        pef_context: str | None = None,
        pre_llm: bool = False,
        pef_snapshot: dict | None = None,
    ) -> None:
        self._delegate().log_decision(
            decision,
            turn=turn,
            stream=stream,
            stream_completed=stream_completed,
            stream_abort_reason=stream_abort_reason,
            stream_truncated=stream_truncated,
            stream_dropped_chars=stream_dropped_chars,
            pef_context=pef_context,
            pre_llm=pre_llm,
            pef_snapshot=pef_snapshot,
        )
