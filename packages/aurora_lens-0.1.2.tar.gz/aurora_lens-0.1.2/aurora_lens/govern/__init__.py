"""Governance engine — decides and executes interventions on flagged LLM responses.

BuiltinBridge works standalone with zero external dependencies.
AuroraGovernorBridge adds enterprise governance (requires unified_rns_system).
"""

from .decision import InterventionAction, GovernanceDecision
from .policy import InterventionPolicy, PolicyRule, DEFAULT_STRICT, DEFAULT_MODERATE
from .bridge import GovernanceBridge, BuiltinBridge, enforce

# AuroraGovernorBridge is lazy — import only when explicitly requested
# to avoid hard dependency on unified_rns_system.

__all__ = [
    "InterventionAction",
    "GovernanceDecision",
    "enforce",
    "InterventionPolicy",
    "PolicyRule",
    "DEFAULT_STRICT",
    "DEFAULT_MODERATE",
    "GovernanceBridge",
    "BuiltinBridge",
    "AuroraGovernorBridge",
]


def __getattr__(name: str):
    if name == "AuroraGovernorBridge":
        from .governor_bridge import AuroraGovernorBridge
        return AuroraGovernorBridge
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
