"""Aurora-governor integration bridge.

Enterprise upgrade: uses the GovernanceKernel from unified_rns_system
for deterministic, auditable governance with:

- AFL-JSONL-1 hash-chained forensic ledger (tamper-evident)
- Content-addressed identifiers (CID) via FallbackCIDProvider
- HMAC-signed AttestedOutput for compliance/audit
- PEF continuity chain across all ledger entries

Requires: pip install unified_rns_system
All imports are lazy — clear ImportError if not installed.
"""

from __future__ import annotations

import datetime
import hashlib
from pathlib import Path
from typing import TYPE_CHECKING, Any

from aurora_lens.govern.bridge import GovernanceBridge, build_forensic_event, enforce, ESCALATION_ROUTES
from aurora_lens.log_slice import consume_log_slice
from aurora_lens.govern.decision import GovernanceDecision, InterventionAction
from aurora_lens.govern.policy import InterventionPolicy, DEFAULT_STRICT
from aurora_lens.verify.flags import Flag, FlagType

if TYPE_CHECKING:
    from aurora_lens.adapters.base import LLMAdapter
    from aurora_lens.pef.state import PEFState


# ── Lazy imports ─────────────────────────────────────────────────────

_GOVERNOR_AVAILABLE = False

try:
    from governance.kernel_api import GovernanceKernel, Intent, State
    from governance.shared_types import KernelStatus, KernelResult, PEFFingerprint
    from governance.audit_trail import ForensicLedger
    from governance.cid_provider import FallbackCIDProvider
    from governance.attestation import (
        AttestedOutput,
        sign_attested_output,
        verify_governed_output,
    )
    _GOVERNOR_AVAILABLE = True
except ImportError:
    pass

_MISSING_MSG = (
    "Aurora-governor integration requires unified_rns_system.\n"
    "Install with: pip install unified_rns_system\n"
    "Or for development: pip install -e /path/to/unified_rns_system"
)

# ── Status mapping ───────────────────────────────────────────────────

def _kernel_status_to_action(
    kernel_status: Any,
    proposed_action: InterventionAction,
) -> InterventionAction:
    """Map GovernanceKernel result to InterventionAction.

    Kernel can escalate but never downgrade:
    - STOP / REFUSE → HARD_STOP
    - CLARIFY → at least FORCE_REVISE
    - CONTINUE / ADMIT → keep proposed action
    """
    if not _GOVERNOR_AVAILABLE:
        return proposed_action

    if kernel_status in (KernelStatus.STOP, KernelStatus.REFUSE):
        return InterventionAction.HARD_STOP

    if kernel_status == KernelStatus.CLARIFY:
        # Escalate to at least FORCE_REVISE
        if proposed_action.value < InterventionAction.FORCE_REVISE.value:
            return InterventionAction.FORCE_REVISE
        return proposed_action

    # CONTINUE / ADMIT → keep the policy's decision
    return proposed_action


# ── Bridge ───────────────────────────────────────────────────────────

class AuroraGovernorBridge(GovernanceBridge):
    """Enterprise governance bridge using aurora-governor kernel.

    Provides:
    - GovernanceKernel for deterministic decision validation
    - ForensicLedger for AFL-JSONL-1 hash-chained audit
    - AttestedOutput for HMAC-signed governance decisions
    - CID-based content addressing

    Falls back to InterventionPolicy for flag→action mapping,
    then validates through the kernel. Kernel can escalate
    but never downgrade a decision.
    """

    def __init__(
        self,
        policy: InterventionPolicy | None = None,
        audit_path: str | Path | None = None,
        secret_key: bytes | None = None,
        constraints: dict | None = None,
        max_revision_attempts: int = 1,
    ):
        """
        Args:
            policy: Intervention policy (defaults to DEFAULT_STRICT).
            audit_path: Path for AFL-JSONL-1 forensic ledger.
            secret_key: HMAC key for AttestedOutput signing.
                        If None, attestation is skipped.
            constraints: Kernel constraints (forbidden_actions, required_permissions, etc.)
            max_revision_attempts: Hard limit on revision loop (1–10).
        """
        if not _GOVERNOR_AVAILABLE:
            raise ImportError(_MISSING_MSG)

        self._policy = policy or DEFAULT_STRICT
        self._secret_key = secret_key
        self._constraints = constraints or {}
        self._max_revision_attempts = max(1, min(10, max_revision_attempts))
        self._last_attestation: AttestedOutput | None = None

        # CID provider (FNV-1a 64-bit — no RNS substrate needed)
        cid_provider = FallbackCIDProvider()
        self._cid_provider = cid_provider

        # Forensic ledger (hash-chained, tamper-evident)
        if audit_path:
            self._trace_id = (
                f"aurora-lens:"
                f"{datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')}"
            )
            self._ledger: ForensicLedger | None = ForensicLedger(
                log_path=str(audit_path),
                trace_id=self._trace_id,
            )
        else:
            self._trace_id = None
            self._ledger = None

        # Governance kernel
        self._kernel = GovernanceKernel(
            cid_provider=cid_provider,
            ledger=self._ledger,
        )

    # ── GovernanceBridge interface ────────────────────────────────

    async def decide(
        self,
        flags: list[Flag],
        response_text: str,
        pef: PEFState,
    ) -> GovernanceDecision:
        """Evaluate flags via policy + kernel validation."""
        # Step 1: Our policy maps flags → proposed action
        proposed_action, rule = self._policy.evaluate_with_rule(flags)
        rule_id = rule.rule_id if rule else None

        # Step 2: Submit to GovernanceKernel for validation
        intent = Intent(
            action="evaluate_output",
            params={
                "proposed_action": proposed_action.name,
                "flags": [
                    {
                        "type": f.flag_type.name,
                        "severity": f.severity,
                        "claim": f.claim,
                    }
                    for f in flags
                ],
                "flag_count": len(flags),
                "worst_severity": (
                    "error" if any(f.severity == "error" for f in flags) else "warning"
                ),
            },
            origin="aurora-lens",
        )

        kernel_result = self._kernel.kernel_step(intent, constraints=self._constraints)

        # Step 3: Kernel can escalate but never downgrade
        action = _kernel_status_to_action(kernel_result.status, proposed_action)

        # CID from kernel
        cid = kernel_result.cid

        rationale = self._build_rationale(flags, action)
        note = (
            self._build_governance_note(flags)
            if action == InterventionAction.SOFT_CORRECT
            else None
        )

        safe_alt = rule.safe_alt if rule else None
        resource = None
        if rule and action == InterventionAction.HARD_STOP:
            route = ESCALATION_ROUTES.get(rule.flag_type.name, (None, None, None, None))
            resource = route[3] if len(route) > 3 else None

        return GovernanceDecision(
            action=action,
            flags=flags,
            rationale=rationale,
            policy=self._policy.name,
            attempt=0,
            governance_note=note,
            cid=cid,
            rule_id=rule_id,
            safe_alt=safe_alt,
            resource=resource,
        )

    async def intervene(
        self,
        decision: GovernanceDecision,
        adapter: LLMAdapter,
        user_input: str,
        pef_context: str,
        history: list[dict[str, str]] | None = None,
    ) -> str:
        """Execute the intervention. Uses enforce() for deterministic output."""
        model_output = decision.original_response or ""
        msg = enforce(decision, model_output)

        if decision.escalation_level >= 1 and decision.action != InterventionAction.PASS:
            self._emit_forensic_envelope(decision, pef_context)
        return msg

    def _emit_forensic_envelope(
        self,
        decision: GovernanceDecision,
        pef_context: str,
    ) -> None:
        """Emit forensic/audit envelope for every non-ADMIT outcome.

        Level 1 (CLARIFY), 2 (REFUSE), 3 (STOP) — all produce an audit artifact.
        """
        if self._ledger is None:
            return
        if decision.action == InterventionAction.PASS:
            return

        failed_constraints = [f.flag_type.name for f in decision.flags]
        state_hash = hashlib.sha256(pef_context.encode()).hexdigest()[:32]
        ts = datetime.datetime.now(datetime.timezone.utc).isoformat()

        # Phase 7: policy_rule, trigger_spans, action_taken, category, domain, subdomain, requires_role
        trigger_spans = [f.evidence[:200] for f in decision.flags[:3]]
        _LEVEL_TO_ACTION = {1: "CLARIFY", 2: "REFUSE", 3: "STOP"}
        action_taken = _LEVEL_TO_ACTION.get(decision.escalation_level, "REFUSE")
        category = decision.flags[0].flag_type.value if decision.flags else "uncategorized"
        route = ESCALATION_ROUTES.get(decision.flags[0].flag_type.name, (None, None, None, None)) if decision.flags else (None, None, None, None)
        domain = route[0] if route[0] else "governance"
        subdomain = route[1]
        requires_role = route[2]

        envelope = {
            "type": "forensic_envelope",
            "trace_id": self._trace_id or "",
            "timestamp": ts,
            "escalation_level": decision.escalation_level,
            "domain": domain,
            "attempted_action": decision.action.name,
            "action_taken": action_taken,
            "category": category,
            "subdomain": subdomain,
            "requires_role": requires_role,
            "failed_constraints": failed_constraints,
            "trigger_spans": trigger_spans,
            "state_hash": state_hash,
        }
        if decision.rule_id is not None:
            envelope["policy_rule"] = decision.rule_id
        from aurora_lens.context import auth_label_var, session_id_var
        sid = session_id_var.get(None)
        if sid is not None:
            envelope["session_id"] = sid
        auth_label = auth_label_var.get(None)
        envelope["consumer_label"] = auth_label  # Always present; null when auth disabled
        if auth_label is not None:
            envelope["auth_label"] = auth_label

        log_slice = consume_log_slice()
        if log_slice is not None:
            envelope.update(log_slice)

        # Deterministic serialization: sort keys before ledger append (matches BuiltinBridge sort_keys=True)
        envelope = dict(sorted(envelope.items()))

        fp = PEFFingerprint(
            kind="forensic_envelope",
            head=state_hash[:16],
            rationale=f"{decision.action.name}:{ts}",
        )
        cid = self._cid_provider.cid_for_pef(fp)
        self._ledger.append(
            op="forensic_envelope",
            payload_data=envelope,
            cid=cid,
            scope={
                "domain": "governance",
                "subdomain": "aurora-lens",
                "event": f"NON_ADMIT_{decision.action.name}",
            },
        )

    def log_decision(
        self,
        decision: GovernanceDecision,
        turn: int = 0,
        *,
        stream: bool = False,
        stream_completed: bool = True,
        stream_abort_reason: str | None = None,
        stream_truncated: bool = False,
        stream_dropped_chars: int = 0,
        pef_context: str | None = None,
        pre_llm: bool = False,
        pef_snapshot: dict | None = None,
    ) -> None:
        """Log to ForensicLedger + produce AttestedOutput."""
        if self._ledger is None and self._secret_key is None:
            return

        # Build payload
        payload = {
            "event_type": "governance_decision",
            "turn": turn,
            "escalation_level": decision.escalation_level,
            "policy": decision.policy,
            "action": decision.action.name,
            "flags": [
                {"type": f.flag_type.name, "severity": f.severity, "claim": f.claim}
                for f in decision.flags
            ],
            "rationale": decision.rationale,
            "attempt": decision.attempt,
            **({"original_response": decision.original_response} if decision.original_response else {}),
            **({"governance_note": decision.governance_note} if decision.governance_note else {}),
        }
        from aurora_lens.context import auth_label_var
        auth_label = auth_label_var.get(None)
        payload["consumer_label"] = auth_label  # Always present; null when auth disabled
        if auth_label is not None:
            payload["auth_label"] = auth_label

        if stream:
            payload["stream"] = True
            payload["stream_completed"] = stream_completed
            if not stream_completed and stream_abort_reason:
                payload["stream_abort_reason"] = stream_abort_reason
            if stream_completed:
                if stream_truncated:
                    payload["stream_truncated"] = True
                    payload["stream_dropped_chars"] = stream_dropped_chars

        log_slice = consume_log_slice()
        if log_slice is not None:
            payload["log_slice_present"] = True
            payload.update(log_slice)
        else:
            payload["log_slice_present"] = False

        # Generate CID for this decision event
        fp = PEFFingerprint(
            kind=decision.action.name,
            head=(decision.rationale or "")[:32],
            rationale=f"turn:{turn}:flags:{len(decision.flags)}",
        )
        cid = self._cid_provider.cid_for_pef(fp)
        decision.cid = cid

        # Canonical forensic_event for non-ADMIT (response + audit)
        if decision.action not in (InterventionAction.PASS, InterventionAction.SOFT_CORRECT):
            ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
            from aurora_lens.context import trace_id_var
            trace_id = trace_id_var.get(None) or (self._trace_id or "")
            decision.forensic_event = build_forensic_event(
                decision,
                pre_llm=pre_llm,
                pef_snapshot=pef_snapshot,
                trace_id=trace_id,
                timestamp=ts,
                audit_id=cid,
            )
            payload["forensic_event"] = decision.forensic_event
            if pef_snapshot is not None:
                payload["pef_snapshot"] = pef_snapshot

        # Append to forensic ledger (hash-chained, tamper-evident)
        if self._ledger is not None:
            self._ledger.append(
                op=decision.action.name,
                payload_data=payload,
                cid=cid,
                scope={
                    "domain": "governance",
                    "subdomain": "aurora-lens",
                    "authority": "policy",
                },
            )

        # Produce AttestedOutput (HMAC-signed)
        if self._secret_key is not None:
            content = decision.corrected_response or decision.original_response or ""
            attested = AttestedOutput(
                content=content,
                policy_cid=f"policy:{decision.policy}",
                rationale_code=decision.action.name,
                decision=decision.action.name,
                event_cid=cid,
                signature="",  # will be replaced by signing
                meta={
                    "turn": turn,
                    "flags": len(decision.flags),
                    "attempt": decision.attempt,
                },
            )
            self._last_attestation = sign_attested_output(attested, self._secret_key)

    # ── Public utilities ──────────────────────────────────────────

    @property
    def last_attestation(self) -> AttestedOutput | None:
        """The most recent AttestedOutput (None if signing not configured)."""
        return self._last_attestation

    def verify_ledger(self) -> bool:
        """Verify the forensic ledger hash chain integrity.

        Returns True if chain is valid (or no ledger configured).
        """
        if self._ledger is None:
            return True
        return self._ledger.verify()

    def verify_attestation(
        self,
        attested: AttestedOutput | None = None,
    ) -> bool:
        """Verify an AttestedOutput signature.

        If no attestation passed, verifies the last one produced.
        Returns False if no secret key or no attestation available.
        """
        if self._secret_key is None:
            return False
        target = attested or self._last_attestation
        if target is None:
            return False
        return verify_governed_output(target, self._secret_key)

    @property
    def kernel_stats(self) -> dict:
        """Return kernel statistics."""
        return self._kernel.get_stats()

    @property
    def ledger_stats(self) -> dict | None:
        """Return ledger statistics (None if no ledger configured)."""
        if self._ledger is None:
            return None
        return self._ledger.get_stats()

    # ── Internal ──────────────────────────────────────────────────

    def _build_rationale(self, flags: list[Flag], action: InterventionAction) -> str:
        if not flags:
            return "No verification flags"

        flag_types = set(f.flag_type.name for f in flags)
        severities = set(f.severity for f in flags)
        worst = "error" if "error" in severities else "warning"

        return (
            f"{action.name}: {len(flags)} flag(s) "
            f"[{', '.join(sorted(flag_types))}] "
            f"(worst severity: {worst})"
        )

    def _build_governance_note(self, flags: list[Flag]) -> str:
        parts = []
        for flag in flags:
            parts.append(f"{flag.flag_type.name}: {flag.claim} — {flag.evidence}")
        return "; ".join(parts)
