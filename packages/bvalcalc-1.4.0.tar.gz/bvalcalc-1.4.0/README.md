# The B-value calculator: expected diversity under background selection

See documentation for details: https://JohriLab.github.io/Bvalcalc/

Jacob Marsh, Austin Daigle, Parul Johri
UNC Chapel Hill, NC
