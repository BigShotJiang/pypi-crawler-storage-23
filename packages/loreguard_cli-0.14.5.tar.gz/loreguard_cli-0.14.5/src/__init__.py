"""Lorekeeper Client Bridge - Local LLM to Backend connector."""

__version__ = "0.2.0"
