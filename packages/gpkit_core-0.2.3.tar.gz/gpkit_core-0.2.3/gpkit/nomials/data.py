"""Machinery for exps, cs, varlocs data -- common to nomials and programs"""

import numpy as np

from ..util.repr_conventions import ReprMixin
from ..varkey import VarKey
from ..varmap import VarSet


class NomialData(ReprMixin):
    """Object for holding cs, exps, and other basic 'nomial' properties.

    cs: array (coefficient of each monomial term)
    exps: tuple of {VarKey: float} (exponents of each monomial term)
    varlocs: {VarKey: list} (terms each variable appears in)
    units: pint.UnitsContainer
    """

    # pylint: disable=too-many-instance-attributes
    _hashvalue = _varlocs = _exps = _cs = _varkeys = None

    def __init__(self, hmap):
        self.hmap = hmap
        self.units = self.hmap.units
        self.any_nonpositive_cs = any(c <= 0 for c in self.hmap.values())

    def to(self, units):
        "Create new Signomial converted to new units"
        return self.__class__(self.hmap.to(units))

    @property
    def exps(self):
        "Create exps or return cached exps"
        if self._exps is None:
            self._exps = tuple(self.hmap.keys())
        return self._exps

    @property
    def cs(self):
        "Create cs or return cached cs"
        if self._cs is None:
            self._cs = np.array(list(self.hmap.values()))
            if self.hmap.units:
                # pylint: disable=fixme
                # TODO: treat vars as dimensionless, it's a hack
                self._cs = self._cs * self.hmap.units
        return self._cs

    def __hash__(self):
        return hash(self.hmap)

    @property
    def vks(self):
        "Set of a NomialData's varkeys, created as necessary."
        vks = VarSet()
        for exp in self.hmap:
            vks.update(exp)
        return vks

    def __eq__(self, other):
        "Equality test"
        if isinstance(other, VarKey):
            return False
        if not hasattr(other, "hmap"):
            return NotImplemented
        if self.hmap != other.hmap:
            return False
        if self.units != other.units:
            return False
        return True
