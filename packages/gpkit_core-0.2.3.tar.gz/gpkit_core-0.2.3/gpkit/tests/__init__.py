"GPkit testing module"
