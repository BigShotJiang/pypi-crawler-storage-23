"Repository for representation standards"

import re
import sys

import numpy as np

from .small_classes import Numbers, Quantity
from .small_scripts import try_str_without

INSIDE_PARENS = re.compile(r"\(.*\)")

if sys.platform[:3] == "win":  # pragma: no cover
    MUL = "*"
    PI_STR = "PI"
    UNICODE_EXPONENTS = False
    UNIT_FORMATTING = ":~"
else:  # pragma: no cover
    MUL = "·"
    PI_STR = "π"
    UNICODE_EXPONENTS = True
    UNIT_FORMATTING = ":P~"


def lineagestr(lineage, modelnums=True):
    "Returns properly formatted lineage string"
    if not isinstance(lineage, tuple):
        lineage = getattr(lineage, "lineage", None)
    return (
        ".".join(
            [f"{name}{num}" if (num and modelnums) else name for name, num in lineage]
        )
        if lineage
        else ""
    )


def unitstr(units, into="%s", options=UNIT_FORMATTING, dimless=""):
    "Returns the string corresponding to an object's units."
    if hasattr(units, "units") and isinstance(units.units, Quantity):
        units = units.units
    if not isinstance(units, Quantity):
        return dimless
    if options == ":~" and "ohm" in str(units.units):  # pragma: no cover
        rawstr = str(units.units)  # otherwise it'll be a capital Omega
    else:
        rawstr = ("{%s}" % options).format(units.units)
    units = rawstr.replace(" ", "").replace("dimensionless", dimless)
    return into % units if units else dimless


def latex_unitstr(units):
    "Returns latex unitstr"
    us = unitstr(units, r"~\mathrm{%s}", ":L~")
    utf = us.replace("frac", "tfrac").replace(r"\cdot", r"\cdot ")
    return utf if utf != r"~\mathrm{-}" else ""


def strify(val, excluded):
    "Turns a value into as pretty a string as possible."
    if isinstance(val, Numbers):
        isqty = hasattr(val, "magnitude")
        if isqty:
            units = val
            val = val.magnitude
        if np.pi / 12 < val < 100 * np.pi and abs(12 * val / np.pi % 1) <= 1e-2:
            # val is in bounds and a clean multiple of PI!
            if val > 3.1:  # product of PI
                val = f"{val/np.pi:.3g}{PI_STR}"
                if val == f"1{PI_STR}":
                    val = PI_STR
            else:  # division of PI
                val = f"({PI_STR}/{np.pi/val:.3g})"
        else:
            val = f"{val:.3g}"
        if isqty:
            val += unitstr(units, " [%s]")
    else:
        val = try_str_without(val, excluded)
    return val


def parenthesize(string, addi=True, mult=True):
    "Parenthesizes a string if it needs it and isn't already."
    parensless = string if "(" not in string else INSIDE_PARENS.sub("", string)
    bare_addi = " + " in parensless or " - " in parensless
    bare_mult = "·" in parensless or "/" in parensless
    if parensless and (addi and bare_addi) or (mult and bare_mult):
        return f"({string})"
    return string


def _render_add(children, excluded):
    left = strify(children[0], excluded)
    right = strify(children[1], excluded)
    if right[0] == "-":
        return f"{left} - {right[1:]}"
    return f"{left} + {right}"


def _render_mul(children, excluded):
    left = parenthesize(strify(children[0], excluded), mult=False)
    right = parenthesize(strify(children[1], excluded), mult=False)
    if left == "1":
        return right
    if right == "1":
        return left
    return f"{left}{MUL}{right}"


def _render_div(children, excluded):
    left = parenthesize(strify(children[0], excluded), mult=False)
    right = parenthesize(strify(children[1], excluded))
    if right == "1":
        return left
    return f"{left}/{right}"


def _render_neg(children, excluded):
    val = parenthesize(strify(children[0], excluded), mult=False)
    return f"-{val}"


def _render_pow(children, excluded):
    left = parenthesize(strify(children[0], excluded))
    x = children[1]
    if left == "1":
        return "1"
    if (
        UNICODE_EXPONENTS
        and not getattr(x, "shape", None)
        and int(x) == x
        and 2 <= x <= 9
    ):
        x = int(x)
        if x in (2, 3):
            return f"{left}{chr(176 + x)}"
        return f"{left}{chr(8304 + x)}"
    return f"{left}^{x}"


def _render_prod(children, excluded):
    val = parenthesize(strify(children[0], excluded))
    return f"{val}.prod()"


def _render_sum(children, excluded):
    val = parenthesize(strify(children[0], excluded))
    return f"{val}.sum()"


def _fmt_slice(s):
    "Format a slice object as a string."
    start = s.start or ""
    stop = s.stop if s.stop and s.stop < sys.maxsize else ""
    step = f":{s.step}" if s.step is not None else ""
    return f"{start}:{stop}{step}"


def _render_index(children, excluded):
    left = parenthesize(strify(children[0], excluded))
    idx = children[1]
    if left[-3:] == "[:]":  # pure variable access
        left = left[:-3]
    if isinstance(idx, tuple):
        elstrs = []
        for el in idx:
            if isinstance(el, slice):
                elstrs.append(_fmt_slice(el))
            elif isinstance(el, Numbers):
                elstrs.append(str(el))
        idx = ",".join(elstrs)
    elif isinstance(idx, slice):
        idx = _fmt_slice(idx)
    return f"{left}[{idx}]"


_AST_RENDERERS = {
    "add": _render_add,
    "mul": _render_mul,
    "div": _render_div,
    "neg": _render_neg,
    "pow": _render_pow,
    "prod": _render_prod,
    "sum": _render_sum,
    "index": _render_index,
}


def _render_ast_node(node, excluded):
    "Renders an ExprNode as a string.  Called by ExprNode.str_without()."
    renderer = _AST_RENDERERS.get(node.op)
    if renderer is None:
        raise ValueError(f"Unknown AST op: {node.op}")
    return renderer(node.children, excluded)


class ReprMixin:
    "This class combines various printing methods for easier adoption."

    lineagestr = lineagestr
    unitstr = unitstr
    latex_unitstr = latex_unitstr

    cached_strs = None
    ast = None

    def parse_ast(self, excluded=()):
        "Turns the AST of this object's construction into a faithful string"
        if self.ast is None:
            return self.str_without(excluded)  # pylint: disable=no-member
        excluded = frozenset({"units"}.union(excluded))
        if self.cached_strs is None:
            self.cached_strs = {}
        elif excluded in self.cached_strs:
            return self.cached_strs[excluded]
        aststr = self.ast.str_without(excluded)
        self.cached_strs[excluded] = aststr
        return aststr

    def __repr__(self):
        "Returns namespaced string."
        return f"gpkit.{self.__class__.__name__}({self})"

    def __str__(self):
        "Returns default string."
        return self.str_without()  # pylint: disable=no-member

    def _repr_latex_(self):
        "Returns default latex for automatic iPython Notebook rendering."
        return "$$" + self.latex() + "$$"  # pylint: disable=no-member
