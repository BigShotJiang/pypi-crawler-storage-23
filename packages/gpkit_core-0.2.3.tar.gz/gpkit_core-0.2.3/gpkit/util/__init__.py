"small utilities for GPkit"

GPCOLORS = ["#59ade4", "#FA3333"]
GPBLU, GPRED = GPCOLORS
