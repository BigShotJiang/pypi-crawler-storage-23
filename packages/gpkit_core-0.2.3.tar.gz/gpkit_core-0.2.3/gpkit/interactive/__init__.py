"Module for the interactive and plotting functions of GPkit"
