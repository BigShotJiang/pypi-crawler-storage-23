"Contains ConstraintSet and related classes and objects"

from .array import ArrayConstraint
from .single_equation import SingleEquationConstraint
