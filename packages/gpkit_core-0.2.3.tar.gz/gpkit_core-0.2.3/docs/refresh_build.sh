while true
do
	sleep 10s
	git pull
	make html
done
