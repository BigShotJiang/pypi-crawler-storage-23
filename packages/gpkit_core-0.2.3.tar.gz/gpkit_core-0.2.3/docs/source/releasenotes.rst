Release Notes
*************

`Release notes are available on Github <https://github.com/convexengineering/gpkit/releases/>`_
