Acknowledgements
****************

We thank the following contributors for helping to improve GPkit:

* Marshall Galbraith for setting up continuous integration.
* `Stephen Boyd`_ for inspiration and suggestions.
* `Kirsten Bray`_ for designing the GPkit logo.

.. _`Stephen Boyd`: http://stanford.edu/~boyd/
.. _`Kirsten Bray`: mailto:kgbray@umich.edu
