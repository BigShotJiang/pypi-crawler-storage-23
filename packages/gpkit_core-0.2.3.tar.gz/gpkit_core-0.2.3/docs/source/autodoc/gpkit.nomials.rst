gpkit.nomials package
=====================

Submodules
----------

gpkit.nomials.array module
--------------------------

.. automodule:: gpkit.nomials.array
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.core module
-------------------------

.. automodule:: gpkit.nomials.core
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.data module
-------------------------

.. automodule:: gpkit.nomials.data
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.map module
------------------------

.. automodule:: gpkit.nomials.map
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.math module
-------------------------

.. automodule:: gpkit.nomials.math
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.substitution module
---------------------------------

.. automodule:: gpkit.nomials.substitution
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.nomials.variables module
------------------------------

.. automodule:: gpkit.nomials.variables
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: gpkit.nomials
   :members:
   :undoc-members:
   :show-inheritance:
