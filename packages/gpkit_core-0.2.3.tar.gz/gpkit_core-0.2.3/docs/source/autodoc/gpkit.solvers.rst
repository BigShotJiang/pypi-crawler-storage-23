gpkit.solvers package
=====================

Submodules
----------

gpkit.solvers.cvxopt module
---------------------------

.. automodule:: gpkit.solvers.cvxopt
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.solvers.mosek\_cli module
-------------------------------

.. automodule:: gpkit.solvers.mosek_cli
   :members:
   :undoc-members:
   :show-inheritance:

gpkit.solvers.mosek\_conif module
---------------------------------

.. automodule:: gpkit.solvers.mosek_conif
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: gpkit.solvers
   :members:
   :undoc-members:
   :show-inheritance:
