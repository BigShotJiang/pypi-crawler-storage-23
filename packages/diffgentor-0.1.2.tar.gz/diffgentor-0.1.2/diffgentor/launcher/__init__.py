"""Launcher module for automatic multi-GPU startup."""

from diffgentor.launcher.launcher import Launcher, LaunchStrategy

__all__ = ["Launcher", "LaunchStrategy"]
