"""CLI module for diffgentor."""

from diffgentor.cli.main import main

__all__ = ["main"]
