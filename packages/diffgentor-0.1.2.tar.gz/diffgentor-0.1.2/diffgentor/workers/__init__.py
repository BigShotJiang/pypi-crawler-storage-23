"""Worker modules for diffgentor."""

from diffgentor.workers.base import BaseWorker

__all__ = ["BaseWorker"]
