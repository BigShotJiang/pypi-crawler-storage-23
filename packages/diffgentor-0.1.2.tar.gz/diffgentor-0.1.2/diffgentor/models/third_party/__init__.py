"""Third-party model implementations via git submodules."""
