export const shadowArgs = {
  "shadow-camera-near": 0.001,
  "shadow-camera-far": 500.0,
  "shadow-bias": -0.00001,
  "shadow-mapSize-width": 1024,
  "shadow-mapSize-height": 1024,
  "shadow-radius": 4.0,
};
