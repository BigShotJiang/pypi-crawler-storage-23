"""
Resources module for RelationalAI clients.
"""

# This package contains resource implementations for different platforms:
# - snowflake: Snowflake-specific resources
# - azure: Azure-specific resources (optional, may not be available in all environments)

