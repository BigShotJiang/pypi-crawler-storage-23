# rhiza-init
initialize repos
