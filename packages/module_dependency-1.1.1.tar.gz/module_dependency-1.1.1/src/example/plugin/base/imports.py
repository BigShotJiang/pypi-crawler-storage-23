# Common imports
import example.plugin.base.number.fake
import example.plugin.base.string.fake

# Plugin import
from example.plugin.base import BasePlugin
__all__ = ["BasePlugin"]
