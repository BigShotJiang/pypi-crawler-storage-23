from typing import Tuple

TVersion = Tuple[int, int, int, str, int]
VERSION: TVersion = (0, 3, 1, 'alpha', 0)
