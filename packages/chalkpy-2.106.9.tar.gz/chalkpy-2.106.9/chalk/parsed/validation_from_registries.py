"""
Unified validation layer that operates directly on registries.

This module provides validation that works for BOTH GQL and Proto conversion paths.
It triggers lazy validations by accessing properties on registry objects and performs
explicit validation checks.

This ensures validation parity between:
- GQL path: get_registered_types() → validate_graph()
- Proto path: ToProtoConverter.convert_graph()

By calling validate_all_from_registries() before conversion in both paths, we ensure
developers cannot add validation to one path and forget the other.
"""

from __future__ import annotations

import ast
from collections import defaultdict
from typing import TYPE_CHECKING

from chalk._lsp.error_builder import LSPErrorBuilder

if TYPE_CHECKING:
    from chalk.features.feature_field import Feature
    from chalk.features.feature_set import Features
    from chalk.features.resolver import ResolverRegistry


def validate_all_from_registries(
    features_registry: dict[str, type["Features"]],
    resolver_registry: "ResolverRegistry",
) -> None:
    """
    Trigger all validations by accessing properties on registry objects.
    This can be run multiple times and not show duplicates.

    This function should be called by BOTH GQL and Proto conversion paths BEFORE
    they perform their conversions. It validates by triggering lazy validations:

    - Error[24]: Feature names with protected prefixes
    - Error[25]: Namespace names with protected prefixes
    - Error[28]: Feature re-definition
    - Error[32]: Invalid join syntax (composite joins must use & not and)
    - Error[35]: Missing has-one join definition
    - Error[37]: Join filter with incorrect type annotation
    - Error[40]: Invalid join lambda
    - Error[42]: Bad foreign key types (type mismatch)
    - Error[43]: Multi-namespace joins
    - Error[51]: Multiple primary features (versioned primary keys)
    - Error[119]: State type validation (stream resolvers)
    - Error[135]: Unrecognized feature reference

    Parameters
    ----------
    features_registry : dict[str, type[Features]]
        The feature registry to validate (FeatureSetBase.registry).
    resolver_registry : ResolverRegistry
        The resolver registry to validate (RESOLVER_REGISTRY).

    Returns
    -------
    None
        Validation errors are accumulated in LSPErrorBuilder and raised as exceptions.
    """

    # ========================================================================
    # FEATURE VALIDATION
    # ========================================================================

    for _, features_cls in features_registry.items():
        # --------------------------------------------------------------------
        # Error[51]: Multiple primary features (versioned primary keys)
        # --------------------------------------------------------------------
        # Accessing __chalk_primary__ triggers _discover_feature() which
        # validates that there's only one primary key. Versioned features
        # create multiple primary keys (e.g., id, id@2, id@3, id@4) which
        # triggers Error[51].
        try:
            _ = features_cls.__chalk_primary__
        except Exception as e:
            # LSPErrorBuilder.promote_exception() re-raises LSP errors
            if not LSPErrorBuilder.promote_exception(e):
                # If it's not an LSP error, something else went wrong
                raise

        feature_definitions: defaultdict[str, list[int]] = defaultdict(list)
        """Tracks line numbers of feature field definitions. This is relative
        to the class, and not to the original file."""

        if features_cls.__chalk_source_info__.dedent_source:
            cls_ast = None
            try:
                cls_ast = ast.parse(features_cls.__chalk_source_info__.dedent_source)
            except Exception:
                pass

            if cls_ast:
                for stmt in cls_ast.body:
                    if isinstance(stmt, ast.ClassDef) and stmt.name == features_cls.__name__:
                        for field in stmt.body:
                            if isinstance(field, ast.AnnAssign) and isinstance(field.target, ast.Name):
                                feature_definitions[field.target.id].append(field.lineno)

        # --------------------------------------------------------------------
        # Iterate through all features in this feature set
        # --------------------------------------------------------------------
        for feature in features_cls.features:
            if len(feature_definitions[feature.name]) >= 2:
                # This feature has been defined multiple times.
                feature.lsp_error_builder.add_diagnostic(
                    message=f"Feature '{feature.attribute_name or feature.name}' has been defined multiple times on the feature class '{features_cls.__name__}'. This feature definition is overwritten by a later definition.",
                    range=feature.lsp_error_builder.property_range(feature.attribute_name or feature.name),
                    label="redefined feature",
                    code="28",
                )

            # Skip autogenerated and no-display features (same as user_types_to_json.py:138)
            # This prevents validating internal features like __chalk_* that are allowed
            # to have protected names
            if feature.is_autogenerated or feature.no_display:
                continue

            # ----------------------------------------------------------------
            # Error[32,35,37,40,42,43]: Join validation
            # ----------------------------------------------------------------
            # Accessing the .join property triggers:
            # - _validate_join() in feature_field.py (Error[32,37])
            # - _validate_filter() in feature_field.py (Error[40,42,43])
            #
            # During GQL conversion, convert_type_to_gql() also checks:
            # - Error[35]: if t.is_has_one and t.join is None
            try:
                _ = feature.join
            except Exception as e:
                if not LSPErrorBuilder.promote_exception(e):
                    raise

            # ----------------------------------------------------------------
            # Error[24,25]: Feature and namespace name validation
            # ----------------------------------------------------------------
            try:
                _validate_feature_names_from_registry(feature)
            except Exception as e:
                if not LSPErrorBuilder.promote_exception(e):
                    raise

    # ========================================================================
    # RESOLVER VALIDATION
    # ========================================================================

    for resolver in resolver_registry.get_all_resolvers():
        # --------------------------------------------------------------------
        # Error[135]: Unrecognized feature reference
        # --------------------------------------------------------------------
        # Accessing resolver.inputs triggers _do_parse() which validates
        # that all input features are recognized and exist in the registry.
        try:
            _ = resolver.inputs
        except Exception as e:
            if not LSPErrorBuilder.promote_exception(e):
                raise

        # --------------------------------------------------------------------
        # Error[119]: State type validation (stream resolvers)
        # --------------------------------------------------------------------
        # Accessing resolver state and default_args triggers validation
        # that default state values match their type annotations.
        try:
            _ = resolver.state
            _ = resolver.default_args
        except Exception as e:
            if not LSPErrorBuilder.promote_exception(e):
                raise


def _validate_feature_names_from_registry(feature: "Feature") -> None:
    """
    Validate that feature names and namespace names don't use protected prefixes.

    This performs the same validation as _validate_feature_names() in
    _graph_validation.py, but operates on Feature objects from the registry
    rather than UpsertFeatureGQL objects.

    Parameters
    ----------
    feature : Feature
        The feature to validate from FeatureSetBase.registry

    Raises
    ------
    Exception
        If feature or namespace name starts with '_chalk' or '__'
    """
    # Error[24]: Feature names cannot begin with '_chalk' or '__'
    if feature.name.startswith("__") or feature.name.startswith("_chalk"):
        feature.lsp_error_builder.add_diagnostic(
            message="Feature names cannot begin with '_chalk' or '__'.",
            range=feature.lsp_error_builder.property_range(feature.attribute_name or feature.name),
            label="protected name",
            code="24",
        )

    # Error[25]: Namespace names cannot begin with '_chalk' or '__'
    if feature.namespace.startswith("__") or feature.namespace.startswith("_chalk"):
        feature.lsp_error_builder.add_diagnostic(
            message="Feature classes cannot have names that begin with '_chalk' or '__'.",
            label="protected namespace",
            range=feature.lsp_error_builder.decorator_kwarg_value_range("name")
            or feature.lsp_error_builder.class_definition_range(),
            code="25",
        )
