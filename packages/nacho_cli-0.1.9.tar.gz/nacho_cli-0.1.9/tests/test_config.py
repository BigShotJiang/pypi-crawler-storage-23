import stat

import yaml

from nacho.config import (
    clear_token,
    get_api_url,
    load_context_config,
    load_token,
    load_tracked_contexts,
    save_token,
    save_tracked_context,
)


# ── get_api_url ─────────────────────────────────────────────────────


def test_get_api_url_default(monkeypatch):
    monkeypatch.delenv("NACHO_API_URL", raising=False)
    assert get_api_url() == "https://nacho.bot/api"


def test_get_api_url_env_override(monkeypatch):
    monkeypatch.setenv("NACHO_API_URL", "https://nacho.example.com/api")
    assert get_api_url() == "https://nacho.example.com/api"


# ── save / load / clear token ───────────────────────────────────────


def test_save_and_load_token(credentials_file, monkeypatch):
    # Patch the module-level constants used by save/load/clear
    monkeypatch.setattr("nacho.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)

    save_token("nacho_abc123")
    assert load_token() == "nacho_abc123"


def test_load_token_missing_file(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)
    assert load_token() is None


def test_load_token_strips_whitespace(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)

    save_token("  nacho_abc123  \n")
    assert load_token() == "nacho_abc123"


def test_clear_token(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)

    save_token("nacho_abc123")
    clear_token()
    assert load_token() is None


def test_clear_token_no_file(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)
    # Should not raise
    clear_token()


def test_save_token_file_permissions(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho.config.CREDENTIALS_FILE", credentials_file)

    save_token("secret")
    mode = credentials_file.stat().st_mode
    assert stat.S_IMODE(mode) == 0o600


# ── load_context_config ─────────────────────────────────────────────


def test_load_context_config(tmp_path):
    config = {
        "name": "my-context",
        "title": "My Context",
        "tags": "python,testing",
    }
    (tmp_path / ".nacho.yml").write_text(yaml.dump(config))
    result = load_context_config(str(tmp_path))
    assert result["name"] == "my-context"
    assert result["title"] == "My Context"
    assert result["tags"] == "python,testing"


def test_load_context_config_missing(tmp_path):
    assert load_context_config(str(tmp_path)) == {}


def test_load_context_config_empty_file(tmp_path):
    (tmp_path / ".nacho.yml").write_text("")
    assert load_context_config(str(tmp_path)) == {}


# ── load_tracked_contexts / save_tracked_context ───────────────────


def test_load_tracked_contexts(tmp_path):
    nacho_dir = tmp_path / ".nacho"
    nacho_dir.mkdir()
    (nacho_dir / "contexts.yml").write_text(
        yaml.dump({"contexts": {"myfile.md": {"name": "foo", "title": "Foo"}}})
    )
    result = load_tracked_contexts(str(tmp_path))
    assert result == {"myfile.md": {"name": "foo", "title": "Foo"}}


def test_load_tracked_contexts_missing(tmp_path):
    result = load_tracked_contexts(str(tmp_path))
    assert result == {}


def test_save_tracked_context(tmp_path):
    save_tracked_context("myfile.md", {"name": "foo", "title": "Foo"}, path=str(tmp_path))

    result = load_tracked_contexts(str(tmp_path))
    assert result == {"myfile.md": {"name": "foo", "title": "Foo"}}
    assert (tmp_path / ".nacho" / "contexts.yml").exists()


def test_save_tracked_context_appends(tmp_path):
    save_tracked_context("first.md", {"name": "first", "title": "First"}, path=str(tmp_path))
    save_tracked_context("second.md", {"name": "second", "title": "Second"}, path=str(tmp_path))

    result = load_tracked_contexts(str(tmp_path))
    assert "first.md" in result
    assert "second.md" in result
    assert result["first.md"]["name"] == "first"
    assert result["second.md"]["name"] == "second"
