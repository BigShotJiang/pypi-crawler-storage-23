"""LLM Router — multi-provider model selection, API calls, and budget enforcement.

Supports Anthropic (Claude), OpenAI (GPT/o-series), and Google (Gemini).
All responses are normalized to a common format so agents don't need
provider-specific code.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import uuid
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from autoforge.engine.config import DEFAULT_PRICING, MODEL_PRICING, ForgeConfig

logger = logging.getLogger(__name__)


# ── LLM Provider Protocol ──────────────────────────────────────────
# Implement this protocol to add a new LLM provider (e.g., Mistral, Cohere).
# Then register it via LLMRouter.register_provider().


class LLMProvider:
    """Protocol for LLM provider implementations.

    To add a new provider:
        1. Subclass LLMProvider
        2. Implement get_client(), call(), convert_messages(), convert_tools()
        3. Register via LLMRouter.register_provider("my_provider", MyProvider())
        4. Add model patterns to detect_provider() or use explicit provider selection
    """

    def get_client(self, config: ForgeConfig, auth: Any) -> Any:
        """Create or return a cached async client."""
        raise NotImplementedError

    async def call(
        self,
        client: Any,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        max_tokens: int,
    ) -> "LLMResponse":
        """Make an API call and return a normalized LLMResponse."""
        raise NotImplementedError


# ── Normalized response types ──────────────────────────────────────


@dataclass
class ContentBlock:
    """A block of content in an LLM response (text, tool_use, or image)."""

    type: str  # "text", "tool_use", or "image"
    text: str = ""
    id: str = ""
    name: str = ""
    input: dict[str, Any] = field(default_factory=dict)
    # Vision fields — used when type == "image"
    media_type: str = ""  # e.g. "image/png", "image/jpeg"
    image_data: str = ""  # base64-encoded image bytes


@dataclass
class Usage:
    """Token usage for a single LLM call."""

    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class LLMResponse:
    """Normalized LLM response — same attribute interface as Anthropic's Message."""

    content: list[ContentBlock] = field(default_factory=list)
    stop_reason: str = "end_turn"  # "end_turn" or "tool_use"
    usage: Usage = field(default_factory=Usage)


# ── Enums ──────────────────────────────────────────────────────────


class TaskComplexity(Enum):
    """Task complexity determines which model to use."""

    HIGH = "high"  # Uses model_strong (e.g. Opus, GPT-4o, Gemini Pro)
    STANDARD = "standard"  # Uses model_fast (e.g. Sonnet, GPT-4o-mini, Flash)
    COMPLEX = "complex"  # Alias of HIGH for backward compatibility
    MODERATE = "moderate"  # Alias of STANDARD for backward compatibility
    LOW = "low"  # Alias of STANDARD for lightweight tasks


class BudgetExceededError(Exception):
    """Raised when the API budget limit is reached."""


# ── Retry configuration ───────────────────────────────────────────

MAX_RETRIES = 3
"""Maximum number of retry attempts for transient API errors."""

_RETRY_BASE_DELAY = 1.0  # seconds — base delay for exponential backoff


# ── Provider detection ─────────────────────────────────────────────

# Known OpenAI model prefixes/names
_OPENAI_MODELS = {"gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo",
                  "codex-5.3", "o3", "o3-mini", "o4", "o4-mini", "o1", "o1-mini", "o1-preview"}


def detect_provider(model: str) -> str:
    """Detect LLM provider from model name.

    Returns "anthropic", "openai", or "google".
    """
    model_lower = model.lower()

    # OpenAI: check exact matches and prefixes
    if model_lower in _OPENAI_MODELS or model_lower.startswith(("gpt-", "codex-", "o1-", "o3-", "o4-")):
        return "openai"

    # Google Gemini
    if model_lower.startswith("gemini"):
        return "google"

    # Default: Anthropic (claude-* and anything else)
    return "anthropic"


# ── LLM Router ─────────────────────────────────────────────────────


class LLMRouter:
    """Routes LLM calls to appropriate providers and tracks usage.

    All agent interactions with LLM APIs go through this class.
    It handles provider detection, model selection, format conversion,
    budget enforcement, and usage logging.
    """

    # Custom provider registry — populated via register_provider()
    # NOTE: class-level registry is intentionally shared so providers
    # registered once are available to all router instances.
    _custom_providers: dict[str, LLMProvider] = {}
    _custom_providers_initialized: bool = False

    @classmethod
    def register_provider(cls, name: str, provider: LLMProvider) -> None:
        """Register a custom LLM provider.

        Once registered, models that detect_provider() maps to `name`
        will be routed through this provider's call() method.

        Args:
            name: Provider identifier (e.g., "mistral", "cohere").
            provider: An LLMProvider implementation.
        """
        # Copy-on-write to avoid mutating a shared default dict
        if not cls._custom_providers_initialized:
            cls._custom_providers = {}
            cls._custom_providers_initialized = True
        cls._custom_providers[name] = provider
        logger.info("Registered custom LLM provider: %s", name)

    def __init__(self, config: ForgeConfig) -> None:
        self.config = config
        self._call_count = 0
        self._clients: dict[str, Any] = {}
        self._auth_providers: dict[str, Any] = {}  # Cached AuthProvider per provider
        self._budget_lock: asyncio.Lock | None = None
        self._client_lock: asyncio.Lock | None = None
        self._reserved_budget_usd: float = 0.0

    async def close(self) -> None:
        """Close all cached async HTTP clients to release connection pools."""
        for provider, client in self._clients.items():
            try:
                if hasattr(client, "close"):
                    await client.close()
                elif hasattr(client, "aclose"):
                    await client.aclose()
            except Exception:
                logger.debug("Failed to close %s client", provider)
        self._clients.clear()

    async def __aenter__(self) -> LLMRouter:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _get_budget_lock(self) -> asyncio.Lock:
        """Lazily create lock to avoid cross-event-loop lock reuse."""
        if self._budget_lock is None:
            self._budget_lock = asyncio.Lock()
        return self._budget_lock

    def _estimate_call_cost_usd(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
    ) -> float:
        """Estimate upper-bound call cost for reservation.

        Uses a conservative chars->tokens approximation to reduce overspend races.
        """
        total_chars = len(system)
        total_chars += sum(len(json.dumps(m, ensure_ascii=False)) for m in messages)
        estimated_input_tokens = max(1, total_chars // 4)
        estimated_output_tokens = max(1, max_tokens)
        pricing = MODEL_PRICING.get(model, DEFAULT_PRICING)
        return (
            estimated_input_tokens * pricing["input"] / 1_000_000
            + estimated_output_tokens * pricing["output"] / 1_000_000
        )

    def _get_client_lock(self) -> asyncio.Lock:
        """Lazily create client lock to avoid cross-event-loop lock reuse."""
        if self._client_lock is None:
            self._client_lock = asyncio.Lock()
        return self._client_lock

    def _get_client(self, provider: str) -> Any:
        """Get or create an async client for the given provider.

        Uses the auth module to determine authentication method (API key,
        OAuth bearer, OAuth2 client_credentials, Google ADC/service account,
        AWS Bedrock, Google Vertex AI, Codex OAuth, Device Code).

        Note: Callers should use _get_or_create_client() for async-safe access.
        This sync method is kept for backward compatibility but may race under
        concurrent calls.
        """
        if provider in self._clients:
            return self._clients[provider]

        from autoforge.engine.auth import (
            AWSBedrockAuth, CodexOAuthAuth, DeviceCodeAuth, VertexAIAuth,
            create_auth_provider,
        )

        auth_config = getattr(self.config, "auth_config", {})
        auth = create_auth_provider(provider, self.config.api_keys, auth_config)
        self._auth_providers[provider] = auth
        client_kwargs = auth.get_client_kwargs()

        if provider == "anthropic":
            # Check for Bedrock or Vertex AI auth
            if isinstance(auth, AWSBedrockAuth):
                from anthropic import AsyncAnthropicBedrock
                client = AsyncAnthropicBedrock(**client_kwargs)
            elif isinstance(auth, VertexAIAuth):
                from anthropic import AsyncAnthropicVertex
                client = AsyncAnthropicVertex(**client_kwargs)
            else:
                from anthropic import AsyncAnthropic
                client = AsyncAnthropic(**client_kwargs)

        elif provider == "openai":
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise ImportError(
                    "OpenAI provider requires the 'openai' package. "
                    "Install it with: pip install forgeai[openai]"
                ) from None
            if isinstance(auth, (CodexOAuthAuth, DeviceCodeAuth)):
                # Token-based auth: client gets a dummy key, real token
                # injected via _ensure_fresh_token before each call
                client = AsyncOpenAI(api_key="placeholder")
            else:
                client = AsyncOpenAI(**client_kwargs)

        elif provider == "google":
            try:
                from google import genai
            except ImportError:
                raise ImportError(
                    "Google provider requires the 'google-genai' package. "
                    "Install it with: pip install forgeai[google]"
                ) from None
            auth_method = auth_config.get("google", {}).get("auth_method", "api_key")
            if auth_method in ("adc", "service_account"):
                # ADC: genai.Client() auto-discovers credentials
                client = genai.Client()
            else:
                key = self.config.api_keys.get("google", "")
                client = genai.Client(api_key=key)

        else:
            raise ValueError(f"Unknown provider: {provider}")

        self._clients[provider] = client
        return client

    async def _ensure_fresh_token(self, provider: str) -> None:
        """Refresh OAuth/dynamic token if needed and update the client."""
        from autoforge.engine.auth import (
            CodexOAuthAuth, DeviceCodeAuth, OAuth2ClientCredentialsAuth,
        )

        auth = self._auth_providers.get(provider)
        if auth is None:
            return

        # Only refresh for token-based auth providers
        if not isinstance(auth, (OAuth2ClientCredentialsAuth, CodexOAuthAuth, DeviceCodeAuth)):
            return

        token = await auth.get_token()
        # Update the client's API key with the fresh token
        if provider in self._clients:
            client = self._clients[provider]
            if hasattr(client, "api_key"):
                client.api_key = token.access_token

    async def _retry_with_backoff(
        self,
        fn: Callable[[], Coroutine[Any, Any, Any]],
        *,
        max_retries: int = MAX_RETRIES,
    ) -> Any:
        """Retry an async callable with exponential backoff for transient errors.

        Retries on rate-limit (HTTP 429), server errors (5xx), and network
        errors (ConnectionError, TimeoutError, OSError).  Non-transient errors
        (400, 401, 403, etc.) are re-raised immediately.

        Backoff schedule: 1s, 2s, 4s (with +-25 % jitter).
        """
        last_exc: BaseException | None = None
        for attempt in range(1, max_retries + 1):
            try:
                return await fn()
            except Exception as exc:
                last_exc = exc

                # --- Classify the error ---
                status: int | None = None
                if hasattr(exc, "status_code"):          # Anthropic / httpx
                    status = exc.status_code
                elif hasattr(exc, "status"):              # OpenAI / aiohttp
                    status = exc.status
                elif hasattr(exc, "code"):                # Google / gRPC
                    code = getattr(exc, "code", None)
                    if isinstance(code, int):
                        status = code

                is_transient = False

                # Rate-limit or server error
                if status is not None and (status == 429 or 500 <= status < 600):
                    is_transient = True

                # Network-level failures
                if isinstance(exc, (ConnectionError, TimeoutError, OSError)):
                    is_transient = True

                if not is_transient or attempt == max_retries:
                    raise

                # Exponential backoff with jitter (+-25 %)
                delay = _RETRY_BASE_DELAY * (2 ** (attempt - 1))
                jitter = delay * 0.25 * (2 * random.random() - 1)
                delay = max(0, delay + jitter)

                logger.warning(
                    "Transient error on attempt %d/%d (status=%s): %s — "
                    "retrying in %.1fs",
                    attempt, max_retries, status, exc, delay,
                )
                await asyncio.sleep(delay)

        # Should never reach here, but satisfy type checker
        assert last_exc is not None
        raise last_exc

    def _select_model(self, complexity: TaskComplexity) -> tuple[str, int]:
        """Return (model_name, max_tokens) for the given complexity."""
        if complexity in (TaskComplexity.HIGH, TaskComplexity.COMPLEX):
            return self.config.model_strong, self.config.max_tokens_strong
        return self.config.model_fast, self.config.max_tokens_fast

    async def generate(
        self,
        prompt: str,
        *,
        complexity: TaskComplexity = TaskComplexity.HIGH,
        max_tokens: int | None = None,
        temperature: float | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Convenience alias: ``await llm.generate(prompt, ...)``

        Maps to :meth:`call` with the prompt wrapped as a single user
        message.  Extra kwargs (``max_tokens``, ``temperature``, etc.) are
        accepted for call-site compatibility but do not affect routing —
        model selection is governed solely by *complexity*.
        """
        return await self.call(
            prompt,
            complexity=complexity,
        )

    async def call(
        self,
        prompt_or_nothing: str | None = None,
        *,
        complexity: TaskComplexity,
        system: str = "",
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Make an LLM call with automatic provider routing.

        Supports two calling conventions:
          - Full:   ``await llm.call(complexity=..., system=..., messages=[...])``
          - Short:  ``await llm.call(prompt, complexity=...)``
            (auto-wrapped into ``messages=[{"role": "user", "content": prompt}]``)

        Args:
            prompt_or_nothing: Optional positional prompt string (short form).
            complexity: Determines which model to use.
            system: System prompt.
            messages: Message history (normalized format).
            tools: Tool definitions (internal format).

        Returns:
            LLMResponse with normalized content blocks.
        """
        # ── short-form compat: llm.call(prompt, complexity=...) ──
        if prompt_or_nothing is not None:
            if messages is not None:
                raise ValueError(
                    "Cannot pass both a positional prompt and messages=",
                )
            messages = [{"role": "user", "content": prompt_or_nothing}]
        elif messages is None:
            raise ValueError("Either a positional prompt or messages= is required")
        model, max_tokens = self._select_model(complexity)
        reservation = self._estimate_call_cost_usd(
            model=model,
            system=system,
            messages=messages,
            max_tokens=max_tokens,
        )

        lock = self._get_budget_lock()
        async with lock:
            projected = (
                self.config.estimated_cost_usd
                + self._reserved_budget_usd
                + reservation
            )
            if projected > self.config.budget_limit_usd:
                raise BudgetExceededError(
                    "Budget exhausted before call: "
                    f"used=${self.config.estimated_cost_usd:.4f}, "
                    f"reserved=${self._reserved_budget_usd:.4f}, "
                    f"next_estimate=${reservation:.4f}, "
                    f"limit=${self.config.budget_limit_usd:.4f}"
                )
            self._reserved_budget_usd += reservation

        provider = detect_provider(model)
        # Async-safe client initialization — prevent duplicate creation
        async with self._get_client_lock():
            self._get_client(provider)
        await self._ensure_fresh_token(provider)
        self._call_count += 1
        call_id = self._call_count

        logger.info(
            f"[LLM #{call_id}] provider={provider} model={model} "
            f"messages={len(messages)} budget_remaining=${self.config.budget_remaining:.2f}"
        )

        response: LLMResponse | None = None
        try:
            # Check custom providers first
            if provider in self._custom_providers:
                custom = self._custom_providers[provider]
                client = self._get_client(provider)
                response = await self._retry_with_backoff(
                    lambda: custom.call(client, model, system, messages, tools, max_tokens)
                )
            elif provider == "anthropic":
                response = await self._call_anthropic(model, max_tokens, system, messages, tools)
            elif provider == "openai":
                response = await self._call_openai(model, max_tokens, system, messages, tools)
            elif provider == "google":
                response = await self._call_google(model, max_tokens, system, messages, tools)
            else:
                raise ValueError(f"Unknown provider: {provider}")
            return response
        finally:
            async with lock:
                self._reserved_budget_usd = max(0.0, self._reserved_budget_usd - reservation)
                if response is not None:
                    self.config.record_usage(
                        model,
                        response.usage.input_tokens,
                        response.usage.output_tokens,
                    )

            if response is not None:
                logger.info(
                    f"[LLM #{call_id}] stop_reason={response.stop_reason} "
                    f"tokens_in={response.usage.input_tokens} tokens_out={response.usage.output_tokens} "
                    f"cost_total=${self.config.estimated_cost_usd:.4f}"
                )

    # ── Anthropic ──────────────────────────────────────────────────

    async def _call_anthropic(
        self, model: str, max_tokens: int, system: str,
        messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None,
    ) -> LLMResponse:
        """Call Anthropic API and normalize the response."""
        client = self._get_client("anthropic")

        # Convert normalized messages to Anthropic format
        ant_messages = self._messages_to_anthropic(messages)

        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": ant_messages,
        }
        if tools:
            kwargs["tools"] = tools  # Already in Anthropic format

        raw = await self._retry_with_backoff(
            lambda: client.messages.create(**kwargs)
        )

        # Normalize response
        content = []
        for block in raw.content:
            if block.type == "text":
                content.append(ContentBlock(type="text", text=block.text))
            elif block.type == "tool_use":
                content.append(ContentBlock(
                    type="tool_use", id=block.id, name=block.name, input=block.input
                ))

        return LLMResponse(
            content=content,
            stop_reason=raw.stop_reason,
            usage=Usage(
                input_tokens=raw.usage.input_tokens,
                output_tokens=raw.usage.output_tokens,
            ),
        )

    def _messages_to_anthropic(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert normalized messages to Anthropic format.

        Normalized messages may contain ContentBlock dataclasses in assistant
        messages. Anthropic expects dicts.
        """
        result = []
        for msg in messages:
            content = msg.get("content")

            # If content is a list, check for ContentBlock instances
            if isinstance(content, list):
                converted = []
                for item in content:
                    if isinstance(item, ContentBlock):
                        if item.type == "text":
                            converted.append({"type": "text", "text": item.text})
                        elif item.type == "tool_use":
                            converted.append({
                                "type": "tool_use",
                                "id": item.id,
                                "name": item.name,
                                "input": item.input,
                            })
                        elif item.type == "image":
                            converted.append({
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": item.media_type or "image/png",
                                    "data": item.image_data,
                                },
                            })
                    elif isinstance(item, dict) and item.get("type") == "image":
                        # Already in raw dict format
                        converted.append(item)
                    else:
                        converted.append(item)
                result.append({"role": msg["role"], "content": converted})
            else:
                result.append(msg)
        return result

    # ── OpenAI ─────────────────────────────────────────────────────

    async def _call_openai(
        self, model: str, max_tokens: int, system: str,
        messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None,
    ) -> LLMResponse:
        """Call OpenAI API and normalize the response."""
        client = self._get_client("openai")

        # OpenAI reasoning/codex models use max_completion_tokens
        model_lower = model.lower()
        is_reasoning = model_lower.startswith(("o1", "o3", "o4", "codex-"))
        token_key = "max_completion_tokens" if is_reasoning else "max_tokens"

        # Convert messages to OpenAI format
        oai_messages = self._messages_to_openai(system, messages, is_reasoning=is_reasoning)

        kwargs: dict[str, Any] = {
            "model": model,
            token_key: max_tokens,
            "messages": oai_messages,
        }
        if tools:
            kwargs["tools"] = self._tools_to_openai(tools)

        raw = await self._retry_with_backoff(
            lambda: client.chat.completions.create(**kwargs)
        )
        choice = raw.choices[0]
        message = choice.message

        # Normalize response
        content: list[ContentBlock] = []

        if message.content:
            content.append(ContentBlock(type="text", text=message.content))

        # Tool calls
        stop_reason = "end_turn"
        if message.tool_calls:
            stop_reason = "tool_use"
            for tc in message.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except (json.JSONDecodeError, TypeError):
                    args = {}
                content.append(ContentBlock(
                    type="tool_use",
                    id=tc.id,
                    name=tc.function.name,
                    input=args,
                ))

        usage = Usage()
        if raw.usage:
            usage = Usage(
                input_tokens=raw.usage.prompt_tokens or 0,
                output_tokens=raw.usage.completion_tokens or 0,
            )

        return LLMResponse(content=content, stop_reason=stop_reason, usage=usage)

    def _messages_to_openai(
        self, system: str, messages: list[dict[str, Any]], *,
        is_reasoning: bool = False,
    ) -> list[dict[str, Any]]:
        """Convert normalized messages to OpenAI format."""
        result: list[dict[str, Any]] = []
        if is_reasoning:
            # o1/o3/o4/codex models use "developer" role instead of "system"
            result.append({"role": "developer", "content": system})
        else:
            result.append({"role": "system", "content": system})

        for msg in messages:
            role = msg["role"]
            content = msg.get("content")

            if role == "assistant":
                # May contain ContentBlock instances
                oai_msg: dict[str, Any] = {"role": "assistant"}
                text_parts = []
                tool_calls = []

                items = content if isinstance(content, list) else [content]
                for item in items:
                    if isinstance(item, ContentBlock):
                        if item.type == "text":
                            text_parts.append(item.text)
                        elif item.type == "tool_use":
                            tool_calls.append({
                                "id": item.id,
                                "type": "function",
                                "function": {
                                    "name": item.name,
                                    "arguments": json.dumps(item.input),
                                },
                            })
                    elif isinstance(item, dict):
                        if item.get("type") == "text":
                            text_parts.append(item.get("text", ""))
                        elif item.get("type") == "tool_use":
                            tool_calls.append({
                                "id": item["id"],
                                "type": "function",
                                "function": {
                                    "name": item["name"],
                                    "arguments": json.dumps(item.get("input", {})),
                                },
                            })
                    elif isinstance(item, str):
                        text_parts.append(item)

                oai_msg["content"] = "\n".join(text_parts) if text_parts else None
                if tool_calls:
                    oai_msg["tool_calls"] = tool_calls
                result.append(oai_msg)

            elif role == "user":
                # May contain tool_result items, images, or plain text.
                # Collect tool results and user content separately to avoid
                # interleaving — OpenAI expects all tool messages grouped
                # right after the assistant tool_calls message.
                if isinstance(content, list):
                    tool_msgs: list[dict[str, Any]] = []
                    user_content_parts: list[dict[str, Any]] = []
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "tool_result":
                            tool_msgs.append({
                                "role": "tool",
                                "tool_call_id": item["tool_use_id"],
                                "content": item.get("content", ""),
                            })
                        elif isinstance(item, ContentBlock) and item.type == "image":
                            # OpenAI vision: data URI format
                            mt = item.media_type or "image/png"
                            user_content_parts.append({
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:{mt};base64,{item.image_data}",
                                },
                            })
                        elif isinstance(item, dict) and item.get("type") == "image":
                            src = item.get("source", {})
                            mt = src.get("media_type", "image/png")
                            data = src.get("data", "")
                            user_content_parts.append({
                                "type": "image_url",
                                "image_url": {"url": f"data:{mt};base64,{data}"},
                            })
                        else:
                            text = item if isinstance(item, str) else (
                                item.text if isinstance(item, ContentBlock) else str(item)
                            )
                            user_content_parts.append({"type": "text", "text": text})
                    # Emit tool messages first (they belong to the preceding
                    # assistant turn), then a single user message if any.
                    result.extend(tool_msgs)
                    if user_content_parts:
                        result.append({
                            "role": "user",
                            "content": user_content_parts,
                        })
                elif isinstance(content, str):
                    result.append({"role": "user", "content": content})
                else:
                    result.append({"role": "user", "content": str(content)})

        return result

    def _tools_to_openai(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert internal tool definitions to OpenAI format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("input_schema", {}),
                },
            }
            for t in tools
        ]

    # ── Google Gemini ──────────────────────────────────────────────

    async def _call_google(
        self, model: str, max_tokens: int, system: str,
        messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None,
    ) -> LLMResponse:
        """Call Google Gemini API and normalize the response."""
        from google import genai
        from google.genai import types

        client = self._get_client("google")

        # Build contents
        contents = self._messages_to_gemini(messages)

        # Build config
        config: dict[str, Any] = {
            "max_output_tokens": max_tokens,
            "system_instruction": system,
        }

        # Convert tools
        gemini_tools = None
        if tools:
            gemini_tools = self._tools_to_gemini(tools)
            config["tools"] = gemini_tools

        raw = await self._retry_with_backoff(
            lambda: client.aio.models.generate_content(
                model=model,
                contents=contents,
                config=types.GenerateContentConfig(**config),
            )
        )

        # Normalize response
        content: list[ContentBlock] = []
        stop_reason = "end_turn"

        if raw.candidates and raw.candidates[0].content:
            for part in raw.candidates[0].content.parts:
                if part.text:
                    content.append(ContentBlock(type="text", text=part.text))
                elif part.function_call:
                    stop_reason = "tool_use"
                    fc = part.function_call
                    content.append(ContentBlock(
                        type="tool_use",
                        id=uuid.uuid4().hex[:12],
                        name=fc.name,
                        input=dict(fc.args) if fc.args else {},
                    ))

        usage = Usage()
        if raw.usage_metadata:
            usage = Usage(
                input_tokens=raw.usage_metadata.prompt_token_count or 0,
                output_tokens=raw.usage_metadata.candidates_token_count or 0,
            )

        return LLMResponse(content=content, stop_reason=stop_reason, usage=usage)

    def _messages_to_gemini(self, messages: list[dict[str, Any]]) -> list[Any]:
        """Convert normalized messages to Gemini contents format."""
        from google.genai import types

        contents = []
        for msg in messages:
            role = "model" if msg["role"] == "assistant" else "user"
            content = msg.get("content")

            parts = []
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, ContentBlock):
                        if item.type == "text":
                            parts.append(types.Part.from_text(text=item.text))
                        elif item.type == "tool_use":
                            parts.append(types.Part(function_call=types.FunctionCall(
                                name=item.name, args=item.input
                            )))
                        elif item.type == "image":
                            import base64 as _b64
                            raw = _b64.b64decode(item.image_data)
                            mt = item.media_type or "image/png"
                            parts.append(types.Part.from_data(data=raw, mime_type=mt))
                    elif isinstance(item, dict):
                        if item.get("type") == "tool_result":
                            parts.append(types.Part(function_response=types.FunctionResponse(
                                name=item.get("tool_name", "tool"),
                                response={"result": item.get("content", "")},
                            )))
                        elif item.get("type") == "text":
                            parts.append(types.Part.from_text(text=item.get("text", "")))
                        elif item.get("type") == "image":
                            import base64 as _b64
                            src = item.get("source", {})
                            raw = _b64.b64decode(src.get("data", ""))
                            mt = src.get("media_type", "image/png")
                            parts.append(types.Part.from_data(data=raw, mime_type=mt))
                    elif isinstance(item, str):
                        parts.append(types.Part.from_text(text=item))
            elif isinstance(content, str):
                parts.append(types.Part.from_text(text=content))

            if parts:
                contents.append(types.Content(role=role, parts=parts))

        return contents

    def _tools_to_gemini(self, tools: list[dict[str, Any]]) -> list[Any]:
        """Convert internal tool definitions to Gemini format."""
        from google.genai import types

        declarations = []
        for t in tools:
            declarations.append(types.FunctionDeclaration(
                name=t["name"],
                description=t.get("description", ""),
                parameters=t.get("input_schema"),
            ))
        return [types.Tool(function_declarations=declarations)]

    # ── Properties ─────────────────────────────────────────────────

    @property
    def total_cost(self) -> float:
        return self.config.estimated_cost_usd

    @property
    def call_count(self) -> int:
        return self._call_count
