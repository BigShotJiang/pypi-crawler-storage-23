"""Packaged fallback scripts for Exo CLI."""
