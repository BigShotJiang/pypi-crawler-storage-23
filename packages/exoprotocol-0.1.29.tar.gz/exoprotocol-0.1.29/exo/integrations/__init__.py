"""ExoProtocol integrations with external agent SDKs."""
