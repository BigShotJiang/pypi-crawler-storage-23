"""Test that the public API is accessible via the expected import patterns."""

from unittest.mock import patch

from pytest_httpx import HTTPXMock


def test_import_from_tyko() -> None:
    """Users can import directly: from tyko import TykoClient"""
    from tyko import Run, RunParams, RunStatus, TykoClient, capture_environment

    assert TykoClient is not None
    assert Run is not None
    assert RunStatus is not None
    assert RunParams is not None
    assert capture_environment is not None


def test_import_tyko_module() -> None:
    """Users can use the module: import tyko; tyko.TykoClient(...)"""
    import tyko

    assert hasattr(tyko, "TykoClient")
    assert hasattr(tyko, "Run")
    assert hasattr(tyko, "RunStatus")
    assert hasattr(tyko, "RunParams")
    assert hasattr(tyko, "__version__")


def test_run_status_values() -> None:
    """RunStatus enum has expected values."""
    from tyko import RunStatus

    assert RunStatus.CREATED == "created"
    assert RunStatus.RUNNING == "running"
    assert RunStatus.COMPLETED == "completed"
    assert RunStatus.FAILED == "failed"


def test_start_run_via_module(httpx_mock: HTTPXMock) -> None:
    """Users can start a run using: import tyko; client = tyko.TykoClient(...)"""
    import tyko

    httpx_mock.add_response(
        url="http://test:8000/runs",
        method="POST",
        json={
            "id": "run-123",
            "name": "brave-golden-eagle",
            "sequential": 1,
            "project": {"name": "my-project"},
            "experiment": {"name": "default"},
        },
    )

    with patch.dict("os.environ", {"TYKO_API_KEY": "test-key"}):
        client = tyko.TykoClient(api_url="http://test:8000")
        run = client.start_run(project="my-project")

    assert run.name == "brave-golden-eagle"
    assert isinstance(run, tyko.Run)
