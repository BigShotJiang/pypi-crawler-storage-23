from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

__version__ = "0.1.12"

from ._client import TykoClient
from ._environment import capture_environment
from ._types import Environment, Experiment, Project, Run, RunParams, RunStatus

__all__ = [
    "TykoClient",
    "TykoCallback",
    "Project",
    "Experiment",
    "Run",
    "RunParams",
    "RunStatus",
    "Environment",
    "capture_environment",
    "__version__",
]


def __getattr__(name: str) -> object:
    if name == "TykoCallback":
        from .integrations import TykoCallback

        return TykoCallback
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
