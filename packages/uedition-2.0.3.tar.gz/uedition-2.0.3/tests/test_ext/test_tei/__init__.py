"""TEI Extension Tests."""
