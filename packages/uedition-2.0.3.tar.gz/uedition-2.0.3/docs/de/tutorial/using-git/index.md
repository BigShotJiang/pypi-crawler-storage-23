# Git im μEditor

:::{note}
Dieser Teil des Tutorials ist optional und Sie können auch direkt zum [Arbeiten mit TEI](../using-tei/index) weitergehen.
:::
