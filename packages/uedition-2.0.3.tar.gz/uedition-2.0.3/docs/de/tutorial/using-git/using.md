# Git verwenden

Die Grundlagen der Nutzung von Git im μEditor sind relativ einfach, wie folgendes Video zeigt.

:::{room3b-video} /uedition/tutorial/git/using/de
:::

# Einzelschritte

1. In der μEditor Menüzeile folgende Menüoption auswählen: {menuselection}`μEditor (Main) --> New Branch`
2. Dem Branch einen Titel geben und dann auf den {guilabel}`Create` Button klicken.
3. Die gewünschten Änderungen machen.
4. In der μEditor Menüzeile folgende Menüoption auswählen: {menuselection}`μEditor --> Merge into the default branch`
