# Eine Seite bearbeiten

Der nächste Schritt, der in folgendem Video gezeigt wird, ist es, eine einzelne Seite zu bearbeiten.

:::{room3b-video} /uedition/tutorial/edit-page/de
:::

## Einzelschritte

1. Links im Dateibrowser die zu bearbeitende Datei auswählen. In diesem Fall werden wir im Ordner {file}`de`, die Datei
   {file}`index.md` auswählen, welche den Inhalt der Startseite enthält.
2. Im Editorbereich einfach den Text wie gewünscht bearbeiten. Standardmäßig nutzt die μEdition Markdown als Textformat.
   Markdown ist ein relativ einfaches Format zur Textauszeichnung. Im nächsten Schritt werden wir uns ein ein bischen
   detailierter mit der Annotation beschäftigen, aber fürs erste einfach ein bischen Text eingeben. Um Absätze
   voneinander zu trennen, einfach eine Leerzeile zwischen den Absätzen einfügen.
3. Die Änderungen speichern, entweder über das Tastaturkürzel {kbd}`Strg+s` (Mac: {kbd}`Command+s`) oder indem man auf
   das Speicher Icon links oben im Interface klickt.
4. Die μEdition wird die Änderung automatisch erkennen und die HTML Seite aktualisieren.
