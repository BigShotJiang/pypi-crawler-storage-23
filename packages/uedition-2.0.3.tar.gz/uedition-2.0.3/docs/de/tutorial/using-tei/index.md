# TEI nutzen

:::{note}
Dieser Teil des Tutorials ist optional und Sie können die μEdition auch ohne TEI nutzen.
:::

Das [TEI](https://tei-c.org/) Format ist ein extrem komplexes und mächtiges Datenformat und in diesem Tutorial können
wir nur die einfachsten Grundlagen ausprobieren.
