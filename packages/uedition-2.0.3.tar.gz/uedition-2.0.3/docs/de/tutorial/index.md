# Tutorial

Dieses Tutorial führt durch die Erstellung einer μEdition. Es deckt nicht alle Funktionalitäten der μEdition ab, aber es
führt in die primären Abläufe ein, um eine μEdition zu erstellen und weiterzuentwickeln. Nach Abschluss des Tutorials
sind sie auch in der Lage, alle weiteren Funktionen über die Nutzerdokumentation hier zu entdecken und zu konfigurieren.

Für dieses Tutorial brauchen sie einen Internetzugang, die Möglichkeit Software auf ihrem Computer zu installieren und
einen Web Browser. Alle weiteren Softwarekomponenten werden dann im Laufe des Tutorials installiert.
