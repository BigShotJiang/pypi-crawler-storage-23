# Erste Schritte

Die ersten Schritte Dokumentation leitet die Herausgeber durch die Abläufe zum
{doc}`Erstellen einer neuen μEdition <create>`, {doc}`hinzufügen einer Sprache <language-add>`,
{doc}`Erstellung von Inhalten <content>` und {doc}`Veröffentlichen <publish>`.

Die Anleitung erwartet keine großen, technischen Vorkenntnisse, ausser Grundkenntnisse über die Nutzung der
Kommandozeile.
