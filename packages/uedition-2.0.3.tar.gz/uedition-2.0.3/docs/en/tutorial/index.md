# Tutorial

This tutorial will take you through the process of creating a μEdition from scratch. It will not cover every bit of
functionality the μEdition supports, but will cover the main processes involved in creating a μEdition. After undertaking
the tutorial, you can then consult the rest of the documentation in order to make full use of all aspects of the μEdition.

To undertake this tutorial, you need Internet access, the ability to install software on your computer, and a web browser.
All other software required to create a μEdition will be installed as part of the tutorial.
