# Configuring sections

The μEdition supports three types of sections:

* Metadata sections for showing information taken from the `tei:teiHeader`.
* Text sections for showing a single, continuous text.
* Textlist sections for showing a list of sub-texts.

## Metadata sections
