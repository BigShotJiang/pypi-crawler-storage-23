# Recipes

This area contains a collection recipies for solving specific problems.

- [Mixed-content XML conversion](mixed-content-xml): The μEdition does not support mixed-content TEI XML. This recipe
  provides a simple conversion script to convert mixed-content TEI, in order to be able to use it in the μEdition.
