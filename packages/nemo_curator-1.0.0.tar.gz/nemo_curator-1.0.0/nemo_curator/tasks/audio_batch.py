# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from dataclasses import dataclass

from loguru import logger

from .tasks import Task


@dataclass
class AudioBatch(Task[dict]):
    """A single data dict with filepath check."""

    def __init__(
        self,
        data: dict | list[dict] | None = None,
        filepath_key: str | None = None,
        task_id: str = "",
        dataset_name: str = "",
        **kwargs,
    ):
        if isinstance(data, dict):
            self.data = [data]
        elif isinstance(data, list) or data is None:
            self.data = data
        else:
            raise ValueError(str(data))
        self.filepath_key = filepath_key
        super().__init__(data=self.data, task_id=task_id, dataset_name=dataset_name, **kwargs)

    @property
    def num_items(self) -> int:
        return len(self.data)

    def validate_item(self, item: dict) -> bool:
        if self.filepath_key is not None and not os.path.exists(item[self.filepath_key]):
            logger.warning(f"File {item[self.filepath_key]} does not exist")
            return False
        else:
            return True

    def validate(self) -> bool:
        """Validate the task data."""
        return all(self.validate_item(item) for item in self.data)
