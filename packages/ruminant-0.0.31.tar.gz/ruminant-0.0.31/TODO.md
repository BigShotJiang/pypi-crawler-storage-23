* new file formats
  * DjVu
  * INDD
  * WOFF2
  * Intel BIOS flash dumps
  * LZ4
* expand file formats
  * Jpeg XL
  * DICOM
* move out of misc.py
  * PE/ELF
* more consistent naming convention
* backends (process the json blob)
  * exiftool-like output
  * filtering/labeling files (e.g. "files that have a gps coordinate in the northern hemisphere")
  * plugins (?)
