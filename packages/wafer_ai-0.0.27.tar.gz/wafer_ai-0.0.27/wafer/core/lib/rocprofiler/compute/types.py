"""Type definitions for ROCprofiler-Compute tool.

Follows Wafer-391: ROCprofiler Tools Architecture.
"""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CheckResult:
    """Result of checking rocprof-compute installation.

    Attributes:
        installed: Whether rocprof-compute is installed
        path: Path to rocprof-compute executable
        version: Version string if available
        install_command: Installation instructions if not installed
    """
    installed: bool
    path: str | None = None
    version: str | None = None
    install_command: str | None = None


@dataclass(frozen=True)
class LaunchResult:
    """Result of building launch command for GUI server.

    Attributes:
        success: Whether command was built successfully
        command: Command array to spawn
        url: Expected URL of GUI server
        port: Port number
        folder: Folder path being analyzed
        error: Error message if unsuccessful
    """
    success: bool
    command: list[str] | None = None
    url: str | None = None
    port: int | None = None
    folder: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class GuiStatus:
    """Current status of GUI server.

    Note: This is managed by the extension handler, not by core.
    Core layer doesn't manage process lifecycle.

    Attributes:
        running: Whether server is currently running
        url: URL of running server
        port: Port number
        folder: Folder being analyzed
    """
    running: bool
    url: str | None = None
    port: int | None = None
    folder: str | None = None


@dataclass(frozen=True)
class ProfileResult:
    """Result of running rocprof-compute profiling or analysis.

    Attributes:
        success: Whether operation succeeded
        workload_path: Path to workload directory
        output_files: List of generated files
        command: Command that was executed
        stdout: Standard output
        stderr: Standard error
        error: Error message if unsuccessful
    """
    success: bool
    workload_path: str | None = None
    output_files: list[str] | None = None
    command: list[str] | None = None
    stdout: str | None = None
    stderr: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class KernelStats:
    """Statistics for a single kernel.

    Attributes:
        kernel_id: Kernel ID/index
        kernel_name: Name of the kernel
        dispatches: Number of dispatches
        duration_ns: Total duration in nanoseconds
        gpu_util: GPU utilization percentage
        memory_bw: Memory bandwidth in GB/s
        metrics: Additional metrics dictionary
    """
    kernel_id: int
    kernel_name: str
    dispatches: int
    duration_ns: float | None = None
    gpu_util: float | None = None
    memory_bw: float | None = None
    metrics: dict[str, Any] | None = None


@dataclass(frozen=True)
class RooflineData:
    """Roofline model data for a kernel.

    Attributes:
        kernel_name: Name of the kernel
        ai: Arithmetic intensity (FLOPS/Byte)
        perf: Performance (GFLOPS)
        roof_type: Roofline type (FP32, FP64, etc.)
    """
    kernel_name: str
    ai: float
    perf: float
    roof_type: str


@dataclass(frozen=True)
class AnalysisResult:
    """Result of analyzing rocprof-compute output.

    Attributes:
        success: Whether analysis succeeded
        workload_path: Path to workload directory
        architecture: GPU architecture (gfx90a, gfx942, etc.)
        kernels: List of kernel statistics
        roofline: Roofline data if available
        summary: Summary statistics
        error: Error message if unsuccessful
    """
    success: bool
    workload_path: str | None = None
    architecture: str | None = None
    kernels: list[KernelStats] | None = None
    roofline: list[RooflineData] | None = None
    summary: dict[str, Any] | None = None
    error: str | None = None
