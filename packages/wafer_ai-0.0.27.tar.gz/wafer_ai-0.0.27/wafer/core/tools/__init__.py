"""Tool executors.

Each file contains both a Tool schema definition and an exec_* function that returns ToolResult.

Imports are lazy: tools are only loaded when accessed, avoiding heavy deps
(pandas, numpy, asyncssh) at CLI startup time.
"""
from __future__ import annotations

import importlib
from typing import Any

_TOOL_REGISTRY: dict[str, tuple[str, list[str]]] = {
    "wafer.core.tools.ask_docs_tool": [
        "ASK_DOCS_TOOL",
        "exec_ask_docs",
    ],
    "wafer.core.tools.bash_tool": [
        "BASH_TOOL",
        "ApprovalCallback",
        "BashPermission",
        "BashPermissionResult",
        "check_bash_permissions",
        "exec_bash",
    ],
    "wafer.core.tools.capture_tool": [
        "CAPTURE_TOOL",
        "exec_capture",
    ],
    "wafer.core.tools.cloud_agent_tool": [
        "CloudAgentConfig",
        "CloudAgentEvent",
        "CloudAgentResult",
        "run_cloud_agent",
    ],
    "wafer.core.tools.eval_tool": [
        "EVAL_TOOL",
        "exec_eval",
    ],
    "wafer.core.tools.distributed_traces_tools": [
        "DISTRIBUTED_TRACES_ANALYZE_TOOL",
        "DISTRIBUTED_TRACES_COMPARE_TOOL",
        "exec_distributed_traces_analyze",
        "exec_distributed_traces_compare",
    ],
    "wafer.core.tools.file_tools": [
        "EDIT_TOOL",
        "GLOB_TOOL",
        "GREP_TOOL",
        "READ_TOOL",
        "WRITE_TOOL",
        "exec_edit",
        "exec_glob",
        "exec_grep",
        "exec_read",
        "exec_write",
    ],
    "wafer.core.tools.rocprof_compute_tools": [
        "ROCPROF_COMPUTE_ANALYZE_TOOL",
        "ROCPROF_COMPUTE_PROFILE_TOOL",
        "exec_rocprof_compute_analyze",
        "exec_rocprof_compute_profile",
    ],
    "wafer.core.tools.rocprof_sdk_tools": [
        "ROCPROF_SDK_ANALYZE_TOOL",
        "ROCPROF_SDK_PROFILE_TOOL",
        "exec_rocprof_sdk_analyze",
        "exec_rocprof_sdk_profile",
    ],
    "wafer.core.tools.sandbox_tool": [
        "SANDBOX_TOOL",
        "exec_sandbox",
    ],
    "wafer.core.tools.rocprof_systems_tools": [
        "ROCPROF_SYSTEMS_INSTRUMENT_TOOL",
        "ROCPROF_SYSTEMS_PROFILE_TOOL",
        "ROCPROF_SYSTEMS_QUERY_TOOL",
        "ROCPROF_SYSTEMS_SAMPLE_TOOL",
        "exec_rocprof_systems_instrument",
        "exec_rocprof_systems_profile",
        "exec_rocprof_systems_query",
        "exec_rocprof_systems_sample",
    ],
    "wafer.core.tools.skill_tool": [
        "SKILL_TOOL",
        "exec_skill",
    ],
    "wafer.core.tools.tracelens_tools": [
        "TRACELENS_COLLECTIVE_TOOL",
        "TRACELENS_COMPARE_TOOL",
        "TRACELENS_REPORT_TOOL",
        "exec_tracelens_collective",
        "exec_tracelens_compare",
        "exec_tracelens_report",
    ],
    "wafer.core.tools.wafer_tool": [
        "BLOCKED_WAFER_SUBCOMMANDS",
        "WAFER_SUBCOMMANDS",
        "WAFER_TOOL",
        "exec_wafer",
    ],
    "wafer.core.tools.write_kernel_tool": [
        "WRITE_KERNEL_TOOL",
        "KernelSubmission",
        "exec_write_kernel",
    ],
}

_NAME_TO_MODULE: dict[str, str] = {}
for _mod, _names in _TOOL_REGISTRY.items():
    for _name in _names:
        _NAME_TO_MODULE[_name] = _mod


def __getattr__(name: str) -> Any:
    module_path = _NAME_TO_MODULE.get(name)
    if module_path is not None:
        mod = importlib.import_module(module_path)
        val = getattr(mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = list(_NAME_TO_MODULE.keys())
