"""SandboxSession: manages tmux lifecycle and command execution on a remote machine."""
from __future__ import annotations

import logging
import shlex
from uuid import uuid4

import trio

from wafer.core.async_ssh import AsyncSSHClient
from wafer.core.sandbox.types import Sandbox


class SandboxSession:
    """Holds AsyncSSHClient, manages tmux lifecycle and command execution."""

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._client: AsyncSSHClient | None = None
        self._initialized = False

    @property
    def _tmp_dir(self) -> str:
        """Per-sandbox temp directory for command output files."""
        return f"/tmp/.wafer_sandbox/{self._sandbox.tmux_session}"

    @property
    def _pid_file(self) -> str:
        """Path to the PID file for the destroy-timer process."""
        return f"{self._tmp_dir}/destroy.pid"

    def _schedule_destroy_cmd(self) -> str:
        """Build command that starts a destroy timer and writes its PID to a file."""
        session = self._sandbox.tmux_session
        timeout_sec = max(3600, self._sandbox.timeout_hours * 3600)
        tmp = self._tmp_dir
        pid_file = self._pid_file
        return (
            f"bash -c '"
            f"nohup bash -c \""
            f"sleep {timeout_sec}; "
            f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null; "
            f"rm -rf {tmp}"
            f"\" >/dev/null 2>&1 & "
            f"echo $! > {pid_file}"
            f"'"
        )

    async def _kill_old_timer(self) -> None:
        """Kill destroy-timer by PID if pid file exists. Best-effort."""
        pid_file = self._pid_file
        result = await self._client.exec(f"cat {pid_file} 2>/dev/null")
        if result.exit_code == 0 and result.stdout.strip():
            pid = result.stdout.strip()
            await self._client.exec(f"kill {pid} 2>/dev/null || true")

    async def _refresh_timer(self) -> None:
        """Kill old destroy-timer, schedule a new one. Resets idle timer on activity."""
        await self._kill_old_timer()
        schedule_result = await self._client.exec(self._schedule_destroy_cmd())
        if schedule_result.exit_code != 0:
            logging.getLogger(__name__).warning(
                "sandbox: failed to schedule destroy timer: %s", schedule_result.stderr
            )

    async def start(self) -> None:
        """Connect, create NEW tmux session, schedule self-destruct."""
        self._client = AsyncSSHClient(
            self._sandbox.ssh_target,
            self._sandbox.ssh_key,
        )
        result = await self._client.exec("true")
        if result.exit_code != 0:
            raise RuntimeError(f"SSH connection failed: {result.stderr}")

        session = self._sandbox.tmux_session
        tmp = self._tmp_dir

        mkdir_result = await self._client.exec(f"mkdir -p {tmp}")
        if mkdir_result.exit_code != 0:
            raise RuntimeError(f"Failed to create sandbox tmp dir: {mkdir_result.stderr}")

        tmux_result = await self._client.exec(
            f"tmux new-session -d -s {shlex.quote(session)}"
        )
        if tmux_result.exit_code != 0:
            raise RuntimeError(f"Failed to create tmux session: {tmux_result.stderr}")

        schedule_result = await self._client.exec(self._schedule_destroy_cmd())
        if schedule_result.exit_code != 0:
            await self._client.exec(
                f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null || true"
            )
            raise RuntimeError(
                f"Failed to schedule sandbox destroy timer: {schedule_result.stderr}"
            )
        self._initialized = True

    async def connect(self) -> None:
        """Connect to an EXISTING tmux session (no new session created)."""
        self._client = AsyncSSHClient(
            self._sandbox.ssh_target,
            self._sandbox.ssh_key,
        )
        result = await self._client.exec("true")
        if result.exit_code != 0:
            raise RuntimeError(f"SSH connection failed: {result.stderr}")

        session = self._sandbox.tmux_session
        check = await self._client.exec(
            f"tmux has-session -t {shlex.quote(session)} 2>/dev/null"
        )
        if check.exit_code != 0:
            raise RuntimeError(
                f"tmux session '{session}' does not exist on remote. "
                f"Create one first: wafer sandbox create"
            )

        await self._client.exec(f"mkdir -p {self._tmp_dir}")
        self._initialized = True

    async def run_command(
        self,
        command: str,
        timeout: int = 180,
    ) -> tuple[str, int]:
        """Run command in tmux session. Returns (output, exit_code). exit_code=-1 on timeout.
        Refreshes the idle timer on each call so active sessions are not killed."""
        if not self._initialized or self._client is None:
            raise RuntimeError("SandboxSession not started; call start() first")

        await self._refresh_timer()

        cmd_id = uuid4().hex[:8]
        tmp = self._tmp_dir
        out_file = f"{tmp}/{cmd_id}.out"
        exit_file = f"{tmp}/{cmd_id}.exit"
        session = self._sandbox.tmux_session

        wrapped = (
            f"( {command} ) > {out_file} 2>&1; echo $? > {exit_file}"
        )
        send_cmd = f"tmux send-keys -t {shlex.quote(session)} {shlex.quote(wrapped)} Enter"
        await self._client.exec(send_cmd)

        poll_interval = 0.5
        elapsed = 0.0
        while elapsed < timeout:
            result = await self._client.exec(
                f"test -f {exit_file} && cat {exit_file}"
            )
            if result.exit_code == 0 and result.stdout.strip():
                exit_code_str = result.stdout.strip().split()[-1]
                try:
                    exit_code = int(exit_code_str)
                except ValueError:
                    exit_code = -1
                out_result = await self._client.exec(f"cat {out_file}")
                output = out_result.stdout or ""
                await self._client.exec(f"rm -f {out_file} {exit_file}")
                return output, exit_code
            await trio.sleep(poll_interval)
            elapsed += poll_interval

        # Timeout: read partial output
        out_result = await self._client.exec(f"cat {out_file} 2>/dev/null || true")
        partial = out_result.stdout or ""
        await self._client.exec(f"rm -f {out_file} {exit_file}")
        return partial, -1

    async def close(self) -> None:
        """Kill tmux session, clean up per-sandbox temp dir, close SSH client."""
        if not self._initialized or self._client is None:
            return
        session = self._sandbox.tmux_session
        await self._client.exec(
            f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null || true"
        )
        await self._client.exec(f"rm -rf {self._tmp_dir} 2>/dev/null || true")
        await self._client.close()
        self._client = None
        self._initialized = False
