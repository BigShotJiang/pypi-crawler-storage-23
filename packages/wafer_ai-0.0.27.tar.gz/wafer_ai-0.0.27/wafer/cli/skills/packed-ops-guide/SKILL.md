---
name: packed-ops-guide
description: Identify and convert scalar VALU operations to packed (v_pk_*) instructions in AMD GPU ISA for 2x throughput. Use when analyzing AMD GPU assembly for packing opportunities or optimizing GEMM epilogues.
---

# Packed Operation Identification & Optimization Guide

## What Are Packed Operations?

AMD CDNA/RDNA GPUs support **packed instructions** (`v_pk_*`) that process **2 data elements per instruction** instead of 1. This is essentially SIMD-within-SIMD: each lane of a wavefront processes a pair of values.

| Scalar (1 element/instr) | Packed (2 elements/instr) | Speedup |
|---------------------------|---------------------------|---------|
| `v_add_f32 v0, v0, v100` | `v_pk_add_f32 v[0:1], v[0:1], v[100:101]` | 2x |
| `v_mul_f32 v0, v0, s10`  | `v_pk_mul_f32 v[0:1], v[0:1], s[10:11]`   | 2x |
| `v_fma_f32 v0, v1, v2, v3` | `v_pk_fma_f32 v[0:1], v[2:3], v[4:5], v[6:7]` | 2x |

**Key constraint**: Packed ops work on **even-aligned register pairs** (`v[0:1]`, `v[2:3]`, `v[4:5]`, ...).

## When to Use This Skill

Activate this skill when:
- Analyzing AMD GPU ISA (`.s`, `.gcn`, `.asm`, `.co` files) for performance
- The ISA analysis reports "Packable scalar pairs found" > 0
- You see repeated scalar VALU ops (`v_add_f32`, `v_mul_f32`) on consecutive registers
- Optimizing GEMM/Tensile epilogue code
- The `wafer tool isa analyze` output shows packing opportunities

## How to Detect Packed Opportunities

### Step 1: Run ISA Analysis

```bash
wafer tool isa analyze kernel.s
```

The output now includes a **"Packed Operation Opportunities"** section:

```
=== Packed Operation Opportunities ===
  Already packed (v_pk_*): 0
  Packable scalar pairs: 16
  Scalar ops to replace: 32
  Packed ops needed: 16
  Instruction savings: 16 (45.7% of VALU)
  Packing ratio: 0%
    Region 1 (lines 15-46): 32 scalar -> 16 packed [epilogue_bias_scale_f32]

  OPPORTUNITY: 16 scalar VALU instruction pairs could be packed...
  ACTION: This looks like a scalar epilogue (e.g., Tensile-generated bias+scale)...
```

### Step 2: Identify the Pattern

Common packable patterns:

#### Pattern 1: Scalar Epilogue (Bias + Scale)
This is the **most common** pattern in Tensile/compiler-generated code. Each output element gets bias added and then scaled, one at a time:

```asm
; BEFORE: Tensile scalar epilogue (2 instructions per element)
v_add_f32 v0, v0, v100     ; Add bias to element 0
v_mul_f32 v0, v0, s10      ; Scale element 0
v_add_f32 v1, v1, v101     ; Add bias to element 1
v_mul_f32 v1, v1, s10      ; Scale element 1
v_add_f32 v2, v2, v102     ; Add bias to element 2
v_mul_f32 v2, v2, s10      ; Scale element 2
v_add_f32 v3, v3, v103     ; Add bias to element 3
v_mul_f32 v3, v3, s10      ; Scale element 3
; ... 8 instructions for 4 elements
```

```asm
; AFTER: Packed epilogue (1 instruction per 2 elements)
v_pk_add_f32 v[0:1], v[0:1], v[100:101]  ; Bias 2 elements at once
v_pk_mul_f32 v[0:1], v[0:1], s[10:11]    ; Scale 2 elements at once
v_pk_add_f32 v[2:3], v[2:3], v[102:103]  ; Bias next 2 elements
v_pk_mul_f32 v[2:3], v[2:3], s[10:11]    ; Scale next 2 elements
; ... 4 instructions for 4 elements (50% reduction!)
```

#### Pattern 2: Repeated Arithmetic
Same operation applied to consecutive elements:

```asm
; BEFORE: Scalar adds on consecutive registers
v_add_f32 v0, v0, v10
v_add_f32 v1, v1, v11
v_add_f32 v2, v2, v12
v_add_f32 v3, v3, v13

; AFTER: Packed adds
v_pk_add_f32 v[0:1], v[0:1], v[10:11]
v_pk_add_f32 v[2:3], v[2:3], v[12:13]
```

#### Pattern 3: Activation Functions
Elementwise activations applied to each GEMM output:

```asm
; BEFORE: Scalar ReLU-like pattern
v_max_f32 v0, v0, 0        ; ReLU element 0
v_max_f32 v1, v1, 0        ; ReLU element 1

; AFTER: (if v_pk_max_f32 available, or restructure with v_pk_* ops)
```

### Step 3: Verify Packability Requirements

For two scalar ops to be packable into one packed op:

1. **Same mnemonic**: Both must be the same instruction (e.g., both `v_add_f32`)
2. **Even-aligned destination pair**: First op targets `vN` where N is even, second targets `v(N+1)`
3. **Compatible source operands**: Sources should be:
   - Consecutive VGPRs (e.g., `v100` and `v101`)
   - Same scalar register (broadcast, e.g., both use `s10`)
   - Same literal constant
4. **Has packed equivalent**: The instruction must have a `v_pk_*` counterpart

### Step 4: Apply the Transformation

#### Manual Rewrite Rules

| Scalar Pair | Packed Equivalent |
|---|---|
| `v_add_f32 vN, ...` + `v_add_f32 v(N+1), ...` | `v_pk_add_f32 v[N:N+1], ...` |
| `v_mul_f32 vN, ...` + `v_mul_f32 v(N+1), ...` | `v_pk_mul_f32 v[N:N+1], ...` |
| `v_fma_f32 vN, ...` + `v_fma_f32 v(N+1), ...` | `v_pk_fma_f32 v[N:N+1], ...` |
| `v_add_f16 vN, ...` + `v_add_f16 v(N+1), ...` | `v_pk_add_f16 v[N:N+1], ...` |
| `v_mul_f16 vN, ...` + `v_mul_f16 v(N+1), ...` | `v_pk_mul_f16 v[N:N+1], ...` |
| `v_fma_f16 vN, ...` + `v_fma_f16 v(N+1), ...` | `v_pk_fma_f16 v[N:N+1], ...` |

#### Register Pair Rules

- Destination: `vN` + `v(N+1)` -> `v[N:N+1]` (N must be even)
- VGPR sources: `vM` + `v(M+1)` -> `v[M:M+1]`
- SGPR sources: `sK` + `sK` -> `s[K:K+1]` (broadcast same value to both halves)
- Literal: same literal in both -> literal (auto-broadcast)

## Architecture Support

| Architecture | f32 packed | f16 packed | Notes |
|---|---|---|---|
| gfx90a (MI210) | v_pk_{add,mul,fma}_f32 | Full f16 packed | CDNA2 |
| gfx942 (MI300X) | v_pk_{add,mul,fma}_f32 | Full f16 packed | CDNA3 |
| gfx1100+ (RDNA3) | Limited | v_pk_{add,mul,fma}_f16 | Consumer GPUs |
| gfx908 (MI100) | No f32 packed | Full f16 packed | CDNA1 |

**Important**: f32 packed operations (`v_pk_*_f32`) are only available on CDNA2+ (gfx90a and later). f16 packed operations have broader support.

## Programmatic API

You can also use the detection programmatically:

```python
from wafer.core.lib.kernel_scope.amdgcn import (
    parse_isa_text,
    analyze_isa,
    detect_packed_opportunities,
    format_packed_analysis,
    suggest_packed_rewrite,
    detect_packable_pairs,
)

# Parse and analyze
parse_result = parse_isa_text(isa_text)
analysis = analyze_isa(parse_result)

# Access packed opportunity analysis from ISAAnalysis
po = analysis.packed_opportunity
if po and po.total_packable_pairs > 0:
    print(f"Found {po.total_packable_pairs} packable pairs")
    print(f"Instruction savings: {po.instruction_savings}")
    print(f"VALU savings: {po.savings_pct_of_valu:.1f}%")
    
    # Show formatted analysis
    print(format_packed_analysis(po))
    
    # Show rewrite suggestions for each pair
    pairs = detect_packable_pairs(parse_result.instructions)
    for pair in pairs:
        print(suggest_packed_rewrite(pair))
```

## Workflow for Agent

When tasked with optimizing an AMD GPU kernel:

1. **Run ISA analysis**: `wafer tool isa analyze <file>`
2. **Check for packed opportunities**: Look for "Packed Operation Opportunities" section
3. **If opportunities found**:
   a. Note the regions and pattern type
   b. Look at the specific scalar instruction pairs
   c. Rewrite them using packed equivalents following the register pairing rules
   d. Verify the target architecture supports the packed ops (gfx90a+ for f32)
4. **If already fully packed**: Report that the kernel is already optimized for packing
5. **Quantify impact**: Report the instruction savings and VALU percentage improvement

## Key Metrics to Report

- **Packable pairs**: How many scalar instruction pairs can be converted
- **Instruction savings**: Total instructions eliminated (= number of pairs)
- **VALU savings %**: What percentage of VALU ops are saved
- **Packing ratio**: What fraction of packable work is already packed (0% = all scalar, 100% = all packed)
- **Pattern type**: What kind of computation is being packed (epilogue, arithmetic, etc.)

## Common Mistakes

1. **Forgetting even-alignment**: v1+v2 is NOT packable (v1 is odd). Only v0+v1, v2+v3, etc.
2. **Wrong architecture**: f32 packed ops don't exist on gfx908 (MI100) or earlier
3. **Ignoring source operand structure**: Both instructions must have compatible source patterns
4. **Packing across control flow**: Don't pack instructions separated by branches or barriers
