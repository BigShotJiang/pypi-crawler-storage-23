"""CO-OPS MCP Server — NOAA Tides & Currents for AI Assistants."""
