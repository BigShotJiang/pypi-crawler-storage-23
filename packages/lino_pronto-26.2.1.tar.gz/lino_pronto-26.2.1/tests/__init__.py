"""
Examples how to run these tests::

  $ python setup.py test
  $ python setup.py test -s tests.DocsTests
  $ python setup.py test -s tests.DocsTests.test_debts
  $ python setup.py test -s tests.DocsTests.test_docs
"""
# import os
# os.environ['DJANGO_SETTINGS_MODULE'] = "lino_pronto.projects.std.settings.test"

from unipath import Path
from lino.utils.pythontest import TestCase


class BaseTestCase(TestCase):
    project_root = Path(__file__).parent.parent
    django_settings_module = 'lino_pronto.projects.std.settings.test'


# class DemoTests(TestCase):

#     def test_std(self):
#         self.run_django_manage_test('lino_pronto/projects/std')
