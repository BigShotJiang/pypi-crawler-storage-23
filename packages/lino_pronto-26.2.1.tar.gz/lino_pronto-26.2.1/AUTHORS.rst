Authors
=======

Lino Pronto is written and maintained by Luc Saffre
<luc.saffre@gmail.com> and Hamza Khchine <hamzakhchine@gmail.com>.
