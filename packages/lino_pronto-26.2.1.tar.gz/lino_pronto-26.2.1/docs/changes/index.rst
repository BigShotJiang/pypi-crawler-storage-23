.. _pronto.changes:

======================
Changes in Lino Pronto
======================


Version 19.1.0 ()
============================================

This is a first prototype.


