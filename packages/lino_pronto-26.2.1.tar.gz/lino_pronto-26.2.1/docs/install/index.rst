.. _pronto.install:

======================
Installing Lino Pronto
======================

See http://www.lino-framework.org/
  
