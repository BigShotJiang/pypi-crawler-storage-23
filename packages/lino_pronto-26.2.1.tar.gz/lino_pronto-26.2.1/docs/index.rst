===========
Lino Pronto
===========

Welcome to the *Lino Pronto* project homepage.

.. py2rst::

  import lino_pronto
  print(lino_pronto.SETUP_INFO['long_description'])


Content
========

.. toctree::
   :maxdepth: 1

   tour/index
   install/index
   changes/index.rst
   api/index.rst
   specs/index.rst
   case_studies/index.rst
