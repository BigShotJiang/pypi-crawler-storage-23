.. doctest docs/specs/contacts.rst
.. include:: /../docs/shared/include/defs.rst

.. _pronto.specs.contacts:

========
Contacts
========

.. include:: /../docs/shared/include/tested.rst

>>> from lino import startup
>>> startup('lino_pronto.projects.pronto1.settings.doctests')
>>> from lino.api.doctest import *

