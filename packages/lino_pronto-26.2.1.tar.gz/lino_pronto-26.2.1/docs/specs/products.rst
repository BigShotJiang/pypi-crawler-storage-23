.. doctest docs/specs/products.rst
.. _specs.products:

===================================================
``products`` : defining the things you sell and buy
===================================================

.. currentmodule:: lino_xl.lib.products

The :mod:`lino_xl.lib.products` plugin adds functionality for managing
"products".

.. contents::
   :depth: 1
   :local:

.. include:: /../docs/shared/include/tested.rst

>>> from lino import startup
>>> startup('lino_pronto.projects.pronto1.settings.doctests')
>>> from lino.api.doctest import *
>>> ar = rt.login("robin")



Products
========


.. class:: Products

    >>> ar.show(products.Products)
    ... #doctest: +ELLIPSIS +NORMALIZE_WHITESPACE +REPORT_UDIFF
    ==== ================================== ============================== ========================
     ID   Designation                        Designation (bn)               Category
    ---- ---------------------------------- ------------------------------ ------------------------
     56   Air Conditioner                    এয়ার কন্ডিশনার                  Sports Equipment
     46   Blender                            ব্লেন্ডার                        Marine Supplies
     1    Cable clip (size: 10mm)            তারের ক্লিপ (আকার: ১০মিমি)      Cable clip
     2    Cable clip (size: 14mm)            তারের ক্লিপ (আকার: ১৪মিমি)      Cable clip
     3    Cable clip (size: 20mm)            তারের ক্লিপ (আকার: ২০মিমি)      Cable clip
     4    Cable clip (size: 25mm)            তারের ক্লিপ (আকার: ২৫মিমি)      Cable clip
     5    Cable clip (size: 4mm)             তারের ক্লিপ (আকার: ৪মিমি)       Cable clip
     6    Cable clip (size: 5mm)             তারের ক্লিপ (আকার: ৫মিমি)       Cable clip
     7    Cable clip (size: 6mm)             তারের ক্লিপ (আকার: ৬মিমি)       Cable clip
     8    Cable clip (size: 7mm)             তারের ক্লিপ (আকার: ৭মিমি)       Cable clip
     9    Cable clip (size: 8mm)             তারের ক্লিপ (আকার: ৮মিমি)       Cable clip
     10   Ceiling holder                     সিলিং হোল্ডার                   Holder
     11   Ceiling holder                     সিলিং হোল্ডার                   Holder
     45   Coffee Maker                       কফি মেকার                      Food & Beverages
     39   Desk Chair                         ডেস্ক চেয়ার                     Lighting
     51   Digital Camera                     ডিজিটাল ক্যামেরা                Kitchenware
     12   Distribution box (db box: 10-13)   বন্টন বাক্স (db box: ১০-১৩)      Distribution box
     13   Distribution box (db box: 14-16)   বন্টন বাক্স (db box: ১৪-১৬)      Distribution box
     14   Distribution box (db box: 4-6)     বন্টন বাক্স (db box: ৪-৬)        Distribution box
     15   Distribution box (db box: 7-9)     বন্টন বাক্স (db box: ৭-৯)        Distribution box
     16   Distribution box (db box: L1)      বন্টন বাক্স (db box: L1)         Distribution box
     17   Distribution box (db box: L2)      বন্টন বাক্স (db box: L2)         Distribution box
     55   Electric Kettle                    ইলেকট্রিক কেটল                  Exhaust Fan
     18   Exhaust fan (size: 10 inches)      নিষ্কাশন পাখা (আকার: ১০ ইঞ্চি)   Exhaust Fan
     19   Exhaust fan (size: 12 inches)      নিষ্কাশন পাখা (আকার: ১২ ইঞ্চি)   Exhaust Fan
     20   Exhaust fan (size: 6 inches)       নিষ্কাশন পাখা (আকার: ৬ ইঞ্চি)    Exhaust Fan
     21   Exhaust fan (size: 8 inches)       নিষ্কাশন পাখা (আকার: ৮ ইঞ্চি)    Exhaust Fan
     57   Fitness Tracker                    ফিটনেস ট্র্যাকার                 Lighting
     44   Headphones                         হেডফোন                         Wire tape
     22   Join box                           জয়েন বাক্স                      Switch box
     23   Join box                           জয়েন বাক্স                      Switch box
     38   Laptop                             ল্যাপটপ                         Piano indicator
     47   Microwave Oven                     মাইক্রোওয়েভ ওভেন                Switch box
     28   PVC box (four gang)                PVC বাক্স (চার গ্যাং)            Switch box
     29   PVC box (one gang)                 PVC বাক্স (এক গ্যাং)             Switch box
     30   PVC box (three gang)               PVC বাক্স (তিন গ্যাং)            Switch box
     31   PVC box (two gang)                 PVC বাক্স (দুই গ্যাং)            Switch box
     24   Piano cutout                       পিয়ানো কাটআউট                  Piano cutout
     25   Piano indicator                    পিয়ানো ইন্ডিকেটর                Piano indicator
     26   Piano socket                       পিয়ানো সকেট                    Piano socket
     27   Piano switch                       পিয়ানো সুইচ                    Piano switch
     48   Refrigerator                       ফ্রিজ                           Socket
     40   Running Shoes                      দৌড়ানোর জুতা                   Lighting
     37   Smartphone                         স্মার্টফোন                       Construction Materials
     53   Smartwatch                         স্মার্টওয়াচ                      Fan
     32   Steel box (four gang)              স্টিল বাক্স (চার গ্যাং)           Switch box
     33   Steel box (one gang)               স্টিল বাক্স (এক গ্যাং)            Switch box
     34   Steel box (three gang)             স্টিল বাক্স (তিন গ্যাং)           Switch box
     35   Steel box (two gang)               স্টিল বাক্স (দুই গ্যাং)           Switch box
     42   Sunglasses                         সানগ্লাস                        Kitchenware
     52   Tablet                             ট্যাবলেট                        Marine Supplies
     36   Tape                               টেপ                            Wire tape
     50   Vacuum Cleaner                     ভ্যাকুয়াম ক্লিনার                Craft Materials
     49   Washing Machine                    ওয়াশিং মেশিন                   Laboratory Equipment
     41   Wristwatch                         ক্লক                            Piano socket
    ==== ================================== ============================== ========================
    <BLANKLINE>


.. class:: Services

    >>> ar.show(products.Services)
    ... #doctest: +ELLIPSIS +NORMALIZE_WHITESPACE -REPORT_UDIFF
    No data to display


.. class:: Category

    Can be used to group products into "categories".  Categories can be edited by the user.

    >>> ar.show(products.Categories)
    ... #doctest: +ELLIPSIS +NORMALIZE_WHITESPACE +REPORT_UDIFF
    ==== ============== ======================== ================== ==============
     ID   Parent         Designation              Designation (bn)   Product type
    ---- -------------- ------------------------ ------------------ --------------
     3                   Electrical               বৈদ্যুতিক           Products
     4    Electrical     Fan                      পাখা               Products
     5    Fan            Exhaust Fan              নিষ্কাশন পাখা       Products
     6    Electrical     Cable clip               তারের ক্লিপ         Products
     7    Electrical     Distribution box         বন্টন বাক্স          Products
     8    Electrical     Wire tape                তারের টেপ          Products
     9    Electrical     Switch box               সুইচ বক্স           Products
     10   Electrical     Switch                   সুইচ               Products
     11   Switch         Piano switch             পিয়ানো সুইচ        Products
     12   Switch         Gang switch              গ্যাং সুইচ          Products
     13   Electrical     Socket                   সকেট               Products
     14   Socket         Piano socket             পিয়ানো সকেট        Products
     15   Electrical     Cutout                   কাটআউট             Products
     16   Cutout         Piano cutout             পিয়ানো কাটআউট      Products
     17   Electrical     Indicator                ইন্ডিকেটর           Products
     18   Indicator      Piano indicator          পিয়ানো ইন্ডিকেটর    Products
     19   Electrical     Holder                   হোল্ডার             Products
     20   Electrical     Pipe                     পাইপ               Products
     23   Exhaust Fan    Clothing                 পোশাক              Products
     27   Switch box     Sports Equipment         ক্রীড়া সরঞ্জাম       Products
     31   Socket         Health Products          স্বাস্থ্য পণ্য         Products
     35                  Musical Instruments      সঙ্গীত যন্ত্র         Products
     39                  Kitchenware              রান্নাঘরের সরঞ্জাম   Products
     43                  Craft Materials          শিল্প সামগ্রী        Products
     47   Piano switch   Lighting                 আলো                Products
     51   Cutout         Fitness Equipment        ফিটনেস সরঞ্জাম      Products
     55                  Sunglasses               সানগ্লাস            Products
     59   Exhaust Fan    Food & Beverages         খাদ্য ও পানীয়       Products
     63                  Construction Materials   নির্মাণ সামগ্রী      Products
     67   Socket         Marine Supplies          মেরিন সরবরাহ       Products
     71                  Laboratory Equipment     প্রয়োগশালা সরঞ্জাম   Products
    ==== ============== ======================== ================== ==============
    <BLANKLINE>


.. class:: ProductTypes

    Can be used to group products into "types".  Types cannot be edited by the
    user.  But every product type can have a layout on its own.

    >>> rt.show(products.ProductTypes)
    ... #doctest: +ELLIPSIS +NORMALIZE_WHITESPACE -REPORT_UDIFF
    ======= ========== ========== ===================
     value   name       text       Table name
    ------- ---------- ---------- -------------------
     100     default    Products   products.Products
     200     services   Services   products.Services
     300     parts      Parts      products.Parts
    ======= ========== ========== ===================
    <BLANKLINE>


.. class:: DeliveryUnits

    The list of possible delivery units of a product.

    >>> rt.show(products.DeliveryUnits)
    ======= ======= ========
     value   name    text
    ------- ------- --------
     10      hour    Hours
     20      piece   Pieces
     30      kg      Kg
     40      box     Boxes
     45      pack    Packs
    ======= ======= ========
    <BLANKLINE>
