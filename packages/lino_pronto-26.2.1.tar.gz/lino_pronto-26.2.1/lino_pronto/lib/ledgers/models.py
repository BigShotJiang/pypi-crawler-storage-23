# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""This module defines the `ledgers` models for Lino Pronto.
"""

import datetime as dt
from django.db import models
from django.utils.text import format_lazy
from lino.api import dd, rt, _
from lino.modlib.users.choicelists import UserTypes
from lino.utils import AttrDict
from lino.utils.html import tostring, mark_safe
from lino.utils.format_number import localize_number
from lino_xl.lib.ledgers.models import *
from .actions import MakeSubscriptionRequest

Ledger.ledger_subscribe_on_ledger = MakeSubscriptionRequest(
    params_layout="""
    role
    user
    """
)


def _user_type_choices(ar):
    user = ar.get_user()
    my_type = int(user.user_type.value)
    types = [int(ut.value) for ut in UserTypes.get_list_items() if not ut.readonly]
    allowed_types = [ut for ut in types if ut <= my_type]
    return [UserTypes.get_by_value(str(ut)) for ut in allowed_types]


class LedgerSubscriptionRequest(dd.Model):
    class Meta:
        app_label = "ledgers"
        verbose_name = _("Ledger subscription request")
        verbose_name_plural = _("Ledger subscription requests")
        abstract = dd.is_abstract_model(__name__, "LedgerSubscriptionRequest")
        unique_together = ["ledger", "user"]

    ledger = dd.ForeignKey(
        "ledgers.Ledger",
        verbose_name=_("Ledger"),
        editable=False,
    )

    user = dd.ForeignKey(
        "users.User",
        verbose_name=_("User"),
        editable=False,
    )

    role = dd.ForeignKey(
        "contacts.RoleType",
        verbose_name=_("Role"),
    )

    user_type = UserTypes.field(
        verbose_name=_("User type"),
        default=dd.plugins.users.user_type_verified,
    )

    @dd.action(label=_("Approve"), select_rows=True)
    def approve_subscription(self, ar, **kw):
        make_subscription = rt.models.ledgers.make_ledger_subscription
        apv = AttrDict(dict(
            company=self.ledger.company,
            ledger=self.ledger,
            role=self.role,
        ))
        tbl = rt.models.ledgers.MyLedgerSubscriptionRequests
        ses = tbl.create_request(parent=ar)
        make_subscription(self.user, apv, ses, user_type=self.user_type)
        self.delete()
        ar.success(format_lazy(
            _("Subscription for user {user} to ledger {ledger} has been approved."),
            user=self.user, ledger=self.ledger))
        ar.set_response(refresh=True)

    @dd.action(label=_("Deny"), select_rows=True)
    def reject_subscription(self, ar, **kw):
        self.delete()
        ar.success(format_lazy(
            _("Subscription request for user {user} to ledger {ledger} has been rejected."),
            user=self.user, ledger=self.ledger))
        ar.set_response(refresh=True)

    @dd.displayfield(_("Action"))
    def approve_subscription_button(self, ar):
        if ar is None:
            return ""
        return (tostring(ar.instance_action_button(self.approve_subscription, _("Approve")))
                 + " | " +
                tostring(ar.instance_action_button(self.reject_subscription, _("Deny"))))

    @dd.chooser()
    def user_type_choices(self, ar):
        return _user_type_choices(ar)


class MyLedgerSubscriptionRequests(dd.Table):
    label = _("My ledger subscription requests")
    model = "ledgers.LedgerSubscriptionRequest"
    column_names = "ledger user role user_type approve_subscription_button"

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        user = ar.get_user()
        if user.is_anonymous or user.ledger is None:
            return cls.model.objects.none()
        return super().get_request_queryset(ar).filter(ledger=user.ledger)
    

def get_subscription_action_permissions(ar, obj, state):
    user = ar.get_user()
    if user.is_anonymous or user.ledger is None:
        return False
    if int(user.user_type.value) < int(obj.user_type.value):
        return False
    return True


class MyLedgerSubscribers(dd.Table):
    label = _("My ledger subscribers")
    model = "users.User"
    column_names = "person_first_name person_last_name user_type end_subscription_button"
    allow_create = False
    allow_delete = False
    hide_top_toolbar = True

    parameters = dict(
        show_old_users=dd.BooleanField(default=False, verbose_name=_("Show old users"))
    )

    params_layout = """
    show_old_users
    """

    @dd.action(
        get_action_permission=get_subscription_action_permissions,
        label=_("End subscription"),
        select_rows=True,
        show_in_toolbar=False,
    )
    def end_subscription(cls, ar):
        obj = ar.selected_rows[0]
        assert isinstance(obj, rt.models.users.User)
        def confirmed(ar):
            # obj.start_date = obj.start_date - dt.timedelta(days=1)
            # obj.end_date = dd.today() - dt.timedelta(days=1)
            obj.end_date = dd.today()
            obj.user_type = dd.plugins.users.user_type_new
            obj.full_clean()
            obj.save()
            ar.success(format_lazy(
                _("Subscription of user {user} has been ended."),
                user=obj))
            ar.set_response(refresh=True)
        msg = format_lazy(
            _("Are you sure you want to end the subscription of user {user}?"),
            user=obj)
        return ar.confirm(confirmed, msg)

    @dd.action(
        get_action_permission=get_subscription_action_permissions,
        label=_("Reactivate user"),
        select_rows=True,
        show_in_toolbar=False,
    )
    def reactivate_user(cls, ar):
        obj = ar.selected_rows[0]
        assert isinstance(obj, rt.models.users.User)
        def confirmed(ar):
            obj.end_date = None
            obj.start_date = dd.today()
            obj.full_clean()
            obj.save()
            ar.success(format_lazy(
                _("User {user} has been reactivated."),
                user=obj))
            ar.set_response(refresh=True)
        msg = format_lazy(
            _("Are you sure you want to reactivate user {user}?"),
            user=obj)
        return ar.confirm(confirmed, msg)

    @dd.displayfield(_("Action"))
    def end_subscription_button(cls, obj, ar, **kw):
        if ar is None:
            return ""
        
        state = None
        if obj.workflow_state_field is not None:
            state = getattr(obj, obj.workflow_state_field.name)

        action_not_available = mark_safe(_("No action available"))
        
        if (obj.end_date is None or obj.end_date > dd.today()) and obj.start_date <= dd.today():
            action = cls.get_action_by_name("end_subscription")
            if not action.get_bound_action_permission(ar, obj, state):
                return action_not_available
            return tostring(ar.row_action_button(obj, cls.get_action_by_name("end_subscription")))
        
        action = cls.get_action_by_name("reactivate_user")
        if not action.get_bound_action_permission(ar, obj, state):
            return action_not_available
        return tostring(ar.row_action_button(obj, cls.get_action_by_name("reactivate_user")))

    @dd.displayfield(_("First name"))
    def person_first_name(self, obj, ar, **kw):
        return obj.person.first_name

    @dd.displayfield(_("Last name"))
    def person_last_name(self, obj, ar, **kw):
        return obj.person.last_name
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        if "user_type" in dfs and int(ar.get_user().user_type.value) >= int(obj.user_type.value):
            dfs.remove("user_type")
        return dfs
    
    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        old_user_filter = models.Q()
        if not ar.param_values.show_old_users:
            old_user_filter = models.Q(end_date__isnull=True) | models.Q(end_date__gt=dd.today())
        return qs.filter(old_user_filter, ledger=ar.get_user().ledger)
    
    @dd.chooser()
    def user_type_choices(self, ar):
        return _user_type_choices(ar)


def welcome_messages(ar):
    if (user := ar.get_user()).is_anonymous:
        return
    if user.ledger is None:
        yield mark_safe("<p>")
        yield _("You are not subscribed to any ledger.")
        yield mark_safe("</p>")
    if user.user_type.has_required_roles([LedgerStaff]):
        if (req_count := rt.models.ledgers.LedgerSubscriptionRequest.objects.filter(
            ledger=user.ledger).count()) > 0:
            tbl = rt.models.ledgers.MyLedgerSubscriptionRequests
            sar = tbl.create_request(parent=ar, action=tbl.default_action)
            yield mark_safe("<p><strong>⇒ </strong>")
            yield format_lazy(
                _("You have {req_count} pending subscription requests. See: "),
                req_count=localize_number(req_count),
            )
            yield sar.ar2button(label=_("subscription request's table"))
            yield "."
            yield mark_safe("</p>")

dd.add_welcome_handler(welcome_messages)