# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""This module defines the `ledgers` package for Lino Pronto.
"""

from lino_xl.lib.ledgers import Plugin


class Plugin(Plugin):
    """The `ledgers` plugin for Lino Pronto."""
    
    def setup_config_menu(self, site, user_type, m, ar=None):
        m = m.add_menu(self.app_label, self.verbose_name)
        m.add_action('ledgers.MyLedgerSubscribers')
        m.add_action('ledgers.MyLedgerSubscriptionRequests')
