# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""This module defines actions for the `ledgers` plugin for Lino Pronto.
"""

from django.utils.text import format_lazy
from lino.api import _, dd, rt
from lino_xl.lib.ledgers.actions import *


class MakeSubscriptionRequest(SubscribeToLedger):
    label = _("Request ledger subscription")
    button_text = "📝"  # "🙋"

    def is_parameters_valid(self, ar, apv):
        if not super().is_parameters_valid(ar, apv):
            return False

        if rt.models.ledgers.LedgerSubscriptionRequest.objects.filter(
            ledger=apv['ledger'] or apv["company"].ledger,
            user=self.user).exists():
            ar.error(format_lazy(
                _("Invalid operation: A subscription request for User ({}) to the selected ledger already exists"),
                self.user))
            return False

        return True

    @staticmethod
    def make_subscription(authorizable_user, apv, ar):
        model = rt.models.ledgers.LedgerSubscriptionRequest
        req_obj = model(ledger=apv['ledger'] or apv["company"].ledger,
                        user=authorizable_user, role=apv['role'],
                        user_type=dd.plugins.users.user_type_verified)
        req_obj.full_clean()
        tbl = rt.models.ledgers.MyLedgerSubscriptionRequests
        req_obj.save_new_instance(tbl.create_request(parent=ar))
        ar.success(format_lazy(
            _("Subscription request for user {user} to ledger {ledger} has been created."),
            user=apv['user'], ledger=req_obj.ledger))
