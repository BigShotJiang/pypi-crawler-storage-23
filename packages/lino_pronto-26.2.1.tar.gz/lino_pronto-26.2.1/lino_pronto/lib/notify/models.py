# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.db import connection
from django.db.models import OuterRef, Subquery
from django.db.models.functions import Coalesce
from django.conf import settings
from django.utils import translation

from lino.api import dd, rt, _
from lino.modlib.linod.choicelists import schedule_daily, schedule_often
from lino.modlib.notify.choicelists import MailModes
from lino.modlib.notify.models import *

USE_SQL_CTE = dd.get_plugin_setting("notify", "use_sql_cte")
subaddress_separator = dd.get_plugin_setting("inbox", "subaddress_separator", None)


class Message(Message):
    class Meta(Message.Meta):
        app_label = "notify"
        abstract = dd.is_abstract_model(__name__, "Message")

    @classmethod
    def send_summary_emails(cls, ar, mm):
        if USE_SQL_CTE:  # Do nothing send_summary_emails_cte() will run instead
            return
        qs = cls.objects.filter(sent__isnull=True, user__isnull=False)

        User = settings.SITE.user_model
        active_users_with_email = User.get_active_users().filter(
            email__isnull=False,
            email__gt="",
        )
        qs = User.filter_active_users(qs, dd.today(), prefix="user__")
        qs = qs.filter(
            user__email__isnull=False,
            user__email__gt="",
            user__user_type__isnull=False,
        ).exclude(user__user_type="")

        Authority = rt.models.users.Authority

        authorized_ids = Authority.objects.filter(
            user_id=OuterRef("user_id")
        ).values("authorized_id")

        max_authority_depth = 8
        user_with_email_candidates = [
            Subquery(
                active_users_with_email.filter(pk=OuterRef("user_id")).values("pk")[:1]
            )
        ]

        user_with_email_candidates.append(
            Subquery(
                active_users_with_email.filter(pk__in=Subquery(authorized_ids)).values("pk")[:1]
            )
        )

        depth = 2
        while depth <= max_authority_depth:
            authorized_ids = Authority.objects.filter(
                user_id__in=Subquery(authorized_ids)
            ).values("authorized_id")
            user_with_email_candidates.append(
                Subquery(
                    active_users_with_email.filter(pk__in=Subquery(authorized_ids)).values("pk")[:1]
                )
            )
            depth += 1

        qs = qs.annotate(user_with_email_id=Coalesce(*user_with_email_candidates))
        qs = qs.filter(user_with_email_id__isnull=False)

        qs = qs.filter(mail_mode=mm).order_by("user")
        if qs.count() == 0:
            ar.logger.debug("No email notifications to send for %s.", mm)
            return

        recipient_ids = set(qs.values_list("user_with_email_id", flat=True))
        recipients_by_id = {
            u.id: u for u in User.objects.filter(pk__in=recipient_ids)
        }

        ar.renderer = dd.plugins.memo.front_end.renderer
        ar.permalink_uris = True
        sender_parts = settings.SERVER_EMAIL.split("@")
        assert len(sender_parts) == 2
        context = ar.get_printable_context()
        template = rt.get_template("notify/summary.eml")
        users = dict()

        def collect(user, obj):
            lst = users.setdefault(user, [])
            lst.append(obj)

        for obj in qs:
            user = recipients_by_id.get(obj.user_with_email_id)
            if user is not None:
                collect(user, obj)

        ar.logger.debug(
            "Send out '%s' summaries for %d users.", mm, len(users))
        for user, messages in users.items():
            with translation.override(user.language):
                sender = sender_parts[0]
                if len(messages) == 1:
                    msg = messages[0]
                    subject = msg.subject
                    if subaddress_separator is not None:
                        if msg.reply_to_id:
                            sender += subaddress_separator + str(msg.reply_to_id)
                        elif msg.owner_id:
                            sender += subaddress_separator + str(msg.owner_type)
                            sender += subaddress_separator + str(msg.owner_id)
                else:
                    subject = _("{} notifications").format(len(messages))
                sender += "@" + sender_parts[1]
                subject = settings.EMAIL_SUBJECT_PREFIX + subject
                context.update(user=user, messages=messages)
                body = template.render(**context)
                ar.send_email(subject, sender, body, [user.email])
                for msg in messages:
                    msg.sent = dd.now()
                    if dd.plugins.notify.mark_seen_when_sent:
                        msg.seen = dd.now()
                    msg.save()
                ar.logger.debug("Sent '%s' summary email to %s.", mm, user)

    @classmethod
    def send_summary_emails_cte(cls, ar, mm, max_authority_depth=8):
        message_table = connection.ops.quote_name(cls._meta.db_table)
        authority_table = connection.ops.quote_name(rt.models.users.Authority._meta.db_table)
        user_model = settings.SITE.user_model
        user_table = connection.ops.quote_name(user_model._meta.db_table)
        mail_mode_value = getattr(mm, "value", mm)
        today = dd.today()

        sql = f"""
WITH RECURSIVE chain AS (
    SELECT
        m.id AS message_id,
        m.user_id AS current_user_id,
        0 AS depth,
        (
            u.email IS NOT NULL
            AND u.email > ''
            AND u.user_type IS NOT NULL
            AND u.user_type <> ''
            AND (u.start_date IS NULL OR u.start_date <= %s)
            AND (u.end_date IS NULL OR u.end_date >= %s)
        ) AS found_email
    FROM {message_table} m
    JOIN {user_table} u ON u.id = m.user_id
    WHERE m.sent IS NULL
      AND m.user_id IS NOT NULL
      AND m.mail_mode = %s

    UNION ALL

    SELECT
        c.message_id,
        a.authorized_id AS current_user_id,
        c.depth + 1 AS depth,
        (
            u.email IS NOT NULL
            AND u.email > ''
            AND u.user_type IS NOT NULL
            AND u.user_type <> ''
            AND (u.start_date IS NULL OR u.start_date <= %s)
            AND (u.end_date IS NULL OR u.end_date >= %s)
        ) AS found_email
    FROM chain c
    JOIN {authority_table} a ON a.user_id = c.current_user_id
    JOIN {user_table} u ON u.id = a.authorized_id
    WHERE c.depth < %s
      AND NOT c.found_email
),
eligible AS (
    SELECT
        c.message_id,
        c.current_user_id AS user_id,
        c.depth
    FROM chain c
    WHERE c.found_email
),
ranked AS (
    SELECT
        e.message_id,
        e.user_id,
        row_number() OVER (
            PARTITION BY e.message_id
            ORDER BY e.depth ASC, e.user_id ASC
        ) AS rn
    FROM eligible e
)
SELECT message_id, user_id
FROM ranked
WHERE rn = 1
"""

        with connection.cursor() as cursor:
            cursor.execute(
                sql,
                [
                    today,
                    today,
                    mail_mode_value,
                    today,
                    today,
                    max_authority_depth,
                ],
            )
            rows = cursor.fetchall()

        if not rows:
            ar.logger.debug("No email notifications to send for %s.", mm)
            return

        # message_ids = {message_id for message_id, _ in rows}
        # recipient_ids = {user_id for _, user_id in rows}
        # recipients_by_id = {
        #     u.id: u for u in user_model.objects.filter(pk__in=recipient_ids)
        # }
        # messages_by_id = {
        #     m.id: m for m in cls.objects.filter(pk__in=message_ids)
        # }

        ar.renderer = dd.plugins.memo.front_end.renderer
        ar.permalink_uris = True
        sender_parts = settings.SERVER_EMAIL.split("@")
        assert len(sender_parts) == 2
        context = ar.get_printable_context()
        template = rt.get_template("notify/summary.eml")
        users = dict()

        def collect(user, obj):
            lst = users.setdefault(user, [])
            lst.append(obj)

        for message_id, user_id in rows:
            try:
                user = user_model.objects.get(pk=user_id)
            except user_model.DoesNotExist:
                continue
            try:
                obj = cls.objects.get(pk=message_id)
            except cls.DoesNotExist:
                continue
            # user = recipients_by_id.get(user_id)
            # obj = messages_by_id.get(message_id)
            # if user is not None and obj is not None:
            #     collect(user, obj)
            collect(user, obj)

        ar.logger.debug(
            "Send out '%s' summaries for %d users.", mm, len(users))
        for user, messages in users.items():
            with translation.override(user.language):
                sender = sender_parts[0]
                if len(messages) == 1:
                    msg = messages[0]
                    subject = msg.subject
                    if subaddress_separator is not None:
                        if msg.reply_to_id:
                            sender += subaddress_separator + str(msg.reply_to_id)
                        elif msg.owner_id:
                            sender += subaddress_separator + str(msg.owner_type)
                            sender += subaddress_separator + str(msg.owner_id)
                else:
                    subject = _("{} notifications").format(len(messages))
                sender += "@" + sender_parts[1]
                subject = settings.EMAIL_SUBJECT_PREFIX + subject
                context.update(user=user, messages=messages)
                body = template.render(**context)
                ar.send_email(subject, sender, body, [user.email])
                for msg in messages:
                    msg.sent = dd.now()
                    if dd.plugins.notify.mark_seen_when_sent:
                        msg.seen = dd.now()
                    msg.save()


@schedule_often(every=10, during_initdb=False)
def send_pending_emails_often_cte(ar):
    if not USE_SQL_CTE:
        return
    rt.models.notify.Message.send_summary_emails_cte(ar, MailModes.often)


@schedule_daily(during_initdb=False)
def send_pending_emails_daily_cte(ar):
    if not USE_SQL_CTE:
        return
    rt.models.notify.Message.send_summary_emails_cte(ar, MailModes.daily)
