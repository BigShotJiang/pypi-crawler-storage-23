# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.modlib.notify import Plugin as BasePlugin


class Plugin(BasePlugin):
    """Notify plugin overrides for Lino Pronto."""

    extends_models = ["Message"]
    use_sql_cte = False  # Set to True to use Common Table Expressions for email sending tasks
