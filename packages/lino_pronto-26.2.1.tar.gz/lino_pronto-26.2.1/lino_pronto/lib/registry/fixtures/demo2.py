import random
from django.db import models, connection
from lino.api import rt, dd
from lino.utils import Cycler

random.seed(1)


def reset_sequence(model_class):
    """Reset the database sequence for a model's primary key after manual ID assignments.
    Compatible with PostgreSQL and SQLite."""
    table_name = model_class._meta.db_table
    
    with connection.cursor() as cursor:
        if connection.vendor == 'postgresql':
            # PostgreSQL uses sequences
            sequence_name = f"{table_name}_id_seq"
            cursor.execute(
                f"SELECT setval('{sequence_name}', COALESCE((SELECT MAX(id) FROM {table_name}), 1), true)"
            )
        elif connection.vendor == 'sqlite':
            # SQLite uses sqlite_sequence table
            cursor.execute(f"SELECT MAX(id) FROM {table_name}")
            max_id = cursor.fetchone()[0]
            if max_id is not None:
                cursor.execute(
                    f"UPDATE sqlite_sequence SET seq = {max_id} WHERE name = '{table_name}'"
                )
        # MySQL uses AUTO_INCREMENT and typically handles this automatically


AssociationTypes = rt.models.contacts.AssociationTypes
Company = rt.models.contacts.Company
RegistrationStates = rt.models.registry.RegistrationStates
CompanyRegistrationRequest = rt.models.registry.CompanyRegistrationRequest

COMPANY_NAMES = [
    "Alpha Corp", "Beta LLC", "Gamma Inc", "Delta Ltd", "Epsilon GmbH",
    "Zeta SA", "Eta BV", "Theta PLC", "Iota Co", "Kappa AG",
    "Lambda Enterprises", "Mu Holdings", "Nu Group", "Xi Partners",
    "Omicron Solutions", "Pi Systems", "Rho Technologies", "Sigma Innovations",
    "Tau Dynamics", "Upsilon Networks", "Phi Ventures", "Chi Labs",
    "Psi Industries", "Omega Services"
]

# (English, Bengali) tuple
PRODUCT_CATEGORY_NAMES = [
    ("Electronics", "ইলেকট্রনিক্স"),
    ("Furniture", "আসবাবপত্র"),
    ("Clothing", "পোশাক"),
    ("Books", "বই"),
    ("Toys", "খেলনা"),
    ("Groceries", "মুদিখানা"),
    ("Sports Equipment", "ক্রীড়া সরঞ্জাম"),
    ("Beauty Products", "সৌন্দর্য পণ্য"),
    ("Automotive Parts", "অটোমোটিভ অংশ"),
    ("Garden Supplies", "বাগান সরবরাহ"),
    ("Health Products", "স্বাস্থ্য পণ্য"),
    ("Office Supplies", "অফিস সরবরাহ"),
    ("Pet Supplies", "পোষা প্রাণীর সরবরাহ"),
    ("Jewelry", "গহনা"),
    ("Musical Instruments", "সঙ্গীত যন্ত্র"),
    ("Baby Products", "শিশু পণ্য"),
    ("Footwear", "পাদুকা"),
    ("Home Decor", "বাড়ির সজ্জা"),
    ("Kitchenware", "রান্নাঘরের সরঞ্জাম"),
    ("Outdoor Gear", "আউটডোর গিয়ার"),
    ("Travel Accessories", "ভ্রমণ আনুষাঙ্গিক"),
    ("Art Supplies", "শিল্প সরবরাহ"),
    ("Craft Materials", "শিল্প সামগ্রী"),
    ("Cleaning Products", "পরিষ্কার করার পণ্য"),
    ("Hardware", "হার্ডওয়্যার"),
    ("Tools", "সরঞ্জাম"),
    ("Lighting", "আলো"),
    ("Appliances", "যন্ত্রপাতি"),
    ("Bedding", "বিছানার কাপড়"),
    ("Bath Products", "স্নান পণ্য"),
    ("Fitness Equipment", "ফিটনেস সরঞ্জাম"),
    ("Stationery", "স্টেশনারি"),
    ("Cameras", "ক্যামেরা"),
    ("Watches", "ঘড়ি"),
    ("Sunglasses", "সানগ্লাস"),
    ("Hobby Supplies", "শখের সরবরাহ"),
    ("Collectibles", "সংগ্রহযোগ্য বস্তু"),
    ("Seasonal Items", "মৌসুমী আইটেম"),
    ("Food & Beverages", "খাদ্য ও পানীয়"),
    ("Medical Supplies", "চিকিৎসা সরবরাহ"),
    ("Safety Equipment", "নিরাপত্তা সরঞ্জাম"),
    ("Industrial Supplies", "শিল্প সরবরাহ"),
    ("Construction Materials", "নির্মাণ সামগ্রী"),
    ("Electrical Supplies", "বৈদ্যুতিক সরবরাহ"),
    ("Plumbing Supplies", "প্লাম্বিং সরবরাহ"),
    ("HVAC Equipment", "এইচভিএসি সরঞ্জাম"),
    ("Marine Supplies", "মেরিন সরবরাহ"),
    ("Aerospace Components", "এয়ারোস্পেস উপাদান"),
    ("Agricultural Products", "কৃষি পণ্য"),
    ("Chemical Products", "রাসায়নিক পণ্য"),
    ("Laboratory Equipment", "প্রয়োগশালা সরঞ্জাম"),
]

# product names (en, bn)
PRODUCT_NAMES = [
    ("Smartphone", "স্মার্টফোন"),
    ("Laptop", "ল্যাপটপ"),
    ("Desk Chair", "ডেস্ক চেয়ার"),
    ("Running Shoes", "দৌড়ানোর জুতা"),
    ("Wristwatch", "ক্লক"),
    ("Sunglasses", "সানগ্লাস"),
    ("Backpack", "ব্যাকপ্যাক"),
    ("Headphones", "হেডফোন"),
    ("Coffee Maker", "কফি মেকার"),
    ("Blender", "ব্লেন্ডার"),
    ("Microwave Oven", "মাইক্রোওয়েভ ওভেন"),
    ("Refrigerator", "ফ্রিজ"),
    ("Washing Machine", "ওয়াশিং মেশিন"),
    ("Vacuum Cleaner", "ভ্যাকুয়াম ক্লিনার"),
    ("Digital Camera", "ডিজিটাল ক্যামেরা"),
    ("Tablet", "ট্যাবলেট"),
    ("Smartwatch", "স্মার্টওয়াচ"),
    ("Gaming Console", "গেমিং কনসোল"),
    ("Electric Kettle", "ইলেকট্রিক কেটল"),
    ("Air Conditioner", "এয়ার কন্ডিশনার"),
    ("Fitness Tracker", "ফিটনেস ট্র্যাকার"),
]


def objects():
    # Reset sequences for models that had explicit IDs in previous fixtures
    reset_sequence(rt.models.products.Category)
    reset_sequence(rt.models.products.Product)
    
    # ar = rt.login(dd.plugins.users.get_demo_user().username)
    association_types = Cycler(AssociationTypes.get_list_items())
    users = Cycler(rt.models.users.User.objects.filter(
        ledger__isnull=False
    ))
    reg_states = Cycler(RegistrationStates.get_list_items())
    last_barcode_id = rt.models.contacts.Company.objects.filter(
        barcode_identity__isnull=False
    ).order_by(
        '-barcode_identity').first().barcode_identity
    for i in range(len(COMPANY_NAMES)):
        association_type = association_types.pop()
        if association_type == AssociationTypes.manufacturer:
            last_barcode_id += 1
        company = Company(
            name=COMPANY_NAMES[i],
            association_type=association_type,
            barcode_identity=(last_barcode_id if association_type == AssociationTypes.manufacturer else None),
        )
        yield company
        reg_state = reg_states.pop()
        kw = dict(state=reg_state)
        if reg_state == RegistrationStates.registered:
            kw.update(
                registered_by=users.pop(),
            )
        yield CompanyRegistrationRequest(
            company=company,
            created_by=users.pop(),
            is_creators_company=False,
            **kw,
        )

    cats = Cycler(list(rt.models.products.Category.objects.all()))

    for en_name, bn_name in PRODUCT_CATEGORY_NAMES:
        cat = rt.models.products.Category(
            name=en_name,
            name_bn=bn_name,
            product_type=rt.models.products.ProductTypes.default,
            parent=random.choice([None, cats.pop()])
        )
        yield cat
        reg_state = reg_states.pop()
        kw = dict(state=reg_state)
        if reg_state == RegistrationStates.registered:
            kw.update(
                registered_by=users.pop(),
            )
        yield rt.models.registry.ProductCategoryIndexRequest(
            category=cat,
            created_by=users.pop(),
            **kw,
        )
    
    vendors = Cycler(list(rt.models.contacts.Company.objects.filter(association_type=AssociationTypes.manufacturer)))

    last_barcode_id = rt.models.products.Product.objects.filter(
        barcode_identity__isnull=False
    ).order_by('-barcode_identity').first().barcode_identity

    for i, (en_name, bn_name) in enumerate(PRODUCT_NAMES):
        user = users.pop()
        cats = rt.models.products.Category.objects.filter(
            models.Q(registry__state=RegistrationStates.registered)
            | models.Q(registry__created_by=user)
        )
        cat = random.choice(cats)
        product = rt.models.products.Product(
            name=en_name,
            name_bn=bn_name,
            vendor=vendors.pop(),
            barcode_identity=last_barcode_id + 1 + i,
            category=cat,
        )
        yield product
        reg_state = cat.registry.state
        kw = dict(state=reg_state)
        if reg_state == RegistrationStates.registered:
            kw.update(
                registered_by=users.pop(),
            )
        yield rt.models.registry.ProductIndexRequest(
            product=product,
            created_by=user,
            **kw,
        )
