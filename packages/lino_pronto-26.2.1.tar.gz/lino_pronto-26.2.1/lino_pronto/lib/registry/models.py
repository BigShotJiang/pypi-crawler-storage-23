# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.conf import settings
from django.utils.html import mark_safe, format_html
from lino.api import dd, rt, _
from lino.core import constants
from lino.core.atomizer import get_atomizer
from lino.core.roles import SiteStaff, SiteUser
from lino.modlib.notify.choicelists import MessageTypes
from lino.utils.format_number import localize_number
from lino.utils.html import tostring
from lino_xl.lib.products.roles import ProductsUser
from .mixins import Registrable
from .choicelists import RegistrationStates

MessageTypes.add_item("registry", _("Object registration request"))


class ProductIndexRequest(Registrable):
    """
    Request to register a product in the product index.
    Only ProductsUser can create requests, only ProductsStaff can register them.
    """
    class Meta:
        app_label = 'registry'
        abstract = dd.is_abstract_model(__name__, 'ProductIndexRequest')
        verbose_name = _("Product index request")
        verbose_name_plural = _("Product index requests")

    product = dd.OneToOneField('products.Product', primary_key=True, related_name='registry')
    
    def __str__(self):
        return _("Index request for {}").format(self.product)

    @dd.displayfield(_("Product"))
    def product_detail(self, ar):
        sar = rt.models.products.AllProducts.create_request(parent=ar)
        return sar.obj2htmls(self.product)


class ProductCategoryIndexRequest(Registrable):
    """
    Request to register a product category in the category index.
    Only ProductsUser can create requests, only ProductsStaff can register them.
    """
    class Meta:
        app_label = 'registry'
        abstract = dd.is_abstract_model(__name__, 'ProductCategoryIndexRequest')
        verbose_name = _("Product category index request")
        verbose_name_plural = _("Product category index requests")

    category = dd.OneToOneField('products.Category', primary_key=True, related_name='registry')
    
    def __str__(self):
        return _("Index request for {}").format(self.category)

    @dd.displayfield(_("Product category"))
    def category_detail(self, ar):
        sar = rt.models.products.AllCategories.create_request(parent=ar)
        return sar.obj2htmls(self.category)


class CompanyRegistrationRequest(Registrable):
    """
    Request to register a company in the company registry.
    Similar to ProductIndexRequest.
    """
    class Meta:
        app_label = 'registry'
        abstract = dd.is_abstract_model(__name__, 'CompanyRegistrationRequest')
        verbose_name = _("Company registration request")
        verbose_name_plural = _("Company registration requests")

    allow_cascaded_delete = ["company"]

    company = dd.OneToOneField('contacts.Company', primary_key=True, related_name='registry')
    is_creators_company = dd.BooleanField(_("My own company"), default=False)

    def __str__(self):
        return _("Registration request for {}").format(self.company)

    @dd.displayfield(_("Company"))
    def company_detail(self, ar):
        sar = rt.models.contacts.AllCompanies.create_request(parent=ar)
        return sar.obj2htmls(self.company)


# Tables

# Abstract base table for registration request tables
class RegistrationRequests(dd.Table):
    """
    Abstract base table for all registration request tables.
    Provides common functionality for displaying and managing registration requests.
    """
    required_roles = dd.login_required(SiteStaff)
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        """Disable editing of system fields."""
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("state")
        dfs.add("created")
        dfs.add("created_by")
        dfs.add("registered_at")
        dfs.add("registered_by")
        return dfs


class PendingRequests(dd.Table):
    """
    Abstract base for tables showing only pending (non-registered) requests.
    """
    abstract = True
    allow_create = False
    allow_delete = False

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        qs = qs.exclude(state__in=[
            RegistrationStates.registered,
            RegistrationStates.rejected
        ])
        return qs


class ProductIndexRequests(RegistrationRequests):
    model = "registry.ProductIndexRequest"
    label = _("Product index requests")
    column_names = "rowselect product_detail state created created_by registered_at registered_by *"


class PendingProductIndexRequests(ProductIndexRequests, PendingRequests):
    label = _("Pending product index requests")


class ProductCategoryIndexRequests(RegistrationRequests):
    model = "registry.ProductCategoryIndexRequest"
    label = _("Product category index requests")
    column_names = "rowselect category_detail state created created_by registered_at registered_by *"


class PendingProductCategoryIndexRequests(ProductCategoryIndexRequests, PendingRequests):
    label = _("Pending product category index requests")


class CompanyRegistrationRequests(RegistrationRequests):
    model = "registry.CompanyRegistrationRequest"
    column_names = "rowselect company_detail state created created_by registered_at registered_by"
    allow_create = False
    allow_delete = False


class PendingCompanyRegistrationRequests(CompanyRegistrationRequests, PendingRequests):
    label = _("Pending company registration requests")


class MyRegistrationRequests(dd.Table):
    """
    Abstract base table for tables that allow users to create registration requests.
    Automatically filters to show only items created by the current user.
    """
    requests_model = None
    request_owner_field = None

    @dd.displayfield(_("Status"))
    def status(self, obj, ar):
        if hasattr(obj, "registry"):
            state = obj.registry.state
            if state == RegistrationStates.registered:
                return (
                    '<span style="background: green; color: white; padding: 5px; '
                    f'border-radius: 3px;"><strong>{state.text}</strong></span>'
                )
            elif state == RegistrationStates.rejected:
                return (
                    '<span style="background: red; color: white; padding: 5px; '
                    f'border-radius: 3px;"><strong>{state.text}</strong></span>'
                )
            elif state == RegistrationStates.under_review:
                return (
                    '<span style="background: orange; color: white; padding: 5px; '
                    f'border-radius: 3px;"><strong>{state.text}</strong></span>'
                )
            else:  # new
                return (
                    '<span style="background: yellow; color: black; padding: 5px; '
                    f'border-radius: 3px;"><strong>{state.text}</strong></span>'
                )
        else:
            return (
                '<span style="background: yellow; color: black; padding: 5px; '
                f'border-radius: 3px;"><strong>{_("Pending")}</strong></span>'
            )

    @classmethod
    def on_analyze(self, site):
        if isinstance(self.requests_model, str):
            self.requests_model = dd.resolve_model(self.requests_model)
        return super().on_analyze(site)

    @classmethod
    def get_extra_request_fields(cls, reqeust, obj, ar):
        """Hook to provide extra fields when creating a request."""
        return {}
    
    @classmethod
    def get_actor_for_embedded_notifying_action_url(cls, obj, ar):
        """Hook to provide a custom actor for the notification action URL."""        
        if isinstance(obj, rt.models.contacts.Company):
            return rt.models.registry.PendingCompanyRegistrationRequests
        elif isinstance(obj, rt.models.products.Product):
            return rt.models.registry.PendingProductIndexRequests
        elif isinstance(obj, rt.models.products.Category):
            return rt.models.registry.PendingProductCategoryIndexRequests
        else:
            raise Exception("Unknown registration request type")


    @classmethod
    def after_create_instance(cls, obj, ar):
        if not hasattr(obj, "registry"):
            actor = cls.get_actor_for_embedded_notifying_action_url(obj, ar)
            request = cls.requests_model(
                **{
                    "created_by": ar.get_user(),
                    cls.request_owner_field: obj,
                }
            )
            for k, v in cls.get_extra_request_fields(request, obj, ar).items():
                setattr(request, k, v)
            request.full_clean()
            request.save_new_instance(
                request.get_default_table().create_request(parent=ar)
            )

            users = rt.models.users.User.objects.filter(
                # TODO: filter by location and head quarters
                user_type__in=rt.models.users.UserTypes.user_types_for_role(SiteStaff)
            )
            recipients = [(u, u.mail_mode) for u in users]

            def msg_func(user):
                request_for_label = cls.model._meta.verbose_name
                subject = _("{} registration request").format(request_for_label)

                params = {}
                if not user.has_usable_password():
                    params[constants.URL_PARAM_SUBST_USER] = user.pk
                permalink = "{}{}".format(
                    settings.SITE.server_url,
                    ar.renderer.get_detail_url(ar, actor, request.pk, **params)
                )
                req = format_html('<a href="{}">{}</a>', permalink, str(request))

                body = _("You have a new {} registration request: {}").format(
                    request_for_label.lower(), req
                )
                body = mark_safe("<p>{}</p>".format(body))
                return (subject, body)

            from lino.modlib.notify.choicelists import MessageTypes

            rt.models.notify.Message.emit_notification(
                ar, request, MessageTypes.registry, msg_func, recipients
            )

            ar.success(_("{0} registration request created.").format(cls.model._meta.verbose_name))
    
    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        """Filter to show only items with registry created by current user."""
        user = ar.get_user()
        if user.is_anonymous or user.ledger is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        # Show items that have a registry created by user sharing the same ledger
        qs = qs.filter(registry__created_by__ledger=user.ledger)
        return qs


class MyCompanyRegistrationRequests(MyRegistrationRequests):
    """Table for ContactsUser to create company registration requests."""

    label = _("My company registration")
    model = "contacts.Company"
    required_roles = dd.login_required(SiteUser)
    column_names = "name registry__is_creators_company association_type status"
    detail_layout = "contacts.MyRegisteredCompanyDetail"

    insert_layout = """
    name
    email
    association_type
    is_my_company
    type
    """

    requests_model = "registry.CompanyRegistrationRequest"
    request_owner_field = "company"

    @dd.virtualfield(dd.BooleanField(_("My own company")), editable=True)
    def is_my_company(self, obj, ar):
        return False

    @classmethod
    def get_extra_request_fields(cls, request, obj, ar):
        field = "is_my_company"
        is_creators_company = ar.rqdata.get(field, "")
        if not is_creators_company:
            is_creators_company = False
        else:
            de = cls.get_data_elem(field)
            sf = get_atomizer(cls, de, field)
            is_creators_company = sf.parse_form_value(
                is_creators_company, request, ar
            )
        return { "is_creators_company": is_creators_company }


class MyProductCategoryIndexRequests(MyRegistrationRequests):
    """Table for ProductsUser to create category index requests."""

    label = _("My category index requests")
    model = "products.Category"
    required_roles = dd.login_required(ProductsUser)
    column_names = "name parent status"

    detail_layout = """
    status id name
    body
    products.ProductsByCategory
    """

    insert_layout = """
    name
    parent
    body
    """

    requests_model = "registry.ProductCategoryIndexRequest"
    request_owner_field = "category"


class MyProductIndexRequests(MyRegistrationRequests):
    """Table for ProductsUser to create product index requests."""

    label = _("My product index requests")
    model = "products.Product"
    required_roles = dd.login_required(ProductsUser)
    column_names = "name vendor category status"
    detail_layout = "products.MyRegisteredProductDetail"

    insert_layout = """
    name
    body
    vendor category
    delivery_unit pieces_per_unit
    """

    requests_model = "registry.ProductIndexRequest"
    request_owner_field = "product"


def welcome_messages(ar):
    user = ar.get_user()
    if user.user_type.has_required_roles([SiteStaff]):
        kw = dict(
            state__in=[RegistrationStates.new, RegistrationStates.under_review]
        )
        pending_company_requests = rt.models.registry.CompanyRegistrationRequest.objects.filter(**kw).count()
        if pending_company_requests:
            ba = rt.models.registry.PendingCompanyRegistrationRequests.get_action_by_name('grid')
            sar = ba.create_request(parent=ar)
            button = tostring(
                sar.ar2button(
                    label=_(
                        'There are {} pending company registration requests.'
                    ).format(
                        localize_number(pending_company_requests)
                    )
                )
            )
            yield mark_safe(f"<p><strong>⇒ </strong>{button}</p>")
        pending_category_requests = rt.models.registry.ProductCategoryIndexRequest.objects.filter(**kw).count()
        if pending_category_requests:
            ba = rt.models.registry.PendingProductCategoryIndexRequests.get_action_by_name('grid')
            sar = ba.create_request(parent=ar)
            button = tostring(
                sar.ar2button(
                    label=_(
                        "There are {} pending product category index requests."
                    ).format(
                        localize_number(pending_category_requests)
                    )
                )
            )
            yield mark_safe(f"<p><strong>⇒ </strong>{button}</p>")
        pending_product_requests = rt.models.registry.ProductIndexRequest.objects.filter(**kw).count()
        if pending_product_requests:
            ba = rt.models.registry.PendingProductIndexRequests.get_action_by_name('grid')
            sar = ba.create_request(parent=ar)
            button = tostring(
                sar.ar2button(
                    label=_(
                        'There are {} pending product index requests.'
                    ).format(
                        localize_number(pending_product_requests)
                    )
                )
            )
            yield mark_safe(f"<p><strong>⇒ </strong>{button}</p>")


dd.add_welcome_handler(welcome_messages)
