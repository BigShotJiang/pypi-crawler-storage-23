# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""
Choicelists for the registry plugin.
"""

from django.conf import settings
from django.utils.html import mark_safe, format_html
from lino.api import dd, rt, _
from lino.core import constants
from lino.core.roles import SiteStaff
from lino.modlib.notify.choicelists import MessageTypes


class RegistrationStates(dd.Workflow):
    """
    Workflow states for registration requests.
    
    State transitions:
    - new → under_review → registered
    - new → registered (direct approval)
    - any state → rejected
    - registered → new (unregister)
    """
    verbose_name = _("Registration state")
    verbose_name_plural = _("Registration states")
    required_roles = dd.login_required(SiteStaff)
    
    @classmethod
    def before_state_change(cls, obj, ar, old_state, new_state):
        """Hook called before state transition."""
        if new_state == cls.registered:
            # Set registration timestamp and user
            obj.registered_at = dd.now()
            obj.registered_by = ar.get_user()
            # Hook for company registration - fix problems and create subscription
            if isinstance(obj, rt.models.registry.CompanyRegistrationRequest):
                obj.company.fix_problems.run_from_ui(ar, fix=True)
                Authority = rt.models.users.Authority
                if obj.is_creators_company and not Authority.objects.filter(
                    authorized=obj.created_by,
                    user__ledger=obj.company.ledger
                ).exists():
                    make_subscription = rt.models.ledgers.make_ledger_subscription
                    make_subscription(obj.created_by, {
                            "company": obj.company,
                            "ledger": obj.company.ledger,
                            "role": None,
                        }, ar,
                        user_type=rt.models.users.UserTypes.get_by_name(
                            obj.company.association_type.default_user_type)
                    )
        elif new_state == cls.new:
            # Unregistering - clear registered info
            obj.registered_at = None
            obj.registered_by = None
    
    @classmethod
    def after_state_change(cls, obj, ar, old_state, new_state):
        """Hook called after state transition. Send notifications."""
        recipients = []
        if isinstance(obj, rt.models.registry.CompanyRegistrationRequest) and obj.is_creators_company:
            recipients.append((obj.created_by, obj.created_by.mail_mode))
        else:
            # For other registration requests, notify the ledger's users
            for user in rt.models.users.User.objects.filter(
                ledger=obj.created_by.ledger,
            ):
                recipients.append((user, user.mail_mode))

        actor = cls.get_actor_for_embedded_notifying_action_url(obj, ar)

        def msg_func(user):
            subject = _("Registration state changed")

            params = {}
            if not user.has_usable_password():
                params[constants.URL_PARAM_SUBST_USER] = user.pk
            permalink = "{}{}".format(
                settings.SITE.server_url,
                # obj.pk should match the pk for the registering object (i.e. Company, Product, Category etc.)
                # since requests points to registering objects as
                # one-to-one field with primary key set to True
                ar.renderer.get_detail_url(ar, actor, obj.pk, **params)
            )
            obj_url = format_html('<a href="{}">{}</a>', permalink, str(obj))

            if new_state in [cls.registered, cls.rejected]:
                body = _("The registration request for {} has been {}.").format(
                    obj_url,
                    new_state.text.lower(),
                )
            else:
                body = _("The registration request for {} has changed state from {} to {}.").format(
                    obj_url,
                    old_state.text.lower(),
                    new_state.text.lower(),
                )
            body = mark_safe("<p>{}</p>".format(body))
            return (subject, body)

        rt.models.notify.Message.emit_notification(
            ar, obj, MessageTypes.registry, msg_func, recipients
        )
    
    @classmethod
    def get_actor_for_embedded_notifying_action_url(cls, obj, ar):
        """Determine the actor for generating action URLs in notifications."""
        if isinstance(obj, rt.models.registry.CompanyRegistrationRequest):
            return rt.models.registry.MyCompanyRegistrationRequests
        elif isinstance(obj, rt.models.registry.ProductIndexRequest):
            return rt.models.registry.MyProductIndexRequests
        elif isinstance(obj, rt.models.registry.ProductCategoryIndexRequest):
            return rt.models.registry.MyProductCategoryIndexRequests
        else:
            raise Exception("Unknown registration request type: {}".format(type(obj)))


add = RegistrationStates.add_item
add('10', _("New"), 'new')
add('20', _("Under review"), 'under_review')
add('30', _("Registered"), 'registered')
add('40', _("Rejected"), 'rejected')


# Define workflow transitions with toolbar visibility and required states
RegistrationStates.registered.add_transition(
    _("Register"),
    required_states='new under_review',
    show_in_toolbar=True,
    help_text=_("Register this request"),
    button_text="✓",
)

RegistrationStates.under_review.add_transition(
    _("Set under review"),
    required_states='new rejected',
    show_in_toolbar=True,
    help_text=_("Set this request under review"),
    button_text="👁",
)

RegistrationStates.rejected.add_transition(
    _("Reject"),
    required_states='new under_review',
    show_in_toolbar=True,
    help_text=_("Reject this request"),
    button_text="✗",
)

RegistrationStates.new.add_transition(
    _("Unregister"),
    required_states='registered',
    show_in_toolbar=True,
    help_text=_("Unregister and reset to new state"),
    button_text="↺",
)
