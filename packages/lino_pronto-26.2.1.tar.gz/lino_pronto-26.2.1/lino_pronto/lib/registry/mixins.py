# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""
Mixins for the registry plugin.
"""

from lino.api import dd, _
from .choicelists import RegistrationStates


class Registrable(dd.Model):
    """
    Mixin for models that represent registration requests.
    
    Provides common fields for tracking registration status, creation, and approval.
    Uses workflow system for state transitions.
    """

    class Meta:
        abstract = True

    workflow_state_field = 'state'

    state = RegistrationStates.field(default=RegistrationStates.new)
    created = dd.DateTimeField(_("Created"), auto_now_add=True)
    created_by = dd.ForeignKey(
        'users.User',
        verbose_name=_("Created by"),
        related_name='%(app_label)s_%(class)s_created'
    )
    created_by_partner = dd.ForeignKey(
        "contacts.Company",
        verbose_name=_("Created by partner"),
        related_name='%(app_label)s_%(class)s_created_by_partner',
        null=True, blank=True,
    )
    registered_at = dd.DateTimeField(_("Registered at"), null=True, blank=True)
    registered_by = dd.ForeignKey(
        'users.User',
        verbose_name=_("Registered by"),
        null=True,
        blank=True,
        related_name='%(app_label)s_%(class)s_registered'
    )

    remark = dd.RichTextField(_("Remark"), blank=True)

    def full_clean(self, *args, **kwargs):
        assert self.created_by_id is not None, _(
                "Cannot create registration request without user info."
            )
        if self.created_by_partner_id is None:
            if not dd.is_installed("linod") or self.created_by.username != dd.get_plugin_setting("linod", "daemon_user"):
                self.created_by_partner = self.created_by.ledger.company
        return super().full_clean(*args, **kwargs)
