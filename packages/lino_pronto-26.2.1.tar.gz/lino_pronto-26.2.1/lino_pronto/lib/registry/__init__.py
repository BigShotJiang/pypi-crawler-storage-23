# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""
The registry plugin for Lino Pronto.

Provides a common framework for registration requests (products, companies, categories, etc.).
"""

from lino.api import ad, _


class Plugin(ad.Plugin):
    """
    Plugin for managing registration requests.
    """
    verbose_name = _("Registry")
    
    def setup_config_menu(self, site, user_type, m, ar=None):
        m = m.add_menu(self.app_label, self.verbose_name)
        m.add_action("registry.MyCompanyRegistrationRequests")
        m.add_action("registry.PendingCompanyRegistrationRequests")
        m.add_action("registry.MyProductIndexRequests")
        m.add_action("registry.PendingProductIndexRequests")
        m.add_action("registry.MyProductCategoryIndexRequests")
        m.add_action("registry.PendingProductCategoryIndexRequests")
    
    def setup_explorer_menu(self, site, user_type, m, ar=None):
        m = m.add_menu(self.app_label, self.verbose_name)
        m.add_action("registry.CompanyRegistrationRequests")
        m.add_action("registry.ProductIndexRequests")
        m.add_action("registry.ProductCategoryIndexRequests")
