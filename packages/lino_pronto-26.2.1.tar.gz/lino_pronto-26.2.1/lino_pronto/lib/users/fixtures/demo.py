from lino_pronto.lib.users.fixtures.demo_users import *
