from django.conf import settings
from lino.api import dd


def objects():
	for u in settings.SITE.user_model.objects.exclude(user_type=""):
		if not u.email:
			u.email = settings.SITE.demo_email
		u.set_password(dd.plugins.users.demo_password)
		yield u