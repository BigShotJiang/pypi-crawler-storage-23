from lino.modlib.users.fixtures.demo_users import *
from lino.api import rt

other_objects = objects
UserTypes = rt.models.users.UserTypes


def objects():
    for obj in other_objects():
        yield obj

    User = settings.SITE.user_model
    yield User(first_name='Alice', last_name='Wonderland', username='alice',
               user_type=UserTypes.user, email=settings.SITE.demo_email)
    yield User(first_name='Russel', last_name='Ibrahim', username='russel',
               user_type=UserTypes.supplier, email=settings.SITE.demo_email)
    yield User(first_name='Cleo', last_name='Patra', username='cleopatra',
               user_type=UserTypes.seller, email=settings.SITE.demo_email)
    yield User(first_name='Abu', last_name='Nomani', username='abunomani',
               user_type=UserTypes.pos_agent, email=settings.SITE.demo_email)
    yield User(first_name='Huntress', last_name='Gretel', username='gretel',
               user_type=UserTypes.supply_staff, email=settings.SITE.demo_email)
    
    yield User(first_name='Bob', last_name='Marley', username='bob',
               user_type=UserTypes.user, email=settings.SITE.demo_email)
    yield User(first_name='David', last_name='Ritter', username='david',
               user_type=UserTypes.supplier, email=settings.SITE.demo_email)
    yield User(first_name='Eva', last_name='Mendes', username='eva',
               user_type=UserTypes.seller, email=settings.SITE.demo_email)
    yield User(first_name='Frank', last_name='Castle', username='frank',
               user_type=UserTypes.pos_agent, email=settings.SITE.demo_email)
    yield User(first_name='Grace', last_name='Hopper', username='grace',
               user_type=UserTypes.supply_staff, email=settings.SITE.demo_email)
    yield User(first_name='Hank', last_name='Pym', username='hank',
               user_type=UserTypes.supplier, email=settings.SITE.demo_email)
    yield User(first_name='Irene', last_name='Adler', username='irene',
               user_type=UserTypes.user, email=settings.SITE.demo_email)
    yield User(first_name='Ivy', last_name='League', username='ivy',
               user_type=UserTypes.seller, email=settings.SITE.demo_email)
    yield User(first_name='Jack', last_name='Sparrow', username='jack',
               user_type=UserTypes.pos_agent, email=settings.SITE.demo_email)
    yield User(first_name='Kara', last_name='Zor-El', username='kara',
               user_type=UserTypes.supply_staff, email=settings.SITE.demo_email)
    yield User(first_name='Liam', last_name='Neeson', username='liam',
               user_type=UserTypes.supplier, email=settings.SITE.demo_email)
