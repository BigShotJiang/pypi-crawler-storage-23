# -*- coding: utf-8 -*-

from lino.api import rt
from lino.modlib.users.fixtures.std import objects as user_fixtures


def objects():
    yield from user_fixtures()
    yield rt.models.users.User(username='admin', first_name='Moderator')
