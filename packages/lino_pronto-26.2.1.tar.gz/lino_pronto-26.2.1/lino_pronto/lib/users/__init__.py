# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.modlib.users import Plugin


class Plugin(Plugin):
    """The `users` plugin for Lino Pronto."""
    extends_models = ['User']
