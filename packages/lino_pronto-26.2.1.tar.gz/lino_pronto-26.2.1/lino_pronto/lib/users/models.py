# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.conf import settings
from django.db.models import Q
from django.db.models.constraints import CheckConstraint, UniqueConstraint
from django.contrib.auth.hashers import UNUSABLE_PASSWORD_PREFIX
from django.utils.text import format_lazy
from lino.api import dd, rt, _
from lino.modlib.checkdata.choicelists import Checker
from lino.modlib.users.models import *
from lino.utils.mti import insert_child
from lino_pronto.lib.ledgers.actions import MakeSubscriptionRequest


HAS_VALID_PASSWORD = (
    Q(password__isnull=False)
    & ~Q(password="")
    & ~Q(password__startswith=UNUSABLE_PASSWORD_PREFIX)
)
DEMO_SITE = settings.SITE.is_demo_site


User.ledger_subscribe_on_user = MakeSubscriptionRequest(params_layout="""
company role
ledger
""")

class User(User):
    class Meta(User.Meta):
        app_label = "users"
        abstract = dd.is_abstract_model(__name__, "User")
        constraints = [
            *getattr(User.Meta, "constraints", []),
            CheckConstraint(
                condition=(
                    ~HAS_VALID_PASSWORD
                    | (~Q(email="") & Q(email__isnull=False))
                ),
                name="users_user_email_required_for_usable_password",
            ),
            UniqueConstraint(
                fields=["email"],
                condition=(HAS_VALID_PASSWORD & (~Q(email=settings.SITE.demo_email) if DEMO_SITE else Q())),
                name="users_user_unique_email_for_usable_password",
            ),
        ]

    def get_row_permission(self, ar, state, ba):
        if not ba.action.readonly:
            user = ar.get_user()
            if user != self:
                if not user.user_type.has_required_roles([SiteAdmin]):
                    if not self.is_editable_by_all():
                        if int(user.user_type.value) >= int(self.user_type.value):
                            return True
                        return False
        return super().get_row_permission(ar, state, ba)
    
    def full_clean(self, *args, **kw):
        if self.start_date is None:
            self.start_date = dd.today()
        return super().full_clean(*args, **kw)


class UserDetail(UserDetail):
    box3 = """
    remarks
    ledger
    """
    
    main = """
    box1 box2 box3
    AuthoritiesGiven:20 AuthoritiesTaken:20 SocialAuthsByUser:30
    """


class UserChecker(Checker):
    verbose_name = _("Check for missing partner and ledger")
    model = User
    missing_msg = _("User {user} has no linked Partner or Ledger")

    def get_checkdata_problems(self, ar, obj, fix=False):
        if obj.partner is None or obj.ledger is None:
            yield True, format_lazy(self.missing_msg, user=obj)
            if fix:
                if obj.partner is None:
                    p = rt.models.contacts.Person(
                        first_name=obj.first_name,
                        last_name=obj.last_name,
                        email=obj.email
                    )
                    p.full_clean()
                    p.save_new_instance(p.get_default_table().create_request(parent=ar))
                    obj.partner = p.partner_ptr
                    obj.full_clean()
                company = obj.company
                if company is None:
                    company = insert_child(
                        obj.partner, rt.models.contacts.Company,
                        full_clean=True,
                        name=obj.get_full_name() or obj.username,
                        association_type=rt.models.contacts.AssociationTypes.customer,
                    )
                    company.fix_problems.run_from_ui(ar, fix=True)
                if obj.ledger is None:
                    # l = rt.models.ledgers.Ledger(company=company)
                    # l.full_clean()
                    # l.save_new_instance(l.get_default_table().create_request(parent=ar))
                    obj.ledger = company.ledger
                    obj.full_clean()
                    # company.ledger = l
                    company.full_clean()
                    company.save()
                obj.save()


UserChecker.activate()

dd.update_field(User, "ledger", editable=False)
