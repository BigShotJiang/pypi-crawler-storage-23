# -*- coding: UTF-8 -*-
# Copyright 2017-2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.utils.html import format_html, mark_safe
from django.utils.text import format_lazy
from django.utils.translation import gettext
from lino.api import dd, rt, _
from lino.core import constants
from lino.core.roles import SiteAdmin
from lino.modlib.checkdata.choicelists import Checker
from lino.modlib.publisher.mixins import Illustrated
from lino.modlib.uploads.actions import CameraStream
from lino.modlib.uploads.roles import UploadsReader
from lino.utils.html import tostring
from lino_xl.lib.accounting.choicelists import TradeTypes
from lino_xl.lib.products.models import *
from lino_xl.lib.vat.choicelists import VatClasses
from .choicelists import *

ProductTypes.clear()
add = ProductTypes.add_item
add('100', _("Products"), 'default', table_name="products.Products")
add('200', _("Services"), 'services', table_name="products.Services")
add('300', _("Parts"), 'parts', table_name="products.Parts")
# add('300', _("Other"), 'default')


class GotoCart(dd.Action):
    # label = _("Go to cart")
    button_text = "🛒"
    sort_index = 52
    select_rows = False

    def get_cart_model(self):
        raise NotImplementedError

    def run_from_ui(self, ar, **kw):
        my_cart = self.get_cart_model().create_user_plan(user=ar.get_user())
        ar.goto_instance(my_cart)


class GotoAcquiringCart(GotoCart):
    action_name = 'goto_acquiring_cart'
    label = _("Go to ordering cart")
    never_collapse = True

    def get_cart_model(self):
        return rt.models.shopping.AcquiringCart


class GotoShoppingCart(GotoCart):
    action_name = 'goto_shopping_cart'
    label = _("Go to shopping cart")

    required_roles = dd.login_required(ProductsUser)

    def get_cart_model(self):
        return rt.models.shopping.Cart


class CameraStream(CameraStream):
    action_name = None
    select_rows = True
    preprocessor = "Lino.captureAndCropImage"
    required_roles = dd.login_required(ProductsUser)

    def handle_insert(self, ar, product, partner_price = None, **kwargs):
        album = product.album if partner_price is None else partner_price.album
        albumOwner = product if partner_price is None else partner_price
        if album is None:
            Album = rt.models.albums.Album
            title = format_lazy(
                _("Album of {product} ({company})"),
                product=product,
                company=product.vendor if partner_price is None else partner_price.partner,
            )
            album = Album(
                title=title,
                user=ar.get_user(),
            )
            album.full_clean()
            album.save_new_instance(album.get_default_table().create_request(parent=ar))
            albumOwner.album = album
            albumOwner.full_clean()
            albumOwner.save()
        kwargs.update({"owner": product})
        kwargs.update(**ar.action_param_values)
        upload = self.handle_uploaded_file(ar, **kwargs)
        album_item = rt.models.albums.AlbumItem(
            album=album,
            upload=upload,
        )
        album_item.set_seqno()
        album_item.full_clean()
        album_item.save_new_instance(
            album_item.get_default_table().create_request(parent=ar)
        )


class ProductImageCapture(CameraStream):
    action_name = 'capture_product_image'

    required_roles = dd.login_required(ProductsStaff)

    def run_from_ui(self, ar, **kwargs):
        product = ar.selected_rows[0]
        self.handle_insert(ar, product, **kwargs)
        ar.success(refresh=True)


class PartnerPriceImageCapture(CameraStream):
    action_name = 'capture_partner_price_image'

    def run_from_ui(self, ar, **kwargs):
        partner_price = ar.selected_rows[0]
        product = partner_price.product
        self.handle_insert(ar, product, partner_price=partner_price, **kwargs)
        ar.success(refresh=True)


class ImagesByProduct(dd.Table):
    label = _("Pictures")
    model = "uploads.Upload"
    required_roles = dd.login_required(UploadsReader)
    master_key = "owner"
    default_display_modes = {None: constants.DISPLAY_MODE_GALLERY}


class PartnerPrice(Illustrated):

    quick_search_fields = [
        'product__name',
        # 'product__name_bn',
        "product__category__name",
        # "product__category__name_bn",
        "product__body",
        # "product__body_bn",
        'partner__name',
        "product__vendor__name",
    ]

    class Meta:
        app_label = 'products'
        verbose_name = _("Partner price")
        verbose_name_plural = _("Partner prices")
        unique_together = ('partner', 'product', 'trade_type')

    partner = dd.ForeignKey('contacts.Company')
    product = dd.ForeignKey('products.Product')
    trade_type = TradeTypes.field(default=TradeTypes.sales)
    price = dd.DecimalField(_("Price"), max_digits=32, decimal_places=2)
    min_order_qty = dd.QuantityField(
        _("Min. order quantity"), default="1")

    camera_stream = PartnerPriceImageCapture()
    # goto_cart = GotoCart()
    goto_acquiring_cart = GotoAcquiringCart()
    goto_shopping_cart = GotoShoppingCart()

    def __str__(self):
        return gettext(_("{product} (PP)").format(product=self.product))

    @classmethod
    def get_simple_parameters(cls):
        for p in super().get_simple_parameters():
            yield p
        yield "trade_type"
        yield "partner"

    def get_cart_action_button(self, ar):
        my_cart = rt.models.shopping.AcquiringCart.objects.filter(user=ar.get_user()).first()
        cart_msg = _("Add to cart 🛒")
        if my_cart is not None:
            qs = rt.models.shopping.AcquiringCartItem.objects.filter(
                cart=my_cart, partner_price=self
            )
            if qs.exists():
                # U+2705
                cart_msg = _("✅ x{quantity} Update 🛒").format(quantity=qs.get().qty)
        tile_id = f"tile-{self.pk}"
        return f'<button class="p-component" id="{tile_id + "-update-button"}">{tostring(ar.instance_action_button(self.add_to_cart, label=cart_msg))}</button>'

    def as_tile(self, ar, prev, **kwargs):
        tile_id = f"tile-{self.pk}"
        tile = f"<h3>{str(self.product)}</h3>"
        if self.album_id is not None and (count := (items := self.album.items.all()).count()):
            tile += '<style>'
            # Set background image for hero
            hero_url = items[0].upload.file.url
            tile += f"#{tile_id} .l-image-gallery-hero {{"
            tile += f"background-image: url('{hero_url}');"
            tile += "}"
            # Set background images for second row items
            for i in range(1, count):
                tile += f"#{tile_id} .l-image-gallery-row-2-scroll .l-image-gallery-item:nth-child({i + 1}) {{"
                tile += f"background-image: url('{items[i].upload.file.url}');"
                tile += "}"
            tile += '</style>'
            tile += '<ul class="l-image-gallery">'
            # Hero image with modal click handler
            tile += f'<li class="l-image-gallery-hero" data-pos="1" data-url="{hero_url}" onclick="event.stopPropagation(); openImageModal(this.getAttribute(\'data-url\')); return false;"></li>'
            # Second row items in scrollable container
            if count > 1:
                tile += '<div class="l-image-gallery-row-2 has-overflow">'
                tile += f'<button class="l-image-gallery-scroll-btn left" onclick="tileScrollBy(event, \'{tile_id}\', -150)" aria-label="Scroll left"></button>'
                tile += '<div class="l-image-gallery-row-2-scroll has-overflow">'
                tile += '<li class="l-image-gallery-item l-image-gallery-placeholder" aria-hidden="true"></li>'
                for i in range(1, count):
                    thumb_url = items[i].upload.file.url
                    tile += f'<li class="l-image-gallery-item" data-pos="{i + 1}" data-url="{thumb_url}"></li>'
                tile += '<li class="l-image-gallery-item l-image-gallery-placeholder" aria-hidden="true"></li>'
                tile += '</div>'
                tile += f'<button class="l-image-gallery-scroll-btn right" onclick="tileScrollBy(event, \'{tile_id}\', 150)" aria-label="Scroll right"></button>'
                tile += '</div>'
            tile += "</ul>"
        else:
            tile += f'<img alt="{_("No image available")}">'
        if self.product.body_short_preview:
            tile += format_html(
                "<div>{}</div>",
                mark_safe(self.product.body_short_preview)
            )
        tile += f'<p>{_("Price:")} {self.price}</p>'
        tile += f'<p>{_("Supplier:")} {self.partner}</p>'
        tile += f'<div style="float: right;">{self.get_cart_action_button(ar)}</div>'
        tile += f'<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" onload="if(typeof setupImageGalleryForTile===\'function\')setupImageGalleryForTile(\'{tile_id}\')" style="display:none">'
        tile = '<div id="{tile_id}" onclick="swapBackgroundImages(event, \'{tile_id}\')">{tile}</div>'.format(
            tile_id=tile_id, tile=tile
        )
        return format_html(constants.TILE_TEMPLATE, chunk=mark_safe(tile))


class PartnerPriceChecker(Checker):
    verbose_name = _("Partner prices checker")
    model = PartnerPrice
    msg_missing = _("Partner price {obj} missing an album. ")
    provision_msg_missing = _("The partner price ({}) has no corresponding provision.")

    def get_checkdata_problems(self, ar, obj, fix=False):
        if obj.trade_type == rt.models.accounting.TradeTypes.purchases:
            return
        msg = "" if obj.album is not None else format_lazy(self.msg_missing, obj=obj)
        provision_exists = rt.models.storage.Provision.objects.filter(
            partner_price=obj,
            provision_state=rt.models.storage.ProvisionStates.in_stock
        ).exists()
        msg += "" if provision_exists  else format_lazy(
            self.provision_msg_missing,
            obj,
        )
        if msg:
            yield True, msg
            if fix:
                if obj.album is None:
                    Album = rt.models.albums.Album
                    title = format_lazy(
                        _("Album of {product} ({company})"),
                        product=obj.product,
                        company=obj.partner)
                    album = Album(
                        title=title,
                        user=ar.get_user(),
                    )
                    album.full_clean()
                    album.save_new_instance(album.get_default_table().create_request(parent=ar))
                    obj.album = album
                    obj.full_clean()
                    obj.save()

                if not provision_exists:
                    Provision = rt.models.storage.Provision
                    prov = Provision(
                        partner_price=obj,
                        provision_state=rt.models.storage.ProvisionStates.in_stock,
                        qty="0"
                    )
                    prov.full_clean()
                    prov.save_new_instance(prov.get_default_table().create_request(parent=ar))


PartnerPriceChecker.activate()


class PartnerPrices(dd.Table):
    model = "products.PartnerPrice"
    column_names = "partner product trade_type price"
    auto_fit_column_widths = True

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        qs = qs.filter(
            product__registry__state=rt.models.registry.RegistrationStates.registered,
            product__registry__isnull=False,
            price__gt=0
        )
        return qs


class Product(Product, Illustrated):
    class Meta(Product.Meta):
        unique_together = ('vendor', 'barcode_identity')

    camera_stream = ProductImageCapture()

    def __str__(self):
        return super().__str__() + " [{}]".format(self.vendor)

    @dd.chooser()
    def vendor_choices(self, ar):
        qs = rt.models.contacts.Companies.create_request(parent=ar).data_iterator
        qs = qs.filter(
            association_type=rt.models.contacts.AssociationTypes.manufacturer
        )
        return qs

    @dd.chooser()
    def category_choices(cls, ar):
        """Only show registered categories in category combo boxes."""
        Categories = rt.models.products.Categories
        return Categories.create_request(parent=ar).data_iterator

    @dd.virtualfield(dd.DecimalField(verbose_name=_("Sales price"), max_digits=32, decimal_places=2, null=True, blank=True), editable=True)
    def my_sales_price(self, ar=None):
        if ar is None or (user := ar.get_user()).is_anonymous or user.ledger is None:
            return None
        PartnerPrice = rt.models.products.PartnerPrice
        c = user.ledger.company
        try:
            pp = PartnerPrice.objects.get(product=self, partner=c, trade_type=TradeTypes.sales)
        except PartnerPrice.DoesNotExist:
            if 'my_sales_price' not in ar.rqdata:
                return None
            pp = None
        if 'my_sales_price' in ar.rqdata:
            if pp is None:
                pp = PartnerPrice(product=self, partner=c, trade_type=TradeTypes.sales)
            pp.price = ar.rqdata['my_sales_price']
            pp.full_clean()
            pp.save()
        return pp.price

    @dd.virtualfield(dd.DecimalField(verbose_name=_('Purchases price'), max_digits=32, decimal_places=2, null=True, blank=True), editable=True)
    def my_purchases_price(self, ar):
        if ar is None or (user := ar.get_user()).is_anonymous or user.ledger is None:
            return None
        PartnerPrice = rt.models.products.PartnerPrice
        c = user.ledger.company
        try:
            pp = PartnerPrice.objects.get(product=self, partner=c, trade_type=TradeTypes.purchases)
        except PartnerPrice.DoesNotExist:
            if 'my_purchases_price' not in ar.rqdata:
                return None
            pp = None
        if 'my_purchases_price' in ar.rqdata:
            if pp is None:
                pp = PartnerPrice(product=self, partner=c, trade_type=TradeTypes.purchases)
            pp.price = ar.rqdata['my_purchases_price']
            pp.full_clean()
            pp.save()
        return pp.price

    def disabled_fields(self, ar):
        df = super().disabled_fields(ar)
        if (user := ar.get_user()).is_anonymous or user.ledger is None:
            df.add('my_purchases_price')
            df.add('my_sales_price')
        return df


class ProductChecker(Checker):
    verbose_name = _("Products checker")
    model = Product
    msg_missing = _("Product {obj} missing an album")

    def get_checkdata_problems(self, ar, obj, fix=False):
        if obj.album is None:
            yield True, format_lazy(self.msg_missing, obj=obj)
            if fix:
                Album = rt.models.albums.Album
                title = format_lazy(
                    _("Album of {product} ({company})"),
                    product=obj,
                    company=obj.vendor)
                album = Album(
                    title=title,
                    user=ar.get_user(),
                )
                album.full_clean()
                album.save_new_instance(album.get_default_table().create_request(parent=ar))
                obj.album = album
                obj.full_clean()
                obj.save()


ProductChecker.activate()

dd.update_field('products.Product', 'vat_class', default=VatClasses.vatless)


class ProductDetail(dd.DetailLayout):

    main = "general sales storage.FillersByProduct"

    general = dd.Panel(
        """
    name
    #barcode id product_type category delivery_unit barcode_svg
    body
    products.ImagesByProduct
    """, _("General"))

    sales = dd.Panel(
        """
    my_purchases_price my_sales_price vat_class
    trading.InvoiceItemsByProduct
    """, _("Sales"))


# Products.column_names = "name tariff sales_price sales_account *"


class ProductCard(dd.DetailLayout):
    main = """
    product_image:30 card_content:70
    """

    card_content = """
    name
    category sales_price
    body_short_preview
    """


class Products(Products):
    column_names = "id name category *"
    card_layout = "products.ProductCard"
    # required_roles = dd.login_required(SiteAdmin)
    allow_create = False
    allow_delete = False
    editable = False
    filter_out_unregistered = True

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        if dd.is_installed('registry') and cls.filter_out_unregistered:
            RegistrationStates = rt.models.registry.RegistrationStates
            # Filter out products without registry or not registered
            qs = qs.filter(
                models.Q(registry__state=RegistrationStates.registered)
                | models.Q(registry__created_by__ledger=ar.get_user().ledger),
                registry__isnull=False,
            )
        return qs

    @dd.displayfield(_("Image"))
    def product_image(self, obj, ar):
        img = getattr(obj.album.items.first(), 'upload', None)
        if img is None:
            return ""
        return '<img src="{}" style="height: 15ch; max-width: 22.5ch">'.format(
            img.get_file_url())
        # return '<img src="{}" style="max-height: 100%; width: 20ch;">'.format(img.get_file_url())


class ProductsQuickInsert(Products):
    column_names = "name vendor category body delivery_unit pieces_per_unit vat_class my_sales_price my_purchases_price product_image *"
    stay_in_grid = True
    insert_layout = None
    required_roles = dd.login_required(SiteAdmin)
    allow_create = True
    allow_delete = True
    editable = True

    @classmethod
    def get_actor_label(cls):
        return _("Products quick insert")


class Categories(Categories):
    # stay_in_grid = True
    # required_roles = dd.login_required(SiteAdmin)
    # insert_layout = """
    # name
    # body
    # parent
    # """

    filter_out_unregistered = True

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        if dd.is_installed("registry") and cls.filter_out_unregistered:
            RegistrationStates = rt.models.registry.RegistrationStates
            # Filter out categories without registry or not registered
            qs = qs.filter(
                models.Q(registry__state=RegistrationStates.registered)
                | models.Q(registry__created_by__ledger=ar.get_user().ledger),
                registry__isnull=False,
            )
        return qs


class Services(Products):
    required_roles = dd.login_required(SiteAdmin)
    _product_type = ProductTypes.services
    column_names = "name sales_account *"


class Parts(Products):
    _product_type = ProductTypes.parts
    column_names = "name sales_account *"


class ProductGallery(dd.Table):
    label = _("Product gallery")
    model = "albums.AlbumItem"
    required_roles = dd.login_required(UploadsReader)
    master_key = "album"
    column_names = "seqno upload upload__preview"
    default_display_modes = {
        None: constants.DISPLAY_MODE_GALLERY,
        70: constants.DISPLAY_MODE_GRID,
    }

    @classmethod
    def get_master_instance(cls, ar, model, pk):
        return super().get_master_instance(ar, model, pk).album


class MyProducts(dd.Table):
    model = "products.PartnerPrice"
    column_names = "product price in_stock"
    required_roles = dd.login_required(ProductsUser)

    default_display_modes = {
        None: constants.DISPLAY_MODE_GRID,
    }

    detail_layout = """
    product trade_type price in_stock
    products.ProductGallery
    """

    goto_acquiring_cart = None
    goto_shopping_cart = None

    @classmethod
    def create_instance(self, ar, **kw):
        obj = super().create_instance(ar, **kw)
        obj.partner = ar.get_user().ledger.company
        return obj

    @dd.virtualfield(dd.DecimalField(
            verbose_name=_("In stock (qty)"), max_digits=32,
            decimal_places=2, null=True, blank=True),
        editable=True
    )
    def in_stock(self, obj, ar=None):
        if ar is None or (user := ar.get_user()).is_anonymous or user.ledger is None:
            return "0"
        Provision = rt.models.storage.Provision
        ProvisionStates = rt.models.storage.ProvisionStates
        c = user.ledger.company
        try:
            provision = Provision.objects.get(
                partner_price=obj, provision_state=ProvisionStates.in_stock
            )
        except Provision.DoesNotExist:
            if "in_stock" not in ar.rqdata:
                return "0"
            provision = None
        if ar.rqdata is not None and "in_stock" in ar.rqdata:
            if provision is None:
                provision = Provision(
                    partner_price=obj, provision_state=ProvisionStates.in_stock
                )
            provision.qty = ar.rqdata["in_stock"]
            provision.full_clean()
            provision.save()
        return provision.qty
    
    # @classmethod
    # def param_defaults(self, ar, **kw):
    #     kw = super().param_defaults(ar, **kw)
    #     kw.update(trade_type=TradeTypes.sales)
    #     kw.update(partner=ar.get_user().ledger.company)
    #     return kw

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        user = ar.get_user()
        if user.is_anonymous or user.ledger is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        # Show both registered and unregistered products for this user's company
        qs = qs.filter(
            partner=user.ledger.company,
            trade_type=TradeTypes.sales
        )
        # qs = qs.annotate(provision=models.Subquery(
        #     rt.models.storage.Provision.objects.filter(
        #         partner=user.ledger.company.partner_ptr,
        #         product=models.OuterRef('product_id'),
        #         provision_state=ProvisionStates.in_stock
        #     ).values('id')[:1]
        # ))
        return qs

    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("trade_type")
        dfs.add("goto_acquiring_cart")
        dfs.add("goto_shopping_cart")
        return dfs


class ProductSearchCard(dd.DetailLayout):
    main = """
    # product_image:50 card_content:50
    product_image
    card_content
    """

    card_content = """
    product__body_short_preview
    partner
    price
    """


class ProductSearch(dd.Table):
    label = _("Search products")
    model = "products.PartnerPrice"
    # column_names = "name category vendor vat_class *"
    card_layout = "products.ProductSearchCard"
    required_roles = dd.login_required(ProductsUser)
    default_display_modes = {
        None: constants.DISPLAY_MODE_TILES,
    }

    allow_create = False
    allow_delete = False

    goto_shopping_cart = None

    @classmethod
    def param_defaults(self, ar, **kw):
        kw = super().param_defaults(ar, **kw)
        kw.update(trade_type=TradeTypes.sales)
        return kw
    
    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        if not ar.rqdata or not ar.rqdata.get("query"):
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        qs = qs.filter(
            trade_type=TradeTypes.sales,
            product__registry__isnull=False,
            product__registry__state=rt.models.registry.RegistrationStates.registered,
            price__gt=0
        )
        return qs
    
    @classmethod
    def get_card_title(self, ar, obj):
        return str(obj.product)

    @dd.displayfield(_("Image"))
    def product_image(self, obj, ar):
        img = getattr(obj.album.items.first(), "upload", None)
        if img is None:
            return "<img alt=\"No image available\">"
        return '<img src="{}" style="width: 100%;">'.format(img.file.url)
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("goto_shopping_cart")
        return dfs


PriceRules.required_roles = dd.login_required(ProductsStaff)
PriceFactors.required_roles = dd.login_required(ProductsStaff)


class MyRegisteredProductDetail(ProductDetail):
    main = """
    status
    id category vat_class delivery_unit
    name
    body
    """


class AllProducts(Products):
    """A table of all products, regardless of their product type.

    Used e.g. in the product registry.

    """

    label = _("All Products")
    filter_out_unregistered = False
    required_roles = dd.login_required(ProductsStaff)


class AllCategories(Categories):
    """A table of all categories, regardless of their product type.

    Used e.g. in the product registry.

    """

    label = _("All Categories")
    filter_out_unregistered = False
    required_roles = dd.login_required(ProductsStaff)
