# -*- coding: UTF-8 -*-
# Copyright 2017-2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
The :ref:`pronto` extension of :mod:`lino_xl.lib.products`.

"""

from lino_xl.lib.products import Plugin as BasePlugin, _


class Plugin(BasePlugin):
    extends_models = ['Product']
    barcode_driver = "ean13"

    def setup_config_menu(self, site, user_type, m, ar=None):
        super().setup_config_menu(site, user_type, m, ar)
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action('products.ProductsQuickInsert')

    def setup_quicklinks(self, tb):
        tb.add_action("products.MyProducts")
        tb.add_action("products.ProductSearch")

    def get_local_css_chunks(self):
        yield """
        
        """

    def get_head_lines(self, site, request):
        yield """
        <style>
        .l-image-gallery {
            list-style-type: none;
            width: 100%;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;

            & li {
                border-radius: 0.25rem;
            }
        }
        
        .l-image-gallery-hero {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            cursor: pointer;
            width: 100%;
            aspect-ratio: 1 / 1;
            transition: opacity 0.15s ease-in-out;
        }
        
        .l-image-gallery-row-2 {
            position: relative;
            width: 100%;
        }
        
        .l-image-gallery-row-2-scroll {
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
            scrollbar-width: thin;
            justify-content: flex-start;
            scroll-behavior: smooth;
        }
        
        .l-image-gallery-row-2-scroll:not(.has-overflow) {
            justify-content: center;
        }
        
        .l-image-gallery-row-2-scroll .l-image-gallery-item {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            cursor: pointer;
            width: 10vmin;
            height: 10vmin;
            flex-shrink: 0;
            transition: opacity 0.15s ease-in-out;
        }
        
        .l-image-gallery-scroll-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 2rem;
            height: 2rem;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        
        .l-image-gallery-row-2.has-overflow .l-image-gallery-scroll-btn {
            display: flex;
        }
        
        .l-image-gallery-scroll-btn:hover {
            opacity: 1;
            background: rgba(255, 255, 255, 1);
        }
        
        .l-image-gallery-scroll-btn.left {
            left: 0.25rem;
        }
        
        .l-image-gallery-scroll-btn.right {
            right: 0.25rem;
        }
        
        .l-image-gallery-scroll-btn::before {
            content: '';
            width: 0.5rem;
            height: 0.5rem;
            border-top: 2px solid #333;
            border-right: 2px solid #333;
        }
        
        .l-image-gallery-scroll-btn.left::before {
            transform: rotate(-135deg);
            margin-left: 0.2rem;
        }
        
        .l-image-gallery-scroll-btn.right::before {
            transform: rotate(45deg);
            margin-right: 0.2rem;
        }
        
        .l-image-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            cursor: zoom-out;
        }
        
        .l-image-modal.active {
            display: flex;
        }
        
        .l-image-modal-content {
            max-width: 95%;
            max-height: 95%;
            object-fit: contain;
            cursor: default;
        }
        
        .l-image-modal-close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            width: 3rem;
            height: 3rem;
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            transition: background 0.2s;
        }
        
        .l-image-modal-close:hover {
            background: rgba(255, 255, 255, 1);
        }
        
        .l-image-modal-close::before,
        .l-image-modal-close::after {
            content: '';
            position: absolute;
            width: 1.5rem;
            height: 2px;
            background: #333;
        }
        
        .l-image-modal-close::before {
            transform: rotate(45deg);
        }
        
        .l-image-modal-close::after {
            transform: rotate(-45deg);
        }
        </style>
        <script>
        function updateCartActionButton(html, tile_id) {
            const updateButton = document.querySelector("#" + tile_id + "-update-button");
            if (updateButton) {
                updateButton.outerHTML = html;
            }
        }
        function openImageModal(imageUrl) {
            let modal = document.getElementById('lino-image-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'lino-image-modal';
                modal.className = 'l-image-modal';
                modal.innerHTML = `
                    <button class="l-image-modal-close" onclick="closeImageModal()" aria-label="Close"></button>
                    <img class="l-image-modal-content" src="" alt="Full size image">
                `;
                document.body.appendChild(modal);
                
                // Close on background click
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        closeImageModal();
                    }
                });
                
                // Close on Escape key
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape' && modal.classList.contains('active')) {
                        closeImageModal();
                    }
                });
            }
            
            const img = modal.querySelector('.l-image-modal-content');
            img.src = imageUrl;
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        
        function closeImageModal() {
            const modal = document.getElementById('lino-image-modal');
            if (modal) {
                modal.classList.remove('active');
                document.body.style.overflow = '';
            }
        }
        
        function swapBackgroundImages(e, tile_id) {
            const tile = document.querySelector("#" + tile_id);
            const target = e.target.closest('.l-image-gallery-item');
            if (!target) return;
            
            const hero = tile.querySelector('.l-image-gallery-hero');
            if (!hero) return;
            
            // Add animation class
            hero.style.opacity = '0.5';
            target.style.opacity = '0.5';
            
            setTimeout(() => {
                // Swap background images
                const heroStyle = window.getComputedStyle(hero).backgroundImage;
                const targetStyle = window.getComputedStyle(target).backgroundImage;
                
                hero.style.backgroundImage = targetStyle;
                target.style.backgroundImage = heroStyle;
                
                // Swap data-url attributes
                const heroUrl = hero.getAttribute('data-url');
                const targetUrl = target.getAttribute('data-url');
                hero.setAttribute('data-url', targetUrl);
                target.setAttribute('data-url', heroUrl);
                
                // Reset opacity
                hero.style.opacity = '1';
                target.style.opacity = '1';
            }, 150);
        }

        function tileScrollBy(event, tile_id, amount) {
            event.stopPropagation();
            const tile = document.querySelector("#" + tile_id);
            const scrollContainer = tile.querySelector('.l-image-gallery-row-2-scroll');
            if (!scrollContainer) return;
            scrollContainer.scrollBy({ left: amount, behavior: 'smooth' });
        }
        
        window.Lino = window.Lino || {};
        const Lino = window.Lino;
        Lino.setupDoneOnTile = {};
        function setupImageGalleryForTile(tile_id) {
            if (tile_id in Lino.setupDoneOnTile) return;
            Lino.setupDoneOnTile[tile_id] = true;
            const tile = document.querySelector("#" + tile_id);
            
            // Check for overflow and toggle buttons/centering
            const row2 = tile.querySelector('.l-image-gallery-row-2');
            const scrollContainer = tile.querySelector('.l-image-gallery-row-2-scroll');
            
            if (row2 && scrollContainer) {
                const checkOverflow = () => {
                    const hasOverflow = scrollContainer.scrollWidth > scrollContainer.clientWidth;
                    if (hasOverflow) {
                        row2.classList.add('has-overflow');
                        scrollContainer.classList.add('has-overflow');
                    } else {
                        row2.classList.remove('has-overflow');
                        scrollContainer.classList.remove('has-overflow');
                    }
                };
                
                // Check on load and on resize
                setTimeout(checkOverflow, 50);
                window.addEventListener('resize', checkOverflow);
            }
        }
        </script>
        """
