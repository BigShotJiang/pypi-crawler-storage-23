# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

import random
from PIL import Image
from django.conf import settings
from lino.api import rt, dd, _
from lino.modlib.uploads.mixins import make_uploaded_file, resize_and_crop
from lino.utils import Cycler
from lino.utils.instantiator import Instantiator
from lino_xl.lib.accounting.choicelists import TradeTypes
from lino_xl.lib.products.choicelists import ProductTypes, DeliveryUnits

try:
    from lino_book import DEMO_DATA
except ImportError:
    DEMO_DATA = None

AssociationTypes = rt.models.contacts.AssociationTypes
Company = rt.models.contacts.Company
ProductIndexRequest = rt.models.registry.ProductIndexRequest
ProductCategoryIndexRequest = rt.models.registry.ProductCategoryIndexRequest
RegistrationStates = rt.models.registry.RegistrationStates
product = Instantiator('products.Product', "vendor barcode_identity delivery_unit pieces_per_unit category").build
partnerprice = Instantiator('products.PartnerPrice', "partner product trade_type price").build
productcat = Instantiator("products.Category").build

IMAGES = []
DEMO_USER = dd.plugins.users.get_demo_user()
ar = rt.login(DEMO_USER.username)
krs = Company.objects.get(barcode_identity=8)
ms = Company.objects.get(barcode_identity=12)
INDEX_PARAMS = {
    'created_by': DEMO_USER,
    'created_by_partner': Company.objects.get(
        name="Miscellaneous",
        association_type=AssociationTypes.system
    ),
    'registered_by': DEMO_USER,
    "state": RegistrationStates.registered,
}


def create_demo_images():
    if DEMO_DATA is None:
        return
    Upload = rt.models.uploads.Upload
    demo_date = dd.demo_date()
    user = DEMO_USER
    global IMAGES

    def make_image(name):
        src = DEMO_DATA / "images" / name
        upload_filename = make_uploaded_file(name, src, demo_date)
        file = settings.SITE.media_root / upload_filename
        type = "image/" + name.split('.')[-1].lower()
        image = Image.open(file)
        width, height = image.size
        crop_min_width = dd.plugins.uploads.crop_min_width
        unit_of_measure = min(width, height) / crop_min_width
        original_width = width / unit_of_measure
        original_height = height / unit_of_measure
        crop = {
            "x": (original_width - crop_min_width) / 2,
            "y": (original_height - crop_min_width) / 2,
            "width": crop_min_width,
            "height": crop_min_width,
            "original_width": original_width,
            "original_height": original_height,
        }
        with file.open("rb") as f:
            imgdata, ext = resize_and_crop(type, f.read(), crop)
        with file.open("wb") as f:
            f.write(imgdata)
        upload = Upload(file=upload_filename, user=user)
        IMAGES.append(upload)
        yield upload

    for name in [
        "MurderontheOrientExpress.jpg",
        "StormIsland.jpg",
        "AndThenThereWereNone.jpg",
        "FirstThereWereTen.jpg"
    ]:
        yield make_image(name)
    IMAGES = Cycler(IMAGES)


def make_partner_prices(partner, product, sales_price, purchase_price):
    yield partnerprice(partner, product, TradeTypes.purchases, purchase_price)
    pp = partnerprice(partner, product, TradeTypes.sales, sales_price)
    yield pp

    pp.fix_problems.run_from_ui(ar, fix=True)
    for i in range(random.randint(0, 10)):
        yield rt.models.albums.AlbumItem(album=pp.album, upload=IMAGES.pop())


def configure_product(
    vendor,
    barcode_identity,
    delivery_unit,
    pieces_per_unit,
    category,
    name,
    sales_price,
    purchase_price,
):
    yield (
        p := product(
            vendor,
            barcode_identity,
            delivery_unit,
            pieces_per_unit,
            category,
            **dd.str2kw("name", name),
        )
    )
    yield ProductIndexRequest(
        product=p,
        **INDEX_PARAMS,
    )

    # p.fix_problems.run_from_ui(ar)
    # album_item = rt.models.albums.AlbumItem(album=p.album, upload=IMAGES.pop())
    # yield album_item

    yield make_partner_prices(krs, p, sales_price, purchase_price)
    yield make_partner_prices(ms, p, sales_price + random.choice([1, -1]), purchase_price)


def configure_category(**kw):
    cat = productcat(**kw)
    yield cat
    yield ProductCategoryIndexRequest(
        category=cat,
        **INDEX_PARAMS,
    )
    return cat


def objects():
    yield from create_demo_images()

    msm = Company.objects.get(barcode_identity=2)
    prodip = Company.objects.get(barcode_identity=3)
    oneplus = Company.objects.get(barcode_identity=4)
    osaca = Company.objects.get(barcode_identity=5)
    sk = Company.objects.get(barcode_identity=6)
    powerplus = Company.objects.get(barcode_identity=7)

    electrical = yield from configure_category(id=3, product_type=ProductTypes.default, **dd.str2kw('name', _("Electrical")))
    fan = yield from configure_category(id=4, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Fan")))
    exhaustfan = yield from configure_category(
        id=5, product_type=ProductTypes.default, parent=fan, **dd.str2kw('name', _("Exhaust Fan")))
    cableclip = yield from configure_category(
        id=6, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Cable clip")))
    distributionbox = yield from configure_category(
        id=7, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Distribution box")))
    wiretape = yield from configure_category(
        id=8, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Wire tape")))
    switchbox = yield from configure_category(
        id=9, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Switch box")))
    switch = yield from configure_category(
        id=10, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Switch")))
    pianoswitch = yield from configure_category(
        id=11, product_type=ProductTypes.default, parent=switch, **dd.str2kw('name', _("Piano switch")))
    gangswitch = yield from configure_category(
        id=12, product_type=ProductTypes.default, parent=switch, **dd.str2kw('name', _("Gang switch")))
    socket = yield from configure_category(
        id=13, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Socket")))
    pianosocket = yield from configure_category(
        id=14, product_type=ProductTypes.default, parent=socket, **dd.str2kw('name', _("Piano socket")))
    cutout = yield from configure_category(
        id=15, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Cutout")))
    pianocutout = yield from configure_category(
        id=16, product_type=ProductTypes.default, parent=cutout, **dd.str2kw('name', _("Piano cutout")))
    indicator = yield from configure_category(
        id=17, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Indicator")))
    pianoindicator = yield from configure_category(
        id=18, product_type=ProductTypes.default, parent=indicator, **dd.str2kw('name', _("Piano indicator")))
    holder = yield from configure_category(
        id=19, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Holder")))
    pipe = yield from configure_category(
        id=20, product_type=ProductTypes.default, parent=electrical, **dd.str2kw('name', _("Pipe")))

    yield configure_product(msm, 1, DeliveryUnits.box, 100, cableclip, _("Cable clip (size: 10mm)"), 60, 52)
    yield configure_product(msm, 2, DeliveryUnits.pack, 100, cableclip, _("Cable clip (size: 14mm)"), 72, 60)
    yield configure_product(msm, 3, DeliveryUnits.pack, 100, cableclip, _("Cable clip (size: 20mm)"), 130, 115)
    yield configure_product(msm, 4, DeliveryUnits.pack, 100, cableclip, _("Cable clip (size: 25mm)"), 180, 165)
    yield configure_product(msm, 5, DeliveryUnits.box, 100, cableclip, _("Cable clip (size: 4mm)"), 25, 20)
    yield configure_product(msm, 6, DeliveryUnits.box, 100, cableclip, _("Cable clip (size: 5mm)"), 26, 22)
    yield configure_product(msm, 7, DeliveryUnits.pack, 100, cableclip, _("Cable clip (size: 6mm)"), 30, 26)
    yield configure_product(msm, 8, DeliveryUnits.box, 100, cableclip, _("Cable clip (size: 7mm)"), 35, 30)
    yield configure_product(msm, 9, DeliveryUnits.box, 100, cableclip, _("Cable clip (size: 8mm)"), 45, 38)
    yield configure_product(oneplus, 1, DeliveryUnits.piece, None, holder, _("Ceiling holder"), 75, 72)
    yield configure_product(msm, 10, DeliveryUnits.piece, None, holder, _("Ceiling holder"), 32, 29)
    yield configure_product(prodip, 1, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: 10-13)"), 520, 500)
    yield configure_product(oneplus, 2, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: 14-16)"), 750, 700)
    yield configure_product(oneplus, 3, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: 4-6)"), 340, 360)
    yield configure_product(oneplus, 4, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: 7-9)"), 400, 370)
    yield configure_product(powerplus, 1, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: L1)"), 26, 23)
    yield configure_product(msm, 11, DeliveryUnits.piece, None, distributionbox, _("Distribution box (db box: L2)"), 30, 26)
    yield configure_product(oneplus, 5, DeliveryUnits.piece, None, exhaustfan, _("Exhaust fan (size: 10 inches)"), 710, 675)
    yield configure_product(oneplus, 6, DeliveryUnits.piece, None, exhaustfan, _("Exhaust fan (size: 12 inches)"), 820, 790)
    yield configure_product(oneplus, 7, DeliveryUnits.piece, None, exhaustfan, _("Exhaust fan (size: 6 inches)"), 620, 580)
    yield configure_product(oneplus, 8, DeliveryUnits.piece, None, exhaustfan, _("Exhaust fan (size: 8 inches)"), 670, 605)
    yield configure_product(oneplus, 9, DeliveryUnits.piece, None, switchbox, _("Join box"), 33, 31.5)
    yield configure_product(msm, 12, DeliveryUnits.piece, None, switchbox, _("Join box"), 25, 23)
    yield configure_product(msm, 13, DeliveryUnits.pack, 12, pianocutout, _("Piano cutout"), 150, 130)
    yield configure_product(msm, 14, DeliveryUnits.piece, None, pianoindicator, _("Piano indicator"), 35, 30)
    yield configure_product(msm, 15, DeliveryUnits.pack, 12, pianosocket, _("Piano socket"), 150, 130)
    yield configure_product(msm, 16, DeliveryUnits.pack, 12, pianoswitch, _("Piano switch"), 150, 130)
    yield configure_product(oneplus, 10, DeliveryUnits.piece, None, switchbox, _("PVC box (four gang)"), 52, 48)
    yield configure_product(oneplus, 11, DeliveryUnits.piece, None, switchbox, _("PVC box (one gang)"), 14, 12)
    yield configure_product(oneplus, 12, DeliveryUnits.piece, None, switchbox, _("PVC box (three gang)"), 45, 40)
    yield configure_product(oneplus, 13, DeliveryUnits.piece, None, switchbox, _("PVC box (two gang)"), 28, 25)
    yield configure_product(sk, 1, DeliveryUnits.piece, None, switchbox, _("Steel box (four gang)"), 105, 100)
    yield configure_product(sk, 2, DeliveryUnits.piece, None, switchbox, _("Steel box (one gang)"), 30, 29)
    yield configure_product(sk, 3, DeliveryUnits.piece, None, switchbox, _("Steel box (three gang)"), 85, 79)
    yield configure_product(sk, 4, DeliveryUnits.piece, None, switchbox, _("Steel box (two gang)"), 62, 59)
    yield configure_product(osaca, 1, DeliveryUnits.piece, None, wiretape, _("Tape"), 165, 150)
