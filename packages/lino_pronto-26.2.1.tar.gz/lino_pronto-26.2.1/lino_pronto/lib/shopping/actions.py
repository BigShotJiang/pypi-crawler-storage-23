# -*- coding: UTF-8 -*-
# Copyright 2024-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""Shopping plugin for a :ref:`pronto` project. This
inherits from :mod:`lino_xl.lib.shopping`.
"""

from django.db import models
from lino.api import dd, rt, _
from lino_xl.lib.shopping.actions import *
from .roles import CartUser


class AddToCart(AddToCart):
    """Use with PartnerPrice and NOT Product"""

    required_roles = dd.login_required(CartUser)
    parameters = dict(quantity=dd.QuantityField(_("Quantity"), default=1))
    params_layout = "quantity"

    def action_param_defaults(self, ar, obj, **kw):
        kw = super().action_param_defaults(ar, obj, **kw)
        my_cart = rt.models.shopping.AcquiringCart.objects.filter(
            user=ar.get_user()
        ).first()
        if my_cart:
            ci = rt.models.shopping.AcquiringCartItem.objects.filter(
                cart=my_cart, partner_price=obj
            ).first()
            if ci:
                kw.update(quantity=ci.qty)
        return kw

    def run_from_ui(self, ar):
        apv = ar.action_param_values
        quantity = apv.quantity
        my_cart = rt.models.shopping.AcquiringCart.create_user_plan(ar.get_user())
        AcquiringCartItem = rt.models.shopping.AcquiringCartItem
        texts = []
        if quantity == 0:
            qs = AcquiringCartItem.objects.filter(
                cart=my_cart, partner_price__pk__in=[obj.pk for obj in ar.selected_rows]
            )
            count = qs.count()
            qs.delete()
            msg = _("{} item(s) have been removed from your shopping cart.").format(
                count
            )
        else:
            for obj in ar.selected_rows:
                texts.append(
                    str(obj.product) + _(" by ") + str(obj.partner) + f" (x{quantity})"
                )
                qs = AcquiringCartItem.objects.filter(cart=my_cart, partner_price=obj)
                if qs.exists():
                    new = False
                    ci = qs.get()
                else:
                    new = True
                    ci = AcquiringCartItem(cart=my_cart, partner_price=obj)
                ci.qty = quantity
                ci.full_clean()

                # if not ar.xcallback_answers:  # because this is called again after confirm
                #     if new:
                #         ci.save_new_instance(ci.get_default_table().create_request(parent=ar))
                #     else:
                #         ci.save()
                if new:
                    ci.save_new_instance(
                        ci.get_default_table().create_request(parent=ar)
                    )
                else:
                    ci.save()

            # def ok(ar2):
            #     ar2.goto_instance(my_cart)

            # msg = _("{} has been placed to your shopping cart. Proceed to cart?")
            # ar.confirm(ok, msg)
            msg = _("{} has been placed to your shopping cart.").format(
                ", ".join(texts)
            )

        if len(ar.selected_rows) == 1:
            obj = ar.selected_rows[0]
            button = obj.get_cart_action_button(ar)
            ar.set_response(
                eval_js=f"updateCartActionButton('{button}', 'tile-{obj.pk}')"
            )

        ar.success(message=msg)


class UpdateQuantity(dd.Action):
    label = _("Update quantity")
    parameters = dict(quantity=dd.QuantityField(_("Quantity"), default=1))
    params_layout = "quantity"
    select_rows = True
    required_roles = dd.login_required(CartUser)

    def action_param_defaults(self, ar, obj, **kw):
        kw = super().action_param_defaults(ar, obj, **kw)
        kw.update(quantity=obj.qty)
        return kw

    def run_from_ui(self, ar):
        apv = ar.action_param_values
        quantity = apv.quantity
        if quantity <= 0:
            raise Exception(
                _(
                    "Quantity cannot be zero or negative. To remove an item, please use the delete action."
                )
            )

        texts = []
        for obj in ar.selected_rows:
            texts.append(
                str(obj.partner_price.product)
                + _(" by ")
                + str(obj.partner_price.partner)
                + f" (x{quantity})"
            )
            obj.qty = quantity
            obj.full_clean()
            obj.save()
        msg = _("Quantities have been updated for items: {}").format(", ".join(texts))
        if len(ar.selected_rows) == 1:
            obj = ar.selected_rows[0]
            para = rt.models.shopping.AcquiringItemsByCart.row_as_paragraph(ar, obj)
            para = para.replace("`", "\\`")  # escape backticks
            ar.set_response(
                eval_js=f"updateCartItemParagraph(`{para}`, 'para-{obj.pk}');"
            )
            master_data = {"total_cost": obj.cart.total_cost}
            ar.set_response(master_data=master_data)
        ar.success(message=msg)


class ChangeSupplier(dd.Action):
    label = _("Change supplier")
    parameters = dict(
        supplier=dd.ForeignKey("contacts.Company", verbose_name=_("Supplier"))
    )
    params_layout = "supplier"
    select_rows = True
    required_roles = dd.login_required(CartUser)

    @dd.chooser()
    def supplier_choices(cls, ar, **kw):
        obj = ar.selected_rows[0]
        assert isinstance(obj, rt.models.shopping.AcquiringCartItem), _(
            "This action is only available for AcquiringCartItem instances."
        )
        Company = rt.models.contacts.Company
        return (
            Company.objects.exclude(pk=obj.partner_price.partner.pk)
            .annotate(
                has_query_product=models.Case(
                    models.When(
                        models.Exists(
                            rt.models.products.PartnerPrice.objects.filter(
                                partner=models.OuterRef("pk"),
                                product=obj.partner_price.product,
                                trade_type=rt.models.products.TradeTypes.sales,
                            )
                        ),
                        then=models.Value(1),
                    ),
                    default=models.Value(0),
                    output_field=models.IntegerField(),
                )
            )
            # TODO: filter by location and distance
            .filter(has_query_product=1)
        )
    
    def get_choices_text(self, obj, ar, field):
        item = ar.selected_rows[0]
        pp = rt.models.products.PartnerPrice.objects.get(
            product=item.partner_price.product,
            partner=obj,
            trade_type=rt.models.products.TradeTypes.sales,
        )
        return (
            super().get_choices_text(obj, ar, field) +
            f" ({dd.get_plugin_setting("accounting", "currency_symbol", "$")}{pp.price})"
        )

    def run_from_ui(self, ar):
        apv = ar.action_param_values
        supplier = apv.supplier

        texts = []
        for obj in ar.selected_rows:
            texts.append(
                str(obj.partner_price.product)
                + _(" by ")
                + str(obj.partner_price.partner)
            )
            pp_qs = rt.models.products.PartnerPrice.objects.filter(
                product=obj.partner_price.product,
                partner=supplier,
                trade_type=rt.models.products.TradeTypes.sales,
            )
            if not pp_qs.exists():
                raise Exception(
                    _("The selected supplier does not offer the product {}").format(
                        obj.partner_price.product
                    )
                )
            obj.partner_price = pp_qs.first()
            obj.full_clean()
            obj.save()

        if len(ar.selected_rows) == 1:
            obj = ar.selected_rows[0]
            para = rt.models.shopping.AcquiringItemsByCart.row_as_paragraph(ar, obj)
            para = para.replace("`", "\\`")  # escape backticks
            ar.set_response(
                eval_js=f"updateCartItemParagraph(`{para}`, 'para-{obj.pk}');"
            )
            master_data = {"total_cost": obj.cart.total_cost}
            ar.set_response(master_data=master_data)
        msg = _("Supplier has been changed for items: {}").format(", ".join(texts))
        ar.success(message=msg)


class GotoInvoicingPlan(dd.Action):
    label = _("Go to invoicing plan")
    required_roles = dd.login_required(CartUser)
    icon_name = "money"
    select_rows = False
    journal_suffix = ""
    never_collapse = True

    def run_from_ui(self, ar):
        user = ar.get_user()
        ref = rt.models.accounting.Journal.ref_prefix(user.ledger.company) + self.journal_suffix
        invoicing_task = rt.models.invoicing.Task.objects.filter(
            target_journal__ref=ref).first()
        if invoicing_task is None:
            raise Exception(
                _("No invoicing plan found for your ledger's {} journal.").format(self.journal_suffix)
            )
        my_plan = rt.models.invoicing.Plan.create_user_plan(user, invoicing_task=invoicing_task)
        my_plan.run_update_plan(ar)
        ar.goto_instance(my_plan)


class GotoInvoicingPlanPO(GotoInvoicingPlan):
    journal_suffix = "PO"


class GotoInvoicingPlanSLS(GotoInvoicingPlan):
    journal_suffix = "SLS"
