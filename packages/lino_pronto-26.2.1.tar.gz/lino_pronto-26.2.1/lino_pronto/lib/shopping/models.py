# -*- coding: UTF-8 -*-
# Copyright 2024-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
Django model (db tables) definitions for :mod:`lino_pronto.lib.shopping` plugin.
"""

from django.db.models.functions import Cast
from django.utils.html import format_html, mark_safe
from lino.api import rt, dd, _
from lino.core import constants
from lino.core.roles import SiteAdmin
from lino.modlib.users.mixins import StartPlan
from lino.utils.html import tostring
from lino_xl.lib.invoicing.mixins import InvoiceGenerator
from lino_xl.lib.shopping.models import *
from lino_xl.lib.shopping.mixins import CartItemMixin
from .roles import CartUser, CartStaff
from .actions import (UpdateQuantity, ChangeSupplier, AddToCart, GotoInvoicingPlanPO,
                      GotoInvoicingPlanSLS)


class InvoiceableCartItem(dd.Model):
    class Meta:
        abstract = True

    def get_invoiceable_end_date(self):
        return None  # End date is not relevant for cart items

    def get_invoiceable_qty(self):
        return self.qty

    def get_invoiceable_product(self, max_date=None):
        return self.partner_price.product

    def after_invoicing(self, ar, invoice):
        ret = super().after_invoicing(ar, invoice)
        self.delete()
        return ret

    def get_wanted_invoice_items(self, info, invoice, ar):
        for item in super().get_wanted_invoice_items(info, invoice, ar):
            item.unit_price = self.partner_price.price
            # item.amount = self.qty * item.unit_price
            item.set_amount(ar, self.qty * self.partner_price.price)
            yield item


class AcquiringCart(UserPlan):
    class Meta:
        app_label = "shopping"
        abstract = dd.is_abstract_model(__name__, 'AcquiringCart')
        verbose_name = _("Ordering cart")
        verbose_name_plural = _("Ordering carts")

    po_invoicing_plan = GotoInvoicingPlanPO()

    @dd.virtualfield(dd.PriceField(_("Total")))
    def total_cost(self, ar):
        if self.pk is None:
            return 0
        total = self.items.aggregate(
            final_total=models.Sum(
                Cast("qty", dd.PriceField()) * models.F("partner_price__price")
            )
        )["final_total"]
        return total or 0
    
    @classmethod
    def create_user_plan(cls, user, **options):
        qs = cls.objects.filter(user=user)
        num = qs.count()
        if num == 1:
            plan = qs.first()
            changed = False
            for k, v in options.items():
                if getattr(plan, k) != v:
                    changed = True
                    setattr(plan, k, v)
            # if "today" not in options:
            #     if plan.today != dd.today():
            #         plan.today = dd.today()
            #         changed = True
            if changed:
                plan.reset_plan()
        else:
            if num > 1:
                dd.logger.warning(
                    f"Got {num} {cls._meta.verbose_name_plural} for {user}"
                )
                qs.delete()
            plan = cls(user=user, **options)
        plan.full_clean()
        plan.save()
        return plan

    def run_update_plan(self, ar):
        Filler = rt.models.storage.Filler
        AcquiringCartItem = rt.models.shopping.AcquiringCartItem
        PartnerPrice = rt.models.products.PartnerPrice
        for filler in Filler.objects.filter(
            partner=ar.get_user().ledger.company,
            provision_state=rt.models.storage.ProvisionStates.in_stock
        ):
            if AcquiringCartItem.objects.filter(cart=self, partner_price__product=filler.provision_product).exists():
                continue
            provision = rt.models.storage.Provision.objects.filter(
                partner_price__partner=filler.partner,
                product=filler.provision_product,
                provision_state=rt.models.storage.ProvisionStates.in_stock
            ).first()
            pp = (
                PartnerPrice.objects.filter(
                    # TODO: add location logic to filter by nearest supplier
                    product=filler.provision_product,
                    trade_type=rt.models.products.TradeTypes.sales,
                )
                .order_by("price")
                .first()
            )
            if provision is None:
                filler.fix_problems.run_from_ui(ar, fix=True)
                item = AcquiringCartItem(
                    cart=self,
                    partner_price=pp,
                    qty=filler.fill_asset
                )
                item.full_clean()
                item.save_new_instance(item.get_default_table().create_request(parent=ar))
            else:
                if provision.qty <= filler.min_asset:
                    item = AcquiringCartItem(
                        cart=self,
                        partner_price=pp,
                        qty=filler.fill_asset - provision.qty
                    )
                    item.full_clean()
                    item.save_new_instance(item.get_default_table().create_request(parent=ar))

        ar.success(refresh=True)


AcquiringCart.update_plan.never_collapse = True


class AcquiringCartItem(CartItemMixin, InvoiceableCartItem, InvoiceGenerator):
    class Meta:
        app_label = "shopping"
        abstract = dd.is_abstract_model(__name__, 'AcquiringCartItem')
        verbose_name = _("Ordering cart item")
        verbose_name_plural = _("Ordering cart items")
        unique_together = ('cart', 'partner_price')

    cart = dd.ForeignKey("shopping.AcquiringCart", related_name="items")
    partner_price = dd.ForeignKey("products.PartnerPrice",
                                  verbose_name=_("Product price"),
                                  null=True, blank=True,
                                  on_delete=models.SET_NULL)

    update_quantity = UpdateQuantity()
    change_supplier = ChangeSupplier()

    def get_invoiceable_partner(self):
        return self.partner_price.partner

    @classmethod
    def get_generators_for_plan(cls, plan, partner=None):
        qs = super().get_generators_for_plan(plan, partner)
        qs = qs.filter(cart__user__ledger=plan.user.ledger)
        if partner is not None:
            qs = qs.filter(partner_price__partner=partner)
        return qs

    def full_clean(self, *args, **kwargs):
        if self.product is None:
            assert self.partner_price is not None
            self.product = self.partner_price.product
        return super().full_clean(*args, **kwargs)


class StartPlan(StartPlan):
    required_roles = dd.login_required(CartUser)
    def get_button_label(self, actor):
        return _("New shopping cart")


def get_misc_partner():
    return rt.models.contacts.Company.objects.get(
        name="Miscellaneous",
        association_type=rt.models.contacts.AssociationTypes.customer,
        registry__state=rt.models.registry.RegistrationStates.registered
    )


class Cart(Cart):

    manager_roles_required = dd.login_required(CartUser)
    # workflow_owner_field = "partner"

    class Meta(Cart.Meta):
        abstract = dd.is_abstract_model(__name__, 'Cart')

    partner = dd.ForeignKey('contacts.Partner', null=True, blank=True, on_delete=models.SET_DEFAULT,
                            default=get_misc_partner)

    start_new_plan = StartPlan()
    sls_invoicing_plan = GotoInvoicingPlanSLS()

    def run_update_plan(self, ar):
        # self.reset_plan()
        self.partner = get_misc_partner()
        self.today = dd.today()
        self.invoice = None
        self.cart_items.all().delete()
        self.full_clean()
        self.save()

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        dfs.add("start_order")
        return dfs


AllCarts.required_roles = dd.login_required(SiteAdmin)
Carts.required_roles = dd.login_required(CartStaff)
Carts.detail_layout = """user partner today delivery_method
    invoicing_address delivery_address invoice
    shopping.ItemsByCart
    """


class ItemsByCart(ItemsByCart):
    column_names = "partner_price qty"

    @classmethod
    def after_create_instance(cls, obj, ar):
        ret = super().after_create_instance(obj, ar)
        if not obj.qty:
            obj.qty = obj.partner_price.min_order_qty
            obj.full_clean()
            obj.save()
        return ret


class AcquiringCarts(dd.Table):
    model = 'shopping.AcquiringCart'
    required_roles = dd.login_required(SiteAdmin)
    # column_names = "user today *"
    detail_layout = """
    total_cost
    shopping.AcquiringItemsByCart
    """


class MyAcquiringCart(My, AcquiringCarts):
    label = _("Orders plan")
    required_roles = dd.login_required(CartStaff)
    default_record_id = "myself"

    # @classmethod
    # def get_actor_label(self):
    #     return super().get_actor_label()

    @classmethod
    def get_row_by_pk(cls, ar, pk):
        return cls.model.create_user_plan(ar.get_user())


class MyCart(MyCart):
    # TODO: Configure inserting from phantom row in CartItem
    label = _("Shopping cart")
    required_roles = dd.login_required(CartStaff)
    default_record_id = "myself"

    @classmethod
    def get_row_by_pk(cls, ar, pk):
        return cls.model.create_user_plan(ar.get_user())


# class CartForPartner(Carts):
#     hide_navigator = True
#     required_roles = dd.login_required(CartUser)


class CartItem(CartItem, InvoiceableCartItem, InvoiceGenerator):
    class Meta(CartItem.Meta):
        abstract = dd.is_abstract_model(__name__, 'CartItem')
        unique_together = ('cart', 'partner_price')

    partner_price = dd.ForeignKey("products.PartnerPrice",
                                  verbose_name=_("Product"),
                                  null=True, blank=True,
                                  on_delete=models.SET_NULL)

    def get_invoiceable_partner(self):
        return self.cart.partner

    @classmethod
    def get_generators_for_plan(cls, plan, partner=None):
        qs = super().get_generators_for_plan(plan, partner)
        qs = qs.filter(cart__user=plan.user)
        # if partner is not None:
        #     qs = qs.filter(partner_price__partner=partner)
        return qs

    def full_clean(self, *args, **kwargs):
        if self.product is None:
            assert self.partner_price is not None, _("partner_price must not be None")
            self.product = self.partner_price.product
        return super().full_clean(*args, **kwargs)

    @dd.chooser()
    def partner_price_choices(cls, ar):
        qs = rt.models.products.PartnerPrice.objects.filter(
            trade_type=rt.models.products.TradeTypes.sales,
            partner=ar.get_user().ledger.company,
            product__registry__isnull=False,
            product__registry__state=rt.models.registry.RegistrationStates.registered,
        )
        return qs


class AcquiringItemsByCart(dd.Table):
    master_key = 'cart'
    model = 'shopping.AcquiringCartItem'
    required_roles = dd.login_required(CartUser)
    column_names = "partner_price__partner partner_price__product qty partner_price__price total_cost"
    allow_create = False

    default_display_modes = {
        None: constants.DISPLAY_MODE_LIST,
    }

    @dd.virtualfield(dd.PriceField(_("Total cost")))
    def total_cost(self, obj, ar):
        return obj.qty * obj.partner_price.price

    @classmethod
    def row_as_paragraph(cls, ar, row):
        title = "<div><p><strong>{}</strong></p></div>".format(_(f"{row.partner_price.product} by {row.partner_price.partner}"))
        delete_ba = cls.get_url_action("delete_selected")
        sar = cls.create_request(master_instance=row.cart, parent=ar, selected_rows=[row], action=delete_ba)
        # delete_action = tostring(sar.as_button())
        delete_action = tostring(sar.row_action_button(row, delete_ba))
        header = f"<div style=\"display: flex; justify-content: space-between; align-items: center;\">{title}<div>{delete_action}</div></div>"
        sar = cls.create_request(
            master_instance=row.cart, parent=ar, selected_rows=[row]
        )
        quantity = f"{row.qty}" + tostring(sar.row_action_button(row, sar.actor.get_action_by_name("update_quantity"), label=" ( ± )"))
        # expense = f"""<table class=\"table\">
        #     <thead>
        #         <tr>
        #             <th>{_("Unit price")}</th>
        #             <th>{_("Quantity")}</th>
        #             <th>{_("Total cost")}</th>
        #         </tr>
        #     </thead>
        #     <tbody>
        #         <tr>
        #             <td>{row.partner_price.price}</td>
        #             <td>{quantity}</td>
        #             <td>{row.qty * row.partner_price.price}</td>
        #         </tr>
        #     </tbody>
        # </table>"""
        expense = f"<p>{_("Unit price")} x {_("Quantity")} = {_("Total cost")}"
        currency_symbol = dd.get_plugin_setting("accounting", "currency_symbol", "$")
        expense += f"<br>{currency_symbol}{row.partner_price.price} x {quantity} = {currency_symbol}{row.qty * row.partner_price.price}</p>"
        actions = ""
        if rt.models.products.PartnerPrice.objects.filter(
            product=row.partner_price.product,
            trade_type=rt.models.products.TradeTypes.sales
        ).exclude(
            pk=row.partner_price.pk
        ).exists():
            # actions += "<br>"
            actions += f"<button class=\"p-component\">{tostring(sar.row_action_button(row, sar.actor.get_action_by_name("change_supplier"), label=_("Change supplier")))}</button>"
        para = format_html(
            "<div class=\"l-items-by-cart-container\" id='para-{}'>{}</div>",
            row.pk,
            mark_safe(header + expense + actions),
        )
        return para


dd.inject_action("products.PartnerPrice", add_to_cart=AddToCart(show_in_toolbar=False))
