# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""Shopping plugin for a :ref:`pronto` project. This
inherits from :mod:`lino_xl.lib.shopping`.

"""

from lino_xl.lib.shopping import Plugin


class Plugin(Plugin):

    extends_models = ["Cart", "CartItem"]

    def get_quicklinks(self):
        yield 'shopping.MyCart'
        yield 'shopping.MyAcquiringCart'

    def get_head_lines(self, site, request):
        yield """
        <style>
        .l-items-by-cart-container {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
        }
        </style>
        <script>
        function updateCartItemParagraph(html, para_id) {
            var para = document.getElementById(para_id);
            if (para) {
                // Extract the original "rp" value from the existing element
                var originalRp = null;
                var rpMatch = para.innerHTML.match(/&quot;rp&quot;:\\s*&quot;([^&]+)&quot;/);
                if (rpMatch) {
                    originalRp = rpMatch[1];
                }
                
                // If we found an original rp value, replace all rp values in the new html
                if (originalRp) {
                    html = html.replace(/(&quot;rp&quot;:\\s*&quot;)[^&]+(&quot;)/g, '$1' + originalRp + '$2');
                }
                
                para.outerHTML = html;
            }
        }
        </script>
        """
