# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""This package provides SEPA (Single Euro Payments Area) related
functionality for Lino Pronto.

"""

from lino_xl.lib.sepa.models import *
