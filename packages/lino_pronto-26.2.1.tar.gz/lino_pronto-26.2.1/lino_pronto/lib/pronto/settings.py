# -*- coding: UTF-8 -*-
# Copyright 2011-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""Default settings module for a :ref:`pronto` project. This is being
inherited by the demo projects in :mod:`lino_pronto.projects`.

"""

import lino_pronto
from lino_pronto import SETUP_INFO
from lino.projects.std.settings import *


class Site(Site):
    """Base class for a :ref:`pronto` application.

    """

    verbose_name = "Lino Pronto"
    description = SETUP_INFO['description']
    version = lino_pronto.__version__
    url = SETUP_INFO['url']

    demo_fixtures = ["std", "few_countries", "minimal_ledger", "demo", "demo2", "checkdata", "checksummaries"]

    # languages = 'en de fr'
    languages = 'en bn'

    user_types_module = 'lino_pronto.lib.pronto.user_types'
    custom_layouts_module = 'lino_pronto.lib.pronto.layouts'

    default_build_method = 'weasy2pdf'

    # textfield_format = 'html'

    def get_plugin_configs(self):
        yield super().get_plugin_configs()
        yield 'users', 'allow_online_registration', True
        yield 'accounting', 'has_purchases', True
        yield 'accounting', 'has_payment_methods', True
        yield "countries", "country_code", "BD"
        yield "linod", "daemon_user", "admin"
        yield "checkdata", "fix_in_background", True
        yield "notify", "use_FCM", True  # Enable Firebase Cloud Messaging for Android notifications
        # yield "notify", "use_sql_cte", True  # Use Common Table Expressions for email sending tasks
        yield ("contacts", "site_owner_lookup",
               dict(name="Pronto BD", registry__isnull=False, registry__state="registered"))
        # yield 'vat', 'declaration_plugin', 'lino_xl.lib.bdvat'
        # yield "uploads", "crop_min_width", 460
        yield "uploads", "crop_aspect_ratio", 1
        yield "uploads", "crop_resize_width", 460
        yield "accounting", "currency_symbol", "৳"  # Bangladeshi Taka
        yield "react", "app_link_android_intent_package", "net.mylino.prontobd"
        yield "react", "app_link_show_open_in_app_banner", True
        yield "react", "app_link_show_fix_settings_cta", True
        yield "react", "primereact_theme_name", "bootstrap4-light-blue"
        yield "jinja", "background_color", "#f0f8ff00"

    def get_installed_plugins(self):
        yield super().get_installed_plugins()
        yield 'lino.modlib.gfks'
        # yield 'lino.modlib.system'
        yield 'lino_pronto.lib.users'
        yield 'lino_xl.lib.countries'
        yield 'lino_pronto.lib.contacts'
        # yield 'lino_xl.lib.webforms'
        yield 'lino_pronto.lib.webforms'
        #~ yield 'lino_xl.lib.households'

        yield 'lino_xl.lib.excerpts'

        # yield 'lino_xl.lib.outbox'
        yield 'lino.modlib.uploads'
        yield 'lino.modlib.weasyprint'
        yield 'lino.modlib.export_excel'
        yield 'lino.modlib.tinymce'
        # yield 'lino.modlib.wkhtmltopdf'

        # accounting must come before trading because its demo fixture
        # creates journals (?)

        yield 'lino_pronto.lib.products'
        yield 'lino_pronto.lib.accounting'
        yield 'lino_pronto.lib.ledgers'
        yield 'lino_pronto.lib.sepa'
        yield 'lino_xl.lib.finan'
        yield 'lino_pronto.lib.vat'
        # yield 'lino_xl.lib.vat'
        yield 'lino_xl.lib.bdvat'
        # yield 'lino_xl.lib.bevat'
        yield 'lino_pronto.lib.trading'
        yield 'lino_pronto.lib.invoicing'
        yield 'lino_pronto.lib.storage'
        yield 'lino_pronto.lib.shopping'
        #~ 'lino.modlib.journals',
        #~ 'lino_xl.lib.projects',
        #~ yield 'lino_xl.lib.blogs'
        #~ yield 'lino.modlib.tickets'
        #~ 'lino.modlib.links',
        #~ 'lino_xl.lib.thirds',
        #~ yield 'lino_xl.lib.postings'
        # yield 'lino_xl.lib.pages'
        # yield "lino_pronto.lib.notify"
        yield "lino.modlib.notify"
        yield "lino_xl.lib.albums"
        yield "lino_pronto.lib.registry"
        yield 'lino_pronto.lib.pronto'


USE_TZ = True
TIME_ZONE = 'UTC'
