# -*- coding: UTF-8 -*-
# Copyright 2015-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""This plugin is automatically installed on sites who use some of the
plugins defined in :mod:`lino_pronto.lib`.  It currently defines the
translations for all these plugins.

.. autosummary::
   :toctree:

    models
    user_types

"""

from lino.api import ad


class Plugin(ad.Plugin):
    
    def get_dashboard_items(self, user):
        yield self.site.models.notify.MyMessages

    def get_patterns(self):
        # this is called once after startup.
        # print("20221102 get_patterns()")
        from django.urls import re_path as url
        from . import views

        rx = '^'

        urls = [
            url(rx + r".well-known/(?P<file_name>[a-zA-Z.]+)$", views.WellKnown.as_view()),
        ]
        return urls
    