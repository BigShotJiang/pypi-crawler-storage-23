# -*- coding: UTF-8 -*-
# Copyright 2011-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
The :xfile:`models.py` module for :ref:`pronto`.

This is empty.
"""

from lino.api import dd, rt
from lino.modlib.users.mixins import My


@dd.receiver(dd.pre_analyze)
def setup(sender, **kwargs):
    MyUploads = rt.models.uploads.MyUploads
    MyUploads.allow_create = False
    MyUploads.camera_stream = None

    MyMessages = rt.models.notify.MyMessages
    MyMessages.required_roles = dd.login_required()

    # MyExcerpts = rt.models.excerpts.MyExcerpts

    @dd.chooser()
    def user_choices(cls, ar):
        User = rt.models.users.User
        user = ar.get_user()
        if user.is_anonymous:
            return User.objects.none()
        return User.objects.filter(pk=user.pk)

    # MyExcerpts.user_choices = user_choices
    My.user_choices = user_choices
