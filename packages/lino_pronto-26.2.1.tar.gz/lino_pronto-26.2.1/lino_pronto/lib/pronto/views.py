# -*- coding: UTF-8 -*-
# Copyright 2015-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""This module defines the views for :ref:`pronto`.

"""

from django import http
from django.views.generic import View
from lino.api import _
from lino.core.views import json_response


class WellKnown(View):
    def get(self, request, file_name=None):
        if file_name == "assetlinks.json":
            return json_response(
                {
                    "relation": ["delegate_permission/common.handle_all_urls"],
                    "target": {
                        "namespace": "android_app",
                        "package_name": "net.mylino.prontobd",
                        "sha256_cert_fingerprints": [
                            "6F:5B:ED:2C:50:D4:AB:4B:D0:D6:0C:66:72:4A:8B:2E:97:F6:2C:A9:2D:73:51:E6:C4:CD:6A:61:46:E9:14:2D"
                        ],
                    },
                }
            )
        else:
            raise http.Http404(_("Unknown file name: %s") % file_name)
