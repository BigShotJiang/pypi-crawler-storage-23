import random
from lino.api import rt
from lino.utils.instantiator import Instantiator
from lino.utils.cycler import Cycler

random.seed(1)


def objects():
    Company = rt.models.contacts.Company
    Product = rt.models.products.Product
    ProvisionStates = rt.models.storage.ProvisionStates
    PartnerPrice = rt.models.products.PartnerPrice
    filler_ = Instantiator("storage.Filler", "provision_product fill_asset min_asset").build
    provision = Instantiator("storage.Provision", "partner_price qty provision_state").build

    ge_bd = Company.objects.get(barcode_identity=9)

    filler = lambda fill_asset, product: filler_(product, str(fill_asset), "5", partner=ge_bd,
        provision_state=ProvisionStates.in_stock)

    for p in (p_qs := Product.objects.all())[4:p_qs.count() - 4]:
        yield filler(random.randint(10, 100), p)

    krs = Company.objects.get(barcode_identity=8)

    companies = Company.objects.filter(
        association_type__in=['supplier', "seller"]
    ).exclude(barcode_identity__in=[8, 12]).exclude(name="Miscellaneous")

    products = Product.objects.all()

    for company in companies:
        for _ in range(30):
            product = random.choice(products)
            try:
                sales_price = PartnerPrice.objects.get(
                    partner=krs, product=product, trade_type="sales").price
            except PartnerPrice.DoesNotExist:
                continue
            if PartnerPrice.objects.filter(partner=company, product=product, trade_type="sales").exists():
                print(f"PartnerPrice already exists for {company} and {product}, skipping.")
                continue
            yield (pp := PartnerPrice(partner=company, product=product,
                trade_type="sales", price=sales_price + random.randint(-10, 10)))
            yield provision(pp, random.randint(2, 50), ProvisionStates.in_stock)
