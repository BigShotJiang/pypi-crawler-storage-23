# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
"""

from lino_xl.lib.storage import Plugin


class Plugin(Plugin):
    extends_models = ['Provision', "Filler"]
    needs_plugins = ['lino_pronto.lib.products', 'lino.modlib.summaries']

    def setup_main_menu(self, site, user_type, m, ar=None):
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("storage.MyProvisions")

    def setup_quicklinks(self, tb):
        tb.add_action("storage.MyStorageFillers")
