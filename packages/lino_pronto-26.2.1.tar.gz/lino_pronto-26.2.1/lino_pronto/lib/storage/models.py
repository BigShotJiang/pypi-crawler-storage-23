# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
"""
from django.core.exceptions import ValidationError
from django.db.models import Q, UniqueConstraint, CheckConstraint, Sum, F
from django.utils.text import format_lazy
from django.utils.translation import gettext
from lino.api import rt, dd, _
from lino.core.roles import SiteAdmin
from lino.modlib.checkdata.choicelists import Checker
from lino_xl.lib.storage.models import *
from lino_xl.lib.storage.choicelists import ProvisionStates
from lino.core.actions import ShowTable


ProvisionStates.clear()
add = ProvisionStates.add_item

add('100', _("In stock"), 'in_stock')
add('200', _("Out of stock"), 'out_of_stock')
add('300', _("Ordered by customer"), 'ordered_cust')
add('400', _("Ordered from provider"), 'ordered_due')
add('500', _("Rented out"), 'rented_out')
add('600', _("Damaged"), 'damaged')
add('700', _("Under repair"), 'under_repair')


class Provision(Provision):
    """
    In pronto we reference the owner of the provision via Provision.partner_price.partner
    and the Provision.partner is reserved for the customer who ordered the product
    or supplier who provides it.
    """
    
    class Meta(Provision.Meta):
        app_label = 'storage'
        abstract = dd.is_abstract_model(__name__, 'Provision')
        # unique_together = [
        #     ('partner_price', 'provision_state'),
        # ]
        constraints = [
            UniqueConstraint(
                fields=['partner_price', 'provision_state'],
                condition=Q(provision_state=ProvisionStates.in_stock),
                name='unique_provision_when_in_stock'
            ),
            UniqueConstraint(
                fields=['partner', 'partner_price', 'provision_state'],
                condition=(~Q(provision_state=ProvisionStates.in_stock)
                          & ~Q(provision_state=ProvisionStates.out_of_stock)),
                name='unique_provision_with_partner'
            ),
            CheckConstraint(
                condition=~Q(provision_state=ProvisionStates.out_of_stock),
                name='no_out_of_stock_provisions'
            ),
            CheckConstraint(
                condition=~Q(provision_state=ProvisionStates.in_stock) | Q(partner__isnull=True),
                name='in_stock_partner_must_be_none'
            ),
        ]
    
    quick_search_fields = [
        "partner_price__product__name",
        "partner_price__partner__name",
        "partner_price__product__body",
        "partner_price__product__barcode_identity",
    ]
    allow_cascaded_delete = ["partner_price"]

    partner_price = dd.ForeignKey("products.PartnerPrice")

    def full_clean(self, *args, **kwargs):
        if self.product_id is None:
            assert self.partner_price is not None
            self.product = self.partner_price.product
        elif self.partner_price_id is not None and self.partner_price.product != self.product:
            raise ValidationError(
                _("Product mismatch: partner_price.product must match product field")
            )
        return super().full_clean(*args, **kwargs)
    

class Filler(Filler):
    """
    In pronto we reference the owner of the filler via Filler.partner_price.partner
    """
    
    class Meta(Filler.Meta):
        app_label = 'storage'
        abstract = dd.is_abstract_model(__name__, 'Filler')

    def clean(self):
        super().clean()
        if self.fill_asset is not None and self.min_asset is not None:
            if self.fill_asset <= self.min_asset:
                raise ValidationError({
                    'fill_asset': _("Fill asset must be greater than minimum asset.")
                })


class FillerChecker(Checker):
    verbose_name = _("Check for fillers with provision")
    model = Filler
    msg_missing = _("The storage filler ({}) is missing an 'in_stock' provision.")

    def get_checkdata_problems(self, ar, obj, fix=False):
        ProvisionStates = rt.models.storage.ProvisionStates
        Provision = rt.models.storage.Provision
        pp_qs = rt.models.products.PartnerPrice.objects.filter(
            partner=obj.partner,
            product=obj.provision_product,
            trade_type="sales",
        )
        if not pp_qs.exists():
            yield (
                False,
                format_lazy(
                    _("The storage filler ({}) has no corresponding partner price."),
                    obj,
                ),
            )
            return

        provision_exists = Provision.objects.filter(
            partner_price=pp_qs.first(),
            product=obj.provision_product,
            provision_state=ProvisionStates.in_stock
        ).exists()
        if not provision_exists:
            yield (True, format_lazy(
                self.msg_missing,
                obj,
            ))
            if fix:
                prov = Provision(
                    partner_price=pp_qs.first(),
                    product=obj.provision_product,
                    provision_state=ProvisionStates.in_stock,
                    qty="0"
                )
                prov.full_clean()
                prov.save_new_instance(prov.get_default_table().create_request(parent=ar))


FillerChecker.activate()


class FillersByPartner(FillersByPartner):
    required_roles = dd.login_required(SiteAdmin)

    @classmethod
    def get_row_permission(cls, obj, ar, state, ba):
        user = ar.get_user()
        if user.ledger is None:
            return False
        return obj.partner == user.ledger.company.partner_ptr
    
    @classmethod
    def get_request_queryset(self, ar, **fltr):
        user = ar.get_user()
        if user.ledger is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        return qs.filter(partner=user.ledger.company.partner_ptr)


Fillers.required_roles = dd.login_required(SiteAdmin)


class ShowFillersTable(ShowTable):

    def get_action_permission(self, ar, obj, state):
        if ar.get_user().ledger is None:
            return False
        return super().get_action_permission(ar, obj, state)


class MyStorageFillers(FillersByPartner):

    required_roles = dd.login_required(StorageUser)
    column_names = "provision_product min_asset fill_asset available_qty"

    # @classmethod
    # def get_default_action(cls):
    #     return ShowFillersTable()

    @dd.virtualfield(dd.QuantityField(_("Available quantity")))
    def available_qty(cls, obj, ar):
        user = ar.get_user()
        if user.ledger is None:
            return "0"
        pp_qs = rt.models.products.PartnerPrice.objects.filter(
            partner=user.ledger.company,
            product=obj.provision_product,
        )
        if not pp_qs.exists():
            return "0"
        Provision = rt.models.storage.Provision
        ProvisionStates = rt.models.storage.ProvisionStates
        prov = Provision.objects.filter(
            partner_price=pp_qs.get(),
            provision_state=ProvisionStates.in_stock
        ).get()
        return prov.qty if prov else "0"

    @classmethod
    def get_master_instance(self, ar, model, pk):
        return ar.get_user().ledger.company.partner_ptr


dd.update_field(Provision, "qty", verbose_name=_("Available quantity"))
dd.update_field(Provision, "partner", null=True, blank=True)


Provisions.required_roles = dd.login_required(SiteAdmin)

class MyProvisions(Provisions):
    
    required_roles = dd.login_required(StorageUser)
    column_names = "partner_price product qty provision_state"

    @classmethod
    def get_request_queryset(self, ar, **fltr):
        user = ar.get_user()
        if user.is_anonymous or user.ledger is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        return qs.filter(partner_price__partner=user.ledger.company)

