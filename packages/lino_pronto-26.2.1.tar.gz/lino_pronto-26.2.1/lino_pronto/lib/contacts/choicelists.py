# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import rt, dd, _


class AssociationType(dd.Choice):
    def __init__(self, value, text, names, default_user_type, **kwargs):
        # self.default_user_type = rt.models.users.UserTypes.get_by_name(default_user_type)
        self.default_user_type = default_user_type
        super().__init__(value, text, names, **kwargs)


class AssociationTypes(dd.ChoiceList):
    """Choice list for types of associations between partners."""
    item_class = AssociationType
    verbose_name = _("Association Type")


add = AssociationTypes.add_item
add("c", _("Simple Citizen"), "customer", "user")
add("s", _("Shop Owner / Retailer"), "seller", "seller")
add("S", _("Wholesaler"), "supplier", "supplier")
add("m", _("Manufacturer"), "manufacturer", "manufacturer")
add("hq", _("System association"), "system", "staff")
