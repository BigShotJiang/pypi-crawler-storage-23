# -*- coding: UTF-8 -*-
# Copyright 2019 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
Lino Pronto extension of :mod:`lino_xl.lib.contacts`

.. autosummary::
   :toctree:

    fixtures.std
    fixtures.demo

"""

from lino_xl.lib.contacts import Plugin


class Plugin(Plugin):
    extends_models = ['Partner', 'Company', 'Person']
    # needs_plugins = ['lino_pronto.lib.pronto']

    fallback_partner_name = 'Miscellaneous'
    """The name to use for the fallback partner created in fixtures.
    
    This partner is used as a fallback for vouchers where the actual partner
    is not known, particularly in trading workflows.
    """

    def setup_main_menu(self, site, user_type, m, ar=None):
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action('contacts.FamiliarPersons')
        m.add_action('contacts.FamiliarCompanies')

    def setup_config_menu(self, site, user_type, m, ar=None):
        super().setup_config_menu(site, user_type, m, ar)
        m = m.add_menu(self.app_label, self.verbose_name)

    def setup_explorer_menu(self, site, user_type, m, ar=None):
        # super().setup_explorer_menu(site, user_type, m, ar)
        m = m.add_menu(self.app_label, self.verbose_name)
        m.add_action("contacts.Roles")
        m.add_action('contacts.AllPersons')
        m.add_action('contacts.AllCompanies')
        m.add_action('contacts.AllPartners')

    def setup_quicklinks(self, tb):
        tb.add_action("contacts.MyCompany")
