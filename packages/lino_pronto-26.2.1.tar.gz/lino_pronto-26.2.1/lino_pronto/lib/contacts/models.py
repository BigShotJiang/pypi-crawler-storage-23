# -*- coding: UTF-8 -*-
# Copyright 2013-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.text import format_lazy
from django.utils.translation import gettext
from lino.api import dd, rt, _
from lino.core.atomizer import get_atomizer
from lino.core.roles import SiteAdmin, SiteStaff, SiteUser
from lino.modlib.checkdata.choicelists import Checker
from lino.modlib.notify.choicelists import MessageTypes
from lino.utils.html import E
from lino_xl.lib.accounting.utils import DC
from lino_xl.lib.contacts.models import *
from lino_xl.lib.invoicing.utils import invoicing_task, invoicing_rule
from .mixins import ByFamiliarity, is_familiar, make_familiar
from .choicelists import AssociationTypes


class SetBarcodeIdentity(dd.Action):
    """
    Action to set barcode identity for selected companies.
    """
    label = _("Set barcode identity")
    button_text = "#️⃣"
    required_roles = dd.login_required(SiteStaff)

    def run_from_ui(self, ar, **kw):
        barcodes = rt.models.contacts.Company.objects.values_list("barcode_identity", flat=True)
        
        def find_barcode_id(start=1):
            barcode_id = start
            while barcode_id in barcodes:
                barcode_id += 1
            return barcode_id
        
        barcode_id = 1
        exists_msg = _("{} has barcode id. ")
        set_msg = _("Set barcode id to {} ({}). ")
        msg = ""
        for obj in ar.selected_rows:
            if obj.barcode_identity is None:
                barcode_id = find_barcode_id(barcode_id)
                obj.barcode_identity = barcode_id
                obj.full_clean()
                obj.save()
                msg += set_msg.format(barcode_id, obj)
                barcode_id += 1
            else:
                msg += exists_msg.format(obj)
        ar.set_response(refresh=True)
        ar.success(msg)


class Partner(Partner):
    """Base table for partners in Lino Pronto."""
    class Meta:
        abstract = dd.is_abstract_model(__name__, "Partner")

    def get_overview_elems(self, ar):
        elems = super().get_overview_elems(ar)
        elems += [str(self.gsm)]
        return elems
    

class Person(Person, Partner):
    """Base table for persons in Lino Pronto."""
    class Meta:
        abstract = dd.is_abstract_model(__name__, "Person")


class Company(Company, Partner):
    """Base table for companies in Lino Pronto."""
    class Meta:
        abstract = dd.is_abstract_model(__name__, "Company")
        unique_together = [('barcode_identity', )]

    association_type = AssociationTypes.field()
    
    set_barcode_identity = SetBarcodeIdentity()

    def disabled_fields(self, ar):
        fields = super().disabled_fields(ar)
        if self.association_type != rt.models.contacts.AssociationTypes.manufacturer:
            fields.add('set_barcode_identity')
        return fields
    
    def full_clean(self, *args, **kwargs):
        if self.association_type == AssociationTypes.manufacturer\
            and hasattr(self, "registry")\
            and self.registry.state == rt.models.registry.RegistrationStates.registered:
            if not self.barcode_identity:
                raise ValidationError({
                    'barcode_identity': _("Barcode identity is required for manufacturers")
                })
        return super().full_clean(*args, **kwargs)


class Familiarity(dd.Model):
    """
    Table to keep a record about who knows who.

    Similar to social-media's add-friend.

    `company` knows the `partner`.
    """

    class Meta:
        app_label = "contacts"
        abstract = dd.is_abstract_model(__name__, "Familiarity")
        verbose_name = _("Familiarity")
        verbose_name_plural = _("Familiarities")
        unique_together = [('company', 'partner')]

    allow_cascaded_delete = ["company"]

    company = dd.ForeignKey("contacts.Company", related_name="familiarities_by_company")
    partner = dd.ForeignKey("contacts.Partner", related_name="familier_to")


class CompanyChecker(Checker):
    verbose_name = _("Check for missing ledger")
    model = Company
    msg_missing = _("This company ({}) has no ledger.")

    def get_checkdata_problems(self, ar, obj, fix=False):
        Ledger = rt.models.ledgers.Ledger
        if not Ledger.objects.filter(company=obj).exists():
            yield (True, format_lazy(self.msg_missing, obj))
            if fix:
                ledger = Ledger(company=obj)
                ledger.full_clean()
                ledger.save_new_instance(ledger.get_default_table().create_request(parent=ar))
                obj.ledger = ledger
                obj.full_clean()
                obj.save()
                
                JournalGroups = rt.models.accounting.JournalGroups
                VoucherTypes = rt.models.accounting.VoucherTypes
                InvoicesByJournal = rt.models.trading.InvoicesByJournal
                
                kw = dict(journal_group=JournalGroups.sales, ledger=ledger, trade_type='sales',
                          dc=DC.credit, voucher_type=VoucherTypes.get_for_table(InvoicesByJournal))

                def make_journal(ref, printed_name, name, **kwargs):
                    kwargs.update(kw)
                    kwargs.update(dd.str2kw('name', name), ref=ref, printed_name=printed_name)
                    vtt = kwargs.pop('table', InvoicesByJournal)
                    return vtt.create_journal(**kwargs)

                REF_PREFIX = obj.as_ref_prefix()

                OFF_JNL = make_journal(f"{REF_PREFIX}OFF", _("Offer"), _("Offers"))
                OFF_JNL.full_clean()
                OFF_JNL.save_new_instance(OFF_JNL.get_default_table().create_request(parent=ar))

                CMP_JNL = make_journal(f"{REF_PREFIX}CMP", _("Component sheet"), _("Component sheets"))
                CMP_JNL.full_clean()
                CMP_JNL.save_new_instance(CMP_JNL.get_default_table().create_request(parent=ar))

                SLS_JNL = make_journal(f"{REF_PREFIX}SLS", _("Invoice"), _("Sales invoices"),
                                       make_storage_movements=True)
                SLS_JNL.full_clean()
                SLS_JNL.save_new_instance(SLS_JNL.get_default_table().create_request(parent=ar))

                task = invoicing_task(SLS_JNL.ref, user_id=1, disabled=True)
                task.full_clean()
                task.save_new_instance(
                    task.get_default_table().create_request(parent=ar)
                )
                follow_up_rule = invoicing_rule(SLS_JNL.ref, rt.models.shopping.CartItem)
                follow_up_rule.full_clean()
                follow_up_rule.save_new_instance(
                    follow_up_rule.get_default_table().create_request(parent=ar)
                )

                misc_partner = rt.models.contacts.Company.objects.get(
                    name="Miscellaneous",
                    association_type=AssociationTypes.customer,
                    registry__state=rt.models.registry.RegistrationStates.registered,
                )

                kw.pop('voucher_type')
                CashInvoicesByJournal = rt.models.trading.CashInvoicesByJournal

                SDN_JNL = make_journal(f"{REF_PREFIX}SDN", _("Delivery note"), _("Delivery notes"),
                                       partner=misc_partner, make_ledger_movements=False, make_storage_movements=True,
                                       table=CashInvoicesByJournal)
                SDN_JNL.full_clean()
                SDN_JNL.save_new_instance(SDN_JNL.get_default_table().create_request(parent=ar))

                SSN_JNL = make_journal(f"{REF_PREFIX}SSN", _("Sales note"), _("Sales notes"),
                                       partner=misc_partner, make_ledger_movements=True, make_storage_movements=True,
                                       table=CashInvoicesByJournal)
                SSN_JNL.full_clean()
                SSN_JNL.save_new_instance(SSN_JNL.get_default_table().create_request(parent=ar))

                # Create purchase order journal
                PurchaseOrdersByJournal = rt.models.accounting.PurchaseOrdersByJournal
                kw.update(journal_group=JournalGroups.purchases,
                          trade_type='purchases', dc=DC.credit,
                          voucher_type=VoucherTypes.get_for_table(PurchaseOrdersByJournal))
                
                PO_JNL = make_journal(f"{REF_PREFIX}PO", _("Purchase order"), _("Purchase orders"),
                                      table=PurchaseOrdersByJournal)
                PO_JNL.full_clean()
                PO_JNL.save_new_instance(PO_JNL.get_default_table().create_request(parent=ar))

                # Create VAT declaration journal
                kw.update(journal_group=JournalGroups.vat,
                          trade_type='taxes', dc=DC.debit)
                Declaration = rt.models.bdvat.Declaration

                VAT_JNL = make_journal(f"{REF_PREFIX}VAT", _("VAT declaration"), _("VAT declarations"),
                                     must_declare=False, table=VoucherTypes.get_for_model(Declaration).table_class)
                VAT_JNL.full_clean()
                VAT_JNL.save_new_instance(VAT_JNL.get_default_table().create_request(parent=ar))

                task = invoicing_task(PO_JNL.ref, user_id=1, disabled=True)
                task.full_clean()
                task.save_new_instance(task.get_default_table().create_request(parent=ar))
                follow_up_rule = invoicing_rule(PO_JNL.ref, rt.models.shopping.AcquiringCartItem)
                follow_up_rule.full_clean()
                follow_up_rule.save_new_instance(follow_up_rule.get_default_table().create_request(parent=ar))

                CommonAccounts = rt.models.accounting.CommonAccounts

                for common_account in CommonAccounts.get_list_items():
                    account = common_account.create_object(ref=f"{REF_PREFIX}{common_account.value}", ledger=ledger)
                    account.full_clean()
                    account.save_new_instance(account.get_default_table().create_request(parent=ar))


CompanyChecker.activate()


class PartnerDetail(PartnerDetail):

    main = "general accounting sepa.AccountsByPartner"

    general = dd.Panel("""
    address_box:60 contact_box:30 overview
    bottom_box
    """,
                       label=_("General"))

    accounting = dd.Panel("""
    purchase_account
    vat.VouchersByPartner
    accounting.MovementsByPartner
    """,
                      label=dd.plugins.accounting.verbose_name)

    address_box = dd.Panel("""
    name_box
    country region city zip_code:10
    addr1
    street_prefix street:25 street_no street_box
    addr2
    """,
                           label=_("Address"))

    contact_box = dd.Panel("""
    info_box
    email:40
    url
    # phone
    gsm #fax
    """,
                           label=_("Contact"))

    bottom_box = """
    remarks
    """

    name_box = "name"
    info_box = "id language"

    accounting = dd.Panel(
        """
        partner_ref
        vat.VouchersByPartner
        accounting.MovementsByPartner
        """,
        label=dd.plugins.accounting.verbose_name,
    )


class PersonDetail(PartnerDetail, PersonDetail):

    name_box = "last_name first_name:15 gender title:10"
    info_box = "id:5 language:10"
    bottom_box = "remarks contacts.RolesByPerson"


class CompanyDetail(PartnerDetail, CompanyDetail):
    main = "general accounting storage"

    bottom_box = """
    barcode_identity association_type
    remarks contacts.RolesByCompany
    """

    storage = dd.Panel("""
    storage.FillersByPartner storage.ProvisionsByPartner
    """, label=dd.plugins.storage.verbose_name)

    name_box = "prefix:10 name type:30"


class MyRegisteredCompanyDetail(CompanyDetail):
    """
    Detail layout for the user's own registered company.
    
    Used in `registry.MyCompanyRegistrationRequests`.
    """
    main = "all"
    
    all = """
    status barcode_identity association_type
    general
    """


class FamiliarCompanies(Companies, ByFamiliarity):
    label = _("Companies")

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        qs = qs.filter(
            models.Q(registry__state=rt.models.registry.RegistrationStates.registered)
            | models.Q(registry__created_by__ledger=ar.get_user().ledger),
            registry__isnull=False,
        )
        return qs


class FamiliarPartners(Partners, ByFamiliarity):
    label = _("Partners")


class FamiliarPersons(Persons, ByFamiliarity):
    label = _("Persons")


class MyCompany(Companies):
    label = _("My company")
    default_record_id = "row"

    @classmethod
    def get_row_permission(cls, obj, ar, state, ba):
        if (user := ar.get_user()).ledger is None:
            return True
        if obj == user.ledger.company:
            return True
        return False

    @classmethod
    def get_row_by_pk(cls, ar, pk):
        if (user := ar.get_user()).ledger is None:
            return None
        return user.ledger.company
    
    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        user = ar.get_user()
        if user.ledger is None:
            return qs.none()
        return qs.filter(pk=user.ledger.company_id)


class Companies(Companies):
    label = _("Companies")
    _editable = False
    # detail_layout = None
    filter_out_unregistered = True

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        if cls.filter_out_unregistered:
            qs = qs.filter(
                models.Q(registry__state=rt.models.registry.RegistrationStates.registered)
                | models.Q(registry__created_by__ledger=ar.get_user().ledger),
                registry__isnull=False,
            )
        return qs


class Partners(Partners):
    _editable = False
    detail_layout = None
    filter_out_unregistered = True

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        qs = super().get_request_queryset(ar, **fltr)
        # Filter out unregistered companies, but keep persons and companies created by current user
        if cls.filter_out_unregistered:
            RegistrationStates = rt.models.registry.RegistrationStates
            qs = qs.exclude(
                models.Q(company__isnull=False) &
                models.Q(company__registry__state__in=[
                    RegistrationStates.new,
                    RegistrationStates.under_review,
                    RegistrationStates.rejected,
                ]) &
                ~models.Q(company__registry__created_by__ledger=ar.get_user().ledger)
            )
        return qs


class Persons(Persons):
    _editable = False
    detail_layout = None


class AllPersons(Persons):
    label = _("All persons")
    _editable = True
    required_roles = dd.login_required(SiteStaff)
    detail_layout = "contacts.PersonDetail"


class AllCompanies(Companies):
    label = _("All companies")
    _editable = True
    required_roles = dd.login_required(SiteStaff)
    detail_layout = "contacts.CompanyDetail"
    filter_out_unregistered = False


class AllPartners(Partners):
    label = _("All partners")
    _editable = True
    required_roles = dd.login_required(SiteStaff)
    detail_layout = "contacts.PartnerDetail"
    filter_out_unregistered = False
