# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import rt, _
from lino.utils.instantiator import Instantiator
# from lino_xl.lib.ledgers.utils import prepare_company

def objects():
    company = Instantiator('contacts.Company', "name barcode_identity association_type").build
    role = Instantiator('contacts.Role', "type person company").build

    RoleType = rt.models.contacts.RoleType
    Person = rt.models.contacts.Person
    Company = rt.models.contacts.Company
    User = rt.models.users.User
    ceo = RoleType.objects.get(name='CEO')
    pos_agent = RoleType.objects.get(name='POS Agent')
    supply_staff = RoleType.objects.get(name='Supply staff')
    admin = rt.models.users.User.objects.get(username='admin')
    AssociationTypes = rt.models.contacts.AssociationTypes
    CompanyRegistrationRequest = rt.models.registry.CompanyRegistrationRequest
    RegistrationStates = rt.models.registry.RegistrationStates

    def prep_company(company_name, bid, association_type, roletype=ceo, username=None, fname=None, lname=None):
        user, _ = User.objects.get_or_create(username=username or company_name)
        person, created = Person.objects.get_or_create(
            first_name=fname or user.first_name or company_name, last_name=lname or user.last_name)
        if created:
            yield person
        user.partner = person.partner_ptr
        yield user
        yield (c := company(company_name, bid, association_type))
        yield role(roletype, person, c)
        # yield prepare_company(c, user)
        c.fix_problems.run_from_ui(c.get_default_table().create_request(), fix=True)
        yield CompanyRegistrationRequest(company=c,
                                         created_by=admin,
                                         registered_by=admin,
                                         state=RegistrationStates.registered,
                                         is_creators_company=False)
        user.ledger = c.ledger
        yield user

    yield prep_company("MSM", 2, AssociationTypes.manufacturer)
    yield prep_company("Prodip", 3, AssociationTypes.manufacturer)
    yield prep_company("One plus", 4, AssociationTypes.manufacturer)
    yield prep_company("Osaca", 5, AssociationTypes.manufacturer)
    yield prep_company("SK", 6, AssociationTypes.manufacturer)
    yield prep_company("Power plus", 7, AssociationTypes.manufacturer)
    yield prep_company("KRS Business Center", 8, AssociationTypes.supplier, username='russel')
    yield prep_company("General electronics BD", 9, AssociationTypes.seller, username="cleopatra")
    yield prep_company("Techno BD", 10, AssociationTypes.seller, username="david")
    yield prep_company("Digital world", 11, AssociationTypes.seller, username="hank")
    yield prep_company("Mobile star", 12, AssociationTypes.supplier, username="liam")

    abunomani = User.objects.get(username='abunomani')
    gretel = User.objects.get(username='gretel')

    yield (p_an := Person(first_name=abunomani.first_name, last_name=abunomani.last_name))
    yield (p_hg := Person(first_name=gretel.first_name, last_name=gretel.last_name))

    abunomani.partner = p_an
    yield abunomani
    gretel.partner = p_hg
    yield gretel

    make_subscription = rt.models.ledgers.make_ledger_subscription
    ar = rt.models.ledgers.Ledger.get_default_table().request()

    cleopatra = User.objects.get(username='cleopatra')
    krs = Company.objects.get(barcode_identity=8)
    ge = Company.objects.get(barcode_identity=9)

    make_subscription(abunomani, dict(company=ge, role=pos_agent, ledger=None), ar)
    make_subscription(cleopatra, dict(company=krs, role=supply_staff, ledger=None), ar)
    make_subscription(gretel, dict(company=krs, role=supply_staff, ledger=None), ar)
