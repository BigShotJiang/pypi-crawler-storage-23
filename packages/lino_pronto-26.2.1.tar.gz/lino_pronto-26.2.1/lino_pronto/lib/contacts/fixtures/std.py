from lino.api import _
from lino_xl.lib.contacts.fixtures.std import *

old_objects = objects
AssociationTypes = rt.models.contacts.AssociationTypes
RegistrationStates = rt.models.registry.RegistrationStates
CompanyRegistrationRequest = rt.models.registry.CompanyRegistrationRequest


def add_company(name, association_type, user, **kw):
    company = rt.models.contacts.Company(
        name=name,
        association_type=association_type,
        **kw
    )
    yield company
    yield CompanyRegistrationRequest(
        company=company,
        created_by=user,
        state=RegistrationStates.registered,
        registered_by=user,
    )


def objects():
    yield old_objects()

    RoleType = rt.models.contacts.RoleType

    yield RoleType(**dd.str2kw('name', _("Distributor")))
    yield RoleType(**dd.str2kw('name', _("POS Agent")))
    yield RoleType(**dd.str2kw('name', _("Supply staff")))

    misc = dd.get_plugin_setting('contacts', 'fallback_partner_name')
    admin = rt.models.users.User.objects.get(username='admin')

    yield add_company(misc, AssociationTypes.customer, admin)
    yield add_company(misc, AssociationTypes.seller, admin)
    yield add_company(misc, AssociationTypes.supplier, admin)
    yield add_company(misc, AssociationTypes.manufacturer, admin, barcode_identity=1)
    yield add_company(misc, AssociationTypes.system, admin)
    yield add_company("Pronto BD", AssociationTypes.system, admin)
