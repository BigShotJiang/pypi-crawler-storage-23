# -*- coding: UTF-8 -*-
# Copyright 2025 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""
This module defines some mixins useful for Lino Pronto.
"""

from django.db import models
from lino.api import dd, rt  # type: ignore


class ByCompany(dd.Table):
    """A mixin for tables that are filtered by the current company.
    """
    abstract = True
    company_lookup_key = "company"

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        """Return the company related queryset only"""
        qs = super().get_request_queryset(ar, **fltr)
        company = ar.get_user().ledger.company
        if company is not None:
            qs = qs.filter(**{cls.company_lookup_key: company})
        return qs


class ByFamiliarity(dd.Table):
    """Mixin for table where familiarity matters"""
    abstract = True
    outer_reference_field = "pk"
    _editable = False
    allow_create = False
    allow_delete = False

    @classmethod
    def get_request_queryset(cls, ar, **fltr):
        user = ar.get_user()
        if user.is_anonymous or user.ledger is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **fltr)
        qs = qs.annotate(familiar=models.Case(
            models.When(
                models.Exists(
                    rt.models.contacts.Familiarity.objects.filter(
                        company=ar.get_user().ledger.company,
                        partner=models.OuterRef(cls.outer_reference_field)
                    )
                ),
                then=models.Value(True)
            ),
            default=models.Value(False),
            output_field=models.BooleanField()
        )).filter(familiar=True)
        return qs


def is_familiar(ar, partner, company=None):
    """Return True if the given partner is familiar for the current user."""
    user = ar.get_user()
    if user.is_anonymous or user.ledger is None:
        return False
    if company is None:
        company = user.ledger.company
    return rt.models.contacts.Familiarity.objects.filter(
        company=company,
        partner=partner
    ).exists()


def make_familiar(ar, partner, company=None):
    """Make the given partner familiar for the current user."""
    user = ar.get_user()
    if user.is_anonymous or user.ledger is None:
        return
    if company is None:
        company = user.ledger.company
    if not is_familiar(ar, partner, company):
        fam = rt.models.contacts.Familiarity(company=company, partner=partner)
        fam.full_clean()
        fam.save_new_instance(fam.get_default_table().create_request(parent=ar))
