# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""The :xfile:`__init__.py` module for :ref:`webforms`.
"""

from lino_xl.lib.webforms import Plugin as BasePlugin


class Plugin(BasePlugin):
    extends_models = ['CreateUserRequest']
