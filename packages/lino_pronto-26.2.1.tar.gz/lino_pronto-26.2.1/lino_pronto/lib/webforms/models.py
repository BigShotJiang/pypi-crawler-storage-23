# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""The :xfile:`models.py` module for :ref:`webforms`."""

from django.core.exceptions import ValidationError
from lino.api import dd, rt, _
from lino_xl.lib.webforms.models import *


class CreateUserRequest(CreateUserRequest):
    class Meta(CreateUserRequest.Meta):
        abstract = dd.is_abstract_model(__name__, 'CreateUserRequest')

    def full_clean(self, *args, **kwargs):
        ret = super().full_clean(*args, **kwargs)
        HAS_VALID_PASSWORD = rt.models.users.HAS_VALID_PASSWORD
        if rt.models.users.User.objects.filter(HAS_VALID_PASSWORD, email=self.email).exists():
            raise ValidationError(
                _("The email {} is taken. Please choose another one."
                  " Or try sign in or password reset.").format(self.email))
        return ret


class CreateUserRequestsWeb(CreateUserRequestsWeb):

    @classmethod
    def after_create_instance(cls, obj, ar):
        ret = super().after_create_instance(obj, ar)
        User = rt.models.users.User
        UserTypes = rt.models.users.UserTypes
        fields = ("first_name", "last_name", "username", "email", "language")
        ut = UserTypes.get_by_name(dd.plugins.users.user_type_new)
        user = User(user_type=ut, **{f: getattr(obj, f) for f in fields})
        user.set_password(obj.password)
        user.on_create(ar)
        user.full_clean()
        user.save()
        obj.password = ""
        obj.user_created = user
        obj.save()
        return ret


@dd.receiver(dd.post_analyze)
def setup(sender, **kwargs):
    if dd.is_installed('linod'):
        rt.models.linod.SystemTask.objects.filter(
            procedure=getattr(
                rt.models.linod.Procedures, 'create_users')
        ).update(disabled=True)
