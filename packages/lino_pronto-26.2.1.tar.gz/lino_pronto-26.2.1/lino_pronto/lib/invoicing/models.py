# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, _
from lino.core import constants
from lino.core.roles import SiteAdmin
from lino.utils.html import format_html, mark_safe, tostring
from lino_xl.lib.invoicing.models import *


class Task(Task):
    class Meta(Task.Meta):
        abstract = dd.is_abstract_model(__name__, "Task")

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        user = ar.get_user()
        if user.user_type.has_required_roles([SiteAdmin]):
            return super().get_request_queryset(ar, **filter)
        if user.is_anonymous or user.ledger is None:
            return cls.objects.none()
        qs = super().get_request_queryset(ar, **filter)
        qs = qs.filter(target_journal__ledger=user.ledger)
        return qs


class Plan(Plan):
    class Meta(Plan.Meta):
        abstract = dd.is_abstract_model(__name__, "Plan")

    def get_row_permission(self, ar, state, ba):
        user = ar.get_user()
        if user.is_anonymous:
            return False
        if not user.user_type.has_required_roles([SiteAdmin]):
            return self.user == user
        return super().get_row_permission(ar, state, ba)
    
    @classmethod
    def get_request_queryset(cls, ar, **filter):
        user = ar.get_user()
        if user.user_type.has_required_roles([SiteAdmin]):
            return super().get_request_queryset(ar, **filter)
        if user.is_anonymous or user.ledger is None:
            return cls.objects.none()
        qs = super().get_request_queryset(ar, **filter)
        qs = qs.filter(user=user)
        return qs


Plan.execute_plan.never_collapse = True


class Item(Item):
    class Meta(Item.Meta):
        abstract = dd.is_abstract_model(__name__, "Item")

    def as_tile(self, ar, prev, **kwargs):
        invoice_button = self.get_invoice_button(ar)
        if invoice_button is None:
            invoice_button = ""
        else:
            invoice_button = tostring(invoice_button)

        selected = "✅" if self.selected else "☐"
        chunk = format_html(
            """
            <div style="text-align: center;">
                <p>{}: {}</p>
                <p>{}: {}</p>
                <div>
                    <p>{}:<br/>{}</p>
                </div>
                <p>{}: {}</p>
                <p>{}: {}</p>
                <div>{}: {}</div>
            </div>""",
            _("Selected"),
            selected,
            _("Supplier"),
            self.partner,
            _("Preview"),
            self.preview,
            _("Invoiceables"),
            self.number,
            _("Amount"),
            self.amount,
            _("Execute plan"),
            mark_safe(invoice_button),
        )
        return format_html(constants.TILE_TEMPLATE, chunk=mark_safe(chunk))


ItemsByPlan.default_display_modes = {
    None: constants.DISPLAY_MODE_GRID,
    70: constants.DISPLAY_MODE_TILES,
}
