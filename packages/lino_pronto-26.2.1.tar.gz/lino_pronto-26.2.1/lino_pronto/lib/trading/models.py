# -*- coding: UTF-8 -*-
# Copyright 2011-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""Shopping plugin for a :ref:`pronto` project. This
inherits from :mod:`lino_xl.lib.trading`.
"""

from django.conf import settings
from django.db import models
from django.utils.html import mark_safe, format_html
from django.utils.text import format_lazy
from lino.api import dd, rt, _
from lino.core import constants
from lino.core.roles import SiteAdmin
from lino.modlib.notify.choicelists import MessageTypes
from lino.utils.format_number import localize_number
from lino_xl.lib.accounting.roles import LedgerUser
from lino_xl.lib.products.roles import ProductsUser
from lino_xl.lib.trading.models import *

MessageTypes.add_item("po_followup", _("Purchase order follow-up"))
FALLBACK_PARTNER_NAME = dd.get_plugin_setting('contacts', 'fallback_partner_name')


def partner_price(partner, product, ar):
    """Get or create the partner price for the given product and current user's ledger."""
    kw = {
        "trade_type": rt.models.accounting.TradeTypes.sales,
        "product": product,
        "partner": partner,
    }
    PartnerPrice = rt.models.products.PartnerPrice
    pp = PartnerPrice.objects.filter(**kw).first()
    if pp is None:
        pp = PartnerPrice(price=0, **kw)
        pp.full_clean()
        pp.save_new_instance(
            pp.get_default_table().create_request(parent=ar)
        )

        users = rt.models.users.User.objects.filter(ledger=partner.ledger)
        recipients = [(user, user.mail_mode) for user in users]
        actor = rt.models.products.MyProducts
        def msg_func(user):
            subject = _("New partner price created (that needs your attention)")

            params = {}
            if not user.has_usable_password():
                params[constants.URL_PARAM_SUBST_USER] = user.pk
            permalink = "{}{}".format(
                settings.SITE.server_url,
                ar.renderer.get_detail_url(ar, actor, pp.pk, **params),
            )
            obj_url = format_html('<a href="{}">{}</a>', permalink, _("price"))

            body = _(
                "A new partner price has been created for product {0} "
                "and partner {1}. Please update the {2}."
            ).format(product, partner, obj_url)
            body = mark_safe("<p>{}</p>".format(body))
            return (subject, body)
        rt.models.notify.Message.emit_notification(
            ar, pp, MessageTypes.po_followup, msg_func, recipients
        )
    return pp


def provision(product, partner_price, partner, provision_state, ar):
    """Get or create the outbound provision for the given product, price, and partner."""
    Provision = rt.models.storage.Provision
    kw = {
        "product": product,
        "partner_price": partner_price,
        "partner": partner,
        "provision_state": provision_state,
    }
    prov = Provision.objects.filter(**kw).first()
    if prov is None:
        prov = Provision(qty="0", **kw)
        prov.full_clean()
        prov.save_new_instance(
            prov.get_default_table().create_request(parent=ar)
        )
    return prov


def update_provision(
        product, partner, partner_price, provision_state, qty_delta, ar):
    prov = provision(
        product, partner_price, partner, provision_state, ar)
    prov.qty += qty_delta
    prov.full_clean()
    prov.save()
    return prov


class ApprovalStates(dd.Workflow):
    """Workflow states for voucher approvals."""
    required_roles = dd.login_required(LedgerUser)

    @classmethod
    def get_column_names(cls, ar):
        return 'value name text button_text'
    
    @classmethod
    def before_state_change(cls, obj, ar, old_state, new_state):
        """Hook called before state transition."""

        if obj.sales_invoice and obj.sales_invoice.state == rt.models.accounting.VoucherStates.registered:
            ar.error(_("Cannot change approval state because the linked sales invoice is already registered."))
            raise Exception("Cannot change approval state")

        user = ar.get_user()

        if new_state in [cls.approved, cls.rejected]:
            obj.approval_date = dd.today()
            obj.approval_user = user
            if new_state == cls.approved:
                ProvisionStates = rt.models.storage.ProvisionStates
                receiver = obj.purchase_order.journal.ledger.company
                for item in obj.purchase_order.items.all():
                    my_pp = partner_price(user.ledger.company, item.product, ar)
                    cust_pp = partner_price(receiver, item.product, ar)

                    update_provision(item.product, receiver, my_pp, ProvisionStates.ordered_cust,
                                     item.qty, ar)

                    update_provision(item.product, None, my_pp, ProvisionStates.in_stock,
                                     -item.qty, ar)

                    update_provision(item.product, user.ledger.company, cust_pp,
                                     ProvisionStates.ordered_due, item.qty, ar)

        elif new_state == cls.pending:
            obj.approval_date = None
            obj.approval_user = None
            # obj.sales_invoice = None

            if old_state == cls.approved or (
                old_state == cls.completed and
                obj.sales_invoice.state != rt.models.accounting.VoucherStates.registered
            ):
                ProvisionStates = rt.models.storage.ProvisionStates
                receiver = obj.purchase_order.journal.ledger.company
                for item in obj.purchase_order.items.all():
                    my_pp = partner_price(user.ledger.company, item.product, ar)
                    cust_p = partner_price(receiver, item.product, ar)

                    update_provision(item.product, receiver, my_pp,
                                     ProvisionStates.ordered_cust, -item.qty, ar)
                    
                    update_provision(item.product, user.ledger.company, cust_p,
                                     ProvisionStates.ordered_due, -item.qty, ar)
                    
                    update_provision(item.product, None,  my_pp,
                                     ProvisionStates.in_stock, item.qty, ar)
        else:
            # Get or validate the sales journal
            if not obj.purchase_order.journal or not obj.purchase_order.journal.ledger:
                ar.error(_("Purchase order journal must have a ledger assigned."))
                return

            # Find corresponding sales journal (look for journal with same ledger and sales trade type)
            Journal = rt.models.accounting.Journal
            # TradeTypes = rt.models.accounting.TradeTypes
            user = ar.get_user()
            sales_journals = Journal.objects.filter(
                ledger=user.ledger,
                ref__endswith='SLS',
            )

            if not sales_journals.exists():
                ar.error(_("No sales journal found for ledger {0}.").format(user.ledger))
                return

            # Use first available sales journal
            sales_journal = sales_journals.get()

            sales_invoice = obj.sales_invoice

            if sales_invoice is None:
                # Create sales invoice
                sales_invoice = sales_journal.create_voucher(
                    partner=obj.purchase_order.journal.ledger.company,
                    user=user,
                    entry_date=dd.today()
                )

                sales_invoice.full_clean()
                sales_invoice.save_new_instance(
                    sales_invoice.get_default_table().create_request(parent=ar)
                )
            else:
                # Clear existing items
                sales_invoice.items.all().delete()
                sales_invoice.entry_date = dd.today()

            # Copy items from purchase order to sales invoice
            for po_item in obj.purchase_order.items.all():
                si_item = sales_invoice.add_voucher_item(
                    product=po_item.product,
                    qty=po_item.qty,
                    description=po_item.description,
                    discount_rate=po_item.discount_rate,
                    discount_amount=po_item.discount_amount,
                    unit_price=po_item.unit_price,
                )
                si_item.set_amount(ar, po_item.get_amount())
                si_item.full_clean()
                si_item.save()
            
            # Save sales invoice
            sales_invoice.full_clean()
            sales_invoice.save()

            obj.sales_invoice = sales_invoice
            obj.full_clean()
            obj.save()
            
            ar.goto_instance(sales_invoice)

        return super().before_state_change(obj, ar, old_state, new_state)

    @classmethod
    def after_state_change(cls, obj, ar, old_state, new_state):
        """Hook called after state transition."""        
        # Send notification to original requester
        users = rt.models.users.User.objects.filter(ledger=obj.purchase_order.journal.ledger)
        recipients = [(user, user.mail_mode) for user in users]

        actor = rt.models.trading.OutboundApprovals

        def msg_func(user):
            subject = _("Purchase order state set to {0}").format(new_state.text)

            params = {}
            if not user.has_usable_password():
                params[constants.URL_PARAM_SUBST_USER] = user.pk
            permalink = "{}{}".format(
                settings.SITE.server_url,
                ar.renderer.get_detail_url(ar, actor, obj.pk, **params),
            )
            obj_url = format_html('<a href="{}">{}</a>', permalink, str(obj.purchase_order))

            body = _("Your purchase order ({0})'s state has been set to {1}").format(obj_url, new_state.text)
            body = mark_safe("<p>{}</p>".format(body))
            return (subject, body)

        rt.models.notify.Message.emit_notification(
            ar, obj, MessageTypes.po_followup, msg_func, recipients
        )

        ar.set_response(refresh=True)



add = ApprovalStates.add_item
add('10', _("Pending"), 'pending')
add('20', _("Approved"), 'approved')
add('30', _("Rejected"), 'rejected')
add('40', _("Sales invoice created"), 'completed')

# Define workflow transitions
ApprovalStates.pending.add_transition(
    _("Pending"),
    button_text="⏳",
    # required_states='approved rejected completed',
    show_in_toolbar=True,
    readonly=True,  # Allows action to appear in toolbar even when table is not editable
    help_text=_("Approve this purchase order"),
    never_collapse=True,
)

ApprovalStates.approved.add_transition(
    _("Approve"),
    required_states='pending',
    button_text="✓",
    show_in_toolbar=True,
    readonly=True,  # Allows action to appear in toolbar even when table is not editable
    help_text=_("Approve this purchase order"),
    never_collapse=True,
)

ApprovalStates.rejected.add_transition(
    _("Reject"),
    required_states='pending',
    button_text="✗",
    show_in_toolbar=True,
    readonly=True,  # Allows action to appear in toolbar even when table is not editable
    help_text=_("Reject this approval"),
    never_collapse=True,
)

ApprovalStates.completed.add_transition(
    _("Create sales invoice"),
    required_states="approved",
    button_text="✓✓",
    show_in_toolbar=True,
    readonly=True,  # Allows action to appear in toolbar even when table is not editable
    help_text=_("Create a sales invoice and complete the approval"),
    never_collapse=True,
)


class VoucherApproval(dd.Model):
    """
    Manages approval workflow for purchase orders and creates linked sales invoices.
    
    When a partner creates a purchase order, they can designate another partner
    who needs to approve it. Upon approval, a sales invoice is automatically 
    created and linked to the original purchase order.
    """

    class Meta:
        app_label = 'trading'
        verbose_name = _("Voucher approval")
        verbose_name_plural = _("Voucher approvals")
        abstract = dd.is_abstract_model(__name__, "VoucherApproval")
        unique_together = [("purchase_order", ), ("sales_invoice", )]

    workflow_state_field = 'state'

    allow_cascaded_delete = ["purchase_order"]

    purchase_order = dd.ForeignKey(
        'trading.VatProductInvoice',
        verbose_name=_("Purchase order"),
        help_text=_("The purchase order requiring approval"),
        related_name='approval_requests'
    )

    sales_invoice = dd.ForeignKey(
        'trading.VatProductInvoice',
        blank=True,
        null=True,
        verbose_name=_("Sales invoice"),
        help_text=_("The sales invoice created upon approval"),
        related_name='approval_sources'
    )

    state = ApprovalStates.field(default=ApprovalStates.pending)

    request_date = models.DateField(
        _("Request date"),
        default=dd.today,
        help_text=_("Date when approval was requested")
    )

    approval_date = models.DateField(
        _("Approval date"),
        blank=True,
        null=True,
        help_text=_("Date when the request was approved or rejected")
    )

    approval_user = dd.ForeignKey(
        'users.User',
        blank=True,
        null=True,
        verbose_name=_("Approved by"),
        help_text=_("User who approved or rejected the request"),
        related_name='voucher_approvals_processed'
    )

    remarks = models.TextField(
        _("Remarks"),
        blank=True,
        help_text=_("Notes about the approval process")
    )

    def __str__(self):
        return _("Approval for {0} by {1}").format(
            self.purchase_order, self.purchase_order.partner
        )
    
    def after_ui_save(self, ar, cw):
        super().after_ui_save(ar, cw)
        # Make the partner familiar with the company if not already
        rt.models.contacts.make_familiar(
            ar,
            self.purchase_order.journal.ledger.company,
            self.purchase_order.partner.get_mti_child("company"),
        )


class VoucherApprovals(dd.Table):
    """Table showing all voucher approvals."""
    model = 'trading.VoucherApproval'
    required_roles = dd.login_required(SiteAdmin)
    column_names = "purchase_order_view purchase_order__partner state request_date approval_date sales_invoice *"
    order_by = ['-request_date']
    allow_create = False
    editable = False
    
    detail_layout = """
    purchase_order_view
    state request_date approval_date approval_user
    sales_invoice
    remarks
    """

    @classmethod
    def get_purchase_order_detail_link(cls, obj, ar, table):
        """Link to the related purchase order."""
        if obj.purchase_order_id:
            sar = table.create_request(parent=ar)
            return sar.row_action_button(
                obj.purchase_order,
                table.get_action_by_name("detail_action"),
                label=obj.purchase_order.as_str(sar),
            )
        return ""

    # @dd.displayfield(_("Purchase order"))
    # def outbound_purchase_order(cls, obj, ar):
    #     """Link to the related purchase order."""
    #     return cls.get_purchase_order_detail_link(
    #         obj, ar, rt.models.accounting.OutboundPurchaseOrders
    #     )

    # @dd.displayfield(_("Purchase order"))
    # def inbound_purchase_order(cls, obj, ar):
    #     """Link to the related purchase order."""
    #     return cls.get_purchase_order_detail_link(
    #         obj, ar, rt.models.accounting.InboundPurchaseOrders
    #     )
    
    @dd.displayfield(_("Purchase order"))
    def purchase_order_view(cls, obj, ar):
        """Link to the related purchase order."""
        if not obj.purchase_order_id:
            return ""
        if obj.purchase_order.journal.ledger == ar.get_user().ledger:
            return cls.get_purchase_order_detail_link(
                obj, ar, rt.models.accounting.OutboundPurchaseOrders
            )
        assert obj.purchase_order.partner.company == ar.get_user().ledger.company,\
            _("Purchase order must be linked to current user's ledger either via journal or partner")
        return cls.get_purchase_order_detail_link(
            obj, ar, rt.models.accounting.InboundPurchaseOrders
        )


class MyVoucherApprovals(VoucherApprovals):
    label = _("My voucher approvals")
    required_roles = dd.login_required(LedgerUser)

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        user = ar.get_user()
        if user.ledger is None:
            return cls.objects.none()
        qs = super().get_request_queryset(ar, **filter)
        qs = qs.filter(
            models.Q(purchase_order__partner=user.ledger.company)
            | models.Q(purchase_order__journal__ledger=user.ledger)
        )
        return qs


class PendingApprovals(VoucherApprovals):
    """Table showing pending approvals."""
    label = _("Pending approvals")
    # column_names = "purchase_order purchase_order__partner request_date *"
    _known_values = {
        'state__in': [ApprovalStates.pending, ApprovalStates.approved],
    }

    # @classmethod
    # def get_simple_parameters(cls):
    #     yield from super().get_simple_parameters()
    #     yield "state"
    #     # yield "state__in"

    # @classmethod
    # def param_defaults(cls, ar, **kw):
    #     kw = super().param_defaults(ar, **kw)
    #     # kw["state"] = ApprovalStates.pending
    #     # kw['state__in'] = [ApprovalStates.pending, ApprovalStates.approved]
    #     return kw


class InboundApprovals(MyVoucherApprovals):
    """Table showing inbound voucher approvals for current user's partners."""
    label = _("Inbound purchase orders")
    column_names = "purchase_order_view state request_date approval_date sales_invoice"
    required_roles = dd.login_required(LedgerUser, ProductsUser)

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        qs = super().get_request_queryset(ar, **filter)
        user = ar.get_user()
        return qs.filter(purchase_order__partner=user.ledger.company)


class InboundPendingApprovals(InboundApprovals, PendingApprovals):
    """Table showing approvals pending for current user's partners."""
    label = _("Inbound purchase orders (pending)")


class OutboundApprovals(MyVoucherApprovals):
    """Table showing outbound voucher approvals initiated by current user's ledger."""
    label = _("Outbound purchase orders")
    required_roles = dd.login_required(LedgerUser)

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        qs = super().get_request_queryset(ar, **filter)
        qs = qs.filter(purchase_order__journal__ledger=ar.get_user().ledger)
        return qs
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        # Disable all workflow transition actions for outbound approvals
        # Workflow actions are named from the ApprovalStates workflow
        for action in ApprovalStates.workflow_actions:
            dfs.add(action.action_name)
        return dfs


class OutboundPendingApprovals(OutboundApprovals, PendingApprovals):
    """Table showing approvals pending for current user's ledger."""
    label = _("Outbound purchase orders (pending)")


class VatProductInvoice(VatProductInvoice):
    """Extended VatProductInvoice with approval workflow for PO journals."""

    class Meta(VatProductInvoice.Meta):
        abstract = dd.is_abstract_model(__name__, "VatProductInvoice")

    def after_state_change(self, ar, old, new):
        """Hook called after state transition."""
        if self.journal_id is not None:

            receiver = self.partner.company
            is_fallback_partner = True
            if receiver is not None:
                is_fallback_partner = receiver.name == FALLBACK_PARTNER_NAME
            my_company = self.journal.ledger.company
            ProvisionStates = rt.models.storage.ProvisionStates

            if self.journal.ref.endswith("PO"):
                if is_fallback_partner:
                    if new == rt.models.accounting.VoucherStates.registered:
                        for item in self.items.all():
                            my_pp = partner_price(my_company, item.product, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, item.qty, ar)

                    elif old == rt.models.accounting.VoucherStates.registered:
                        for item in self.items.all():
                            my_pp = partner_price(my_company, item.product, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, -item.qty, ar)

            elif self.journal.ref.endswith("SLS"):
                approval = rt.models.trading.VoucherApproval.objects.filter(
                    sales_invoice=self
                ).first()

                if new == rt.models.accounting.VoucherStates.registered:
                    if approval:
                        assert not is_fallback_partner, \
                            _("Cannot register sales invoice linked to approval with fallback partner")
                        assert receiver is not None, \
                            _("Cannot register sales invoice to non-company partner linked to approval")
                        for item in approval.sales_invoice.items.all():
                            order_item = approval.purchase_order.items.filter(
                                product=item.product).first()

                            my_pp = partner_price(my_company, item.product, ar)
                            cust_pp = partner_price(receiver, item.product, ar)

                            if not order_item:
                                update_provision(item.product, None, my_pp,
                                                ProvisionStates.in_stock, -item.qty, ar)
                                update_provision(item.product, None, cust_pp,
                                                ProvisionStates.in_stock, item.qty, ar)
                                continue

                            update_provision(item.product, receiver, my_pp,
                                            ProvisionStates.ordered_cust, -order_item.qty, ar)
                            update_provision(item.product, None, cust_pp,
                                            ProvisionStates.in_stock, item.qty, ar)
                            update_provision(item.product, my_company, cust_pp,
                                            ProvisionStates.ordered_due, -order_item.qty, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, order_item.qty - item.qty, ar)

                    else:
                        for item in self.items.all():
                            my_pp = partner_price(my_company, item.product, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, -item.qty, ar)

                            if not is_fallback_partner and receiver is not None:
                                cust_pp = partner_price(receiver, item.product, ar)
                                update_provision(item.product, None, cust_pp,
                                                ProvisionStates.in_stock, item.qty, ar)
                elif old == rt.models.accounting.VoucherStates.registered:
                    if approval:
                        assert not is_fallback_partner, \
                            _("Cannot un-register sales invoice linked to approval with fallback partner")
                        assert receiver is not None, \
                            _("Cannot un-register sales invoice to non-company partner linked to approval")
                        for item in self.items.all():
                            order_item = approval.purchase_order.items.filter(
                                product=item.product).first()

                            my_pp = partner_price(my_company, item.product, ar)
                            cust_pp = partner_price(receiver, item.product, ar)

                            if not order_item:
                                update_provision(item.product, None, my_pp,
                                                ProvisionStates.in_stock, item.qty, ar)
                                update_provision(item.product, None, cust_pp,
                                                ProvisionStates.in_stock, -item.qty, ar)
                                continue

                            update_provision(item.product, receiver, my_pp,
                                            ProvisionStates.ordered_cust, order_item.qty, ar)
                            update_provision(item.product, None, cust_pp,
                                            ProvisionStates.in_stock, -item.qty, ar)
                            update_provision(item.product, my_company, cust_pp,
                                            ProvisionStates.ordered_due, order_item.qty, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, item.qty - order_item.qty, ar)
                    else:
                        for item in self.items.all():
                            my_pp = partner_price(my_company, item.product, ar)
                            update_provision(item.product, None, my_pp,
                                            ProvisionStates.in_stock, item.qty, ar)

                            if not is_fallback_partner and receiver is not None:
                                cust_pp = partner_price(receiver, item.product, ar)
                                update_provision(item.product, None, cust_pp,
                                                ProvisionStates.in_stock, -item.qty, ar)

        return super().after_state_change(ar, old, new)

    @dd.displayfield(_("Sent"))
    def approval_sent(self, ar):
        """Indicates whether this voucher has been sent for approval."""
        if self.pk is not None and self.approval_requests.exists():
            return "✅"  # "✓"
        return "✗"
    
    @dd.action(
        label=_("Send voucher"),
        help_text=_("Send this purchase order for approval"),
        show_in_workflow=True,
        icon_name='email_go',
        never_collapse=True,
    )
    def send_voucher(self, ar):
        """
        Sends the purchase order for approval by creating a VoucherApproval record.
        """
        # Check if this is a PO journal
        if not (self.journal and self.journal.ref and self.journal.ref.upper().endswith("PO")):
            ar.error(_("This action is only available for purchase order journals."))
            return
        
        # Check if partner is set
        if not self.partner:
            ar.error(_("Please specify a partner before sending the voucher."))
            return

        # Check if already sent
        if self.approval_requests.exists():
            ar.error(_("This voucher has already been sent for approval."))
            return

        rt.models.contacts.make_familiar(ar, self.partner)

        # Create the approval request
        approval = VoucherApproval(
            purchase_order=self,
            request_date=dd.today(),
            state=ApprovalStates.pending,
        )
        approval.full_clean()
        approval.save_new_instance(approval.get_default_table().create_request(parent=ar))

        # Send notification to approval partner
        User = rt.models.users.User
        users = User.objects.filter(ledger__company=self.partner)
        recipients = [(user, user.mail_mode) for user in users]

        def msg_func(user):
            subject = _("Purchase order requires your approval")
            cls = rt.models.trading.InboundPendingApprovals
            # detail_ba = cls.get_url_action("detail")
            # sar = ar.spawn_request(actor=cls, action=detail_ba)
            # sar.permalink_uris = True
            # permalink = sar.get_permalink(detail_ba, approval)
            params = {}
            if not user.has_usable_password():
                params[constants.URL_PARAM_SUBST_USER] = user.pk
            permalink = "{}{}".format(
                settings.SITE.server_url,
                ar.renderer.get_detail_url(ar, cls, approval.pk, **params)
            )
            # if permalink.startswith("/"):
            #     permalink = "{}/#{}".format(settings.SITE.server_url, permalink)
            po = format_html('<a href="{}">{}</a>', permalink, str(self))
            # po = sar.obj2htmls(approval, text=str(self))
            body = _("Purchase order {0} requires your approval").format(po)
            body = mark_safe("<p>{0}</p>".format(body))
            # body = _("Purchase order {0} requires your approval").format(self)
            return (subject, body)

        rt.models.notify.Message.emit_notification(
            ar, approval, MessageTypes.po_followup, msg_func, recipients
        )

        OutboundApprovals = rt.models.trading.OutboundApprovals
        sar = OutboundApprovals.create_request(parent=ar)
        js = sar.renderer.instance_handler(
            sar, approval, OutboundApprovals.get_action_by_name("detail_action"))
        # ar.goto_instance(approval)
        ar.set_response(eval_js=js)
        ar.set_response(refresh=True)
        ar.success(_("Voucher sent to {0} for approval.").format(self.partner))

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        if self.journal_id is None or not self.journal.ref.endswith("PO")\
            or not self.pk or self.approval_requests.exists():
            dfs.add("send_voucher")
        return dfs

    def get_trade_type(self):
        if self.journal and self.journal.ref.endswith("PO"):
            return rt.models.accounting.TradeTypes.purchases
        return super().get_trade_type()


class InvoiceItem(InvoiceItem):
    class Meta(InvoiceItem.Meta):
        abstract = dd.is_abstract_model(__name__, "InvoiceItem")

    # def get_amount(self):
    #     return rt.models.products.PartnerPrice.objects.get(
    #         product=self.get_invoiceable_product(),
    #         partner=self.get_invoiceable_partner(),
    #         trade_type=rt.models.accounting.TradeTypes.sales,
    #     ).price * self.get_invoiceable_qty()


invoices_original_queryset = Invoices.get_request_queryset


@classmethod
def get_request_queryset_invoices(cls, ar, **fltr):
    qs = invoices_original_queryset(ar, **fltr)
    user = ar.get_user()
    if user.is_anonymous or user.ledger is None:
        return qs.none()
    return qs.filter(
        models.Q(journal__ledger=user.ledger) | models.Q(partner=user.ledger.company)
    )


Invoices.get_request_queryset = get_request_queryset_invoices

# InvoicesByJournal.allow_create = False
InvoicesByJournal.allow_delete = False

class ItemsByInvoice(ItemsByInvoice):
    default_display_modes = {
        None: constants.DISPLAY_MODE_GRID,
        70: constants.DISPLAY_MODE_LIST,
    }

    @classmethod
    def row_as_paragraph(cls, ar, row):
        item = row
        return format_html(
            "<p><strong>{}</strong>:<br/>{} x {}</p><hr/>",
            item.product,
            item.qty,
            item.unit_price,
        )


def welcome_messages(ar):
    user = ar.get_user()
    if user.is_anonymous:
        return
    if user.ledger is None:
        return
    if user.user_type.has_required_roles([LedgerUser, ProductsUser]):
        if (req_count := rt.models.trading.VoucherApproval.objects.filter(
            models.Q(state=ApprovalStates.pending) | models.Q(state=ApprovalStates.approved),
            purchase_order__partner=user.ledger.company,
        ).count()) > 0:
            tbl = rt.models.trading.InboundPendingApprovals
            sar = tbl.create_request(parent=ar, action=tbl.get_action_by_name("grid"))
            yield mark_safe("<p><strong>⇒ </strong>")
            yield format_lazy(
                _("You have {req_count} pending voucher approvals. See: "),
                req_count=localize_number(req_count),
            )
            yield sar.ar2button(label=_("voucher approvals table"))
            yield "."
            yield mark_safe("</p>")

    if (qs := rt.models.products.PartnerPrice.objects.filter(
        partner__ledger=user.ledger,
        trade_type=rt.models.accounting.TradeTypes.sales,
        price=0,
    )).exists():
        tbl = rt.models.products.MyProducts
        ba = tbl.get_action_by_name("grid")
        sar = tbl.create_request(parent=ar, action=ba)
        yield mark_safe("<p><strong>⇒ </strong>")
        yield format_lazy(
            _("You have {pp_count} partner prices with price 0. See: "),
            pp_count=localize_number(qs.count()),
        )
        price_filter = [{
            "field": "price",
            "type": "numeric",
            "value": 0,
            "comparison": "exact",
        }]
        yield sar.renderer.window_action_button(
            sar,
            ba,
            status={"data": {constants.URL_PARAM_GRIDFILTER: price_filter}},
            label=_("partner prices with price 0"),
        )
        # yield sar.ar2button(label=_("partner prices table"))
        yield "."
        yield mark_safe("</p>")


dd.add_welcome_handler(welcome_messages)
