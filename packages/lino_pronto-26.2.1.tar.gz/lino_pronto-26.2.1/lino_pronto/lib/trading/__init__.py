# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino_xl.lib.trading import Plugin as BasePlugin


class Plugin(BasePlugin):
    """Shopping plugin for a :ref:`pronto` project. This
    inherits from :mod:`lino_xl.lib.trading`.
    """

    extends_models = ["InvoiceItem", "VatProductInvoice"]

    def get_quicklinks(self):
        return []
    
    def setup_config_menu(self, site, user_type, m, ar=None):
        ret = super().setup_config_menu(site, user_type, m, ar)
        mg = self
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("trading.InboundApprovals")
        return ret
    
    def setup_explorer_menu(self, site, user_type, m, ar=None):
        ret = super().setup_explorer_menu(site, user_type, m, ar)
        mg = self
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("trading.OutboundApprovals")
        return ret
