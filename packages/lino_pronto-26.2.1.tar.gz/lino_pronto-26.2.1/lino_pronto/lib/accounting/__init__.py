# -*- coding: UTF-8 -*-
# Copyright 2024-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""This is Lino pronto's standard plugin for General accounting.
Inherits from :mod:`lino_xl.lib.accounting` See :doc:`/plugins/accounting`.

Adds purchase order functionality via PurchaseOrdersByJournal.

"""

from lino_xl.lib.accounting import Plugin as BasePlugin


class Plugin(BasePlugin):
    """Pronto accounting plugin with purchase order support."""
    
    def setup_main_menu(self, site, user_type, m, ar=None):
        super().setup_main_menu(site, user_type, m, ar)
        # Purchase orders are added to the purchases menu by JournalGroups
        # configuration in setup_menu_spec()

    def setup_config_menu(self, site, user_type, m, ar=None):
        ret = super().setup_config_menu(site, user_type, m, ar)
        mg = self
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("accounting.InboundPurchaseOrders")
        return ret
    
    def setup_explorer_menu(self, site, user_type, m, ar=None):
        ret = super().setup_explorer_menu(site, user_type, m, ar)
        mg = self
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("accounting.OutboundPurchaseOrders")
        return ret
