# -*- coding: UTF-8 -*-
# Copyright 2024-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, rt, _
from lino.core.roles import SiteAdmin
from lino_xl.lib.accounting.models import *
from lino_xl.lib.accounting.ui import ByJournal, PartnerVouchers
from lino_xl.lib.accounting.choicelists import VoucherTypes
from lino_xl.lib.accounting.roles import LedgerUser
from lino_xl.lib.products.roles import ProductsUser


class PurchaseOrderDetail(dd.DetailLayout):
    """Detail layout for purchase orders."""
    
    main = "general more"

    general = dd.Panel("""
    general1 general2 general3
    trading.ItemsByInvoice
    """, label=_("General"))

    general1 = """
    approval_sent
    number partner
    entry_date accounting_period
    your_ref:20 vat_regime:20
    """

    general2 = """
    payment_term
    due_date
    """

    general3 = """
    workflow_buttons
    total_base
    total_vat
    total_incl
    """

    more = dd.Panel("""
    more1 more2
    vat.MovementsByVoucher
    """, label=_("More"))

    more1 = """
    journal user
    narration id
    """

    more2 = """
    uploads.UploadsByController:60
    """


class PurchaseOrders(PartnerVouchers):
    """Base table for purchase orders."""
    editable = False
    required_roles = dd.login_required(SiteAdmin)
    model = 'trading.VatProductInvoice'
    order_by = ["-id"]
    column_names = "entry_date id number_with_year partner total_incl user *"
    detail_layout = "accounting.PurchaseOrderDetail"
    insert_layout = """
    journal partner
    entry_date
    your_ref
    """

    @classmethod
    def get_request_queryset(cls, ar, **kw):
        qs = super().get_request_queryset(ar, **kw).annotate(
            # Placeholder for subclasses which filters by inbound_po
            inbound_po=models.Value(False, output_field=models.BooleanField()))
        
        user = ar.get_user()
        
        if user.is_anonymous or user.ledger is None:
            return qs.none()
        
        qs = qs.filter(journal__isnull=False, journal__ref__endswith="PO")
        qs = qs.annotate(
            inbound_po=models.Case(
                models.When(models.Q(models.Exists(
                    rt.models.trading.VoucherApproval.objects.filter(
                        purchase_order=models.OuterRef('pk'),
                    ))) & models.Q(partner=user.ledger.company), then=models.Value(True)
                ),
                default=models.Value(False),
                output_field=models.BooleanField()
            )
        ).filter(
            models.Q(journal__ledger=user.ledger) | models.Q(inbound_po=True)
        )
        return qs


class InboundPurchaseOrderDetail(PurchaseOrderDetail):
    """Detail layout for inbound purchase orders."""
    
    main = "general more"

    general = dd.Panel("""
    general1 general2 general3
    trading.ItemsByInvoice
    """, label=_("General"))

    general1 = """
    number
    partner
    entry_date
    accounting_period
    # your_ref
    vat_regime
    """

    general2 = """
    payment_term
    due_date
    user__ledger__company__overview
    """

    general3 = """
    workflow_buttons
    total_base
    total_vat
    total_incl
    """

    more = dd.Panel("""
    more1 more2
    vat.MovementsByVoucher
    """, label=_("More"))

    more1 = """
    journal user
    narration id
    """

    more2 = """
    uploads.UploadsByController:60
    """


class InboundPurchaseOrders(PurchaseOrders):
    """Table showing purchase orders sent to us by our customers.
    
    This uses VatAccountInvoice model but provides a separate
    voucher type for purchase orders, distinct from regular
    purchase invoices.
    """
    label = _("Inbound purchase orders")
    allow_create = False
    allow_delete = False
    required_roles = dd.login_required(LedgerUser, ProductsUser)
    detail_layout = "accounting.InboundPurchaseOrderDetail"
    # column_names = "number_with_year entry_date due_date "

    @classmethod
    def get_request_queryset(cls, ar, **kw):
        qs = super().get_request_queryset(ar, **kw)
        qs = qs.filter(inbound_po=True)
        return qs
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("toggle_state")
        dfs.add("check_data")
        dfs.add("show_problems")
        dfs.add("fix_problems")
        dfs.add("show_uploads")
        return dfs


class OutboundPurchaseOrders(PurchaseOrders):
    """Table showing purchase orders that we created an sent to our suppliers.
    
    This uses VatAccountInvoice model but provides a separate
    voucher type for purchase orders, distinct from regular
    purchase invoices.
    """
    editable = True
    label = _("Outbound purchase orders")
    required_roles = dd.login_required(LedgerUser)

    @classmethod
    def get_request_queryset(cls, ar, **kw):
        qs = super().get_request_queryset(ar, **kw)
        qs = qs.exclude(inbound_po=True)
        return qs
    

class PurchaseOrdersByJournal(ByJournal, OutboundPurchaseOrders):
    """Table showing purchase orders grouped by journal.
    
    This uses VatAccountInvoice model but provides a separate
    voucher type for purchase orders, distinct from regular
    purchase invoices.
    """
    label = _("Purchase orders")
    column_names = "number_with_year entry_date due_date " \
        "your_ref partner " \
        "total_incl " \
        "total_base total_vat user workflow_buttons *"
    insert_layout = """
    # partner
    entry_date
    your_ref
    """

    @classmethod
    def create_instance(self, ar, **kw):
        obj = super().create_instance(ar, **kw)
        fallback_partner = rt.models.contacts.Company.objects.get(
            name=dd.get_plugin_setting('contacts', 'fallback_partner_name'),
            association_type='supplier'
        )
        obj.partner = fallback_partner
        return obj
    
    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("partner")
        return dfs


# Register the voucher type
VoucherTypes.add_item_lazy(PurchaseOrdersByJournal)

Accounts.required_roles = dd.login_required(SiteAdmin)
Journals.required_roles = dd.login_required(SiteAdmin)
PaymentMethods.required_roles = dd.login_required(SiteAdmin)

original_journal_choices = Voucher.journal_choices


@dd.chooser()
def journal_choices(cls, ar):
    """To be used only with ByJournal abstract table."""
    qs = original_journal_choices.__func__(cls, ar)  # call raw function with explicit class
    Journal = rt.models.accounting.Journal
    if ar.master_instance is None:
        return qs
    assert isinstance(ar.master_instance, Journal), \
        _("This chooser should only be used with ByJournal abstract table.")
    user = ar.get_user()
    if user.is_anonymous or user.ledger is None:
        return qs.none()
    if not user.user_type.has_required_roles([dd.SiteStaff]):
        assert ar.master_instance.ledger == user.ledger,\
            _("Users can only see journals of their own ledger")
    return qs.filter(pk=ar.master_instance.pk)


Voucher.journal_choices = journal_choices
