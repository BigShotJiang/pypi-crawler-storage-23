# -*- coding: UTF-8 -*-
# Copyright 2013-2019 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
.. autosummary::
   :toctree:

    lib
    projects

"""

from .setup_info import SETUP_INFO

__version__ = "26.2.1"

intersphinx_urls = dict(docs="https://lino-framework.gitlab.io/pronto/")
srcref_url = 'https://gitlab.com/lino-framework/pronto/blob/master/%s'
doc_trees = ['docs']
