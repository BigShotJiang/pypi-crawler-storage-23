import datetime
from ..settings import *
# from .users_db import DBSETTINGS


class Site(Site):
    is_demo_site = True
    the_demo_date = datetime.date(2019, 1, 18)
    languages  = "en bn"
    default_ui = "lino_react.react"

    def get_plugin_configs(self):
        yield super().get_plugin_configs()
        # yield "notify", "use_sql_cte", False
        # yield "notify", "use_sql_cte", True


SITE = Site(globals())

DEBUG = True

ALLOWED_HOSTS = ['*']

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql',
#         'NAME': 'pronto',
#         'USER': 'pronto',
#         'PASSWORD': 'pronto',
#         'HOST': 'localhost',
#         'PORT': '5432',
#     }
# }

# DATABASES = DBSETTINGS
# DATABASE_ROUTERS = ['lino_pronto.utils.db_routes_and_settings.DBRouter']
