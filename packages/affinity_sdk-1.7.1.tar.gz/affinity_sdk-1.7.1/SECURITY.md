## Security policy

### Reporting a vulnerability

Please do not open a public issue.

Report vulnerabilities privately via GitHub Security Advisories:
`https://github.com/yaniv-golan/affinity-sdk/security/advisories/new`

We will respond as quickly as possible and coordinate a fix and disclosure.
