# Client

## `Affinity`

::: affinity.Affinity

## `AsyncAffinity`

::: affinity.AsyncAffinity
