# Lists

::: affinity.services.lists.ListService

::: affinity.services.lists.AsyncListService
