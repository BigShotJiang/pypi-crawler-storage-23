"""
Reporting module.

Handles rich CLI output and HTML report generation.
"""

from .models import SuiteResult

def generate_html_report(result: SuiteResult, output_path: str):
    # TODO: Implement HTML report generation
    pass

def print_suite_summary(result: SuiteResult):
    # TODO: Implement rich CLI summary
    pass
