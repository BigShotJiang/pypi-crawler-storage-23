"""ICDEV data -- GOTCHA layers (Goals, Context, Hardprompts, Args)."""
