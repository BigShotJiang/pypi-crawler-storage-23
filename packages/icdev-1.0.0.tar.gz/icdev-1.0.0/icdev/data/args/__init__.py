# Package marker for PyPI distribution
