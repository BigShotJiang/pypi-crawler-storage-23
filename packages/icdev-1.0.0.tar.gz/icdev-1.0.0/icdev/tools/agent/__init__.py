# [TEMPLATE: CUI // SP-CTI]
"""ICDEV Agent Execution Framework — subprocess-based Claude Code CLI invocation."""
