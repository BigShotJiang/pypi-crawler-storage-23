"""ICDEV -- Intelligent Certified Development Platform.

A system that builds systems. AI-powered meta-builder for generating
complete, autonomous, ATO-ready applications with 42 compliance framework
mappings, 15 coordinating AI agents, and the GOTCHA framework.

GOTCHA layers:
  G - Goals     (workflow definitions)
  O - Orchestration (AI agent layer)
  T - Tools     (deterministic Python scripts)
  C - Context   (reference material)
  H - Hardprompts (reusable LLM instruction templates)
  A - Args      (YAML/JSON behavior settings)
"""

from icdev._version import __version__

__all__ = ["__version__"]
