# -*- coding: utf-8 -*-
"""Feature Gate Service — v6.1: All features free, no gating."""

from typing import Optional
from mcp.types import TextContent


def require_error_tools(feature_name: str = "error") -> Optional[list[TextContent]]:
    """v6.1: Always returns None — no gating."""
    return None


def require_kb_access(project_path: str) -> Optional[list[TextContent]]:
    """v6.1: Always returns None."""
    return None


def append_free_nudge(
    result: list[TextContent], project_path: str, tool_name: str
) -> list[TextContent]:
    """v6.1: No-op."""
    return result
