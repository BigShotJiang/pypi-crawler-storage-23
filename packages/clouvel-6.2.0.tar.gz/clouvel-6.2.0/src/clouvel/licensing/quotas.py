# -*- coding: utf-8 -*-
"""Licensing Quotas Module

WARN count tracking, KB Trial management, Meeting quotas.
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

from .first_project import get_project_tier
from .validation import get_machine_id


# ============================================================
# WARN 횟수 추적 (v3.1: 전환율 개선)
# ============================================================

def _get_warn_count_path() -> Path:
    """Get warn count tracking file path: ~/.clouvel/warn_count.json"""
    if os.name == 'nt':
        base = Path(os.environ.get('USERPROFILE', '~'))
    else:
        base = Path.home()
    clouvel_dir = base / ".clouvel"
    clouvel_dir.mkdir(parents=True, exist_ok=True)
    return clouvel_dir / "warn_count.json"


def increment_warn_count(project_path: str) -> int:
    """Increment WARN count for a project and return new count."""
    path = _get_warn_count_path()
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, ValueError):
            data = {}

    normalized = str(Path(project_path).resolve())
    count = data.get(normalized, 0) + 1
    data[normalized] = count

    try:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass

    return count


def get_warn_count(project_path: str) -> int:
    """Get current WARN count for a project."""
    path = _get_warn_count_path()
    if not path.exists():
        return 0
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        normalized = str(Path(project_path).resolve())
        return data.get(normalized, 0)
    except (OSError, json.JSONDecodeError, ValueError):
        return 0


# ============================================================
# KB Trial 관리 (v3.1: 7일 체험)
# ============================================================

def _get_kb_trial_path() -> Path:
    """Get KB trial tracking file path: ~/.clouvel/kb_trial.json"""
    if os.name == 'nt':
        base = Path(os.environ.get('USERPROFILE', '~'))
    else:
        base = Path.home()
    clouvel_dir = base / ".clouvel"
    clouvel_dir.mkdir(parents=True, exist_ok=True)
    return clouvel_dir / "kb_trial.json"


def get_kb_trial_start(project_path: str) -> Optional[str]:
    """Get KB trial start date for a project. Returns ISO date string or None."""
    path = _get_kb_trial_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        normalized = str(Path(project_path).resolve())
        return data.get(normalized)
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def start_kb_trial(project_path: str) -> str:
    """Start KB trial for a project. Returns the start date."""
    path = _get_kb_trial_path()
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, ValueError):
            data = {}

    normalized = str(Path(project_path).resolve())
    # Don't overwrite existing trial
    if normalized in data:
        return data[normalized]

    start_date = datetime.now().isoformat()
    data[normalized] = start_date

    try:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass

    return start_date


def is_kb_trial_active(project_path: str) -> bool:
    """v6.0: Always True — KB access is free."""
    return True


# ============================================================
# 주간 풀 매니저 체험 (v3.1)
# ============================================================

def _get_weekly_meeting_path() -> Path:
    """Get weekly meeting tracking file path: ~/.clouvel/weekly_meeting.json"""
    if os.name == 'nt':
        base = Path(os.environ.get('USERPROFILE', '~'))
    else:
        base = Path.home()
    clouvel_dir = base / ".clouvel"
    clouvel_dir.mkdir(parents=True, exist_ok=True)
    return clouvel_dir / "weekly_meeting.json"


def can_use_weekly_full_meeting(project_path: str) -> Dict[str, Any]:
    """Check if user can use weekly full meeting trial.

    Returns dict with:
    - available: bool
    - last_used_week: str (ISO week, e.g. "2026-W05")
    - current_week: str
    """
    path = _get_weekly_meeting_path()
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, ValueError):
            data = {}

    normalized = str(Path(project_path).resolve())
    now = datetime.now()
    current_week = f"{now.isocalendar()[0]}-W{now.isocalendar()[1]:02d}"

    last_used_week = data.get(normalized)

    return {
        "available": last_used_week != current_week,
        "last_used_week": last_used_week,
        "current_week": current_week,
    }


def mark_weekly_meeting_used(project_path: str) -> None:
    """Mark weekly full meeting as used for this week."""
    path = _get_weekly_meeting_path()
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, ValueError):
            data = {}

    normalized = str(Path(project_path).resolve())
    now = datetime.now()
    current_week = f"{now.isocalendar()[0]}-W{now.isocalendar()[1]:02d}"
    data[normalized] = current_week

    try:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


# ============================================================
# Monthly Meeting Quota (v3.3: 월 3회 Full Meeting 체험)
# ============================================================

FREE_MONTHLY_MEETINGS = 3


def _get_quota_exhausted_message() -> str:
    """Get the quota exhausted message (shared by server and local paths)."""
    return f"""
\U0001f3af \uc774\ubc88 \ub2ec \ubb34\ub8cc Meeting {FREE_MONTHLY_MEETINGS}\ud68c\ub97c \ubaa8\ub450 \uc0ac\uc6a9\ud588\uc2b5\ub2c8\ub2e4!

8\uba85 C-level \ub9e4\ub2c8\uc800\uc758 \ud53c\ub4dc\ubc31\uc774 \ub3c4\uc6c0\uc774 \ub418\uc168\ub098\uc694?

Clouvel v6.0\uc5d0\uc11c\ub294 \ubaa8\ub4e0 \uae30\ub2a5\uc774 \ubb34\ub8cc\uc785\ub2c8\ub2e4!
"""


def _get_monthly_meeting_path() -> Path:
    """Get monthly meeting quota tracking file path: ~/.clouvel/monthly_meeting.json"""
    if os.name == 'nt':
        base = Path(os.environ.get('USERPROFILE', '~'))
    else:
        base = Path.home()
    clouvel_dir = base / ".clouvel"
    clouvel_dir.mkdir(parents=True, exist_ok=True)
    return clouvel_dir / "monthly_meeting.json"


def check_meeting_quota(project_path: str = None) -> Dict[str, Any]:
    """v6.0: Always allowed — unlimited meetings."""
    return {
        "allowed": True,
        "used": 0,
        "remaining": 999,
        "limit": 999,
        "current_month": datetime.now().strftime("%Y-%m"),
    }


def consume_meeting_quota(project_path: str = None) -> Dict[str, Any]:
    """v6.0: No-op — unlimited meetings."""
    return {"used": 0, "remaining": 999}


def _mirror_meeting_to_local(server_result: dict) -> None:
    """Mirror server meeting state to local file."""
    path = _get_monthly_meeting_path()
    current_month = datetime.now().strftime("%Y-%m")
    data = {"month": current_month, "used": server_result.get("used", 0)}
    try:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass
