# -*- coding: utf-8 -*-
"""English messages for Clouvel"""

# Document type names
DOC_NAMES = {
    "prd": "PRD",
    "architecture": "Architecture",
    "api_spec": "API Spec",
    "db_schema": "DB Schema",
    "verification": "Verification Plan",
}

# can_code messages
CAN_CODE_BLOCK_NO_DOCS = """⛔ BLOCK | No docs folder: {path}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Why blocked? PRD-first prevents 2+ hours of rework.

  🚀 Quick Fix (copy & run):

  Option 1: Create PRD template
  → start(path=".", init=True)

  Option 2: Minimal PRD (fastest)
  → start(path=".", template="minimal")

  Option 3: Full PRD with guide
  → start(path=".", guide=True)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

After creating PRD, fill in:
1. ## Summary - What are you building?
2. ## Acceptance Criteria - When is it done?

Then run can_code again to proceed.
"""

CAN_CODE_BLOCK_MISSING_DOCS = """⛔ BLOCK | Missing: {missing_items}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Found: {detected_list}
  Missing (required): {missing_list}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 Quick Fix:

1. If PRD exists but missing Acceptance Criteria:
   Add this section to your PRD:

   ## Acceptance Criteria
   - [ ] User can...
   - [ ] System should...
   - [ ] Test: ...

2. If no PRD at all:
   → start(path=".", template="minimal")

Then run can_code again to proceed.
"""

CAN_CODE_PASS_WITH_WARN = """✅ PASS | ⚠️ WARN {warn_count} | Required: {found_docs} ✓{test_info} | Missing recommended: {warn_summary}

## PRD Table of Contents
{prd_toc}

## Rules for This Session
- Build ONLY what is listed in the PRD sections above
- Read the relevant PRD section BEFORE implementing each feature
- Do NOT implement features not in the PRD
- Do NOT modify PRD without explicit user approval
{prd_rule}"""

CAN_CODE_PASS = """✅ PASS | Required: {found_docs} ✓{test_info} | Ready to code

## PRD Table of Contents
{prd_toc}

## Rules for This Session
- Build ONLY what is listed in the PRD sections above
- Read the relevant PRD section BEFORE implementing each feature
- Do NOT implement features not in the PRD
- Do NOT modify PRD without explicit user approval
{prd_rule}"""

# v6.0: Welcome message (all features free)
FIRST_PROJECT_WELCOME = """
Welcome to Clouvel! All features are included:
- 8 C-Level managers (PM, CTO, QA, CSO, CDO, CMO, CFO, ERROR)
- Code blocking (prevents coding without proper spec)
- Knowledge Base (context persists across sessions)
- Error Learning (never repeat the same mistake)
- Unlimited meetings and projects
"""

FIRST_PROJECT_ADDITIONAL_BLOCKED = ""

# v6.0: No project limit
CAN_CODE_PROJECT_LIMIT = ""

CAN_CODE_WARN_NO_DOCS_FREE = """WARN | No docs folder: {path} | Recommended: start(path=".")

PRD-first is recommended.
Why spec first? 10 min spec -> 2 hours saved (no rework)
"""

CAN_CODE_WARN_NO_PRD_FREE = """WARN | No PRD found | Recommended: start(path=".")

PRD-first is recommended.
Why spec first? 10 min spec -> 2 hours saved (no rework)
"""

CAN_CODE_PASS_FREE = """PASS | PRD exists | {test_count} tests | Ready to code

## PRD Table of Contents
{prd_toc}

## Rules for This Session
- Build ONLY what is listed in the PRD sections above
- Read the relevant PRD section BEFORE implementing each feature
- Do NOT implement features not in the PRD
- Do NOT modify PRD without explicit user approval
"""

CAN_CODE_WARN_ACCUMULATED = """
---
PRD warnings accumulated: {count} time(s).

Create docs/PRD.md: `start(path, guide=True)`
"""

# v6.0: Legacy messages kept as empty strings for backward compatibility
CAN_CODE_KB_TRIAL_EXPIRED = ""
CAN_CODE_TRIAL_ACTIVE = ""
CAN_CODE_TRIAL_EXPIRED = ""
CAN_CODE_TRIAL_NUDGE_5 = ""
CAN_CODE_TRIAL_NUDGE_7 = ""

PRD_RULE_WARNING = "\n\n⚠️ PRD Edit Rule: Do NOT modify PRD without explicit user request. If changes are needed, first propose (1) why changes are needed (2) benefits of improvement (3) specific changes, then proceed after approval."

# Test related
TEST_COUNT = "{count} tests"
NO_TESTS = "No Tests (⚠️ write tests before marking complete)"

# PRD section
PRD_SECTION_PREFIX = "PRD {section} section"

# scan_docs messages
SCAN_PATH_NOT_FOUND = "Path not found: {path}"
SCAN_NOT_DIRECTORY = "Not a directory: {path}"
SCAN_RESULT = "📁 {path}\nTotal {count} files\n\n"

# analyze_docs messages
ANALYZE_PATH_NOT_FOUND = "Path not found: {path}"
ANALYZE_RESULT_HEADER = "## Analysis Result: {path}\n\nCoverage: {coverage:.0%}\n\n"
ANALYZE_FOUND_HEADER = "### Found\n"
ANALYZE_MISSING_HEADER = "### Missing (Need to write)\n"
ANALYZE_COMPLETE = "✅ All required docs present. Ready for vibe coding.\n"
ANALYZE_INCOMPLETE = "⛔ Write {count} documents first, then start coding.\n"

# init_docs messages
INIT_RESULT_HEADER = "## docs folder initialized\n\nPath: `{path}`\n\n"
INIT_CREATED_HEADER = "### Created files\n"
INIT_ALREADY_EXISTS = "All files already exist.\n\n"
INIT_NEXT_STEPS = "### Next steps\n1. Start with PRD.md\n2. Use `get_prd_guide` tool for writing guidelines\n"

# Template contents
TEMPLATE_PRD = """# {project_name} PRD

> Created: {date}

## Summary

[TODO]

## Acceptance Criteria

- [ ] [Acceptance criterion 1]
- [ ] [Acceptance criterion 2]
- [ ] [Acceptance criterion 3]
"""

TEMPLATE_ARCHITECTURE = """# {project_name} Architecture

## System Structure

[TODO]
"""

TEMPLATE_API = """# {project_name} API Spec

## Endpoints

[TODO]
"""

TEMPLATE_DATABASE = """# {project_name} DB Schema

## Tables

[TODO]
"""

TEMPLATE_VERIFICATION = """# {project_name} Verification Plan

## Test Cases

[TODO]
"""
