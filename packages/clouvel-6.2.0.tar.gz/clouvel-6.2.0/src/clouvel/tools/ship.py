# -*- coding: utf-8 -*-
"""
Clouvel Ship Tool

One-click test, verify, and evidence generation tool.

v6.0: All features free. No trial/license validation required.
v3.1: Runtime entitlement checks (no import-time constants).
v3.2: project_path based detection for MCP compatibility.
"""

from typing import Dict, Any, List

from ..api_client import call_ship_api
from ..utils.entitlements import is_developer


def _trial_exhausted_response() -> Dict[str, Any]:
    """Legacy stub - v6.0: all features are free, this should never be reached."""
    return {
        "error": None,
        "message": "Clouvel v6.0 — All features are free.",
        "formatted_output": "All features are available without limits."
    }


def ship(
    path: str,
    feature: str = "",
    steps: List[str] = None,
    generate_evidence: bool = True,
    auto_fix: bool = False
) -> Dict[str, Any]:
    """
    One-click test, verification, and evidence generation.

    - lint: Code style check
    - typecheck: Type check
    - test: Run tests
    - build: Build verification
    """
    # Dev mode bypass (runtime check with project_path, not import-time)
    if is_developer(path):
        try:
            from .ship_pro import ship as ship_impl
            return ship_impl(
                path=path,
                feature=feature,
                steps=steps,
                generate_evidence=generate_evidence,
                auto_fix=auto_fix
            )
        except ImportError:
            pass

    # Check permission via API
    api_result = call_ship_api(path=path, feature=feature)

    if not api_result.get("allowed", False):
        if api_result.get("error") == "trial_exhausted":
            return _trial_exhausted_response()
        return {
            "error": api_result.get("error", "Not allowed"),
            "message": api_result.get("message", "Ship not available"),
            "formatted_output": f"Error: {api_result.get('message', 'Ship not available')}"
        }

    # Run ship locally
    try:
        from .ship_pro import ship as ship_impl
        result = ship_impl(
            path=path,
            feature=feature,
            steps=steps,
            generate_evidence=generate_evidence,
            auto_fix=auto_fix
        )

        return result

    except ImportError:
        return {
            "error": "Implementation not found",
            "message": "ship_pro.py module not found. Ensure the ship implementation is installed.",
            "formatted_output": """
==================================================
SHIP MODULE NOT FOUND
==================================================

The **ship** tool requires the ship implementation module.

Please ensure ship_pro.py is installed correctly.

==================================================
"""
        }


def quick_ship(path: str, feature: str = "") -> Dict[str, Any]:
    """Quick lint and test execution only."""
    return ship(path=path, feature=feature, steps=["lint", "test"])


def full_ship(path: str, feature: str = "") -> Dict[str, Any]:
    """All verification steps + auto_fix."""
    return ship(path=path, feature=feature, steps=["lint", "typecheck", "test", "build"], auto_fix=True)
