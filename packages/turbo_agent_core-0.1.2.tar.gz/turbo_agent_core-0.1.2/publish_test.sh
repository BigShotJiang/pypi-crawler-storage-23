export UV_PUBLISH_TOKEN=
rm -rf dist
uv build ./
uv publish --publish-url https://test.pypi.org/legacy/
