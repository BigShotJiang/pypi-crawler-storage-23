# coding=utf-8
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from turbo_agent_core.schema.events import BaseEvent


class BaseEventBroker(ABC):
    """事件流（Broker）抽象接口。

    说明：目前主要用于"事件写入/旁路监控/消费归档"链路。
    读侧（订阅/ACK/消费者组）在 Redis Stream 场景下有额外语义，
    因此实现会在具体 broker 中扩展。
    """

    @abstractmethod
    async def publish(self, stream: str, event: BaseEvent) -> Optional[str]:
        """发布一个事件到指定 stream。

        返回值：
        - Redis Stream：返回 message_id
        - Memory Queue：返回 None 或内部 id
        """

    @abstractmethod
    async def healthcheck(self) -> bool:
        """检查 broker 是否可用。"""
