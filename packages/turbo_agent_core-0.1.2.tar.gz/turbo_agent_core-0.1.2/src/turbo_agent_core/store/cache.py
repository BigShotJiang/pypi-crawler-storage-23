from abc import ABC, abstractmethod
from typing import Optional, Any

class BaseCacheStore(ABC):
    """Abstract base class for caching."""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        pass

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        pass

    @abstractmethod
    async def delete(self, key: str) -> None:
        pass
