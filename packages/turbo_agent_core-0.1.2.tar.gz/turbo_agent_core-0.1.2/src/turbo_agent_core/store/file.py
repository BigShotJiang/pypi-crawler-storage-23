from abc import ABC, abstractmethod
from typing import Optional, AsyncGenerator

class BaseFileStore(ABC):
    """Abstract base class for file storage."""
    
    @abstractmethod
    async def save_file(self, path: str, content: bytes) -> str:
        """Save file and return file hash/ID."""
        pass

    @abstractmethod
    async def get_file(self, path: str) -> Optional[bytes]:
        pass
        
    @abstractmethod
    async def get_file_stream(self, path: str) -> AsyncGenerator[bytes, None]:
        pass
