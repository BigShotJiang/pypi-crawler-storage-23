# coding=utf-8
from abc import ABC, abstractmethod
from typing import Optional, Any, TypeVar, Generic

from turbo_agent_core.schema.basic import TurboEntity

T = TypeVar("T", bound=TurboEntity)

class BaseAssembler(ABC, Generic[T]):
    """
    数据组装器抽象基类。
    负责将底层存储模型（如 Prisma ORM 对象）转换为 Core Pydantic 实体。
    """

    def __init__(self, client: Any):
        """
        初始化组装器。
        
        Args:
            client: 数据库客户端实例 (如 Prisma Client)
        """
        self.client = client

    @abstractmethod
    async def assemble(self, entity_id: str, version: Optional[str] = None) -> Optional[T]:
        """
        根据 ID 组装 Core 实体。
        
        Args:
            entity_id: 实体 ID
            version: 可选的版本标识
            
        Returns:
            组装好的 Core 实体，如果不存在则返回 None
        """
        pass
