"""
Core 模块存储抽象层

提供各类存储的抽象接口，包括：
- TurboEntityStore: TurboEntity 继承类（Agent, Character, Tool, LLMModel）的配置存储
  资源定位方式：belongToProjectId + name_id
- JobStore: 任务作业类（Job, JobTask, TaskSpec）的配置存储
- ResourceEntityStore: 资源类（Project, KnowledgeResource, Workset, BusinessSetting, Secret, ModelInstance）的配置存储
- StateStore: 状态类（Conversation, Message, Action, ReActRound, ToolCallRecord, JobTaskState）的配置存储
- ExternalStore: 外部服务类（Platform, AuthMethod, McpServerSpec, McpResourceDescriptor）的配置存储
- ResourceStore: KnowledgeResource 文件存储抽象
- ResourceInfo: 资源文件信息数据类
"""

# 配置存储抽象（按 schema 分类）
from .entity import TurboEntityStore
from .job import JobStore
from .resource import ResourceEntityStore
from .state import StateStore
from .external import ExternalStore

# 其他存储抽象
from .file import BaseFileStore
from .execution import BaseExecutionStore
from .cache import BaseCacheStore
from .broker import BaseEventBroker
from .assembler import BaseAssembler
from .monitor import BaseRuntimeMonitor
from .resource import ResourceStore, ResourceInfo
from .workspace import WorkspaceStore, FileInfo, CommitInfo, TagInfo

__all__ = [
    # 配置存储抽象（按 schema 分类）
    "TurboEntityStore",
    "JobStore", 
    "ResourceEntityStore",
    "StateStore",
    "ExternalStore",
    # 其他存储抽象
    "BaseFileStore",
    "BaseExecutionStore",
    "BaseCacheStore",
    "BaseEventBroker",
    "BaseAssembler",
    "BaseRuntimeMonitor",
    "ResourceStore",
    "ResourceInfo",
    "WorkspaceStore",
    "FileInfo",
    "CommitInfo",
    "TagInfo",
]
