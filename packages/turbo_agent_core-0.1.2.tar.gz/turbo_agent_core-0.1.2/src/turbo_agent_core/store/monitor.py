from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, TypeVar, Callable, Awaitable
from dataclasses import dataclass

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent, UserInfo
from turbo_agent_core.utils.aggregators import EventTreeAggregator


T = TypeVar("T")


@dataclass
class _PendingWrite:
    stream: str
    event_json: str


class BaseRuntimeMonitor(ABC):
    """Runtime 监控器基类。"""
    
    @abstractmethod
    def start(self) -> None: ...
    
    @abstractmethod
    async def close(self) -> None: ...
    
    @abstractmethod
    def write(self, event: BaseEvent) -> None: ...
