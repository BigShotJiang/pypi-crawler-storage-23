1. configure ecotax (see module account_ecotax).

2. configure a product with ecotax classification and add it to new invoice.
This action automatically creates eco-tax lines

3. Go the menu Accounting/reporting/management/Ecotax line Analysis and Analyse ecotax.
