This module adds reporting fields to the eco-tax line object and
the menu to acces tree & pivot view to facilitate the eco-tax declaration.
