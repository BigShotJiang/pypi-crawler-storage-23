"""Protocol and decorator for interactive inspector backends.

Inspector backends enable warm/hot inspectors that maintain session state.
Unlike static inspectors (which just render data), backends can:
- Load models and maintain GPU memory across requests
- Process inference requests in real-time
- Handle bidirectional communication with the browser UI

Usage:
    @inspector_backend
    class CrossSectionBackend:
        '''Interactive cross-section visualization backend.'''

        async def initialize(self, ctx: InspectorContext) -> None:
            '''Load model and artifacts when session starts.'''
            self.model = load_model(ctx.artifacts['checkpoint'])
            self.data = ctx.artifacts['dataset']

        async def handle_message(self, msg: dict) -> dict:
            '''Process requests from browser UI.'''
            if msg['type'] == 'slice':
                result = self.model.slice(msg['params'])
                return {'type': 'slice_result', 'data': result}
            return {'error': 'unknown message type'}

        async def cleanup(self) -> None:
            '''Release resources when session ends.'''
            del self.model
            torch.cuda.empty_cache()

Note: This defines the protocol only. Runtime support for executing backends
will be added in a future version. Users can write backends now and they
will work when daemon support is added.
"""

from dataclasses import dataclass
from typing import Any, Protocol, TypeVar, runtime_checkable

T = TypeVar("T", bound=type)


@dataclass
class InspectorContext:
    """Context provided to inspector backends during initialization.

    Contains references to artifacts and configuration needed by the backend.
    The daemon populates this before calling initialize().
    """

    # Artifact references by name -> storage_ref
    artifacts: dict[str, str]

    # Inspector configuration from manifest.json
    config: dict[str, Any]

    # Run metadata
    run_id: str
    node_id: str | None = None

    # Workspace path (for loading additional files if needed)
    workspace_path: str | None = None


@runtime_checkable
class InspectorBackendProtocol(Protocol):
    """Protocol for interactive inspector backends (warm/hot inspectors).

    Backends implementing this protocol can maintain state across requests,
    enabling scenarios like:
    - Keeping ML models loaded in GPU memory
    - Processing real-time inference requests
    - Interactive parameter exploration

    Lifecycle:
    1. initialize() - Called when session starts. Load artifacts, models, etc.
    2. handle_message() - Called for each message from browser. Return response.
    3. cleanup() - Called when session ends. Release resources.

    The daemon manages the backend lifecycle, including:
    - Spawning backend processes (subprocess or in-process)
    - Routing WebSocket messages to handle_message()
    - Calling cleanup() on disconnect/timeout
    """

    async def initialize(self, ctx: InspectorContext) -> None:
        """Called when inspector session starts.

        Use this to:
        - Load artifacts from ctx.artifacts
        - Initialize models (e.g., load weights to GPU)
        - Set up any persistent state

        Args:
            ctx: Context with artifact references and configuration.
        """
        ...

    async def handle_message(self, msg: dict[str, Any]) -> dict[str, Any]:
        """Handle a message from the browser frontend.

        Messages come from the inspector UI via the postMessage bridge.
        Return a response dict that will be sent back to the UI.

        Args:
            msg: Message dict from the browser. Format is inspector-specific.

        Returns:
            Response dict to send back to browser.
        """
        ...

    async def cleanup(self) -> None:
        """Called when inspector session ends.

        Use this to:
        - Release GPU memory
        - Close file handles
        - Clean up any resources

        Called on:
        - User closes inspector
        - WebSocket disconnect
        - Session timeout
        """
        ...


def inspector_backend(cls: T) -> T:
    """Decorator to mark a class as an inspector backend.

    Backends are discovered by the daemon's discovery system alongside
    blocks and handlers. They are instantiated when a user opens an
    inspector that requires a backend.

    Usage:
        @inspector_backend
        class MyBackend:
            async def initialize(self, ctx: InspectorContext) -> None:
                ...

            async def handle_message(self, msg: dict) -> dict:
                ...

            async def cleanup(self) -> None:
                ...

    The decorated class must implement the InspectorBackendProtocol:
    - initialize(ctx) - Setup when session starts
    - handle_message(msg) - Handle browser messages
    - cleanup() - Teardown when session ends
    """
    cls.__athena_inspector_backend__ = True  # type: ignore[attr-defined]
    return cls


def get_inspector_backend_marker(cls: type) -> bool:
    """Check if a class is marked as an inspector backend.

    Args:
        cls: Class to check.

    Returns:
        True if the class has the inspector_backend decorator.
    """
    return getattr(cls, "__athena_inspector_backend__", False)


def is_inspector_backend(obj: Any) -> bool:
    """Check if an object implements the InspectorBackendProtocol.

    This uses runtime_checkable to verify the object has the required methods.

    Args:
        obj: Object to check.

    Returns:
        True if object implements InspectorBackendProtocol.
    """
    return isinstance(obj, InspectorBackendProtocol)
