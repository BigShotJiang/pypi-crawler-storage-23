"""Handler decorator for storage backend resolution.

Handlers resolve storage_ref URIs (e.g., s3://, gs://) to artifact data streams.
They are discovered from workspace/handlers/ directory and used by the daemon's
inspector server to fetch artifacts from various storage backends.

Usage:
    @handler(schemes=["s3", "s3a"])
    async def s3_handler(storage_ref: str, env: dict[str, str]) -> AsyncIterator[bytes]:
        '''Fetch artifact data from S3.'''
        # Parse storage_ref (e.g., "s3://bucket/key")
        # Use credentials from env (e.g., AWS_ACCESS_KEY_ID)
        # Yield chunks of data
        ...

The handler function must:
- Be an async generator that yields bytes
- Accept storage_ref (str) and env (dict) parameters
- Handle its own authentication using credentials from env
"""

import functools
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass
from typing import Any, TypeVar

F = TypeVar("F", bound=Callable[..., AsyncIterator[bytes]])


@dataclass(frozen=True)
class HandlerSpec:
    """Specification for a storage handler."""

    name: str
    schemes: list[str]
    description: str | None = None


def handler(
    schemes: list[str],
    name: str | None = None,
    description: str | None = None,
) -> Callable[[F], F]:
    """Decorator to define a storage handler.

    Args:
        schemes: List of URI schemes this handler supports (e.g., ["s3", "s3a"]).
        name: Handler name (defaults to function name).
        description: Handler description (defaults to function docstring).

    Example:
        @handler(schemes=["s3"])
        async def s3_fetch(storage_ref: str, env: dict[str, str]) -> AsyncIterator[bytes]:
            '''Fetch artifact data from S3.'''
            import aioboto3
            # ... implementation
            yield chunk
    """

    def decorator(func: F) -> F:
        handler_name = name or func.__name__
        handler_description = description or func.__doc__

        spec = HandlerSpec(
            name=handler_name,
            schemes=schemes,
            description=handler_description,
        )

        # Attach spec to function
        func.__athena_handler__ = spec  # type: ignore[attr-defined]

        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> AsyncIterator[bytes]:
            async for chunk in func(*args, **kwargs):
                yield chunk

        # Copy attribute to wrapper
        wrapper.__athena_handler__ = spec  # type: ignore[attr-defined]

        return wrapper  # type: ignore[return-value]

    return decorator


def get_handler_spec(func: Callable[..., Any]) -> HandlerSpec | None:
    """Get the handler spec from a decorated function."""
    return getattr(func, "__athena_handler__", None)
