"""Block execution context for the Athena SDK."""

from __future__ import annotations

import hashlib
import logging
import os
import re
from pathlib import Path
from typing import Any
from uuid import UUID

import httpx

from athena.output_handle import OutputHandle
from athena.types import ArtifactRef

logger = logging.getLogger(__name__)

# Characters allowed in event_name: alphanumeric, slash, underscore, dot, hyphen.
# Anything else (e.g. spaces) is replaced with underscores.
_EVENT_NAME_RE = re.compile(r"[^a-zA-Z0-9/_.\-]")

# Environment variable for Block API URL (set by daemon when running blocks)
ATHENA_BLOCK_API_ENV = "ATHENA_BLOCK_API"


class _InputsProxy(dict[str, Any]):
    """Dict proxy that transparently unwraps OutputHandles on access.

    When a block does `ctx.inputs["name"]`, this returns the raw Python
    object instead of the OutputHandle wrapper. Internal code that needs
    the raw OutputHandles should access `_raw_inputs` directly.
    """

    def __getitem__(self, key: str) -> Any:
        value = super().__getitem__(key)
        if isinstance(value, OutputHandle) and value.has_data:
            return value.get_data()
        return value

    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        try:
            return self[key]
        except KeyError:
            return default


class ArtifactManager:
    """Manager for artifact operations."""

    def __init__(self, context: BlockContext) -> None:
        self._context = context
        self._block_api_client = context._block_api_client
        self._block_api_url = context._block_api_url

    async def register(
        self,
        local_path: str | Path,
        schema_type: str,
        name: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        input_artifacts: list[ArtifactRef] | None = None,
    ) -> ArtifactRef:
        """Register a local file as an artifact."""
        path = Path(local_path)
        if not path.exists():
            raise FileNotFoundError(f"Artifact file not found: {path}")

        # Calculate content hash
        content_hash = self._calculate_hash(path)

        # Get file info
        size_bytes = path.stat().st_size
        artifact_name = name or path.name

        # Build storage_ref URI - use file:// for absolute paths
        abs_path = str(path.absolute())
        storage_ref = f"file://{abs_path}"

        payload = {
            "name": artifact_name,
            "content_hash": content_hash,
            "schema_type": schema_type,
            "size_bytes": size_bytes,
            "tags": tags or [],
            "metadata": metadata or {},
            "input_artifact_ids": [str(ref.artifact_id) for ref in (input_artifacts or [])],
            "storage_ref": storage_ref,
            "run_id": str(self._context.run_id) if self._context.run_id else None,
            "step_id": self._context.step_id,
        }
        response = await self._block_api_client.post(
            f"{self._block_api_url}/api/artifacts", json=payload
        )

        response.raise_for_status()
        data = response.json()

        artifact_ref = ArtifactRef(
            artifact_id=UUID(data["id"]),
            schema_type=schema_type,
            name=artifact_name,
        )

        # Emit artifact_written event
        await self._context.emit_event(
            "artifact_written",
            f"artifact/{_EVENT_NAME_RE.sub('_', artifact_name)}",
            {
                "artifact_id": str(artifact_ref.artifact_id),
                "schema_type": schema_type,
                "tags": tags or [],
            },
        )

        return artifact_ref

    def _calculate_hash(self, path: Path) -> str:
        """Calculate SHA256 hash of a file."""
        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()


class BlockContext:
    """Context provided to blocks during execution.

    Inputs are OutputHandles that may contain in-memory data for fast access
    between blocks in the same run.

    Access inputs via ctx.inputs["name"] (transparently unwraps OutputHandles).
    Access secrets via ctx.secrets["KEY"] (resolved by daemon at runtime).
    """

    def __init__(
        self,
        run_id: UUID | None = None,
        step_id: str | None = None,
        lab_id: UUID | None = None,
        inputs: dict[str, OutputHandle[Any]] | None = None,
        config: dict[str, Any] | None = None,
        secrets: dict[str, str] | None = None,
    ) -> None:
        self.run_id = run_id
        self.step_id = step_id
        self.lab_id = lab_id
        # _raw_inputs preserves OutputHandles for internal use (lineage tracking)
        self._raw_inputs: dict[str, Any] = inputs or {}
        # inputs transparently unwraps OutputHandles so blocks see raw values
        self.inputs: _InputsProxy = _InputsProxy(self._raw_inputs)
        self.config = config or {}
        self.secrets: dict[str, str] = secrets or {}

        # Configure error handling for event emission
        # Set ATHENA_FAIL_ON_EVENT_ERROR=true to fail blocks when event emission fails
        self._fail_on_event_error = (
            os.environ.get("ATHENA_FAIL_ON_EVENT_ERROR", "").lower() == "true"
        )

        # Block API is required - blocks must run through the daemon
        self._block_api_url = os.environ.get(ATHENA_BLOCK_API_ENV)
        if not self._block_api_url:
            raise RuntimeError(
                f"Block API URL not configured. Set {ATHENA_BLOCK_API_ENV} environment variable. "
                "Blocks must run through the daemon (athena sync)."
            )
        self._block_api_client = httpx.AsyncClient(timeout=30.0)
        logger.debug("Using Block API at %s", self._block_api_url)

        # Artifact manager
        self.artifacts = ArtifactManager(self)

    async def emit_metric(
        self,
        name: str,
        value: float,
        epoch: int | None = None,
        step: int | None = None,
        **labels: Any,
    ) -> None:
        """Emit a metric event."""
        payload = {
            "value": value,
            "epoch": epoch,
            "step": step,
            "labels": labels,
        }
        await self.emit_event("metric", name, payload)

    async def emit_progress(
        self,
        current: int,
        total: int,
        message: str | None = None,
    ) -> None:
        """Emit a progress event."""
        payload = {
            "current": current,
            "total": total,
            "message": message,
        }
        await self.emit_event("progress", None, payload)

    async def emit_event(
        self,
        event_type: str,
        event_name: str | None,
        payload: dict[str, Any],
    ) -> None:
        """Emit a generic event (buffered via Block API)."""
        # Sanitize event_name (replace spaces etc. with underscores)
        if event_name is not None:
            event_name = _EVENT_NAME_RE.sub("_", event_name)
        event_data = {
            "run_id": str(self.run_id) if self.run_id else None,
            "node_id": self.step_id,
            "event_type": event_type,
            "event_name": event_name,
            "payload": payload,
        }

        try:
            response = await self._block_api_client.post(
                f"{self._block_api_url}/api/events", json=event_data
            )
            response.raise_for_status()
        except httpx.HTTPError as e:
            logger.warning("Failed to emit event: %s", e)
            if self._fail_on_event_error:
                raise

    async def check_pause(self) -> bool:
        """Check if the run should be paused or this node is held (cooperative pause point).

        When the run is paused or the node is held, the Block API holds the
        response open until the run resumes / node is released, so this call
        blocks during pause. Returns True if the run is paused or the node is
        held, False otherwise.
        """
        if not self.run_id:
            return False

        try:
            url = f"{self._block_api_url}/api/runs/{self.run_id}/status"
            if self.step_id:
                url += f"?node_id={self.step_id}"
            response = await self._block_api_client.get(
                url,
                timeout=httpx.Timeout(timeout=None),  # Block API controls the wait
            )
            response.raise_for_status()
            data = response.json()
            return data.get("status") == "paused" or data.get("node_held", False)
        except httpx.HTTPError:
            return False

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._block_api_client.aclose()

    async def __aenter__(self) -> BlockContext:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
