"""In-memory storage backend for testing."""

from pathlib import Path


class MemoryStorageBackend:
    """In-memory storage backend.

    Useful for testing without filesystem access.
    All data is lost when the process exits.
    """

    def __init__(self) -> None:
        """Initialize in-memory storage."""
        self._store: dict[str, bytes] = {}

    @property
    def provider_name(self) -> str:
        """Name of this storage provider."""
        return "memory"

    async def put(self, key: str, data: bytes) -> str:
        """Store data under the given key."""
        self._store[key] = data
        return f"memory://{key}"

    async def put_file(self, key: str, file_path: Path) -> str:
        """Store a file under the given key."""
        data = file_path.read_bytes()
        return await self.put(key, data)

    async def get(self, key: str) -> bytes:
        """Retrieve data for the given key."""
        if key not in self._store:
            raise KeyError(f"Key not found: {key}")
        return self._store[key]

    async def get_to_file(self, key: str, file_path: Path) -> None:
        """Retrieve data and write to file."""
        data = await self.get(key)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(data)

    async def exists(self, key: str) -> bool:
        """Check if a key exists in storage."""
        return key in self._store

    async def delete(self, key: str) -> bool:
        """Delete data for the given key."""
        if key not in self._store:
            return False
        del self._store[key]
        return True

    async def get_url(self, key: str, expires_in: int = 3600) -> str:  # noqa: ARG002
        """Get a memory:// URL for the key."""
        return f"memory://{key}"

    def clear(self) -> None:
        """Clear all stored data."""
        self._store.clear()

    def size(self) -> int:
        """Get number of stored items."""
        return len(self._store)

    def total_bytes(self) -> int:
        """Get total bytes stored."""
        return sum(len(v) for v in self._store.values())
