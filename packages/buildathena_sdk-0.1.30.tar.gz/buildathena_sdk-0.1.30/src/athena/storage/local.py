"""Local filesystem storage backend."""

import asyncio
import hashlib
import shutil
from pathlib import Path

import aiofiles
import aiofiles.os


class LocalStorageBackend:
    """Local filesystem storage backend.

    Stores artifacts in a content-addressed directory structure:
    base_path/
      ab/cd/  # First 4 chars of hash as directories
        abcd1234...  # Full hash as filename
    """

    def __init__(self, base_path: Path | str) -> None:
        """Initialize local storage.

        Args:
            base_path: Root directory for artifact storage
        """
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    @property
    def provider_name(self) -> str:
        """Name of this storage provider."""
        return "local"

    def _key_to_path(self, key: str) -> Path:
        """Convert storage key to filesystem path.

        Uses first 4 characters as directory sharding to avoid
        too many files in a single directory.
        """
        # Clean key of any path separators
        clean_key = key.replace("/", "_").replace("\\", "_")

        # Shard by first 2+2 characters
        if len(clean_key) >= 4:
            return self.base_path / clean_key[:2] / clean_key[2:4] / clean_key
        return self.base_path / clean_key

    async def put(self, key: str, data: bytes) -> str:
        """Store data under the given key."""
        path = self._key_to_path(key)
        path.parent.mkdir(parents=True, exist_ok=True)

        async with aiofiles.open(path, "wb") as f:
            await f.write(data)

        return str(path)

    async def put_file(self, key: str, file_path: Path) -> str:
        """Store a file under the given key."""
        dest = self._key_to_path(key)
        dest.parent.mkdir(parents=True, exist_ok=True)

        # Use shutil for efficient file copy
        # Run in thread pool to not block event loop
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, shutil.copy2, file_path, dest)

        return str(dest)

    async def get(self, key: str) -> bytes:
        """Retrieve data for the given key."""
        path = self._key_to_path(key)

        if not path.exists():
            raise KeyError(f"Key not found: {key}")

        async with aiofiles.open(path, "rb") as f:
            return await f.read()

    async def get_to_file(self, key: str, file_path: Path) -> None:
        """Retrieve data and write to file."""
        src = self._key_to_path(key)

        if not src.exists():
            raise KeyError(f"Key not found: {key}")

        file_path.parent.mkdir(parents=True, exist_ok=True)

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, shutil.copy2, src, file_path)

    async def exists(self, key: str) -> bool:
        """Check if a key exists in storage."""
        path = self._key_to_path(key)
        return path.exists()

    async def delete(self, key: str) -> bool:
        """Delete data for the given key."""
        path = self._key_to_path(key)

        if not path.exists():
            return False

        await aiofiles.os.remove(path)
        return True

    async def get_url(self, key: str, expires_in: int = 3600) -> str:  # noqa: ARG002
        """Get a file:// URL for accessing the data."""
        path = self._key_to_path(key)
        return f"file://{path.absolute()}"


def compute_content_hash(data: bytes) -> str:
    """Compute SHA-256 content hash for data."""
    return hashlib.sha256(data).hexdigest()


async def compute_file_hash(file_path: Path) -> str:
    """Compute SHA-256 content hash for a file."""
    sha = hashlib.sha256()

    async with aiofiles.open(file_path, "rb") as f:
        while chunk := await f.read(8192):
            sha.update(chunk)

    return sha.hexdigest()
