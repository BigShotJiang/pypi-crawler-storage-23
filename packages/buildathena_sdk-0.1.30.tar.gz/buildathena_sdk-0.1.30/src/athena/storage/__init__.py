"""Storage backend protocol and implementations.

This module provides artifact storage capabilities for blocks.
The harness uses these backends to materialize OutputHandles before
sending references back to the daemon.

Storage backends:
- LocalStorageBackend: Content-addressed local filesystem storage
- MemoryStorageBackend: In-memory storage for testing
"""

from athena.storage.local import LocalStorageBackend, compute_content_hash, compute_file_hash
from athena.storage.memory import MemoryStorageBackend
from athena.storage.protocol import StorageBackend

__all__ = [
    "StorageBackend",
    "LocalStorageBackend",
    "MemoryStorageBackend",
    "compute_content_hash",
    "compute_file_hash",
]
