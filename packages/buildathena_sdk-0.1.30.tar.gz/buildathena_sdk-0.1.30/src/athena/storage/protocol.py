"""Storage backend protocol.

This protocol defines the interface for artifact storage backends.
Implementations are provided in this module; the protocol is shared
so that SDK components can reference it.
"""

from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class StorageBackend(Protocol):
    """Protocol for artifact storage backends.

    Storage backends handle the actual bytes of artifacts.
    The server stores metadata; backends store data.
    """

    async def put(self, key: str, data: bytes) -> str:
        """Store data under the given key.

        Args:
            key: Storage key (content hash or path)
            data: Raw bytes to store

        Returns:
            Full storage path/URI for retrieval
        """
        ...

    async def put_file(self, key: str, file_path: Path) -> str:
        """Store a file under the given key.

        More efficient for large files than put() with read bytes.

        Args:
            key: Storage key (content hash or path)
            file_path: Path to file to store

        Returns:
            Full storage path/URI for retrieval
        """
        ...

    async def get(self, key: str) -> bytes:
        """Retrieve data for the given key.

        Args:
            key: Storage key

        Returns:
            Raw bytes

        Raises:
            KeyError: If key not found
        """
        ...

    async def get_to_file(self, key: str, file_path: Path) -> None:
        """Retrieve data and write to file.

        More efficient for large files than get() + write.

        Args:
            key: Storage key
            file_path: Path to write data to

        Raises:
            KeyError: If key not found
        """
        ...

    async def exists(self, key: str) -> bool:
        """Check if a key exists in storage.

        Args:
            key: Storage key

        Returns:
            True if exists
        """
        ...

    async def delete(self, key: str) -> bool:
        """Delete data for the given key.

        Args:
            key: Storage key

        Returns:
            True if deleted, False if not found
        """
        ...

    async def get_url(self, key: str, expires_in: int = 3600) -> str:
        """Get a URL for accessing the data.

        For local storage, returns file:// URL.
        For cloud storage, returns signed URL.

        Args:
            key: Storage key
            expires_in: URL validity in seconds (for signed URLs)

        Returns:
            Access URL
        """
        ...

    @property
    def provider_name(self) -> str:
        """Name of this storage provider (e.g., 'local', 's3', 'gcs')."""
        ...
