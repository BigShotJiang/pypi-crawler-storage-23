"""Workspace scanner for discovering blocks and handlers.

This module provides the WorkspaceScanner class which scans a workspace
directory for Python files containing @block and @handler decorators.
"""

import ast
import importlib.util
import logging
import sys
import traceback as tb_module
from pathlib import Path
from typing import Any

from athena.decorators import get_block_spec
from athena.discovery.schemas import (
    BlockRegistry,
    DiscoveredBlock,
    DiscoveredHandler,
    InputSpec,
    OutputSpec,
)
from athena.handler import get_handler_spec

logger = logging.getLogger(__name__)

# Directories to skip during scanning
SKIP_DIRS = frozenset(
    {
        ".venv",
        "venv",
        ".git",
        "__pycache__",
        ".athena",
        "node_modules",
        ".tox",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "build",
        "dist",
        "*.egg-info",
    }
)


class DecoratorDetector(ast.NodeVisitor):
    """AST visitor that detects @block and @handler decorators."""

    def __init__(self) -> None:
        self.decorated_functions: list[tuple[str, str]] = []  # (func_name, decorator_type)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_decorators(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_decorators(node)
        self.generic_visit(node)

    def _check_decorators(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        """Check if a function has @block or @handler decorators."""
        for decorator in node.decorator_list:
            decorator_name = self._get_decorator_name(decorator)
            if decorator_name in ("block", "handler"):
                self.decorated_functions.append((node.name, decorator_name))

    def _get_decorator_name(self, decorator: ast.expr) -> str | None:
        """Extract the base name from a decorator expression."""
        if isinstance(decorator, ast.Name):
            return decorator.id
        elif isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Name):
                return decorator.func.id
            elif isinstance(decorator.func, ast.Attribute):
                return decorator.func.attr
        elif isinstance(decorator, ast.Attribute):
            return decorator.attr
        return None


def _quick_detect_decorators(
    file_path: Path,
) -> tuple[list[tuple[str, str]], list[dict[str, str]]]:
    """Quickly detect decorated functions using AST parsing.

    Returns a tuple of (decorated_functions, errors) where:
        - decorated_functions is a list of (function_name, decorator_type) tuples
        - errors is a list of {"file": str, "error": str} dicts for any parse failures
    """
    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(file_path))
        detector = DecoratorDetector()
        detector.visit(tree)
        return detector.decorated_functions, []
    except (SyntaxError, UnicodeDecodeError) as e:
        logger.debug(f"Could not parse {file_path}: {e}")
        return [], [{"file": str(file_path), "error": str(e)}]


def _load_module_from_path(
    file_path: Path, module_name: str
) -> tuple[Any | None, str | None, str | None]:
    """Dynamically load a Python module from a file path.

    Returns:
        Tuple of (module, error_string, traceback_string).
        On success error_string and traceback_string are None.
        On failure module is None, error_string contains the exception message,
        and traceback_string contains the full traceback.
    """
    try:
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        if spec is None or spec.loader is None:
            return None, "Could not create module spec", None

        module = importlib.util.module_from_spec(spec)
        # Use a unique module name to avoid conflicts
        sys.modules[module_name] = module

        try:
            spec.loader.exec_module(module)
            return module, None, None
        finally:
            # Clean up sys.modules to avoid side effects
            sys.modules.pop(module_name, None)

    except Exception as e:
        logger.warning(f"Could not load module from {file_path}: {e}")
        return None, str(e), tb_module.format_exc()


def _should_skip_dir(dir_name: str) -> bool:
    """Check if a directory should be skipped during scanning."""
    if dir_name.startswith("."):
        return True
    if dir_name.endswith(".egg-info"):
        return True
    return dir_name in SKIP_DIRS


class WorkspaceScanner:
    """Scanner for discovering blocks and handlers in a workspace."""

    def __init__(
        self,
        workspace_path: Path,
        scan_paths: list[str] | None = None,
    ) -> None:
        """Initialize the scanner.

        Args:
            workspace_path: Path to the workspace root directory.
            scan_paths: Optional list of paths relative to workspace to scan.
                        If None, scans the entire workspace.
        """
        self.workspace_path = workspace_path.resolve()
        self.scan_paths = scan_paths

    def scan(self) -> BlockRegistry:
        """Scan the workspace for blocks and handlers.

        Returns:
            BlockRegistry containing all discovered blocks and handlers.
        """
        blocks: list[DiscoveredBlock] = []
        handlers: list[DiscoveredHandler] = []
        scan_errors: list[dict[str, Any]] = []

        # Find all Python files
        python_files = self._find_python_files()

        for file_path in python_files:
            # Quick AST check first
            decorated, parse_errors = _quick_detect_decorators(file_path)
            for err in parse_errors:
                # Convert absolute path to relative for consistency
                try:
                    rel = Path(err["file"]).relative_to(self.workspace_path)
                    err["file"] = str(rel)
                except ValueError:
                    pass
                scan_errors.append(err)
            if not decorated:
                continue

            # We have decorated functions, do the full import
            relative_path = file_path.relative_to(self.workspace_path)
            module_name = f"__athena_scan_{hash(str(file_path))}"

            module, load_error, load_traceback = _load_module_from_path(file_path, module_name)
            if module is None:
                err_entry: dict[str, Any] = {
                    "file": str(relative_path),
                    "functions": [name for name, _ in decorated],
                    "error": load_error or "unknown import failure",
                }
                if load_traceback:
                    err_entry["traceback"] = load_traceback
                scan_errors.append(err_entry)
                continue

            for func_name, decorator_type in decorated:
                func = getattr(module, func_name, None)
                if func is None:
                    scan_errors.append(
                        {
                            "file": str(relative_path),
                            "error": (
                                f"Function '{func_name}' detected by AST but not "
                                f"accessible after import (conditional definition or __all__ filtering?)"
                            ),
                        }
                    )
                    continue

                if decorator_type == "block":
                    block = self._extract_block(func, relative_path, func_name)
                    if block:
                        blocks.append(block)

                elif decorator_type == "handler":
                    handler = self._extract_handler(func, relative_path, func_name)
                    if handler:
                        handlers.append(handler)

        # Check for duplicate block names (#3)
        seen_names: dict[str, str] = {}  # name -> first file_path
        for block in blocks:
            if block.name in seen_names:
                scan_errors.append(
                    {
                        "file": block.file_path,
                        "error": (
                            f"Duplicate block name '{block.name}': also defined in "
                            f"'{seen_names[block.name]}'. Each block must have a unique name."
                        ),
                    }
                )
            else:
                seen_names[block.name] = block.file_path

        return BlockRegistry(
            language="python",
            workspace=str(self.workspace_path),
            blocks=blocks,
            handlers=handlers,
            scan_errors=scan_errors,
        )

    def _find_python_files(self) -> list[Path]:
        """Find all Python files in the workspace, skipping excluded directories.

        If scan_paths is configured, only scans those paths relative to workspace.
        Otherwise, scans the entire workspace.
        """
        python_files: list[Path] = []

        def _walk(path: Path) -> None:
            try:
                entries = list(path.iterdir())
            except PermissionError:
                return

            for entry in entries:
                if entry.is_dir():
                    if not _should_skip_dir(entry.name):
                        _walk(entry)
                elif entry.is_file() and entry.suffix == ".py":
                    python_files.append(entry)

        if self.scan_paths:
            # Scan only configured paths
            for scan_path in self.scan_paths:
                target = self.workspace_path / scan_path
                if target.exists():
                    if target.is_dir():
                        _walk(target)
                    elif target.is_file() and target.suffix == ".py":
                        python_files.append(target)
                else:
                    logger.debug(f"Scan path does not exist: {target}")
        else:
            # Scan entire workspace (default behavior)
            _walk(self.workspace_path)

        return python_files

    def _extract_block(self, func: Any, file_path: Path, func_name: str) -> DiscoveredBlock | None:
        """Extract block information from a decorated function."""
        spec = get_block_spec(func)
        if spec is None:
            return None

        inputs = [
            InputSpec(name=inp.name, type=inp.type, required=inp.required) for inp in spec.inputs
        ]
        outputs = [OutputSpec(name=out.name, type=out.type) for out in spec.outputs]

        return DiscoveredBlock(
            name=spec.name,
            file_path=str(file_path),
            function_name=func_name,
            inputs=inputs,
            outputs=outputs,
            config_schema=spec.config_schema,
            config_path=spec.config_path,
            secrets=spec.secrets,
            description=spec.description,
        )

    def _extract_handler(
        self, func: Any, file_path: Path, func_name: str
    ) -> DiscoveredHandler | None:
        """Extract handler information from a decorated function."""
        spec = get_handler_spec(func)
        if spec is None:
            return None

        return DiscoveredHandler(
            name=spec.name,
            schemes=spec.schemes,
            file_path=str(file_path),
            function_name=func_name,
            description=spec.description,
        )


def scan_workspace(
    workspace_path: str | Path,
    scan_paths: list[str] | None = None,
) -> BlockRegistry:
    """Convenience function to scan a workspace.

    Args:
        workspace_path: Path to the workspace root.
        scan_paths: Optional list of paths relative to workspace to scan.
                    If None, scans the entire workspace (backward compatible).

    Returns:
        BlockRegistry with all discovered blocks.
    """
    path = Path(workspace_path) if isinstance(workspace_path, str) else workspace_path
    scanner = WorkspaceScanner(path, scan_paths=scan_paths)
    return scanner.scan()
