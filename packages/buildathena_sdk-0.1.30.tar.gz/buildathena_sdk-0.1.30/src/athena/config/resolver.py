"""Reference resolution for config values.

This module provides resolution of `${...}` style references in config values:

- `${path.to.value}` - Reference to another config value
- `${env:VAR}` - Environment variable
- `${env:VAR:default}` - Environment variable with default

Usage:
    from athena.config.resolver import resolve_references

    config = {
        "shared": {"latent_dim": 64},
        "model": {"latent_dim": "${shared.latent_dim}"}
    }
    resolved = resolve_references(config)
    # resolved["model"]["latent_dim"] == 64
"""

from __future__ import annotations

import os
import re
from typing import Any


class ReferenceError(Exception):
    """Error raised when reference resolution fails."""

    pass


# Pattern for ${...} references
REFERENCE_PATTERN = re.compile(r"\$\{([^}]+)\}")

# Delete sentinel - when a value equals this, remove the key
DELETE_SENTINEL = "___"


def resolve_references(config: dict[str, Any]) -> dict[str, Any]:
    """Resolve all ${...} references in a config dict.

    This function:
    1. Builds a dependency graph of references
    2. Detects circular references
    3. Resolves references in topological order
    4. Returns a new dict with all references resolved

    Args:
        config: Config dict with ${...} reference strings.

    Returns:
        New dict with all references resolved to their values.

    Raises:
        ReferenceError: If a reference is invalid or circular.
    """
    # Build dependency graph
    graph = _build_reference_graph(config)

    # Topological sort to get resolution order
    order = _topological_sort(graph)

    # Resolve in order
    result = _deep_copy(config)
    for path in order:
        _resolve_path(result, path)

    return result


def _build_reference_graph(config: dict[str, Any]) -> dict[str, set[str]]:
    """Build a dependency graph of config paths that contain references.

    Returns:
        Dict mapping path -> set of paths it references.
    """
    graph: dict[str, set[str]] = {}
    _scan_references(config, "", graph)
    return graph


def _scan_references(
    obj: Any,
    current_path: str,
    graph: dict[str, set[str]],
) -> None:
    """Recursively scan for references and build graph."""
    if isinstance(obj, str):
        # Check if string contains any references
        if REFERENCE_PATTERN.search(obj):
            refs = _extract_references(obj)
            # Add to graph even if no path refs (for env-only refs)
            # Empty set means no dependencies, but still needs resolution
            graph[current_path] = refs
    elif isinstance(obj, dict):
        for key, value in obj.items():
            child_path = f"{current_path}.{key}" if current_path else key
            _scan_references(value, child_path, graph)
    elif isinstance(obj, list):
        for i, value in enumerate(obj):
            child_path = f"{current_path}[{i}]"
            _scan_references(value, child_path, graph)


def _extract_references(s: str) -> set[str]:
    """Extract all ${path.to.value} references from a string.

    Skips special references like ${env:...}.
    """
    refs = set()
    for match in REFERENCE_PATTERN.finditer(s):
        ref_content = match.group(1)
        # Skip special references (env:, etc.) - add only path references
        if ":" not in ref_content and not ref_content.startswith("env:"):
            refs.add(ref_content)
    return refs


def _topological_sort(graph: dict[str, set[str]]) -> list[str]:
    """Topological sort of paths based on their dependencies.

    Args:
        graph: Dict mapping path -> set of paths it depends on.

    Returns:
        List of paths in resolution order (dependencies first).

    Raises:
        ReferenceError: If circular dependency detected.
    """
    # Kahn's algorithm
    # First, collect all nodes (paths that have or are referenced)
    all_nodes = set(graph.keys())
    for deps in graph.values():
        all_nodes.update(deps)

    # Calculate in-degree for each node
    in_degree: dict[str, int] = dict.fromkeys(all_nodes, 0)
    for path, deps in graph.items():
        for dep in deps:
            if dep in in_degree:
                # dep must be resolved before path (so path depends on dep)
                pass  # We count edges TO the path
        in_degree[path] = len(deps)

    # Actually, we need reverse edges: if A references B, B must come before A
    reverse_graph: dict[str, set[str]] = {node: set() for node in all_nodes}
    for path, deps in graph.items():
        for dep in deps:
            if dep in reverse_graph:
                reverse_graph[dep].add(path)

    # Recalculate in-degree based on what references each node
    in_degree = dict.fromkeys(all_nodes, 0)
    for path, deps in graph.items():
        for dep in deps:
            if dep in all_nodes:
                pass  # path depends on dep
        # in_degree[path] = number of dependencies path has
        in_degree[path] = len([d for d in deps if d in all_nodes])

    # Start with nodes that have no dependencies
    queue = [node for node in all_nodes if in_degree[node] == 0]
    result = []

    while queue:
        node = queue.pop(0)
        result.append(node)

        # For each node that depends on this one
        for dependent in reverse_graph.get(node, set()):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # Only include paths that actually have references to resolve
    result = [p for p in result if p in graph]

    if len(result) != len(graph):
        # Some nodes not processed - circular dependency
        remaining = set(graph.keys()) - set(result)
        raise ReferenceError(f"Circular reference detected involving: {remaining}")

    return result


def _resolve_path(
    result: dict[str, Any],
    path: str,
) -> None:
    """Resolve references at a specific path in the result dict."""
    # Get the value at this path
    value = _get_by_path(result, path)

    if isinstance(value, str):
        # Resolve the string
        resolved = _resolve_string(value, result)
        _set_by_path(result, path, resolved)


def _resolve_string(s: str, config: dict[str, Any]) -> Any:
    """Resolve all ${...} references in a string.

    If the entire string is a single reference, returns the referenced value
    (preserving its type). Otherwise, performs string interpolation.
    """
    # Check if entire string is a single reference
    match = REFERENCE_PATTERN.fullmatch(s)
    if match:
        ref_content = match.group(1)
        return _resolve_single_reference(ref_content, config)

    # Multiple references or mixed content - string interpolation
    def replace(m: re.Match[str]) -> str:
        ref_content = m.group(1)
        value = _resolve_single_reference(ref_content, config)
        return str(value) if value is not None else m.group(0)

    return REFERENCE_PATTERN.sub(replace, s)


def _resolve_single_reference(ref: str, config: dict[str, Any]) -> Any:
    """Resolve a single reference (content inside ${...})."""
    # Handle env: references
    if ref.startswith("env:"):
        return _resolve_env_reference(ref[4:])

    # Path reference
    try:
        return _get_by_path(config, ref)
    except KeyError:
        raise ReferenceError(f"Reference not found: ${{{ref}}}")


def _resolve_env_reference(ref: str) -> str:
    """Resolve an environment variable reference.

    Format: VAR or VAR:default
    """
    if ":" in ref:
        var_name, default = ref.split(":", 1)
        return os.environ.get(var_name, default)
    else:
        value = os.environ.get(ref)
        if value is None:
            raise ReferenceError(f"Environment variable not set: {ref}")
        return value


def _get_by_path(obj: Any, path: str) -> Any:
    """Get a value from a nested dict/list by dot-notation path.

    Supports:
    - dict keys: "a.b.c"
    - list indices: "a[0].b"
    """
    if not path:
        return obj

    parts = _parse_path(path)
    current = obj

    for part in parts:
        if isinstance(part, int):
            # List index
            if not isinstance(current, list):
                raise KeyError(f"Expected list at index {part}, got {type(current)}")
            if part < 0 or part >= len(current):
                raise KeyError(f"Index {part} out of range")
            current = current[part]
        else:
            # Dict key
            if not isinstance(current, dict):
                raise KeyError(f"Expected dict for key '{part}', got {type(current)}")
            if part not in current:
                raise KeyError(f"Key not found: {part}")
            current = current[part]

    return current


def _set_by_path(obj: dict[str, Any], path: str, value: Any) -> None:
    """Set a value in a nested dict/list by dot-notation path."""
    parts = _parse_path(path)

    if not parts:
        return

    current: Any = obj
    for part in parts[:-1]:
        current = current[part]

    last_part = parts[-1]
    if isinstance(last_part, int):
        current[last_part] = value
    else:
        current[last_part] = value


def _parse_path(path: str) -> list[str | int]:
    """Parse a dot-notation path into parts.

    "a.b[0].c" -> ["a", "b", 0, "c"]
    """
    parts: list[str | int] = []
    current = ""

    i = 0
    while i < len(path):
        char = path[i]

        if char == ".":
            if current:
                parts.append(current)
                current = ""
        elif char == "[":
            if current:
                parts.append(current)
                current = ""
            # Find closing bracket
            j = path.index("]", i + 1)
            index_str = path[i + 1 : j]
            parts.append(int(index_str))
            i = j
        else:
            current += char

        i += 1

    if current:
        parts.append(current)

    return parts


def _deep_copy(obj: Any) -> Any:
    """Deep copy a config structure (dict/list/primitives only)."""
    if isinstance(obj, dict):
        return {k: _deep_copy(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_deep_copy(v) for v in obj]
    else:
        return obj
