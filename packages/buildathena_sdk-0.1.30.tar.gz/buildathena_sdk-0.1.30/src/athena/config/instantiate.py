"""Recursive instantiation of config trees.

This module provides the `instantiate()` function which recursively
walks a config tree and instantiates any ObjectSpec or CustomObjectSpec
instances it finds.

Usage:
    from athena.config import instantiate

    # Config with nested specs
    config = PipelineConfig(
        vae=VAEConfig(
            epochs=100,
            dataloader=DataLoaderSpec(
                type="pytorch_dataloader",
                batch_size=32,
                dataset=DatasetSpec(
                    type="nc_dataset",
                    params={"folder_path": "data/"},
                ),
            ),
        ),
    )

    # Instantiate all nested specs
    instantiated = instantiate(config)
    # Now config.vae.dataloader is an actual DataLoader instance
"""

from typing import Any

from pydantic import BaseModel

from athena.config.specs import CustomObjectSpec, ObjectSpec


def instantiate(config: Any) -> Any:
    """Recursively instantiate a config tree.

    Walks the config tree and instantiates:
    - ObjectSpec instances via their instantiate() method
    - CustomObjectSpec instances via their instantiate() method
    - Nested Pydantic models by instantiating their fields
    - Dicts by instantiating their values
    - Lists by instantiating their elements

    Args:
        config: Config object, dict, list, or primitive value.

    Returns:
        The config with all ObjectSpec/CustomObjectSpec instances
        replaced by their instantiated objects.
    """
    if isinstance(config, ObjectSpec):
        # ObjectSpec has its own instantiate() method
        return config.instantiate()

    elif isinstance(config, CustomObjectSpec):
        # CustomObjectSpec has its own instantiate() method
        return config.instantiate()

    elif isinstance(config, BaseModel):
        # For regular Pydantic models, instantiate nested fields
        return _instantiate_model(config)

    elif isinstance(config, dict):
        return {k: instantiate(v) for k, v in config.items()}

    elif isinstance(config, list):
        return [instantiate(v) for v in config]

    # Primitive values pass through unchanged
    return config


def _instantiate_model(model: BaseModel) -> BaseModel:
    """Instantiate nested specs in a Pydantic model.

    Creates a new instance of the model with all ObjectSpec/CustomObjectSpec
    fields instantiated.

    Args:
        model: Pydantic model instance.

    Returns:
        New model instance with instantiated fields.
    """
    # Get all field values
    updates: dict[str, Any] = {}
    needs_update = False

    for field_name in type(model).model_fields:
        value = getattr(model, field_name)
        instantiated = instantiate(value)

        # Track if anything changed
        if instantiated is not value:
            updates[field_name] = instantiated
            needs_update = True

    if not needs_update:
        return model

    # Create new model with instantiated fields
    return model.model_copy(update=updates)


def instantiate_field(config: BaseModel, field_name: str) -> Any:
    """Instantiate a specific field from a config.

    This is useful when you want to instantiate only part of a config
    without walking the entire tree.

    Args:
        config: Pydantic model containing the field.
        field_name: Name of the field to instantiate.

    Returns:
        The instantiated field value.

    Raises:
        AttributeError: If the field doesn't exist.
    """
    value = getattr(config, field_name)
    return instantiate(value)
