# athena-sdk

Python SDK for building blocks and workflows on the Athena ML orchestration platform.

## Installation

```bash
pip install buildathena-sdk
```

## Quick Start

### Define a Block

```python
from athena import block, BlockContext

@block(name="TrainModel", outputs=["checkpoint"])
async def train_model(ctx: BlockContext, epochs: int = 100):
    for epoch in range(epochs):
        loss = train_epoch()
        await ctx.emit_metric("loss", loss, epoch=epoch)

    ref = await ctx.artifacts.register("model.pt", schema_type="checkpoint")
    return {"checkpoint": ref}
```

### Use Credentials

Declare required secrets in the `@block` decorator and access via `ctx.secrets`:

```python
from athena import block, BlockContext

@block(name="MyBlock", secrets=["OPENAI_API_KEY"])
async def my_block(ctx: BlockContext, config):
    key = ctx.secrets["OPENAI_API_KEY"]
```

## Features

- **Block Decorator**: `@block` for defining workflow nodes
- **Handler Decorator**: `@handler` for custom URI scheme storage backends (s3://, gs://)
- **Inspector Backend**: `@inspector_backend` protocol for interactive UI plugins
- **BlockContext**: Emit metrics, progress, logs, and register artifacts
- **Config System**: YAML with `$include`, `$extends`, `${ref}` substitution
- **Discovery**: AST-based scanner for workspace block detection
- **Credentials**: Secure secret management with `@block(secrets=...)` and `ctx.secrets`

## License

Proprietary - Copyright (c) 2026 Athena Technologies. All rights reserved.
