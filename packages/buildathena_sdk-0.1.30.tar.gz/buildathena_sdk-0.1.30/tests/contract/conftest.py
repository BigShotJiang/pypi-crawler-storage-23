"""Contract test fixtures for SDK blocks.

Provides fixtures that record block outputs (events, artifacts) for verification
without making actual HTTP calls to the server.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
import pytest_asyncio

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from athena import BlockContext


@dataclass
class EmittedEvent:
    """Record of an emitted event."""

    event_type: str
    event_name: str | None
    payload: dict[str, Any]


@dataclass
class RegisteredArtifact:
    """Record of a registered artifact."""

    artifact_id: UUID
    name: str
    schema_type: str
    content_hash: str
    size_bytes: int
    tags: list[str]
    metadata: dict[str, Any]
    local_path: Path | None


@dataclass
class ContractTestRecorder:
    """Records all observable outputs from block execution.

    Use this to verify that blocks comply with their contracts:
    - Emitting required metrics/progress events
    - Registering expected artifacts
    - Returning declared outputs
    """

    events: list[EmittedEvent] = field(default_factory=list)
    artifacts: list[RegisteredArtifact] = field(default_factory=list)

    def record_event(
        self, event_type: str, event_name: str | None, payload: dict[str, Any]
    ) -> None:
        """Record an event emission."""
        self.events.append(EmittedEvent(event_type, event_name, payload))

    def record_artifact(
        self,
        artifact_id: UUID,
        name: str,
        schema_type: str,
        content_hash: str,
        size_bytes: int,
        tags: list[str],
        metadata: dict[str, Any],
        local_path: Path | None = None,
    ) -> None:
        """Record an artifact registration."""
        self.artifacts.append(
            RegisteredArtifact(
                artifact_id,
                name,
                schema_type,
                content_hash,
                size_bytes,
                tags,
                metadata,
                local_path,
            )
        )

    # ==========================================================================
    # Assertion helpers
    # ==========================================================================

    def assert_event_emitted(
        self, event_type: str, event_name: str | None = None, **payload_match: Any
    ) -> EmittedEvent:
        """Assert an event was emitted and return it.

        Args:
            event_type: Type of event (e.g., "metric", "progress")
            event_name: Optional name to match (e.g., metric name)
            **payload_match: Key-value pairs that must be in the payload

        Returns:
            The matching event

        Raises:
            AssertionError: If no matching event found
        """
        for event in self.events:
            if event.event_type != event_type:
                continue
            if event_name is not None and event.event_name != event_name:
                continue
            if all(event.payload.get(k) == v for k, v in payload_match.items()):
                return event

        raise AssertionError(
            f"No event found matching type={event_type!r}, name={event_name!r}, "
            f"payload={payload_match}.\nEmitted events: {self.events}"
        )

    def assert_artifact_registered(
        self, schema_type: str, name: str | None = None, **metadata_match: Any
    ) -> RegisteredArtifact:
        """Assert an artifact was registered and return it.

        Args:
            schema_type: Schema type to match
            name: Optional name to match
            **metadata_match: Key-value pairs that must be in metadata

        Returns:
            The matching artifact

        Raises:
            AssertionError: If no matching artifact found
        """
        for artifact in self.artifacts:
            if artifact.schema_type != schema_type:
                continue
            if name is not None and artifact.name != name:
                continue
            if all(artifact.metadata.get(k) == v for k, v in metadata_match.items()):
                return artifact

        raise AssertionError(
            f"No artifact found matching schema_type={schema_type!r}, name={name!r}, "
            f"metadata={metadata_match}.\nRegistered artifacts: {self.artifacts}"
        )

    def assert_metric_emitted(self, name: str, value: float | None = None) -> EmittedEvent:
        """Assert a metric was emitted.

        Args:
            name: Metric name to find
            value: Optional value to verify

        Returns:
            The matching metric event
        """
        event = self.assert_event_emitted("metric", name)
        if value is not None:
            actual = event.payload.get("value")
            assert actual == value, f"Metric {name!r} has value {actual}, expected {value}"
        return event

    def assert_progress_emitted(self, current: int, total: int) -> EmittedEvent:
        """Assert progress was emitted with specific values."""
        return self.assert_event_emitted("progress", None, current=current, total=total)

    def get_metrics(self, name: str) -> list[EmittedEvent]:
        """Get all metric events with the given name."""
        return [e for e in self.events if e.event_type == "metric" and e.event_name == name]

    def get_artifacts_by_schema(self, schema_type: str) -> list[RegisteredArtifact]:
        """Get all artifacts with the given schema type."""
        return [a for a in self.artifacts if a.schema_type == schema_type]


@pytest.fixture
def contract_recorder() -> ContractTestRecorder:
    """Create a fresh contract test recorder."""
    return ContractTestRecorder()


@pytest_asyncio.fixture
async def contract_context(
    contract_recorder: ContractTestRecorder,
    tmp_path: Path,  # noqa: ARG001
) -> AsyncGenerator[BlockContext, None]:
    """Create a BlockContext wired to record outputs.

    This creates a real BlockContext but intercepts HTTP calls to record
    events and artifacts instead of making network requests.
    """
    import os

    from athena import BlockContext

    run_id = uuid4()
    lab_id = uuid4()

    # Create a mock HTTP client that records calls
    mock_client = AsyncMock()

    async def mock_post(url: str, **kwargs: Any) -> MagicMock:
        """Handle POST requests by recording them."""
        response = MagicMock()
        response.raise_for_status = MagicMock()

        json_data = kwargs.get("json", {})

        if "/events" in url:
            # Record event
            contract_recorder.record_event(
                json_data.get("event_type", "unknown"),
                json_data.get("event_name"),
                json_data.get("payload", {}),
            )
            response.json.return_value = {"status": "ok"}
        elif "/artifacts" in url:
            # Record artifact registration
            artifact_id = uuid4()
            contract_recorder.record_artifact(
                artifact_id=artifact_id,
                name=json_data.get("name", "unnamed"),
                schema_type=json_data.get("schema_type", "unknown"),
                content_hash=json_data.get("content_hash", ""),
                size_bytes=json_data.get("size_bytes", 0),
                tags=json_data.get("tags", []),
                metadata=json_data.get("metadata", {}),
                local_path=Path(json_data.get("storage_ref", "").replace("file://", ""))
                if json_data.get("storage_ref", "").startswith("file://")
                else None,
            )
            response.json.return_value = {"id": str(artifact_id)}
        else:
            response.json.return_value = {"status": "ok"}

        return response

    async def mock_get(url: str, **kwargs: Any) -> MagicMock:  # noqa: ARG001
        """Handle GET requests."""
        response = MagicMock()
        response.raise_for_status = MagicMock()

        if "/status" in url:
            response.json.return_value = {"status": "running"}
        elif "/meta" in url:
            response.json.return_value = {"name": "test", "schema_type": "test"}
        else:
            response.json.return_value = {}

        return response

    mock_client.post = mock_post
    mock_client.get = mock_get
    mock_client.is_closed = False
    mock_client.aclose = AsyncMock()

    # Set environment variable for Block API URL
    with patch.dict(os.environ, {"ATHENA_BLOCK_API": "http://127.0.0.1:8002"}):
        ctx = BlockContext(
            run_id=run_id,
            step_id="test_step",
            lab_id=lab_id,
            config={"test": True},
        )
        # Replace the HTTP client with our mock
        ctx._block_api_client = mock_client

        yield ctx

        await ctx.close()
