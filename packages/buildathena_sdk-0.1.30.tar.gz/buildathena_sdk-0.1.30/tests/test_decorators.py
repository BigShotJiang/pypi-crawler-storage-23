"""Tests for SDK decorators."""

from collections.abc import AsyncIterator

import pytest
from pydantic import BaseModel

from athena import (
    BlockContext,
    block,
    get_block_spec,
    get_config_class,
)
from athena.handler import get_handler_spec, handler


class TrainConfig(BaseModel):
    """Test config class."""

    epochs: int = 100
    batch_size: int = 32


@block(
    name="TestBlock",
    description="A test block",
    inputs=["data"],
    outputs=["output"],
    config=TrainConfig,
)
async def sample_block_func(
    ctx: BlockContext,  # noqa: ARG001
    config: TrainConfig,  # noqa: ARG001
) -> dict:
    """A test block function."""
    return {"output": None}


class TestBlockDecorator:
    """Tests for the @block decorator."""

    def test_block_decorator_attaches_spec(self) -> None:
        """Test that @block attaches a spec to the function."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert spec.name == "TestBlock"
        assert spec.description == "A test block"

    def test_block_decorator_captures_inputs(self) -> None:
        """Test that @block captures input definitions."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert len(spec.inputs) == 1
        assert spec.inputs[0].name == "data"
        assert spec.inputs[0].type == "Any"

    def test_block_decorator_captures_outputs(self) -> None:
        """Test that @block captures output definitions."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert len(spec.outputs) == 1
        assert spec.outputs[0].name == "output"

    def test_block_decorator_captures_config_class(self) -> None:
        """Test that @block captures config class."""
        config_class = get_config_class(sample_block_func)

        assert config_class is not None
        assert config_class == TrainConfig

    def test_block_decorator_captures_config_schema(self) -> None:
        """Test that @block captures config schema."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert spec.config_schema is not None
        assert "epochs" in spec.config_schema.get("properties", {})

    @pytest.mark.asyncio
    async def test_decorated_function_is_callable(self) -> None:
        """Test that decorated function remains callable."""
        # Create a mock context
        from unittest.mock import MagicMock

        ctx = MagicMock(spec=BlockContext)
        config = TrainConfig()

        result = await sample_block_func(ctx, config)

        assert result == {"output": None}

    def test_block_decorator_with_defaults(self) -> None:
        """Test @block with default values."""

        @block(name="MinimalBlock")
        async def minimal_block(_ctx: BlockContext) -> None:
            pass

        spec = get_block_spec(minimal_block)

        assert spec is not None
        assert spec.name == "MinimalBlock"
        assert len(spec.inputs) == 0
        assert len(spec.outputs) == 0
        assert spec.config_schema is None
        assert spec.secrets == []

    def test_block_decorator_with_secrets(self) -> None:
        """Test @block with secrets declaration."""

        @block(
            name="SecretBlock",
            secrets=["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"],
        )
        async def secret_block(_ctx: BlockContext) -> None:
            """Block that requires secrets."""
            pass

        spec = get_block_spec(secret_block)

        assert spec is not None
        assert spec.secrets == ["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"]

    def test_block_decorator_secrets_defaults_to_empty(self) -> None:
        """Test that secrets defaults to empty list when not specified."""

        @block(name="NoSecrets")
        async def no_secrets_block(_ctx: BlockContext) -> None:
            pass

        spec = get_block_spec(no_secrets_block)

        assert spec is not None
        assert spec.secrets == []
        assert spec.secrets == []

    def test_block_decorator_without_name(self) -> None:
        """Test @block without explicit name uses function name."""

        @block()
        async def auto_named_block(_ctx: BlockContext) -> None:
            """Auto-named block."""
            pass

        spec = get_block_spec(auto_named_block)

        assert spec is not None
        assert spec.name == "auto_named_block"
        assert spec.description == "Auto-named block."

    @pytest.mark.asyncio
    async def test_sync_block_is_callable(self) -> None:
        """Test that a sync function decorated with @block can be called via await."""
        from unittest.mock import MagicMock

        @block(name="SyncBlock")
        def sync_block(
            ctx: BlockContext,  # noqa: ARG001
        ) -> dict:
            """A sync block function."""
            return {"result": 42}

        spec = get_block_spec(sync_block)
        assert spec is not None
        assert spec.name == "SyncBlock"

        ctx = MagicMock(spec=BlockContext)
        # The @block decorator wraps sync functions in an async wrapper
        result = await sync_block(ctx)  # type: ignore[misc]
        assert result == {"result": 42}

    @pytest.mark.asyncio
    async def test_async_block_still_works(self) -> None:
        """Test that an async function decorated with @block still works."""
        from unittest.mock import MagicMock

        @block(name="AsyncBlock")
        async def async_block(
            ctx: BlockContext,  # noqa: ARG001
        ) -> dict:
            """An async block function."""
            return {"result": 99}

        ctx = MagicMock(spec=BlockContext)
        result = await async_block(ctx)
        assert result == {"result": 99}


@handler(schemes=["s3", "s3a"])
async def sample_s3_handler(
    storage_ref: str,  # noqa: ARG001
    env: dict[str, str],  # noqa: ARG001
) -> AsyncIterator[bytes]:
    """Fetch data from S3."""
    yield b"test data"


class TestHandlerDecorator:
    """Tests for the @handler decorator."""

    def test_handler_decorator_attaches_spec(self) -> None:
        """Test that @handler attaches a spec to the function."""
        spec = get_handler_spec(sample_s3_handler)

        assert spec is not None
        assert spec.name == "sample_s3_handler"
        assert spec.schemes == ["s3", "s3a"]
        assert spec.description == "Fetch data from S3."

    def test_handler_decorator_with_custom_name(self) -> None:
        """Test @handler with custom name."""

        @handler(schemes=["gs"], name="GoogleStorage", description="Custom GCS handler")
        async def gcs_handler(
            storage_ref: str,  # noqa: ARG001
            env: dict[str, str],  # noqa: ARG001
        ) -> AsyncIterator[bytes]:
            yield b"data"

        spec = get_handler_spec(gcs_handler)

        assert spec is not None
        assert spec.name == "GoogleStorage"
        assert spec.schemes == ["gs"]
        assert spec.description == "Custom GCS handler"

    @pytest.mark.asyncio
    async def test_decorated_handler_is_callable(self) -> None:
        """Test that decorated handler remains callable."""
        chunks = []
        async for chunk in sample_s3_handler("s3://bucket/key", {}):
            chunks.append(chunk)

        assert chunks == [b"test data"]

    def test_handler_decorator_with_single_scheme(self) -> None:
        """Test @handler with a single scheme."""

        @handler(schemes=["file"])
        async def file_handler(
            storage_ref: str,  # noqa: ARG001
            env: dict[str, str],  # noqa: ARG001
        ) -> AsyncIterator[bytes]:
            """Handle file:// URIs."""
            yield b"file data"

        spec = get_handler_spec(file_handler)

        assert spec is not None
        assert spec.schemes == ["file"]
        assert spec.description == "Handle file:// URIs."

    def test_get_handler_spec_returns_none_for_non_handler(self) -> None:
        """Test that get_handler_spec returns None for non-handler functions."""

        def regular_function() -> None:
            pass

        spec = get_handler_spec(regular_function)
        assert spec is None
