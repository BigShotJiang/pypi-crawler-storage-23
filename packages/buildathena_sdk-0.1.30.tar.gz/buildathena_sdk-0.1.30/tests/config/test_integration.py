"""Integration tests for the config system.

These tests verify the complete flow:
YAML loading → schema validation → spec instantiation
"""

from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from athena.config import (
    ObjectSpec,
    instantiate,
    load_config,
    objects,
)

# ============================================================================
# Test classes to register
# ============================================================================


class LogTransform:
    """Apply log transform."""

    def __init__(self, base: float = 10, abs_value: bool = False):
        self.base = base
        self.abs_value = abs_value


class NormalizeTransform:
    """Normalize with mean/std."""

    def __init__(self, mean: float, std: float):
        self.mean = mean
        self.std = std


class ComposeTransform:
    """Compose multiple transforms."""

    def __init__(self, transforms: list):
        self.transforms = transforms


class NCDataset:
    """NetCDF dataset wrapper."""

    def __init__(self, folder_path: str, transform=None, cache: bool = True):
        self.folder_path = folder_path
        self.transform = transform
        self.cache = cache


class PyTorchDataLoader:
    """Simple DataLoader wrapper."""

    def __init__(
        self,
        dataset,
        batch_size: int = 32,
        num_workers: int = 4,
        shuffle: bool = True,
    ):
        self.dataset = dataset
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.shuffle = shuffle


@pytest.fixture(autouse=True)
def setup_registry():
    """Set up registry before each test."""
    objects.clear()

    objects.register_class("log", LogTransform)
    objects.register_class("normalize", NormalizeTransform)
    objects.register_class("compose", ComposeTransform)
    objects.register_class("nc_dataset", NCDataset)
    objects.register_class("pytorch_dataloader", PyTorchDataLoader)

    yield

    objects.clear()


# ============================================================================
# Config schemas
# ============================================================================


class VAEConfig(BaseModel):
    """Configuration for VAE training block."""

    epochs: int = Field(default=100, ge=1)
    learning_rate: float = Field(default=0.001, gt=0)
    dataloader: ObjectSpec


class PipelineConfig(BaseModel):
    """Full pipeline configuration."""

    name: str
    vae: VAEConfig
    output_dir: str = "./outputs"


# ============================================================================
# Integration tests
# ============================================================================


class TestFullConfigFlow:
    """Test the complete config loading and instantiation flow."""

    def test_yaml_to_objects(self, tmp_path: Path) -> None:
        """Test loading YAML config and instantiating objects."""
        # Write config file
        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text(
            """
name: test_pipeline
vae:
  epochs: 50
  learning_rate: 0.0001
  dataloader:
    type: pytorch_dataloader
    params:
      batch_size: 64
      num_workers: 8
      shuffle: true
    children:
      dataset:
        type: nc_dataset
        params:
          folder_path: /data/samples
          cache: false
        children:
          transform:
            type: compose
            children:
              transforms:
                - type: log
                  params:
                    base: 10
                    abs_value: true
                - type: normalize
                  params:
                    mean: 0.5
                    std: 0.1
output_dir: ./my_outputs
            """
        )

        # Load and validate
        config = load_config(config_file, PipelineConfig)

        # Verify schema values
        assert config.name == "test_pipeline"
        assert config.vae.epochs == 50
        assert config.vae.learning_rate == 0.0001
        assert config.output_dir == "./my_outputs"

        # Verify spec structure
        assert config.vae.dataloader.params["batch_size"] == 64
        assert config.vae.dataloader.params["num_workers"] == 8
        dataset_spec = config.vae.dataloader.children["dataset"]
        assert isinstance(dataset_spec, ObjectSpec)
        assert dataset_spec.type == "nc_dataset"
        transform_spec = dataset_spec.children["transform"]
        assert isinstance(transform_spec, ObjectSpec)
        assert transform_spec.type == "compose"
        transforms_spec = transform_spec.children["transforms"]
        assert isinstance(transforms_spec, list)
        assert len(transforms_spec) == 2

        # Instantiate dataloader
        loader = config.vae.dataloader.instantiate()

        assert isinstance(loader, PyTorchDataLoader)
        assert loader.batch_size == 64
        assert loader.num_workers == 8
        assert loader.shuffle is True

        # Verify dataset
        assert isinstance(loader.dataset, NCDataset)
        assert loader.dataset.folder_path == "/data/samples"
        assert loader.dataset.cache is False

        # Verify transform chain
        assert isinstance(loader.dataset.transform, ComposeTransform)
        assert len(loader.dataset.transform.transforms) == 2
        assert isinstance(loader.dataset.transform.transforms[0], LogTransform)
        assert loader.dataset.transform.transforms[0].base == 10
        assert loader.dataset.transform.transforms[0].abs_value is True
        assert isinstance(loader.dataset.transform.transforms[1], NormalizeTransform)
        assert loader.dataset.transform.transforms[1].mean == 0.5
        assert loader.dataset.transform.transforms[1].std == 0.1

    def test_config_with_includes(self, tmp_path: Path) -> None:
        """Test config composition with $include."""
        # Base dataloader config
        base_file = tmp_path / "base_dataloader.yaml"
        base_file.write_text(
            """
type: pytorch_dataloader
params:
  batch_size: 32
  num_workers: 4
  shuffle: true
children:
  dataset:
    type: nc_dataset
    params:
      folder_path: /default/data
            """
        )

        # Override file
        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text(
            """
name: override_pipeline
vae:
  epochs: 100
  dataloader:
    $include: base_dataloader.yaml
    params:
      batch_size: 128
    children:
      dataset:
        params:
          folder_path: /custom/data
            """
        )

        config = load_config(config_file, PipelineConfig)

        # Check that include worked and override applied
        assert config.name == "override_pipeline"
        assert config.vae.dataloader.params["batch_size"] == 128  # Overridden
        assert config.vae.dataloader.params["num_workers"] == 4  # From base
        dataset_spec = config.vae.dataloader.children["dataset"]
        assert isinstance(dataset_spec, ObjectSpec)
        assert dataset_spec.params["folder_path"] == "/custom/data"

    def test_instantiate_helper(self, tmp_path: Path) -> None:
        """Test the instantiate() helper function."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
name: test
vae:
  epochs: 10
  dataloader:
    type: pytorch_dataloader
    params:
      batch_size: 16
    children:
      dataset:
        type: nc_dataset
        params:
          folder_path: /test
            """
        )

        config = load_config(config_file, PipelineConfig)

        # Use instantiate helper to instantiate nested specs
        instantiated = instantiate(config)

        # The config model is returned with instantiated nested objects
        assert isinstance(instantiated, PipelineConfig)
        assert instantiated.name == "test"

        # Dataloader should now be instantiated
        assert isinstance(instantiated.vae.dataloader, PyTorchDataLoader)
        assert isinstance(instantiated.vae.dataloader.dataset, NCDataset)

    def test_validation_errors(self, tmp_path: Path) -> None:
        """Test that validation errors are properly raised."""
        config_file = tmp_path / "invalid.yaml"
        config_file.write_text(
            """
name: test
vae:
  epochs: -5
  dataloader:
    type: nc_dataset
    params:
      folder_path: /test
            """
        )

        from athena.config.loader import ConfigLoadError

        with pytest.raises(ConfigLoadError, match="Config validation failed"):
            load_config(config_file, PipelineConfig)

    def test_unknown_type_error(self, tmp_path: Path) -> None:
        """Test that unknown registry types raise proper errors."""
        config_file = tmp_path / "unknown.yaml"
        config_file.write_text(
            """
name: test
vae:
  epochs: 10
  dataloader:
    type: unknown_type
    params:
      batch_size: 32
            """
        )

        config = load_config(config_file, PipelineConfig)

        from athena.config.registry import RegistryError

        with pytest.raises(RegistryError, match="Unknown objects: 'unknown_type'"):
            config.vae.dataloader.instantiate()


class TestRegistryUISupport:
    """Test registry features for UI support."""

    def test_names_for_dropdown(self) -> None:
        """Test getting names for UI dropdowns."""
        assert "log" in objects.names()
        assert "normalize" in objects.names()
        assert "compose" in objects.names()
        assert "nc_dataset" in objects.names()
        assert "pytorch_dataloader" in objects.names()

    def test_registry_inspection(self) -> None:
        """Test registry can be inspected."""
        assert len(objects) == 5
        assert "log" in objects
        assert objects.has("normalize")


class TestComplexNesting:
    """Test complex nested config structures."""

    def test_deeply_nested_transforms(self, tmp_path: Path) -> None:
        """Test deeply nested compose transforms."""
        config_file = tmp_path / "deep.yaml"
        config_file.write_text(
            """
name: deep_test
vae:
  epochs: 1
  dataloader:
    type: pytorch_dataloader
    children:
      dataset:
        type: nc_dataset
        params:
          folder_path: /test
        children:
          transform:
            type: compose
            children:
              transforms:
                - type: compose
                  children:
                    transforms:
                      - type: log
                        params:
                          base: 2
                      - type: normalize
                        params:
                          mean: 0
                          std: 1
                - type: normalize
                  params:
                    mean: 0.5
                    std: 0.5
            """
        )

        config = load_config(config_file, PipelineConfig)
        loader = config.vae.dataloader.instantiate()

        # Verify nested structure
        outer_compose = loader.dataset.transform
        assert isinstance(outer_compose, ComposeTransform)
        assert len(outer_compose.transforms) == 2

        inner_compose = outer_compose.transforms[0]
        assert isinstance(inner_compose, ComposeTransform)
        assert len(inner_compose.transforms) == 2
        assert isinstance(inner_compose.transforms[0], LogTransform)
        assert inner_compose.transforms[0].base == 2

    def test_empty_params(self, tmp_path: Path) -> None:
        """Test specs with empty params."""
        config_file = tmp_path / "empty.yaml"
        config_file.write_text(
            """
name: empty_test
vae:
  epochs: 1
  dataloader:
    type: pytorch_dataloader
    children:
      dataset:
        type: nc_dataset
        params:
          folder_path: /test
        children:
          transform:
            type: log
            """
        )

        config = load_config(config_file, PipelineConfig)
        loader = config.vae.dataloader.instantiate()

        # Should use default params
        assert isinstance(loader.dataset.transform, LogTransform)
        assert loader.dataset.transform.base == 10  # Default
        assert loader.dataset.transform.abs_value is False  # Default
