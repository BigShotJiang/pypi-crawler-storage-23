"""Tests for the config registry module."""

import pytest

from athena.config.registry import Registry, RegistryError


class TestRegistry:
    """Tests for the Registry class."""

    def test_register_decorator(self) -> None:
        """Test registering a class with the decorator."""
        registry = Registry("test")

        @registry.register("my_class")
        class MyClass:
            pass

        assert registry.has("my_class")
        assert registry.get("my_class") is MyClass

    def test_register_class_method(self) -> None:
        """Test registering a class with register_class method."""
        registry = Registry("test")

        class MyClass:
            pass

        registry.register_class("my_class", MyClass)

        assert registry.has("my_class")
        assert registry.get("my_class") is MyClass

    def test_register_duplicate_raises(self) -> None:
        """Test that registering duplicate names raises an error."""
        registry = Registry("test")

        @registry.register("duplicate")
        class FirstClass:
            pass

        with pytest.raises(RegistryError, match="already registered"):

            @registry.register("duplicate")
            class SecondClass:
                pass

    def test_get_unknown_raises(self) -> None:
        """Test that getting an unknown name raises an error."""
        registry = Registry("test")

        with pytest.raises(RegistryError, match="Unknown test: 'unknown'"):
            registry.get("unknown")

    def test_get_unknown_lists_available(self) -> None:
        """Test that error message lists available names."""
        registry = Registry("test")

        @registry.register("alpha")
        class Alpha:
            pass

        @registry.register("beta")
        class Beta:
            pass

        with pytest.raises(RegistryError, match="Available: alpha, beta"):
            registry.get("gamma")

    def test_names_returns_sorted(self) -> None:
        """Test that names() returns sorted list."""
        registry = Registry("test")

        @registry.register("zebra")
        class Zebra:
            pass

        @registry.register("apple")
        class Apple:
            pass

        @registry.register("mango")
        class Mango:
            pass

        assert registry.names() == ["apple", "mango", "zebra"]

    def test_len(self) -> None:
        """Test __len__ returns number of entries."""
        registry = Registry("test")
        assert len(registry) == 0

        @registry.register("first")
        class First:
            pass

        assert len(registry) == 1

        @registry.register("second")
        class Second:
            pass

        assert len(registry) == 2

    def test_contains(self) -> None:
        """Test __contains__ for `in` operator."""
        registry = Registry("test")

        @registry.register("exists")
        class Exists:
            pass

        assert "exists" in registry
        assert "missing" not in registry

    def test_has(self) -> None:
        """Test has() method."""
        registry = Registry("test")

        @registry.register("exists")
        class Exists:
            pass

        assert registry.has("exists")
        assert not registry.has("missing")

    def test_clear(self) -> None:
        """Test clear() removes all entries."""
        registry = Registry("test")

        @registry.register("first")
        class First:
            pass

        @registry.register("second")
        class Second:
            pass

        assert len(registry) == 2

        registry.clear()

        assert len(registry) == 0
        assert not registry.has("first")
        assert not registry.has("second")

    def test_repr(self) -> None:
        """Test __repr__ output."""
        registry = Registry("transforms")

        @registry.register("normalize")
        class Normalize:
            pass

        assert repr(registry) == "Registry('transforms', 1 entries)"

    def test_decorator_returns_class_unchanged(self) -> None:
        """Test that decorator returns the class unchanged."""
        registry = Registry("test")

        @registry.register("my_class")
        class MyClass:
            def method(self) -> str:
                return "hello"

        # Class should work normally
        instance = MyClass()
        assert instance.method() == "hello"

    def test_instantiate_registered_class(self) -> None:
        """Test instantiating a class from the registry."""
        registry = Registry("test")

        @registry.register("point")
        class Point:
            def __init__(self, x: float, y: float) -> None:
                self.x = x
                self.y = y

        cls = registry.get("point")
        instance = cls(x=1.0, y=2.0)

        assert instance.x == 1.0
        assert instance.y == 2.0
