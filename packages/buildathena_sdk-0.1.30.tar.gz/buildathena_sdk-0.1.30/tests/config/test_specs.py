"""Tests for the config specs module."""

import pytest

from athena.config import objects
from athena.config.registry import Registry
from athena.config.specs import (
    CustomObjectSpec,
    ObjectSpec,
)

# ============================================================================
# Test fixtures - register test classes
# ============================================================================


class Point:
    """Simple test class with x, y coordinates."""

    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y


class LogTransform:
    """Test transform that applies log."""

    def __init__(self, base: float = 10) -> None:
        self.base = base

    def __call__(self, x: float) -> float:
        import math

        return math.log(x) / math.log(self.base)


class NormalizeTransform:
    """Test transform that normalizes."""

    def __init__(self, mean: float, std: float) -> None:
        self.mean = mean
        self.std = std

    def __call__(self, x: float) -> float:
        return (x - self.mean) / self.std


class ComposeTransform:
    """Test transform that composes multiple transforms."""

    def __init__(self, transforms: list) -> None:
        self.transforms = transforms

    def __call__(self, x: float) -> float:
        for t in self.transforms:
            x = t(x)
        return x


class SimpleDataset:
    """Test dataset."""

    def __init__(self, folder_path: str, transform=None) -> None:
        self.folder_path = folder_path
        self.transform = transform

    def __len__(self) -> int:
        return 100

    def __getitem__(self, idx: int) -> float:
        val = float(idx)
        if self.transform:
            val = self.transform(val)
        return val


class SimpleDataLoader:
    """Test dataloader."""

    def __init__(
        self,
        dataset,
        batch_size: int = 32,
        num_workers: int = 4,
        shuffle: bool = True,
    ) -> None:
        self.dataset = dataset
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.shuffle = shuffle


@pytest.fixture(autouse=True)
def setup_registry():
    """Set up test registry before each test."""
    # Clear and register test classes
    objects.clear()

    objects.register_class("point", Point)
    objects.register_class("log", LogTransform)
    objects.register_class("normalize", NormalizeTransform)
    objects.register_class("compose", ComposeTransform)
    objects.register_class("simple_dataset", SimpleDataset)
    objects.register_class("pytorch_dataloader", SimpleDataLoader)

    yield

    # Cleanup
    objects.clear()


# ============================================================================
# ObjectSpec tests - params only
# ============================================================================


class TestObjectSpecParams:
    """Tests for ObjectSpec with params only."""

    def test_simple_instantiation(self) -> None:
        """Test instantiating with params only."""
        spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
        point = spec.instantiate()

        assert isinstance(point, Point)
        assert point.x == 1
        assert point.y == 2

    def test_uses_class_defaults(self) -> None:
        """Test that missing params use class defaults."""
        spec = ObjectSpec(type="log")
        transform = spec.instantiate()

        assert isinstance(transform, LogTransform)
        assert transform.base == 10  # Default value

    def test_override_defaults(self) -> None:
        """Test overriding class defaults."""
        spec = ObjectSpec(type="log", params={"base": 2})
        transform = spec.instantiate()

        assert transform.base == 2

    def test_empty_params(self) -> None:
        """Test that params defaults to empty dict."""
        spec = ObjectSpec(type="log")
        assert spec.params == {}


# ============================================================================
# ObjectSpec tests - single child
# ============================================================================


class TestObjectSpecSingleChild:
    """Tests for ObjectSpec with a single child."""

    def test_child_is_instantiated(self) -> None:
        """Test that a child is instantiated and passed to parent."""
        spec = ObjectSpec(
            type="simple_dataset",
            params={"folder_path": "/data/samples"},
            children={
                "transform": ObjectSpec(
                    type="normalize",
                    params={"mean": 0.5, "std": 0.1},
                )
            },
        )
        dataset = spec.instantiate()

        assert isinstance(dataset, SimpleDataset)
        assert dataset.folder_path == "/data/samples"
        assert isinstance(dataset.transform, NormalizeTransform)
        assert dataset.transform.mean == 0.5
        assert dataset.transform.std == 0.1

    def test_child_without_params(self) -> None:
        """Test child with default params."""
        spec = ObjectSpec(
            type="simple_dataset",
            params={"folder_path": "/data"},
            children={"transform": ObjectSpec(type="log")},
        )
        dataset = spec.instantiate()

        assert isinstance(dataset.transform, LogTransform)
        assert dataset.transform.base == 10


# ============================================================================
# ObjectSpec tests - list of children (compose pattern)
# ============================================================================


class TestObjectSpecListChildren:
    """Tests for ObjectSpec with list of children."""

    def test_compose_pattern(self) -> None:
        """Test composing multiple children."""
        spec = ObjectSpec(
            type="compose",
            children={
                "transforms": [
                    ObjectSpec(type="log", params={"base": 10}),
                    ObjectSpec(type="normalize", params={"mean": 0, "std": 1}),
                ]
            },
        )
        transform = spec.instantiate()

        assert isinstance(transform, ComposeTransform)
        assert len(transform.transforms) == 2
        assert isinstance(transform.transforms[0], LogTransform)
        assert transform.transforms[0].base == 10
        assert isinstance(transform.transforms[1], NormalizeTransform)

    def test_empty_list(self) -> None:
        """Test compose with empty list."""
        spec = ObjectSpec(
            type="compose",
            children={"transforms": []},
        )
        transform = spec.instantiate()

        assert isinstance(transform, ComposeTransform)
        assert transform.transforms == []


# ============================================================================
# ObjectSpec tests - nested children (dataloader → dataset → transform)
# ============================================================================


class TestObjectSpecNestedChildren:
    """Tests for deeply nested ObjectSpec trees."""

    def test_full_tree_instantiation(self) -> None:
        """Test instantiating full dataloader -> dataset -> transform tree."""
        spec = ObjectSpec(
            type="pytorch_dataloader",
            params={"batch_size": 64, "shuffle": False},
            children={
                "dataset": ObjectSpec(
                    type="simple_dataset",
                    params={"folder_path": "/data/samples"},
                    children={
                        "transform": ObjectSpec(
                            type="compose",
                            children={
                                "transforms": [
                                    ObjectSpec(type="log", params={"base": 10}),
                                    ObjectSpec(type="normalize", params={"mean": 0, "std": 1}),
                                ]
                            },
                        )
                    },
                )
            },
        )
        loader = spec.instantiate()

        assert isinstance(loader, SimpleDataLoader)
        assert loader.batch_size == 64
        assert loader.shuffle is False
        assert isinstance(loader.dataset, SimpleDataset)
        assert loader.dataset.folder_path == "/data/samples"
        assert isinstance(loader.dataset.transform, ComposeTransform)
        assert len(loader.dataset.transform.transforms) == 2

    def test_nested_compose(self) -> None:
        """Test nested compose transforms."""
        spec = ObjectSpec(
            type="compose",
            children={
                "transforms": [
                    ObjectSpec(
                        type="compose",
                        children={
                            "transforms": [
                                ObjectSpec(type="log"),
                            ]
                        },
                    ),
                    ObjectSpec(type="normalize", params={"mean": 0, "std": 1}),
                ]
            },
        )
        transform = spec.instantiate()

        assert isinstance(transform, ComposeTransform)
        assert len(transform.transforms) == 2
        assert isinstance(transform.transforms[0], ComposeTransform)
        assert len(transform.transforms[0].transforms) == 1
        assert isinstance(transform.transforms[0].transforms[0], LogTransform)


# ============================================================================
# ObjectSpec tests - custom registry override
# ============================================================================


class TestObjectSpecCustomRegistry:
    """Tests for ObjectSpec with custom registry."""

    def test_custom_registry(self) -> None:
        """Test using a custom registry."""
        custom_registry = Registry("custom")

        @custom_registry.register("custom_point")
        class CustomPoint:
            def __init__(self, x: int, y: int):
                self.x = x
                self.y = y

        spec = ObjectSpec(type="custom_point", params={"x": 10, "y": 20})
        point = spec.instantiate(registry=custom_registry)

        assert isinstance(point, CustomPoint)
        assert point.x == 10
        assert point.y == 20

    def test_custom_registry_with_children(self) -> None:
        """Test custom registry is passed to children."""
        custom_registry = Registry("custom")

        @custom_registry.register("wrapper")
        class Wrapper:
            def __init__(self, inner):
                self.inner = inner

        @custom_registry.register("inner")
        class Inner:
            def __init__(self, value: int):
                self.value = value

        spec = ObjectSpec(
            type="wrapper",
            children={"inner": ObjectSpec(type="inner", params={"value": 42})},
        )
        wrapper = spec.instantiate(registry=custom_registry)

        assert isinstance(wrapper, Wrapper)
        assert isinstance(wrapper.inner, Inner)
        assert wrapper.inner.value == 42


# ============================================================================
# ObjectSpec base class behavior tests
# ============================================================================


class TestObjectSpecBaseBehavior:
    """Tests for ObjectSpec base class behavior."""

    def test_extra_fields_forbidden(self) -> None:
        """Test that extra fields are forbidden."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            ObjectSpec(type="log", **{"unknown_field": "value"})  # type: ignore[arg-type]

    def test_children_default_empty(self) -> None:
        """Test that children defaults to empty dict."""
        spec = ObjectSpec(type="log")
        assert spec.children == {}

    def test_params_and_children_merge(self) -> None:
        """Test that params and children are merged correctly."""
        # Children should override params with same key
        spec = ObjectSpec(
            type="simple_dataset",
            params={"folder_path": "/data", "transform": "should_be_overridden"},
            children={"transform": ObjectSpec(type="log")},
        )
        dataset = spec.instantiate()

        # Child took precedence
        assert isinstance(dataset.transform, LogTransform)


# ============================================================================
# CustomObjectSpec tests
# ============================================================================


class TestCustomObjectSpec:
    """Tests for CustomObjectSpec."""

    def test_instantiate_builtin(self) -> None:
        """Test instantiating a built-in class."""
        spec = CustomObjectSpec(
            target="collections.OrderedDict",
            params={},
        )
        obj = spec.instantiate()

        from collections import OrderedDict

        assert isinstance(obj, OrderedDict)

    def test_instantiate_with_params(self) -> None:
        """Test instantiating with params."""
        spec = CustomObjectSpec(
            target="collections.Counter",
            params={"a": 1, "b": 2},
        )
        obj = spec.instantiate()

        from collections import Counter

        assert isinstance(obj, Counter)
        assert obj["a"] == 1
        assert obj["b"] == 2

    def test_instantiate_with_args(self) -> None:
        """Test instantiating with positional args."""
        spec = CustomObjectSpec(
            target="collections.deque",
            params={"maxlen": 5},
        )
        obj = spec.instantiate([1, 2, 3])

        from collections import deque

        assert isinstance(obj, deque)
        assert obj.maxlen == 5
        assert list(obj) == [1, 2, 3]

    def test_instantiate_with_kwargs_override(self) -> None:
        """Test that kwargs override params."""
        spec = CustomObjectSpec(
            target="collections.Counter",
            params={"a": 1, "b": 2},
        )
        obj = spec.instantiate(b=10)

        assert obj["a"] == 1
        assert obj["b"] == 10  # Overridden

    def test_invalid_module_raises(self) -> None:
        """Test that invalid module raises ImportError."""
        spec = CustomObjectSpec(
            target="nonexistent.module.Class",
        )
        with pytest.raises(ModuleNotFoundError):
            spec.instantiate()

    def test_invalid_class_raises(self) -> None:
        """Test that invalid class raises AttributeError."""
        spec = CustomObjectSpec(
            target="collections.NonexistentClass",
        )
        with pytest.raises(AttributeError):
            spec.instantiate()
