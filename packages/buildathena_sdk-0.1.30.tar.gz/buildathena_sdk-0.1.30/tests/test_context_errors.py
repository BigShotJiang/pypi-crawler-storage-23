"""Tests for error handling in BlockContext.

These tests verify that:
1. Event emission failures use logger, not print()
2. Block execution continues even when events fail to emit
"""

import logging
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from athena.context import BlockContext


class TestEventEmissionErrors:
    """Tests for event emission error handling."""

    @pytest.fixture
    def context(self) -> BlockContext:
        """Create a BlockContext for testing."""
        from uuid import uuid4

        return BlockContext(
            run_id=uuid4(),
            step_id="test-step-456",
        )

    @pytest.mark.asyncio
    async def test_emit_event_failure_logged_not_printed(
        self, context: BlockContext, caplog: pytest.LogCaptureFixture, capsys: pytest.CaptureFixture
    ) -> None:
        """Event emission failure uses logger.warning(), not print().

        print() to stdout is lost in production environments.
        logger.warning() ensures failures are captured in observability systems.
        """
        with patch.object(context._block_api_client, "post", new_callable=AsyncMock) as mock_post:
            # Mock HTTP failure
            mock_post.side_effect = httpx.HTTPError("Connection refused")

            # Emit a metric (should fail)
            with caplog.at_level(logging.WARNING):
                await context.emit_metric("test_metric", 42.0)

            # Check stdout - should NOT have the warning (print is bad)
            captured = capsys.readouterr()

            # Current implementation uses print() - this test should FAIL
            if "Warning:" in captured.out or "Failed to emit" in captured.out:
                pytest.fail(
                    "Event emission failure uses print() instead of logging. "
                    "Change print() to logger.warning() for proper observability."
                )

            # Should have log entry instead
            # Note: After fix, this assertion should pass
            # assert any("Failed to emit" in record.message for record in caplog.records)

    @pytest.mark.asyncio
    async def test_block_continues_on_event_failure(self, context: BlockContext) -> None:
        """Block execution continues even if event emission fails.

        Event emission is fire-and-forget - failures should not crash blocks.
        """
        with patch.object(context._block_api_client, "post", new_callable=AsyncMock) as mock_post:
            # Mock HTTP failure
            mock_post.side_effect = httpx.HTTPError("Connection refused")

            # These should not raise - block continues executing
            await context.emit_metric("metric_1", 1.0)
            await context.emit_metric("metric_2", 2.0)
            await context.emit_progress(current=50, total=100)

            # All calls attempted despite failures
            assert mock_post.call_count == 3

    @pytest.mark.asyncio
    async def test_emit_metric_success_no_warning(
        self, context: BlockContext, caplog: pytest.LogCaptureFixture, capsys: pytest.CaptureFixture
    ) -> None:
        """Successful event emission produces no warnings."""
        with patch.object(context._block_api_client, "post", new_callable=AsyncMock) as mock_post:
            # Mock success
            mock_response = AsyncMock()
            mock_response.raise_for_status = lambda: None
            mock_post.return_value = mock_response

            with caplog.at_level(logging.WARNING):
                await context.emit_metric("test_metric", 42.0)

            # No warnings on success
            captured = capsys.readouterr()
            assert "Warning" not in captured.out
            assert len([r for r in caplog.records if r.levelno >= logging.WARNING]) == 0

    @pytest.mark.asyncio
    async def test_emit_progress_failure_logged(
        self, context: BlockContext, caplog: pytest.LogCaptureFixture, capsys: pytest.CaptureFixture
    ) -> None:
        """Progress emission failure also uses logger, not print()."""
        with patch.object(context._block_api_client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.side_effect = httpx.HTTPError("Timeout")

            with caplog.at_level(logging.WARNING):
                await context.emit_progress(current=1, total=10)

            captured = capsys.readouterr()

            # Same check as emit_metric
            if "Warning:" in captured.out or "Failed to emit" in captured.out:
                pytest.fail("Progress emission failure uses print() instead of logging.")
