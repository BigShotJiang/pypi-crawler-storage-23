"""Tests for OutputHandle.

Comprehensive tests to ensure proper coverage of the output_handle module.
"""

import pytest

from athena.output_handle import OutputHandle
from athena.storage import MemoryStorageBackend


class TestOutputHandleFromData:
    """Tests for OutputHandle.from_data factory method."""

    def test_from_data_basic(self):
        """Test creating handle from basic data."""
        handle = OutputHandle.from_data({"key": "value"}, name="test")
        assert handle.name == "test"
        assert handle.has_data
        assert not handle.is_materialized
        assert handle.get_data() == {"key": "value"}

    def test_from_data_with_all_options(self):
        """Test creating handle with all optional parameters."""
        handle = OutputHandle.from_data(
            data=[1, 2, 3],
            name="test",
            schema_type="list",
            mime_type="application/json",
            tags=["test", "data"],
            metadata={"source": "test"},
            step_id="step-1",
            format="json",
        )
        assert handle.name == "test"
        assert handle.schema_type == "list"
        assert handle.mime_type == "application/json"
        assert handle.tags == ["test", "data"]
        assert handle.metadata == {"source": "test"}
        assert handle.step_id == "step-1"
        assert handle._format == "json"

    def test_from_data_with_inputs(self):
        """Test creating handle with input handles for lineage."""
        input1 = OutputHandle.from_data("input1", name="in1")
        input1.content_hash = "hash1"
        input2 = OutputHandle.from_data("input2", name="in2")
        input2.content_hash = "hash2"

        handle = OutputHandle.from_data("output", name="out", inputs=[input1, input2])
        assert len(handle.input_handles) == 2
        assert len(handle.input_handles) == 2
        assert handle.input_handles[0].content_hash == "hash1"
        assert handle.input_handles[1].content_hash == "hash2"

    def test_from_data_with_custom_serializer(self):
        """Test creating handle with custom serializer."""

        def custom_ser(x: str) -> bytes:
            return b"custom:" + str(x).encode()

        def custom_deser(x: bytes) -> str:
            return x.decode().replace("custom:", "")

        handle = OutputHandle.from_data(
            "test",
            name="custom",
            serializer=custom_ser,
            deserializer=custom_deser,
        )
        assert handle.serialize() == b"custom:test"
        assert handle.deserialize(b"custom:hello") == "hello"


class TestOutputHandleFromStorage:
    """Tests for OutputHandle.from_storage factory method."""

    def test_from_storage_basic(self):
        """Test creating handle from storage reference."""
        handle = OutputHandle.from_storage(
            storage_key="/artifacts/abc123",
            content_hash="abc123",
            name="stored",
        )
        assert handle.storage_key == "/artifacts/abc123"
        assert handle.content_hash == "abc123"
        assert handle.name == "stored"
        assert handle.is_materialized
        assert not handle.has_data

    def test_from_storage_with_all_options(self):
        """Test creating from storage with all options."""

        def custom_deser(x: bytes) -> str:
            return x.decode()

        handle = OutputHandle.from_storage(
            storage_key="/artifacts/xyz",
            content_hash="xyz789",
            name="stored",
            schema_type="model",
            deserializer=custom_deser,
            step_id="step-1",
        )
        assert handle.schema_type == "model"
        assert handle.step_id == "step-1"
        assert handle._deserializer is custom_deser


class TestOutputHandleSerialization:
    """Tests for OutputHandle serialization methods."""

    def test_serialize_dict_to_json(self):
        """Test serializing dict to JSON (default)."""
        handle = OutputHandle.from_data({"a": 1, "b": 2})
        serialized = handle.serialize()
        assert b'"a"' in serialized
        assert b'"b"' in serialized

    def test_serialize_bytes_passthrough(self):
        """Test that bytes are passed through as-is."""
        data = b"raw bytes"
        handle = OutputHandle.from_data(data)
        assert handle.serialize() == data

    def test_serialize_str_as_json(self):
        """Test that strings are JSON-serialized (symmetric with deserialize)."""
        handle = OutputHandle.from_data("hello world")
        assert handle.serialize() == b'"hello world"'

    def test_serialize_with_pickle_format(self):
        """Test serializing with pickle format."""
        import pickle

        data = {"complex": [1, 2, {"nested": True}]}
        handle = OutputHandle.from_data(data, format="pickle")
        serialized = handle.serialize()
        assert pickle.loads(serialized) == data

    def test_serialize_no_data_raises(self):
        """Test that serializing without data raises ValueError."""
        handle = OutputHandle.from_storage("/key", "hash")
        with pytest.raises(ValueError, match="No data to serialize"):
            handle.serialize()

    def test_deserialize_json(self):
        """Test deserializing JSON."""
        handle = OutputHandle.from_data({})  # format will default to json
        result = handle.deserialize(b'{"key": "value"}')
        assert result == {"key": "value"}

    def test_deserialize_pickle(self):
        """Test deserializing pickle."""
        import pickle

        data = {"test": [1, 2, 3]}
        handle = OutputHandle.from_data(data, format="pickle")
        serialized = pickle.dumps(data)
        result = handle.deserialize(serialized)
        assert result == data

    def test_compute_hash(self):
        """Test computing content hash."""
        handle = OutputHandle.from_data("test data")
        hash1 = handle.compute_hash()
        hash2 = handle.compute_hash()
        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 hex


class TestOutputHandleDataAccess:
    """Tests for data access methods."""

    def test_get_data_returns_data(self):
        """Test get_data returns the in-memory data."""
        handle = OutputHandle.from_data([1, 2, 3])
        assert handle.get_data() == [1, 2, 3]

    def test_get_data_no_data_raises(self):
        """Test get_data raises when no data available."""
        handle = OutputHandle.from_storage("/key", "hash")
        with pytest.raises(ValueError, match="No in-memory data available"):
            handle.get_data()

    def test_set_data_clears_storage(self):
        """Test that set_data clears storage info."""
        handle = OutputHandle.from_storage("/key", "hash")
        assert handle.is_materialized

        handle.set_data("new data")

        assert handle.has_data
        assert not handle.is_materialized
        assert handle.storage_key is None
        assert handle.content_hash is None


class TestOutputHandleMaterialization:
    """Tests for materialization."""

    @pytest.mark.asyncio
    async def test_materialize_data(self):
        """Test materializing in-memory data."""
        storage = MemoryStorageBackend()
        handle = OutputHandle.from_data({"test": "data"}, name="test")

        content_hash = await handle.materialize(storage)

        assert handle.is_materialized
        assert handle.content_hash == content_hash
        assert await storage.exists(content_hash)

    @pytest.mark.asyncio
    async def test_materialize_already_materialized(self):
        """Test that materializing twice returns existing hash."""
        storage = MemoryStorageBackend()
        handle = OutputHandle.from_data("data")

        hash1 = await handle.materialize(storage)
        hash2 = await handle.materialize(storage)

        assert hash1 == hash2


class TestOutputHandleLoadData:
    """Tests for loading data from storage."""

    @pytest.mark.asyncio
    async def test_load_data_returns_inmemory_if_available(self):
        """Test that load_data returns in-memory data if available."""
        storage = MemoryStorageBackend()
        handle = OutputHandle.from_data([1, 2, 3])

        data = await handle.load_data(storage)
        assert data == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_load_data_fetches_from_storage(self):
        """Test that load_data fetches from storage when needed."""
        storage = MemoryStorageBackend()
        # Store data manually
        await storage.put("hash123", b'{"loaded": true}')

        handle = OutputHandle.from_storage("/path", "hash123")
        data = await handle.load_data(storage)

        assert data == {"loaded": True}
        assert handle.has_data  # Cached in memory

    @pytest.mark.asyncio
    async def test_load_data_not_materialized_raises(self):
        """Test that load_data raises if not materialized."""
        storage = MemoryStorageBackend()
        handle = OutputHandle()  # No data, no storage ref

        with pytest.raises(ValueError, match="no materialized data"):
            await handle.load_data(storage)


class TestOutputHandleReleaseMemory:
    """Tests for memory release."""

    def test_release_memory_after_materialized(self):
        """Test releasing memory after materialization."""
        handle = OutputHandle.from_data("data")
        handle.storage_key = "/path"
        handle.content_hash = "hash"

        assert handle.has_data
        handle.release_memory()
        assert not handle.has_data

    def test_release_memory_not_materialized_raises(self):
        """Test that releasing memory before materialization raises."""
        handle = OutputHandle.from_data("data")

        with pytest.raises(ValueError, match="Cannot release memory before materialization"):
            handle.release_memory()
