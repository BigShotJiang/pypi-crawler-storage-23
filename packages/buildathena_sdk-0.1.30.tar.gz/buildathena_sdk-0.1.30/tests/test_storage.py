"""Tests for storage backends in athena-sdk.

These tests ensure coverage for the storage module that was moved from daemon to SDK.
"""

import tempfile
from pathlib import Path

import pytest

from athena.storage import LocalStorageBackend, MemoryStorageBackend
from athena.storage.local import compute_content_hash, compute_file_hash


class TestMemoryStorageBackend:
    """Tests for in-memory storage backend."""

    @pytest.fixture
    def storage(self):
        return MemoryStorageBackend()

    @pytest.mark.asyncio
    async def test_put_and_get(self, storage):
        """Test storing and retrieving data."""
        key = "test-key"
        data = b"hello world"

        path = await storage.put(key, data)
        assert path == f"memory://{key}"

        retrieved = await storage.get(key)
        assert retrieved == data

    @pytest.mark.asyncio
    async def test_exists(self, storage):
        """Test checking key existence."""
        assert not await storage.exists("nonexistent")

        await storage.put("exists", b"data")
        assert await storage.exists("exists")

    @pytest.mark.asyncio
    async def test_delete(self, storage):
        """Test deleting data."""
        await storage.put("to-delete", b"data")
        assert await storage.exists("to-delete")

        result = await storage.delete("to-delete")
        assert result is True
        assert not await storage.exists("to-delete")

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, storage):
        """Test deleting nonexistent key."""
        result = await storage.delete("nonexistent")
        assert result is False

    @pytest.mark.asyncio
    async def test_get_nonexistent(self, storage):
        """Test getting nonexistent key raises KeyError."""
        with pytest.raises(KeyError):
            await storage.get("nonexistent")

    @pytest.mark.asyncio
    async def test_put_file(self, storage):
        """Test storing a file."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"file content")
            file_path = Path(f.name)

        try:
            await storage.put_file("file-key", file_path)
            retrieved = await storage.get("file-key")
            assert retrieved == b"file content"
        finally:
            file_path.unlink()

    @pytest.mark.asyncio
    async def test_get_to_file(self, storage):
        """Test retrieving data to file."""
        await storage.put("key", b"file data")

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "output.bin"
            await storage.get_to_file("key", file_path)

            assert file_path.exists()
            assert file_path.read_bytes() == b"file data"

    @pytest.mark.asyncio
    async def test_clear(self, storage):
        """Test clearing all data."""
        await storage.put("key1", b"data1")
        await storage.put("key2", b"data2")

        assert storage.size() == 2
        storage.clear()
        assert storage.size() == 0

    def test_provider_name(self, storage):
        """Test provider name."""
        assert storage.provider_name == "memory"

    @pytest.mark.asyncio
    async def test_get_url(self, storage):
        """Test getting URL returns memory URL."""
        await storage.put("url-key", b"data")
        url = await storage.get_url("url-key")
        assert url == "memory://url-key"


class TestLocalStorageBackend:
    """Tests for local filesystem storage backend."""

    @pytest.fixture
    def storage(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield LocalStorageBackend(tmpdir)

    @pytest.mark.asyncio
    async def test_put_and_get(self, storage):
        """Test storing and retrieving data."""
        key = "abcd1234"
        data = b"hello world"

        path = await storage.put(key, data)
        assert Path(path).exists()

        retrieved = await storage.get(key)
        assert retrieved == data

    @pytest.mark.asyncio
    async def test_exists(self, storage):
        """Test checking key existence."""
        assert not await storage.exists("nonexistent")

        await storage.put("abcd5678", b"data")
        assert await storage.exists("abcd5678")

    @pytest.mark.asyncio
    async def test_delete(self, storage):
        """Test deleting data."""
        await storage.put("abcd0000", b"data")
        assert await storage.exists("abcd0000")

        result = await storage.delete("abcd0000")
        assert result is True
        assert not await storage.exists("abcd0000")

    @pytest.mark.asyncio
    async def test_get_url(self, storage):
        """Test getting file URL."""
        await storage.put("abcd1111", b"data")
        url = await storage.get_url("abcd1111")
        assert url.startswith("file://")

    @pytest.mark.asyncio
    async def test_sharding(self, storage):
        """Test that keys are sharded into subdirectories."""
        key = "abcdef123456"
        await storage.put(key, b"data")

        # Check sharding structure: base/ab/cd/abcdef123456
        expected_path = storage.base_path / "ab" / "cd" / key
        assert expected_path.exists()

    def test_provider_name(self, storage):
        """Test provider name."""
        assert storage.provider_name == "local"

    @pytest.mark.asyncio
    async def test_put_file(self, storage):
        """Test storing a file."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"file content from disk")
            file_path = Path(f.name)

        try:
            key = "abcd2222"
            await storage.put_file(key, file_path)
            retrieved = await storage.get(key)
            assert retrieved == b"file content from disk"
        finally:
            file_path.unlink()

    @pytest.mark.asyncio
    async def test_get_to_file(self, storage):
        """Test retrieving data to file."""
        key = "abcd3333"
        await storage.put(key, b"data to file")

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "output.bin"
            await storage.get_to_file(key, file_path)

            assert file_path.exists()
            assert file_path.read_bytes() == b"data to file"

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, storage):
        """Test deleting nonexistent key returns False."""
        result = await storage.delete("nonexistent")
        assert result is False


class TestContentHash:
    """Tests for content hashing utilities."""

    def test_compute_content_hash(self):
        """Test computing hash of bytes."""
        data = b"hello world"
        hash1 = compute_content_hash(data)
        hash2 = compute_content_hash(data)

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 hex

    def test_different_data_different_hash(self):
        """Test that different data produces different hashes."""
        hash1 = compute_content_hash(b"data1")
        hash2 = compute_content_hash(b"data2")
        assert hash1 != hash2

    @pytest.mark.asyncio
    async def test_compute_file_hash(self):
        """Test computing hash of a file."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"file content")
            file_path = Path(f.name)

        try:
            file_hash = await compute_file_hash(file_path)
            data_hash = compute_content_hash(b"file content")
            assert file_hash == data_hash
        finally:
            file_path.unlink()


class TestLocalStoragePermissions:
    """Tests for local storage file permissions."""

    @pytest.mark.asyncio
    async def test_local_storage_permissions(self):
        """Test that files created by local storage have correct permissions."""
        import os
        import stat

        with tempfile.TemporaryDirectory() as tmpdir:
            storage = LocalStorageBackend(tmpdir)
            key = "abcd1234"
            data = b"test data"

            path_str = await storage.put(key, data)
            path = Path(path_str)

            # Check the file exists
            assert path.exists()

            # Get file permissions
            file_stat = os.stat(path)
            mode = file_stat.st_mode

            # File should be readable by owner
            assert mode & stat.S_IRUSR, "File should be readable by owner"

            # File should be writable by owner
            assert mode & stat.S_IWUSR, "File should be writable by owner"

            # File should NOT be world-writable (security check)
            assert not (mode & stat.S_IWOTH), "File should not be world-writable"


class TestStorageNotFoundError:
    """Tests for storage not found error handling."""

    @pytest.mark.asyncio
    async def test_memory_storage_not_found_error(self):
        """Test that reading a missing key from memory storage raises KeyError."""
        storage = MemoryStorageBackend()
        with pytest.raises(KeyError, match="Key not found: nonexistent-key"):
            await storage.get("nonexistent-key")

    @pytest.mark.asyncio
    async def test_local_storage_not_found_error(self):
        """Test that reading a missing key from local storage raises KeyError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = LocalStorageBackend(tmpdir)
            with pytest.raises(KeyError, match="Key not found: nonexistent-key"):
                await storage.get("nonexistent-key")


class TestStorageOverwriteBehavior:
    """Tests for storage overwrite behavior."""

    @pytest.mark.asyncio
    async def test_memory_storage_overwrite_behavior(self):
        """Test that writing to an existing key in memory storage overwrites the data."""
        storage = MemoryStorageBackend()
        key = "overwrite-key"

        # Write initial data
        await storage.put(key, b"initial data")
        assert await storage.get(key) == b"initial data"

        # Write new data to same key
        await storage.put(key, b"overwritten data")
        assert await storage.get(key) == b"overwritten data"

    @pytest.mark.asyncio
    async def test_local_storage_overwrite_behavior(self):
        """Test that writing to an existing key in local storage overwrites the data."""
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = LocalStorageBackend(tmpdir)
            key = "abcd5678"

            # Write initial data
            await storage.put(key, b"initial data")
            assert await storage.get(key) == b"initial data"

            # Write new data to same key
            await storage.put(key, b"overwritten data")
            assert await storage.get(key) == b"overwritten data"


class TestMemoryStorageIsolation:
    """Tests for memory storage instance isolation."""

    @pytest.mark.asyncio
    async def test_memory_storage_isolation(self):
        """Test that different MemoryStorageBackend instances don't share data."""
        storage1 = MemoryStorageBackend()
        storage2 = MemoryStorageBackend()

        # Write to first instance
        await storage1.put("key1", b"data from storage1")

        # First instance should have the data
        assert await storage1.exists("key1")
        assert await storage1.get("key1") == b"data from storage1"

        # Second instance should NOT have the data
        assert not await storage2.exists("key1")
        with pytest.raises(KeyError):
            await storage2.get("key1")

        # Write to second instance with same key
        await storage2.put("key1", b"data from storage2")

        # Each instance should have its own data
        assert await storage1.get("key1") == b"data from storage1"
        assert await storage2.get("key1") == b"data from storage2"

    @pytest.mark.asyncio
    async def test_memory_storage_isolation_multiple_keys(self):
        """Test isolation with multiple keys across instances."""
        storage1 = MemoryStorageBackend()
        storage2 = MemoryStorageBackend()
        storage3 = MemoryStorageBackend()

        # Each instance gets different data
        await storage1.put("shared-key", b"instance1")
        await storage2.put("shared-key", b"instance2")
        await storage3.put("shared-key", b"instance3")

        # Verify isolation
        assert await storage1.get("shared-key") == b"instance1"
        assert await storage2.get("shared-key") == b"instance2"
        assert await storage3.get("shared-key") == b"instance3"

        # Verify sizes are independent
        assert storage1.size() == 1
        assert storage2.size() == 1
        assert storage3.size() == 1

        # Clear one doesn't affect others
        storage1.clear()
        assert storage1.size() == 0
        assert storage2.size() == 1
        assert storage3.size() == 1
