"""Tests for WorkspaceScanner."""

from pathlib import Path

import pytest

from athena.discovery.scanner import WorkspaceScanner, scan_workspace


@pytest.fixture
def mock_workspace(tmp_path: Path) -> Path:
    """Create a mock workspace with blocks."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    # Create blocks directory
    blocks_dir = workspace / "blocks"
    blocks_dir.mkdir()

    # Create a block file
    (blocks_dir / "train_vae.py").write_text(
        '''
from pydantic import BaseModel
from athena import block, BlockContext, ArtifactRef


class VAEConfig(BaseModel):
    epochs: int = 100


@block(
    name="TrainVAE",
    description="Train a VAE model",
    inputs=["data"],
    outputs=["checkpoint", "samples"],
    config=VAEConfig,
)
async def train_vae(ctx: BlockContext, config: VAEConfig) -> dict:
    """Train VAE model."""
    return {}
'''
    )

    # Create another block
    (blocks_dir / "train_ldm.py").write_text(
        '''
from pydantic import BaseModel
from athena import block, BlockContext, ArtifactRef


class LDMConfig(BaseModel):
    epochs: int = 50


@block(
    name="TrainLDM",
    description="Train a LDM model",
    inputs=["vae", "data"],
    outputs=["checkpoint"],
    config=LDMConfig,
)
async def train_ldm(ctx: BlockContext, config: LDMConfig) -> dict:
    """Train LDM model."""
    return {}
'''
    )

    # Create a file that should be skipped (no decorators)
    (workspace / "utils.py").write_text(
        """
def helper_function():
    return 42
"""
    )

    # Create a .venv directory that should be skipped
    venv_dir = workspace / ".venv"
    venv_dir.mkdir()
    (venv_dir / "some_package.py").write_text(
        """
# This should be skipped
from athena import block
@block(name="ShouldBeSkipped")
async def should_be_skipped():
    pass
"""
    )

    return workspace


class TestWorkspaceScanner:
    """Tests for WorkspaceScanner."""

    def test_scanner_finds_blocks(self, mock_workspace: Path) -> None:
        """Test that scanner finds decorated blocks."""
        scanner = WorkspaceScanner(mock_workspace)
        registry = scanner.scan()

        assert len(registry.blocks) == 2
        assert len(registry.scan_errors) == 0

        block_names = {b.name for b in registry.blocks}
        assert "TrainVAE" in block_names
        assert "TrainLDM" in block_names

    def test_scanner_captures_block_details(self, mock_workspace: Path) -> None:
        """Test that scanner captures block inputs/outputs."""
        scanner = WorkspaceScanner(mock_workspace)
        registry = scanner.scan()

        vae_block = next(b for b in registry.blocks if b.name == "TrainVAE")

        assert len(vae_block.inputs) == 1
        assert vae_block.inputs[0].name == "data"
        assert len(vae_block.outputs) == 2
        output_names = {o.name for o in vae_block.outputs}
        assert "checkpoint" in output_names
        assert "samples" in output_names

    def test_scanner_captures_relative_paths(self, mock_workspace: Path) -> None:
        """Test that scanner captures relative file paths."""
        scanner = WorkspaceScanner(mock_workspace)
        registry = scanner.scan()

        vae_block = next(b for b in registry.blocks if b.name == "TrainVAE")
        assert vae_block.file_path == "blocks/train_vae.py"
        assert vae_block.function_name == "train_vae"

    def test_scanner_skips_venv(self, mock_workspace: Path) -> None:
        """Test that scanner skips .venv directory."""
        scanner = WorkspaceScanner(mock_workspace)
        registry = scanner.scan()

        block_names = {b.name for b in registry.blocks}
        assert "ShouldBeSkipped" not in block_names

    def test_scanner_sets_workspace_path(self, mock_workspace: Path) -> None:
        """Test that scanner sets workspace path in registry."""
        scanner = WorkspaceScanner(mock_workspace)
        registry = scanner.scan()

        assert registry.workspace == str(mock_workspace.resolve())

    def test_scan_workspace_convenience(self, mock_workspace: Path) -> None:
        """Test scan_workspace convenience function."""
        registry = scan_workspace(mock_workspace)

        assert len(registry.blocks) == 2


class TestScannerEdgeCases:
    """Tests for scanner edge cases."""

    def test_empty_workspace(self, tmp_path: Path) -> None:
        """Test scanning empty workspace."""
        scanner = WorkspaceScanner(tmp_path)
        registry = scanner.scan()

        assert len(registry.blocks) == 0

    def test_workspace_with_syntax_errors(self, tmp_path: Path) -> None:
        """Test that scanner handles files with syntax errors."""
        workspace = tmp_path / "workspace"
        workspace.mkdir()

        (workspace / "bad_syntax.py").write_text(
            """
def broken(:
    pass
"""
        )

        # Also add a valid block file
        (workspace / "good.py").write_text(
            """
from athena import block, BlockContext

@block(name="GoodBlock")
async def good_block(ctx: BlockContext) -> dict:
    return {}
"""
        )

        scanner = WorkspaceScanner(workspace)
        registry = scanner.scan()

        # Should find the good block but skip the bad file
        assert len(registry.blocks) == 1
        assert registry.blocks[0].name == "GoodBlock"

    def test_workspace_with_import_errors(self, tmp_path: Path) -> None:
        """Test that scanner handles files with import errors."""
        workspace = tmp_path / "workspace"
        workspace.mkdir()

        (workspace / "import_error.py").write_text(
            """
from nonexistent_module import something
from athena import block, BlockContext

@block(name="WontLoad")
async def wont_load(ctx: BlockContext) -> dict:
    return {}
"""
        )

        scanner = WorkspaceScanner(workspace)
        registry = scanner.scan()

        # Should handle the import error gracefully
        assert len(registry.blocks) == 0

        # scan_errors should capture the failure with actual error message
        assert len(registry.scan_errors) == 1
        assert registry.scan_errors[0]["file"] == "import_error.py"
        assert "wont_load" in registry.scan_errors[0]["functions"]
        assert "nonexistent_module" in registry.scan_errors[0]["error"]
