"""Tests for SDK types."""

from uuid import uuid4

import pytest

from athena.types import ArtifactRef, BlockConfig, BlockInput, BlockOutput, BlockSpec


class TestArtifactRef:
    """Tests for ArtifactRef."""

    def test_create_artifact_ref(self) -> None:
        """Test creating an ArtifactRef."""
        artifact_id = uuid4()
        ref = ArtifactRef(
            artifact_id=artifact_id,
            schema_type="vae_checkpoint",
            name="checkpoint.pt",
        )

        assert ref.artifact_id == artifact_id
        assert ref.schema_type == "vae_checkpoint"
        assert ref.name == "checkpoint.pt"

    def test_artifact_ref_is_frozen(self) -> None:
        """Test that ArtifactRef is immutable."""
        from pydantic import ValidationError

        ref = ArtifactRef(artifact_id=uuid4())

        with pytest.raises(ValidationError):  # Pydantic v2 raises ValidationError for frozen model
            ref.artifact_id = uuid4()  # type: ignore

    def test_artifact_ref_str(self) -> None:
        """Test ArtifactRef string representation."""
        artifact_id = uuid4()
        ref = ArtifactRef(artifact_id=artifact_id)

        assert str(artifact_id) in str(ref)


class TestBlockConfig:
    """Tests for BlockConfig."""

    def test_block_config_allows_extra(self) -> None:
        """Test that BlockConfig allows extra fields."""
        # BlockConfig uses extra="allow" so extra fields go to model_extra
        # The type checker doesn't know about these dynamic fields
        config = BlockConfig.model_validate({"epochs": 100, "learning_rate": 0.001})

        assert config.model_extra is not None
        assert config.model_extra["epochs"] == 100
        assert config.model_extra["learning_rate"] == 0.001


class TestBlockSpec:
    """Tests for BlockSpec."""

    def test_create_block_spec(self) -> None:
        """Test creating a BlockSpec."""
        spec = BlockSpec(
            name="TrainVAE",
            description="Train a VAE model",
            inputs=[
                BlockInput(name="data", type="ArtifactRef", required=True),
            ],
            outputs=[
                BlockOutput(name="checkpoint", type="ArtifactRef"),
            ],
        )

        assert spec.name == "TrainVAE"
        assert len(spec.inputs) == 1
        assert len(spec.outputs) == 1
        assert spec.inputs[0].name == "data"
        assert spec.outputs[0].name == "checkpoint"
