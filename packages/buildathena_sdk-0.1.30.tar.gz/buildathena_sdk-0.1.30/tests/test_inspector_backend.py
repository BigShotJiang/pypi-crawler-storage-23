"""Tests for inspector backend protocol."""

from typing import Any

import pytest

from athena.inspector_backend import (
    InspectorContext,
    get_inspector_backend_marker,
    inspector_backend,
    is_inspector_backend,
)


class TestInspectorContext:
    """Tests for InspectorContext dataclass."""

    def test_context_creation(self) -> None:
        """Test InspectorContext can be created with required fields."""
        ctx = InspectorContext(
            artifacts={"model": "local://abc123"},
            config={"param": "value"},
            run_id="run-123",
        )

        assert ctx.artifacts == {"model": "local://abc123"}
        assert ctx.config == {"param": "value"}
        assert ctx.run_id == "run-123"
        assert ctx.node_id is None
        assert ctx.workspace_path is None

    def test_context_with_optional_fields(self) -> None:
        """Test InspectorContext with all fields."""
        ctx = InspectorContext(
            artifacts={"checkpoint": "file:///path/to/model.pt"},
            config={},
            run_id="run-456",
            node_id="train_vae",
            workspace_path="/workspace",
        )

        assert ctx.node_id == "train_vae"
        assert ctx.workspace_path == "/workspace"


class TestInspectorBackendDecorator:
    """Tests for the @inspector_backend decorator."""

    def test_decorator_marks_class(self) -> None:
        """Test that @inspector_backend marks the class."""

        @inspector_backend
        class MyBackend:
            async def initialize(self, ctx: InspectorContext) -> None:
                pass

            async def handle_message(self, _msg: dict[str, Any]) -> dict[str, Any]:
                return {}

            async def cleanup(self) -> None:
                pass

        assert get_inspector_backend_marker(MyBackend) is True

    def test_unmarked_class_not_backend(self) -> None:
        """Test that unmarked classes are not marked as backends."""

        class NotABackend:
            pass

        assert get_inspector_backend_marker(NotABackend) is False

    def test_decorator_preserves_class(self) -> None:
        """Test that decorator preserves class functionality."""

        @inspector_backend
        class CounterBackend:
            def __init__(self) -> None:
                self.count = 0

            async def initialize(self, _ctx: InspectorContext) -> None:
                self.count = 1

            async def handle_message(self, _msg: dict[str, Any]) -> dict[str, Any]:
                self.count += 1
                return {"count": self.count}

            async def cleanup(self) -> None:
                self.count = 0

        backend = CounterBackend()
        assert backend.count == 0


class TestInspectorBackendProtocol:
    """Tests for the InspectorBackendProtocol."""

    def test_protocol_check_with_implementation(self) -> None:
        """Test is_inspector_backend with implementing class."""

        class ValidBackend:
            async def initialize(self, ctx: InspectorContext) -> None:
                pass

            async def handle_message(self, _msg: dict[str, Any]) -> dict[str, Any]:
                return {}

            async def cleanup(self) -> None:
                pass

        backend = ValidBackend()
        assert is_inspector_backend(backend) is True

    def test_protocol_check_with_partial_implementation(self) -> None:
        """Test is_inspector_backend with partial implementation."""

        class PartialBackend:
            async def initialize(self, ctx: InspectorContext) -> None:
                pass

            # Missing handle_message and cleanup

        backend = PartialBackend()
        assert is_inspector_backend(backend) is False

    def test_protocol_check_with_non_backend(self) -> None:
        """Test is_inspector_backend with non-backend object."""

        class NotABackend:
            def some_method(self) -> None:
                pass

        obj = NotABackend()
        assert is_inspector_backend(obj) is False

    def test_protocol_check_with_primitive(self) -> None:
        """Test is_inspector_backend with primitive types."""
        assert is_inspector_backend("string") is False
        assert is_inspector_backend(123) is False
        assert is_inspector_backend(None) is False

    @pytest.mark.asyncio
    async def test_decorated_backend_implements_protocol(self) -> None:
        """Test that decorated backend can be used as protocol implementation."""

        @inspector_backend
        class WorkingBackend:
            def __init__(self) -> None:
                self.initialized = False
                self.messages: list[dict[str, Any]] = []

            async def initialize(self, ctx: InspectorContext) -> None:
                self.initialized = True
                self.ctx = ctx

            async def handle_message(self, msg: dict[str, Any]) -> dict[str, Any]:
                self.messages.append(msg)
                return {"received": msg.get("data")}

            async def cleanup(self) -> None:
                self.initialized = False
                self.messages.clear()

        backend = WorkingBackend()
        assert is_inspector_backend(backend)
        assert get_inspector_backend_marker(WorkingBackend)

        # Test lifecycle
        ctx = InspectorContext(
            artifacts={"test": "local://test123"},
            config={},
            run_id="test-run",
        )

        await backend.initialize(ctx)
        assert backend.initialized is True

        response = await backend.handle_message({"data": "hello"})
        assert response == {"received": "hello"}
        assert len(backend.messages) == 1

        await backend.cleanup()
        assert backend.initialized is False
        assert len(backend.messages) == 0
