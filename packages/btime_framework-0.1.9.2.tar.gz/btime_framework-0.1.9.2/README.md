1° - Instale a lib:
    pip install Btime_framework




2° - Exemplos de inicio (copia e modifica no seu código):

    import btime_framework as BT
    from btime_framework import By  # Opcional

    class Framework:
        def __init__(self):
            self.sys = BT.System()  # Classe para opções que envolvem sistema (pdf, janelas, arquivos...)
            self.instance = BT.Instancedriver(Browser="Chrome")  # Essa é a instância do navegador, classe mestre
            self.options = self.instance.initialize_options()
            self.driver = None
            self.EL= None

        def inicialize_driver(self):

            # Caso queria adicionar argumentos específicos (antes de iniciar o driver)
            self.instance.arguments.add_new_argument('--disable-blink-features=AutomationControlled')  
            # self.instance.arguments.add_new_argument

            # O driver já vem com argumentos padrões para evitar detecções e bugs
            self.driver = self.instance.initialize_driver(maximize=True)

            # Essa é a classe que agrupa todas as formas de detecção de elementos
            self.EL = self.instance.elements

    class Scrapping_or_another_application(Framework):
        def __init__(self):
            super().__init__()
            self.inicialize_driver()

        def run(self):
            self.driver.get('https://www.google.com/')

            self.EL.find_element_with_wait(By.ID, 'APjFqb').send_keys('Example')
            self.EL.find_element_with_wait(By.XPATH, '//div[*[1][self::center]]//input[@value="Estou com sorte"]').click()
            # ...

    if __name__ == "__main__":
        bot = Scrapping_or_another_application()
        bot.run()




3° - O framework usa diversas libs e importa dinamicamente, para importar as libs basta usar os comandos abaixo:
   
   CMD
   - cd C:\Users\SeuUsuario\Documents\SeuProjeto
   - bt -fi SeuArquivo.py

Nisso ele vai te retornar todos os imports que você precisa
