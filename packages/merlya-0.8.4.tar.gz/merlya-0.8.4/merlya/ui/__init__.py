"""
Merlya UI - Console user interface.

Rich-based console with markdown rendering and autocompletion.
"""

from merlya.ui.console import ConsoleUI

__all__ = ["ConsoleUI"]
