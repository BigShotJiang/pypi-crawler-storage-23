"""Tests for provisioner state tracking."""
