# Basileus CLI

CLI for deploying Basileus autonomous prediction market agents on Base.

## Install

```bash
pip install basileus
```

## Usage

```bash
basileus deploy
```
