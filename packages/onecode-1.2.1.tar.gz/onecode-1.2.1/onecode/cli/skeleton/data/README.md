## Info

Default folder for:
* searching input data
* output data (typically under `data/outputs`)
