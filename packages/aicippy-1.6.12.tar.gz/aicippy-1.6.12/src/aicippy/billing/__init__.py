"""
Billing module for subscription plan integration.

Provides plan validation, credit management, and subscription enforcement
for AiCippy CLI access. Supports both the AiVibe platform API (primary)
and direct DynamoDB access (legacy fallback). Only users with an active
CHAKRA plan ($33/month, 250 credits) can use AiCippy. Admin users bypass
all restrictions.
"""

from __future__ import annotations

from aicippy.billing.credit_manager import CreditManager
from aicippy.billing.models import CreditTransaction, PlanInfo, PlanStatus
from aicippy.billing.plan_validator import PlanValidator

__all__ = [
    "CreditManager",
    "CreditTransaction",
    "PlanInfo",
    "PlanStatus",
    "PlanValidator",
]
