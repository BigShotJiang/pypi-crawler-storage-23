"""
AiCippy Installer Package.

Provides comprehensive cross-platform installation with:
- Automatic dependency detection and installation
- System-level permissions configuration
- Environment variable management
- Visual progress with animations
- Session management with auto-login timeout
"""

from __future__ import annotations

from aicippy.installer.auto_updater import (
    AutoUpdater,
    get_auto_updater,
)
from aicippy.installer.main import (
    CURRENT_VERSION,
    InstallationResult,
    VersionInfo,
    check_latest_version,
    get_installation_info,
    install_aicippy,
    perform_upgrade,
    uninstall_aicippy,
    upgrade_aicippy,
    verify_installation,
)
from aicippy.installer.platform_detect import (
    Architecture,
    OperatingSystem,
    PlatformInfo,
    ShellType,
    detect_platform,
)
from aicippy.installer.session_manager import (
    SessionInfo,
    SessionManager,
    SessionValidationResult,
    cleanup_expired_sessions,
    create_session,
    find_active_session_for_email,
    get_current_user,
    has_any_active_session,
    invalidate_session,
    list_all_sessions,
    needs_login,
    validate_session,
)

__all__ = [
    # Version info
    "CURRENT_VERSION",
    "Architecture",
    # Auto-updater
    "AutoUpdater",
    "InstallationResult",
    "OperatingSystem",
    "PlatformInfo",
    "SessionInfo",
    # Session management
    "SessionManager",
    "SessionValidationResult",
    "ShellType",
    "VersionInfo",
    "check_latest_version",
    "cleanup_expired_sessions",
    "create_session",
    # Platform detection
    "detect_platform",
    "find_active_session_for_email",
    "get_auto_updater",
    "get_current_user",
    "get_installation_info",
    "has_any_active_session",
    # Main installer functions
    "install_aicippy",
    "invalidate_session",
    "list_all_sessions",
    "needs_login",
    "perform_upgrade",
    "uninstall_aicippy",
    "upgrade_aicippy",
    "validate_session",
    "verify_installation",
]
