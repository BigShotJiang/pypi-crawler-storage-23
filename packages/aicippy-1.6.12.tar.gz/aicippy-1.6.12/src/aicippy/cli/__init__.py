"""
CLI module for AiCippy.

Provides the command-line interface using Typer with Rich UI.
Features:
- Interactive session with beautiful UI
- File upload with OS-native file browser dialogs
- Shell command execution with user input passthrough
- Workspace management
- AI command detection and automatic execution
- Human verification to prevent automated access
"""

from __future__ import annotations

from aicippy.cli.ai_command_executor import (
    AICommandExecutor,
    CommandExecutionResult,
    DetectedCommand,
    process_ai_response_with_commands,
)
from aicippy.cli.human_verify import (
    HumanVerifier,
    VerificationResult,
    is_likely_automated,
    require_human_verification,
)
from aicippy.cli.main import app
from aicippy.cli.shell_executor import (
    CommandResult,
    ShellExecutor,
    execute_command_with_passthrough,
)
from aicippy.cli.upload_manager import (
    UploadManager,
    UploadResult,
    get_uploads_directory,
    get_working_directory,
    open_file_dialog,
)

__all__ = [
    # AI command execution
    "AICommandExecutor",
    "CommandExecutionResult",
    "CommandResult",
    "DetectedCommand",
    # Human verification
    "HumanVerifier",
    # Shell execution
    "ShellExecutor",
    # Upload management
    "UploadManager",
    "UploadResult",
    "VerificationResult",
    "app",
    "execute_command_with_passthrough",
    "get_uploads_directory",
    "get_working_directory",
    "is_likely_automated",
    "open_file_dialog",
    "process_ai_response_with_commands",
    "require_human_verification",
]
