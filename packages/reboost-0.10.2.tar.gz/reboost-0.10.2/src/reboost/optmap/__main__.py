from __future__ import annotations

from .cli import optical_cli

if __name__ == "__main__":
    optical_cli()
