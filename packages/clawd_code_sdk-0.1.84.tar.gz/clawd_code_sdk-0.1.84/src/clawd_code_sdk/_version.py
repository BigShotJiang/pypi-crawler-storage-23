"""Version information for clawd-code-sdk."""

from __future__ import annotations

from importlib.metadata import version


__version__ = version("clawd-code-sdk")
