# Plugin for using LibreTranslate with ocr_translate

This is a plugin for the [ocr_translate](https://github.com/Crivella/ocr_translate) server for implementing translations using [LibreTranslate](https://github.com/LibreTranslate/LibreTranslate)

## Usage

### For versions of the server `>=0.7`

- Install through the server plugin manager **OR** manually by running `pip install ocr_translate-libretranslate`
