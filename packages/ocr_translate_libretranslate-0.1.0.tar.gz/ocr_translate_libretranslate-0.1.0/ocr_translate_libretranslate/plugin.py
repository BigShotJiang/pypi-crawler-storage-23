###################################################################################
# ocr_translate_LibreTranslate - a plugin for ocr_translate                               #
# Copyright (C) 2024-present Crivella                                             #
#                                                                                 #
# This program is free software: you can redistribute it and/or modify            #
# it under the terms of the GNU General Public License as published by            #
# the Free Software Foundation, either version 3 of the License.                  #
#                                                                                 #
# This program is distributed in the hope that it will be useful,                 #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                  #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                   #
# GNU General Public License for more details.                                    #
#                                                                                 #
# You should have received a copy of the GNU General Public License               #
# along with this program.  If not, see {http://www.gnu.org/licenses/}.           #
#                                                                                 #
# Home: https://github.com/Crivella/ocr_translate-LibreTranslate                          #
###################################################################################
"""Plugin to implement LibreTranslate (LLMs) based translations for ocr_translate"""

import logging
import os

import requests
from ocr_translate import models as m

DEFAULT_LIBTRANSLATE_ENDPOINT = 'http://127.0.0.1:5000/'

logger = logging.getLogger('plugin')


class LibreTranslateTSLModel(m.TSLModel):
    """TSLModel plugin to allow usage of LibreTranslate for translation."""
    class Meta:  # pylint: disable=missing-class-docstring
        proxy = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.endpoint = os.getenv('OCT_LIBTRANSLATE_ENDPOINT', DEFAULT_LIBTRANSLATE_ENDPOINT)

        api_key = os.getenv('OCT_LIBTRANSLATE_API_KEY', None)
        if api_key is not None:
            logger.info('Using API key for LibreTranslate authentication.')
        self.api_key = api_key

    def make_request(self, method: str, url: str, data: dict = None, headers: dict = None) -> dict:
        """Make a request to the LibreTranslate server."""
        res = requests.request(method, f'{self.endpoint}/{url}', json=data, headers=headers, timeout=120)
        if res.status_code != 200:
            logger.error(f'Failed to make request to LibreTranslate: {res.text}')
            raise requests.RequestException(f'Failed to make request to LibreTranslate: {res.text}')
        try:
            data = res.json()
        # Case of multiple json lines
        except Exception as exc:  # pylint: disable=bare-except
            body = res.content.decode('utf-8').replace('\n', '').replace(' ', '')
            if '"status":"success"' in body:
                return {'status': 'success'}
            raise requests.RequestException(f'Failed to parse response from LibreTranslate: {body}. Error: {exc}')
        return res.json()

    def get_model_list(self) -> list[dict]:
        """Get the list of models available inside LibreTranslate.

        Returns:
            list[dict]: List of models available in LibreTranslate.
        """
        return self.make_request('GET', 'tags').get('models', [])

    def load(self):
        """Do nothing as LibreTranslate only allow to select a subset of the supported langs at startup of the server"""

    def unload(self) -> None:
        """Unload the model from memory."""

    def _translate(
            self,
            tokens: list, src_lang: str, dst_lang: str, options: dict = None) -> str | list[str]:
        """Translate a text using a the loaded model.

        Args:
            tokens (list): list or list[list] of string tokens to be translated.
            lang_src (str): Source language.
            lang_dst (str): Destination language.
            options (dict, optional): Options for the translation. Defaults to {}.

        Raises:
            TypeError: If text is not a string or a list of strings.

        Returns:
            Union[str,list[str]]: Translated text. If text is a list, returns a list of translated strings.
        """
        if options is None:
            options = {}

        batch = True
        if isinstance(tokens[0], str):
            batch = False
            tokens = [tokens]
        sentences = [' '.join(_) for _ in tokens]

        data = {
            'q': sentences,
            'source': src_lang,
            'target': dst_lang,
        }
        headers = {
            'Content-Type': 'application/json',
        }

        if self.api_key is not None:
            data['api_key'] = self.api_key

        res = self.make_request('POST', 'translate', data, headers).get('translatedText', [])

        if not batch:
            res = res[0]

        return res
