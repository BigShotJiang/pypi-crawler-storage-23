# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.0] - 2026-03-06
## [0.6.11] - 2026-03-06
## [0.6.10] - 2026-03-06
## [0.6.9] - 2026-03-06
## [0.6.8] - 2026-03-06
## [0.6.7] - 2026-03-06
## [0.6.6] - 2026-03-06

### Dependencies

- Bump the minor-patch group across 1 directory with 10 updates (#59)
## [0.6.5] - 2026-03-06

### Dependencies

- Bump aquasecurity/trivy-action (#56)
## [0.6.4] - 2026-02-25

### Added

- update tools
- add commitlint

### Fixed

- argocd linter fixes
## [0.6.3] - 2026-02-24

### Added

- add release notes ci action

### Miscellaneous

- update changelog
- update dependabot config
## [Unreleased]

### Changed

- CI workflow hardening: added `timeout-minutes` to all 23 workflows, `concurrency` groups to 17 workflows
- CI: pinned unpinned actions in release pipeline (`anchore/sbom-action`, `actions/attest-build-provenance`) to SHA hashes
- CI: pinned tool versions (`bandit==1.9.3`, `build==1.4.0`) in CI/release workflows
- CI: added self-trigger paths to 6 workflows (bandit, hadolint, dockle, trivy, pip-audit, snyk)
- Added `make release` command for automated version bumping

## [0.6.1] - 2026-02-24

### Changed

- Added SonarCloud analysis workflow
- Bumped sigstore/cosign-installer from 3.9.1 to 4.0.0
- Bumped python Docker base from 3.13-slim to 3.14-slim
- Bumped actions/create-github-app-token from 2.0.6 to 2.2.1

## [0.6.0] - 2026-02-24

### Changed

- Bumped google/osv-scanner-action from 2.3.2 to 2.3.3
- Bumped bridgecrewio/checkov-action from 12.3080.0 to 12.3081.0
- Bumped actions/labeler from 5.0.0 to 6.0.1

## [0.5.9] - 2026-02-24

### Changed

- Extracted formatting logic from `server.py` into dedicated `formatters.py` module (server.py -39% LOC)
- Added 41 unit tests for formatters (305 total tests, 100% coverage)

## [0.5.8] - 2026-02-10

### Changed

- Enforce manual context selection — `select_kube_context` must be called before any validation tool (no implicit default context)
- Refactored Makefile to create and use local `.venv`

## [0.5.6] - 2026-02-07

### Added

- ArgoCD application management tools: `argocd_app_list`, `argocd_app_get`, `argocd_app_diff`
- ArgoCD uses `--core` mode (kubeconfig only, no ArgoCD server auth needed)
- ArgoCD CLI bundled in Docker image (v2.13.3)
- `KUBE_LINT_ARGOCD_TIMEOUT` environment variable for ArgoCD CLI timeout

### Changed

- Refactored all tests to use `pytest-mock` (`mocker` fixture) instead of `unittest.mock`
- Refactored release workflow

## [0.4.4] - 2026-02-07

### Added

- YAML syntax validation tool (`yaml_validate`) — catches syntax errors, duplicate keys, tab indentation without a cluster
- `py.typed` marker for PEP 561 inline type support
- mypy strict type checking with CI integration
- CHANGELOG.md

### Changed

- Replaced flake8 with ruff for linting (adds isort, pyupgrade, bugbear, simplify rules)
- Updated README with ArgoCD docs, Docker config, troubleshooting, and environment variables

### Removed

- `.flake8` configuration file

## [0.4.3] - 2026-02-03

### Fixed

- Release workflow fixes
- Removed Docker Hub publishing (GHCR only)

## [0.4.2] - 2026-01-28

### Changed

- Refactored error handling across all lint modules
- Refactored test suite structure
- Updated README
- Consolidated CI actions

## [0.4.1] - 2026-01-27

### Fixed

- CI and release workflow fixes
- OSV scanner configuration

## [0.4.0] - 2026-01-26

### Changed

- Migrated Docker base image from DHI to `python:3.13-slim`
- Updated CI actions and approver configuration
- Updated README

## [0.3.9] - 2026-01-20

### Fixed

- Release workflow logic updates

## [0.3.8] - 2026-01-19

### Changed

- Bumped actions/stale from 9.1.0 to 10.1.1
- Bumped dessant/lock-threads from 5.0.1 to 6.0.0
- Bumped sigstore/cosign-installer
- Bumped actions/attest-build-provenance from 2 to 3
- Bumped actions/dependency-review-action

## [0.3.7] - 2026-01-18

### Fixed

- Security action updates
- Compliance issues addressed

## [0.3.6] - 2026-01-17

### Added

- Additional CI and quality actions (bandit, pip-audit, hadolint, gitleaks, dockle, checkov)

## [0.3.5] - 2026-01-15

### Added

- Housekeeping actions (stale, lock)
- Trivy container scanning

## [0.3.4] - 2026-01-14

### Added

- Supply chain security actions (scorecard, dependency-review, cosign)

### Fixed

- Codecov and CI permissions configuration

## [0.3.3] - 2026-01-13

### Fixed

- Release action updates

## [0.3.2] - 2026-01-12

### Fixed

- Release workflow trigger fixes

## [0.3.1] - 2026-01-12

### Fixed

- Publish step trigger on release

## [0.3.0] - 2026-01-11

### Added

- Kustomize overlay validation (`kustomize_dryrun` tool)
- Kubeconform offline schema validation (`kubeconform_validate` tool)
- Helm chart validation (`helm_dryrun` tool)
- Shared `dryrun` module to reduce code duplication

### Changed

- Refactored repetitive validation code into shared utilities

## [0.2.0] - 2026-01-10

### Added

- Initial release
- FluxCD manifest dry-run validation (`flux_dryrun` tool)
- Flux health check (`flux_check` tool)
- Flux reconciliation status (`flux_status` tool)
- Context selection (`select_kube_context`, `list_kube_contexts` tools)
- Docker image with kubectl, helm, flux, kubeconform
- CI pipeline with tests and coverage
- Release workflow with PyPI OIDC publishing

[Unreleased]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.6.1...HEAD
[0.6.1]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.5.9...v0.6.0
[0.5.9]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.5.8...v0.5.9
[0.5.8]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.5.6...v0.5.8
[0.5.6]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.4.4...v0.5.6
[0.4.4]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.4.3...v0.4.4
[0.4.3]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.9...v0.4.0
[0.3.9]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.8...v0.3.9
[0.3.8]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.7...v0.3.8
[0.3.7]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.6...v0.3.7
[0.3.6]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.5...v0.3.6
[0.3.5]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.4...v0.3.5
[0.3.4]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.3...v0.3.4
[0.3.3]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/sophotechlabs/kube-lint-mcp/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/sophotechlabs/kube-lint-mcp/releases/tag/v0.2.0
