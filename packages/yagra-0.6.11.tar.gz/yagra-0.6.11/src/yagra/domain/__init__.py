"""Package providing the domain layer for Yagra."""
