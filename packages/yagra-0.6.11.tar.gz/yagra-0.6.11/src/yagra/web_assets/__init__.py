"""Provides bundled static assets for the Web UI."""
