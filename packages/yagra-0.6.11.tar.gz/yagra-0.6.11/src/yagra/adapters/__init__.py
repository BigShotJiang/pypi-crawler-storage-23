"""Package providing the adapter layer for Yagra."""
