import numpy as np

print(np.arange(10))