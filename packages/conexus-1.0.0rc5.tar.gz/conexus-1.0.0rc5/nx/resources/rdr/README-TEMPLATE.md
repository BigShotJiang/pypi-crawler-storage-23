# Recommendation Decisioning Records (RDRs)

RDRs are specification prompts built through iterative research and refinement.

See the [RDR process documentation](https://github.com/cwensel/rdr) for the full workflow.

## Index

| ID | Title | Status | Type | Priority |
|----|-------|--------|------|----------|
