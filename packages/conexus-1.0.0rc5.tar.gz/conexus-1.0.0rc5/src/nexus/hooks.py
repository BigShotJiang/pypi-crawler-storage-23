# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Hal Hildebrand. All rights reserved.
"""SessionStart and SessionEnd hook logic for Claude Code integration."""
from __future__ import annotations

import subprocess
from pathlib import Path

import sqlite3

import structlog

from nexus.db.t2 import T2Database
from nexus.session import (
    generate_session_id, session_file_path, write_session_file,
    write_claude_session_id,
)


_log = structlog.get_logger()

# -- Helpers ------------------------------------------------------------------

def _default_db_path() -> Path:
    return Path.home() / ".config" / "nexus" / "memory.db"


def _open_t2() -> T2Database:
    return T2Database(_default_db_path())


def _open_t1(session_id: str):
    from nexus.db.t1 import T1Database
    return T1Database(session_id=session_id)


def _infer_repo() -> str:
    """Detect current repo name from git, or fall back to cwd name."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=True, timeout=10,
        )
        return Path(result.stdout.strip()).name
    except Exception:
        return Path.cwd().name


# -- SessionStart -------------------------------------------------------------

def session_start(claude_session_id: str | None = None) -> str:
    """Execute the SessionStart hook.

    1. Write stable session ID so all Bash subprocesses share one namespace.
       Uses the Claude session ID if provided (from hook stdin JSON), otherwise
       generates a UUID4. Written to both the flat current_session file and the
       legacy getsid-keyed file.
    2. Detect PM project via T2 query.
    3. If PM: inject computed PM resume (<=2000 chars) via pm_resume().
       Else: print recent memory summary (<=10 entries x 500 chars).

    Returns the output string to be printed.
    """
    session_id = claude_session_id or generate_session_id()
    # Write flat file — stable across all Bash subprocesses (thought, scratch)
    write_claude_session_id(session_id)
    # Write legacy getsid-keyed file — used by SessionEnd for T1 flush
    write_session_file(session_id)

    lines: list[str] = [f"Nexus ready. T1 scratch initialized (session: {session_id})."]

    repo = _infer_repo()
    try:
        with _open_t2() as db:
            # PM detection: check for BLOCKERS.md with 'pm' tag
            from nexus.pm import pm_resume
            blockers_row = db.get(project=repo, title="BLOCKERS.md")
            is_pm = blockers_row is not None and "pm" in (blockers_row.get("tags") or "")
            if is_pm:
                content = pm_resume(db, project=repo)
                if content:
                    lines.append(content)
            else:
                # Non-PM: recent memory summary
                entries = db.list_entries(project=repo)[:10]
                if entries:
                    lines.append(f"Recent memory ({repo}, last {len(entries)} entries):")
                    for e in entries:
                        lines.append(f"  - {e['title']} ({e.get('agent') or '-'}, {e.get('timestamp', '')[:10]})")
                else:
                    lines.append(f"No memory entries for '{repo}'.")
    except (sqlite3.Error, OSError):
        lines.append("(memory unavailable)")

    return "\n".join(lines)


# -- SessionEnd ---------------------------------------------------------------

def session_end() -> str:
    """Execute the SessionEnd hook.

    1. Flush flagged T1 entries to T2.
    2. Clear T1 session entries.
    3. Run T2 expire.
    4. Remove the session file.

    Returns a summary string.
    """
    session_file = session_file_path()

    # Read session ID so we can open T1
    try:
        session_id = session_file.read_text().strip() or None
    except FileNotFoundError:
        session_id = None

    flushed = 0
    expired = 0

    try:
        with _open_t2() as db:
            if session_id:
                t1 = _open_t1(session_id)
                for entry in t1.flagged_entries():
                    db.put(
                        project=entry["flush_project"],
                        title=entry["flush_title"],
                        content=entry["content"],
                        tags=entry.get("tags", ""),
                        ttl=None,
                    )
                    flushed += 1
                # Only clear T1 after all entries are successfully flushed to T2.
                # A finally: t1.clear() would wipe entries if db.put() raises, so
                # we intentionally clear only on full success.
                # If db.put() fails mid-loop, the already-flushed entries will be
                # re-flushed on the next session end — T2.put uses ON CONFLICT DO UPDATE
                # so duplicate flushes are idempotent (same project/title overwrites).
                t1.clear()

            expired = db.expire()
    except (sqlite3.Error, OSError) as exc:
        _log.warning("session_end: storage error during flush/expire", error=str(exc))

    # Remove session file
    try:
        session_file.unlink()
    except OSError:
        pass

    parts = [f"Session ended. Flushed {flushed} scratch entries. Expired {expired} memory entries."]
    return "\n".join(parts)
