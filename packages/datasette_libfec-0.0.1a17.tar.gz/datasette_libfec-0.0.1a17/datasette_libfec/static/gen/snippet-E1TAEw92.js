import{W as p,X as t,Y as c}from"./stores-Czp_dy3j.js";function l(s,a,...e){var r=new c(s);p(()=>{const n=a()??null;r.ensure(n,n&&(o=>n(o,...e)))},t)}export{l as s};
