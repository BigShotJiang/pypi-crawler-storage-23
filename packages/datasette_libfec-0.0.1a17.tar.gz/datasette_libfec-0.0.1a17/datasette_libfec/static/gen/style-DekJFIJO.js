import{t as y}from"./class-C5DDKbJD.js";function f(e,s,i,r){var l=e.__style;if(l!==s){var t=y(s);t==null?e.removeAttribute("style"):e.style.cssText=t,e.__style=s}return r}export{f as s};
