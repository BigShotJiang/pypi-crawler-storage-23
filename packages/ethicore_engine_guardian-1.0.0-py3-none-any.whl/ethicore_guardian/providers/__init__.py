"""
Ethicore Engine™ - Guardian SDK - Providers Package
AI provider integrations for Guardian SDK
"""

# This makes the providers directory a proper Python package
# Providers will be imported dynamically by Guardian when needed

__version__ = "1.0.0"