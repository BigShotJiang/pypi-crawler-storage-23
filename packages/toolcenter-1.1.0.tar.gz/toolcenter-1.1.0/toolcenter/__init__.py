"""ToolCenter Python SDK

Official Python client library for ToolCenter's web automation and utility APIs.
Provides easy access to screenshot capture, PDF generation, QR codes, metadata
extraction, and many other web-related services.

Example:
    >>> from toolcenter import ToolCenter
    >>> tc = ToolCenter('your-api-key')
    >>> result = tc.screenshot(url='https://example.com', width=1920)
"""

from .client import ToolCenter, ToolCenterError, AuthenticationError, RateLimitError

__version__ = '1.0.0'
__author__ = 'ToolCenter'
__email__ = 'hello@toolcenter.dev'

__all__ = [
    'ToolCenter',
    'ToolCenterError', 
    'AuthenticationError',
    'RateLimitError',
    '__version__'
]