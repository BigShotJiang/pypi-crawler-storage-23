#!/usr/bin/env python3
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="toolcenter",
    version="1.1.0",
    author="ToolCenter",
    author_email="hello@toolcenter.dev",
    description="Official Python SDK for ToolCenter's web automation and utility APIs",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/toolcenter-dev/sdk-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["requests>=2.20.0"],
)
