"""Neo Cortex MCP — dual mode memory tools.

Modes (controlled by ENV vars):
    - Proxy (default): forwards to neo-cortex HTTP API on port 5074
    - Embedded: CORTEX_DATA_DIR set → local CortexService + ChromaDB
    - Embedded + subscriber: CORTEX_DATA_DIR + MEMORY_HUB_URL set
      → also runs SignalR subscriber in daemon thread

Usage:
    python -m neo_cortex.mcp          # stdio transport (for Claude Code)
    python -m neo_cortex.mcp --http   # HTTP transport (for testing)
"""

import logging
import os
import sys
import threading
from pathlib import Path
from typing import Optional

import httpx
from fastmcp import FastMCP

logger = logging.getLogger("neo-cortex-mcp")

# --- ENV-based mode detection ---
_data_dir = os.environ.get("CORTEX_DATA_DIR")
_hub_url = os.environ.get("MEMORY_HUB_URL")
_embedded = _data_dir is not None

# --- Shared state ---
_cortex = None  # CortexService instance (embedded mode only)
_http = None    # httpx.Client (proxy mode only)

# --- Embedded mode init ---
if _embedded:
    from neo_cortex.subscriber import configure_paths

    configure_paths(_data_dir)
    Path(_data_dir).mkdir(parents=True, exist_ok=True)

    _init_error = None
    try:
        from neo_cortex import config
        from neo_cortex.classifier import GroqClassifier
        from neo_cortex.cortex import CortexService
        from neo_cortex.embedder import JinaEmbedder
        from neo_cortex.memory_index import MemoryIndex
        from neo_cortex.store import MemoryStore

        store = MemoryStore(config.CORTEX_DB_PATH, config.COLLECTION_NAME)
        embedder = JinaEmbedder(config.load_api_key("jina"))
        classifier = GroqClassifier(config.load_api_key("groq"))
        index = MemoryIndex(config.MEMORY_INDEX_DB_PATH)
        _cortex = CortexService(store, embedder, classifier, index=index)
        logger.info("Embedded mode: CortexService ready (data=%s)", _data_dir)
    except Exception as e:
        _init_error = str(e)
        logger.error("CortexService init failed: %s — tools will return errors", e)
        _cortex = None
else:
    # Proxy mode — connect to HTTP API
    from neo_cortex import config

    CORTEX_BASE = f"http://127.0.0.1:{config.CORTEX_PORT}"
    _http = httpx.Client(base_url=CORTEX_BASE, timeout=15.0)
    logger.info("Proxy mode: forwarding to %s", CORTEX_BASE)


def _check_embedded():
    """Raise clear error if embedded mode but cortex init failed."""
    if _embedded and _cortex is None:
        raise RuntimeError(f"CortexService init failed: {_init_error}. Check JINA_API_KEY and GROQ_API_KEY env vars.")


def _get(path: str, **params) -> dict:
    _check_embedded()
    resp = _http.get(path, params={k: v for k, v in params.items() if v is not None})
    resp.raise_for_status()
    return resp.json()


def _post(path: str, data: dict = None) -> dict:
    _check_embedded()
    resp = _http.post(path, json=data)
    resp.raise_for_status()
    return resp.json()


# --- Subscriber thread (embedded + hub_url) ---
def _start_subscriber(hub_url: str, cortex) -> threading.Thread:
    """Start SignalR subscriber in a daemon thread with its own asyncio loop."""
    import asyncio as _asyncio

    from neo_cortex.subscriber import TurnAccumulator

    async def _run():
        from pysignalr.client import SignalRClient

        client = SignalRClient(hub_url)
        accumulator = TurnAccumulator()

        async def on_user_message(args):
            data = args[0] if args else {}
            accumulator.on_user_message(data.get("sessionId", ""), data.get("text", ""))

        async def on_assistant_message(args):
            data = args[0] if args else {}
            accumulator.on_assistant_message(
                data.get("sessionId", ""), data.get("text", ""), data.get("model", "unknown"))

        async def on_tool_use(args):
            data = args[0] if args else {}
            accumulator.on_tool_use(data.get("sessionId", ""), data.get("toolName", ""))

        async def on_tool_result(args):
            logger.debug("ToolResult received")

        async def on_turn_complete(args):
            if not accumulator.is_complete:
                accumulator.reset()
                return
            from neo_cortex.models import IngestRequest
            req = IngestRequest(
                session_id=accumulator.session_id,
                question=accumulator.question,
                answer=accumulator.answer,
                model=accumulator.model,
                tools_used=accumulator.tools_used,
                turn_number=accumulator.turn_number,
            )
            try:
                memory_id = await cortex.ingest(req)
                if memory_id:
                    logger.info("Subscriber ingested: %s (turn %d)", memory_id, accumulator.turn_number)
            except Exception:
                logger.exception("Subscriber ingest failed for turn %d", accumulator.turn_number)
            accumulator.reset()

        client.on("MemoryUserMessage", on_user_message)
        client.on("MemoryAssistantMessage", on_assistant_message)
        client.on("MemoryToolUse", on_tool_use)
        client.on("MemoryToolResult", on_tool_result)
        client.on("MemoryTurnComplete", on_turn_complete)

        logger.info("Subscriber connecting to %s", hub_url)
        await client.run()

    def _thread_target():
        _asyncio.run(_run())

    t = threading.Thread(target=_thread_target, daemon=True, name="cortex-subscriber")
    t.start()
    return t


# --- MCP server ---
mcp = FastMCP(
    "neo-cortex",
    instructions="Neo's memory cortex. Semantic memory search, ingestion, dream cycles, and timeline.",
)


@mcp.tool()
async def memory_query(query: str, n: int = 5) -> dict:
    """Search past conversation memories by semantic similarity.

    Args:
        query: What to search for (natural language)
        n: Number of results to return (default 5)
    """
    if _cortex:
        result = await _cortex.recall(query, n=n, smart=True)
        return result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    return _get("/api/query", q=query, n=n, smart="true")


@mcp.tool()
async def memory_stats() -> dict:
    """Get cortex statistics: total memories, sessions, energy levels, dream count."""
    if _cortex:
        result = _cortex.stats()
        return result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    return _get("/api/stats")


@mcp.tool()
async def memory_dream() -> dict:
    """Run one dream cycle: boost high-energy memories, decay others."""
    if _cortex:
        result = await _cortex.dream()
        return result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    return _post("/api/dream")


@mcp.tool()
async def memory_ingest(turn: dict) -> dict:
    """Manually ingest a conversation turn into memory.

    Args:
        turn: JSON with session_id, question, answer, model, stats
    """
    if _cortex:
        from neo_cortex.models import IngestRequest
        req = IngestRequest(**turn)
        memory_id = await _cortex.ingest(req)
        return {"status": "ok", "id": memory_id}
    return _post("/api/ingest", data=turn)


@mcp.tool()
async def memory_timeline(n: int = 10, project: Optional[str] = None) -> dict:
    """Get most recent memories by timestamp (newest first).

    Use this at session start to load recent context, or to see what happened lately.

    Args:
        n: Number of recent memories to return (default 10)
        project: Optional filter by project name
    """
    if _cortex:
        result = await _cortex.timeline(n=n, project=project)
        return result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    return _get("/api/timeline", n=n, project=project)


@mcp.tool()
async def memory_search(query: str = "", project: Optional[str] = None,
                        activity: Optional[str] = None, n: int = 10) -> dict:
    """Search memory index. Returns compact results (title/project/date).
    Use memory_get for full details of specific memories.

    Args:
        query: Search text (or empty for recent)
        project: Filter by project name
        activity: Filter by activity type
        n: Max results
    """
    if _cortex:
        if hasattr(_cortex, '_index') and _cortex._index:
            results = _cortex._index.search_fts(query=query, project=project, activity=activity, n=n)
            return {"results": [r.__dict__ for r in results]}
        # Fallback: use recall
        result = await _cortex.recall(query or "recent", n=n)
        return result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    return _get("/api/search", q=query, project=project, activity=activity, n=n)


@mcp.tool()
async def memory_get(ids: str) -> dict:
    """Get full memory details by IDs (comma-separated).

    Args:
        ids: Comma-separated memory IDs (e.g. "v3_abc_1_12345,v3_def_2_67890")
    """
    if _cortex:
        if hasattr(_cortex, '_index') and _cortex._index:
            id_list = [i.strip() for i in ids.split(",")]
            records = _cortex._index.get_by_ids(id_list)
            return {"memories": [r.__dict__ for r in records]}
        return {"error": "memory_get requires SQLite index in embedded mode"}
    return _get("/api/memories", ids=ids)


# --- Entrypoint ---
def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    # Start subscriber if both env vars set
    if _hub_url and _cortex:
        _start_subscriber(_hub_url, _cortex)

    if "--http" in sys.argv:
        mcp.run(transport="streamable-http", host="127.0.0.1", port=5075)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
