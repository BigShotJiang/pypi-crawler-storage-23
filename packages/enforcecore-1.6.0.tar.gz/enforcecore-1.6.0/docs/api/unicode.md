# Unicode Normalization

::: enforcecore.redactor.unicode.normalize_unicode

::: enforcecore.redactor.unicode.normalize_homoglyphs

::: enforcecore.redactor.unicode.decode_encoded_pii

::: enforcecore.redactor.unicode.prepare_for_detection
