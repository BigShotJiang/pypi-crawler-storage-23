"""Tests for enforcecore.auditstore module."""
