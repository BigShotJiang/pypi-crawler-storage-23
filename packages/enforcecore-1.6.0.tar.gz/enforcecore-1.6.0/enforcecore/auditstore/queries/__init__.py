"""Compliance query templates for regulatory reporting."""

from .eu_ai_act import EUAIActQueries

__all__ = ["EUAIActQueries"]
