"""CLI entry point for TokenNuke MCP server."""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog='tokennuke',
        description='TokenNuke — Nuke your token usage. Intelligent code indexer MCP server.',
    )
    parser.add_argument(
        '--version',
        action='version',
        version=f'%(prog)s {__import__("tokennuke").__version__}',
    )
    parser.add_argument(
        '--transport',
        choices=['stdio', 'streamable-http'],
        default='stdio',
        help='MCP transport (default: stdio)',
    )
    parser.add_argument(
        '--port',
        type=int,
        default=5100,
        help='Port for streamable-http transport (default: 5100)',
    )
    parser.add_argument(
        '--data-dir',
        type=str,
        default=None,
        help='Directory for index databases (default: ~/.tokennuke)',
    )

    args = parser.parse_args()

    from tokennuke.server import create_server

    server = create_server(data_dir=args.data_dir)

    if args.transport == 'stdio':
        server.run(transport='stdio')
    else:
        server.run(transport='streamable-http', port=args.port)


if __name__ == '__main__':
    main()
