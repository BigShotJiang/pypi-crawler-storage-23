"""TokenNuke embedder — FastEmbed ONNX embeddings."""

from .embed import Embedder

__all__ = ['Embedder']
