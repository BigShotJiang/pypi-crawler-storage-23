"""TokenNuke — Nuke your token usage.

Intelligent code indexer with O(1) symbol retrieval, hybrid search,
and call graph analysis. Built as an MCP server for AI agents.
"""

__version__ = '0.2.0'
