# TokenNuke Strategic Next Steps

Based on competitive analysis vs Context Mode (98% savings competitor).

## The Gap

Context Mode beats TokenNuke on **one specific dimension**: transparent output filtering. They achieve this through:
1. PreToolUse hooks that intercept tool responses
2. Sandbox execution for large artifacts
3. 4x session extension proof (30min → 3hrs)

TokenNuke has superior code understanding (call graphs, semantic search, 10 languages) but doesn't compress tool outputs.

## Phase 1: Close the Output Filtering Gap (2-3 days)

### Add `compress_output` Tool
```python
@mcp.tool()
def compress_output(
    raw_output: str,
    output_type: str = "log" | "snapshot" | "diff" | "json",
    max_tokens: int = 500,
) -> str:
    """Compress any tool output before it enters context.
    
    Reduces 56 KB snapshots → 299 bytes (Context Mode style).
    Works with outputs from ANY MCP tool.
    """
    if output_type == "log":
        # Keep first 300 chars + tail + summary
        lines = raw_output.split('\n')
        return f"{lines[0]}\n...\n{lines[-1]}\n[{len(lines)} lines total]"
    elif output_type == "snapshot":
        # HTML snapshots: extract title + key elements
        return extract_key_elements(raw_output)
    elif output_type == "diff":
        # Diffs: keep hunks, drop context lines
        return compress_diff_hunks(raw_output)
    elif output_type == "json":
        # JSON: prune empty arrays, truncate strings > 100 chars
        return compress_json(raw_output)
```

**Impact**: Users can manually compress outputs. ~60% of Context Mode's win.

### Measure Session Duration
```python
# In server.py, track:
- tokens_used_so_far
- estimated_remaining_session
- warn_at_80_percent_budget

# Return in tool responses
```

**Impact**: Quantify actual session extension benefit.

### Update README
- Add "Output Compression" section
- Show before/after examples (56 KB → 299 bytes)
- Explain synergy with other tools

---

## Phase 2: Achieve Parity (1 week)

### Implement MCP PreToolUse Hook Pattern
```python
# If MCP protocol supports output hooks, use them
# Otherwise, create wrapper that intercepts outputs automatically

class TokenNukeWrapper:
    def __init__(self, mcp_server):
        self.mcp_server = mcp_server
    
    def call_tool(self, tool_name, *args):
        raw_result = self.mcp_server.call_tool(tool_name, *args)
        # Auto-compress if output is large
        if len(raw_result) > 5000:
            return self.compress_output(raw_result)
        return raw_result
```

**Why**: Matches Context Mode's transparent compression.

### Add Codebase Diff Analysis
```python
@mcp.tool()
def analyze_diff(
    repo_id: str,
    old_revision: str,  # "v1.0.0" or git hash
    new_revision: str,  # "HEAD" or git hash
) -> str:
    """Analyze code changes, return only CHANGED symbols.
    
    For PR reviews: returns just the functions/classes that changed.
    Ignores unchanged code.
    
    Returns:
    - File-by-file summary of changes
    - Symbols that were added/modified/deleted
    - Call graph impact (what else might break?)
    """
    # Git diff → parse AST → compare symbols → return only changed
```

**Impact**: Huge for code review workflows. Reduces review context by 70%.

### Benchmark Session Duration Gains
```python
# Run TokenNuke + Context Mode together in test session
# Measure: tokens used for same task
# Report: "TokenNuke + compress_output → X% savings vs raw approach"
```

---

## Phase 3: Differentiate (2+ weeks)

### Larger Embedding Model
Context Mode uses BM25 keyword matching. TokenNuke has 384-dim vector embeddings.
- Upgrade to 768-dim (better semantic understanding)
- Fine-tune on code (function names, docstrings)
- Measure improvement in `search_symbols` relevance

### Codebase Evolution Tracking
```python
@mcp.tool()
def track_change_history(repo_id: str, symbol: str) -> str:
    """Show how a symbol evolved over time.
    
    Returns:
    - 10 most recent versions (with diffs)
    - Who changed it and when
    - Why (commit message context)
    - Breaking changes timeline
    """
```

### Team-Wide Code Intelligence
```python
# Shared index across team
# Track who owns which symbols
# PR review suggestions based on ownership + impact
# Codebase health metrics
```

---

## Implementation Checklist

- [ ] Add `compress_output` tool
- [ ] Add session duration tracking
- [ ] Test 56 KB → 299 byte compression (match Context Mode)
- [ ] Update README with "Output Compression" section
- [ ] Measure actual session duration improvement
- [ ] Run benchmark: TokenNuke vs raw vs Context Mode
- [ ] Add `analyze_diff` tool
- [ ] Implement PreToolUse hook (if MCP protocol allows)
- [ ] Consider 768-dim embeddings
- [ ] Document synergy with other MCP tools

---

## Key Insight

Context Mode's biggest innovation isn't the 98% savings on one output type.
It's **transparency**: users don't have to think about compression.

TokenNuke should do the same:
- Auto-compress large outputs
- Transparent to user
- Works with ANY tool output
- Zero configuration

**Combined effect**: TokenNuke + Context Mode approach = 95%+ average savings across code retrieval + tool output compression.

---

## Competitive Positioning

**TokenNuke**: "Symbol intelligence engine"
- **What**: Understand code structure (call graphs, dependencies, types)
- **Why**: AI agents need to reason about code, not just read it
- **How**: Tree-sitter AST + vector embeddings + call graph analysis

**Context Mode**: "Output filtering layer"
- **What**: Compress ANY tool output before context
- **Why**: Reduce noise, extend session duration
- **How**: Sandbox execution + FTS5 + preprocessing

**Together**: Best-in-class code understanding + output filtering = unstoppable for code-heavy workflows.

