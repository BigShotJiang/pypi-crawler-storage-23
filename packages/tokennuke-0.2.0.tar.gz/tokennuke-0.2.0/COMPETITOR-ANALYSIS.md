# TokenNuke vs Context Mode: Competitive Analysis

## Executive Summary

**Context Mode** achieves 98% context savings vs TokenNuke's 92% through a fundamentally different architecture. While TokenNuke focuses on **intelligent retrieval** (finding the exact symbols you need), Context Mode focuses on **aggressive output filtering** (processing tool responses before they enter context).

The two approaches are **complementary, not competing**. Context Mode's wins are in tool output compression; TokenNuke's wins are in symbol discovery and code understanding.

---

## Technical Architecture Comparison

### TokenNuke: Symbol-First Retrieval
**Core Innovation**: O(1) byte-offset reads
- **Index**: Tree-sitter AST parsing → extract symbols (functions, classes, types)
- **Store**: SQLite with FTS5 + vector embeddings
- **Retrieve**: Seek directly to byte offset in source file
- **Search**: Hybrid (BM25 + semantic vectors via RRF)
- **Graph**: Call graph analysis (who calls this? what does this call?)

**Token Savings Mechanism**: Reduce *input* size by fetching only needed symbols instead of entire files.

**Example**:
```
Read entire file (500 lines):        ~4,000 tokens
file_outline + get_symbol approach:  ~200-400 tokens
Savings:                              90-95%
```

---

### Context Mode: Tool Output Filtering
**Core Innovation**: PreToolUse hooks + sandbox execution
1. **Sandbox Execution**: Tool calls spawn isolated subprocess
   - Captures stdout only
   - Transforms 56 KB Playwright snapshot → 299 bytes
   - Raw artifacts never reach Claude's context

2. **Knowledge Base Search**: SQLite FTS5 + BM25 ranking
   - Index markdown content
   - Return exact code blocks with heading hierarchy
   - Not summaries, actual indexed content

3. **Automatic Output Routing**: PreToolUse hook intercepts tool responses
   - No workflow changes needed
   - Compression is transparent to users

**Token Savings Mechanism**: Reduce *output* size by filtering tool responses before they enter context.

**Example**:
```
Raw Playwright snapshot:  56 KB
After filtering:          299 bytes
Savings:                  98%
Session extension:        ~30 min → ~3 hours (same token budget)
```

---

## Head-to-Head Comparison

| Dimension | TokenNuke | Context Mode | Winner |
|-----------|-----------|--------------|--------|
| **Search Paradigm** | Symbol-first retrieval | Output filtering | Depends on use case |
| **Index Type** | Code structure (tree-sitter AST) | Tool output + markdown FTS | Different purposes |
| **Search Speed** | O(1) byte seeks + RRF | FTS5 BM25 ranking | TokenNuke (predictable) |
| **Semantic Understanding** | Vector embeddings (384-dim) | BM25 keyword + stemming | TokenNuke (better search) |
| **Call Graph** | Yes (who calls what) | No | TokenNuke exclusive |
| **Languages Supported** | 10 languages | N/A (tool-agnostic) | TokenNuke specialized |
| **Configuration** | Requires per-repo setup | Transparent MCP hook | Context Mode (simpler) |
| **Output Compression** | N/A (input-focused) | 98% reduction | Context Mode exclusive |
| **Extensibility** | Fixed to code symbols | Works with ANY tool output | Context Mode (universal) |
| **Session Duration** | No stated improvement | ~4x longer (30min → 3hrs) | Context Mode (proven) |

---

## The 98% vs 92% Question

### TokenNuke's 92% Claim
- Reduces file reads via symbol retrieval
- Example: 500-line file → 200-400 token get_symbol call
- Savings: `(4000 - 400) / 4000 = 90-95%`
- More conservative claim: "80-95%"

### Context Mode's 98% Claim
- Compresses specific tool outputs (Playwright snapshots, log files, etc.)
- Example: 56 KB snapshot → 299 bytes = 0.5% retention
- Achieves 98% savings on **high-volume outputs**
- BUT: Only applies to certain tools (screenshots, large logs)
- Average across all tools likely lower

**Key Insight**: Context Mode's 98% is *local* to specific high-volume tool outputs. TokenNuke's 92% is *average* across all symbol retrieval.

---

## What Context Mode Has That TokenNuke Doesn't

### 1. **PreToolUse Hooks** (Biggest Advantage)
- Intercept tool responses BEFORE they enter context
- Automatic filtering (no workflow changes)
- Works with ANY MCP tool (not code-specific)

**TokenNuke equivalent**: Manual → use `get_symbol` instead of `cat file.txt`

### 2. **Transparent Output Compression**
- Playwright snapshots: 56 KB → 299 bytes
- Large logs: compressed before context
- Zero user configuration

**TokenNuke equivalent**: Requires knowing to use search_symbols instead of file_outline + reading entire file

### 3. **Session Duration Extension**
- Proven 4x extension (30 min → 3 hours same token budget)
- Direct measurement of practical impact
- TokenNuke doesn't provide session duration metrics

### 4. **Ten Language Runtimes**
- JS, Python, Shell, Ruby, Go, Rust, Java, Kotlin, etc.
- Auto-detection via Bun
- 3-5x speed gains from Bun execution

**TokenNuke**: Parser-based only (doesn't execute code)

---

## What TokenNuke Has That Context Mode Doesn't

### 1. **Call Graph Analysis** (Major Advantage)
- `get_callers`: Who calls this function?
- `get_callees`: What does this function call?
- Depth traversal (up to 5 levels)
- Essential for impact analysis and refactoring

**Context Mode**: No equivalent. Can't trace code dependencies.

### 2. **Symbol-Level Search**
- Search for "authentication middleware" → finds relevant functions
- Hybrid search (FTS5 + 384-dim vector embeddings)
- Works across entire codebase
- Returns exact byte offsets for O(1) retrieval

**Context Mode**: Requires indexing markdown docs. Less precise for undocumented code.

### 3. **Language-Specific AST Parsing** (10 Languages)
- Python, JS, TS, Go, Rust, Java, C, C++, C#, Ruby
- Extracts docstrings, decorators, type info
- Handles language idioms (e.g., Go type_spec, C declarators)
- Symbol kind detection (function, class, method, type, constant, interface)

**Context Mode**: Tool-agnostic (doesn't understand code structure).

### 4. **Incremental Indexing**
- SHA-256 per file
- Only re-indexes changed files
- Scales to 100K+ file repos
- SQLite backend (not JSON)

**Context Mode**: No stated incremental indexing.

### 5. **Security-First Design**
- Path traversal protection
- Secret file detection
- Binary filtering
- Safe UTF-8 decoding

**Context Mode**: Not mentioned (possible blindspot).

---

## Synergy: Combining Both

The two tools are **not competing**—they solve different problems:

### Scenario 1: Code Refactoring
1. **TokenNuke**: `search_symbols` → find all functions named "parse"
2. **TokenNuke**: `get_callers` → understand impact
3. **TokenNuke**: `get_symbol` → retrieve specific function (200 tokens vs 4000)
4. **Context Mode**: If you call `run_tests` → compress output to 299 bytes
5. **Result**: Massive token savings across the entire workflow

### Scenario 2: Debugging Large Codebase
1. **TokenNuke**: `search_text` → find where "TODO" comments are
2. **TokenNuke**: `get_symbol` → fetch the specific function
3. **TokenNuke**: `get_callees` → see downstream impact
4. **Context Mode**: If you run `run_linter` → compress warnings to actionable summary
5. **Result**: Both tool outputs and code retrieval optimized

### Scenario 3: Adding a Feature
1. **TokenNuke**: `repo_outline` → high-level code map
2. **TokenNuke**: `search_symbols` → find similar patterns
3. **TokenNuke**: `get_symbol` → examine implementation details
4. **Context Mode**: If you run `run_benchmarks` → compress before/after diffs
5. **Result**: Code understanding + output compression both active

---

## Opportunity: TokenNuke Should Add

### 1. **Tool Output Filtering Hook** (High Impact)
```python
# Pseudo-code: add optional output filter to TokenNuke MCP
@mcp.tool()
def format_tool_output(
    raw_output: str,
    output_type: str = "log" | "snapshot" | "diff"
) -> str:
    """Compress tool output before returning to context."""
    if output_type == "log":
        return compress_log(raw_output)  # Return first 500 chars + summary
    elif output_type == "snapshot":
        return compress_snapshot(raw_output)  # Extract key fields only
    elif output_type == "diff":
        return compress_diff(raw_output)  # Return hunks only, no context
```

**Why**: Context Mode's hook strategy is brilliant. TokenNuke could add similar output filtering to improve on its 92%.

### 2. **MCP Tool Discovery & Filtering**
```python
# New tool: format_mcp_output
# Automatically filter outputs from ANY MCP tool before context
```

**Why**: Removes the need for users to manually use `format_tool_output`. Transparent compression like Context Mode.

### 3. **Session Duration Metrics**
- Track tokens used per session
- Estimate remaining session time
- Warn when approaching context limit
- Suggest "compress outputs" when needed

**Why**: Context Mode proves 4x session extension. TokenNuke should measure this too.

### 4. **Codebase Diff Analysis**
```python
@mcp.tool()
def analyze_diff(repo_id: str, old_version: str, new_version: str) -> str:
    """Compare two versions, return only symbols that changed."""
```

**Why**: Huge for reviewing PRs. Return only changed symbols, not entire files.

---

## Confidence Scoring

### What Context Mode Actually Delivers
- **Output filtering**: 98% on specific tool types (high-volume) ✓
- **Sandbox execution**: Proven to work ✓
- **Session extension**: 4x measured ✓
- **FTS5 search**: Standard tech, reliable ✓

**Confidence on 98% claim**: MEDIUM (applies to high-volume tools, not average)

### What TokenNuke Actually Delivers
- **Symbol indexing**: 10 languages, tree-sitter proven ✓
- **O(1) retrieval**: Byte-offset seeks work ✓
- **Call graph**: Code understanding ✓
- **90-95% savings claim**: Conservative, realistic ✓

**Confidence on 92% average**: HIGH (well-engineered, proven)

---

## Strategic Recommendation

**TokenNuke should not fight Context Mode. Absorb its ideas.**

### Phase 1 (High Priority)
1. Add `compress_output` tool that mirrors Context Mode's filtering
2. Implement PreToolUse hook pattern for MCP integration
3. Measure actual session duration gains
4. Document output compression in README

### Phase 2 (Medium Priority)
1. Add codebase diff analysis
2. Improve semantic search (maybe larger embeddings?)
3. Add benchmark tracking across code changes
4. Security audit (secrets detection)

### Phase 3 (Optional)
1. Support for 10+ language runtimes (Bun-based execution)
2. Codebase evolution tracking
3. Team-wide code intelligence platform

**Bottom Line**: TokenNuke has better code understanding (call graphs, semantic search). Context Mode has better output filtering. Combined, they're unstoppable.

---

## Files to Review in TokenNuke Codebase

1. **server.py** (783 lines) — All 13 MCP tools defined here
2. **embed.py** (143 lines) — Hybrid search with RRF, vector embeddings
3. **extractor.py** (348 lines) — Tree-sitter AST parsing, symbol extraction
4. **database.py** — Symbol storage, FTS5 indexes, call graph resolution
5. **security.py** — Path traversal protection, binary detection

All in: `/home/moltbot/projects/tokennuke/src/tokennuke/`

