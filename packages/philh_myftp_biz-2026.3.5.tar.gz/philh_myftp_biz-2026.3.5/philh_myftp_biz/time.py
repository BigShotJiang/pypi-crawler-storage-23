from typing import Self, SupportsFloat, SupportsInt, Any

#====================================================
# Time Zone

from pytz import timezone as __timezone

TIMEZONE = __timezone('America/New_York')

#====================================================

def sleep(
    s: int,
    show: bool = False
):
    """
    Wrapper for time.Sleep function

    If show is True, then '#/# seconds' will print to the console each second
    """
    from .terminal import ProgressBar
    from time import sleep

    # If show is True
    if show:

        pbar = ProgressBar(s)
    
        # loop once for each second
        for _ in range(s):

            sleep(1)

            pbar.step()

        pbar.stop()

    else:
        sleep(s)
    
    return True

def toHMS(stamp:int) -> str:
    """
    Convert a unix time stamp to 'hh:mm:ss'
    """

    m, s = divmod(stamp, 60)
    h, m = divmod(m, 60)
    
    return f'{h:02d}:{m:02d}:{s:02d}'

class Stopwatch:
    """
    Keeps track of time
    """

    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.running = False

    def elapsed(self) -> None | float:
        """
        Get the # of seconds between now or the stop time, and the start time
        """
        from time import perf_counter

        if self.start_time != None:

            if self.running:
                elapsed = perf_counter() - self.start_time
            else:
                elapsed = self.end_time - self.start_time

            return elapsed

    def start(self) -> Self:
        """
        Start the stopwatch at 0
        """
        from time import perf_counter

        self.start_time = perf_counter()
        self.end_time = None
        self.running = True

        return self

    def stop(self) -> Self:
        """
        Stop the stopwatch
        """
        from time import perf_counter

        self.end_time = perf_counter()
        self.running = False
        
        return self

    def __int__(self) -> int:
        return int(self.elapsed())
    
    __float__ = elapsed

    def __gt__(self, 
        other: SupportsFloat|SupportsInt
    ) -> bool:
        return self.elapsed() > other

    def __ge__(self, 
        other: SupportsFloat|SupportsInt
    ) -> bool:
        return self.elapsed() >= other

    def __lt__(self, 
        other: SupportsFloat|SupportsInt
    ) -> bool:
        return self.elapsed() < other
    
    def __le__(self, 
        other: SupportsFloat|SupportsInt
    ) -> bool:
        return self.elapsed() <= other
    
    def __eq__(self, 
        other: SupportsFloat|SupportsInt
    ) -> bool:
        return self.elapsed() == other

class from_stamp:
    """
    Handler for a unix time stamp
    """

    def __init__(self,
        stamp: SupportsFloat
    ) -> None:
        from datetime import datetime
        from functools import partial
        from .classtools import cpath
        from .num import is_num

        if not is_num(stamp):
            raise ValueError(f'{cpath(stamp)} is not a number')

        dt: datetime = datetime.fromtimestamp(
            timestamp = float(stamp),
            tz = TIMEZONE
        )

        self.year: int = dt.year
        """Year (####)"""

        self.month: int = dt.month
        """Month (1-12)"""
        
        self.day: int = dt.day
        """Day of the Month (1-31)"""
        
        self.hour: int = dt.hour
        """Hour (0-23)"""
        
        self.minute: int = dt.minute
        """Minute (0-59)"""
        
        self.second: int = dt.second
        """Second (0-59)"""

        self.decisecond: int = (dt.microsecond // 100000)
        """Decisecond (0-9)"""

        self.centisecond: int = (dt.microsecond // 10000)
        """Centisecond (0-99)"""

        self.millisecond: int = (dt.microsecond // 1000)
        """Millisecond (0-999)"""

        self.microsecond: int = dt.microsecond
        """Microsecond (0-999999)"""

        self.unix: int = stamp
        """Unix Time Stamp"""

        self.stamp: partial[str] = partial(
            dt.strftime,
            format = "%Y-%m-%d %H:%M:%S"
        )
        """Get Formatted Time Stamp"""

        self.ISO: str = dt.isoformat()
        """ISO format string"""

    def __int__(self) -> int:
        return int(self.unix)
    
    def __float__(self) -> float:
        return float(self.unix)
    
    def __repr__(self) -> str:
        from .text import abbr
        from .classtools import loc

        return f"<from_stamp '{abbr(30, self.ISO)}' @{loc(self)}>"

    def __eq__(self,
        other: Any|SupportsFloat
    ) -> bool:

        if isinstance(other, (from_stamp, int, float)):
            return (self.unix == float(other))
        else:
            return False
        
    def __lt__(self,
        other: Any|SupportsFloat
    ) -> bool:
        from .classtools import cpath

        if isinstance(other, (from_stamp, int, float)):
            return (self.unix < float(other))
        
        else:
            raise TypeError(cpath(other))
        
    def __gt__(self, 
        other: Any|SupportsFloat
    ) -> bool:
        from .classtools import cpath

        if isinstance(other, (from_stamp, int, float)):
            return (self.unix > float(other))
        
        else:
            raise TypeError(cpath(other))

def now() -> from_stamp:
    """
    Get details of the current time
    """
    from time import time

    return from_stamp(stamp=time())

def from_string(
    string: str
) -> from_stamp:
    """
    Get details of time string
    """
    from dateutil.parser._parser import ParserError
    from .classtools import cpath
    from dateutil import parser

    try:
    
        dt = parser.parse(string)
        return from_stamp(dt.timestamp())
    
    except OSError, ParserError:
    
        raise TypeError(cpath(string))

def from_ymdhms(
    year:   int = 0,
    month:  int = 0,
    day:    int = 0,
    hour:   int = 0,
    minute: int = 0,
    second: int = 0,
) -> from_stamp:
    """
    Get details of time from year, month, day, hour, minute, & second
    """
    from datetime import datetime

    t = datetime(
        year=year,
        month=month,
        day=day,
        hour=hour,
        minute=minute,
        second=second
    )

    try:

        return from_stamp(stamp=t.timestamp())
    
    except OSError as e:
        raise TypeError(*e.args)