"""Tests for string formatting recipes."""

import pytest
from rewrite import InMemoryExecutionContext, InMemoryLargeSourceSet, Recipe
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.string_formatting import (
    ReplacePercentFormatWithFString,
    ReplaceStrFormatWithFString,
)
from openrewrite_migrate_python.migrate.upgrade_to_python38 import UpgradeToPython38


def _assert_idempotent(recipe: Recipe):
    """Return an after_recipe callback that asserts running the recipe again produces no change."""
    def check(source_file):
        ctx = InMemoryExecutionContext()
        lss = InMemoryLargeSourceSet([source_file])
        results = recipe.run(lss, ctx)
        for r in results:
            if r._after is not None and r._after is not r._before:
                assert False, (
                    f"Recipe is not idempotent. Second run produced a change:\n"
                    f"Before: {r._before.print_all()!r}\n"
                    f"After:  {r._after.print_all()!r}"
                )
    return check


class TestReplaceStrFormatWithFString:
    """Tests for the ReplaceStrFormatWithFString recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_simple_auto_numbered(self):
        """'Hello {}'.format(name) → f'Hello {name}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "Hello {}".format(name)
                """,
                """
                message = f"Hello {name}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_multiple_auto_numbered(self):
        """'{} and {}'.format(a, b) → f'{a} and {b}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{} and {}".format(a, b)
                """,
                """
                message = f"{a} and {b}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_explicit_positional(self):
        """'{0} {1}'.format(a, b) → f'{a} {b}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{0} {1}".format(a, b)
                """,
                """
                message = f"{a} {b}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_reordered_positional(self):
        """'{1} {0}'.format(a, b) → f'{b} {a}' (reordered)"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{1} {0}".format(a, b)
                """,
                """
                message = f"{b} {a}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_named_args(self):
        """'{name}'.format(name=x) → f'{x}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{name}".format(name=x)
                """,
                """
                message = f"{x}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_conversion_repr(self):
        """'{!r}'.format(x) → f'{x!r}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{!r}".format(x)
                """,
                """
                message = f"{x!r}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_format_spec(self):
        """'{:.2f}'.format(x) → f'{x:.2f}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{:.2f}".format(x)
                """,
                """
                message = f"{x:.2f}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_single_quotes(self):
        """'Hello {}'.format(name) → f'Hello {name}' (single quotes)"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = 'Hello {}'.format(name)
                """,
                """
                message = f'Hello {name}'
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_escaped_braces(self):
        """'{{literal braces}}'.format() → f'{{literal braces}}'"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{{literal braces}}".format()
                """,
                """
                message = f"{{literal braces}}"
                """,
            )
        )

    def test_no_change_variable_receiver(self):
        """template.format(x) — variable receiver, no change."""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                template = "Hello {}"
                message = template.format("World")
                """
            )
        )

    def test_no_change_bytes_literal(self):
        """b'{}' .format(x) — bytes literal, no change."""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = b"hello"
                """
            )
        )

    def test_no_change_star_args(self):
        """'{}' .format(*args) — star args, no change."""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{}".format(*args)
                """
            )
        )

    def test_no_change_repeated_side_effect(self):
        """'{0} {0}'.format(func()) — repeated + side effect, no change."""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{0} {0}".format(func())
                """
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_repeated_safe(self):
        """'{0} {0}'.format(name) → f'{name} {name}' (repeated + safe)"""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "{0} {0}".format(name)
                """,
                """
                message = f"{name} {name}"
                """,
            )
        )

    def test_no_change_backslash_in_string(self):
        """'hello\\n{}'.format(name) — backslash escape, no change."""
        spec = RecipeSpec(recipe=ReplaceStrFormatWithFString())
        spec.rewrite_run(
            python(
                r"""
                message = "hello\n{}".format(name)
                """
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_idempotent(self):
        """Running the recipe twice produces the same result."""
        recipe = ReplaceStrFormatWithFString()
        spec = RecipeSpec(recipe=recipe)
        spec.rewrite_run(
            python(
                """
                message = "Hello {}".format(name)
                """,
                """
                message = f"Hello {name}"
                """,
                after_recipe=_assert_idempotent(recipe),
            )
        )


class TestReplacePercentFormatWithFString:
    """Tests for the ReplacePercentFormatWithFString recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_simple_percent_s(self):
        """'Hello %s' % name → f'Hello {name}'"""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "Hello %s" % name
                """,
                """
                message = f"Hello {name}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_multiple_percent_s(self):
        """'%s and %s' % (a, b) → f'{a} and {b}'"""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "%s and %s" % (a, b)
                """,
                """
                message = f"{a} and {b}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_percent_r(self):
        """'%r' % x → f'{x!r}'"""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "%r" % x
                """,
                """
                message = f"{x!r}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_escaped_percent(self):
        """'100%% of %s' % name → f'100% of {name}'"""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "100%% of %s" % name
                """,
                """
                message = f"100% of {name}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_single_quotes(self):
        """'Hello %s' % name → f'Hello {name}' (single quotes)"""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = 'Hello %s' % name
                """,
                """
                message = f'Hello {name}'
                """,
            )
        )

    def test_no_change_variable_receiver(self):
        """template % name — variable receiver, no change."""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                template = "Hello %s"
                message = template % name
                """
            )
        )

    def test_no_change_unsupported_specifier(self):
        """'%d' % x — unsupported specifier, no change."""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "%d" % x
                """
            )
        )

    def test_no_change_named_substitution(self):
        """'%(name)s' % d — named substitution, no change."""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "%(name)s" % d
                """
            )
        )

    def test_no_change_width_flags(self):
        """'%-10s' % x — width/flags, no change."""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                """
                message = "%-10s" % x
                """
            )
        )

    def test_no_change_backslash(self):
        r"""'%s\n' % x — backslash in string, no change."""
        spec = RecipeSpec(recipe=ReplacePercentFormatWithFString())
        spec.rewrite_run(
            python(
                r"""
                message = "%s\n" % x
                """
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_idempotent(self):
        """Running the recipe twice produces the same result."""
        recipe = ReplacePercentFormatWithFString()
        spec = RecipeSpec(recipe=recipe)
        spec.rewrite_run(
            python(
                """
                message = "Hello %s" % name
                """,
                """
                message = f"Hello {name}"
                """,
                after_recipe=_assert_idempotent(recipe),
            )
        )


class TestUpgradeToPython38StringFormatting:
    """Test that string formatting recipes cooperate in UpgradeToPython38."""

    @pytest.mark.requires_dev_openrewrite
    def test_convertible_format_is_replaced(self):
        """Convertible .format() becomes an f-string."""
        spec = RecipeSpec(recipe=UpgradeToPython38())
        spec.rewrite_run(
            python(
                """
                message = "Hello {}".format(name)
                """,
                """
                message = f"Hello {name}"
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_convertible_percent_is_replaced(self):
        """Convertible %-formatting becomes an f-string."""
        spec = RecipeSpec(recipe=UpgradeToPython38())
        spec.rewrite_run(
            python(
                """
                message = "Hello %s" % name
                """,
                """
                message = f"Hello {name}"
                """,
            )
        )
