"""Tests for threading deprecation migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.threading_deprecations import (
    ReplaceConditionNotifyAll,
    ReplaceThreadingActiveCount,
    ReplaceThreadingCurrentThread,
)


class TestReplaceThreadingCurrentThread:
    """Tests for ReplaceThreadingCurrentThread recipe."""

    def test_replaces_threading_current_thread(self):
        spec = RecipeSpec(recipe=ReplaceThreadingCurrentThread())
        spec.rewrite_run(
            python(
                "t = threading.currentThread()",
                "t = threading.current_thread()",
            )
        )

    def test_no_change_when_already_snake_case(self):
        spec = RecipeSpec(recipe=ReplaceThreadingCurrentThread())
        spec.rewrite_run(
            python("t = threading.current_thread()")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceThreadingCurrentThread())
        spec.rewrite_run(
            python("t = other.currentThread()")
        )


class TestReplaceThreadingActiveCount:
    """Tests for ReplaceThreadingActiveCount recipe."""

    def test_replaces_threading_active_count(self):
        spec = RecipeSpec(recipe=ReplaceThreadingActiveCount())
        spec.rewrite_run(
            python(
                "count = threading.activeCount()",
                "count = threading.active_count()",
            )
        )

    def test_no_change_when_already_snake_case(self):
        spec = RecipeSpec(recipe=ReplaceThreadingActiveCount())
        spec.rewrite_run(
            python("count = threading.active_count()")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceThreadingActiveCount())
        spec.rewrite_run(
            python("count = other.activeCount()")
        )


class TestReplaceConditionNotifyAll:
    """Tests for ReplaceConditionNotifyAll recipe."""

    def test_replaces_notify_all(self):
        spec = RecipeSpec(recipe=ReplaceConditionNotifyAll())
        spec.rewrite_run(
            python(
                "cond.notifyAll()",
                "cond.notify_all()",
            )
        )

    def test_no_change_when_already_snake_case(self):
        spec = RecipeSpec(recipe=ReplaceConditionNotifyAll())
        spec.rewrite_run(
            python("cond.notify_all()")
        )
