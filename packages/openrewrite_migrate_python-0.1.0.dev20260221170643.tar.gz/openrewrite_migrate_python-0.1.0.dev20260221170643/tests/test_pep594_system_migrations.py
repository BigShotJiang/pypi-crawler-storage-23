"""Tests for PEP 594 system/platform module migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.pep594_system_migrations import (
    FindCryptModule,
    FindMsilibModule,
    FindNisModule,
    FindOssaudiodevModule,
    FindSpwdModule,
)


class TestFindCryptModule:
    """Tests for FindCryptModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_crypt(self):
        spec = RecipeSpec(recipe=FindCryptModule())
        spec.rewrite_run(
            python(
                "import crypt",
                "/*~~(The `crypt` module was removed in Python 3.13. Use `bcrypt`, `argon2-cffi`, or `passlib` instead.)~~>*/import crypt",
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_from_crypt_import(self):
        spec = RecipeSpec(recipe=FindCryptModule())
        spec.rewrite_run(
            python(
                "from crypt import crypt as crypt_password",
                "/*~~(The `crypt` module was removed in Python 3.13. Use `bcrypt`, `argon2-cffi`, or `passlib` instead.)~~>*/from crypt import crypt as crypt_password",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindCryptModule())
        spec.rewrite_run(
            python("import hashlib")
        )


class TestFindMsilibModule:
    """Tests for FindMsilibModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_msilib(self):
        spec = RecipeSpec(recipe=FindMsilibModule())
        spec.rewrite_run(
            python(
                "import msilib",
                "/*~~(The `msilib` module was removed in Python 3.13.)~~>*/import msilib",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindMsilibModule())
        spec.rewrite_run(
            python("import os")
        )


class TestFindNisModule:
    """Tests for FindNisModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_nis(self):
        spec = RecipeSpec(recipe=FindNisModule())
        spec.rewrite_run(
            python(
                "import nis",
                "/*~~(The `nis` module was removed in Python 3.13.)~~>*/import nis",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindNisModule())
        spec.rewrite_run(
            python("import os")
        )


class TestFindOssaudiodevModule:
    """Tests for FindOssaudiodevModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_ossaudiodev(self):
        spec = RecipeSpec(recipe=FindOssaudiodevModule())
        spec.rewrite_run(
            python(
                "import ossaudiodev",
                "/*~~(The `ossaudiodev` module was removed in Python 3.13.)~~>*/import ossaudiodev",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindOssaudiodevModule())
        spec.rewrite_run(
            python("import os")
        )


class TestFindSpwdModule:
    """Tests for FindSpwdModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_spwd(self):
        spec = RecipeSpec(recipe=FindSpwdModule())
        spec.rewrite_run(
            python(
                "import spwd",
                "/*~~(The `spwd` module was removed in Python 3.13.)~~>*/import spwd",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindSpwdModule())
        spec.rewrite_run(
            python("import pwd")
        )
