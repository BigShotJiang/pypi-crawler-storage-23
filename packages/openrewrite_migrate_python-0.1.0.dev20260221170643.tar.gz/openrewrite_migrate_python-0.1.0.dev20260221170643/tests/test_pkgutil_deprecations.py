"""Tests for pkgutil deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.pkgutil_deprecations import (
    ReplacePkgutilFindLoader,
    ReplacePkgutilGetLoader,
)


class TestReplacePkgutilFindLoader:
    """Tests for the ReplacePkgutilFindLoader recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_pkgutil_find_loader(self):
        """Test that pkgutil.find_loader() is found and marked."""
        spec = RecipeSpec(recipe=ReplacePkgutilFindLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                loader = pkgutil.find_loader("mymodule")
                """,
                """
                import pkgutil
                loader = /*~~(pkgutil.find_loader() is deprecated: Replace with importlib.util.find_spec() (Python 3.12+))~~>*/pkgutil.find_loader("mymodule")
                """,
            )
        )

    def test_no_change_when_walk_packages(self):
        """Test that pkgutil.walk_packages() is not marked."""
        spec = RecipeSpec(recipe=ReplacePkgutilFindLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                for pkg in pkgutil.walk_packages():
                    pass
                """
            )
        )


class TestReplacePkgutilGetLoader:
    """Tests for the ReplacePkgutilGetLoader recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_pkgutil_get_loader(self):
        """Test that pkgutil.get_loader() is found and marked."""
        spec = RecipeSpec(recipe=ReplacePkgutilGetLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                loader = pkgutil.get_loader("mymodule")
                """,
                """
                import pkgutil
                loader = /*~~(pkgutil.get_loader() is deprecated: Replace with importlib.util.find_spec() (Python 3.12+))~~>*/pkgutil.get_loader("mymodule")
                """,
            )
        )

    def test_no_change_when_iter_modules(self):
        """Test that pkgutil.iter_modules() is not marked."""
        spec = RecipeSpec(recipe=ReplacePkgutilGetLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                for mod in pkgutil.iter_modules():
                    pass
                """
            )
        )
