"""Tests for distutils deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.distutils_deprecations import (
    FindDistutilsUsage,
)


class TestFindDistutilsUsage:
    """Tests for the FindDistutilsUsage recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_distutils_import(self):
        """Test that distutils imports are found and marked."""
        spec = RecipeSpec(recipe=FindDistutilsUsage())
        spec.rewrite_run(
            python(
                """
                from distutils.core import setup
                """,
                """
                /*~~(distutils is deprecated: Migrate to setuptools (removed in Python 3.12))~~>*/from distutils.core import setup
                """,
            )
        )

    def test_no_change_when_setuptools(self):
        """Test that setuptools imports are not marked."""
        spec = RecipeSpec(recipe=FindDistutilsUsage())
        spec.rewrite_run(
            python(
                """
                from setuptools import setup
                """
            )
        )

    def test_no_change_when_other_imports(self):
        """Test that unrelated imports are not marked."""
        spec = RecipeSpec(recipe=FindDistutilsUsage())
        spec.rewrite_run(
            python(
                """
                import os
                from typing import List
                """
            )
        )
