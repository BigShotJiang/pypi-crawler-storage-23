"""Tests for platform module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.platform_deprecations import FindPlatformPopen


class TestFindPlatformPopen:
    """Tests for FindPlatformPopen recipe."""

    def test_finds_platform_popen(self):
        spec = RecipeSpec(recipe=FindPlatformPopen())
        spec.rewrite_run(
            python(
                "output = platform.popen('ls')",
                "output = /*~~(platform.popen() was removed in Python 3.8. Use os.popen() or subprocess.run() instead.)~~>*/platform.popen('ls')",
            )
        )

    def test_no_change_when_not_platform_popen(self):
        spec = RecipeSpec(recipe=FindPlatformPopen())
        spec.rewrite_run(
            python("output = os.popen('ls').read()")
        )
