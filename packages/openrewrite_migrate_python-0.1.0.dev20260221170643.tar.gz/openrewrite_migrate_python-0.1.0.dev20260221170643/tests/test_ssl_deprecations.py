"""Tests for ssl deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.ssl_deprecations import (
    FindSslMatchHostname,
)


class TestFindSslMatchHostname:
    """Tests for the FindSslMatchHostname recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_ssl_match_hostname(self):
        """Test that ssl.match_hostname() is found and marked."""
        spec = RecipeSpec(recipe=FindSslMatchHostname())
        spec.rewrite_run(
            python(
                """
                import ssl
                ssl.match_hostname(cert, hostname)
                """,
                """
                import ssl
                /*~~(ssl.match_hostname() is deprecated: Use ssl.SSLContext.check_hostname instead (removed in Python 3.12))~~>*/ssl.match_hostname(cert, hostname)
                """,
            )
        )

    def test_no_change_when_different_method(self):
        """Test that other ssl methods are not marked."""
        spec = RecipeSpec(recipe=FindSslMatchHostname())
        spec.rewrite_run(
            python(
                """
                import ssl
                ctx = ssl.create_default_context()
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that non-ssl module calls are not marked."""
        spec = RecipeSpec(recipe=FindSslMatchHostname())
        spec.rewrite_run(
            python(
                """
                class MySsl:
                    def match_hostname(self, cert, hostname):
                        pass

                my_ssl = MySsl()
                my_ssl.match_hostname(cert, hostname)
                """
            )
        )
