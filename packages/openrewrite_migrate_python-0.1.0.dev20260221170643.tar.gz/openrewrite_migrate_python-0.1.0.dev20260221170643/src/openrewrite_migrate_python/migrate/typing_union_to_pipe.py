"""
Recipes for migrating typing.Optional and typing.Union to PEP 604 union syntax.

PEP 604 (Python 3.10+) introduced the `X | Y` syntax for union types:

- typing.Optional[X] -> X | None
- typing.Union[X, Y] -> X | Y
- typing.Union[X, Y, Z] -> X | Y | Z

See: https://peps.python.org/pep-0604/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JRightPadded, Space
from rewrite.java.tree import (
    ArrayAccess,
    Expression,
    FieldAccess,
    Identifier,
    Literal,
    ParameterizedType,
)
from rewrite.python.tree import CollectionLiteral, UnionType
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.10
_Python310 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.10"),
]


def _is_typing_optional(clazz: Expression) -> bool:
    """Check if a clazz expression is typing.Optional or just Optional."""
    if isinstance(clazz, Identifier):
        return clazz.simple_name == "Optional"
    if isinstance(clazz, FieldAccess):
        name = clazz.name
        target = clazz.target
        if (isinstance(name, Identifier) and name.simple_name == "Optional" and
            isinstance(target, Identifier) and target.simple_name == "typing"):
            return True
    return False


def _is_typing_union(clazz: Expression) -> bool:
    """Check if a clazz expression is typing.Union or just Union."""
    if isinstance(clazz, Identifier):
        return clazz.simple_name == "Union"
    if isinstance(clazz, FieldAccess):
        name = clazz.name
        target = clazz.target
        if (isinstance(name, Identifier) and name.simple_name == "Union" and
            isinstance(target, Identifier) and target.simple_name == "typing"):
            return True
    return False


def _create_none_literal(prefix: Space) -> Literal:
    """Create a Literal node representing None."""
    return Literal(
        _id=random_id(),
        _prefix=prefix,
        _markers=Markers.EMPTY,
        _value=None,
        _value_source="None",
        _unicode_escapes=None,
        _type=None,
    )


def _create_union_type(types: List[Expression], prefix: Space) -> UnionType:
    """Create a UnionType node (X | Y | Z).

    The UnionType node represents the PEP 604 union syntax.
    Each type in the list is separated by ' | '.
    """
    # Create JRightPadded list with ' | ' after each type except the last
    padded_types = []
    for i, type_expr in enumerate(types):
        # First type keeps its own prefix (or empty)
        if i == 0:
            type_expr = type_expr.replace(_prefix=Space.EMPTY) if hasattr(type_expr, 'replace') else type_expr
        else:
            # Other types get single space prefix (after the |)
            type_expr = type_expr.replace(_prefix=Space.SINGLE_SPACE) if hasattr(type_expr, 'replace') else type_expr

        # All types except the last get ' | ' after (space before |)
        if i < len(types) - 1:
            after = Space.SINGLE_SPACE  # Space before the |
        else:
            after = Space.EMPTY

        padded_types.append(JRightPadded(
            _element=type_expr,
            _after=after,
            _markers=Markers.EMPTY,
        ))

    return UnionType(
        _id=random_id(),
        _prefix=prefix,
        _markers=Markers.EMPTY,
        _types=padded_types,
        _type=None,
    )


@categorize(_Python310)
class ReplaceTypingOptionalWithUnion(Recipe):
    """
    Replace `typing.Optional[X]` with `X | None` (PEP 604).

    PEP 604 introduced the `|` operator for union types in Python 3.10.
    `Optional[X]` is equivalent to `X | None`.

    Example:
        Before:
            from typing import Optional
            name: Optional[str] = None

        After:
            name: str | None = None
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingOptionalWithUnion"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Optional[X]` with `X | None`"

    @property
    def description(self) -> str:
        return (
            "PEP 604 introduced the `|` operator for union types in Python 3.10. "
            "Replace `Optional[X]` with the more concise `X | None` syntax."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "typing", "pep604"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_parameterized_type(
                self, param_type: ParameterizedType, p: ExecutionContext
            ) -> Optional[Expression]:
                param_type = super().visit_parameterized_type(param_type, p)

                # Check if this is Optional[X]
                if not _is_typing_optional(param_type.clazz):
                    return param_type

                # Get the type arguments
                type_params = param_type.type_parameters
                if type_params is None or len(type_params) != 1:
                    return param_type

                type_arg = type_params[0]

                # Create X | None using UnionType
                none_literal = _create_none_literal(Space.EMPTY)
                return _create_union_type([type_arg, none_literal], param_type.prefix)

            def visit_array_access(
                self, array_access: ArrayAccess, p: ExecutionContext
            ) -> Optional[Expression]:
                array_access = super().visit_array_access(array_access, p)

                # Check if this is Optional[X]
                if not _is_typing_optional(array_access.indexed):
                    return array_access

                # Get the type argument from the dimension
                index = array_access.dimension.index

                # Create X | None using UnionType
                none_literal = _create_none_literal(Space.EMPTY)
                return _create_union_type([index, none_literal], array_access.prefix)

        return Visitor()


@categorize(_Python310)
class ReplaceTypingUnionWithPipe(Recipe):
    """
    Replace `typing.Union[X, Y]` with `X | Y` (PEP 604).

    PEP 604 introduced the `|` operator for union types in Python 3.10.
    `Union[X, Y, Z]` becomes `X | Y | Z`.

    Example:
        Before:
            from typing import Union
            value: Union[int, str] = 0

        After:
            value: int | str = 0
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingUnionWithPipe"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Union[X, Y]` with `X | Y`"

    @property
    def description(self) -> str:
        return (
            "PEP 604 introduced the `|` operator for union types in Python 3.10. "
            "Replace `Union[X, Y, ...]` with the more concise `X | Y | ...` syntax."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "typing", "pep604"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_parameterized_type(
                self, param_type: ParameterizedType, p: ExecutionContext
            ) -> Optional[Expression]:
                param_type = super().visit_parameterized_type(param_type, p)

                # Check if this is Union[X, Y, ...]
                if not _is_typing_union(param_type.clazz):
                    return param_type

                # Get the type arguments
                type_params = param_type.type_parameters
                if type_params is None or len(type_params) < 2:
                    return param_type

                # Create union type with all type parameters
                return _create_union_type(list(type_params), param_type.prefix)

            def visit_array_access(
                self, array_access: ArrayAccess, p: ExecutionContext
            ) -> Optional[Expression]:
                array_access = super().visit_array_access(array_access, p)

                # Check if this is Union[X, Y, ...]
                if not _is_typing_union(array_access.indexed):
                    return array_access

                # Get the type arguments from the dimension
                index = array_access.dimension.index

                # Extract elements from CollectionLiteral
                if not isinstance(index, CollectionLiteral):
                    return array_access

                elements = list(index.elements)
                if len(elements) < 2:
                    return array_access

                # Create union type with all elements
                return _create_union_type(elements, array_access.prefix)

        return Visitor()
