"""
Recipes for migrating deprecated platform module functions.

The following function was deprecated in Python 3.3 and removed in Python 3.8:
- platform.popen() -> os.popen() or subprocess

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python38)
class FindPlatformPopen(Recipe):
    """
    Find usages of removed `platform.popen()`.

    `platform.popen()` was deprecated in Python 3.3 and removed in Python 3.8.
    Use `os.popen()` or `subprocess.run()` instead.

    Example:
        Before:
            import platform
            output = platform.popen('ls').read()

        After:
            import subprocess
            output = subprocess.run(['ls'], capture_output=True, text=True).stdout
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindPlatformPopen"

    @property
    def display_name(self) -> str:
        return "Find removed `platform.popen()` usage"

    @property
    def description(self) -> str:
        return (
            "`platform.popen()` was removed in Python 3.8. "
            "Use `os.popen()` or `subprocess.run()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "platform"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "popen":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "platform":
                    return method

                return _mark_deprecated(
                    method,
                    "platform.popen() was removed in Python 3.8. "
                    "Use os.popen() or subprocess.run() instead."
                )

        return Visitor()
