"""Composite recipe for upgrading from Python 3.11 to Python 3.12."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.recipes import ChangeImport

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython312(Recipe):
    """
    Migrate deprecated and removed APIs for Python 3.12 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.11 to be compatible with Python 3.12.

    Key changes in Python 3.12:
    - The `imp` module is removed (use `importlib` instead)
    - `asynchat`, `asyncore`, and `smtpd` modules removed
    - `distutils` is fully removed (use `setuptools` or `packaging`)
    - `configparser.SafeConfigParser` is removed (use `ConfigParser`)
    - `Path.link_to()` removed (use `hardlink_to()` with reversed args)

    See: https://docs.python.org/3/whatsnew/3.12.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython312"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.12"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated and removed APIs for Python 3.12 compatibility. "
            "This includes detecting usage of the removed `imp` module and other "
            "legacy modules that were removed in Python 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.12 upgrade."""
        # Import here to avoid circular imports
        from .calendar_deprecations import ReplaceCalendarConstants
        from .shutil_deprecations import FindShutilRmtreeOnerror
        from .sys_last_deprecations import FindSysLastExcInfo
        from .distutils_deprecations import FindDistutilsUsage
        from .distutils_migrations import ReplaceDistutilsVersion
        from .imp_migrations import FindImpUsage
        from .os_deprecations import FindOsPopen, FindOsSpawn
        from .pathlib_deprecations import FindPathlibLinkTo
        from .pkgutil_deprecations import ReplacePkgutilFindLoader, ReplacePkgutilGetLoader
        from .removed_modules_312 import FindRemovedModules312
        from .ssl_deprecations import FindSslMatchHostname
        from .upgrade_to_python311 import UpgradeToPython311

        return [
            # First apply all Python 3.11 upgrades (which includes 3.10 upgrades)
            UpgradeToPython311(),
            # calendar mixed-case constants deprecated in Python 3.12
            ReplaceCalendarConstants(),
            # imp module was removed in Python 3.12 - auto-fix where possible
            ChangeImport(old_module="imp", old_name="reload", new_module="importlib"),  # imp.reload() -> importlib.reload()
            FindImpUsage(),  # Flag any remaining imp usage
            # distutils removed in 3.12 (detection only)
            ReplaceDistutilsVersion(),
            FindDistutilsUsage(),
            # pkgutil.find_loader/get_loader deprecated in 3.12 (detection only)
            ReplacePkgutilFindLoader(),
            ReplacePkgutilGetLoader(),
            # Path.link_to() removed in 3.12
            FindPathlibLinkTo(),
            # Detect imports of modules removed in 3.12
            FindRemovedModules312(),
            # ssl.match_hostname() removed in 3.12
            FindSslMatchHostname(),
            # os.popen/os.spawn* deprecated (use subprocess)
            FindOsPopen(),
            FindOsSpawn(),
            # shutil.rmtree(onerror=) deprecated in 3.12
            FindShutilRmtreeOnerror(),
            # sys.last_type/last_value/last_traceback deprecated in 3.12
            FindSysLastExcInfo(),
        ]
