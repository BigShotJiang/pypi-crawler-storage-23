"""Composite recipe for upgrading from Python 3.10 to Python 3.11."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.recipes import ChangeImport

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython311(Recipe):
    """
    Migrate deprecated and removed APIs for Python 3.11 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.10 to be compatible with Python 3.11.

    Key changes in Python 3.11:
    - The `@asyncio.coroutine` decorator is removed (use `async def` instead)
    - `inspect.getargspec()` is removed (use `inspect.getfullargspec()`)
    - `gettext.lgettext()` and related functions removed
    - Various deprecation warnings for features removed in later versions

    See: https://docs.python.org/3/whatsnew/3.11.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython311"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.11"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated and removed APIs for Python 3.11 compatibility. "
            "This includes handling removed modules, deprecated functions, and "
            "API changes between Python 3.10 and 3.11."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.11"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.11 upgrade."""
        # Import here to avoid circular imports
        from .asyncio_coroutine_to_async import MigrateAsyncioCoroutine
        from .asyncio_deprecations import FindAsyncioCoroutineDecorator
        from .locale_getdefaultlocale_deprecation import FindLocaleGetdefaultlocale
        from .re_deprecations import FindReTemplate
        from .configparser_deprecations import (
            ReplaceConfigparserReadfp,
            ReplaceConfigparserSafeConfigParser,
        )
        from .datetime_utc import ReplaceDatetimeUtcFromTimestamp, ReplaceDatetimeUtcNow
        from .gettext_deprecations import ReplaceGettextDeprecations
        from .socket_deprecations import FindSocketGetFQDN
        from .unittest_deprecations import ReplaceUnittestDeprecatedAliases
        from .upgrade_to_python310 import UpgradeToPython310

        return [
            # First apply all Python 3.10 upgrades
            UpgradeToPython310(),
            # Note: datetime deprecation warnings start in 3.12, but we include them
            # here as proactive modernization for forward compatibility
            ReplaceDatetimeUtcNow(),
            ReplaceDatetimeUtcFromTimestamp(),
            # inspect.getargspec() was deprecated in 3.0 and removed in 3.11
            ChangeImport(old_module="inspect", old_name="getargspec", new_module="inspect", new_name="getfullargspec"),
            # configparser.SafeConfigParser deprecated in 3.2, removed in 3.12
            ReplaceConfigparserSafeConfigParser(),
            # configparser.readfp() deprecated in 3.2, removed in 3.13
            ReplaceConfigparserReadfp(),
            # gettext.lgettext() etc. deprecated in 3.8, removed in 3.11
            ReplaceGettextDeprecations(),
            # logging.warn() deprecated in 3.3 (still works but not recommended)
            ChangeImport(old_module="logging", old_name="warn", new_module="logging", new_name="warning"),
            # unittest method aliases (assertEquals, etc.) removed in 3.11/3.12
            ReplaceUnittestDeprecatedAliases(),
            # @asyncio.coroutine + yield from -> async def + await (removed in 3.11)
            MigrateAsyncioCoroutine(),
            # Detect @asyncio.coroutine usage that can't be auto-migrated
            FindAsyncioCoroutineDecorator(),
            # socket.getfqdn() deprecated in 3.11
            FindSocketGetFQDN(),
            # locale.getdefaultlocale() deprecated in 3.11
            FindLocaleGetdefaultlocale(),
            # re.template() / re.TEMPLATE deprecated in 3.11
            FindReTemplate(),
        ]
