"""
Recipes for migrating older string formatting styles to f-strings.

Python 3.6 introduced f-strings (PEP 498) which provide a more readable and
often faster way to format strings. Older formatting styles include:

- %-formatting: "Hello %s" % name
- str.format(): "Hello {}".format(name)

See: https://peps.python.org/pep-0498/
"""

import string as _string_module
from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JRightPadded, Space
from rewrite.java.tree import Binary, Expression, FieldAccess, Identifier, Literal, MethodInvocation, Parentheses
from rewrite.python.tree import CollectionLiteral, FormattedString, NamedArgument, Star
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.6
_Python36 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.6"),
]


def _is_string_literal(expr: Any) -> bool:
    """Check if an expression is a string literal."""
    if isinstance(expr, Literal):
        # Check if the value source looks like a string (starts with quote)
        value_source = expr.value_source
        if value_source and len(value_source) > 0:
            first_char = value_source[0]
            # String literals start with ', ", f', r', b', etc.
            if first_char in ('"', "'"):
                return True
            # Check for prefixed strings like r"...", b"...", etc.
            if len(value_source) > 1 and first_char.lower() in ('r', 'b', 'u') and value_source[1] in ('"', "'"):
                return True
    return False


def _get_fstring_delimiter(value_source: str) -> Optional[str]:
    """Determine the f-string opening delimiter from a string literal's value_source.

    Returns e.g. 'f"', "f'", 'f\"\"\"', or None if the string can't be converted.
    Bails out on bytes (b) and raw (r) prefixes.
    """
    s = value_source
    # Skip prefix characters
    while s and s[0].lower() in ('u', 'b', 'r', 'f'):
        if s[0].lower() in ('b', 'r'):
            return None
        s = s[1:]

    if s.startswith('"""'):
        return 'f"""'
    elif s.startswith("'''"):
        return "f'''"
    elif s.startswith('"'):
        return 'f"'
    elif s.startswith("'"):
        return "f'"
    return None


def _is_side_effect_free(expr: Any) -> bool:
    """Check if an expression is safe to duplicate (no side effects)."""
    return isinstance(expr, (Identifier, Literal, FieldAccess))


def _has_backslash(value_source: str) -> bool:
    """Check if the string content (between quotes) contains a backslash."""
    s = value_source
    # Skip prefix characters (u, f — bytes/raw already bailed)
    while s and s[0].lower() in ('u', 'f'):
        s = s[1:]
    if s.startswith('"""') or s.startswith("'''"):
        content = s[3:-3]
    else:
        content = s[1:-1]
    return '\\' in content


def _convert_format_to_fstring(method: MethodInvocation) -> Optional[FormattedString]:
    """Convert a ``"...".format(...)`` MethodInvocation to a FormattedString.

    Returns None if the conversion is not safe.
    """
    select = method.select
    if not isinstance(select, Literal):
        return None

    value_source = select.value_source
    if not value_source:
        return None

    # Determine f-string delimiter (also bails on bytes/raw)
    delimiter = _get_fstring_delimiter(value_source)
    if delimiter is None:
        return None

    # Bail out on backslash escapes — Formatter.parse() unescapes them
    # and we can't reliably reconstruct original escape sequences
    if _has_backslash(value_source):
        return None

    # Get the actual format string value
    format_string = select.value
    if not isinstance(format_string, str):
        return None

    # Check for star args
    raw_args = list(method.arguments)
    for arg in raw_args:
        if isinstance(arg, Star):
            return None

    # Parse format string
    try:
        parsed = list(_string_module.Formatter().parse(format_string))
    except (ValueError, KeyError):
        return None

    # Validate fields
    for _literal_text, field_name, format_spec, _conversion in parsed:
        if field_name is None:
            continue
        # Bail on nested/dynamic format specs
        if format_spec and ('{' in format_spec or '}' in format_spec):
            return None
        # Bail on attribute/index access in field names
        if '.' in field_name or '[' in field_name:
            return None

    # Build positional and named arg maps
    positional_args: List[Expression] = []
    named_args: dict[str, Expression] = {}
    for arg in raw_args:
        if isinstance(arg, NamedArgument):
            named_args[arg.name.simple_name] = arg.value
        else:
            positional_args.append(arg)

    # Check repeated explicit positional indices with side-effect expressions
    index_usage: dict[int, int] = {}
    for _, field_name, _, _ in parsed:
        if field_name is not None and field_name.isdigit():
            idx = int(field_name)
            index_usage[idx] = index_usage.get(idx, 0) + 1

    for idx, count in index_usage.items():
        if count > 1:
            if idx >= len(positional_args):
                return None
            if not _is_side_effect_free(positional_args[idx]):
                return None

    # Build f-string parts
    parts: List[Expression] = []
    auto_index = 0

    for literal_text, field_name, format_spec, conversion in parsed:
        # Literal text fragment
        if literal_text:
            # Re-escape braces for f-string source
            escaped_text = literal_text.replace('{', '{{').replace('}', '}}')
            parts.append(Literal(
                _id=random_id(),
                _prefix=Space.EMPTY,
                _markers=Markers.EMPTY,
                _value=literal_text,
                _value_source=escaped_text,
                _unicode_escapes=None,
                _type=None,
            ))

        # Interpolated value
        if field_name is not None:
            # Resolve the argument expression
            if field_name == '':
                # Auto-numbered
                if auto_index >= len(positional_args):
                    return None
                arg_expr = positional_args[auto_index]
                auto_index += 1
            elif field_name.isdigit():
                idx = int(field_name)
                if idx >= len(positional_args):
                    return None
                arg_expr = positional_args[idx]
            else:
                # Named argument
                if field_name not in named_args:
                    return None
                arg_expr = named_args[field_name]

            padded_expr = JRightPadded(
                _element=arg_expr.replace(_prefix=Space.EMPTY),
                _after=Space.EMPTY,
                _markers=Markers.EMPTY,
            )

            # Map conversion flag
            conversion_enum = None
            if conversion == 'r':
                conversion_enum = FormattedString.Value.Conversion.REPR
            elif conversion == 's':
                conversion_enum = FormattedString.Value.Conversion.STR
            elif conversion == 'a':
                conversion_enum = FormattedString.Value.Conversion.ASCII

            # Format spec
            format_node = None
            if format_spec:
                format_node = Literal(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _value=format_spec,
                    _value_source=format_spec,
                    _unicode_escapes=None,
                    _type=None,
                )

            parts.append(FormattedString.Value(
                _id=random_id(),
                _prefix=Space.EMPTY,
                _markers=Markers.EMPTY,
                _expression=padded_expr,
                _debug=None,
                _conversion=conversion_enum,
                _format=format_node,
            ))

    return FormattedString(
        _id=random_id(),
        _prefix=method.prefix,
        _markers=Markers.EMPTY,
        _delimiter=delimiter,
        _parts=parts,
        _type=None,
    )


@categorize(_Python36)
class ReplaceStrFormatWithFString(Recipe):
    """
    Replace ``"...".format(...)`` calls with f-strings.

    Converts ``str.format()`` calls where the receiver is a string literal
    to equivalent f-strings (Python 3.6+). Only converts cases where the
    conversion is safe and unambiguous.

    Example:
        Before:
            message = "Hello {}".format(name)

        After:
            message = f"Hello {name}"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceStrFormatWithFString"

    @property
    def display_name(self) -> str:
        return "Replace `str.format()` with f-string"

    @property
    def description(self) -> str:
        return (
            'Replace `"...".format(...)` calls with f-strings (Python 3.6+). '
            "Only converts cases where the format string is a literal and the "
            "conversion is safe."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.6", "f-string"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[Expression]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method, MethodInvocation):
                    return method

                # Check if method name is "format"
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "format":
                    return method

                # Check if the select (receiver) is a string literal
                select = method.select
                if select is None or not _is_string_literal(select):
                    return method

                result = _convert_format_to_fstring(method)
                if result is not None:
                    return result

                return method

        return Visitor()


def _parse_percent_format(format_string: str) -> Optional[List[tuple]]:
    """Parse a %-format string into a list of (type, value) tuples.

    Returns a list of tuples:
    - ('literal', text) for literal text parts
    - ('spec', 's'|'r') for %s/%r specifiers

    Returns None if the format string contains unsupported specifiers
    (e.g. %d, %f, %(name)s, %-10s).
    """
    parts = []
    i = 0
    current_literal: List[str] = []

    while i < len(format_string):
        if format_string[i] == '%':
            if i + 1 >= len(format_string):
                return None  # Trailing %
            next_char = format_string[i + 1]
            if next_char == '%':
                current_literal.append('%')
                i += 2
            elif next_char in ('s', 'r'):
                if current_literal:
                    parts.append(('literal', ''.join(current_literal)))
                    current_literal = []
                parts.append(('spec', next_char))
                i += 2
            else:
                return None  # Unsupported specifier
        else:
            current_literal.append(format_string[i])
            i += 1

    if current_literal:
        parts.append(('literal', ''.join(current_literal)))

    return parts


def _convert_percent_to_fstring(binary: Binary) -> Optional[FormattedString]:
    """Convert a ``"..." % (...)`` Binary to a FormattedString.

    Returns None if the conversion is not safe.
    """
    left = binary.left
    if not isinstance(left, Literal):
        return None

    value_source = left.value_source
    if not value_source:
        return None

    # Determine f-string delimiter (also bails on bytes/raw)
    delimiter = _get_fstring_delimiter(value_source)
    if delimiter is None:
        return None

    # Bail out on backslash escapes
    if _has_backslash(value_source):
        return None

    # Get the actual format string value
    format_string = left.value
    if not isinstance(format_string, str):
        return None

    # Parse the format string
    parsed = _parse_percent_format(format_string)
    if parsed is None:
        return None

    # Count specifiers
    spec_count = sum(1 for t, _ in parsed if t == 'spec')

    # Extract arguments from right-hand side
    right = binary.right

    # Unwrap Parentheses if present
    if isinstance(right, Parentheses):
        right = right.tree

    # Get argument list
    if isinstance(right, CollectionLiteral) and right.kind == CollectionLiteral.Kind.TUPLE:
        args = list(right.elements)
    else:
        args = [right]

    # Verify arg count matches specifier count
    if len(args) != spec_count:
        return None

    # Build f-string parts
    parts: List[Expression] = []
    arg_index = 0

    for part_type, part_value in parsed:
        if part_type == 'literal':
            # Re-escape braces for f-string source
            escaped_text = part_value.replace('{', '{{').replace('}', '}}')
            parts.append(Literal(
                _id=random_id(),
                _prefix=Space.EMPTY,
                _markers=Markers.EMPTY,
                _value=part_value,
                _value_source=escaped_text,
                _unicode_escapes=None,
                _type=None,
            ))
        elif part_type == 'spec':
            arg_expr = args[arg_index]
            arg_index += 1

            padded_expr = JRightPadded(
                _element=arg_expr.replace(_prefix=Space.EMPTY),
                _after=Space.EMPTY,
                _markers=Markers.EMPTY,
            )

            conversion_enum = None
            if part_value == 'r':
                conversion_enum = FormattedString.Value.Conversion.REPR

            parts.append(FormattedString.Value(
                _id=random_id(),
                _prefix=Space.EMPTY,
                _markers=Markers.EMPTY,
                _expression=padded_expr,
                _debug=None,
                _conversion=conversion_enum,
                _format=None,
            ))

    return FormattedString(
        _id=random_id(),
        _prefix=binary.prefix,
        _markers=Markers.EMPTY,
        _delimiter=delimiter,
        _parts=parts,
        _type=None,
    )


@categorize(_Python36)
class ReplacePercentFormatWithFString(Recipe):
    """
    Replace ``"..." % (...)`` expressions with f-strings.

    Converts %-style string formatting where the format string is a literal
    containing only ``%s`` and ``%r`` specifiers to equivalent f-strings
    (Python 3.6+). Only converts cases where the conversion is safe and
    unambiguous.

    Example:
        Before:
            message = "Hello %s" % name

        After:
            message = f"Hello {name}"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePercentFormatWithFString"

    @property
    def display_name(self) -> str:
        return "Replace `%` formatting with f-string"

    @property
    def description(self) -> str:
        return (
            'Replace `"..." % (...)` expressions with f-strings (Python 3.6+). '
            "Only converts `%s` and `%r` specifiers where the format string is "
            "a literal and the conversion is safe."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.6", "f-string"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: Binary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_binary(binary, p)

                if not isinstance(binary, Binary):
                    return binary

                # Check if this is a modulo operation (%)
                if binary.operator != Binary.Type.Modulo:
                    return binary

                # Check if the left side is a string literal
                if not _is_string_literal(binary.left):
                    return binary

                result = _convert_percent_to_fstring(binary)
                if result is not None:
                    return result

                return binary

        return Visitor()
