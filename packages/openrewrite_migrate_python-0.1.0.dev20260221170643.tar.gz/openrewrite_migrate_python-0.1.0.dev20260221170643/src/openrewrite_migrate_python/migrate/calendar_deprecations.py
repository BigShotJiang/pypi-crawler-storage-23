"""
Recipes for migrating deprecated calendar module constants.

The mixed-case month and day constants were deprecated in Python 3.12
in favor of uppercase constants:

- calendar.January → calendar.JANUARY
- calendar.February → calendar.FEBRUARY
- ... and so on for all months and days

See: https://docs.python.org/3/library/calendar.html
"""

from typing import Any, Optional, Dict

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, FieldAccess

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

# Mapping of deprecated constant names to their uppercase replacements
CALENDAR_CONSTANTS: Dict[str, str] = {
    # Month constants
    "January": "JANUARY",
    "February": "FEBRUARY",
    "March": "MARCH",
    "April": "APRIL",
    "May": "MAY",
    "June": "JUNE",
    "July": "JULY",
    "August": "AUGUST",
    "September": "SEPTEMBER",
    "October": "OCTOBER",
    "November": "NOVEMBER",
    "December": "DECEMBER",
    # Day constants
    "Monday": "MONDAY",
    "Tuesday": "TUESDAY",
    "Wednesday": "WEDNESDAY",
    "Thursday": "THURSDAY",
    "Friday": "FRIDAY",
    "Saturday": "SATURDAY",
    "Sunday": "SUNDAY",
}


def _is_calendar_access(identifier: Identifier) -> bool:
    """
    Check if this identifier looks like a calendar module constant access.

    Without full type attribution, we check for common patterns.
    """
    # The identifier itself should be a known calendar constant name
    return identifier.simple_name in CALENDAR_CONSTANTS


@categorize(_Python312)
class ReplaceCalendarConstants(Recipe):
    """
    Replace deprecated calendar module constants with uppercase equivalents.

    In Python 3.12, the mixed-case calendar constants were deprecated in favor
    of uppercase versions:
    - calendar.January → calendar.JANUARY
    - calendar.Monday → calendar.MONDAY
    - etc.

    Example:
        Before:
            import calendar
            first_month = calendar.January
            start_of_week = calendar.Monday

        After:
            import calendar
            first_month = calendar.JANUARY
            start_of_week = calendar.MONDAY
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceCalendarConstants"

    @property
    def display_name(self) -> str:
        return "Replace deprecated calendar constants with uppercase"

    @property
    def description(self) -> str:
        return (
            "Replace deprecated mixed-case calendar constants like `calendar.January` "
            "with their uppercase equivalents like `calendar.JANUARY`. "
            "The mixed-case constants were deprecated in Python 3.12."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                # Check if accessing a calendar module constant
                name = field_access.name
                if not isinstance(name, Identifier):
                    return field_access

                const_name = name.simple_name
                if const_name not in CALENDAR_CONSTANTS:
                    return field_access

                # Check if the target is the calendar module
                target = field_access.target
                if isinstance(target, Identifier) and target.simple_name == "calendar":
                    # Replace with uppercase version
                    new_name_str = CALENDAR_CONSTANTS[const_name]
                    new_identifier = name.replace(_simple_name=new_name_str)
                    # Replace the name in the field access via padding
                    return field_access.padding.replace(
                        name=field_access.padding.name.replace(element=new_identifier)
                    )

                return field_access

        return Visitor()
