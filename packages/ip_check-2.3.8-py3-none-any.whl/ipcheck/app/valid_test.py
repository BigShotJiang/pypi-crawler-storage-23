#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Iterable
from ipcheck import IpcheckStage
from ipcheck.app.statemachine import state_machine
from ipcheck.app.valid_test_config import ValidTestConfig
from ipcheck.app.utils import console_print, console_refresh, adjust_list_by_size, parse_url
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import urllib3
from ipcheck.app.ip_info import IpInfo
urllib3.disable_warnings()

from ipcheck import USER_AGENTS
import random


class ValidTest:

    def __init__(self, ip_list: Iterable[IpInfo], config: ValidTestConfig) -> None:
        self.ip_list = ip_list
        self.config = config

    def run(self) -> Iterable[IpInfo]:
        if not self.config.enabled:
            console_print('跳过可用性测试')
            return self.ip_list
        state_machine.ipcheck_stage = IpcheckStage.VALID_TEST
        state_machine.stop_event.clear()
        state_machine.clear()
        console_print('准备测试可用性 ... ...')
        if len(self.ip_list) > self.config.ip_limit_count:
            console_print('待测试ip 过多, 当前最大限制数量为{} 个, 压缩中... ...'.format(self.config.ip_limit_count))
            self.ip_list = adjust_list_by_size(self.ip_list, self.config.ip_limit_count)
        console_print('可用性域名为: {}'.format(self.config.host_name))
        console_print('是否使用user-agent: {}'.format(self.config.user_agent))
        total_count = len(self.ip_list)
        console_print('正在测试ip可用性, 总数为{}'.format(total_count))
        passed_ips = []
        thread_pool_executor = ThreadPoolExecutor(
            max_workers=self.config.thread_num, thread_name_prefix="valid_")
        all_task = [thread_pool_executor.submit(
            self.__test, ip_info) for ip_info in self.ip_list]
        test_count = 0
        pass_count = 0

        not_done_futures = set(all_task)
        while not_done_futures:
            if state_machine.ipcheck_stage != IpcheckStage.VALID_TEST:
                for f in not_done_futures:
                    f.cancel()
                thread_pool_executor.shutdown(wait=False)
                return passed_ips  # 立即返回，不继续后续逻辑

            done, not_done_futures = wait(not_done_futures, return_when=FIRST_COMPLETED, timeout=0.5)
            for future in done:
                test_count += 1
                try:
                    ret = future.result()
                    if ret:
                        pass_count += 1
                        passed_ips.append(ret)
                        state_machine.cache(ret)
                except Exception:
                    pass
                content = '  当前进度为: {}/{}, {} pass'.format(test_count, total_count, pass_count)
                console_refresh(content)

        thread_pool_executor.shutdown(wait=True)
        console_print('可用性结果为: 总数{}, {} pass'.format(len(self.ip_list), len(passed_ips)))
        return passed_ips

    def __test(self, ip_info) -> None:
        if state_machine.ipcheck_stage != IpcheckStage.VALID_TEST:
            return None
        check_key = self.config.check_key
        pool = urllib3.HTTPSConnectionPool(
                ip_info.ip, assert_hostname=self.config.host_name,
                server_hostname=self.config.host_name,
                port=ip_info.port, cert_reqs='CERT_NONE')
        res = None
        headers = {
            'Host': self.config.host_name,
        }
        if self.config.user_agent:
            headers.update({'User-Agent': random.choice(USER_AGENTS)})
        try:
            with pool.urlopen('GET', self.config.path,
                                               retries=urllib3.util.Retry(self.config.max_retry, backoff_factor=self.config.retry_factor, respect_retry_after_header=False),
                                               headers=headers,
                                               assert_same_host=False,
                                               timeout=self.config.timeout,
                                               preload_content=False,
                                               redirect=True) as r:
                if state_machine.ipcheck_stage != IpcheckStage.VALID_TEST:
                    return None
                if '/cdn-cgi/trace' == self.config.path:
                    req_dict = {}
                    for line in r.readlines():
                        line = line.decode('utf-8')
                        kv = line.strip().split('=')
                        req_dict.update({kv[0]: kv[1]})
                    if req_dict.get(check_key, None) == self.config.host_name:
                        loc = req_dict.get('loc', None)
                        colo = req_dict.get('colo', None)
                        ip_info.loc = loc
                        ip_info.colo = colo
                        res = ip_info
                elif r.status == 200:
                    res = ip_info
            pool.close()

            # 二次验证: 检查大文件Content-Length
            if res and self.config.file_check and self.config.file_url:
                if state_machine.ipcheck_stage != IpcheckStage.VALID_TEST:
                    return None
                file_host, file_path = parse_url(self.config.file_url)
                file_headers = {'Host': file_host}
                if self.config.user_agent:
                    file_headers.update({'User-Agent': random.choice(USER_AGENTS)})

                # 创建独立的连接池以确保 SNI 正确
                file_pool = urllib3.HTTPSConnectionPool(
                    ip_info.ip,
                    assert_hostname=file_host,
                    server_hostname=file_host,
                    port=ip_info.port,
                    cert_reqs='CERT_NONE')

                with file_pool.urlopen('GET', file_path,
                                  headers=file_headers,
                                  assert_same_host=False,
                                  timeout=self.config.timeout,
                                  retries=urllib3.util.Retry(self.config.max_retry, backoff_factor=self.config.retry_factor, respect_retry_after_header=False),
                                  preload_content=False,
                                  redirect=True) as fr:
                    if state_machine.ipcheck_stage != IpcheckStage.VALID_TEST:
                        return None
                    if fr.status == 200:
                        cl = fr.headers.get('Content-Length', 0)
                        if not cl or int(cl) <= 0:
                            res = None
                    else:
                        res = None
                file_pool.close()
        except Exception as e:
            res = None
            if self.config.print_err:
                console_print(f'valid test for {ip_info.simple_info} encounters err {e}')
        return res
