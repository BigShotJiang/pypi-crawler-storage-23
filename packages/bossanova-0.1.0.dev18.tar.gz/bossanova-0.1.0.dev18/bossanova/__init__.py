# Backend API (must be imported first, before any JAX usage)
from bossanova.internal.maths.backend import backend, get_backend, set_backend

# Configure JAX x64 eagerly if JAX is available — SINGLE AUTHORITATIVE LOCATION.
# This MUST happen before any JAX arrays are created anywhere in the codebase.
# We cannot defer this to lazy loading because submodules (e.g., lmer_core.py)
# import JAX at module level and would create float32 arrays otherwise.
# All other modules rely on this having run at import time.
try:
    import jax

    jax.config.update("jax_enable_x64", True)
except (ImportError, AttributeError):
    pass  # JAX not available or partially initialized, will use numpy backend

# Configuration
from bossanova.internal.maths.config import (  # noqa: E402
    get_display_digits,
    get_singular_tolerance,
    set_display_digits,
    set_singular_tolerance,
)

# Data loading
from bossanova.data import (  # noqa: E402
    load_dataset,
    show_datasets,
)

# Unified model
from bossanova.model import model  # noqa: E402

# Statistics
from bossanova.internal.compare import compare, lrt  # noqa: E402

# Visualization
from bossanova.internal import viz  # noqa: E402

# Expressions
from bossanova import expressions  # noqa: E402

__all__ = [
    "backend",
    "compare",
    "expressions",
    "get_backend",
    "get_display_digits",
    "get_singular_tolerance",
    "load_dataset",
    "lrt",
    "model",
    "set_backend",
    "set_display_digits",
    "set_singular_tolerance",
    "show_datasets",
    "viz",
]

from importlib.metadata import version as _get_version

__version__ = _get_version("bossanova")
