"""Design matrix construction — coding, naming, reference grids, random effects.

Call chain:
    formula.build_design_matrices() -> treatment_coding() / sum_coding() / ... (categorical columns)
    marginal.build_reference_grid() -> build_reference_row() (EMM reference grids)
    formula.build_random_effects_from_spec() -> build_z_simple() / build_z_nested() / build_z_crossed()

Submodules:
    coding: Contrast matrix builders for categorical encoding (treatment, sum, helmert, poly)
    names: Design matrix column name parsing and variable type detection
    reference: Reference design matrix (X_ref) for marginal effects
    z_matrix: Sparse Z matrix (random effects design matrix) construction
"""

from .coding import (
    array_to_coding_matrix,
    convert_coding_to_hypothesis,
    helmert_coding,
    helmert_coding_labels,
    poly_coding,
    poly_coding_labels,
    sequential_coding,
    sequential_coding_labels,
    sum_coding,
    sum_coding_labels,
    treatment_coding,
    treatment_coding_labels,
)
from .names import (
    DesignColumnInfo,
    extract_base_term,
    extract_categorical_variables,
    extract_level_from_column,
    identify_column_type,
    parse_design_column_name,
)
from .reference import (
    build_reference_design_matrix,
    build_reference_row,
    build_slope_reference_matrix,
)
from .z_matrix import (
    RandomEffectsInfo,
    build_random_effects,
    build_z_crossed,
    build_z_nested,
    build_z_simple,
)

__all__ = [
    "DesignColumnInfo",
    "RandomEffectsInfo",
    "array_to_coding_matrix",
    "build_random_effects",
    "build_reference_design_matrix",
    "build_reference_row",
    "build_slope_reference_matrix",
    "build_z_crossed",
    "build_z_nested",
    "build_z_simple",
    "convert_coding_to_hypothesis",
    "extract_base_term",
    "extract_categorical_variables",
    "extract_level_from_column",
    "helmert_coding",
    "helmert_coding_labels",
    "identify_column_type",
    "parse_design_column_name",
    "poly_coding",
    "poly_coding_labels",
    "sequential_coding",
    "sequential_coding_labels",
    "sum_coding",
    "sum_coding_labels",
    "treatment_coding",
    "treatment_coding_labels",
]
