"""LaTeX equation rendering for model formulas.

Call chain:
    model.equation() -> build_equation(spec) -> LaTeX string

Container flow:
    Input: ModelSpec (formula, family, link, random terms)
    Output: str (LaTeX equation for display)

Submodules:
    latex: LaTeX string construction from model specification
"""

from bossanova.internal.rendering.latex import build_equation

__all__ = ["build_equation"]
