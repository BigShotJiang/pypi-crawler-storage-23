"""Formula parsing, design matrix construction, and newdata evaluation.

Call chain:
    model(formula, data) -> parse_formula() -> build_bundle_from_data() -> build_design_matrices()
    model.predict(newdata=) -> evaluate_newdata() (applies learned encoding to new observations)

Container flow:
    Input: formula string + Polars DataFrame
    Output: FormulaSpec (via parse_formula) + DataBundle (X, y, Z matrices via build_design_matrices)

Submodules:
    parse: R-style formula string parsing into FormulaSpec
    parser/: Recursive descent parser (scanner, tokens, AST nodes)
    design: Design matrix construction from FormulaSpec
    evaluate: Term evaluation (AST nodes to design matrix columns)
    evaluate_transforms: Stateful, math, and polynomial transforms
    evaluate_contrast: Contrast function evaluation for categorical encoding
    evaluate_newdata: Apply learned encoding to new observations
    encoding: Categorical variable encoding using Polars Enum
    random_effects: Z matrix construction from FormulaSpec
    helpers: Shared AST utilities
    bundle: DataBundle construction from formula + DataFrame
    contrast_registry: Contrast function vocabulary and validation
    contrast_specs: User-facing contrast specification resolution
"""

from bossanova.internal.formula.design import (
    DesignResult,
    build_design_matrices,
)
from bossanova.internal.formula.evaluate import (
    TermResult,
)
from bossanova.internal.formula.evaluate_newdata import (
    evaluate_newdata,
)
from bossanova.internal.formula.parse import (
    FormulaError,
    expand_double_verts,
    expand_nested_syntax,
    parse_formula,
)
from bossanova.internal.formula.random_effects import (
    build_random_effects_from_spec,
)

__all__ = [
    "DesignResult",
    "FormulaError",
    "TermResult",
    "build_design_matrices",
    "build_random_effects_from_spec",
    "evaluate_newdata",
    "expand_double_verts",
    "expand_nested_syntax",
    "parse_formula",
]
