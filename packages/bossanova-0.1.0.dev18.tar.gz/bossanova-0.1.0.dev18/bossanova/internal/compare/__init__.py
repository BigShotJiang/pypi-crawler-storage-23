"""Model comparison: information criteria, likelihood ratio tests, and composite tables.

Call chain:
    bossanova.compare(m1, m2, ...) -> compare() (composite AIC/BIC/loglik table)
    bossanova.lrt(m1, m2) -> lrt() (nested model likelihood ratio test)

Container flow:
    Input: Sequence of fitted model instances
    Output: Polars DataFrame with comparison metrics

Submodules:
    compare: Composite comparison table (AIC, BIC, loglik, df)
    ic: Information criterion comparison (delta-AIC/BIC, Akaike/Schwarz weights)
    lrt: Likelihood ratio test for nested mixed models
    lrt_compare: LRT implementation details
    f_test: F-test for nested linear models
    deviance: Deviance test for nested GLMs
    cv: Cross-validation comparison (Nadeau-Bengio corrected t-test)
    refit: REML-to-ML refit helper for mixed model comparison
    helpers: Shared formatting utilities
"""

from bossanova.internal.compare.compare import compare
from bossanova.internal.compare.ic import compare_aic, compare_bic
from bossanova.internal.compare.lrt import lrt

__all__ = ["compare", "compare_aic", "compare_bic", "lrt"]
