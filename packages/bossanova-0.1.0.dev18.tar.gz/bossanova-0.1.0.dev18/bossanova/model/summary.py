"""Summary formatting for model results.

Provides functions to format model summaries in R-like and compact styles.
Used by the model.summary() method.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.fit.diagnostics import compute_r_squared
from bossanova.internal.maths.inference import compute_aic, compute_bic

# Human-readable model type names
_MODEL_TYPE_DISPLAY: dict[str, str] = {
    "lm": "Linear Model",
    "glm": "Generalized Linear Model",
    "lmer": "Linear Mixed Model",
    "glmer": "Generalized Linear Mixed Model",
}

if TYPE_CHECKING:
    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        InferenceState,
        MeeState,
        ModelSpec,
    )


__all__ = ["FormattedText", "format_summary"]


class FormattedText(str):
    """String subclass that displays without quotes in the REPL.

    Returned by :meth:`model.summary` so that typing ``m.summary()``
    in a REPL or notebook displays the formatted output directly,
    without needing ``print()``.  All ``str`` operations (``in``,
    ``len``, slicing, etc.) work as expected.
    """

    def __repr__(self) -> str:
        return str(self)


# =============================================================================
# Significance codes
# =============================================================================


def significance_code(p: float) -> str:
    """Return significance code for p-value (R-style).

    Args:
        p: P-value.

    Returns:
        Significance code: '***', '**', '*', '.', or ' '.
    """
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    if p < 0.1:
        return "."
    return " "


def format_pvalue(p: float, digits: int = 4) -> str:
    """Format p-value for display.

    Args:
        p: P-value.
        digits: Number of decimal places for numeric p-values.

    Returns:
        Formatted string, e.g., '<2e-16' for very small values.
    """
    if p <= 2.3e-16:
        return "<2.2e-16"
    if p < 0.001:
        return f"{p:.2e}"
    return f"{p:.{digits}f}"


# =============================================================================
# R-style summary
# =============================================================================


def format_r_style(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    mee: MeeState | None,
    last_op: str | None,
    digits: int = 3,
) -> str:
    """Format model summary in R style.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fitting results.
        params_inference: Optional inference state.
        mee: Optional marginal effects state.
        last_op: Last operation performed.
        digits: Number of decimal places for numeric output.

    Returns:
        Formatted summary string.
    """
    lines: list[str] = []
    d = digits

    # Header with model type
    type_name = model_type_name(spec)
    lines.append(f"{type_name}: {spec.formula}")
    lines.append("")

    # Residual summary
    residuals = fit.residuals
    quartiles = np.percentile(residuals, [0, 25, 50, 75, 100])
    col_w = d + 4  # sign + digit(s) + dot + digits
    lines.append("Residuals:")
    lines.append("    Min      1Q  Median      3Q     Max")
    lines.append(
        f"{quartiles[0]:>{col_w}.{d}f} {quartiles[1]:>{col_w}.{d}f} "
        f"{quartiles[2]:>{col_w}.{d}f} "
        f"{quartiles[3]:>{col_w}.{d}f} {quartiles[4]:>{col_w}.{d}f}"
    )
    lines.append("")

    # Coefficient table
    lines.append("Coefficients:")
    lines.extend(format_coef_table(bundle, fit, params_inference, digits=d))
    lines.append("")

    # Significance codes (only if we have inference)
    if params_inference is not None:
        lines.append("---")
        lines.append("Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1")
        lines.append("")

    # Model-level statistics
    lines.extend(format_model_stats(spec, bundle, fit, digits=d))

    # Marginal effects summary if last op was explore and has inference
    if last_op == "explore" and mee is not None and mee.has_inference:
        lines.append("")
        lines.append("---")
        lines.extend(format_mee_summary(mee, digits=d))

    return "\n".join(lines)


def format_coef_table(
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    *,
    digits: int = 3,
) -> list[str]:
    """Format coefficient table.

    Args:
        bundle: Data bundle with term names.
        fit: Fitting results with coefficients.
        params_inference: Optional inference state.
        digits: Number of decimal places for numeric output.

    Returns:
        List of formatted table lines.
    """
    lines: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    d = digits

    # Column widths adapt to digits
    est_w = d + 5  # sign + digits + dot + digits
    se_w = d + 4
    stat_w = d + 4

    # Calculate column widths
    max_term_width = max(len(name) for name in term_names)
    max_term_width = max(max_term_width, 11)  # At least as wide as "(Intercept)"

    if params_inference is not None:
        # Full table with inference
        header = f"{'':>{max_term_width}}  Estimate  Std.Err  t value  Pr(>|t|)    "
        lines.append(header)

        se = params_inference.se
        statistic = params_inference.statistic
        p_value = params_inference.p_value

        for i, name in enumerate(term_names):
            sig = significance_code(p_value[i])
            p_str = format_pvalue(p_value[i], digits=d)
            lines.append(
                f"{name:>{max_term_width}}  {estimates[i]:>{est_w}.{d}f}  "
                f"{se[i]:>{se_w}.{d}f}  "
                f"{statistic[i]:>{stat_w}.{max(d - 1, 1)}f}  {p_str:>8} {sig}"
            )
    else:
        # Simple table without inference
        header = f"{'':>{max_term_width}}  Estimate"
        lines.append(header)

        for i, name in enumerate(term_names):
            lines.append(f"{name:>{max_term_width}}  {estimates[i]:>{est_w}.{d}f}")

    return lines


def format_model_stats(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    *,
    digits: int = 3,
) -> list[str]:
    """Format model-level statistics.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        digits: Number of decimal places for numeric output.

    Returns:
        List of formatted statistics lines.
    """
    lines: list[str] = []
    d = digits

    # Residual standard error / sigma
    if fit.sigma is not None:
        lines.append(f"Residual std error: {fit.sigma:.{d}f} on {fit.df_resid:.0f} df")
    elif fit.dispersion is not None:
        lines.append(f"Dispersion parameter: {fit.dispersion:.{d}f}")

    # R-squared for gaussian models
    if spec.family == "gaussian" and not spec.has_random_effects:
        r_squared, adj_r_squared = compute_r_squared(
            bundle.y, fit.residuals, bundle.n, bundle.p
        )
        lines.append(
            f"Multiple R-squared: {r_squared:.{d}f}, "
            f"Adjusted R-squared: {adj_r_squared:.{d}f}"
        )

    # AIC and BIC
    k = len(fit.coef)
    if fit.theta is not None:
        k += len(fit.theta)
    aic = compute_aic(float(fit.loglik), k)
    bic = compute_bic(float(fit.loglik), k, bundle.n)
    lines.append(f"AIC: {aic:.{max(d - 2, 1)}f}, BIC: {bic:.{max(d - 2, 1)}f}")

    return lines


def format_mee_summary(mee: MeeState, *, digits: int = 3) -> list[str]:
    """Format marginal effects summary.

    Args:
        mee: Marginal effects state.
        digits: Number of decimal places for numeric output.

    Returns:
        List of formatted lines.
    """
    lines: list[str] = []
    d = digits
    lines.append(f"Marginal Effects ({mee.type}): {mee.explore_formula}")
    lines.append("")

    # Simple table of estimates
    grid_cols = mee.grid.columns
    estimates = mee.estimate

    # Header
    header_parts = list(grid_cols) + ["estimate"]
    if mee.se is not None:
        header_parts.extend(["se", "p_value"])
    lines.append("  ".join(f"{h:>12}" for h in header_parts))

    # Rows
    grid_data = mee.grid.to_dicts()
    for i, row in enumerate(grid_data):
        row_parts = [str(row[col])[:12] for col in grid_cols]
        row_parts.append(f"{estimates[i]:.{d}f}")
        if mee.se is not None:
            row_parts.append(f"{mee.se[i]:.{d}f}")
            if mee.p_value is not None:
                row_parts.append(format_pvalue(mee.p_value[i], digits=d))
        lines.append("  ".join(f"{p:>12}" for p in row_parts))

    return lines


# =============================================================================
# Compact summary
# =============================================================================


def format_compact(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    mee: MeeState | None,
    last_op: str | None,
    digits: int = 3,
) -> str:
    """Format model summary in compact style.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fitting results.
        params_inference: Optional inference state.
        mee: Optional marginal effects state.
        last_op: Last operation performed.
        digits: Number of decimal places for numeric output.

    Returns:
        Formatted summary string.
    """
    lines: list[str] = []
    d = digits

    # First line: model info
    model_info_parts = [f"model({spec.formula})"]

    # Add key statistics
    if spec.family == "gaussian" and not spec.has_random_effects:
        r_squared, _ = compute_r_squared(bundle.y, fit.residuals, bundle.n, bundle.p)
        model_info_parts.append(f"R2={r_squared:.{d}f}")
    else:
        k = len(fit.coef)
        if fit.theta is not None:
            k += len(fit.theta)
        model_info_parts.append(
            f"AIC={compute_aic(float(fit.loglik), k):.{max(d - 2, 1)}f}"
        )

    model_info_parts.append(f"n={bundle.n}")
    lines.append(": ".join([model_info_parts[0], ", ".join(model_info_parts[1:])]))

    # Second line: coefficient summary
    coef_parts = []
    term_names = bundle.X_names
    estimates = fit.coef

    for i, name in enumerate(term_names):
        if params_inference is not None:
            p = params_inference.p_value[i]
            if p < 0.001:
                p_str = "p<0.001"
            elif p < 0.01:
                p_str = "p<0.01"
            elif p < 0.05:
                p_str = "p<0.05"
            else:
                p_str = f"p={p:.{max(d - 1, 1)}f}"
            coef_parts.append(f"{name}: {estimates[i]:.{d}f} ({p_str})")
        else:
            coef_parts.append(f"{name}: {estimates[i]:.{d}f}")

    lines.append(", ".join(coef_parts))

    # Marginal effects if available
    if last_op == "explore" and mee is not None:
        mee_info = f"MEE ({mee.focal_var}): {len(mee.estimate)} estimates"
        if mee.has_inference:
            # Count significant at p < 0.05
            if mee.p_value is not None:
                n_sig = np.sum(mee.p_value < 0.05)
                mee_info += f", {n_sig} significant (p<0.05)"
        lines.append(mee_info)

    return "\n".join(lines)


# =============================================================================
# Model type name
# =============================================================================


def model_type_name(spec: ModelSpec) -> str:
    """Get human-readable model type name.

    Args:
        spec: Model specification.

    Returns:
        Model type name string.
    """
    if spec.has_random_effects:
        model_type = "lmer" if spec.family == "gaussian" else "glmer"
    else:
        model_type = "lm" if spec.family == "gaussian" else "glm"
    base_name = _MODEL_TYPE_DISPLAY[model_type]
    if spec.family == "gaussian":
        return base_name
    return f"{base_name} ({spec.family})"


# =============================================================================
# Main entry point
# =============================================================================


def format_summary(
    *,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None = None,
    mee: MeeState | None = None,
    last_op: str | None = None,
    style: str = "r",
    digits: int = 3,
) -> FormattedText:
    """Format a model summary.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fitting results.
        params_inference: Optional inference state for parameters.
        mee: Optional marginal effects state.
        last_op: Last operation performed on the model.
        style: Output style ("r" or "compact").
        digits: Number of decimal places for numeric output.

    Returns:
        FormattedText that displays without needing ``print()``.

    Raises:
        ValueError: If style is not recognized.

    Examples:
        >>> m = model("y ~ x", data).fit().infer()
        >>> m.summary()  # Displays formatted output directly
    """
    if style == "r":
        text = format_r_style(
            spec, bundle, fit, params_inference, mee, last_op, digits=digits
        )
    elif style == "compact":
        text = format_compact(
            spec, bundle, fit, params_inference, mee, last_op, digits=digits
        )
    else:
        raise ValueError(f"Unknown summary style: {style!r}. Use 'r' or 'compact'.")
    return FormattedText(text)
