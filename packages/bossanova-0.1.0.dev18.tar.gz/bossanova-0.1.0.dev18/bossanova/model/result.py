"""ModelResult — display-friendly proxy returned by model methods.

When a model method like ``.fit()``, ``.explore()``, or ``.infer()`` is
called, it returns a ``ModelResult`` instead of the raw model instance.
This proxy delegates display to the underlying result DataFrame, giving
notebook environments (marimo, Jupyter) consistent rendering with property
access (e.g., ``.params``, ``.effects``).

All other attribute access and method calls are forwarded to the model
instance, so method chaining works seamlessly::

    m = model("y ~ x", data).fit().infer()   # Each returns ModelResult
    m.params          # Forwarded to model.params → DataFrame
    m.explore("x")    # Forwarded to model.explore() → new ModelResult
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl

if TYPE_CHECKING:
    from bossanova.model.core import model

__all__ = ["ModelResult"]


class ModelResult:
    """Proxy returned by model methods that renders as a DataFrame.

    Enables consistent notebook rendering (marimo, Jupyter) by delegating
    ``_repr_html_`` to the current result DataFrame, while forwarding all
    model methods and properties for seamless chaining.

    The displayed DataFrame is always the *current* result — determined
    dynamically by the model's ``_last_op`` state — so mutations to the
    model are reflected immediately.

    Args:
        model_ref: The model instance that produced this result.
    """

    __slots__ = ("_model",)

    def __init__(self, model_ref: model) -> None:
        object.__setattr__(self, "_model", model_ref)

    @property
    def dataframe(self) -> pl.DataFrame | None:
        """The current result DataFrame.

        Returns the same DataFrame as the corresponding model property
        (``.params``, ``.effects``, ``.predictions``, etc.) based on
        whichever method was called last.

        Returns:
            Polars DataFrame for the last operation, or None if no
            result-producing method has been called.
        """
        return self._model._result_for_display()

    def __repr__(self) -> str:
        """Text representation with model header and result table.

        Delegates to the model's ``__repr__``, which includes the header
        line and (when ``_auto_display`` is True) the result DataFrame.

        Returns:
            String showing model metadata and optionally the result table.
        """
        return repr(self._model)

    def _repr_html_(self) -> str:
        """Rich HTML representation for notebooks.

        Returns just the result DataFrame's HTML table — no model header —
        for consistent rendering with property access like ``.effects``.
        Notebook environments (marimo, Jupyter) render this identically
        to a bare ``pl.DataFrame``.

        When no displayable result is available or auto-display is off,
        falls back to the model header in a ``<pre>`` tag.

        Returns:
            HTML string from the result DataFrame, or header-only HTML.
        """
        if not self._model._auto_display:
            return f"<pre>{self._model._header_repr()}</pre>"

        df = self._model._result_for_display()
        if df is None:
            return f"<pre>{self._model._header_repr()}</pre>"

        return df._repr_html_()

    def __getattr__(self, name: str) -> Any:
        """Forward attribute access to the underlying model.

        Enables seamless chaining (``m.fit().explore("x").infer()``) and
        property access (``m.fit().params``) through the proxy.

        Args:
            name: Attribute name to look up on the model.

        Returns:
            The attribute from the model instance.
        """
        return getattr(self._model, name)
