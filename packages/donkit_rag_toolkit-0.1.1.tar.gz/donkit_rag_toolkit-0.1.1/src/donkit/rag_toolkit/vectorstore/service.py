"""High-level vectorstore service.

Orchestrates URI validation and vectorstore operations.
Embeddings must be provided externally — this module does not
read credentials or create embedders.
"""

from __future__ import annotations

from langchain_core.embeddings import Embeddings

from donkit.rag_toolkit.vectorstore.loader import ProgressCallback
from donkit.rag_toolkit.vectorstore.loader import VectorstoreLoader


class VectorstoreService:
    """High-level service for vectorstore load/delete operations.

    Accepts ready-to-use Embeddings instances. Does not create embedders
    or read environment variables.
    """

    @staticmethod
    async def load(
        *,
        chunks_path: str,
        embeddings: Embeddings,
        backend: str = "qdrant",
        collection_name: str,
        database_uri: str = "http://localhost:6333",
        progress_callback: ProgressCallback | None = None,
    ) -> str:
        """Load chunks into vectorstore.

        Args:
            chunks_path: Path to chunked files (directory, file, or comma-separated).
            embeddings: Ready-to-use Embeddings instance.
            backend: Vectorstore backend (qdrant, chroma, milvus).
            collection_name: Collection name in vectorstore.
            database_uri: Database URI (localhost for local, any valid URI).
            progress_callback: Optional async callback for progress reporting.

        Returns:
            Summary string with load results.
        """
        loader = VectorstoreLoader(
            backend=backend,
            embeddings=embeddings,
            collection_name=collection_name,
            database_uri=database_uri,
        )

        result = await loader.load_from_path(
            chunks_path, progress_callback=progress_callback
        )
        return result.to_summary(collection_name, backend)

    @staticmethod
    def delete(
        *,
        embeddings: Embeddings,
        backend: str = "qdrant",
        collection_name: str,
        database_uri: str = "http://localhost:6333",
        filename: str | None = None,
        document_id: str | None = None,
    ) -> str:
        """Delete a document from vectorstore.

        Args:
            embeddings: Ready-to-use Embeddings instance.
            backend: Vectorstore backend.
            collection_name: Collection name.
            database_uri: Database URI.
            filename: Filename to delete.
            document_id: Document ID to delete.

        Returns:
            Status message string.
        """
        if not filename and not document_id:
            return "Error: must provide either 'filename' or 'document_id'"

        if filename and document_id:
            return "Error: provide only one of 'filename' or 'document_id', not both"

        try:
            loader = VectorstoreLoader(
                backend=backend,
                embeddings=embeddings,
                collection_name=collection_name,
                database_uri=database_uri,
            )
        except ValueError as e:
            return f"Error initializing vectorstore: {e}"
        except Exception as e:
            return f"Unexpected error during initialization: {e}"

        try:
            success = loader.delete_document(document_id=document_id, filename=filename)
            identifier = filename if filename else document_id

            if success:
                return (
                    f"Successfully deleted document from collection "
                    f"'{collection_name}' ({backend}):\n"
                    f"  Identifier: {identifier}"
                )
            else:
                return (
                    f"Failed to delete document from collection "
                    f"'{collection_name}' ({backend}):\n"
                    f"  Identifier: {identifier}\n"
                    f"  Document might not exist in the collection"
                )
        except Exception as e:
            return f"Error deleting document: {str(e)}"
