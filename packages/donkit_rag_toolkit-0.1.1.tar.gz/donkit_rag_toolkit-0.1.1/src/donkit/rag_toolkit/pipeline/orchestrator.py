"""RAG pipeline orchestrator.

Executes the full RAG build pipeline in a single call:
process documents -> chunk -> load to vectorstore.

Standalone version: does not read credentials, create embedders,
or manage Docker containers. All dependencies (RagConfig, Embeddings,
database_uri) must be provided externally.
"""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from donkit.chunker import ChunkerConfig
from langchain_core.embeddings import Embeddings
from loguru import logger

from donkit.rag_toolkit.chunking.service import ChunkingService
from donkit.rag_toolkit.config.validator import validate_rag_config
from donkit.rag_toolkit.document_processing.processor import DocumentProcessor
from donkit.rag_toolkit.schemas.config import RagConfig
from donkit.rag_toolkit.vectorstore.service import VectorstoreService

# Async progress callback: (step_number, total_steps, message) -> None
ProgressCallback = Callable[[int, int, str], object]

TOTAL_STEPS = 4


@dataclass
class PipelineBuildResult:
    """Result of a complete RAG pipeline build."""

    project_id: str
    vectorstore_url: str = ""
    documents_processed: int = 0
    chunks_created: int = 0
    chunks_loaded: int = 0
    skipped_files: list[dict[str, str]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_agent_response(self) -> str:
        """Format result for the LLM agent."""
        lines = [
            f"RAG pipeline built successfully for project '{self.project_id}'.",
            "",
            f"Documents processed: {self.documents_processed}",
            f"Chunks created: {self.chunks_created}",
            f"Chunks loaded to vectorstore: {self.chunks_loaded}",
        ]
        if self.skipped_files:
            lines.append(f"Skipped files: {len(self.skipped_files)}")
            for sf in self.skipped_files:
                lines.append(f"  - {sf['file']}: {sf['reason']}")
        lines.extend(
            [
                "",
                f"Vectorstore: {self.vectorstore_url}",
            ]
        )
        if self.errors:
            lines.append("")
            lines.append(f"Warnings ({len(self.errors)}):")
            for err in self.errors:
                lines.append(f"  - {err}")
        return "\n".join(lines)


class RagPipelineOrchestrator:
    """Orchestrates the full RAG build pipeline."""

    @staticmethod
    async def build(
        source_path: str,
        rag_config: RagConfig,
        embeddings: Embeddings,
        database_uri: str | None = None,
        project_id: str | None = None,
        progress_callback: ProgressCallback | None = None,
        llm_model: Any | None = None,
    ) -> PipelineBuildResult:
        """Build a complete RAG pipeline from source documents.

        Steps:
        1. Validate config
        2. Process documents
        3. Chunk documents
        4. Load chunks to vectorstore

        Args:
            source_path: Path to source files or directory.
            rag_config: RAG configuration (required).
            embeddings: Ready-to-use Embeddings instance (required).
            database_uri: URI of the vectorstore (e.g. http://localhost:6333).
                If not provided, falls back to rag_config.database_uri,
                then to local Chroma persistent storage at
                projects/{project_id}/chroma_db.
            project_id: Optional project ID. Auto-generated if None.
            progress_callback: Optional callback for progress reporting.
            llm_model: Optional LLM model instance for document processing.

        Returns:
            PipelineBuildResult with URLs and statistics.

        Raises:
            RuntimeError: If a critical pipeline step fails.
        """
        if not project_id:
            project_id = uuid.uuid4().hex[:12]

        if not database_uri:
            database_uri = rag_config.database_uri

        if not database_uri:
            database_uri = f"projects/{project_id}/chroma_db"
            rag_config.db_type = "chroma"
            logger.info(
                f"No database URI provided, using persistent Chroma at: {database_uri}"
            )

        result = PipelineBuildResult(
            project_id=project_id, vectorstore_url=database_uri
        )

        async def _progress(step: int, msg: str) -> None:
            logger.info(f"[Pipeline {project_id}] Step {step}/{TOTAL_STEPS}: {msg}")
            if progress_callback:
                cb_result = progress_callback(step, TOTAL_STEPS, msg)
                if asyncio.iscoroutine(cb_result):
                    await cb_result

        # Step 1: Validate config
        await _progress(1, "Validating RAG config")
        rag_config = validate_rag_config(rag_config, project_id=project_id)
        db_type = rag_config.db_type

        try:
            # Step 2: Process documents
            await _progress(2, "Processing documents")

            def _reader_progress(
                current: int, total: int, message: str | None = None
            ) -> None:
                if progress_callback:
                    msg = message or f"Processing page {current}/{total}"
                    cb = progress_callback(current, total, msg)
                    if asyncio.iscoroutine(cb):
                        asyncio.ensure_future(cb)

            async def _file_progress(current: int, total: int, message: str) -> None:
                if progress_callback:
                    cb = progress_callback(current, total, message)
                    if asyncio.iscoroutine(cb):
                        await cb

            doc_result = await DocumentProcessor.process_documents(
                source_path=source_path,
                project_id=project_id,
                reading_format=rag_config.reading_format,
                llm_model=llm_model,
                reader_progress_callback=_reader_progress
                if progress_callback
                else None,
                file_progress_callback=_file_progress if progress_callback else None,
                reading_pipeline=rag_config.reading_pipeline,
            )

            if isinstance(doc_result, dict) and doc_result.get("status") == "error":
                raise RuntimeError(
                    f"Document processing failed: {doc_result.get('message')}"
                )

            result.documents_processed = doc_result.get("processed_count", 0)
            result.skipped_files = doc_result.get("skipped_files", [])
            output_dir = doc_result.get(
                "output_directory", f"projects/{project_id}/processed"
            )

            # Step 3: Chunk documents
            await _progress(3, "Chunking documents")
            chunker_config = ChunkerConfig(
                split_type=rag_config.chunking_options.split_type,
                chunk_size=rag_config.chunking_options.chunk_size,
                chunk_overlap=rag_config.chunking_options.chunk_overlap,
            )
            chunk_result = ChunkingService.chunk_documents(
                source_path=output_dir,
                project_id=project_id,
                params=chunker_config,
                incremental=False,
            )

            if chunk_result.get("status") == "error":
                raise RuntimeError(f"Chunking failed: {chunk_result.get('message')}")

            chunks_created = sum(
                item.get("chunks_count", 0)
                for item in chunk_result.get("successful", [])
            )
            result.chunks_created = chunks_created
            chunks_path = chunk_result.get("output_path", "")

            # Step 4: Load chunks to vectorstore
            await _progress(4, "Loading chunks to vectorstore")
            collection_name = rag_config.retriever_options.collection_name or project_id

            async def _vs_progress(current: int, total: int, message: str) -> None:
                if progress_callback:
                    cb = progress_callback(current, total, message)
                    if asyncio.iscoroutine(cb):
                        await cb

            load_summary = await VectorstoreService.load(
                chunks_path=chunks_path,
                embeddings=embeddings,
                backend=db_type,
                collection_name=collection_name,
                database_uri=database_uri,
                progress_callback=_vs_progress if progress_callback else None,
            )

            result.chunks_loaded = result.chunks_created
            logger.debug(f"Vectorstore load summary: {load_summary}")

        except Exception as exc:
            logger.error(
                f"[Pipeline {project_id}] Failed: {type(exc).__name__}: {exc}",
                exc_info=True,
            )
            raise

        return result
