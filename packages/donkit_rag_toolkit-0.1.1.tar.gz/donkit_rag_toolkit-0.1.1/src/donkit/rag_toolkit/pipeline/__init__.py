"""RAG pipeline orchestration.

Provides RagPipelineOrchestrator for building complete RAG pipelines
in a single call: process documents -> chunk -> load to vectorstore.
"""

from .orchestrator import PipelineBuildResult
from .orchestrator import RagPipelineOrchestrator

__all__ = [
    "RagPipelineOrchestrator",
    "PipelineBuildResult",
]
