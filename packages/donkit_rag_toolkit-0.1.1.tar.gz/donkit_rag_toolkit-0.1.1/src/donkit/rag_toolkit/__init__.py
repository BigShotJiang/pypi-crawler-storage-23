"""
donkit-rag-toolkit — Standalone RAG toolkit.

Build, search, and evaluate RAG pipelines programmatically without CLI dependencies.
All credentials, embeddings, and database URI must be provided externally.

Usage:

    from donkit.rag_toolkit import RagPipelineOrchestrator, PipelineBuildResult
    from donkit.rag_toolkit.schemas.config import RagConfig

    result = await RagPipelineOrchestrator.build(
        source_path="/path/to/docs",
        rag_config=rag_config,
        embeddings=my_embeddings,
        database_uri="http://localhost:6333",
    )
"""

from .chunking import ChunkingService
from .config import RagConfigValidator
from .config import validate_rag_config
from .deployment import ComposeManager
from .deployment import DockerEnvironment
from .deployment import EnvFileGenerator
from .deployment import LLMProviderCredentials
from .document_processing import DocumentProcessor
from .document_processing import PathNormalizer
from .evaluation import DocumentNormalizer
from .evaluation import RagEvaluator
from .evaluation import RAGMetrics
from .pipeline import PipelineBuildResult
from .pipeline import RagPipelineOrchestrator
from .query import RagQueryClient
from .retriever import RetrieverClient
from .retriever import RetrieverService
from .vectorstore import VectorstoreLoader
from .vectorstore import VectorstoreLoadResult
from .vectorstore import VectorstoreService

__all__ = [
    # Config
    "RagConfigValidator",
    "validate_rag_config",
    # Deployment
    "EnvFileGenerator",
    "LLMProviderCredentials",
    "DockerEnvironment",
    "ComposeManager",
    # Retriever
    "RetrieverClient",
    "RetrieverService",
    # Vectorstore
    "VectorstoreLoader",
    "VectorstoreLoadResult",
    "VectorstoreService",
    # Evaluation
    "RAGMetrics",
    "DocumentNormalizer",
    "RagEvaluator",
    # Document processing
    "PathNormalizer",
    "DocumentProcessor",
    # Chunking
    "ChunkingService",
    # Pipeline
    "RagPipelineOrchestrator",
    "PipelineBuildResult",
    # Query
    "RagQueryClient",
]
