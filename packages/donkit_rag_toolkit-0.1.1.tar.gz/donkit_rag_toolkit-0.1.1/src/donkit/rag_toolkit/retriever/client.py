"""Retriever client wrapper.

Wraps donkit-retriever to provide document search capabilities
against vector databases. Analogous to vectorstore/loader.py
but for retrieval instead of loading.
"""

from __future__ import annotations

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from donkit.rag_toolkit.schemas.config import RetrieverOptions


class RetrieverClient:
    """Low-level client for searching documents in a vectorstore.

    Wraps ``donkit.retriever.create_vectorstore_service`` and exposes
    a simple ``search`` method.
    """

    def __init__(
        self,
        backend: str,
        embeddings: Embeddings,
        collection_name: str,
        database_uri: str,
        retriever_options: RetrieverOptions | None = None,
    ):
        from donkit.retriever import RetrievalConfig
        from donkit.retriever import create_vectorstore_service
        from donkit.retriever.retrieval_config import (
            RetrieverOptions as DonkitRetrieverOptions,
        )

        self.backend = backend
        self.collection_name = collection_name

        donkit_retriever_opts = self._map_options(
            retriever_options, DonkitRetrieverOptions
        )
        config = RetrievalConfig(
            vector_database=backend,
            retriever_options=donkit_retriever_opts,
        )

        self.service = create_vectorstore_service(
            db_type=backend,
            embeddings=embeddings,
            config=config,
            collection_name=collection_name,
            database_uri=database_uri,
        )

    async def search(self, query: str, k: int = 5) -> list[Document]:
        """Search for documents matching the query.

        Args:
            query: Search query string.
            k: Maximum number of documents to return.

        Returns:
            List of matching documents sorted by relevance.
        """
        return await self.service.search_documents(query, k)

    @staticmethod
    def _map_options(
        options: RetrieverOptions | None,
        donkit_options_cls: type,
    ) -> object:
        """Map rag-toolkit RetrieverOptions to donkit-retriever RetrieverOptions.

        Args:
            options: rag-toolkit retriever options (or None for defaults).
            donkit_options_cls: The donkit RetrieverOptions class.

        Returns:
            Instance of donkit RetrieverOptions.
        """
        if options is None:
            return donkit_options_cls()

        return donkit_options_cls(
            collection_name=options.collection_name,
            composite_query_detection=options.composite_query_detection,
            partial_search=options.partial_search,
            query_rewrite=options.query_rewrite,
            max_retrieved_docs=options.max_retrieved_docs,
            ranked_documents=options.ranked_documents,
            minimum_relevance=options.minimum_relevance,
        )
