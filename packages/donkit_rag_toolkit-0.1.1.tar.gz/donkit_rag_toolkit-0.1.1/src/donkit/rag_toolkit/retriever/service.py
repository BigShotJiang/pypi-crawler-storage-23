"""High-level retriever service.

Orchestrates vectorstore search operations via donkit-retriever.
Embeddings must be provided externally — this module does not
read credentials or create embedders.
"""

from __future__ import annotations

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from donkit.rag_toolkit.retriever.client import RetrieverClient
from donkit.rag_toolkit.schemas.config import RetrieverOptions


class RetrieverService:
    """High-level service for vectorstore search operations.

    Accepts ready-to-use Embeddings instances. Does not create embedders
    or read environment variables.
    """

    @staticmethod
    async def search(
        *,
        query: str,
        embeddings: Embeddings,
        backend: str = "qdrant",
        collection_name: str,
        database_uri: str = "http://localhost:6333",
        k: int = 5,
        retriever_options: RetrieverOptions | None = None,
    ) -> list[Document]:
        """Search for documents in a vectorstore.

        Args:
            query: Search query string.
            embeddings: Ready-to-use Embeddings instance.
            backend: Vectorstore backend (qdrant, chroma, milvus).
            collection_name: Collection name in vectorstore.
            database_uri: Database URI.
            k: Maximum number of documents to return.
            retriever_options: Optional retriever configuration.

        Returns:
            List of matching documents sorted by relevance.
        """
        client = RetrieverClient(
            backend=backend,
            embeddings=embeddings,
            collection_name=collection_name,
            database_uri=database_uri,
            retriever_options=retriever_options,
        )

        return await client.search(query, k)
