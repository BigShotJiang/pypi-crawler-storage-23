# Ganjirs

**A powerful HTTP/FTP Folder Downloader GUI with built-in browser and SOCKS5/HTTP proxy support.**

Created by **RAKIB**

[![PyPI version](https://badge.fury.io/py/ganjirs.svg)](https://badge.fury.io/py/ganjirs)
[![Python Versions](https://img.shields.io/pypi/pyversions/ganjirs.svg)](https://pypi.org/project/ganjirs/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- **Recursive Directory Downloading** — Recursively download entire HTTP/FTP directory trees with a single click
- **Built-in Browser** — Navigate HTTP/FTP servers with a full-featured browser including bookmarks, history, and tab management
- **SOCKS5 / HTTP Proxy Support** — Route all traffic through SOCKS5 or HTTP proxies, with optional authentication
- **YAML Proxy Configuration** — Load proxy lists from YAML files and rotate them automatically
- **Multi-threaded Downloads** — Download multiple files in parallel with configurable concurrency
- **Resume Support** — Resume interrupted downloads automatically
- **Progress Tracking** — Real-time progress bars and download speed display
- **Filter & Sort** — Filter directory listings by name, sort by name, date, or size
- **Download Queue** — Queue and manage multiple download jobs
- **Retry Failed Downloads** — Automatically retry failed downloads with a single click
- **Aria2 / wget Integration** — Optionally use aria2c or wget as the download backend for maximum performance
- **Stop / Cancel** — Stop any download in progress at any time

---

## 📦 Installation

```bash
pip install ganjirs
```

**Optional dependencies** for full proxy support:

```bash
pip install ganjirs[full]
```

### Dependencies

| Package | Purpose |
|---|---|
| `requests` | HTTP requests and downloading |
| `beautifulsoup4` | HTML parsing for directory listings |
| `PySocks` | SOCKS4/SOCKS5 proxy support |
| `PyYAML` | Loading proxy configs from YAML files |

> **Note:** `tkinter` is required and ships with Python by default. On Linux, install it with: `sudo apt install python3-tk`

---

## 🚀 Usage

### Launch the GUI

After installing, run from anywhere in your terminal:

```bash
ganjirs
```

Or:

```bash
ganjirs-gui
```

### Use as a Python module

```python
from ganjirs import main
main()
```

Or integrate directly:

```python
import tkinter as tk
from ganjirs import HttpDownloaderGUI

root = tk.Tk()
app = HttpDownloaderGUI(root)
root.mainloop()
```

---

## 🖥️ Screenshots

### Downloader Tab
Enter a URL, configure your proxy, set thread count, and start downloading. The progress panel shows live stats for each file.

### Browser Tab
Navigate HTTP directory listings with the built-in browser. Double-click folders to explore, click files to download. Use the sidebar for bookmarks and history.

---

## ⚙️ Configuration

### Proxy Setup

**Via the GUI:**
1. Open the **Proxy** tab
2. Select proxy type: `SOCKS5`, `SOCKS4`, or `HTTP`
3. Enter server, port, and optional credentials
4. Click **Apply**

**Via YAML file:**

Create a `proxies.yaml`:
```yaml
proxies:
  - type: SOCKS5
    server: 127.0.0.1
    port: 1080
    username: user      # optional
    password: pass      # optional
  - type: HTTP
    server: proxy.example.com
    port: 8080
```

Then load it in the GUI via **File → Load Proxy File**.

---

## 🔧 Advanced: Using aria2 Backend

If `aria2c` is installed and available in your PATH, Ganjirs can use it as the download backend for much faster multi-connection downloads:

1. Install aria2: https://aria2.github.io/
2. In the GUI, go to **Settings → Download Engine → aria2**

---

## 📋 Requirements

- Python 3.8+
- Windows, macOS, or Linux
- `tkinter` (ships with standard Python installations; on some Linux distros install `python3-tk`)

---

## 🤝 Contributing

Contributions are welcome! Please open an issue or pull request on GitHub.

---

## 📄 License

This project is licensed under the **MIT License**. See [LICENSE](LICENSE) for details.
