raise ImportError(
    "sugarpowder.pipes has been removed in v2.0. "
    "Use the 'pipe' package instead: https://pypi.org/project/pipe/"
)
