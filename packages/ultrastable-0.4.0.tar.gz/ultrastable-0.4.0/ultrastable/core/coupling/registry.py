from __future__ import annotations

import math
from collections.abc import Mapping, MutableMapping
from dataclasses import dataclass
from typing import Any, Protocol


class CouplingFunction(Protocol):
    def __call__(
        self, value: float, *, params: Mapping[str, Any] | None = None, **context: Any
    ) -> float: ...


@dataclass
class CouplingSpec:
    func: str
    params: Mapping[str, Any] | None = None


class CouplingRegistry:
    """Registry holding parameterized coupling functions.

    The registry ensures policy/config serialization stays string-addressable.
    Each function receives the current value and an optional params mapping.
    Additional keyword arguments supplied to :meth:`evaluate` are forwarded to
    the function (e.g., `dt` for time delta).
    """

    def __init__(self) -> None:
        self._funcs: MutableMapping[str, CouplingFunction] = {}

    def register(self, name: str, func: CouplingFunction, *, replace: bool = False) -> None:
        if not name:
            raise ValueError("Coupling function name is required")
        key = name.strip()
        if not key:
            raise ValueError("Coupling function name must be non-empty")
        if not replace and key in self._funcs:
            raise ValueError(f"Coupling function '{key}' already registered")
        self._funcs[key] = func

    def unregister(self, name: str) -> None:
        self._funcs.pop(name, None)

    def get(self, name: str) -> CouplingFunction:
        try:
            return self._funcs[name]
        except KeyError as exc:
            raise KeyError(f"Coupling function '{name}' is not registered") from exc

    def names(self) -> list[str]:
        return sorted(self._funcs.keys())

    def evaluate(
        self,
        spec: CouplingSpec | Mapping[str, Any] | str,
        value: float,
        **context: Any,
    ) -> float:
        if isinstance(spec, str):
            name = spec
            params = None
        else:
            func_name = spec.func if isinstance(spec, CouplingSpec) else spec.get("func")
            if not func_name:
                raise ValueError("Coupling spec must include 'func'")
            name = func_name
            params = spec.params if isinstance(spec, CouplingSpec) else spec.get("params")
        func = self.get(name)
        return float(func(value, params=params, **context))

    def copy(self) -> CouplingRegistry:
        other = CouplingRegistry()
        other._funcs.update(self._funcs)
        return other


def _param(params: Mapping[str, Any] | None, key: str, default: float) -> float:
    if params is None:
        return float(default)
    return float(params.get(key, default))


def _linear(value: float, *, params: Mapping[str, Any] | None = None, **_: Any) -> float:
    k = _param(params, "k", 1.0)
    c = _param(params, "c", 0.0)
    return k * value + c


def _sigmoid(value: float, *, params: Mapping[str, Any] | None = None, **_: Any) -> float:
    k = _param(params, "k", 1.0)
    x0 = _param(params, "x0", 0.0)
    exponent = -k * (value - x0)
    # Clamp exponent to avoid overflow
    exponent = max(-60.0, min(60.0, exponent))
    return 1.0 / (1.0 + math.exp(exponent))


def _threshold(value: float, *, params: Mapping[str, Any] | None = None, **_: Any) -> float:
    threshold = _param(params, "threshold", 0.0)
    low = _param(params, "low", 0.0)
    high = _param(params, "high", 1.0)
    return high if value >= threshold else low


def _rectified_linear(value: float, *, params: Mapping[str, Any] | None = None, **_: Any) -> float:
    k = _param(params, "k", 1.0)
    bias = _param(params, "bias", 0.0)
    return max(0.0, k * value + bias)


def _exponential_decay(
    value: float, *, params: Mapping[str, Any] | None = None, **context: Any
) -> float:
    rate = max(0.0, _param(params, "rate", 0.0))
    dt_param = _param(params, "dt", 1.0) if params and "dt" in params else None
    dt_context = context.get("dt")
    dt = (
        float(dt_context) if dt_context is not None else (dt_param if dt_param is not None else 1.0)
    )
    factor = 1.0 - rate * max(dt, 0.0)
    if factor < 0.0:
        factor = 0.0
    return value * factor


def create_default_registry() -> CouplingRegistry:
    registry = CouplingRegistry()
    registry.register("linear", _linear)
    registry.register("sigmoid", _sigmoid)
    registry.register("threshold", _threshold)
    registry.register("rectified_linear", _rectified_linear)
    registry.register("exponential_decay", _exponential_decay)
    return registry


default_registry = create_default_registry()


def evaluate_coupling(
    spec: CouplingSpec | Mapping[str, Any] | str,
    value: float,
    **context: Any,
) -> float:
    return default_registry.evaluate(spec, value, **context)


def get_registered_names() -> list[str]:
    return default_registry.names()
