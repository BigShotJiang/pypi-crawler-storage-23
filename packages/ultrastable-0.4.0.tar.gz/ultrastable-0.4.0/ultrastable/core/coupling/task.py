from __future__ import annotations

from collections.abc import Mapping, MutableMapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ..events import TaskCouplingEvent
from .registry import CouplingRegistry, CouplingSpec, default_registry

if TYPE_CHECKING:
    from ..health import EssentialVariable


def _as_coupling_spec(
    spec: CouplingSpec | Mapping[str, Any] | str,
) -> CouplingSpec:
    if isinstance(spec, CouplingSpec):
        params = dict(spec.params or {})
        return CouplingSpec(func=spec.func, params=params)
    if isinstance(spec, str):
        return CouplingSpec(func=spec, params=None)
    func = spec.get("func")
    if not func:
        raise ValueError("coupling spec requires 'func'")
    params = spec.get("params") or {}
    return CouplingSpec(func=str(func), params=dict(params))


@dataclass
class TaskCoupledVariable:
    """Variable that decays over time and recharges via registry-driven coupling."""

    name: str
    decay: float
    coupling: CouplingSpec | Mapping[str, Any] | str
    min_value: float = 0.0
    max_value: float = 1.0
    start_value: float | None = None
    registry: CouplingRegistry | None = None
    tags: MutableMapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("TaskCoupledVariable.name is required")
        if self.max_value <= self.min_value:
            raise ValueError("max_value must be > min_value")
        if self.decay < 0.0:
            raise ValueError("decay must be >= 0")
        self._registry = self.registry or default_registry
        self._spec = _as_coupling_spec(self.coupling)
        if self.start_value is None:
            self._value = self.max_value
        else:
            self._value = self._clamp(float(self.start_value))

    @property
    def value(self) -> float:
        return self._value

    def to_config(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "decay": self.decay,
            "coupling": {"func": self._spec.func, "params": dict(self._spec.params or {})},
            "min_value": self.min_value,
            "max_value": self.max_value,
            "start_value": self._value,
            "tags": dict(self.tags),
        }

    @classmethod
    def from_config(
        cls,
        cfg: Mapping[str, Any],
        *,
        registry: CouplingRegistry | None = None,
    ) -> TaskCoupledVariable:
        coupling_cfg = cfg.get("coupling")
        if coupling_cfg is None:
            raise ValueError("coupling config required")
        return cls(
            name=str(cfg["name"]),
            decay=float(cfg.get("decay", 0.0)),
            coupling=coupling_cfg,
            min_value=float(cfg.get("min_value", 0.0)),
            max_value=float(cfg.get("max_value", 1.0)),
            start_value=float(cfg.get("start_value", cfg.get("initial", 0.0))),
            registry=registry,
            tags=dict(cfg.get("tags") or {}),
        )

    def reset(self, value: float | None = None) -> None:
        if value is None:
            self._value = self.max_value
        else:
            self._value = self._clamp(float(value))

    def to_essential_variable(self) -> EssentialVariable:
        from ..health import EssentialVariable  # lazy import to avoid circular dependency

        scale = max(self.max_value - self.min_value, 1.0)
        return EssentialVariable.bounded(
            self.name,
            min=self.min_value,
            max=self.max_value,
            scale=scale,
            tags=dict(self.tags),
        )

    def step(self, signal: float, *, dt: float = 1.0) -> TaskCouplingEvent:
        dt = max(0.0, float(dt))
        signal_value = float(signal)
        pre = self._value
        if dt == 0.0:
            coupling_value = self._registry.evaluate(
                self._spec,
                signal_value,
                state=pre,
                dt=dt,
            )
            return TaskCouplingEvent(
                variable=self.name,
                task_signal=signal_value,
                coupling_value=coupling_value,
                decay_applied=0.0,
                dt=0.0,
                pre_value=pre,
                post_value=pre,
                tags=dict(self.tags),
            )

        decay_factor = max(0.0, 1.0 - self.decay * dt)
        decayed = pre * decay_factor
        decay_applied = pre - decayed
        coupling_value = self._registry.evaluate(
            self._spec,
            signal_value,
            state=pre,
            dt=dt,
        )
        post = decayed + coupling_value * dt
        post_clamped = self._clamp(post)
        self._value = post_clamped
        return TaskCouplingEvent(
            variable=self.name,
            task_signal=signal_value,
            coupling_value=coupling_value,
            decay_applied=decay_applied,
            dt=dt,
            pre_value=pre,
            post_value=post_clamped,
            tags=dict(self.tags),
        )

    def _clamp(self, value: float) -> float:
        return max(self.min_value, min(self.max_value, value))
