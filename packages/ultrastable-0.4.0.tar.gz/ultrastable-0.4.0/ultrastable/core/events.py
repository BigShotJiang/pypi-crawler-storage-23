from __future__ import annotations

import hashlib
import importlib
import json
from collections.abc import Mapping, MutableMapping
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, TypedDict

from ultrastable.events.registry import EventSchemaRegistry

EVENT_SCHEMA_VERSION = "1.2"


def _utc_now_iso_ms() -> str:
    # Use millisecond precision; produce trailing 'Z' to indicate UTC
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _sorted_json(data: Mapping[str, Any]) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


class BodyHash(TypedDict):
    algorithm: str
    digest: str
    salt: str | None


_HASH_FIELD_OVERRIDES: dict[str, str] = {
    "prompt_text": "prompt_hash",
    "response_text": "response_hash",
    "message": "message_hash",
}


def _body_hash(value: str, *, algorithm: str = "sha256", salt: str | None = None) -> BodyHash:
    return {
        "algorithm": algorithm,
        "digest": _hash_text(value),
        "salt": salt,
    }


def _migrate_event_v11_to_current(payload: dict[str, Any]) -> dict[str, Any]:
    upgraded = dict(payload)
    upgraded.setdefault("redaction_level", "metadata-only")
    upgraded.setdefault("timestamp", _utc_now_iso_ms())
    upgraded["schema_version"] = EVENT_SCHEMA_VERSION
    return upgraded


@dataclass
class BaseEvent:
    event_type: str
    timestamp: str = field(default_factory=_utc_now_iso_ms)

    def to_dict(self, redaction_level: str = "metadata-only") -> dict[str, Any]:
        payload: dict[str, Any] = {
            "event_type": self.event_type,
            "schema_version": EVENT_SCHEMA_VERSION,
            "timestamp": self.timestamp,
            "redaction_level": redaction_level,
        }
        # Shallow copy dataclass fields (excluding base fields already present)
        data = asdict(self)
        data.pop("event_type", None)
        data.pop("timestamp", None)
        # Merge, then apply redaction policy
        payload.update(data)
        return apply_redaction(payload, redaction_level)

    def to_json(self, redaction_level: str = "metadata-only") -> str:
        return _sorted_json(self.to_dict(redaction_level=redaction_level))


# Run lifecycle ---------------------------------------------------------------


@dataclass
class RunEvent(BaseEvent):
    event_type: str = field(init=False, default="run")
    run_id: str = ""
    phase: str = "start"  # "start" | "end"
    policy_version: str | None = None
    policy_hash: str | None = None
    ultrastable_version: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)


# Steps & costs ---------------------------------------------------------------


@dataclass
class StepEvent(BaseEvent):
    event_type: str = field(init=False, default="step")
    step_id: str = ""
    role: str | None = None  # "user" | "assistant" | "tool" | "system"
    kind: str | None = None  # "llm" | "tool" | "action"
    model: str | None = None
    tool_name: str | None = None
    tool_args_hash: str | None = None
    latency_ms: float | None = None
    tokens_prompt: int | None = None
    tokens_completion: int | None = None
    tokens_total: int | None = None
    cost_usd: float | None = None
    d_h: float | None = None
    # Body fields (subject to redaction policies)
    prompt_text: str | None = None
    response_text: str | None = None
    prompt_hash: BodyHash | None = None
    response_hash: BodyHash | None = None
    prompt_text_sha256: str | None = None
    response_text_sha256: str | None = None
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class CostEvent(BaseEvent):
    event_type: str = field(init=False, default="cost")
    step_id: str | None = None
    provider: str | None = None
    model: str | None = None
    tokens: int | None = None
    usd: float | None = None
    cache_hit: bool | None = None
    tags: dict[str, Any] = field(default_factory=dict)


# Health & viability ----------------------------------------------------------


@dataclass
class HealthSnapshotEvent(BaseEvent):
    event_type: str = field(init=False, default="health_snapshot")
    # Essential variable values: name -> value
    values: dict[str, float] = field(default_factory=dict)
    # Normalized deviations: name -> deviation (>= 0)
    deviations: dict[str, float] = field(default_factory=dict)
    # Aggregated health distance D(H)
    d_h: float | None = None
    # Coupled variable values (if any)
    coupled_values: dict[str, float] = field(default_factory=dict)
    # Variable tags carried into events: name -> {tag: value}
    variable_tags: dict[str, dict[str, Any]] = field(default_factory=dict)
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class TriggerEvent(BaseEvent):
    event_type: str = field(init=False, default="trigger")
    trigger_id: str | None = None
    detector: str = ""
    severity: str = "warn"  # "warn" | "critical"
    explanation: str | None = None
    related_step_ids: list[str] = field(default_factory=list)
    variables: list[str] = field(default_factory=list)
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class InterventionEvent(BaseEvent):
    event_type: str = field(init=False, default="intervention")
    intervention_type: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    trigger_ids: list[str] = field(default_factory=list)
    # Outcome measurement (may be unknown)
    outcome: dict[str, Any] = field(default_factory=dict)
    pre_snapshot_id: str | None = None
    post_snapshot_id: str | None = None
    stochastic_params: dict[str, Any] = field(default_factory=dict)
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class ErrorEvent(BaseEvent):
    event_type: str = field(init=False, default="error")
    category: str = ""
    code: str | None = None
    message: str | None = None  # subject to redaction policies
    message_hash: BodyHash | None = None
    message_sha256: str | None = None
    step_id: str | None = None
    retry_count: int | None = None
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskCouplingEvent(BaseEvent):
    event_type: str = field(init=False, default="task_coupling")
    variable: str = ""
    task_signal: float | None = None
    coupling_value: float | None = None
    decay_applied: float | None = None
    dt: float | None = None
    pre_value: float | None = None
    post_value: float | None = None
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicySwitchEvent(BaseEvent):
    event_type: str = field(init=False, default="policy_switch")
    from_policy: str = ""
    to_policy: str = ""
    reason: str | None = None
    d_h: float | None = None
    policy_hash: str | None = None
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass
class PlasticityFacilitationEvent(BaseEvent):
    event_type: str = field(init=False, default="plasticity_facilitation")
    layer: str = ""
    magnitude: float = 0.0
    comfort_dist: float | None = None
    tags: dict[str, Any] = field(default_factory=dict)


# Redaction -------------------------------------------------------------------


def apply_redaction(event: MutableMapping[str, Any], mode: str) -> dict[str, Any]:
    """Apply redaction policy to an event dict and return a new dict.

    Modes:
      - "metadata-only": remove raw text fields entirely; keep hashes only
      - "selective-text": keep allowlist fields when present (see below)
      - "full-text": do nothing (explicit opt-in)
    """

    if mode not in {"metadata-only", "selective-text", "full-text"}:
        mode = "metadata-only"

    # Make a shallow copy to avoid mutating input
    e = dict(event)

    def _record_hash_for(field: str) -> None:
        body = e.get(field)
        if not (isinstance(body, str) and body):
            return
        hash_field = _HASH_FIELD_OVERRIDES.get(field, f"{field}_hash")
        descriptor = _body_hash(body)
        e[hash_field] = descriptor
        # Backcompat for downstream systems that still read *_sha256
        e[field + "_sha256"] = descriptor["digest"]

    def redact_body(prefix: str) -> None:
        _record_hash_for(prefix)
        e.pop(prefix, None)

    if e.get("event_type") in {"step", "error"}:
        if mode == "metadata-only":
            # Remove all text bodies; keep hashes for auditability
            if "prompt_text" in e:
                redact_body("prompt_text")
            if "response_text" in e:
                redact_body("response_text")
            if "message" in e:
                redact_body("message")
        elif mode == "selective-text":
            # Allowlist: keep error message only; step bodies hashed
            if e.get("event_type") == "step":
                if "prompt_text" in e:
                    redact_body("prompt_text")
                if "response_text" in e:
                    redact_body("response_text")
            # For ErrorEvent, keep message but also include a hash for traceability
            if "message" in e and isinstance(e["message"], str):
                _record_hash_for("message")
        elif mode == "full-text":
            # No changes
            pass

    return e


class _DictPayloadWrapper:
    def __init__(self, payload: Mapping[str, Any]) -> None:
        self._payload = dict(payload)

    def model_dump(self) -> dict[str, Any]:
        return dict(self._payload)

    def dict(self) -> dict[str, Any]:
        return dict(self._payload)


class _LazyEventModel:
    @classmethod
    def model_validate(cls, payload: Mapping[str, Any]) -> _DictPayloadWrapper | Any:
        model_cls = _load_event_model()
        if model_cls is None:
            return _DictPayloadWrapper(payload)
        if hasattr(model_cls, "model_validate"):
            return model_cls.model_validate(payload)
        if hasattr(model_cls, "parse_obj"):
            return model_cls.parse_obj(payload)
        return _DictPayloadWrapper(payload)

    @classmethod
    def parse_obj(cls, payload: Mapping[str, Any]) -> _DictPayloadWrapper | Any:
        model_cls = _load_event_model()
        if model_cls is None:
            return _DictPayloadWrapper(payload)
        if hasattr(model_cls, "parse_obj"):
            return model_cls.parse_obj(payload)
        if hasattr(model_cls, "model_validate"):
            return model_cls.model_validate(payload)
        return _DictPayloadWrapper(payload)


_EVENT_MODEL_CLS: Any | None = None


def _load_event_model() -> Any | None:
    global _EVENT_MODEL_CLS
    if _EVENT_MODEL_CLS is not None:
        return _EVENT_MODEL_CLS
    try:
        models = importlib.import_module("ultrastable.events.models")
    except Exception:
        _EVENT_MODEL_CLS = None
        return None
    available = getattr(models, "AVAILABLE", False)
    model_cls = getattr(models, "BaseEventModel", None)
    if not available or model_cls is None:
        _EVENT_MODEL_CLS = None
        return None
    _EVENT_MODEL_CLS = model_cls
    return model_cls


event_schema_registry = EventSchemaRegistry(latest_version=EVENT_SCHEMA_VERSION)
event_schema_registry.register(EVENT_SCHEMA_VERSION, _LazyEventModel)
event_schema_registry.register("1.1", _LazyEventModel)
event_schema_registry.add_migration("1.1", EVENT_SCHEMA_VERSION, _migrate_event_v11_to_current)


__all__ = [
    "BaseEvent",
    "RunEvent",
    "StepEvent",
    "HealthSnapshotEvent",
    "TriggerEvent",
    "InterventionEvent",
    "CostEvent",
    "ErrorEvent",
    "TaskCouplingEvent",
    "PolicySwitchEvent",
    "PlasticityFacilitationEvent",
    "EVENT_SCHEMA_VERSION",
    "event_schema_registry",
    "apply_redaction",
]
