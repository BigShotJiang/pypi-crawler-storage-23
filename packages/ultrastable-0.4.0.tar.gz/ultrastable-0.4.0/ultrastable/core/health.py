from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any, cast

import numpy as np

from .coupling import TaskCoupledVariable
from .events import HealthSnapshotEvent, TaskCouplingEvent

KIND_SETPOINT = "SETPOINT"
KIND_BOUNDED = "BOUNDED"
KIND_MONOTONIC = "MONOTONIC"


def _is_finite(x: float) -> bool:
    return bool(np.isfinite(float(x)))


@dataclass
class EssentialVariable:
    name: str
    kind: str
    scale: float
    weight: float = 1.0
    hysteresis: float = 0.0
    tags: dict[str, Any] = field(default_factory=dict)
    # Setpoint
    target: float | None = None
    tolerance: float | None = None
    # Bounded
    min: float | None = None
    max: float | None = None
    # Monotonic
    hard_limit: float | None = None

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("EssentialVariable.name is required")
        if self.kind not in {KIND_SETPOINT, KIND_BOUNDED, KIND_MONOTONIC}:
            raise ValueError("Invalid kind")
        if not _is_finite(self.scale) or float(self.scale) <= 0.0:
            raise ValueError("scale must be positive and finite")
        if not _is_finite(self.weight) or float(self.weight) < 0.0:
            raise ValueError("weight must be finite and >= 0")
        if not _is_finite(self.hysteresis) or float(self.hysteresis) < 0.0:
            raise ValueError("hysteresis must be finite and >= 0")

        if self.kind == KIND_SETPOINT:
            if self.target is None or self.tolerance is None:
                raise ValueError("SETPOINT requires target and tolerance")
            if not (_is_finite(self.target) and _is_finite(self.tolerance)):
                raise ValueError("SETPOINT target/tolerance must be finite")
            if float(self.tolerance) < 0.0:
                raise ValueError("tolerance must be >= 0")
        elif self.kind == KIND_BOUNDED:
            if self.min is None or self.max is None:
                raise ValueError("BOUNDED requires min and max")
            if not (_is_finite(self.min) and _is_finite(self.max)):
                raise ValueError("BOUNDED min/max must be finite")
            if float(self.min) >= float(self.max):
                raise ValueError("min must be < max")
        elif self.kind == KIND_MONOTONIC:
            if self.hard_limit is None or not _is_finite(self.hard_limit):
                raise ValueError("MONOTONIC requires finite hard_limit")
            if float(self.hard_limit) <= 0.0:
                raise ValueError("hard_limit must be > 0")

    # Construction helpers -------------------------------------------------
    @classmethod
    def setpoint(
        cls,
        name: str,
        *,
        target: float,
        tolerance: float,
        scale: float,
        weight: float = 1.0,
        hysteresis: float = 0.0,
        tags: dict[str, Any] | None = None,
    ) -> EssentialVariable:
        return cls(
            name=name,
            kind=KIND_SETPOINT,
            target=float(target),
            tolerance=float(tolerance),
            scale=float(scale),
            weight=float(weight),
            hysteresis=float(hysteresis),
            tags=dict(tags or {}),
        )

    @classmethod
    def bounded(
        cls,
        name: str,
        *,
        min: float,
        max: float,
        scale: float,
        weight: float = 1.0,
        hysteresis: float = 0.0,
        tags: dict[str, Any] | None = None,
    ) -> EssentialVariable:
        return cls(
            name=name,
            kind=KIND_BOUNDED,
            min=float(min),
            max=float(max),
            scale=float(scale),
            weight=float(weight),
            hysteresis=float(hysteresis),
            tags=dict(tags or {}),
        )

    @classmethod
    def monotonic(
        cls,
        name: str,
        *,
        hard_limit: float,
        scale: float,
        weight: float = 1.0,
        hysteresis: float = 0.0,
        tags: dict[str, Any] | None = None,
    ) -> EssentialVariable:
        return cls(
            name=name,
            kind=KIND_MONOTONIC,
            hard_limit=float(hard_limit),
            scale=float(scale),
            weight=float(weight),
            hysteresis=float(hysteresis),
            tags=dict(tags or {}),
        )

    # Semantics ------------------------------------------------------------
    def deviation(self, value: float) -> float:
        v = float(value)
        if not _is_finite(v):
            raise ValueError("value must be finite")
        if self.kind == KIND_SETPOINT:
            return abs(v - float(self.target)) / float(self.scale)  # type: ignore[arg-type]
        if self.kind == KIND_BOUNDED:
            mn = float(self.min)  # type: ignore[arg-type]
            mx = float(self.max)  # type: ignore[arg-type]
            if mn <= v <= mx:
                return 0.0
            if v < mn:
                return (mn - v) / float(self.scale)
            return (v - mx) / float(self.scale)
        # KIND_MONOTONIC
        return v / float(self.hard_limit)  # type: ignore[arg-type]

    def distance_to_boundary(self, value: float) -> float:
        """Dimensionless distance to the nearest boundary, 0 when at/over boundary.

        - SETPOINT: (tolerance - |x-target|) / scale, clipped at [0, +inf)
        - BOUNDED: min(x-min, max-x) / scale when inside; 0 when outside
        - MONOTONIC: (hard_limit - x) / hard_limit, clipped at [0, +inf)
        """
        v = float(value)
        if self.kind == KIND_SETPOINT:
            tol = float(self.tolerance)  # type: ignore[arg-type]
            rem = max(0.0, tol - abs(v - float(self.target)))  # type: ignore[arg-type]
            return rem / float(self.scale)
        if self.kind == KIND_BOUNDED:
            mn = float(self.min)  # type: ignore[arg-type]
            mx = float(self.max)  # type: ignore[arg-type]
            if mn <= v <= mx:
                return min(v - mn, mx - v) / float(self.scale)
            return 0.0
        # KIND_MONOTONIC
        hl = float(self.hard_limit)  # type: ignore[arg-type]
        return max(0.0, hl - v) / hl

    def is_breach(self, value: float) -> bool:
        v = float(value)
        if self.kind == KIND_BOUNDED:
            mn = cast(float, self.min)
            mx = cast(float, self.max)
            return not (mn <= v <= mx)
        if self.kind == KIND_MONOTONIC:
            return v > float(self.hard_limit)  # type: ignore[arg-type]
        # SETPOINT has no hard boundary by default
        return False


class EssentialVariableSpace:
    """Holds variables and their current values.

    Thread-safety: not thread-safe. Wrap updates in an external lock if needed.
    """

    def __init__(
        self,
        variables: Iterable[EssentialVariable],
        *,
        coupled_variables: Iterable[TaskCoupledVariable] | None = None,
    ):
        base_list = list(variables)
        self._vars: dict[str, EssentialVariable] = {v.name: v for v in base_list}
        if len(self._vars) != len(base_list):
            # Non-unique names aren't allowed
            raise ValueError("Duplicate variable names")
        self._values: dict[str, float] = {name: 0.0 for name in self._vars}
        self._coupled: dict[str, TaskCoupledVariable] = {}
        if coupled_variables:
            for coupled in coupled_variables:
                if coupled.name in self._vars:
                    raise ValueError(f"Duplicate variable name '{coupled.name}'")
                if coupled.name in self._coupled:
                    raise ValueError(f"Duplicate coupled variable '{coupled.name}'")
                ev = coupled.to_essential_variable()
                self._vars[coupled.name] = ev
                self._values[coupled.name] = coupled.value
                self._coupled[coupled.name] = coupled

    def set(self, name: str, value: float | int) -> None:
        if name not in self._vars:
            raise KeyError(name)
        v = float(value)
        if not _is_finite(v):
            raise ValueError("value must be finite")
        self._values[name] = v
        coupled = self._coupled.get(name)
        if coupled is not None:
            coupled.reset(v)

    def batch_update(self, updates: Mapping[str, float | int]) -> None:
        for k, v in updates.items():
            self.set(k, v)

    def get(self, name: str) -> float:
        return self._values[name]

    @property
    def variables(self) -> Mapping[str, EssentialVariable]:
        return self._vars

    @property
    def values(self) -> Mapping[str, float]:
        return self._values

    @property
    def coupled_variables(self) -> Mapping[str, TaskCoupledVariable]:
        return self._coupled

    def snapshot(
        self, health: HealthModel, tags: dict[str, Any] | None = None
    ) -> HealthSnapshotEvent:
        deviations, d_h = health.compute(self)
        # Carry variable tags into snapshot
        variable_tags = {name: dict(ev.tags) for name, ev in self._vars.items()}
        coupled_values = {name: self._values[name] for name in self._coupled}
        return HealthSnapshotEvent(
            values=dict(self._values),
            deviations=deviations,
            d_h=d_h,
            coupled_values=coupled_values,
            variable_tags=variable_tags,
            tags=dict(tags or {}),
        )

    def step_coupled(self, signal: float, dt: float = 1.0) -> list[TaskCouplingEvent]:
        if not self._coupled:
            return []
        events: list[TaskCouplingEvent] = []
        for name, coupled in self._coupled.items():
            event = coupled.step(signal, dt=dt)
            self._values[name] = coupled.value
            events.append(event)
        return events


class HealthModel:
    def __init__(self, metric: str = "l2"):
        if metric not in {"l1", "l2", "linf"}:
            raise ValueError("metric must be one of 'l1', 'l2', 'linf'")
        self.metric = metric

    def compute(self, space: EssentialVariableSpace) -> tuple[dict[str, float], float]:
        # Deterministic ordering by variable name
        names = sorted(space.variables.keys())
        devs: dict[str, float] = {}
        weighted: list[float] = []
        for name in names:
            var = space.variables[name]
            val = space.values[name]
            dev = var.deviation(val)
            devs[name] = dev
            weighted.append(var.weight * dev)

        arr = np.array(weighted, dtype=float)
        if self.metric == "l1":
            d_h = float(np.sum(np.abs(arr)))
        elif self.metric == "l2":
            d_h = float(np.sqrt(np.sum(arr**2)))
        else:  # linf
            d_h = float(np.max(np.abs(arr))) if arr.size else 0.0
        return devs, d_h


class ViabilityPolicy:
    def __init__(
        self,
        space: EssentialVariableSpace,
        *,
        health: HealthModel | None = None,
        warn_threshold: float | None = None,
        critical_threshold: float | None = None,
        monotonic_warn_fraction: float = 0.9,
        bounded_warn_fraction: float = 0.1,
        setpoint_warn_mult: float = 1.0,
        setpoint_critical_mult: float = 2.0,
    ) -> None:
        self.space = space
        self.health = health or HealthModel("l2")
        self.warn_threshold = warn_threshold
        self.critical_threshold = critical_threshold
        self.monotonic_warn_fraction = float(monotonic_warn_fraction)
        self.bounded_warn_fraction = float(bounded_warn_fraction)
        self.setpoint_warn_mult = float(setpoint_warn_mult)
        self.setpoint_critical_mult = float(setpoint_critical_mult)
        self._last_status: dict[str, str] = {}

    def evaluate(self, space: EssentialVariableSpace | None = None) -> tuple[str, list[str]]:
        sp = space or self.space
        reasons: list[str] = []
        overall = "ok"

        # Per-variable checks
        for name, ev in sp.variables.items():
            x = sp.values[name]
            status = "ok"
            if ev.kind == KIND_MONOTONIC:
                hl = float(ev.hard_limit)  # type: ignore[arg-type]
                if x > hl:
                    status = "critical"
                    reasons.append(f"{name}: budget breach > hard_limit")
                elif x >= self.monotonic_warn_fraction * hl:
                    status = "warn"
                    reasons.append(f"{name}: near budget {x:.4g}/{hl}")
            elif ev.kind == KIND_BOUNDED:
                mn = float(ev.min)  # type: ignore[arg-type]
                mx = float(ev.max)  # type: ignore[arg-type]
                if not (mn <= x <= mx):
                    status = "critical"
                    reasons.append(f"{name}: out of bounds [{mn}, {mx}]")
                else:
                    width = mx - mn
                    proximity = min(x - mn, mx - x)
                    if proximity <= self.bounded_warn_fraction * width:
                        status = "warn"
                        reasons.append(f"{name}: near boundary")
            else:  # SETPOINT
                tol = float(ev.tolerance)  # type: ignore[arg-type]
                dev = abs(x - float(ev.target))  # type: ignore[arg-type]
                if dev >= self.setpoint_critical_mult * tol:
                    status = "critical"
                    reasons.append(f"{name}: far from target >= {self.setpoint_critical_mult}x tol")
                elif dev >= self.setpoint_warn_mult * tol:
                    status = "warn"
                    reasons.append(f"{name}: deviation >= {self.setpoint_warn_mult}x tol")

            # Apply simple hysteresis on warn → ok transitions
            prev = self._last_status.get(name)
            if prev == "warn" and status == "ok":
                if ev.kind == KIND_MONOTONIC:
                    hl = float(ev.hard_limit)  # type: ignore[arg-type]
                    if x >= (self.monotonic_warn_fraction - ev.hysteresis) * hl:
                        status = "warn"
                elif ev.kind == KIND_BOUNDED:
                    mn = float(ev.min)  # type: ignore[arg-type]
                    mx = float(ev.max)  # type: ignore[arg-type]
                    width = mx - mn
                    proximity = min(x - mn, mx - x)
                    if proximity <= (self.bounded_warn_fraction + ev.hysteresis) * width:
                        status = "warn"
                else:  # SETPOINT
                    tol = float(ev.tolerance)  # type: ignore[arg-type]
                    dev = abs(x - float(ev.target))  # type: ignore[arg-type]
                    if dev >= max(0.0, (self.setpoint_warn_mult - ev.hysteresis)) * tol:
                        status = "warn"

            self._last_status[name] = status
            if status == "critical":
                overall = "critical"
            elif status == "warn" and overall == "ok":
                overall = "warn"

        # Aggregated D(H) thresholds (optional)
        _, d_h = self.health.compute(sp)
        if self.critical_threshold is not None and d_h >= self.critical_threshold:
            if overall != "critical":
                reasons.append(
                    f"D(H) >= critical_threshold ({d_h:.4g} >= {self.critical_threshold})"
                )
            overall = "critical"
        elif self.warn_threshold is not None and d_h >= self.warn_threshold:
            if overall == "ok":
                reasons.append(f"D(H) >= warn_threshold ({d_h:.4g} >= {self.warn_threshold})")
            if overall != "critical":
                overall = "warn"

        return overall, reasons

    def distance_to_boundary(self, space: EssentialVariableSpace | None = None) -> dict[str, float]:
        sp = space or self.space
        out: dict[str, float] = {}
        for name, ev in sp.variables.items():
            out[name] = ev.distance_to_boundary(sp.values[name])
        return out


__all__ = [
    "KIND_SETPOINT",
    "KIND_BOUNDED",
    "KIND_MONOTONIC",
    "EssentialVariable",
    "EssentialVariableSpace",
    "HealthModel",
    "ViabilityPolicy",
]
