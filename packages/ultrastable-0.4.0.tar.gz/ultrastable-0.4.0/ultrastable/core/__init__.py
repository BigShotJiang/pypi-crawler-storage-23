"""Core (numpy-only) components for Ultrastable.

This module is intentionally dependency-light: it only imports NumPy and the
Python standard library. Rich validation and optional features live outside
`ultrastable.core` behind extras.
"""

from __future__ import annotations

import numpy as _np  # noqa: F401  (explicitly ensure numpy is a core dependency)

from .controller import Controller, ControllerDecision
from .coupling import (
    CouplingFunction,
    CouplingRegistry,
    CouplingSpec,
    TaskCoupledVariable,
    create_default_registry,
    default_registry,
    evaluate_coupling,
    get_registered_names,
)
from .health import (
    KIND_BOUNDED,
    KIND_MONOTONIC,
    KIND_SETPOINT,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)

__all__ = [
    "ping",
    "KIND_SETPOINT",
    "KIND_BOUNDED",
    "KIND_MONOTONIC",
    "Controller",
    "ControllerDecision",
    "CouplingFunction",
    "CouplingRegistry",
    "CouplingSpec",
    "create_default_registry",
    "default_registry",
    "evaluate_coupling",
    "get_registered_names",
    "TaskCoupledVariable",
    "EssentialVariable",
    "EssentialVariableSpace",
    "HealthModel",
    "ViabilityPolicy",
]


def ping() -> str:
    """Lightweight sanity function for import checks."""
    return "ultrastable-core"
