from __future__ import annotations

from collections import deque
from collections.abc import Mapping, MutableMapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

from ultrastable.interventions.base import (
    Intervention,
    InterventionRequest,
    InterventionResult,
)

from .events import HealthSnapshotEvent, StepEvent, TriggerEvent
from .health import ViabilityPolicy


class DetectorLike(Protocol):
    name: str

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]: ...


@dataclass
class ControllerDecision:
    triggers: list[TriggerEvent] = field(default_factory=list)
    policy_status: str = "ok"
    intervention: InterventionResult | None = None
    outcomes: list[Mapping[str, Any]] = field(default_factory=list)


@dataclass
class _PendingIntervention:
    name: str
    pre_dh: float | None
    start_step: int
    breach_count: int = 0


class Controller:
    """Deterministic controller orchestrating detectors and interventions."""

    def __init__(
        self,
        policy: ViabilityPolicy,
        *,
        detectors: Sequence[DetectorLike] | None = None,
        interventions: Sequence[Intervention] | None = None,
        step_window: int = 20,
        snapshot_window: int = 5,
        cooldown_steps: int = 3,
        eta: float = 1.0,
    ) -> None:
        if step_window <= 0:
            raise ValueError("step_window must be > 0")
        if snapshot_window <= 0:
            raise ValueError("snapshot_window must be > 0")
        if eta < 1.0:
            raise ValueError("eta must be >= 1.0")
        self.policy = policy
        self.detectors = list(detectors or [])
        self.interventions = list(interventions or [])
        self._steps: deque[StepEvent] = deque(maxlen=step_window)
        self._snapshots: deque[HealthSnapshotEvent] = deque(maxlen=snapshot_window)
        self._cooldowns: dict[str, int] = {}
        self._pending: list[_PendingIntervention] = []
        self._cooldown_steps = max(0, cooldown_steps)
        self._step_index = 0
        self._eta = float(eta)
        self._escalation_debt = 0.0

    def update(
        self,
        step: StepEvent,
        snapshot: HealthSnapshotEvent | None = None,
        state: MutableMapping[str, Any] | None = None,
    ) -> ControllerDecision:
        self._step_index += 1
        self._steps.append(step)
        if snapshot is not None:
            self._snapshots.append(snapshot)
        policy_status, policy_reasons = self.policy.evaluate()
        policy_status, policy_reasons = self._apply_asymmetric_escalation(
            policy_status, policy_reasons, snapshot
        )
        triggers = self._collect_triggers(policy_status, policy_reasons)

        decision = ControllerDecision(triggers=triggers, policy_status=policy_status)
        decision.outcomes = self._update_pending(policy_status, snapshot)

        if not triggers:
            return decision

        request = InterventionRequest(
            triggers=triggers,
            policy=self.policy,
            pre_snapshot=snapshot,
            pre_snapshot_id=self._snapshot_id(snapshot),
            state=state,
        )
        for intervention in self.interventions:
            if self._cooldowns.get(intervention.name, 0) > 0:
                continue
            result = intervention.run(request)
            if result is None:
                continue
            decision.intervention = result
            if result.event and "status" not in result.event.outcome:
                result.event.outcome.setdefault("status", "pending")
            if self._cooldown_steps > 0:
                self._cooldowns[intervention.name] = self._cooldown_steps + 1
            self._pending.append(
                _PendingIntervention(
                    name=intervention.name,
                    pre_dh=self._snapshot_dh(snapshot),
                    start_step=self._step_index,
                )
            )
            break

        self._decay_cooldowns()
        return decision

    def _collect_triggers(self, policy_status: str, reasons: list[str]) -> list[TriggerEvent]:
        triggers: list[TriggerEvent] = []
        if policy_status in {"warn", "critical"}:
            explanation = "; ".join(reasons) if reasons else policy_status
            triggers.append(
                TriggerEvent(
                    detector="viability_policy",
                    severity=policy_status,
                    explanation=explanation,
                    tags={"policy_status": policy_status},
                )
            )
        step_snapshot = list(self._snapshots) if self._snapshots else None
        for detector in self.detectors:
            triggers.extend(detector.evaluate(list(self._steps), step_snapshot))
        return triggers

    def _apply_asymmetric_escalation(
        self,
        policy_status: str,
        reasons: list[str],
        snapshot: HealthSnapshotEvent | None,
    ) -> tuple[str, list[str]]:
        del snapshot  # snapshots are unused, but retained for API compatibility.
        if self._eta <= 1.0:
            return policy_status, reasons

        if policy_status in {"warn", "critical"}:
            self._escalation_debt = max(self._escalation_debt, self._eta)
            return policy_status, reasons

        if self._escalation_debt <= 0:
            self._escalation_debt = 0.0
            return policy_status, reasons

        self._escalation_debt = max(0.0, self._escalation_debt - 1.0)
        if self._escalation_debt > 0:
            biased_reasons = list(reasons)
            biased_reasons.append(
                "Controller eta bias requires additional ok steps "
                f"(remaining={self._escalation_debt:.4g}, eta={self._eta:.4g})"
            )
            return "warn", biased_reasons

        return policy_status, reasons

    def _decay_cooldowns(self) -> None:
        to_delete: list[str] = []
        for name, value in self._cooldowns.items():
            new_value = max(0, value - 1)
            self._cooldowns[name] = new_value
            if new_value == 0:
                to_delete.append(name)
        for name in to_delete:
            del self._cooldowns[name]

    def _update_pending(
        self, policy_status: str, snapshot: HealthSnapshotEvent | None
    ) -> list[Mapping[str, Any]]:
        if not self._pending:
            return []
        outcomes: list[Mapping[str, Any]] = []
        current_dh = self._snapshot_dh(snapshot)
        if policy_status == "ok":
            for pending in self._pending:
                delta = None
                if current_dh is not None and pending.pre_dh is not None:
                    delta = pending.pre_dh - current_dh
                outcomes.append(
                    {
                        "intervention_type": pending.name,
                        "delta_dh": delta,
                        "steps_to_recover": self._step_index - pending.start_step,
                        "repeated_breach_count": pending.breach_count,
                        "status": "recovered",
                    }
                )
            self._pending.clear()
            return outcomes

        # When still in warn/critical, increment breach counters.
        for pending in self._pending:
            pending.breach_count += 1
        return outcomes

    def _snapshot_id(self, snapshot: HealthSnapshotEvent | None) -> str | None:
        if snapshot is None:
            return None
        if "snapshot_id" in snapshot.tags:
            return str(snapshot.tags["snapshot_id"])
        return None

    def _snapshot_dh(self, snapshot: HealthSnapshotEvent | None) -> float | None:
        if snapshot is not None and snapshot.d_h is not None:
            return snapshot.d_h
        _, d_h = self.policy.health.compute(self.policy.space)
        return d_h


__all__ = ["Controller", "ControllerDecision"]
