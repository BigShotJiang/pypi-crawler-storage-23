from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from .base import Intervention
from .offline import (
    Backoff,
    ContextPrune,
    PersonaSwap,
    ResetContextTrim,
    ResetModelFallback,
    ResetReplan,
    ResetSummarize,
    ResetToolBreaker,
    StochasticParameterReset,
    StochasticReplan,
    StopTheLine,
)

Builder = Callable[[Mapping[str, Any]], Intervention]


class InterventionRegistry:
    """Registry that instantiates interventions from config dictionaries."""

    def __init__(self) -> None:
        self._builders: dict[str, Builder] = {}

    def register(self, kind: str, factory: Callable[..., Intervention]) -> None:
        key = _normalize_kind(kind)
        if key in self._builders:
            raise ValueError(f"Intervention '{kind}' is already registered")
        self._builders[key] = _wrap_factory(factory)

    def build(self, spec: Mapping[str, Any] | str) -> Intervention:
        kind, params = _parse_spec(spec)
        builder = self._builders.get(kind)
        if builder is None:
            raise KeyError(f"Intervention '{kind}' is not registered")
        return builder(params)

    def available(self) -> list[str]:
        return sorted(self._builders)


def _normalize_kind(kind: str) -> str:
    normalized = str(kind or "").strip().lower()
    if not normalized:
        raise ValueError("kind must be a non-empty string")
    return normalized


def _wrap_factory(factory: Callable[..., Intervention]) -> Builder:
    def builder(params: Mapping[str, Any]) -> Intervention:
        kwargs = dict(params or {})
        try:
            return factory(**kwargs)
        except TypeError as exc:  # pragma: no cover - defensive wrapping
            raise ValueError(f"Failed to construct intervention: {exc}") from exc

    return builder


def _parse_spec(spec: Mapping[str, Any] | str) -> tuple[str, Mapping[str, Any]]:
    if isinstance(spec, str):
        return _normalize_kind(spec), {}
    if not isinstance(spec, Mapping):
        raise TypeError("spec must be a string or mapping")
    kind = _normalize_kind(spec.get("kind", ""))
    params = spec.get("params") or {}
    if not isinstance(params, Mapping):
        raise TypeError("spec.params must be a mapping")
    return kind, params


def create_default_registry() -> InterventionRegistry:
    registry = InterventionRegistry()
    registry.register("reset_context_trim", ResetContextTrim)
    registry.register("reset_replan", ResetReplan)
    registry.register("reset_tool_breaker", ResetToolBreaker)
    registry.register("reset_model_fallback", ResetModelFallback)
    registry.register("stochastic_replan", StochasticReplan)
    registry.register("stochastic_parameter_reset", StochasticParameterReset)
    registry.register("reset_summarize", ResetSummarize)
    registry.register("context_prune", ContextPrune)
    registry.register("persona_swap", PersonaSwap)
    registry.register("backoff", Backoff)
    registry.register("stop_the_line", StopTheLine)
    return registry


default_registry = create_default_registry()

__all__ = ["InterventionRegistry", "create_default_registry", "default_registry"]
