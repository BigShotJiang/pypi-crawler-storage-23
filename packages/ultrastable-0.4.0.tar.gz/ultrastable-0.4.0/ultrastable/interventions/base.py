from __future__ import annotations

from collections.abc import Mapping, MutableMapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np
from numpy.random import Generator

from ultrastable.core.events import (
    HealthSnapshotEvent,
    InterventionEvent,
    TriggerEvent,
)
from ultrastable.core.health import ViabilityPolicy


@dataclass
class InterventionRequest:
    triggers: Sequence[TriggerEvent]
    policy: ViabilityPolicy | None = None
    pre_snapshot: HealthSnapshotEvent | None = None
    pre_snapshot_id: str | None = None
    state: MutableMapping[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class InterventionResult:
    plan: Mapping[str, Any]
    outcome: Mapping[str, Any] | None = None
    state: MutableMapping[str, Any] | None = None
    event: InterventionEvent | None = None


class Intervention(Protocol):
    name: str

    def run(self, request: InterventionRequest) -> InterventionResult | None: ...


class Summarizer(Protocol):
    def summarize(
        self,
        messages: Sequence[Mapping[str, Any]],
        *,
        max_chars: int | None = None,
    ) -> str: ...


class StochasticIntervention:
    """Base class for interventions that rely on local RNG state."""

    def __init__(self, *, seed: int | None = None) -> None:
        self._seed = seed
        self._rng: Generator = np.random.default_rng(seed)

    @property
    def seed(self) -> int | None:
        return self._seed

    def reseed(self, seed: int | None = None) -> None:
        self._seed = seed
        self._rng = np.random.default_rng(seed)

    @property
    def rng(self) -> Generator:
        return self._rng

    def _stochastic_metadata(self, **extra: Any) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self._seed is not None:
            payload["seed"] = self._seed
        payload.update(extra)
        return payload


def build_event(
    *,
    intervention_type: str,
    request: InterventionRequest,
    parameters: Mapping[str, Any],
    outcome: Mapping[str, Any] | None = None,
    post_snapshot_id: str | None = None,
    tags: Mapping[str, Any] | None = None,
    stochastic_params: Mapping[str, Any] | None = None,
) -> InterventionEvent:
    trigger_ids = [t.trigger_id for t in request.triggers if t.trigger_id]
    event = InterventionEvent(
        intervention_type=intervention_type,
        parameters=dict(parameters),
        trigger_ids=trigger_ids,
        outcome=dict(outcome or {}),
        pre_snapshot_id=request.pre_snapshot_id,
        post_snapshot_id=post_snapshot_id,
        stochastic_params=dict(stochastic_params or {}),
        tags=dict(tags or {}),
    )
    return event


__all__ = [
    "InterventionRequest",
    "InterventionResult",
    "Intervention",
    "Summarizer",
    "StochasticIntervention",
    "build_event",
]
