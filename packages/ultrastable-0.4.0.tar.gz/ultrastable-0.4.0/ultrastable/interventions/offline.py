from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, MutableMapping, Sequence
from typing import Any

from ultrastable.core.events import TriggerEvent

from .base import (
    Intervention,
    InterventionRequest,
    InterventionResult,
    StochasticIntervention,
    Summarizer,
    build_event,
)


def _is_tool_message(message: Mapping[str, Any]) -> bool:
    role = str(message.get("role", "")).lower()
    kind = str(message.get("kind", "")).lower()
    tags = message.get("tags", {}) or {}
    tag_role = str(tags.get("role", "")).lower()
    return role == "tool" or kind == "tool" or tag_role == "tool"


def _is_pinned(message: Mapping[str, Any]) -> bool:
    tags = message.get("tags", {}) or {}
    return bool(message.get("pinned") or tags.get("pinned"))


def _estimate_tokens(message: Mapping[str, Any]) -> int:
    tokens = message.get("tokens")
    if isinstance(tokens, (int, float)):
        return int(tokens)
    content = str(message.get("content", ""))
    if not content:
        return 0
    return max(1, math.ceil(len(content) / 4))


def _message_id(message: Mapping[str, Any], fallback: int) -> str:
    for key in ("id", "message_id", "step_id"):
        val = message.get(key)
        if isinstance(val, str) and val:
            return val
    return f"msg_{fallback}"


def _trim_context(
    messages: Sequence[Mapping[str, Any]],
    *,
    keep_last: int,
    preserve_system: bool,
) -> tuple[list[Mapping[str, Any]], dict[str, Any]]:
    indexed = list(enumerate(messages))
    system_idx = {
        idx
        for idx, msg in indexed
        if preserve_system and str(msg.get("role", "")).lower() == "system"
    }
    pinned_idx = {idx for idx, msg in indexed if _is_pinned(msg)}
    keep_idx = set(system_idx) | set(pinned_idx)
    remainder = [idx for idx, _ in indexed if idx not in keep_idx]
    dropped_idx: list[int] = []
    while len(remainder) > keep_last:
        drop_idx = next((i for i in remainder if _is_tool_message(messages[i])), None)
        if drop_idx is None:
            drop_idx = remainder[0]
        remainder.remove(drop_idx)
        dropped_idx.append(drop_idx)
    keep_idx |= set(remainder)
    trimmed = [messages[i] for i in range(len(messages)) if i in keep_idx]
    dropped_ids = [_message_id(messages[i], i) for i in range(len(messages)) if i not in keep_idx]
    stats = {
        "dropped_count": len(dropped_ids),
        "dropped_ids": dropped_ids,
        "pre_messages": len(messages),
        "post_messages": len(trimmed),
        "pre_tokens": sum(_estimate_tokens(m) for m in messages),
        "post_tokens": sum(_estimate_tokens(m) for m in trimmed),
    }
    return trimmed, stats


class ResetContextTrim(Intervention):
    name = "RESET_CONTEXT_TRIM"

    def __init__(self, keep_last_turns: int = 6, preserve_system: bool = True) -> None:
        if keep_last_turns <= 0:
            raise ValueError("keep_last_turns must be > 0")
        self.keep_last_turns = keep_last_turns
        self.preserve_system = preserve_system

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        conversation = list(state.get("conversation") or [])
        if not conversation:
            return None
        trimmed, stats = _trim_context(
            conversation,
            keep_last=self.keep_last_turns,
            preserve_system=self.preserve_system,
        )
        if stats["dropped_count"] == 0:
            return None

        state["conversation"] = trimmed
        parameters = {
            "action": "trim_context",
            "keep_last_turns": self.keep_last_turns,
            "preserve_system": self.preserve_system,
        }
        outcome = stats
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class ResetReplan(Intervention):
    name = "RESET_REPLAN"

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        if state.get("force_replan"):
            return None
        state["force_replan"] = True
        parameters = {"action": "force_replan"}
        outcome = {"status": "flagged"}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class StochasticReplan(StochasticIntervention):
    name = "STOCHASTIC_REPLAN"

    def __init__(self, *, noise_std: float = 0.3, seed: int | None = None) -> None:
        super().__init__(seed=seed)
        if noise_std <= 0:
            raise ValueError("noise_std must be > 0")
        self.noise_std = float(noise_std)

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        noise = float(self.rng.normal(0.0, self.noise_std))
        state["force_replan"] = True
        state["replan_noise"] = noise
        parameters = {
            "action": "stochastic_replan",
            "noise_std": self.noise_std,
        }
        outcome = {"status": "flagged", "noise": noise}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
            stochastic_params=self._stochastic_metadata(noise=noise),
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class ResetToolBreaker(Intervention):
    name = "RESET_TOOL_BREAKER"

    def __init__(self, cooldown_steps: int = 5, state_key: str = "disabled_tools") -> None:
        if cooldown_steps <= 0:
            raise ValueError("cooldown_steps must be > 0")
        self.cooldown_steps = cooldown_steps
        self.state_key = state_key

    def _extract_tool_name(
        self, triggers: Sequence[TriggerEvent], state: MutableMapping[str, Any]
    ) -> str | None:
        for trigger in triggers:
            if trigger.tags.get("tool_name"):
                return str(trigger.tags["tool_name"])
        if "tool_name" in state:
            return str(state["tool_name"])
        if "looping_tool" in state:
            return str(state["looping_tool"])
        return None

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        target_tool = self._extract_tool_name(request.triggers, state)
        if not target_tool:
            return None
        disabled = dict(state.get(self.state_key) or {})
        if disabled.get(target_tool) == self.cooldown_steps:
            return None
        disabled[target_tool] = self.cooldown_steps
        state[self.state_key] = disabled
        parameters = {
            "action": "tool_breaker",
            "tool_name": target_tool,
            "cooldown_steps": self.cooldown_steps,
        }
        outcome = {"disabled_tools": disabled}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class ResetModelFallback(Intervention):
    name = "RESET_MODEL_FALLBACK"

    def __init__(self, fallback_model: str | None = None) -> None:
        self.fallback_model = fallback_model

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        current = state.get("current_model")
        candidates = state.get("available_models") or []
        fallback = self.fallback_model or state.get("fallback_model")
        if fallback is None and candidates:
            fallback = candidates[-1]
        if fallback is None or fallback == current:
            return None
        allowed = set(candidates) if candidates else None
        if allowed is not None and fallback not in allowed:
            return None
        state["current_model"] = fallback
        history = list(state.get("model_route_history") or [])
        history.append({"from": current, "to": fallback})
        state["model_route_history"] = history
        parameters = {
            "action": "model_fallback",
            "to_model": fallback,
        }
        outcome = {"previous_model": current, "current_model": fallback}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class ResetSummarize(Intervention):
    name = "RESET_SUMMARIZE"

    def __init__(
        self,
        summarizer: Summarizer,
        *,
        summarizer_id: str = "local",
        method: str = "deterministic",
        summary_state_key: str = "conversation_summary",
        max_chars: int | None = 2000,
    ) -> None:
        self.summarizer = summarizer
        self.summarizer_id = summarizer_id
        self.method = method
        self.summary_state_key = summary_state_key
        self.max_chars = max_chars

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        conversation = list(state.get("conversation") or [])
        if not conversation:
            return None
        summary = self.summarizer.summarize(conversation, max_chars=self.max_chars)
        if not summary:
            return None
        state[self.summary_state_key] = summary
        digest = hashlib.sha256(summary.encode("utf-8")).hexdigest()
        parameters = {
            "action": "summarize",
            "summary_key": self.summary_state_key,
            "max_chars": self.max_chars,
        }
        outcome = {"summary_hash": digest, "summary_length": len(summary)}
        tags = {
            "summarizer_id": self.summarizer_id,
            "method": self.method,
            "summary_hash": digest,
        }
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
            tags=tags,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class ContextPrune(Intervention):
    name = "CONTEXT_PRUNE"

    """Summarize old turns while keeping critical context.

    Example:
        summarizer = MySummarizer()
        intervention = ContextPrune(summarizer, keep_last_turns=4)
    """

    def __init__(
        self,
        summarizer: Summarizer,
        *,
        keep_last_turns: int = 4,
        preserve_system: bool = True,
        summary_state_key: str = "conversation_summary",
        summary_role: str = "system",
        summary_prefix: str = "[Summary]",
        max_chars: int | None = 2000,
    ) -> None:
        if keep_last_turns <= 0:
            raise ValueError("keep_last_turns must be > 0")
        self.summarizer = summarizer
        self.keep_last_turns = keep_last_turns
        self.preserve_system = preserve_system
        self.summary_state_key = summary_state_key
        self.summary_role = summary_role
        self.summary_prefix = summary_prefix
        self.max_chars = max_chars

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        conversation = list(state.get("conversation") or [])
        if len(conversation) <= self.keep_last_turns:
            return None
        preserved = []
        if self.preserve_system:
            for msg in conversation:
                if str(msg.get("role", "")).lower() == "system":
                    preserved.append(dict(msg))
        head = conversation[: -self.keep_last_turns]
        if not head:
            return None
        summary = self.summarizer.summarize(head, max_chars=self.max_chars)
        if not summary:
            return None
        summary_entry = {
            "id": f"summary-{len(state.get('summaries', []))}",
            "role": self.summary_role,
            "content": f"{self.summary_prefix} {summary}".strip(),
            "tags": {"summary": True},
        }
        tail = [dict(msg) for msg in conversation[-self.keep_last_turns :]]
        merged: list[Mapping[str, Any]] = []
        seen_ids: set[str] = set()
        for msg in preserved + [summary_entry] + tail:
            mid = str(msg.get("id") or f"msg-{len(merged)}")
            if mid in seen_ids:
                continue
            seen_ids.add(mid)
            merged.append(msg)
        state["conversation"] = merged
        summaries = list(state.get("summaries") or [])
        summaries.append(summary)
        state["summaries"] = summaries
        state[self.summary_state_key] = summary
        digest = hashlib.sha256(summary.encode("utf-8")).hexdigest()
        parameters = {
            "action": "context_prune",
            "keep_last_turns": self.keep_last_turns,
            "preserve_system": self.preserve_system,
        }
        outcome = {
            "summary_hash": digest,
            "summary_length": len(summary),
            "post_messages": len(merged),
            "pre_messages": len(conversation),
            "kept_turns": self.keep_last_turns,
        }
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
            tags={"summary_hash": digest},
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class PersonaSwap(Intervention):
    name = "PERSONA_SWAP"

    """Inject a deterministic system persona when a breach occurs."""

    def __init__(
        self,
        persona_prompt: str = "You are now operating in diagnostics mode. Explain your reasoning.",
        *,
        history_key: str = "persona_history",
        tag: str = "persona_swap",
    ) -> None:
        if not persona_prompt:
            raise ValueError("persona_prompt must be non-empty")
        self.persona_prompt = persona_prompt
        self.history_key = history_key
        self.tag = tag

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        conversation = list(state.get("conversation") or [])
        history = list(state.get(self.history_key) or [])
        if history and history[-1].get("prompt") == self.persona_prompt:
            return None
        entry = {
            "id": f"persona-{len(history)}",
            "role": "system",
            "content": self.persona_prompt,
            "tags": {self.tag: True},
        }
        new_conversation = [entry]
        new_conversation.extend(
            msg for msg in conversation if not (msg.get("tags") or {}).get(self.tag)
        )
        state["conversation"] = new_conversation
        history.append({"prompt": self.persona_prompt})
        state[self.history_key] = history
        parameters = {"action": "persona_swap"}
        outcome = {"active_persona": self.persona_prompt}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class Backoff(Intervention):
    name = "BACKOFF"

    """Record a pause/backoff window in the controller state."""

    def __init__(
        self,
        *,
        steps: int = 3,
        reason: str = "policy_breach",
        state_key: str = "backoff",
    ) -> None:
        if steps <= 0:
            raise ValueError("steps must be > 0")
        self.steps = steps
        self.reason = reason
        self.state_key = state_key

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        current = dict(state.get(self.state_key) or {})
        if current.get("remaining_steps", 0) >= self.steps:
            return None
        payload = {"remaining_steps": self.steps, "reason": self.reason}
        state[self.state_key] = payload
        parameters = {"action": "backoff", "steps": self.steps}
        outcome = payload
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class StopTheLine(Intervention):
    name = "STOP_THE_LINE"

    """Flag the run as halted and emit a high-severity report."""

    def __init__(
        self,
        *,
        report_key: str = "stop_report",
    ) -> None:
        self.report_key = report_key

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        if state.get("halted"):
            return None
        report = {
            "triggers": [t.detector for t in request.triggers],
            "severity": max((t.severity for t in request.triggers), default="warn"),
            "reason": "stop_the_line",
        }
        state["halted"] = True
        state[self.report_key] = report
        parameters = {"action": "stop_the_line"}
        outcome = dict(report)
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
            tags={"halted": True},
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


class StochasticParameterReset(StochasticIntervention):
    name = "STOCHASTIC_PARAMETER_RESET"

    def __init__(
        self,
        *,
        state_key: str = "parameters",
        fraction: float = 0.5,
        noise_std: float = 0.1,
        seed: int | None = None,
    ) -> None:
        super().__init__(seed=seed)
        if fraction <= 0:
            raise ValueError("fraction must be > 0")
        if noise_std <= 0:
            raise ValueError("noise_std must be > 0")
        self.state_key = state_key
        self.fraction = float(fraction)
        self.noise_std = float(noise_std)

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        state = dict(request.state or {})
        params = dict(state.get(self.state_key) or {})
        numeric_keys = [k for k, v in params.items() if isinstance(v, (int, float))]
        if not numeric_keys:
            return None
        total = len(numeric_keys)
        count = max(1, min(total, int(math.ceil(total * self.fraction))))
        idxs = self.rng.choice(total, size=count, replace=False)
        updated: dict[str, float] = {}
        for idx in idxs:
            key = numeric_keys[int(idx)]
            base = float(params[key])
            delta = float(self.rng.normal(0.0, self.noise_std))
            params[key] = base + delta
            updated[key] = params[key]
        state[self.state_key] = params
        parameters = {
            "action": "stochastic_parameter_reset",
            "state_key": self.state_key,
            "noise_std": self.noise_std,
            "fraction": self.fraction,
        }
        outcome = {"updated_parameters": updated, "total_parameters": total}
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters=parameters,
            outcome=outcome,
            stochastic_params=self._stochastic_metadata(reset_keys=list(updated.keys())),
        )
        return InterventionResult(plan=parameters, outcome=outcome, state=state, event=event)


__all__ = [
    "ResetContextTrim",
    "ResetReplan",
    "StochasticReplan",
    "ResetToolBreaker",
    "ResetModelFallback",
    "ResetSummarize",
    "ContextPrune",
    "PersonaSwap",
    "Backoff",
    "StopTheLine",
    "StochasticParameterReset",
]
