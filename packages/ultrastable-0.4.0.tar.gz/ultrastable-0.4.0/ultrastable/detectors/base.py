from __future__ import annotations

from collections import deque
from collections.abc import Iterator, Sequence
from typing import Protocol

from ultrastable.core.events import HealthSnapshotEvent, StepEvent, TriggerEvent


class Detector(Protocol):
    """Detector interface.

    Implementations inspect a rolling window of `StepEvent`s (and optionally the
    latest `HealthSnapshotEvent`s) and emit zero or more `TriggerEvent`s.
    """

    name: str

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]: ...


class StepWindow:
    """Simple sliding window helper for step events."""

    def __init__(self, maxlen: int) -> None:
        self._buffer: deque[StepEvent] = deque(maxlen=maxlen)

    def append(self, step: StepEvent) -> None:
        self._buffer.append(step)

    def extend(self, steps: Sequence[StepEvent]) -> None:
        for step in steps:
            self._buffer.append(step)

    def __iter__(self) -> Iterator[StepEvent]:
        return iter(self._buffer)

    def __len__(self) -> int:
        return len(self._buffer)

    def snapshot(self) -> Sequence[StepEvent]:
        return list(self._buffer)


__all__ = ["Detector", "StepWindow"]
