from __future__ import annotations

import math
import re
from collections import Counter, deque
from collections.abc import Iterable, Sequence

from ultrastable.core.events import HealthSnapshotEvent, StepEvent, TriggerEvent

from .base import Detector


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _ngrams(text: str, n: int) -> Counter[str]:
    if len(text) < n:
        return Counter([text])
    return Counter(text[i : i + n] for i in range(len(text) - n + 1))


def _jaccard(a: Counter[str], b: Counter[str]) -> float:
    if not a and not b:
        return 1.0
    set_a = set(a)
    set_b = set(b)
    inter = len(set_a & set_b)
    union = len(set_a | set_b)
    return inter / union if union else 1.0


def _coerce_float(value: float | int | None) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class LexicalRepeatDetector(Detector):
    name = "lexical_repeat"

    def __init__(
        self,
        window_size: int = 6,
        repeat_threshold: int = 3,
        min_chars: int = 20,
        similarity_threshold: float = 0.92,
        critical_repeat_threshold: int = 4,
        ngram: int = 3,
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if repeat_threshold < 2:
            raise ValueError("repeat_threshold must be >= 2")
        self.window_size = window_size
        self.repeat_threshold = repeat_threshold
        self.min_chars = min_chars
        self.similarity_threshold = similarity_threshold
        self.critical_repeat_threshold = critical_repeat_threshold
        self.ngram = ngram

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        relevant = [
            s
            for s in steps[-self.window_size :]
            if (s.role or s.kind) in {"assistant", "llm"}
            and isinstance(s.response_text, str)
            and len(s.response_text.strip()) >= self.min_chars
        ]
        if len(relevant) < self.repeat_threshold:
            return []

        last = relevant[-self.repeat_threshold :]
        similarities: list[float] = []
        grams_cache: list[Counter[str]] = []
        for step in last:
            grams_cache.append(_ngrams(_normalize_text(step.response_text or ""), self.ngram))
        for i in range(1, len(grams_cache)):
            similarities.append(_jaccard(grams_cache[i - 1], grams_cache[i]))
        avg_similarity = sum(similarities) / len(similarities)
        if avg_similarity < self.similarity_threshold:
            return []

        severity = "critical" if len(relevant) >= self.critical_repeat_threshold else "warn"
        trigger = TriggerEvent(
            detector=self.name,
            severity=severity,
            explanation=(
                f"Repeated assistant output detected (avg similarity {avg_similarity:.2%},"
                f" {len(last)} repeats)"
            ),
            related_step_ids=[step.step_id for step in last if step.step_id],
        )
        return [trigger]


class ToolLoopDetector(Detector):
    name = "tool_loop"

    def __init__(
        self,
        window_size: int = 12,
        repeat_threshold: int = 3,
        failure_statuses: Iterable[str] | None = None,
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if repeat_threshold < 2:
            raise ValueError("repeat_threshold must be >= 2")
        self.window_size = window_size
        self.repeat_threshold = repeat_threshold
        self.failure_statuses = {
            s.lower() for s in (failure_statuses or ["error", "timeout", "429"])
        }

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        recent = [s for s in steps[-self.window_size :] if (s.kind == "tool" or s.role == "tool")]
        if len(recent) < self.repeat_threshold:
            return []

        triggers: list[TriggerEvent] = []
        # Check repeated identical calls
        key_buffer: deque[tuple[str, str | None]] = deque(maxlen=self.repeat_threshold)
        for step in recent:
            key = (
                step.tool_name or step.tags.get("tool_name", ""),
                step.tool_args_hash or step.tags.get("tool_args_hash"),
            )
            if not key[0]:
                continue
            key_buffer.append(key)
            if len(key_buffer) == self.repeat_threshold:
                if all(k == key_buffer[0] for k in key_buffer):
                    triggers.append(
                        TriggerEvent(
                            detector=self.name,
                            severity="warn",
                            explanation=(
                                f"Tool '{key[0]}' called {self.repeat_threshold} times with"
                                " identical args"
                            ),
                            related_step_ids=[
                                step.step_id
                                for step in recent[-self.repeat_threshold :]
                                if step.step_id
                            ],
                            tags={"loop_key": str(key), "tool_name": key[0]},
                        )
                    )
                    break

        # Check failure signatures
        failure_steps = [
            step
            for step in recent
            if str(step.tags.get("status", "")).lower() in self.failure_statuses
            or str(step.tags.get("error", "")).lower() in self.failure_statuses
        ]
        if len(failure_steps) >= self.repeat_threshold:
            tool_name = next((s.tool_name for s in reversed(failure_steps) if s.tool_name), None)
            triggers.append(
                TriggerEvent(
                    detector=self.name,
                    severity="critical",
                    explanation=(
                        f"{len(failure_steps)} recent tool errors (statuses"
                        f" {self.failure_statuses})"
                    ),
                    related_step_ids=[step.step_id for step in failure_steps if step.step_id][
                        -self.repeat_threshold :
                    ],
                    tags={"tool_name": tool_name} if tool_name else {},
                )
            )

        return triggers


class ContextPressureDetector(Detector):
    name = "context_pressure"

    def __init__(
        self,
        max_tokens: int = 4000,
        warn_fraction: float = 0.85,
        critical_fraction: float = 0.95,
        fallback_chars_per_token: float = 4.0,
        snapshot_variable: str | None = "context_util",
    ) -> None:
        if max_tokens <= 0:
            raise ValueError("max_tokens must be > 0")
        if not (0 < warn_fraction <= 1.0) or not (0 < critical_fraction <= 1.0):
            raise ValueError("fractions must be in (0,1]")
        self.max_tokens = max_tokens
        self.warn_fraction = warn_fraction
        self.critical_fraction = critical_fraction
        self.fallback_chars_per_token = fallback_chars_per_token
        self.snapshot_variable = snapshot_variable

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        last_step = steps[-1] if steps else None
        if last_step is None:
            return []

        utilization = None
        if snapshots and self.snapshot_variable:
            # Use latest snapshot value if available
            for snapshot in reversed(snapshots):
                if self.snapshot_variable in snapshot.values:
                    utilization = float(snapshot.values[self.snapshot_variable])
                    break

        if utilization is None:
            tokens_total = last_step.tokens_total
            if tokens_total is None:
                tokens_total = (last_step.tokens_prompt or 0) + (last_step.tokens_completion or 0)
            if tokens_total is None or tokens_total == 0:
                # Fall back to chars
                prompt = last_step.prompt_text or ""
                response = last_step.response_text or ""
                approx_tokens = math.ceil(len(prompt) / self.fallback_chars_per_token) + math.ceil(
                    len(response) / self.fallback_chars_per_token
                )
                tokens_total = approx_tokens
            utilization = float(tokens_total) / float(self.max_tokens)

        severity = None
        threshold = None
        if utilization >= self.critical_fraction:
            severity = "critical"
            threshold = self.critical_fraction
        elif utilization >= self.warn_fraction:
            severity = "warn"
            threshold = self.warn_fraction

        if severity is None:
            return []

        explanation = (
            f"Context utilization {utilization:.1%} >= {threshold:.0%} of max tokens"
            f" {self.max_tokens}"
        )
        trigger = TriggerEvent(
            detector=self.name,
            severity=severity,
            explanation=explanation,
            related_step_ids=[last_step.step_id] if last_step.step_id else [],
            tags={
                "utilization": utilization,
                "max_tokens": self.max_tokens,
                "threshold": threshold,
            },
        )
        return [trigger]


def _tokenize_words(text: str) -> Counter[str]:
    cleaned = re.sub(r"[^a-z0-9\s]+", " ", (text or "").lower())
    tokens = [tok for tok in cleaned.split() if tok]
    return Counter(tokens)


def _cosine_similarity(a: Counter[str], b: Counter[str]) -> float:
    if not a or not b:
        return 0.0
    numerator = sum(a[token] * b.get(token, 0) for token in a)
    if numerator == 0:
        return 0.0
    denom = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
    if denom == 0:
        return 0.0
    return numerator / denom


class SemanticLoopDetector(Detector):
    name = "semantic_loop"

    def __init__(
        self,
        window_size: int = 6,
        min_turns: int = 3,
        similarity_threshold: float = 0.94,
        min_chars: int = 12,
        critical_turns: int = 4,
    ) -> None:
        if window_size <= 1:
            raise ValueError("window_size must be > 1")
        if min_turns < 2 or critical_turns < 2:
            raise ValueError("turn thresholds must be >= 2")
        self.window_size = window_size
        self.min_turns = min_turns
        self.similarity_threshold = similarity_threshold
        self.min_chars = min_chars
        self.critical_turns = critical_turns

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        relevant = [
            s
            for s in steps[-self.window_size :]
            if (s.role or s.kind) in {"assistant", "llm"}
            and isinstance(s.response_text, str)
            and len(s.response_text.strip()) >= self.min_chars
        ]
        if len(relevant) < self.min_turns:
            return []
        tokenized = [_tokenize_words(step.response_text or "") for step in relevant]
        similarities: list[float] = []
        for idx in range(1, len(tokenized)):
            similarities.append(_cosine_similarity(tokenized[idx - 1], tokenized[idx]))
        if not similarities:
            return []
        avg_similarity = sum(similarities) / len(similarities)
        if avg_similarity < self.similarity_threshold:
            return []
        severity = "critical" if len(relevant) >= self.critical_turns else "warn"
        return [
            TriggerEvent(
                detector=self.name,
                severity=severity,
                explanation=(
                    f"Semantic loop detected (avg cosine {avg_similarity:.2%},"
                    f" {len(relevant)} turns)"
                ),
                related_step_ids=[step.step_id for step in relevant if step.step_id],
            )
        ]


class ContextRotDetector(Detector):
    name = "context_rot"

    def __init__(
        self,
        window_size: int = 5,
        variable: str = "context_util",
        warn_threshold: float = 0.75,
        critical_threshold: float = 0.9,
        growth_threshold: float = 0.1,
        critical_growth: float = 0.2,
        max_tokens: int = 4000,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be >= 2")
        self.window_size = window_size
        self.variable = variable
        self.warn_threshold = warn_threshold
        self.critical_threshold = critical_threshold
        self.growth_threshold = growth_threshold
        self.critical_growth = critical_growth
        self.max_tokens = max_tokens

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        series = self._collect_series(steps, snapshots)
        if len(series) < 2:
            return []
        window = series[-self.window_size :]
        start = window[0]
        end = window[-1]
        growth = max(0.0, end - start)
        severity = None
        if end >= self.critical_threshold or growth >= self.critical_growth:
            severity = "critical"
        elif end >= self.warn_threshold and growth >= self.growth_threshold:
            severity = "warn"
        if severity is None:
            return []
        return [
            TriggerEvent(
                detector=self.name,
                severity=severity,
                explanation=(
                    f"Context utilization climbed from {start:.2f} to {end:.2f} (+{growth:.2f})"
                ),
                tags={"series_window": len(window)},
            )
        ]

    def _collect_series(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None,
    ) -> list[float]:
        values: list[float] = []
        if snapshots:
            for snapshot in snapshots[-self.window_size :]:
                raw = snapshot.values.get(self.variable)
                if raw is not None:
                    try:
                        values.append(float(max(0.0, min(1.0, float(raw)))))
                    except (TypeError, ValueError):
                        continue
        if len(values) >= 2:
            return values
        for step in steps[-self.window_size :]:
            util = step.tags.get(self.variable)
            if util is not None:
                try:
                    values.append(float(util))
                    continue
                except (TypeError, ValueError):
                    pass
            tokens = step.tokens_total or step.tokens_prompt or 0.0
            if tokens and self.max_tokens > 0:
                values.append(min(1.0, float(tokens) / float(self.max_tokens)))
        return values


class PredictiveBudgetExhaustionDetector(Detector):
    name = "predictive_budget_exhaustion"

    def __init__(
        self,
        budget_limit: float,
        window_size: int = 8,
        warn_horizon_steps: float = 5.0,
        critical_horizon_steps: float = 2.0,
        *,
        min_window_spend: float = 0.0,
        spend_variable: str = "spend_usd",
        min_samples: int | None = None,
    ) -> None:
        if budget_limit <= 0.0:
            raise ValueError("budget_limit must be > 0")
        if window_size < 3:
            raise ValueError("window_size must be >= 3 to fit a regression line")
        if warn_horizon_steps <= 0.0 or critical_horizon_steps <= 0.0:
            raise ValueError("horizon steps must be > 0")
        if critical_horizon_steps > warn_horizon_steps:
            raise ValueError("critical horizon must be <= warn horizon")
        if min_window_spend < 0.0:
            raise ValueError("min_window_spend must be >= 0")
        if min_samples is None:
            min_samples = max(3, min(window_size, 6))
        if min_samples < 3 or min_samples > window_size:
            raise ValueError("min_samples must be in [3, window_size]")
        self.budget_limit = float(budget_limit)
        self.window_size = window_size
        self.warn_horizon_steps = float(warn_horizon_steps)
        self.critical_horizon_steps = float(critical_horizon_steps)
        self.min_window_spend = float(min_window_spend)
        self.spend_variable = spend_variable
        self.min_samples = int(min_samples)

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        if not steps:
            return []
        samples = self._build_series(steps)
        if len(samples) < self.min_samples:
            return []
        window = samples[-self.window_size :]
        if window[-1][1] - window[0][1] < self.min_window_spend:
            return []
        regression = self._linear_regression(window)
        if regression is None:
            return []
        slope, _ = regression
        if slope <= 0:
            return []
        current_spend = self._current_spend(window, snapshots)
        remaining = self.budget_limit - current_spend
        eta_steps = 0.0 if remaining <= 0 else remaining / slope
        severity = self._classify_eta(eta_steps)
        if severity is None:
            return []
        reason = "projected spend/time horizon"
        related = [step.step_id for step in steps[-len(window) :] if step.step_id]
        eta_seconds = self._estimate_eta_seconds(steps, len(window), eta_steps)
        eta_duration = self._format_eta_duration(eta_seconds)
        explanation = (
            f"{reason}: spend ${current_spend:.4g}/${self.budget_limit:.4g} projected to breach in"
            f" {eta_steps:.2f} steps"
        )
        if eta_duration:
            explanation += f" (~{eta_duration})"
        explanation += f" (trend ${slope:.4g}/step)"
        tags: dict[str, float | int | str] = {
            "reason": reason,
            "eta_steps": eta_steps,
            "spend": current_spend,
            "budget_limit": self.budget_limit,
            "slope_usd_per_step": slope,
            "window_size": len(window),
        }
        if eta_seconds is not None:
            tags["eta_seconds"] = eta_seconds
        return [
            TriggerEvent(
                detector=self.name,
                severity=severity,
                explanation=explanation,
                related_step_ids=related,
                tags=tags,
            )
        ]

    def _build_series(self, steps: Sequence[StepEvent]) -> list[tuple[int, float]]:
        series: list[tuple[int, float]] = []
        total = 0.0
        for idx, step in enumerate(steps):
            delta = _coerce_float(step.cost_usd)
            if delta:
                total += delta
            series.append((idx, total))
        return series

    def _linear_regression(
        self,
        window: Sequence[tuple[int, float]],
    ) -> tuple[float, float] | None:
        n = len(window)
        if n < 2:
            return None
        xs = [float(p[0]) for p in window]
        ys = [p[1] for p in window]
        mean_x = sum(xs) / n
        mean_y = sum(ys) / n
        numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys, strict=False))
        denominator = sum((x - mean_x) ** 2 for x in xs)
        if denominator == 0.0:
            return None
        slope = numerator / denominator
        intercept = mean_y - slope * mean_x
        return slope, intercept

    def _current_spend(
        self,
        window: Sequence[tuple[int, float]],
        snapshots: Sequence[HealthSnapshotEvent] | None,
    ) -> float:
        if snapshots:
            for snapshot in reversed(snapshots):
                value = snapshot.values.get(self.spend_variable)
                if value is None:
                    continue
                coerced = _coerce_float(value)
                if coerced is not None:
                    return coerced
        return window[-1][1]

    def _classify_eta(self, eta_steps: float) -> str | None:
        epsilon = 1e-9
        if eta_steps <= self.critical_horizon_steps + epsilon:
            return "critical"
        if eta_steps <= self.warn_horizon_steps + epsilon:
            return "warn"
        return None

    def _estimate_eta_seconds(
        self,
        steps: Sequence[StepEvent],
        window_length: int,
        eta_steps: float,
    ) -> float | None:
        if eta_steps < 0:
            return None
        if window_length <= 0 or not steps:
            return None
        recent_steps = steps[-window_length:]
        avg_duration = self._mean_step_duration_seconds(recent_steps)
        if avg_duration is None:
            return None
        return eta_steps * avg_duration

    def _mean_step_duration_seconds(self, steps: Sequence[StepEvent]) -> float | None:
        durations: list[float] = []
        for step in steps:
            latency = _coerce_float(getattr(step, "latency_ms", None))
            if latency is None and step.tags:
                latency = _coerce_float(step.tags.get("latency_ms"))
            if latency is None:
                continue
            seconds = latency / 1000.0
            if seconds <= 0:
                continue
            durations.append(seconds)
        if not durations:
            return None
        return sum(durations) / len(durations)

    def _format_eta_duration(self, seconds: float | None) -> str | None:
        if seconds is None:
            return None
        seconds = max(0.0, float(seconds))
        if seconds < 1e-6:
            return "0s"
        if seconds < 1.0:
            return f"{seconds * 1000:.0f}ms"
        if seconds < 60.0:
            return f"{seconds:.1f}s"
        if seconds < 3600.0:
            minutes = seconds / 60.0
            return f"{minutes:.1f}m"
        hours = seconds / 3600.0
        return f"{hours:.1f}h"


class ToolFailureDetector(Detector):
    name = "tool_failure"

    def __init__(
        self,
        window_size: int = 20,
        warn_ratio: float = 0.35,
        critical_ratio: float = 0.5,
        consecutive_threshold: int = 3,
        failure_statuses: Iterable[str] | None = None,
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if not (0 < warn_ratio <= 1.0) or not (0 < critical_ratio <= 1.0):
            raise ValueError("ratios must be within (0,1]")
        self.window_size = window_size
        self.warn_ratio = warn_ratio
        self.critical_ratio = critical_ratio
        self.consecutive_threshold = max(1, consecutive_threshold)
        self.failure_statuses = {
            s.lower() for s in (failure_statuses or ["error", "timeout", "rate_limited", "429"])
        }

    def evaluate(
        self,
        steps: Sequence[StepEvent],
        snapshots: Sequence[HealthSnapshotEvent] | None = None,
    ) -> list[TriggerEvent]:
        recent = [
            step
            for step in steps[-self.window_size :]
            if (step.kind == "tool" or step.role == "tool")
        ]
        if not recent:
            return []
        failures = [self._is_failure(step) for step in recent]
        fail_count = sum(1 for flag in failures if flag)
        ratio = fail_count / len(recent)
        severity = None
        if ratio >= self.critical_ratio or self._has_consecutive_failures(failures):
            severity = "critical"
        elif ratio >= self.warn_ratio:
            severity = "warn"
        if severity is None:
            return []
        last_tool = next((step.tool_name for step in reversed(recent) if step.tool_name), None)
        return [
            TriggerEvent(
                detector=self.name,
                severity=severity,
                explanation=(
                    f"{fail_count}/{len(recent)} recent tool calls failed (ratio {ratio:.0%})"
                ),
                tags={"tool_name": last_tool} if last_tool else {},
                related_step_ids=[
                    step.step_id
                    for step, failed in zip(recent, failures, strict=False)
                    if failed and step.step_id
                ],
            )
        ]

    def _is_failure(self, step: StepEvent) -> bool:
        status = str(step.tags.get("status", "")).lower()
        error = str(step.tags.get("error", "")).lower()
        return (status in self.failure_statuses) or (error in self.failure_statuses)

    def _has_consecutive_failures(self, failures: list[bool]) -> bool:
        streak = 0
        for flag in failures:
            if flag:
                streak += 1
                if streak >= self.consecutive_threshold:
                    return True
            else:
                streak = 0
        return False


__all__ = [
    "LexicalRepeatDetector",
    "ToolLoopDetector",
    "ContextPressureDetector",
    "SemanticLoopDetector",
    "ContextRotDetector",
    "PredictiveBudgetExhaustionDetector",
    "ToolFailureDetector",
]
