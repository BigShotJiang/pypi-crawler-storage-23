from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from .base import Detector
from .offline import (
    ContextPressureDetector,
    ContextRotDetector,
    LexicalRepeatDetector,
    PredictiveBudgetExhaustionDetector,
    SemanticLoopDetector,
    ToolFailureDetector,
    ToolLoopDetector,
)

Builder = Callable[[Mapping[str, Any]], Detector]


class DetectorRegistry:
    """Registry that instantiates detectors from config dictionaries."""

    def __init__(self) -> None:
        self._builders: dict[str, Builder] = {}

    def register(self, kind: str, factory: Callable[..., Detector]) -> None:
        key = _normalize_kind(kind)
        if key in self._builders:
            raise ValueError(f"Detector '{kind}' is already registered")
        self._builders[key] = _wrap_factory(factory)

    def build(self, spec: Mapping[str, Any] | str) -> Detector:
        kind, params = _parse_spec(spec)
        builder = self._builders.get(kind)
        if builder is None:
            raise KeyError(f"Detector '{kind}' is not registered")
        return builder(params)

    def available(self) -> list[str]:
        return sorted(self._builders)


def _normalize_kind(kind: str) -> str:
    normalized = str(kind or "").strip().lower()
    if not normalized:
        raise ValueError("kind must be a non-empty string")
    return normalized


def _wrap_factory(factory: Callable[..., Detector]) -> Builder:
    def builder(params: Mapping[str, Any]) -> Detector:
        kwargs = dict(params or {})
        try:
            return factory(**kwargs)
        except TypeError as exc:  # pragma: no cover - defensive wrapping
            raise ValueError(f"Failed to construct detector: {exc}") from exc

    return builder


def _parse_spec(spec: Mapping[str, Any] | str) -> tuple[str, Mapping[str, Any]]:
    if isinstance(spec, str):
        return _normalize_kind(spec), {}
    if not isinstance(spec, Mapping):
        raise TypeError("spec must be a string or mapping")
    kind = _normalize_kind(spec.get("kind", ""))
    params = spec.get("params") or {}
    if not isinstance(params, Mapping):
        raise TypeError("spec.params must be a mapping")
    return kind, params


def create_default_registry() -> DetectorRegistry:
    registry = DetectorRegistry()
    registry.register("lexical_repeat", LexicalRepeatDetector)
    registry.register("semantic_loop", SemanticLoopDetector)
    registry.register("tool_loop", ToolLoopDetector)
    registry.register("tool_failure", ToolFailureDetector)
    registry.register("context_pressure", ContextPressureDetector)
    registry.register("context_rot", ContextRotDetector)
    registry.register("predictive_budget_exhaustion", PredictiveBudgetExhaustionDetector)
    return registry


default_registry = create_default_registry()

__all__ = ["DetectorRegistry", "create_default_registry", "default_registry"]
