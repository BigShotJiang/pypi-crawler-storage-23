"""Offline-first detectors for stagnation, loops, and context drift."""

from .base import Detector, StepWindow
from .offline import (
    ContextPressureDetector,
    ContextRotDetector,
    LexicalRepeatDetector,
    PredictiveBudgetExhaustionDetector,
    SemanticLoopDetector,
    ToolFailureDetector,
    ToolLoopDetector,
)
from .registry import DetectorRegistry, create_default_registry, default_registry

__all__ = [
    "Detector",
    "StepWindow",
    "LexicalRepeatDetector",
    "SemanticLoopDetector",
    "ToolLoopDetector",
    "ToolFailureDetector",
    "ContextPressureDetector",
    "ContextRotDetector",
    "PredictiveBudgetExhaustionDetector",
    "DetectorRegistry",
    "create_default_registry",
    "default_registry",
]
