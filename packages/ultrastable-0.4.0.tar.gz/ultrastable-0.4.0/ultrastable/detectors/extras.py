"""Optional detectors that require extras (placeholders)."""


def _require(extra: str) -> None:
    raise ImportError(
        f"{extra} extras are not installed. Install ultrastable[{extra}] to enable enhanced "
        "detectors."
    )


class EmbeddingSimilarityDetector:  # pragma: no cover - placeholder
    def __init__(self, *args: object, **kwargs: object) -> None:
        _require("detectors")


class JudgeDetector:  # pragma: no cover - placeholder
    def __init__(self, *args: object, **kwargs: object) -> None:
        _require("detectors")


__all__ = ["EmbeddingSimilarityDetector", "JudgeDetector"]
