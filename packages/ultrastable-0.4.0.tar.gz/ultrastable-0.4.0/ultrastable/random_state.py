"""Helpers to enforce deterministic RNG state when `--seed` is supplied."""

from __future__ import annotations

import importlib
import random
from typing import Any, Final, cast

import numpy as np

try:  # pragma: no cover - optional dependency
    import torch
except Exception:  # pragma: no cover - torch not installed
    torch = cast(Any, None)

_MAX_SEED: Final = 2**32


def normalize_seed(seed: int) -> int:
    """Clamp seeds to a safe 32-bit range to keep downstream RNGs happy."""

    value = int(seed)
    normalized = abs(value) % _MAX_SEED
    return normalized


def seed_process(seed: int) -> int:
    """Seed Python, NumPy, and (when available) torch RNGs."""

    normalized = normalize_seed(seed)
    random.seed(normalized)
    np.random.seed(normalized)
    _seed_torch(normalized)
    return normalized


def _seed_torch(seed: int) -> None:
    if torch is None:
        return
    _seed_torch_cpu(seed)
    _seed_optional_accelerators(seed)
    _configure_torch_determinism()


def _seed_torch_cpu(seed: int) -> None:
    generator = _torch_default_generator()
    if generator is None:
        return
    try:
        generator.manual_seed(seed)
    except Exception:
        pass


def _torch_default_generator() -> Any | None:
    if torch is None:
        return None
    try:
        return getattr(torch.random, "default_generator", None)
    except Exception:
        return None


def _seed_optional_accelerators(seed: int) -> None:
    for module_name, method in (
        ("cuda", "manual_seed_all"),
        ("mps", "manual_seed"),
        ("xpu", "manual_seed_all"),
    ):
        _seed_optional_device(seed, module_name, method)


def _seed_optional_device(seed: int, module_name: str, method_name: str) -> None:
    module = _import_torch_module(module_name)
    if module is None:
        return
    try:
        is_in_bad_fork = getattr(module, "_is_in_bad_fork", None)
        if callable(is_in_bad_fork) and is_in_bad_fork():
            return
    except Exception:
        return
    method = getattr(module, method_name, None)
    if not callable(method):
        return
    try:
        method(seed)
    except Exception:
        pass


def _import_torch_module(module_name: str) -> Any | None:
    if torch is None:
        return None
    try:
        return importlib.import_module(f"torch.{module_name}")
    except Exception:
        return None


def _configure_torch_determinism() -> None:
    if torch is None:
        return
    try:
        use_deterministic = getattr(torch, "use_deterministic_algorithms", None)
    except Exception:
        use_deterministic = None
    if callable(use_deterministic):
        try:
            use_deterministic(True, warn_only=True)
        except TypeError:
            use_deterministic(True)
        except RuntimeError:
            pass
    backends = getattr(torch, "backends", None)
    if backends is None:
        return
    cudnn = getattr(backends, "cudnn", None)
    if cudnn is None:
        return
    try:
        cudnn.deterministic = True
        cudnn.benchmark = False
    except Exception:
        pass


__all__ = ["normalize_seed", "seed_process"]
