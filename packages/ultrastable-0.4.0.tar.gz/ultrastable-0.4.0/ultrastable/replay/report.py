from __future__ import annotations

from typing import Any

from .engine import ReplayResult


def generate_report(result: ReplayResult) -> dict[str, Any]:
    payload = {
        "steps": result.total_steps,
        "triggers": result.total_triggers,
        "interventions": result.total_interventions,
        "decisions": [
            {
                "step_id": d.step_id,
                "policy_status": d.policy_status,
                "triggers": d.trigger_count,
                "intervention_fired": d.intervention_fired,
            }
            for d in result.decisions
        ],
    }
    if result.metadata:
        payload["metadata"] = dict(result.metadata)
    return payload


def generate_causal_report(result: ReplayResult) -> dict[str, Any]:
    timeline: list[dict[str, Any]] = []
    for decision in result.decisions:
        timeline.append(
            {
                "step_id": decision.step_id,
                "policy_status": decision.policy_status,
                "trigger_count": decision.trigger_count,
                "intervention_fired": decision.intervention_fired,
                "triggers": [
                    {
                        "detector": trig.detector,
                        "severity": trig.severity,
                        "explanation": trig.explanation,
                        "variables": list(trig.variables),
                    }
                    for trig in decision.triggers
                ],
            }
        )
    payload = {
        "steps": result.total_steps,
        "triggers": result.total_triggers,
        "interventions": result.total_interventions,
        "timeline": timeline,
    }
    if result.metadata:
        payload["metadata"] = dict(result.metadata)
    return payload


__all__ = ["generate_report", "generate_causal_report"]
