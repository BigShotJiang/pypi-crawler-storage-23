from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from ultrastable.core import Controller
from ultrastable.core.events import (
    EVENT_SCHEMA_VERSION,
    StepEvent,
    TriggerEvent,
    event_schema_registry,
)
from ultrastable.events.registry import EventSchemaError
from ultrastable.ledger.canonical import CanonicalJsonError, canonical_record_bytes
from ultrastable.random_state import normalize_seed, seed_process


@dataclass
class ReplayDecision:
    step_id: str
    policy_status: str
    trigger_count: int
    intervention_fired: bool
    triggers: list[TriggerEvent] = field(default_factory=list)


@dataclass
class ReplayResult:
    decisions: list[ReplayDecision] = field(default_factory=list)
    total_steps: int = 0
    total_triggers: int = 0
    total_interventions: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


class LedgerHashChainError(ValueError):
    """Raised when a ledger's hash chain cannot be verified during replay."""


@dataclass
class LedgerHashSummary:
    present: bool = False
    verified: bool = False
    events: int = 0
    first_event_hash: str | None = None
    last_event_hash: str | None = None
    reason: str | None = None

    def to_metadata(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"present": self.present, "verified": self.verified}
        if self.present:
            if self.events:
                payload["events"] = self.events
            if self.first_event_hash:
                payload["first_event_hash"] = self.first_event_hash
            if self.last_event_hash:
                payload["last_event_hash"] = self.last_event_hash
        else:
            payload["reason"] = self.reason or "absent"
        return payload


def _compute_record_hash(record: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_record_bytes(record)).hexdigest()


def _is_hex_digest(value: str) -> bool:
    if len(value) != 64:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


class _HashChainObserver:
    """Validate ledger hash chains as events are streamed for replay."""

    def __init__(self, summary: LedgerHashSummary | None = None) -> None:
        self._summary = summary
        self._expected_prev_hash: str | None = None
        self._chain_seen = False

    def observe(self, record: Mapping[str, Any], *, line_no: int) -> None:
        stored_hash = record.get("event_hash")
        stored_prev = record.get("prev_hash")
        has_chain_fields = stored_hash is not None or stored_prev is not None
        if not has_chain_fields:
            if self._chain_seen:
                raise LedgerHashChainError(
                    f"Line {line_no}: missing event_hash in hash-chained ledger"
                )
            return

        self._chain_seen = True
        if self._summary is not None:
            self._summary.present = True

        if stored_prev is not None and not isinstance(stored_prev, str):
            raise LedgerHashChainError(
                f"Line {line_no}: prev_hash must be a string or null "
                f"(found {type(stored_prev).__name__})"
            )
        if stored_prev != self._expected_prev_hash:
            raise LedgerHashChainError(
                f"Line {line_no}: prev_hash mismatch "
                f"(expected {self._expected_prev_hash!r}, found {stored_prev!r})"
            )

        if stored_hash is None:
            raise LedgerHashChainError(f"Line {line_no}: missing event_hash")
        if not isinstance(stored_hash, str):
            raise LedgerHashChainError(
                f"Line {line_no}: event_hash must be a string (found {type(stored_hash).__name__})"
            )
        if not _is_hex_digest(stored_hash):
            raise LedgerHashChainError(
                f"Line {line_no}: event_hash must be a 64-character hex digest "
                f"(found {stored_hash!r})"
            )

        record_copy = dict(record)
        record_copy.pop("event_hash", None)
        try:
            computed_hash = _compute_record_hash(record_copy)
        except CanonicalJsonError as exc:
            raise LedgerHashChainError(
                f"Line {line_no}: cannot canonicalize record for hashing ({exc})"
            ) from exc

        if stored_hash != computed_hash:
            raise LedgerHashChainError(
                f"Line {line_no}: event_hash mismatch "
                f"(recorded {stored_hash}, computed {computed_hash})"
            )

        if self._summary is not None:
            if self._summary.first_event_hash is None:
                self._summary.first_event_hash = stored_hash
            self._summary.last_event_hash = stored_hash
            self._summary.events += 1
            self._summary.verified = True
        self._expected_prev_hash = stored_hash


def replay_events(events: Sequence[StepEvent], controller: Controller) -> ReplayResult:
    result = ReplayResult()
    state: dict[str, Any] = {"conversation": []}
    for step in events:
        decision = controller.update(step, snapshot=None, state=state)
        trigger_count = len(decision.triggers)
        result.decisions.append(
            ReplayDecision(
                step_id=step.step_id,
                policy_status=decision.policy_status,
                trigger_count=trigger_count,
                intervention_fired=decision.intervention is not None,
                triggers=list(decision.triggers),
            )
        )
        result.total_steps += 1
        result.total_triggers += trigger_count
        if decision.intervention is not None:
            result.total_interventions += 1
    return result


def parse_step_event(data: dict[str, Any]) -> StepEvent:
    allowed_fields = {
        "step_id",
        "role",
        "kind",
        "model",
        "tool_name",
        "tool_args_hash",
        "latency_ms",
        "tokens_prompt",
        "tokens_completion",
        "tokens_total",
        "cost_usd",
        "prompt_text",
        "response_text",
        "prompt_hash",
        "response_hash",
        "prompt_text_sha256",
        "response_text_sha256",
        "tags",
    }
    kwargs = {k: data.get(k) for k in allowed_fields if k in data}
    if not kwargs.get("step_id"):
        kwargs["step_id"] = data.get("id", "step")
    return StepEvent(**cast(dict[str, Any], kwargs))


def load_step_events(
    path: str | Path, *, hash_summary: LedgerHashSummary | None = None
) -> list[StepEvent]:
    events: list[StepEvent] = []
    observer = _HashChainObserver(hash_summary)
    with Path(path).open("r", encoding="utf-8") as fp:
        for idx, raw in enumerate(fp, 1):
            line = raw.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            observer.observe(data, line_no=idx)
            if data.get("event_type") != "step":
                continue
            try:
                normalized = event_schema_registry.migrate(data, to_version=EVENT_SCHEMA_VERSION)
                validated = event_schema_registry.validate(normalized)
            except EventSchemaError as exc:
                raise EventSchemaError(
                    f"Unsupported event schema version in {path}: {exc}"
                ) from exc
            events.append(parse_step_event(validated))
    if hash_summary is not None and not hash_summary.present:
        hash_summary.reason = hash_summary.reason or "absent"
    return events


def replay_ledger(
    path: str | Path,
    controller: Controller,
    *,
    deterministic: bool = False,
    seed: int | None = None,
) -> ReplayResult:
    ledger_path = Path(path)
    ledger_digest = _ledger_digest(ledger_path)
    hash_summary = LedgerHashSummary()
    events = load_step_events(ledger_path, hash_summary=hash_summary)
    metadata: dict[str, Any] = {
        "ledger_path": str(ledger_path),
        "ledger_sha256": ledger_digest,
        "hash_chain": hash_summary.to_metadata(),
    }
    policy_hash = _controller_policy_hash(controller)
    if policy_hash:
        metadata["policy_hash"] = policy_hash
    use_deterministic = deterministic or seed is not None
    if use_deterministic:
        derived_seed = _derive_seed(ledger_digest, policy_hash)
        seed_to_use = normalize_seed(seed if seed is not None else derived_seed)
        _apply_deterministic_seed(controller, seed_to_use)
        metadata["deterministic"] = True
        metadata["seed"] = seed_to_use
        metadata["seed_source"] = "user" if seed is not None else "derived"
    else:
        metadata["deterministic"] = False
    result = replay_events(events, controller)
    result.metadata = metadata
    return result


def _ledger_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(65536), b""):
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _controller_policy_hash(controller: Controller) -> str | None:
    meta = getattr(controller, "policy_metadata", None)
    if isinstance(meta, Mapping):
        value = meta.get("policy_hash")
        if isinstance(value, str) and value:
            return value
    return None


def _derive_seed(ledger_digest: str, policy_hash: str | None) -> int:
    payload = hashlib.sha256()
    payload.update(ledger_digest.encode("ascii"))
    if policy_hash:
        payload.update(policy_hash.encode("utf-8"))
    return int.from_bytes(payload.digest()[:8], "big", signed=False)


def _apply_deterministic_seed(controller: Controller, seed: int) -> None:
    seed_process(seed)
    interventions = getattr(controller, "interventions", [])
    for idx, intervention in enumerate(interventions):
        reseed = getattr(intervention, "reseed", None)
        if callable(reseed):
            reseed(seed + idx)


__all__ = [
    "LedgerHashChainError",
    "LedgerHashSummary",
    "replay_events",
    "replay_ledger",
    "ReplayResult",
    "load_step_events",
]
