"""Event schemas and optional validators (extras).

This package should not import any optional dependencies by default. Validation
layers (e.g., Pydantic) are provided behind the `events` extra and imported by
consumers explicitly.
"""

__all__: list[str] = []
