from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any


class EventSchemaError(ValueError):
    """Raised when an event JSON object does not conform to a registered schema."""


Validator = Callable[[Mapping[str, Any]], dict[str, Any]]
Migrator = Callable[[dict[str, Any]], dict[str, Any]]


class EventSchemaRegistry:
    """Registry of event schema versions plus validation + migration helpers."""

    def __init__(self, *, latest_version: str) -> None:
        if not latest_version:
            raise ValueError("latest_version must be a non-empty string")
        self.latest_version = latest_version
        self._validators: dict[str, Validator] = {}
        self._forward_migrations: dict[str, tuple[str, Migrator]] = {}

    def register(self, version: str, model: Any | None = None) -> None:
        """Register a schema version with an optional validation model/callable."""
        if not version:
            raise ValueError("version must be a non-empty string")
        self._validators[version] = self._build_validator(model)

    def add_migration(self, from_version: str, to_version: str, migrator: Migrator) -> None:
        """Register a one-step migration callable."""
        if not from_version or not to_version:
            raise ValueError("version arguments must be non-empty strings")
        self._forward_migrations[from_version] = (to_version, migrator)

    def validate(self, event_json: Mapping[str, Any]) -> dict[str, Any]:
        """Validate an event payload against its declared schema."""
        if not isinstance(event_json, Mapping):
            raise EventSchemaError("event payload must be a mapping")
        version = str(event_json.get("schema_version") or self.latest_version)
        validator = self._validators.get(version)
        if validator is None:
            raise EventSchemaError(
                f"Unsupported event schema version '{version}'. Registered versions: "
                f"{', '.join(sorted(self._validators)) or 'none'}"
            )
        try:
            return validator(event_json)
        except Exception as exc:  # pragma: no cover - validation failure details vary
            raise EventSchemaError(f"Event validation failed for schema {version}: {exc}") from exc

    def migrate(
        self,
        event_json: Mapping[str, Any],
        to_version: str | None = None,
    ) -> dict[str, Any]:
        """Migrate an event payload to the requested schema version."""
        if not isinstance(event_json, Mapping):
            raise EventSchemaError("event payload must be a mapping")
        payload: dict[str, Any] = dict(event_json)
        target = str(to_version or self.latest_version)
        if target not in self._validators:
            raise EventSchemaError(f"Target schema version '{target}' is not registered")
        current = str(payload.get("schema_version") or target)
        payload.setdefault("schema_version", current)
        if current == target:
            payload["schema_version"] = target
            return payload
        visited: set[str] = set()
        while current != target:
            if current in visited:
                raise EventSchemaError("Detected a migration cycle; check registered migrations")
            visited.add(current)
            step = self._forward_migrations.get(current)
            if not step:
                raise EventSchemaError(
                    f"No migration path from schema version '{current}' to '{target}'"
                )
            next_version, migrator = step
            payload = migrator(dict(payload))
            payload["schema_version"] = next_version
            current = next_version
        payload["schema_version"] = target
        return payload

    @staticmethod
    def _build_validator(model: Any | None) -> Validator:
        if model is None:
            return lambda payload: dict(payload)

        if hasattr(model, "model_validate"):
            return lambda payload: dict(model.model_validate(payload).model_dump())

        if hasattr(model, "parse_obj"):
            return lambda payload: dict(model.parse_obj(payload).dict())

        if callable(model):

            def validator(payload: Mapping[str, Any]) -> dict[str, Any]:
                result = model(payload)
                if isinstance(result, Mapping):
                    return dict(result)
                if hasattr(result, "model_dump"):
                    return dict(result.model_dump())
                if hasattr(result, "dict"):
                    return dict(result.dict())
                if hasattr(result, "__dict__"):
                    return dict(result.__dict__)
                return dict(result)

            return validator

        raise TypeError("model must be a pydantic model, callable, or None")


__all__ = ["EventSchemaRegistry", "EventSchemaError"]
