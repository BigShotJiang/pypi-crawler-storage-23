from __future__ import annotations

from typing import Any

AVAILABLE = False

_HAS_PYDANTIC = False

try:
    from pydantic import BaseModel
except ImportError:  # pragma: no cover - pydantic missing
    _HAS_PYDANTIC = False
else:
    _HAS_PYDANTIC = True

if _HAS_PYDANTIC:
    try:
        AVAILABLE = True

        class BaseEventModel(BaseModel):
            event_type: str
            schema_version: str
            timestamp: str
            redaction_level: str

            model_config = {"extra": "allow"}

            class Config:  # pragma: no cover - pydantic v1
                extra = "allow"

        class RunEventModel(BaseEventModel):
            run_id: str
            phase: str
            policy_version: str | None = None
            ultrastable_version: str | None = None
            meta: dict[str, Any] = {}

        class StepEventModel(BaseEventModel):
            step_id: str
            role: str | None = None
            kind: str | None = None
            model: str | None = None
            tool_name: str | None = None
            tool_args_hash: str | None = None
            latency_ms: float | None = None
            tokens_prompt: int | None = None
            tokens_completion: int | None = None
            tokens_total: int | None = None
            cost_usd: float | None = None
            d_h: float | None = None
            prompt_text: str | None = None
            response_text: str | None = None
            prompt_hash: dict[str, Any] | None = None
            response_hash: dict[str, Any] | None = None
            prompt_text_sha256: str | None = None
            response_text_sha256: str | None = None
            tags: dict[str, Any] = {}

        class CostEventModel(BaseEventModel):
            step_id: str | None = None
            provider: str | None = None
            model: str | None = None
            tokens: int | None = None
            usd: float | None = None
            cache_hit: bool | None = None
            tags: dict[str, Any] = {}

        class HealthSnapshotEventModel(BaseEventModel):
            values: dict[str, float] = {}
            deviations: dict[str, float] = {}
            d_h: float | None = None
            variable_tags: dict[str, dict[str, Any]] = {}
            tags: dict[str, Any] = {}

        class TriggerEventModel(BaseEventModel):
            trigger_id: str | None = None
            detector: str
            severity: str
            explanation: str | None = None
            related_step_ids: list[str] = []
            variables: list[str] = []
            tags: dict[str, Any] = {}

        class InterventionEventModel(BaseEventModel):
            intervention_type: str
            parameters: dict[str, Any] = {}
            trigger_ids: list[str] = []
            outcome: dict[str, Any] = {}
            pre_snapshot_id: str | None = None
            post_snapshot_id: str | None = None
            tags: dict[str, Any] = {}

        class PlasticityFacilitationEventModel(BaseEventModel):
            layer: str
            magnitude: float
            comfort_dist: float | None = None
            tags: dict[str, Any] = {}

        class ErrorEventModel(BaseEventModel):
            category: str
            code: str | None = None
            message: str | None = None
            message_hash: dict[str, Any] | None = None
            message_sha256: str | None = None
            step_id: str | None = None
            retry_count: int | None = None
            tags: dict[str, Any] = {}

    except Exception:  # pragma: no cover - fallback if definitions fail
        AVAILABLE = False
        _HAS_PYDANTIC = False

if not _HAS_PYDANTIC:
    AVAILABLE = False

    class BaseEventModel:  # type: ignore
        ...

    class RunEventModel(BaseEventModel):  # type: ignore
        ...

    class StepEventModel(BaseEventModel):  # type: ignore
        ...

    class CostEventModel(BaseEventModel):  # type: ignore
        ...

    class HealthSnapshotEventModel(BaseEventModel):  # type: ignore
        ...

    class TriggerEventModel(BaseEventModel):  # type: ignore
        ...

    class InterventionEventModel(BaseEventModel):  # type: ignore
        ...

    class PlasticityFacilitationEventModel(BaseEventModel):  # type: ignore
        ...

    class ErrorEventModel(BaseEventModel):  # type: ignore
        ...


__all__ = [
    "AVAILABLE",
    "BaseEventModel",
    "RunEventModel",
    "StepEventModel",
    "HealthSnapshotEventModel",
    "TriggerEventModel",
    "InterventionEventModel",
    "PlasticityFacilitationEventModel",
    "CostEventModel",
    "ErrorEventModel",
]
