from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import AsyncExporter, _to_line


class FileExporter(AsyncExporter):
    """Writes events to a JSONL file."""

    def __init__(
        self,
        path: str | Path,
        *,
        queue_size: int = 256,
        encoding: str = "utf-8",
    ) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._encoding = encoding
        self._fp = self._path.open("a", encoding=self._encoding)
        super().__init__(queue_size=queue_size)

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        for event in batch:
            self._fp.write(_to_line(event) + "\n")
        self._fp.flush()

    def close(self) -> None:
        super().close()
        self._fp.close()


__all__ = ["FileExporter"]
