from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from .http import HttpBatchExporter


class OtlpExporter(HttpBatchExporter):
    """Lightweight OTLP/HTTP exporter wrapping HttpBatchExporter."""

    def __init__(
        self,
        endpoint: str,
        *,
        resource: Mapping[str, Any] | None = None,
        scope: Mapping[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        self._resource = dict(resource or {})
        self._scope = dict(scope or {})
        headers = {"content-type": "application/json"}
        super().__init__(endpoint, headers=headers, **kwargs)

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        payload = {
            "resource": self._resource,
            "scope": self._scope,
            "events": batch,
        }
        serialized = json.dumps(payload).encode("utf-8")
        attempt = 0
        while True:
            try:
                self._sender(serialized, self._headers)
                return
            except Exception:
                attempt += 1
                if attempt > self._retries:
                    break
                if self._backoff > 0:
                    import time

                    time.sleep(self._backoff * (2 ** (attempt - 1)))


__all__ = ["OtlpExporter"]
