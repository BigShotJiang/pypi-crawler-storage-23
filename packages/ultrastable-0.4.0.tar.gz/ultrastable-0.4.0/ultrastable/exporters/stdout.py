from __future__ import annotations

import sys
from typing import Any, TextIO

from .base import AsyncExporter, _to_line


class StdoutExporter(AsyncExporter):
    """Writes events to a text stream (stdout by default)."""

    def __init__(
        self,
        *,
        stream: TextIO | None = None,
        queue_size: int = 128,
    ) -> None:
        self._stream = stream or sys.stdout
        super().__init__(queue_size=queue_size)

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        for event in batch:
            self._stream.write(_to_line(event) + "\n")
        self._stream.flush()


__all__ = ["StdoutExporter"]
