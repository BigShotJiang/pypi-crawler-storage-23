from __future__ import annotations

import json
import queue
import threading
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import TracebackType
from typing import Any, Protocol

from ultrastable.core.events import BaseEvent


@dataclass
class ExportResult:
    accepted: bool
    queued: int
    dropped: int = 0
    processed: int = 0


class Exporter(Protocol):
    def export(
        self,
        batch: Sequence[Mapping[str, Any] | BaseEvent],
    ) -> ExportResult: ...


class AsyncExporter:
    """Base class for non-blocking exporters with bounded queues."""

    def __init__(
        self,
        *,
        queue_size: int = 128,
        name: str | None = None,
        start_worker: bool = True,
    ) -> None:
        if queue_size <= 0:
            raise ValueError("queue_size must be > 0")
        self._queue: queue.Queue[list[dict[str, Any]] | None] = queue.Queue(maxsize=queue_size)
        self._drops = 0
        self._name = name or self.__class__.__name__
        self._worker: threading.Thread | None = None
        self._running = False
        if start_worker:
            self._start_worker()

    def _start_worker(self) -> None:
        if self._running:
            return
        self._running = True
        self._worker = threading.Thread(
            target=self._worker_loop, name=f"{self._name}-worker", daemon=True
        )
        self._worker.start()

    def export(
        self,
        batch: Sequence[Mapping[str, Any] | BaseEvent],
    ) -> ExportResult:
        normalized = self._normalize_batch(batch)
        try:
            self._queue.put_nowait(normalized)
            return ExportResult(accepted=True, queued=self._queue.qsize())
        except queue.Full:
            self._drops += len(normalized)
            return ExportResult(
                accepted=False,
                queued=self._queue.qsize(),
                dropped=len(normalized),
            )

    def flush(self, timeout: float | None = None) -> None:
        """Block until all queued batches have been processed."""
        self._queue.join()

    def close(self) -> None:
        if not self._running:
            return
        self._running = False
        self._queue.put(None)
        if self._worker is not None:
            self._worker.join()
        self._worker = None

    def __enter__(self) -> AsyncExporter:
        if not self._running:
            self._start_worker()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def _normalize_batch(
        self,
        batch: Sequence[Mapping[str, Any] | BaseEvent],
    ) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for event in batch:
            if isinstance(event, BaseEvent):
                normalized.append(event.to_dict())
            elif isinstance(event, Mapping):
                normalized.append(dict(event))
            else:
                raise TypeError(f"Unsupported event type: {type(event)!r}")
        return normalized

    def _worker_loop(self) -> None:
        while True:
            try:
                item = self._queue.get()
            except Exception:
                continue
            if item is None:
                self._queue.task_done()
                break
            try:
                self._handle_batch(item)
            finally:
                self._queue.task_done()

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        raise NotImplementedError


def _to_line(event: Mapping[str, Any]) -> str:
    return json.dumps(event, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


__all__ = ["Exporter", "AsyncExporter", "ExportResult", "_to_line"]
