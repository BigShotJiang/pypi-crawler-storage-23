from __future__ import annotations

import importlib
import json
import time
from collections.abc import Callable, Mapping
from typing import Any, cast

from .base import AsyncExporter

httpx = cast(Any, None)
try:  # pragma: no cover
    httpx = importlib.import_module("httpx")
except ModuleNotFoundError:  # pragma: no cover
    httpx = None

Sender = Callable[[bytes, Mapping[str, str]], None]


class HttpBatchExporter(AsyncExporter):
    """Non-blocking HTTP exporter with retry/backoff."""

    def __init__(
        self,
        endpoint: str,
        *,
        method: str = "POST",
        headers: Mapping[str, str] | None = None,
        timeout: float = 5.0,
        retries: int = 3,
        backoff: float = 0.2,
        queue_size: int = 128,
        sender: Sender | None = None,
    ) -> None:
        super().__init__(queue_size=queue_size)
        self._endpoint = endpoint
        self._method = method.upper()
        self._headers = {"content-type": "application/json"}
        if headers:
            self._headers.update(headers)
        self._timeout = timeout
        self._retries = max(0, retries)
        self._backoff = max(0.0, backoff)
        self._client: Any | None = None
        self._sender: Sender
        if sender is not None:
            self._sender = sender
        else:
            if httpx is None:
                raise ImportError("httpx must be installed or provide a custom sender")
            self._client = httpx.Client(timeout=self._timeout)
            self._sender = self._send_via_client

    def close(self) -> None:
        super().close()
        if self._client is not None:
            self._client.close()
            self._client = None

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        payload = json.dumps(batch).encode("utf-8")
        self._send_with_retry(payload)

    def _send_with_retry(self, payload: bytes) -> None:
        attempt = 0
        while True:
            try:
                self._sender(payload, self._headers)
                return
            except Exception:
                attempt += 1
                if attempt > self._retries:
                    break
                if self._backoff > 0:
                    time.sleep(self._backoff * (2 ** (attempt - 1)))

    def _send_via_client(self, payload: bytes, headers: Mapping[str, str]) -> None:
        assert self._client is not None  # for type-checker
        response = self._client.request(
            self._method,
            self._endpoint,
            content=payload,
            headers=headers,
        )
        response.raise_for_status()


__all__ = ["HttpBatchExporter"]
