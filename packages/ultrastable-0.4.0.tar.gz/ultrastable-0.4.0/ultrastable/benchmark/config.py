"""Harness configuration helpers for AFMB baseline runners."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, cast

from ultrastable.benchmark.manifest import SuiteDescriptor
from ultrastable.ledger.canonical import canonical_record_json

HARNESS_CONFIG_SCHEMA_VERSION = "afmb_harness_config/v1"
DEFAULT_HARNESS_CONFIG_FILENAME = "afmb_harness_config.json"

BaselineKind = Literal["timeout_only", "retry_cap", "tool_call_cap", "budget_cap"]


@dataclass(slots=True)
class BaselineDefaults:
    """Optional shared defaults applied to every baseline."""

    cases: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.cases:
            payload["cases"] = list(self.cases)
        if self.tags:
            payload["tags"] = list(self.tags)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any] | None) -> BaselineDefaults:
        if payload is None:
            return cls()
        cases = _normalize_str_sequence(payload.get("cases"), "defaults.cases")
        tags = _normalize_str_sequence(payload.get("tags"), "defaults.tags")
        return cls(cases=cases, tags=tags)


@dataclass(slots=True)
class TimeoutLimits:
    """Baseline that stops after max steps or wall-clock."""

    max_steps: int | None = None
    max_wall_seconds: float | None = None

    def __post_init__(self) -> None:
        if self.max_steps is None and self.max_wall_seconds is None:
            raise ValueError("timeout baselines require max_steps or max_wall_seconds")
        if self.max_steps is not None and self.max_steps <= 0:
            raise ValueError("max_steps must be positive")
        if self.max_wall_seconds is not None and self.max_wall_seconds <= 0:
            raise ValueError("max_wall_seconds must be positive")

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.max_steps is not None:
            payload["max_steps"] = self.max_steps
        if self.max_wall_seconds is not None:
            payload["max_wall_seconds"] = self.max_wall_seconds
        return payload


@dataclass(slots=True)
class RetryCapLimits:
    """Baseline that stops after N retries."""

    max_retries: int

    def __post_init__(self) -> None:
        if self.max_retries <= 0:
            raise ValueError("max_retries must be positive")

    def to_dict(self) -> dict[str, Any]:
        return {"max_retries": self.max_retries}


@dataclass(slots=True)
class ToolCallCapLimits:
    """Baseline that stops after N tool calls."""

    max_tool_calls: int

    def __post_init__(self) -> None:
        if self.max_tool_calls <= 0:
            raise ValueError("max_tool_calls must be positive")

    def to_dict(self) -> dict[str, Any]:
        return {"max_tool_calls": self.max_tool_calls}


@dataclass(slots=True)
class BudgetCapLimits:
    """Baseline that stops once spend/tokens exceed a hard limit."""

    max_spend_usd: float | None = None
    max_tokens: int | None = None

    def __post_init__(self) -> None:
        if self.max_spend_usd is None and self.max_tokens is None:
            raise ValueError("budget cap baselines require max_spend_usd or max_tokens")
        if self.max_spend_usd is not None and self.max_spend_usd <= 0:
            raise ValueError("max_spend_usd must be positive")
        if self.max_tokens is not None and self.max_tokens <= 0:
            raise ValueError("max_tokens must be positive")

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.max_spend_usd is not None:
            payload["max_spend_usd"] = self.max_spend_usd
        if self.max_tokens is not None:
            payload["max_tokens"] = self.max_tokens
        return payload


BaselineLimits = TimeoutLimits | RetryCapLimits | ToolCallCapLimits | BudgetCapLimits


@dataclass(slots=True)
class BaselineRunnerSpec:
    """Materialized runner spec derived from config entries."""

    name: str
    kind: BaselineKind
    limits: BaselineLimits
    cases: tuple[str, ...]
    tags: tuple[str, ...]
    metadata: Mapping[str, str]
    notes: str | None = None


@dataclass(slots=True)
class BaselineConfig:
    """Config entry describing a runnable baseline."""

    name: str
    kind: BaselineKind
    limits: BaselineLimits
    cases: tuple[str, ...] | None = None
    tags: tuple[str, ...] | None = None
    metadata: Mapping[str, str] | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "kind": self.kind,
            "limits": self.limits.to_dict(),
        }
        if self.cases is not None:
            payload["cases"] = list(self.cases)
        if self.tags is not None:
            payload["tags"] = list(self.tags)
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.notes:
            payload["notes"] = self.notes
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> BaselineConfig:
        name = _require_str(payload.get("name"), "baseline.name")
        kind_raw = _require_str(payload.get("kind"), f"baseline[{name}].kind")
        kind = _normalize_baseline_kind(kind_raw)
        limits_block = _require_mapping(payload.get("limits"), f"baseline[{name}].limits")
        limits = _parse_limits(kind, limits_block)
        cases = _normalize_optional_str_sequence(payload.get("cases"), f"baseline[{name}].cases")
        tags = _normalize_optional_str_sequence(payload.get("tags"), f"baseline[{name}].tags")
        metadata = _optional_str_dict(payload.get("metadata"), f"baseline[{name}].metadata")
        notes = _optional_str(payload.get("notes"), f"baseline[{name}].notes")
        return cls(
            name=name,
            kind=kind,
            limits=limits,
            cases=cases,
            tags=tags,
            metadata=metadata,
            notes=notes,
        )

    def build_runner_spec(
        self, defaults: BaselineDefaults, suite: SuiteDescriptor
    ) -> BaselineRunnerSpec:
        cases = self.cases if self.cases is not None else (defaults.cases or suite.cases)
        if not cases:
            raise ValueError(f"baseline '{self.name}' does not target any cases")
        tags = self.tags if self.tags is not None else defaults.tags
        metadata = dict(self.metadata) if self.metadata else {}
        return BaselineRunnerSpec(
            name=self.name,
            kind=self.kind,
            limits=self.limits,
            cases=cases,
            tags=tags,
            metadata=metadata,
            notes=self.notes,
        )


@dataclass(slots=True)
class HarnessConfig:
    """Top-level harness configuration for AFMB baselines."""

    suite: SuiteDescriptor
    baselines: tuple[BaselineConfig, ...]
    schema_version: str = HARNESS_CONFIG_SCHEMA_VERSION
    defaults: BaselineDefaults = field(default_factory=BaselineDefaults)
    metadata: Mapping[str, str] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "suite": self.suite.to_dict(),
            "baselines": [baseline.to_dict() for baseline in self.baselines],
        }
        defaults_payload = self.defaults.to_dict()
        if defaults_payload:
            payload["defaults"] = defaults_payload
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        return payload

    def to_json(self, *, indent: int | None = None) -> str:
        data = self.to_dict()
        if indent is not None:
            return json.dumps(data, indent=indent, sort_keys=True)
        return canonical_record_json(data)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> HarnessConfig:
        schema_version = _optional_str(payload.get("schema_version"), "schema_version") or (
            HARNESS_CONFIG_SCHEMA_VERSION
        )
        suite_block = _require_mapping(payload.get("suite"), "suite")
        baselines_value = payload.get("baselines")
        if not isinstance(baselines_value, Sequence):
            raise ValueError("baselines must be a sequence")
        baselines = tuple(
            BaselineConfig.from_dict(_require_mapping(item, f"baselines[{idx}]"))
            for idx, item in enumerate(baselines_value)
        )
        if not baselines:
            raise ValueError("harness config must define at least one baseline")
        defaults_value = _optional_mapping(payload.get("defaults"), "defaults")
        defaults = BaselineDefaults.from_dict(defaults_value)
        metadata = _optional_str_dict(payload.get("metadata"), "metadata")
        return cls(
            schema_version=schema_version,
            suite=SuiteDescriptor.from_dict(suite_block),
            baselines=baselines,
            defaults=defaults,
            metadata=metadata,
        )

    @classmethod
    def from_json(cls, payload: str) -> HarnessConfig:
        parsed = json.loads(payload)
        if not isinstance(parsed, Mapping):
            raise ValueError("harness config JSON must decode to an object")
        return cls.from_dict(parsed)

    @classmethod
    def load(cls, path: str | Path) -> HarnessConfig:
        return cls.from_json(Path(path).read_text(encoding="utf-8"))

    def runner_specs(self) -> tuple[BaselineRunnerSpec, ...]:
        return tuple(
            baseline.build_runner_spec(self.defaults, self.suite) for baseline in self.baselines
        )


def _normalize_baseline_kind(kind: str) -> BaselineKind:
    normalized = kind.lower()
    if normalized in {"timeout", "timeout_only"}:
        return "timeout_only"
    if normalized in {"retry", "retry_cap"}:
        return "retry_cap"
    if normalized in {"tool", "tool_calls", "tool_call_cap"}:
        return "tool_call_cap"
    if normalized in {"budget", "budget_cap", "hard_budget"}:
        return "budget_cap"
    raise ValueError(f"Unknown baseline kind: {kind!r}")


def _parse_limits(kind: BaselineKind, payload: Mapping[str, Any]) -> BaselineLimits:
    if kind == "timeout_only":
        max_steps = _optional_positive_int(payload.get("max_steps"), "limits.max_steps")
        max_wall = _optional_positive_float(
            payload.get("max_wall_seconds"),
            "limits.max_wall_seconds",
        )
        return TimeoutLimits(max_steps=max_steps, max_wall_seconds=max_wall)
    if kind == "retry_cap":
        max_retries = _require_positive_int(payload.get("max_retries"), "limits.max_retries")
        return RetryCapLimits(max_retries=max_retries)
    if kind == "tool_call_cap":
        max_tool_calls = _require_positive_int(
            payload.get("max_tool_calls"),
            "limits.max_tool_calls",
        )
        return ToolCallCapLimits(max_tool_calls=max_tool_calls)
    if kind == "budget_cap":
        max_spend = _optional_positive_float(payload.get("max_spend_usd"), "limits.max_spend_usd")
        max_tokens = _optional_positive_int(payload.get("max_tokens"), "limits.max_tokens")
        return BudgetCapLimits(max_spend_usd=max_spend, max_tokens=max_tokens)
    raise ValueError(f"Unsupported baseline kind: {kind}")


def _require_mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return value


def _optional_mapping(value: Any, field: str) -> Mapping[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return value


def _require_str(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    return value


def _optional_str(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, field)


def _normalize_str_sequence(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raise ValueError(f"{field} must be a sequence of strings")
    if not isinstance(value, Sequence):
        raise ValueError(f"{field} must be a sequence")
    return tuple(_require_str(item, f"{field}[{idx}]") for idx, item in enumerate(value))


def _normalize_optional_str_sequence(value: Any, field: str) -> tuple[str, ...] | None:
    if value is None:
        return None
    return _normalize_str_sequence(value, field)


def _optional_str_dict(value: Any, field: str) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, str] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = _require_str(raw_val, f"{field}.{key}")
    return result


def _require_positive_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    if value <= 0:
        raise ValueError(f"{field} must be positive")
    return cast(int, value)


def _optional_positive_int(value: Any, field: str) -> int | None:
    if value is None:
        return None
    return _require_positive_int(value, field)


def _optional_positive_float(value: Any, field: str) -> float | None:
    if value is None:
        return None
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError(f"{field} must be a number")
    result = float(value)
    if result <= 0.0:
        raise ValueError(f"{field} must be positive")
    return result


__all__ = [
    "BaselineConfig",
    "BaselineDefaults",
    "BaselineKind",
    "BaselineRunnerSpec",
    "BudgetCapLimits",
    "DEFAULT_HARNESS_CONFIG_FILENAME",
    "HARNESS_CONFIG_SCHEMA_VERSION",
    "HarnessConfig",
    "RetryCapLimits",
    "TimeoutLimits",
    "ToolCallCapLimits",
]
