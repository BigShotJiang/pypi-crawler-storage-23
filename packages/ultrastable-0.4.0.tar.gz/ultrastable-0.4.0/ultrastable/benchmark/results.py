"""Benchmark results schema definitions and helpers."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, cast

from ultrastable.ledger.canonical import canonical_record_json

from .manifest import SuiteDescriptor

RESULTS_SCHEMA_VERSION = "benchmark_results/v1"
DEFAULT_RESULTS_FILENAME = "results.json"
RUN_STATUS_VALUES = frozenset({"completed", "failed", "partial", "error"})
CASE_STATUS_VALUES = frozenset({"passed", "failed", "error", "skipped"})

ScalarMetric = bool | int | float | str


@dataclass(slots=True)
class RunSummary:
    """Aggregated outcome for a benchmark run."""

    status: str
    cases_total: int
    cases_passed: int | None = None
    cases_failed: int | None = None
    cases_errored: int | None = None
    cases_skipped: int | None = None
    duration_seconds: float | None = None
    metrics: Mapping[str, ScalarMetric] = field(default_factory=dict)
    notes: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": self.status,
            "cases_total": self.cases_total,
        }
        if self.cases_passed is not None:
            payload["cases_passed"] = self.cases_passed
        if self.cases_failed is not None:
            payload["cases_failed"] = self.cases_failed
        if self.cases_errored is not None:
            payload["cases_errored"] = self.cases_errored
        if self.cases_skipped is not None:
            payload["cases_skipped"] = self.cases_skipped
        if self.duration_seconds is not None:
            payload["duration_seconds"] = self.duration_seconds
        if self.metrics:
            payload["metrics"] = dict(self.metrics)
        if self.notes:
            payload["notes"] = self.notes
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> RunSummary:
        status = _require_status(payload.get("status"), "summary.status", RUN_STATUS_VALUES)
        cases_total = _require_int(payload.get("cases_total"), "summary.cases_total")
        cases_passed = _optional_int(payload.get("cases_passed"), "summary.cases_passed")
        cases_failed = _optional_int(payload.get("cases_failed"), "summary.cases_failed")
        cases_errored = _optional_int(payload.get("cases_errored"), "summary.cases_errored")
        cases_skipped = _optional_int(payload.get("cases_skipped"), "summary.cases_skipped")
        duration_seconds = _optional_float(
            payload.get("duration_seconds"),
            "summary.duration_seconds",
        )
        metrics = _normalize_metrics(payload.get("metrics"), "summary.metrics")
        notes = _optional_str(payload.get("notes"), "summary.notes")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "summary.metadata") or {}
        return cls(
            status=status,
            cases_total=cases_total,
            cases_passed=cases_passed,
            cases_failed=cases_failed,
            cases_errored=cases_errored,
            cases_skipped=cases_skipped,
            duration_seconds=duration_seconds,
            metrics=metrics,
            notes=notes,
            metadata=metadata,
        )


@dataclass(slots=True)
class VariantResult:
    """Outcome for a specific policy/baseline variant within a case."""

    name: str
    kind: str | None = None
    status: str | None = None
    metrics: Mapping[str, ScalarMetric] = field(default_factory=dict)
    artifacts: Mapping[str, str] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": self.name}
        if self.kind:
            payload["kind"] = self.kind
        if self.status:
            payload["status"] = self.status
        if self.metrics:
            payload["metrics"] = dict(self.metrics)
        if self.artifacts:
            payload["artifacts"] = dict(self.artifacts)
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.notes:
            payload["notes"] = self.notes
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> VariantResult:
        name = _require_str(payload.get("name"), "variant.name")
        kind = _optional_str(payload.get("kind"), "variant.kind")
        raw_status = payload.get("status")
        status: str | None = None
        if raw_status is not None:
            status = _require_status(raw_status, "variant.status", CASE_STATUS_VALUES)
        metrics = _normalize_metrics(payload.get("metrics"), "variant.metrics")
        artifacts = _optional_str_map(payload.get("artifacts"), "variant.artifacts")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "variant.metadata") or {}
        notes = _optional_str(payload.get("notes"), "variant.notes")
        return cls(
            name=name,
            kind=kind,
            status=status,
            metrics=metrics,
            artifacts=artifacts,
            metadata=metadata,
            notes=notes,
        )


@dataclass(slots=True)
class CaseResult:
    """Per-case benchmark result with optional variant breakdowns."""

    case_id: str
    status: str
    name: str | None = None
    description: str | None = None
    duration_seconds: float | None = None
    metrics: Mapping[str, ScalarMetric] = field(default_factory=dict)
    variants: tuple[VariantResult, ...] = ()
    artifacts: Mapping[str, str] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    tags: tuple[str, ...] = ()
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "case_id": self.case_id,
            "status": self.status,
        }
        if self.name:
            payload["name"] = self.name
        if self.description:
            payload["description"] = self.description
        if self.duration_seconds is not None:
            payload["duration_seconds"] = self.duration_seconds
        if self.metrics:
            payload["metrics"] = dict(self.metrics)
        if self.variants:
            payload["variants"] = [variant.to_dict() for variant in self.variants]
        if self.artifacts:
            payload["artifacts"] = dict(self.artifacts)
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.tags:
            payload["tags"] = list(self.tags)
        if self.notes:
            payload["notes"] = self.notes
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> CaseResult:
        case_id = _require_str(payload.get("case_id"), "case.case_id")
        status = _require_status(payload.get("status"), "case.status", CASE_STATUS_VALUES)
        name = _optional_str(payload.get("name"), "case.name")
        description = _optional_str(payload.get("description"), "case.description")
        duration_seconds = _optional_float(payload.get("duration_seconds"), "case.duration_seconds")
        metrics = _normalize_metrics(payload.get("metrics"), "case.metrics")
        variants_value = payload.get("variants")
        variants: tuple[VariantResult, ...] = ()
        if variants_value is not None:
            if isinstance(variants_value, str):
                raise ValueError("case.variants must be a sequence of objects")
            if not isinstance(variants_value, Sequence):
                raise ValueError("case.variants must be a sequence")
            variants = tuple(
                VariantResult.from_dict(_require_mapping(item, f"case.variants[{idx}]"))
                for idx, item in enumerate(variants_value)
            )
        artifacts = _optional_str_map(payload.get("artifacts"), "case.artifacts")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "case.metadata") or {}
        tags = _normalize_str_sequence(payload.get("tags"), "case.tags")
        notes = _optional_str(payload.get("notes"), "case.notes")
        return cls(
            case_id=case_id,
            status=status,
            name=name,
            description=description,
            duration_seconds=duration_seconds,
            metrics=metrics,
            variants=variants,
            artifacts=artifacts,
            metadata=metadata,
            tags=tags,
            notes=notes,
        )


@dataclass(slots=True)
class RunResults:
    """Structured results emitted by a benchmark run."""

    suite: SuiteDescriptor
    summary: RunSummary
    cases: tuple[CaseResult, ...] = ()
    schema_version: str = RESULTS_SCHEMA_VERSION
    run_id: str | None = None
    manifest_path: str | None = None
    command: str | None = None
    artifacts: Mapping[str, str] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    tags: tuple[str, ...] = ()
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "suite": self.suite.to_dict(),
            "summary": self.summary.to_dict(),
            "cases": [case.to_dict() for case in self.cases],
        }
        if self.run_id:
            payload["run_id"] = self.run_id
        if self.manifest_path:
            payload["manifest_path"] = self.manifest_path
        if self.command:
            payload["command"] = self.command
        if self.artifacts:
            payload["artifacts"] = dict(self.artifacts)
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.tags:
            payload["tags"] = list(self.tags)
        if self.notes:
            payload["notes"] = self.notes
        return payload

    def to_json(self, *, indent: int | None = None) -> str:
        data = self.to_dict()
        if indent is not None:
            return json.dumps(data, indent=indent, sort_keys=True)
        return canonical_record_json(data)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> RunResults:
        schema_version = _optional_str(payload.get("schema_version"), "schema_version") or (
            RESULTS_SCHEMA_VERSION
        )
        suite_block = _require_mapping(payload.get("suite"), "suite")
        summary_block = _require_mapping(payload.get("summary"), "summary")
        cases_value = payload.get("cases")
        if cases_value is None:
            raise ValueError("cases must be provided (use an empty array if no cases ran)")
        if isinstance(cases_value, str):
            raise ValueError("cases must be a sequence of objects")
        if not isinstance(cases_value, Sequence):
            raise ValueError("cases must be a sequence")
        cases = tuple(
            CaseResult.from_dict(_require_mapping(item, f"cases[{idx}]"))
            for idx, item in enumerate(cases_value)
        )
        run_id = _optional_str(payload.get("run_id"), "run_id")
        manifest_path = _optional_str(payload.get("manifest_path"), "manifest_path")
        command = _optional_str(payload.get("command"), "command")
        artifacts = _optional_str_map(payload.get("artifacts"), "artifacts")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "metadata") or {}
        tags = _normalize_str_sequence(payload.get("tags"), "tags")
        notes = _optional_str(payload.get("notes"), "notes")
        return cls(
            suite=SuiteDescriptor.from_dict(suite_block),
            summary=RunSummary.from_dict(summary_block),
            cases=cases,
            schema_version=schema_version,
            run_id=run_id,
            manifest_path=manifest_path,
            command=command,
            artifacts=artifacts,
            metadata=metadata,
            tags=tags,
            notes=notes,
        )

    @classmethod
    def from_json(cls, payload: str) -> RunResults:
        parsed = json.loads(payload)
        if not isinstance(parsed, Mapping):
            raise ValueError("results JSON must decode to an object")
        return cls.from_dict(parsed)


def _require_mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return value


def _require_str(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    return value


def _optional_str(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, field)


def _require_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    return cast(int, value)


def _optional_int(value: Any, field: str) -> int | None:
    if value is None:
        return None
    return _require_int(value, field)


def _optional_float(value: Any, field: str) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a number")
    return float(value)


def _normalize_metrics(value: Any, field: str) -> dict[str, ScalarMetric]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, ScalarMetric] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        if isinstance(raw_val, bool):
            result[key] = raw_val
        elif isinstance(raw_val, (int, float, str)):
            result[key] = raw_val
        else:
            raise ValueError(f"{field}.{key} must be a scalar metric (int/float/bool/str)")
    return result


def _optional_str_keyed_mapping(value: Any, field: str) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, Any] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = raw_val
    return result


def _optional_str_map(value: Any, field: str) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, str] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = _require_str(raw_val, f"{field}.{key}")
    return result


def _normalize_str_sequence(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raise ValueError(f"{field} must be a sequence of strings, not a single string")
    if not isinstance(value, Sequence):
        raise ValueError(f"{field} must be a sequence")
    return tuple(_require_str(item, f"{field}[{idx}]") for idx, item in enumerate(value))


def _require_status(value: Any, field: str, allowed: frozenset[str]) -> str:
    status = _require_str(value, field)
    if status not in allowed:
        allowed_list = ", ".join(sorted(allowed))
        raise ValueError(f"{field} must be one of: {allowed_list}")
    return status


__all__ = [
    "DEFAULT_RESULTS_FILENAME",
    "RESULTS_SCHEMA_VERSION",
    "RunResults",
    "RunSummary",
    "CaseResult",
    "VariantResult",
]
