"""Markdown report helpers for benchmark runs."""

from __future__ import annotations

from pathlib import Path

from .manifest import SuiteDescriptor
from .results import CaseResult, RunResults, RunSummary, VariantResult

METRIC_DEFINITIONS_MD = """**Metrics**
- Spend avoided (baseline – guarded)
- Time-to-detect (steps to first trigger)
- Containment (max spend/tokens reached)
- False positives (triggers in healthy runs)
- Overhead (runtime delta; extra tokens if applicable)
"""


def render_report_md(
    results: RunResults,
    *,
    include_metric_definitions: bool = True,
) -> str:
    """Render a human-readable Markdown report for a benchmark run."""

    lines: list[str] = []
    suite_label = _format_suite_label(results.suite)
    lines.append(f"# Benchmark Report — {suite_label}")
    lines.append("")
    lines.extend(_render_overview(results, suite_label))
    if results.summary.metrics:
        lines.append("## Summary Metrics")
        lines.append("")
        lines.append("| Metric | Value |")
        lines.append("| --- | --- |")
        for key, value in sorted(results.summary.metrics.items()):
            lines.append(f"| {key} | {value} |")
        lines.append("")
    if results.cases:
        lines.append("## Case Outcomes")
        lines.append("")
        for case in results.cases:
            lines.extend(_render_case_block(case))
            lines.append("")
    if include_metric_definitions:
        lines.append("## Metric Definitions")
        lines.append("")
        lines.append(METRIC_DEFINITIONS_MD.strip())
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def write_report_md(
    results: RunResults,
    path: str | Path,
    *,
    include_metric_definitions: bool = True,
) -> Path:
    """Write the Markdown report to disk (creating parent directories as needed)."""

    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        render_report_md(results, include_metric_definitions=include_metric_definitions),
        encoding="utf-8",
    )
    return output_path


def _render_overview(results: RunResults, suite_label: str) -> list[str]:
    summary = results.summary
    lines = ["## Run Overview", ""]
    lines.append(f"- **Suite:** {suite_label}")
    lines.append(f"- **Status:** {summary.status}")
    case_breakdown = _format_case_breakdown(summary)
    if case_breakdown:
        lines.append(f"- **Cases:** {case_breakdown}")
    if summary.duration_seconds is not None:
        lines.append(f"- **Duration:** {summary.duration_seconds:.2f}s")
    if results.run_id:
        lines.append(f"- **Run ID:** {results.run_id}")
    if results.command:
        lines.append(f"- **Command:** `{results.command}`")
    if results.manifest_path:
        lines.append(f"- **Manifest:** `{results.manifest_path}`")
    if results.artifacts:
        artifact_pairs: list[str] = []
        for key, value in sorted(results.artifacts.items()):
            artifact_pairs.append(f"{key} -> `{value}`")
        lines.append(f"- **Artifacts:** {', '.join(artifact_pairs)}")
    if results.tags:
        lines.append(f"- **Tags:** {', '.join(results.tags)}")
    if results.notes:
        lines.append(f"- **Notes:** {results.notes}")
    lines.append("")
    return lines


def _render_case_block(case: CaseResult) -> list[str]:
    title = f"### Case {case.case_id}"
    if case.name:
        title += f" — {case.name}"
    lines = [title, ""]
    lines.append(f"- **Status:** {case.status}")
    if case.description:
        lines.append(f"- **Description:** {case.description}")
    if case.duration_seconds is not None:
        lines.append(f"- **Duration:** {case.duration_seconds:.2f}s")
    if case.metrics:
        lines.append("- **Metrics:**")
        for key, value in sorted(case.metrics.items()):
            lines.append(f"  - {key}: {value}")
    if case.variants:
        lines.append("- **Variants:**")
        for variant in case.variants:
            lines.append(f"  - {variant.name}{_format_variant_suffix(variant)}")
    if case.tags:
        lines.append(f"- **Tags:** {', '.join(case.tags)}")
    if case.notes:
        lines.append(f"- **Notes:** {case.notes}")
    return lines


def _format_variant_suffix(variant: VariantResult) -> str:
    parts: list[str] = []
    if variant.kind:
        parts.append(variant.kind)
    if variant.status:
        parts.append(variant.status)
    if variant.metrics:
        metric_pairs = ", ".join(f"{key}={value}" for key, value in sorted(variant.metrics.items()))
        parts.append(metric_pairs)
    if not parts:
        return ""
    return f" ({'; '.join(parts)})"


def _format_suite_label(suite: SuiteDescriptor) -> str:
    parts = [suite.name, suite.version]
    if suite.variant:
        parts.append(f"({suite.variant})")
    return " ".join(part for part in parts if part)


def _format_case_breakdown(summary: RunSummary) -> str:
    components: list[str] = [str(summary.cases_total)]
    breakdown: list[tuple[int | None, str]] = [
        (summary.cases_passed, "passed"),
        (summary.cases_failed, "failed"),
        (summary.cases_errored, "errored"),
        (summary.cases_skipped, "skipped"),
    ]
    details = [f"{count} {label}" for count, label in breakdown if count]
    if details:
        components.append(f"({' / '.join(details)})")
    return " ".join(components)


__all__ = ["METRIC_DEFINITIONS_MD", "render_report_md", "write_report_md"]
