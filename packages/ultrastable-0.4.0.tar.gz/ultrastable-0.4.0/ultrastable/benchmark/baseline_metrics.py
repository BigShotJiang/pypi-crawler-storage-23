"""Helpers to compute AFMB baseline metrics and emit `results.json` artifacts."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from ultrastable.ledger import iter_events

from .config import BaselineRunnerSpec
from .manifest import SuiteDescriptor
from .results import (
    CaseResult,
    RunResults,
    RunSummary,
    ScalarMetric,
    VariantResult,
)

_CASE_STATUS_VALUES = {"passed", "failed", "error", "skipped"}


def emit_baseline_results(
    *,
    suite: SuiteDescriptor,
    baseline: BaselineRunnerSpec,
    ledger_path: str | Path,
    run_id: str | None = None,
    manifest_path: str | None = None,
    command: str | None = None,
    case_tag: str = "case_id",
    tags: Sequence[str] | None = None,
    artifacts: Mapping[str, str] | None = None,
    metadata: Mapping[str, Any] | None = None,
    notes: str | None = None,
    output_path: str | Path | None = None,
    indent: int | None = 2,
) -> RunResults:
    """Summarize a baseline ledger and optionally persist `results.json`.

    The helper scans the ledger for case-tagged events, aggregates comparable
    metrics (steps, tool calls, tokens, cost, duration, violations, etc.), and
    emits `CaseResult` entries with a `VariantResult` for the supplied baseline.
    """

    ledger_path = Path(ledger_path)
    if not ledger_path.exists():
        raise FileNotFoundError(f"Ledger not found: {ledger_path}")
    case_accumulators, run_start, run_end = _collect_case_metrics(ledger_path, case_tag=case_tag)
    case_results = _build_case_results(suite, baseline, case_accumulators)
    summary = _build_summary(case_results, run_start, run_end)
    result = RunResults(
        suite=suite,
        summary=summary,
        cases=tuple(case_results),
        run_id=run_id,
        manifest_path=manifest_path,
        command=command,
        artifacts=dict(artifacts or {}),
        metadata=dict(metadata or {}),
        tags=tuple(tags or baseline.tags),
        notes=notes,
    )
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(result.to_json(indent=indent), encoding="utf-8")
    return result


def _build_case_results(
    suite: SuiteDescriptor,
    baseline: BaselineRunnerSpec,
    accumulators: dict[str, _CaseAccumulator],
) -> list[CaseResult]:
    ordered_cases: list[str] = list(suite.cases) if suite.cases else []
    remaining = [case_id for case_id in accumulators.keys() if case_id not in ordered_cases]
    ordered_cases.extend(sorted(remaining))
    if not ordered_cases:
        ordered_cases = sorted(accumulators.keys())
    results: list[CaseResult] = []
    for case_id in ordered_cases:
        accumulator = accumulators.get(case_id)
        if accumulator is None:
            results.append(
                CaseResult(
                    case_id=case_id,
                    status="skipped",
                    tags=baseline.tags,
                    notes=f"No ledger events tagged with case '{case_id}'",
                )
            )
            continue
        results.append(accumulator.to_case_result(baseline))
    return results


def _build_summary(
    case_results: Sequence[CaseResult],
    run_start: datetime | None,
    run_end: datetime | None,
) -> RunSummary:
    cases_total = len(case_results)
    cases_passed = sum(1 for case in case_results if case.status == "passed")
    cases_failed = sum(1 for case in case_results if case.status == "failed")
    cases_errored = sum(1 for case in case_results if case.status == "error")
    cases_skipped = sum(1 for case in case_results if case.status == "skipped")
    if cases_errored:
        status = "error"
    elif cases_failed:
        status = "failed"
    elif cases_passed and cases_passed < cases_total:
        status = "partial"
    else:
        status = "completed"
    duration_seconds: float | None = None
    if run_start and run_end and run_end >= run_start:
        duration_seconds = (run_end - run_start).total_seconds()
    summary_metrics = _aggregate_summary_metrics(case_results)
    return RunSummary(
        status=status,
        cases_total=cases_total,
        cases_passed=cases_passed or None,
        cases_failed=cases_failed or None,
        cases_errored=cases_errored or None,
        cases_skipped=cases_skipped or None,
        duration_seconds=duration_seconds,
        metrics=summary_metrics,
    )


def _aggregate_summary_metrics(case_results: Sequence[CaseResult]) -> dict[str, ScalarMetric]:
    total_steps = 0
    total_tokens = 0
    total_cost = 0.0
    total_tool_calls = 0
    total_violations = 0
    for case in case_results:
        metrics = case.metrics
        total_steps += int(metrics.get("steps", 0) or 0)
        total_tokens += int(metrics.get("tokens_total", 0) or 0)
        total_tool_calls += int(metrics.get("tool_calls", 0) or 0)
        total_cost += float(metrics.get("cost_usd", 0.0) or 0.0)
        total_violations += int(metrics.get("violations", 0) or 0)
    result: dict[str, ScalarMetric] = {}
    if total_steps:
        result["total_steps"] = total_steps
    if total_tokens:
        result["total_tokens"] = total_tokens
    if total_tool_calls:
        result["total_tool_calls"] = total_tool_calls
    if total_cost:
        result["total_cost_usd"] = round(total_cost, 8)
    if total_violations:
        result["total_violations"] = total_violations
    return result


def _collect_case_metrics(
    ledger_path: Path,
    *,
    case_tag: str,
) -> tuple[dict[str, _CaseAccumulator], datetime | None, datetime | None]:
    accumulators: dict[str, _CaseAccumulator] = {}
    run_start: datetime | None = None
    run_end: datetime | None = None
    for event in iter_events(str(ledger_path)):
        case_id = _extract_case_id(event, case_tag=case_tag)
        if case_id is None:
            continue
        accumulator = accumulators.setdefault(case_id, _CaseAccumulator(case_id=case_id))
        event_timestamp = _parse_timestamp(event.get("timestamp"))
        if event_timestamp:
            if run_start is None or event_timestamp < run_start:
                run_start = event_timestamp
            if run_end is None or event_timestamp > run_end:
                run_end = event_timestamp
        accumulator.ingest(event)
    return accumulators, run_start, run_end


def _extract_case_id(event: Mapping[str, Any], *, case_tag: str) -> str | None:
    tags = event.get("tags")
    if isinstance(tags, Mapping):
        for key in (case_tag, "case_id", "case", "scenario", "scenario_id"):
            value = tags.get(key)
            if value is not None:
                return str(value)
    meta = event.get("meta")
    if isinstance(meta, Mapping):
        for key in (case_tag, "case_id", "case", "scenario"):
            value = meta.get(key)
            if value is not None:
                return str(value)
    return None


def _parse_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    normalized = value
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _as_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return int(value)


def _as_float(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


@dataclass(slots=True)
class _CaseAccumulator:
    case_id: str
    steps: int = 0
    tool_calls: int = 0
    tokens_total: int = 0
    cost_usd: float = 0.0
    violations: int = 0
    interventions: int = 0
    errors: int = 0
    status_override: str | None = None
    _start_ts: datetime | None = None
    _end_ts: datetime | None = None

    def ingest(self, event: Mapping[str, Any]) -> None:
        event_type = str(event.get("event_type") or "").lower()
        if event_type == "step":
            self._record_step(event)
            return
        if event_type == "trigger":
            self.violations += 1
            return
        if event_type == "intervention":
            self.interventions += 1
            return
        if event_type == "error":
            self.errors += 1
            return
        if event_type == "run":
            self._maybe_update_status_from_run(event)

    def to_case_result(self, baseline: BaselineRunnerSpec) -> CaseResult:
        metrics = self._build_metrics()
        variant = VariantResult(
            name=baseline.name,
            kind="baseline",
            status=self._final_status(),
            metrics=dict(metrics),
            metadata=_merge_variant_metadata(baseline),
            notes=baseline.notes,
        )
        return CaseResult(
            case_id=self.case_id,
            status=self._final_status(),
            duration_seconds=self._duration_seconds(),
            metrics=metrics,
            variants=(variant,),
            tags=baseline.tags,
        )

    def _record_step(self, event: Mapping[str, Any]) -> None:
        self.steps += 1
        tokens_total = _as_int(event.get("tokens_total"))
        if tokens_total is None:
            prompt = _as_int(event.get("tokens_prompt")) or 0
            completion = _as_int(event.get("tokens_completion")) or 0
            tokens_total = prompt + completion
        self.tokens_total += tokens_total or 0
        cost_val = _as_float(event.get("cost_usd"))
        if cost_val is not None:
            self.cost_usd += cost_val
        role = str(event.get("role") or "").lower()
        kind = str(event.get("kind") or "").lower()
        if role == "tool" or kind == "tool":
            self.tool_calls += 1
        timestamp = _parse_timestamp(event.get("timestamp"))
        if timestamp:
            if self._start_ts is None or timestamp < self._start_ts:
                self._start_ts = timestamp
            if self._end_ts is None or timestamp > self._end_ts:
                self._end_ts = timestamp

    def _maybe_update_status_from_run(self, event: Mapping[str, Any]) -> None:
        meta = event.get("meta")
        if not isinstance(meta, Mapping):
            return
        status = meta.get("status")
        if isinstance(status, str):
            normalized = status.lower()
            if normalized in _CASE_STATUS_VALUES:
                self.status_override = normalized

    def _final_status(self) -> str:
        if self.status_override and self.status_override in _CASE_STATUS_VALUES:
            return self.status_override
        if self.errors:
            return "error"
        if self.violations:
            return "failed"
        if self.steps == 0:
            return "skipped"
        return "passed"

    def _duration_seconds(self) -> float | None:
        if self._start_ts and self._end_ts and self._end_ts >= self._start_ts:
            return (self._end_ts - self._start_ts).total_seconds()
        return None

    def _build_metrics(self) -> dict[str, ScalarMetric]:
        metrics: dict[str, ScalarMetric] = {
            "steps": self.steps,
            "tool_calls": self.tool_calls,
            "tokens_total": self.tokens_total,
            "cost_usd": round(self.cost_usd, 8),
        }
        if self.violations:
            metrics["violations"] = self.violations
        if self.interventions:
            metrics["interventions"] = self.interventions
        if self.errors:
            metrics["errors"] = self.errors
        return metrics


def _merge_variant_metadata(baseline: BaselineRunnerSpec) -> dict[str, Any]:
    metadata: dict[str, Any] = {"baseline_kind": baseline.kind}
    if baseline.metadata:
        metadata.update(baseline.metadata)
    limits_payload = baseline.limits.to_dict()
    if limits_payload:
        metadata["limits"] = limits_payload
    return metadata


__all__ = ["emit_baseline_results"]
