"""Run manifest schema definitions and helpers."""

from __future__ import annotations

import json
import platform
import socket
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, cast

from ultrastable import __version__ as ULTRASTABLE_VERSION
from ultrastable.ledger.canonical import canonical_record_json

MANIFEST_SCHEMA_VERSION = "run_manifest/v1"
DEFAULT_MANIFEST_FILENAME = "manifest.json"


@dataclass(slots=True)
class SuiteDescriptor:
    """Identifies the benchmark suite executed in a run."""

    name: str
    version: str
    variant: str | None = None
    description: str | None = None
    cases: tuple[str, ...] = ()
    parameters: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": self.name, "version": self.version}
        if self.variant:
            payload["variant"] = self.variant
        if self.description:
            payload["description"] = self.description
        if self.cases:
            payload["cases"] = list(self.cases)
        if self.parameters:
            payload["parameters"] = dict(self.parameters)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> SuiteDescriptor:
        name = _require_str(payload.get("name"), "suite.name")
        version = _require_str(payload.get("version"), "suite.version")
        variant = _optional_str(payload.get("variant"), "suite.variant")
        description = _optional_str(payload.get("description"), "suite.description")
        cases = _normalize_str_sequence(payload.get("cases"), "suite.cases")
        parameters = _optional_str_keyed_mapping(payload.get("parameters"), "suite.parameters")
        return cls(
            name=name,
            version=version,
            variant=variant,
            description=description,
            cases=cases,
            parameters=parameters,
        )


@dataclass(slots=True)
class SeedBlock:
    """Canonicalizes the seeds that make a benchmark run deterministic."""

    global_seed: int
    suite: Mapping[str, int] = field(default_factory=dict)
    cases: Mapping[str, int] = field(default_factory=dict)
    policies: Mapping[str, int] = field(default_factory=dict)
    extra: Mapping[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"global": self.global_seed}
        if self.suite:
            payload["suite"] = dict(self.suite)
        if self.cases:
            payload["cases"] = dict(self.cases)
        if self.policies:
            payload["policies"] = dict(self.policies)
        if self.extra:
            payload["extra"] = dict(self.extra)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> SeedBlock:
        global_seed = _require_int(payload.get("global"), "seeds.global")
        suite = _optional_int_mapping(payload.get("suite"), "seeds.suite")
        cases = _optional_int_mapping(payload.get("cases"), "seeds.cases")
        policies = _optional_int_mapping(payload.get("policies"), "seeds.policies")
        extra = _optional_int_mapping(payload.get("extra"), "seeds.extra")
        return cls(
            global_seed=global_seed,
            suite=suite,
            cases=cases,
            policies=policies,
            extra=extra,
        )


@dataclass(slots=True)
class PolicyDescriptor:
    """Describes policy artifacts referenced by a benchmark run."""

    name: str
    version: str | None = None
    role: str | None = None
    path: str | None = None
    policy_hash: str | None = None
    description: str | None = None
    metadata: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": self.name}
        if self.version:
            payload["version"] = self.version
        if self.role:
            payload["role"] = self.role
        if self.path:
            payload["path"] = self.path
        if self.policy_hash:
            payload["policy_hash"] = self.policy_hash
        if self.description:
            payload["description"] = self.description
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> PolicyDescriptor:
        name = _require_str(payload.get("name"), "policy.name")
        version = _optional_str(payload.get("version"), "policy.version")
        role = _optional_str(payload.get("role"), "policy.role")
        path = _optional_str(payload.get("path"), "policy.path")
        policy_hash = _optional_str(payload.get("policy_hash"), "policy.policy_hash")
        description = _optional_str(payload.get("description"), "policy.description")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "policy.metadata")
        return cls(
            name=name,
            version=version,
            role=role,
            path=path,
            policy_hash=policy_hash,
            description=description,
            metadata=metadata,
        )


@dataclass(slots=True)
class EnvironmentSnapshot:
    """Capture runtime information for reproducibility."""

    platform: Mapping[str, str]
    python: Mapping[str, str]
    ultrastable_version: str
    hostname: str | None = None
    git: Mapping[str, Any] | None = None
    extra: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "platform": dict(self.platform),
            "python": dict(self.python),
            "ultrastable_version": self.ultrastable_version,
        }
        if self.hostname:
            payload["hostname"] = self.hostname
        if self.git:
            payload["git"] = dict(self.git)
        if self.extra:
            payload["extra"] = dict(self.extra)
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> EnvironmentSnapshot:
        platform_block = _require_str_dict(payload.get("platform"), "env.platform")
        python_block = _require_str_dict(payload.get("python"), "env.python")
        ultrastable_version = _require_str(
            payload.get("ultrastable_version"),
            "env.ultrastable_version",
        )
        hostname = _optional_str(payload.get("hostname"), "env.hostname")
        git_block = _optional_mapping(payload.get("git"), "env.git")
        extra_block = _optional_mapping(payload.get("extra"), "env.extra")
        return cls(
            platform=platform_block,
            python=python_block,
            ultrastable_version=ultrastable_version,
            hostname=hostname,
            git=git_block,
            extra=extra_block or {},
        )


@dataclass(slots=True)
class RunManifest:
    """Structured manifest describing a benchmark invocation."""

    suite: SuiteDescriptor
    seeds: SeedBlock
    policies: tuple[PolicyDescriptor, ...]
    env: EnvironmentSnapshot
    schema_version: str = MANIFEST_SCHEMA_VERSION
    run_id: str | None = None
    created_at: str | None = None
    command: str | None = None
    output_dir: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    tags: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "suite": self.suite.to_dict(),
            "seeds": self.seeds.to_dict(),
            "policies": [policy.to_dict() for policy in self.policies],
            "env": self.env.to_dict(),
        }
        if self.run_id:
            payload["run_id"] = self.run_id
        if self.created_at:
            payload["created_at"] = self.created_at
        if self.command:
            payload["command"] = self.command
        if self.output_dir:
            payload["output_dir"] = self.output_dir
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.tags:
            payload["tags"] = list(self.tags)
        return payload

    def to_json(self, *, indent: int | None = None) -> str:
        data = self.to_dict()
        if indent is not None:
            return json.dumps(data, indent=indent, sort_keys=True)
        return canonical_record_json(data)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> RunManifest:
        schema_version = _optional_str(payload.get("schema_version"), "schema_version") or (
            MANIFEST_SCHEMA_VERSION
        )
        suite_block = _require_mapping(payload.get("suite"), "suite")
        seeds_block = _require_mapping(payload.get("seeds"), "seeds")
        env_block = _require_mapping(payload.get("env"), "env")
        policies_value = payload.get("policies")
        policies: tuple[PolicyDescriptor, ...] = ()
        if policies_value is not None:
            if isinstance(policies_value, str):
                raise ValueError("policies must be a sequence of objects")
            if not isinstance(policies_value, Sequence):
                raise ValueError("policies must be a sequence")
            policies = tuple(
                PolicyDescriptor.from_dict(_require_mapping(item, f"policies[{idx}]"))
                for idx, item in enumerate(policies_value)
            )
        run_id = _optional_str(payload.get("run_id"), "run_id")
        created_at = _optional_str(payload.get("created_at"), "created_at")
        command = _optional_str(payload.get("command"), "command")
        output_dir = _optional_str(payload.get("output_dir"), "output_dir")
        metadata = _optional_str_keyed_mapping(payload.get("metadata"), "metadata") or {}
        tags = _normalize_str_sequence(payload.get("tags"), "tags")
        return cls(
            schema_version=schema_version,
            suite=SuiteDescriptor.from_dict(suite_block),
            seeds=SeedBlock.from_dict(seeds_block),
            policies=policies,
            env=EnvironmentSnapshot.from_dict(env_block),
            run_id=run_id,
            created_at=created_at,
            command=command,
            output_dir=output_dir,
            metadata=metadata,
            tags=tags,
        )

    @classmethod
    def from_json(cls, payload: str) -> RunManifest:
        parsed = json.loads(payload)
        if not isinstance(parsed, Mapping):
            raise ValueError("manifest JSON must decode to an object")
        return cls.from_dict(parsed)


def capture_environment_snapshot(
    *, include_git: bool = True, cwd: str | None = None, extra: Mapping[str, Any] | None = None
) -> EnvironmentSnapshot:
    """Capture the current environment details for a manifest."""

    uname = platform.uname()
    platform_block = {
        "system": uname.system,
        "release": uname.release,
        "version": uname.version,
        "machine": uname.machine,
        "processor": uname.processor,
    }
    python_block = {
        "implementation": platform.python_implementation(),
        "version": platform.python_version(),
    }
    hostname = socket.gethostname() or None
    git_block = _detect_git_metadata(cwd=cwd) if include_git else None
    extra_payload: dict[str, Any] = {"python_executable": sys.executable}
    if extra:
        # Extra metadata overrides the defaults if keys collide.
        extra_payload.update(extra)
    return EnvironmentSnapshot(
        platform=platform_block,
        python=python_block,
        ultrastable_version=ULTRASTABLE_VERSION,
        hostname=hostname,
        git=git_block,
        extra=extra_payload,
    )


def iso8601_utc_now() -> str:
    """Return an ISO 8601 UTC timestamp with millisecond precision."""

    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _detect_git_metadata(*, cwd: str | None) -> Mapping[str, Any] | None:
    try:
        commit = _run_git(("rev-parse", "HEAD"), cwd=cwd)
    except (OSError, subprocess.CalledProcessError):
        return None
    branch: str | None
    try:
        branch = _run_git(("rev-parse", "--abbrev-ref", "HEAD"), cwd=cwd)
    except (OSError, subprocess.CalledProcessError):
        branch = None
    try:
        status = _run_git(("status", "--short"), cwd=cwd, check=False)
    except (OSError, subprocess.CalledProcessError):
        status = ""
    metadata: dict[str, Any] = {"commit": commit, "dirty": bool(status.strip())}
    if branch and branch != "HEAD":
        metadata["branch"] = branch
    return metadata


def _run_git(args: Sequence[str], *, cwd: str | None, check: bool = True) -> str:
    result = subprocess.run(
        ["git", *args],
        check=check,
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    return result.stdout.strip()


def _require_mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return value


def _require_str(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    return value


def _optional_str(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, field)


def _normalize_str_sequence(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raise ValueError(f"{field} must be a sequence of strings, not a single string")
    if not isinstance(value, Sequence):
        raise ValueError(f"{field} must be a sequence")
    return tuple(_require_str(item, f"{field}[{idx}]") for idx, item in enumerate(value))


def _optional_mapping(value: Any, field: str) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return dict(value)


def _require_str_dict(value: Any, field: str) -> dict[str, str]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, str] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = _require_str(raw_val, f"{field}.{key}")
    return result


def _optional_str_keyed_mapping(value: Any, field: str) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, Any] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = raw_val
    return result


def _require_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    return cast(int, value)


def _optional_int_mapping(value: Any, field: str) -> dict[str, int]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    result: dict[str, int] = {}
    for key, raw_val in value.items():
        if not isinstance(key, str):
            raise ValueError(f"{field} keys must be strings")
        result[key] = _require_int(raw_val, f"{field}.{key}")
    return result
