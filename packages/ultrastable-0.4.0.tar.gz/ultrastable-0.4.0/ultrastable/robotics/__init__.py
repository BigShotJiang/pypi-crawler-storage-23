"""Optional robotics/control wrappers and demos (extras)."""

from .battery import BatteryLightSeekerEnv, OrganismicDriveWrapper, build_battery_light_controller
from .drive import DriveReward, DriveWrapper
from .homeostat import (
    LightSeekerEnv,
    MobileHomeostat2D,
    build_guard_and_env,
    build_homeostat_controller,
    render_mobile_homeostat_svg,
)
from .plasticity import (
    HomeostasisPlasticityWrapper,
    PlasticityRegistry,
    PlasticitySpec,
    create_default_plasticity_registry,
    default_plasticity_registry,
    evaluate_plasticity,
)
from .shield import LyapunovShield
from .torch_resets import EnsembleReset, LayerReset, NeuronReset

__all__ = [
    "BatteryLightSeekerEnv",
    "DriveReward",
    "DriveWrapper",
    "OrganismicDriveWrapper",
    "LightSeekerEnv",
    "MobileHomeostat2D",
    "render_mobile_homeostat_svg",
    "build_guard_and_env",
    "build_homeostat_controller",
    "build_battery_light_controller",
    "HomeostasisPlasticityWrapper",
    "PlasticityRegistry",
    "PlasticitySpec",
    "create_default_plasticity_registry",
    "default_plasticity_registry",
    "evaluate_plasticity",
    "LyapunovShield",
    "NeuronReset",
    "LayerReset",
    "EnsembleReset",
]
