from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from itertools import zip_longest

Vector = Sequence[float]


def _default_lyapunov(state: Vector) -> float:
    return sum(float(v) ** 2 for v in state)


def _to_vector(values: Iterable[float]) -> list[float]:
    return [float(v) for v in values]


@dataclass
class LyapunovShield:
    """Minimal Lyapunov-based shield for torque/acceleration commands.

    The shield uses a simple quadratic Lyapunov candidate (customizable) with a
    discrete-time integrator model: ``x_next = x + dt * (u - damping * x)``.
    If the predicted Lyapunov value exceeds ``threshold``, the command is
    scaled down uniformly until the state respects the limit.
    """

    threshold: float = 1.0
    damping: float = 0.1
    dt: float = 1.0
    lyapunov_fn: Callable[[Vector], float] = field(default=_default_lyapunov)

    def __post_init__(self) -> None:
        if self.threshold <= 0:
            raise ValueError("threshold must be > 0")
        if self.dt <= 0:
            raise ValueError("dt must be > 0")
        if self.damping < 0:
            raise ValueError("damping must be >= 0")

    def project(self, action: Vector, state: Vector) -> list[float]:
        """Project an action into the safe set defined by the Lyapunov bound."""

        predicted = self._predict_state(action, state)
        v_next = self.lyapunov_fn(predicted)
        if v_next <= self.threshold:
            return _to_vector(action)

        if self.lyapunov_fn(state) > self.threshold:
            # Already unsafe; zero the action to avoid further growth.
            return [0.0 for _ in action]

        lo, hi = 0.0, 1.0
        best = [0.0 for _ in action]
        for _ in range(24):
            mid = (lo + hi) / 2.0
            scaled = [float(a) * mid for a in action]
            if self.lyapunov_fn(self._predict_state(scaled, state)) <= self.threshold:
                best = scaled
                lo = mid
            else:
                hi = mid
        return _to_vector(best)

    def is_safe(self, action: Vector, state: Vector) -> bool:
        return self.lyapunov_fn(self._predict_state(action, state)) <= self.threshold

    def _predict_state(self, action: Vector, state: Vector) -> list[float]:
        predicted: list[float] = []
        for a, x in zip_longest(action, state, fillvalue=0.0):
            decay = self.damping * float(x)
            predicted.append(float(x) + self.dt * (float(a) - decay))
        return predicted


__all__ = ["LyapunovShield"]
