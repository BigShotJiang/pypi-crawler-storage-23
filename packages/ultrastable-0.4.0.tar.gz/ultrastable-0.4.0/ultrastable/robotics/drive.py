from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ultrastable.core import Controller, ViabilityPolicy
from ultrastable.core.events import StepEvent


class DriveReward:
    """Homeostatic reward helper operating on a ViabilityPolicy."""

    def __init__(
        self,
        policy: ViabilityPolicy,
        *,
        variable_bindings: Mapping[str, str] | None = None,
        mode: str = "delta",
        hybrid_weight: float = 0.5,
    ) -> None:
        if mode not in {"delta", "negative", "hybrid"}:
            raise ValueError("mode must be 'delta', 'negative', or 'hybrid'")
        if hybrid_weight < 0:
            raise ValueError("hybrid_weight must be >= 0")
        self.policy = policy
        self.variable_bindings = dict(variable_bindings or {})
        self.mode = mode
        self.hybrid_weight = float(hybrid_weight)
        self._last_dh: float | None = None

    def reset(self, metrics: Mapping[str, float] | None = None) -> float:
        if metrics:
            self._apply_metrics(metrics)
        current = self._current_dh()
        self._last_dh = current
        return current

    def compute(self, metrics: Mapping[str, float] | None = None) -> dict[str, float]:
        if metrics:
            self._apply_metrics(metrics)
        current = self._current_dh()
        previous = self._last_dh if self._last_dh is not None else current
        if self.mode == "delta":
            value = previous - current
        elif self.mode == "negative":
            value = -current
        else:
            value = (previous - current) + (-current * self.hybrid_weight)
        self._last_dh = current
        return {"reward": float(value), "d_h": current}

    def _apply_metrics(self, metrics: Mapping[str, float]) -> None:
        space = self.policy.space
        for key, raw in metrics.items():
            target = self.variable_bindings.get(key, key)
            if target in space.variables:
                space.set(target, float(raw))

    def _current_dh(self) -> float:
        _, d_h = self.policy.health.compute(self.policy.space)
        return float(d_h)


class DriveWrapper:
    """Adapter that monitors an environment and applies drive rewards/penalties."""

    def __init__(
        self,
        env: Any,
        controller: Controller,
        *,
        ledger: Any | None = None,
        drive_reward: DriveReward | None = None,
        reward_mode: str = "mixed",
        drive_weight: float = 1.0,
    ) -> None:
        if reward_mode not in {"task_only", "drive_only", "mixed"}:
            raise ValueError("reward_mode must be task_only, drive_only, or mixed")
        if drive_weight < 0:
            raise ValueError("drive_weight must be >= 0")
        self.env = env
        self.controller = controller
        self.ledger = ledger
        self.drive_reward = drive_reward or DriveReward(controller.policy)
        self.reward_mode = reward_mode
        self.drive_weight = float(drive_weight)
        self._step_index = 0

    def reset(self, *args: Any, metrics: Mapping[str, float] | None = None, **kwargs: Any) -> Any:
        observation = self.env.reset(*args, **kwargs)
        if metrics:
            self.drive_reward.reset(metrics)
        else:
            self.drive_reward.reset()
        return observation

    def step(
        self,
        action: Any,
        *,
        metrics: Mapping[str, float],
        tags: Mapping[str, Any] | None = None,
    ) -> tuple[Any, float, bool, bool, dict[str, Any]]:
        result = self.env.step(action)
        if len(result) == 4:
            observation, reward, terminated, info = result
            truncated = False
        else:
            observation, reward, terminated, truncated, info = result

        drive_data = self.drive_reward.compute(metrics)
        snapshot = self.controller.policy.space.snapshot(self.controller.policy.health)
        step_event = StepEvent(
            step_id=f"drive-{self._step_index}",
            role="agent",
            kind="robotic",
            d_h=snapshot.d_h,
            tags={"action": str(action), **(tags or {})},
        )
        self._emit(step_event)
        self._emit(snapshot)

        decision = self.controller.update(step_event, snapshot=snapshot, state={})
        for trigger in decision.triggers:
            self._emit(trigger)
        if decision.intervention and decision.intervention.event:
            self._emit(decision.intervention.event)

        adjusted_reward = self._combine_rewards(float(reward), drive_data["reward"])
        info_dict = dict(info or {})
        info_dict["drive_reward"] = drive_data["reward"]
        info_dict["d_h"] = drive_data["d_h"]
        info_dict["policy_status"] = decision.policy_status

        self._step_index += 1
        return observation, adjusted_reward, terminated, truncated, info_dict

    def _combine_rewards(self, task_reward: float, drive_adjustment: float) -> float:
        if self.reward_mode == "task_only":
            return task_reward
        drive_component = self.drive_weight * drive_adjustment
        if self.reward_mode == "drive_only":
            return drive_component
        return task_reward + drive_component

    def _emit(self, event: Any) -> None:
        if not self.ledger or event is None:
            return
        self.ledger.add(event)


__all__ = ["DriveReward", "DriveWrapper"]
