from __future__ import annotations

import math
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, cast

from ultrastable.core.events import PlasticityFacilitationEvent
from ultrastable.core.health import ViabilityPolicy

try:  # pragma: no cover - optional dependency
    import torch
    from torch import nn
except Exception:  # pragma: no cover - torch missing
    torch = cast(Any, None)
    nn = cast(Any, None)

BaseModule: type[Any]
if TYPE_CHECKING:  # pragma: no cover - typing only
    from torch import Tensor
    from torch import nn as torch_nn

    BaseModule = torch_nn.Module
elif nn is not None:
    BaseModule = nn.Module
else:
    BaseModule = object


class PlasticityCurve(Protocol):
    def __call__(
        self,
        z: float,
        *,
        params: Mapping[str, Any] | None = None,
        **context: Any,
    ) -> float: ...


@dataclass
class PlasticitySpec:
    func: str
    params: Mapping[str, Any] | None = None


class PlasticityRegistry:
    """Registry for mapping analytic plasticity curves by string identifier."""

    def __init__(self) -> None:
        self._funcs: MutableMapping[str, PlasticityCurve] = {}

    def register(self, name: str, func: PlasticityCurve, *, replace: bool = False) -> None:
        key = name.strip()
        if not key:
            raise ValueError("Plasticity function name must be non-empty")
        if not replace and key in self._funcs:
            raise ValueError(f"Plasticity function '{key}' already registered")
        self._funcs[key] = func

    def unregister(self, name: str) -> None:
        self._funcs.pop(name, None)

    def get(self, name: str) -> PlasticityCurve:
        try:
            return self._funcs[name]
        except KeyError as exc:  # pragma: no cover - helpful message
            raise KeyError(f"Plasticity function '{name}' is not registered") from exc

    def evaluate(
        self,
        spec: PlasticitySpec | Mapping[str, Any] | str,
        z: float,
        **context: Any,
    ) -> float:
        if isinstance(spec, str):
            name = spec
            params = None
        else:
            func_name = spec.func if isinstance(spec, PlasticitySpec) else spec.get("func")
            if not func_name:
                raise ValueError("Plasticity spec must include 'func'")
            name = func_name
            params = spec.params if isinstance(spec, PlasticitySpec) else spec.get("params")
        func = self.get(name)
        return float(func(z, params=params, **context))

    def names(self) -> list[str]:
        return sorted(self._funcs)

    def copy(self) -> PlasticityRegistry:
        other = PlasticityRegistry()
        other._funcs.update(self._funcs)
        return other


def _spec_from_input(spec: PlasticitySpec | Mapping[str, Any] | str) -> PlasticitySpec:
    if isinstance(spec, PlasticitySpec):
        return PlasticitySpec(func=spec.func, params=dict(spec.params or {}))
    if isinstance(spec, str):
        return PlasticitySpec(func=spec, params=None)
    func_name = spec.get("func")
    if not func_name:
        raise ValueError("Plasticity spec requires 'func'")
    params = spec.get("params") or {}
    return PlasticitySpec(func=str(func_name), params=dict(params))


def _param(params: Mapping[str, Any] | None, key: str, default: float) -> float:
    if params is None:
        return float(default)
    return float(params.get(key, default))


def _clamp01(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


def _dipaolo_quadratic(
    z: float,
    *,
    params: Mapping[str, Any] | None = None,
    **_: Any,
) -> float:
    sensitivity = _param(params, "sensitivity", 1.0)
    bounded = _clamp01(float(z))
    return sensitivity * (2.0 * bounded - 1.0) ** 2


def _hebbian(
    z: float,
    *,
    params: Mapping[str, Any] | None = None,
    **context: Any,
) -> float:
    eta = _param(params, "eta", 1.0)
    pre = context.get("pre_activation")
    if pre is None:
        pre_val = float(z)
    else:
        try:
            pre_val = float(pre)
        except (TypeError, ValueError):
            pre_val = float(z)
    bounded_post = _clamp01(float(z))
    bounded_pre = _clamp01(pre_val)
    return eta * bounded_pre * bounded_post


def create_default_plasticity_registry() -> PlasticityRegistry:
    registry = PlasticityRegistry()
    registry.register("dipaolo_quadratic", _dipaolo_quadratic)
    registry.register("hebbian", _hebbian)
    return registry


default_plasticity_registry = create_default_plasticity_registry()


def evaluate_plasticity(
    spec: PlasticitySpec | Mapping[str, Any] | str,
    z: float,
    **context: Any,
) -> float:
    resolved = _spec_from_input(spec)
    return default_plasticity_registry.evaluate(resolved, z, **context)


class HomeostasisPlasticityWrapper(BaseModule):
    """PyTorch module wrapper that perturbs weights when health deteriorates.

    The wrapper keeps lightweight activation summaries per tracked layer
    (normalized to z \\in [0, 1]) and consults the PlasticityRegistry to convert
    those activations into a facilitation magnitude. When the system is inside
    the comfort zone (distance-to-boundary >= ``comfort_threshold``) weights
    remain untouched. Otherwise, Gaussian noise scaled by the registry-curved
    magnitude is added to layer parameters under ``torch.no_grad``.
    """

    def __init__(
        self,
        module: Any,
        policy: ViabilityPolicy,
        *,
        curve: PlasticitySpec | Mapping[str, Any] | str = "dipaolo_quadratic",
        registry: PlasticityRegistry | None = None,
        comfort_threshold: float = 0.25,
        scale: float = 0.01,
        max_delta: float = 0.05,
        smoothing: float = 0.9,
        layer_names: Sequence[str] | None = None,
        ledger: Any | None = None,
    ) -> None:
        if nn is None or torch is None:  # pragma: no cover - requires extras
            raise RuntimeError("HomeostasisPlasticityWrapper requires torch>=2.0 (robotics extra)")
        if not isinstance(module, nn.Module):
            raise TypeError("module must be an instance of torch.nn.Module")
        if not (0.0 <= smoothing < 1.0):
            raise ValueError("smoothing must be in [0, 1)")
        super().__init__()
        self.module = module
        self.policy = policy
        self.ledger = ledger
        self._registry = registry or default_plasticity_registry
        self._spec = _spec_from_input(curve)
        self.comfort_threshold = max(1e-6, float(comfort_threshold))
        self.scale = max(0.0, float(scale))
        self.max_delta = max(0.0, float(max_delta))
        self.smoothing = float(smoothing)
        self._activations: dict[str, dict[str, float]] = {}
        self._layer_params: dict[str, list[torch_nn.Parameter]] = {}
        self._layer_display: dict[str, str] = {}
        self._hooks: list[Any] = []
        self._register_layers(layer_names)

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        return self.module(*args, **kwargs)

    def close(self) -> None:
        for handle in self._hooks:
            try:
                handle.remove()
            except Exception:  # pragma: no cover - hook already removed
                continue
        self._hooks.clear()

    def facilitate(
        self,
        *,
        comfort_dist: float | None = None,
        tags: Mapping[str, Any] | None = None,
    ) -> list[PlasticityFacilitationEvent]:
        if torch is None:
            raise RuntimeError("torch is required to apply plasticity")
        if self.scale <= 0.0 or self.max_delta <= 0.0:
            return []
        if comfort_dist is None:
            comfort_dist = self._compute_comfort_distance()
        comfort_dist = float(max(0.0, comfort_dist))
        if comfort_dist >= self.comfort_threshold:
            return []
        urgency = (self.comfort_threshold - comfort_dist) / self.comfort_threshold
        events: list[PlasticityFacilitationEvent] = []
        for layer_key, stats in self._activations.items():
            z = stats.get("z")
            if z is None:
                continue
            pre = stats.get("pre", z)
            curved = self._registry.evaluate(self._spec, z, pre_activation=pre)
            magnitude = min(self.max_delta, max(0.0, self.scale * curved * urgency))
            if magnitude <= 0.0:
                continue
            if not self._apply_perturbation(layer_key, magnitude):
                continue
            event = PlasticityFacilitationEvent(
                layer=self._layer_display.get(layer_key, layer_key),
                magnitude=float(magnitude),
                comfort_dist=comfort_dist,
                tags=dict(tags or {}),
            )
            events.append(event)
            self._emit(event)
        return events

    # Internal helpers -------------------------------------------------

    def _register_layers(self, target_names: Sequence[str] | None) -> None:
        assert torch is not None and nn is not None
        named = dict(self.module.named_modules())
        targets: list[str] = []
        if target_names:
            targets = list(target_names)
        else:
            for name, mod in named.items():
                if not name:
                    continue
                if any(param.requires_grad for param in mod.parameters(recurse=False)):
                    targets.append(name)
            if not targets:
                targets = [""]

        for name in targets:
            module = named.get(name) if name else self.module
            if module is None:
                raise ValueError(f"Layer '{name}' not found in wrapped module")
            params = [p for p in module.parameters(recurse=False) if p.requires_grad]
            if not params:
                continue
            key = name or "__root__"
            display = name or module.__class__.__name__
            self._layer_params[key] = params
            self._layer_display[key] = display
            handle = module.register_forward_hook(self._make_activation_hook(key))
            self._hooks.append(handle)
        if not self._layer_params:
            params = [p for p in self.module.parameters() if p.requires_grad]
            if params:
                key = "__root__"
                self._layer_params[key] = params
                self._layer_display[key] = self.module.__class__.__name__
                handle = self.module.register_forward_hook(self._make_activation_hook(key))
                self._hooks.append(handle)

    def _make_activation_hook(self, key: str) -> Callable[[Any, Any, Any], None]:
        assert torch is not None

        def hook(module: Any, inputs: Any, output: Any) -> None:
            self._update_activation(key, "pre", self._normalize_activation(inputs))
            self._update_activation(key, "z", self._normalize_activation(output))

        return hook

    def _normalize_activation(self, value: Any) -> float:
        if torch is None:
            return 0.5
        tensor = self._first_tensor(value)
        if tensor is None:
            try:
                scalar = abs(float(value))
            except (TypeError, ValueError):
                return 0.5
            return 1.0 / (1.0 + math.exp(-scalar))
        if tensor.numel() == 0:
            return 0.5
        with torch.no_grad():
            scalar = float(tensor.detach().abs().mean().item())
        return 1.0 / (1.0 + math.exp(-scalar))

    def _first_tensor(self, value: Any) -> Tensor | None:
        if torch is None:
            return None
        if isinstance(value, (tuple, list)):
            for item in value:
                tensor = self._first_tensor(item)
                if tensor is not None:
                    return tensor
            return None
        if isinstance(value, dict):
            for item in value.values():
                tensor = self._first_tensor(item)
                if tensor is not None:
                    return tensor
            return None
        if torch.is_tensor(value):
            return value
        return None

    def _update_activation(self, key: str, field: str, value: float) -> None:
        stats = self._activations.setdefault(key, {})
        prev = stats.get(field)
        if prev is None:
            stats[field] = value
        else:
            stats[field] = self.smoothing * prev + (1.0 - self.smoothing) * value

    def _apply_perturbation(self, key: str, magnitude: float) -> bool:
        if torch is None:
            return False
        params = self._layer_params.get(key)
        if not params:
            return False
        with torch.no_grad():
            for param in params:
                noise = torch.randn_like(param) * magnitude
                param.add_(noise)
        return True

    def _compute_comfort_distance(self) -> float:
        distances = self.policy.distance_to_boundary()
        if not distances:
            return 0.0
        return float(min(distances.values()))

    def _emit(self, event: PlasticityFacilitationEvent) -> None:
        if not self.ledger:
            return
        try:
            self.ledger.add(event)
        except AttributeError:  # pragma: no cover - ledger missing add()
            pass


__all__ = [
    "PlasticityCurve",
    "PlasticitySpec",
    "PlasticityRegistry",
    "create_default_plasticity_registry",
    "default_plasticity_registry",
    "evaluate_plasticity",
    "HomeostasisPlasticityWrapper",
]
