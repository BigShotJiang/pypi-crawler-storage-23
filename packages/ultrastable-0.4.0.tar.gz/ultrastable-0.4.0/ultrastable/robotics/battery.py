from __future__ import annotations

import random
from collections.abc import Callable, Mapping
from typing import Any, cast

from ultrastable.core import (
    Controller,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.core.coupling import TaskCoupledVariable
from ultrastable.core.events import StepEvent
from ultrastable.interventions import ResetReplan

try:  # pragma: no cover - optional dependency
    import gymnasium as gym
    from gymnasium import spaces
except Exception:  # pragma: no cover - gym not installed
    gym = cast(Any, None)
    spaces = cast(Any, None)


def _clamp(value: float, *, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


class BatteryLightSeekerEnv(gym.Env if gym else object):  # type: ignore[misc]
    """Simple 1D light-seeking environment with optional sensor inversion."""

    metadata: dict[str, list[str]] = {"render_modes": []}

    def __init__(
        self,
        *,
        seed: int = 0,
        sensor_noise: float = 0.02,
        inversion_interval: int = 40,
        max_steps: int = 240,
    ) -> None:
        self._base_seed = seed
        self._rng = random.Random(seed)
        self.sensor_noise = max(0.0, sensor_noise)
        self.inversion_interval = max(1, inversion_interval)
        self.max_steps = max(1, max_steps)
        self.step_count = 0
        self.rewire_count = 0
        self.sensor_inverted = False
        self.position = 0.0
        self.light_position = 0.0
        if spaces is not None:
            self.action_space: Any = spaces.Discrete(3)
            self.observation_space = spaces.Dict(
                {
                    "sensor_left": spaces.Box(low=0.0, high=1.0, shape=()),
                    "sensor_right": spaces.Box(low=0.0, high=1.0, shape=()),
                    "position": spaces.Box(low=-1.0, high=1.0, shape=()),
                    "light_delta": spaces.Box(low=-1.0, high=1.0, shape=()),
                    "inverted_hint": spaces.Box(low=0.0, high=1.0, shape=()),
                }
            )

    def reset(
        self, *, seed: int | None = None, options: Mapping[str, Any] | None = None
    ) -> tuple[dict[str, float], dict[str, Any]]:
        if seed is not None:
            self._rng.seed(seed)
        else:
            self._rng.seed(self._base_seed + self.rewire_count)
        self.step_count = 0
        self.sensor_inverted = False
        self.rewire_count = 0
        self.position = self._rng.uniform(-0.3, 0.3)
        self.light_position = self._rng.uniform(-0.8, 0.8)
        obs = self._observation()
        return obs, self._info(reward=0.0, observation=obs)

    def step(self, action: int) -> tuple[dict[str, float], float, bool, bool, dict[str, Any]]:
        idx = int(action)
        if idx <= 0:
            move = -0.15
        elif idx == 1:
            move = 0.0
        else:
            move = 0.15
        self.position = _clamp(self.position + move, lo=-1.0, hi=1.0)
        self._advance_light()
        self.step_count += 1
        if self.step_count % self.inversion_interval == 0:
            self.rewire()
        reward = self._reward(move)
        obs = self._observation()
        terminated = False
        truncated = self.step_count >= self.max_steps
        return obs, reward, terminated, truncated, self._info(reward=reward, observation=obs)

    def rewire(self) -> None:
        self.sensor_inverted = not self.sensor_inverted
        self.rewire_count += 1

    # Internal utilities --------------------------------------------------

    def _advance_light(self) -> None:
        drift = self._rng.uniform(-0.12, 0.12)
        self.light_position = _clamp(self.light_position + drift, lo=-1.0, hi=1.0)

    def _reward(self, move: float) -> float:
        distance = abs(self.light_position - self.position)
        illumination = 1.0 - _clamp(distance, lo=0.0, hi=1.0)
        effort = 0.05 * abs(move) / 0.15
        reward = illumination - effort - 0.02
        return max(-1.0, min(1.0, reward))

    def _observation(self) -> dict[str, float]:
        delta = _clamp(self.light_position - self.position, lo=-1.0, hi=1.0)
        left = _clamp(-delta, lo=0.0, hi=1.0)
        right = _clamp(delta, lo=0.0, hi=1.0)
        if self.sensor_inverted:
            left, right = right, left
        left += self._rng.uniform(-self.sensor_noise, self.sensor_noise)
        right += self._rng.uniform(-self.sensor_noise, self.sensor_noise)
        return {
            "sensor_left": _clamp(left),
            "sensor_right": _clamp(right),
            "position": self.position,
            "light_delta": delta,
            "inverted_hint": 1.0 if self.sensor_inverted else 0.0,
        }

    def _info(
        self, *, reward: float, observation: Mapping[str, float] | None = None
    ) -> dict[str, Any]:
        obs = observation or self._observation()
        direction_signal = obs["sensor_right"] - obs["sensor_left"]
        actual_signal = _clamp(self.light_position - self.position, lo=-1.0, hi=1.0)
        coherence = 1.0 - min(1.0, abs(direction_signal - actual_signal))
        illum = max(0.0, 1.0 - abs(self.light_position - self.position))
        return {
            "metrics": {
                "illumination": illum,
                "sensor_coherence": coherence,
            },
            "sensor_inverted": self.sensor_inverted,
            "rewire_count": self.rewire_count,
            "reward": reward,
            "dt": 1.0,
        }


def build_battery_light_controller() -> Controller:
    """Construct a controller with a coupled battery variable."""

    battery = TaskCoupledVariable(
        name="battery",
        decay=0.25,
        coupling={"func": "rectified_linear", "params": {"k": 0.8}},
        min_value=0.0,
        max_value=1.0,
        start_value=0.7,
        tags={"kind": "trust-battery"},
    )
    space = EssentialVariableSpace(
        [
            EssentialVariable.bounded("illumination", min=0.2, max=1.0, scale=0.8),
            EssentialVariable.bounded("sensor_coherence", min=0.3, max=1.0, scale=0.7),
        ],
        coupled_variables=[battery],
    )
    policy = ViabilityPolicy(
        space=space,
        health=HealthModel("l2"),
        bounded_warn_fraction=0.3,
        monotonic_warn_fraction=0.8,
    )
    controller = Controller(
        policy=policy,
        detectors=[],
        interventions=[ResetReplan()],
        cooldown_steps=2,
    )
    return controller


class OrganismicDriveWrapper:
    """Connects an environment reward signal to TaskCoupledVariable metabolism."""

    def __init__(
        self,
        env: Any,
        controller: Controller,
        *,
        ledger: Any | None = None,
        reward_to_signal: Callable[[float], float] | None = None,
    ) -> None:
        self.env = env
        self.controller = controller
        self.ledger = ledger
        self._reward_to_signal = reward_to_signal or (lambda r: max(0.0, r))
        self._step_index = 0
        self._last_dh = self._current_dh()
        self._state: dict[str, Any] = {}

    def reset(self, *args: Any, **kwargs: Any) -> tuple[Any, dict[str, Any]]:
        result = self.env.reset(*args, **kwargs)
        if isinstance(result, tuple) and len(result) == 2:
            obs, info = result
        else:  # pragma: no cover - gym compatibility
            obs = result
            info = {}
        metrics = dict(info.get("metrics") or {})
        if metrics:
            self._update_metrics(metrics)
        self._last_dh = self._current_dh()
        return obs, info

    def step(
        self, action: Any, *, tags: Mapping[str, Any] | None = None
    ) -> tuple[Any, float, bool, bool, dict[str, Any]]:
        result = self.env.step(action)
        if len(result) == 4:
            observation, reward, terminated, info = result
            truncated = False
        else:
            observation, reward, terminated, truncated, info = result
        info = dict(info or {})
        dt = float(info.get("dt", 1.0))
        metrics = dict(info.get("metrics") or {})
        if metrics:
            self._update_metrics(metrics)
        self._apply_task_signal(reward, dt=dt)
        snapshot = self.controller.policy.space.snapshot(self.controller.policy.health)
        step_event = StepEvent(
            step_id=f"organism-{self._step_index}",
            role="agent",
            kind="robotic",
            d_h=snapshot.d_h,
            tags={
                "action": self._action_value(action),
                "reward": reward,
                **(tags or {}),
            },
        )
        self._emit(step_event)
        self._emit(snapshot)
        decision = self.controller.update(step_event, snapshot=snapshot, state=self._state)
        for trigger in decision.triggers:
            self._emit(trigger)
        if decision.intervention and decision.intervention.event:
            self._emit(decision.intervention.event)
        drive_penalty = max(0.0, (snapshot.d_h or 0.0) - self._last_dh)
        self._last_dh = snapshot.d_h or 0.0
        info["drive_penalty"] = drive_penalty
        info["policy_status"] = decision.policy_status
        space = self.controller.policy.space
        for name in space.coupled_variables:
            info[f"{name}_value"] = space.values.get(name)
        self._step_index += 1
        return observation, reward, terminated, truncated, info

    # Internal helpers --------------------------------------------------

    def _update_metrics(self, metrics: Mapping[str, float]) -> None:
        space = self.controller.policy.space
        for name, value in metrics.items():
            if name in space.variables:
                space.set(name, float(value))

    def _apply_task_signal(self, reward: float, *, dt: float) -> None:
        signal = self._reward_to_signal(float(reward))
        space = self.controller.policy.space
        events = space.step_coupled(signal=signal, dt=dt)
        if events:
            self._emit(events)

    def _current_dh(self) -> float:
        _, d_h = self.controller.policy.health.compute(self.controller.policy.space)
        return float(d_h)

    def _action_value(self, action: Any) -> Any:
        if hasattr(action, "item"):
            try:
                return action.item()
            except Exception:  # pragma: no cover - fallback
                return action
        return action

    def _emit(self, event: Any) -> None:
        if not self.ledger or event is None:
            return
        if isinstance(event, list):
            for item in event:
                self._emit(item)
            return
        self.ledger.add(event)


__all__ = [
    "BatteryLightSeekerEnv",
    "OrganismicDriveWrapper",
    "build_battery_light_controller",
]
