from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

try:  # pragma: no cover - optional dependency
    import torch
    from torch import nn
except Exception:  # pragma: no cover - torch missing
    torch = cast(Any, None)
    nn = cast(Any, None)

if TYPE_CHECKING:  # pragma: no cover
    from torch import nn as torch_nn
else:  # pragma: no cover - typing fallback
    torch_nn = Any


def _require_torch() -> None:
    if torch is None or nn is None:
        raise RuntimeError("torch_resets requires the 'ultrastable[robotics]' extra (torch>=2.0)")


def _maybe_reset_parameters(layer: Any) -> None:
    if hasattr(layer, "reset_parameters"):
        layer.reset_parameters()
        return
    for param in layer.parameters():
        nn.init.uniform_(param, -0.05, 0.05)


def _sample_indices(total: int, count: int, generator: torch.Generator) -> list[int]:
    """Return deterministic python ints from a randperm slice for typing sanity."""
    perm = torch.randperm(total, generator=generator)
    return [int(value) for value in perm[:count].tolist()]


@dataclass
class NeuronReset:
    """Reinitialize a fraction of neurons that appear dormant."""

    module: torch_nn.Module
    fraction: float = 0.1
    threshold: float = 1e-3
    layer_types: tuple[type[torch_nn.Module], ...] = (nn.Linear,) if nn else tuple()
    seed: int | None = None

    def apply(self) -> list[str]:
        _require_torch()
        if self.fraction <= 0.0:
            return []
        events: list[str] = []
        generator = torch.Generator()
        if self.seed is not None:
            generator.manual_seed(int(self.seed))
        for name, layer in self.module.named_modules():
            if not isinstance(layer, self.layer_types):
                continue
            layer_any = cast(Any, layer)
            weight = getattr(layer_any, "weight", None)
            if weight is None:
                continue
            magnitude = weight.detach().abs().mean(dim=1)
            mask = magnitude < self.threshold
            count = int(mask.sum().item())
            if count == 0:
                total = weight.size(0)
                num = max(1, math.floor(total * self.fraction))
                perm = torch.randperm(total, generator=generator)
                mask = torch.zeros(total, dtype=torch.bool)
                mask[perm[:num]] = True
                count = num
            before = layer_any.weight.detach().clone()
            nn.init.kaiming_uniform_(layer_any.weight[mask], a=math.sqrt(5))
            bias = getattr(layer_any, "bias", None)
            if bias is not None:
                fan_in, _ = nn.init._calculate_fan_in_and_fan_out(before)
                bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
                nn.init.uniform_(bias[mask], -bound, bound)
            events.append(f"{name}:{count}")
        return events


@dataclass
class LayerReset:
    """Reset entire layers (heads) back to initialization."""

    module: torch_nn.Module
    fraction: float = 0.5
    layer_types: tuple[type[torch_nn.Module], ...] = (nn.Linear,) if nn else tuple()
    seed: int | None = None

    def apply(self) -> list[str]:
        _require_torch()
        layers: list[tuple[str, nn.Module]] = [
            (name, layer)
            for name, layer in self.module.named_modules()
            if isinstance(layer, self.layer_types)
        ]
        if not layers or self.fraction <= 0.0:
            return []
        total = len(layers)
        num = max(1, math.floor(total * self.fraction))
        generator = torch.Generator()
        if self.seed is not None:
            generator.manual_seed(int(self.seed))
        selected = _sample_indices(total, num, generator)
        events: list[str] = []
        for idx in selected:
            name, layer = layers[idx]
            _maybe_reset_parameters(layer)
            events.append(name)
        return events


@dataclass
class EnsembleReset:
    """Reset a subset of modules from an ensemble."""

    modules: Sequence[torch_nn.Module]
    fraction: float = 0.5
    seed: int | None = None

    def apply(self) -> list[int]:
        _require_torch()
        if self.fraction <= 0.0 or not self.modules:
            return []
        total = len(self.modules)
        num = max(1, math.floor(total * self.fraction))
        generator = torch.Generator()
        if self.seed is not None:
            generator.manual_seed(int(self.seed))
        selected = _sample_indices(total, num, generator)
        for idx in selected:
            _maybe_reset_parameters(self.modules[idx])
        return selected


__all__ = ["NeuronReset", "LayerReset", "EnsembleReset"]
