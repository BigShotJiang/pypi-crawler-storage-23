from __future__ import annotations

import math
import random
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from ultrastable.agent import AgentGuard
from ultrastable.core import (
    Controller,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.interventions import ResetReplan
from ultrastable.ledger import JsonlLedger


def _clamp(value: float, *, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


@dataclass
class LightSource:
    center: tuple[float, float]
    sigma: float
    weight: float


@dataclass
class MobileHomeostat2D:
    """Simple 2D light-gradient environment with homeostatic dynamics."""

    seed: int = 0
    step_size: float = 0.12
    base_battery_drain: float = 0.04
    recharge_rate: float = 0.09
    drift_scale: float = 0.015
    dark_zone_center: tuple[float, float] = (0.0, -0.55)
    dark_zone_radius: float = 0.35
    x_bounds: tuple[float, float] = (-1.0, 1.0)
    y_bounds: tuple[float, float] = (-1.0, 1.0)

    def __post_init__(self) -> None:
        self._rng = random.Random(self.seed)
        self._sources: list[LightSource] = [
            LightSource(center=(0.65, 0.55), sigma=0.26, weight=1.0),
            LightSource(center=(-0.55, 0.45), sigma=0.32, weight=0.85),
        ]
        self._active_source = 0
        self.history: list[dict[str, float]] = []
        self.reset()

    def reset(self, *, seed: int | None = None) -> dict[str, float]:
        if seed is not None:
            self._rng.seed(seed)
        else:
            self._rng.seed(self.seed)
        self.position: list[float] = [
            self._rng.uniform(-0.85, -0.55),
            self._rng.uniform(-0.95, -0.65),
        ]
        self.battery = self._rng.uniform(0.55, 0.7)
        self.temperature = self._rng.uniform(0.35, 0.5)
        self.instability = 0.0
        self.rewire_count = 0
        self.step_index = 0
        self.history = []
        return self.observe()

    def step(self, action: tuple[float, float] | None = None) -> dict[str, float]:
        move = action or self._scripted_action()
        dx, dy = float(move[0]), float(move[1])
        dx += self._rng.uniform(-self.drift_scale, self.drift_scale)
        dy += self._rng.uniform(-self.drift_scale, self.drift_scale)
        norm = math.hypot(dx, dy)
        if norm > 1e-9:
            limit = self.step_size
            if norm > limit:
                scale = limit / norm
                dx *= scale
                dy *= scale
        self.position[0] = _clamp(self.position[0] + dx, lo=self.x_bounds[0], hi=self.x_bounds[1])
        self.position[1] = _clamp(self.position[1] + dy, lo=self.y_bounds[0], hi=self.y_bounds[1])
        current_position = (self.position[0], self.position[1])
        intensity = self._light_intensity(current_position)
        in_dark_zone = self._in_dark_zone(current_position)
        drain = self.base_battery_drain * (1.6 if in_dark_zone else 1.0)
        recharge = intensity * self.recharge_rate
        self.battery = _clamp(self.battery - drain + recharge)
        if in_dark_zone:
            self.instability = _clamp(self.instability + 0.12)
        else:
            self.instability = _clamp(self.instability - 0.05)
        temp_noise = self._rng.uniform(-0.015, 0.015)
        self.temperature = _clamp(self.temperature + 0.08 * (intensity - 0.5) + temp_noise)
        self.step_index += 1
        metrics = self.observe()
        self.history.append(
            {
                "x": metrics["position_x"],
                "y": metrics["position_y"],
                "light_intensity": metrics["light_intensity"],
                "battery": metrics["battery"],
                "in_dark_zone": metrics["in_dark_zone"],
            }
        )
        return metrics

    def rewire(self) -> None:
        """Swap the target light source to simulate wiring changes."""

        self._active_source = (self._active_source + 1) % len(self._sources)
        self.rewire_count += 1
        self.instability = _clamp(self.instability * 0.5)
        self.battery = _clamp(self.battery + 0.15)

    def observe(self) -> dict[str, float]:
        x, y = self.position
        intensity = self._light_intensity((x, y))
        dark_zone = 1.0 if self._in_dark_zone((x, y)) else 0.0
        return {
            "position_x": float(x),
            "position_y": float(y),
            "battery": float(self.battery),
            "battery_depletion": float(1.0 - self.battery),
            "light_intensity": float(intensity),
            "instability": float(self.instability),
            "temperature": float(self.temperature),
            "in_dark_zone": dark_zone,
            "rewire_count": float(self.rewire_count),
        }

    # Internal helpers -------------------------------------------------

    def _scripted_action(self) -> tuple[float, float]:
        goal = self._sources[self._active_source].center
        dx = goal[0] - self.position[0]
        dy = goal[1] - self.position[1]
        dist = math.hypot(dx, dy)
        if dist < 1e-9:
            return 0.0, 0.0
        step = min(self.step_size * 0.9, dist)
        ratio = step / dist
        return dx * ratio, dy * ratio

    def _light_intensity(self, position: tuple[float, float]) -> float:
        x, y = position
        total = 0.15
        for idx, source in enumerate(self._sources):
            center_x, center_y = source.center
            dx = x - center_x
            dy = y - center_y
            sigma = source.sigma
            weight = source.weight
            strength = weight * math.exp(-((dx * dx + dy * dy) / (2.0 * sigma * sigma)))
            if idx == self._active_source:
                strength *= 1.25
            total += strength
        return _clamp(total)

    def _in_dark_zone(self, position: tuple[float, float]) -> bool:
        x, y = position
        cx, cy = self.dark_zone_center
        dist = math.hypot(x - cx, y - cy)
        return dist <= self.dark_zone_radius


class LightSeekerEnv(MobileHomeostat2D):
    """Backward-compatible alias for v0.2.x."""


def build_homeostat_controller() -> Controller:
    space = EssentialVariableSpace(
        [
            EssentialVariable.monotonic("battery_depletion", hard_limit=1.0, scale=1.0),
            EssentialVariable.bounded("light_intensity", min=0.4, max=1.0, scale=0.6),
            EssentialVariable.bounded("instability", min=0.0, max=0.35, scale=0.35),
        ]
    )
    policy = ViabilityPolicy(
        space=space,
        health=HealthModel("l2"),
        monotonic_warn_fraction=0.75,
        bounded_warn_fraction=0.2,
    )
    return Controller(
        policy=policy,
        detectors=[],
        interventions=[ResetReplan()],
        cooldown_steps=2,
    )


def build_guard_and_env(
    path: str | Path, seed: int = 0
) -> tuple[AgentGuard, MobileHomeostat2D, JsonlLedger]:
    controller = build_homeostat_controller()
    ledger = JsonlLedger(str(path))
    guard = AgentGuard(
        controller=controller,
        ledger=ledger,
        context_budget_chars=None,
        variable_bindings={
            "light_intensity": "light_intensity",
            "instability": "instability",
            "battery_depletion": "battery_depletion",
        },
        accumulate_metrics=["battery", "light_intensity"],
    )
    env = MobileHomeostat2D(seed=seed)
    return guard, env, ledger


def render_mobile_homeostat_svg(
    env: MobileHomeostat2D,
    path: str | Path,
    *,
    width: int = 640,
    height: int = 480,
) -> Path:
    """Render a simple SVG trajectory plot for the MobileHomeostat2D."""

    output = Path(path)
    history = list(env.history)
    if not history:
        output.write_text("<svg xmlns='http://www.w3.org/2000/svg'></svg>\n", encoding="utf-8")
        return output

    def project(points: Iterable[tuple[float, float]]) -> list[tuple[float, float]]:
        scale_x = width / (env.x_bounds[1] - env.x_bounds[0])
        scale_y = height / (env.y_bounds[1] - env.y_bounds[0])
        projected: list[tuple[float, float]] = []
        for px, py in points:
            sx = (px - env.x_bounds[0]) * scale_x
            sy = height - (py - env.y_bounds[0]) * scale_y
            projected.append((sx, sy))
        return projected

    points_xy = [(item["x"], item["y"]) for item in history]
    projected = project(points_xy)
    point_str = " ".join(f"{x:.1f},{y:.1f}" for x, y in projected)
    start_x, start_y = projected[0]
    end_x, end_y = projected[-1]
    dark_x, dark_y = project([env.dark_zone_center])[0]
    avg_scale = (
        width / (env.x_bounds[1] - env.x_bounds[0]) + height / (env.y_bounds[1] - env.y_bounds[0])
    ) / 2.0
    dark_radius = env.dark_zone_radius * avg_scale
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">\n'
        f'  <rect x="0" y="0" width="{width}" height="{height}" fill="#05060a"/>\n'
        f'  <circle cx="{dark_x:.1f}" cy="{dark_y:.1f}" r="{dark_radius:.1f}" fill="#190a0a" '
        f'fill-opacity="0.7" stroke="#402121" stroke-width="2"/>\n'
        f'  <polyline points="{point_str}" fill="none" stroke="#3ad1ff" stroke-width="3" '
        f'stroke-linecap="round" stroke-linejoin="round"/>\n'
        f'  <circle cx="{start_x:.1f}" cy="{start_y:.1f}" r="6" fill="#f1cd3f" '
        f'stroke="#ffffff" stroke-width="1.5"/>\n'
        f'  <circle cx="{end_x:.1f}" cy="{end_y:.1f}" r="5" fill="#39f17f" '
        f'stroke="#ffffff" stroke-width="1.2"/>\n'
        "</svg>\n"
    )
    output.write_text(svg, encoding="utf-8")
    return output


__all__ = [
    "LightSeekerEnv",
    "MobileHomeostat2D",
    "render_mobile_homeostat_svg",
    "build_homeostat_controller",
    "build_guard_and_env",
]
