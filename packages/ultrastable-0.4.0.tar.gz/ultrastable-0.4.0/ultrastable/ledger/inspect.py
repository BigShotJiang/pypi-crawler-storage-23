from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any


def summarize_jsonl(path: str) -> dict[str, Any]:
    from .jsonl import iter_events

    by_type: dict[str, int] = {}
    by_detector: dict[str, int] = {}
    by_severity: dict[str, int] = {}
    by_intervention: dict[str, int] = {}
    total_tokens = 0
    total_usd = 0.0
    events_total = 0
    step_counts: dict[str, int] = {}
    step_total = 0
    tool_calls = 0
    intervention_outcomes: dict[str, int] = {}

    for ev in iter_events(path):
        events_total += 1
        et = ev.get("event_type", "?")
        by_type[et] = by_type.get(et, 0) + 1

        if et == "trigger":
            det = ev.get("detector", "?")
            sev = ev.get("severity", "?")
            by_detector[det] = by_detector.get(det, 0) + 1
            by_severity[sev] = by_severity.get(sev, 0) + 1
        if et == "intervention":
            it = ev.get("intervention_type", "?")
            by_intervention[it] = by_intervention.get(it, 0) + 1
            status = _intervention_status(ev)
            if status:
                intervention_outcomes[status] = intervention_outcomes.get(status, 0) + 1
        if et == "step":
            step_total += 1
            kind_value = _normalize_label(ev.get("kind"))
            kind_key = kind_value or "unknown"
            step_counts[kind_key] = step_counts.get(kind_key, 0) + 1
            if _is_tool_step(ev, kind_value):
                tool_calls += 1
        if et in {"cost", "step"}:
            # Aggregate tokens/usd when available
            tokens = ev.get("tokens_total") or ev.get("tokens")
            usd = ev.get("cost_usd") or ev.get("usd")
            if isinstance(tokens, int):
                total_tokens += tokens
            if isinstance(usd, (int, float)):
                total_usd += float(usd)

    # Deterministic ordering by sorting keys for nested dicts
    def sort_dict(d: dict[str, Any]) -> dict[str, Any]:
        return {k: d[k] for k in sorted(d.keys())}

    summary: dict[str, Any] = {
        "events_total": events_total,
        "by_type": sort_dict(by_type),
        "triggers": {
            "by_detector": sort_dict(by_detector),
            "by_severity": sort_dict(by_severity),
        },
        "interventions": {
            "by_type": sort_dict(by_intervention),
            "outcomes": sort_dict(intervention_outcomes),
        },
        "steps": {
            "total": int(step_total),
            "tool_calls": int(tool_calls),
            "by_kind": sort_dict(step_counts),
        },
        "cost": {
            "tokens": int(total_tokens),
            "usd": round(total_usd, 12),  # stable rounding
        },
    }
    return summary


def format_summary(summary: dict[str, Any]) -> str:
    return json.dumps(summary, sort_keys=True, separators=(",", ":"))


def _normalize_label(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    return text or None


def _is_tool_step(event: Mapping[str, Any], kind: str | None) -> bool:
    if kind == "tool":
        return True
    role = _normalize_label(event.get("role"))
    if role == "tool":
        return True
    tags = event.get("tags")
    if isinstance(tags, Mapping):
        tag_kind = _normalize_label(tags.get("kind"))
        if tag_kind == "tool":
            return True
    return False


def _intervention_status(event: Mapping[str, Any]) -> str | None:
    tags = event.get("tags")
    if isinstance(tags, Mapping):
        status = _normalize_label(tags.get("status"))
        if status:
            return status
    outcome = event.get("outcome")
    if isinstance(outcome, Mapping):
        status = _normalize_label(outcome.get("status"))
        if status:
            return status
    return None
