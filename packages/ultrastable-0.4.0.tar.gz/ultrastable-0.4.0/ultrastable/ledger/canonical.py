"""Canonical (stable) JSON serialization helpers for ledger hashing."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

JsonScalar = str | int | float | bool | None
JsonValue = JsonScalar | list["JsonValue"] | dict[str, "JsonValue"]


class CanonicalJsonError(TypeError):
    """Raised when a payload cannot be serialized into canonical ledger JSON."""


def canonicalize_record(record: Mapping[str, Any]) -> dict[str, JsonValue]:
    """Return a JSON-serializable copy of the record for stable hashing."""
    return _normalize_mapping(record)


def canonical_record_json(record: Mapping[str, Any]) -> str:
    """Serialize a record to canonical JSON (sorted keys, compact separators)."""
    normalized = canonicalize_record(record)
    return json.dumps(normalized, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def canonical_record_bytes(record: Mapping[str, Any]) -> bytes:
    """Serialize a record to canonical JSON bytes (UTF-8)."""
    return canonical_record_json(record).encode("utf-8")


def _normalize_mapping(mapping: Mapping[str, Any]) -> dict[str, JsonValue]:
    normalized: dict[str, JsonValue] = {}
    for key, value in mapping.items():
        if not isinstance(key, str):
            raise CanonicalJsonError(
                f"Ledger payload keys must be strings for canonical hashing (got {type(key)!r})"
            )
        normalized[key] = _normalize_value(value)
    return normalized


def _normalize_value(value: Any) -> JsonValue:
    if isinstance(value, Mapping):
        return _normalize_mapping(value)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_normalize_value(entry) for entry in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    raise CanonicalJsonError(
        f"Unsupported ledger value type for canonical hashing: {type(value)!r}"
    )


__all__ = [
    "CanonicalJsonError",
    "canonical_record_bytes",
    "canonical_record_json",
    "canonicalize_record",
]
