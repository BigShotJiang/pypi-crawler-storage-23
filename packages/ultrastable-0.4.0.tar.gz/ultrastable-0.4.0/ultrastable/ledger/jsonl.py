from __future__ import annotations

import errno
import hashlib
import json
import os
from collections.abc import Generator, Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ultrastable.core.events import BaseEvent, apply_redaction
from ultrastable.ledger.canonical import (
    CanonicalJsonError,
    canonical_record_bytes,
    canonical_record_json,
)

_ROTATION_INDEX_SUFFIX = ".index"


def _compute_event_hash(record: Mapping[str, Any]) -> str:
    """Return the SHA-256 digest of the canonicalized record."""
    return hashlib.sha256(canonical_record_bytes(record)).hexdigest()


def _is_hex_digest(value: str) -> bool:
    if len(value) != 64:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


@dataclass(slots=True)
class HashChainValidationResult:
    events: int
    issues: list[str]
    chain_present: bool = False

    @property
    def ok(self) -> bool:
        return not self.issues


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def _normalize_redaction_mode(value: str | None) -> str:
    """Normalize user-provided redaction choices to supported modes."""
    if not value:
        return "metadata-only"
    normalized = value.strip().lower()
    if normalized in {"metadata-only", "selective-text", "full-text"}:
        return normalized
    if normalized == "none":
        return "full-text"
    return "metadata-only"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _today_key() -> str:
    # YYYYMMDD for filenames
    return _utc_now().strftime("%Y%m%d")


def _next_rotated_path(base_path: str, tag: str) -> str:
    root, ext = os.path.splitext(base_path)
    n = 1
    while True:
        candidate = f"{root}-{tag}-{n:04d}{ext or '.jsonl'}"
        if not os.path.exists(candidate):
            return candidate
        n += 1


def _rotation_index_path(base_path: str) -> Path:
    return Path(f"{base_path}{_ROTATION_INDEX_SUFFIX}")


def _load_rotation_entries(base_path: str) -> list[str]:
    index_path = _rotation_index_path(base_path)
    try:
        raw = index_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict):
        entries = data.get("rotations", [])
    elif isinstance(data, list):
        entries = data
    else:
        entries = []
    cleaned: list[str] = []
    seen: set[str] = set()
    for item in entries:
        if not isinstance(item, str):
            continue
        normalized = os.path.abspath(item)
        if normalized in seen:
            continue
        if os.path.exists(normalized):
            cleaned.append(normalized)
            seen.add(normalized)
    return cleaned


def _write_rotation_entries(base_path: str, entries: list[str]) -> None:
    index_path = _rotation_index_path(base_path)
    payload = {
        "rotations": entries,
        "updated_at": _utc_now().isoformat(),
    }
    index_path.parent.mkdir(parents=True, exist_ok=True)
    index_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _prune_rotation_entries(entries: list[str], keep: int | None) -> tuple[list[str], list[str]]:
    if keep is None or keep <= 0:
        return entries, []
    kept = entries[:keep]
    removed = entries[keep:]
    return kept, removed


def _remove_files(paths: list[str]) -> list[str]:
    removed: list[str] = []
    for path in paths:
        try:
            os.remove(path)
        except FileNotFoundError:
            continue
        else:
            removed.append(path)
    return removed


def _sync_rotation_index(base_path: str, keep: int | None) -> tuple[list[str], list[str]]:
    entries = _load_rotation_entries(base_path)
    entries, removed = _prune_rotation_entries(entries, keep)
    _write_rotation_entries(base_path, entries)
    removed_files = _remove_files(removed)
    return entries, removed_files


def _register_rotation(
    base_path: str, rotated_path: str, keep: int | None
) -> tuple[list[str], list[str]]:
    rotated_abs = os.path.abspath(rotated_path)
    entries = _load_rotation_entries(base_path)
    entries = [rotated_abs] + [p for p in entries if p != rotated_abs]
    entries, removed = _prune_rotation_entries(entries, keep)
    _write_rotation_entries(base_path, entries)
    removed_files = _remove_files(removed)
    return entries, removed_files


def _perform_rotation(base_path: str) -> str:
    rotated = _next_rotated_path(base_path, _utc_now().strftime("%Y%m%d%H%M%S"))
    if os.path.exists(base_path):
        os.rename(base_path, rotated)
    else:
        Path(rotated).touch()
    Path(base_path).write_text("", encoding="utf-8")
    return rotated


class JsonlLedger:
    """Append-only JSONL ledger with optional rotation and redaction.

    Writing strategy:
    - Uses low-level os.open with O_APPEND and os.write for atomic append.
    - Flush policy:
        - flush="none": rely on OS buffering
        - flush="fsync": call os.fsync after each write
    Rotation:
        - max_bytes: rotate when file size would exceed this value
        - rotate_daily: rotate when the YYYYMMDD key changes
        - keep_rotations: keep newest N rotated files + maintain manifest index
    """

    def __init__(
        self,
        path: str,
        *,
        redaction: str = "metadata-only",
        flush: str = "none",  # "none" | "fsync"
        max_bytes: int | None = None,
        rotate_daily: bool = False,
        keep_rotations: int | None = None,
    ) -> None:
        self._base_path = os.path.abspath(path)
        self._path = self._base_path
        self._fd: int | None = None
        self._redaction = _normalize_redaction_mode(redaction)
        if flush not in {"none", "fsync"}:
            raise ValueError("flush must be 'none' or 'fsync'")
        self._flush = flush
        self._max_bytes = max_bytes
        self._rotate_daily = rotate_daily
        self._day_key = _today_key()
        self._keep_rotations = keep_rotations
        _ensure_dir(self._base_path)
        self._prev_hash: str | None = self._load_last_event_hash()
        self._open()

    # Context manager -----------------------------------------------------
    def __enter__(self) -> JsonlLedger:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: Any | None,
    ) -> None:
        self.close()

    # Public API ----------------------------------------------------------
    @property
    def path(self) -> str:
        return self._path

    @property
    def redaction(self) -> str:
        return self._redaction

    def add(self, event: BaseEvent | Mapping[str, Any]) -> None:
        """Serialize and append a single event as JSONL."""
        if isinstance(event, BaseEvent):
            payload = event.to_dict(redaction_level=self._redaction)
        else:
            payload = dict(event)
            if "event_type" not in payload:
                raise ValueError("event dict must include 'event_type'")
            if "redaction_level" not in payload:
                payload["redaction_level"] = self._redaction
            payload = apply_redaction(payload, payload.get("redaction_level", self._redaction))
        line, event_hash = self._serialize_with_hash(payload, self._prev_hash)
        data = (line + "\n").encode("utf-8")
        if self._maybe_rotate(len(data)):
            line, event_hash = self._serialize_with_hash(payload, self._prev_hash)
            data = (line + "\n").encode("utf-8")
        self._write_bytes(data)
        self._prev_hash = event_hash

    def add_many(self, events: Iterable[BaseEvent | Mapping[str, Any]]) -> None:
        for ev in events:
            self.add(ev)

    def close(self) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            finally:
                self._fd = None

    # Internals -----------------------------------------------------------
    def _open(self) -> None:
        flags = os.O_APPEND | os.O_CREAT | os.O_WRONLY
        self._fd = os.open(self._path, flags, 0o644)

    def _maybe_rotate(self, next_line_len: int) -> bool:
        rotated = False
        # Daily rotation
        if self._rotate_daily:
            key = _today_key()
            if key != self._day_key:
                rotated_path = _next_rotated_path(self._base_path, self._day_key)
                try:
                    if self._fd is not None:
                        os.close(self._fd)
                finally:
                    self._fd = None
                os.rename(self._path, rotated_path)
                _register_rotation(self._base_path, rotated_path, self._keep_rotations)
                self._path = self._base_path
                self._day_key = key
                self._open()
                self._prev_hash = None
                rotated = True

        # Size-based rotation
        if self._max_bytes is not None and self._max_bytes > 0:
            try:
                st = os.stat(self._path)
                size = int(st.st_size)
            except OSError as e:
                if e.errno == errno.ENOENT:
                    size = 0
                else:
                    raise
            if size + next_line_len > self._max_bytes:
                rotated_path = _next_rotated_path(self._base_path, _utc_now().strftime("%H%M%S"))
                try:
                    if self._fd is not None:
                        os.close(self._fd)
                finally:
                    self._fd = None
                os.rename(self._path, rotated_path)
                _register_rotation(self._base_path, rotated_path, self._keep_rotations)
                self._path = self._base_path
                self._open()
                self._prev_hash = None
                rotated = True
        return rotated

    def _write_bytes(self, data: bytes) -> None:
        if self._fd is None:
            self._open()
        assert self._fd is not None
        os.write(self._fd, data)
        if self._flush == "fsync":
            os.fsync(self._fd)

    def _serialize_with_hash(
        self, payload: Mapping[str, Any], prev_hash: str | None
    ) -> tuple[str, str]:
        record = dict(payload)
        record["prev_hash"] = prev_hash
        event_hash = _compute_event_hash(record)
        record["event_hash"] = event_hash
        return canonical_record_json(record), event_hash

    def _load_last_event_hash(self) -> str | None:
        try:
            with open(self._path, encoding="utf-8") as fp:
                last_hash: str | None = None
                for raw in fp:
                    line = raw.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    candidate = data.get("event_hash")
                    if isinstance(candidate, str) and candidate:
                        last_hash = candidate
                return last_hash
        except FileNotFoundError:
            return None


def iter_events(path: str) -> Generator[dict[str, Any], None, None]:
    """Yield parsed JSON events from a JSONL file, skipping invalid lines."""
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                # Skip corrupted/truncated lines (e.g., crash during write)
                continue


def rotate(path: str, *, max_mb: float, keep: int) -> dict[str, Any]:
    """Rotate a ledger file when it exceeds the requested size.

    Returns manifest details describing the rotation + index state.
    """

    if max_mb <= 0:
        raise ValueError("max_mb must be greater than zero")
    if keep <= 0:
        raise ValueError("keep must be >= 1")
    base_path = os.path.abspath(path)
    _ensure_dir(base_path)
    max_bytes = max(1, int(max_mb * 1024 * 1024))
    removed: list[str] = []
    entries, removed_missing = _sync_rotation_index(base_path, keep)
    removed.extend(removed_missing)

    try:
        size = os.path.getsize(base_path)
    except OSError as exc:
        if exc.errno == errno.ENOENT:
            size = 0
        else:
            raise

    rotated_now: str | None = None
    if size > max_bytes:
        rotated_now = _perform_rotation(base_path)
        entries, removed_now = _register_rotation(base_path, rotated_now, keep)
        removed.extend(removed_now)
    return {
        "base_path": base_path,
        "index_path": str(_rotation_index_path(base_path)),
        "rotated": entries,
        "removed": removed,
        "rotated_now": rotated_now,
    }


def validate_hash_chain(path: str) -> HashChainValidationResult:
    """Validate the prev_hash/event_hash chain recorded in a JSONL ledger.

    Ledgers that predate hash chaining simply skip the verification step.
    """

    issues: list[str] = []
    events = 0
    expected_prev_hash: str | None = None
    chain_present = False
    with open(path, encoding="utf-8") as fp:
        for idx, raw in enumerate(fp, 1):
            line = raw.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError as exc:
                issues.append(f"Line {idx}: invalid JSON ({exc})")
                # Cannot advance the hash chain without a parsed record.
                continue
            stored_prev = data.get("prev_hash")
            stored_hash = data.get("event_hash")
            has_chain_fields = stored_hash is not None or stored_prev is not None
            if not has_chain_fields:
                if chain_present:
                    issues.append(f"Line {idx}: missing event_hash in hash-chained ledger")
                continue

            chain_present = True
            events += 1
            if stored_prev is not None and not isinstance(stored_prev, str):
                issues.append(
                    f"Line {idx}: prev_hash must be a string or null "
                    f"(found {type(stored_prev).__name__})"
                )
            elif stored_prev != expected_prev_hash:
                issues.append(
                    f"Line {idx}: prev_hash mismatch "
                    f"(expected {expected_prev_hash!r}, found {stored_prev!r})"
                )

            record = dict(data)
            record.pop("event_hash", None)
            computed_hash: str | None = None
            try:
                computed_hash = _compute_event_hash(record)
            except CanonicalJsonError as exc:
                issues.append(f"Line {idx}: cannot canonicalize record for hashing ({exc})")

            if stored_hash is None:
                issues.append(f"Line {idx}: missing event_hash")
            elif not isinstance(stored_hash, str):
                issues.append(
                    f"Line {idx}: event_hash must be a string (found {type(stored_hash).__name__})"
                )
            elif not _is_hex_digest(stored_hash):
                issues.append(
                    f"Line {idx}: event_hash must be a 64-character hex string "
                    f"(found {stored_hash!r})"
                )
            elif computed_hash is not None and stored_hash != computed_hash:
                issues.append(
                    f"Line {idx}: event_hash mismatch "
                    f"(recorded {stored_hash}, computed {computed_hash})"
                )

            if isinstance(stored_hash, str):
                expected_prev_hash = stored_hash
    return HashChainValidationResult(events=events, issues=issues, chain_present=chain_present)
