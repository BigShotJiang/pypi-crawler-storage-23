"""Append-only JSONL ledger and local inspection utilities."""

from .canonical import (
    CanonicalJsonError,
    canonical_record_bytes,
    canonical_record_json,
    canonicalize_record,
)
from .inspect import format_summary, summarize_jsonl
from .jsonl import (
    HashChainValidationResult,
    JsonlLedger,
    iter_events,
    rotate,
    validate_hash_chain,
)

__all__ = [
    "CanonicalJsonError",
    "canonical_record_bytes",
    "canonical_record_json",
    "canonicalize_record",
    "HashChainValidationResult",
    "JsonlLedger",
    "iter_events",
    "summarize_jsonl",
    "format_summary",
    "rotate",
    "validate_hash_chain",
]
