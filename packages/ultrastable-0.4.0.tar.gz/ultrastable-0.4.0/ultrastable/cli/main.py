from __future__ import annotations

import argparse
import json
from collections.abc import Callable, Mapping
from datetime import datetime
from pathlib import Path
from typing import Any

from ultrastable.cli import dashboard
from ultrastable.cli.demos import (
    build_agent_loop_controller,
    build_budget_controller,
    run_agent_loop_demo,
    run_battery_light_seeker_demo,
    run_budget_cap_demo,
)
from ultrastable.events.registry import EventSchemaError
from ultrastable.export import export_budget_policy, export_routing_policy
from ultrastable.ledger import (
    HashChainValidationResult,
    format_summary,
    summarize_jsonl,
    validate_hash_chain,
)
from ultrastable.policy import (
    PolicyPackError,
    canonicalize_policy,
    load_policy_document,
    load_policy_pack_file,
    policy_hash,
)
from ultrastable.replay.engine import LedgerHashChainError, replay_ledger
from ultrastable.replay.report import generate_causal_report, generate_report
from ultrastable.reporting import (
    generate_spend_report,
    generate_unit_econ_report,
    generate_zombie_report,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ultrastable", add_help=True)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_inspect = sub.add_parser("inspect", help="Inspect a JSONL ledger and print a summary")
    p_inspect.add_argument("path", help="Path to ledger.jsonl")
    _add_output_format_args(p_inspect, default_format="json")

    p_ledger = sub.add_parser("ledger", help="Ledger utilities")
    ledger_sub = p_ledger.add_subparsers(dest="ledger_cmd", required=True)
    p_ledger_validate = ledger_sub.add_parser(
        "validate", help="Validate ledger JSON structure (and optional hash chain)"
    )
    p_ledger_validate.add_argument("path", help="Path to ledger.jsonl")
    p_ledger_validate.add_argument(
        "--hash-chain",
        action="store_true",
        help="Verify the prev_hash/event_hash chain for tamper evidence",
    )

    p_demo = sub.add_parser("demo", help="Run offline demos")
    demo_sub = p_demo.add_subparsers(dest="demo_cmd", required=True)
    p_demo_agent = demo_sub.add_parser("agent-loop", help="Run the agent loop demo")
    _add_redaction_override_arg(p_demo_agent)
    p_demo_agent.add_argument(
        "--output",
        default="runs/agent_loop_ledger.jsonl",
        help="Where to write the demo ledger",
    )
    p_demo_agent.add_argument(
        "--policy-pack",
        help="Path to a PolicyPack (JSON) to drive the demo controller",
    )
    p_demo_budget = demo_sub.add_parser("budget-cap", help="Run the budget cap demo")
    _add_redaction_override_arg(p_demo_budget)
    p_demo_budget.add_argument(
        "--output",
        default="runs/budget_cap_ledger.jsonl",
        help="Where to write the demo ledger",
    )
    p_demo_budget.add_argument(
        "--policy-pack",
        help="Path to a PolicyPack (JSON) to drive the demo controller",
    )
    p_demo_battery = demo_sub.add_parser(
        "battery-seeker", help="Run the Battery Light Seeker robotics demo"
    )
    _add_redaction_override_arg(p_demo_battery)
    p_demo_battery.add_argument(
        "--output",
        default="runs/battery_light_seeker_ledger.jsonl",
        help="Where to write the demo ledger",
    )
    p_demo_battery.add_argument(
        "--steps",
        type=int,
        default=200,
        help="Number of environment steps to simulate",
    )

    p_replay = sub.add_parser("replay", help="Replay a ledger under a demo policy")
    p_replay.add_argument("path", help="Path to ledger.jsonl")
    p_replay.add_argument(
        "--demo-policy",
        choices=["agent-loop", "budget-cap"],
        help="Use a built-in demo policy/controller for replay",
    )
    p_replay.add_argument(
        "--policy-pack",
        help="Load a PolicyPack (JSON only) to replay the ledger deterministically",
    )
    p_replay.add_argument(
        "--report",
        choices=["summary", "causal"],
        default="summary",
        help="Select the replay report format",
    )
    p_replay.add_argument(
        "--deterministic",
        action="store_true",
        help="Replay with stable RNG seeds (records seed in metadata)",
    )
    p_replay.add_argument(
        "--seed",
        type=int,
        help="Override deterministic seed (implies --deterministic)",
    )

    p_validate = sub.add_parser("validate", help="Validate ledgers or policies")
    v_sub = p_validate.add_subparsers(dest="validate_cmd", required=True)
    p_validate_ledger = v_sub.add_parser("ledger", help="Validate ledger JSON structure")
    p_validate_ledger.add_argument("path", help="Path to ledger.jsonl")
    p_validate_ledger.add_argument(
        "--hash-chain",
        action="store_true",
        help="Verify the prev_hash/event_hash chain for tamper evidence",
    )
    p_validate_policy = v_sub.add_parser(
        "policy", help="Validate policy pack and emit canonical JSON + hash"
    )
    p_validate_policy.add_argument("path", help="Path to policy.json")

    p_dashboard = sub.add_parser("dashboard", help="Run live dashboards for demos")
    p_dashboard.add_argument(
        "demo",
        choices=["agent-loop"],
        help="Demo scenario to visualize",
    )
    p_dashboard.add_argument(
        "--output",
        default="runs/agent_loop_dashboard.jsonl",
        help="Where to write the dashboard ledger",
    )
    _add_redaction_override_arg(p_dashboard)

    p_report = sub.add_parser("report", help="Generate finance-grade reports")
    report_sub = p_report.add_subparsers(dest="report_cmd", required=True)
    p_report_spend = report_sub.add_parser("spend", help="Summarize spend totals")
    p_report_spend.add_argument("path", help="Path to ledger.jsonl")
    p_report_spend.add_argument(
        "--by",
        default="agent_id",
        help="Group by tag key (customer, feature, agent_id, model, run_id, etc.)",
    )
    p_report_spend.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Limit number of groups; remaining entries are aggregated into 'others'",
    )
    p_report_spend.add_argument(
        "--filter",
        dest="filters",
        action="append",
        default=None,
        help="Tag or field filter in key=value form (can repeat)",
    )
    p_report_spend.add_argument("--start-time", help="Filter events after this ISO timestamp")
    p_report_spend.add_argument("--end-time", help="Filter events before this ISO timestamp")
    _add_output_format_args(p_report_spend)

    p_report_unit = report_sub.add_parser("unit-econ", help="Compute unit economics")
    p_report_unit.add_argument("path", help="Path to ledger.jsonl")
    p_report_unit.add_argument(
        "--by",
        default="customer",
        help="Group by tag key (customer, feature, agent_id, etc.)",
    )
    p_report_unit.add_argument(
        "--metric",
        choices=["cost_per_task", "cost_per_user", "cost_per_$revenue"],
        default="cost_per_task",
        help="Unit economics metric to compute",
    )
    p_report_unit.add_argument("--task-map", help="JSON file mapping group -> task count")
    p_report_unit.add_argument("--user-map", help="JSON file mapping group -> user count")
    p_report_unit.add_argument("--revenue-map", help="JSON file mapping group -> revenue (USD)")
    p_report_unit.add_argument(
        "--filter",
        dest="filters",
        action="append",
        default=None,
        help="Tag or field filter in key=value form (can repeat)",
    )
    p_report_unit.add_argument("--start-time", help="Filter events after this ISO timestamp")
    p_report_unit.add_argument("--end-time", help="Filter events before this ISO timestamp")
    _add_output_format_args(p_report_unit)

    p_report_zombie = report_sub.add_parser("zombie", help="Detect zombie spend incidents")
    p_report_zombie.add_argument("path", help="Path to ledger.jsonl")
    p_report_zombie.add_argument("--trigger-threshold", type=int, default=3)
    p_report_zombie.add_argument("--error-threshold", type=int, default=3)
    p_report_zombie.add_argument("--spend-threshold", type=float, default=5.0)
    p_report_zombie.add_argument("--min-steps", type=int, default=20)
    p_report_zombie.add_argument(
        "--filter",
        dest="filters",
        action="append",
        default=None,
        help="Tag or field filter in key=value form (can repeat)",
    )
    p_report_zombie.add_argument("--start-time", help="Filter events after this ISO timestamp")
    p_report_zombie.add_argument("--end-time", help="Filter events before this ISO timestamp")
    _add_output_format_args(p_report_zombie)

    p_export = sub.add_parser("export", help="Generate config artifacts from ledgers")
    export_sub = p_export.add_subparsers(dest="export_cmd", required=True)
    p_export_routing = export_sub.add_parser(
        "routing-policy", help="Generate deterministic routing policy fragments"
    )
    p_export_routing.add_argument("ledger", help="Path to ledger.jsonl")
    p_export_routing.add_argument(
        "--group-by",
        default="customer",
        help="Ledger tag/field to use for routing buckets",
    )
    p_export_routing.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Limit number of routing entries",
    )
    p_export_routing.add_argument(
        "--output",
        type=Path,
        help="Write exported JSON to a file (defaults to stdout)",
    )
    p_export_budget = export_sub.add_parser(
        "budget-policy", help="Create a PolicyPack tuned to observed spend"
    )
    p_export_budget.add_argument("ledger", help="Path to ledger.jsonl")
    p_export_budget.add_argument(
        "--name",
        default="auto_budget_policy",
        help="Policy name to embed in the export",
    )
    p_export_budget.add_argument(
        "--description",
        help="Optional description to include in the PolicyPack",
    )
    p_export_budget.add_argument(
        "--group-by",
        default="customer",
        help="Ledger tag/field to drive budget recommendations",
    )
    p_export_budget.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Limit number of budget recommendations",
    )
    p_export_budget.add_argument(
        "--output",
        type=Path,
        help="Write exported PolicyPack to a file (defaults to stdout)",
    )

    args = parser.parse_args(argv)

    if args.cmd == "inspect":
        summary = summarize_jsonl(args.path)
        _emit_output(
            summary,
            fmt=getattr(args, "format", "json"),
            output_path=getattr(args, "output", None),
            text_formatter=format_summary,
        )
        return 0

    if args.cmd == "demo":
        output = Path(getattr(args, "output", "runs/demo_ledger.jsonl"))
        redaction = _normalize_redaction_choice(getattr(args, "redaction", None))
        policy_pack_path = getattr(args, "policy_pack", None)
        if args.demo_cmd == "agent-loop":
            path = run_agent_loop_demo(output, policy_pack=policy_pack_path, redaction=redaction)
        elif args.demo_cmd == "battery-seeker":
            steps = getattr(args, "steps", 200)
            path = run_battery_light_seeker_demo(output, max_steps=steps, redaction=redaction)
        else:
            path = run_budget_cap_demo(output, policy_pack=policy_pack_path, redaction=redaction)
        print(f"Demo ledger written to {path}")
        return 0

    if args.cmd == "replay":
        controller = None
        if getattr(args, "policy_pack", None):
            controller = load_policy_pack_file(args.policy_pack).controller
        elif args.demo_policy:
            if args.demo_policy == "agent-loop":
                controller = build_agent_loop_controller()
            else:
                controller = build_budget_controller()
        deterministic = bool(getattr(args, "deterministic", False) or getattr(args, "seed", None))
        if controller is not None:
            try:
                result = replay_ledger(
                    args.path,
                    controller,
                    deterministic=deterministic,
                    seed=getattr(args, "seed", None),
                )
            except (EventSchemaError, LedgerHashChainError) as exc:
                print(f"Replay failed: {exc}")
                return 1
            if args.report == "causal":
                report = generate_causal_report(result)
            else:
                report = generate_report(result)
            print(json.dumps(report, sort_keys=True))
            return 0
        if args.report == "causal":
            print("Causal report requires --policy-pack or --demo-policy to be specified.")
            return 1
        summary = summarize_jsonl(args.path)
        payload = {
            "policy": "recorded",
            "events_replayed": summary["events_total"],
            "triggers": summary["triggers"],
            "interventions": summary["interventions"],
        }
        print(json.dumps(payload, sort_keys=True))
        return 0

    if args.cmd == "ledger":
        if args.ledger_cmd == "validate":
            return _validate_ledger(
                Path(args.path),
                hash_chain=bool(getattr(args, "hash_chain", False)),
            )
        print("Unknown ledger command")
        return 1

    if args.cmd == "validate":
        target = args.validate_cmd
        if target == "ledger":
            return _validate_ledger(
                Path(args.path),
                hash_chain=bool(getattr(args, "hash_chain", False)),
            )
        if target == "policy":
            return _validate_policy(Path(args.path))
        print("Unknown validate target")
        return 1

    if args.cmd == "dashboard":
        if not dashboard.rich_available():
            print("Rich dashboard requires the 'cli' extra (pip install ultrastable[cli]).")
            return 1
        if args.demo == "agent-loop":
            redaction = _normalize_redaction_choice(getattr(args, "redaction", None))
            path = dashboard.run_agent_loop_dashboard(args.output, redaction=redaction)
            print(f"Dashboard ledger written to {path}")
            return 0

    if args.cmd == "report":
        if args.report_cmd == "spend":
            filters = _parse_filter_args(getattr(args, "filters", None))
            try:
                start_time = _parse_time_arg(getattr(args, "start_time", None))
                end_time = _parse_time_arg(getattr(args, "end_time", None))
            except ValueError as exc:
                print(exc)
                return 1
            report = generate_spend_report(
                args.path,
                group_by=getattr(args, "by", None),
                limit=getattr(args, "limit", None),
                filters=filters,
                start_time=start_time,
                end_time=end_time,
            )
        elif args.report_cmd == "unit-econ":
            filters = _parse_filter_args(getattr(args, "filters", None))
            try:
                start_time = _parse_time_arg(getattr(args, "start_time", None))
                end_time = _parse_time_arg(getattr(args, "end_time", None))
            except ValueError as exc:
                print(exc)
                return 1
            report = generate_unit_econ_report(
                args.path,
                group_by=getattr(args, "by", None),
                metric=args.metric,
                task_map=_load_mapping_file(args.task_map),
                user_map=_load_mapping_file(args.user_map),
                revenue_map=_load_mapping_file(args.revenue_map),
                filters=filters,
                start_time=start_time,
                end_time=end_time,
            )
        else:
            filters = _parse_filter_args(getattr(args, "filters", None))
            try:
                start_time = _parse_time_arg(getattr(args, "start_time", None))
                end_time = _parse_time_arg(getattr(args, "end_time", None))
            except ValueError as exc:
                print(exc)
                return 1
            report = generate_zombie_report(
                args.path,
                trigger_threshold=args.trigger_threshold,
                error_threshold=args.error_threshold,
                spend_threshold=args.spend_threshold,
                min_steps=args.min_steps,
                filters=filters,
                start_time=start_time,
                end_time=end_time,
            )
        text_formatter = _format_spend_report_text if args.report_cmd == "spend" else None
        _emit_output(
            report,
            fmt=getattr(args, "format", "json"),
            output_path=getattr(args, "output", None),
            text_formatter=text_formatter,
        )
        return 0

    if args.cmd == "export":
        if args.export_cmd == "routing-policy":
            payload = export_routing_policy(
                args.ledger,
                group_by=getattr(args, "group_by", None),
                limit=getattr(args, "limit", None),
            )
        else:
            payload = export_budget_policy(
                args.ledger,
                name=getattr(args, "name", "auto_budget_policy"),
                description=getattr(args, "description", None),
                group_by=getattr(args, "group_by", None),
                limit=getattr(args, "limit", None),
            )
        _emit_output(payload, fmt="json", output_path=getattr(args, "output", None))
        return 0

    parser.print_help()
    return 1


def _validate_ledger(path: Path, *, hash_chain: bool = False) -> int:
    issues: list[str] = []
    lines = 0
    try:
        with path.open("r", encoding="utf-8") as fp:
            for idx, raw in enumerate(fp, 1):
                line = raw.strip()
                if not line:
                    continue
                lines += 1
                try:
                    data = json.loads(line)
                except json.JSONDecodeError as exc:
                    issues.append(f"Line {idx}: invalid JSON ({exc})")
                    continue
                if "event_type" not in data:
                    issues.append(f"Line {idx}: missing event_type")
                if "timestamp" not in data:
                    issues.append(f"Line {idx}: missing timestamp")
    except FileNotFoundError:
        print(f"Ledger not found: {path}")
        return 1
    if issues:
        print("Ledger validation failed:")
        for issue in issues:
            print(f" - {issue}")
        return 1
    if hash_chain:
        chain = _validate_ledger_hash_chain(path)
        if not chain.ok:
            print("Ledger hash chain validation failed:")
            for issue in chain.issues:
                print(f" - {issue}")
            return 1
        if chain.chain_present:
            print(f"Ledger OK ({chain.events} events, hash chain verified)")
        else:
            print(f"Ledger OK ({lines} events, hash chain absent)")
        return 0
    print(f"Ledger OK ({lines} events)")
    return 0


def _validate_ledger_hash_chain(path: Path) -> HashChainValidationResult:
    try:
        return validate_hash_chain(str(path))
    except FileNotFoundError:
        return HashChainValidationResult(events=0, issues=[f"Ledger not found: {path}"])


def _emit_output(
    payload: Any,
    *,
    fmt: str,
    output_path: Path | None,
    text_formatter: Callable[[Any], str] | None = None,
) -> None:
    rendered = _render_payload(payload, fmt=fmt, text_formatter=text_formatter)
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        text = rendered if rendered.endswith("\n") else rendered + "\n"
        output_path.write_text(text, encoding="utf-8")
    else:
        print(rendered)


def _render_payload(payload: Any, *, fmt: str, text_formatter: Callable[[Any], str] | None) -> str:
    if fmt == "json":
        return json.dumps(payload, sort_keys=True)
    if text_formatter:
        return text_formatter(payload)
    return json.dumps(payload, indent=2, sort_keys=True)


def _add_output_format_args(parser: argparse.ArgumentParser, default_format: str = "json") -> None:
    parser.add_argument(
        "--format",
        choices=("json", "text"),
        default=default_format,
        help="Select output format (json or text)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Write the command output to a file instead of stdout",
    )


def _add_redaction_override_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--redaction",
        choices=("metadata-only", "selective-text", "full-text", "none"),
        default="metadata-only",
        help="Override the ledger redaction mode (use 'none' to disable redaction)",
    )


def _validate_policy(path: Path) -> int:
    try:
        data = load_policy_document(path)
    except FileNotFoundError:
        print(f"Policy not found: {path}")
        return 1
    except ValueError as exc:
        print(f"Policy invalid: {exc}")
        return 2
    except Exception as exc:
        print(f"Failed to load policy: {exc}")
        return 1
    try:
        canonical = canonicalize_policy(data)
    except PolicyPackError as exc:
        print(f"Policy invalid: {exc}")
        return 2
    except Exception as exc:
        print(f"Failed to canonicalize policy: {exc}")
        return 1
    payload = {
        "path": str(path),
        "policy_hash": policy_hash(canonical),
        "canonical_policy": canonical,
    }
    print(json.dumps(payload, sort_keys=True))
    return 0


def _load_mapping_file(path: str | None) -> dict[str, float]:
    if not path:
        return {}
    content = Path(path).read_text(encoding="utf-8")
    data = json.loads(content)
    if not isinstance(data, Mapping):
        raise ValueError(f"Expected mapping in {path}")
    out: dict[str, float] = {}
    for key, value in data.items():
        try:
            out[str(key)] = float(value)
        except (TypeError, ValueError):
            continue
    return out


def _parse_filter_args(items: list[str] | None) -> dict[str, str]:
    filters: dict[str, str] = {}
    if not items:
        return filters
    for item in items:
        if not item or "=" not in item:
            continue
        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key:
            filters[key] = value
    return filters


def _parse_time_arg(value: str | None) -> datetime | None:
    if not value:
        return None
    text = value.strip()
    if not text:
        return None
    normalized = text.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        raise ValueError(f"Invalid ISO timestamp: {value}") from None


def _normalize_redaction_choice(value: str | None) -> str:
    if not value:
        return "metadata-only"
    normalized = value.strip().lower()
    aliases = {
        "metadata-only": "metadata-only",
        "selective-text": "selective-text",
        "full-text": "full-text",
        "none": "full-text",
    }
    return aliases.get(normalized, "metadata-only")


def _format_spend_report_text(report: Mapping[str, Any]) -> str:
    lines: list[str] = []
    group_by = str(report.get("group_by", "all"))
    totals = report.get("totals") or {}
    totals_line = (
        f"Spend totals (group_by={group_by}): tokens={_coerce_int(totals.get('tokens'))}, "
        f"usd={_format_usd(totals.get('usd'))}, "
        f"steps={_coerce_int(totals.get('steps'))}, "
        f"tool_calls={_coerce_int(totals.get('tool_calls'))}"
    )
    lines.append(totals_line)

    groups = report.get("groups")
    if isinstance(groups, (list, tuple)) and groups:
        lines.append("Groups:")
        for idx, entry in enumerate(groups, 1):
            key = entry.get("key", "(unknown)")
            line = (
                f" {idx}. {key} - usd={_format_usd(entry.get('usd'))}, "
                f"tokens={_coerce_int(entry.get('tokens'))}, "
                f"steps={_coerce_int(entry.get('steps'))}, "
                f"tool_calls={_coerce_int(entry.get('tool_calls'))}"
            )
            lines.append(line)
    else:
        lines.append("Groups: (none)")

    health = report.get("health") or {}
    trend_line = _summarize_dh_trend(health.get("d_h_trend"))
    effect_line = _summarize_delta_effect(health.get("intervention_effect_size"))
    if trend_line or effect_line:
        lines.append("")
        if trend_line:
            lines.append(trend_line)
        if effect_line:
            lines.append(effect_line)
    return "\n".join(lines)


def _summarize_dh_trend(trend: Mapping[str, Any] | None) -> str:
    if not trend or not trend.get("samples"):
        return "D(H) trend: no D(H) samples recorded"
    samples = int(trend.get("samples", 0))
    start = _format_point(trend.get("start"))
    end = _format_point(trend.get("end"))
    delta = _format_float(trend.get("delta"), signed=True)
    median = _format_float(trend.get("median"))
    p90 = _format_float(trend.get("p90"))
    min_point = _format_point(trend.get("min"))
    max_point = _format_point(trend.get("max"))
    return (
        f"D(H) trend: {start} -> {end} (delta {delta}, samples={samples}, "
        f"median={median}, p90={p90}, min={min_point}, max={max_point})"
    )


def _summarize_delta_effect(effect: Mapping[str, Any] | None) -> str:
    if not effect or not effect.get("samples"):
        return "Delta D(H) summary: no intervention outcomes recorded"
    samples = int(effect.get("samples", 0))
    parts = [
        f"samples={samples}",
        f"mean={_format_float(effect.get('mean_delta'), signed=True)}",
        f"median={_format_float(effect.get('median_delta'), signed=True)}",
        f"p90={_format_float(effect.get('p90_delta'), signed=True)}",
        f"best={_format_float(effect.get('largest_recovery'), signed=True)}",
        f"worst={_format_float(effect.get('largest_regression'), signed=True)}",
    ]
    improved = _format_percentage(effect.get("improved_fraction"))
    worsened = _format_percentage(effect.get("worsened_fraction"))
    if improved:
        parts.append(f"improved={improved}")
    if worsened:
        parts.append(f"worsened={worsened}")
    statuses = effect.get("status_breakdown")
    if isinstance(statuses, Mapping) and statuses:
        formatted = ", ".join(f"{key}={value}" for key, value in sorted(statuses.items()))
        parts.append(f"statuses={formatted}")
    detail = ", ".join(parts)
    return f"Delta D(H) summary: {detail}"


def _format_point(point: Mapping[str, Any] | None) -> str:
    if not point:
        return "n/a"
    value = _format_float(point.get("d_h"))
    timestamp = point.get("timestamp")
    if timestamp:
        return f"{value}@{timestamp}"
    return value


def _format_usd(value: Any) -> str:
    number = _coerce_float(value)
    if number is None:
        return "n/a"
    return f"${number:.4f}"


def _format_float(value: Any, *, signed: bool = False) -> str:
    number = _coerce_float(value)
    if number is None:
        return "n/a"
    fmt = f"{{:{'+' if signed else ''}.3f}}"
    return fmt.format(number)


def _format_percentage(value: Any) -> str | None:
    number = _coerce_float(value)
    if number is None:
        return None
    return f"{number * 100:.0f}%"


def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _coerce_int(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return int(value)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
