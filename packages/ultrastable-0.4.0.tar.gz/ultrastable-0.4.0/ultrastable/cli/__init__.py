"""CLI entrypoints (extras)."""

__all__: list[str] = []
