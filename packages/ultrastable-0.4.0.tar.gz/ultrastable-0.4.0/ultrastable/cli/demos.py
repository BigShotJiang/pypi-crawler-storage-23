from __future__ import annotations

from collections.abc import Callable, Mapping
from pathlib import Path

from ultrastable.agent import AgentGuard, StepMetrics
from ultrastable.core import (
    Controller,
    ControllerDecision,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.detectors import LexicalRepeatDetector, ToolLoopDetector
from ultrastable.interventions import ResetContextTrim, ResetReplan
from ultrastable.ledger import JsonlLedger
from ultrastable.policy import load_policy_pack_file
from ultrastable.robotics import (
    BatteryLightSeekerEnv,
    OrganismicDriveWrapper,
    build_battery_light_controller,
)

DemoStepHook = Callable[[int, ControllerDecision, StepMetrics], None]


def build_agent_loop_controller() -> Controller:
    space = EssentialVariableSpace(
        [
            EssentialVariable.bounded("context_util", min=0.0, max=1.0, scale=1.0),
            EssentialVariable.monotonic("spend_usd", hard_limit=0.50, scale=0.50),
            EssentialVariable.monotonic("tokens_total", hard_limit=2000, scale=2000),
            EssentialVariable.monotonic("retries", hard_limit=5, scale=5),
        ]
    )
    policy = ViabilityPolicy(
        space=space,
        health=HealthModel("l2"),
        bounded_warn_fraction=0.15,
        monotonic_warn_fraction=0.8,
    )
    return Controller(
        policy=policy,
        detectors=[LexicalRepeatDetector(repeat_threshold=3)],
        interventions=[ResetContextTrim(keep_last_turns=3), ResetReplan()],
        cooldown_steps=2,
    )


def build_agent_loop_guard(
    path: Path,
    *,
    controller: Controller | None = None,
    redaction: str = "metadata-only",
) -> tuple[AgentGuard, JsonlLedger]:
    controller = controller or build_agent_loop_controller()
    ledger = JsonlLedger(str(path), redaction=redaction)
    guard = AgentGuard(controller=controller, ledger=ledger, context_budget_chars=4000)
    return guard, ledger


def run_agent_loop_demo(
    path: str | Path,
    *,
    on_step: DemoStepHook | None = None,
    max_steps: int = 6,
    policy_pack: str | Path | None = None,
    redaction: str = "metadata-only",
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    controller = None
    if policy_pack:
        controller = load_policy_pack_file(policy_pack).controller
    guard, ledger = build_agent_loop_guard(output, controller=controller, redaction=redaction)
    try:
        run_agent_loop_sequence(guard, on_step=on_step, max_steps=max_steps)
    finally:
        ledger.close()
    return output


def run_agent_loop_sequence(
    guard: AgentGuard,
    *,
    on_step: DemoStepHook | None = None,
    max_steps: int = 6,
) -> None:
    guard.start_run(run_id="agent-loop-demo", tags={"agent": "loop"})
    conversation = [{"id": "sys", "role": "system", "content": "Keep responses short."}]
    guard.pre_step(conversation)
    prompt = "Say hello politely."
    repeated_response = "Hello! I hope you're having a nice day."
    try:
        for idx in range(max_steps):
            metrics = StepMetrics(
                tokens_prompt=15,
                tokens_completion=15,
                cost_usd=0.005,
                retries=1 if idx % 2 == 1 else 0,
            )
            decision = guard.post_step(
                step_id=f"loop-{idx}",
                role="assistant",
                kind="llm",
                model="offline-demo-model",
                prompt_text=prompt,
                response_text=repeated_response,
                metrics=metrics,
                tags={"iteration": idx},
            )
            if on_step:
                on_step(idx, decision, metrics)
            conversation.append({"id": f"user-{idx}", "role": "user", "content": prompt})
            conversation.append(
                {"id": f"assistant-{idx}", "role": "assistant", "content": repeated_response}
            )
            if decision.policy_status == "critical":
                break
            guard.pre_step(conversation)
    finally:
        guard.end_run()


def build_budget_controller() -> Controller:
    space = EssentialVariableSpace(
        [
            EssentialVariable.monotonic("spend_usd", hard_limit=0.02, scale=0.02),
            EssentialVariable.monotonic("tokens_total", hard_limit=500, scale=500),
        ]
    )
    policy = ViabilityPolicy(space=space, health=HealthModel("l2"), monotonic_warn_fraction=0.8)
    return Controller(
        policy=policy,
        detectors=[ToolLoopDetector()],
        interventions=[ResetReplan()],
        cooldown_steps=1,
    )


def _build_budget_guard(
    path: Path,
    *,
    controller: Controller | None = None,
    redaction: str = "metadata-only",
) -> tuple[AgentGuard, JsonlLedger]:
    controller = controller or build_budget_controller()
    ledger = JsonlLedger(str(path), redaction=redaction)
    guard = AgentGuard(controller=controller, ledger=ledger, context_budget_chars=None)
    return guard, ledger


def run_budget_cap_demo(
    path: str | Path,
    *,
    policy_pack: str | Path | None = None,
    redaction: str = "metadata-only",
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    controller = None
    if policy_pack:
        controller = load_policy_pack_file(policy_pack).controller
    guard, ledger = _build_budget_guard(output, controller=controller, redaction=redaction)
    guard.start_run(run_id="budget-demo", tags={"agent": "budget"})
    guard.pre_step([{"id": "sys", "role": "system", "content": "Be concise."}])
    prompt = "Summarize account status."
    for idx in range(10):
        decision = guard.post_step(
            step_id=f"budget-step-{idx}",
            role="assistant",
            kind="llm",
            model="demo-model",
            prompt_text=prompt,
            response_text="Working on it...",
            metrics=StepMetrics(tokens_total=50, cost_usd=0.005),
        )
        if decision.policy_status == "critical":
            break
    guard.end_run()
    ledger.close()
    return output


class _AdaptiveSensorPolicy:
    def __init__(self) -> None:
        self._frustration = 0.0
        self._assume_inverted = False

    def select_action(self, observation: Mapping[str, float]) -> int:
        left = float(observation.get("sensor_left", 0.0))
        right = float(observation.get("sensor_right", 0.0))
        if self._assume_inverted:
            left, right = right, left
        if right - left > 0.05:
            return 2  # move right
        if left - right > 0.05:
            return 0  # move left
        return 1  # stay

    def update(self, reward: float) -> None:
        if reward < 0.2:
            self._frustration += 1.0
        else:
            self._frustration = max(0.0, self._frustration - 0.5)
        if self._frustration >= 5.0:
            self._assume_inverted = not self._assume_inverted
            self._frustration = 0.0


def run_battery_light_seeker_demo(
    path: str | Path,
    *,
    max_steps: int = 200,
    seed: int = 2,
    redaction: str = "metadata-only",
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    env = BatteryLightSeekerEnv(seed=seed)
    controller = build_battery_light_controller()
    ledger = JsonlLedger(str(output), redaction=redaction)
    wrapper = OrganismicDriveWrapper(env, controller, ledger=ledger)
    policy = _AdaptiveSensorPolicy()
    observation, info = wrapper.reset()
    reward = 0.0
    rewire_schedule = {max_steps // 3, (2 * max_steps) // 3}
    try:
        for step in range(max_steps):
            if step in rewire_schedule:
                env.rewire()
            action = policy.select_action(observation)
            observation, reward, terminated, truncated, info = wrapper.step(
                action,
                tags={
                    "demo": "battery_light_seeker",
                    "step": step,
                    "rewire_count": info.get("rewire_count", 0),
                    "sensor_inverted": info.get("sensor_inverted", False),
                },
            )
            policy.update(reward)
            if info.get("policy_status") == "critical":
                env.rewire()
            if terminated or truncated:
                break
    finally:
        ledger.close()
    return output


__all__ = [
    "run_agent_loop_demo",
    "run_agent_loop_sequence",
    "run_budget_cap_demo",
    "run_battery_light_seeker_demo",
    "build_agent_loop_controller",
    "build_agent_loop_guard",
    "build_budget_controller",
]
