from __future__ import annotations

from collections import deque
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from importlib.util import find_spec
from pathlib import Path
from typing import Any

from ultrastable.agent import StepMetrics
from ultrastable.cli.demos import build_agent_loop_guard, run_agent_loop_sequence
from ultrastable.core import KIND_BOUNDED, KIND_MONOTONIC, Controller, ControllerDecision

__all__ = ["rich_available", "run_agent_loop_dashboard"]


def rich_available() -> bool:
    return find_spec("rich") is not None


@dataclass
class _RichDeps:
    Console: Any
    Live: Any
    Panel: Any
    Table: Any
    Text: Any
    Bar: Any


def _import_rich() -> _RichDeps:
    if not rich_available():
        raise RuntimeError("Rich dashboard requires the 'rich' extra.")
    from rich.bar import Bar
    from rich.console import Console
    from rich.live import Live
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    return _RichDeps(Console=Console, Live=Live, Panel=Panel, Table=Table, Text=Text, Bar=Bar)


@dataclass
class _MetricState:
    name: str
    label: str
    kind: str
    min_value: float
    max_value: float
    warn_fraction: float
    value: float = 0.0

    def status(self) -> str:
        if self.kind == KIND_MONOTONIC:
            if self.value > self.max_value:
                return "critical"
            if self.value >= self.warn_fraction * self.max_value:
                return "warn"
            return "ok"
        if self.kind == KIND_BOUNDED:
            if not (self.min_value <= self.value <= self.max_value):
                return "critical"
            width = self.max_value - self.min_value
            if width <= 0:
                return "critical"
            proximity = min(self.value - self.min_value, self.max_value - self.value)
            if proximity <= self.warn_fraction * width:
                return "warn"
            return "ok"
        return "ok"

    def begin(self) -> float:
        return self.min_value if self.kind == KIND_BOUNDED else 0.0

    def end(self) -> float:
        return self.max_value

    def clamped_value(self) -> float:
        start = self.begin()
        end = self.end()
        if start >= end:
            return end
        return max(start, min(self.value, end))

    def summary(self) -> str:
        if self.kind == KIND_BOUNDED:
            width = self.max_value - self.min_value
            pct = 0.0 if width <= 0 else (self.value - self.min_value) / width
            return f"{pct * 100:.1f}% of range"
        note = ""
        if self.value > self.max_value:
            note = " (breach)"
        return f"{self.value:.3g}/{self.max_value:.3g}{note}"


class _DashboardState:
    def __init__(self, controller: Controller):
        self.controller = controller
        policy = controller.policy
        space = policy.space
        self.metrics: list[_MetricState] = []
        mapping = {
            "spend_usd": "Budget (USD)",
            "context_util": "Context Utilization",
            "retries": "Retries",
        }
        for key, label in mapping.items():
            ev = space.variables.get(key)
            if not ev:
                continue
            if ev.kind == KIND_MONOTONIC:
                self.metrics.append(
                    _MetricState(
                        name=key,
                        label=label,
                        kind=ev.kind,
                        min_value=0.0,
                        max_value=float(ev.hard_limit or 0.0),
                        warn_fraction=policy.monotonic_warn_fraction,
                    )
                )
            elif ev.kind == KIND_BOUNDED:
                self.metrics.append(
                    _MetricState(
                        name=key,
                        label=label,
                        kind=ev.kind,
                        min_value=float(ev.min or 0.0),
                        max_value=float(ev.max or 0.0),
                        warn_fraction=policy.bounded_warn_fraction,
                    )
                )
        self.policy_status = "ok"
        self.policy_reason = "within policy"
        self.step_index = 0
        self.dh = 0.0
        self.triggers: deque[str] = deque(maxlen=6)
        self.interventions: deque[str] = deque(maxlen=6)

    def update(self, decision: ControllerDecision, step_index: int) -> None:
        self.step_index = step_index + 1
        space = self.controller.policy.space
        for metric in self.metrics:
            metric.value = space.values.get(metric.name, 0.0)
        _, self.dh = self.controller.policy.health.compute(space)
        self.policy_status = decision.policy_status
        if decision.policy_status == "ok":
            self.policy_reason = "within policy"
        for trigger in decision.triggers:
            message = trigger.explanation or trigger.detector
            entry = f"{trigger.severity.upper()} {trigger.detector}: {message}"
            self.triggers.appendleft(entry)
            if trigger.detector == "viability_policy":
                self.policy_status = trigger.tags.get("policy_status", trigger.severity)
                self.policy_reason = message
        if decision.intervention and decision.intervention.event:
            event = decision.intervention.event
            status = (event.outcome or {}).get("status", "pending")
            self.interventions.appendleft(f"{event.intervention_type} ({status})")
        if decision.outcomes:
            for outcome in decision.outcomes:
                label = outcome.get("intervention_type", "unknown")
                status = outcome.get("status", "pending")
                delta = outcome.get("delta_dh")
                detail = f"{label} outcome: {status}"
                if isinstance(delta, (int, float)):
                    detail += f" ΔD(H)={delta:.2f}"
                self.interventions.appendleft(detail)


class _DashboardRenderer:
    def __init__(self, controller: Controller, refresh_per_second: float = 5.0):
        self._rich: _RichDeps | None = None
        self.console: Any | None = None
        self.refresh_per_second = refresh_per_second
        self.state = _DashboardState(controller)
        self._live: Any | None = None

    def run(self, drive: Callable[[], None]) -> None:
        rich = self._ensure_rich()
        renderable = self.render()
        with rich.Live(
            renderable,
            console=self.console,
            refresh_per_second=self.refresh_per_second,
        ) as live:
            self._live = live
            drive()
        self._live = None

    def handle_step(self, step_index: int, decision: ControllerDecision, _: StepMetrics) -> None:
        self.state.update(decision, step_index)
        if self._live:
            self._live.update(self.render())

    def render(self) -> Any:
        rich = self._ensure_rich()
        Panel = rich.Panel
        Table = rich.Table
        grid = Table.grid(expand=True)
        grid.add_column(ratio=3)
        grid.add_column(ratio=2)
        grid.add_row(self._render_metrics(), self._render_events())
        return Panel(grid, border_style=self._status_color(self.state.policy_status))

    def _render_metrics(self) -> Any:
        rich = self._ensure_rich()
        Panel = rich.Panel
        Table = rich.Table
        Text = rich.Text
        header = Table.grid(expand=True)
        header.add_column(justify="left")
        header.add_column(justify="right")
        header.add_row(
            Text(f"Step {self.state.step_index}", style="bold"),
            Text(f"D(H): {self.state.dh:.2f}", style="bold"),
        )
        header.add_row(
            Text(
                f"Policy: {self.state.policy_status.upper()}",
                style=self._status_color(self.state.policy_status),
            ),
            Text(self.state.policy_reason, style="italic"),
        )

        metrics_row = Table.grid(expand=True)
        if self.state.metrics:
            for _ in self.state.metrics:
                metrics_row.add_column()
            metrics_row.add_row(*[self._render_metric(m) for m in self.state.metrics])
        else:
            metrics_row.add_column()
            metrics_row.add_row(Text("No essential variables recorded", style="dim"))

        layout = Table.grid(expand=True)
        layout.add_row(header)
        layout.add_row(metrics_row)
        return Panel(
            layout,
            title="Health",
            border_style=self._status_color(self.state.policy_status),
        )

    def _render_metric(self, metric: _MetricState) -> Any:
        rich = self._ensure_rich()
        Panel = rich.Panel
        Table = rich.Table
        Bar = rich.Bar
        Text = rich.Text
        table = Table.grid(expand=True)
        table.add_row(Text(metric.label, style="bold"))
        table.add_row(Text(metric.summary()))
        table.add_row(
            Bar(
                size=24,
                begin=metric.begin(),
                end=metric.end(),
                value=metric.clamped_value(),
                color=self._status_color(metric.status()),
            )
        )
        return Panel(table, border_style=self._status_color(metric.status()))

    def _render_events(self) -> Any:
        Table = self._ensure_rich().Table
        grid = Table.grid(expand=True)
        grid.add_row(self._render_history("Triggers", self.state.triggers))
        grid.add_row(self._render_history("Interventions", self.state.interventions))
        return grid

    def _render_history(self, title: str, entries: Sequence[str] | deque[str]) -> Any:
        rich = self._ensure_rich()
        Panel = rich.Panel
        Table = rich.Table
        Text = rich.Text
        table = Table.grid(expand=True)
        if entries:
            for entry in entries:
                table.add_row(Text(entry, overflow="fold"))
        else:
            table.add_row(Text("none yet", style="dim"))
        return Panel(table, title=title)

    @staticmethod
    def _status_color(status: str) -> str:
        return {
            "ok": "green",
            "warn": "yellow",
            "critical": "red",
        }.get(status, "cyan")

    def _ensure_rich(self) -> _RichDeps:
        if self._rich is None:
            if not rich_available():
                raise RuntimeError("Rich dashboard requires the 'cli' extra.")
            self._rich = _import_rich()
            self.console = self._rich.Console()
        return self._rich


def run_agent_loop_dashboard(
    path: str | Path,
    *,
    max_steps: int = 6,
    refresh_per_second: float = 5.0,
    redaction: str = "metadata-only",
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    guard, ledger = build_agent_loop_guard(output, redaction=redaction)
    renderer = _DashboardRenderer(guard.controller, refresh_per_second=refresh_per_second)

    def _drive() -> None:
        run_agent_loop_sequence(guard, on_step=renderer.handle_step, max_steps=max_steps)

    try:
        renderer.run(_drive)
    finally:
        ledger.close()
    return output
