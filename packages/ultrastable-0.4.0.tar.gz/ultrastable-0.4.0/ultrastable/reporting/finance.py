from __future__ import annotations

import math
from collections import Counter, defaultdict
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ultrastable.ledger import iter_events


@dataclass
class _RunContext:
    current_run: str | None = None
    run_tags: dict[str, dict[str, Any]] = field(default_factory=dict)
    run_status: dict[str, str | None] = field(default_factory=dict)

    def handle_run_event(self, event: Mapping[str, Any]) -> bool:
        if event.get("event_type") != "run":
            return False
        run_id = str(event.get("run_id") or self.current_run or "(unknown)")
        phase = event.get("phase", "start")
        meta = event.get("meta") or {}
        tags = dict(meta.get("tags") or {})
        if phase == "start":
            self.current_run = run_id
            if tags:
                self.run_tags[run_id] = tags
            status = meta.get("status")
            if status is not None:
                self.run_status[run_id] = status
        else:  # end
            status = meta.get("status")
            if status is not None:
                self.run_status[run_id] = status
            if self.current_run == run_id:
                self.current_run = None
        return True

    def resolve_tag(self, key: str, event_tags: Mapping[str, Any]) -> Any:
        if key in event_tags:
            return event_tags[key]
        if self.current_run and self.current_run in self.run_tags:
            run_tags = self.run_tags[self.current_run]
            if key in run_tags:
                return run_tags[key]
        return None

    def current_run_id(self, event: Mapping[str, Any]) -> str:
        candidate = event.get("run_id")
        if candidate:
            return str(candidate)
        if self.current_run:
            return self.current_run
        return "(unknown)"


def generate_spend_report(
    path: str,
    *,
    group_by: str | None = "agent_id",
    limit: int | None = None,
    filters: Mapping[str, str] | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
) -> dict[str, Any]:
    context = _RunContext()
    totals = {"tokens": 0, "usd": 0.0, "steps": 0, "tool_calls": 0}
    groups: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"tokens": 0, "usd": 0.0, "steps": 0, "tool_calls": 0}
    )
    health = _HealthAggregator()
    for event in iter_events(path):
        etype = event.get("event_type")
        if etype == "run":
            context.handle_run_event(event)
            continue
        if etype not in {"step", "intervention"}:
            continue
        run_id = context.current_run_id(event)
        tags = event.get("tags") or {}
        if not _event_in_scope(event, tags, context, filters, start_time, end_time, run_id):
            continue
        if etype == "step":
            key = _resolve_group_key(group_by, event, tags, context, run_id)
            stats = groups[key]
            tokens = event.get("tokens_total")
            if tokens is not None:
                stats["tokens"] += int(tokens)
                totals["tokens"] += int(tokens)
            cost = event.get("cost_usd")
            if cost is not None:
                stats["usd"] += float(cost)
                totals["usd"] += float(cost)
            stats["steps"] += 1
            totals["steps"] += 1
            if (event.get("kind") == "tool") or (event.get("role") == "tool"):
                stats["tool_calls"] += 1
                totals["tool_calls"] += 1
            health.record_step(event)
        else:
            health.record_intervention(event)
    group_list = _sort_and_limit(groups, limit)
    return {
        "group_by": group_by or "all",
        "totals": _round_totals(totals),
        "groups": group_list,
        "health": health.payload(),
    }


def generate_unit_econ_report(
    path: str,
    *,
    group_by: str | None = "agent_id",
    metric: str = "cost_per_task",
    task_map: Mapping[str, float] | None = None,
    user_map: Mapping[str, float] | None = None,
    revenue_map: Mapping[str, float] | None = None,
    filters: Mapping[str, str] | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
) -> dict[str, Any]:
    groups, totals = _aggregate_spend(
        path,
        group_by,
        filters=filters,
        start_time=start_time,
        end_time=end_time,
    )
    denom_map: Mapping[str, float] | None
    default = 1.0
    if metric == "cost_per_task":
        denom_map = task_map
    elif metric == "cost_per_user":
        denom_map = user_map
    else:
        denom_map = revenue_map
        default = 1.0
    rows = []
    for key, stats in groups.items():
        denom = float(denom_map.get(key, default)) if denom_map else default
        if denom <= 0:
            usd_per = None
            tokens_per = None
        else:
            usd_per = stats["usd"] / denom if stats["usd"] else 0.0
            tokens_per = stats["tokens"] / denom if stats["tokens"] else 0.0
        rows.append(
            {
                "key": key,
                "usd": stats["usd"],
                "tokens": stats["tokens"],
                "denominator": denom,
                "usd_per_unit": usd_per,
                "tokens_per_unit": tokens_per,
            }
        )
    rows.sort(key=lambda item: (-item["usd"], -item["tokens"], item["key"]))
    return {
        "group_by": group_by or "all",
        "metric": metric,
        "groups": rows,
        "totals": _round_totals(totals),
    }


def generate_zombie_report(
    path: str,
    *,
    trigger_threshold: int = 3,
    error_threshold: int = 3,
    spend_threshold: float = 5.0,
    min_steps: int = 20,
    filters: Mapping[str, str] | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
) -> dict[str, Any]:
    context = _RunContext()
    runs: dict[str, dict[str, Any]] = defaultdict(_new_run_state)
    for line_no, event in enumerate(iter_events(path), 1):
        if event.get("event_type") == "run":
            context.handle_run_event(event)
            run_id = context.current_run_id(event)
            data = runs[run_id]
            meta = event.get("meta") or {}
            status = meta.get("status")
            if status is not None:
                data["status"] = status
            continue
        run_id = context.current_run_id(event)
        tags = event.get("tags") or {}
        if not _event_in_scope(event, tags, context, filters, start_time, end_time, run_id):
            continue
        data = runs[run_id]
        etype = event.get("event_type")
        if etype == "step":
            data["steps"] += 1
            tokens = event.get("tokens_total")
            if tokens is not None:
                data["tokens"] += int(tokens)
            cost = event.get("cost_usd")
            if cost is not None:
                data["usd"] += float(cost)
            status = str(tags.get("status", "")).lower()
            if status in {"error", "timeout", "fail"}:
                data["tool_errors"] += 1
                data["tool_error_events"].append(
                    {
                        "line": line_no,
                        "timestamp": event.get("timestamp"),
                        "step_id": event.get("step_id"),
                        "status": status,
                    }
                )
            data["step_evidence"].append(
                {
                    "line": line_no,
                    "timestamp": event.get("timestamp"),
                    "step_id": event.get("step_id"),
                    "usd": cost,
                    "tokens_total": tokens,
                }
            )
        elif etype == "trigger":
            detector = event.get("detector") or "unknown"
            if detector == data["current_trigger"]:
                data["current_streak"] += 1
            else:
                data["current_trigger"] = detector
                data["current_streak"] = 1
            data["max_streak"] = max(data["max_streak"], data["current_streak"])
            data["trigger_counts"][detector] += 1
            data["trigger_events"].append(
                {
                    "line": line_no,
                    "timestamp": event.get("timestamp"),
                    "detector": detector,
                    "severity": event.get("severity"),
                    "related_step_ids": list(event.get("related_step_ids") or []),
                }
            )
        elif etype == "intervention":
            data["interventions"] += 1
    incidents: list[dict[str, Any]] = []
    for run_id, data in runs.items():
        completed = str(data.get("status") or "").lower() in {"completed", "success"}
        if data["max_streak"] >= trigger_threshold and data["interventions"] == 0:
            incidents.append(
                _build_incident(
                    run_id,
                    "repeated_triggers",
                    data,
                    evidence={
                        "trigger_events": data["trigger_events"][-trigger_threshold:],
                        "interventions": data["interventions"],
                    },
                    extra={
                        "detector": data["current_trigger"],
                        "max_streak": data["max_streak"],
                    },
                )
            )
        if data["tool_errors"] >= error_threshold:
            incidents.append(
                _build_incident(
                    run_id,
                    "tool_failure_storm",
                    data,
                    evidence={"tool_errors": data["tool_error_events"]},
                    extra={"tool_errors": data["tool_errors"]},
                )
            )
        if data["usd"] >= spend_threshold and not completed:
            incidents.append(
                _build_incident(
                    run_id,
                    "high_spend_incomplete",
                    data,
                    evidence={"steps": data["step_evidence"][-3:]},
                    extra={"usd": data["usd"], "status": data.get("status")},
                )
            )
        if data["steps"] >= min_steps and data["interventions"] == 0:
            incidents.append(
                _build_incident(
                    run_id,
                    "no_intervention_long_run",
                    data,
                    evidence={"steps": data["step_evidence"][:3]},
                    extra={"steps": data["steps"]},
                )
            )
    incidents.sort(key=lambda inc: (-inc["details"].get("usd", 0.0), inc["run_id"], inc["reason"]))
    return {
        "runs_evaluated": len(runs),
        "thresholds": {
            "trigger_threshold": trigger_threshold,
            "error_threshold": error_threshold,
            "spend_threshold": spend_threshold,
            "min_steps": min_steps,
        },
        "incidents": incidents,
    }


def _aggregate_spend(
    path: str,
    group_by: str | None,
    *,
    filters: Mapping[str, str] | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    context = _RunContext()
    groups: dict[str, dict[str, Any]] = defaultdict(lambda: {"tokens": 0, "usd": 0.0, "steps": 0})
    totals = {"tokens": 0, "usd": 0.0, "steps": 0}
    for event in iter_events(path):
        if event.get("event_type") == "run":
            context.handle_run_event(event)
            continue
        if event.get("event_type") != "step":
            continue
        tags = event.get("tags") or {}
        run_id = context.current_run_id(event)
        if not _event_in_scope(event, tags, context, filters, start_time, end_time, run_id):
            continue
        key = _resolve_group_key(group_by, event, tags, context, run_id)
        stats = groups[key]
        tokens = event.get("tokens_total")
        if tokens is not None:
            stats["tokens"] += int(tokens)
            totals["tokens"] += int(tokens)
        cost = event.get("cost_usd")
        if cost is not None:
            stats["usd"] += float(cost)
            totals["usd"] += float(cost)
        stats["steps"] += 1
        totals["steps"] += 1
    return groups, totals


def _resolve_group_key(
    group_by: str | None,
    event: Mapping[str, Any],
    tags: Mapping[str, Any],
    context: _RunContext,
    run_id: str,
) -> str:
    if not group_by or group_by == "all":
        return "all"
    if group_by in {"run", "run_id"}:
        return run_id
    if group_by == "model":
        return str(event.get("model") or "(unknown)")
    value = context.resolve_tag(group_by, tags)
    if value is None:
        value = tags.get(group_by)
    return str(value) if value not in {None, ""} else "(unknown)"


def _sort_and_limit(
    groups: Mapping[str, Mapping[str, Any]], limit: int | None
) -> list[dict[str, Any]]:
    entries = [{"key": key, **stats} for key, stats in groups.items()]
    entries.sort(key=lambda item: (-item["usd"], -item["tokens"], item["key"]))
    if limit and limit > 0 and len(entries) > limit:
        top = entries[:limit]
        others_stats = {"key": "others", "tokens": 0, "usd": 0.0, "steps": 0, "tool_calls": 0}
        for item in entries[limit:]:
            others_stats["tokens"] += item.get("tokens", 0)
            others_stats["usd"] += item.get("usd", 0.0)
            others_stats["steps"] += item.get("steps", 0)
            others_stats["tool_calls"] += item.get("tool_calls", 0)
        return top + [others_stats]
    return entries


def _round_totals(totals: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "tokens": int(totals.get("tokens", 0)),
        "usd": float(totals.get("usd", 0.0)),
        "steps": int(totals.get("steps", 0)),
        "tool_calls": int(totals.get("tool_calls", 0)),
    }


def _new_run_state() -> dict[str, Any]:
    return {
        "steps": 0,
        "tokens": 0,
        "usd": 0.0,
        "tool_errors": 0,
        "interventions": 0,
        "trigger_counts": Counter(),
        "current_trigger": None,
        "current_streak": 0,
        "max_streak": 0,
        "status": None,
        "trigger_events": [],
        "tool_error_events": [],
        "step_evidence": [],
    }


def _event_in_scope(
    event: Mapping[str, Any],
    tags: Mapping[str, Any],
    context: _RunContext,
    filters: Mapping[str, str] | None,
    start_time: datetime | None,
    end_time: datetime | None,
    run_id: str,
) -> bool:
    if start_time or end_time:
        timestamp = _parse_event_timestamp(event.get("timestamp"))
        if not _timestamp_in_range(timestamp, start_time, end_time):
            return False
    if not filters:
        return True
    for key, expected in filters.items():
        candidate = _resolve_filter_value(key, event, tags, context, run_id)
        if candidate is None:
            return False
        if str(candidate) != expected:
            return False
    return True


def _parse_event_timestamp(raw: Any) -> datetime | None:
    if not raw:
        return None
    if isinstance(raw, datetime):
        return raw
    text = str(raw)
    normalized = text.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _timestamp_in_range(
    timestamp: datetime | None,
    start_time: datetime | None,
    end_time: datetime | None,
) -> bool:
    if timestamp is None:
        return False if start_time or end_time else True
    if start_time and timestamp < start_time:
        return False
    if end_time and timestamp > end_time:
        return False
    return True


def _resolve_filter_value(
    key: str,
    event: Mapping[str, Any],
    tags: Mapping[str, Any],
    context: _RunContext,
    run_id: str,
) -> Any:
    if key == "run_id":
        return run_id
    if key == "event_type":
        return event.get("event_type")
    if key in event:
        return event[key]
    candidate = tags.get(key)
    if candidate is not None:
        return candidate
    return context.resolve_tag(key, tags)


def _build_incident(
    run_id: str,
    reason: str,
    data: Mapping[str, Any],
    *,
    evidence: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    details = {
        "steps": data.get("steps", 0),
        "usd": data.get("usd", 0.0),
        "tokens": data.get("tokens", 0),
        "status": data.get("status"),
    }
    if extra:
        details.update(extra)
    payload = {
        "run_id": run_id,
        "reason": reason,
        "details": details,
    }
    if evidence:
        payload["evidence"] = evidence
    return payload


class _HealthAggregator:
    def __init__(self) -> None:
        self._series: list[tuple[str | None, float]] = []
        self._deltas: list[float] = []
        self._status_counts: Counter[str] = Counter()

    def record_step(self, event: Mapping[str, Any]) -> None:
        value = _coerce_float(event.get("d_h"))
        if value is None:
            return
        timestamp = _normalize_timestamp(event.get("timestamp"))
        self._series.append((timestamp, value))

    def record_intervention(self, event: Mapping[str, Any]) -> None:
        if not _is_intervention_outcome(event):
            return
        outcome = event.get("outcome") or {}
        delta = _coerce_float(outcome.get("delta_dh"))
        if delta is None:
            return
        self._deltas.append(delta)
        status = _extract_status(event, outcome)
        if status:
            self._status_counts[status] += 1

    def payload(self) -> dict[str, Any]:
        return {
            "d_h_trend": self._trend_payload(),
            "intervention_effect_size": self._effect_payload(),
        }

    def _trend_payload(self) -> dict[str, Any]:
        if not self._series:
            return {"samples": 0}
        values = [value for _, value in self._series]
        samples = len(values)
        sorted_values = sorted(values)
        payload: dict[str, Any] = {
            "samples": samples,
            "start": _point_payload(self._series[0]),
            "end": _point_payload(self._series[-1]),
            "delta": values[-1] - values[0],
            "mean": sum(values) / samples,
            "median": _median(sorted_values),
            "p90": _percentile(sorted_values, 0.9),
        }
        min_index = min(range(samples), key=lambda idx: values[idx])
        max_index = max(range(samples), key=lambda idx: values[idx])
        payload["min"] = _point_payload(self._series[min_index])
        payload["max"] = _point_payload(self._series[max_index])
        return payload

    def _effect_payload(self) -> dict[str, Any]:
        if not self._deltas:
            return {"samples": 0}
        deltas = sorted(self._deltas)
        samples = len(deltas)
        improved = sum(1 for value in deltas if value > 0)
        worsened = sum(1 for value in deltas if value < 0)
        payload: dict[str, Any] = {
            "samples": samples,
            "mean_delta": sum(deltas) / samples,
            "median_delta": _median(deltas),
            "p90_delta": _percentile(deltas, 0.9),
            "largest_recovery": deltas[-1],
            "largest_regression": deltas[0],
            "improved_fraction": improved / samples,
            "worsened_fraction": worsened / samples,
        }
        if self._status_counts:
            payload["status_breakdown"] = dict(self._status_counts)
        return payload


def _extract_status(event: Mapping[str, Any], outcome: Mapping[str, Any]) -> str | None:
    candidate: Any | None = None
    tags = event.get("tags")
    if isinstance(tags, Mapping):
        candidate = tags.get("status")
    if candidate is None and isinstance(outcome, Mapping):
        candidate = outcome.get("status")
    if candidate is None:
        return None
    text = str(candidate).strip().lower()
    return text or None


def _normalize_timestamp(raw: Any) -> str | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        return raw
    return str(raw)


def _point_payload(entry: tuple[str | None, float]) -> dict[str, Any]:
    timestamp, value = entry
    return {"timestamp": timestamp, "d_h": value}


def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _median(sorted_values: list[float]) -> float:
    if not sorted_values:
        return 0.0
    n = len(sorted_values)
    mid = n // 2
    if n % 2 == 1:
        return sorted_values[mid]
    return (sorted_values[mid - 1] + sorted_values[mid]) / 2.0


def _percentile(sorted_values: list[float], fraction: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    fraction = min(max(fraction, 0.0), 1.0)
    position = fraction * (len(sorted_values) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


def _is_intervention_outcome(event: Mapping[str, Any]) -> bool:
    params = event.get("parameters")
    if isinstance(params, Mapping):
        phase = params.get("phase")
        if phase is not None:
            return str(phase).strip().lower() == "outcome"
    name = event.get("intervention_type")
    if isinstance(name, str):
        return name.upper().endswith("_OUTCOME")
    return False
