"""Report profiles and JSON schema helpers for CLI reports."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

Schema = Mapping[str, Any]


@dataclass(frozen=True)
class ReportProfile:
    name: str
    description: str
    schema: Schema


HEALTH_POINT_SCHEMA: Schema = {
    "type": "object",
    "required": ["d_h"],
    "properties": {
        "timestamp": {"type": ["string", "null"]},
        "d_h": {"type": "number"},
    },
}


D_H_TREND_SCHEMA: Schema = {
    "type": "object",
    "required": ["samples"],
    "properties": {
        "samples": {"type": "integer"},
        "start": HEALTH_POINT_SCHEMA,
        "end": HEALTH_POINT_SCHEMA,
        "delta": {"type": "number"},
        "mean": {"type": "number"},
        "median": {"type": "number"},
        "p90": {"type": "number"},
        "min": HEALTH_POINT_SCHEMA,
        "max": HEALTH_POINT_SCHEMA,
    },
}


INTERVENTION_EFFECT_SCHEMA: Schema = {
    "type": "object",
    "required": ["samples"],
    "properties": {
        "samples": {"type": "integer"},
        "mean_delta": {"type": "number"},
        "median_delta": {"type": "number"},
        "p90_delta": {"type": "number"},
        "largest_recovery": {"type": "number"},
        "largest_regression": {"type": "number"},
        "improved_fraction": {"type": "number"},
        "worsened_fraction": {"type": "number"},
        "status_breakdown": {
            "type": "object",
            "additionalProperties": {"type": "integer"},
        },
    },
}


HEALTH_SECTION_SCHEMA: Schema = {
    "type": "object",
    "required": ["d_h_trend", "intervention_effect_size"],
    "properties": {
        "d_h_trend": D_H_TREND_SCHEMA,
        "intervention_effect_size": INTERVENTION_EFFECT_SCHEMA,
    },
}


SPEND_REPORT_SCHEMA: Schema = {
    "type": "object",
    "required": ["group_by", "totals", "groups", "health"],
    "properties": {
        "group_by": {"type": "string"},
        "totals": {
            "type": "object",
            "required": ["tokens", "usd", "steps", "tool_calls"],
            "properties": {
                "tokens": {"type": "integer"},
                "usd": {"type": "number"},
                "steps": {"type": "integer"},
                "tool_calls": {"type": "integer"},
            },
        },
        "groups": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["key", "tokens", "usd", "steps", "tool_calls"],
                "properties": {
                    "key": {"type": "string"},
                    "tokens": {"type": "integer"},
                    "usd": {"type": "number"},
                    "steps": {"type": "integer"},
                    "tool_calls": {"type": "integer"},
                },
            },
        },
        "health": HEALTH_SECTION_SCHEMA,
    },
}


UNIT_ECON_REPORT_SCHEMA: Schema = {
    "type": "object",
    "required": ["group_by", "metric", "totals", "groups"],
    "properties": {
        "group_by": {"type": "string"},
        "metric": {"type": "string"},
        "totals": {
            "type": "object",
            "required": ["tokens", "usd", "steps"],
            "properties": {
                "tokens": {"type": "integer"},
                "usd": {"type": "number"},
                "steps": {"type": "integer"},
            },
        },
        "groups": {
            "type": "array",
            "items": {
                "type": "object",
                "required": [
                    "key",
                    "tokens",
                    "usd",
                    "denominator",
                    "usd_per_unit",
                    "tokens_per_unit",
                ],
                "properties": {
                    "key": {"type": "string"},
                    "tokens": {"type": "integer"},
                    "usd": {"type": "number"},
                    "denominator": {"type": "number"},
                    "usd_per_unit": {"type": ["number", "null"]},
                    "tokens_per_unit": {"type": ["number", "null"]},
                },
            },
        },
    },
}


ZOMBIE_REPORT_SCHEMA: Schema = {
    "type": "object",
    "required": ["runs_evaluated", "thresholds", "incidents"],
    "properties": {
        "runs_evaluated": {"type": "integer"},
        "thresholds": {
            "type": "object",
            "required": [
                "trigger_threshold",
                "error_threshold",
                "spend_threshold",
                "min_steps",
            ],
            "properties": {
                "trigger_threshold": {"type": "integer"},
                "error_threshold": {"type": "integer"},
                "spend_threshold": {"type": "number"},
                "min_steps": {"type": "integer"},
            },
        },
        "incidents": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["run_id", "reason", "details", "evidence"],
                "properties": {
                    "run_id": {"type": "string"},
                    "reason": {"type": "string"},
                    "details": {"type": "object"},
                    "evidence": {"type": "object"},
                },
            },
        },
    },
}


REPORT_PROFILES: dict[str, ReportProfile] = {
    "spend": ReportProfile(
        name="spend",
        description="Spend aggregation grouped by a tag or field.",
        schema=SPEND_REPORT_SCHEMA,
    ),
    "unit_econ": ReportProfile(
        name="unit_econ",
        description="Unit economics (cost per task/user/revenue).",
        schema=UNIT_ECON_REPORT_SCHEMA,
    ),
    "zombie": ReportProfile(
        name="zombie",
        description="Zombie spend and incident detection.",
        schema=ZOMBIE_REPORT_SCHEMA,
    ),
}


def get_report_profile(name: str) -> ReportProfile:
    key = name.lower()
    if key not in REPORT_PROFILES:
        raise KeyError(f"Unknown report profile '{name}'")
    return REPORT_PROFILES[key]


def validate_report_payload(name: str, payload: Mapping[str, Any]) -> None:
    profile = get_report_profile(name)
    _validate_schema(profile.schema, payload)


def _validate_schema(schema: Mapping[str, Any], data: Any, path: str = "$") -> None:
    expected_type = schema.get("type")
    if isinstance(expected_type, list):
        if not any(_matches_type(t, data) for t in expected_type):
            raise ValueError(f"{path}: expected one of {expected_type}, got {type(data).__name__}")
    elif expected_type:
        if not _matches_type(expected_type, data):
            raise ValueError(f"{path}: expected {expected_type}, got {type(data).__name__}")

    if "enum" in schema and data not in schema["enum"]:
        raise ValueError(f"{path}: value {data!r} not in enum {schema['enum']}")
    if schema.get("type") == "object" and isinstance(data, Mapping):
        required = schema.get("required", [])
        for key in required:
            if key not in data:
                raise ValueError(f"{path}: missing key '{key}'")
        properties = schema.get("properties", {})
        for key, subschema in properties.items():
            if key in data:
                _validate_schema(subschema, data[key], f"{path}.{key}")
    elif schema.get("type") == "array" and isinstance(data, list):
        item_schema = schema.get("items")
        if item_schema:
            for idx, item in enumerate(data):
                _validate_schema(item_schema, item, f"{path}[{idx}]")


def _matches_type(expected: str | None, value: Any) -> bool:
    if expected == "object":
        return isinstance(value, Mapping)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


__all__ = [
    "ReportProfile",
    "REPORT_PROFILES",
    "SPEND_REPORT_SCHEMA",
    "UNIT_ECON_REPORT_SCHEMA",
    "ZOMBIE_REPORT_SCHEMA",
    "get_report_profile",
    "validate_report_payload",
]
