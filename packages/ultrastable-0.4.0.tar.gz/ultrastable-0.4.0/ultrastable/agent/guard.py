from __future__ import annotations

import uuid
from collections.abc import Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from typing import Any, Protocol

from ultrastable.core import Controller, ControllerDecision
from ultrastable.core.events import (
    BaseEvent,
    CostEvent,
    ErrorEvent,
    HealthSnapshotEvent,
    InterventionEvent,
    PolicySwitchEvent,
    RunEvent,
    StepEvent,
    apply_redaction,
)

from .cost import CostModel


@dataclass
class StepMetrics:
    tokens_prompt: int | None = None
    tokens_completion: int | None = None
    tokens_total: int | None = None
    cost_usd: float | None = None
    latency_ms: float | None = None
    retries: int | None = None
    errors: int | None = None
    context_chars: int | None = None


@dataclass
class AgentStepResult:
    """Normalized agent output passed back into the guard."""

    step_id: str
    role: str = "assistant"
    kind: str = "llm"
    model: str | None = None
    prompt_text: str | None = None
    response_text: str | None = None
    tool_name: str | None = None
    tool_args_hash: str | None = None
    tags: Mapping[str, Any] | None = None
    task_signal: float | None = None
    feedback: Mapping[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: AgentStepResult | Mapping[str, Any]) -> AgentStepResult:
        if isinstance(payload, AgentStepResult):
            return payload
        if not isinstance(payload, Mapping):
            raise TypeError("Agent step result must be a mapping or AgentStepResult")
        step_id = str(payload.get("step_id") or "").strip()
        if not step_id:
            raise ValueError("Agent step result requires a non-empty step_id")
        return cls(
            step_id=step_id,
            role=str(payload.get("role") or "assistant"),
            kind=str(payload.get("kind") or "llm"),
            model=payload.get("model"),
            prompt_text=payload.get("prompt_text"),
            response_text=payload.get("response_text"),
            tool_name=payload.get("tool_name"),
            tool_args_hash=payload.get("tool_args_hash"),
            tags=payload.get("tags"),
            task_signal=payload.get("task_signal"),
            feedback=payload.get("feedback"),
        )


class GuardHooks(Protocol):
    def preflight(self, context: Sequence[Mapping[str, Any]] | None) -> None: ...

    def postflight(
        self,
        result: AgentStepResult | Mapping[str, Any],
        metrics: StepMetrics | Mapping[str, Any] | None = None,
    ) -> ControllerDecision: ...

    def on_viability_breach(self, decision: ControllerDecision) -> None: ...


class TelemetrySink(Protocol):
    def start_run(self, run_id: str, policy_hash: str | None) -> None: ...

    def end_run(self, status: str | None) -> None: ...

    def record_snapshot(self, d_h: float | None) -> None: ...

    def record_step_metrics(
        self,
        *,
        tokens_total: float | int | None,
        spend_usd: float | int | None,
        errors: float | int | None = None,
    ) -> None: ...

    def record_trigger_count(self, count: int) -> None: ...

    def record_intervention(self, applied: bool) -> None: ...


class AgentGuard(GuardHooks):
    """Framework-agnostic guard that records steps and drives the controller."""

    def __init__(
        self,
        controller: Controller,
        *,
        ledger: Any | None = None,
        context_budget_chars: int | None = 16000,
        variable_bindings: Mapping[str, str] | None = None,
        accumulate_metrics: Sequence[str] | None = None,
        telemetry: TelemetrySink | None = None,
    ) -> None:
        self.controller = controller
        self.ledger = ledger
        self.context_budget_chars = context_budget_chars
        self.variable_bindings = dict(
            variable_bindings
            or {
                "tokens_prompt": "tokens_prompt",
                "tokens_completion": "tokens_completion",
                "tokens_total": "tokens_total",
                "cost_usd": "spend_usd",
                "latency_ms": "latency_ms",
                "retries": "retries",
                "errors": "errors",
                "context_util": "context_util",
            }
        )
        self.accumulate_metrics = set(
            accumulate_metrics or {"tokens_total", "cost_usd", "retries", "errors"}
        )
        self._accumulators: dict[str, float] = {}
        self._run_id: str | None = None
        self.state: MutableMapping[str, Any] = {"conversation": []}
        self._current_context: list[dict[str, Any]] = []
        self.cost_model = CostModel()
        self._last_snapshot: HealthSnapshotEvent | None = None
        self._telemetry = telemetry

    # Run lifecycle -----------------------------------------------------------------

    def start_run(self, *, run_id: str | None = None, tags: Mapping[str, Any] | None = None) -> str:
        run_id = run_id or str(uuid.uuid4())
        self._run_id = run_id
        metadata = self._controller_metadata()
        policy_version = metadata.get("policy_name", self.controller.policy.__class__.__name__)
        event = RunEvent(
            run_id=run_id,
            phase="start",
            ultrastable_version=None,
            policy_version=policy_version,
            policy_hash=metadata.get("policy_hash"),
            meta=self._build_run_meta(metadata, tags),
        )
        self._emit(event)
        if self._telemetry:
            self._telemetry.start_run(run_id, metadata.get("policy_hash"))
        return run_id

    def end_run(self, *, status: str = "completed", tags: Mapping[str, Any] | None = None) -> None:
        if not self._run_id:
            return
        metadata = self._controller_metadata()
        policy_version = metadata.get("policy_name", self.controller.policy.__class__.__name__)
        event = RunEvent(
            run_id=self._run_id,
            phase="end",
            policy_version=policy_version,
            policy_hash=metadata.get("policy_hash"),
            meta=self._build_run_meta(metadata, tags, status=status),
        )
        self._emit(event)
        if self._telemetry:
            self._telemetry.end_run(status)
        self._run_id = None
        self._last_snapshot = None

    # Step lifecycle ----------------------------------------------------------------

    def preflight(self, context: Sequence[Mapping[str, Any]] | None) -> None:
        """Hook invoked before running an agent iteration."""
        self.pre_step(context)

    def pre_step(self, context: Sequence[Mapping[str, Any]] | None) -> None:
        if context is None:
            return
        sanitized: list[dict[str, Any]] = []
        for entry in context:
            sanitized.append(
                {
                    "id": entry.get("id") or entry.get("message_id"),
                    "role": entry.get("role"),
                    "content": entry.get("content"),
                    "pinned": entry.get("pinned", False),
                    "tags": dict(entry.get("tags") or {}),
                }
            )
        self._current_context = sanitized
        self.state["conversation"] = list(sanitized)

    def postflight(
        self,
        result: AgentStepResult | Mapping[str, Any],
        metrics: StepMetrics | Mapping[str, Any] | None = None,
    ) -> ControllerDecision:
        """Record agent output and propagate through the controller."""
        normalized = AgentStepResult.from_payload(result)
        decision = self.post_step(
            step_id=normalized.step_id,
            role=normalized.role,
            kind=normalized.kind,
            model=normalized.model,
            prompt_text=normalized.prompt_text,
            response_text=normalized.response_text,
            tool_name=normalized.tool_name,
            tool_args_hash=normalized.tool_args_hash,
            metrics=metrics,
            tags=normalized.tags,
            task_signal=normalized.task_signal,
            feedback=normalized.feedback,
        )
        if decision.policy_status in {"warn", "critical"}:
            self.on_viability_breach(decision)
        return decision

    def post_step(
        self,
        *,
        step_id: str,
        role: str,
        kind: str = "llm",
        model: str | None = None,
        prompt_text: str | None = None,
        response_text: str | None = None,
        tool_name: str | None = None,
        tool_args_hash: str | None = None,
        metrics: StepMetrics | Mapping[str, Any] | None = None,
        tags: Mapping[str, Any] | None = None,
        task_signal: float | None = None,
        feedback: Mapping[str, Any] | None = None,
    ) -> ControllerDecision:
        metrics_dict = self._to_metrics(metrics)
        self._apply_task_signal(task_signal=task_signal, feedback=feedback)
        self._update_context_state(step_id, role, prompt_text, response_text, tags)
        self._inject_context_metric(metrics_dict)
        if self._telemetry:
            self._telemetry.record_step_metrics(
                tokens_total=metrics_dict.get("tokens_total"),
                spend_usd=metrics_dict.get("cost_usd"),
                errors=metrics_dict.get("errors"),
            )
        snapshot = self._update_variables_and_snapshot(metrics_dict)
        d_h = self._current_dh(snapshot)
        step_event = StepEvent(
            step_id=step_id,
            role=role,
            kind=kind,
            model=model,
            tool_name=tool_name,
            tool_args_hash=tool_args_hash,
            prompt_text=prompt_text,
            response_text=response_text,
            tokens_prompt=metrics_dict.get("tokens_prompt"),
            tokens_completion=metrics_dict.get("tokens_completion"),
            tokens_total=metrics_dict.get("tokens_total"),
            cost_usd=metrics_dict.get("cost_usd"),
            latency_ms=metrics_dict.get("latency_ms"),
            d_h=d_h,
            tags=dict(tags or {}),
        )
        self._emit(step_event)
        self._emit_cost_event(step_event, metrics_dict)
        self._last_snapshot = snapshot
        if snapshot is not None:
            self._emit(snapshot)
        decision = self.controller.update(step_event, snapshot=snapshot, state=self.state)
        trigger_count = len(decision.triggers)
        if self._telemetry:
            self._telemetry.record_trigger_count(trigger_count)
        for trigger in decision.triggers:
            self._emit(trigger)
        if decision.intervention:
            if decision.intervention.event:
                self._emit(decision.intervention.event)
            if self._telemetry:
                self._telemetry.record_intervention(applied=True)
        for outcome in decision.outcomes:
            self._emit(
                InterventionEvent(
                    intervention_type=f"{outcome.get('intervention_type', 'unknown')}_OUTCOME",
                    parameters={"phase": "outcome"},
                    outcome=dict(outcome),
                    tags={"status": outcome.get("status", "unknown")},
                )
            )
        return decision

    def on_viability_breach(self, decision: ControllerDecision) -> None:
        """Hook invoked when the policy status is warn/critical."""
        # Default implementation intentionally empty.
        return

    def _emit_cost_event(self, step_event: StepEvent, metrics: dict[str, Any]) -> None:
        accounted = self.cost_model.update(
            tokens_prompt=metrics.get("tokens_prompt"),
            tokens_completion=metrics.get("tokens_completion"),
            tokens_total=metrics.get("tokens_total"),
            cost_usd=metrics.get("cost_usd"),
        )
        if accounted is None:
            return
        event = CostEvent(
            step_id=step_event.step_id,
            tokens=accounted.tokens_total,
            usd=accounted.cost_usd,
            tags={"mode": accounted.mode},
        )
        self._emit(event)

    def on_error(
        self,
        error: Exception | str,
        *,
        step_id: str | None = None,
        tags: Mapping[str, Any] | None = None,
    ) -> None:
        message = str(error)
        event = ErrorEvent(
            category="agent_error",
            message=message,
            step_id=step_id,
            tags=dict(tags or {}),
        )
        self._emit(event)

    # Internal helpers --------------------------------------------------------------

    def _to_metrics(self, metrics: StepMetrics | Mapping[str, Any] | None) -> dict[str, Any]:
        if metrics is None:
            return {}
        if isinstance(metrics, StepMetrics):
            return {k: v for k, v in metrics.__dict__.items() if v is not None}
        return {k: v for k, v in metrics.items() if v is not None}

    def _update_context_state(
        self,
        step_id: str,
        role: str,
        prompt_text: str | None,
        response_text: str | None,
        tags: Mapping[str, Any] | None,
    ) -> None:
        conversation = list(self.state.get("conversation") or [])
        if prompt_text:
            conversation.append(
                {
                    "id": f"{step_id}-prompt",
                    "role": "user",
                    "content": prompt_text,
                    "tags": {},
                }
            )
        conversation.append(
            {
                "id": step_id,
                "role": role,
                "content": response_text,
                "tags": dict(tags or {}),
            }
        )
        self.state["conversation"] = conversation

    def _inject_context_metric(self, metrics: dict[str, Any]) -> None:
        if self.context_budget_chars and self.context_budget_chars > 0:
            content = "".join(
                str(msg.get("content", "")) for msg in self.state.get("conversation", [])
            )
            utilization = min(1.0, len(content) / float(self.context_budget_chars))
            metrics["context_util"] = utilization

    def _update_variables_and_snapshot(self, metrics: dict[str, Any]) -> HealthSnapshotEvent | None:
        space = self.controller.policy.space
        updated = False
        for metric, value in metrics.items():
            target = self.variable_bindings.get(metric)
            if not target or target not in space.variables:
                continue
            val = float(value)
            if metric in self.accumulate_metrics:
                acc = self._accumulators.get(target, 0.0) + val
                self._accumulators[target] = acc
                val = acc
            space.set(target, val)
            updated = True
        if not updated:
            return None
        snapshot = space.snapshot(self.controller.policy.health)
        snapshot.tags.setdefault("snapshot_id", str(uuid.uuid4()))
        if self._telemetry:
            self._telemetry.record_snapshot(snapshot.d_h)
        return snapshot

    def _current_dh(self, snapshot: HealthSnapshotEvent | None) -> float | None:
        if snapshot is not None and snapshot.d_h is not None:
            return snapshot.d_h
        _, d_h = self.controller.policy.health.compute(self.controller.policy.space)
        return d_h

    def _emit(self, event: Any) -> None:
        if event is None:
            return
        if isinstance(event, list):
            for e in event:
                self._emit(e)
            return
        if not self.ledger:
            return
        payload = self._redact_for_ledger(event)
        self.ledger.add(payload)

    def _redact_for_ledger(self, event: Any) -> Any:
        mode = self._ledger_redaction_mode()
        if isinstance(event, BaseEvent):
            return event.to_dict(redaction_level=mode)
        if isinstance(event, Mapping):
            payload = dict(event)
            payload.setdefault("redaction_level", mode)
            return apply_redaction(payload, payload["redaction_level"])
        return event

    def _ledger_redaction_mode(self) -> str:
        ledger = self.ledger
        if ledger is None:
            return "metadata-only"
        redaction = getattr(ledger, "redaction", None)
        if callable(redaction):
            try:
                redaction = redaction()
            except TypeError:
                redaction = None
        if isinstance(redaction, str) and redaction:
            return redaction
        return "metadata-only"

    def _apply_task_signal(
        self,
        *,
        task_signal: float | None,
        feedback: Mapping[str, Any] | None,
    ) -> None:
        space = getattr(self.controller.policy, "space", None)
        if not space or not getattr(space, "coupled_variables", None):
            return
        signal = self._extract_task_signal(task_signal, feedback)
        if signal is None:
            signal = 0.0
        dt = self._extract_signal_dt(feedback)
        events = space.step_coupled(signal=signal, dt=dt)
        for event in events:
            self._emit(event)

    def _extract_task_signal(
        self,
        task_signal: float | None,
        feedback: Mapping[str, Any] | None,
    ) -> float | None:
        if task_signal is not None:
            try:
                return float(task_signal)
            except (TypeError, ValueError):
                return None
        if not feedback:
            return None
        for key in ("signal", "score", "value", "reward"):
            if key in feedback and feedback[key] is not None:
                try:
                    return float(feedback[key])
                except (TypeError, ValueError):
                    continue
        return None

    def _extract_signal_dt(self, feedback: Mapping[str, Any] | None) -> float:
        if not feedback:
            return 1.0
        for key in ("dt", "duration"):
            if key in feedback and feedback[key] is not None:
                try:
                    dt = float(feedback[key])
                    return dt if dt >= 0 else 0.0
                except (TypeError, ValueError):
                    continue
        return 1.0

    def _controller_metadata(self, controller: Controller | None = None) -> Mapping[str, Any]:
        ctrl = controller or self.controller
        meta = getattr(ctrl, "policy_metadata", None)
        if isinstance(meta, Mapping):
            return meta
        return {}

    def _build_run_meta(
        self,
        metadata: Mapping[str, Any],
        tags: Mapping[str, Any] | None,
        status: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"tags": dict(tags or {})}
        if status is not None:
            payload["status"] = status
        name = metadata.get("policy_name")
        description = metadata.get("policy_description")
        if name:
            payload["policy_name"] = name
        if description:
            payload["policy_description"] = description
        return payload


@dataclass(frozen=True)
class PolicyBand:
    name: str
    controller: Controller
    enter_dh: float
    exit_dh: float | None = None


class MultiPolicyGuard(AgentGuard):
    """AgentGuard variant that switches between controllers/policies based on health."""

    def __init__(
        self,
        bands: Sequence[PolicyBand],
        *,
        ledger: Any | None = None,
        context_budget_chars: int | None = 16000,
        variable_bindings: Mapping[str, str] | None = None,
        accumulate_metrics: Sequence[str] | None = None,
    ) -> None:
        if not bands:
            raise ValueError("MultiPolicyGuard requires at least one PolicyBand")
        ordered = sorted(bands, key=lambda b: b.enter_dh)
        base = ordered[0]
        space = base.controller.policy.space
        for band in ordered[1:]:
            other_space = band.controller.policy.space
            if other_space is not space:
                raise ValueError("All policy bands must share the same EssentialVariableSpace")
        self._bands = ordered
        self._band_map = {band.name: band for band in ordered}
        self._band_index = {band.name: idx for idx, band in enumerate(ordered)}
        self._active_policy = base.name
        super().__init__(
            controller=base.controller,
            ledger=ledger,
            context_budget_chars=context_budget_chars,
            variable_bindings=variable_bindings,
            accumulate_metrics=accumulate_metrics,
        )

    @property
    def active_policy(self) -> str:
        return self._active_policy

    def post_step(
        self,
        *,
        step_id: str,
        role: str,
        kind: str = "llm",
        model: str | None = None,
        prompt_text: str | None = None,
        response_text: str | None = None,
        tool_name: str | None = None,
        tool_args_hash: str | None = None,
        metrics: StepMetrics | Mapping[str, Any] | None = None,
        tags: Mapping[str, Any] | None = None,
        task_signal: float | None = None,
        feedback: Mapping[str, Any] | None = None,
    ) -> ControllerDecision:
        decision = super().post_step(
            step_id=step_id,
            role=role,
            kind=kind,
            model=model,
            prompt_text=prompt_text,
            response_text=response_text,
            tool_name=tool_name,
            tool_args_hash=tool_args_hash,
            metrics=metrics,
            tags=tags,
            task_signal=task_signal,
            feedback=feedback,
        )
        self._evaluate_policy_switch()
        return decision

    def _evaluate_policy_switch(self) -> None:
        snapshot = self._last_snapshot
        if snapshot is None:
            return
        d_h = snapshot.d_h
        target = self._determine_target_policy(d_h)
        if target != self._active_policy:
            self._switch_policy(target, d_h, reason="d_h_threshold")
            return
        self._maybe_exit_band(d_h)

    def _determine_target_policy(self, d_h: float | None) -> str:
        if d_h is None:
            return self._active_policy
        target = self._bands[0].name
        for band in self._bands:
            if d_h >= band.enter_dh:
                target = band.name
        return target

    def _maybe_exit_band(self, d_h: float | None) -> None:
        current_band = self._band_map[self._active_policy]
        idx = self._band_index[self._active_policy]
        if idx == 0:
            return
        if current_band.exit_dh is None:
            return
        if d_h is None or d_h <= current_band.exit_dh:
            target = self._bands[idx - 1].name
            if target != self._active_policy:
                self._switch_policy(target, d_h, reason="d_h_recovered")

    def _switch_policy(self, name: str, d_h: float | None, reason: str) -> None:
        previous = self._active_policy
        if name == previous:
            return
        band = self._band_map[name]
        self.controller = band.controller
        self._active_policy = name
        metadata = self._controller_metadata()
        event = PolicySwitchEvent(
            from_policy=previous,
            to_policy=name,
            reason=reason,
            d_h=d_h,
            policy_hash=metadata.get("policy_hash"),
            tags={"policy_order": [b.name for b in self._bands]},
        )
        self._emit(event)


__all__ = [
    "AgentGuard",
    "AgentStepResult",
    "MultiPolicyGuard",
    "PolicyBand",
    "StepMetrics",
]
