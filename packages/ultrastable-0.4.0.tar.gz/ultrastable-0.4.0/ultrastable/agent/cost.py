from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CostSnapshot:
    tokens_total: int | None
    cost_usd: float | None
    mode: str


class CostModel:
    """Simple cost accounting model that works with partial telemetry."""

    def __init__(self, *, cost_per_token: float | None = None) -> None:
        self.tokens_total = 0
        self.cost_usd = 0.0
        self.cost_per_token = cost_per_token

    def update(
        self,
        *,
        tokens_prompt: int | None = None,
        tokens_completion: int | None = None,
        tokens_total: int | None = None,
        cost_usd: float | None = None,
    ) -> CostSnapshot | None:
        prompt = tokens_prompt or 0
        completion = tokens_completion or 0
        if tokens_total is not None:
            total = tokens_total
        elif prompt or completion:
            total = prompt + completion
        else:
            total = None

        mode = "reported"
        if total is not None:
            self.tokens_total += total

        if cost_usd is not None:
            self.cost_usd += float(cost_usd)
        elif total is not None and self.cost_per_token is not None:
            self.cost_usd += total * self.cost_per_token
            mode = "estimated"
        elif total is not None:
            mode = "tokens_only"
        else:
            mode = "unknown"

        if total is None and cost_usd is None:
            return None

        return CostSnapshot(
            tokens_total=total,
            cost_usd=self.cost_usd if self.cost_usd else None,
            mode=mode,
        )


__all__ = ["CostModel", "CostSnapshot"]
