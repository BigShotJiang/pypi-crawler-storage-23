from __future__ import annotations

import importlib
import os
import threading
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, cast


def _load_optional_module(name: str) -> Any | None:
    try:  # pragma: no cover - optional dependency
        return importlib.import_module(name)
    except Exception:  # pragma: no cover - optional dependency
        return None


_otel_metrics: Any | None = _load_optional_module("opentelemetry.metrics")
_otel_trace: Any | None = _load_optional_module("opentelemetry.trace")

_OTLP_ENDPOINT_ENV_KEYS = (
    "ULTRASTABLE_OTLP_ENDPOINT",
    "ULTRASTABLE_OTEL_EXPORTER_OTLP_ENDPOINT",
    "OTEL_EXPORTER_OTLP_ENDPOINT",
)
_OTLP_HEADERS_ENV_KEYS = (
    "ULTRASTABLE_OTLP_HEADERS",
    "ULTRASTABLE_OTEL_EXPORTER_OTLP_HEADERS",
    "OTEL_EXPORTER_OTLP_HEADERS",
)
_OTEL_ENV_CONFIGURED = False
_OTEL_ENV_LOCK = threading.Lock()

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from opentelemetry.metrics import Counter, Histogram, Meter
    from opentelemetry.trace import Span, Tracer
else:  # pragma: no cover - runtime fallback without dependency
    Counter = Histogram = Meter = Span = Tracer = Any


def _get_trace_module() -> Any | None:
    global _otel_trace
    if _otel_trace is None:
        _otel_trace = _load_optional_module("opentelemetry.trace")
    return _otel_trace


def _get_metrics_module() -> Any | None:
    global _otel_metrics
    if _otel_metrics is None:
        _otel_metrics = _load_optional_module("opentelemetry.metrics")
    return _otel_metrics


def configure_otel_from_env(*, force: bool = False) -> bool:
    """Configure OTLP exporters when endpoint/headers env vars are set."""

    endpoint = _first_env_value(_OTLP_ENDPOINT_ENV_KEYS)
    if not endpoint:
        return False
    headers = _parse_otlp_headers(_first_env_value(_OTLP_HEADERS_ENV_KEYS))
    with _OTEL_ENV_LOCK:
        global _OTEL_ENV_CONFIGURED
        if _OTEL_ENV_CONFIGURED and not force:
            return True
        configured = _install_otlp_exporters(endpoint, headers)
        _OTEL_ENV_CONFIGURED = configured
        return configured


def _first_env_value(keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = os.getenv(key)
        if value:
            trimmed = value.strip()
            if trimmed:
                return trimmed
    return None


def _parse_otlp_headers(value: str | None) -> dict[str, str]:
    headers: dict[str, str] = {}
    if not value:
        return headers
    for part in value.split(","):
        if not part:
            continue
        key, sep, raw_value = part.partition("=")
        if not sep:
            continue
        key = key.strip()
        if not key:
            continue
        headers[key] = raw_value.strip()
    return headers


def _install_otlp_exporters(endpoint: str, headers: Mapping[str, str]) -> bool:
    trace_api = _get_trace_module()
    metrics_api = _get_metrics_module()
    if trace_api is None and metrics_api is None:
        return False
    try:
        from opentelemetry.sdk.resources import Resource
    except Exception:  # pragma: no cover - optional dependency missing
        return False
    resource = Resource.create({"service.name": "ultrastable.guard"})
    configured = False
    if trace_api is not None:
        configured |= _install_span_exporter(trace_api, resource, endpoint, headers)
    if metrics_api is not None:
        configured |= _install_metric_exporter(metrics_api, resource, endpoint, headers)
    return configured


def _install_span_exporter(
    trace_api: Any,
    resource: Any,
    endpoint: str,
    headers: Mapping[str, str],
) -> bool:
    try:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except Exception:  # pragma: no cover - optional dependency missing
        return False
    setter = getattr(trace_api, "set_tracer_provider", None)
    if not callable(setter):
        return False
    try:
        exporter_headers = dict(headers) if headers else None
        tracer_provider = TracerProvider(resource=resource)
        span_endpoint = _normalize_otlp_http_endpoint(endpoint, signal="traces")
        span_exporter = OTLPSpanExporter(endpoint=span_endpoint, headers=exporter_headers)
        span_processor = BatchSpanProcessor(span_exporter)
        tracer_provider.add_span_processor(span_processor)
        setter(tracer_provider)
        return True
    except Exception:  # pragma: no cover - exporter failures ignored
        return False


def _install_metric_exporter(
    metrics_api: Any,
    resource: Any,
    endpoint: str,
    headers: Mapping[str, str],
) -> bool:
    try:
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    except Exception:  # pragma: no cover - optional dependency missing
        return False
    setter = getattr(metrics_api, "set_meter_provider", None)
    if not callable(setter):
        return False
    try:
        exporter_headers = dict(headers) if headers else None
        metric_endpoint = _normalize_otlp_http_endpoint(endpoint, signal="metrics")
        metric_exporter = OTLPMetricExporter(endpoint=metric_endpoint, headers=exporter_headers)
        reader = PeriodicExportingMetricReader(metric_exporter)
        meter_provider = MeterProvider(resource=resource, metric_readers=[reader])
        setter(meter_provider)
        return True
    except Exception:  # pragma: no cover - exporter failures ignored
        return False


def _normalize_otlp_http_endpoint(endpoint: str, *, signal: str) -> str:
    """Normalize OTLP/HTTP endpoints while preserving explicit "/v1" bases.

    Accepts common forms and returns a stable URL:
      - If endpoint already ends with "/v1/<signal>", return as-is.
      - If endpoint ends with "/v1", preserve exactly (do not append signal).
      - If endpoint contains "/v1/" (e.g., custom or other signal path), return as-is.
      - Otherwise append "/v1/<signal>".
    """
    base = (endpoint or "").strip()
    if not base:
        return base
    base = base.rstrip("/")
    signal_suffix = f"/v1/{signal}"
    if base.endswith(signal_suffix):
        return base
    if base.endswith("/v1"):
        return base
    if "/v1/" in base:
        return base
    return base + signal_suffix


class GuardRunTelemetry:
    """Emit OpenTelemetry spans/metrics for guard runs when available."""

    def __init__(
        self,
        *,
        tracer: Tracer | None = None,
        meter: Meter | None = None,
        span_name: str = "ultrastable.run",
        metric_prefix: str = "ultrastable",
    ) -> None:
        if tracer is None or meter is None:
            configure_otel_from_env()
        self._span_name = span_name
        self._metric_prefix = metric_prefix
        self._tracer: Tracer | None = tracer or self._build_tracer()
        self._meter: Meter | None = meter or self._build_meter()
        self._run_span: Span | None = None
        self._run_attrs: dict[str, str] = {}
        self._d_h_histogram: Histogram | None = self._create_histogram("d_h")
        self._spend_counter: Counter | None = self._create_counter("spend_usd")
        self._tokens_counter: Counter | None = self._create_counter("tokens_total")
        self._trigger_counter: Counter | None = self._create_counter("trigger_count")
        self._step_counter: Counter | None = self._create_counter("step_count")
        self._error_counter: Counter | None = self._create_counter("error_count")
        self._intervention_counter: Counter | None = self._create_counter("intervention_count")

    def start_run(self, run_id: str, policy_hash: str | None) -> None:
        """Start (or reset) the run span and capture immutable attributes."""

        if not run_id:
            return
        attrs = {"run_id": str(run_id)}
        if policy_hash:
            attrs["policy_hash"] = str(policy_hash)
        self._run_attrs = attrs
        if self._run_span is not None:
            self._end_span()
        if self._tracer is None:
            self._run_span = None
            return
        span_kwargs: dict[str, Any] = {}
        span_kind = getattr(_otel_trace, "SpanKind", None)
        if span_kind is not None:
            span_kwargs["kind"] = getattr(span_kind, "INTERNAL", span_kind)
        try:
            self._run_span = self._tracer.start_span(
                self._span_name,
                attributes=self._metric_attributes(),
                **span_kwargs,
            )
        except Exception:  # pragma: no cover - tracer errors ignored
            self._run_span = None

    def end_run(self, status: str | None) -> None:
        """End the active run span and reset run-level attributes."""

        if self._run_span is not None:
            if status:
                self._set_span_attr(self._run_span, "run.status", status)
            self._end_span()
        self._run_attrs = {}

    def record_snapshot(self, d_h: float | int | None) -> None:
        """Record the health distance measurement when a snapshot is emitted."""

        if self._d_h_histogram is None or not self._run_attrs:
            return
        value = self._coerce_float(d_h)
        if value is None or value < 0:
            return
        self._record_histogram(self._d_h_histogram, value)

    def record_step_metrics(
        self,
        *,
        tokens_total: float | int | None,
        spend_usd: float | int | None,
        errors: float | int | None = None,
    ) -> None:
        """Accumulate spend/token counters for each AgentGuard step."""

        if not self._run_attrs:
            return
        if self._step_counter is not None:
            self._add_counter(self._step_counter, 1.0)
        tokens_value = self._coerce_float(tokens_total)
        if tokens_value is not None and tokens_value > 0 and self._tokens_counter is not None:
            self._add_counter(self._tokens_counter, tokens_value)
        spend_value = self._coerce_float(spend_usd)
        if spend_value is not None and spend_value >= 0 and self._spend_counter is not None:
            self._add_counter(self._spend_counter, spend_value)
        errors_value = self._coerce_float(errors)
        if errors_value is not None and errors_value > 0 and self._error_counter is not None:
            self._add_counter(self._error_counter, errors_value)

    def record_trigger_count(self, count: int) -> None:
        """Increment trigger counter per controller decision."""

        if self._trigger_counter is None or not self._run_attrs:
            return
        if count <= 0:
            return
        self._add_counter(self._trigger_counter, float(count))

    def record_intervention(self, applied: bool) -> None:
        """Record when an intervention is applied."""

        if not applied or self._intervention_counter is None or not self._run_attrs:
            return
        self._add_counter(self._intervention_counter, 1.0)

    def _metric_attributes(self) -> dict[str, str]:
        return dict(self._run_attrs)

    def _coerce_float(self, value: float | int | None) -> float | None:
        if value is None:
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _build_tracer(self) -> Tracer | None:
        if _otel_trace is None:
            return None
        getter = getattr(_otel_trace, "get_tracer", None)
        if not callable(getter):
            return None
        try:
            return cast(Tracer, getter("ultrastable.agent"))
        except Exception:  # pragma: no cover - tracer factory failures ignored
            return None

    def _build_meter(self) -> Meter | None:
        if _otel_metrics is None:
            return None
        getter = getattr(_otel_metrics, "get_meter", None)
        if not callable(getter):
            return None
        try:
            return cast(Meter, getter("ultrastable.agent"))
        except Exception:  # pragma: no cover - meter factory failures ignored
            return None

    def _create_histogram(self, name: str) -> Histogram | None:
        if self._meter is None:
            return None
        factory = getattr(self._meter, "create_histogram", None)
        if not callable(factory):
            return None
        metric_name = f"{self._metric_prefix}.{name}"
        try:
            return cast(Histogram, factory(metric_name))
        except Exception:  # pragma: no cover - instrument creation failures ignored
            return None

    def _create_counter(self, name: str) -> Counter | None:
        if self._meter is None:
            return None
        factory = getattr(self._meter, "create_counter", None)
        if not callable(factory):
            return None
        metric_name = f"{self._metric_prefix}.{name}"
        try:
            return cast(Counter, factory(metric_name))
        except Exception:  # pragma: no cover - instrument creation failures ignored
            return None

    def _record_histogram(self, histogram: Histogram, value: float) -> None:
        try:
            histogram.record(value, attributes=self._metric_attributes())
        except Exception:  # pragma: no cover - instrumentation failures ignored
            return

    def _add_counter(self, counter: Counter, value: float) -> None:
        try:
            counter.add(value, attributes=self._metric_attributes())
        except Exception:  # pragma: no cover - instrumentation failures ignored
            return

    def _set_span_attr(self, span: Span, key: str, value: Any) -> None:
        setter = getattr(span, "set_attribute", None)
        if not callable(setter):
            return
        try:
            setter(key, value)
        except Exception:  # pragma: no cover - instrumentation failures ignored
            return

    def _end_span(self) -> None:
        span = self._run_span
        if span is None:
            return
        try:
            span.end()
        except Exception:  # pragma: no cover - instrumentation failures ignored
            pass
        self._run_span = None


__all__ = ["GuardRunTelemetry", "configure_otel_from_env"]
