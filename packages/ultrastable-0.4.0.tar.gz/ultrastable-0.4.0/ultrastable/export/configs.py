from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from ultrastable.policy import POLICY_SCHEMA_VERSION
from ultrastable.reporting.finance import generate_spend_report


def export_routing_policy(
    ledger_path: str | Path,
    *,
    group_by: str | None = "customer",
    limit: int | None = 10,
) -> dict[str, Any]:
    report = generate_spend_report(str(ledger_path), group_by=group_by, limit=limit)
    ledger = Path(ledger_path)
    digest = _ledger_digest(ledger)
    total_usd = report["totals"].get("usd", 0.0) or 0.0
    routes: list[dict[str, Any]] = []
    for idx, group in enumerate(report["groups"], 1):
        usd = float(group.get("usd", 0.0) or 0.0)
        tokens = int(group.get("tokens", 0) or 0)
        share = usd / total_usd if total_usd else 0.0
        routes.append(
            {
                "key": group.get("key", f"group_{idx}"),
                "max_usd": round(usd, 6),
                "max_tokens": tokens,
                "share_weight": round(share, 6),
                "priority": idx,
            }
        )
    return {
        "schema": "ultrastable/export/routing-policy/v1",
        "ledger_path": str(ledger),
        "ledger_sha256": digest,
        "group_by": group_by or "all",
        "routes": routes,
        "totals": report["totals"],
    }


def export_budget_policy(
    ledger_path: str | Path,
    *,
    name: str = "auto_budget_policy",
    description: str | None = None,
    group_by: str | None = "customer",
    limit: int | None = 10,
) -> dict[str, Any]:
    report = generate_spend_report(str(ledger_path), group_by=group_by, limit=limit)
    ledger = Path(ledger_path)
    digest = _ledger_digest(ledger)
    routes = export_routing_policy(ledger_path, group_by=group_by, limit=limit)["routes"]
    max_usd = max((route["max_usd"] for route in routes), default=report["totals"].get("usd", 0.0))
    base_scale = max(1.0, round(max_usd or 1.0, 6))
    hard_limit = round((max_usd or 1.0) * 1.2 + 1e-9, 6)
    policy = {
        "policy_schema_version": POLICY_SCHEMA_VERSION,
        "name": name,
        "description": description or f"Auto-generated budget policy derived from {ledger.name}",
        "policy": {
            "monotonic_warn_fraction": 0.85,
            "bounded_warn_fraction": 0.15,
            "variables": [
                {
                    "name": "spend_usd",
                    "kind": "MONOTONIC",
                    "scale": base_scale,
                    "hard_limit": hard_limit,
                    "tags": {"source": "export_budget_policy"},
                }
            ],
        },
        "detectors": [
            {"kind": "tool_failure"},
            {"kind": "semantic_loop"},
            {"kind": "context_rot"},
        ],
        "interventions": [
            {"kind": "context_prune"},
            {"kind": "backoff"},
            {"kind": "stop_the_line"},
        ],
        "meta": {
            "ledger_path": str(ledger),
            "ledger_sha256": digest,
            "group_by": group_by or "all",
            "budget_routes": routes,
        },
    }
    return policy


def _ledger_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


__all__ = ["export_routing_policy", "export_budget_policy"]
