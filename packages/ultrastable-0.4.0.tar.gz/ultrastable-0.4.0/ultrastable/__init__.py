"""Ultrastable core package.

This package provides stability and guard primitives for AI agents (and optional
robotics/control use) with a minimal core that depends only on NumPy + stdlib.

The top-level package does not import optional extras by default.
"""

from __future__ import annotations

import re
from importlib import metadata as _metadata
from pathlib import Path

__all__ = ["__version__"]


def _version_from_pyproject() -> str | None:
    # Attempt to read version from a nearby pyproject.toml when running from source
    try:
        root = Path(__file__).resolve().parents[1]
        pyproject = root / "pyproject.toml"
        if not pyproject.exists():
            return None
        text = pyproject.read_text(encoding="utf-8")
        # Conservatively extract the [project] section and its version key
        m = re.search(r"(?ms)^\[project\]\n(.*?)(?:^\[|\Z)", text)
        if not m:
            return None
        block = m.group(1)
        vm = re.search(r"(?m)^\s*version\s*=\s*\"([^\"]+)\"\s*$", block)
        if not vm:
            return None
        return vm.group(1)
    except Exception:
        return None


def _get_version() -> str:
    # Prefer source version when running from a checkout to keep tests stable
    src_version = _version_from_pyproject()
    if src_version:
        return src_version
    try:
        return _metadata.version("ultrastable")
    except _metadata.PackageNotFoundError:
        # Fallback for editable or source tree without installed metadata
        return "0.4.0"


__version__ = _get_version()
