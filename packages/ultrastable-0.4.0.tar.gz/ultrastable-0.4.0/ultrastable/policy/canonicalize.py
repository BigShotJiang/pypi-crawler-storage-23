"""Deterministic PolicyPack canonicalization and hashing."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any

from .model import (
    DEFAULT_SCHEMA_VERSION,
    FLOAT_PRECISION,
    LEGACY_POLICY_SCHEMA_VERSIONS,
    POLICY_SCHEMA_VERSION,
    SUPPORTED_POLICY_SCHEMA_VERSIONS,
)
from .validate import PolicyPackError


def upgrade_policy_document(doc: Mapping[str, Any]) -> dict[str, Any]:
    """Return a copy of the policy document upgraded to the latest schema version."""
    if not isinstance(doc, Mapping):
        raise PolicyPackError("policy pack must be a mapping")
    upgraded: dict[str, Any] = dict(doc)
    raw_version = upgraded.get("policy_schema_version")
    version = ""
    if raw_version is not None:
        version = str(raw_version).strip()
    if not version or version in LEGACY_POLICY_SCHEMA_VERSIONS:
        version = POLICY_SCHEMA_VERSION
    elif version not in SUPPORTED_POLICY_SCHEMA_VERSIONS:
        supported = ", ".join(sorted(SUPPORTED_POLICY_SCHEMA_VERSIONS))
        raise PolicyPackError(
            f"Unsupported policy_schema_version '{version}'. Supported versions: {supported}"
        )
    upgraded["policy_schema_version"] = version
    return upgraded


def canonicalize_policy(obj: Mapping[str, Any]) -> dict[str, Any]:
    """Return a deterministic policy pack dict with defaults applied."""
    upgraded = upgrade_policy_document(obj)
    schema_version = str(upgraded.get("schema_version") or DEFAULT_SCHEMA_VERSION)
    name = str(upgraded.get("name") or "default")
    description = str(upgraded.get("description") or "")
    meta = _canonical_tree(upgraded.get("meta") or {})
    controller = _canonicalize_controller(upgraded.get("controller"))
    policy = _canonicalize_policy(upgraded.get("policy"))
    detectors = _canonicalize_components(upgraded.get("detectors"), section="detectors")
    interventions = _canonicalize_components(upgraded.get("interventions"), section="interventions")
    canonical = {
        "schema_version": schema_version,
        "policy_schema_version": upgraded["policy_schema_version"],
        "name": name,
        "description": description,
        "controller": controller,
        "policy": policy,
        "detectors": detectors,
        "interventions": interventions,
        "meta": meta,
    }
    return canonical


def hash_canonical(canonical: Mapping[str, Any]) -> str:
    payload = json.dumps(
        canonical,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def policy_hash(pack: Mapping[str, Any]) -> str:
    """Compute the SHA-256 hash of the canonical JSON bytes."""
    canonical = canonicalize_policy(pack)
    return hash_canonical(canonical)


def _canonicalize_controller(obj: Mapping[str, Any] | None) -> dict[str, Any]:
    defaults = {"step_window": 20, "snapshot_window": 5, "cooldown_steps": 3}
    data = dict(obj or {})
    step_window = _canonical_int(data.get("step_window", defaults["step_window"]), minimum=1)
    snapshot_window = _canonical_int(
        data.get("snapshot_window", defaults["snapshot_window"]), minimum=1
    )
    cooldown_steps = _canonical_int(
        data.get("cooldown_steps", defaults["cooldown_steps"]), minimum=0
    )
    eta_value = _canonical_float(data.get("eta"), default=1.0)
    eta = eta_value if eta_value is not None else 1.0
    if eta < 1.0:
        raise PolicyPackError("controller.eta must be >= 1.0")
    allowed_keys = {"step_window", "snapshot_window", "cooldown_steps", "eta"}
    extra_keys = sorted(set(data) - allowed_keys)
    if extra_keys:
        raise PolicyPackError(f"Unsupported controller keys: {', '.join(extra_keys)}")
    return {
        "step_window": step_window,
        "snapshot_window": snapshot_window,
        "cooldown_steps": cooldown_steps,
        "eta": eta,
    }


def _canonicalize_policy(obj: Mapping[str, Any] | None) -> dict[str, Any]:
    if not isinstance(obj, Mapping):
        raise PolicyPackError("policy section is required")
    data = dict(obj)
    variables = data.get("variables")
    if not isinstance(variables, Sequence) or not variables:
        raise PolicyPackError("policy.variables must be a non-empty list")
    canonical = {
        "health": _canonicalize_health(data.get("health")),
        "warn_threshold": _canonical_float(data.get("warn_threshold"), allow_none=True),
        "critical_threshold": _canonical_float(data.get("critical_threshold"), allow_none=True),
        "monotonic_warn_fraction": _canonical_float(
            data.get("monotonic_warn_fraction"), default=0.9
        ),
        "bounded_warn_fraction": _canonical_float(data.get("bounded_warn_fraction"), default=0.1),
        "setpoint_warn_mult": _canonical_float(data.get("setpoint_warn_mult"), default=1.0),
        "setpoint_critical_mult": _canonical_float(data.get("setpoint_critical_mult"), default=2.0),
        "variables": _canonicalize_variables(variables),
        "coupled_variables": _canonicalize_coupled(data.get("coupled_variables")),
    }
    extra_keys = sorted(
        set(data)
        - {
            "health",
            "warn_threshold",
            "critical_threshold",
            "monotonic_warn_fraction",
            "bounded_warn_fraction",
            "setpoint_warn_mult",
            "setpoint_critical_mult",
            "variables",
            "coupled_variables",
        }
    )
    if extra_keys:
        raise PolicyPackError(f"Unsupported policy keys: {', '.join(extra_keys)}")
    return canonical


def _canonicalize_health(value: Any) -> dict[str, Any]:
    if value is None:
        metric = "l2"
    elif isinstance(value, str):
        metric = value
    elif isinstance(value, Mapping):
        metric = value.get("metric", "l2")
    else:
        raise PolicyPackError("policy.health must be a string or mapping")
    metric = str(metric).lower()
    if metric not in {"l1", "l2", "linf"}:
        raise PolicyPackError(f"Unsupported health metric '{metric}'")
    return {"metric": metric}


def _canonicalize_variables(raw: Sequence[Any]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    canonical: list[dict[str, Any]] = []
    for idx, item in enumerate(raw):
        if not isinstance(item, Mapping):
            raise PolicyPackError(f"variable #{idx} must be a mapping")
        name = str(item.get("name") or "").strip()
        if not name:
            raise PolicyPackError("variable name is required")
        if name in seen:
            raise PolicyPackError(f"duplicate variable '{name}'")
        seen.add(name)
        kind = str(item.get("kind") or "").upper()
        if kind not in {"SETPOINT", "BOUNDED", "MONOTONIC"}:
            raise PolicyPackError(f"variable '{name}' has unsupported kind '{kind}'")
        tags = _canonical_tree(item.get("tags") or {})
        scale = _canonical_float(item.get("scale"))
        weight = _canonical_float(item.get("weight"), default=1.0)
        hysteresis = _canonical_float(item.get("hysteresis"), default=0.0)
        entry = {
            "name": name,
            "kind": kind,
            "scale": scale,
            "weight": weight,
            "hysteresis": hysteresis,
            "tags": tags,
            "target": _canonical_float(item.get("target"), allow_none=True),
            "tolerance": _canonical_float(item.get("tolerance"), allow_none=True),
            "min": _canonical_float(item.get("min"), allow_none=True),
            "max": _canonical_float(item.get("max"), allow_none=True),
            "hard_limit": _canonical_float(item.get("hard_limit"), allow_none=True),
        }
        _validate_variable_required_fields(entry)
        canonical.append(entry)
    canonical.sort(key=lambda v: v["name"])
    return canonical


def _validate_variable_required_fields(entry: Mapping[str, Any]) -> None:
    kind = entry["kind"]
    name = entry["name"]
    if entry["scale"] is None:
        raise PolicyPackError(f"variable '{name}' requires scale")
    if kind == "SETPOINT":
        if entry["target"] is None or entry["tolerance"] is None:
            raise PolicyPackError(f"SETPOINT variable '{name}' requires target/tolerance")
    elif kind == "BOUNDED":
        if entry["min"] is None or entry["max"] is None:
            raise PolicyPackError(f"BOUNDED variable '{name}' requires min/max")
    else:
        if entry["hard_limit"] is None:
            raise PolicyPackError(f"MONOTONIC variable '{name}' requires hard_limit")


def _canonicalize_coupled(entries: Any) -> list[dict[str, Any]]:
    if not entries:
        return []
    if not isinstance(entries, Sequence):
        raise PolicyPackError("policy.coupled_variables must be a list")
    output: list[dict[str, Any]] = []
    for idx, item in enumerate(entries):
        if not isinstance(item, Mapping):
            raise PolicyPackError(f"coupled variable #{idx} must be a mapping")
        name = str(item.get("name") or "").strip()
        if not name:
            raise PolicyPackError("coupled variable name is required")
        decay = _canonical_float(item.get("decay"), default=0.1)
        coupling = item.get("coupling")
        if not isinstance(coupling, Mapping):
            raise PolicyPackError("coupling entry must be a mapping")
        func = str(coupling.get("func") or "").strip().lower()
        params = _canonical_tree(coupling.get("params") or {})
        output.append(
            {
                "name": name,
                "decay": decay,
                "min_value": _canonical_float(item.get("min_value"), default=0.0),
                "max_value": _canonical_float(item.get("max_value"), default=1.0),
                "coupling": {"func": func, "params": params},
            }
        )
    output.sort(key=lambda v: v["name"])
    return output


def _canonicalize_components(entries: Any, *, section: str) -> list[dict[str, Any]]:
    if entries is None:
        return []
    if not isinstance(entries, Sequence):
        raise PolicyPackError(f"{section} must be a list")
    canonical: list[dict[str, Any]] = []
    seen: set[tuple[str, str | None]] = set()
    for idx, item in enumerate(entries):
        if not isinstance(item, Mapping):
            raise PolicyPackError(f"{section} entry #{idx} must be a mapping")
        kind = str(item.get("kind") or "").strip()
        if not kind:
            raise PolicyPackError(f"{section} entry #{idx} missing kind")
        label = str(item.get("name") or "").strip() or None
        dedupe_key = (kind, label)
        if dedupe_key in seen:
            raise PolicyPackError(f"duplicate entry '{kind}' in {section}")
        seen.add(dedupe_key)
        entry = {
            "kind": kind,
            "name": label,
            "params": _canonical_tree(item.get("params") or {}),
        }
        canonical.append(entry)
    canonical.sort(
        key=lambda e: (e["kind"], e["name"] or "", json.dumps(e["params"], sort_keys=True))
    )
    return canonical


def _canonical_tree(value: Any) -> Any:
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key in sorted(value, key=lambda k: str(k)):
            result[str(key)] = _canonical_tree(value[key])
        return result
    if isinstance(value, (list, tuple, set)):
        return [_canonical_tree(v) for v in value]
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        return _round_float(value)
    if isinstance(value, str):
        return value
    if isinstance(value, Decimal):
        return _round_float(float(value))
    raise PolicyPackError(f"Unsupported value type {type(value)!r} in params")


def _canonical_int(value: Any, *, minimum: int | None = None) -> int:
    if value is None:
        raise PolicyPackError("integer value is required")
    if isinstance(value, bool):
        raise PolicyPackError("boolean cannot be used where int required")
    try:
        num = int(value)
    except (TypeError, ValueError):
        raise PolicyPackError(f"invalid integer value {value!r}") from None
    if minimum is not None and num < minimum:
        raise PolicyPackError(f"value {num} must be >= {minimum}")
    return num


def _canonical_float(
    value: Any,
    *,
    default: float | None = None,
    allow_none: bool = False,
) -> float | None:
    if value is None:
        if default is not None:
            return _round_float(float(default))
        if allow_none:
            return None
        raise PolicyPackError("floating-point value is required")
    if isinstance(value, bool):
        raise PolicyPackError("boolean cannot be used where float required")
    try:
        num = float(value)
    except (TypeError, ValueError):
        raise PolicyPackError(f"invalid float value {value!r}") from None
    return _round_float(num)


def _round_float(value: float) -> float:
    dec = Decimal(str(value))
    quant = Decimal("1").scaleb(-FLOAT_PRECISION)
    rounded = dec.quantize(quant, rounding=ROUND_HALF_EVEN)
    normalized = rounded.normalize()
    try:
        return float(normalized)
    except (OverflowError, ValueError):
        return float(rounded)


__all__ = ["canonicalize_policy", "policy_hash", "upgrade_policy_document", "hash_canonical"]
