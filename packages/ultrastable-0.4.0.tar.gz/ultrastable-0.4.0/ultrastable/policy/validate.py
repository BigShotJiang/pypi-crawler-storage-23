"""Semantic validation helpers for PolicyPack documents."""

from __future__ import annotations


class PolicyPackError(ValueError):
    """Raised when a policy pack definition is invalid."""


__all__ = ["PolicyPackError"]
