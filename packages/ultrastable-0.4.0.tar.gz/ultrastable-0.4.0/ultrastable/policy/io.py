"""PolicyPack load/save helpers."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ultrastable.core.coupling.registry import CouplingRegistry
from ultrastable.detectors.registry import DetectorRegistry
from ultrastable.interventions.registry import InterventionRegistry

from .build import build_controller_from_pack
from .canonicalize import upgrade_policy_document
from .model import LoadedPolicyPack


def load_policy_document(path: str | Path) -> Mapping[str, Any]:
    source = Path(path)
    text = source.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Policy packs must be JSON. Failed to parse {source}: {exc}") from exc
    if not isinstance(data, Mapping):
        raise ValueError("Policy pack file must contain a mapping at the top level")
    return upgrade_policy_document(data)


def load_policy_pack_file(
    path: str | Path,
    *,
    detector_registry: DetectorRegistry | None = None,
    intervention_registry: InterventionRegistry | None = None,
    coupling_registry: CouplingRegistry | None = None,
) -> LoadedPolicyPack:
    document = load_policy_document(path)
    return build_controller_from_pack(
        document,
        detector_registry=detector_registry,
        intervention_registry=intervention_registry,
        coupling_registry=coupling_registry,
    )


__all__ = ["load_policy_document", "load_policy_pack_file"]
