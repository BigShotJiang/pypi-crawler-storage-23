"""Controller construction helpers for PolicyPacks."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from ultrastable.core import (
    Controller,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.core.coupling.registry import CouplingRegistry
from ultrastable.core.coupling.registry import (
    default_registry as default_coupling_registry,
)
from ultrastable.core.coupling.task import TaskCoupledVariable
from ultrastable.detectors.base import Detector
from ultrastable.detectors.registry import DetectorRegistry
from ultrastable.detectors.registry import (
    default_registry as default_detector_registry,
)
from ultrastable.interventions.base import Intervention
from ultrastable.interventions.registry import InterventionRegistry
from ultrastable.interventions.registry import (
    default_registry as default_intervention_registry,
)

from .canonicalize import canonicalize_policy, hash_canonical
from .model import LoadedPolicyPack


def build_controller_from_pack(
    pack: Mapping[str, Any],
    *,
    detector_registry: DetectorRegistry | None = None,
    intervention_registry: InterventionRegistry | None = None,
    coupling_registry: CouplingRegistry | None = None,
) -> LoadedPolicyPack:
    """Build a Controller + metadata from a PolicyPack mapping."""
    canonical = canonicalize_policy(pack)
    digest = hash_canonical(canonical)
    policy_cfg = canonical["policy"]
    variables = _build_variables(policy_cfg["variables"])
    coupled_entries = policy_cfg.get("coupled_variables") or []
    coupling_reg = coupling_registry or default_coupling_registry
    coupled = [
        TaskCoupledVariable.from_config(entry, registry=coupling_reg) for entry in coupled_entries
    ]
    space = EssentialVariableSpace(variables, coupled_variables=coupled)
    health = HealthModel(policy_cfg["health"]["metric"])
    policy = ViabilityPolicy(
        space=space,
        health=health,
        warn_threshold=policy_cfg["warn_threshold"],
        critical_threshold=policy_cfg["critical_threshold"],
        monotonic_warn_fraction=policy_cfg["monotonic_warn_fraction"],
        bounded_warn_fraction=policy_cfg["bounded_warn_fraction"],
        setpoint_warn_mult=policy_cfg["setpoint_warn_mult"],
        setpoint_critical_mult=policy_cfg["setpoint_critical_mult"],
    )
    controller_cfg = canonical["controller"]
    detector_reg = detector_registry or default_detector_registry
    detectors = [_build_detector(detector_reg, entry) for entry in canonical["detectors"]]
    intervention_reg = intervention_registry or default_intervention_registry
    interventions = [
        _build_intervention(intervention_reg, entry) for entry in canonical["interventions"]
    ]
    controller = Controller(
        policy=policy,
        detectors=detectors,
        interventions=interventions,
        step_window=controller_cfg["step_window"],
        snapshot_window=controller_cfg["snapshot_window"],
        cooldown_steps=controller_cfg["cooldown_steps"],
        eta=controller_cfg["eta"],
    )
    metadata = {
        "policy_name": canonical["name"],
        "policy_description": canonical["description"],
        "policy_hash": digest,
        "policy_schema_version": canonical["policy_schema_version"],
    }
    controller.policy_metadata = metadata  # type: ignore[attr-defined]
    controller.policy_pack = canonical  # type: ignore[attr-defined]
    return LoadedPolicyPack(
        controller=controller,
        canonical=canonical,
        policy_hash=digest,
        metadata=metadata,
    )


def _build_variables(entries: Sequence[Mapping[str, Any]]) -> list[EssentialVariable]:
    built: list[EssentialVariable] = []
    for entry in entries:
        tags = dict(entry.get("tags") or {})
        params = {
            "name": entry["name"],
            "scale": entry["scale"],
            "weight": entry["weight"],
            "hysteresis": entry["hysteresis"],
            "tags": tags,
        }
        kind = entry["kind"]
        if kind == "SETPOINT":
            built.append(
                EssentialVariable.setpoint(
                    target=entry["target"],
                    tolerance=entry["tolerance"],
                    **params,
                )
            )
        elif kind == "BOUNDED":
            built.append(
                EssentialVariable.bounded(
                    min=entry["min"],
                    max=entry["max"],
                    **params,
                )
            )
        else:
            built.append(
                EssentialVariable.monotonic(
                    hard_limit=entry["hard_limit"],
                    **params,
                )
            )
    return built


def _build_detector(registry: DetectorRegistry, entry: Mapping[str, Any]) -> Detector:
    spec = {"kind": entry["kind"], "params": entry.get("params") or {}}
    return registry.build(spec)


def _build_intervention(registry: InterventionRegistry, entry: Mapping[str, Any]) -> Intervention:
    spec = {"kind": entry["kind"], "params": entry.get("params") or {}}
    return registry.build(spec)


__all__ = ["build_controller_from_pack"]
