"""Shared policy-pack models and schema constants."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ultrastable.core import Controller

FLOAT_PRECISION = 9
DEFAULT_SCHEMA_VERSION = "policy_pack/v1"
POLICY_SCHEMA_VERSION = DEFAULT_SCHEMA_VERSION
SUPPORTED_POLICY_SCHEMA_VERSIONS = {POLICY_SCHEMA_VERSION}
LEGACY_POLICY_SCHEMA_VERSIONS = {"policy_pack/v0"}


@dataclass
class LoadedPolicyPack:
    controller: Controller
    canonical: dict[str, Any]
    policy_hash: str
    metadata: dict[str, Any]


__all__ = [
    "LoadedPolicyPack",
    "DEFAULT_SCHEMA_VERSION",
    "POLICY_SCHEMA_VERSION",
    "FLOAT_PRECISION",
    "SUPPORTED_POLICY_SCHEMA_VERSIONS",
    "LEGACY_POLICY_SCHEMA_VERSIONS",
]
