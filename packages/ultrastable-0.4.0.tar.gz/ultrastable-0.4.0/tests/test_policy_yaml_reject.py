from __future__ import annotations

import json
from pathlib import Path

import pytest

from ultrastable.policy import load_policy_document


def test_policy_loader_rejects_yaml(tmp_path: Path) -> None:
    # A minimal YAML content that is not valid JSON
    yaml_text = """
    name: my_pack
    policy:
      variables:
        - name: spend_usd
          kind: monotonic
          hard_limit: 10
    """.strip()
    p = tmp_path / "pack.yaml"
    p.write_text(yaml_text, encoding="utf-8")
    with pytest.raises(ValueError) as exc:
        _ = load_policy_document(p)
    msg = str(exc.value).lower()
    assert "json" in msg and "failed to parse" in msg


def test_policy_loader_accepts_json(tmp_path: Path) -> None:
    doc = {
        "name": "pack",
        "policy": {
            "variables": [
                {"name": "spend_usd", "kind": "monotonic", "hard_limit": 10, "scale": 1.0}
            ]
        },
    }
    p = tmp_path / "pack.json"
    p.write_text(json.dumps(doc), encoding="utf-8")
    loaded = load_policy_document(p)
    assert isinstance(loaded, dict)
    assert loaded.get("policy")
