from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import pytest

from ultrastable.core.coupling.registry import (
    CouplingRegistry,
    CouplingSpec,
    create_default_registry,
    default_registry,
    evaluate_coupling,
)


def _passthrough(value: float, *, params: Mapping[str, Any] | None = None, **context: Any) -> float:
    return float(value)


def test_default_registry_contains_all_builtin_names() -> None:
    names = set(default_registry.names())
    for builtin in [
        "linear",
        "sigmoid",
        "threshold",
        "rectified_linear",
        "exponential_decay",
    ]:
        assert builtin in names


def test_linear_config_evaluation() -> None:
    registry = create_default_registry()
    spec = {"func": "linear", "params": {"k": 2.0, "c": -1.0}}
    assert registry.evaluate(spec, 3.0) == pytest.approx(5.0)


def test_threshold_returns_low_high_values() -> None:
    registry = create_default_registry()
    spec = {"func": "threshold", "params": {"threshold": 0.5, "low": -1, "high": 2}}
    assert registry.evaluate(spec, 0.4) == pytest.approx(-1)
    assert registry.evaluate(spec, 0.6) == pytest.approx(2)


def test_exponential_decay_honors_dt_context_override() -> None:
    registry = create_default_registry()
    spec = {"func": "exponential_decay", "params": {"rate": 0.25}}
    result = registry.evaluate(spec, 8.0, dt=0.5)
    # 8 * (1 - 0.25 * 0.5) = 8 * 0.875
    assert result == pytest.approx(7.0)


def test_coupling_spec_dataclass_roundtrip() -> None:
    registry = create_default_registry()
    spec = CouplingSpec(func="rectified_linear", params={"k": 3, "bias": -2})
    assert registry.evaluate(spec, 1.0) == pytest.approx(1.0)


def test_register_duplicate_without_replace_errors() -> None:
    registry = CouplingRegistry()
    registry.register("linear", _passthrough)
    with pytest.raises(ValueError):
        registry.register("linear", _passthrough)


def test_evaluate_coupling_helper_uses_default_registry() -> None:
    assert evaluate_coupling("sigmoid", 0.0) == pytest.approx(0.5, rel=1e-4)
