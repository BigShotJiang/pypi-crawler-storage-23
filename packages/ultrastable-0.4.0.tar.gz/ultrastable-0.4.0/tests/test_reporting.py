from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import cast

import pytest

from ultrastable.core.events import InterventionEvent, RunEvent, StepEvent, TriggerEvent
from ultrastable.ledger import JsonlLedger
from ultrastable.reporting import (
    generate_spend_report,
    generate_unit_econ_report,
    generate_zombie_report,
    get_report_profile,
    validate_report_payload,
)

GOLDEN_DIR = Path(__file__).parent / "data" / "golden_reports"


def _write_sample_ledger(path: Path) -> None:
    with JsonlLedger(str(path), redaction="full-text") as ledger:
        ledger.add(
            RunEvent(
                run_id="run-good",
                phase="start",
                timestamp="2024-01-01T00:00:00Z",
                meta={"tags": {"customer": "c1"}},
            )
        )
        ledger.add(
            StepEvent(
                step_id="g1",
                role="assistant",
                kind="llm",
                model="demo",
                tokens_total=50,
                cost_usd=0.05,
                tags={"customer": "c1"},
                timestamp="2024-01-01T00:00:10Z",
            )
        )
        ledger.add(
            StepEvent(
                step_id="g2",
                role="tool",
                kind="tool",
                tokens_total=30,
                cost_usd=0.03,
                tags={"customer": "c1"},
                timestamp="2024-01-01T00:00:20Z",
            )
        )
        ledger.add(
            RunEvent(
                run_id="run-good",
                phase="end",
                timestamp="2024-01-01T00:01:00Z",
                meta={"status": "completed"},
            )
        )

        ledger.add(
            RunEvent(
                run_id="run-zombie",
                phase="start",
                timestamp="2024-01-02T00:00:00Z",
                meta={"tags": {"customer": "c2"}},
            )
        )
        for idx in range(4):
            ledger.add(
                StepEvent(
                    step_id=f"z-step-{idx}",
                    role="assistant",
                    kind="llm",
                    tokens_total=20,
                    cost_usd=0.02,
                    tags={"customer": "c2", "status": "error" if idx < 3 else "ok"},
                    timestamp=f"2024-01-02T00:00:{10 + idx:02d}Z",
                )
            )
        for idx in range(3):
            ledger.add(
                TriggerEvent(
                    detector="tool_loop",
                    severity="critical",
                    explanation="loop",
                    related_step_ids=[f"z-step-{idx}"],
                    timestamp=f"2024-01-02T00:01:{idx:02d}Z",
                )
            )
        ledger.add(
            RunEvent(
                run_id="run-zombie",
                phase="end",
                timestamp="2024-01-02T00:02:00Z",
                meta={"status": "failed"},
            )
        )


def _load_golden(name: str) -> dict[str, object]:
    path = GOLDEN_DIR / name
    return cast(dict[str, object], json.loads(path.read_text(encoding="utf-8")))


def test_spend_report_groups_by_customer(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_spend_report(str(ledger_path), group_by="customer")
    assert report["totals"]["tokens"] == 160
    assert len(report["groups"]) == 2
    keys = [grp["key"] for grp in report["groups"]]
    assert set(keys) == {"c1", "c2"}


def test_spend_report_filters_by_customer(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_spend_report(
        str(ledger_path), group_by="customer", filters={"customer": "c1"}
    )
    assert len(report["groups"]) == 1
    assert report["groups"][0]["key"] == "c1"


def test_spend_report_time_window(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    start = datetime.fromisoformat("2024-01-02T00:00:00+00:00")
    report = generate_spend_report(str(ledger_path), group_by="customer", start_time=start)
    assert report["totals"]["tokens"] == 80


def test_unit_econ_report_uses_task_map(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_unit_econ_report(
        str(ledger_path),
        group_by="customer",
        metric="cost_per_task",
        task_map={"c1": 2, "c2": 1},
    )
    groups = {entry["key"]: entry for entry in report["groups"]}
    assert groups["c1"]["usd_per_unit"] == 0.04
    assert groups["c2"]["usd_per_unit"] == 0.08


def test_zombie_report_detects_repeated_triggers(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_zombie_report(
        str(ledger_path),
        trigger_threshold=3,
        error_threshold=2,
        spend_threshold=0.05,
        min_steps=3,
    )
    assert report["runs_evaluated"] == 2
    incidents = {inc["reason"]: inc for inc in report["incidents"]}
    assert "repeated_triggers" in incidents
    assert incidents["repeated_triggers"]["evidence"]["trigger_events"]


def test_report_spend_golden_snapshot(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_spend_report(str(ledger_path), group_by="customer")
    assert report == _load_golden("spend_report.json")


def test_report_unit_econ_golden_snapshot(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_unit_econ_report(
        str(ledger_path),
        group_by="customer",
        metric="cost_per_task",
        task_map={"c1": 2, "c2": 1},
    )
    assert report == _load_golden("unit_econ_report.json")


def test_report_zombie_golden_snapshot(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    report = generate_zombie_report(
        str(ledger_path),
        trigger_threshold=3,
        error_threshold=2,
        spend_threshold=0.05,
        min_steps=3,
    )
    assert report == _load_golden("zombie_report.json")


def test_spend_report_includes_health_metrics(tmp_path: Path) -> None:
    ledger_path = tmp_path / "health.jsonl"
    with JsonlLedger(str(ledger_path), redaction="full-text") as ledger:
        ledger.add(
            RunEvent(
                run_id="health-run",
                phase="start",
                timestamp="2024-02-01T00:00:00Z",
                meta={"tags": {"customer": "c3"}},
            )
        )
        values = [0.4, 0.2, 0.05]
        for idx, value in enumerate(values):
            ledger.add(
                StepEvent(
                    step_id=f"h{idx}",
                    role="assistant",
                    kind="llm",
                    tokens_total=10,
                    cost_usd=0.01,
                    d_h=value,
                    tags={"customer": "c3"},
                    timestamp=f"2024-02-01T00:00:{10 + idx:02d}Z",
                )
            )
        ledger.add(
            InterventionEvent(
                intervention_type="RESET_CONTEXT_TRIM_OUTCOME",
                parameters={"phase": "outcome"},
                outcome={
                    "intervention_type": "RESET_CONTEXT_TRIM",
                    "delta_dh": 0.15,
                    "steps_to_recover": 2,
                    "repeated_breach_count": 1,
                    "status": "recovered",
                },
                tags={"status": "recovered"},
                timestamp="2024-02-01T00:01:30Z",
            )
        )
        ledger.add(
            InterventionEvent(
                intervention_type="RESET_CONTEXT_TRIM_OUTCOME",
                parameters={"phase": "outcome"},
                outcome={
                    "intervention_type": "RESET_CONTEXT_TRIM",
                    "delta_dh": -0.05,
                    "steps_to_recover": 4,
                    "repeated_breach_count": 2,
                    "status": "regressed",
                },
                tags={"status": "regressed"},
                timestamp="2024-02-01T00:01:45Z",
            )
        )
        ledger.add(
            RunEvent(
                run_id="health-run",
                phase="end",
                timestamp="2024-02-01T00:02:00Z",
                meta={"status": "completed"},
            )
        )
    report = generate_spend_report(str(ledger_path), group_by=None)
    health = report["health"]
    trend = health["d_h_trend"]
    assert trend["samples"] == 3
    assert trend["start"]["d_h"] == pytest.approx(0.4)
    assert trend["end"]["d_h"] == pytest.approx(0.05)
    assert trend["delta"] == pytest.approx(-0.35)
    assert trend["min"]["d_h"] == pytest.approx(0.05)
    effect = health["intervention_effect_size"]
    assert effect["samples"] == 2
    assert effect["largest_recovery"] == pytest.approx(0.15)
    assert effect["largest_regression"] == pytest.approx(-0.05)
    breakdown = effect["status_breakdown"]
    assert breakdown["recovered"] == 1
    assert breakdown["regressed"] == 1
    assert effect["improved_fraction"] == pytest.approx(0.5)


def test_report_profiles_validate_outputs(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    _write_sample_ledger(ledger_path)
    spend = generate_spend_report(str(ledger_path), group_by="customer")
    unit_econ = generate_unit_econ_report(str(ledger_path), group_by="customer")
    zombie = generate_zombie_report(str(ledger_path))
    validate_report_payload("spend", spend)
    validate_report_payload("unit_econ", unit_econ)
    validate_report_payload("zombie", zombie)
    profile = get_report_profile("spend")
    assert profile.name == "spend"
    assert "Spend" in profile.description or "spend" in profile.description.lower()
