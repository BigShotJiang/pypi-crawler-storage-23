from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, cast

import pytest

from ultrastable.observability.otel import GuardRunTelemetry, configure_otel_from_env

if TYPE_CHECKING:  # pragma: no cover - typing helpers only
    from opentelemetry.metrics import Meter
    from opentelemetry.trace import Tracer


class _FakeSpan:
    def __init__(self, name: str, attributes: Mapping[str, Any] | None) -> None:
        self.name = name
        self.attributes = dict(attributes or {})
        self.ended = False

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def end(self) -> None:
        self.ended = True


class _FakeTracer:
    def __init__(self) -> None:
        self.spans: list[_FakeSpan] = []

    def start_span(
        self,
        name: str,
        *,
        attributes: Mapping[str, Any] | None = None,
        **_: Any,
    ) -> _FakeSpan:
        span = _FakeSpan(name, attributes)
        self.spans.append(span)
        return span


class _FakeCounter:
    def __init__(self, name: str) -> None:
        self.name = name
        self.records: list[tuple[float, dict[str, Any]]] = []

    def add(self, value: float, *, attributes: Mapping[str, Any] | None = None) -> None:
        self.records.append((value, dict(attributes or {})))


class _FakeHistogram:
    def __init__(self, name: str) -> None:
        self.name = name
        self.records: list[tuple[float, dict[str, Any]]] = []

    def record(self, value: float, *, attributes: Mapping[str, Any] | None = None) -> None:
        self.records.append((value, dict(attributes or {})))


class _FakeMeter:
    def __init__(self) -> None:
        self.counters: dict[str, _FakeCounter] = {}
        self.histograms: dict[str, _FakeHistogram] = {}

    def create_counter(self, name: str) -> _FakeCounter:
        counter = _FakeCounter(name)
        self.counters[name] = counter
        return counter

    def create_histogram(self, name: str) -> _FakeHistogram:
        histogram = _FakeHistogram(name)
        self.histograms[name] = histogram
        return histogram


def test_guard_run_telemetry_emits_spans_and_metrics() -> None:
    tracer = _FakeTracer()
    meter = _FakeMeter()
    telemetry = GuardRunTelemetry(
        tracer=cast("Tracer", tracer),
        meter=cast("Meter", meter),
    )
    telemetry.start_run("demo-run", policy_hash="sha256:abc")
    telemetry.record_snapshot(0.42)
    telemetry.record_step_metrics(tokens_total=128, spend_usd=0.75, errors=2)
    telemetry.record_trigger_count(2)
    telemetry.record_step_metrics(tokens_total=None, spend_usd=0.25, errors=0)
    telemetry.record_intervention(applied=True)
    telemetry.end_run(status="completed")

    assert tracer.spans and tracer.spans[0].name == "ultrastable.run"
    span = tracer.spans[0]
    assert span.attributes["run_id"] == "demo-run"
    assert span.attributes["policy_hash"] == "sha256:abc"
    assert span.attributes["run.status"] == "completed"
    assert span.ended

    spend = meter.counters["ultrastable.spend_usd"]
    tokens = meter.counters["ultrastable.tokens_total"]
    triggers = meter.counters["ultrastable.trigger_count"]
    d_h = meter.histograms["ultrastable.d_h"]
    steps = meter.counters["ultrastable.step_count"]
    errors = meter.counters["ultrastable.error_count"]
    interventions = meter.counters["ultrastable.intervention_count"]

    assert spend.records[0][0] == 0.75
    assert spend.records[1][0] == 0.25
    assert tokens.records[0][0] == 128.0
    assert triggers.records[0][0] == 2.0
    assert d_h.records[0][0] == 0.42
    assert steps.records and all(record[0] == 1.0 for record in steps.records)
    assert errors.records and errors.records[0][0] == 2.0
    assert interventions.records and interventions.records[0][0] == 1.0
    for _, attrs in (
        spend.records
        + tokens.records
        + triggers.records
        + d_h.records
        + steps.records
        + errors.records
        + interventions.records
    ):
        assert attrs["run_id"] == "demo-run"
        assert attrs["policy_hash"] == "sha256:abc"


def test_guard_run_telemetry_noops_without_dependencies() -> None:
    telemetry = GuardRunTelemetry(tracer=None, meter=None)
    telemetry.start_run("noop", policy_hash=None)
    telemetry.record_snapshot(1.0)
    telemetry.record_step_metrics(tokens_total=1, spend_usd=0.1)
    telemetry.record_trigger_count(1)
    telemetry.end_run(status="completed")


def test_configure_otel_from_env_returns_false_when_exporter_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import ultrastable.observability.otel as otel_mod

    for key in otel_mod._OTLP_ENDPOINT_ENV_KEYS + otel_mod._OTLP_HEADERS_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)

    called = False

    def _never_invoked(endpoint: str, headers: Mapping[str, str]) -> bool:
        nonlocal called
        called = True
        return True

    monkeypatch.setattr(otel_mod, "_install_otlp_exporters", _never_invoked)
    monkeypatch.setattr(otel_mod, "_OTEL_ENV_CONFIGURED", False)

    assert configure_otel_from_env(force=True) is False
    assert called is False


def test_configure_otel_from_env_installs_otlp_exporters(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    trace_export = pytest.importorskip("opentelemetry.exporter.otlp.proto.http.trace_exporter")
    metric_export = pytest.importorskip("opentelemetry.exporter.otlp.proto.http.metric_exporter")
    sdk_trace = pytest.importorskip("opentelemetry.sdk.trace")
    sdk_trace_export = pytest.importorskip("opentelemetry.sdk.trace.export")
    sdk_metrics = pytest.importorskip("opentelemetry.sdk.metrics")
    sdk_metrics_export = pytest.importorskip("opentelemetry.sdk.metrics.export")
    otel_trace = pytest.importorskip("opentelemetry.trace")
    otel_metrics = pytest.importorskip("opentelemetry.metrics")

    monkeypatch.setenv("ULTRASTABLE_OTLP_ENDPOINT", "https://collector.example.com/v1")
    monkeypatch.setenv("ULTRASTABLE_OTLP_HEADERS", "x-auth=secret, x-env=dev")
    monkeypatch.setattr("ultrastable.observability.otel._OTEL_ENV_CONFIGURED", False)

    captures: list[tuple[str, str, dict[str, str]]] = []

    class _CapturingSpanExporter:
        def __init__(
            self,
            *,
            endpoint: str,
            headers: Mapping[str, str] | None = None,
            **_: Any,
        ) -> None:
            captures.append(("span", endpoint, dict(headers or {})))

    class _CapturingMetricExporter:
        def __init__(
            self,
            *,
            endpoint: str,
            headers: Mapping[str, str] | None = None,
            **_: Any,
        ) -> None:
            captures.append(("metric", endpoint, dict(headers or {})))

    class _BatchSpanProcessor:
        def __init__(self, exporter: Any) -> None:
            self.exporter = exporter

    class _TracerProvider:
        def __init__(self, *, resource: Any | None = None) -> None:
            self.resource = resource
            self.processors: list[Any] = []

        def add_span_processor(self, processor: Any) -> None:
            self.processors.append(processor)

    class _MetricReader:
        def __init__(self, exporter: Any) -> None:
            self.exporter = exporter

    class _MeterProvider:
        def __init__(
            self,
            *,
            resource: Any | None = None,
            metric_readers: list[Any] | None = None,
        ) -> None:
            self.resource = resource
            self.metric_readers = list(metric_readers or [])

    set_calls: dict[str, Any] = {}

    def _set_tracer_provider(provider: Any) -> None:
        set_calls["trace"] = provider

    def _set_meter_provider(provider: Any) -> None:
        set_calls["meter"] = provider

    monkeypatch.setattr(trace_export, "OTLPSpanExporter", _CapturingSpanExporter)
    monkeypatch.setattr(metric_export, "OTLPMetricExporter", _CapturingMetricExporter)
    monkeypatch.setattr(sdk_trace_export, "BatchSpanProcessor", _BatchSpanProcessor)
    monkeypatch.setattr(sdk_trace, "TracerProvider", _TracerProvider)
    monkeypatch.setattr(sdk_metrics_export, "PeriodicExportingMetricReader", _MetricReader)
    monkeypatch.setattr(sdk_metrics, "MeterProvider", _MeterProvider)
    monkeypatch.setattr(otel_trace, "set_tracer_provider", _set_tracer_provider)
    monkeypatch.setattr(otel_metrics, "set_meter_provider", _set_meter_provider)

    assert configure_otel_from_env(force=True) is True
    assert len(captures) == 2
    capture_map = {kind: (endpoint, headers) for kind, endpoint, headers in captures}
    assert capture_map["span"][0] == "https://collector.example.com/v1"
    assert capture_map["span"][1]["x-auth"] == "secret"
    assert capture_map["metric"][1]["x-env"] == "dev"
    assert set_calls["trace"].processors, "Tracer provider should register the processor"
    assert set_calls["meter"].metric_readers, "Meter provider should register a reader"

    assert configure_otel_from_env() is True
    assert len(captures) == 2, "Subsequent calls should not rebuild exporters"


def test_configure_otel_from_env_enabled_path_uses_headers_and_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import ultrastable.observability.otel as otel_mod

    for key in otel_mod._OTLP_ENDPOINT_ENV_KEYS + otel_mod._OTLP_HEADERS_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)

    endpoint = "https://collect.example.net:4318/v1"
    headers = "x-api-key = secret , user = agent , invalid"
    monkeypatch.setenv(otel_mod._OTLP_ENDPOINT_ENV_KEYS[0], endpoint)
    monkeypatch.setenv(otel_mod._OTLP_HEADERS_ENV_KEYS[0], headers)

    captured: dict[str, Any] = {}

    def _capture(endpoint_arg: str, headers_arg: Mapping[str, str]) -> bool:
        captured["endpoint"] = endpoint_arg
        captured["headers"] = dict(headers_arg)
        return True

    monkeypatch.setattr(otel_mod, "_install_otlp_exporters", _capture)
    monkeypatch.setattr(otel_mod, "_OTEL_ENV_CONFIGURED", False)

    assert configure_otel_from_env(force=True) is True
    assert captured["endpoint"] == endpoint
    assert captured["headers"]["x-api-key"] == "secret"
    assert captured["headers"]["user"] == "agent"
    assert "invalid" not in captured["headers"]
