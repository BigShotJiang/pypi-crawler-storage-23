from __future__ import annotations

import random

import numpy as np
import pytest

from ultrastable.random_state import normalize_seed, seed_process


def test_seed_process_reseeds_python_and_numpy() -> None:
    first = seed_process(2026)
    assert first == normalize_seed(2026)
    py_values_one = [random.random() for _ in range(3)]
    np_values_one = np.random.rand(3)

    seed_process(2026)
    py_values_two = [random.random() for _ in range(3)]
    np_values_two = np.random.rand(3)

    assert py_values_one == py_values_two
    assert np.allclose(np_values_one, np_values_two)


def test_seed_process_normalizes_negative_inputs() -> None:
    normalized = seed_process(-42)
    assert normalized == normalize_seed(-42)
    assert 0 <= normalized < 2**32


def test_seed_process_seeds_torch_when_available() -> None:
    try:
        torch = pytest.importorskip("torch")
    except pytest.skip.Exception:
        raise
    except Exception as exc:  # pragma: no cover - environment specific import failure
        pytest.skip(f"torch import failed: {exc}")

    seed_process(777)
    tensor_one = torch.rand(4)

    seed_process(777)
    tensor_two = torch.rand(4)

    assert torch.equal(tensor_one, tensor_two)
