from __future__ import annotations

import importlib.util
import json
import types
import uuid
import warnings
from collections.abc import Callable, Mapping, Sequence
from itertools import chain, repeat
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypedDict, cast

import pytest

from ultrastable.agent import AgentGuard
from ultrastable.cli.demos import build_budget_controller
from ultrastable.ledger import JsonlLedger

if TYPE_CHECKING:  # pragma: no cover - typing only
    from langchain_core.outputs import Generation as GenerationType
    from langchain_core.outputs import LLMResult as LLMResultType
    from langchain_core.runnables import RunnableConfig
else:  # pragma: no cover - runtime fallback
    GenerationType = Any  # type: ignore[assignment]
    LLMResultType = Any  # type: ignore[assignment]
    _langchain_runnables = pytest.importorskip("langchain_core.runnables")
    RunnableConfig = _langchain_runnables.RunnableConfig

_langchain_outputs = pytest.importorskip("langchain_core.outputs")
Generation = cast("type[GenerationType]", _langchain_outputs.Generation)
LLMResult = cast("type[LLMResultType]", _langchain_outputs.LLMResult)
from ultrastable_langchain import (  # noqa: E402
    UltrastableCallbackHandler,
    llm_run_to_guard_step,
    pre_step_context_from_prompts,
    tool_run_to_guard_step,
)

_langchain_tools = pytest.importorskip("langchain_core.tools")
tool = _langchain_tools.tool


def _clock_from(*ticks: float) -> Callable[[], float]:
    iterator = chain(ticks, repeat(ticks[-1]))

    def _clock() -> float:
        return next(iterator)

    return _clock


class _MockLangChainCallbackManager:
    """Minimal shim that replays LangChain callback sequences into a handler."""

    def __init__(self, handler: UltrastableCallbackHandler) -> None:
        self._handler = handler

    def emit_llm_run(
        self,
        *,
        serialized: Mapping[str, Any] | None = None,
        prompts: Sequence[str] | None = None,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        tags: Sequence[str] | None = None,
        metadata: Mapping[str, Any] | None = None,
        invocation_params: Mapping[str, Any] | None = None,
        result: LLMResultType | None = None,
        propagate_parent_on_end: bool = True,
    ) -> uuid.UUID:
        run_id = run_id or uuid.uuid4()
        self._handler.on_llm_start(
            dict(serialized or {"id": ["mock_llm"]}),
            list(prompts or ["ping"]),
            run_id=run_id,
            parent_run_id=parent_run_id,
            tags=list(tags or ()),
            metadata=dict(metadata or {}),
            invocation_params=dict(invocation_params or {}),
        )
        llm_result = result or LLMResult(
            generations=[[Generation(text="pong")]],
            llm_output={"token_usage": {"prompt_tokens": 1, "completion_tokens": 1}},
        )
        parent_for_end = parent_run_id if propagate_parent_on_end else None
        self._handler.on_llm_end(llm_result, run_id=run_id, parent_run_id=parent_for_end)
        return run_id

    def emit_tool_run(
        self,
        *,
        serialized: Mapping[str, Any] | None = None,
        input_str: str = "",
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        tags: Sequence[str] | None = None,
        metadata: Mapping[str, Any] | None = None,
        inputs: Mapping[str, Any] | None = None,
        output: Any = None,
        propagate_parent_on_end: bool = True,
    ) -> uuid.UUID:
        run_id = run_id or uuid.uuid4()
        self._handler.on_tool_start(
            dict(serialized or {"id": ["mock_tool"], "name": "mock_tool"}),
            input_str,
            run_id=run_id,
            parent_run_id=parent_run_id,
            tags=list(tags or ()),
            metadata=dict(metadata or {}),
            inputs=dict(inputs or {}),
        )
        parent_for_end = parent_run_id if propagate_parent_on_end else None
        self._handler.on_tool_end(output, run_id=run_id, parent_run_id=parent_for_end)
        return run_id


def test_ultrastable_callback_handler_records_llm_runs() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(1.0, 2.5))
    run_id = uuid.uuid4()
    handler.on_llm_start(
        serialized={"id": ["fake_llm"]},
        prompts=["Hello there"],
        run_id=run_id,
        tags=["trace"],
        metadata={"tenant": "demo"},
        invocation_params={"model_name": "demo-llm"},
    )
    result = LLMResult(
        generations=[
            [Generation(text="General Kenobi!", generation_info={"finish_reason": "stop"})]
        ],
        llm_output={"token_usage": {"prompt_tokens": 8, "completion_tokens": 2}},
    )
    handler.on_llm_end(result, run_id=run_id)

    assert len(handler.llm_runs) == 1
    llm_run = handler.llm_runs[0]
    assert llm_run.run_id == str(run_id)
    assert llm_run.parent_run_id is None
    assert llm_run.prompts == ("Hello there",)
    assert llm_run.invocation_params == {"model_name": "demo-llm"}
    assert llm_run.metadata == {"tenant": "demo"}
    assert llm_run.tags == ("trace",)
    assert llm_run.response == result
    assert llm_run.latency_ms == pytest.approx(1500.0)


def test_ultrastable_callback_handler_records_tool_runs() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(10.0, 10.25))
    run_id = uuid.uuid4()
    parent_run_id = uuid.uuid4()
    handler.on_tool_start(
        serialized={"id": ["search_tool"], "name": "search"},
        input_str="search('ultrastable')",
        run_id=run_id,
        parent_run_id=parent_run_id,
        tags=["tool"],
        metadata={"agent": "alpha"},
        inputs={"query": "ultrastable"},
    )
    handler.on_tool_end({"documents": 2}, run_id=run_id)

    assert len(handler.tool_runs) == 1
    tool_run = handler.tool_runs[0]
    assert tool_run.run_id == str(run_id)
    assert tool_run.parent_run_id == str(parent_run_id)
    assert tool_run.input_str.startswith("search(")
    assert tool_run.inputs == {"query": "ultrastable"}
    assert tool_run.metadata == {"agent": "alpha"}
    assert tool_run.tags == ("tool",)
    assert tool_run.output == {"documents": 2}
    assert tool_run.latency_ms == pytest.approx(250.0)


def test_mocked_langchain_callbacks_preserve_llm_parent_ids() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(3.0, 3.25))
    manager = _MockLangChainCallbackManager(handler)
    parent_run_id = uuid.uuid4()
    llm_result = LLMResult(
        generations=[[Generation(text="mock response", generation_info={"finish_reason": "stop"})]],
        llm_output={"token_usage": {"prompt_tokens": 4, "completion_tokens": 1}},
    )
    manager.emit_llm_run(
        serialized={"id": ["chat"], "kwargs": {"model": "demo-llm"}},
        prompts=["ping"],
        run_id=uuid.uuid4(),
        parent_run_id=parent_run_id,
        tags=["agent", "mock"],
        metadata={"tenant": "demo"},
        invocation_params={"model": "demo-llm", "temperature": 0.1},
        result=llm_result,
        propagate_parent_on_end=False,
    )

    assert len(handler.llm_runs) == 1
    llm_run = handler.llm_runs[0]
    assert llm_run.parent_run_id == str(parent_run_id)
    assert llm_run.tags == ("agent", "mock")
    assert llm_run.serialized["id"] == ["chat"]
    assert llm_run.invocation_params["temperature"] == 0.1
    assert llm_run.response == llm_result
    assert llm_run.latency_ms == pytest.approx(250.0)


def test_mocked_langchain_callbacks_preserve_tool_parent_ids() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(5.0, 5.75))
    manager = _MockLangChainCallbackManager(handler)
    parent_run_id = uuid.uuid4()
    manager.emit_tool_run(
        serialized={"id": ["search_node"], "name": "search"},
        input_str="search('ultrastable')",
        run_id=uuid.uuid4(),
        parent_run_id=parent_run_id,
        tags=["tool"],
        metadata={"agent": "beta"},
        inputs={"query": "ultrastable"},
        output={"documents": 3},
        propagate_parent_on_end=False,
    )

    assert len(handler.tool_runs) == 1
    tool_run = handler.tool_runs[0]
    assert tool_run.parent_run_id == str(parent_run_id)
    assert tool_run.tags == ("tool",)
    assert tool_run.metadata == {"agent": "beta"}
    assert tool_run.inputs == {"query": "ultrastable"}
    assert tool_run.latency_ms == pytest.approx(750.0)


def test_ultrastable_callback_handler_reset_clears_pending_runs() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(0.0, 0.1))
    run_id = uuid.uuid4()
    handler.on_llm_start(serialized={"id": ["stub"]}, prompts=["ping"], run_id=run_id)
    handler.reset()
    handler.on_llm_end(
        LLMResult(generations=[[Generation(text="pong")]], llm_output={}),
        run_id=run_id,
    )

    assert handler.llm_runs == []


def test_llm_run_to_guard_step_maps_metrics_and_tags() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(2.0, 4.0))
    run_id = uuid.uuid4()
    handler.on_llm_start(
        serialized={"id": ["fake_llm"], "kwargs": {"model": "demo-llm"}},
        prompts=["Hello", "World"],
        run_id=run_id,
        tags=["trace"],
        metadata={"tenant": "demo", "cost_usd": 0.05},
        invocation_params={"model_name": "demo-llm"},
    )
    result = LLMResult(
        generations=[[Generation(text="Hi there!")]],
        llm_output={"token_usage": {"prompt_tokens": 5, "completion_tokens": 3}},
    )
    handler.on_llm_end(result, run_id=run_id)

    guard_step = llm_run_to_guard_step(handler.llm_runs[0])

    assert guard_step.result.step_id == str(run_id)
    assert guard_step.result.model == "demo-llm"
    assert guard_step.result.prompt_text == "Hello\n\nWorld"
    assert guard_step.result.response_text == "Hi there!"
    assert guard_step.result.tags == {
        "tenant": "demo",
        "cost_usd": 0.05,
        "langchain_tags": ["trace"],
    }
    assert guard_step.metrics is not None
    assert guard_step.metrics.tokens_prompt == 5
    assert guard_step.metrics.tokens_completion == 3
    assert guard_step.metrics.tokens_total == 8
    assert guard_step.metrics.cost_usd == pytest.approx(0.05)
    assert guard_step.metrics.latency_ms == pytest.approx(2000.0)


def test_llm_run_to_guard_step_surfaces_retry_error_counts() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(1.0, 1.5))
    manager = _MockLangChainCallbackManager(handler)
    manager.emit_llm_run(
        serialized={"id": ["chat"]},
        prompts=["ping"],
        metadata={"retry_count": "2", "error_count": 3},
    )

    guard_step = llm_run_to_guard_step(handler.llm_runs[-1])

    assert guard_step.metrics is not None
    assert guard_step.metrics.retries == 2
    assert guard_step.metrics.errors == 3


def test_tool_run_to_guard_step_derives_tool_args_hash() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(10.0, 10.1))
    run_id = uuid.uuid4()
    handler.on_tool_start(
        serialized={"id": ["search"], "name": "search_tool"},
        input_str="search('ultrastable')",
        run_id=run_id,
        inputs={"query": "ultrastable", "top_k": 3},
    )
    handler.on_tool_end({"documents": 1}, run_id=run_id)

    tool_event = handler.tool_runs[0]
    guard_step = tool_run_to_guard_step(tool_event)
    guard_step_repeat = tool_run_to_guard_step(tool_event)

    assert guard_step.result.tool_name == "search_tool"
    assert guard_step.result.tool_args_hash is not None
    assert guard_step.result.tool_args_hash == guard_step_repeat.result.tool_args_hash
    assert tool_event.tool_name == "search_tool"
    assert tool_event.tool_args_hash == guard_step.result.tool_args_hash
    assert guard_step.metrics is not None
    assert guard_step.metrics.latency_ms == pytest.approx(100.0)
    assert guard_step.result.prompt_text is not None
    assert guard_step.result.prompt_text.startswith("search(")
    assert guard_step.result.response_text == "{'documents': 1}"


def test_tool_run_to_guard_step_surface_retry_error_counts_from_metadata() -> None:
    handler = UltrastableCallbackHandler(clock=_clock_from(3.0, 3.01))
    manager = _MockLangChainCallbackManager(handler)
    manager.emit_tool_run(
        serialized={"id": ["search"], "name": "search_tool"},
        input_str="search('ultrastable')",
        metadata={"status": "ERROR", "retries": 1},
    )

    guard_step = tool_run_to_guard_step(handler.tool_runs[-1])

    assert guard_step.metrics is not None
    assert guard_step.metrics.retries == 1
    assert guard_step.metrics.errors == 1


def test_pre_step_context_from_prompts_filters_empty_entries() -> None:
    context = pre_step_context_from_prompts(["", "   ", "Hello there"], base_id="ctx")

    assert context == [
        {"id": "ctx-2", "role": "user", "content": "Hello there", "pinned": False, "tags": {}}
    ]


def _load_example_module() -> types.ModuleType:
    root = Path(__file__).resolve().parents[1]
    example_path = root / "examples" / "langchain_connector_minimal.py"
    spec = importlib.util.spec_from_file_location("langchain_connector_minimal", example_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load langchain_connector_minimal example module.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_langchain_minimal_example(tmp_path: Path) -> None:
    example = _load_example_module()
    ledger_path, report_path = example.run_example(output_dir=tmp_path)

    assert ledger_path.exists()
    assert report_path.exists()

    ledger_events = [
        json.loads(line) for line in ledger_path.read_text().splitlines() if line.strip()
    ]
    run_phases = {event.get("phase") for event in ledger_events if event.get("event_type") == "run"}
    step_events = [event for event in ledger_events if event.get("event_type") == "step"]

    assert {"start", "end"}.issubset(run_phases)
    assert len(step_events) == 3

    report = json.loads(report_path.read_text())
    assert report["group_by"] == "agent_id"
    assert report["totals"]["steps"] == 3
    assert report["groups"][0]["key"] == "langchain-minimal"
    assert report["groups"][0]["tool_calls"] == 1


class LangGraphLoopState(TypedDict, total=False):
    ticket: str
    attempts: int
    fail_until: int
    max_attempts: int
    history: list[str]
    last_tool_status: str


def test_langgraph_tool_loop_triggers_detector(tmp_path: Path) -> None:
    langgraph_graph = pytest.importorskip("langgraph.graph")
    StateGraph = langgraph_graph.StateGraph
    START = langgraph_graph.START
    END = cast(str, langgraph_graph.END)

    handler = UltrastableCallbackHandler()
    agent_tags = {"agent_id": "langgraph-loop"}

    @tool
    def lookup_ticket(ticket: str) -> str:
        """Return a canned status update for the provided ticket."""

        return f"{ticket} is still pending triage."

    def call_lookup(
        state: LangGraphLoopState,
        *,
        config: RunnableConfig | None = None,
    ) -> LangGraphLoopState:
        cfg: dict[str, Any] = dict(config or {})
        attempt = int(state.get("attempts", 0)) + 1
        fail_until = int(state.get("fail_until", 0))
        should_fail = attempt <= fail_until
        metadata = dict(cfg.get("metadata") or {})
        if should_fail:
            metadata.update(
                {
                    "status": "ERROR",
                    "retry_count": attempt - 1,
                    "error": f"lookup failed at attempt {attempt}",
                }
            )
        else:
            metadata["status"] = "OK"
            metadata.pop("error", None)
        callbacks = list(cfg.get("callbacks") or [])
        if not callbacks:
            callbacks = [handler]
        tool_config: dict[str, Any] = dict(cfg)
        tool_config["callbacks"] = callbacks
        tool_config["metadata"] = metadata
        result = lookup_ticket.invoke(state["ticket"], config=tool_config)
        history = list(state.get("history") or [])
        history.append(result)
        return {
            "attempts": attempt,
            "history": history,
            "last_tool_status": metadata["status"],
        }

    def route_next(state: LangGraphLoopState) -> str:
        attempts = int(state.get("attempts", 0))
        max_attempts = int(state.get("max_attempts", 0))
        if state.get("last_tool_status") == "ERROR" and attempts < max_attempts:
            return "call_lookup"
        return END

    graph = StateGraph(LangGraphLoopState)
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="The 'config' parameter should be typed as 'RunnableConfig'",
        )
        graph.add_node("call_lookup", call_lookup)
    graph.add_edge(START, "call_lookup")
    graph.add_conditional_edges("call_lookup", route_next)
    compiled_graph = graph.compile()

    initial_state: LangGraphLoopState = {
        "ticket": "INC-347",
        "fail_until": 3,
        "max_attempts": 4,
        "history": [],
    }
    compiled_graph.invoke(initial_state, config={"callbacks": [handler]})

    assert len(handler.tool_runs) == initial_state["max_attempts"]

    ledger_path = tmp_path / "langgraph_tool_loop.jsonl"
    guard, ledger = _build_tool_loop_guard(ledger_path)
    decisions = []
    try:
        guard.start_run(run_id="langgraph-loop", tags=agent_tags)
        for idx, tool_run in enumerate(handler.tool_runs):
            guard_step = tool_run_to_guard_step(tool_run, step_id=f"langgraph-tool-{idx}")
            tags = dict(agent_tags)
            if guard_step.result.tags:
                tags.update(guard_step.result.tags)
            decision = guard.post_step(
                step_id=guard_step.result.step_id,
                role=guard_step.result.role,
                kind=guard_step.result.kind,
                model=guard_step.result.model,
                prompt_text=guard_step.result.prompt_text,
                response_text=guard_step.result.response_text,
                tool_name=guard_step.result.tool_name,
                tool_args_hash=guard_step.result.tool_args_hash,
                metrics=guard_step.metrics,
                tags=tags,
            )
            decisions.append(decision)
    finally:
        guard.end_run()
        ledger.close()

    assert any(
        any(trigger.detector == "tool_loop" for trigger in decision.triggers)
        for decision in decisions
    )
    decision_tool_loop_triggers = [
        trigger
        for decision in decisions
        for trigger in decision.triggers
        if trigger.detector == "tool_loop"
    ]
    assert decision_tool_loop_triggers
    assert any(trigger.severity == "critical" for trigger in decision_tool_loop_triggers)
    assert any(trigger.tags.get("tool_name") for trigger in decision_tool_loop_triggers)
    assert any(
        str(trigger.explanation or "").startswith(
            f"{initial_state['fail_until']} recent tool errors"
        )
        for trigger in decision_tool_loop_triggers
    )

    ledger_events = [
        json.loads(line) for line in ledger_path.read_text().splitlines() if line.strip()
    ]
    tool_steps = [
        event
        for event in ledger_events
        if event.get("event_type") == "step" and event.get("kind") == "tool"
    ]
    assert len(tool_steps) == len(handler.tool_runs)
    error_steps = [
        event
        for event in tool_steps
        if str(event.get("tags", {}).get("status", "")).lower() == "error"
    ]
    assert len(error_steps) == initial_state["fail_until"]
    tool_loop_triggers = [
        event
        for event in ledger_events
        if event.get("event_type") == "trigger" and event.get("detector") == "tool_loop"
    ]
    assert tool_loop_triggers
    assert any(event.get("severity") == "critical" for event in tool_loop_triggers)
    assert any(
        str(event.get("explanation", "")).startswith(
            f"{initial_state['fail_until']} recent tool errors"
        )
        for event in tool_loop_triggers
    )
    intervention_events = [
        event for event in ledger_events if event.get("event_type") == "intervention"
    ]
    assert any(event.get("intervention_type") == "RESET_REPLAN" for event in intervention_events)
    assert any(
        event.get("intervention_type") == "RESET_REPLAN_OUTCOME" for event in intervention_events
    )


def _build_tool_loop_guard(path: Path) -> tuple[AgentGuard, JsonlLedger]:
    controller = build_budget_controller()
    ledger = JsonlLedger(str(path), redaction="metadata-only")
    guard = AgentGuard(controller=controller, ledger=ledger, context_budget_chars=None)
    return guard, ledger
