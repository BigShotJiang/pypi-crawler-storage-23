"""Tests for the experiment runner utility helpers."""

import json
from pathlib import Path

from scripts.run_ultrastable_experiments import (
    load_experiment_plan,
    save_command_output,
)


def test_save_command_output_allows_none_path() -> None:
    """Ensure no exception occurs when output path is omitted."""
    save_command_output(None, "ok payload")


def test_save_command_output_writes_file(tmp_path: Path) -> None:
    """A provided output path is created (including parents) and populated."""
    destination = tmp_path / "nested" / "payload.txt"

    save_command_output(destination, "some bytes")

    assert destination.exists()
    assert destination.read_text(encoding="utf-8") == "some bytes\n"


def test_load_experiment_plan_expands_tokens(tmp_path: Path) -> None:
    """Plan loader supports token substitution and path normalization."""
    plan_path = tmp_path / "plan.json"
    workdir = tmp_path / "work"
    repo_root = tmp_path / "repo"
    workdir.mkdir()
    repo_root.mkdir()
    plan_path.write_text(
        json.dumps(
            {
                "steps": [
                    {
                        "name": "sample",
                        "command": ["echo", "{workdir}", "{repo_root}"],
                        "output_path": "reports/out.txt",
                        "cwd": "child",
                        "timeout": 5,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    steps = load_experiment_plan(plan_path, workdir=workdir, repo_root=repo_root)

    assert steps[0]["command"] == ["echo", str(workdir), str(repo_root)]
    assert steps[0]["output_path"] == workdir / "reports/out.txt"
    assert steps[0]["cwd"] == workdir / "child"
    assert steps[0]["timeout"] == 5
