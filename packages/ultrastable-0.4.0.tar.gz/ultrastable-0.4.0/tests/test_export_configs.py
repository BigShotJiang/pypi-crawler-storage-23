from __future__ import annotations

import json
from pathlib import Path

from ultrastable.core.events import RunEvent, StepEvent
from ultrastable.export import export_budget_policy, export_routing_policy
from ultrastable.ledger import JsonlLedger
from ultrastable.policy import canonicalize_policy


def _write_ledger(path: Path) -> None:
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(RunEvent(run_id="run1", phase="start", meta={"tags": {"customer": "c1"}}))
        ledger.add(
            StepEvent(
                step_id="s1",
                role="assistant",
                tokens_total=50,
                cost_usd=0.05,
                tags={"customer": "c1"},
            )
        )
        ledger.add(RunEvent(run_id="run1", phase="end", meta={"status": "completed"}))
        ledger.add(RunEvent(run_id="run2", phase="start", meta={"tags": {"customer": "c2"}}))
        ledger.add(
            StepEvent(
                step_id="s2",
                role="assistant",
                tokens_total=30,
                cost_usd=0.03,
                tags={"customer": "c2"},
            )
        )
        ledger.add(RunEvent(run_id="run2", phase="end"))


def test_export_routing_policy_deterministic(tmp_path: Path) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    _write_ledger(ledger_path)
    export1 = export_routing_policy(str(ledger_path), group_by="customer", limit=2)
    export2 = export_routing_policy(str(ledger_path), group_by="customer", limit=2)
    assert export1 == export2
    assert export1["schema"].endswith("routing-policy/v1")
    assert len(export1["routes"]) == 2


def test_export_budget_policy_round_trip(tmp_path: Path) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    _write_ledger(ledger_path)
    policy = export_budget_policy(str(ledger_path), name="auto", group_by="customer")
    canonical = canonicalize_policy(policy)
    assert canonical["name"] == "auto"
    assert canonical["policy"]["variables"]
    # Ensure routes stored in metadata for GitOps use
    assert canonical["meta"]["budget_routes"]
    # Deterministic JSON serialization
    payload = json.dumps(policy, sort_keys=True)
    assert "ledger_sha256" in payload
