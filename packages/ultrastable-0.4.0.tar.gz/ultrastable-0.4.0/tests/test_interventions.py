from __future__ import annotations

from collections.abc import Mapping, MutableMapping, Sequence
from typing import Any

from ultrastable.core.events import TriggerEvent
from ultrastable.interventions import (
    Backoff,
    ContextPrune,
    InterventionRequest,
    PersonaSwap,
    ResetContextTrim,
    ResetModelFallback,
    ResetReplan,
    ResetSummarize,
    ResetToolBreaker,
    StochasticParameterReset,
    StochasticReplan,
    StopTheLine,
)


class DummySummarizer:
    def summarize(
        self, messages: Sequence[Mapping[str, Any]], *, max_chars: int | None = None
    ) -> str:
        text = " | ".join(str(m.get("content", "")) for m in messages)
        if max_chars is not None:
            return text[:max_chars]
        return text


def make_request(state: MutableMapping[str, Any] | None = None) -> InterventionRequest:
    trigger = TriggerEvent(detector="test", severity="warn")
    return InterventionRequest(triggers=[trigger], state=state or {})


def test_context_trim_drops_tool_messages_first() -> None:
    conversation = [
        {"id": "sys", "role": "system", "content": "You are helpful"},
        {"id": "1", "role": "user", "content": "Hi"},
        {"id": "2", "role": "tool", "content": "Verbose tool output"},
        {"id": "3", "role": "assistant", "content": "Response"},
        {"id": "4", "role": "tool", "content": "More tool", "pinned": True},
        {"id": "5", "role": "assistant", "content": "Follow up"},
    ]
    req = make_request({"conversation": conversation})
    intervention = ResetContextTrim(keep_last_turns=2)
    res = intervention.run(req)
    assert res is not None
    assert res.event is not None
    assert res.state is not None
    assert res.outcome is not None
    trimmed_conv = res.state["conversation"]
    ids = [msg["id"] for msg in trimmed_conv]
    # Tool id "2" should be dropped before others, pinned tool "4" kept
    assert "2" not in ids and "4" in ids and "sys" in ids
    outcome = res.outcome
    assert outcome is not None
    assert outcome["post_messages"] <= 4


def test_reset_replan_sets_flag_once() -> None:
    intervention = ResetReplan()
    res1 = intervention.run(make_request({}))
    assert res1 is not None and res1.state is not None and res1.state["force_replan"] is True
    res2 = intervention.run(InterventionRequest(triggers=[], state=res1.state))
    assert res2 is None  # idempotent


def test_tool_breaker_disables_tool_with_cooldown() -> None:
    trigger = TriggerEvent(detector="tool_loop", severity="critical", tags={"tool_name": "search"})
    req = InterventionRequest(triggers=[trigger], state={})
    intervention = ResetToolBreaker(cooldown_steps=3)
    res = intervention.run(req)
    assert res is not None
    assert res.state is not None
    assert res.state["disabled_tools"]["search"] == 3
    # Running again without cooldown change should be a no-op
    res2 = intervention.run(InterventionRequest(triggers=[trigger], state=res.state))
    assert res2 is None


def test_model_fallback_switches_model_once() -> None:
    state = {
        "current_model": "gpt-4",
        "available_models": ["gpt-4", "gpt-3.5"],
        "fallback_model": "gpt-3.5",
    }
    intervention = ResetModelFallback()
    res = intervention.run(make_request(state))
    assert res is not None
    assert res.state is not None
    assert res.state["current_model"] == "gpt-3.5"
    res2 = intervention.run(InterventionRequest(triggers=[], state=res.state))
    assert res2 is None


def test_reset_summarize_adds_summary_and_hash() -> None:
    conversation = [
        {"id": "1", "role": "user", "content": "Hello"},
        {"id": "2", "role": "assistant", "content": "Hi there"},
    ]
    state = {"conversation": conversation}
    summarizer = DummySummarizer()
    intervention = ResetSummarize(summarizer, summarizer_id="dummy", method="concat", max_chars=50)
    res = intervention.run(make_request(state))
    assert res is not None
    assert res.state is not None
    summary_text = res.state["conversation_summary"]
    assert "Hello" in summary_text
    assert res.event is not None
    assert res.event.tags["summarizer_id"] == "dummy"
    assert "summary_hash" in res.event.outcome
    # Summary text should not leak into event parameters or outcome
    event_json = res.event.to_dict()
    assert "Hello" not in str(event_json)


def test_context_prune_summarizes_and_preserves_system() -> None:
    conversation = [
        {"id": "sys", "role": "system", "content": "Stay terse"},
        {"id": "1", "role": "user", "content": "msg1"},
        {"id": "2", "role": "assistant", "content": "msg2"},
        {"id": "3", "role": "user", "content": "msg3"},
        {"id": "4", "role": "assistant", "content": "msg4"},
    ]
    state = {"conversation": conversation}
    summarizer = DummySummarizer()
    intervention = ContextPrune(summarizer, keep_last_turns=2, summary_prefix="Summary:")
    res = intervention.run(make_request(state))
    assert res is not None
    assert res.state is not None
    convo = res.state["conversation"]
    assert convo[0]["role"] == "system"
    assert any(msg.get("tags", {}).get("summary") for msg in convo)
    assert res.outcome is not None
    outcome = res.outcome
    assert outcome["post_messages"] <= 4


def test_persona_swap_inserts_new_prompt_once() -> None:
    conversation = [{"id": "sys", "role": "system", "content": "Default persona"}]
    state = {"conversation": conversation}
    intervention = PersonaSwap(persona_prompt="Debug persona active.")
    res = intervention.run(make_request(state))
    assert res is not None and res.state is not None
    assert res.state["conversation"][0]["content"].startswith("Debug persona")
    res2 = intervention.run(InterventionRequest(triggers=[], state=res.state))
    assert res2 is None


def test_backoff_sets_remaining_steps() -> None:
    intervention = Backoff(steps=4, reason="too_many_errors")
    res = intervention.run(make_request({}))
    assert res is not None and res.state is not None
    assert res.state["backoff"]["remaining_steps"] == 4
    res2 = intervention.run(InterventionRequest(triggers=[], state=res.state))
    assert res2 is None


def test_stop_the_line_marks_halted() -> None:
    trigger = TriggerEvent(detector="guard", severity="critical")
    req = InterventionRequest(triggers=[trigger], state={})
    intervention = StopTheLine()
    res = intervention.run(req)
    assert res is not None and res.state is not None
    assert res.state["halted"] is True
    outcome = res.outcome
    assert outcome is not None
    assert outcome["severity"] == "critical"
    res2 = intervention.run(InterventionRequest(triggers=[trigger], state=res.state))
    assert res2 is None


def test_stochastic_replan_deterministic_seed() -> None:
    request = make_request({})
    i1 = StochasticReplan(noise_std=0.1, seed=42)
    i2 = StochasticReplan(noise_std=0.1, seed=42)
    r1 = i1.run(request)
    r2 = i2.run(make_request({}))
    assert r1 is not None and r2 is not None
    assert r1.event is not None and r2.event is not None
    assert r1.event.stochastic_params == r2.event.stochastic_params
    assert r1.state is not None and r2.state is not None
    assert r1.state["replan_noise"] == r2.state["replan_noise"]


def test_stochastic_parameter_reset_updates_subset() -> None:
    params = {"k1": 1.0, "k2": 2.0, "bias": 0.5}
    request = make_request({"parameters": params})
    intervention = StochasticParameterReset(fraction=0.5, noise_std=0.05, seed=7)
    result = intervention.run(request)
    assert result is not None
    assert result.outcome is not None
    updated = result.outcome["updated_parameters"]
    assert 1 <= len(updated) <= len(params)
    assert result.event is not None
    assert result.event.stochastic_params["reset_keys"] == list(updated.keys())
