from __future__ import annotations

import glob
import json
import os
import tempfile
from pathlib import Path

from ultrastable.core.events import ErrorEvent, InterventionEvent, RunEvent, StepEvent
from ultrastable.ledger import (
    JsonlLedger,
    iter_events,
    rotate,
    summarize_jsonl,
    validate_hash_chain,
)


def test_jsonl_ledger_writes_valid_jsonl_and_redaction() -> None:
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "ledger.jsonl")
        with JsonlLedger(path, redaction="metadata-only", flush="fsync") as ledger:
            ledger.add(RunEvent(run_id="r1", phase="start"))
            ledger.add(
                StepEvent(
                    step_id="s1", prompt_text="secret", response_text="answer", tokens_total=5
                )
            )
            ledger.add(ErrorEvent(category="tool_error", message="details"))

        # Read back lines; each must be valid JSON
        with open(path, encoding="utf-8") as f:
            lines = [ln.strip() for ln in f if ln.strip()]
        assert len(lines) == 3
        for ln in lines:
            data = json.loads(ln)
            assert isinstance(data, dict)

        # Ensure redaction removed raw bodies and included hashes
        evs = list(iter_events(path))
        step = next(e for e in evs if e["event_type"] == "step")
        assert "prompt_text" not in step and step.get("prompt_text_sha256")
        assert "response_text" not in step and step.get("response_text_sha256")
        assert step.get("prompt_hash")
        assert step.get("response_hash")
        assert step["prompt_hash"]["digest"] == step["prompt_text_sha256"]
        assert step["response_hash"]["digest"] == step["response_text_sha256"]
        err = next(e for e in evs if e["event_type"] == "error")
        assert "message" not in err and err.get("message_sha256")
        assert err.get("message_hash")
        assert err["message_hash"]["digest"] == err["message_sha256"]
        # Each entry carries a tamper-evident hash chain
        for idx, ev in enumerate(evs):
            digest = ev.get("event_hash")
            assert isinstance(digest, str)
            assert len(digest) == 64
            int(digest, 16)
            if idx == 0:
                assert ev.get("prev_hash") is None
            else:
                assert ev.get("prev_hash") == evs[idx - 1]["event_hash"]


def test_metadata_only_hash_mode_is_deterministic(tmp_path: Path) -> None:
    path = tmp_path / "ledger.jsonl"
    secret_prompt = "hash-mode-prompt"
    secret_response = "hash-mode-response"
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(
            StepEvent(
                step_id="s1",
                prompt_text=secret_prompt,
                response_text=secret_response,
                tokens_total=1,
            )
        )
        ledger.add(
            StepEvent(
                step_id="s2",
                prompt_text=secret_prompt,
                response_text=secret_response,
                tokens_total=1,
            )
        )

    steps = [ev for ev in iter_events(str(path)) if ev.get("event_type") == "step"]
    assert len(steps) == 2
    assert steps[0]["prompt_hash"] == steps[1]["prompt_hash"]
    assert steps[0]["response_hash"] == steps[1]["response_hash"]
    assert "prompt_text" not in steps[0] and "prompt_text" not in steps[1]
    assert "response_text" not in steps[0] and "response_text" not in steps[1]


def test_metadata_only_hash_mode_strips_raw_file_content(tmp_path: Path) -> None:
    path = tmp_path / "ledger.jsonl"
    secret_prompt = "drop-this-prompt"
    secret_response = "drop-this-response"
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(
            StepEvent(
                step_id="s1",
                prompt_text=secret_prompt,
                response_text=secret_response,
                tokens_total=1,
            )
        )

    raw_text = path.read_text(encoding="utf-8")
    assert secret_prompt not in raw_text
    assert secret_response not in raw_text
    step = next(ev for ev in iter_events(str(path)) if ev.get("event_type") == "step")
    assert step.get("prompt_hash")
    assert step.get("response_hash")
    assert "prompt_text" not in step and "response_text" not in step


def test_ledger_resumes_prev_hash_chain(tmp_path: Path) -> None:
    path = tmp_path / "resume.jsonl"
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(RunEvent(run_id="resume", phase="start"))
        ledger.add(RunEvent(run_id="resume", phase="end"))
    # Capture the last hash from the first session
    initial_events = list(iter_events(str(path)))
    assert len(initial_events) == 2
    last_hash = initial_events[-1]["event_hash"]
    assert isinstance(last_hash, str)

    # Reopen the same ledger and append a new entry
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(StepEvent(step_id="s-resume", tokens_total=1))

    events = list(iter_events(str(path)))
    assert len(events) == 3
    assert events[-1]["prev_hash"] == last_hash


def test_validate_hash_chain_skips_legacy_ledgers(tmp_path: Path) -> None:
    path = tmp_path / "legacy.jsonl"
    records = [
        {
            "event_type": "run",
            "schema_version": "1.1",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "run_id": "legacy",
            "phase": "start",
        },
        {
            "event_type": "step",
            "schema_version": "1.1",
            "timestamp": "2025-01-01T00:01:00.000Z",
            "step_id": "legacy-step",
        },
    ]
    serialized = "\n".join(json.dumps(record) for record in records)
    path.write_text(serialized + "\n", encoding="utf-8")

    result = validate_hash_chain(str(path))
    assert result.ok
    assert result.chain_present is False
    assert result.events == 0


def test_validate_hash_chain_handles_legacy_prefix(tmp_path: Path) -> None:
    path = tmp_path / "hybrid.jsonl"
    legacy_records = [
        {
            "event_type": "run",
            "schema_version": "1.1",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "run_id": "legacy",
            "phase": "start",
        }
    ]
    path.write_text(
        "\n".join(json.dumps(record) for record in legacy_records) + "\n",
        encoding="utf-8",
    )

    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(StepEvent(step_id="s1", tokens_total=1))
        ledger.add(StepEvent(step_id="s2", tokens_total=2))

    result = validate_hash_chain(str(path))
    assert result.ok
    assert result.chain_present is True
    assert result.events == 2


def test_default_mode_drops_raw_prompt_and_response(tmp_path: Path) -> None:
    path = tmp_path / "default_ledger.jsonl"
    secret_prompt = "default redaction prompt"
    secret_response = "default redaction response"
    with JsonlLedger(str(path)) as ledger:
        ledger.add(
            StepEvent(
                step_id="default",
                prompt_text=secret_prompt,
                response_text=secret_response,
                tokens_total=1,
            )
        )

    content = path.read_text(encoding="utf-8")
    assert secret_prompt not in content
    assert secret_response not in content
    step = next(ev for ev in iter_events(str(path)) if ev.get("event_type") == "step")
    assert step["redaction_level"] == "metadata-only"
    assert "prompt_text" not in step and "response_text" not in step
    assert step.get("prompt_hash") and step.get("response_hash")


def test_size_rotation_creates_new_file() -> None:
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "ledger.jsonl")
        # Small max_bytes to force rotation on second write
        ledger = JsonlLedger(path, redaction="metadata-only", max_bytes=100)
        try:
            ledger.add(RunEvent(run_id="r1", phase="start"))
            ledger.add(RunEvent(run_id="r2", phase="start"))
        finally:
            ledger.close()

        files = sorted(glob.glob(os.path.join(td, "ledger-*.jsonl")))
        assert len(files) >= 1  # at least one rotated file
        # Base file should also exist
        assert os.path.exists(path)

        # All files contain valid JSON lines
        for fp in [path] + files:
            for ev in iter_events(fp):
                assert isinstance(ev, dict)


def test_summarize_jsonl_counts_and_totals() -> None:
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "ledger.jsonl")
        with JsonlLedger(path, redaction="metadata-only") as ledger:
            ledger.add(StepEvent(step_id="s1", tokens_total=3, cost_usd=0.002))
            ledger.add(StepEvent(step_id="s2", tokens_total=7, cost_usd=0.004))
        summary = summarize_jsonl(path)
        assert summary["events_total"] == 2
        assert summary["by_type"]["step"] == 2
        assert summary["cost"]["tokens"] == 10
        assert abs(summary["cost"]["usd"] - 0.006) < 1e-9


def test_summarize_jsonl_highlights_tool_calls_and_outcomes(tmp_path: Path) -> None:
    path = tmp_path / "ledger.jsonl"
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(
            StepEvent(
                step_id="tool-1",
                role="tool",
                kind="tool",
                tokens_total=1,
                cost_usd=0.001,
            )
        )
        ledger.add(
            StepEvent(
                step_id="llm-1",
                role="assistant",
                kind="llm",
                tokens_total=2,
                cost_usd=0.002,
            )
        )
        ledger.add(
            InterventionEvent(
                intervention_type="RESET_REPLAN_OUTCOME",
                tags={"status": "APPLIED"},
                outcome={"status": "applied"},
            )
        )

    summary = summarize_jsonl(str(path))
    assert summary["steps"]["total"] == 2
    assert summary["steps"]["tool_calls"] == 1
    assert summary["steps"]["by_kind"]["tool"] == 1
    assert summary["interventions"]["outcomes"]["applied"] == 1


def test_iter_events_skips_truncated_lines(tmp_path: Path) -> None:
    path = tmp_path / "ledger.jsonl"
    with JsonlLedger(str(path), redaction="metadata-only") as ledger:
        ledger.add(StepEvent(step_id="complete", tokens_total=1))
    # Simulate crash during write by appending an incomplete JSON fragment
    with path.open("ab") as fp:
        fp.write(b'{"event_type":"step","step_id":"partial"')
    events = list(iter_events(str(path)))
    assert len(events) == 1
    assert events[0]["step_id"] == "complete"


def test_manual_rotate_creates_index_and_prunes(tmp_path: Path) -> None:
    path = tmp_path / "ledger.jsonl"

    def write_large_payload(step_prefix: str) -> None:
        with JsonlLedger(str(path), redaction="full-text") as ledger:
            for idx in range(5):
                ledger.add(
                    StepEvent(
                        step_id=f"{step_prefix}-{idx}",
                        prompt_text="x" * 4096,
                        response_text="y" * 4096,
                    )
                )

    write_large_payload("a")
    result = rotate(str(path), max_mb=0.01, keep=2)
    assert result["rotated_now"] is not None
    index_path = Path(result["index_path"])
    assert index_path.exists()
    assert len(result["rotated"]) == 1
    assert all(Path(p).exists() for p in result["rotated"])
    assert Path(result["base_path"]).exists()

    # Trigger two more rotations and ensure only the newest two files are kept
    write_large_payload("b")
    rotate(str(path), max_mb=0.01, keep=2)
    write_large_payload("c")
    final_result = rotate(str(path), max_mb=0.01, keep=2)
    assert len(final_result["rotated"]) == 2
    assert all(Path(p).exists() for p in final_result["rotated"])
    assert final_result["removed"], "expected older rotations to be pruned"
    # Index file should list the same entries returned by rotate(...)
    index_data = json.loads(index_path.read_text(encoding="utf-8"))
    assert index_data["rotations"] == final_result["rotated"]
