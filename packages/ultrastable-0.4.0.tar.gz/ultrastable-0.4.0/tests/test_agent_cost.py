from ultrastable.agent.cost import CostModel


def test_cost_model_with_reported_cost() -> None:
    model = CostModel()
    snapshot = model.update(tokens_total=100, cost_usd=0.02)
    assert snapshot is not None
    assert snapshot.tokens_total == 100
    assert snapshot.cost_usd == 0.02
    assert snapshot.mode == "reported"


def test_cost_model_estimates_from_tokens() -> None:
    model = CostModel(cost_per_token=0.0001)
    snapshot = model.update(tokens_prompt=0, tokens_completion=50, cost_usd=None)
    assert snapshot is not None
    assert snapshot.tokens_total == 50
    assert snapshot.cost_usd is not None
    assert abs(snapshot.cost_usd - 0.005) < 1e-9
    assert snapshot.mode == "estimated"


def test_cost_model_tokens_only_mode() -> None:
    model = CostModel()
    snapshot = model.update(tokens_total=20)
    assert snapshot is not None
    assert snapshot.tokens_total == 20
    assert snapshot.cost_usd is None
    assert snapshot.mode == "tokens_only"


def test_cost_model_unknown_returns_none() -> None:
    model = CostModel()
    assert model.update() is None
