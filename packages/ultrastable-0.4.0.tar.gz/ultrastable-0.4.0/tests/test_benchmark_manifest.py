from __future__ import annotations

import json
from typing import Any

import pytest

from ultrastable.benchmark.manifest import (
    MANIFEST_SCHEMA_VERSION,
    EnvironmentSnapshot,
    PolicyDescriptor,
    RunManifest,
    SeedBlock,
    SuiteDescriptor,
    capture_environment_snapshot,
)


def test_run_manifest_round_trip() -> None:
    manifest = RunManifest(
        schema_version=MANIFEST_SCHEMA_VERSION,
        suite=SuiteDescriptor(
            name="afmb",
            version="v1",
            variant="smoke",
            description="AFMB smoke tests",
            cases=("s1", "s2"),
            parameters={"budget": "5m"},
        ),
        seeds=SeedBlock(
            global_seed=123,
            suite={"afmb": 321},
            cases={"s1": 111, "s2": 222},
            policies={"guard": 42},
            extra={"reset": 77},
        ),
        policies=(
            PolicyDescriptor(
                name="guard",
                version="2026-02-25",
                role="controller",
                path="configs/guard.json",
                policy_hash="sha256:abc123",
                description="Reference guard",
                metadata={"policy_pack_schema": "policy_pack/v1"},
            ),
        ),
        env=EnvironmentSnapshot(
            platform={
                "system": "Linux",
                "release": "6.8.0",
                "version": "#1 SMP",
                "machine": "x86_64",
                "processor": "generic",
            },
            python={"implementation": "CPython", "version": "3.10.13"},
            ultrastable_version="0.3.0",
            hostname="ci-host",
            git={"commit": "deadbeef", "dirty": False},
            extra={"python_executable": "/usr/bin/python3"},
        ),
        run_id="afmb-run-001",
        created_at="2026-02-26T00:00:00Z",
        command="ultrastable benchmark run --suite afmb --output runs/afmb --seed 123",
        output_dir="runs/afmb",
        metadata={"ci_build": "nightly"},
        tags=("afmb", "smoke"),
    )

    payload = manifest.to_dict()
    assert payload["suite"]["name"] == "afmb"
    assert payload["seeds"]["global"] == 123
    assert payload["policies"][0]["policy_hash"] == "sha256:abc123"
    rebuilt = RunManifest.from_dict(payload)
    assert rebuilt == manifest

    json_payload = manifest.to_json()
    parsed = json.loads(json_payload)
    assert parsed["suite"]["version"] == "v1"
    assert RunManifest.from_json(json_payload) == manifest


def test_capture_environment_snapshot_has_minimum_fields() -> None:
    snapshot = capture_environment_snapshot(include_git=False)
    env_dict = snapshot.to_dict()
    assert env_dict["platform"]["system"]
    assert env_dict["python"]["implementation"]
    assert env_dict["ultrastable_version"]
    # Git metadata was disabled explicitly.
    assert "git" not in env_dict


def test_run_manifest_rejects_invalid_policies_block() -> None:
    payload = _minimal_manifest_dict()
    payload["policies"] = "oops"
    with pytest.raises(ValueError):
        RunManifest.from_dict(payload)


def test_seed_block_requires_integer_values() -> None:
    payload = _minimal_manifest_dict()
    payload["seeds"]["suite"] = {"afmb": "abc"}
    with pytest.raises(ValueError):
        RunManifest.from_dict(payload)


def _minimal_manifest_dict() -> dict[str, Any]:
    return {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "suite": {"name": "afmb", "version": "v1"},
        "seeds": {"global": 42},
        "policies": [],
        "env": {
            "platform": {
                "system": "Linux",
                "release": "6.8.0",
                "version": "#1",
                "machine": "x86_64",
                "processor": "generic",
            },
            "python": {"implementation": "CPython", "version": "3.10.13"},
            "ultrastable_version": "0.3.0",
        },
    }
