from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ultrastable.cli.demos import build_agent_loop_controller
from ultrastable.core import EssentialVariable, EssentialVariableSpace, HealthModel, ViabilityPolicy
from ultrastable.robotics import DriveReward, DriveWrapper


class DummyEnv:
    def __init__(self) -> None:
        self.state = 0.0

    def reset(self) -> float:
        self.state = 0.0
        return self.state

    def step(self, action: float) -> tuple[float, float, bool, bool, dict[str, Any]]:
        self.state += action
        return self.state, 1.0, False, False, {}


class MemoryLedger:
    def __init__(self, redaction: str = "metadata-only") -> None:
        self.events: list[Any] = []
        self._redaction = redaction

    @property
    def redaction(self) -> str:
        return self._redaction

    def add(self, event: Any) -> None:
        self.events.append(event)


def _event_type(event: Any) -> str | None:
    if isinstance(event, Mapping):
        return event.get("event_type")
    return getattr(event, "event_type", None)


def test_drive_reward_modes() -> None:
    controller = build_agent_loop_controller()
    ledger = MemoryLedger()
    env = DummyEnv()
    wrapper = DriveWrapper(env, controller=controller, ledger=ledger, reward_mode="mixed")
    wrapper.reset(metrics={"context_util": 0.1, "spend_usd": 0.0, "tokens_total": 0.0})
    _, reward1, *_ = wrapper.step(
        action=0.1,
        metrics={"context_util": 0.2, "spend_usd": 0.0, "tokens_total": 5},
    )
    _, reward2, *_ = wrapper.step(
        action=0.1,
        metrics={"context_util": 0.9, "spend_usd": 0.01, "tokens_total": 8},
    )
    assert reward2 <= reward1
    info = wrapper.step(
        action=0.0,
        metrics={"context_util": 0.5, "spend_usd": 0.01, "tokens_total": 3},
    )[4]
    assert "drive_reward" in info and "d_h" in info
    step_event = next(e for e in ledger.events if _event_type(e) == "step")
    assert getattr(step_event, "d_h", None) is not None

    drive_only = DriveWrapper(env, controller=controller, reward_mode="drive_only")
    drive_only.reset(metrics={"context_util": 0.1, "spend_usd": 0.0, "tokens_total": 0.0})
    _, drive_reward_only, *_ = drive_only.step(
        action=0.1,
        metrics={"context_util": 0.8, "spend_usd": 0.02, "tokens_total": 10},
    )
    assert drive_reward_only <= 0  # purely driven by D(H)


def test_drive_wrapper_handles_long_runs() -> None:
    controller = build_agent_loop_controller()
    env = DummyEnv()
    wrapper = DriveWrapper(env, controller=controller, reward_mode="task_only")
    wrapper.reset(metrics={"context_util": 0.1, "spend_usd": 0.0, "tokens_total": 0.0})
    for idx in range(60):
        wrapper.step(
            action=0.05,
            metrics={
                "context_util": min(0.99, 0.2 + idx * 0.01),
                "spend_usd": 0.001 * idx,
                "tokens_total": 5 + idx,
            },
        )


def test_drive_reward_handles_mixed_variables() -> None:
    space = EssentialVariableSpace(
        [
            EssentialVariable.bounded("temp", min=0.0, max=1.0, scale=1.0),
            EssentialVariable.monotonic("wear", hard_limit=10.0, scale=10.0),
        ]
    )
    policy = ViabilityPolicy(space=space, health=HealthModel("l2"))
    reward = DriveReward(policy, mode="delta")
    reward.reset({"temp": 0.2, "wear": 1.0})
    first = reward.compute({"temp": 0.8, "wear": 4.0})
    assert first["reward"] < 0  # drive increased
    second = reward.compute({"temp": 0.1, "wear": 2.0})
    assert second["reward"] > 0  # drive reduced

    negative = DriveReward(policy, mode="negative")
    negative.reset({"temp": 0.2, "wear": 1.0})
    neg = negative.compute({"temp": 0.4, "wear": 1.5})
    assert neg["reward"] == -neg["d_h"]
