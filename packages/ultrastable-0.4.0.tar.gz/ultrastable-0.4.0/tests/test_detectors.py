from __future__ import annotations

from typing import Any

import pytest

from ultrastable.core.events import HealthSnapshotEvent, StepEvent
from ultrastable.detectors import (
    ContextPressureDetector,
    ContextRotDetector,
    LexicalRepeatDetector,
    PredictiveBudgetExhaustionDetector,
    SemanticLoopDetector,
    ToolFailureDetector,
    ToolLoopDetector,
)


def make_step(**kwargs: Any) -> StepEvent:
    return StepEvent(**kwargs)


def test_lexical_repeat_detector_triggers_on_repetition() -> None:
    detector = LexicalRepeatDetector(repeat_threshold=3, similarity_threshold=0.8, min_chars=5)
    steps = [
        make_step(step_id=str(i), role="assistant", response_text=text)
        for i, text in enumerate(["Hello world", "Hello world!", "hello  world   "])
    ]
    triggers = detector.evaluate(steps)
    assert triggers and triggers[0].detector == detector.name
    assert triggers[0].severity in {"warn", "critical"}


def test_tool_loop_detector_detects_identical_calls_and_failures() -> None:
    detector = ToolLoopDetector(repeat_threshold=3)
    steps = [
        make_step(step_id="t1", kind="tool", tool_name="search", tool_args_hash="abc"),
        make_step(step_id="t2", kind="tool", tool_name="search", tool_args_hash="abc"),
        make_step(step_id="t3", kind="tool", tool_name="search", tool_args_hash="abc"),
    ]
    triggers = detector.evaluate(steps)
    assert any(t.explanation and "identical" in t.explanation for t in triggers)

    failure_steps = [
        make_step(step_id="f1", kind="tool", tool_name="api", tags={"status": "error"}),
        make_step(step_id="f2", kind="tool", tool_name="api", tags={"status": "error"}),
        make_step(step_id="f3", kind="tool", tool_name="api", tags={"status": "error"}),
    ]
    triggers2 = detector.evaluate(failure_steps)
    assert any(t.severity == "critical" for t in triggers2)


def test_context_pressure_detector_warns_on_high_utilization() -> None:
    detector = ContextPressureDetector(max_tokens=100, warn_fraction=0.5, critical_fraction=0.8)
    steps = [make_step(step_id="s1", tokens_total=60)]
    triggers = detector.evaluate(steps)
    assert triggers and triggers[0].severity == "warn"

    steps2 = [make_step(step_id="s2", tokens_total=90)]
    triggers2 = detector.evaluate(steps2)
    assert triggers2 and triggers2[0].severity == "critical"


def test_context_pressure_uses_snapshot_value_when_available() -> None:
    detector = ContextPressureDetector(max_tokens=100, warn_fraction=0.1, critical_fraction=0.2)
    step = make_step(step_id="s1", tokens_total=1)
    snapshot = HealthSnapshotEvent(values={"context_util": 0.25})
    triggers = detector.evaluate([step], [snapshot])
    assert triggers and triggers[0].severity == "critical"


def test_semantic_loop_detector_detects_cosine_similarity() -> None:
    detector = SemanticLoopDetector(
        window_size=4, min_turns=3, similarity_threshold=0.6, min_chars=4
    )
    steps = [
        make_step(step_id=f"sem-{i}", role="assistant", response_text="Repeat this exact answer")
        for i in range(3)
    ]
    triggers = detector.evaluate(steps)
    assert triggers and triggers[0].detector == "semantic_loop"
    assert detector.evaluate(steps)  # last change still similar enough due to normalization


def test_context_rot_detector_tracks_growth_from_snapshots() -> None:
    detector = ContextRotDetector(
        window_size=4, warn_threshold=0.5, critical_threshold=0.8, max_tokens=500
    )
    steps = [make_step(step_id="ctx-0", tokens_total=100)]
    snapshots = [
        HealthSnapshotEvent(values={"context_util": value}) for value in (0.4, 0.45, 0.52, 0.85)
    ]
    triggers = detector.evaluate(steps, snapshots)
    assert triggers and triggers[0].severity == "critical"

    # fallback to token-based estimate
    steps2 = [
        make_step(step_id=f"ctx-{i}", tokens_total=count, tags={})
        for i, count in enumerate([100, 150, 250, 350])
    ]
    triggers2 = detector.evaluate(steps2, None)
    assert triggers2


def test_tool_failure_detector_ratios_and_consecutive() -> None:
    detector = ToolFailureDetector(
        window_size=5, warn_ratio=0.4, critical_ratio=0.6, consecutive_threshold=2
    )
    steps = [
        make_step(step_id=f"tool-{i}", kind="tool", tool_name="api", tags={"status": status})
        for i, status in enumerate(["ok", "error", "error", "error", "ok"])
    ]
    triggers = detector.evaluate(steps)
    assert triggers and triggers[0].severity == "critical"

    warn_steps = [
        make_step(step_id=f"warn-{i}", kind="tool", tool_name="api", tags={"status": status})
        for i, status in enumerate(["ok", "error", "ok", "error", "ok"])
    ]
    triggers2 = detector.evaluate(warn_steps)
    assert triggers2 and all(t.severity in {"warn", "critical"} for t in triggers2)


def test_optional_detectors_not_imported_by_default() -> None:
    import sys

    __import__("ultrastable.detectors")
    assert "ultrastable.detectors.extras" not in sys.modules


def test_predictive_budget_detector_warns_and_is_deterministic() -> None:
    detector = PredictiveBudgetExhaustionDetector(
        budget_limit=1.0,
        window_size=5,
        warn_horizon_steps=4.0,
        critical_horizon_steps=2.0,
    )
    steps = [
        make_step(step_id=f"budget-{i}", kind="llm", cost_usd=0.1, latency_ms=500) for i in range(6)
    ]
    triggers = detector.evaluate(steps)
    assert triggers and triggers[0].severity == "warn"
    explanation = triggers[0].explanation or ""
    assert explanation.startswith("projected spend/time horizon:")
    assert "(~2.0s)" in explanation
    assert triggers[0].tags.get("reason") == "projected spend/time horizon"
    eta_seconds = triggers[0].tags.get("eta_seconds")
    assert isinstance(eta_seconds, (int, float))
    assert float(eta_seconds) == pytest.approx(2.0, rel=1e-6)
    assert detector.evaluate(steps)[0].explanation == triggers[0].explanation


def test_predictive_budget_detector_uses_snapshots_and_marks_critical() -> None:
    detector = PredictiveBudgetExhaustionDetector(
        budget_limit=0.75,
        window_size=4,
        warn_horizon_steps=3.0,
        critical_horizon_steps=1.5,
    )
    steps = [
        make_step(step_id=f"crit-{i}", kind="llm", cost_usd=0.15, latency_ms=750) for i in range(4)
    ]
    snapshot = HealthSnapshotEvent(values={"spend_usd": 0.6})
    triggers = detector.evaluate(steps, [snapshot])
    assert triggers and triggers[0].severity == "critical"
    assert "0.6" in (triggers[0].explanation or "")
    assert triggers[0].tags.get("reason") == "projected spend/time horizon"
