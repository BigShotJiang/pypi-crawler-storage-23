from __future__ import annotations

import pytest

from ultrastable.detectors import LexicalRepeatDetector
from ultrastable.detectors.registry import DetectorRegistry, create_default_registry
from ultrastable.interventions import ResetContextTrim
from ultrastable.interventions.registry import (
    InterventionRegistry,
)
from ultrastable.interventions.registry import (
    create_default_registry as create_intervention_registry,
)


def test_detector_registry_builds_with_params() -> None:
    registry = DetectorRegistry()
    registry.register("lexical_repeat", LexicalRepeatDetector)
    detector = registry.build({"kind": "lexical_repeat", "params": {"repeat_threshold": 5}})
    assert isinstance(detector, LexicalRepeatDetector)
    assert detector.repeat_threshold == 5


def test_detector_registry_duplicate_registration_error() -> None:
    registry = DetectorRegistry()
    registry.register("lexical_repeat", LexicalRepeatDetector)
    with pytest.raises(ValueError):
        registry.register("lexical_repeat", LexicalRepeatDetector)
    with pytest.raises(KeyError):
        registry.build("tool_loop")


def test_default_detector_registry_lists_builtins() -> None:
    registry = create_default_registry()
    assert "lexical_repeat" in registry.available()


def test_intervention_registry_builds_instances() -> None:
    registry = InterventionRegistry()
    registry.register("reset_context_trim", ResetContextTrim)
    intervention = registry.build({"kind": "reset_context_trim", "params": {"keep_last_turns": 2}})
    assert isinstance(intervention, ResetContextTrim)


def test_intervention_registry_duplicate_registration_error() -> None:
    registry = InterventionRegistry()
    registry.register("reset_context_trim", ResetContextTrim)
    with pytest.raises(ValueError):
        registry.register("reset_context_trim", ResetContextTrim)
    with pytest.raises(KeyError):
        registry.build("unknown")


def test_default_intervention_registry_lists_builtins() -> None:
    registry = create_intervention_registry()
    assert "reset_context_trim" in registry.available()
