from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ultrastable.agent import AgentGuard, AgentStepResult, MultiPolicyGuard, PolicyBand, StepMetrics
from ultrastable.core import (
    Controller,
    ControllerDecision,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    TaskCoupledVariable,
    ViabilityPolicy,
)
from ultrastable.detectors import LexicalRepeatDetector
from ultrastable.interventions import ResetContextTrim, ResetReplan
from ultrastable.interventions.base import InterventionResult
from ultrastable.ledger import JsonlLedger


class MemoryLedger:
    def __init__(self, redaction: str = "metadata-only") -> None:
        self.events: list[Any] = []
        self._redaction = redaction

    @property
    def redaction(self) -> str:
        return self._redaction

    def add(self, event: Any) -> None:
        if isinstance(event, list):
            self.events.extend(event)
        else:
            self.events.append(event)


class RecordingTelemetry:
    def __init__(self) -> None:
        self.starts: list[tuple[str, str | None]] = []
        self.ends: list[str | None] = []
        self.snapshots: list[float | None] = []
        self.metrics: list[tuple[float | int | None, float | int | None, float | int | None]] = []
        self.triggers: list[int] = []
        self.interventions: list[bool] = []

    def start_run(self, run_id: str, policy_hash: str | None) -> None:
        self.starts.append((run_id, policy_hash))

    def end_run(self, status: str | None) -> None:
        self.ends.append(status)

    def record_snapshot(self, d_h: float | None) -> None:
        self.snapshots.append(d_h)

    def record_step_metrics(
        self,
        *,
        tokens_total: float | int | None,
        spend_usd: float | int | None,
        errors: float | int | None = None,
    ) -> None:
        self.metrics.append((tokens_total, spend_usd, errors))

    def record_trigger_count(self, count: int) -> None:
        self.triggers.append(count)

    def record_intervention(self, applied: bool) -> None:
        self.interventions.append(applied)


def build_controller() -> Controller:
    space = EssentialVariableSpace(
        [
            EssentialVariable.bounded("context_util", min=0.0, max=1.0, scale=1.0),
            EssentialVariable.monotonic("spend_usd", hard_limit=0.01, scale=0.01),
            EssentialVariable.monotonic("tokens_total", hard_limit=200, scale=200),
        ]
    )
    policy = ViabilityPolicy(
        space=space,
        health=HealthModel("l2"),
        monotonic_warn_fraction=0.8,
        bounded_warn_fraction=0.15,
    )
    controller = Controller(
        policy=policy,
        detectors=[LexicalRepeatDetector(repeat_threshold=3)],
        interventions=[ResetContextTrim(keep_last_turns=2), ResetReplan()],
    )
    return controller


def build_coupled_controller() -> Controller:
    coupled = TaskCoupledVariable(
        name="trust_battery",
        decay=0.2,
        coupling={"func": "linear", "params": {"k": 0.5, "c": 0.0}},
        min_value=0.0,
        max_value=1.0,
        start_value=1.0,
    )
    space = EssentialVariableSpace(
        [
            EssentialVariable.monotonic("tokens_total", hard_limit=200, scale=200),
        ],
        coupled_variables=[coupled],
    )
    policy = ViabilityPolicy(space=space, health=HealthModel("l2"), monotonic_warn_fraction=0.8)
    return Controller(policy=policy, detectors=[], interventions=[])


def test_agent_guard_records_steps_and_triggers() -> None:
    ledger = MemoryLedger()
    controller = build_controller()
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=200)
    guard.start_run(run_id="test-run")
    conversation = [{"id": "sys", "role": "system", "content": "Be terse."}]
    guard.pre_step(conversation)
    responses = ["This is a repetitive reply." for _ in range(3)]
    for idx, response in enumerate(responses):
        guard.post_step(
            step_id=f"step-{idx}",
            role="assistant",
            kind="llm",
            model="demo",
            prompt_text="say hello",
            response_text=response,
            metrics=StepMetrics(tokens_prompt=5, tokens_completion=5, cost_usd=0.0005),
            tags={"iteration": idx},
        )
    guard.end_run(status="completed")

    step_events = [e for e in ledger.events if e.get("event_type") == "step"]
    assert len(step_events) == 3
    assert all("d_h" in ev and ev["d_h"] is not None for ev in step_events)
    snapshots = [e for e in ledger.events if e.get("event_type") == "health_snapshot"]
    assert snapshots and all("d_h" in snap and snap["d_h"] is not None for snap in snapshots)
    trigger_events = [e for e in ledger.events if e.get("event_type") == "trigger"]
    assert any(ev["detector"] == "lexical_repeat" for ev in trigger_events)


def test_agent_guard_emits_telemetry_hooks() -> None:
    ledger = MemoryLedger()
    controller = build_controller()
    controller.policy_metadata = {"policy_hash": "sha256:demo"}  # type: ignore[attr-defined]
    controller.interventions = []
    telemetry = RecordingTelemetry()
    guard = AgentGuard(
        controller,
        ledger=ledger,
        context_budget_chars=200,
        telemetry=telemetry,
    )
    guard.start_run(run_id="telemetry-run")
    guard.pre_step([{"id": "sys", "role": "system", "content": "Be stable."}])
    decision = guard.post_step(
        step_id="step-0",
        role="assistant",
        kind="llm",
        model="demo",
        prompt_text="Say hello",
        response_text="Hello!",
        metrics=StepMetrics(tokens_total=10, cost_usd=0.01),
    )
    guard.end_run(status="completed")

    assert telemetry.starts == [("telemetry-run", "sha256:demo")]
    assert telemetry.ends == ["completed"]
    assert telemetry.metrics[0] == (10, 0.01, None)
    assert telemetry.snapshots and telemetry.snapshots[-1] is not None
    assert telemetry.triggers and telemetry.triggers[-1] == len(decision.triggers)
    assert telemetry.interventions == []


def test_agent_guard_records_intervention_telemetry() -> None:
    ledger = MemoryLedger()
    controller = build_controller()
    telemetry = RecordingTelemetry()
    guard = AgentGuard(
        controller,
        ledger=ledger,
        context_budget_chars=200,
        telemetry=telemetry,
    )

    def fake_update(
        self: Controller,
        step_event: Any,
        snapshot: Any = None,
        state: Any = None,
    ) -> ControllerDecision:
        decision = ControllerDecision(
            triggers=[],
            policy_status="warn",
            intervention=InterventionResult(plan={"action": "trim"}),
        )
        return decision

    controller.update = fake_update.__get__(controller, Controller)  # type: ignore[method-assign]
    guard.start_run(run_id="intervention-run")
    guard.post_step(
        step_id="step-intervention",
        role="assistant",
        kind="llm",
        model="demo",
        prompt_text="Trigger intervention",
        response_text="Intervention applied",
        metrics=StepMetrics(tokens_total=5, cost_usd=0.005, errors=1),
    )
    guard.end_run(status="completed")

    assert telemetry.interventions == [True]
    assert telemetry.metrics and telemetry.metrics[-1][-1] == 1


def test_agent_guard_redacts_prompt_bodies_by_default() -> None:
    ledger = MemoryLedger()
    controller = build_controller()
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=None)
    guard.start_run(run_id="redact-default")
    guard.pre_step([{"id": "u", "role": "user", "content": "hi"}])
    guard.post_step(
        step_id="s1",
        role="assistant",
        prompt_text="secret prompt",
        response_text="classified response",
        metrics=StepMetrics(tokens_total=5),
    )
    guard.end_run()
    step_event = next(e for e in ledger.events if e.get("event_type") == "step")
    assert "prompt_text" not in step_event
    assert "response_text" not in step_event
    assert step_event["prompt_hash"]["algorithm"] == "sha256"
    assert step_event["response_hash"]["digest"]


def test_agent_guard_honors_full_text_redaction() -> None:
    ledger = MemoryLedger(redaction="full-text")
    controller = build_controller()
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=None)
    guard.start_run(run_id="full-text")
    guard.post_step(
        step_id="s1",
        role="assistant",
        prompt_text="keep me",
        response_text="and me",
        metrics=StepMetrics(tokens_total=1),
    )
    guard.end_run()
    step_event = next(e for e in ledger.events if e.get("event_type") == "step")
    assert step_event["prompt_text"] == "keep me"
    assert step_event["response_text"] == "and me"
    assert step_event["redaction_level"] == "full-text"


def test_agent_guard_budget_stop(tmp_path: Path) -> None:
    ledger_path = tmp_path / "agent.jsonl"
    ledger = JsonlLedger(str(ledger_path))
    controller = build_controller()
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=500)
    guard.start_run(run_id="budget")
    guard.pre_step([{"id": "sys", "role": "system", "content": "hi"}])
    critical_seen = False
    for idx in range(10):
        decision = guard.post_step(
            step_id=f"budget-{idx}",
            role="assistant",
            kind="llm",
            prompt_text="status?",
            response_text="Still working",
            metrics=StepMetrics(tokens_prompt=10, tokens_completion=10, cost_usd=0.002),
        )
        if decision.policy_status == "critical":
            critical_seen = True
            break
    guard.end_run()
    ledger.close()
    assert critical_seen
    with open(ledger_path, encoding="utf-8") as fp:
        lines = [json.loads(line) for line in fp if line.strip()]
    assert any(line["event_type"] == "trigger" for line in lines)


def test_agent_guard_task_signal_emits_coupling_events() -> None:
    ledger = MemoryLedger()
    controller = build_coupled_controller()
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=None)
    guard.start_run(run_id="trust-battery")
    guard.pre_step([{"id": "sys", "role": "system", "content": "stay on task"}])
    guard.post_step(
        step_id="s0",
        role="assistant",
        metrics=StepMetrics(tokens_total=5),
        task_signal=0.5,
    )
    guard.post_step(
        step_id="s1",
        role="assistant",
        metrics=StepMetrics(tokens_total=5),
        feedback={"signal": 0.2, "dt": 0.5},
    )
    guard.end_run()
    coupling_events = [e for e in ledger.events if e.get("event_type") == "task_coupling"]
    assert len(coupling_events) >= 2
    assert coupling_events[0]["task_signal"] == 0.5
    assert coupling_events[1]["dt"] == 0.5


def test_multi_policy_guard_switches_based_on_dh() -> None:
    space = EssentialVariableSpace(
        [EssentialVariable.monotonic("tokens_total", hard_limit=100, scale=100)]
    )
    normal_policy = ViabilityPolicy(space=space, health=HealthModel("l2"))
    recovery_policy = ViabilityPolicy(space=space, health=HealthModel("l2"))
    normal = Controller(policy=normal_policy)
    recovery = Controller(policy=recovery_policy, cooldown_steps=0)
    bands = [
        PolicyBand(name="normal", controller=normal, enter_dh=0.0, exit_dh=0.2),
        PolicyBand(name="recovery", controller=recovery, enter_dh=0.8, exit_dh=0.3),
    ]
    ledger = MemoryLedger()
    guard = MultiPolicyGuard(bands, ledger=ledger, context_budget_chars=None, accumulate_metrics=())
    guard.accumulate_metrics = set()
    guard.start_run(run_id="multi")
    guard.pre_step([{"id": "sys", "role": "system", "content": "test"}])
    guard.post_step(
        step_id="high",
        role="assistant",
        metrics=StepMetrics(tokens_total=90),
    )
    assert guard.active_policy == "recovery"
    guard.post_step(
        step_id="recover",
        role="assistant",
        metrics=StepMetrics(tokens_total=10),
    )
    assert guard.active_policy == "normal"
    guard.end_run()
    switch_events = [e for e in ledger.events if e.get("event_type") == "policy_switch"]
    assert len(switch_events) >= 2


def test_agent_guard_run_events_include_policy_hash() -> None:
    ledger = MemoryLedger()
    controller = build_controller()
    controller.policy_metadata = {"policy_name": "demo", "policy_hash": "abc123"}  # type: ignore[attr-defined]
    guard = AgentGuard(controller, ledger=ledger, context_budget_chars=None)
    guard.start_run(run_id="hash-test")
    guard.end_run()
    run_events = [e for e in ledger.events if e.get("event_type") == "run"]
    assert run_events[0]["policy_hash"] == "abc123"
    assert run_events[-1]["policy_hash"] == "abc123"


def test_agent_guard_hooks_wrap_dummy_agent() -> None:
    ledger = MemoryLedger()
    controller = build_controller()

    class HookedGuard(AgentGuard):
        def __init__(self, controller: Controller) -> None:
            super().__init__(controller, ledger=ledger, context_budget_chars=None)
            self.breaches: list[str] = []

        def on_viability_breach(self, decision: ControllerDecision) -> None:
            self.breaches.append(decision.policy_status)

    guard = HookedGuard(controller)
    guard.start_run(run_id="hook-demo")
    guard.preflight([{"id": "sys", "role": "system", "content": "stay brief"}])

    def dummy_agent(step_id: str) -> AgentStepResult:
        return AgentStepResult(
            step_id=step_id,
            prompt_text="summarize status",
            response_text="working",
            tags={"iteration": step_id},
        )

    metrics = StepMetrics(tokens_total=150, cost_usd=0.001)
    guard.postflight(dummy_agent("hook-0"), metrics)
    decision = guard.postflight(
        {"step_id": "hook-1", "prompt_text": "update?", "response_text": "still working"},
        metrics,
    )
    guard.end_run()
    assert guard.controller.policy.space.get("tokens_total") == 300.0
    assert guard.breaches and decision.policy_status in {"warn", "critical"}
