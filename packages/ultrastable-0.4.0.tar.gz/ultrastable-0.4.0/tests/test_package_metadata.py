from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PyProjectMeta:
    name: str
    version: str
    readme_path: str
    classifiers: list[str]
    license: str


def _extract_project_section(text: str) -> str:
    # Grab the [project] section conservatively without requiring a TOML parser.
    match = re.search(r"(?ms)^\[project\]\n(.*?)(?:^\[|\Z)", text)
    if not match:
        raise AssertionError("[project] section not found in pyproject.toml")
    return match.group(1)


def _extract_quoted_list(block: str, key: str) -> list[str]:
    # Matches multi-line arrays like: key = ["a", "b", ...]
    m = re.search(rf"(?ms)^\s*{re.escape(key)}\s*=\s*\[(.*?)\]", block)
    if not m:
        return []
    inner = m.group(1)
    return re.findall(r'"([^\"]+)"', inner)


def _extract_scalar(block: str, key: str) -> str:
    m = re.search(rf"(?m)^\s*{re.escape(key)}\s*=\s*\"([^\"]+)\"\s*$", block)
    if not m:
        raise AssertionError(f"Missing required key: {key}")
    return m.group(1)


def _extract_license_expr(block: str) -> str:
    try:
        return _extract_scalar(block, "license")
    except AssertionError:
        pass
    m = re.search(r"(?ms)^\s*license\s*=\s*\{(.*?)\}\s*$", block)
    if not m:
        raise AssertionError("Missing required key: license")
    inner = m.group(1)
    text_match = re.search(r'text\s*=\s*"([^"]+)"', inner)
    if text_match:
        return text_match.group(1)
    file_match = re.search(r'file\s*=\s*"([^"]+)"', inner)
    if file_match:
        return f"file:{file_match.group(1)}"
    raise AssertionError("license table must contain text or file entry")


def load_pyproject_meta() -> PyProjectMeta:
    text = Path("pyproject.toml").read_text(encoding="utf-8")
    proj = _extract_project_section(text)
    name = _extract_scalar(proj, "name")
    version = _extract_scalar(proj, "version")
    readme_path = _extract_scalar(proj, "readme")
    classifiers = _extract_quoted_list(proj, "classifiers")
    license_expr = _extract_license_expr(proj)
    return PyProjectMeta(
        name=name,
        version=version,
        readme_path=readme_path,
        classifiers=classifiers,
        license=license_expr,
    )


def _contains_all(items: Iterable[str], required: Iterable[str]) -> bool:
    s = set(items)
    return all(r in s for r in required)


def test_pyproject_basic_metadata() -> None:
    import ultrastable

    meta = load_pyproject_meta()
    assert meta.name == "ultrastable"
    assert meta.version == ultrastable.__version__
    assert meta.license == "MIT"

    # README exists and is non-empty
    readme = Path(meta.readme_path)
    assert readme.exists(), f"README path not found: {meta.readme_path}"
    assert readme.stat().st_size > 0, "README should not be empty"

    # Classifiers include essential trove markers
    required = [
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
    ]
    assert meta.classifiers, "classifiers must be present in pyproject"
    assert _contains_all(meta.classifiers, required), (
        "Missing required trove classifiers; got: " + ", ".join(meta.classifiers)
    )


def test_build_metadata_and_description_content_type() -> None:
    # Build a wheel via pip and inspect METADATA for content type and classifiers.
    import sys
    import tempfile
    import zipfile

    with tempfile.TemporaryDirectory() as tmpdir:
        # Build wheel via pip to avoid build API/version differences
        import subprocess

        subprocess.run(
            [sys.executable, "-m", "pip", "wheel", "--no-deps", "-w", tmpdir, "."],
            check=True,
            capture_output=True,
            text=True,
        )

        wheels = list(Path(tmpdir).glob("*.whl"))
        assert wheels, "No wheel produced by build"
        wheel_path = wheels[0]

        with zipfile.ZipFile(wheel_path) as zf:
            meta_name = next(n for n in zf.namelist() if n.endswith("/METADATA"))
            metadata_text = zf.read(meta_name).decode("utf-8", errors="replace")
            assert "ultrastable/py.typed" in zf.namelist(), "py.typed marker missing from wheel"

        assert "Name: ultrastable" in metadata_text
        assert "Description-Content-Type: text/markdown" in metadata_text

        # Ensure at least one key classifier from pyproject made it into the wheel
        assert "Classifier: Programming Language :: Python :: 3.10" in metadata_text


def test_wheel_contains_py_typed(tmp_path: Path) -> None:
    import zipfile

    from setuptools import build_meta

    dist_dir = tmp_path / "wheel-artifacts"
    dist_dir.mkdir()

    wheel_name = build_meta.build_wheel(str(dist_dir))
    wheel_path = dist_dir / wheel_name
    assert wheel_path.exists(), "setuptools backend did not produce a wheel"

    with zipfile.ZipFile(wheel_path) as zf:
        members = zf.namelist()

    assert "ultrastable/py.typed" in members, (
        "py.typed marker missing from wheel members: " + ", ".join(sorted(members))
    )


def test_sdist_contains_py_typed(tmp_path: Path) -> None:
    import tarfile

    from setuptools import build_meta

    dist_dir = tmp_path / "dist-artifacts"
    dist_dir.mkdir()
    sdist_name = build_meta.build_sdist(str(dist_dir))
    sdist_path = dist_dir / sdist_name
    assert sdist_path.exists(), "setuptools backend did not produce an sdist"

    with tarfile.open(sdist_path, "r:gz") as tar:
        members = {member.name for member in tar.getmembers()}

    assert any(name.endswith("ultrastable/py.typed") for name in members), (
        "py.typed marker missing from sdist members: " + ", ".join(sorted(members))
    )


def test_readme_renders_markdown() -> None:
    try:
        from readme_renderer import markdown
    except Exception:  # pragma: no cover - optional
        import pytest

        pytest.skip("readme_renderer not installed; skipping README rendering check")

    meta = load_pyproject_meta()
    html = markdown.render(Path(meta.readme_path).read_text(encoding="utf-8"))
    assert html, "Rendered README should not be empty"
    assert "<h1" in html or "<h2" in html, "Rendered README should contain headings"
