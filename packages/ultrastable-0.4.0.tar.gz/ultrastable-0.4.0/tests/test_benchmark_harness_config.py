from __future__ import annotations

from pathlib import Path

import pytest

from ultrastable.benchmark.config import (
    HARNESS_CONFIG_SCHEMA_VERSION,
    BaselineConfig,
    BaselineDefaults,
    BudgetCapLimits,
    HarnessConfig,
    TimeoutLimits,
)
from ultrastable.benchmark.manifest import SuiteDescriptor

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_loads_sample_baseline_config() -> None:
    path = REPO_ROOT / "benchmarks" / "afmb_baselines.json"
    config = HarnessConfig.load(path)
    assert config.schema_version == HARNESS_CONFIG_SCHEMA_VERSION
    assert config.suite.name == "afmb"
    specs = config.runner_specs()
    assert [spec.name for spec in specs] == [
        "timeout_only",
        "retry_cap_3",
        "tool_call_cap_20",
        "hard_budget_cap",
    ]
    timeout = specs[0]
    assert timeout.kind == "timeout_only"
    assert isinstance(timeout.limits, TimeoutLimits)
    assert timeout.limits.max_steps == 60
    assert timeout.cases == ("s1", "s2", "s3", "s4", "s5")
    retry = specs[1]
    assert retry.kind == "retry_cap"
    assert retry.metadata == {"severity": "strict"}
    tool_cap = specs[2]
    assert tool_cap.cases == ("s2", "s4")
    budget = specs[3]
    assert isinstance(budget.limits, BudgetCapLimits)
    assert budget.limits.max_spend_usd == 3.0
    assert budget.tags == ("afmb", "baseline", "cost")


def test_runner_spec_requires_cases_when_no_defaults() -> None:
    suite = SuiteDescriptor(name="afmb", version="v1")
    baseline = BaselineConfig(
        name="timeout",
        kind="timeout_only",
        limits=TimeoutLimits(max_steps=5),
    )
    config = HarnessConfig(suite=suite, baselines=(baseline,), defaults=BaselineDefaults())
    with pytest.raises(ValueError):
        config.runner_specs()


def test_budget_cap_requires_limits() -> None:
    payload = {
        "suite": {"name": "afmb", "version": "v1", "cases": ["s1"]},
        "baselines": [
            {
                "name": "bad_budget",
                "kind": "budget_cap",
                "limits": {},
            }
        ],
    }
    with pytest.raises(ValueError):
        HarnessConfig.from_dict(payload)
