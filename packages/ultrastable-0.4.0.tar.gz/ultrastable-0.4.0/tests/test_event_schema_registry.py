from __future__ import annotations

import pytest

from ultrastable.events.registry import EventSchemaError, EventSchemaRegistry


def _make_registry() -> EventSchemaRegistry:
    registry = EventSchemaRegistry(latest_version="2.0")
    registry.register("2.0", lambda payload: dict(payload))
    registry.register("1.0", lambda payload: dict(payload))

    def upgrade(payload: dict[str, str]) -> dict[str, str]:
        upgraded = dict(payload)
        upgraded.setdefault("redaction_level", "metadata-only")
        upgraded["schema_version"] = "2.0"
        return upgraded

    registry.add_migration("1.0", "2.0", upgrade)
    return registry


def test_registry_validate_known_version() -> None:
    registry = _make_registry()
    event = {"schema_version": "2.0", "event_type": "step"}
    validated = registry.validate(event)
    assert validated["event_type"] == "step"


def test_registry_migrates_forward() -> None:
    registry = _make_registry()
    legacy = {"schema_version": "1.0", "event_type": "step"}
    migrated = registry.migrate(legacy, to_version="2.0")
    assert migrated["schema_version"] == "2.0"
    assert migrated["redaction_level"] == "metadata-only"


def test_registry_rejects_unknown_version() -> None:
    registry = _make_registry()
    with pytest.raises(EventSchemaError):
        registry.validate({"schema_version": "9.9"})
