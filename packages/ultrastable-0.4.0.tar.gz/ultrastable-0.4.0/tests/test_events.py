import json
from typing import Any

import ultrastable.core.events as core_events


def _roundtrip(event: core_events.BaseEvent, mode: str = "metadata-only") -> dict[str, Any]:
    s = event.to_json(redaction_level=mode)
    parsed = json.loads(s)
    if not isinstance(parsed, dict):
        raise AssertionError("event JSON did not decode to a dict")
    return parsed


def test_all_events_json_serializable_and_stable_ordering() -> None:
    # Prepare minimal instances
    events = [
        core_events.RunEvent(run_id="r1", phase="start", policy_version="p1"),
        core_events.StepEvent(step_id="s1", role="assistant", kind="llm", model="m"),
        core_events.HealthSnapshotEvent(
            values={"latency_ms": 100.0}, deviations={"latency_ms": 0.2}, d_h=0.2
        ),
        core_events.TriggerEvent(
            detector="LexicalRepeatDetector", severity="warn", explanation="repetition"
        ),
        core_events.InterventionEvent(intervention_type="RESET_REPLAN"),
        core_events.CostEvent(tokens=10, usd=0.001),
        core_events.ErrorEvent(category="tool_timeout"),
    ]

    for ev in events:
        # Roundtrip should parse as JSON
        data = _roundtrip(ev)
        assert isinstance(data, dict)
        # Required fields present
        assert data["event_type"]
        assert data["schema_version"] == core_events.EVENT_SCHEMA_VERSION
        assert data["timestamp"]

        # Determinism: same object → same JSON string
        s1 = ev.to_json()
        s2 = ev.to_json()
        assert s1 == s2


def test_metadata_only_redacts_bodies() -> None:
    step = core_events.StepEvent(
        step_id="s1",
        prompt_text="secret prompt",
        response_text="secret response",
    )
    data = _roundtrip(step, mode="metadata-only")
    assert "prompt_text" not in data
    assert "response_text" not in data
    # Hashes should be present for auditability
    prompt_hash = data.get("prompt_hash")
    response_hash = data.get("response_hash")
    assert isinstance(prompt_hash, dict) and prompt_hash.get("digest")
    assert isinstance(response_hash, dict) and response_hash.get("digest")
    assert prompt_hash.get("algorithm") == "sha256"
    assert response_hash.get("algorithm") == "sha256"
    assert prompt_hash.get("digest") == data.get("prompt_text_sha256")
    assert response_hash.get("digest") == data.get("response_text_sha256")
    assert prompt_hash.get("salt") is None and response_hash.get("salt") is None
    assert data["redaction_level"] == "metadata-only"

    err = core_events.ErrorEvent(category="provider_error", message="sensitive details")
    edata = _roundtrip(err, mode="metadata-only")
    assert "message" not in edata
    message_hash = edata.get("message_hash")
    assert isinstance(message_hash, dict)
    assert message_hash.get("digest") == edata.get("message_sha256")
    assert message_hash.get("algorithm") == "sha256"


def test_selective_text_keeps_error_message_but_hashes_step_bodies() -> None:
    step = core_events.StepEvent(
        step_id="s2",
        prompt_text="prompt",
        response_text="response",
    )
    data = _roundtrip(step, mode="selective-text")
    assert "prompt_text" not in data and data.get("prompt_text_sha256")
    assert "response_text" not in data and data.get("response_text_sha256")
    assert isinstance(data.get("prompt_hash"), dict)
    assert isinstance(data.get("response_hash"), dict)

    err = core_events.ErrorEvent(category="provider_error", message="keep me")
    edata = _roundtrip(err, mode="selective-text")
    assert edata.get("message") == "keep me"
    assert isinstance(edata.get("message_hash"), dict)
    assert edata.get("message_sha256")


def test_full_text_mode_preserves_bodies() -> None:
    step = core_events.StepEvent(step_id="s3", prompt_text="prompt", response_text="response")
    data = _roundtrip(step, mode="full-text")
    assert data.get("prompt_text") == "prompt"
    assert data.get("response_text") == "response"

    err = core_events.ErrorEvent(category="provider_error", message="keep body")
    err_data = _roundtrip(err, mode="full-text")
    assert err_data.get("message") == "keep body"


def test_metadata_only_does_not_leak_full_text() -> None:
    secret_prompt = "never leak this prompt"
    secret_response = "never leak this response"
    step = core_events.StepEvent(
        step_id="s4",
        prompt_text=secret_prompt,
        response_text=secret_response,
    )
    json_payload = step.to_json(redaction_level="metadata-only")
    assert secret_prompt not in json_payload
    assert secret_response not in json_payload
    parsed = json.loads(json_payload)
    assert parsed.get("prompt_hash")
    assert parsed.get("response_hash")
