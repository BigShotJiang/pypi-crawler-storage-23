from __future__ import annotations

from pathlib import Path

from ultrastable.benchmark.manifest import SuiteDescriptor
from ultrastable.benchmark.report import (
    METRIC_DEFINITIONS_MD,
    render_report_md,
    write_report_md,
)
from ultrastable.benchmark.results import CaseResult, RunResults, RunSummary, VariantResult


def _sample_results() -> RunResults:
    suite = SuiteDescriptor(name="afmb", version="v1", variant="smoke")
    summary = RunSummary(
        status="completed",
        cases_total=2,
        cases_passed=2,
        duration_seconds=42.5,
        metrics={"total_steps": 12, "total_cost_usd": 0.12},
    )
    cases = (
        CaseResult(
            case_id="s1",
            status="passed",
            name="lexical_repeat_loop",
            description="Repeats responses until guard intervenes.",
            duration_seconds=12.3,
            metrics={"steps": 5, "cost_usd": 0.05},
            variants=(
                VariantResult(
                    name="guarded",
                    kind="policy",
                    status="passed",
                    metrics={"violations": 1},
                ),
            ),
        ),
        CaseResult(
            case_id="s2",
            status="passed",
            duration_seconds=9.8,
            metrics={"steps": 7, "cost_usd": 0.07},
        ),
    )
    return RunResults(
        suite=suite,
        summary=summary,
        cases=cases,
        run_id="afmb-20260226-001",
        manifest_path="manifest.json",
        command="ultrastable benchmark run --suite afmb --seed 1",
        artifacts={"results": "results.json"},
        tags=("afmb", "smoke"),
    )


def test_render_report_md_includes_metric_definitions() -> None:
    results = _sample_results()

    markdown = render_report_md(results)

    assert markdown.startswith("# Benchmark Report")
    assert "## Run Overview" in markdown
    assert "Case s1" in markdown
    assert METRIC_DEFINITIONS_MD.strip() in markdown


def test_write_report_md_persists_file(tmp_path: Path) -> None:
    results = _sample_results()
    output_path = tmp_path / "report.md"

    write_report_md(results, output_path)

    contents = output_path.read_text(encoding="utf-8")
    assert contents == render_report_md(results)
