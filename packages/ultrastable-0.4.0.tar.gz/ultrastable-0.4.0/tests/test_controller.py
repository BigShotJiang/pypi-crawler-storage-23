from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import pytest

from ultrastable.core import (
    Controller,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.core.controller import ControllerDecision
from ultrastable.core.events import HealthSnapshotEvent, StepEvent, TriggerEvent
from ultrastable.interventions import Intervention, InterventionRequest, InterventionResult
from ultrastable.interventions.base import build_event


class DummyIntervention(Intervention):
    name = "DUMMY"

    def run(self, request: InterventionRequest) -> InterventionResult | None:
        if not request.triggers:
            return None
        event = build_event(
            intervention_type=self.name,
            request=request,
            parameters={"action": "dummy"},
            outcome={"status": "pending"},
        )
        return InterventionResult(
            plan={"action": "dummy"}, outcome=event.outcome, state=request.state, event=event
        )


class AlwaysTriggerDetector:
    name = "always"

    def evaluate(
        self, steps: Sequence[StepEvent], snapshots: Sequence[HealthSnapshotEvent] | None = None
    ) -> list[TriggerEvent]:
        if not steps:
            return []
        return [
            TriggerEvent(
                detector=self.name,
                severity="warn",
                explanation="test",
                related_step_ids=[steps[-1].step_id],
            )
        ]


def make_policy() -> ViabilityPolicy:
    space = EssentialVariableSpace(
        [
            EssentialVariable.monotonic("spend_ratio", hard_limit=1.0, scale=1.0),
        ]
    )
    return ViabilityPolicy(
        space=space,
        health=HealthModel("l2"),
        monotonic_warn_fraction=0.8,
    )


def test_controller_triggers_once_and_respects_cooldown() -> None:
    policy = make_policy()
    controller = Controller(
        policy=policy,
        detectors=[AlwaysTriggerDetector()],
        interventions=[DummyIntervention()],
        cooldown_steps=2,
    )
    state: dict[str, Any] = {}
    decisions: list[ControllerDecision] = []
    for idx in range(4):
        step = StepEvent(step_id=f"s{idx}", role="assistant", response_text="hi")
        decisions.append(controller.update(step, snapshot=None, state=state))

    assert decisions[0].intervention is not None
    assert decisions[1].intervention is None  # cooldown active
    assert decisions[2].intervention is None  # still cooldown
    assert decisions[3].intervention is not None  # cooldown expired


def test_controller_outcome_tracking_until_recovery() -> None:
    policy = make_policy()
    controller = Controller(
        policy=policy,
        detectors=[],
        interventions=[DummyIntervention()],
        cooldown_steps=1,
    )
    state: dict[str, Any] = {}
    # Step 1: push util high to trigger policy warn
    policy.space.set("spend_ratio", 0.95)
    snapshot1 = policy.space.snapshot(policy.health)
    decision1 = controller.update(
        StepEvent(step_id="a1", role="assistant", response_text="hi"),
        snapshot=snapshot1,
        state=state,
    )
    assert decision1.intervention is not None
    assert any(trigger.detector == "viability_policy" for trigger in decision1.triggers)

    # Step 2: still warn => pending breach count should increment
    policy.space.set("spend_ratio", 0.9)
    snapshot2 = policy.space.snapshot(policy.health)
    decision2 = controller.update(
        StepEvent(step_id="a2", role="assistant", response_text="hi"),
        snapshot=snapshot2,
        state=state,
    )
    assert not decision2.outcomes

    # Step 3: recover to safe range
    policy.space.set("spend_ratio", 0.2)
    snapshot3 = policy.space.snapshot(policy.health)
    decision3 = controller.update(
        StepEvent(step_id="a3", role="assistant", response_text="hi"),
        snapshot=snapshot3,
        state=state,
    )
    assert decision3.outcomes, "expected recovery outcome"
    outcome = decision3.outcomes[0]
    assert outcome["status"] == "recovered"
    assert outcome["repeated_breach_count"] >= 1
    assert outcome["delta_dh"] is not None and outcome["delta_dh"] > 0


def test_controller_eta_requires_additional_recovery_before_dropping_warn() -> None:
    policy = make_policy()
    controller = Controller(
        policy=policy,
        detectors=[],
        interventions=[],
        eta=2.0,
        cooldown_steps=0,
    )
    state: dict[str, Any] = {}

    def run_step(step_id: str) -> ControllerDecision:
        snapshot = policy.space.snapshot(policy.health)
        return controller.update(
            StepEvent(step_id=step_id, role="assistant", response_text="hi"),
            snapshot=snapshot,
            state=state,
        )

    policy.space.set("spend_ratio", 0.2)
    decision_ok = run_step("s_ok")
    assert decision_ok.policy_status == "ok"
    assert not decision_ok.triggers

    policy.space.set("spend_ratio", 0.95)
    decision_warn = run_step("s_warn")
    assert decision_warn.policy_status == "warn"
    assert any(trigger.detector == "viability_policy" for trigger in decision_warn.triggers)

    policy.space.set("spend_ratio", 0.2)
    decision_first_recover = run_step("s_recover_1")
    assert decision_first_recover.policy_status == "warn"
    assert any(
        "eta bias" in (trigger.explanation or "") for trigger in decision_first_recover.triggers
    )

    policy.space.set("spend_ratio", 0.2)
    decision_second_recover = run_step("s_recover_2")
    assert decision_second_recover.policy_status == "ok"
    assert not decision_second_recover.triggers


def test_controller_eta_must_be_at_least_one() -> None:
    policy = make_policy()
    with pytest.raises(ValueError):
        Controller(policy=policy, eta=0.5)
