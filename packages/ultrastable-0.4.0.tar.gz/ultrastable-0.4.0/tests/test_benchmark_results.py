from __future__ import annotations

import pytest

from ultrastable.benchmark.manifest import SuiteDescriptor
from ultrastable.benchmark.results import (
    CaseResult,
    RunResults,
    RunSummary,
    VariantResult,
)


def test_run_results_round_trip() -> None:
    suite = SuiteDescriptor(name="afmb", version="v1", cases=("s1", "s2"))
    summary = RunSummary(
        status="completed",
        cases_total=2,
        cases_passed=2,
        duration_seconds=12.5,
        metrics={"success_rate": 1.0},
        metadata={"ci_build": "nightly"},
    )
    cases = (
        CaseResult(
            case_id="s1",
            status="passed",
            name="Scenario 1",
            description="Baseline guard behaves",
            duration_seconds=5.2,
            metrics={"failures": 0},
            variants=(
                VariantResult(
                    name="reference",
                    kind="policy",
                    status="passed",
                    metrics={"reward": 1.0},
                    artifacts={"ledger": "ledgers/s1.jsonl"},
                ),
            ),
            artifacts={"ledger": "ledgers/s1.jsonl"},
            metadata={"attempts": 1},
            tags=("smoke",),
            notes="All good",
        ),
        CaseResult(
            case_id="s2",
            status="passed",
            metrics={"failures": 0},
        ),
    )
    results = RunResults(
        suite=suite,
        summary=summary,
        cases=cases,
        run_id="afmb-20260226-001",
        manifest_path="manifest.json",
        command="ultrastable benchmark run --suite afmb --seed 1",
        artifacts={"results": "results.json"},
        metadata={"experiment": "smoke"},
        tags=("afmb", "smoke"),
        notes="Deterministic run",
    )

    payload = results.to_dict()
    rebuilt = RunResults.from_dict(payload)
    assert rebuilt == results

    json_payload = results.to_json(indent=2)
    assert RunResults.from_json(json_payload) == results


def test_invalid_case_status_raises() -> None:
    suite = SuiteDescriptor(name="afmb", version="v1")
    summary = RunSummary(status="completed", cases_total=1)
    payload = {
        "suite": suite.to_dict(),
        "summary": summary.to_dict(),
        "cases": [
            {
                "case_id": "s1",
                "status": "unknown",
            }
        ],
    }
    with pytest.raises(ValueError):
        RunResults.from_dict(payload)


def test_case_metrics_must_be_mapping() -> None:
    payload = {
        "case_id": "s1",
        "status": "passed",
        "metrics": ["not", "a", "mapping"],
    }
    with pytest.raises(ValueError):
        CaseResult.from_dict(payload)
