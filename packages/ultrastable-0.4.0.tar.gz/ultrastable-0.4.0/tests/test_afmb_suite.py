from __future__ import annotations

from pathlib import Path

from scripts.run_afmb_suite import SCENARIOS, run_afmb_suite


def test_afmb_suite_runs_offline(tmp_path: Path) -> None:
    summary = run_afmb_suite(tmp_path, max_duration_seconds=120.0)
    assert summary["suite"] == "afmb"
    assert len(summary["scenarios"]) == len(SCENARIOS)
    assert summary["total_duration_seconds"] < 120.0

    for entry in summary["scenarios"]:
        ledger_path = Path(entry["ledger"])
        assert ledger_path.exists()
        assert entry["steps"] >= 1

    summary_path = Path(summary["summary_path"])
    assert summary_path.exists()
