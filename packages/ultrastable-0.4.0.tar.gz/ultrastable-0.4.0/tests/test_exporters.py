from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

from ultrastable.core.events import StepEvent
from ultrastable.exporters import FileExporter, StdoutExporter
from ultrastable.exporters.base import AsyncExporter


class DummyExporter(AsyncExporter):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(start_worker=False, **kwargs)
        self.handled: list[list[dict[str, Any]]] = []

    def _handle_batch(self, batch: list[dict[str, Any]]) -> None:
        self.handled.append(batch)


def test_stdout_exporter_writes_deterministic_lines() -> None:
    stream = io.StringIO()
    exporter = StdoutExporter(stream=stream, queue_size=8)
    events = [
        StepEvent(step_id="s1", role="assistant", response_text="hi"),
        StepEvent(step_id="s2", role="assistant", response_text="bye"),
    ]
    exporter.export(events)
    exporter.flush()
    exporter.close()
    output = stream.getvalue().strip().splitlines()
    assert len(output) == 2
    data = [json.loads(line) for line in output]
    assert data[0]["step_id"] == "s1"
    assert data[1]["step_id"] == "s2"


def test_file_exporter_writes_jsonl(tmp_path: Path) -> None:
    path = tmp_path / "events.jsonl"
    exporter = FileExporter(str(path), queue_size=8)
    exporter.export(
        [
            StepEvent(step_id="a", role="assistant", response_text="one"),
            {"event_type": "custom", "value": 1},
        ]
    )
    exporter.flush()
    exporter.close()
    with path.open("r", encoding="utf-8") as fp:
        lines = [line.strip() for line in fp if line.strip()]
    assert len(lines) == 2
    assert json.loads(lines[0])["step_id"] == "a"
    assert json.loads(lines[1])["event_type"] == "custom"


def test_exporter_drops_when_queue_full() -> None:
    exporter = DummyExporter(queue_size=1)
    result1 = exporter.export([{"event_type": "one"}])
    assert result1.accepted
    result2 = exporter.export([{"event_type": "two"}])
    assert not result2.accepted and result2.dropped == 1
    exporter.close()
