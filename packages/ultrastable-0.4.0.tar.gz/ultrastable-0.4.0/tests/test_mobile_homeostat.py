from __future__ import annotations

from pathlib import Path
from typing import Any

from ultrastable.robotics import (
    MobileHomeostat2D,
    build_guard_and_env,
    render_mobile_homeostat_svg,
)


class MemoryLedger:
    def __init__(self, redaction: str = "metadata-only") -> None:
        self.events: list[Any] = []
        self._redaction = redaction

    @property
    def redaction(self) -> str:
        return self._redaction

    def add(self, event: Any) -> None:
        self.events.append(event)


def test_mobile_homeostat_rewire() -> None:
    env = MobileHomeostat2D(seed=1)
    env.reset()
    before = env.observe()
    env.rewire()
    after = env.step()
    assert env.rewire_count == 1
    assert after["light_intensity"] != before["light_intensity"]


def test_mobile_homeostat_script_recharges() -> None:
    env = MobileHomeostat2D(seed=2)
    start = env.reset()["battery"]
    reached_goal = False
    for _ in range(60):
        metrics = env.step()
        if metrics["light_intensity"] > 0.85:
            reached_goal = True
    assert reached_goal
    assert env.battery > start


def test_mobile_homeostat_guard(tmp_path: Path) -> None:
    ledger_path = tmp_path / "homeostat.jsonl"
    guard, env, ledger = build_guard_and_env(ledger_path, seed=3)
    guard.ledger = MemoryLedger()
    guard.start_run(run_id="test")
    env.reset()
    rewired = False
    for step in range(50):
        metrics = env.step()
        decision = guard.post_step(
            step_id=f"s-{step}",
            role="robot",
            kind="homeostat",
            metrics=metrics,
            tags={"step": step},
        )
        if decision.policy_status == "critical":
            env.rewire()
            rewired = True
    guard.end_run()
    assert rewired
    assert any(e.get("event_type") == "step" for e in guard.ledger.events)


def test_mobile_homeostat_plot(tmp_path: Path) -> None:
    env = MobileHomeostat2D(seed=4)
    env.reset()
    for _ in range(10):
        env.step()
    svg_path = tmp_path / "trajectory.svg"
    render_mobile_homeostat_svg(env, svg_path)
    data = svg_path.read_text(encoding="utf-8")
    assert "polyline" in data
