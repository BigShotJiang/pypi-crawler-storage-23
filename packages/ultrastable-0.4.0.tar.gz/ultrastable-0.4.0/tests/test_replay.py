from __future__ import annotations

import json
from pathlib import Path

import pytest

from ultrastable.cli.demos import build_agent_loop_controller
from ultrastable.core.events import StepEvent
from ultrastable.events.registry import EventSchemaError
from ultrastable.ledger import JsonlLedger
from ultrastable.replay.engine import (
    LedgerHashChainError,
    load_step_events,
    replay_events,
    replay_ledger,
)
from ultrastable.replay.report import generate_causal_report, generate_report


def make_steps() -> list[StepEvent]:
    return [
        StepEvent(step_id="s0", role="assistant", kind="llm", response_text="hi"),
        StepEvent(step_id="s1", role="assistant", kind="llm", response_text="hi"),
        StepEvent(step_id="s2", role="assistant", kind="llm", response_text="hi"),
    ]


def test_replay_events_counts() -> None:
    controller = build_agent_loop_controller()
    result1 = replay_events(make_steps(), controller)
    result2 = replay_events(make_steps(), controller)
    assert result1.total_steps == result2.total_steps == 3
    assert result1.total_interventions == result2.total_interventions


def test_generate_causal_report_contains_timeline() -> None:
    controller = build_agent_loop_controller()
    result = replay_events(make_steps(), controller)
    report = generate_causal_report(result)
    assert "timeline" in report
    assert len(report["timeline"]) == result.total_steps


def test_load_step_events_migrates_old_schema(tmp_path: Path) -> None:
    ledger = tmp_path / "legacy.jsonl"
    ledger.write_text(
        json.dumps(
            {
                "event_type": "step",
                "schema_version": "1.1",
                "timestamp": "2024-01-01T00:00:00Z",
                "step_id": "legacy-step",
                "role": "assistant",
                "kind": "llm",
            }
        )
        + "\n",
        encoding="utf-8",
    )

    events = load_step_events(ledger)

    assert len(events) == 1
    assert events[0].step_id == "legacy-step"


def test_load_step_events_rejects_unknown_schema(tmp_path: Path) -> None:
    ledger = tmp_path / "bad.jsonl"
    ledger.write_text(
        json.dumps(
            {
                "event_type": "step",
                "schema_version": "9.9",
                "timestamp": "2024-01-01T00:00:00Z",
                "step_id": "bad",
            }
        )
        + "\n",
        encoding="utf-8",
    )

    with pytest.raises(EventSchemaError):
        load_step_events(ledger)


def _write_ledger(path: Path) -> None:
    ledger = JsonlLedger(str(path))
    ledger.add(StepEvent(step_id="s1", role="assistant", kind="llm", response_text="hello"))
    ledger.add(StepEvent(step_id="s2", role="assistant", kind="llm", response_text="world"))
    ledger.close()


def test_load_step_events_preserves_text_hashes(tmp_path: Path) -> None:
    ledger_path = tmp_path / "hashes.jsonl"
    with JsonlLedger(str(ledger_path), redaction="metadata-only") as ledger:
        ledger.add(
            StepEvent(
                step_id="s1",
                role="assistant",
                kind="llm",
                prompt_text="prompt-secret",
                response_text="response-secret",
            )
        )

    events = load_step_events(ledger_path)
    assert len(events) == 1
    step = events[0]
    assert step.prompt_text is None
    assert step.response_text is None
    assert step.prompt_hash is not None
    assert step.response_hash is not None
    assert step.prompt_text_sha256 is not None
    assert step.response_text_sha256 is not None
    assert step.prompt_hash["digest"] == step.prompt_text_sha256
    assert step.response_hash["digest"] == step.response_text_sha256


def test_replay_ledger_deterministic_reports(tmp_path: Path) -> None:
    ledger = tmp_path / "ledger.jsonl"
    _write_ledger(ledger)
    controller_a = build_agent_loop_controller()
    controller_b = build_agent_loop_controller()
    result_a = replay_ledger(ledger, controller_a, deterministic=True)
    result_b = replay_ledger(ledger, controller_b, deterministic=True)
    assert result_a.metadata.get("deterministic") is True
    assert result_a.metadata.get("seed") == result_b.metadata.get("seed")
    assert generate_report(result_a) == generate_report(result_b)

    controller_c = build_agent_loop_controller()
    manual_seed = 12345
    result_c = replay_ledger(ledger, controller_c, deterministic=True, seed=manual_seed)
    assert result_c.metadata.get("seed") == manual_seed
    assert result_c.metadata.get("seed_source") == "user"
    hash_meta = result_a.metadata.get("hash_chain")
    assert isinstance(hash_meta, dict)
    assert hash_meta["present"] is True
    assert hash_meta["verified"] is True
    assert hash_meta["last_event_hash"]


def test_replay_ledger_detects_hash_mismatch(tmp_path: Path) -> None:
    ledger = tmp_path / "ledger.jsonl"
    _write_ledger(ledger)
    records = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line]
    assert records
    records[0]["response_text"] = "tampered"
    ledger.write_text(
        "\n".join(
            json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for entry in records
        )
        + "\n",
        encoding="utf-8",
    )
    controller = build_agent_loop_controller()
    with pytest.raises(LedgerHashChainError):
        replay_ledger(ledger, controller)


def test_replay_ledger_handles_legacy_without_hash_chain(tmp_path: Path) -> None:
    ledger = tmp_path / "legacy.jsonl"
    ledger.write_text(
        json.dumps(
            {
                "event_type": "step",
                "schema_version": "1.2",
                "timestamp": "2024-01-01T00:00:00Z",
                "step_id": "s1",
                "role": "assistant",
                "kind": "llm",
            }
        )
        + "\n",
        encoding="utf-8",
    )
    controller = build_agent_loop_controller()
    result = replay_ledger(ledger, controller)
    hash_meta = result.metadata.get("hash_chain")
    assert isinstance(hash_meta, dict)
    assert hash_meta["present"] is False
    assert hash_meta["reason"] == "absent"
