from __future__ import annotations

from typing import Any

import pytest

from ultrastable.ledger.canonical import (
    CanonicalJsonError,
    canonical_record_json,
    canonicalize_record,
)


def test_canonical_record_json_is_deterministic() -> None:
    payload = {
        "event_type": "step",
        "timestamp": "2026-02-25T00:00:00Z",
        "redaction_level": "metadata-only",
        "tags": {"customer": "alpha", "priority": 1},
        "metrics": [{"b": 2, "a": 1}, {"x": 9, "y": 10}],
    }
    reordered = {
        "metrics": [{"a": 1, "b": 2}, {"y": 10, "x": 9}],
        "timestamp": "2026-02-25T00:00:00Z",
        "redaction_level": "metadata-only",
        "event_type": "step",
        "tags": {"priority": 1, "customer": "alpha"},
    }
    assert canonical_record_json(payload) == canonical_record_json(reordered)


def test_canonicalize_record_normalizes_sequences() -> None:
    payload = {
        "event_type": "run",
        "redaction_level": "metadata-only",
        "values": (1, 2, {"tuple": ("x", "y")}),
    }
    normalized = canonicalize_record(payload)
    assert normalized["values"] == [1, 2, {"tuple": ["x", "y"]}]


def test_canonicalize_record_rejects_non_string_keys() -> None:
    bad_payload: Any = {1: "bad"}
    with pytest.raises(CanonicalJsonError):
        canonicalize_record(bad_payload)


def test_canonicalize_record_rejects_unsupported_types() -> None:
    with pytest.raises(CanonicalJsonError):
        canonicalize_record({"event_type": "run", "bad": {1, 2}})
