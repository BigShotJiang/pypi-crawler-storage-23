from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, cast

import pytest

from ultrastable.policy import (
    POLICY_SCHEMA_VERSION,
    PolicyPackError,
    build_controller_from_pack,
    canonicalize_policy,
    load_policy_pack_file,
    policy_hash,
    upgrade_policy_document,
)


def _sample_pack() -> dict[str, Any]:
    return {
        "name": "demo",
        "description": "Example policy",
        "controller": {"step_window": 30},
        "policy": {
            "variables": [
                {
                    "name": "spend",
                    "kind": "monotonic",
                    "scale": 0.0100000003,
                    "hard_limit": "0.0100000003",
                },
                {
                    "name": "context_util",
                    "kind": "bounded",
                    "scale": 1,
                    "min": 0,
                    "max": 1,
                    "tags": {"team": "eng"},
                },
            ],
            "monotonic_warn_fraction": 0.85,
            "bounded_warn_fraction": "0.2",
            "coupled_variables": [
                {
                    "name": "trust_battery",
                    "decay": 0.1,
                    "coupling": {"func": "linear", "params": {"k": 0.5}},
                    "min_value": 0.0,
                    "max_value": 1.0,
                }
            ],
        },
        "detectors": [
            {"kind": "tool_loop", "params": {"window_size": 6}},
            {"kind": "lexical_repeat", "params": {"repeat_threshold": 4}},
        ],
        "interventions": [
            {"kind": "reset_replan", "params": {}},
            {"kind": "reset_context_trim", "params": {"keep_last_turns": 3}},
        ],
    }


def test_canonicalization_applies_defaults_and_sorting() -> None:
    pack = _sample_pack()
    canonical = canonicalize_policy(pack)
    assert canonical["schema_version"] == "policy_pack/v1"
    assert canonical["policy_schema_version"] == POLICY_SCHEMA_VERSION
    assert canonical["controller"] == {
        "step_window": 30,
        "snapshot_window": 5,
        "cooldown_steps": 3,
        "eta": 1.0,
    }
    variables = canonical["policy"]["variables"]
    assert [v["name"] for v in variables] == ["context_util", "spend"]
    spend = next(v for v in variables if v["name"] == "spend")
    assert spend["hard_limit"] == pytest.approx(0.01)
    assert canonical["policy"]["monotonic_warn_fraction"] == pytest.approx(0.85)
    assert canonical["policy"]["bounded_warn_fraction"] == pytest.approx(0.2)
    detectors = canonical["detectors"]
    assert [d["kind"] for d in detectors] == ["lexical_repeat", "tool_loop"]
    assert canonical["interventions"][0]["kind"] == "reset_context_trim"


def test_policy_pack_controller_eta_configurable() -> None:
    pack = _sample_pack()
    pack["controller"]["eta"] = 2.5
    canonical = canonicalize_policy(pack)
    assert canonical["controller"]["eta"] == pytest.approx(2.5)
    loaded = build_controller_from_pack(pack)
    controller_any = cast(Any, loaded.controller)
    assert controller_any._eta == pytest.approx(2.5)


def test_policy_pack_controller_eta_must_be_at_least_one() -> None:
    pack = _sample_pack()
    pack["controller"]["eta"] = 0.9
    with pytest.raises(PolicyPackError):
        canonicalize_policy(pack)


def test_policy_hash_stable_across_ordering() -> None:
    pack_a = _sample_pack()
    pack_b = copy.deepcopy(pack_a)
    pack_b["policy"]["variables"].reverse()
    pack_b["detectors"].reverse()
    pack_b["interventions"].reverse()
    assert policy_hash(pack_a) == policy_hash(pack_b)


def test_missing_policy_or_variables_raise() -> None:
    with pytest.raises(PolicyPackError):
        canonicalize_policy({})
    with pytest.raises(PolicyPackError):
        canonicalize_policy({"policy": {"variables": []}})


def test_duplicate_detectors_forbidden() -> None:
    pack = _sample_pack()
    pack["detectors"].append({"kind": "tool_loop"})
    with pytest.raises(PolicyPackError):
        canonicalize_policy(pack)


def test_float_rounding_canonical() -> None:
    pack = _sample_pack()
    pack["policy"]["variables"][0]["scale"] = 0.1234567899876
    canonical = canonicalize_policy(pack)
    scale = next(v for v in canonical["policy"]["variables"] if v["name"] == "spend")["scale"]
    assert scale == pytest.approx(0.12345679)


def test_load_policy_pack_file(tmp_path: Path) -> None:
    pack = _sample_pack()
    pack_path = tmp_path / "pack.json"
    pack_path.write_text(json.dumps(pack), encoding="utf-8")
    loaded = load_policy_pack_file(pack_path)
    assert loaded.policy_hash == policy_hash(pack)
    assert loaded.canonical["policy_schema_version"] == POLICY_SCHEMA_VERSION
    controller_any = cast(Any, loaded.controller)
    assert controller_any.policy_metadata["policy_name"] == pack["name"]


def test_build_controller_from_pack_sets_metadata() -> None:
    pack = _sample_pack()
    loaded = build_controller_from_pack(pack)
    assert loaded.policy_hash
    assert loaded.metadata["policy_hash"] == loaded.policy_hash
    assert loaded.metadata["policy_schema_version"] == POLICY_SCHEMA_VERSION
    controller_any = cast(Any, loaded.controller)
    assert controller_any.policy_metadata["policy_name"] == pack["name"]
    assert controller_any.policy_metadata["policy_hash"] == loaded.policy_hash
    assert len(loaded.controller.detectors) == 2
    assert len(loaded.controller.interventions) == 2
    assert "trust_battery" in loaded.controller.policy.space.coupled_variables


def test_upgrade_policy_document_adds_policy_schema_version() -> None:
    pack = _sample_pack()
    upgraded = upgrade_policy_document(pack)
    assert upgraded["policy_schema_version"] == POLICY_SCHEMA_VERSION


def test_upgrade_policy_document_rejects_unknown_version() -> None:
    pack = _sample_pack()
    pack["policy_schema_version"] = "policy_pack/v999"
    with pytest.raises(PolicyPackError):
        upgrade_policy_document(pack)


def test_policy_hash_unchanged_without_schema_field() -> None:
    pack = _sample_pack()
    pack_with_version = copy.deepcopy(pack)
    pack_with_version["policy_schema_version"] = POLICY_SCHEMA_VERSION
    assert policy_hash(pack) == policy_hash(pack_with_version)
