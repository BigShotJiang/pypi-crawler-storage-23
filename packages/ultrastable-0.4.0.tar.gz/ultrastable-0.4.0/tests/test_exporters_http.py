from __future__ import annotations

import json
from collections.abc import Mapping

from ultrastable.core.events import StepEvent
from ultrastable.exporters.http import HttpBatchExporter
from ultrastable.exporters.otlp import OtlpExporter


class CapturingSender:
    def __init__(self, failures: int = 0) -> None:
        self.failures = failures
        self.calls: list[tuple[bytes, Mapping[str, str]]] = []

    def __call__(self, payload: bytes, headers: Mapping[str, str]) -> None:
        self.calls.append((payload, headers))
        if self.failures > 0:
            self.failures -= 1
            raise RuntimeError("fail once")


def test_http_batch_exporter_sends_payload_and_retries() -> None:
    sender = CapturingSender(failures=1)
    exporter = HttpBatchExporter(
        "http://example.com",
        sender=sender,
        retries=2,
        backoff=0.0,
    )
    exporter.export([StepEvent(step_id="s1", role="assistant", response_text="hi")])
    exporter.flush()
    exporter.close()
    assert len(sender.calls) == 2
    payload = json.loads(sender.calls[-1][0].decode("utf-8"))
    assert payload[0]["step_id"] == "s1"


def test_otlp_exporter_wraps_events() -> None:
    sender = CapturingSender()
    exporter = OtlpExporter(
        "http://otlp.example.com",
        sender=sender,
        resource={"service.name": "test"},
        scope={"name": "ultrastable"},
    )
    exporter.export([{"event_type": "custom", "value": 1}])
    exporter.flush()
    exporter.close()
    assert len(sender.calls) == 1
    data = json.loads(sender.calls[0][0])
    assert data["resource"]["service.name"] == "test"
    assert data["events"][0]["value"] == 1
