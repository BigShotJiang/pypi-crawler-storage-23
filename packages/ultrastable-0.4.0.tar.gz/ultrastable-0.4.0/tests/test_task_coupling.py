from __future__ import annotations

from typing import Any

import pytest

from ultrastable.core import (
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    TaskCoupledVariable,
)
from ultrastable.core.events import TaskCouplingEvent


def make_task_variable(**overrides: Any) -> TaskCoupledVariable:
    kwargs: dict[str, Any] = {
        "name": "battery",
        "decay": 0.2,
        "coupling": {"func": "linear", "params": {"k": 0.0, "c": 0.0}},
        "min_value": 0.0,
        "max_value": 10.0,
        "start_value": 10.0,
    }
    kwargs.update(overrides)
    return TaskCoupledVariable(**kwargs)


def test_task_coupled_variable_decay_matches_euler_step() -> None:
    var = make_task_variable(decay=0.1, max_value=10.0, start_value=10.0)
    event = var.step(0.0, dt=0.5)
    expected = 10.0 * (1.0 - 0.1 * 0.5)
    assert event.post_value == pytest.approx(expected)
    event2 = var.step(0.0, dt=0.5)
    second_expected = expected * (1.0 - 0.1 * 0.5)
    assert event2.post_value == pytest.approx(second_expected)


def test_task_coupled_recharge_clamped_to_max() -> None:
    var = make_task_variable(
        decay=0.1,
        start_value=5.0,
        max_value=6.0,
        coupling={"func": "linear", "params": {"k": 10.0, "c": 0.0}},
    )
    event = var.step(1.0, dt=1.0)
    assert event.post_value == pytest.approx(var.max_value)


def test_task_coupled_serialization_roundtrip() -> None:
    var = make_task_variable(decay=0.05, start_value=7.5)
    cfg = var.to_config()
    clone = TaskCoupledVariable.from_config(cfg)
    assert clone.value == pytest.approx(var.value)
    event_original = var.step(0.3, dt=0.25)
    event_clone = clone.step(0.3, dt=0.25)
    assert event_original.post_value == pytest.approx(event_clone.post_value)


def test_space_step_coupled_updates_snapshot_and_returns_events() -> None:
    coupled = make_task_variable()
    space = EssentialVariableSpace(
        [EssentialVariable.monotonic("spend_usd", hard_limit=100.0, scale=100.0)],
        coupled_variables=[coupled],
    )
    events = space.step_coupled(signal=0.0, dt=1.0)
    assert len(events) == 1
    event = events[0]
    assert isinstance(event, TaskCouplingEvent)
    assert space.get("battery") == pytest.approx(event.post_value)
    snapshot = space.snapshot(HealthModel("l2"))
    assert "battery" in snapshot.coupled_values
    assert snapshot.coupled_values["battery"] == pytest.approx(event.post_value)
