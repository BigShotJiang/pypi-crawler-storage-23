from __future__ import annotations

import subprocess
import sys


def test_importing_ultrastable_does_not_import_benchmark_subpackage() -> None:
    """Guard that the core import path stays free of benchmark/baseline code."""
    code = (
        "import sys; import ultrastable;"
        "print(any(name.startswith('ultrastable.benchmark') for name in sys.modules))"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
        check=True,
    )
    assert result.stdout.strip() == "False"
