from __future__ import annotations

import json
from pathlib import Path

from ultrastable.benchmark.baseline_metrics import emit_baseline_results
from ultrastable.benchmark.config import BaselineRunnerSpec, TimeoutLimits
from ultrastable.benchmark.manifest import SuiteDescriptor


def test_emit_baseline_results_builds_case_variants(tmp_path: Path) -> None:
    ledger_path = tmp_path / "baseline_ledger.jsonl"
    events = [
        {
            "event_type": "step",
            "timestamp": "2026-02-26T00:00:00.000Z",
            "step_id": "s1-step-1",
            "role": "assistant",
            "kind": "llm",
            "tokens_total": 50,
            "cost_usd": 0.02,
            "tags": {"case_id": "s1"},
        },
        {
            "event_type": "trigger",
            "timestamp": "2026-02-26T00:00:01.000Z",
            "tags": {"case_id": "s1"},
        },
        {
            "event_type": "step",
            "timestamp": "2026-02-26T00:00:02.000Z",
            "step_id": "s2-step-1",
            "role": "tool",
            "kind": "tool",
            "tokens_total": 10,
            "cost_usd": 0.001,
            "tags": {"case_id": "s2"},
        },
        {
            "event_type": "intervention",
            "timestamp": "2026-02-26T00:00:03.000Z",
            "tags": {"case_id": "s2"},
        },
        {
            "event_type": "error",
            "timestamp": "2026-02-26T00:00:04.000Z",
            "tags": {"case_id": "s2"},
        },
    ]
    ledger_path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
    suite = SuiteDescriptor(name="afmb", version="v1", cases=("s1", "s2", "s3"))
    baseline = BaselineRunnerSpec(
        name="timeout_only",
        kind="timeout_only",
        limits=TimeoutLimits(max_steps=10),
        cases=suite.cases,
        tags=("afmb", "baseline"),
        metadata={"severity": "strict"},
    )

    results = emit_baseline_results(suite=suite, baseline=baseline, ledger_path=ledger_path)

    assert results.summary.cases_total == 3
    assert results.summary.cases_failed == 1
    assert results.summary.cases_errored == 1
    assert results.summary.status == "error"
    assert results.summary.metrics["total_steps"] == 2
    assert results.summary.metrics["total_cost_usd"] == 0.021

    case_s1, case_s2, case_s3 = results.cases
    assert case_s1.case_id == "s1" and case_s1.status == "failed"
    assert case_s2.case_id == "s2" and case_s2.status == "error"
    assert case_s3.case_id == "s3" and case_s3.status == "skipped"

    variant_s1 = case_s1.variants[0]
    assert variant_s1.name == "timeout_only"
    assert variant_s1.metrics["steps"] == 1
    assert variant_s1.metrics["violations"] == 1
    assert variant_s1.metrics["tokens_total"] == 50
    assert variant_s1.metrics["cost_usd"] == 0.02
    assert variant_s1.metadata["limits"]["max_steps"] == 10

    variant_s2 = case_s2.variants[0]
    assert variant_s2.metrics["steps"] == 1
    assert variant_s2.metrics["tool_calls"] == 1
    assert variant_s2.metrics["errors"] == 1


def test_emit_baseline_results_supports_custom_case_tag(tmp_path: Path) -> None:
    ledger_path = tmp_path / "custom_case_tag.jsonl"
    events = [
        {
            "event_type": "step",
            "timestamp": "2026-02-26T01:00:00.000Z",
            "step_id": "scenario-a-1",
            "tokens_total": 5,
            "cost_usd": 0.0005,
            "tags": {"scenario": "case-a"},
        }
    ]
    ledger_path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
    suite = SuiteDescriptor(name="afmb", version="v1")
    baseline = BaselineRunnerSpec(
        name="retry_cap",
        kind="timeout_only",
        limits=TimeoutLimits(max_steps=2),
        cases=("case-a",),
        tags=("afmb", "baseline"),
        metadata={},
    )

    results = emit_baseline_results(
        suite=suite,
        baseline=baseline,
        ledger_path=ledger_path,
        case_tag="scenario",
    )

    assert len(results.cases) == 1
    assert results.cases[0].case_id == "case-a"
    assert results.cases[0].metrics["steps"] == 1


def test_emit_baseline_results_computes_metrics_from_synthetic_ledger(tmp_path: Path) -> None:
    ledger_path = tmp_path / "synthetic_metrics.jsonl"
    events = [
        {
            "event_type": "step",
            "timestamp": "2026-02-26T00:00:00.000Z",
            "step_id": "guarded-1",
            "tokens_prompt": 30,
            "tokens_completion": 20,
            "cost_usd": 0.02,
            "role": "assistant",
            "tags": {"case_id": "case-guarded"},
        },
        {
            "event_type": "step",
            "timestamp": "2026-02-26T00:00:12.000Z",
            "step_id": "guarded-2",
            "tokens_total": 10,
            "cost_usd": 0.005,
            "role": "tool",
            "kind": "tool",
            "tags": {"case_id": "case-guarded"},
        },
        {
            "event_type": "trigger",
            "timestamp": "2026-02-26T00:00:20.000Z",
            "tags": {"case_id": "case-guarded"},
        },
        {
            "event_type": "intervention",
            "timestamp": "2026-02-26T00:00:28.000Z",
            "tags": {"case_id": "case-guarded"},
        },
        {
            "event_type": "step",
            "timestamp": "2026-02-26T00:02:00.000Z",
            "step_id": "baseline-1",
            "tokens_total": 15,
            "cost_usd": 0.01,
            "role": "assistant",
            "tags": {"case_id": "case-baseline"},
        },
        {
            "event_type": "error",
            "timestamp": "2026-02-26T00:02:05.000Z",
            "tags": {"case_id": "case-baseline"},
        },
    ]
    ledger_path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
    suite = SuiteDescriptor(name="afmb", version="v1", cases=("case-guarded", "case-baseline"))
    baseline = BaselineRunnerSpec(
        name="timeout_only",
        kind="timeout_only",
        limits=TimeoutLimits(max_steps=5),
        cases=suite.cases,
        tags=("afmb", "baseline"),
        metadata={},
    )

    results = emit_baseline_results(suite=suite, baseline=baseline, ledger_path=ledger_path)

    guarded = next(case for case in results.cases if case.case_id == "case-guarded")
    baseline_case = next(case for case in results.cases if case.case_id == "case-baseline")

    assert guarded.metrics["steps"] == 2
    assert guarded.metrics["tokens_total"] == 60
    assert guarded.metrics["cost_usd"] == 0.025
    assert guarded.metrics["tool_calls"] == 1
    assert guarded.metrics["violations"] == 1
    assert guarded.metrics["interventions"] == 1
    assert guarded.duration_seconds == 12.0
    assert "duration_seconds" not in guarded.metrics
    assert guarded.status == "failed"

    assert baseline_case.metrics["steps"] == 1
    assert baseline_case.metrics["tokens_total"] == 15
    assert baseline_case.metrics["cost_usd"] == 0.01
    assert baseline_case.duration_seconds == 0.0
    assert "duration_seconds" not in baseline_case.metrics
    assert baseline_case.metrics["errors"] == 1
    assert baseline_case.status == "error"

    summary = results.summary
    assert summary.duration_seconds == 125.0
    assert summary.metrics["total_steps"] == 3
    assert summary.metrics["total_tokens"] == 75
    assert summary.metrics["total_cost_usd"] == 0.035
    assert summary.metrics["total_tool_calls"] == 1
    assert summary.metrics["total_violations"] == 1
