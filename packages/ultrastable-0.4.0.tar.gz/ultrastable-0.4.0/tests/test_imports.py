import importlib
import importlib.metadata as importlib_metadata
import sys


def test_top_level_import_works() -> None:
    import ultrastable  # noqa: F401


def test_core_import_minimal_and_no_optional_deps() -> None:
    # Import the core module
    forbidden = [
        "pydantic",
        "rich",
        "typer",
        "httpx",
        "gymnasium",
        "torch",
        "opentelemetry",
    ]
    baseline_modules = set(sys.modules)

    import ultrastable.core as core  # noqa: F401

    # Core should cause numpy to be present (declared dependency)
    assert "numpy" in sys.modules, "numpy should be imported by ultrastable.core"

    # Ensure optional extra deps are NOT imported as a side effect
    for name in forbidden:
        newly_loaded = name in sys.modules and name not in baseline_modules
        assert not newly_loaded, f"{name} imported unexpectedly"


def test_import_ultrastable_core_idempotent() -> None:
    import ultrastable.core as core

    before = set(sys.modules.keys())
    importlib.reload(core)
    after = set(sys.modules.keys())

    # Reloading core should not suddenly import optional deps
    forbidden = {
        "pydantic",
        "rich",
        "typer",
        "httpx",
        "gymnasium",
        "torch",
        "opentelemetry",
    }
    assert forbidden.isdisjoint(after - before)


def test_opentelemetry_dependencies_are_scoped_to_extras() -> None:
    requirements = importlib_metadata.requires("ultrastable") or []
    otel_requirements = [
        requirement for requirement in requirements if "opentelemetry" in requirement.lower()
    ]
    # Ensure the extras actually carry the exporter dependencies.
    assert otel_requirements, "Expected otlp/cortex extras to declare OpenTelemetry deps"
    allowed_markers = ('extra == "otlp"', 'extra == "cortex"')
    for requirement in otel_requirements:
        assert any(marker in requirement for marker in allowed_markers), (
            f"OpenTelemetry dependency leaked into the core install: {requirement}"
        )
