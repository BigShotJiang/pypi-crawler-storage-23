from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from ultrastable.cli.main import main as cli_main
from ultrastable.core.events import InterventionEvent, RunEvent, StepEvent
from ultrastable.ledger import JsonlLedger
from ultrastable.policy import canonicalize_policy, policy_hash


def write_sample_ledger(path: Path) -> None:
    ledger = JsonlLedger(str(path))
    ledger.add(
        StepEvent(
            step_id="s1", role="assistant", kind="llm", response_text="hello", tokens_total=10
        )
    )
    ledger.close()


def write_report_ledger(path: Path) -> None:
    ledger = JsonlLedger(str(path))
    ledger.add(RunEvent(run_id="r1", phase="start", meta={"tags": {"customer": "c1"}}))
    ledger.add(
        StepEvent(
            step_id="s1",
            role="assistant",
            kind="llm",
            response_text="hello",
            tokens_total=10,
            cost_usd=0.01,
            tags={"customer": "c1"},
        )
    )
    ledger.add(RunEvent(run_id="r1", phase="end", meta={"status": "completed"}))
    ledger.close()


def write_health_ledger(path: Path) -> None:
    ledger = JsonlLedger(str(path))
    ledger.add(
        RunEvent(
            run_id="health-run",
            phase="start",
            timestamp="2024-02-10T00:00:00Z",
            meta={"tags": {"customer": "synth"}},
        )
    )
    values = [0.5, 0.35, 0.2, 0.1]
    for idx, value in enumerate(values):
        ledger.add(
            StepEvent(
                step_id=f"h{idx}",
                role="assistant",
                kind="llm",
                response_text="hi",
                tokens_total=5,
                cost_usd=0.005,
                d_h=value,
                tags={"customer": "synth"},
                timestamp=f"2024-02-10T00:00:{idx * 5:02d}Z",
            )
        )
    ledger.add(
        InterventionEvent(
            intervention_type="RESET_CONTEXT_TRIM",
            parameters={"phase": "outcome"},
            outcome={
                "intervention_type": "RESET_CONTEXT_TRIM",
                "delta_dh": 0.2,
                "status": "recovered",
            },
            tags={"status": "recovered"},
            timestamp="2024-02-10T00:01:00Z",
        )
    )
    ledger.add(
        InterventionEvent(
            intervention_type="RESET_CONTEXT_TRIM",
            parameters={"phase": "outcome"},
            outcome={
                "intervention_type": "RESET_CONTEXT_TRIM",
                "delta_dh": -0.05,
                "status": "regressed",
            },
            tags={"status": "regressed"},
            timestamp="2024-02-10T00:01:30Z",
        )
    )
    ledger.add(
        RunEvent(
            run_id="health-run",
            phase="end",
            timestamp="2024-02-10T00:02:00Z",
            meta={"status": "completed"},
        )
    )
    ledger.close()


def write_legacy_ledger_without_hash_chain(path: Path) -> None:
    records = [
        {
            "event_type": "run",
            "schema_version": "1.1",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "run_id": "legacy",
            "phase": "start",
        },
        {
            "event_type": "step",
            "schema_version": "1.1",
            "timestamp": "2025-01-01T00:01:00.000Z",
            "step_id": "legacy-step",
            "role": "assistant",
            "kind": "llm",
            "tokens_total": 5,
        },
    ]
    serialized = "\n".join(json.dumps(record) for record in records)
    path.write_text(serialized + "\n", encoding="utf-8")


def write_policy_pack(path: Path) -> dict[str, Any]:
    pack: dict[str, Any] = {
        "name": "demo-pack",
        "policy": {
            "variables": [
                {"name": "spend_usd", "kind": "monotonic", "scale": 1, "hard_limit": 10},
                {"name": "tokens_total", "kind": "monotonic", "scale": 100, "hard_limit": 100},
            ]
        },
        "detectors": [{"kind": "lexical_repeat"}],
        "interventions": [{"kind": "reset_replan"}],
    }
    path.write_text(json.dumps(pack), encoding="utf-8")
    return pack


def _load_ledger_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open(encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
    return records


def _rewrite_ledger(path: Path, records: list[dict[str, Any]]) -> None:
    serialized = "\n".join(
        json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        for record in records
    )
    path.write_text(serialized + "\n", encoding="utf-8")


def test_cli_inspect_and_validate(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    assert cli_main(["inspect", str(ledger_path)]) == 0
    inspect_out = capsys.readouterr().out
    data = json.loads(inspect_out)
    assert data["events_total"] == 1

    assert cli_main(["validate", "ledger", str(ledger_path)]) == 0
    validate_out = capsys.readouterr().out
    assert "Ledger OK" in validate_out


def test_cli_ledger_validate_command(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    assert cli_main(["ledger", "validate", str(ledger_path)]) == 0
    output = capsys.readouterr().out
    assert "Ledger OK" in output


def test_cli_ledger_validate_hash_chain(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    assert cli_main(["ledger", "validate", str(ledger_path), "--hash-chain"]) == 0
    output = capsys.readouterr().out.lower()
    assert "hash chain verified" in output


def test_cli_ledger_validate_hash_chain_accepts_legacy_ledgers(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "legacy.jsonl"
    write_legacy_ledger_without_hash_chain(ledger_path)
    assert cli_main(["ledger", "validate", str(ledger_path), "--hash-chain"]) == 0
    output = capsys.readouterr().out.lower()
    assert "hash chain absent" in output


def test_cli_ledger_validate_hash_chain_detects_tampering(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    lines = [
        json.loads(line)
        for line in ledger_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert lines, "ledger should contain at least one event"
    lines[0]["event_type"] = "tampered"
    ledger_path.write_text(
        "\n".join(
            json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for record in lines
        )
        + "\n",
        encoding="utf-8",
    )
    assert cli_main(["ledger", "validate", str(ledger_path), "--hash-chain"]) == 1
    output = capsys.readouterr().out.lower()
    assert "hash chain validation failed" in output


def test_cli_ledger_validate_hash_chain_detects_reordering(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_report_ledger(ledger_path)
    records = _load_ledger_records(ledger_path)
    assert len(records) >= 3
    records[1], records[2] = records[2], records[1]
    _rewrite_ledger(ledger_path, records)
    assert cli_main(["ledger", "validate", str(ledger_path), "--hash-chain"]) == 1
    output = capsys.readouterr().out.lower()
    assert "hash chain validation failed" in output
    assert "prev_hash mismatch" in output


def test_cli_ledger_validate_hash_chain_detects_insertion(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_report_ledger(ledger_path)
    records = _load_ledger_records(ledger_path)
    assert len(records) >= 3
    dup_record = json.loads(json.dumps(records[1]))
    records.insert(1, dup_record)
    _rewrite_ledger(ledger_path, records)
    assert cli_main(["ledger", "validate", str(ledger_path), "--hash-chain"]) == 1
    output = capsys.readouterr().out.lower()
    assert "hash chain validation failed" in output
    assert "prev_hash mismatch" in output


def test_cli_inspect_output_file(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    output_file = tmp_path / "inspect.json"

    assert (
        cli_main(["inspect", str(ledger_path), "--format", "json", "--output", str(output_file)])
        == 0
    )
    captured = capsys.readouterr()
    assert captured.out == ""
    payload = json.loads(output_file.read_text(encoding="utf-8"))
    assert payload["events_total"] == 1


def test_cli_replay(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    assert cli_main(["replay", str(ledger_path), "--demo-policy", "agent-loop"]) == 0
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert payload["steps"] == 1
    assert payload["metadata"]["hash_chain"]["verified"] is True


def test_cli_replay_deterministic(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    cmd = ["replay", str(ledger_path), "--demo-policy", "agent-loop", "--deterministic"]
    assert cli_main(cmd) == 0
    payload1 = json.loads(capsys.readouterr().out)
    assert payload1["metadata"]["deterministic"] is True
    assert "seed" in payload1["metadata"]
    assert payload1["metadata"]["hash_chain"]["verified"] is True
    assert cli_main(cmd) == 0
    payload2 = json.loads(capsys.readouterr().out)
    assert payload1 == payload2


def test_cli_replay_detects_hash_mismatch(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_sample_ledger(ledger_path)
    records = _load_ledger_records(ledger_path)
    assert records
    records[0]["response_text"] = "tampered"
    _rewrite_ledger(ledger_path, records)
    assert cli_main(["replay", str(ledger_path), "--demo-policy", "agent-loop"]) == 1
    output = capsys.readouterr().out.lower()
    assert "event_hash mismatch" in output


def test_cli_demo_agent_loop(tmp_path: Path) -> None:
    output = tmp_path / "demo_ledgers" / "agent_loop.jsonl"
    assert cli_main(["demo", "agent-loop", "--output", str(output)]) == 0
    assert output.exists()


def test_cli_demo_redaction_override(tmp_path: Path) -> None:
    output = tmp_path / "demo_ledgers" / "agent_loop_full.jsonl"
    args = ["demo", "agent-loop", "--output", str(output), "--redaction", "none"]
    assert cli_main(args) == 0
    with output.open(encoding="utf-8") as fp:
        events = [json.loads(line) for line in fp if line.strip()]
    step_events = [e for e in events if e.get("event_type") == "step"]
    assert step_events
    assert any("response_text" in event for event in step_events)


def test_cli_dashboard_requires_rich(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from ultrastable.cli import dashboard as dash_mod

    monkeypatch.setattr(dash_mod, "rich_available", lambda: False)
    assert cli_main(["dashboard", "agent-loop"]) == 1
    out = capsys.readouterr().out.lower()
    assert "rich" in out and "extra" in out


def test_cli_validate_policy(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    policy_path = tmp_path / "policy.json"
    policy_path.write_text(
        json.dumps(
            {
                "policy": {
                    "variables": [
                        {"name": "spend", "kind": "monotonic", "scale": 1, "hard_limit": 10}
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    assert cli_main(["validate", "policy", str(policy_path)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["policy_hash"]
    assert payload["canonical_policy"]["policy"]["variables"][0]["name"] == "spend"


def test_cli_report_spend(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "report.jsonl"
    write_report_ledger(ledger_path)
    assert cli_main(["report", "spend", str(ledger_path), "--by", "customer"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["totals"]["tokens"] == 10
    assert payload["groups"][0]["key"] == "c1"


def test_cli_report_spend_includes_health_summary(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "health.jsonl"
    write_health_ledger(ledger_path)
    assert cli_main(["report", "spend", str(ledger_path), "--by", "customer"]) == 0
    payload = json.loads(capsys.readouterr().out)
    health = payload["health"]
    trend = health["d_h_trend"]
    assert trend["samples"] == 4
    assert trend["start"]["d_h"] == pytest.approx(0.5)
    assert trend["end"]["d_h"] == pytest.approx(0.1)
    assert trend["delta"] == pytest.approx(-0.4)
    assert trend["min"]["d_h"] == pytest.approx(0.1)
    assert trend["max"]["d_h"] == pytest.approx(0.5)
    effect = health["intervention_effect_size"]
    assert effect["samples"] == 2
    assert effect["largest_recovery"] == pytest.approx(0.2)
    assert effect["largest_regression"] == pytest.approx(-0.05)
    assert effect["improved_fraction"] == pytest.approx(0.5)
    assert effect["worsened_fraction"] == pytest.approx(0.5)
    assert effect["status_breakdown"]["recovered"] == 1
    assert effect["status_breakdown"]["regressed"] == 1


def test_cli_report_spend_text_shows_health_summary(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    ledger_path = tmp_path / "health_text.jsonl"
    write_health_ledger(ledger_path)
    assert (
        cli_main(
            [
                "report",
                "spend",
                str(ledger_path),
                "--by",
                "customer",
                "--format",
                "text",
            ]
        )
        == 0
    )
    output = capsys.readouterr().out
    assert "D(H) trend" in output
    assert "samples=4" in output
    assert "Delta D(H) summary" in output
    assert "samples=2" in output


def test_cli_report_spend_output_file(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "report.jsonl"
    write_report_ledger(ledger_path)
    output_file = tmp_path / "report.json"

    assert (
        cli_main(
            [
                "report",
                "spend",
                str(ledger_path),
                "--by",
                "customer",
                "--format",
                "json",
                "--output",
                str(output_file),
            ]
        )
        == 0
    )
    captured = capsys.readouterr()
    assert captured.out == ""
    payload = json.loads(output_file.read_text(encoding="utf-8"))
    assert payload["groups"][0]["key"] == "c1"


def test_cli_export_routing_policy(tmp_path: Path) -> None:
    ledger_path = tmp_path / "report.jsonl"
    write_report_ledger(ledger_path)
    output = tmp_path / "routing.json"
    args = [
        "export",
        "routing-policy",
        str(ledger_path),
        "--group-by",
        "customer",
        "--limit",
        "1",
    ]
    assert cli_main([*args, "--output", str(output)]) == 0
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["routes"] and payload["routes"][0]["key"] == "c1"

    output_copy = tmp_path / "routing_repeat.json"
    assert cli_main([*args, "--output", str(output_copy)]) == 0
    assert output.read_text(encoding="utf-8") == output_copy.read_text(encoding="utf-8")


def test_cli_export_budget_policy(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "report.jsonl"
    write_report_ledger(ledger_path)
    output = tmp_path / "policy.json"
    assert (
        cli_main(
            [
                "export",
                "budget-policy",
                str(ledger_path),
                "--name",
                "auto",
                "--output",
                str(output),
            ]
        )
        == 0
    )
    policy = json.loads(output.read_text(encoding="utf-8"))
    canonical = canonicalize_policy(policy)
    assert canonical["name"] == "auto"
    assert canonical["meta"]["budget_routes"]

    capsys.readouterr()
    assert cli_main(["validate", "policy", str(output)]) == 0
    validation_payload = json.loads(capsys.readouterr().out)
    assert validation_payload["policy_hash"]
    assert validation_payload["canonical_policy"]["name"] == "auto"


def test_cli_demo_with_policy_pack(tmp_path: Path) -> None:
    ledger_path = tmp_path / "demo_pack.jsonl"
    pack_path = tmp_path / "pack.json"
    pack = write_policy_pack(pack_path)
    expected_hash = policy_hash(pack)
    assert (
        cli_main(
            [
                "demo",
                "agent-loop",
                "--output",
                str(ledger_path),
                "--policy-pack",
                str(pack_path),
            ]
        )
        == 0
    )
    with ledger_path.open(encoding="utf-8") as fp:
        events = [json.loads(line) for line in fp if line.strip()]
    run_events = [e for e in events if e["event_type"] == "run"]
    assert run_events and run_events[0]["policy_hash"] == expected_hash


def test_cli_replay_with_policy_pack(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    ledger_path = tmp_path / "ledger.jsonl"
    write_report_ledger(ledger_path)
    pack_path = tmp_path / "pack.json"
    write_policy_pack(pack_path)
    assert cli_main(["replay", str(ledger_path), "--policy-pack", str(pack_path)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["steps"] >= 1


def test_cli_validate_policy_validation_error(tmp_path: Path) -> None:
    policy_path = tmp_path / "bad_policy.json"
    policy_path.write_text(
        json.dumps({"policy": {"variables": []}}, indent=2),
        encoding="utf-8",
    )
    assert cli_main(["validate", "policy", str(policy_path)]) == 2


def test_cli_validate_policy_missing_file(tmp_path: Path) -> None:
    missing = tmp_path / "missing.json"
    assert cli_main(["validate", "policy", str(missing)]) == 1
