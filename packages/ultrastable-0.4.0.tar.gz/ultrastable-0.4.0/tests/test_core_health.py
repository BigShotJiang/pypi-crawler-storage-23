from __future__ import annotations

import json
import random

import numpy as np

from ultrastable.core import (
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.core.events import EVENT_SCHEMA_VERSION


def test_construction_helpers_and_validation() -> None:
    # Valid constructions
    ev1 = EssentialVariable.setpoint("latency_ms", target=350, tolerance=50, scale=350, weight=1.0)
    ev2 = EssentialVariable.bounded("context_util", min=0.0, max=0.85, scale=0.85, weight=1.2)
    ev3 = EssentialVariable.monotonic("spend_usd", hard_limit=5.0, scale=5.0, weight=2.0)

    assert ev1.kind == "SETPOINT" and ev2.kind == "BOUNDED" and ev3.kind == "MONOTONIC"

    # Invalid: negative scale, NaN, wrong bounds
    try:
        EssentialVariable.bounded("bad", min=1.0, max=0.5, scale=1.0)
        raise AssertionError("expected ValueError for invalid bounds")
    except ValueError:
        pass
    try:
        EssentialVariable.monotonic("bad2", hard_limit=0.0, scale=1.0)
        raise AssertionError("expected ValueError for non-positive hard_limit")
    except ValueError:
        pass


def test_normalized_deviation_and_aggregation() -> None:
    evs = [
        EssentialVariable.setpoint("a", target=0.0, tolerance=1.0, scale=1.0, weight=1.0),
        EssentialVariable.bounded("b", min=-1.0, max=1.0, scale=1.0, weight=2.0),
        EssentialVariable.monotonic("c", hard_limit=10.0, scale=10.0, weight=3.0),
    ]
    space = EssentialVariableSpace(evs)
    space.batch_update({"a": 0.0, "b": 0.5, "c": 2})

    health_l1 = HealthModel("l1")
    devs, d1 = health_l1.compute(space)
    assert np.isclose(devs["a"], 0.0)
    assert np.isclose(devs["b"], 0.0)  # inside bounds => 0
    assert np.isclose(devs["c"], 0.2)  # 2/10
    # Weighted l1 = 1*0 + 2*0 + 3*0.2 = 0.6
    assert np.isclose(d1, 0.6)

    health_l2 = HealthModel("l2")
    _, d2 = health_l2.compute(space)
    assert np.isclose(d2, np.sqrt((0.0**2) + (0.0**2) + (0.6**2)))  # weights already applied

    health_linf = HealthModel("linf")
    _, d_inf = health_linf.compute(space)
    assert np.isclose(d_inf, 0.6)


def test_space_snapshot_event_and_tags() -> None:
    evs = [
        EssentialVariable.setpoint(
            "temperature", target=20, tolerance=2, scale=2, tags={"unit": "C"}
        ),
        EssentialVariable.bounded(
            "context_util", min=0.0, max=0.85, scale=0.85, tags={"unit": "ratio"}
        ),
        EssentialVariable.monotonic("retries", hard_limit=7, scale=7, tags={"unit": "count"}),
    ]
    space = EssentialVariableSpace(evs)
    space.batch_update({"temperature": 20.0, "context_util": 0.5, "retries": 3})

    health = HealthModel("l2")
    snap = space.snapshot(health)
    data = json.loads(snap.to_json())
    assert data["schema_version"] == EVENT_SCHEMA_VERSION
    assert data["event_type"] == "health_snapshot"
    assert set(data["values"]).issuperset({"temperature", "context_util", "retries"})
    assert set(data["deviations"]).issuperset({"temperature", "context_util", "retries"})
    assert "variable_tags" in data and data["variable_tags"]["retries"]["unit"] == "count"


def test_viability_policy_budget_breach_and_warn_with_hysteresis() -> None:
    spend = EssentialVariable.monotonic("spend_usd", hard_limit=100.0, scale=100.0, hysteresis=0.05)
    space = EssentialVariableSpace([spend])
    health = HealthModel("l2")
    policy = ViabilityPolicy(space, health=health, monotonic_warn_fraction=0.9)

    space.set("spend_usd", 95)
    status, reasons = policy.evaluate()
    assert status == "warn" and any("near budget" in r for r in reasons)

    # Slight decrease that is within hysteresis should stay warn
    space.set("spend_usd", 89.9)
    status2, _ = policy.evaluate()
    assert status2 == "warn"

    # Big drop should return to ok
    space.set("spend_usd", 50)
    status3, _ = policy.evaluate()
    assert status3 == "ok"

    # Breach => critical
    space.set("spend_usd", 101)
    status4, reasons4 = policy.evaluate()
    assert status4 == "critical" and any("budget breach" in r for r in reasons4)


def test_distance_to_boundary_behavior() -> None:
    evs = [
        EssentialVariable.bounded("util", min=0.0, max=1.0, scale=1.0),
        EssentialVariable.setpoint("latency", target=100.0, tolerance=25.0, scale=25.0),
        EssentialVariable.monotonic("calls", hard_limit=10.0, scale=10.0),
    ]
    space = EssentialVariableSpace(evs)
    space.batch_update({"util": 0.25, "latency": 90.0, "calls": 3})
    policy = ViabilityPolicy(space)
    d = policy.distance_to_boundary()
    # > 0 because within bounds / under limit
    assert d["util"] > 0 and d["latency"] > 0 and d["calls"] > 0

    space.set("util", 1.1)  # outside bounds
    d2 = policy.distance_to_boundary()
    assert d2["util"] == 0.0


def test_deviation_non_negative_across_variables() -> None:
    rng = random.Random(42)
    evs = [
        EssentialVariable.setpoint("latency", target=100.0, tolerance=20.0, scale=20.0),
        EssentialVariable.bounded("util", min=0.0, max=0.9, scale=0.9),
        EssentialVariable.monotonic("spend", hard_limit=10.0, scale=10.0),
    ]
    for ev in evs:
        for _ in range(200):
            if ev.kind == "MONOTONIC":
                value = rng.uniform(0.0, 15.0)
            else:
                value = rng.uniform(-5.0, 15.0)
            assert ev.deviation(value) >= 0.0
            assert ev.distance_to_boundary(value) >= 0.0


def test_monotonic_variable_deviation_ordered() -> None:
    rng = random.Random(7)
    ev = EssentialVariable.monotonic("requests", hard_limit=12.0, scale=12.0)
    for _ in range(200):
        a = rng.uniform(0.0, 18.0)
        b = rng.uniform(0.0, 18.0)
        dev_a = ev.deviation(a)
        dev_b = ev.deviation(b)
        if a <= b:
            assert dev_a <= dev_b + 1e-12
        else:
            assert dev_a >= dev_b - 1e-12


def test_bounded_variable_zero_inside_range() -> None:
    rng = random.Random(99)
    ev = EssentialVariable.bounded("pressure", min=-2.0, max=3.0, scale=5.0)
    for _ in range(200):
        sample = rng.uniform(-2.0, 3.0)
        assert abs(ev.deviation(sample)) <= 1e-12
