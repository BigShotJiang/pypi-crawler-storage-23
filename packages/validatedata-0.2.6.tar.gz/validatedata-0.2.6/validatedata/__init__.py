from .validatedata import validate, validate_data, validate_types

__version__ = '0.2.6'
