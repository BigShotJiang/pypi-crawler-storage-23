import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt


class ID3Classifier:

    def __init__(self):

        self.tree = None
        self.target = "__target__"
        self.features = None
        self.majority_class = None
        self.max_depth = None


    # ===============================
    # ENTROPY
    # ===============================
    def entropy(self, data):

        values, counts = np.unique(
            data,
            return_counts=True
        )

        ent = 0

        for count in counts:

            prob = count / sum(counts)

            if prob > 0:

                ent -= prob * math.log2(prob)

        return ent


    # ===============================
    # INFORMATION GAIN
    # ===============================
    def information_gain(self, df, feature):

        total_entropy = self.entropy(
            df[self.target]
        )

        values, counts = np.unique(
            df[feature],
            return_counts=True
        )

        weighted_entropy = 0

        for i in range(len(values)):

            subset = df[
                df[feature] == values[i]
            ]

            subset_entropy = self.entropy(
                subset[self.target]
            )

            weight = counts[i] / sum(counts)

            weighted_entropy += (
                weight * subset_entropy
            )

        return total_entropy - weighted_entropy


    # ===============================
    # ID3 TREE BUILDER
    # ===============================
    def _id3(self, data, features, depth):

        # pure node
        if len(
            np.unique(data[self.target])
        ) == 1:

            return np.unique(
                data[self.target]
            )[0]


        # ⭐ MAX DEPTH STOP (TRAINING)
        if (

            self.max_depth is not None

            and depth >= self.max_depth

        ):

            return data[
                self.target
            ].mode()[0]


        # no features
        if len(features) == 0:

            return data[
                self.target
            ].mode()[0]


        igs = [

            self.information_gain(
                data,
                f
            )

            for f in features

        ]

        best = features[np.argmax(igs)]

        tree = {best: {}}

        remaining = [

            f for f in features
            if f != best

        ]


        for value in np.unique(data[best]):

            subset = data[
                data[best] == value
            ]

            if len(subset) == 0:

                tree[best][value] = data[
                    self.target
                ].mode()[0]

            else:

                tree[best][value] = self._id3(

                    subset,

                    remaining,

                    depth + 1

                )

        return tree


    # ===============================
    # SKLEARN STYLE FIT
    # ===============================
    def fit(self, X, y, max_depth=None):

        if not isinstance(X, pd.DataFrame):

            X = pd.DataFrame(X)

        df = X.copy()

        df[self.target] = y

        self.features = list(X.columns)

        self.majority_class = df[
            self.target
        ].mode()[0]

        self.max_depth = max_depth

        self.tree = self._id3(

            df,

            self.features,

            depth=0

        )

        return self


    # ===============================
    # PRINT TREE
    # ===============================
    def print_tree(

        self,

        tree=None,

        indent="",

        depth=0,

        max_depth=None

    ):

        if tree is None:

            tree = self.tree


        # ⭐ STOP PRINT
        if (

            max_depth is not None

            and depth == max_depth

        ):

            print(indent + "...")
            return


        if not isinstance(tree, dict):

            print(indent + "→", tree)

            return


        root = list(tree.keys())[0]

        print(indent + root)


        for value, subtree in tree[root].items():

            print(indent + " ├─", value)

            self.print_tree(

                subtree,

                indent + " │   ",

                depth + 1,

                max_depth

            )


    # ===============================
    # TREE PLOT
    # ===============================
    def plot_tree(

        self,

        save_as=None,

        max_depth=None

    ):

        fig, ax = plt.subplots(

            figsize=(14,9)

        )

        ax.axis('off')

        level_gap = 0.15


        def draw_node(node, x, y, dx, depth):

            # ⭐ STOP DRAWING
            if (

                max_depth is not None

                and depth == max_depth

            ):

                ax.text(

                    x,

                    y,

                    "...",

                    ha='center',

                    bbox=dict(

                        boxstyle="round",

                        fc="lightgrey",

                        ec="black"

                    )

                )

                return


            if not isinstance(node, dict):

                ax.text(

                    x,

                    y,

                    str(node),

                    ha='center',

                    bbox=dict(

                        boxstyle="round",

                        fc="lightblue",

                        ec="black"

                    )

                )

                return


            root = list(node.keys())[0]


            ax.text(

                x,

                y,

                root,

                ha='center',

                bbox=dict(

                    boxstyle="round",

                    fc="lightgreen",

                    ec="black"

                )

            )


            children = list(

                node[root].items()

            )

            n = len(children)

            start_x = x - dx*(n-1)/2


            for i,(value, subtree) in enumerate(children):

                child_x = start_x + i*dx

                child_y = y - level_gap


                ax.plot(

                    [x, child_x],

                    [y-0.02, child_y+0.02],

                    'k'

                )


                ax.text(

                    (x+child_x)/2,

                    (y+child_y)/2,

                    str(value),

                    ha='center'

                )


                draw_node(

                    subtree,

                    child_x,

                    child_y,

                    dx/1.8,

                    depth + 1

                )


        draw_node(

            self.tree,

            0.5,

            1.0,

            0.4,

            depth=0

        )


        if save_as:

            plt.savefig(

                save_as,

                bbox_inches="tight"

            )

            print(f"Tree saved as {save_as}")


        plt.show()


    # ===============================
    # SINGLE PREDICT
    # ===============================
    def _predict(self, tree, sample):

        if not isinstance(tree, dict):

            return tree


        root = list(tree.keys())[0]

        value = sample[root]


        if value not in tree[root]:

            return self.majority_class


        return self._predict(

            tree[root][value],

            sample

        )


    # ===============================
    # SKLEARN STYLE PREDICT
    # ===============================
    def predict(self, X):

        if not isinstance(X, pd.DataFrame):

            X = pd.DataFrame(X)

        preds = []

        for _, row in X.iterrows():

            preds.append(

                self._predict(

                    self.tree,

                    row

                )

            )

        return np.array(preds)