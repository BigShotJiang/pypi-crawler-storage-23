from __future__ import annotations

from oncecheck.auth.api import normalize_quota_result
from oncecheck.cli import _quota_detail_text


def test_normalize_quota_starter_never_unlimited():
    raw = {"allowed": True, "plan": "starter", "used": 5, "limit": -1}
    normalized = normalize_quota_result(raw, fallback_plan="starter")
    assert normalized["plan"] == "starter"
    assert normalized["limit"] == 3
    assert normalized["allowed"] is False


def test_normalize_quota_team_unlimited():
    raw = {"allowed": True, "plan": "team", "used": 8, "limit": -1}
    normalized = normalize_quota_result(raw, fallback_plan="team")
    assert normalized["plan"] == "team"
    assert normalized["limit"] == -1
    assert normalized["allowed"] is True


def test_normalize_quota_enforces_cap_even_when_server_allowed():
    raw = {"allowed": True, "plan": "starter", "used": 3, "limit": 3}
    normalized = normalize_quota_result(raw, fallback_plan="starter")
    assert normalized["allowed"] is False


def test_quota_detail_text_shows_unlimited_label():
    assert _quota_detail_text({"used": 5, "limit": -1}) == "5/unlimited today"
