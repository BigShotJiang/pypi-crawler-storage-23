from __future__ import annotations

from oncecheck.cli import cli, _platform_from_rule_id, _platforms_for_filter


def test_scan_has_policy_freshness_options():
    scan_cmd = cli.commands["scan"]
    option_names = {param.name for param in scan_cmd.params}
    assert "analysis_mode" in option_names
    assert "require_compiler_engine" in option_names
    assert "advanced_profile" in option_names
    assert "install_engines" in option_names
    assert "policy_sync" in option_names
    assert "policy_max_age_days" in option_names
    assert "require_fresh_policies" in option_names


def test_rules_group_has_new_commands():
    rules_cmd = cli.commands["rules"]
    assert "sync" in rules_cmd.commands
    assert "status" in rules_cmd.commands
    assert "list" in rules_cmd.commands
    assert "show" in rules_cmd.commands
    assert "doctor" in rules_cmd.commands
    assert "impact" in rules_cmd.commands


def test_platform_helpers():
    assert _platforms_for_filter("all") == ["ios", "android", "web", "common"]
    assert _platforms_for_filter("ios") == ["ios"]
    assert _platform_from_rule_id("IOS-PRIV-001") == "ios"
    assert _platform_from_rule_id("AND-SDK-001") == "android"
    assert _platform_from_rule_id("WEB-SEC-001") == "web"
    assert _platform_from_rule_id("CROSS-GDPR-001") == "common"
    assert _platform_from_rule_id("SUPPLY-DEP-001") == "common"
    assert _platform_from_rule_id("UNKNOWN-001") is None


def test_benchmark_group_commands():
    bench_cmd = cli.commands["benchmark"]
    assert "score" in bench_cmd.commands
    assert "template" in bench_cmd.commands
    assert "gate" in bench_cmd.commands
    assert "gate-config" in bench_cmd.commands


def test_suppress_group_commands():
    suppress_cmd = cli.commands["suppress"]
    assert "add" in suppress_cmd.commands
    assert "list" in suppress_cmd.commands


def test_top_level_engines_command_exists():
    assert "engines" in cli.commands
