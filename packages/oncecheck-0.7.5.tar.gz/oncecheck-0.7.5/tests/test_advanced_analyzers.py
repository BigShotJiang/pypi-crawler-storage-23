from __future__ import annotations

import pytest

from oncecheck.engine import advanced_analyzers as aa


def test_detected_languages(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "app.ts").write_text("const x = 1;")
    (tmp_path / "src" / "MainActivity.kt").write_text("class MainActivity")
    (tmp_path / "src" / "App.swift").write_text("import Foundation")

    langs = aa.detected_languages(tmp_path)
    assert "javascript" in langs
    assert "java" in langs
    assert "swift" in langs


def test_strict_mode_raises_when_no_engines(monkeypatch, tmp_path):
    monkeypatch.setattr(aa, "available_engines", lambda: {"semgrep": False, "codeql": False})
    with pytest.raises(RuntimeError, match="No advanced compiler-grade engine"):
        aa.run_advanced_analysis(tmp_path, strict=True)

