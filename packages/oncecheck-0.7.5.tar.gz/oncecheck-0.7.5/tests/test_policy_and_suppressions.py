from __future__ import annotations

from oncecheck.engine.suppressions import add_suppression, get_suppression_reasons, list_suppressions
from oncecheck.rules.policy_map import impacted_rules_for_sources, policy_clause_for_rule


def test_policy_clause_mapping():
    assert "OWASP Top 10" in policy_clause_for_rule("WEB-OWASP-003")
    assert "Google Play Permissions Policy" in policy_clause_for_rule("AND-PERM-001")
    assert policy_clause_for_rule("UNKNOWN-001") == ""


def test_impacted_rules_for_sources():
    rules = ["WEB-OWASP-003", "WEB-A11Y-001", "AND-PERM-001", "IOS-SEC-001"]
    impacted = impacted_rules_for_sources(["owasp_top_10", "w3c_wcag_21"], rules)
    assert "WEB-OWASP-003" in impacted
    assert "WEB-A11Y-001" in impacted


def test_suppressions_with_reasons(tmp_path):
    add_suppression(tmp_path, "web-owasp-003", "Accepted risk for legacy migration window")
    add_suppression(tmp_path, "AND-PERM-001", "Requires partner SDK until Q3")
    rules = list_suppressions(tmp_path)
    reasons = get_suppression_reasons(tmp_path)
    assert "WEB-OWASP-003" in rules
    assert "AND-PERM-001" in rules
    assert "WEB-OWASP-003" in reasons
    assert "reason" in reasons["WEB-OWASP-003"]
