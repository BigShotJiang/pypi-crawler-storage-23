"""Plan-based rule tier definitions.

Starter (free) plan includes ~35 of the most critical rules.
Team plan includes all 76 rules.
"""

from __future__ import annotations

# Rules included in the Starter (free) plan
STARTER_RULES: set[str] = {
    # iOS (8 of 22) — critical privacy, security, and metadata
    "IOS-PRIV-001",   # Missing NSCameraUsageDescription
    "IOS-PRIV-002",   # Missing NSPhotoLibraryUsageDescription
    "IOS-PRIV-003",   # Missing NSUserTrackingUsageDescription
    "IOS-SEC-001",    # ATS disabled globally
    "IOS-SEC-003",    # Hardcoded secrets
    "IOS-PRIV-007",   # Missing PrivacyInfo.xcprivacy
    "IOS-META-001",   # Missing app icons
    "IOS-META-002",   # Bundle identifier invalid

    # Android (10 of 19) — SDK, permissions, and security
    "AND-SDK-001",    # Target SDK below Play minimum
    "AND-PERM-001",   # Dangerous permissions
    "AND-PERM-002",   # Background location without foreground
    "AND-SEC-001",    # Debuggable build
    "AND-SEC-002",    # Cleartext traffic allowed
    "AND-SEC-005",    # ProGuard/R8 not enabled
    "AND-DATA-002",   # Hardcoded secrets
    "AND-POL-001",    # Ads SDK without disclosure
    "AND-POL-002",    # Analytics without privacy policy
    "AND-POL-003",    # Foreground service without type

    # Web (13 of 27) — headers, OWASP, a11y, privacy
    "WEB-SEC-001",    # Missing CSP
    "WEB-SEC-002",    # Missing HSTS
    "WEB-SEC-007",    # Hardcoded secrets
    "WEB-SEC-008",    # CORS wildcard
    "WEB-OWASP-001",  # Known vulnerabilities
    "WEB-OWASP-002",  # Unsafe eval()
    "WEB-OWASP-003",  # XSS vectors
    "WEB-OWASP-004",  # Insecure cookies
    "WEB-A11Y-001",   # Images missing alt text
    "WEB-A11Y-002",   # Missing keyboard navigation
    "WEB-A11Y-004",   # Form inputs missing labels
    "WEB-PRIV-001",   # Cookie banner missing
    "WEB-PRIV-002",   # No privacy policy

    # Common (4 of 8) — regulatory, supply chain
    "CROSS-COPPA-001",  # COPPA compliance
    "CROSS-PCI-001",    # PCI-DSS raw card handling
    "SUPPLY-LIC-001",   # GPL dependencies
    "SUPPLY-DEP-001",   # Outdated frameworks
}
