"""
JIT Compiler and kernel generation
"""

import sys
from pathlib import Path

# Permitir import desde directorio padre
parent_dir = Path(__file__).parent.parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Re-export desde z_compiler.py
from z_compiler import (
    initialize_jit_compiler,
    get_jit_compiler,
    get_execution_mode,
    print_compiler_status,
    print_execution_info,
)

__all__ = [
    'initialize_jit_compiler',
    'get_jit_compiler',
    'get_execution_mode',
    'print_compiler_status',
    'print_execution_info',
]
