"""
Neural network layers, attention, and optimizers
"""

import sys
from pathlib import Path

# Permitir import desde directorio padre
parent_dir = Path(__file__).parent.parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Re-export desde z_layers.py
from z_layers import (
    TransformerBlock,
    Embedding,
    PositionalEncoding,
    LayerNormalization,
    MultiHeadAttention,
    AdamW,
    SGD,
    RMSprop,
    SchedulerLinear,
    SchedulerCosine,
    Dropout,
)

__all__ = [
    'TransformerBlock',
    'Embedding',
    'PositionalEncoding',
    'LayerNormalization',
    'MultiHeadAttention',
    'AdamW',
    'SGD',
    'RMSprop',
    'SchedulerLinear',
    'SchedulerCosine',
    'Dropout',
]
