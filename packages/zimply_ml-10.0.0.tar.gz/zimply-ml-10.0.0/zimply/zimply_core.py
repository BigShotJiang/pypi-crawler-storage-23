"""
Main ZIMPLY model and configuration
"""

import sys
from pathlib import Path

# Permitir import desde directorio padre goas
parent_dir = Path(__file__).parent.parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Re-export desde zimply.py (in parent directory)
try:
    # Try importing from parent directory (goas/)
    from zimply import ZIMPLY, ZIMPLYConfig
except ImportError:
    # Fallback: import específico del módulo
    import sys
    import importlib.util
    spec = importlib.util.spec_from_file_location("zimply_module", str(parent_dir / "zimply.py"))
    if spec and spec.loader:
        zimply_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(zimply_module)
        ZIMPLY = zimply_module.ZIMPLY
        ZIMPLYConfig = zimply_module.ZIMPLYConfig

__all__ = [
    'ZIMPLY',
    'ZIMPLYConfig',
]
