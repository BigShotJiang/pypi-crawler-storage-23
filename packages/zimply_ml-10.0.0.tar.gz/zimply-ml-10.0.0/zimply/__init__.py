"""
ZIMPLY v10.0 Pro - Machine Learning Framework
=============================================

A high-performance, modular ML framework with automatic JIT compilation,
zero-copy data pipelines, and seamless GPU/CPU portability.

Usage:
    from zimply import ZIMPLY, ZIMPLYConfig
    from zimply.data import create_dataloader
    
    config = ZIMPLYConfig(vocab_size=50000, embedding_dim=768)
    model = ZIMPLY(config=config)
    
    loader = create_dataloader('data.txt', vocab_path='vocab')
    for batch in loader:
        output = model(batch)
"""

__version__ = "10.0.0"
__author__ = "ZIMPLY Development Team"
__license__ = "ZIMPLY No-Modification License"

# Core imports - expose main API
from zimply.zimply_core import (
    ZIMPLY,
    ZIMPLYConfig,
)

from zimply.tensor import (
    Tensor,
    Device,
    DType,
    cross_entropy_loss,
    mse_loss,
)

from zimply.layers import (
    TransformerBlock,
    Embedding,
    PositionalEncoding,
    LayerNormalization,
    MultiHeadAttention,
    AdamW,
    SGD,
    RMSprop,
    SchedulerLinear,
    SchedulerCosine,
    Dropout,
)

from zimply.data import (
    BPETokenizer,
    DataLoader,
    AsyncDataLoader,
    ZeroCopyBPETokenizer,
    MemoryMappedReader,
    VocabularyManager,
    DataLoaderConfig,
    create_dataloader,
)

from zimply.compiler import (
    initialize_jit_compiler,
    get_jit_compiler,
    get_execution_mode,
    print_compiler_status,
    print_execution_info,
)

__all__ = [
    # Main API
    'ZIMPLY',
    'ZIMPLYConfig',
    
    # Tensor operations
    'Tensor',
    'Device',
    'DType',
    'cross_entropy_loss',
    'mse_loss',
    
    # Layers
    'TransformerBlock',
    'Embedding',
    'PositionalEncoding',
    'LayerNormalization',
    'MultiHeadAttention',
    'AdamW',
    'SGD',
    'RMSprop',
    'SchedulerLinear',
    'SchedulerCosine',
    'Dropout',
    
    # Data
    'BPETokenizer',
    'DataLoader',
    'AsyncDataLoader',
    'ZeroCopyBPETokenizer',
    'MemoryMappedReader',
    'VocabularyManager',
    'DataLoaderConfig',
    'create_dataloader',
    
    # Compiler
    'initialize_jit_compiler',
    'get_jit_compiler',
    'get_execution_mode',
    'print_compiler_status',
    'print_execution_info',
]
