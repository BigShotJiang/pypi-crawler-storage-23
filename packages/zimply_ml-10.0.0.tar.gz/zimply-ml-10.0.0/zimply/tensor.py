"""
Tensor operations and autograd engine
"""

import sys
from pathlib import Path

# Permitir import desde directorio padre (para desarrollo)
parent_dir = Path(__file__).parent.parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Re-export desde z_tensor.py
from z_tensor import (
    Tensor,
    Device,
    DType,
    cross_entropy_loss,
    mse_loss,
)

__all__ = [
    'Tensor',
    'Device',
    'DType',
    'cross_entropy_loss',
    'mse_loss',
]
