"""
Setup configuration for ZIMPLY package
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="zimply-ml",
    version="10.0.0",
    author="ZIMPLY Development Team",
    author_email="info@zimply.ai",
    description="High-performance ML framework with automatic JIT compilation and zero-copy data pipelines",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://zimply.ai",
    project_urls={
        "Documentation": "https://zimply.readthedocs.io",
        "Contact": "info@zimply.ai",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
            "mypy>=0.950",
        ],
        "cuda": [
            "torch>=2.0.0",
        ],
    },
    include_package_data=True,
    keywords="machine-learning deep-learning neural-networks jit-compiler gpu-computing",
    zip_safe=False,
)
