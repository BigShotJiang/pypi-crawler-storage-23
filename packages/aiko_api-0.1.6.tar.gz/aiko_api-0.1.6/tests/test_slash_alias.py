"""
Quick test to verify bot.slash works as expected.
"""

import asyncio
from aiko_api import Bot

# Create bot
bot = Bot(command_prefix="!", bot=True)

# Test that both syntaxes work
print("Testing bot.slash_commands vs bot.slash...")

# Test 1: bot.slash_commands (original)
try:
    print(f"bot.slash_commands: {type(bot.slash_commands)}")
    print(f"Has register_commands: {hasattr(bot.slash_commands, 'register_commands')}")
    print(f"Has component_handler: {hasattr(bot.slash_commands, 'component_handler')}")
    print("✅ bot.slash_commands works!")
except Exception as e:
    print(f"❌ bot.slash_commands failed: {e}")

# Test 2: bot.slash (new alias)
try:
    print(f"bot.slash: {type(bot.slash)}")
    print(f"Has register_commands: {hasattr(bot.slash, 'register_commands')}")
    print(f"Has component_handler: {hasattr(bot.slash, 'component_handler')}")
    print("✅ bot.slash works!")
except Exception as e:
    print(f"❌ bot.slash failed: {e}")

# Test 3: Are they the same object?
try:
    same_object = bot.slash_commands is bot.slash
    print(f"Same object: {same_object}")
    if same_object:
        print("✅ bot.slash is an alias to bot.slash_commands!")
    else:
        print("❌ bot.slash is not the same as bot.slash_commands")
except Exception as e:
    print(f"❌ Comparison failed: {e}")

print("\n🎯 Test complete! You can now use either:")
print("   bot.slash_commands.register_commands()")
print("   OR")
print("   bot.slash.register_commands()")
