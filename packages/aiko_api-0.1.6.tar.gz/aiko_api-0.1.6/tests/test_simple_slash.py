"""
Quick test of the simplified slash commands API.
"""

import asyncio
from aiko_api.simple_slash import button, row
from aiko_api.components_simple import ButtonBuilder


def test_simple_button():
    """Test the ultra-simple button creation."""
    print("Testing simple button creation...")

    # Test different button styles
    primary_btn = button("Click me", "test_btn", style="primary")
    assert primary_btn.style == 1
    assert primary_btn.label == "Click me"
    assert primary_btn.custom_id == "test_btn"

    danger_btn = button("Delete", "delete_btn", style="danger")
    assert danger_btn.style == 4
    assert danger_btn.label == "Delete"

    link_btn = button("Visit", "https://example.com", style="link")
    assert link_btn.style == 5
    assert link_btn.url == "https://example.com"

    print("✅ Button creation works!")


def test_row_creation():
    """Test simple row creation."""
    print("Testing row creation...")

    btn1 = button("Button 1", "btn1")
    btn2 = button("Button 2", "btn2")

    row_component = row(btn1, btn2)
    assert len(row_component.components) == 2

    print("✅ Row creation works!")


def test_standalone_builders():
    """Test the standalone builder functions."""
    print("Testing standalone builders...")

    # Test ButtonBuilder static methods
    primary = ButtonBuilder.primary("Primary", "prim")
    assert primary.style == 1

    success = ButtonBuilder.success("Success", "succ")
    assert success.style == 3

    print("✅ Standalone builders work!")


if __name__ == "__main__":
    test_simple_button()
    test_row_creation()
    test_standalone_builders()
    print("🎉 All tests passed! The simplified API is working correctly.")
