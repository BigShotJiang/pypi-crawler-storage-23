# Aiko API 🎯

**Ultra-simple Discord bot development with direct `button()` and `row()` functions.**

```python
from aiko_api import Bot, button, row

bot = Bot(command_prefix="!")

@bot.slash()
async def hello(ctx):
    btn = button("Click me!", "btn", style="success")
    await ctx.respond("Hello!", components=[row(btn)])

bot.run("YOUR_TOKEN")
```

## 🚀 Quick Start

```bash
pip install aiko-api
```

```python
from aiko_api import Bot, button, row

bot = Bot(command_prefix="!")

@bot.slash()
async def hello(ctx):
    my_btn = button("Click me!", "btn", style="success")
    await ctx.respond("Hello!", components=[row(my_btn)])

bot.run("YOUR_TOKEN")
```

## ✨ Features

- ⚡ **Direct `button()` and `row()` functions** - no complex builders
- 🎯 **Ultra-simple syntax** - minimal code, maximum functionality  
- 📝 **Clean decorators** - `@bot.slash()`, `@bot.slash.on_click()`
- 🔄 **Full asyncio support** - modern async/await
- 🚀 **Zero boilerplate** - get started in seconds
- 📦 **Lightweight** - only what you need

## 🎯 Why Aiko API?

### Before (Other Libraries)
```python
# Complex, verbose syntax
button = Button(
    style=ButtonStyle.SUCCESS,
    label="Click me!",
    custom_id="btn"
)
row = ActionRow(components=[button])
```

### After (Aiko API)
```python
# Ultra-simple, intuitive
btn = button("Click me!", "btn", style="success")
row = row(btn)
```

## 📚 Examples

### Basic Button
```python
@bot.slash()
async def basic(ctx):
    btn = button("Click me!", "btn", style="success")
    await ctx.respond("Hello!", components=[row(btn)])

@bot.slash.on_click("btn")
async def handle_click(ctx):
    await ctx.respond("Clicked! 🎉")
```

### Multiple Buttons
```python
@bot.slash()
async def colors(ctx):
    red = button("Red", "red", style="danger")
    blue = button("Blue", "blue", style="primary")
    await ctx.respond("Pick:", components=[row(red, blue)])
```

### Embed + Buttons
```python
@bot.slash()
async def dashboard(ctx):
    from aiko_api.common.models import Embed
    
    embed = Embed(title="Dashboard", color=0x00ff00)
    play_btn = button("Play", "play", style="success")
    
    await ctx.respond(embed=embed, components=[row(play_btn)])
```

## 🎯 Direct Functions

The magic is in the direct functions:

```python
from aiko_api import button, row

# Create buttons anywhere - no bot needed!
btn1 = button("Primary", "btn1", style="primary")
btn2 = button("Danger", "btn2", style="danger")
my_row = row(btn1, btn2)
```

## 📖 Documentation

- [Basic Examples](examples/basic/) - Simple usage patterns
- [Advanced Examples](examples/advanced/) - Complex features  
- [Demos](examples/demos/) - Interactive demonstrations

## 🛠️ Installation

```bash
pip install aiko-api
```

## 🔧 Requirements

- Python 3.8+
- asyncio
- curl_cffi

## 📄 License

MIT License - see LICENSE file for details.

## 🎯 Mission

Make Discord bot development **ultra-simple** while maintaining full functionality. 
No complex builders, no verbose syntax - just direct, intuitive functions that work!

---

**Aiko API** - Discord bots made simple 🎯