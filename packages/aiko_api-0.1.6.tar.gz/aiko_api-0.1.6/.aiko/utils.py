import base64
import json
import sys

import re
import requests
from .katlog import get_logger

log = get_logger("aiko_api", level="DEBUG")

def get_build_number():
    """Fetches the latest Discord client build number."""
    try:
        page = requests.get("https://discord.com/app", timeout=10).text
        assets = re.findall(r'src="/assets/([^"]+)"', page)
        
        for asset in reversed(assets):
            js = requests.get(f"https://discord.com/assets/{asset}", timeout=10).text
            if "buildNumber:" in js:
                return int(js.split('buildNumber:"')[1].split('"')[0])
    except Exception as e:
        log.error(f"Failed to fetch build number: {e}")
        return 254000 # Fallback

def get_super_properties():
    """Generates a valid X-Super-Properties header value."""
    build_num = get_build_number()
    properties = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en-US",
        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "browser_version": "120.0.0.0",
        "os_version": "10",
        "referrer": "",
        "referring_domain": "",
        "referrer_current": "",
        "referring_domain_current": "",
        "release_channel": "stable",
        "client_build_number": build_num,
        "client_event_source": None
    }
    
    return base64.b64encode(json.dumps(properties).encode()).decode('utf-8')

def get_user_agent():
    return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
