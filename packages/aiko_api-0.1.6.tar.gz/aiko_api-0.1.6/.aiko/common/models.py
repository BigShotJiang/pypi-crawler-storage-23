# aiko_api/common/models.py
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import datetime

@dataclass(kw_only=True)
class Base:
    _state: Any = field(default=None, repr=False, compare=False)

@dataclass
class Snowflake(Base):
    id: str

    @property
    def created_at(self):
        timestamp = ((int(self.id) >> 22) + 1420070400000) / 1000
        return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc)

@dataclass
class User(Snowflake):
    username: str
    discriminator: str
    avatar: Optional[str]
    bot: bool = False
    
    @property
    def mention(self):
        return f"<@{self.id}>"
    
    def __str__(self):
        return self.mention
    
    @property
    def display_name(self):
        return self.username

    async def send(self, content, **kwargs):
        if self._state:
            dm = await self._state.user.create_dm(self.id)
            return await self._state.messages.send(dm['id'], content, **kwargs)
        raise NotImplementedError("State not initialized")

@dataclass
class Member(User):
    nick: Optional[str] = None
    roles: List[str] = field(default_factory=list)
    joined_at: Optional[str] = None
    
    @property
    def display_name(self):
        return self.nick if self.nick else self.username

@dataclass
class Guild(Snowflake):
    name: str
    icon: Optional[str]
    owner_id: str
    roles: Dict[str, Any] = field(default_factory=dict)
    members: Dict[str, Member] = field(default_factory=dict)
    channels: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Channel(Snowflake):
    name: str
    type: int
    guild_id: Optional[str] = None

    @property
    def mention(self):
        return f"<#{self.id}>"
    
    def __str__(self):
        return self.mention

    async def send(self, content, **kwargs):
        if self._state:
            return await self._state.messages.send(self.id, content, **kwargs)

@dataclass
class Attachment(Snowflake):
    filename: str
    url: str
    proxy_url: str
    size: int
    height: Optional[int] = None
    width: Optional[int] = None
    content_type: Optional[str] = None
    ephemeral: bool = False

    @property
    def is_image(self):
        if self.content_type:
            return self.content_type.startswith("image/")
        return any(self.filename.lower().endswith(ext) for ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"))

@dataclass
class Embed:
    title: Optional[str] = None
    type: str = "rich"
    description: Optional[str] = None
    url: Optional[str] = None
    timestamp: Optional[str] = None
    color: Optional[int] = None
    footer: Optional[Dict[str, Any]] = None
    image: Optional[Dict[str, Any]] = None
    thumbnail: Optional[Dict[str, Any]] = None
    video: Optional[Dict[str, Any]] = None
    provider: Optional[Dict[str, Any]] = None
    author: Optional[Dict[str, Any]] = None
    fields: List[Dict[str, Any]] = field(default_factory=list)

@dataclass
class Message(Snowflake):
    channel_id: str
    guild_id: Optional[str]
    author: User
    content: str
    timestamp: str
    tts: bool
    mention_everyone: bool
    attachments: List[Attachment] = field(default_factory=list)
    embeds: List[Embed] = field(default_factory=list)
    reactions: List[Any] = field(default_factory=list)

    @property
    def image_url(self) -> Optional[str]:
        """Returns the first image URL found in attachments or embeds."""
        for attachment in self.attachments:
            if attachment.is_image:
                return attachment.url
        for embed in self.embeds:
            if embed.image:
                return embed.image.get("url")
            if embed.thumbnail:
                return embed.thumbnail.get("url")
        return None

    @property
    def gif_url(self) -> Optional[str]:
        """Returns the first GIF URL found in attachments or embeds."""
        for attachment in self.attachments:
            if attachment.filename.lower().endswith(".gif") or (attachment.content_type == "image/gif"):
                return attachment.url
        for embed in self.embeds:
            if embed.url and embed.url.lower().endswith(".gif"):
                return embed.url
            if embed.image and embed.image.get("url", "").lower().endswith(".gif"):
                return embed.image.get("url")
        return None

    async def reply(self, content, **kwargs):
        if self._state:
            return await self._state.messages.reply(self.channel_id, self.id, content, **kwargs)

    async def delete(self):
        if self._state:
            return await self._state.messages.delete(self.channel_id, self.id)

    async def edit(self, content, **kwargs):
        if self._state:
            return await self._state.messages.edit(self.channel_id, self.id, content, **kwargs)

    async def add_reaction(self, emoji):
        if self._state:
            await self._state.messages.add_reaction(self.channel_id, self.id, emoji)

@dataclass(kw_only=True)
class Activity:
    name: str
    type: int = 0
    url: Optional[str] = None
    state: Optional[str] = None
    details: Optional[str] = None
    application_id: Optional[str] = None
    timestamps: Optional[Dict[str, int]] = None
    assets: Optional[Dict[str, str]] = None
    party: Optional[Dict[str, Any]] = None
    buttons: Optional[List[str]] = None

    def to_dict(self):
        data = {"name": self.name, "type": self.type}
        for attr in ("url", "state", "details", "application_id", "timestamps", "assets", "party", "buttons"):
            val = getattr(self, attr)
            if val is not None:
                data[attr] = val
        return data
