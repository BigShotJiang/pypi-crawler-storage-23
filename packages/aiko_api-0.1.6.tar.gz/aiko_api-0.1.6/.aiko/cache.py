from typing import Dict, Optional, Any, Deque, List
from collections import deque
from .common.models import User, Guild, Message, Channel, Member, Attachment, Embed

class Cache:
    def __init__(self, client):
        self.client = client
        self.users: Dict[str, User] = {}
        self.guilds: Dict[str, Guild] = {}
        self.channels: Dict[str, Channel] = {}
        self.messages: Deque[Message] = deque(maxlen=1000)
        
    def store_user(self, data: Dict[str, Any]) -> User:
        user_id = data['id']
        if user_id in self.users:
            user = self.users[user_id]
            user.username = data.get('username', user.username)
            user.discriminator = data.get('discriminator', user.discriminator)
            user.avatar = data.get('avatar', user.avatar)
            return user

        user = User(
            id=user_id,
            username=data['username'],
            discriminator=data.get('discriminator', '0000'),
            avatar=data.get('avatar'),
            bot=data.get('bot', False),
            _state=self.client
        )
        self.users[user.id] = user
        return user

    def get_user(self, user_id: str) -> Optional[User]:
        return self.users.get(user_id)

    def store_member(self, guild_id: str, data: Dict[str, Any]) -> Member:
        user_data = data.get('user')
        if not user_data:
            user_data = data
            
        user = self.store_user(user_data)
        member = Member(
            id=user.id,
            username=user.username,
            discriminator=user.discriminator,
            avatar=user.avatar,
            bot=user.bot,
            nick=data.get('nick'),
            roles=data.get('roles', []),
            joined_at=data.get('joined_at'),
            _state=self.client
        )
        
        guild = self.get_guild(guild_id)
        if guild:
            guild.members[member.id] = member
            
        return member

    def store_guild(self, data: Dict[str, Any]) -> Guild:
        guild_id = data['id']
        guild = self.guilds.get(guild_id)
        
        if not guild:
            guild = Guild(
                id=guild_id,
                name=data['name'],
                icon=data.get('icon'),
                owner_id=data.get('owner_id', ''),
                _state=self.client
            )
            self.guilds[guild.id] = guild

        guild.name = data.get('name', guild.name)
        guild.icon = data.get('icon', guild.icon)
        guild.owner_id = data.get('owner_id', guild.owner_id)

        for channel_data in data.get('channels', []):
            channel_data['guild_id'] = guild_id
            self.store_channel(channel_data)

        for member_data in data.get('members', []):
            self.store_member(guild_id, member_data)

        return guild

    def get_guild(self, guild_id: str) -> Optional[Guild]:
        return self.guilds.get(guild_id)

    def store_channel(self, data: Dict[str, Any]) -> Channel:
        channel_id = data['id']
        channel = Channel(
            id=channel_id,
            name=data.get('name', 'unknown'),
            type=data.get('type', 0),
            guild_id=data.get('guild_id'),
            _state=self.client
        )
        self.channels[channel.id] = channel
        
        if channel.guild_id:
            guild = self.get_guild(channel.guild_id)
            if guild:
                guild.channels[channel.id] = channel
                
        return channel

    def get_channel(self, channel_id: str) -> Optional[Channel]:
        return self.channels.get(channel_id)

    def store_message(self, data: Dict[str, Any]) -> Message:
        author_data = data.get('author')
        author = self.store_user(author_data) if author_data else None

        attachments = []
        for a_data in data.get('attachments', []):
            attachments.append(Attachment(
                id=a_data['id'],
                filename=a_data['filename'],
                url=a_data['url'],
                proxy_url=a_data['proxy_url'],
                size=a_data['size'],
                height=a_data.get('height'),
                width=a_data.get('width'),
                content_type=a_data.get('content_type'),
                ephemeral=a_data.get('ephemeral', False),
                _state=self.client
            ))

        embeds = []
        for e_data in data.get('embeds', []):
            embeds.append(Embed(
                title=e_data.get('title'),
                type=e_data.get('type', 'rich'),
                description=e_data.get('description'),
                url=e_data.get('url'),
                timestamp=e_data.get('timestamp'),
                color=e_data.get('color'),
                footer=e_data.get('footer'),
                image=e_data.get('image'),
                thumbnail=e_data.get('thumbnail'),
                video=e_data.get('video'),
                provider=e_data.get('provider'),
                author=e_data.get('author'),
                fields=e_data.get('fields', [])
            ))

        message = Message(
            id=data['id'],
            channel_id=data['channel_id'],
            guild_id=data.get('guild_id'),
            author=author,
            content=data.get('content', ''),
            timestamp=data['timestamp'],
            tts=data.get('tts', False),
            mention_everyone=data.get('mention_everyone', False),
            attachments=attachments,
            embeds=embeds,
            reactions=data.get('reactions', []),
            _state=self.client
        )
        self.messages.append(message)
        return message
        
    def clear(self):
        self.users.clear()
        self.guilds.clear()
        self.channels.clear()
        self.messages.clear()
