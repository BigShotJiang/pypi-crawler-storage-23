"""
Aiko API - Ultra-simple Discord Bot Development

The most intuitive Discord API wrapper with ultra-simple syntax:
- ⚡ Direct button() and row() functions
- 🎯 One-line component creation
- 📝 Clean slash command decorators
- 🔄 Asyncio-first design
- 🚀 Zero boilerplate

Example:
    from aiko_api import Bot, button, row

    bot = Bot(command_prefix="!")

    @bot.slash()
    async def hello(ctx):
        btn = button("Click me!", "btn", style="success")
        await ctx.respond("Hello!", components=[row(btn)])

    bot.run("YOUR_TOKEN")
"""

from typing import TYPE_CHECKING

__title__ = "aiko_api"
__author__ = "Aiko"
__license__ = "MIT"
__version__ = "0.3.0"
__description__ = "Ultra-simple Discord API wrapper"

# Core functionality - what 90% of users need
from .client import Client
from .commands import Bot, Context, Command, Cog, command, cog
from .common.models import (
    # Essential models
    User,
    Member,
    Guild,
    Channel,
    Role,
    Message,
    Embed,
    # Components
    Button,
    ActionRow,
    SelectMenu,
    TextInput,
    Modal,
    # Enums
    ChannelType,
    ComponentType,
    ButtonStyle,
    TextInputStyle,
)

# Ultra-simple API - the magic!
from .simple_api import button, row

# Utilities
from .common.constants import ActivityType, OpCode
from .katlog import get_logger

# Advanced features (optional)
from .slash_commands_v2 import (
    SlashContext,
    ComponentContext,
    ModalContext,
)
from .common.interactions import (
    ApplicationCommand,
    ApplicationCommandType,
    Interaction,
    InteractionType,
    InteractionResponse,
)

__all__ = [
    # Core - essential for basic usage
    "Bot",
    "Client",
    "Context",
    "Command",
    "Cog",
    "command",
    "cog",
    # Essential models
    "User",
    "Member",
    "Guild",
    "Channel",
    "Role",
    "Message",
    "Embed",
    "Button",
    "ActionRow",
    "SelectMenu",
    "TextInput",
    "Modal",
    # Ultra-simple API - the magic!
    "button",  # button("Label", "id", style="success")
    "row",  # row(btn1, btn2, btn3)
    # Utilities
    "get_logger",
    "ActivityType",
    "OpCode",
    # Enums
    "ChannelType",
    "ComponentType",
    "ButtonStyle",
    "TextInputStyle",
    # Advanced (optional)
    "ApplicationCommand",
    "Interaction",
    "SlashContext",
    "ComponentContext",
    "ModalContext",
]
