# aiko_api/core/interactions.py
from typing import Any, Dict, List, Optional
from .http import HTTPClient
from ..common.interactions import (
    ApplicationCommand,
    InteractionResponse,
)


class InteractionHTTP(HTTPClient):
    """HTTP methods for Discord Interactions and Application Commands."""

    async def create_interaction_response(
        self, interaction_id: str, token: str, response: InteractionResponse
    ):
        """Create a response to an interaction."""
        endpoint = f"/interactions/{interaction_id}/{token}/callback"
        data = {"type": response.type}
        if response.data:
            data["data"] = response.data
        return await self.post(endpoint, json=data)

    async def get_original_interaction_response(self, application_id: str, token: str):
        """Get the original interaction response."""
        endpoint = f"/webhooks/{application_id}/{token}/messages/@original"
        return await self.get(endpoint)

    async def edit_original_interaction_response(
        self, application_id: str, token: str, **kwargs
    ):
        """Edit the original interaction response."""
        endpoint = f"/webhooks/{application_id}/{token}/messages/@original"
        return await self.patch(endpoint, **kwargs)

    async def delete_original_interaction_response(
        self, application_id: str, token: str
    ):
        """Delete the original interaction response."""
        endpoint = f"/webhooks/{application_id}/{token}/messages/@original"
        return await self.delete(endpoint)

    async def create_followup_message(self, application_id: str, token: str, **kwargs):
        """Create a followup message for an interaction."""
        endpoint = f"/webhooks/{application_id}/{token}"
        return await self.post(endpoint, **kwargs)

    async def edit_followup_message(
        self, application_id: str, token: str, message_id: str, **kwargs
    ):
        """Edit a followup message."""
        endpoint = f"/webhooks/{application_id}/{token}/messages/{message_id}"
        return await self.patch(endpoint, **kwargs)

    async def delete_followup_message(
        self, application_id: str, token: str, message_id: str
    ):
        """Delete a followup message."""
        endpoint = f"/webhooks/{application_id}/{token}/messages/{message_id}"
        return await self.delete(endpoint)

    # Application Commands
    async def get_global_application_commands(self, application_id: str):
        """Get all global application commands."""
        endpoint = f"/applications/{application_id}/commands"
        return await self.get(endpoint)

    async def create_global_application_command(
        self, application_id: str, command: ApplicationCommand
    ):
        """Create a global application command."""
        endpoint = f"/applications/{application_id}/commands"
        return await self.post(endpoint, json=command.__dict__)

    async def get_global_application_command(
        self, application_id: str, command_id: str
    ):
        """Get a global application command."""
        endpoint = f"/applications/{application_id}/commands/{command_id}"
        return await self.get(endpoint)

    async def edit_global_application_command(
        self, application_id: str, command_id: str, command: ApplicationCommand
    ):
        """Edit a global application command."""
        endpoint = f"/applications/{application_id}/commands/{command_id}"
        return await self.patch(endpoint, json=command.__dict__)

    async def delete_global_application_command(
        self, application_id: str, command_id: str
    ):
        """Delete a global application command."""
        endpoint = f"/applications/{application_id}/commands/{command_id}"
        return await self.delete(endpoint)

    async def bulk_overwrite_global_application_commands(
        self, application_id: str, commands: List[ApplicationCommand]
    ):
        """Bulk overwrite global application commands."""
        endpoint = f"/applications/{application_id}/commands"
        commands_data = [cmd.__dict__ for cmd in commands]
        return await self.put(endpoint, json=commands_data)

    # Guild Application Commands
    async def get_guild_application_commands(self, application_id: str, guild_id: str):
        """Get all guild application commands."""
        endpoint = f"/applications/{application_id}/guilds/{guild_id}/commands"
        return await self.get(endpoint)

    async def create_guild_application_command(
        self, application_id: str, guild_id: str, command: ApplicationCommand
    ):
        """Create a guild application command."""
        endpoint = f"/applications/{application_id}/guilds/{guild_id}/commands"
        return await self.post(endpoint, json=command.__dict__)

    async def get_guild_application_command(
        self, application_id: str, guild_id: str, command_id: str
    ):
        """Get a guild application command."""
        endpoint = (
            f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.get(endpoint)

    async def edit_guild_application_command(
        self,
        application_id: str,
        guild_id: str,
        command_id: str,
        command: ApplicationCommand,
    ):
        """Edit a guild application command."""
        endpoint = (
            f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.patch(endpoint, json=command.__dict__)

    async def delete_guild_application_command(
        self, application_id: str, guild_id: str, command_id: str
    ):
        """Delete a guild application command."""
        endpoint = (
            f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.delete(endpoint)

    async def bulk_overwrite_guild_application_commands(
        self, application_id: str, guild_id: str, commands: List[ApplicationCommand]
    ):
        """Bulk overwrite guild application commands."""
        endpoint = f"/applications/{application_id}/guilds/{guild_id}/commands"
        commands_data = [cmd.__dict__ for cmd in commands]
        return await self.put(endpoint, json=commands_data)

    # Application Command Permissions
    async def get_guild_application_command_permissions(
        self, application_id: str, guild_id: str
    ):
        """Get guild application command permissions."""
        endpoint = (
            f"/applications/{application_id}/guilds/{guild_id}/commands/permissions"
        )
        return await self.get(endpoint)

    async def get_application_command_permissions(
        self, application_id: str, guild_id: str, command_id: str
    ):
        """Get application command permissions."""
        endpoint = f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}/permissions"
        return await self.get(endpoint)

    async def edit_application_command_permissions(
        self,
        application_id: str,
        guild_id: str,
        command_id: str,
        permissions: Dict[str, Any],
    ):
        """Edit application command permissions."""
        endpoint = f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}/permissions"
        return await self.put(endpoint, json=permissions)

    # Application Role Connection Metadata
    async def get_application_role_connection_metadata_records(
        self, application_id: str
    ):
        """Get application role connection metadata records."""
        endpoint = f"/applications/{application_id}/role-connections/metadata"
        return await self.get(endpoint)

    async def update_application_role_connection_metadata_records(
        self, application_id: str, records: List[Dict[str, Any]]
    ):
        """Update application role connection metadata records."""
        endpoint = f"/applications/{application_id}/role-connections/metadata"
        return await self.put(endpoint, json=records)

    # Application Information
    async def get_application_info(self):
        """Get current application info."""
        endpoint = "/oauth2/applications/@me"
        return await self.get(endpoint)
