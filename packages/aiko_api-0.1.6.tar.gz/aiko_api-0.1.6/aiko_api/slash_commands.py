# aiko_api/slash_commands.py
import asyncio
import inspect
from typing import Any, Callable, Dict, List, Optional, Union, TYPE_CHECKING
from dataclasses import dataclass

from .katlog import get_logger
from .client import Client
from .common.models import Message, User
from .common.interactions import (
    ApplicationCommand,
    ApplicationCommandType,
    ApplicationCommandOption,
    ApplicationCommandOptionType,
    Interaction,
    InteractionType,
    InteractionResponse,
    InteractionResponseType,
    InteractionApplicationCommandCallbackData,
)

if TYPE_CHECKING:
    from .client import Client

log = get_logger("aiko_api", level="DEBUG")


class SlashContext:
    def __init__(self, interaction: Interaction, bot: "Client") -> None:
        self.interaction: Interaction = interaction
        self.bot: "Client" = bot
        self.author: User = interaction.author
        self.channel_id: str = interaction.channel_id
        self.guild_id: Optional[str] = interaction.guild_id
        self.token: str = interaction.token
        self.id: str = interaction.id
        self.command_name: Optional[str] = (
            interaction.data.name if interaction.data else None
        )
        self.options: Dict[str, Any] = self._parse_options(
            interaction.data.options if interaction.data else []
        )
        self.responded: bool = False
        self.deferred: bool = False

    def _parse_options(self, options: List[Any]) -> Dict[str, Any]:
        """Parse interaction options into a dictionary."""
        result: Dict[str, Any] = {}
        for option in options:
            # Handle different option structures
            if hasattr(option, "type"):
                if option.type == ApplicationCommandOptionType.SUB_COMMAND:
                    result[option.name] = self._parse_options(option.options)
                elif option.type == ApplicationCommandOptionType.SUB_COMMAND_GROUP:
                    result[option.name] = self._parse_options(option.options)
                else:
                    result[option.name] = option.value
            else:
                # Handle raw dict format from Discord
                if isinstance(option, dict):
                    result[option["name"]] = option.get("value")
                else:
                    result[option.name] = getattr(option, "value", None)
        return result

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        tts: bool = False,
        ephemeral: bool = False,
        components: Optional[List[Any]] = None,
        files: Optional[List[Any]] = None,
    ) -> None:
        """Respond to the interaction."""
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if content is not None:
            data["content"] = str(content)

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        if tts:
            data["tts"] = True

        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        if components:
            data["components"] = components

        if files:
            # Handle file uploads - would need multipart form data
            log.warning("File uploads not yet implemented for slash commands")

        response = InteractionResponse(
            type=InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data=data
        )

        await self.bot.http.create_interaction_response(self.id, self.token, response)
        self.responded = True

    async def defer(self, *, ephemeral: bool = False) -> None:
        """Defer the interaction response."""
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        response = InteractionResponse(
            type=InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data=data
        )

        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True
        self.deferred = True

    async def send_followup(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        tts: bool = False,
        ephemeral: bool = False,
        components: Optional[List[Any]] = None,
        files: Optional[List[Any]] = None,
    ) -> None:
        """Send a followup message after the initial response."""
        if not self.responded:
            raise RuntimeError(
                "Must respond to interaction first before sending followups"
            )

        data: Dict[str, Any] = {}
        if content is not None:
            data["content"] = str(content)

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        if tts:
            data["tts"] = True

        if ephemeral:
            data["flags"] = 64

        if components:
            data["components"] = components

        if files:
            log.warning("File uploads not yet implemented for slash command followups")

        # Get application ID if not available
        if not hasattr(self.bot, "application_id"):
            app_info = await self.bot.http.get_application_info()
            self.bot.application_id = app_info["id"]

        await self.bot.http.create_followup_message(
            self.bot.application_id, self.token, json=data
        )

    async def send(self, content: Optional[str] = None, **kwargs: Any) -> Any:
        """Alias for respond - just works!"""
        return await self.respond(content, **kwargs)

    async def reply(self, content: Optional[str] = None, **kwargs: Any) -> Any:
        """Reply to the interaction - another alias."""
        return await self.respond(content, **kwargs)

    async def thinking(self, *, ephemeral: bool = False) -> Any:
        """Show thinking state (alias for defer)."""
        return await self.defer(ephemeral=ephemeral)

    async def delete_response(self) -> None:
        """Delete the original response - cleanup made easy!"""
        if not self.responded:
            raise RuntimeError("Cannot delete response that hasn't been sent")

        if not hasattr(self.bot, "application_id"):
            app_info = await self.bot.http.get_application_info()
            self.bot.application_id = app_info["id"]

        await self.bot.http.delete_original_interaction_response(
            self.bot.application_id, self.token
        )

    async def send(self, content: Optional[str] = None, **kwargs: Any) -> Any:
        """Alias for respond."""
        if self.responded:
            return await self.send_followup(content, **kwargs)
        return await self.respond(content, **kwargs)

    def get_option(self, name: str, default: Any = None) -> Any:
        """Get an option value by name - simple and easy!"""
        return self.options.get(name, default)


class SlashCommand:
    def __init__(
        self,
        func: Callable,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        guild_ids: Optional[List[str]] = None,
    ) -> None:
        self.func: Callable = func
        self.name: str = name or func.__name__
        self.description: str = (
            description or inspect.getdoc(func) or "No description provided"
        )
        self.guild_ids: List[str] = guild_ids or []
        self.options: List[ApplicationCommandOption] = []
        self._parse_signature()

    def _parse_signature(self) -> None:
        """Parse function signature to create command options."""
        sig = inspect.signature(self.func)
        params: List[Any] = list(sig.parameters.values())

        # Skip 'self' and 'ctx' parameters
        if params and params[0].name == "self":
            params = params[1:]
        if params and params[0].name in ("ctx", "context"):
            params = params[1:]

        for param in params:
            option_type: int = self._get_option_type(param.annotation, param.default)
            required: bool = param.default == inspect.Parameter.empty

            option = ApplicationCommandOption(
                type=option_type,
                name=param.name,
                description=f"The {param.name} parameter",
                required=required,
            )
            self.options.append(option)

    def _get_option_type(self, annotation: Any, default: Any) -> int:
        """Convert Python type annotations to Discord option types."""
        if annotation == str:
            return ApplicationCommandOptionType.STRING
        elif annotation == int:
            return ApplicationCommandOptionType.INTEGER
        elif annotation == bool:
            return ApplicationCommandOptionType.BOOLEAN
        elif annotation == float:
            return ApplicationCommandOptionType.NUMBER
        elif annotation == User:
            return ApplicationCommandOptionType.USER
        elif annotation.__class__.__name__ == "Channel":
            return ApplicationCommandOptionType.CHANNEL
        elif annotation.__class__.__name__ == "Role":
            return ApplicationCommandOptionType.ROLE
        else:
            return ApplicationCommandOptionType.STRING  # Default to string

    async def invoke(self, ctx: SlashContext) -> None:
        """Invoke the command with the given context."""
        try:
            kwargs: Dict[str, Any] = {}

            # Parse options from interaction
            for option_name, option_value in ctx.options.items():
                kwargs[option_name] = option_value

            # Call the function with context and options
            await self.func(ctx, **kwargs)
        except Exception as e:
            log.error(f"Error invoking slash command {self.name}: {e}")
            if not ctx.responded:
                await ctx.respond(f"An error occurred: {str(e)}", ephemeral=True)


class SlashCommandManager:
    def __init__(self, bot: "Client") -> None:
        self.bot: "Client" = bot
        self.commands: Dict[str, SlashCommand] = {}
        self._application_id: Optional[str] = None

    def command(
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        guild_ids: Optional[List[str]] = None,
    ) -> Callable:
        """Decorator to register a slash command."""

        def decorator(func: Callable) -> SlashCommand:
            cmd = SlashCommand(
                func, name=name, description=description, guild_ids=guild_ids
            )
            self.commands[cmd.name] = cmd
            return cmd

        return decorator

    def slash_command(self, **kwargs: Any) -> Callable:
        """Alias for command."""
        return self.command(**kwargs)

    def slash(self, **kwargs: Any) -> Callable:
        """Ultra-short alias for command - just use @bot.slash!"""
        return self.command(**kwargs)

    def cmd(self, **kwargs: Any) -> Callable:
        """Another short alias."""
        return self.command(**kwargs)

    async def register_commands(self) -> None:
        """Register all slash commands with Discord."""
        if not self._application_id:
            # Get application info
            app_info = await self.bot.http.get_application_info()
            self._application_id = app_info["id"]
            self.bot.application_id = self._application_id  # Store for later use

        for cmd in self.commands.values():
            application_cmd = ApplicationCommand(
                name=cmd.name,
                description=cmd.description,
                options=cmd.options,
                type=ApplicationCommandType.CHAT_INPUT,
            )

            if cmd.guild_ids:
                # Register for specific guilds
                for guild_id in cmd.guild_ids:
                    await self.bot.http.create_guild_application_command(
                        self._application_id,
                        guild_id,
                        application_cmd.to_dict()
                        if hasattr(application_cmd, "to_dict")
                        else application_cmd.__dict__,
                    )
            else:
                # Register globally
                await self.bot.http.create_global_application_command(
                    self._application_id,
                    application_cmd.to_dict()
                    if hasattr(application_cmd, "to_dict")
                    else application_cmd.__dict__,
                )

        log.info(f"Registered {len(self.commands)} slash commands")

    async def handle_interaction(self, interaction: Interaction) -> None:
        """Handle an incoming interaction."""
        if not interaction.is_application_command:
            return

        if not interaction.data:
            return

        command_name: str = interaction.data.name
        if command_name in self.commands:
            ctx = SlashContext(interaction, self.bot)
            await self.commands[command_name].invoke(ctx)
        else:
            log.warning(f"Unknown slash command: {command_name}")
