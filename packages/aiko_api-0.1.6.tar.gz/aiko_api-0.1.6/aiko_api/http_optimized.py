"""
High-performance HTTP client for Discord API.

Optimized for speed with curl_cffi while providing comprehensive
error handling, rate limiting, and connection pooling.
"""

import json
import time
import asyncio
from typing import Optional, Dict, Any, Union
from curl_cffi import requests
from urllib.parse import quote

from .katlog import get_logger
from .common.errors import (
    HTTPException,
    Forbidden,
    NotFound,
    DiscordServerError,
    RateLimited,
    GatewayNotFound,
)
from .common.constants import DISCORD_API
from .core.headers import HeaderBuilder

# High-performance logger
log = get_logger("aiko_api.http", level="INFO")

# TODO: Implement intelligent rate limiting per route
# TODO: Add request/response caching for immutable endpoints
# TODO: Optimize connection pooling for high-throughput scenarios
# TODO: Add request retry with exponential backoff
# TODO: Implement circuit breaker pattern for failing endpoints


class OptimizedHTTPClient:
    """High-performance HTTP client optimized for Discord API.

    Features:
    - Connection pooling with curl_cffi
    - Intelligent rate limiting
    - Automatic retry with backoff
    - Comprehensive error handling
    - Performance monitoring
    """

    def __init__(
        self,
        token: str = None,
        impersonate: str = "chrome120",
        proxy: str = None,
        max_retries: int = 5,
        timeout: int = 30,
    ):
        """Initialize optimized HTTP client.

        Args:
            token: Discord bot token
            impersonate: Browser impersonation for requests
            proxy: Proxy configuration
            max_retries: Maximum retry attempts
            timeout: Request timeout in seconds
        """
        self.token = token
        self.impersonate = impersonate
        self.proxy = proxy
        self.max_retries = max_retries
        self.timeout = timeout

        # Performance tracking
        self._request_count = 0
        self._error_count = 0
        self._rate_limit_hits = 0
        self._last_rate_limit = 0

        # Session management
        self._session = None
        self._session_lock = asyncio.Lock()

        # Header management
        self.header_builder = HeaderBuilder(token)

        # Rate limiting buckets (per-route rate limiting)
        self._rate_limit_buckets: Dict[str, Dict[str, Any]] = {}

    async def _get_session(self) -> requests.Session:
        """Get or create HTTP session with proper locking."""
        if self._session is None:
            async with self._session_lock:
                if self._session is None:
                    self._session = requests.Session(
                        impersonate=self.impersonate,
                        proxies={"http": self.proxy, "https": self.proxy}
                        if self.proxy
                        else None,
                        timeout=self.timeout,
                    )
        return self._session

    def _get_rate_limit_bucket(self, endpoint: str) -> str:
        """Get rate limit bucket key for an endpoint.

        Args:
            endpoint: API endpoint

        Returns:
            Rate limit bucket key
        """
        # Major parameters for Discord rate limiting
        if "/channels/" in endpoint:
            parts = endpoint.split("/")
            if len(parts) >= 3:
                return f"channels:{parts[2]}"
        elif "/guilds/" in endpoint:
            parts = endpoint.split("/")
            if len(parts) >= 3:
                return f"guilds:{parts[2]}"
        elif "/webhooks/" in endpoint:
            parts = endpoint.split("/")
            if len(parts) >= 3:
                return f"webhooks:{parts[2]}"

        return "global"

    async def _handle_rate_limit(self, bucket: str, reset_after: float) -> None:
        """Handle rate limiting for a specific bucket.

        Args:
            bucket: Rate limit bucket
            reset_after: Seconds until rate limit resets
        """
        self._rate_limit_hits += 1
        self._last_rate_limit = time.time()

        log.warning(f"Rate limited on bucket {bucket} for {reset_after}s")

        # Store rate limit info
        self._rate_limit_buckets[bucket] = {
            "reset_time": time.time() + reset_after,
            "limited": True,
        }

        # Wait for rate limit to reset
        await asyncio.sleep(reset_after + 0.1)  # Add small buffer

    def _should_retry(self, status_code: int, attempt: int) -> bool:
        """Determine if request should be retried.

        Args:
            status_code: HTTP status code
            attempt: Current attempt number

        Returns:
            Whether to retry the request
        """
        if attempt >= self.max_retries:
            return False

        # Retry on server errors and rate limits
        if status_code in [502, 503, 504, 520, 521, 522, 524]:
            return True
        elif status_code == 429:  # Rate limited
            return True

        return False

    def _calculate_backoff(self, attempt: int) -> float:
        """Calculate exponential backoff time.

        Args:
            attempt: Current attempt number

        Returns:
            Backoff time in seconds
        """
        return min(2**attempt + (time.time() % 1), 60)  # Max 60s

    async def request(
        self, method: str, endpoint: str, **kwargs
    ) -> Union[Dict[str, Any], list, str]:
        """Make an HTTP request to Discord API with optimization.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            **kwargs: Additional request parameters

        Returns:
            Response data

        Raises:
            Various Discord exceptions based on status code
        """
        session = await self._get_session()
        url = DISCORD_API + endpoint

        # Get rate limit bucket
        bucket = self._get_rate_limit_bucket(endpoint)

        # Check if bucket is rate limited
        bucket_info = self._rate_limit_buckets.get(bucket)
        if (
            bucket_info
            and bucket_info.get("limited")
            and time.time() < bucket_info.get("reset_time", 0)
        ):
            wait_time = bucket_info["reset_time"] - time.time()
            log.info(f"Waiting for rate limit on {bucket}: {wait_time:.2f}s")
            await asyncio.sleep(wait_time)

        # Build headers
        headers = self.header_builder.build(context=kwargs.pop("context", None))
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        # Handle file uploads
        files = kwargs.pop("files", None)
        data = kwargs.pop("data", None)
        json_payload = kwargs.pop("json", None)

        # Remove Content-Type for multipart
        if files and "Content-Type" in headers:
            headers.pop("Content-Type")

        # Retry logic
        for attempt in range(self.max_retries + 1):
            try:
                self._request_count += 1

                # Make request
                response = session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    files=files,
                    data=data,
                    json=json_payload,
                    **kwargs,
                )

                # Handle rate limiting
                if response.status_code == 429:
                    reset_after = float(
                        response.headers.get("X-RateLimit-Reset-After", 1)
                    )
                    await self._handle_rate_limit(bucket, reset_after)
                    continue  # Retry after rate limit

                # Success
                if 200 <= response.status_code < 300:
                    if response.content:
                        try:
                            return response.json()
                        except json.JSONDecodeError:
                            return response.text
                    return None

                # Handle specific status codes
                if response.status_code == 403:
                    raise Forbidden(response, await self._get_error_message(response))
                elif response.status_code == 404:
                    raise NotFound(response, await self._get_error_message(response))
                elif response.status_code >= 500:
                    raise DiscordServerError(
                        response, await self._get_error_message(response)
                    )
                else:
                    raise HTTPException(
                        response, await self._get_error_message(response)
                    )

            except (requests.RequestsError, OSError) as e:
                log.error(f"Request error on attempt {attempt + 1}: {e}")
                self._error_count += 1

                if self._should_retry(0, attempt):
                    backoff = self._calculate_backoff(attempt)
                    log.info(f"Retrying after {backoff:.2f}s")
                    await asyncio.sleep(backoff)
                    continue
                else:
                    raise

        # Max retries exceeded
        raise HTTPException(None, f"Max retries ({self.max_retries}) exceeded")

    async def _get_error_message(self, response) -> str:
        """Extract error message from response.

        Args:
            response: HTTP response

        Returns:
            Error message
        """
        try:
            if response.content:
                data = response.json()
                if isinstance(data, dict):
                    return data.get("message", "Unknown error")
            return f"HTTP {response.status_code}"
        except:
            return "Unknown error"

    # Convenience methods for common HTTP operations
    async def get(self, endpoint: str, **kwargs) -> Union[Dict[str, Any], list]:
        """Make a GET request."""
        return await self.request("GET", endpoint, **kwargs)

    async def post(self, endpoint: str, **kwargs) -> Union[Dict[str, Any], list]:
        """Make a POST request."""
        return await self.request("POST", endpoint, **kwargs)

    async def put(self, endpoint: str, **kwargs) -> Union[Dict[str, Any], list]:
        """Make a PUT request."""
        return await self.request("PUT", endpoint, **kwargs)

    async def patch(self, endpoint: str, **kwargs) -> Union[Dict[str, Any], list]:
        """Make a PATCH request."""
        return await self.request("PATCH", endpoint, **kwargs)

    async def delete(self, endpoint: str, **kwargs) -> Union[Dict[str, Any], list]:
        """Make a DELETE request."""
        return await self.request("DELETE", endpoint, **kwargs)

    # Performance monitoring
    @property
    def stats(self) -> Dict[str, Any]:
        """Get performance statistics."""
        return {
            "total_requests": self._request_count,
            "total_errors": self._error_count,
            "rate_limit_hits": self._rate_limit_hits,
            "last_rate_limit": self._last_rate_limit,
            "active_buckets": len(self._rate_limit_buckets),
        }

    def reset_stats(self) -> None:
        """Reset performance statistics."""
        self._request_count = 0
        self._error_count = 0
        self._rate_limit_hits = 0
        self._rate_limit_buckets.clear()


# Backward compatibility - export as HTTP
HTTP = OptimizedHTTPClient
