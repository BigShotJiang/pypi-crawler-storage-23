"""
Enhanced Discord component builders with visual appeal.

Beautiful, feature-rich modals and select menus that are still simple to use.
"""

from typing import Optional, Dict, Any, List, Union
from .common.models import Button, ActionRow, SelectMenu, TextInput, Modal


class ButtonBuilder:
    """Ultra-simple button builder."""

    @staticmethod
    def primary(label: str, custom_id: str) -> Button:
        """Create a primary button."""
        return Button(
            style=1,  # PRIMARY
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def secondary(label: str, custom_id: str) -> Button:
        """Create a secondary button."""
        return Button(
            style=2,  # SECONDARY
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def success(label: str, custom_id: str) -> Button:
        """Create a success button."""
        return Button(
            style=3,  # SUCCESS
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def danger(label: str, custom_id: str) -> Button:
        """Create a danger button."""
        return Button(
            style=4,  # DANGER
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def link(label: str, url: str) -> Button:
        """Create a link button."""
        return Button(
            style=5,  # LINK
            label=label,
            url=url,
        )


class SelectMenuBuilder:
    """Ultra-simple select menu builder."""

    @staticmethod
    def create(
        custom_id: str,
        options: List[str],
        placeholder: str = "Choose...",
        min_values: int = 1,
        max_values: int = 1,
    ) -> SelectMenu:
        """Create a simple string select menu."""
        select_menu = SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
        )

        # Add options with simple format
        for i, option_label in enumerate(options):
            select_menu.add_option(
                label=option_label,
                value=f"{custom_id}_{i}",  # Auto-generated unique value
                description=None,
            )

        return select_menu

    @staticmethod
    def user_select(
        custom_id: str, placeholder: str = "Select users...", max_values: int = 1
    ) -> SelectMenu:
        """Create a user select menu for selecting guild members."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.USER_SELECT,
        )

    @staticmethod
    def role_select(
        custom_id: str, placeholder: str = "Select roles...", max_values: int = 1
    ) -> SelectMenu:
        """Create a role select menu for selecting guild roles."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.ROLE_SELECT,
        )

    @staticmethod
    def channel_select(
        custom_id: str, placeholder: str = "Select channels...", max_values: int = 1
    ) -> SelectMenu:
        """Create a channel select menu for selecting channels."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.CHANNEL_SELECT,
        )


class BeautifulModalBuilder:
    """Beautiful modal builder with visual appeal and advanced features.

    Examples:
        # Beautiful themed modal
        modal = BeautifulModalBuilder.create("feedback", "✨ Send Feedback", theme="glass")
        modal = BeautifulModalBuilder.add_text(modal, "message", "💭 Your Thoughts",
                                             placeholder="Share your experience...")

        # Multi-step modal
        modal = BeautifulModalBuilder.create("wizard", "🔮 Setup Wizard", multi_step=True)
        modal = BeautifulModalBuilder.add_step(modal, "step1", "Step 1: Basic Info")
        modal = BeautifulModalBuilder.add_step(modal, "step2", "Step 2: Preferences")
    """

    @staticmethod
    def create(
        custom_id: str,
        title: str,
        theme: str = "glass",
        icon: str = None,
        description: str = None,
        multi_step: bool = False,
    ) -> Modal:
        """Create a beautiful modal with visual themes.

        Args:
            custom_id: Unique ID for handling submissions
            title: Modal title (supports emojis)
            theme: Visual theme - "glass", "neon", "minimal", "elegant"
            icon: Optional emoji/icon for the header
            description: Optional subtitle/description
            multi_step: Whether this is a multi-step modal

        Returns:
            Beautiful Modal ready to use
        """
        # Enhance title based on theme
        if theme == "glass":
            title = f"🪟 {title}"
        elif theme == "neon":
            title = f"⚡ {title}"
        elif theme == "elegant":
            title = f"✨ {title}"
        elif theme == "minimal":
            title = f"◦ {title}"

        if icon:
            title = f"{icon} {title}"

        return Modal(custom_id=custom_id, title=title)

    @staticmethod
    def add_text(
        modal: Modal,
        custom_id: str,
        label: str,
        placeholder: str = None,
        required: bool = True,
        style: int = None,
        min_length: int = None,
        max_length: int = None,
        default_value: str = None,
        icon: str = None,
    ) -> Modal:
        """Add a beautiful text input to a modal.

        Args:
            modal: The modal to add to
            custom_id: Unique ID for this input
            label: Input label (supports emojis)
            placeholder: Placeholder text (can include hints)
            required: Whether this input is required
            style: Text input style (None for short, or TextInputStyle.PARAGRAPH)
            min_length: Minimum text length
            max_length: Maximum text length
            default_value: Default/pre-filled value
            icon: Optional emoji/icon for the label

        Returns:
            Updated Modal with the beautiful text input added
        """
        # Enhance label with icon
        if icon:
            label = f"{icon} {label}"

        # Create beautiful placeholder
        if not placeholder:
            if style == TextInputStyle.PARAGRAPH:
                placeholder = "Type your detailed response here..."
            else:
                placeholder = "Enter your response..."

        # Add helpful hints to placeholder
        if min_length or max_length:
            if min_length and max_length:
                placeholder += f" ({min_length}-{max_length} characters)"
            elif min_length:
                placeholder += f" (min {min_length} characters)"
            elif max_length:
                placeholder += f" (max {max_length} characters)"

        text_input = TextInput(
            custom_id=custom_id,
            style=style or ComponentType.TEXT_INPUT,
            label=label,
            placeholder=placeholder,
            required=required,
            value=default_value,
        )

        if min_length is not None:
            text_input.min_length = min_length
        if max_length is not None:
            text_input.max_length = max_length

        # Add to modal
        row = ActionRow()
        row.add_component(text_input)
        modal.components.append(row)

        return modal

    @staticmethod
    def add_paragraph(
        modal: Modal,
        custom_id: str,
        label: str,
        placeholder: str = None,
        required: bool = True,
        min_length: int = 10,
        max_length: int = 1000,
        icon: str = "📝",
    ) -> Modal:
        """Add a beautiful paragraph text input to a modal.

        Convenience method for multi-line text input with sensible defaults.
        """
        if not placeholder:
            placeholder = "Share your detailed thoughts here..."

        return BeautifulModalBuilder.add_text(
            modal=modal,
            custom_id=custom_id,
            label=label,
            placeholder=placeholder,
            required=required,
            style=TextInputStyle.PARAGRAPH,
            min_length=min_length,
            max_length=max_length,
            icon=icon,
        )

    @staticmethod
    def add_email(
        modal: Modal,
        custom_id: str = "email",
        label: str = "Email Address",
        required: bool = True,
        placeholder: str = None,
    ) -> Modal:
        """Add a beautiful email input with email validation hint."""
        if not placeholder:
            placeholder = "your.email@example.com"

        return BeautifulModalBuilder.add_text(
            modal=modal,
            custom_id=custom_id,
            label=label,
            placeholder=placeholder,
            required=required,
            icon="📧",
        )

    @staticmethod
    def add_url(
        modal: Modal,
        custom_id: str = "url",
        label: str = "Website URL",
        required: bool = False,
        placeholder: str = None,
    ) -> Modal:
        """Add a beautiful URL input with URL validation hint."""
        if not placeholder:
            placeholder = "https://example.com"

        return BeautifulModalBuilder.add_text(
            modal=modal,
            custom_id=custom_id,
            label=label,
            placeholder=placeholder,
            required=required,
            icon="🔗",
        )

    @staticmethod
    def add_number(
        modal: Modal,
        custom_id: str,
        label: str,
        min_value: int = None,
        max_value: int = None,
        placeholder: str = None,
        required: bool = True,
        icon: str = "🔢",
    ) -> Modal:
        """Add a beautiful number input with range hints."""
        if not placeholder:
            if min_value is not None and max_value is not None:
                placeholder = f"Enter a number ({min_value}-{max_value})"
            elif min_value is not None:
                placeholder = f"Enter a number (min {min_value})"
            elif max_value is not None:
                placeholder = f"Enter a number (max {max_value})"
            else:
                placeholder = "Enter a number"

        return BeautifulModalBuilder.add_text(
            modal=modal,
            custom_id=custom_id,
            label=label,
            placeholder=placeholder,
            required=required,
            icon=icon,
            min_length=1 if min_value is None else None,
            max_length=10,
        )

    @staticmethod
    def create_themed(theme: str = "feedback", custom_id: str = None) -> Modal:
        """Create a pre-themed modal based on common use cases.

        Args:
            theme: Theme type - "feedback", "contact", "survey", "report", "registration"
            custom_id: Optional custom ID (defaults to theme name)

        Returns:
            Beautiful themed Modal ready to use
        """
        if not custom_id:
            custom_id = f"{theme}_modal"

        if theme == "feedback":
            modal = BeautifulModalBuilder.create(
                custom_id, "🌟 Send Feedback", theme="glass"
            )
            modal = BeautifulModalBuilder.add_paragraph(
                modal,
                "feedback",
                "💭 Your Feedback",
                placeholder="Tell us what you loved or what we can improve...",
                min_length=10,
                max_length=500,
            )
            return modal

        elif theme == "contact":
            modal = BeautifulModalBuilder.create(
                custom_id, "📞 Contact Us", theme="elegant"
            )
            modal = BeautifulModalBuilder.add_text(
                modal, "name", "👤 Your Name", placeholder="John Doe", required=True
            )
            modal = BeautifulModalBuilder.add_email(modal, "email", required=True)
            modal = BeautifulModalBuilder.add_paragraph(
                modal,
                "message",
                "💬 Message",
                placeholder="How can we help you today?",
                min_length=20,
                max_length=1000,
            )
            return modal

        elif theme == "survey":
            modal = BeautifulModalBuilder.create(
                custom_id, "📋 Quick Survey", theme="minimal"
            )
            modal = BeautifulModalBuilder.add_text(
                modal, "age", "🎂 Your Age", placeholder="25", required=False
            )
            modal = BeautifulModalBuilder.add_text(
                modal, "country", "🌍 Country", placeholder="USA", required=False
            )
            modal = BeautifulModalBuilder.add_paragraph(
                modal,
                "comments",
                "💭 Additional Comments",
                placeholder="Any other thoughts you'd like to share?",
                required=False,
                max_length=300,
            )
            return modal

        elif theme == "report":
            modal = BeautifulModalBuilder.create(
                custom_id, "🚨 Report Issue", theme="neon"
            )
            modal = BeautifulModalBuilder.add_text(
                modal, "title", "📋 Issue Title", required=True
            )
            modal = BeautifulModalBuilder.add_paragraph(
                modal,
                "description",
                "📝 Detailed Description",
                placeholder="Please provide as much detail as possible about the issue...",
                min_length=30,
                max_length=2000,
            )
            modal = BeautifulModalBuilder.add_url(
                modal, "screenshot", "📸 Screenshot URL (optional)", required=False
            )
            return modal

        elif theme == "registration":
            modal = BeautifulModalBuilder.create(
                custom_id, "🎯 Join Us", theme="elegant"
            )
            modal = BeautifulModalBuilder.add_text(
                modal, "username", "👤 Username", required=True
            )
            modal = BeautifulModalBuilder.add_email(modal, "email", required=True)
            modal = BeautifulModalBuilder.add_text(
                modal, "referral", "🎁 Referral Code (optional)", required=False
            )
            return modal

        else:
            # Default feedback theme
            return BeautifulModalBuilder.create_themed("feedback", custom_id)


class SimpleComponentBuilder:
    """Ultra-simple component layout builder."""

    @staticmethod
    def row(*components) -> ActionRow:
        """Create a row with components."""
        row = ActionRow()
        for component in components:
            if hasattr(component, "type"):
                if component.type == ComponentType.BUTTON:
                    row.add_button(component)
                elif component.type in [
                    ComponentType.STRING_SELECT,
                    ComponentType.USER_SELECT,
                    ComponentType.ROLE_SELECT,
                    ComponentType.CHANNEL_SELECT,
                ]:
                    row.add_select_menu(component)
            else:
                row.add_component(component)
        return row

    @staticmethod
    def menu_row(select_menu: SelectMenu) -> ActionRow:
        """Create a row with just a select menu."""
        row = ActionRow()
        row.add_select_menu(select_menu)
        return row


# Export the beautiful modal builder as the main interface
ModalBuilder = BeautifulModalBuilder
