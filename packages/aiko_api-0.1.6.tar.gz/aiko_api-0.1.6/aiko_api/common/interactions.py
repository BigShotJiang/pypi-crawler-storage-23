# aiko_api/common/interactions.py
import datetime
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Union, TYPE_CHECKING
from .models import Base, User, Member, Channel, Role, Message, Embed


class InteractionType:
    """Discord interaction types."""

    PING: int = 1
    APPLICATION_COMMAND: int = 2
    MESSAGE_COMPONENT: int = 3
    APPLICATION_COMMAND_AUTOCOMPLETE: int = 4
    MODAL_SUBMIT: int = 5


class ApplicationCommandType:
    """Discord application command types."""

    CHAT_INPUT: int = 1
    USER: int = 2
    MESSAGE: int = 3


class ApplicationCommandOptionType:
    """Discord application command option types."""

    SUB_COMMAND: int = 1
    SUB_COMMAND_GROUP: int = 2
    STRING: int = 3
    INTEGER: int = 4
    BOOLEAN: int = 5
    USER: int = 6
    CHANNEL: int = 7
    ROLE: int = 8
    MENTIONABLE: int = 9
    NUMBER: int = 10
    ATTACHMENT: int = 11


class InteractionResponseType:
    """Discord interaction response types."""

    PONG: int = 1
    CHANNEL_MESSAGE_WITH_SOURCE: int = 4
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE: int = 5
    DEFERRED_UPDATE_MESSAGE: int = 6
    UPDATE_MESSAGE: int = 7
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT: int = 8
    MODAL: int = 9
    PREMIUM_REQUIRED: int = 10


@dataclass
class ApplicationCommandOptionChoice(Base):
    name: str
    value: Union[str, int, float]


@dataclass
class ApplicationCommandOption(Base):
    type: int
    name: str
    description: str
    required: bool = False
    choices: List["ApplicationCommandOptionChoice"] = field(default_factory=list)
    options: List["ApplicationCommandOption"] = field(default_factory=list)
    channel_types: List[int] = field(default_factory=list)
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    autocomplete: bool = False


@dataclass
class ApplicationCommand(Base):
    name: str
    type: int = ApplicationCommandType.CHAT_INPUT
    description: str = ""
    options: List[ApplicationCommandOption] = field(default_factory=list)
    default_member_permissions: Optional[str] = None
    dm_permission: bool = True
    nsfw: bool = False
    guild_id: Optional[str] = None


@dataclass
class InteractionData(Base):
    id: str
    name: str
    type: int
    options: List[ApplicationCommandOption] = field(default_factory=list)
    resolved: Optional[Dict[str, Any]] = None
    custom_id: Optional[str] = None
    component_type: Optional[int] = None
    values: List[str] = field(default_factory=list)
    target_id: Optional[str] = None
    components: List[Any] = field(default_factory=list)


@dataclass
class Interaction(Base):
    id: str
    application_id: str
    type: int
    channel_id: str
    author: User
    data: Optional[InteractionData] = None
    guild_id: Optional[str] = None
    member: Optional[Member] = None
    user: Optional[User] = None
    token: str = ""
    version: int = 1
    message: Optional[Message] = None
    locale: Optional[str] = None
    guild_locale: Optional[str] = None

    def __post_init__(self) -> None:
        # Set up convenience properties
        self.is_ping: bool = self.type == InteractionType.PING
        self.is_application_command: bool = (
            self.type == InteractionType.APPLICATION_COMMAND
        )
        self.is_message_component: bool = self.type == InteractionType.MESSAGE_COMPONENT
        self.is_autocomplete: bool = (
            self.type == InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE
        )
        self.is_modal_submit: bool = self.type == InteractionType.MODAL_SUBMIT

    @property
    def created_at(self) -> datetime.datetime:
        """Get the creation time of this interaction."""
        timestamp = ((int(self.id) >> 22) + 1420070400000) / 1000
        return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc)


@dataclass
class InteractionResponse(Base):
    type: int
    data: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format for Discord API."""
        result: Dict[str, Any] = {"type": self.type}
        if self.data:
            result["data"] = self.data
        return result


@dataclass
class InteractionApplicationCommandCallbackData(Base):
    tts: bool = False
    content: Optional[str] = None
    embeds: List[Embed] = field(default_factory=list)
    allowed_mentions: Optional[Dict[str, Any]] = None
    flags: Optional[int] = None
    components: List[Dict[str, Any]] = field(default_factory=list)
    attachments: List[Any] = field(default_factory=list)
