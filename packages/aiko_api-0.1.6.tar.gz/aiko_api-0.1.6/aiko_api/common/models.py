"""
Discord API models and data structures.

This module contains all Discord object models including users, messages, channels,
and interactive components like buttons, select menus, and modals.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Union
import datetime


@dataclass(kw_only=True)
class Base:
    """Base class for all Discord models."""

    _state: Any = field(default=None, repr=False, compare=False)


@dataclass
class Snowflake(Base):
    """Base class for Discord objects with unique IDs."""

    id: str

    @property
    def created_at(self) -> datetime.datetime:
        """Get the creation time of this snowflake."""
        timestamp = ((int(self.id) >> 22) + 1420070400000) / 1000
        return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc)


# === Core Discord Models ===


@dataclass
class User(Snowflake):
    """Represents a Discord user."""

    username: str
    discriminator: str
    avatar: Optional[str]
    bot: bool = False

    @property
    def mention(self) -> str:
        """Get the user's mention string."""
        return f"<@{self.id}>"

    def __str__(self) -> str:
        return self.mention

    @property
    def display_name(self) -> str:
        """Get the display name (username or nickname)."""
        return self.username

    async def send(self, content: str, **kwargs) -> Any:
        """Send a DM to this user."""
        if not self._state:
            raise RuntimeError("User state not initialized")
        return await self._state.messages.send(self.id, content, **kwargs)


@dataclass
class Member(User):
    """Represents a guild member."""

    nick: Optional[str] = None
    roles: List[str] = field(default_factory=list)
    joined_at: Optional[str] = None

    @property
    def display_name(self) -> str:
        """Get the display name (nickname or username)."""
        return self.nick if self.nick else self.username


@dataclass
class Role(Snowflake):
    """Represents a Discord role."""

    name: str
    color: int = 0
    hoist: bool = False
    icon: Optional[str] = None
    unicode_emoji: Optional[str] = None
    position: int = 0
    permissions: str = "0"
    managed: bool = False
    mentionable: bool = False
    tags: Dict[str, Any] = field(default_factory=dict)

    @property
    def mention(self) -> str:
        """Get the role's mention string."""
        return f"<@&{self.id}>"

    def __str__(self) -> str:
        return self.mention

    def has_permission(self, permission: int) -> bool:
        """Check if role has specific permission."""
        perms = int(self.permissions)
        return (perms & permission) == permission or (
            perms & 0x8
        ) == 0x8  # Administrator


@dataclass
class PermissionOverwrite:
    """Represents a permission overwrite for a channel."""

    id: str
    type: int  # 0 for role, 1 for member
    allow: str = "0"
    deny: str = "0"

    @property
    def allow_permissions(self) -> int:
        return int(self.allow)

    @property
    def deny_permissions(self) -> int:
        return int(self.deny)


# === Channel and Message Models ===


class ChannelType:
    """Discord channel types."""

    GUILD_TEXT = 0
    DM = 1
    GUILD_VOICE = 2
    GROUP_DM = 3
    GUILD_CATEGORY = 4
    GUILD_ANNOUNCEMENT = 5
    ANNOUNCEMENT_THREAD = 10
    PUBLIC_THREAD = 11
    PRIVATE_THREAD = 12
    GUILD_STAGE_VOICE = 13
    GUILD_DIRECTORY = 14
    GUILD_FORUM = 15
    GUILD_MEDIA = 16


@dataclass
class Channel(Snowflake):
    """Represents a Discord channel."""

    name: str
    type: int
    guild_id: Optional[str] = None
    position: int = 0
    parent_id: Optional[str] = None
    permission_overwrites: List[Dict[str, Any]] = field(default_factory=list)
    nsfw: bool = False
    topic: Optional[str] = None
    rate_limit_per_user: Optional[int] = None
    bitrate: Optional[int] = None
    user_limit: Optional[int] = None

    @property
    def mention(self) -> str:
        """Get the channel's mention string."""
        return f"<#{self.id}>"

    def __str__(self) -> str:
        return self.mention

    @property
    def is_text_channel(self) -> bool:
        """Check if this is a text channel."""
        return self.type in [ChannelType.GUILD_TEXT, ChannelType.GUILD_ANNOUNCEMENT]

    @property
    def is_voice_channel(self) -> bool:
        """Check if this is a voice channel."""
        return self.type in [ChannelType.GUILD_VOICE, ChannelType.GUILD_STAGE_VOICE]

    @property
    def is_thread(self) -> bool:
        """Check if this is a thread channel."""
        return self.type in [
            ChannelType.ANNOUNCEMENT_THREAD,
            ChannelType.PUBLIC_THREAD,
            ChannelType.PRIVATE_THREAD,
        ]

    async def send(self, content: str, **kwargs) -> Any:
        """Send a message to this channel."""
        if not self._state:
            raise RuntimeError("Channel state not initialized")
        return await self._state.messages.send(self.id, content, **kwargs)


@dataclass
class Guild(Snowflake):
    """Represents a Discord guild."""

    name: str
    icon: Optional[str]
    owner_id: str
    roles: Dict[str, Any] = field(default_factory=dict)
    members: Dict[str, Member] = field(default_factory=dict)
    channels: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Attachment(Snowflake):
    """Represents a message attachment."""

    filename: str
    url: str
    proxy_url: str
    size: int
    height: Optional[int] = None
    width: Optional[int] = None
    content_type: Optional[str] = None
    ephemeral: bool = False

    @property
    def is_image(self) -> bool:
        """Check if this attachment is an image."""
        if self.content_type:
            return self.content_type.startswith("image/")
        return any(
            self.filename.lower().endswith(ext)
            for ext in (".png", ".jpg", ".jpeg", ".gif", ".webp")
        )


@dataclass
class Embed:
    """Represents a Discord embed."""

    title: Optional[str] = None
    type: str = "rich"
    description: Optional[str] = None
    url: Optional[str] = None
    timestamp: Optional[str] = None
    color: Optional[int] = None
    footer: Optional[Dict[str, Any]] = None
    image: Optional[Dict[str, Any]] = None
    thumbnail: Optional[Dict[str, Any]] = None
    video: Optional[Dict[str, Any]] = None
    provider: Optional[Dict[str, Any]] = None
    author: Optional[Dict[str, Any]] = None
    fields: List[Dict[str, Any]] = field(default_factory=list)

    def add_field(self, name: str, value: str, inline: bool = True) -> "Embed":
        """Add a field to the embed."""
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def set_author(
        self, name: str, url: Optional[str] = None, icon_url: Optional[str] = None
    ) -> "Embed":
        """Set the author of the embed."""
        self.author = {"name": name}
        if url:
            self.author["url"] = url
        if icon_url:
            self.author["icon_url"] = icon_url
        return self

    def set_footer(self, text: str, icon_url: Optional[str] = None) -> "Embed":
        """Set the footer of the embed."""
        self.footer = {"text": text}
        if icon_url:
            self.footer["icon_url"] = icon_url
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert embed to dictionary for API."""
        data = {}
        for key in ["title", "type", "description", "url", "timestamp", "color"]:
            value = getattr(self, key)
            if value is not None:
                data[key] = value

        for key in [
            "footer",
            "image",
            "thumbnail",
            "video",
            "provider",
            "author",
            "fields",
        ]:
            value = getattr(self, key)
            if value:
                data[key] = value
        return data


@dataclass
class Message(Snowflake):
    """Represents a Discord message."""

    channel_id: str
    guild_id: Optional[str]
    author: User
    content: str
    timestamp: str
    tts: bool
    mention_everyone: bool
    attachments: List[Attachment] = field(default_factory=list)
    embeds: List[Embed] = field(default_factory=list)
    reactions: List[Any] = field(default_factory=list)
    components: List[Any] = field(default_factory=list)  # Message components

    @property
    def image_url(self) -> Optional[str]:
        """Get the first image URL from attachments or embeds."""
        for attachment in self.attachments:
            if attachment.is_image:
                return attachment.url
        for embed in self.embeds:
            if embed.image:
                return embed.image.get("url")
            if embed.thumbnail:
                return embed.thumbnail.get("url")
        return None

    async def reply(self, content: str, **kwargs) -> Any:
        """Reply to this message."""
        if not self._state:
            raise RuntimeError("Message state not initialized")
        return await self._state.messages.reply(
            self.channel_id, self.id, content, **kwargs
        )

    async def edit(self, content: str, **kwargs) -> Any:
        """Edit this message."""
        if not self._state:
            raise RuntimeError("Message state not initialized")
        return await self._state.messages.edit(
            self.channel_id, self.id, content, **kwargs
        )

    async def delete(self) -> Any:
        """Delete this message."""
        if not self._state:
            raise RuntimeError("Message state not initialized")
        return await self._state.messages.delete(self.channel_id, self.id)

    async def add_reaction(self, emoji: str) -> Any:
        """Add a reaction to this message."""
        if not self._state:
            raise RuntimeError("Message state not initialized")
        return await self._state.messages.add_reaction(self.channel_id, self.id, emoji)


# === Component Models ===


class ComponentType:
    """Discord component types."""

    ACTION_ROW = 1
    BUTTON = 2
    STRING_SELECT = 3
    TEXT_INPUT = 4
    USER_SELECT = 5
    ROLE_SELECT = 6
    MENTIONABLE_SELECT = 7
    CHANNEL_SELECT = 8


class ButtonStyle:
    """Discord button styles."""

    PRIMARY = 1  # Blurple
    SECONDARY = 2  # Gray
    SUCCESS = 3  # Green
    DANGER = 4  # Red
    LINK = 5  # URL buttons


class TextInputStyle:
    """Discord text input styles for modals."""

    SHORT = 1  # Single line
    PARAGRAPH = 2  # Multi-line


@dataclass
class Button(Base):
    """Represents a Discord button component."""

    style: int
    label: Optional[str] = None
    emoji: Optional[Dict[str, Any]] = None
    custom_id: Optional[str] = None
    url: Optional[str] = None
    disabled: bool = False
    type: int = field(default=ComponentType.BUTTON, init=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert button to dictionary for Discord API."""
        data = {"type": self.type, "style": self.style}

        if self.label:
            data["label"] = self.label
        if self.emoji:
            data["emoji"] = self.emoji
        if self.custom_id:
            data["custom_id"] = self.custom_id
        if self.url:
            data["url"] = self.url
        if self.disabled:
            data["disabled"] = self.disabled

        return data


@dataclass
class SelectMenu(Base):
    """Represents a Discord select menu component."""

    custom_id: str
    placeholder: Optional[str] = None
    min_values: int = 1
    max_values: int = 1
    disabled: bool = False
    type: int = field(default=ComponentType.STRING_SELECT, init=False)
    options: List[Dict[str, Any]] = field(default_factory=list)
    channel_types: Optional[List[int]] = None  # For channel selects

    def add_option(
        self,
        label: str,
        value: str,
        description: Optional[str] = None,
        emoji: Optional[Dict[str, Any]] = None,
    ) -> "SelectMenu":
        """Add an option to the select menu."""
        option = {"label": label, "value": value}
        if description:
            option["description"] = description
        if emoji:
            option["emoji"] = emoji
        self.options.append(option)
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert select menu to dictionary for Discord API."""
        data = {
            "type": self.type,
            "custom_id": self.custom_id,
            "min_values": self.min_values,
            "max_values": self.max_values,
        }

        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.disabled:
            data["disabled"] = self.disabled
        if self.options:
            data["options"] = self.options
        if self.channel_types:
            data["channel_types"] = self.channel_types

        return data


@dataclass
class ActionRow(Base):
    """Represents a Discord action row component."""

    components: List[Any] = field(default_factory=list)
    type: int = field(default=ComponentType.ACTION_ROW, init=False)

    def add_button(self, button: Button) -> "ActionRow":
        """Add a button to this action row."""
        if len(self.components) < 5:  # Discord limit
            self.components.append(button)
        return self

    def add_select_menu(self, select_menu: SelectMenu) -> "ActionRow":
        """Add a select menu to this action row."""
        if len(self.components) < 5:  # Discord limit
            self.components.append(select_menu)
        return self

    def add_component(self, component: Any) -> "ActionRow":
        """Add any component to this action row."""
        if len(self.components) < 5:  # Discord limit
            self.components.append(component)
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert action row to dictionary for Discord API."""
        return {
            "type": self.type,
            "components": [
                comp.to_dict() if hasattr(comp, "to_dict") else comp
                for comp in self.components
            ],
        }


# === Modal Models ===


@dataclass
class TextInput(Base):
    """Represents a text input component for modals."""

    custom_id: str
    style: int
    label: str
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    required: bool = True
    value: Optional[str] = None
    placeholder: Optional[str] = None
    type: int = field(default=ComponentType.TEXT_INPUT, init=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert text input to dictionary for Discord API."""
        data = {
            "type": self.type,
            "custom_id": self.custom_id,
            "style": self.style,
            "label": self.label,
            "required": self.required,
        }

        if self.min_length is not None:
            data["min_length"] = self.min_length
        if self.max_length is not None:
            data["max_length"] = self.max_length
        if self.value is not None:
            data["value"] = self.value
        if self.placeholder is not None:
            data["placeholder"] = self.placeholder

        return data


@dataclass
class Modal(Base):
    """Represents a Discord modal."""

    custom_id: str
    title: str
    components: List[ActionRow] = field(default_factory=list)

    def add_text_input(self, text_input: TextInput) -> "Modal":
        """Add a text input to the modal."""
        # Modals require text inputs to be in action rows
        row = ActionRow()
        row.add_component(text_input)
        self.components.append(row)
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert modal to dictionary for Discord API."""
        return {
            "custom_id": self.custom_id,
            "title": self.title,
            "components": [comp.to_dict() for comp in self.components],
        }


# === Activity Models ===


@dataclass(kw_only=True)
class Activity:
    """Represents a Discord activity (rich presence)."""

    name: str
    type: int = 0
    url: Optional[str] = None
    state: Optional[str] = None
    details: Optional[str] = None
    application_id: Optional[str] = None
    timestamps: Optional[Dict[str, int]] = None
    assets: Optional[Dict[str, str]] = None
    party: Optional[Dict[str, Any]] = None
    buttons: Optional[List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert activity to dictionary for Discord API."""
        data = {"name": self.name, "type": self.type}
        for attr in (
            "url",
            "state",
            "details",
            "application_id",
            "timestamps",
            "assets",
            "party",
            "buttons",
        ):
            val = getattr(self, attr)
            if val is not None:
                data[attr] = val
        return data


# === Utility Classes ===


class Emoji:
    """Represents a Discord emoji."""

    def __init__(self, id: str, name: str, animated: bool = False):
        self.id = id
        self.name = name
        self.animated = animated

    @property
    def mention(self) -> str:
        """Get the emoji mention string."""
        if self.animated:
            return f"<a:{self.name}:{self.id}>"
        return f"<{self.name}:{self.id}>"

    def __str__(self) -> str:
        return self.mention


# TODO: Add more emoji utility methods
# TODO: Add sticker support
# TODO: Add guild scheduled events
# TODO: Add thread member models
# TODO: Add voice state models
