"""
Ultra-simple API for Discord components and interactions.

Provides the most intuitive way to create buttons, rows, and handle interactions.
Just import and use - no complex setup needed!
"""

from typing import List, Optional, Callable, Any, Union
from .slash_commands_v2 import SlashCommandManager, SlashContext, ComponentContext
from .components_simple import ButtonBuilder, SimpleComponentBuilder, SelectMenuBuilder
from .common.models import Button, ActionRow
from .common.models import ComponentType


class SimpleSlashManager(SlashCommandManager):
    """Enhanced slash command manager with ultra-simple API."""

    def __call__(self, **kwargs: Any) -> Callable:
        """Make bot.slash() work as decorator - ultra simple!"""
        return self.command(**kwargs)

    def button(self, label: str, custom_id: str, style: str = "primary") -> Button:
        """Create a button - ultra simple!

        Args:
            label: Button text
            custom_id: Unique ID for handling clicks
            style: Button style (primary, secondary, success, danger, link)

        Returns:
            Button ready to use

        Examples:
            button = bot.slash.button("Click me", "test_button")
            danger_btn = bot.slash.button("Delete", "del", style="danger")
        """
        style_map: dict[str, int] = {
            "primary": 1,
            "secondary": 2,
            "success": 3,
            "danger": 4,
            "link": 5,
        }
        button_style: int = style_map.get(style.lower(), 1)

        return Button(
            style=button_style,
            label=label,
            custom_id=custom_id if style.lower() != "link" else None,
            url=None if style.lower() != "link" else custom_id,
        )

    def row(self, *components: Any) -> ActionRow:
        """Create a row with components - super simple!

        Examples:
            row = bot.slash.row(button1, button2)
            menu_row = bot.slash.row(select_menu)
        """
        return SimpleComponentBuilder.row(*components)

    def on_click(self, custom_id: str) -> Callable:
        """Ultra-simple button click handler decorator.

        Examples:
            @bot.slash.on_click("test_button")
            async def handle_click(ctx):
                await ctx.respond("Button clicked!")
        """
        return self.component_handler(custom_id)


# Standalone functions - use anywhere without bot!
def button(label: str, custom_id: str, style: str = "primary") -> Button:
    """Create a button - ultra simple!

    Examples:
        my_button = button("Click me", "my_button")
        danger_button = button("Delete", "delete", style="danger")
        link_button = button("Visit", "https://example.com", style="link")
    """
    style_map: dict[str, int] = {
        "primary": 1,
        "secondary": 2,
        "success": 3,
        "danger": 4,
        "link": 5,
    }
    button_style: int = style_map.get(style.lower(), 1)

    return Button(
        style=button_style,
        label=label,
        custom_id=custom_id if style.lower() != "link" else None,
        url=None if style.lower() != "link" else custom_id,
    )


def row(*components: Any) -> ActionRow:
    """Create a row with components - super simple!

    Examples:
        my_row = row(button1, button2, button3)
        menu_row = row(select_menu)
    """
    return SimpleComponentBuilder.row(*components)
