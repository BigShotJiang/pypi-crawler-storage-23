"""
Simplified Discord component builders.

Ultra-simple APIs for select menus and modals that are easy to use
while maintaining high performance with curl_cffi.
"""

from typing import Optional, Dict, Any, List, Union
from .common.models import Button, ActionRow, SelectMenu, TextInput, Modal
from .common.models import ComponentType


class ButtonBuilder:
    """Ultra-simple button builder."""

    @staticmethod
    def primary(label: str, custom_id: str) -> Button:
        """Create a primary button."""
        return Button(
            style=1,  # PRIMARY
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def secondary(label: str, custom_id: str) -> Button:
        """Create a secondary button."""
        return Button(
            style=2,  # SECONDARY
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def success(label: str, custom_id: str) -> Button:
        """Create a success button."""
        return Button(
            style=3,  # SUCCESS
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def danger(label: str, custom_id: str) -> Button:
        """Create a danger button."""
        return Button(
            style=4,  # DANGER
            label=label,
            custom_id=custom_id,
        )

    @staticmethod
    def link(label: str, url: str) -> Button:
        """Create a link button."""
        return Button(
            style=5,  # LINK
            label=label,
            url=url,
        )


class SimpleSelectMenuBuilder:
    """Ultra-simple select menu builder.

    Examples:
        # Basic select menu
        select = SimpleSelectMenuBuilder.create("color", ["Red", "Blue", "Green"])

        # With handler
        @bot.slash_commands.component_handler("color")
        async def handle_color(ctx):
            print(f"Selected: {ctx.values[0]}")
    """

    @staticmethod
    def create(
        custom_id: str,
        options: List[str],
        placeholder: str = "Choose...",
        min_values: int = 1,
        max_values: int = 1,
    ) -> SelectMenu:
        """Create a simple string select menu.

        Args:
            custom_id: Unique ID for handling interactions
            options: List of option labels
            placeholder: Placeholder text
            min_values: Minimum selections required
            max_values: Maximum selections allowed

        Returns:
            Configured SelectMenu ready to use
        """
        select_menu: SelectMenu = SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
        )

        # Add options with simple format
        for i, option_label in enumerate(options):
            select_menu.add_option(
                label=option_label,
                value=f"{custom_id}_{i}",  # Auto-generated unique value
                description=None,
            )

        return select_menu

    @staticmethod
    def user_select(
        custom_id: str, placeholder: str = "Select users...", max_values: int = 1
    ) -> SelectMenu:
        """Create a user select menu for selecting guild members."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.USER_SELECT,
        )

    @staticmethod
    def role_select(
        custom_id: str, placeholder: str = "Select roles...", max_values: int = 1
    ) -> SelectMenu:
        """Create a role select menu for selecting guild roles."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.ROLE_SELECT,
        )

    @staticmethod
    def channel_select(
        custom_id: str, placeholder: str = "Select channels...", max_values: int = 1
    ) -> SelectMenu:
        """Create a channel select menu for selecting channels."""
        return SelectMenu(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=1,
            max_values=max_values,
            type=ComponentType.CHANNEL_SELECT,
        )


class SimpleModalBuilder:
    """Ultra-simple modal builder.

    Examples:
        # Simple modal with text input
        modal = SimpleModalBuilder.create("feedback", "Send Feedback")
        modal = SimpleModalBuilder.add_text(modal, "message", "Your message")

        # Handle submission
        @bot.slash_commands.modal_handler("feedback")
        async def handle_feedback(ctx):
            message = ctx.get_value("message")
            await ctx.respond(f"Got: {message}")
    """

    @staticmethod
    def create(custom_id: str, title: str) -> Modal:
        """Create a simple modal.

        Args:
            custom_id: Unique ID for handling submissions
            title: Modal title

        Returns:
            Configured Modal ready to use
        """
        return Modal(custom_id=custom_id, title=title)

    @staticmethod
    def add_text(
        modal: Modal,
        custom_id: str,
        label: str,
        placeholder: Optional[str] = None,
        required: bool = True,
        style: Optional[int] = None,
    ) -> Modal:
        """Add a text input to a modal.

        Args:
            modal: The modal to add to
            custom_id: Unique ID for this input
            label: Input label shown to user
            placeholder: Placeholder text
            required: Whether this input is required
            style: Text input style (None for short, or TextInputStyle.PARAGRAPH)

        Returns:
            Updated Modal with the text input added
        """
        text_input: TextInput = TextInput(
            custom_id=custom_id,
            style=style or ComponentType.TEXT_INPUT,
            label=label,
            placeholder=placeholder,
            required=required,
        )

        # Add to modal
        row: ActionRow = ActionRow()
        row.add_component(text_input)
        modal.components.append(row)

        return modal

    @staticmethod
    def add_paragraph(
        modal: Modal,
        custom_id: str,
        label: str,
        placeholder: Optional[str] = None,
        required: bool = True,
    ) -> Modal:
        """Add a paragraph text input to a modal.

        Convenience method for multi-line text input.
        """
        return SimpleModalBuilder.add_text(
            modal=modal,
            custom_id=custom_id,
            label=label,
            placeholder=placeholder,
            required=required,
            style=TextInputStyle.PARAGRAPH,
        )


class SimpleComponentBuilder:
    """Ultra-simple component layout builder."""

    @staticmethod
    def row(*components: Any) -> ActionRow:
        """Create a row with components."""
        row: ActionRow = ActionRow()
        for component in components:
            if hasattr(component, "type"):
                if component.type == ComponentType.BUTTON:
                    row.add_button(component)
                elif component.type in [
                    ComponentType.STRING_SELECT,
                    ComponentType.USER_SELECT,
                    ComponentType.ROLE_SELECT,
                    ComponentType.CHANNEL_SELECT,
                ]:
                    row.add_select_menu(component)
            else:
                row.add_component(component)
        return row

    @staticmethod
    def menu_row(select_menu: SelectMenu) -> ActionRow:
        """Create a row with just a select menu.

        Convenience method for the common case of a single select menu.
        """
        row: ActionRow = ActionRow()
        row.add_select_menu(select_menu)
        return row


class EmojiConverter:
    """Simple emoji conversion utilities."""

    @staticmethod
    def from_string(emoji_str: str) -> Optional[Dict[str, Any]]:
        """Parse emoji from string format."""
        if not emoji_str:
            return None

        # Custom animated emoji: <a:name:id>
        if emoji_str.startswith("<a:") and emoji_str.endswith(">"):
            parts: List[str] = emoji_str[3:-1].split(":")
            if len(parts) == 2:
                return {"name": parts[0], "id": parts[1], "animated": True}

        # Custom static emoji: <:name:id>
        if emoji_str.startswith("<:") and emoji_str.endswith(">"):
            parts: List[str] = emoji_str[2:-1].split(":")
            if len(parts) == 2:
                return {"name": parts[0], "id": parts[1], "animated": False}

        # Unicode emoji
        return {"name": emoji_str, "id": None}

    @staticmethod
    def menu_row(select_menu: SelectMenu) -> ActionRow:
        """Create a row with just a select menu.

        Convenience method for the common case of a single select menu.
        """
        row: ActionRow = ActionRow()
        row.add_select_menu(select_menu)
        return row


# Export simplified builders as the main interface
SelectMenuBuilder = SimpleSelectMenuBuilder
ModalBuilder = SimpleModalBuilder
ComponentBuilder = SimpleComponentBuilder
