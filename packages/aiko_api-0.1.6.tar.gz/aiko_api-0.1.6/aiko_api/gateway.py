import asyncio
import json
import sys
import time
from typing import Optional, Any, Dict, List, Union
from curl_cffi import CurlWsFlag
from .katlog import get_logger
from .common.errors import AikoException

log = get_logger("aiko_api", level="DEBUG")


class ConnectionClosed(AikoException):
    """Raised when the WebSocket connection is closed."""

    pass


class DiscordWebSocket:
    """Implements the websocket connection to Discord's gateway using curl_cffi."""

    GATEWAY: str = "wss://gateway.discord.gg/?v=10&encoding=json"

    def __init__(
        self, client: Any, loop: Optional[asyncio.AbstractEventLoop] = None
    ) -> None:
        self.client: Any = client
        self.loop: asyncio.AbstractEventLoop = loop or asyncio.get_event_loop()
        self.socket: Optional[Any] = None
        self.heartbeat_interval: Optional[float] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self.session_id: Optional[str] = None
        self.sequence: Optional[int] = None
        self._keep_alive: Optional[asyncio.Task] = None
        self._closed: bool = False
        self._reconnect_attempts: int = 0
        self._max_reconnect_attempts: int = 10
        self._base_delay: int = 1
        self._max_delay: int = 60
        self._ready: bool = False

    async def connect(self) -> None:
        try:
            session = self.client.http._get_session()
            self.socket = await session.ws_connect(
                self.GATEWAY, headers=self.client.http.headers.build()
            )
        except Exception as e:
            log.error(f"Failed to connect to gateway: {e}")
            raise

        self._closed = False
        self._ready = False
        await self.identify()
        await self._wait_for_ready()
        self._keep_alive = asyncio.create_task(self.run())

    async def identify(self) -> None:
        """Send identify payload to Discord."""
        identify_data: Dict[str, Any] = {
            "op": 2,
            "d": {
                "token": self.client.http.token,
                "intents": self.client.intents or 513,  # Default intents
                "properties": {
                    "os": sys.platform,
                    "browser": "aiko_api",
                    "device": "aiko_api",
                },
            },
        }
        await self.send_as_json(identify_data)

    async def send_as_json(self, data: Dict[str, Any]) -> None:
        """Send data as JSON to the websocket."""
        if self.socket:
            await self.socket.send(json.dumps(data))

    async def send_heartbeat(self) -> None:
        """Send heartbeat to Discord."""
        heartbeat_data: Dict[str, Any] = {
            "op": 1,
            "d": self.sequence,
        }
        await self.send_as_json(heartbeat_data)
        log.debug("Sent heartbeat")

    async def run(self) -> None:
        """Main websocket loop."""
        while not self._closed:
            try:
                await self.send_heartbeat()
                await asyncio.sleep(self.heartbeat_interval or 30)
            except Exception as e:
                log.error(f"Error in heartbeat: {e}")
                if not self._closed:
                    await self.close()
                    await self.reconnect()
                    break

    async def reconnect(self) -> None:
        """Reconnect to the gateway."""
        if self._reconnect_attempts >= self._max_reconnect_attempts:
            log.error("Max reconnection attempts reached")
            await self.close()
            return

        self._reconnect_attempts += 1
        delay: int = min(
            self._base_delay * (2**self._reconnect_attempts), self._max_delay
        )
        log.info(
            f"Reconnecting in {delay} seconds... (attempt {self._reconnect_attempts})"
        )
        await asyncio.sleep(delay)
        await self.connect()

    async def close(self) -> None:
        """Close the websocket connection."""
        self._closed = True
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        if self.socket:
            await self.socket.close()
        if self._keep_alive:
            self._keep_alive.cancel()

    async def _wait_for_ready(self) -> None:
        """Wait for the ready event."""
        while not self._ready and not self._closed:
            await asyncio.sleep(0.1)

    async def received_message(self, msg: str) -> None:
        """Handle received messages from Discord."""
        try:
            data: Dict[str, Any] = json.loads(msg)
            await self._handle_dispatch(data)
        except json.JSONDecodeError as e:
            log.error(f"Failed to decode JSON: {e}")

    async def _handle_dispatch(self, data: Dict[str, Any]) -> None:
        """Handle dispatch events from Discord."""
        op: int = data.get("op", 0)

        if op == 10:  # Hello
            self.heartbeat_interval = data["d"]["heartbeat_interval"] / 1000
            self._heartbeat_task = asyncio.create_task(self.run())
            log.debug("Received hello, starting heartbeat")
        elif op == 11:  # Heartbeat ACK
            log.debug("Received heartbeat ACK")
        elif op == 0:  # Dispatch
            event: str = data.get("t", "")
            if event == "READY":
                self.session_id = data["d"]["session_id"]
                self._ready = True
                log.info("Connected to Discord gateway")
            elif event == "RESUMED":
                log.info("Resumed connection to Discord gateway")

            # Update sequence number
            if "s" in data and data["s"]:
                self.sequence = data["s"]

            # Dispatch event
            await self.client.dispatch(event, data.get("d"))

    async def poll_event(self) -> None:
        """Poll for events from the websocket."""
        if not self.socket:
            return

        try:
            msg: str = await self.socket.recv()
            if msg:
                await self.received_message(msg)
        except Exception as e:
            if not self._closed:
                log.error(f"Error polling events: {e}")
                await self.close()
                await self.reconnect()
