"""
Enhanced slash commands with modern Discord interactions.

This module provides comprehensive support for Discord's interaction system including:
- Application commands (slash commands, context menus)
- Interactive components (buttons, select menus)
- Modal forms with text inputs
- Autocomplete functionality
- Advanced interaction handling with proper error management

Built for high performance with proper async handling, connection pooling,
and optimized for the curl_cffi HTTP client.
"""

import asyncio
import inspect
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Union,
    TypeVar,
    ParamSpec,
    TYPE_CHECKING,
)
from dataclasses import dataclass
from enum import Enum

from .katlog import get_logger
from .common.interactions import (
    ApplicationCommand,
    ApplicationCommandType,
    ApplicationCommandOption,
    ApplicationCommandOptionType,
    ApplicationCommandOptionChoice,
    Interaction,
    InteractionType,
    InteractionResponse,
    InteractionResponseType,
    InteractionApplicationCommandCallbackData,
)
from .common.models import Button, ActionRow, SelectMenu, TextInput, Modal

# High-performance logger with nanosecond precision
log = get_logger("aiko_api.interactions", level="INFO")

T = TypeVar("T")
P = ParamSpec("P")


# TODO: Add comprehensive interaction state management
# TODO: Implement interaction timeout handling
# TODO: Add component interaction validation
# TODO: Optimize interaction response caching
# TODO: Add interaction rate limiting per guild/user


class SlashOption:
    """Represents a slash command option with validation and type safety.

    Provides enhanced features over basic Discord options including:
    - Type validation and conversion
    - Min/max value constraints
    - String length constraints
    - Channel type filtering
    - Autocomplete support
    """

    def __init__(
        self,
        description: str,
        option_type: Optional[int] = None,
        required: bool = True,
        choices: Optional[List[Dict[str, Any]]] = None,
        autocomplete: bool = False,
        min_value: Optional[Union[int, float]] = None,
        max_value: Optional[Union[int, float]] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        channel_types: Optional[List[int]] = None,
    ) -> None:
        """Initialize a slash command option.

        Args:
            description: Option description shown in Discord
            option_type: Discord option type (auto-detected if None)
            required: Whether this option is required
            choices: List of predefined choices
            autocomplete: Whether to enable autocomplete
            min_value: Minimum numeric value
            max_value: Maximum numeric value
            min_length: Minimum string length
            max_length: Maximum string length
            channel_types: Allowed channel types for channel options
        """
        self.description: str = description
        self.option_type: Optional[int] = option_type
        self.required: bool = required
        self.choices: List[Dict[str, Any]] = choices or []
        self.autocomplete: bool = autocomplete
        self.min_value: Optional[Union[int, float]] = min_value
        self.max_value: Optional[Union[int, float]] = max_value
        self.min_length: Optional[int] = min_length
        self.max_length: Optional[int] = max_length
        self.channel_types: List[int] = channel_types or []


class SlashContext:
    """Enhanced context for slash commands with modern interaction features.

    Provides comprehensive support for responding to interactions including:
    - Ephemeral responses
    - Component support (buttons, select menus)
    - File uploads
    - Embed management
    - Followup messages
    - Message editing and deletion
    """

    def __init__(self, interaction: Interaction, bot: Any) -> None:
        """Initialize slash command context.

        Args:
            interaction: The Discord interaction
            bot: The bot instance
        """
        self.interaction: Interaction = interaction
        self.bot: Any = bot
        self.author: User = interaction.author
        self.channel_id: str = interaction.channel_id
        self.guild_id: Optional[str] = interaction.guild_id
        self.token: str = interaction.token
        self.id: str = interaction.id
        self.command_name: Optional[str] = (
            interaction.data.name if interaction.data else None
        )
        self.options: Dict[str, Any] = self._parse_options(
            interaction.data.options if interaction.data else []
        )
        self.responded: bool = False
        self.deferred: bool = False
        self._followup_count: int = 0

    def _parse_options(self, options: List[Any]) -> Dict[str, Any]:
        """Parse interaction options into a validated dictionary.

        Args:
            options: Raw interaction options from Discord

        Returns:
            Parsed options dictionary
        """
        result: Dict[str, Any] = {}
        for option in options:
            if isinstance(option, dict):
                result[option["name"]] = option.get("value")
            else:
                result[option.name] = getattr(option, "value", None)
        return result

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        file: Optional[Any] = None,
        files: Optional[List[Any]] = None,
        tts: bool = False,
        ephemeral: bool = False,
        view: Optional[Any] = None,
        components: Optional[List[Any]] = None,
        allowed_mentions: Optional[Any] = None,
        suppress_embeds: bool = False,
        silent: bool = False,
        delete_after: Optional[float] = None,
    ) -> None:
        """Respond to the interaction with comprehensive options.

        Args:
            content: Message content (max 2000 characters)
            embed: Single embed object
            embeds: List of embed objects (max 10)
            file: Single file to upload
            files: List of files to upload
            tts: Whether to send as TTS
            ephemeral: Whether response is ephemeral (only visible to user)
            view: Discord view components (deprecated, use components)
            components: List of component action rows
            allowed_mentions: Mention restrictions
            suppress_embeds: Whether to suppress embeds
            silent: Whether to suppress notifications
            delete_after: Auto-delete after specified seconds

        Raises:
            RuntimeError: If interaction has already been responded to
        """
        if self.responded:
            return await self.send_followup(
                content=content,
                embed=embed,
                embeds=embeds,
                file=file,
                files=files,
                tts=tts,
                ephemeral=ephemeral,
                view=view,
                components=components,
                allowed_mentions=allowed_mentions,
                suppress_embeds=suppress_embeds,
                silent=silent,
                delete_after=delete_after,
            )

        data: Dict[str, Any] = {}

        # Content handling
        if content is not None:
            data["content"] = str(content)[:2000]  # Discord limit

        # Embed handling
        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds[:10]
            ]

        # Component handling
        if components:
            data["components"] = components

        # Flags
        flags: int = 0
        if ephemeral:
            flags |= 64  # EPHEMERAL flag
        if suppress_embeds:
            flags |= 1 << 2  # SUPPRESS_EMBEDS
        if silent:
            flags |= 1 << 12  # SUPPRESS_NOTIFICATIONS

        if flags:
            data["flags"] = flags

        # TTS
        if tts:
            data["tts"] = True

        # File handling (TODO: Implement file upload support)
        if file or files:
            log.warning("File uploads not yet implemented for interactions")

        # Send response
        response = InteractionResponse(
            type=InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data=data
        )

        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True

        # Auto-delete if requested
        if delete_after:
            asyncio.create_task(self._delete_after(delete_after))

    async def _delete_after(self, delay: float) -> None:
        """Delete the original response after a delay."""
        await asyncio.sleep(delay)
        try:
            await self.delete_original_response()
        except Exception as e:
            log.debug(f"Failed to auto-delete response: {e}")

    async def defer(self, *, ephemeral: bool = False, thinking: bool = True) -> None:
        """Defer the interaction response to allow more processing time.

        Args:
            ephemeral: Whether the deferred response will be ephemeral
            thinking: Whether to show "Bot is thinking..." state

        Raises:
            RuntimeError: If interaction has already been responded to
        """
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        response_type: InteractionResponseType = (
            InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE
            if thinking
            else InteractionResponseType.DEFERRED_UPDATE_MESSAGE
        )

        response = InteractionResponse(type=response_type, data=data if data else None)
        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True
        self.deferred = True

    async def send_followup(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        file: Optional[Any] = None,
        files: Optional[List[Any]] = None,
        tts: bool = False,
        ephemeral: bool = False,
        view: Optional[Any] = None,
        components: Optional[List[Any]] = None,
        allowed_mentions: Optional[Any] = None,
        suppress_embeds: bool = False,
        silent: bool = False,
        delete_after: Optional[float] = None,
    ) -> None:
        """Send a followup message to an interaction.

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            file: Single file
            files: List of files
            tts: TTS flag
            ephemeral: Ephemeral flag
            view: View components
            components: Component list
            allowed_mentions: Mention restrictions
            suppress_embeds: Suppress embeds flag
            silent: Silent flag
            delete_after: Auto-delete delay
        """
        if not self.responded:
            raise RuntimeError(
                "Must respond to interaction first before sending followups"
            )

        data: Dict[str, Any] = {}
        if content is not None:
            data["content"] = str(content)

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        if components:
            data["components"] = components

        if tts:
            data["tts"] = True

        if ephemeral:
            data["flags"] = 64

        if suppress_embeds:
            data["flags"] = (data.get("flags") or 0) | 1 << 2

        if silent:
            data["flags"] = (data.get("flags") or 0) | 1 << 12

        # Get application ID for followup
        if not hasattr(self.bot, "application_id"):
            app_info = await self.bot.http.get_application_info()
            self.bot.application_id = app_info["id"]

        await self.bot.http.create_followup_message(
            self.bot.application_id, self.token, json=data
        )
        self._followup_count += 1

        if delete_after:
            # TODO: Implement followup deletion
            pass

    async def send(self, content: Optional[str] = None, **kwargs: Any) -> Any:
        """Alias for respond."""
        return await self.respond(content, **kwargs)

    async def reply(self, content: Optional[str] = None, **kwargs: Any) -> Any:
        """Reply to the interaction."""
        return await self.respond(content, **kwargs)

    async def thinking(self, *, ephemeral: bool = False) -> Any:
        """Show thinking state (alias for defer)."""
        return await self.defer(ephemeral=ephemeral, thinking=True)

    async def delete_original_response(self) -> None:
        """Delete the original interaction response."""
        if not self.responded:
            raise RuntimeError("Cannot delete response that hasn't been sent")

        if not hasattr(self.bot, "application_id"):
            app_info = await self.bot.http.get_application_info()
            self.bot.application_id = app_info["id"]

        await self.bot.http.delete_original_interaction_response(
            self.bot.application_id, self.token
        )

    def get_option(self, name: str, default: Any = None) -> Any:
        """Get an option value by name.

        Args:
            name: Option name
            default: Default value if not found

        Returns:
            Option value or default
        """
        return self.options.get(name, default)

    @property
    def latency(self) -> Optional[float]:
        """Get bot latency in seconds."""
        return getattr(self.bot, "latency", None)


class ComponentContext:
    """Context for component interactions (buttons, select menus).

    Handles user interactions with message components like button clicks
    and select menu selections.
    """

    def __init__(self, interaction: Interaction, bot: Any) -> None:
        """Initialize component context.

        Args:
            interaction: The component interaction
            bot: The bot instance
        """
        self.interaction: Interaction = interaction
        self.bot: Any = bot
        self.author: User = interaction.author
        self.channel_id: str = interaction.channel_id
        self.guild_id: Optional[str] = interaction.guild_id
        self.token: str = interaction.token
        self.id: str = interaction.id
        self.custom_id: Optional[str] = (
            interaction.data.get("custom_id") if interaction.data else None
        )
        self.component_type: Optional[int] = (
            interaction.data.get("component_type") if interaction.data else None
        )
        self.values: List[str] = (
            interaction.data.get("values", []) if interaction.data else []
        )
        self.responded: bool = False
        self.deferred: bool = False

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        components: Optional[List[Any]] = None,
        ephemeral: bool = False,
        tts: bool = False,
        suppress_embeds: bool = False,
        silent: bool = False,
    ) -> None:
        """Respond to the component interaction.

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            components: Component list
            ephemeral: Whether response is ephemeral
            tts: TTS flag
            suppress_embeds: Suppress embeds flag
            silent: Silent flag
        """
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if content is not None:
            data["content"] = str(content)

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        if components:
            data["components"] = components

        if tts:
            data["tts"] = True

        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        if suppress_embeds:
            data["flags"] = (data.get("flags") or 0) | 1 << 2

        if silent:
            data["flags"] = (data.get("flags") or 0) | 1 << 12

        # Component interactions need specific response types
        if content or embed or embeds or components:
            # Send a new message
            response = InteractionResponse(
                type=InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data=data
            )
        else:
            # Just acknowledge the interaction
            response = InteractionResponse(
                type=InteractionResponseType.DEFERRED_UPDATE_MESSAGE, data=None
            )

        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True

    async def update(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        components: Optional[List[Any]] = None,
        suppress_embeds: bool = False,
    ) -> None:
        """Update the message this component is attached to.

        Args:
            content: New message content
            embed: New embed
            embeds: New embeds
            components: New components
            suppress_embeds: Whether to suppress embeds
        """
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if content is not None:
            data["content"] = str(content)

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        if components:
            data["components"] = components

        if suppress_embeds:
            data["flags"] = (data.get("flags") or 0) | 1 << 2

        response = InteractionResponse(
            type=InteractionResponseType.UPDATE_MESSAGE, data=data
        )

        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True

    async def defer(self, *, ephemeral: bool = False, update: bool = False) -> None:
        """Defer the component interaction.

        Args:
            ephemeral: Whether the deferred response will be ephemeral
            update: Whether this is a component update
        """
        if self.responded:
            raise RuntimeError("Interaction has already been responded to")

        data: Dict[str, Any] = {}
        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        response_type: InteractionResponseType = (
            InteractionResponseType.DEFERRED_UPDATE_MESSAGE
            if update
            else InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE
        )

        response = InteractionResponse(type=response_type, data=data if data else None)
        await self.bot.http.create_interaction_response(
            self.id, self.token, response.to_dict()
        )
        self.responded = True
        self.deferred = True


class ModalContext:
    """Context for modal interactions (form submissions).

    Handles user submissions from modal forms containing text inputs.
    """

    def __init__(self, interaction: Interaction, bot: Any) -> None:
        """Initialize modal context.

        Args:
            interaction: The modal interaction
            bot: The bot instance
        """
        self.interaction: Interaction = interaction
        self.bot: Any = bot
        self.author: User = interaction.author
        self.channel_id: str = interaction.channel_id
        self.guild_id: Optional[str] = interaction.guild_id
        self.token: str = interaction.token
        self.id: str = interaction.id
        self.custom_id: Optional[str] = (
            interaction.data.get("custom_id") if interaction.data else None
        )
        self.components: List[Any] = (
            interaction.data.get("components", []) if interaction.data else []
        )
        self.responded: bool = False
        self.deferred: bool = False

        # Parse form data into a dictionary
        self.values: Dict[str, str] = self._parse_modal_data(self.components)

    def _parse_modal_data(self, components: List[Any]) -> Dict[str, str]:
        """Parse modal form data into a dictionary.

        Args:
            components: Modal component data from Discord

        Returns:
            Dictionary mapping custom_id to input values
        """
        values: Dict[str, str] = {}
        for row in components:
            if isinstance(row, dict) and row.get("components"):
                for component in row["components"]:
                    if component.get("type") == ComponentType.TEXT_INPUT:
                        custom_id: str = component.get("custom_id")
                        value: str = component.get("value", "")
                        if custom_id:
                            values[custom_id] = value
        return values

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[List[Any]] = None,
        components: Optional[List[Any]] = None,
        ephemeral: bool = True,
        tts: bool = False,
        suppress_embeds: bool = False,
        silent: bool = False,
    ) -> None:
        """Respond to the modal submission.

        Note: Modal responses are ephemeral by default for better UX.

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            components: Component list
            ephemeral: Whether response is ephemeral (default True)
            tts: TTS flag
            suppress_embeds: Suppress embeds flag
            silent: Silent flag
        """
        return await ComponentContext.respond(
            self,
            content,
            embed=embed,
            embeds=embeds,
            components=components,
            ephemeral=ephemeral,
            tts=tts,
            suppress_embeds=suppress_embeds,
            silent=silent,
        )

    def get_value(self, custom_id: str, default: str = "") -> str:
        """Get a form input value by custom_id.

        Args:
            custom_id: The custom_id of the text input
            default: Default value if not found

        Returns:
            Input value or default
        """
        return self.values.get(custom_id, default)


class SlashCommand:
    """Represents a slash command with enhanced features."""

    def __init__(
        self,
        func: Callable,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        guild_ids: Optional[List[str]] = None,
        default_member_permissions: Optional[str] = None,
        dm_permission: bool = True,
        nsfw: bool = False,
        **kwargs: Any,
    ) -> None:
        """Initialize a slash command.

        Args:
            func: The command function
            name: Command name (defaults to function name)
            description: Command description
            guild_ids: Guild IDs to register command in
            default_member_permissions: Required permissions
            dm_permission: Whether command works in DMs
            nsfw: Whether command is NSFW
        """
        self.func: Callable = func
        self.name: str = name or func.__name__
        self.description: str = (
            description or inspect.getdoc(func) or "No description provided"
        )
        self.guild_ids: List[str] = guild_ids or []
        self.default_member_permissions: Optional[str] = default_member_permissions
        self.dm_permission: bool = dm_permission
        self.nsfw: bool = nsfw
        self.options: List[ApplicationCommandOption] = []
        self._parse_signature()

    def _parse_signature(self) -> None:
        """Parse function signature to create command options."""
        sig = inspect.signature(self.func)
        params: List[Any] = list(sig.parameters.values())

        # Skip 'self' and 'ctx' parameters
        if params and params[0].name == "self":
            params = params[1:]
        if params and params[0].name in ("ctx", "context"):
            params = params[1:]

        for param in params:
            option_type: int = self._get_option_type(param.annotation, param.default)
            required: bool = param.default == inspect.Parameter.empty

            option = ApplicationCommandOption(
                type=option_type,
                name=param.name,
                description=f"The {param.name} parameter",
                required=required,
            )
            self.options.append(option)

    def _get_option_type(self, annotation: Any, default: Any) -> int:
        """Convert Python type annotations to Discord option types."""
        if annotation == str:
            return ApplicationCommandOptionType.STRING
        elif annotation == int:
            return ApplicationCommandOptionType.INTEGER
        elif annotation == bool:
            return ApplicationCommandOptionType.BOOLEAN
        elif annotation == float:
            return ApplicationCommandOptionType.NUMBER
        else:
            # Default to string for unknown types
            return ApplicationCommandOptionType.STRING

    def to_application_command(self) -> ApplicationCommand:
        """Convert to Discord application command format."""
        return ApplicationCommand(
            name=self.name,
            description=self.description,
            options=self.options,
            type=ApplicationCommandType.CHAT_INPUT,
            default_member_permissions=self.default_member_permissions,
            dm_permission=self.dm_permission,
            nsfw=self.nsfw,
        )

    async def invoke(self, ctx: SlashContext) -> None:
        """Invoke the command with the given context."""
        try:
            kwargs: Dict[str, Any] = {}
            for option_name, option_value in ctx.options.items():
                kwargs[option_name] = option_value

            await self.func(ctx, **kwargs)
        except Exception as e:
            log.error(f"Error invoking slash command {self.name}: {e}")
            if not ctx.responded:
                await ctx.respond(f"💥 Command failed: {str(e)}", ephemeral=True)


class SlashCommandManager:
    """Modern slash command manager with comprehensive interaction support.

    Manages application commands, component interactions, and modal submissions
    with high performance and proper error handling.
    """

    def __init__(self, bot: Any) -> None:
        """Initialize the slash command manager.

        Args:
            bot: The bot instance
        """
        self.bot: Any = bot
        self.commands: Dict[str, SlashCommand] = {}
        self._application_id: Optional[str] = None
        self._autocomplete_handlers: Dict[str, Dict[str, Callable]] = {}
        self._component_handlers: Dict[str, Callable] = {}
        self._modal_handlers: Dict[str, Callable] = {}

    def command(
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        guild_ids: Optional[List[str]] = None,
        default_member_permissions: Optional[str] = None,
        dm_permission: bool = True,
        nsfw: bool = False,
        **kwargs: Any,
    ) -> Callable:
        """Decorator to register a slash command.

        Args:
            name: Command name
            description: Command description
            guild_ids: Guild IDs to register in
            default_member_permissions: Required permissions
            dm_permission: Whether works in DMs
            nsfw: Whether command is NSFW
        """

        def decorator(func: Callable) -> SlashCommand:
            cmd = SlashCommand(
                func,
                name=name,
                description=description,
                guild_ids=guild_ids,
                default_member_permissions=default_member_permissions,
                dm_permission=dm_permission,
                nsfw=nsfw,
                **kwargs,
            )
            self.commands[cmd.name] = cmd
            return cmd

        return decorator

    def slash_command(self, **kwargs: Any) -> Callable:
        """Alias for command decorator."""
        return self.command(**kwargs)

    def slash(self, **kwargs: Any) -> Callable:
        """Shorter alias for command decorator."""
        return self.command(**kwargs)

    def option(
        self,
        description: str,
        option_type: Optional[int] = None,
        required: bool = True,
        choices: Optional[List[Dict[str, Any]]] = None,
        autocomplete: bool = False,
        **kwargs: Any,
    ) -> SlashOption:
        """Create a command option.

        Args:
            description: Option description
            option_type: Discord option type
            required: Whether required
            choices: Predefined choices
            autocomplete: Whether to enable autocomplete
        """
        return SlashOption(
            description=description,
            option_type=option_type,
            required=required,
            choices=choices,
            autocomplete=autocomplete,
            **kwargs,
        )

    async def register_commands(
        self, guild_id: Optional[str] = None, delete_existing: bool = True
    ) -> None:
        """Register commands with Discord.

        Args:
            guild_id: Specific guild to register in (None for global)
            delete_existing: Whether to delete existing commands first
        """
        if not self._application_id:
            app_info = await self.bot.http.get_application_info()
            self._application_id = app_info["id"]
            self.bot.application_id = self._application_id

        commands_to_register: List[ApplicationCommand] = []
        for cmd in self.commands.values():
            app_cmd = cmd.to_application_command()
            commands_to_register.append(app_cmd)

        # Register commands (guild-specific or global)
        if guild_id or any(cmd.guild_ids for cmd in self.commands.values()):
            target_guilds: set[str] = set()
            if guild_id:
                target_guilds.add(guild_id)
            for cmd in self.commands.values():
                target_guilds.update(cmd.guild_ids)

            for guild_id in target_guilds:
                if delete_existing:
                    await self.bot.http.bulk_overwrite_guild_application_commands(
                        self._application_id, guild_id, []
                    )

                guild_commands: List[ApplicationCommand] = [
                    cmd.to_application_command()
                    for cmd in self.commands.values()
                    if not cmd.guild_ids or guild_id in cmd.guild_ids
                ]

                if guild_commands:
                    await self.bot.http.bulk_overwrite_guild_application_commands(
                        self._application_id, guild_id, guild_commands
                    )
        else:
            # Global commands
            if delete_existing:
                await self.bot.http.bulk_overwrite_global_application_commands(
                    self._application_id, []
                )

            if commands_to_register:
                await self.bot.http.bulk_overwrite_global_application_commands(
                    self._application_id, commands_to_register
                )

        log.info(f"🚀 Registered {len(self.commands)} slash commands")

    async def handle_interaction(self, interaction: Interaction) -> None:
        """Handle incoming interactions with proper routing.

        Args:
            interaction: The Discord interaction
        """
        try:
            if interaction.type == InteractionType.APPLICATION_COMMAND:
                await self._handle_command(interaction)
            elif interaction.type == InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE:
                await self._handle_autocomplete(interaction)
            elif interaction.type == InteractionType.MESSAGE_COMPONENT:
                await self._handle_component(interaction)
            elif interaction.type == InteractionType.MODAL_SUBMIT:
                await self._handle_modal_submit(interaction)
            else:
                log.debug(f"Unknown interaction type: {interaction.type}")
        except Exception as e:
            log.error(f"Error handling interaction: {e}")

    async def _handle_command(self, interaction: Interaction) -> None:
        """Handle slash command interactions."""
        if not interaction.data:
            return

        command_name: str = interaction.data.name
        if command_name in self.commands:
            ctx = SlashContext(interaction, self.bot)
            try:
                await self.commands[command_name].invoke(ctx)
            except Exception as e:
                log.error(f"Failed to invoke command {command_name}: {e}")
                if not ctx.responded:
                    await ctx.respond("Command execution failed", ephemeral=True)
        else:
            log.warning(f"Unknown slash command: {command_name}")

    async def _handle_autocomplete(self, interaction: Interaction) -> None:
        """Handle autocomplete interactions."""
        # TODO: Implement autocomplete response handling
        log.debug("Autocomplete not yet implemented")
        pass

    async def _handle_component(self, interaction: Interaction) -> None:
        """Handle component interactions (buttons, select menus)."""
        if not interaction.data:
            return

        custom_id: Optional[str] = interaction.data.get("custom_id")
        if not custom_id:
            return

        # Check for registered component handlers
        handler: Optional[Callable] = self._component_handlers.get(custom_id)
        if handler:
            try:
                # Determine context type based on component
                component_type: Optional[int] = interaction.data.get("component_type")
                if component_type == 3:  # SELECT_MENU
                    ctx = ComponentContext(interaction, self.bot)
                else:  # BUTTON
                    ctx = ComponentContext(interaction, self.bot)

                await handler(ctx)
            except Exception as e:
                log.error(f"Error in component handler for {custom_id}: {e}")
                # Try to send error response without crashing
                try:
                    await interaction.response.send_message(
                        "An error occurred processing this interaction.", ephemeral=True
                    )
                except:
                    pass
        else:
            log.debug(f"No handler registered for component: {custom_id}")

    async def _handle_modal_submit(self, interaction: Interaction) -> None:
        """Handle modal form submissions."""
        if not interaction.data:
            return

        custom_id: Optional[str] = interaction.data.get("custom_id")
        if not custom_id:
            return

        handler: Optional[Callable] = self._modal_handlers.get(custom_id)
        if handler:
            try:
                ctx = ModalContext(interaction, self.bot)
                await handler(ctx)
            except Exception as e:
                log.error(f"Error in modal handler for {custom_id}: {e}")
                try:
                    await interaction.response.send_message(
                        "An error occurred processing this form.", ephemeral=True
                    )
                except:
                    pass
        else:
            log.debug(f"No handler registered for modal: {custom_id}")

    # Component registration methods
    def register_component_handler(self, custom_id: str, handler: Callable) -> None:
        """Register a handler for a specific component custom_id.

        Args:
            custom_id: The component's custom_id
            handler: Async function to handle the interaction
        """
        self._component_handlers[custom_id] = handler
        log.debug(f"Registered component handler for: {custom_id}")

    def unregister_component_handler(self, custom_id: str) -> None:
        """Unregister a component handler.

        Args:
            custom_id: The component's custom_id
        """
        if custom_id in self._component_handlers:
            del self._component_handlers[custom_id]
            log.debug(f"Unregistered component handler for: {custom_id}")

    def component_handler(self, custom_id: str) -> Callable:
        """Decorator to register a component handler.

        Args:
            custom_id: The component's custom_id

        Returns:
            Decorator function
        """

        def decorator(func: Callable) -> Callable:
            self.register_component_handler(custom_id, func)
            return func

        return decorator

    # Modal registration methods
    def register_modal_handler(self, custom_id: str, handler: Callable) -> None:
        """Register a handler for a specific modal custom_id.

        Args:
            custom_id: The modal's custom_id
            handler: Async function to handle the submission
        """
        self._modal_handlers[custom_id] = handler
        log.debug(f"Registered modal handler for: {custom_id}")

    def unregister_modal_handler(self, custom_id: str) -> None:
        """Unregister a modal handler.

        Args:
            custom_id: The modal's custom_id
        """
        if custom_id in self._modal_handlers:
            del self._modal_handlers[custom_id]
            log.debug(f"Unregistered modal handler for: {custom_id}")

    def modal_handler(self, custom_id: str) -> Callable:
        """Decorator to register a modal handler.

        Args:
            custom_id: The modal's custom_id

        Returns:
            Decorator function
        """

        def decorator(func: Callable) -> Callable:
            self.register_modal_handler(custom_id, func)
            return func

        return decorator

    # Utility methods
    def get_command(self, name: str) -> Optional[SlashCommand]:
        """Get a command by name."""
        return self.commands.get(name)

    def remove_command(self, name: str) -> Optional[SlashCommand]:
        """Remove a command."""
        return self.commands.pop(name, None)

    def clear_commands(self) -> None:
        """Clear all commands."""
        self.commands.clear()

    @property
    def command_count(self) -> int:
        """Get the number of registered commands."""
        return len(self.commands)

    @property
    def component_handler_count(self) -> int:
        """Get the number of registered component handlers."""
        return len(self._component_handlers)

    @property
    def modal_handler_count(self) -> int:
        """Get the number of registered modal handlers."""
        return len(self._modal_handlers)
