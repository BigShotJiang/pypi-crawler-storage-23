"""
Tests for ServeMD Documentation Server
"""
