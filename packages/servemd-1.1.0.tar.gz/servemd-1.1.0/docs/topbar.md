# Top Navigation

## left
* [📚 Docs Home](index.md)
* [🚀 Quick Start](quick-setup.md)

## right
* [GitHub](https://github.com/jberends/servemd)
* [Docker Hub](https://hub.docker.com/r/jberends/servemd)
* {{search:icon=lucide-search,mode=button,placeholder=Search...}}

<!-- Re{{search}} the {{search}} tag: see Navigation docs for mode, icon, and more. -->
