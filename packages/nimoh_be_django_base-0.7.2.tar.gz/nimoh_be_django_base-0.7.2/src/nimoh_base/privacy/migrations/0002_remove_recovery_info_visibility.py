"""
Remove domain-specific ``recovery_info_visibility`` field from PrivacyProfile.

This field described "who can see recovery information and progress" — a concept
specific to addiction-recovery domain apps.  It has no place in a generic reusable
base package.  Consumer projects that need it should add it in their own model
extension or a separate app.
"""

from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("nimoh_privacy", "0001_initial"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="privacyprofile",
            name="recovery_info_visibility",
        ),
    ]
