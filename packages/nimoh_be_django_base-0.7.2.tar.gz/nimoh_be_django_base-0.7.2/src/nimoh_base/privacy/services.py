"""\nPrivacy / GDPR service layer.\n\nCentralizes GDPR business logic (export, erasure, consent, cleanup),\nkeeping views thin.  Views handle HTTP concerns; this module owns\ndomain logic, audit logging, and error handling.\n"""

import csv
import logging
from datetime import timedelta
from io import StringIO

from django.http import HttpResponse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from nimoh_base.auth.models import AuditLog
from nimoh_base.core.exceptions import ProblemDetailException

# UserProfileBasic is imported lazily inside methods to avoid a 'privacy → profiles' module-level
# circular dependency. Use _get_profile_model() below — never import at module level here.
from .utils.gdpr import GDPRDataEraser, GDPRDataExporter

logger = logging.getLogger(__name__)


def _get_profile_model():
    """
    Lazy accessor for the configured profile model.

    Configure via ``NIMOH_BASE['PROFILE_MODEL'] = 'app_label.ModelName'`` in
    your Django settings (e.g. ``'profiles.UserProfileBasic'``).
    """
    from django.apps import apps
    from django.conf import settings
    from django.core.exceptions import ImproperlyConfigured

    nimoh_cfg = getattr(settings, "NIMOH_BASE", {})
    model_path = nimoh_cfg.get("PROFILE_MODEL")
    if not model_path:
        raise ImproperlyConfigured(
            "NIMOH_BASE['PROFILE_MODEL'] must be set to use privacy dashboard features. "
            "Example: NIMOH_BASE = {'PROFILE_MODEL': 'profiles.UserProfileBasic'}"
        )
    app_label, model_name = model_path.rsplit(".", 1)
    return apps.get_model(app_label, model_name)


class GDPRService:
    """Service for GDPR-related operations."""

    # ------------------------------------------------------------------
    # Data Export (Article 20)
    # ------------------------------------------------------------------

    @staticmethod
    def export_user_data(user, validated_data, request):
        """
        Process a GDPR data-export request.

        Returns either a ``dict`` (JSON response body) for the JSON
        format, or an ``HttpResponse`` for file downloads.
        """
        export_format = validated_data["export_format"]

        try:
            exporter = GDPRDataExporter(user)

            if export_format == "csv":
                return GDPRService._create_csv_export(
                    user,
                    exporter,
                    validated_data,
                    request,
                )

            return GDPRService._create_file_export(
                user,
                exporter,
                validated_data,
                request,
            )

        except Exception as e:
            logger.error(
                "GDPR export failed for user %s: %s",
                user.id,
                e,
            )
            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description=f"GDPR data export failed: {e}",
                success=False,
                risk_level="high",
                metadata={"error": str(e)},
            )
            raise ProblemDetailException(
                title="Export Failed",
                detail=_("Data export failed. Please try again or contact support."),
                status_code=500,
            )

    @staticmethod
    def _create_csv_export(user, exporter, validated_data, request):
        """Generate a flat CSV download for the CSV export format."""
        data = exporter.export_user_data()

        output = StringIO()
        writer = csv.writer(output)

        # ---- account fields ----
        writer.writerow(["section", "field", "value"])
        account = data.get("account_data", {})
        for field, value in account.items():
            writer.writerow(["account", field, value])

        # ---- session summary ----
        sessions = data.get("session_data", [])
        for i, session in enumerate(sessions, 1):
            for field, value in session.items():
                writer.writerow([f"session_{i}", field, value])

        # ---- privacy settings ----
        privacy = data.get("privacy_data", {})
        for field, value in privacy.items():
            writer.writerow(["privacy", field, value])

        csv_content = output.getvalue()
        response = HttpResponse(csv_content, content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = (
            f'attachment; filename="gdpr_export_{user.username}_{timezone.now().strftime("%Y%m%d")}.csv"'
        )

        AuditLog.log_from_request(
            request,
            event_type="security_event",
            description="GDPR data export completed (CSV)",
            risk_level="medium",
            metadata={
                "export_format": "csv",
                "include_consent_history": validated_data["include_consent_history"],
                "include_processing_records": validated_data["include_processing_records"],
                "row_count": csv_content.count("\n"),
            },
        )
        return response

    @staticmethod
    def _create_file_export(user, exporter, validated_data, request):
        """Generate a ZIP file download for production exports."""
        export_file = exporter.create_export_file()

        response = HttpResponse(
            export_file.read(),
            content_type="application/zip",
        )
        response["Content-Disposition"] = (
            f'attachment; filename="gdpr_export_{user.username}_{timezone.now().strftime("%Y%m%d")}.zip"'
        )

        AuditLog.log_from_request(
            request,
            event_type="security_event",
            description="GDPR data export completed",
            risk_level="medium",
            metadata={
                "export_format": validated_data["export_format"],
                "include_consent_history": validated_data["include_consent_history"],
                "include_processing_records": validated_data["include_processing_records"],
                "file_size": (export_file.tell() if hasattr(export_file, "tell") else "unknown"),
            },
        )
        return response

    # ------------------------------------------------------------------
    # Data Erasure (Article 17)
    # ------------------------------------------------------------------

    @staticmethod
    def erase_user_data(user, validated_data, request):
        """
        Process a GDPR data-erasure (right to be forgotten) request.

        Returns a dict with the erasure summary.
        """
        try:
            eraser = GDPRDataEraser(user)
            erasure_summary = eraser.initiate_erasure(
                reason=validated_data["reason"],
                retain_audit=True,
            )

            logger.info("GDPR erasure completed for user %s", user.id)

            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description="GDPR data erasure completed",
                risk_level="high",
                metadata={
                    "erasure_reason": validated_data["reason"],
                    "confirm_understanding": validated_data["confirm_understanding"],
                    "confirm_irreversible": validated_data["confirm_irreversible"],
                    "erasure_summary": erasure_summary,
                },
            )

            return {
                "status": "completed",
                "message": str(_("Account deletion completed successfully.")),
                "erasure_summary": erasure_summary,
            }

        except Exception as e:
            logger.error(
                "GDPR erasure failed for user %s: %s",
                user.id,
                e,
            )
            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description=f"GDPR data erasure failed: {e}",
                success=False,
                risk_level="high",
                metadata={"error": str(e)},
            )
            raise ProblemDetailException(
                title="Erasure Failed",
                detail=_("Account deletion failed. Please contact support."),
                status_code=500,
            )

    # ------------------------------------------------------------------
    # Consent Management (Article 7)
    # ------------------------------------------------------------------

    @staticmethod
    def update_consent(user, consent_type, granted, request):
        """
        Record a consent change and create an audit entry.

        Returns a response-ready dict.
        """
        try:
            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description=(f"Consent {consent_type} {'granted' if granted else 'withdrawn'}"),
                risk_level="medium",
                metadata={
                    "consent_type": consent_type,
                    "granted": granted,
                    "previous_state": "unknown",
                },
            )

            return {
                "status": "updated",
                "consent_type": consent_type,
                "consent_status": granted,
                "effective_date": timezone.now().isoformat(),
                "message": str(_(f"Consent for {consent_type} has been {'granted' if granted else 'withdrawn'}.")),
            }

        except Exception as e:
            logger.error(
                "Consent update failed for user %s: %s",
                user.id,
                e,
            )
            raise ProblemDetailException(
                title="Consent Update Failed",
                detail=_("Failed to update consent preferences. Please try again."),
                status_code=500,
            )

    @staticmethod
    def get_consent_status():
        """Return current consent status (stub — needs ConsentRecord model)."""
        return {
            "consent_status": {
                "data_processing": True,
                "marketing": False,
                "analytics": True,
                "third_party": False,
                "cookies": True,
                "profiling": False,
            },
            "last_updated": timezone.now().isoformat(),
        }

    # ------------------------------------------------------------------
    # Privacy Dashboard
    # ------------------------------------------------------------------

    @staticmethod
    def get_privacy_dashboard(user):
        """
        Assemble privacy dashboard data for *user*.

        Raises ``ProblemDetailException`` if the profile is missing.
        """
        try:
            UserProfileBasic = _get_profile_model()
            profile = UserProfileBasic.objects.get(user=user)
        except UserProfileBasic.DoesNotExist:
            raise ProblemDetailException(
                title="Profile Not Found",
                detail=_("User profile not found."),
                status_code=404,
            )

        return {
            "privacy_settings": {
                "profile_visibility": profile.profile_visibility,
                "show_sobriety_date": profile.show_sobriety_date,
                "allow_direct_messages": profile.allow_direct_messages,
                "email_notifications": profile.email_notifications,
                "community_notifications": profile.community_notifications,
            },
            "data_processing_purposes": [
                "Account management and authentication",
                "Recovery support and community features",
                "Safety and crisis intervention",
                "Platform improvement and analytics",
            ],
            "consent_status": {
                "data_processing": True,
                "marketing": False,
                "analytics": True,
                "third_party": False,
            },
            "rights_exercise_history": [],
            "data_retention_info": {
                "profile_data": "36 months",
                "session_logs": "12 months",
                "audit_logs": "84 months",
                "support_data": "24 months",
            },
            "third_party_sharing": {
                "enabled": False,
                "partners": [],
                "purposes": [],
            },
            "security_measures": {
                "data_encryption": True,
                "access_controls": True,
                "audit_logging": True,
                "backup_security": True,
            },
        }

    # ------------------------------------------------------------------
    # Data Cleanup
    # ------------------------------------------------------------------

    @staticmethod
    def cleanup_user_data(user, validated_data):
        """
        Perform data cleanup for the requested scopes.

        Returns a response-ready dict with a cleanup summary.
        """
        from nimoh_base.auth.models import UserSession

        try:
            cleanup_summary = {}
            cutoff_date = timezone.now() - timedelta(days=30)

            for scope in validated_data["cleanup_scope"]:
                if scope == "expired_sessions":
                    qs = UserSession.objects.filter(
                        user=user,
                        is_active=False,
                        created_at__lt=cutoff_date,
                    )
                    count = qs.count()
                    if not validated_data["preserve_legal_hold"]:
                        qs.delete()
                    cleanup_summary["expired_sessions"] = count

                elif scope == "old_audit_logs":
                    cleanup_summary["old_audit_logs"] = 0

                elif scope == "temporary_files":
                    cleanup_summary["temporary_files"] = 0

                elif scope == "cached_data":
                    cleanup_summary["cached_data"] = 0

            return {
                "status": "completed",
                "cleanup_summary": cleanup_summary,
                "message": str(_("Data cleanup completed successfully.")),
                "preserve_legal_hold": validated_data["preserve_legal_hold"],
            }

        except Exception as e:
            logger.error(
                "Data cleanup failed for user %s: %s",
                user.id,
                e,
            )
            raise ProblemDetailException(
                title="Cleanup Failed",
                detail=_("Data cleanup failed. Please try again."),
                status_code=500,
            )

    @staticmethod
    def get_cleanup_status(user):
        """Return information about data available for cleanup."""
        from nimoh_base.auth.models import UserSession

        cutoff_date = timezone.now() - timedelta(days=30)
        expired_count = UserSession.objects.filter(
            user=user,
            is_active=False,
            created_at__lt=cutoff_date,
        ).count()

        return {
            "cleanup_available": {
                "expired_sessions": expired_count,
                "temporary_files": 0,
                "cached_data": 0,
                "analytics_data": 0,
            },
            "legal_hold_items": 0,
            "last_cleanup": None,
            "auto_cleanup_enabled": True,
        }

    # ------------------------------------------------------------------
    # Data Rectification (Article 16)
    # ------------------------------------------------------------------

    # Allowlist of user-writable fields for rectification requests.
    # Consumer projects may extend this; keep it minimal in the base package.
    _RECTIFIABLE_FIELDS = frozenset(
        [
            "first_name",
            "last_name",
            "email",
        ]
    )

    @staticmethod
    def rectify_data(user, validated_data, request):
        """
        Apply a GDPR Article 16 rectification request.

        Only fields present in ``_RECTIFIABLE_FIELDS`` are processed;
        unknown keys are collected and returned as warnings.
        """
        fields = validated_data.get("fields", {})
        reason = validated_data.get("reason", "")

        applied = {}
        skipped = {}

        for field, new_value in fields.items():
            if field in GDPRService._RECTIFIABLE_FIELDS:
                setattr(user, field, new_value)
                applied[field] = new_value
            else:
                skipped[field] = "field not rectifiable via this endpoint"

        if applied:
            user.save(update_fields=list(applied.keys()))

        AuditLog.log_from_request(
            request,
            event_type="security_event",
            description="GDPR data rectification request",
            risk_level="medium",
            metadata={
                "applied_fields": list(applied.keys()),
                "skipped_fields": list(skipped.keys()),
                "reason": reason,
            },
        )

        return {
            "status": "completed",
            "applied": applied,
            "skipped": skipped,
            "message": str(_("Data rectification completed.")),
        }

    # ------------------------------------------------------------------
    # Processing Restriction (Article 18)
    # ------------------------------------------------------------------

    @staticmethod
    def restrict_processing(user, validated_data, request):
        """
        Apply a GDPR Article 18 processing restriction for *user*.

        Creates or updates the user's ``PrivacyProfile`` and logs the action.
        """
        from .models import PrivacyProfile

        reason = validated_data.get("reason", "")
        profile, _created = PrivacyProfile.objects.get_or_create(user=user)

        if profile.processing_restricted:
            return {
                "status": "already_restricted",
                "message": str(_("Processing is already restricted for this account.")),
                "restricted_at": profile.processing_restricted_at.isoformat()
                if profile.processing_restricted_at
                else None,
            }

        profile.restrict_processing()

        AuditLog.log_from_request(
            request,
            event_type="security_event",
            description="GDPR processing restriction applied",
            risk_level="medium",
            metadata={"reason": reason},
        )

        return {
            "status": "restricted",
            "restricted_at": profile.processing_restricted_at.isoformat(),
            "message": str(_("Data processing has been restricted for your account.")),
        }

    @staticmethod
    def lift_restriction(user, request):
        """
        Lift an existing GDPR Article 18 processing restriction.

        No-op (with informative response) if no restriction is active.
        """
        from .models import PrivacyProfile

        profile, _created = PrivacyProfile.objects.get_or_create(user=user)

        if not profile.processing_restricted:
            return {
                "status": "not_restricted",
                "message": str(_("No active processing restriction found for this account.")),
            }

        profile.lift_processing_restriction()

        AuditLog.log_from_request(
            request,
            event_type="security_event",
            description="GDPR processing restriction lifted",
            risk_level="medium",
            metadata={},
        )

        return {
            "status": "lifted",
            "message": str(_("Data processing restriction has been lifted.")),
        }
