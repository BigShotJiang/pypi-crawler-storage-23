"""
Custom storage backends.

- Base64DatabaseStorage: Store images as Base64 encoded strings in the database
  (for cloud deployment with ephemeral storage)

- OptimizedImageStorage: Store files on external USB drive with automatic
  image optimization, thumbnail generation, and EXIF handling
  (for self-hosted Raspberry Pi deployment)

- ExternalDriveStorage: Simple file storage on external USB drive without
  optimization (for documents, exports, etc.)
"""

import base64
import binascii
import logging
import os
from io import BytesIO

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.core.files.base import ContentFile
from django.core.files.storage import FileSystemStorage, Storage
from django.utils.deconstruct import deconstructible

try:
    from PIL import Image

    _PIL_AVAILABLE = True
except ImportError:
    Image = None  # type: ignore[assignment]
    _PIL_AVAILABLE = False

logger = logging.getLogger(__name__)


@deconstructible
class Base64DatabaseStorage(Storage):
    """
    Store files as Base64 encoded strings in the database.

    This storage backend is perfect for platforms with ephemeral storage
    like Railway, where file system changes don't persist across deployments.

    The actual Base64 data is stored in the model's field itself.
    """

    def __init__(self, location=None):
        self.location = location or ""

    def _open(self, name, mode="rb"):
        """
        Open a file from Base64 string.
        The 'name' parameter contains the Base64 encoded data.
        """
        if not name or name.startswith("data:"):
            # Already a data URL, extract the base64 part
            if "," in name:
                name = name.split(",", 1)[1]

        try:
            file_data = base64.b64decode(name)
            return ContentFile(file_data)
        except binascii.Error:
            return ContentFile(b"")

    def _save(self, name, content):
        """
        Save file by converting it to Base64.
        Returns the Base64 string (not a filename).
        """
        # Read the file content
        if hasattr(content, "read"):
            file_content = content.read()
        else:
            file_content = content

        # Encode to Base64
        encoded = base64.b64encode(file_content).decode("utf-8")

        # Return Base64 string with data URL prefix for easy browser rendering
        # Format: data:image/jpeg;base64,<encoded_data>
        content_type = self._get_content_type(name)
        return f"data:{content_type};base64,{encoded}"

    def _get_content_type(self, name):
        """Get content type based on file extension."""
        name_lower = name.lower()
        _MIME_MAP = {
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".svg": "image/svg+xml",
            ".pdf": "application/pdf",
            ".csv": "text/csv",
            ".txt": "text/plain",
            ".json": "application/json",
            ".zip": "application/zip",
        }
        for ext, mime in _MIME_MAP.items():
            if name_lower.endswith(ext):
                return mime
        return "application/octet-stream"  # safe generic binary default

    def delete(self, name):
        """
        Delete a file. For Base64 storage, this is a no-op
        as the data is in the database field itself.
        """
        pass

    def exists(self, name):
        """
        Check if a file exists.
        For Base64 storage, if name is provided, it exists.
        """
        return bool(name)

    def listdir(self, path):
        """
        List directory contents.
        Not applicable for Base64 storage.
        """
        return [], []

    def size(self, name):
        """
        Return the size of the Base64 encoded data.
        """
        if not name:
            return 0

        # Remove data URL prefix if present
        if name.startswith("data:"):
            name = name.split(",", 1)[1] if "," in name else name

        # Base64 encoded size is roughly 4/3 of original
        # Decode to get actual size
        try:
            decoded = base64.b64decode(name)
            return len(decoded)
        except binascii.Error:
            return 0

    def url(self, name):
        """
        Return the URL for accessing the file.
        For Base64, we return the data URL directly.
        """
        if not name:
            return ""

        # If already a data URL, return as is
        if name.startswith("data:"):
            return name

        # Otherwise, construct data URL
        content_type = "image/jpeg"  # Default
        return f"data:{content_type};base64,{name}"

    def get_accessed_time(self, name):
        """Not applicable for Base64 storage."""
        return None

    def get_created_time(self, name):
        """Not applicable for Base64 storage."""
        return None

    def get_modified_time(self, name):
        """Not applicable for Base64 storage."""
        return None


# ============================================================================
# BINARY DATABASE STORAGE (§4.8 — replaces base64 overhead)
# ============================================================================

#: Files above this threshold trigger a warning recommending cloud storage.
_BINARY_STORAGE_WARN_BYTES = 1 * 1024 * 1024  # 1 MB
#: Files above this threshold are refused with a ``ValueError``.
_BINARY_STORAGE_HARD_LIMIT_BYTES = 10 * 1024 * 1024  # 10 MB


@deconstructible
class BinaryDatabaseStorage(Storage):
    """Store raw binary blobs inside the database — no base64 encoding overhead.

    **Use only for small files** (thumbnails, avatars, small documents).  The
    library recommends using a dedicated object store (AWS S3, GCS, Cloudflare
    R2, MinIO, …) for anything over ~1 MB; see the DEPLOYMENT docs.

    **Migration from Base64DatabaseStorage:** Field values created by the old
    backend start with ``data:<mime>;base64,``.  ``_open`` transparently
    decodes those values so no data migration is needed for read operations.
    New writes always store raw bytes.

    Blob layout stored in the ``name`` field
    ----------------------------------------
    ``b"<mime_null><raw_bytes>"``

    Where ``<mime_null>`` is the MIME type followed by a null byte (``\\x00``)
    so the MIME can be recovered on read without a separate database column.
    When the MIME is unknown ``application/octet-stream`` is used.
    """

    def __init__(self, size_limit: int = _BINARY_STORAGE_HARD_LIMIT_BYTES) -> None:
        self._size_limit = size_limit

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _mime_for(name: str) -> str:
        """Return MIME type based on *name* extension."""
        _MIME_MAP = {
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".svg": "image/svg+xml",
            ".pdf": "application/pdf",
            ".csv": "text/csv",
            ".txt": "text/plain",
            ".json": "application/json",
            ".zip": "application/zip",
        }
        for ext, mime in _MIME_MAP.items():
            if name.lower().endswith(ext):
                return mime
        return "application/octet-stream"

    @staticmethod
    def _encode(mime: str, raw: bytes) -> bytes:
        """Pack mime + raw bytes into the stored blob format."""
        return mime.encode() + b"\x00" + raw

    @staticmethod
    def _decode(blob: bytes) -> tuple[str, bytes]:
        """Unpack the stored blob into ``(mime, raw_bytes)``."""
        sep = blob.find(b"\x00")
        if sep == -1:
            return "application/octet-stream", blob
        return blob[:sep].decode(errors="replace"), blob[sep + 1 :]

    # ------------------------------------------------------------------
    # Django Storage API
    # ------------------------------------------------------------------

    def _open(self, name: str, mode: str = "rb"):
        # Legacy: value from Base64DatabaseStorage starts with "data:"
        if isinstance(name, str) and name.startswith("data:"):
            # Decode base64 data URL
            try:
                _, b64 = name.split(",", 1)
                raw = base64.b64decode(b64)
            except Exception:
                raw = b""
            return ContentFile(raw)

        # Current format: bytes stored in field
        if isinstance(name, (bytes, memoryview)):
            blob = bytes(name)
            _mime, raw = self._decode(blob)
            return ContentFile(raw)

        # Fallback: treat as plain base64 or empty
        try:
            raw = base64.b64decode(name)
        except Exception:
            raw = b""
        return ContentFile(raw)

    def _save(self, name: str, content) -> bytes:
        raw: bytes = content.read() if hasattr(content, "read") else bytes(content)

        if len(raw) > self._size_limit:
            raise ValueError(
                f"File '{name}' is {len(raw):,} bytes which exceeds the "
                f"BinaryDatabaseStorage hard limit of {self._size_limit:,} bytes. "
                f"Use a cloud object store (S3/GCS/R2/MinIO) for large files. "
                f"See docs/DEPLOYMENT.md for guidance."
            )

        if len(raw) > _BINARY_STORAGE_WARN_BYTES:
            logger.warning(
                "BinaryDatabaseStorage: file '%s' is %s KB. Consider using a cloud object store for files > 1 MB.",
                name,
                len(raw) // 1024,
            )

        mime = self._mime_for(name)
        return self._encode(mime, raw)  # type: ignore[return-value]

    def delete(self, name) -> None:
        pass  # blob lives in the model field; field clear is caller's responsibility

    def exists(self, name) -> bool:
        return bool(name)

    def listdir(self, path):
        return [], []

    def size(self, name) -> int:
        if not name:
            return 0
        if isinstance(name, (bytes, memoryview)):
            blob = bytes(name)
            _mime, raw = self._decode(blob)
            return len(raw)
        # Legacy base64 string
        try:
            if isinstance(name, str) and name.startswith("data:"):
                _, b64 = name.split(",", 1)
                return len(base64.b64decode(b64))
            return len(base64.b64decode(name))
        except Exception:
            return 0

    def url(self, name) -> str:
        if not name:
            return ""
        if isinstance(name, (bytes, memoryview)):
            blob = bytes(name)
            mime, raw = self._decode(blob)
            encoded = base64.b64encode(raw).decode()
            return f"data:{mime};base64,{encoded}"
        # Already a data URL or legacy base64
        if isinstance(name, str) and name.startswith("data:"):
            return name
        return f"data:application/octet-stream;base64,{name}"

    def get_accessed_time(self, name):
        return None

    def get_created_time(self, name):
        return None

    def get_modified_time(self, name):
        return None


# ============================================================================
# EXTERNAL USB DRIVE STORAGE (Raspberry Pi Self-Hosted)
# ============================================================================


@deconstructible
class OptimizedImageStorage(FileSystemStorage):
    """
    Custom storage backend that:
    1. Stores files on external USB drive
    2. Automatically optimizes images on upload
    3. Generates multiple thumbnail sizes
    4. Preserves EXIF orientation
    5. Reduces storage space by ~70%

    Performance: Adds ~300ms to upload for optimization, but saves bandwidth on every view.
    """

    def __init__(self, location=None, base_url=None):
        """Initialize storage with external drive location."""
        if not _PIL_AVAILABLE:
            raise ImproperlyConfigured(
                "OptimizedImageStorage requires Pillow. Install it with: pip install 'nimoh-be-django-base[image]'"
            )
        # Use external drive location or fallback to settings
        location = location or getattr(settings, "MEDIA_ROOT", "/mnt/media/app-media")
        base_url = base_url or getattr(settings, "MEDIA_URL", "/media/")
        super().__init__(location=location, base_url=base_url)

        logger.info(f"OptimizedImageStorage initialized: {location}")

    def save(self, name, content, max_length=None):
        """
        Save file with automatic image optimization.

        For images: creates original, optimized version, and 3 thumbnail sizes.
        For other files: saves normally without processing.
        """
        # Detect if this is an image
        if self._is_image(name):
            try:
                return self._save_optimized_image(name, content, max_length)
            except (OSError, ValueError) as e:
                logger.error(f"Image optimization failed for {name}: {e}", exc_info=True)
                # Fallback to normal save if optimization fails
                return super().save(name, content, max_length)
        else:
            # Non-image files: save normally
            return super().save(name, content, max_length)

    def _is_image(self, filename):
        """Check if file is an image based on extension."""
        image_extensions = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff"}
        ext = os.path.splitext(filename)[1].lower()
        return ext in image_extensions

    def _save_optimized_image(self, name, content, max_length=None):
        """
        Save image with optimization:
        1. Save original in originals/ (95% quality)
        2. Create optimized version in optimized/ (85% quality)
        3. Generate thumbnails in thumbnails/{small,medium,large}/

        Returns the path to the optimized version (stored in database).
        """
        # Reset file pointer if needed
        if hasattr(content, "seek"):
            content.seek(0)

        # Read image
        try:
            image = Image.open(content)
            image.load()  # Force load to catch corrupted images
        except (OSError, SyntaxError) as e:
            logger.error(f"Failed to open image {name}: {e}")
            raise

        # Fix EXIF orientation
        image = self._fix_orientation(image)

        # Save original (slightly compressed to save space)
        original_path = f"profile_photos/originals/{name}"
        original_content = self._compress_image(image, quality=95)
        super().save(original_path, ContentFile(original_content), max_length)
        logger.debug(f"Saved original: {original_path}")

        # Save optimized version (more compression for web serving)
        optimized_path = f"profile_photos/optimized/{name}"
        optimized_content = self._compress_image(image, quality=85, max_size=(1920, 1920))
        super().save(optimized_path, ContentFile(optimized_content), max_length)
        logger.debug(f"Saved optimized: {optimized_path}")

        # Generate thumbnails
        self._generate_thumbnails(image, name)

        # Return optimized path (this is what gets stored in database)
        return optimized_path

    def _fix_orientation(self, image):
        """
        Fix image orientation based on EXIF data.

        Many phones save images with rotation in EXIF rather than actual pixels.
        This ensures images display correctly regardless of EXIF orientation.
        """
        try:
            from PIL import ExifTags

            # Get EXIF data
            exif = image._getexif() if hasattr(image, "_getexif") else None

            if exif:
                # Find orientation tag
                orientation_key = None
                for tag, value in ExifTags.TAGS.items():
                    if value == "Orientation":
                        orientation_key = tag
                        break

                if orientation_key and orientation_key in exif:
                    orientation = exif[orientation_key]

                    # Rotate based on orientation value
                    if orientation == 3:
                        image = image.rotate(180, expand=True)
                    elif orientation == 6:
                        image = image.rotate(270, expand=True)
                    elif orientation == 8:
                        image = image.rotate(90, expand=True)

                    logger.debug(f"Fixed orientation: {orientation}")
        except (AttributeError, KeyError, IndexError) as e:
            # No EXIF data or orientation tag, that's fine
            logger.debug(f"No EXIF orientation data: {e}")
        except Exception as e:
            # Log but don't fail on EXIF issues
            logger.warning(f"Error processing EXIF: {e}")

        return image

    def _compress_image(self, image, quality=85, max_size=None):
        """
        Compress image to reduce file size.

        Args:
            image: PIL Image object
            quality: JPEG quality (1-100, default 85)
            max_size: Tuple (width, height) to resize to, or None to keep original size

        Returns:
            Bytes of compressed JPEG image
        """
        # Make a copy to avoid modifying original
        img = image.copy()

        # Resize if max_size specified
        if max_size:
            img.thumbnail(max_size, Image.Resampling.LANCZOS)

        # Convert to RGB if needed (JPEG doesn't support transparency)
        if img.mode in ("RGBA", "LA", "P"):
            # Create white background
            background = Image.new("RGB", img.size, (255, 255, 255))

            # Convert palette images to RGBA first
            if img.mode == "P":
                img = img.convert("RGBA")

            # Paste image on white background
            if img.mode in ("RGBA", "LA"):
                background.paste(img, mask=img.split()[-1])  # Use alpha channel as mask
            else:
                background.paste(img)

            img = background
        elif img.mode != "RGB":
            img = img.convert("RGB")

        # Save to bytes with optimization
        output = BytesIO()
        img.save(
            output,
            format="JPEG",
            quality=quality,
            optimize=True,  # Enable JPEG optimization
            progressive=True,  # Progressive JPEG for better web loading
        )
        output.seek(0)

        return output.read()

    def _generate_thumbnails(self, image, name):
        """
        Generate multiple thumbnail sizes.

        Creates 3 sizes:
        - small: 150x150 (for lists, previews)
        - medium: 300x300 (for cards, medium displays)
        - large: 600x600 (for modals, detailed views)
        """
        thumbnail_sizes = {
            "small": (150, 150),
            "medium": (300, 300),
            "large": (600, 600),
        }

        for size_name, (width, height) in thumbnail_sizes.items():
            try:
                # Create thumbnail
                thumb = image.copy()
                thumb.thumbnail((width, height), Image.Resampling.LANCZOS)

                # Save thumbnail with good compression
                thumb_path = f"profile_photos/thumbnails/{size_name}/{name}"
                thumb_content = self._compress_image(thumb, quality=80)
                super().save(thumb_path, ContentFile(thumb_content))

                logger.debug(f"Generated {size_name} thumbnail: {thumb_path}")
            except (OSError, ValueError) as e:
                logger.error(f"Failed to generate {size_name} thumbnail for {name}: {e}")


@deconstructible
class ExternalDriveStorage(FileSystemStorage):
    """
    Simple storage backend for non-image files (documents, exports).

    Stores files on external USB drive without optimization.
    Use this for documents, PDFs, exports, etc.
    """

    def __init__(self, location=None, base_url=None):
        """Initialize storage with external drive location."""
        location = location or getattr(settings, "MEDIA_ROOT", "/mnt/media/app-media")
        base_url = base_url or getattr(settings, "MEDIA_URL", "/media/")
        super().__init__(location=location, base_url=base_url)

        logger.info(f"ExternalDriveStorage initialized: {location}")
