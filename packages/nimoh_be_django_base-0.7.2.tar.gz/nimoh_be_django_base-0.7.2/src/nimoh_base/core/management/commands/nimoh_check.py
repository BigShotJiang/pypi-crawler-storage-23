"""
Management command: nimoh_check
================================

Runs all ``nimoh_base``-tagged Django system checks and reports the results
in a human-friendly format.  This is a thin wrapper around the built-in
Django check framework; it is equivalent to::

    ./manage.py check --tag nimoh_base

but provides:

- Colour-coded PASS / WARNING / ERROR output.
- A summary line with counts.
- A non-zero exit code when errors are present (CI-friendly).
- Coverage of *only* nimoh-base checks, so noise from third-party apps is
  excluded.

Usage::

    ./manage.py nimoh_check
    ./manage.py nimoh_check --fail-level WARNING   # exit non-zero on warnings too
    ./manage.py nimoh_check --deploy                # include deployment checks
"""

import sys

from django.core.checks import ERROR, WARNING, run_checks
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Run nimoh-base system checks (nimoh_base tag) and report results."

    # Disable Django's automatic system-check run so we fully own the output
    # and don't print the same findings twice.
    requires_system_checks: list = []

    def add_arguments(self, parser):
        parser.add_argument(
            "--fail-level",
            default="ERROR",
            choices=["WARNING", "ERROR", "CRITICAL"],
            help=(
                "Minimum message level that causes a non-zero exit code. "
                "Default: ERROR.  Use WARNING to also fail on warnings (strict mode)."
            ),
        )
        parser.add_argument(
            "--deploy",
            action="store_true",
            default=False,
            help="Include Django deployment checks in addition to nimoh_base checks.",
        )

    def handle(self, *args, **options):
        fail_level_name = options["fail_level"]
        include_deployment = options["deploy"]

        # Resolve the integer level threshold
        _level_map = {"WARNING": WARNING, "ERROR": ERROR, "CRITICAL": 50}
        fail_level = _level_map.get(fail_level_name, ERROR)

        # Collect checks
        tags = ["nimoh_base"]
        if include_deployment:
            tags.append("security")  # Django's built-in deployment checks

        messages = run_checks(tags=tags)

        if not messages:
            self.stdout.write(self.style.SUCCESS("✔  All nimoh_base checks passed."))
            return

        # Sort: errors first, then warnings
        messages.sort(key=lambda m: m.level, reverse=True)

        errors = [m for m in messages if m.level >= ERROR]
        warnings = [m for m in messages if WARNING <= m.level < ERROR]
        notices = [m for m in messages if m.level < WARNING]

        for msg in messages:
            if msg.level >= ERROR:
                label = self.style.ERROR(f"ERROR   [{msg.id}]")
            elif msg.level >= WARNING:
                label = self.style.WARNING(f"WARNING [{msg.id}]")
            else:
                label = self.style.NOTICE(f"INFO    [{msg.id}]")

            self.stdout.write(f"{label}  {msg.msg}")
            if msg.hint:
                hint_prefix = self.style.HTTP_INFO("  HINT:")
                self.stdout.write(f"{hint_prefix} {msg.hint}")
            self.stdout.write("")

        # Summary line
        parts = []
        if errors:
            parts.append(self.style.ERROR(f"{len(errors)} error(s)"))
        if warnings:
            parts.append(self.style.WARNING(f"{len(warnings)} warning(s)"))
        if notices:
            parts.append(self.style.NOTICE(f"{len(notices)} notice(s)"))

        self.stdout.write("─" * 62)
        self.stdout.write(f"nimoh_check summary: {', '.join(parts)}")

        # Exit non-zero when messages meet or exceed the fail level
        worst = max(m.level for m in messages)
        if worst >= fail_level:
            sys.exit(1)
