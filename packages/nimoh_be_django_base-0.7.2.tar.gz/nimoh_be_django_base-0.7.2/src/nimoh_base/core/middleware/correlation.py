"""
Correlation ID Middleware
=========================

Sets ``request.correlation_id`` to the value of the incoming
``X-Request-ID`` or ``X-Correlation-ID`` header, or generates a new
UUID4 when neither header is present.

The ID is echoed back in the ``X-Correlation-ID`` response header so
that clients and upstream proxies can correlate their records with
server-side structured logs.

Position in ``MIDDLEWARE``: before ``ErrorHandlingMiddleware`` (and
ideally as early as possible) so that every subsequent middleware,
view, and the error handler always find a populated
``request.correlation_id``.
"""

import uuid

from django.utils.deprecation import MiddlewareMixin


class CorrelationIdMiddleware(MiddlewareMixin):
    """
    Propagate or generate a per-request correlation ID.

    Resolution order:

    1. ``X-Request-ID`` request header (set by nginx, API gateways, etc.)
    2. ``X-Correlation-ID`` request header (set by some legacy clients)
    3. A freshly generated ``uuid.uuid4()``

    The resolved value is:

    * Stored on ``request.correlation_id`` for use by logging formatters
      and error handlers throughout the request lifecycle.
    * Returned in the ``X-Correlation-ID`` response header so callers
      can match requests to log lines.

    Security note: incoming header values are truncated to 128 chars to
    prevent log injection via abnormally long IDs.
    """

    _REQUEST_HEADERS = ("HTTP_X_REQUEST_ID", "HTTP_X_CORRELATION_ID")

    def process_request(self, request):
        for header in self._REQUEST_HEADERS:
            value = request.META.get(header, "").strip()
            if value:
                # Truncate to guard against log injection.
                request.correlation_id = value[:128]
                return None
        request.correlation_id = str(uuid.uuid4())
        return None

    def process_response(self, request, response):
        correlation_id = getattr(request, "correlation_id", None)
        if correlation_id:
            response["X-Correlation-ID"] = correlation_id
        return response
