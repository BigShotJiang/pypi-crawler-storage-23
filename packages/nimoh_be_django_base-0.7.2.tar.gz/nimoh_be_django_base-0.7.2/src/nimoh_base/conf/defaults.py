"""
nimoh_base.conf.defaults
========================
Typed default values for the ``NIMOH_BASE`` dict.

Consumers can import and merge these so their settings files always stay
up-to-date with new keys added in future package versions::

    from nimoh_base.conf.defaults import NIMOH_BASE_DEFAULTS

    NIMOH_BASE = {
        **NIMOH_BASE_DEFAULTS,
        # Override with project-specific values:
        'SITE_NAME': 'My Application',
        'SUPPORT_EMAIL': 'support@myapp.com',
        'NOREPLY_EMAIL': 'noreply@myapp.com',
    }

Note: ``SITE_NAME``, ``SUPPORT_EMAIL``, and ``NOREPLY_EMAIL`` are **required**
— they have no meaningful default and will raise ``ImproperlyConfigured``
at startup if not set.  They are included here only as documentation markers.
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────────
# NIMOH_BASE key reference
#
# Each entry documents:
#   key          — The NIMOH_BASE dict key
#   type         — Expected Python type
#   required     — True if omitting the key raises ImproperlyConfigured
#   default      — Effective default when key is absent (required keys: None)
#   description  — What the setting controls in package code
# ─────────────────────────────────────────────────────────────────────────────

NIMOH_BASE_SCHEMA: list[dict] = [
    {
        "key": "SITE_NAME",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            "Human-readable application name. Used in all outbound emails "
            "(subject lines, greetings) and in error messages."
        ),
    },
    {
        "key": "SUPPORT_EMAIL",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            "Support contact email address embedded in password-reset, email verification, and GDPR data-export emails."
        ),
    },
    {
        "key": "NOREPLY_EMAIL",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            'The "From" address for all system-generated outbound emails. '
            "Typically something like 'noreply@myapp.com'."
        ),
    },
    {
        "key": "SERVER_HEADER",
        "type": str,
        "required": False,
        "default": "",
        "description": (
            "Value for the HTTP ``Server`` response header set by "
            "``SecurityHeadersMiddleware``. An empty string suppresses the "
            "header entirely (recommended for production)."
        ),
    },
    {
        "key": "PASSWORD_CHECKER_USER_AGENT",
        "type": str,
        "required": False,
        "default": "Django-Password-Validator",
        "description": ("User-Agent string sent to the HaveIBeenPwned k-anonymity API during password breach checks."),
    },
    {
        "key": "CELERY_APP_NAME",
        "type": str,
        "required": False,
        "default": "django-app",
        "description": (
            "Celery application name string (the first arg to ``Celery(...)``). "
            "Used by ``nimoh_base.conf.celery.make_celery()``."
        ),
    },
    {
        "key": "CACHE_KEY_PREFIX",
        "type": str,
        "required": False,
        "default": "app",
        "description": (
            "Prefix applied to every Redis cache key so multiple projects "
            "can share a Redis instance without key collisions."
        ),
    },
    {
        "key": "MOBILE_APP_IDENTIFIERS",
        "type": list,  # list[str]
        "required": False,
        "default": [],
        "description": (
            "Additional User-Agent substrings recognised as mobile clients by "
            "``MobileDetectionMiddleware`` / ``is_mobile_request()``.  The "
            "package always recognises ``react-native``, ``expo``, and "
            "``mobile-app`` regardless of this setting."
        ),
    },
    {
        "key": "ENABLE_MONITORING_PERSISTENCE",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "When ``True``, ``PerformanceMonitoringMiddleware`` writes "
            "per-request metrics to the ``PerformanceMetric`` / "
            "``EndpointMetrics`` database tables.  Disable in high-traffic "
            "environments and rely on time-series exports instead."
        ),
    },
    {
        "key": "HEALTH_CHECK_CELERY",
        "type": bool,
        "required": False,
        "default": True,
        "description": (
            "When ``False``, the Celery worker ping is skipped in "
            "``/api/v1/health/``.  Useful when running without a Celery "
            "worker (e.g. local dev, CI)."
        ),
    },
    {
        "key": "MAX_LOGIN_ATTEMPTS",
        "type": int,
        "required": False,
        "default": 5,
        "description": (
            "Maximum number of consecutive failed login attempts before "
            "``AbstractNimohUser.lock_account()`` is called automatically."
        ),
    },
    {
        "key": "ACCOUNT_LOCK_DURATION_MINUTES",
        "type": int,
        "required": False,
        "default": 30,
        "description": (
            "How long (in minutes) an account stays locked after exceeding "
            "``MAX_LOGIN_ATTEMPTS``.  The lock is lifted automatically once "
            "this duration has elapsed."
        ),
    },
    {
        "key": "SECURITY_SCRUB_PII",
        "type": bool,
        "required": False,
        "default": True,
        "description": (
            "When ``True`` (default), ``SecurityHeadersMiddleware`` applies regex-based PII "
            "scrubbing (emails, phone numbers, SSNs) to non-documentation JSON/XML response "
            "bodies. If your API legitimately returns PII to authenticated callers "
            "(e.g. ``GET /me/`` returns the user's email) you must set this to ``False`` "
            "or the response will be broken. Log-level scrubbing via ``SensitiveDataFilter`` "
            "is always active regardless of this setting."
        ),
    },
    {
        "key": "BREACH_CHECK_FAIL_OPEN",
        "type": bool,
        "required": False,
        "default": True,
        "description": (
            "Controls behaviour when the HaveIBeenPwned k-anonymity API is unreachable "
            "during password validation.  When ``True`` (default) the check silently passes "
            "so user registration is never blocked by external API downtime.  Set to "
            "``False`` in high-security environments to reject password changes when the "
            "breach check cannot be completed."
        ),
    },
    {
        "key": "FORCE_HTTPS",
        "type": bool,
        "required": False,
        "default": True,
        "description": (
            "When ``True`` (default) and ``DEBUG=False``, "
            "``HTTPSRedirectMiddleware`` issues a permanent (301) redirect for all "
            "plain-HTTP requests.  Has no effect when ``DEBUG=True`` to avoid "
            "breaking local development.  Set to ``False`` when HTTPS termination "
            "is handled upstream (e.g. by a load-balancer or Nginx) and Django "
            "never receives direct HTTPS connections."
        ),
    },
    {
        "key": "PUBLIC_MEDIA_CACHE",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "When ``True``, ``MediaSecurityMiddleware`` sets "
            "``Cache-Control: public, max-age=31536000, immutable`` on media responses. "
            "Defaults to ``False`` (``Cache-Control: private, no-store``) to prevent "
            "private user-uploaded files from being served from shared/public caches. "
            "Only enable if ALL files under ``MEDIA_URL`` are publicly accessible."
        ),
    },
    {
        "key": "AUDIT_LOG_RETENTION_DAYS",
        "type": int,
        "required": False,
        "default": 365,
        "description": (
            "How many days of ``AuditLog`` rows to keep.  The "
            "``cleanup_old_audit_logs`` Celery task deletes rows older than this "
            "threshold.  One year is the recommended minimum for compliance "
            "auditing.  Set to ``0`` to disable automatic pruning (not recommended "
            "for high-traffic sites where the table would grow unbounded)."
        ),
    },
    {
        "key": "MONITORING_RETENTION_DAYS",
        "type": int,
        "required": False,
        "default": 30,
        "description": (
            "How many days of monitoring rows (``PerformanceMetric``, "
            "``HealthCheck``, ``EndpointMetrics``) to keep. "
            "The ``cleanup_monitoring_metrics`` Celery beat task prunes rows "
            "older than this window every Sunday at 03:00 UTC."
        ),
    },
    {
        "key": "DATA_RETENTION_INACTIVE_DAYS",
        "type": int,
        "required": False,
        "default": 730,
        "description": (
            "Days of inactivity after which accounts that have opted into "
            "automatic data retention enforcement "
            "(``PrivacyProfile.auto_delete_inactive_data = True``) are anonymised "
            "by the ``enforce_data_retention`` Celery beat task. "
            "Defaults to 730 days (2 years).  Inactivity is measured from "
            "the later of ``last_login`` and ``date_joined``."
        ),
    },
    {
        "key": "GDPR_EXPORT_MAX_ROWS",
        "type": int,
        "required": False,
        "default": 1000,
        "description": (
            "Maximum number of ``AuditLog`` rows included in a user's GDPR data export "
            "(Article 20 — Right to Data Portability). Raising this limit increases export "
            "file size and memory usage; lower it in high-traffic systems with dense audit "
            "logs. The rows returned are always the most recent ones."
        ),
    },
    {
        "key": "SHOW_BANNER",
        "type": bool,
        "required": False,
        "default": None,  # None → auto: True when DEBUG=True, False in production
        "description": (
            "Controls whether the ASCII startup banner is printed to stdout when "
            "``run_startup_checks()`` is called.  ``None`` (default) means *auto*: "
            "the banner is shown when ``DEBUG=True`` and suppressed otherwise, so it "
            "never pollutes structured JSON logs in production.  Set explicitly to "
            "``True`` or ``False`` to override the auto behaviour."
        ),
    },
    {
        "key": "TWO_FACTOR_ENABLED",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "Master switch for TOTP two-factor authentication.  When ``True`` the "
            "``/auth/2fa/`` endpoints are active and users who have completed the "
            "TOTP setup flow will be required to present a valid TOTP code on every "
            "login.  When ``False`` (default) the 2FA machinery exists in the DB but "
            "login always issues tokens after the first factor (password), regardless "
            "of the per-user ``two_factor_enabled`` flag.  Install the ``[2fa]`` "
            "extra (``django-otp``) if you enable this setting."
        ),
    },
    {
        "key": "METRICS_ENABLED",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "Enable the ``GET /monitoring/prometheus/`` endpoint that returns "
            "application metrics in Prometheus text exposition format.  Requires "
            "``prometheus-client`` (install the ``[monitoring]`` extra).  "
            "The endpoint returns ``503`` with instructions when this is ``False``."
        ),
    },
    {
        "key": "METRICS_AUTH_REQUIRED",
        "type": bool,
        "required": False,
        "default": True,
        "description": (
            "When ``True`` (default) the Prometheus metrics endpoint requires "
            "``IsAdminUser`` authentication.  Set to ``False`` only when the "
            "endpoint is protected at the network / ingress level."
        ),
    },
    {
        "key": "SOCIAL_AUTH_ENABLED",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "Enable social / OAuth2 login via ``social-auth-app-django``.  "
            "Requires the ``[social]`` extra.  When ``True`` the package "
            "wires ``AUTHENTICATION_BACKENDS`` and the ``/auth/social/`` URL "
            "namespace into the project's auth URLs."
        ),
    },
    {
        "key": "EMAIL_CHANGE_EXPIRY_HOURS",
        "type": int,
        "required": False,
        "default": 24,
        "description": ("Number of hours before an email-change confirmation token expires. Default 24 hours."),
    },
    {
        "key": "PROFILE_MODEL",
        "type": str,
        "required": False,
        "default": None,
        "description": (
            "Dotted ``app_label.ModelName`` path to the consumer project's user-profile model "
            "(e.g. ``'profiles.UserProfileBasic'``).  Required when using "
            "``GDPRService.get_privacy_dashboard()`` and other profile-aware GDPR helpers. "
            "The model is resolved lazily via ``django.apps.apps.get_model()`` so it may be "
            "defined in any installed app; configure it after all ``INSTALLED_APPS`` are loaded. "
            "Leave as ``None`` (default) if your project does not use the profile dashboard."
        ),
    },
]

# ── Convenience: default values dict (required keys excluded) ─────────────────

NIMOH_BASE_DEFAULTS: dict[str, object] = {
    entry["key"]: entry["default"] for entry in NIMOH_BASE_SCHEMA if not entry["required"]
}
"""
Dict of all **optional** ``NIMOH_BASE`` keys with their default values.

Merge this into your project settings and then override as needed::

    from nimoh_base.conf.defaults import NIMOH_BASE_DEFAULTS

    NIMOH_BASE = {
        **NIMOH_BASE_DEFAULTS,
        'SITE_NAME': 'My App',
        'SUPPORT_EMAIL': 'support@myapp.com',
        'NOREPLY_EMAIL': 'noreply@myapp.com',
    }
"""

# ── Convenience: set of required key names ───────────────────────────────────

NIMOH_BASE_REQUIRED_KEYS: frozenset[str] = frozenset(entry["key"] for entry in NIMOH_BASE_SCHEMA if entry["required"])
"""Frozenset of keys that raise ``ImproperlyConfigured`` when missing."""
