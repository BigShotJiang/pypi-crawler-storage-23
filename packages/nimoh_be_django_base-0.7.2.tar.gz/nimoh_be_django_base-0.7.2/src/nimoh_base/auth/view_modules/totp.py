"""
TOTP two-factor authentication views.

Endpoints
---------
POST   /auth/2fa/setup/               begin_setup_view
POST   /auth/2fa/confirm/             confirm_setup_view
POST   /auth/2fa/verify/              verify_view  (login completion)
POST   /auth/2fa/backup-codes/regenerate/  regenerate_backup_codes_view
DELETE /auth/2fa/disable/             disable_view
"""

import logging

from django.utils.translation import gettext_lazy as _
from drf_spectacular.utils import OpenApiResponse, extend_schema
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from nimoh_base.core.api_tags import APITags
from nimoh_base.core.exceptions import ProblemDetailException
from nimoh_base.core.throttling import AuthenticationRateThrottle

from ..serializers import (
    BackupCodesResponseSerializer,
    TOTPConfirmSerializer,
    TOTPDisableSerializer,
    TOTPSetupResponseSerializer,
    TOTPVerifySerializer,
)
from ..services import AuthenticationService, TwoFactorService
from ..utils.cookies import set_refresh_token_cookie
from ..utils.mobile import is_mobile_client

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────────────────────────────────────


@extend_schema(
    operation_id="auth_2fa_setup",
    summary="Begin TOTP 2FA setup",
    description=(
        "Generates a new TOTP secret and provisioning URI for the authenticated user. "
        "The secret is stored as an **unconfirmed** device until "
        "``POST /auth/2fa/confirm/`` is called with a valid code.\n\n"
        "Calling this endpoint again before confirming will replace the pending device."
    ),
    request=None,
    responses={
        200: TOTPSetupResponseSerializer,
        400: OpenApiResponse(description="2FA is already enabled"),
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def begin_setup_view(request):
    """Return a TOTP provisioning URI so the user can add their account to an
    authenticator app.  Does *not* enable 2FA until ``/confirm/`` succeeds."""
    user = request.user

    if getattr(user, "two_factor_enabled", False):
        raise ProblemDetailException(
            title="2FA already enabled",
            detail=_("Two-factor authentication is already enabled on this account."),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="2fa_already_enabled",
        )

    data = TwoFactorService.begin_setup(user)
    return Response(
        {"secret": data["secret"], "otpauth_uri": data["otpauth_uri"]},
        status=status.HTTP_200_OK,
    )


@extend_schema(
    operation_id="auth_2fa_confirm",
    summary="Confirm TOTP 2FA setup",
    description=(
        "Verify the TOTP code from the authenticator app to confirm the pending "
        "device and **enable** 2FA on the account.  Returns 8 single-use backup "
        "codes — display them to the user immediately, they are never shown again."
    ),
    request=TOTPConfirmSerializer,
    responses={
        200: BackupCodesResponseSerializer,
        400: OpenApiResponse(description="Invalid TOTP code or no pending setup"),
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def confirm_setup_view(request):
    """Confirm the pending setup and return plain-text backup codes."""
    serializer = TOTPConfirmSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        backup_codes = TwoFactorService.confirm_setup(request.user, serializer.validated_data["code"])
    except ValueError as exc:
        raise ProblemDetailException(
            title="TOTP confirmation failed",
            detail=str(exc),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="totp_confirm_failed",
        )

    return Response({"backup_codes": backup_codes}, status=status.HTTP_200_OK)


# ─────────────────────────────────────────────────────────────────────────────
# Login completion (verify)
# ─────────────────────────────────────────────────────────────────────────────


@extend_schema(
    operation_id="auth_2fa_verify",
    summary="Complete login with TOTP code",
    description=(
        "Exchange a ``challenge_token`` (from the ``202`` login response) plus a "
        "6-digit TOTP code (or backup code) for full JWT access / refresh tokens.\n\n"
        "The challenge token is single-use and expires in 5 minutes."
    ),
    request=TOTPVerifySerializer,
    responses={
        200: OpenApiResponse(description="Login completed — access token in body, refresh token in httpOnly cookie"),
        400: OpenApiResponse(description="Invalid TOTP code or expired challenge"),
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([AllowAny])
def verify_view(request):
    """Complete a 2FA login by verifying the TOTP code."""
    throttle = AuthenticationRateThrottle()
    if not throttle.allow_request(request, verify_view):
        raise ProblemDetailException(
            title="Rate limit exceeded",
            detail=_("Too many verification attempts. Please try again later."),
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            code="rate_limit_exceeded",
        )

    serializer = TOTPVerifySerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        auth_data = AuthenticationService.complete_two_factor_login(
            challenge_token=serializer.validated_data["challenge_token"],
            code=serializer.validated_data["code"],
            request=request,
            device_name=serializer.validated_data.get("device_name", "Unknown Device"),
            device_fingerprint=serializer.validated_data.get("device_fingerprint", ""),
            remember_me=serializer.validated_data.get("remember_me", False),
        )
    except ValueError as exc:
        raise ProblemDetailException(
            title="2FA verification failed",
            detail=str(exc),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="totp_verify_failed",
        )

    user = auth_data["user"]
    response_data = {
        "access_token": auth_data["access_token"],
        "expires_in": auth_data["expires_in"],
        "token_type": auth_data["token_type"],
        "user": {
            "id": str(user.id),
            "email": user.email,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "email_verified": user.email_verified,
        },
    }

    remember_me = serializer.validated_data.get("remember_me", False)
    max_age = 14 * 24 * 60 * 60 if remember_me else 7 * 24 * 60 * 60

    if is_mobile_client(request):
        response_data["refresh_token"] = auth_data["refresh_token"]
        return Response(response_data, status=status.HTTP_200_OK)

    response = Response(response_data, status=status.HTTP_200_OK)
    return set_refresh_token_cookie(response, auth_data["refresh_token"], max_age=max_age)


# ─────────────────────────────────────────────────────────────────────────────
# Backup codes
# ─────────────────────────────────────────────────────────────────────────────


@extend_schema(
    operation_id="auth_2fa_regenerate_backup_codes",
    summary="Regenerate backup codes",
    description=(
        "Invalidates all existing backup codes and returns 8 fresh ones. "
        "Requires the user to be authenticated and 2FA to be enabled."
    ),
    request=None,
    responses={
        200: BackupCodesResponseSerializer,
        400: OpenApiResponse(description="2FA is not enabled"),
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def regenerate_backup_codes_view(request):
    """Regenerate backup codes for the authenticated user."""
    if not getattr(request.user, "two_factor_enabled", False):
        raise ProblemDetailException(
            title="2FA not enabled",
            detail=_("Two-factor authentication is not enabled on this account."),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="2fa_not_enabled",
        )

    codes = TwoFactorService.regenerate_backup_codes(request.user)
    return Response({"backup_codes": codes}, status=status.HTTP_200_OK)


# ─────────────────────────────────────────────────────────────────────────────
# Disable
# ─────────────────────────────────────────────────────────────────────────────


@extend_schema(
    operation_id="auth_2fa_disable",
    summary="Disable 2FA",
    description=(
        "Disable two-factor authentication on the account.  "
        "Requires a valid TOTP code or backup code to confirm intent."
    ),
    request=TOTPDisableSerializer,
    responses={
        200: OpenApiResponse(description="2FA disabled successfully"),
        400: OpenApiResponse(description="Invalid code or 2FA not enabled"),
    },
    tags=[APITags.AUTHENTICATION],
)
@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def disable_view(request):
    """Disable 2FA for the authenticated user."""
    if not getattr(request.user, "two_factor_enabled", False):
        raise ProblemDetailException(
            title="2FA not enabled",
            detail=_("Two-factor authentication is not enabled on this account."),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="2fa_not_enabled",
        )

    serializer = TOTPDisableSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        TwoFactorService.disable(request.user, serializer.validated_data["code"])
    except ValueError as exc:
        raise ProblemDetailException(
            title="2FA disable failed",
            detail=str(exc),
            status_code=status.HTTP_400_BAD_REQUEST,
            code="totp_disable_failed",
        )

    return Response(
        {"message": "Two-factor authentication has been disabled."},
        status=status.HTTP_200_OK,
    )
