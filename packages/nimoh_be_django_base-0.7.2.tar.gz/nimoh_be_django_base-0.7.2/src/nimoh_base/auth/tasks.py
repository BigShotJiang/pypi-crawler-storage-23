"""
Celery tasks for authentication app.

Background tasks for:
- Cleaning up expired tokens
- Cleaning up expired sessions
- Security maintenance
"""

import logging
import smtplib
from datetime import timedelta

from celery import shared_task
from django.db.utils import DatabaseError
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def cleanup_expired_tokens(self):
    """
    Delete expired authentication tokens.

    Runs daily at 1am via Celery Beat.
    Removes expired tokens to prevent database bloat:
    - Blacklisted JWT tokens
    - Password reset tokens
    - Email verification tokens

    Returns:
        dict: Summary of deleted tokens
    """
    try:
        from .models import EmailVerificationToken, PasswordResetToken, TokenBlacklist

        cutoff_date = timezone.now()

        # Delete expired blacklisted tokens
        deleted_blacklist = TokenBlacklist.objects.filter(expires_at__lt=cutoff_date).delete()[0]

        # Delete expired password reset tokens
        deleted_reset = PasswordResetToken.objects.filter(expires_at__lt=cutoff_date).delete()[0]

        # Delete expired email verification tokens
        deleted_verify = EmailVerificationToken.objects.filter(expires_at__lt=cutoff_date).delete()[0]

        result = {
            "blacklist": deleted_blacklist,
            "password_reset": deleted_reset,
            "email_verification": deleted_verify,
            "total": deleted_blacklist + deleted_reset + deleted_verify,
            "status": "success",
        }

        logger.info(
            "Token cleanup completed",
            extra={
                "deleted_blacklist": deleted_blacklist,
                "deleted_reset": deleted_reset,
                "deleted_verify": deleted_verify,
            },
        )

        return result

    except DatabaseError as exc:
        logger.error("Token cleanup failed", exc_info=True, extra={"error": str(exc)})
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=3)
def cleanup_inactive_sessions(self):
    """
    Clean up inactive user sessions.

    Runs daily at 1:30am via Celery Beat.
    Removes sessions that have been inactive for > 30 days.

    Returns:
        dict: Summary of deleted sessions
    """
    try:
        from .models import UserSession

        cutoff_date = timezone.now() - timedelta(days=30)

        # Delete old inactive sessions
        deleted_count = UserSession.objects.filter(last_activity__lt=cutoff_date, is_active=False).delete()[0]

        result = {
            "deleted": deleted_count,
            "status": "success",
            "cutoff_date": cutoff_date.isoformat(),
        }

        logger.info("Cleaned up inactive sessions", extra={"deleted_count": deleted_count})

        return result

    except DatabaseError as exc:
        logger.error("Session cleanup failed", exc_info=True, extra={"error": str(exc)})
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=3)
def cleanup_old_audit_logs(self):
    """
    Archive old audit logs.

    Runs weekly on Saturday at 2am via Celery Beat.
    Keeps 1 year of audit logs for compliance.

    Returns:
        dict: Summary of archived logs
    """
    try:
        from nimoh_base.conf import nimoh_setting

        from .models import AuditLog

        retention_days = nimoh_setting("AUDIT_LOG_RETENTION_DAYS", 365)
        cutoff_date = timezone.now() - timedelta(days=retention_days)

        # Delete logs older than the configured retention window.
        deleted_count = AuditLog.objects.filter(timestamp__lt=cutoff_date).delete()[0]

        result = {
            "deleted": deleted_count,
            "status": "success",
            "cutoff_date": cutoff_date.isoformat(),
        }

        logger.info("Cleaned up old audit logs", extra={"deleted_count": deleted_count})

        return result

    except DatabaseError as exc:
        logger.error("Audit log cleanup failed", exc_info=True, extra={"error": str(exc)})
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=2)
def check_password_breach_async(self, user_id: str, sha1_prefix: str, sha1_suffix_hmac: str):
    """
    Asynchronously check if a password has been found in a known data breach.

    This task runs after user registration to avoid blocking the request cycle.
    If the password is breached, an email notification is sent to the user.

    Security design
    ---------------
    The caller computes the full SHA-1 hash but passes only:
    - ``sha1_prefix``    — first 5 characters (sent to HIBP k-anonymity API)
    - ``sha1_suffix_hmac`` — HMAC-SHA256(SECRET_KEY, sha1_hash[5:]), so the
      raw SHA-1 suffix (reversible for weak passwords via rainbow tables) never
      travels through the Celery broker (Redis).

    This task re-HMACs each suffix returned by the HIBP API and uses
    :func:`hmac.compare_digest` for a timing-safe comparison.

    Args:
        user_id:          User UUID as string.
        sha1_prefix:      First 5 characters of the uppercase hex SHA-1.
        sha1_suffix_hmac: HMAC-SHA256 of the remaining SHA-1 suffix.

    Returns:
        dict: Result with breach status.
    """
    try:
        import hmac as _hmac

        import requests
        from django.conf import settings
        from django.contrib.auth import get_user_model

        User = get_user_model()

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            logger.warning(f"User {user_id} not found for password breach check")
            return {"status": "user_not_found"}

        # Query HaveIBeenPwned with k-anonymity — only the 5-char prefix is sent.
        try:
            response = requests.get(
                f"https://api.pwnedpasswords.com/range/{sha1_prefix.upper()}",
                timeout=3,
                headers={"Add-Padding": "true"},
            )
            response.raise_for_status()
        except requests.RequestException as e:
            logger.warning(f"HIBP API request failed: {e}", extra={"user_id": user_id})
            return {"status": "api_error", "error": str(e)}

        # Compare each returned suffix via HMAC to avoid reconstructing the
        # original SHA-1 in memory.
        is_breached = False
        for line in response.text.splitlines():
            returned_suffix = line.split(":")[0].strip().upper()
            candidate_hmac = _hmac.new(
                settings.SECRET_KEY.encode(),
                returned_suffix.encode(),
                "sha256",
            ).hexdigest()
            if _hmac.compare_digest(candidate_hmac, sha1_suffix_hmac):
                is_breached = True
                break

        if is_breached:
            logger.warning(f"User {user.email} registered with breached password", extra={"user_id": str(user.id)})

            # Send email notification to user about breached password
            try:
                from django.conf import settings
                from django.core.mail import send_mail

                subject = "Security Alert: Password Previously Compromised"
                message = f"""
Hello {user.username},

Our security system has detected that the password you registered with has been found in a data breach.

While your account is secure, we strongly recommend changing your password to a unique one that hasn't been compromised.

You can change your password in your account settings.

Best regards,
The Security Team
"""
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [user.email],
                    fail_silently=True,
                )
            except (smtplib.SMTPException, OSError) as e:
                logger.error(
                    f"Failed to send breach notification email to {user.email}: {e!s}", extra={"user_id": str(user.id)}
                )

            return {"status": "breached", "user_id": str(user.id), "email": user.email}

        return {"status": "safe", "user_id": str(user.id)}

    except Exception as exc:
        logger.error(f"Password breach check failed for user {user_id}: {exc}", exc_info=True)
        # Don't retry indefinitely - breach check is optional
        if self.request.retries < self.max_retries:
            raise self.retry(exc=exc, countdown=60)
        return {"status": "error", "error": str(exc)}


@shared_task(bind=True, max_retries=3)
def enforce_session_limit_task(self, user_pk):
    """
    Evict the oldest active sessions when a user's concurrent-session limit is exceeded.

    Dispatched asynchronously after every successful login / session creation so
    that the login request itself is not slowed down by the DB query.

    Args:
        user_pk: Primary key of the user whose sessions should be checked.
    """
    try:
        from django.contrib.auth import get_user_model

        from .models import UserSession

        User = get_user_model()
        try:
            user = User.objects.get(pk=user_pk)
        except User.DoesNotExist:
            logger.warning("enforce_session_limit_task: user %s not found, skipping", user_pk)
            return {"status": "skipped", "reason": "user_not_found"}

        UserSession.enforce_session_limit(user)
        return {"status": "ok", "user_id": str(user_pk)}
    except Exception as exc:
        logger.error("enforce_session_limit_task failed for user %s", user_pk, exc_info=True)
        raise self.retry(exc=exc, countdown=60)
