class AdminInfoMixin:
    admin_info = ""

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context["subtitle"] = self.admin_info
        return super().changelist_view(request, extra_context=extra_context)
