from django.urls import reverse

from territories_dashboard_lib.website_lib.models import StaticPage


def get_website_links():

    links = []
    links.append(reverse("website:landing-page"))
    links.append(reverse("website:indicateurs"))
    links.append(reverse("website:comparison-redirect"))
    links.append(reverse("website:lexique"))
    links.append(reverse("website:sitemap"))
    for static_page in StaticPage.objects.all():
        links.append(
            reverse("website:static-page", kwargs={"page_url": static_page.url})
        )
    return links
