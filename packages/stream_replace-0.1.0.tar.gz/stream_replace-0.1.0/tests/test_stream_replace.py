from __future__ import annotations

import asyncio
import re

import pytest

from stream_replace import Replacer, astream_replace, stream_replace


# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------

def collect(replacer: Replacer, chunks: list[str]) -> str:
    parts = [replacer.feed(c) for c in chunks]
    parts.append(replacer.flush())
    return "".join(parts)


async def _async_gen(chunks: list[str]):
    for c in chunks:
        yield c


# ---------------------------------------------------------------
# Basic string replacement
# ---------------------------------------------------------------

class TestStringBasic:
    def test_single_chunk(self):
        r = Replacer([("hello", "world")])
        assert collect(r, ["hello there"]) == "world there"

    def test_multiple_occurrences(self):
        r = Replacer([("ab", "X")])
        assert collect(r, ["ab cd ab"]) == "X cd X"

    def test_no_match(self):
        r = Replacer([("xyz", "!")])
        assert collect(r, ["hello world"]) == "hello world"

    def test_empty_chunks(self):
        r = Replacer([("a", "b")])
        assert collect(r, ["", "a", "", "a", ""]) == "bb"

    def test_replacement_with_callable(self):
        r = Replacer([("bad", lambda s: s.upper())])
        assert collect(r, ["this is bad"]) == "this is BAD"


# ---------------------------------------------------------------
# Cross-chunk partial matching (strings)
# ---------------------------------------------------------------

class TestStringPartial:
    def test_split_across_two_chunks(self):
        r = Replacer([("hello", "world")])
        assert collect(r, ["hel", "lo"]) == "world"

    def test_split_across_three_chunks(self):
        r = Replacer([("hello", "world")])
        assert collect(r, ["he", "ll", "o done"]) == "world done"

    def test_partial_that_never_completes(self):
        r = Replacer([("hello", "world")])
        assert collect(r, ["hel", " nope"]) == "hel nope"

    def test_overlapping_partial(self):
        r = Replacer([("abc", "X")])
        assert collect(r, ["ab", "ab", "c"]) == "abX"

    def test_partial_at_stream_end(self):
        r = Replacer([("hello", "world")])
        assert collect(r, ["hel"]) == "hel"

    def test_match_then_partial(self):
        r = Replacer([("aa", "X")])
        assert collect(r, ["aa", "a"]) == "Xa"


# ---------------------------------------------------------------
# Regex replacement
# ---------------------------------------------------------------

class TestRegex:
    def test_simple_regex(self):
        r = Replacer([(re.compile(r"\d+"), "#")])
        assert collect(r, ["abc 123 def"]) == "abc # def"

    def test_phone_number_masking(self):
        r = Replacer([(re.compile(r"1[3-9]\d{9}"), "[PHONE]")])
        assert collect(r, ["call 13800138000 now"]) == "call [PHONE] now"

    def test_regex_with_groups(self):
        r = Replacer([(re.compile(r"(\d+)"), lambda m: str(int(m.group()) * 2))])
        assert collect(r, ["val=5 x=10"]) == "val=10 x=20"

    def test_regex_expand(self):
        r = Replacer([(re.compile(r"(\w+)@(\w+)"), r"\1[at]\2")])
        assert collect(r, ["email: a@b"]) == "email: a[at]b"


# ---------------------------------------------------------------
# Tag-style removal (unbounded regex)
# ---------------------------------------------------------------

class TestTagRemoval:
    def test_think_tag_single_chunk(self):
        r = Replacer([(re.compile(r"<think>[\s\S]*?</think>"), "")])
        assert collect(r, ["<think>reasoning</think>answer"]) == "answer"

    def test_think_tag_across_chunks(self):
        r = Replacer([(re.compile(r"<think>[\s\S]*?</think>"), "")])
        chunks = ["<think>", "some reasoning", "</think>", "final answer"]
        assert collect(r, chunks) == "final answer"

    def test_think_tag_split_open(self):
        r = Replacer([(re.compile(r"<think>[\s\S]*?</think>"), "")])
        chunks = ["<thi", "nk>stuff</think>ok"]
        assert collect(r, chunks) == "ok"

    def test_think_tag_split_close(self):
        r = Replacer([(re.compile(r"<think>[\s\S]*?</think>"), "")])
        chunks = ["<think>stuff</thi", "nk>ok"]
        assert collect(r, chunks) == "ok"

    def test_text_before_think_tag(self):
        r = Replacer([(re.compile(r"<think>[\s\S]*?</think>"), "")])
        chunks = ["prefix <think>", "inner", "</think> suffix"]
        assert collect(r, chunks) == "prefix  suffix"


# ---------------------------------------------------------------
# Multiple rules
# ---------------------------------------------------------------

class TestMultipleRules:
    def test_string_and_regex(self):
        r = Replacer([
            ("foo", "bar"),
            (re.compile(r"\d+"), "#"),
        ])
        assert collect(r, ["foo has 3 items"]) == "bar has # items"

    def test_earliest_match_wins(self):
        r = Replacer([
            ("bc", "X"),
            ("ab", "Y"),
        ])
        assert collect(r, ["abc"]) == "Yc"

    def test_non_overlapping(self):
        r = Replacer([
            ("aa", "X"),
            ("bb", "Y"),
        ])
        assert collect(r, ["aabb"]) == "XY"


# ---------------------------------------------------------------
# wrap / wrap_async
# ---------------------------------------------------------------

class TestWrap:
    def test_wrap_sync(self):
        r = Replacer([("hello", "world")])
        result = "".join(r.wrap(["hel", "lo there"]))
        assert result == "world there"

    def test_wrap_sync_functional(self):
        result = "".join(stream_replace(["hel", "lo"], [("hello", "world")]))
        assert result == "world"

    @pytest.mark.asyncio
    async def test_wrap_async(self):
        r = Replacer([("hello", "world")])
        parts = []
        async for chunk in r.wrap_async(_async_gen(["hel", "lo there"])):
            parts.append(chunk)
        assert "".join(parts) == "world there"

    @pytest.mark.asyncio
    async def test_astream_replace(self):
        parts = []
        async for chunk in astream_replace(
            _async_gen(["hel", "lo"]),
            [("hello", "world")],
        ):
            parts.append(chunk)
        assert "".join(parts) == "world"


# ---------------------------------------------------------------
# Reset / reuse
# ---------------------------------------------------------------

class TestReset:
    def test_reset_clears_buffer(self):
        r = Replacer([("hello", "world")])
        r.feed("hel")
        r.reset()
        assert collect(r, ["hello"]) == "world"


# ---------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------

class TestEdgeCases:
    def test_empty_stream(self):
        r = Replacer([("x", "y")])
        assert collect(r, []) == ""

    def test_replacement_longer_than_pattern(self):
        r = Replacer([("a", "xyz")])
        assert collect(r, ["aaa"]) == "xyzxyzxyz"

    def test_replacement_empty(self):
        r = Replacer([("remove", "")])
        assert collect(r, ["please remove this"]) == "please  this"

    def test_chinese_characters(self):
        r = Replacer([("敏感词", "***")])
        assert collect(r, ["这是一个敏", "感词测试"]) == "这是一个***测试"

    def test_single_char_pattern(self):
        r = Replacer([("x", "O")])
        assert collect(r, ["axbxc"]) == "aObOc"

    def test_pattern_same_as_replacement(self):
        r = Replacer([("a", "a")])
        assert collect(r, ["aaa"]) == "aaa"

    def test_unicode_emoji(self):
        r = Replacer([("😀", "smile")])
        assert collect(r, ["hello 😀 world"]) == "hello smile world"

    def test_many_small_chunks(self):
        r = Replacer([("hello", "world")])
        assert collect(r, list("hello")) == "world"
