from __future__ import annotations

from typing import AsyncIterable, Iterable

from stream_replace._rule import Rule, parse_rule


class Replacer:
    """Streaming text replacer that correctly handles partial matches across
    chunk boundaries.

    Usage::

        r = Replacer([("hello", "world")])
        for chunk in token_stream:
            yield r.feed(chunk)
        yield r.flush()
    """

    __slots__ = ("_rules", "_buffer")

    def __init__(self, rules: list[tuple]) -> None:
        self._rules: list[Rule] = [parse_rule(r) for r in rules]
        self._buffer: str = ""

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def feed(self, chunk: str) -> str:
        """Process an incoming chunk.  Returns text that is safe to emit."""
        if not chunk:
            return ""
        self._buffer += chunk
        return self._process(flushing=False)

    def flush(self) -> str:
        """Flush any remaining buffered text.  Call once after the stream ends."""
        return self._process(flushing=True)

    def reset(self) -> None:
        """Clear internal state so the instance can be reused."""
        self._buffer = ""

    # ------------------------------------------------------------------
    # Convenience wrappers
    # ------------------------------------------------------------------

    def wrap(self, iterable: Iterable[str]) -> Iterable[str]:
        """Wrap a sync iterable of chunks, yielding replaced text."""
        self.reset()
        for chunk in iterable:
            out = self.feed(chunk)
            if out:
                yield out
        out = self.flush()
        if out:
            yield out

    async def wrap_async(self, iterable: AsyncIterable[str]) -> AsyncIterable[str]:
        """Wrap an async iterable of chunks, yielding replaced text."""
        self.reset()
        async for chunk in iterable:
            out = self.feed(chunk)
            if out:
                yield out
        out = self.flush()
        if out:
            yield out

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _process(self, *, flushing: bool) -> str:
        result: list[str] = []
        buf = self._buffer

        # Phase 1: find and apply all complete matches iteratively
        pos = 0
        while pos < len(buf):
            earliest = self._find_earliest_match(buf, pos)
            if earliest is None:
                break
            result.append(buf[pos:earliest.start])
            result.append(earliest.replacement_text)
            pos = earliest.end

        remaining = buf[pos:]

        if flushing:
            # No more data coming — do one final replacement pass on the
            # remaining tail, then emit everything.
            final = self._replace_all(remaining)
            result.append(final)
            self._buffer = ""
        else:
            # Determine safe-to-emit boundary in *remaining*.
            safe = self._safe_boundary(remaining)
            result.append(remaining[:safe])
            self._buffer = remaining[safe:]

        return "".join(result)

    def _find_earliest_match(self, text: str, pos: int):
        """Return the earliest MatchResult among all rules, or None."""
        from stream_replace._rule import MatchResult

        best: MatchResult | None = None
        for rule in self._rules:
            m = rule.search(text, pos)
            if m is not None and (best is None or m.start < best.start):
                best = m
        return best

    def _safe_boundary(self, remaining: str) -> int:
        """How many characters from *remaining* can be safely emitted."""
        if not remaining:
            return 0

        safe = len(remaining)
        for rule in self._rules:
            p = rule.find_partial_start(remaining)
            if p is not None and p < safe:
                safe = p
        return safe

    def _replace_all(self, text: str) -> str:
        """Run all rules on *text* until no more matches (for flush)."""
        buf = text
        changed = True
        while changed:
            changed = False
            pos = 0
            parts: list[str] = []
            while pos < len(buf):
                m = self._find_earliest_match(buf, pos)
                if m is None:
                    break
                parts.append(buf[pos:m.start])
                parts.append(m.replacement_text)
                pos = m.end
                changed = True
            parts.append(buf[pos:])
            buf = "".join(parts)
        return buf
