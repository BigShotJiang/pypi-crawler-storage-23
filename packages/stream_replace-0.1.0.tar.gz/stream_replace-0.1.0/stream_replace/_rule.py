from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Union

from stream_replace._utils import extract_literal_prefix, find_suffix_prefix_overlap

Replacement = Union[str, Callable]


@dataclass(slots=True)
class MatchResult:
    start: int
    end: int
    replacement_text: str


@dataclass(slots=True)
class StringRule:
    pattern: str
    replacement: Replacement

    def search(self, text: str, pos: int = 0) -> MatchResult | None:
        idx = text.find(self.pattern, pos)
        if idx == -1:
            return None
        matched = self.pattern
        rep = self.replacement(matched) if callable(self.replacement) else self.replacement
        return MatchResult(start=idx, end=idx + len(self.pattern), replacement_text=rep)

    def find_partial_start(self, text: str) -> int | None:
        return find_suffix_prefix_overlap(text, self.pattern)


@dataclass(slots=True)
class RegexRule:
    regex: re.Pattern[str]
    replacement: Replacement
    literal_prefix: str = field(init=False)
    _fallback_lookback: int = 0

    def __post_init__(self) -> None:
        self.literal_prefix = extract_literal_prefix(self.regex)
        if not self.literal_prefix and self._fallback_lookback == 0:
            self._fallback_lookback = 32

    def search(self, text: str, pos: int = 0) -> MatchResult | None:
        m = self.regex.search(text, pos)
        if m is None:
            return None
        if callable(self.replacement):
            rep = self.replacement(m)
        else:
            rep = m.expand(self.replacement)
        return MatchResult(start=m.start(), end=m.end(), replacement_text=rep)

    def find_partial_start(self, text: str) -> int | None:
        prefix = self.literal_prefix
        if prefix:
            # Check whether a complete literal prefix exists without a full
            # regex match — that means an open (unfinished) match is in
            # progress and we must hold back from that position.
            search_start = 0
            while True:
                idx = text.find(prefix, search_start)
                if idx == -1:
                    break
                if self.regex.search(text, idx) is None:
                    return idx
                search_start = idx + 1

            # Also check if the very tail is a *partial* literal prefix
            # (token split mid-prefix).
            return find_suffix_prefix_overlap(text, prefix)

        if self._fallback_lookback > 0 and len(text) > 0:
            return max(0, len(text) - self._fallback_lookback)
        return None


Rule = StringRule | RegexRule


def parse_rule(spec: tuple) -> Rule:
    """Convert a user-supplied tuple into a Rule object.

    Accepted forms:
        (str,   str | callable)
        (re.Pattern, str | callable)
        (str,   str | callable, dict)      -- extra options forwarded
        (re.Pattern, str | callable, dict)
    """
    if len(spec) == 2:
        pattern, replacement = spec
        opts: dict = {}
    elif len(spec) == 3:
        pattern, replacement, opts = spec
    else:
        raise ValueError(f"Rule tuple must have 2 or 3 elements, got {len(spec)}")

    if isinstance(pattern, str):
        return StringRule(pattern=pattern, replacement=replacement)
    if isinstance(pattern, re.Pattern):
        lookback = opts.get("lookback", 0)
        rule = RegexRule(regex=pattern, replacement=replacement, _fallback_lookback=lookback)
        return rule

    raise TypeError(f"Pattern must be str or re.Pattern, got {type(pattern).__name__}")
