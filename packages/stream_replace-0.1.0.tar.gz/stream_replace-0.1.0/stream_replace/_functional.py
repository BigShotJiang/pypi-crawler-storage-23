from __future__ import annotations

from typing import AsyncIterable, Iterable

from stream_replace._replacer import Replacer


def stream_replace(
    iterable: Iterable[str],
    rules: list[tuple],
) -> Iterable[str]:
    """Convenience wrapper — apply replacement *rules* to a sync chunk stream."""
    return Replacer(rules).wrap(iterable)


async def astream_replace(
    iterable: AsyncIterable[str],
    rules: list[tuple],
) -> AsyncIterable[str]:
    """Convenience wrapper — apply replacement *rules* to an async chunk stream."""
    async for chunk in Replacer(rules).wrap_async(iterable):
        yield chunk
