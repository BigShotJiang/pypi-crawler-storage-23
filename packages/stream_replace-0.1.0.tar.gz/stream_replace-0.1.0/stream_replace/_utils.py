from __future__ import annotations

import re

try:
    import re._parser as _sre_parse  # Python 3.13+
except ImportError:
    import sre_parse as _sre_parse  # type: ignore[no-redef]


def extract_literal_prefix(pattern: re.Pattern[str]) -> str:
    """Extract the leading literal character sequence from a compiled regex.

    Examples:
        r"<think>[\\s\\S]*?</think>" -> "<think>"
        r"hello\\s+world"            -> "hello"
        r"\\d{11}"                   -> ""
    """
    try:
        parsed = _sre_parse.parse(pattern.pattern)
    except Exception:
        return ""

    chars: list[str] = []
    for op, av in parsed:
        if op == _sre_parse.LITERAL:
            chars.append(chr(av))
        else:
            break
    return "".join(chars)


def find_suffix_prefix_overlap(text: str, pattern: str) -> int | None:
    """Find the earliest position in *text* where a suffix of *text* equals
    a proper prefix of *pattern*.

    Returns the start index in *text*, or None if no overlap exists.

    Example:
        text="abc hel", pattern="hello" -> 4  (suffix "hel" is prefix of "hello")
    """
    if not pattern:
        return None

    max_check = min(len(text), len(pattern) - 1)
    for length in range(max_check, 0, -1):
        suffix = text[-length:]
        if pattern[:length] == suffix:
            return len(text) - length
    return None
