def main():
    print("Hello from stream-replace!")


if __name__ == "__main__":
    main()
