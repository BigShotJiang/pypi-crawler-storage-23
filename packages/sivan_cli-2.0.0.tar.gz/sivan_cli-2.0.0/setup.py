from setuptools import setup

setup(
    name="sivan-cli",
    version="2.0.0",
    py_modules=["sivan"],
    install_requires=[
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "sivan=sivan:main",
        ],
    },
)
