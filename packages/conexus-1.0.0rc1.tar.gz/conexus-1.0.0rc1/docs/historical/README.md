# Historical Documents

This directory contains original design documents, specifications, and implementation plans from Nexus development. They are preserved for reference but are not actively maintained.

## Contents

- **spec.md** — The original vision and specification document. Written at project inception, it describes what Nexus borrows from mgrep, SeaGOAT, and Arcaneum, along with the original storage tier schemas and CLI design. Superseded by the current docs and codebase.

- **architecture.md** — The original architecture document with module maps, component diagrams, risk register, and the phased implementation plan (Phases 1-7). Superseded by `docs/architecture.md`.

- **plans/** — Design documents and implementation plans from brainstorming sessions. Each follows the `YYYY-MM-DD-<topic>-{design,impl-plan}.md` convention.

## Why These Are Here

These documents reflect the thinking at the time they were written. The codebase has evolved since — module names changed, APIs shifted, features were added. Rather than silently deleting them or letting them drift further out of date, they live here as a record of how the project took shape.

For current documentation, see the [docs root](../README.md) or the [project README](../../README.md).
