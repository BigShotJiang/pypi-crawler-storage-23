"""Allow running nordpy as `python -m nordpy`."""

from nordpy.app import main

main()
