"""Nordpy — Interactive TUI for Nordnet financial data."""

__version__ = "1.2.0"
