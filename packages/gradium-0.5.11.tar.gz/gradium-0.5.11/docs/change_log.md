## 2026.02

We're excited to announce major updates to the Gradium API and Gradium Studio, delivering enhanced text-to-speech (TTS) and speech-to-text (STT) capabilities for developers and enterprises.

🎙️ **Advanced TTS and STT Models**

Experience our latest text-to-speech model and speech recognition model with improved audio quality, accuracy, and natural-sounding voice generation. Perfect for voice applications, transcription services, and conversational AI. Now by default 

📖 **Custom Pronunciation Dictionaries**

Take control of speech synthesis with pronunciation dictionaries. Ensure brand names, technical terminology, and industry-specific acronyms are pronounced correctly every time. Ideal for healthcare, finance, and industry specific applications.

⚡ **WebSocket Multiplexing for Real-Time Audio**

Boost performance with multiplexing support: process multiple TTS or STT requests simultaneously over a single WebSocket connection. Reduce latency, minimize connection overhead, and scale efficiently for high-volume applications.

🎁 **Gradium Referral Program**

Love Gradium? Join our referral program: share Gradium with your network and earn up to 9M API credits while your referrals get exclusive discounts. Win-win for developers and businesses alike.

☁️ **AWS Marketplace & SageMaker AI Deployment**

Deploy Gradium TTS and ASR models directly on AWS SageMaker with full bidirectional streaming support. Accelerate your deployment timeline while keeping your voice AI infrastructure secure within your private cloud network. Now available on AWS Marketplace.

Feedbacks are always welcome, do not hesitate to join our [discord channel](https://discord.com/invite/bcysuPRzXE)!
