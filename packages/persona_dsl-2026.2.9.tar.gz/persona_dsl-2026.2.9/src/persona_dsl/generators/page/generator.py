import ast
import inspect
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .structure import StructureParser
from .codegen import CodeGenerator


class PageGenerator:
    """
    Генератор страниц 2.0 (Refactored).
    Orchestrates parsing (Structure) and rendering (Codegen).
    """

    def __init__(
        self,
        debug_mode: bool = False,
        test_id_prefix: Optional[str] = None,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        self.debug_mode = debug_mode
        self._test_id_prefix = test_id_prefix
        self.leaf_overrides = leaf_overrides or {}

        # State
        self._pending_updates: Dict[str, str] = {}

        # Sub-components
        self.structure_parser = StructureParser(test_id_prefix)
        self.code_generator = CodeGenerator(debug_mode)

    def get_pending_updates(self) -> Dict[str, str]:
        """Returns map of file_path -> new_code for referenced components."""
        return self._pending_updates

    def apply_pending_updates(self) -> None:
        """Writes all pending component updates to disk."""
        for file_path, code in self._pending_updates.items():
            try:
                Path(file_path).write_text(code, encoding="utf-8")
                if self.debug_mode:
                    print(f"Deep updated component: {file_path}")
            except Exception as e:
                print(f"Failed to write deep update for {file_path}: {e}")
        self._pending_updates.clear()

    def generate_from_aria_snapshot(
        self,
        snapshot: Any,
        class_name: str = "GeneratedPage",
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
        component_overrides: Optional[Dict[str, Tuple[str, str]]] = None,
        existing_element_defs: Optional[Dict[str, Dict[str, Any]]] = None,
        base_class: str = "Page",
    ) -> str:
        """Оркестрация процесса генерации."""

        # 1. Parsing & Structure

        # We need to track used names across the tree
        used_names: set[str] = set()
        elements_tree = self.structure_parser.parse_aria_node_recursive(
            snapshot, used_names, {}
        )

        # 2. Structural Simplification (Flattening)
        # Collect consumed refs
        consumed_refs = self.structure_parser.collect_consumed_refs(elements_tree)
        elements_tree = self.structure_parser.flatten_tree_recursive(
            elements_tree, consumed_refs
        )

        # 3. Name Recalculation (LCL-Fix)
        self.structure_parser.recalculate_names(elements_tree)

        # 3.5 Reconcile with existing names (Smart Preservation)
        if existing_element_defs:
            self._reconcile_names(elements_tree, existing_element_defs)

        # 4. Semantic Promotion
        # Need current names
        # Logic in structure parser handles recursions?
        # Promote sem wrappers needs 'used_names' to generate new unique ones.
        self.structure_parser.promote_semantic_wrappers(elements_tree, used_names)

        # 5. Apply Shared Components (Deep Update Logic)
        self._apply_components(elements_tree, component_overrides)

        # 6. Identify Complex Sections
        self.structure_parser.identify_complex_sections(elements_tree)

        # 6.5 Identify Table Prototypes (Smart Tables)
        self.structure_parser.identify_table_prototypes(elements_tree)

        # 7. Codegen
        return self.code_generator.generate_code(
            elements_tree,
            class_name,
            page_path,
            aria_snapshot_path,
            screenshot_path,
            leaf_overrides or {},
            component_overrides,
            base_class=base_class,
        )

    def generate_or_update_from_aria_snapshot(
        self,
        snapshot: Any,
        class_name: str = "GeneratedPage",
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        existing_code: Optional[str] = None,
    ) -> str:

        # 1. Parse existing code to find overrides/components
        existing_tree = None
        existing_class_node = None
        base_class = "Page"

        if existing_code:
            try:
                existing_tree = ast.parse(existing_code)
                existing_class_node = next(
                    (
                        n
                        for n in existing_tree.body
                        if isinstance(n, ast.ClassDef) and n.name == class_name
                    ),
                    None,
                )

                # Extract Base Class
                if existing_class_node and existing_class_node.bases:
                    base_node = existing_class_node.bases[0]
                    if isinstance(base_node, ast.Name):
                        base_class = base_node.id
                    elif isinstance(base_node, ast.Attribute):
                        base_class = base_node.attr
            except Exception:
                pass

        # 2. Extract mappings
        leaf_overrides = {}
        existing_element_defs = {}

        if existing_class_node:
            # We need to expose extraction logic from codegen?
            leaf_overrides = self.code_generator.extract_field_mappings(
                existing_class_node
            )

        if existing_tree:
            existing_element_defs = self._extract_element_definitions(existing_tree)
            if self.debug_mode:
                print(
                    f"DEBUG: Existing Defs Keys: {list(existing_element_defs.keys())}"
                )
                for k, v in existing_element_defs.items():
                    print(f"  {k}: {v}")

        component_overrides = (
            self._extract_component_overrides(existing_tree) if existing_tree else {}
        )

        # 3. Generate
        # We assume if existing file has 'Banner' base, we reuse it.
        # But if leaf_overrides is empty, and base is Page, we might regenerate freely.
        # Logic from previous fix: if leaf_overrides OR base_class != "Page", trigger regen.

        new_code = self.generate_from_aria_snapshot(
            snapshot,
            class_name,
            page_path,
            aria_snapshot_path,
            screenshot_path,
            leaf_overrides,
            component_overrides,
            existing_element_defs=existing_element_defs,
            base_class=base_class,
        )

        # 4. Merge?
        # For now we rely on pure regeneration with overrides.
        # But if existing methods existed, we lose them!
        # The refactor preserves logic: we need to merge custom methods back.

        if existing_code:
            # Re-parse new code
            new_tree = ast.parse(new_code)
            new_class_node = next(
                (
                    n
                    for n in new_tree.body
                    if isinstance(n, ast.ClassDef) and n.name == class_name
                ),
                None,
            )

            if existing_class_node and new_class_node:
                self._merge_custom_methods(existing_class_node, new_class_node)

                # Re-assemble
                # Replace class in new_tree
                for i, node in enumerate(new_tree.body):
                    if isinstance(node, ast.ClassDef) and node.name == class_name:
                        new_tree.body[i] = new_class_node
                        break

                # Unparse
                try:
                    import black

                    return black.format_str(ast.unparse(new_tree), mode=black.Mode())
                except Exception:
                    return ast.unparse(new_tree)

        return new_code

    def _extract_component_overrides(
        self, tree: ast.Module
    ) -> Dict[str, Tuple[str, str]]:
        """
        Parses the AST of the EXISTING page file to find which fields are using custom component classes.
        Returns: { 'var_name': ('ClassName', 'module.path') }
        """
        overrides: Dict[str, Tuple[str, str]] = {}
        if not tree:
            return overrides

        # 1. Collect Imports: ClassName -> ModulePath
        imports_map = {}
        for node in tree.body:
            if isinstance(node, ast.ImportFrom):
                module = node.module
                for name in node.names:
                    # name.name is the class name, name.asname is alias
                    cls_name = name.name
                    alias = name.asname or cls_name
                    if module:
                        imports_map[alias] = (cls_name, module)

        # 2. Find Page Class
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                self._scan_class_for_components(node, imports_map, overrides)

        return overrides

    def _scan_class_for_components(
        self, class_node: ast.ClassDef, imports_map: Dict, overrides: Dict
    ) -> None:
        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            return

        for stmt in init_method.body:
            # Look for: self.var_name = self.add_element(ClassName(...))
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                ):
                    var_name = target.attr

                    if (
                        isinstance(stmt.value, ast.Call)
                        and isinstance(stmt.value.func, ast.Attribute)
                        and stmt.value.func.attr == "add_element"
                    ):
                        if stmt.value.args and isinstance(stmt.value.args[0], ast.Call):
                            element_call = stmt.value.args[0]
                            if isinstance(element_call.func, ast.Name):
                                cls_name = element_call.func.id
                                # Check if this class is imported from components
                                if cls_name in imports_map:
                                    original_cls_name, module_path = imports_map[
                                        cls_name
                                    ]
                                    # Filter out standard persona imports
                                    # Also allow if explicitly from 'components'
                                    if (
                                        "components" in module_path
                                        or not module_path.startswith(
                                            "persona_dsl.pages"
                                        )
                                    ):
                                        overrides[var_name] = (
                                            original_cls_name,
                                            module_path,
                                        )

    def _extract_element_definitions(
        self, tree: ast.Module
    ) -> Dict[str, Dict[str, Any]]:
        """
        Parses the existing module to find element definitions in ALL classes.
        Returns: { var_name: { 'role': ..., 'name': ..., 'test_id': ..., ... } }
        """
        definitions: Dict[str, Any] = {}
        if not tree:
            return definitions

        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                self._scan_class_for_definitions(node, definitions)
        return definitions

    def _scan_class_for_definitions(
        self, class_node: ast.ClassDef, definitions: Dict
    ) -> None:
        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            return

        for stmt in init_method.body:
            # Match: self.var_name = ... add_element(Class(kw=val...))
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                var_name = None
                if isinstance(target, ast.Attribute):
                    var_name = target.attr

                if (
                    var_name
                    and isinstance(stmt.value, ast.Call)
                    and isinstance(stmt.value.func, ast.Attribute)
                    and stmt.value.func.attr == "add_element"
                ):
                    if stmt.value.args and isinstance(stmt.value.args[0], ast.Call):
                        el_call = stmt.value.args[0]
                        # Extract props
                        props: Dict[str, Any] = {}
                        if isinstance(el_call.func, ast.Name):
                            props["role"] = el_call.func.id

                        for kw in el_call.keywords:
                            if isinstance(kw.value, ast.Constant) and kw.arg:
                                props[kw.arg] = kw.value.value

                        # Store in definitions.
                        # Collision strategy: Last one wins or merging?
                        # Usually names are unique enough or we prioritize Page class?
                        # For now, flat namespace.
                        definitions[var_name] = props

    def _reconcile_names(
        self,
        elements: List[Dict[str, Any]],
        existing_defs: Dict[str, Dict[str, Any]],
        consumed_vars: Optional[set[str]] = None,
    ) -> None:
        """
        Matches new elements to existing variable names to preserve user renames.
        """
        if consumed_vars is None:
            consumed_vars = set()

        for el in elements:
            # Try to find a match in existing_defs
            # Priority: test_id > accessible_name > text (if available)

            match_var = None

            # 1. By Test ID
            if el.get("test_id"):
                for var, props in existing_defs.items():
                    if (
                        props.get("test_id") == el["test_id"]
                        and var not in consumed_vars
                    ):
                        match_var = var
                        break

            # 2. By Name/Text (if no match yet)
            if not match_var:
                candidates = []
                if el.get("name"):
                    candidates.append(el["name"])
                if el.get("text"):
                    candidates.append(el["text"])

                found = False
                for c in candidates:
                    for var, props in existing_defs.items():
                        if var in consumed_vars:
                            continue

                        # Check accessible_name OR name kwarg
                        target_name = props.get("accessible_name")

                        if target_name and target_name == c:
                            match_var = var
                            found = True
                            break
                    if found:
                        break

            if match_var:
                # APPLY PRESERVATION
                el["var_name"] = match_var
                el["init_kwargs"][
                    "name"
                ] = match_var  # Ensure name kwarg matches var if it was standard
                consumed_vars.add(match_var)

                # Also remove from existing_defs so we don't double match?
                # No, one-to-one mapping needed.
                # Assuming unique matches for now.

            # Recurse
            if el.get("children"):
                self._reconcile_names(el["children"], existing_defs, consumed_vars)

    def _apply_components(
        self,
        elements: List[Dict[str, Any]],
        component_overrides: Optional[Dict[str, Tuple[str, str]]] = None,
    ) -> None:
        """
        Recursive Deep Update Logic.
        """
        import importlib

        component_overrides = component_overrides or {}

        for el in elements:
            var_name = el.get("var_name")
            if var_name and component_overrides and var_name in component_overrides:
                cls_name, module_path = component_overrides[var_name]

                # Dynamic Load
                try:
                    module = importlib.import_module(module_path)
                    component_cls = getattr(module, cls_name)

                    el["class"] = component_cls
                    el["custom_import_module"] = module_path

                    # DEEP UPDATE
                    # 1. Resolve Path
                    try:
                        source_file = inspect.getsourcefile(component_cls)
                        if source_file and el.get("children"):
                            # Check if we should update this component
                            # We instantiate a NEW generator to generate the component code
                            # using the SUBTREE of the snapshot (el["children"])

                            # We need to construct a "snapshot" for the component.
                            # The component is the ROOT of its own file.
                            # Its children in the tree are its contents.

                            # NOTE: The component class might expect a certain structure.
                            # We pass the children list as if they were children of the root?
                            # generate_or_update expects a snapshot that IS a list or dict.
                            pass

                            sub_generator = PageGenerator(debug_mode=self.debug_mode)

                            # Read existing code
                            existing_comp_code = Path(source_file).read_text(
                                encoding="utf-8"
                            )

                            # Generate updated code
                            # We pass 'children' as the snapshot content?
                            # No, generate_.. expects the structure.
                            # If el is the component root, passed snapshot should satisfy it.
                            # But el itself is the component instance invocation.
                            # Its children are what we want inside the component.

                            # We wrap children in a fake root?
                            # Or we act as if 'children' IS the snapshot list.

                            new_comp_code = sub_generator.generate_or_update_from_aria_snapshot(
                                snapshot=el["children"],  # List of dicts
                                class_name=cls_name,
                                existing_code=existing_comp_code,
                                # paths...
                            )

                            # Store update
                            self._pending_updates[str(source_file)] = new_comp_code

                            # Merge sub-generator updates?
                            self._pending_updates.update(
                                sub_generator.get_pending_updates()
                            )

                    except Exception:
                        pass

                    # Clear children from tree to avoid generating them in parent
                    el["children"] = []

                except Exception:
                    pass

            # Recurse
            if el.get("children"):
                self._apply_components(el["children"], component_overrides)

    def _merge_custom_methods(
        self, old_class: ast.ClassDef, new_class: ast.ClassDef
    ) -> None:
        """Copies custom methods AND DOCSTRINGS from old class to new class."""

        # 1. Merge Docstring
        old_doc = ast.get_docstring(old_class)
        if old_doc:
            # Create new docstring node
            doc_node = ast.Expr(value=ast.Constant(value=old_doc))

            # Check if new class has docstring
            if (
                new_class.body
                and isinstance(new_class.body[0], ast.Expr)
                and isinstance(new_class.body[0].value, ast.Constant)
                and isinstance(new_class.body[0].value.value, str)
            ):
                # Replace existing
                new_class.body[0] = doc_node
            else:
                # Insert at beginning
                new_class.body.insert(0, doc_node)

        # 2. Merge Methods
        existing_methods = {
            n.name: n for n in old_class.body if isinstance(n, ast.FunctionDef)
        }

        # We always keep generated __init__
        # But we want to keep other methods (actions, etc.)

        for name, method_node in existing_methods.items():
            if name == "__init__":
                continue

            # Check if new class has it?
            # Usually generator only produces __init__.
            # So we append custom methods.
            new_class.body.append(method_node)
