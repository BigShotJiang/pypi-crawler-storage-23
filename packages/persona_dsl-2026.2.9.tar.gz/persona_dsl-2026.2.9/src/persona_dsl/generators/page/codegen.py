import ast
from typing import Any, Dict, List, Optional, Tuple

from persona_dsl.utils.naming import to_pascal_case
from .utils import ROLE_TO_CLASS


class CodeGenerator:
    """
    Handles generation of Python AST and source code from the elements tree.
    """

    def __init__(self, debug_mode: bool = False):
        self.debug_mode = debug_mode
        self._seen_test_ids: List[str] = []  # Used for prefix calc

    def set_seen_test_ids(self, ids: List[str]) -> None:
        self._seen_test_ids = ids

    def generate_code(
        self,
        elements_tree: List[Dict[str, Any]],
        class_name: str,
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
        component_overrides: Optional[Dict[str, Tuple[str, str]]] = None,
        base_class: str = "Page",
    ) -> str:

        # 1. Collect all classes to generate (Main Page + Nested Sections)
        # We need a list of (ClassName, BaseClass, Elements) to generate order-independently?
        # Actually, Python requires classes to be defined before use (or quoted, but typically before).
        # We should generate Nested Classes FIRST, then the Main Class.

        extra_classes_ast = []
        import_nodes = []

        # Helper to recursively generate section classes
        def collect_sections(els: List[Dict[str, Any]]) -> None:
            for el in els:
                if el.get("is_complex_section") and not el.get("custom_import_module"):
                    # Generate a nested class for this section
                    section_class_name = to_pascal_case(el["var_name"])
                    # Heuristic: If it has role 'banner', inherit Frame/Banner?
                    # For now, default to Element or specific role class if meaningful.
                    # Or 'Region', 'Group'.

                    role = el.get("role")
                    section_base_class = "Element"
                    if role in ROLE_TO_CLASS:
                        section_base_class = ROLE_TO_CLASS[role].__name__

                    if (
                        section_class_name == class_name
                        or section_class_name == section_base_class
                    ):
                        section_class_name = f"{section_class_name}Section"

                    # Generate AST for this section
                    # Note: We need to calc imports for it too?
                    # Yes.

                    # Extract its subtree
                    section_elements = el.get("children", [])

                    # RECURSE FIRST: Sections inside sections
                    collect_sections(section_elements)

                    section_ast = self._generate_class_ast(
                        class_name=section_class_name,
                        base_class=section_base_class,
                        elements=section_elements,
                        parent_var="self",
                        leaf_overrides=leaf_overrides
                        or {},  # Pass overrides? Assuming overrides use flat var_names... might need scoping.
                        leaf_seen={},  # Reset seen for class scope
                        is_root_page=False,
                    )
                    extra_classes_ast.append(section_ast)

                    # Update element to point to this new local class
                    el["class_name_ref"] = section_class_name
                elif el.get("is_table_component"):
                    # Generate a nested class for this Table Component
                    # It behaves like a complex section, but with a Nested Row Class.

                    # 1. Generate the Table Class
                    table_class_name = el["class_name_ref"]
                    table_base_class = "Table"

                    # Extract prototype children for the Row Class
                    row_prototype = el.get("row_prototype")
                    row_children = (
                        row_prototype.get("children", []) if row_prototype else []
                    )

                    # 2. Check for deeper nesting inside the Row?
                    collect_sections(row_children)

                    # 3. Generate AST for the Table Class
                    # Note: We need to inject the Row Class Definition inside this class.
                    # We pass the prototype children to _generate_class_ast via a special arg?
                    # construct_inner_classes?

                    table_ast = self._generate_class_ast(
                        class_name=table_class_name,
                        base_class=table_base_class,
                        elements=el.get(
                            "children", []
                        ),  # Table's direct children (headers?)
                        parent_var="self",
                        leaf_overrides=leaf_overrides or {},
                        leaf_seen={},
                        is_root_page=False,
                        # Pass Nested Row Info
                        nested_row_info={
                            "class_name": el["row_class_name"],  # "Row"
                            "elements": row_children,
                        },
                    )
                    extra_classes_ast.append(table_ast)

                else:
                    if el.get("children"):  # Continuation of else
                        collect_sections(el["children"])

        collect_sections(elements_tree)

        # 2. Main Page Class
        main_class_def = self._generate_class_ast(
            class_name=class_name,
            base_class=base_class,
            elements=elements_tree,
            parent_var="self",
            leaf_overrides=leaf_overrides or {},
            leaf_seen={},
            is_root_page=True,
            aria_snapshot_path=aria_snapshot_path,
            screenshot_path=screenshot_path,
            page_path=page_path,
        )

        # 3. Imports
        # Collect all used classes to import
        used_classes = {base_class}  # Main base class

        # Collect from ROLE_TO_CLASS
        def collect_used_classes(els: List[Dict[str, Any]]) -> None:
            for el in els:
                # If custom component
                if el.get("custom_import_module"):
                    continue  # Handled separately

                # If local section
                if el.get("class_name_ref"):
                    # We need the base class of that section
                    role = el.get("role")
                    if role and role in ROLE_TO_CLASS:
                        used_classes.add(ROLE_TO_CLASS[role].__name__)
                    else:
                        used_classes.add("Element")

                    # Recurse? No, sections are generated locally.
                    # But imports for their children IS needed?
                    # Wait. Logic above generates AST for sections.
                    # That AST uses classes. So yes, we need imports for ALL elements in ALL generated classes.
                    if el.get("children"):
                        collect_used_classes(el["children"])

                    # Also check prototype children if it's a Smart Table
                    if el.get("is_table_component") or (
                        el.get("has_row_prototype") and el.get("row_prototype")
                    ):
                        # Ensure TableRow is imported
                        used_classes.add("TableRow")

                        # We MUST traverse the prototype children to gather imports (e.g. TableCell, Button)
                        p_children = el["row_prototype"].get("children", [])
                        collect_used_classes(p_children)

                    continue

                role = el.get("role")
                if role and role in ROLE_TO_CLASS:
                    used_classes.add(ROLE_TO_CLASS[role].__name__)
                else:
                    used_classes.add("Element")

                if el.get("children"):
                    collect_used_classes(el["children"])

                # Also check prototype if Smart Table (even if not section ref? usually table IS section/component)
                if el.get("has_row_prototype") and el.get("row_prototype"):
                    p_children = el["row_prototype"].get("children", [])
                    collect_used_classes(p_children)

        collect_used_classes(elements_tree)

        sorted_imports = sorted(list(used_classes))

        # Standard Imports
        imports_stmt = ast.ImportFrom(
            module="persona_dsl.pages",
            names=[ast.alias(name=cls_name) for cls_name in sorted_imports],
            level=0,
        )
        import_nodes.append(imports_stmt)

        # Custom Component Imports (from deep update / registry)
        # We need to find all custom imports used in the tree
        custom_imports_map: Dict[str, set[str]] = {}  # module -> set(classes)

        def collect_custom_imports(els: List[Dict[str, Any]]) -> None:
            for el in els:
                mod = el.get("custom_import_module")
                cls_obj = el.get("class")
                if cls_obj and hasattr(cls_obj, "__name__"):
                    cls = cls_obj.__name__
                else:
                    cls = str(cls_obj) if cls_obj else ""
                # Wait, el["class"] might be the actual class object or string?
                # In _apply_components we set: el["class"] = component_cls (Type)

                if mod and cls:
                    if mod not in custom_imports_map:
                        custom_imports_map[mod] = set()
                    custom_imports_map[mod].add(cls)

                if el.get("children"):
                    collect_custom_imports(el["children"])

        collect_custom_imports(elements_tree)

        for mod, classes in custom_imports_map.items():
            sorted_cls = sorted(list(classes))
            imp = ast.ImportFrom(
                module=mod, names=[ast.alias(name=c) for c in sorted_cls], level=0
            )
            import_nodes.append(imp)

        # 4. Assembly
        module_body: List[Any] = []
        module_body.extend(import_nodes)
        module_body.extend(extra_classes_ast)
        module_body.append(main_class_def)
        module = ast.Module(body=module_body, type_ignores=[])

        code = ast.unparse(ast.fix_missing_locations(module))

        try:
            import black

            return black.format_str(code, mode=black.Mode())
        except Exception:
            return code

    def _generate_class_ast(
        self,
        class_name: str,
        base_class: str,
        elements: List[Dict[str, Any]],
        parent_var: str,
        leaf_overrides: Dict[str, List[str]],
        leaf_seen: Dict[str, int],
        is_root_page: bool = False,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        page_path: Optional[str] = None,
        nested_row_info: Optional[Dict[str, Any]] = None,
    ) -> ast.ClassDef:
        # Body of __init__
        init_body: List[Any] = []

        # super().__init__()
        # If it's a component (not root page), pass **kwargs to super
        if is_root_page:
            super_call = ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Call(
                            func=ast.Name(id="super", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                        attr="__init__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[],
                )
            )
            init_body.append(super_call)
        else:
            # Component: def __init__(self, **kwargs): super().__init__(**kwargs)
            super_call = ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Call(
                            func=ast.Name(id="super", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                        attr="__init__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[
                        ast.keyword(
                            arg=None, value=ast.Name(id="kwargs", ctx=ast.Load())
                        )
                    ],
                )
            )
            init_body.append(super_call)

        # Nested Classes (e.g. Row Class inside Table)
        # We handle this BEFORE fields, but INSIDE the class body?
        # Actually, in Python class body executes. We can just append the class def to init_body??
        # NO. Class def is part of Class Body, NOT __init__.
        # This function returns a ClassDef. It builds __init__ method.
        # We need to inject the nested ClassDef into the `class_body` list.
        # But `_generate_class_ast` currently assumes the only method is `__init__`.
        # We need to change the structure to allow inserting other body elements.

        inner_class_defs = []
        # nested_row_info is passed explicitly now
        if nested_row_info:
            row_ast = self._generate_class_ast(
                class_name=nested_row_info["class_name"],
                base_class="TableRow",
                elements=nested_row_info["elements"],
                parent_var="self",
                leaf_overrides=leaf_overrides,
                leaf_seen=leaf_seen,
                is_root_page=False,
            )
            inner_class_defs.append(row_ast)

        # Paths (only for root page)
        if is_root_page:
            if page_path:
                init_body.append(
                    ast.Assign(
                        targets=[self._create_attribute_chain("self.expected_path")],
                        value=ast.Constant(value=page_path),
                    )
                )
            if aria_snapshot_path:
                init_body.append(
                    ast.Assign(
                        targets=[
                            self._create_attribute_chain(
                                "self.static_aria_snapshot_path"
                            )
                        ],
                        value=ast.Constant(value=aria_snapshot_path),
                    )
                )
            if screenshot_path:
                init_body.append(
                    ast.Assign(
                        targets=[
                            self._create_attribute_chain("self.static_screenshot_path")
                        ],
                        value=ast.Constant(value=screenshot_path),
                    )
                )

        # Elements Generation
        element_stmts = self._build_init_body_ast(
            elements,
            parent_var,
            [],
            {},
            leaf_overrides,
            leaf_seen.copy(),  # Fresh seen list for each class scope
        )
        init_body.extend(element_stmts)

        # Determine kwonlyargs for __init__
        # ERROR: kwonlyargs means `def foo(*, kwargs)`, combined with `**kwargs` this is invalid: `def foo(*, kwargs, **kwargs)`.
        # We want `def foo(**kwargs)`. So kwonlyargs should be empty of kwargs.
        # But we pass `kw_defaults=[None]`.

        # Correct approach for def __init__(self, **kwargs):
        # args=[self], vararg=None, kwonlyargs=[], kwarg=kwargs

        # 4. Define __init__ method
        init_method = ast.FunctionDef(
            name="__init__",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg="self")],
                vararg=None,
                kwonlyargs=[],  # No keyword-only args
                kw_defaults=[],
                kwarg=ast.arg(arg="kwargs") if not is_root_page else None,
                defaults=[],
            ),
            body=init_body,  # type: ignore
            decorator_list=[],
            returns=ast.Name(id="None", ctx=ast.Load()),
        )

        # 5. Define Class
        # Combine [Inner Classes] + [__init__]
        class_body = inner_class_defs + [init_method]

        class_def = ast.ClassDef(
            name=class_name,
            bases=[ast.Name(id=base_class, ctx=ast.Load())],
            keywords=[],
            body=class_body,
            decorator_list=[],
            type_params=[],  # Added in py3.12
        )

        return class_def

    def _build_init_body_ast(
        self,
        elements: List[Dict[str, Any]],
        parent_var: str,
        path_stack: List[str],
        context: Dict[str, Any],
        leaf_overrides: Dict[str, List[str]],
        leaf_seen: Dict[str, int],
    ) -> List[ast.AST]:
        """
        Рекурсивно строит список AST-инструкций для __init__.
        """
        stmts: List[Any] = []

        for el in elements:
            role = el["role"]
            var_name = el["var_name"]
            class_name_ref = el.get("class_name_ref")  # If generated nested class
            custom_import_name = None
            if el.get("custom_import_module"):
                # It's a custom imported component
                cls_obj = el.get("class")
                if cls_obj and hasattr(cls_obj, "__name__"):
                    custom_import_name = cls_obj.__name__
                else:
                    custom_import_name = str(cls_obj) if cls_obj else None

            # Check duplication in this scope
            if var_name in leaf_seen:
                leaf_seen[var_name] += 1
                var_name = f"{var_name}_{leaf_seen[var_name]}"
            else:
                leaf_seen[var_name] = 1  # Start count

            # Determine class name
            element_class = "Element"
            if custom_import_name:
                element_class = custom_import_name
            elif class_name_ref:
                element_class = class_name_ref
            elif role in ROLE_TO_CLASS:
                element_class = ROLE_TO_CLASS[role].__name__

            # Init kwargs
            init_kwargs = el["init_kwargs"].copy()
            # Ensure name matches var_name (in case of renaming)
            init_kwargs["name"] = var_name

            # Smart Table: Add row_type if available
            if el.get("row_class_ref"):
                init_kwargs["row_type"] = el["row_class_ref"]

            # If using custom class or nested class, we generally pass name/accessible_name if they accept it.
            # Standard Elements accept them.
            # Custom components might too (inheriting Element).

            keywords = []
            for k, v in init_kwargs.items():
                val_node: ast.expr = ast.Constant(value=v)
                # If value is a class definition (string ref), we need ast.Name
                if k == "row_type":
                    val_node = ast.Name(id=v, ctx=ast.Load())

                keywords.append(ast.keyword(arg=k, value=val_node))

            # Call Construction: ElementClass(name="...", ...)
            element_call = ast.Call(
                func=ast.Name(id=element_class, ctx=ast.Load()),
                args=[],
                keywords=keywords,
            )

            # Check for Unstable Locator
            # If no text, no accessible name, no test_id, no placeholder, and NO index -> Unstable?
            # Elements with explicit index are stable by definition (they target structural position).
            has_stable_locator = any(
                k in init_kwargs
                for k in [
                    "text",
                    "accessible_name",
                    "test_id",
                    "placeholder",
                    "locator",
                    "index",
                    "column_header",
                ]
            )
            if not has_stable_locator and role not in [
                "document",
                "generic",
                "row",
                "rowgroup",
            ]:  # row/rowgroup often structural only
                # Add TODO comment
                stmts.append(
                    ast.Expr(value=ast.Constant(value="TODO: Unstable Locator"))
                )

            # Parent Add: self.parent.add_element(...)
            # If parent_var is "self", direct. If "self.banner", also direct.

            # Smart Preservation Override Check
            # If this element corresponds to a manually written assignment in leaf_overrides,
            # we try to preserve that EXACT assignment AST?
            # Or simplified: if 'banner' exists in leaf_overrides, we check if we should skip?
            # Current logic: leaf_overrides used for 'leaf' fields match.
            # Impl: If we have overrides, we might need complex matching.
            # For now standard generation.

            add_call = ast.Call(
                func=ast.Attribute(
                    value=(
                        ast.Name(id=parent_var, ctx=ast.Load())
                        if "." not in parent_var
                        else self._create_attribute_chain(parent_var)
                    ),
                    attr="add_element",
                    ctx=ast.Load(),
                ),
                args=[element_call],
                keywords=[],
            )

            # Assign: parent_var.var_name = ...
            # target_value = ast.Name(id="self", ctx=ast.Load())
            if parent_var != "self":
                # target_value = self._create_attribute_chain(parent_var)
                pass

            # Note: ast.Assign targets require ctx=Store() on the final attribute
            # _create_attribute_chain returns separate nodes with Load().
            # We need to construct the Store() target manually.
            if parent_var == "self":
                target_node = ast.Attribute(
                    value=ast.Name(id="self", ctx=ast.Load()),
                    attr=var_name,
                    ctx=ast.Store(),
                )
            else:
                # parent_var is e.g. "self.foo", we want "self.foo.var_name"
                # We reuse _create_attribute_chain for "self.foo" (Load), then add attr.
                parent_node = self._create_attribute_chain(parent_var)
                target_node = ast.Attribute(
                    value=parent_node, attr=var_name, ctx=ast.Store()
                )

            assign = ast.Assign(targets=[target_node], value=add_call)

            stmts.append(assign)

            # Recursion
            if not custom_import_name and not class_name_ref:
                # Standard element, generate children appended to it
                new_parent = (
                    f"{parent_var}.{var_name}"
                    if parent_var != "self"
                    else f"self.{var_name}"
                )
                if el["children"]:
                    # Create NEW scope for children names properties
                    child_seen: Dict[str, Any] = {}
                    child_stmts = self._build_init_body_ast(
                        el["children"],
                        new_parent,
                        path_stack + [var_name],
                        context,
                        leaf_overrides,
                        child_seen,  # Pass new scope
                    )
                    stmts.extend(child_stmts)

        return stmts

    def _create_attribute_chain(self, dot_path: str) -> ast.expr:
        parts = dot_path.split(".")
        if len(parts) == 1:
            return ast.Name(id=parts[0], ctx=ast.Load())

        value: ast.expr = ast.Name(id=parts[0], ctx=ast.Load())
        for part in parts[1:]:
            value = ast.Attribute(value=value, attr=part, ctx=ast.Load())
        return value

    def extract_field_mappings(self, class_node: ast.ClassDef) -> Dict[str, List[str]]:
        """
        Анализирует AST существующего класса и находит маппинг:
        var_name -> [locator_chain] (?)

        For now: returns map of defined fields to detect prescence.
        """
        mappings: Dict[str, Any] = {}

        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            return {}

        for stmt in init_method.body:
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if (
                        isinstance(target, ast.Attribute)
                        and isinstance(target.value, ast.Name)
                        and target.value.id == "self"
                    ):
                        mappings[target.attr] = []  # Found field

        return mappings

    def _compute_test_id_prefix(self) -> str:
        """Находит общий префикс для test_id по токенам '-', '_'."""
        if not self._seen_test_ids or len(self._seen_test_ids) < 2:
            return ""

        # Dummy impl relies on external setting
        return ""
