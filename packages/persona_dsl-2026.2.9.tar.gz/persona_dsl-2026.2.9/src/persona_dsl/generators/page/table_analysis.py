from typing import List, Dict, Any
import os
from .utils import sanitize_name


def identify_table_prototypes(elements: List[Dict[str, Any]]) -> None:
    """
    Analyzes Tables to detect repetitive Row patterns.
    If found, marks the Table as having a prototype and cleans up children.
    """
    for el in elements:
        role = el.get("role")
        children = el.get("children", [])

        # Recurse
        if children:
            identify_table_prototypes(children)

        if role in ("table", "grid") and children:
            # Look for 'row' elements (could be direct or inside rowgroup)
            rows = []
            rowgroups = [c for c in children if c.get("role") == "rowgroup"]
            direct_rows = [c for c in children if c.get("role") == "row"]

            rows.extend(direct_rows)
            for rg in rowgroups:
                rows.extend(
                    [c for c in rg.get("children", []) if c.get("role") == "row"]
                )

            # Filter out "header" rows (usually <th> inside).
            data_rows = []
            for r in rows:
                cells = r.get("children", [])
                has_headers = any(c.get("role") == "columnheader" for c in cells)
                if not has_headers:
                    data_rows.append(r)

            if len(data_rows) >= 1:
                # Pick the last data row as prototype
                prototype_row = data_rows[-1]

                # Mark Table
                el["has_row_prototype"] = True
                el["row_prototype"] = prototype_row

                # Derive Component Name
                table_name = el.get("var_name", "table")
                cleaned = table_name.replace("_", " ").title().replace(" ", "")
                el["is_table_component"] = True
                el["class_name_ref"] = f"{cleaned}Table"
                el["row_class_name"] = "Row"

                # SEMANTIC NAMING: Map Prototype Cells to Headers
                header_row = None
                if len(rows) > len(data_rows):
                    for r in rows:
                        if r not in data_rows:
                            cells = r.get("children", [])
                            if any(c.get("role") == "columnheader" for c in cells):
                                header_row = r
                                break

                if header_row and prototype_row:
                    # Extract Column Names
                    headers = []
                    h_cells = header_row.get("children", [])
                    for cell in h_cells:
                        h_name = cell.get("accessible_name") or cell.get("name") or ""
                        headers.append(h_name)

                    # Apply to Prototype
                    p_cells = prototype_row.get("children", [])

                    for i, cell in enumerate(p_cells):
                        if i < len(headers):
                            h_name = headers[i]
                            if h_name:
                                semantic_name = sanitize_name(h_name)

                                # Update cell definitions
                                cell["var_name"] = semantic_name
                                cell["name"] = semantic_name

                                if "init_kwargs" in cell:
                                    cell["init_kwargs"]["name"] = semantic_name
                                    if "accessible_name" in cell["init_kwargs"]:
                                        del cell["init_kwargs"]["accessible_name"]

                                    # ADD ROBUST COLUMN HEADER
                                    cell["init_kwargs"]["column_header"] = h_name

                                    # Remove index
                                    if "index" in cell["init_kwargs"]:
                                        del cell["init_kwargs"]["index"]

                    # Recursive Generalization of Internals
                    for i, p_cell in enumerate(p_cells):
                        corresponding_cells = []
                        for r in data_rows:
                            r_children = r.get("children", [])
                            if i < len(r_children):
                                corresponding_cells.append(r_children[i])

                        generalize_children(p_cell, corresponding_cells)

                # Clean up children: remove generated rows
                new_children = []
                for child in children:
                    c_role = child.get("role")
                    if c_role in ("row", "rowgroup"):
                        continue
                    new_children.append(child)

                el["children"] = new_children


def generalize_children(
    proto_el: Dict[str, Any], other_els: List[Dict[str, Any]]
) -> None:
    if not proto_el.get("children"):
        return

    p_children = proto_el["children"]

    for idx, p_child in enumerate(p_children):
        counterparts = []
        for other in other_els:
            o_children = other.get("children", [])
            if idx < len(o_children):
                counterparts.append(o_children[idx])

        if not counterparts:
            continue

        def get_acc(el: Dict[str, Any]) -> str:
            return (
                el.get("accessible_name")
                or el.get("init_kwargs", {}).get("accessible_name")
                or el.get("text")
                or ""
            )

        acc_names = [get_acc(p_child)] + [get_acc(c) for c in counterparts]
        acc_names = [a for a in acc_names if a]

        if not acc_names:
            generalize_children(p_child, counterparts)
            continue

        common = os.path.commonprefix(acc_names).strip()

        if len(common) >= 3:
            p_child["accessible_name"] = common
            if "init_kwargs" in p_child:
                p_child["init_kwargs"]["accessible_name"] = common

            new_name = sanitize_name(common)
            p_child["name"] = new_name
            p_child["var_name"] = new_name
            if "init_kwargs" in p_child:
                p_child["init_kwargs"]["name"] = new_name
        else:
            p_child["accessible_name"] = None
            if "init_kwargs" in p_child:
                if "accessible_name" in p_child["init_kwargs"]:
                    del p_child["init_kwargs"]["accessible_name"]

        generalize_children(p_child, counterparts)
