from typing import Any, Dict

from persona_dsl.pages.elements import Element

# NOTE: PageGenerator is only needed for type checking to avoid circular imports
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class VirtualPage:
    """
    Динамическая страница, построенная на основе ARIA-снепшота (dict) в памяти.
    Позволяет обращаться к элементам по структуре (page.banner.button) без генерации файла.
    """

    def __init__(self, snapshot: Dict[str, Any]):
        from persona_dsl.generators import PageGenerator

        self._snapshot = snapshot
        # Используем генератор для получения маппинга ролей на классы,
        # но логику построения реализуем упрощенно для runtime-объектов
        self._generator = PageGenerator()
        self._root = self._build_tree(snapshot)

    @property
    def root(self) -> Element:
        return self._root

    def _sanitize_name(self, name: str) -> str:
        from persona_dsl.generators.page.utils import sanitize_name

        return sanitize_name(name)

    def _build_tree(self, node: Dict[str, Any]) -> Element:
        role = node.get("role", "generic")
        name = node.get("name", "")
        ref = node.get("ref")

        # Определяем класс элемента
        from persona_dsl.generators.page.utils import ROLE_TO_CLASS

        cls = ROLE_TO_CLASS.get(role, Element)

        # Создаем инстанс
        # Мы не знаем точное имя переменной здесь, так как оно зависит от контекста родителя.
        # Используем роль/имя как временное имя.
        base_name = self._sanitize_name(name) or role

        kwargs: Dict[str, Any] = {
            "name": base_name,
            "accessible_name": name,
            "aria_ref": ref,
        }
        # Если это базовый класс Element, ему нужно передать role явно.
        # Если это подкласс (Button, Link и т.д.), у них role обычно init=False и задан дефолтом.
        if cls is Element:
            kwargs["role"] = role

        el = cls(**kwargs)

        # Обрабатываем детей
        children = node.get("children", [])

        # Для именования детей нужно следить за уникальностью в рамках этого родителя
        used_names = set()

        for child_node in children:
            child_el = self._build_tree(child_node)

            # Придумываем имя для ребенка
            child_role = child_node.get("role", "element")
            child_aria_name = child_node.get("name", "")

            var_name_base = self._sanitize_name(child_aria_name) or child_role

            # Уникализация
            final_name = var_name_base
            i = 1
            while final_name in used_names or hasattr(el, final_name):
                final_name = f"{var_name_base}_{i}"
                i += 1

            used_names.add(final_name)

            # Обновляем имя элемента
            child_el.name = final_name

            # Добавляем в родителя
            # Используем add_element, чтобы прописались parent ссылки и _elements
            el.add_element(child_el, alias=final_name)

        return el

    def __getattr__(self, name: str) -> Element:
        # Делегируем доступ к корневому элементу
        return getattr(self._root, name)
