from .call_operation import CallOperation
from .operation_result import OperationResult

__all__ = ["CallOperation", "OperationResult"]
