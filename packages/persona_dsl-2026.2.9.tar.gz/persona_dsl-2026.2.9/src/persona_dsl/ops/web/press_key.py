from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class PressKey(Ops):
    """
    Атомарное действие: нажать клавишу на элементе.
    Приоритет поиска: по ARIA-роли и имени, затем по `locator`.
    Поддерживает проброс аргументов в Playwright (timeout, no_wait_after, etc).
    """

    def __init__(self, element: Element, key: str, **kwargs: Any):
        """
        Args:
            element: Экземпляр элемента, на котором нажимается клавиша.
            key: Имя клавиши для нажатия (например, 'Enter', 'Tab', 'ArrowDown').
            **kwargs: Дополнительные аргументы для Playwright locator.press().
        """
        if not isinstance(element, Element):
            raise TypeError(
                f"PressKey ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.key = key
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} нажимает клавишу '{self.key}' на элементе '{self.element.name}'{extra}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        locator.press(self.key, **self.kwargs)
