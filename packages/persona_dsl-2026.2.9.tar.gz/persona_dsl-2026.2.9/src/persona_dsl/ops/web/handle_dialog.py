from enum import Enum
from typing import Any, Optional

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId


class DialogAction(str, Enum):
    ACCEPT = "accept"
    DISMISS = "dismiss"


class HandleDialog(Ops):
    """
    Действие: Обработать следующий появившийся диалог (Alert/Confirm/Prompt).
    Настраивает одноразовый слушатель.
    """

    def __init__(
        self,
        action: DialogAction = DialogAction.ACCEPT,
        prompt_text: Optional[str] = None,
    ):
        self.action = action
        self.prompt_text = prompt_text

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} ожидает и обрабатывает диалог ({self.action})"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page

        from playwright.sync_api import Dialog

        def handler(dialog: Dialog) -> None:
            if self.action == DialogAction.ACCEPT:
                dialog.accept(prompt_text=self.prompt_text)
            else:
                dialog.dismiss()

        # Применяем .once(), чтобы обработать только один следующий диалог
        page.once("dialog", handler)
