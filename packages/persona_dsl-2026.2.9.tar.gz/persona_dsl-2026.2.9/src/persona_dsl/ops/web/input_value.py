from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class InputValue(Ops):
    """
    Бизнес-операция: получить текущее значение из поля ввода (input/textarea/select).
    Использует Playwright Locator.input_value() для корректного чтения значения.
    """

    def __init__(self, element: Element):
        self.element = element

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} запрашивает значение поля ввода '{self.element.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        return locator.input_value()
