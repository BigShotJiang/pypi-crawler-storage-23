from typing import Any, Generator, Optional

from persona_dsl.components.step import Step
from .click import Click
from persona_dsl.pages.elements import Element


class SelectOption(Step):
    """
    Выбирает опцию в выпадающем списке.
    Поддерживает как стандартные <select>, так и кастомные dropdowns (через клик).
    """

    def __init__(
        self,
        element: Element,
        value: Optional[str] = None,
        label: Optional[str] = None,
        index: Optional[int] = None,
    ) -> None:
        self.element = element
        self.value = value
        self.label = label
        self.index = index

        desc_parts = []
        if value:
            desc_parts.append(f"value='{value}'")
        if label:
            desc_parts.append(f"label='{label}'")
        if index is not None:
            desc_parts.append(f"index={index}")

        super().__init__(f"Выбрать опцию в {element}: {', '.join(desc_parts)}")

    def _run(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Generator[Any, Any, None]:
        browser = persona.skills["browser"]["default"]  # TODO: Robust skill getting
        page = browser.page

        # 1. Resolve locator
        # We need the underlying locator.
        # usually element.resolve(page) returns a Locator.
        locator = self.element.resolve(page)

        # 2. Check if it is a <select> tag
        tag_name = locator.evaluate("el => el.tagName", timeout=1000).lower()

        if tag_name == "select":
            # Use Playwright's select_option
            select_kwargs: dict[str, Any] = {}
            if self.value:
                select_kwargs["value"] = self.value
            if self.label:
                select_kwargs["label"] = self.label
            if self.index is not None:
                select_kwargs["index"] = self.index

            locator.select_option(**select_kwargs)
        else:
            # Custom Dropdown interactions
            # 1. Click to open (if not open?)
            # Heuristic: Click element, then wait for option?
            yield Click(self.element)

            # 2. Find option.
            # Usually option is in a separate layer (which we just fixed grouping for!).
            # But here we might not know the option element structure.
            # We try to use text matching globally or relative?
            # If we know the option text (label), we can try to click exact text.

            if self.label:
                # Try to find text in the page (assuming Portal raises it to root or visible layer).
                # This is risky but standard for "Select by Text" in custom dropdowns.
                yield Click(page.get_by_text(self.label, exact=True))
            elif self.value:
                # Value is often internal, might not be visible text.
                # Try text anyway or test-id?
                yield Click(page.get_by_text(self.value, exact=True))

            # Index is hard for custom dropdowns without improved structure knowledge.
