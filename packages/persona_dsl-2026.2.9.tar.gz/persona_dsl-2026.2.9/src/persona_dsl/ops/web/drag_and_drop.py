from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.pages.elements import Element
from persona_dsl.skills.core.skill_definition import SkillId


class DragAndDrop(Ops):
    """
    Действие: Перетащить элемент (source) на целевой элемент (target).
    Wrapper for: locator.drag_to(target_locator)
    """

    def __init__(self, source: Element, target: Element):
        self.source = source
        self.target = target

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} перетаскивает '{self.source}' на '{self.target}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        source_locator = self.source.resolve(page)
        target_locator = self.target.resolve(page)

        source_locator.drag_to(target_locator)
