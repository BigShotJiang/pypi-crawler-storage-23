from typing import Any, Union
import copy

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element, ElementList


class ElementsCount(Ops):
    """
    Бизнес-операция: подсчитать количество элементов, соответствующих прототипу.

    Принимает:
      - Element: будет посчитано количество совпадений для данного описания элемента.
      - ElementList: используется его прототип для построения локатора и подсчёта.
    """

    def __init__(self, element_or_list: Union[Element, ElementList]):
        if isinstance(element_or_list, ElementList):
            self._element = (
                element_or_list._prototype
            )  # noqa: SLF001 (осознанный доступ к прототипу)
        elif isinstance(element_or_list, Element):
            self._element = element_or_list
        else:
            raise TypeError("ElementsCount ожидает Element или ElementList")

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} подсчитывает количество элементов для '{self._element.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> int:
        page = persona.skill(SkillId.BROWSER).page
        # Базовый локатор — родитель, если он есть; иначе вся страница
        base = self._element.parent.resolve(page) if self._element.parent else page

        # Строим локатор для всех совпадений (index=None)
        # Using copy and modifying the copy is safer and more robust than manual constructor
        probe = copy.copy(self._element)
        probe.index = None

        locator = probe._get_playwright_locator(base)
        return locator.count()
