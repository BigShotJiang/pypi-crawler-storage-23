import allure
import requests
import time
from typing import Any, cast, Optional
from pydantic import TypeAdapter, ValidationError
from persona_dsl.utils.metrics import metrics
from .core.base import Skill


class UseAPI(Skill):
    """Навык для взаимодействия с REST API."""

    def __init__(
        self,
        session: requests.Session,
        base_url: str,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        retries: int = 0,
        backoff: float = 0.5,
        log_bodies: bool = False,
    ):
        super().__init__(session)
        self.base_url = base_url
        self.timeout = timeout
        self.retries = retries
        self.backoff = backoff
        self.log_bodies = log_bodies

    @classmethod
    def at(
        cls,
        base_url: str,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        retries: int = 0,
        backoff: float = 0.5,
        log_bodies: bool = False,
        default_headers: Optional[dict] = None,
    ) -> "UseAPI":
        session = requests.Session()
        session.verify = verify_ssl
        if default_headers:
            session.headers.update(default_headers)
        inst = cls(session, base_url, verify_ssl, timeout, retries, backoff, log_bodies)
        return inst

    @property
    def session(self) -> requests.Session:
        return cast(requests.Session, self._driver)

    def _full_url(self, path: str) -> str:
        """Строит полный URL из базового и относительного пути."""
        if path.startswith("http://") or path.startswith("https://"):
            return path
        base = self.base_url.rstrip("/")
        rel = path if path.startswith("/") else f"/{path}"
        return f"{base}{rel}"

    def _request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        """Обертка над requests с метриками, ретраями и опциональными вложениями в Allure."""
        url = self._full_url(path)
        status = None
        t0 = time.perf_counter()
        attempts = self.retries + 1
        last_exc = None
        try:
            for attempt in range(attempts):
                try:
                    # Преобразуем Pydantic-модели в dict перед отправкой (json/data могут содержать модели или их коллекции)
                    def _to_jsonable(obj: Any) -> Any:
                        if hasattr(obj, "model_dump"):
                            return obj.model_dump()
                        if isinstance(obj, dict):
                            return {k: _to_jsonable(v) for k, v in obj.items()}
                        if isinstance(obj, (list, tuple)):
                            return [_to_jsonable(x) for x in obj]
                        return obj

                    if "json" in kwargs:
                        kwargs["json"] = _to_jsonable(kwargs["json"])
                    if "data" in kwargs:
                        kwargs["data"] = _to_jsonable(kwargs["data"])

                    resp = self.session.request(
                        method=method.upper(),
                        url=url,
                        timeout=kwargs.pop("timeout", self.timeout),
                        **kwargs,
                    )
                    status = resp.status_code
                    # Повторяем при 5xx, если есть попытки
                    if 500 <= status < 600 and attempt < self.retries:
                        time.sleep(self.backoff * (2**attempt))
                        continue
                    if self.log_bodies:
                        req_body = kwargs.get("json", kwargs.get("data"))
                        # Собираем заголовки: session.headers (если доступны) + per-request headers
                        combined_headers = {}
                        try:
                            base_headers_obj = getattr(self.session, "headers", {})
                            base_headers = dict(base_headers_obj)
                        except Exception:
                            base_headers = {}
                        req_headers = {}
                        try:
                            if isinstance(kwargs.get("headers"), dict):
                                req_headers = dict(kwargs.get("headers") or {})
                        except Exception:
                            req_headers = {}
                        combined_headers.update(base_headers)
                        combined_headers.update(req_headers)
                        if "Authorization" in combined_headers:
                            combined_headers["Authorization"] = "***"
                        allure.attach(
                            f"Request: {method.upper()} {url}\nheaders={combined_headers}\nbody={req_body}",
                            "HTTP Request",
                            allure.attachment_type.TEXT,
                        )
                        allure.attach(
                            f"Response: status={resp.status_code}\nheaders={dict(resp.headers)}\nbody={resp.text[:1000]}",
                            "HTTP Response",
                            allure.attachment_type.TEXT,
                        )
                    return resp
                except requests.RequestException as e:
                    last_exc = e
                    if attempt < self.retries:
                        time.sleep(self.backoff * (2**attempt))
                        continue
                    raise
        except Exception:
            status = -1
            if last_exc:
                raise last_exc
            raise
        finally:
            duration = time.perf_counter() - t0
            tags = {"method": method.upper(), "endpoint": path, "status": status}
            metrics.gauge("api.request.duration", duration, tags)
            metrics.counter("api.request", tags).inc()
        # This code should be unreachable, as the loop will always either return a response
        # or raise an exception.
        raise RuntimeError(
            "Unreachable code in UseAPI._request reached"
        )  # pragma: no cover

    def get(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("PATCH", path, **kwargs)

    def head(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("HEAD", path, **kwargs)

    def options(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("OPTIONS", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> requests.Response:
        return self._request("DELETE", path, **kwargs)

    def _validate_as(self, data: Any, model_type: Any) -> Any:
        """
        Преобразует произвольный JSON в указанный тип с помощью Pydantic v2.
        Поддерживает сложные аннотации (например, list[MyModel]) через TypeAdapter.
        При ошибке валидации выбрасывает исключение с подробной диагностикой (без скрытых фолбеков).
        """
        try:
            return TypeAdapter(model_type).validate_python(data)
        except (ValidationError, TypeError) as e:
            raise ValueError(
                f"Валидация ответа API не прошла для типа {model_type}: {e}"
            ) from e

    def get_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает GET и валидирует JSON-ответ как указанный тип (Pydantic v2).
        Пример: api.get_json_as('/users/1', User) или api.get_json_as('/users', list[User])
        """
        resp = self.get(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def post_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает POST и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.post(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def put_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает PUT и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.put(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def patch_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает PATCH и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.patch(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def delete_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает DELETE и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.delete(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def head_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает HEAD и валидирует JSON-ответ как указанный тип (если сервер всё же возвращает тело).
        Примечание: согласно спецификации, ответ HEAD не должен содержать тело; метод добавлен для полноты API.
        """
        resp = self.head(path, **kwargs)
        # Если тело ответа пустое — это валидный случай для HEAD-запроса.
        if not resp.text:
            return None
        try:
            data = resp.json()
        except requests.JSONDecodeError as e:
            raise ValueError(
                f"HEAD {path}: ответ содержит тело, но оно не является валидным JSON: {e}"
            ) from e
        return self._validate_as(data, model_type)

    def options_json_as(self, path: str, model_type: Any, **kwargs: Any) -> Any:
        """
        Делает OPTIONS и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.options(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def release(self) -> None:
        """Освобождает ресурсы HTTP-клиента (закрывает Session)."""
        try:
            self.session.close()
        except Exception:
            pass

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        return super().forget()
