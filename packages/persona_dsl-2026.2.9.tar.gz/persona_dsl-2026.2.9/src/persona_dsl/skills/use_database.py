import time
from types import ModuleType
from typing import Any, Optional
from urllib.parse import urlparse
from persona_dsl.utils.metrics import metrics
from .core.base import Skill


class UseDatabase(Skill):
    """Навык для взаимодействия с реляционными базами данных."""

    def __init__(self, dsn: str, driver: ModuleType):
        super().__init__(driver)
        self.dsn = dsn
        self.connection: Optional[Any] = None

    @staticmethod
    def with_dsn(dsn: str, driver: ModuleType) -> "UseDatabase":
        """Фабричный метод для создания экземпляра навыка.

        Args:
            dsn: DSN-строка для подключения к базе данных.
            driver: Модуль-драйвер для работы с БД (например, psycopg или oracledb).

        Returns:
            Экземпляр UseDatabase.
        """
        return UseDatabase(dsn, driver)

    def get_connection(self) -> Any:
        """Возвращает активное соединение с базой данных.

        Если соединение отсутствует или закрыто, создает новое.

        Returns:
            Активное соединение с БД.
        """
        need_reconnect = (
            self.connection is None
            or getattr(self.connection, "closed", False)
            or (
                callable(getattr(self.connection, "is_healthy", None))
                and not self.connection.is_healthy()
            )
        )
        if need_reconnect:
            # Поддерживаем корректные способы подключения драйверов:
            # - pg8000: требуем DSN в URL-формате postgresql://user:pass@host:port/db и конструируем именованные аргументы
            # - psycopg/psycopg2: принимают conninfo строкой (передаём как есть)
            # - oracledb: допускает строку вида "user/password@dsn" как позиционный аргумент
            drv_name = getattr(self.driver, "__name__", "") or ""
            if drv_name.startswith("pg8000"):
                u = urlparse(self.dsn)
                if u.scheme not in (
                    "postgresql",
                    "postgres",
                    "postgresql+pg8000",
                    "postgres+pg8000",
                ):
                    raise ValueError(
                        "Для драйвера pg8000 DSN должен быть в URL-формате: postgresql://user:pass@host:port/dbname"
                    )
                user = u.username or ""
                password = u.password or ""
                host = u.hostname or ""
                port = int(u.port or 5432)
                db = u.path.lstrip("/") if u.path else ""
                if not (user and host and db):
                    raise ValueError(
                        "pg8000: некорректный DSN URL (требуются user, host, database). Пример: postgresql://user:pass@localhost:5432/db"
                    )
                self.connection = self.driver.connect(
                    user=user, password=password, host=host, port=port, database=db
                )
            else:
                # Для остальных драйверов используем conninfo/позиционный аргумент согласно их API.
                self.connection = self.driver.connect(self.dsn)
        return self.connection

    def execute(self, query: str, params: Optional[Any] = None) -> Any:
        """Выполняет SQL-запрос с метриками и возвращает первую строку результата.

        Args:
            query: SQL-запрос.
            params: Параметры запроса.

        Returns:
            Первая строка результата (или None).
        """
        t0 = time.perf_counter()
        status = "ok"
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or ())
                result = cursor.fetchone()
                conn.commit()
                return result
            finally:
                try:
                    cursor.close()
                except Exception:
                    pass
        except Exception:
            status = "error"
            raise
        finally:
            duration = time.perf_counter() - t0
            tags = {
                "driver": self.driver.__name__,
                "query": query.split()[0].upper() if query else "UNKNOWN",
                "status": status,
            }
            metrics.gauge("db.query.duration", duration, tags)
            metrics.counter("db.query", tags).inc()

    def release(self) -> None:
        """Закрывает соединение с БД, если оно открыто."""
        if self.connection:
            if hasattr(self.connection, "closed") and not self.connection.closed:
                self.connection.close()
            elif hasattr(self.connection, "close"):  # Для oracledb, где нет closed
                self.connection.close()
            self.connection = None

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        return super().forget()
