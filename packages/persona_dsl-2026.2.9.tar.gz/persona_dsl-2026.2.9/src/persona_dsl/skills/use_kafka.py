import logging
from typing import Optional, List, Dict, Any

from kafka import KafkaConsumer, KafkaProducer

from .core.base import Skill

logger = logging.getLogger(__name__)


class UseKafka(Skill):
    """Навык для взаимодействия с Kafka."""

    def __init__(
        self,
        bootstrap_servers: str,
        group_id: Optional[str] = None,
        from_offset: str = "latest",  # "earliest" | "latest"
        timeout: float = 10.0,
    ):
        super().__init__(driver=None)
        self.bootstrap_servers = bootstrap_servers
        self.group_id = group_id
        self.from_offset = (
            from_offset if from_offset in ("earliest", "latest") else "latest"
        )
        self.timeout = float(timeout)
        self._producer = None
        self._consumer = None

    @staticmethod
    def with_servers(
        bootstrap_servers: str,
        group_id: Optional[str] = None,
        from_offset: str = "latest",
        timeout: float = 10.0,
    ) -> "UseKafka":
        """Фабричный метод для создания экземпляра навыка."""
        return UseKafka(
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            from_offset=from_offset,
            timeout=timeout,
        )

    def _get_producer(self) -> Any:
        if self._producer is None:
            self._producer = KafkaProducer(bootstrap_servers=self.bootstrap_servers)
        return self._producer

    def _get_consumer(self, topic: str) -> Any:
        if self._consumer is None:
            auto_offset_reset = self.from_offset
            consumer_timeout_ms = int(self.timeout * 1000)
            self._consumer = KafkaConsumer(
                topic,
                bootstrap_servers=self.bootstrap_servers,
                group_id=self.group_id,
                enable_auto_commit=False,
                auto_offset_reset=auto_offset_reset,
                consumer_timeout_ms=consumer_timeout_ms,
            )
        return self._consumer

    def send_message(
        self,
        topic: str,
        message: bytes,
        key: Optional[bytes] = None,
        headers: Optional[List[tuple[str, bytes]]] = None,
    ) -> None:
        """Отправляет сообщение в указанный топик Kafka."""
        producer = self._get_producer()
        try:
            future = producer.send(topic, key=key, value=message, headers=headers or [])
            future.get(timeout=self.timeout)
            producer.flush(timeout=self.timeout)
        except Exception as e:
            logger.error(f"[UseKafka] Ошибка при отправке сообщения в '{topic}': {e}")
            raise

    def consume(
        self,
        topic: str,
        max_messages: int = 1,
        timeout: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """Читает сообщения из топика (до max_messages или до таймаута)."""
        consumer = self._get_consumer(topic)
        results: List[Dict[str, Any]] = []
        end_after = timeout or self.timeout
        try:
            import time

            start = time.time()
            while len(results) < max_messages and (time.time() - start) < end_after:
                try:
                    msg = next(consumer)
                except StopIteration:
                    break
                results.append(
                    {
                        "topic": msg.topic,
                        "partition": msg.partition,
                        "offset": msg.offset,
                        "timestamp": msg.timestamp,
                        "key": msg.key,
                        "value": msg.value,
                        "headers": dict(msg.headers or []),
                    }
                )
        except Exception as e:
            logger.error(f"[UseKafka] Ошибка при чтении сообщений из '{topic}': {e}")
            raise
        return results

    def release(self) -> None:
        """Закрывает все соединения и освобождает ресурсы."""
        try:
            if self._producer:
                self._producer.flush(timeout=self.timeout)
                self._producer.close()
        except Exception:
            pass
        try:
            if self._consumer:
                self._consumer.close()
        except Exception:
            pass
        self._producer = None
        self._consumer = None

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        return super().forget()
