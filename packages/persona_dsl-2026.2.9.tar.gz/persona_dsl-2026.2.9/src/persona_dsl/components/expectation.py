from .step import Step


class Expectation(Step):
    """
    Алиас для Step, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass
