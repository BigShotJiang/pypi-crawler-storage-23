from .base_step import BaseStep


class Ops(BaseStep):
    """Базовый класс для всех низкоуровневых, исполняемых операций."""

    pass
