from typing import Any

from hamcrest import assert_that, equal_to

from persona_dsl.components.expectation import Expectation
from persona_dsl.utils.path import extract_by_path


class PathEqual(Expectation):
    """
    Проверяет, что значение по указанному пути (dot/bracket нотация) внутри объекта равно ожидаемому.

    Пример:
        PathEqual("a.b[0].c", 42).check({"a": {"b": [{"c": 42}]}})  # проходит
    """

    def __init__(self, path: str, expected: Any):
        self.path = path
        self.expected = expected

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        actual = args[0]
        value = extract_by_path(actual, self.path)
        assert_that(value, equal_to(self.expected))

    def _get_step_description(self, persona: Any) -> str:
        return f"значение по пути '{self.path}' равно '{self.expected}'"
