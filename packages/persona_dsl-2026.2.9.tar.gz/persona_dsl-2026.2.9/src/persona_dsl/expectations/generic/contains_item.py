from typing import Any

from persona_dsl.components.expectation import Expectation
from hamcrest import assert_that, has_item


class ContainsItem(Expectation):
    """Проверяет, что список содержит указанный элемент."""

    def __init__(self, expected_item: Any):
        self.expected_item = expected_item

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        """Проверяет, что список содержит указанный элемент."""
        actual_list = args[0]
        assert_that(actual_list, has_item(self.expected_item))

    def _get_step_description(self, persona: Any) -> str:
        return f"содержит элемент '{self.expected_item}'"
