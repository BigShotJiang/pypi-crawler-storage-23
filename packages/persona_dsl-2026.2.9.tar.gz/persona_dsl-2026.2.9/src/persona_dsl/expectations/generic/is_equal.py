from typing import Any

from persona_dsl.components.expectation import Expectation
from hamcrest import assert_that, equal_to


class IsEqualTo(Expectation):
    """Проверяет, что фактическое значение равно ожидаемому."""

    def __init__(self, expected: Any):
        """Инициализирует ожидание.

        Args:
            expected: Ожидаемое значение.
        """
        self.expected = expected

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        """Проверяет, что фактическое значение равно ожидаемому."""
        actual = args[0]
        assert_that(actual, equal_to(self.expected))

    def _get_step_description(self, persona: Any) -> str:
        return f"равно '{self.expected}'"
