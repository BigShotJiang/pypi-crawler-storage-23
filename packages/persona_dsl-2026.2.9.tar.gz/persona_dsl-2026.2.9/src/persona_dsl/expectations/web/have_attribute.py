from typing import Any, Optional

from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.pages.elements import Element
from persona_dsl.skills.core.skill_definition import SkillId


class HaveAttribute(Expectation):
    """
    Проверка: Элемент имеет атрибут с ожидаемым значением (или любым, если value=None).
    """

    def __init__(self, name: str, value: Optional[str] = None, timeout: float = 5000):
        self.name = name
        self.value = value
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        val_desc = f"='{self.value}'" if self.value is not None else ""
        return f"имеет атрибут '{self.name}'{val_desc}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        element_or_locator = args[0]
        page = persona.skill(SkillId.BROWSER).page

        if isinstance(element_or_locator, Element):
            locator = element_or_locator.resolve(page)
        else:
            locator = element_or_locator

        if self.value is not None:
            expect(locator).to_have_attribute(
                self.name, self.value, timeout=self.timeout
            )
        else:
            # Playwright to_have_attribute требует значение. Для проверки просто наличия можно проверить regex ".*"
            expect(locator).to_have_attribute(self.name, r".*", timeout=self.timeout)
