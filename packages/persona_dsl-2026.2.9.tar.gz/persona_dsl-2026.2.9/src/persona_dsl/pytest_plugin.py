from __future__ import annotations
import os
import json
import time
import logging
import functools
from enum import Enum
from functools import lru_cache
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Tuple, Type, List, Optional, Generator, TYPE_CHECKING
from urllib.parse import urlparse

import allure
import pytest
import yaml
import requests

if TYPE_CHECKING:
    from persona_dsl.components.expectation import Expectation
    from persona_dsl.persona import Persona
    from persona_dsl.utils.config import Config
from persona_dsl.skills.core.skill_definition import SkillId

logger = logging.getLogger(__name__)


class DataDrivenError(Exception):
    """Кастомное исключение для ошибок в @data_driven."""

    pass


def _taas_ready() -> bool:
    """
    Проверяет, корректно ли сконфигурирован контекст TaaS:
    - установлен TAAS_RUN_ID
    - TAAS_STREAM_MAXLEN является положительным целым
    """
    if not os.environ.get("TAAS_RUN_ID"):
        return False
    raw = os.getenv("TAAS_STREAM_MAXLEN", "10000")
    try:
        return int(raw) > 0
    except Exception:
        return False


# --- Allure Step Instrumentation ---
_original_allure_step = allure.step


@contextmanager
def _instrumented_allure_step(description: str) -> Generator[Any, None, None]:
    """Обертка над allure.step, которая отправляет события в TaaS."""
    from .utils.taas_integration import publish_taas_event

    start_time = time.time()
    publish_taas_event(
        {
            "event": "step_start",
            "type": "allure_step",
            "data": {"description": description, "timestamp": start_time},
        }
    )

    status = "passed"
    try:
        with _original_allure_step(description) as s:
            yield s
    except Exception:
        status = "failed"
        raise
    finally:
        end_time = time.time()
        duration = end_time - start_time
        publish_taas_event(
            {
                "event": "step_end",
                "type": "allure_step",
                "data": {
                    "description": description,
                    "timestamp": end_time,
                    "duration": duration,
                    "status": status,
                },
            }
        )


# --- End Allure Step Instrumentation ---


def _get_skill_config(
    config: Config, skill_type: str, name: str
) -> Optional[Dict[str, Any]]:
    stype_config = config.skills.get(skill_type)
    if stype_config is None:
        return None

    if name == "default":
        # Strategy for default config:
        # 1. Check for explicit "default" key
        if "default" in stype_config and isinstance(stype_config["default"], dict):
            return stype_config["default"]

        # 2. If no explicit "default", treat the whole dictionary as the default config.
        # This allows nested params like "viewport" or "custom_settings" to be part of the config
        # without being mistaken for named profiles.
        # If users want mixed scenarios (default params + named profiles), they MUST use explicit "default" key.
        return stype_config

    named_config = stype_config.get(name)
    return named_config if isinstance(named_config, dict) else None


def _create_selenoid_session(
    hub_url: str, capabilities: Dict[str, Any], retries: int = 3, timeout: float = 10.0
) -> Tuple[str, str]:
    """
    Создает сессию в Selenoid через WebDriver API с повторными попытками.
    Возвращает кортеж (ws_endpoint, session_id).
    """
    session_url = f"{hub_url.rstrip('/')}/wd/hub/session"
    last_error: Optional[Exception] = None

    for attempt in range(retries + 1):
        try:
            logger.info(
                f"Попытка создания сессии Selenoid ({attempt + 1}/{retries + 1})..."
            )
            # requests imported at module level
            resp = requests.post(
                session_url, json={"capabilities": capabilities}, timeout=timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                # Формат ответа WebDriver: { "value": { "sessionId": "...", "capabilities": ... } }
                value = data.get("value", {})
                session_id = value.get("sessionId") or data.get("sessionId")

                if not session_id:
                    raise RuntimeError(f"Selenoid не вернул sessionId: {data}")

                # Формируем WS URL для CDP
                parsed = urlparse(hub_url)
                ws_scheme = "wss" if parsed.scheme == "https" else "ws"
                ws_endpoint = f"{ws_scheme}://{parsed.netloc}/devtools/{session_id}"

                logger.info(f"Сессия Selenoid создана: {session_id}")
                return ws_endpoint, session_id
            else:
                logger.warning(
                    f"Ошибка создания сессии Selenoid (Code {resp.status_code}): {resp.text}"
                )
        except Exception as e:
            last_error = e
            logger.warning(f"Ошибка подключения к Selenoid: {e}")

        if attempt < retries:
            time.sleep(2.0)

    raise RuntimeError(
        f"Не удалось создать сессию Selenoid после {retries + 1} попыток. Последняя ошибка: {last_error}"
    )


def _get_persona_config(config: Config, role: str) -> Optional[Dict[str, Any]]:
    personas_config = config.personas
    if role == "default":
        if "default" in personas_config and isinstance(
            personas_config["default"], dict
        ):
            return personas_config["default"]
        implicit_config = {
            k: v for k, v in personas_config.items() if not isinstance(v, dict)
        }
        return implicit_config or None
    named_config = personas_config.get(role)
    return named_config if isinstance(named_config, dict) else None


def _build_chromium_args(cfg: Dict[str, Any]) -> List[str]:
    """Строит список аргументов командной строки для Chromium-based браузеров."""
    args = list(cfg.get("args") or [])

    if cfg.get("no_sandbox", False):
        args.append("--no-sandbox")

    disable_features = list(cfg.get("disable_features") or [])

    if cfg.get("ignore_https_errors", False):
        args.append("--ignore-certificate-errors")
        # Отключаем принудительное обновление до HTTPS и связанные с ним предупреждения
        if "HttpsUpgrades" not in disable_features:
            disable_features.append("HttpsUpgrades")
        if "EnforceHttps" not in disable_features:
            disable_features.append("EnforceHttps")

        # Для HTTP сайтов отключаем предупреждения о небезопасности
        base_url = cfg.get("base_url")
        if base_url:
            parsed_url = urlparse(base_url)
            if parsed_url.scheme == "http":
                origin = f"{parsed_url.scheme}://{parsed_url.netloc}"
                args.append(f"--unsafely-treat-insecure-origin-as-secure={origin}")

    if cfg.get("start_maximized", False):
        args.append("--start-maximized")

    if disable_features:
        features_str = ",".join(disable_features)
        args.append(f"--disable-features={features_str}")

    return args


class PersonaDispatcher:
    def __init__(
        self,
        config: Config,
        persona_class: Type[Persona],
        request: pytest.FixtureRequest,
    ):
        self.config = config
        self.persona_class = persona_class
        self.request = request
        self._personas: Dict[str, Persona] = {}
        self._resources: Dict[str, Any] = {}

    def __call__(self, role_id: str = "default") -> Persona:
        return self.persona(role_id)

    def persona(self, role_id: str | Enum = "default") -> Persona:
        role_id_str = role_id.value if isinstance(role_id, Enum) else str(role_id)
        if role_id_str not in self._personas:
            persona_cfg = _get_persona_config(self.config, role_id_str)
            if not persona_cfg:
                if role_id_str == "default":
                    # Создаем пустую конфигурацию для персоны по умолчанию
                    persona_cfg = {"name": "Персона"}
                else:
                    pytest.fail(
                        f"Конфигурация для роли '{role_id_str}' не найдена в 'config/{self.config.env}.yaml'"
                    )
            persona_name = persona_cfg.get("name", "Персона")
            new_persona = self.persona_class(name=persona_name)

            # Инициализация RolePersona
            new_persona.role_id = role_id_str
            new_persona.params = persona_cfg or {}

            auth_key = persona_cfg.get("auth_key")
            if auth_key:
                if not isinstance(auth_key, str):
                    pytest.fail(
                        f"Поле 'auth_key' для роли '{role_id_str}' должно быть строкой.",
                        pytrace=False,
                    )
                if auth_key not in self.config.auth:
                    pytest.fail(
                        f"Ключ авторизации '{auth_key}' для роли '{role_id_str}' не найден в config/auth.yaml",
                        pytrace=False,
                    )
                secrets_data = self.config.auth.get(auth_key)
                if not isinstance(secrets_data, dict):
                    pytest.fail(
                        f"Данные для ключа авторизации '{auth_key}' в config/auth.yaml должны быть словарём.",
                        pytrace=False,
                    )
                new_persona.secrets = secrets_data
            else:
                new_persona.secrets = {}

            # LCL-37: Прокидываем конфигурацию ретраев
            new_persona.retries_config = self.config.retries or {}

            def provider(p: Persona, st: SkillId, sn: str) -> Any:
                return self._get_skill_for_persona(p, st, sn, role_id_str)

            new_persona.set_skill_provider(provider)
            # Экспонируем pytest request внутрь персоны для Ops, которым нужен доступ к CLI-флагам
            setattr(new_persona, "_pytest_request", self.request)
            self._personas[role_id_str] = new_persona
        return self._personas[role_id_str]

    def _get_skill_for_persona(
        self, persona: Persona, skill_id: Any, name: str, role_id: str
    ) -> Any:
        name_str = name
        # skill_id is SkillId(str, Enum), so .value works if it is an instance,
        # but here we rely on it being string-like or having .value
        skill_val = getattr(skill_id, "value", str(skill_id))
        skill_key = f"{skill_val}.{name_str}"
        if skill_key not in persona.skills.get(skill_val, {}):
            skill_instance = self._create_skill_instance(skill_id, name_str, role_id)
            persona.learn((skill_val, name_str, skill_instance))
        return persona.skills[skill_val][name_str]

    def _create_skill_instance(self, skill_id: Any, name: str, role_id: str) -> Any:
        cfg = _get_skill_config(self.config, skill_id.value, name)
        if cfg is None:
            pytest.fail(
                f"Конфигурация для навыка '{skill_id.value}.{name}' не найдена."
            )

        # skill_id can be SkillId enum or string
        skill_val = getattr(skill_id, "value", str(skill_id))

        if skill_val == "browser":
            from persona_dsl.skills.use_browser import UseBrowser
            from playwright.sync_api import (
                sync_playwright,
            )  # локальный импорт для избежания тяжёлых импортов на уровне модуля

            if "playwright" not in self._resources:
                self._resources["playwright"] = sync_playwright().start()
                pw = self._resources["playwright"]
                browser_type = getattr(pw, cfg.get("type", "chromium"))

                selenoid_url = cfg.get("selenoid_url")
                ws_endpoint = cfg.get("ws_endpoint")

                if selenoid_url:
                    # Создание сессии в Selenoid
                    selenoid_opts = cfg.get("selenoid_options", {})

                    # Определяем browserName для Selenoid
                    requested_type = cfg.get("type", "chromium")
                    if requested_type == "sberbrowser":
                        browser_name = "sberbrowser"
                        # Playwright не знает про sberbrowser, используем chromium
                        browser_type = getattr(pw, "chromium")
                    elif requested_type == "chromium":
                        browser_name = "chrome"  # Selenoid обычно использует "chrome" или "chromium"
                    else:
                        browser_name = requested_type

                    # Базовые capabilities
                    caps = {
                        "browserName": browser_name,
                        "version": cfg.get("version", ""),
                        "enableVNC": selenoid_opts.get("enableVNC", True),
                        "enableVideo": selenoid_opts.get("enableVideo", False),
                    }
                    # Добавляем специфичные опции
                    if "goog:chromeOptions" in selenoid_opts:
                        caps["goog:chromeOptions"] = selenoid_opts["goog:chromeOptions"]

                    # Другие опции первого уровня
                    for k, v in selenoid_opts.items():
                        if k not in caps:
                            caps[k] = v

                    # --- UNIFICATION: Inject config args into capabilities ---
                    common_args = _build_chromium_args(cfg)

                    opts_key = "goog:chromeOptions"
                    if "browserName" in caps and "firefox" in caps["browserName"]:
                        opts_key = "moz:firefoxOptions"

                    if opts_key not in caps:
                        caps[opts_key] = {}
                    if "args" not in caps[opts_key]:
                        caps[opts_key]["args"] = []

                    # 1. Headless (from config)
                    if cfg.get("headless", False):
                        if "--headless" not in caps[opts_key]["args"]:
                            caps[opts_key]["args"].append("--headless")

                    # 2. Common Args (no_sandbox, disable_features, etc)
                    # Avoid duplicates
                    existing_args = set(caps[opts_key]["args"])
                    for arg in common_args:
                        if arg not in existing_args:
                            caps[opts_key]["args"].append(arg)

                    # 3. Добавление имени теста
                    if self.request and self.request.node:
                        caps["name"] = self.request.node.name
                        if caps.get("enableVideo"):
                            caps["videoName"] = f"{self.request.node.name}.mp4"

                    # Все capabilities оборачиваем в alwaysMatch для W3C
                    w3c_caps = {"alwaysMatch": caps}

                    retries = cfg.get("session_retries", 3)
                    timeout = cfg.get("session_timeout", 30.0)

                    ws_url, session_id = _create_selenoid_session(
                        selenoid_url, w3c_caps, retries=retries, timeout=timeout
                    )

                    # Сохраняем для очистки
                    if "selenoid_sessions" not in self._resources:
                        self._resources["selenoid_sessions"] = []
                    self._resources["selenoid_sessions"].append(
                        {"url": selenoid_url, "id": session_id}
                    )

                    self._resources["browser"] = browser_type.connect_over_cdp(
                        ws_url,
                        slow_mo=float(cfg.get("slow_mo", 0.0)),
                        timeout=float(cfg.get("timeout", 30000.0)),
                    )

                elif ws_endpoint:
                    # Подключение к удалённому браузеру по WebSocket
                    self._resources["browser"] = browser_type.connect_over_cdp(
                        ws_endpoint,
                        slow_mo=float(cfg.get("slow_mo", 0.0)),
                        timeout=float(cfg.get("timeout", 30000.0)),
                    )
                else:
                    # Локальный запуск
                    args = _build_chromium_args(cfg)

                    executable_path = cfg.get("executable_path")
                    channel = cfg.get("channel")
                    slow_mo = float(cfg.get("slow_mo", 0.0))
                    timeout = float(cfg.get("timeout", 30000.0))

                    launch_opts = {
                        "headless": cfg.get("headless", True),
                        "executable_path": executable_path,
                        "args": args if args else None,
                        "channel": channel,
                        "slow_mo": slow_mo,
                        "timeout": timeout,
                    }
                    launch_opts = {
                        k: v for k, v in launch_opts.items() if v is not None
                    }
                    self._resources["browser"] = browser_type.launch(**launch_opts)
                self._resources["browser_contexts"] = {}
            browser = self._resources["browser"]
            contexts: Dict[str, Any] = self._resources["browser_contexts"]
            if role_id not in contexts:
                context_options = {
                    "base_url": cfg.get("base_url"),
                    "ignore_https_errors": cfg.get("ignore_https_errors", False),
                }
                viewport = cfg.get("viewport")

                # Check for start_maximized
                # Also check if user manually added --start-maximized to args
                raw_args = cfg.get("args") or []
                is_maximized = cfg.get("start_maximized", False) or any(
                    "--start-maximized" in str(arg) for arg in raw_args
                )

                if is_maximized and not cfg.get("headless", True):
                    # User Rule 1: Headless False + Maximized -> Ignore Viewport, use window size
                    if "viewport" in context_options:
                        del context_options["viewport"]
                    context_options["no_viewport"] = True
                elif (
                    isinstance(viewport, dict)
                    and "width" in viewport
                    and "height" in viewport
                ):
                    # User Rule 2: Headless True (or not maximized) -> Respect Viewport
                    context_options["viewport"] = viewport
                elif is_maximized:
                    # Fallback: if maximized but headless, and no viewport specified -> None (window size)
                    context_options["viewport"] = None
                contexts[role_id] = browser.new_context(**context_options)
            context = contexts[role_id]
            # Используем первую страницу в контексте или создаем новую, если ее нет.
            # Это обеспечивает персистентную сессию для роли в рамках теста.
            # Это обеспечивает персистентную сессию для роли в рамках теста.
            if not context.pages:
                page = context.new_page()
            else:
                page = context.pages[0]

            base_url_from_config = cfg.get("base_url")

            # Глобальные таймауты страницы из конфига (мс)
            default_timeout = cfg.get("default_timeout", 0.0)
            default_navigation_timeout = cfg.get("default_navigation_timeout", 0.0)

            # Валидация и применение в навык
            def _to_float_or_none(v: Any) -> Optional[float]:
                if v is None:
                    return None
                if not isinstance(v, (int, float, str)):
                    pytest.fail(
                        f"Параметр таймаута должен быть числом или строкой, а не {type(v).__name__}",
                        pytrace=False,
                    )
                try:
                    return float(v)
                except (ValueError, TypeError):
                    pytest.fail(
                        f"Параметр таймаута '{v}' не может быть преобразован в число.",
                        pytrace=False,
                    )

            default_timeout_f = _to_float_or_none(default_timeout)
            default_navigation_timeout_f = _to_float_or_none(default_navigation_timeout)

            return UseBrowser.from_page(
                page,
                base_url=base_url_from_config,
                default_timeout=default_timeout_f,
                default_navigation_timeout=default_navigation_timeout_f,
            )

        if skill_val == "api":
            from persona_dsl.skills.use_api import UseAPI

            base_url = cfg.get("base_url")
            if not isinstance(base_url, str) or not base_url:
                pytest.fail(
                    f"Конфигурация 'skills.api.{name}.base_url' должна быть непустой строкой.",
                    pytrace=False,
                )
            verify_ssl = bool(cfg.get("verify_ssl", True))
            timeout = float(cfg.get("timeout", 10.0))
            retries = int(cfg.get("retries", 0))
            backoff = float(cfg.get("backoff", 0.5))
            log_bodies = bool(cfg.get("log_bodies", False))
            headers = cfg.get("headers")
            if headers is not None and not isinstance(headers, dict):
                pytest.fail(
                    f"Конфигурация 'skills.api.{name}.headers' должна быть словарём (dict).",
                    pytrace=False,
                )
            return UseAPI.at(
                base_url=base_url,
                verify_ssl=verify_ssl,
                timeout=timeout,
                retries=retries,
                backoff=backoff,
                log_bodies=log_bodies,
                default_headers=headers,
            )

        if skill_val == "db":
            from persona_dsl.skills.use_database import UseDatabase

            driver_name = cfg.get("driver")
            dsn = cfg.get("dsn")
            if not isinstance(driver_name, str) or not driver_name:
                pytest.fail(
                    f"Конфигурация 'skills.db.{name}' должна содержать непустую строку 'driver'."
                )
            if not isinstance(dsn, str) or not dsn:
                pytest.fail(
                    f"Конфигурация 'skills.db.{name}.dsn' должна быть непустой строкой."
                )
            user = cfg.get("user")
            password = cfg.get("password")
            # если в dsn есть плейсхолдеры, требуем соответствующие поля
            if ("{user}" in dsn or "{password}" in dsn) and (
                not isinstance(user, str) or not isinstance(password, str)
            ):
                pytest.fail(
                    f"Конфигурация 'skills.db.{name}' должна содержать 'user' и 'password' для подстановки в dsn.",
                    pytrace=False,
                )
            if "{user}" in dsn or "{password}" in dsn:
                dsn_final = dsn.format(user=user or "", password=password or "")
            else:
                dsn_final = dsn
            try:
                driver_module = __import__(driver_name)
            except (ImportError, ModuleNotFoundError) as e:
                pytest.fail(f"Не удалось импортировать драйвер БД '{driver_name}': {e}")
            return UseDatabase.with_dsn(dsn=dsn_final, driver=driver_module)

        if skill_val == "kafka":
            from persona_dsl.skills.use_kafka import UseKafka

            bootstrap = cfg.get("bootstrap_servers")
            if not bootstrap:
                pytest.fail("Конфигурация Kafka должна содержать 'bootstrap_servers'")
            group_id = cfg.get("group_id")
            from_offset = cfg.get("from_offset", "latest")
            timeout = float(cfg.get("timeout", 10.0))
            return UseKafka.with_servers(
                bootstrap_servers=bootstrap,
                group_id=group_id,
                from_offset=from_offset,
                timeout=timeout,
            )
        if skill_val == "soap":
            from persona_dsl.skills.use_soap import UseSOAP

            wsdl_url = cfg.get("wsdl_url")
            if not wsdl_url:
                pytest.fail("Конфигурация SOAP должна содержать 'wsdl_url'")
            return UseSOAP.at(wsdl_url)

        raise NotImplementedError(
            f"Ленивое создание для навыка '{skill_val}' не реализовано."
        )

    def _parse_args_with_role(
        self, args: Tuple[Any, ...]
    ) -> Tuple[str, Tuple[Any, ...]]:
        """Разбирает аргументы, отделяя опциональную роль в начале.

        Поддерживаются:
        - Enum (BaseRole)
        - str (идентификатор роли)
        """
        role_id = "default"
        if args:
            first = args[0]
            if isinstance(first, Enum):
                role_id = first.value
                args = args[1:]
            elif isinstance(first, str):
                role_id = first
                args = args[1:]
        return role_id, args

    def make(self, *args: Any) -> None:
        """Выполняет действия, изменяющие состояние системы."""
        from persona_dsl.components.base_step import BaseStep

        role_id, actions = self._parse_args_with_role(args)
        if not all(isinstance(arg, BaseStep) for arg in actions):
            raise TypeError("Метод 'make' принимает только шаги (BaseStep).")
        persona_instance = self.persona(role_id)
        for item in actions:
            item.execute(persona_instance)

    # Синонимы для make
    perform = make
    does = make

    def get(self, *args: Any) -> Any:
        """Получает данные из системы, не изменяя ее состояние."""
        from persona_dsl.components.base_step import BaseStep

        role_id, facts = self._parse_args_with_role(args)
        if not all(isinstance(arg, BaseStep) for arg in facts):
            raise TypeError("Метод 'get' принимает только шаги (BaseStep).")
        if not facts:
            raise ValueError("Метод 'get' требует хотя бы один Fact.")

        persona_instance = self.persona(role_id)
        results = [fact.execute(persona_instance) for fact in facts]

        return results[0] if len(results) == 1 else tuple(results)

    def check(self, actual_value: Any, *expectations: Expectation) -> None:
        """Проверяет фактическое значение на соответствие ожиданиям."""
        from persona_dsl.components.expectation import Expectation

        if not all(isinstance(arg, Expectation) for arg in expectations):
            raise TypeError(
                "Метод 'check' может принимать только Expectation в качестве второго и последующих аргументов."
            )
        if not expectations:
            raise ValueError("Метод 'check' требует хотя бы один Expectation.")

        # Для проверок используется персона по умолчанию, т.к. они не привязаны к роли
        persona_instance = self.persona("default")
        for expectation in expectations:
            expectation.execute(persona_instance, actual_value)

    def _cleanup_resources(self) -> None:
        for persona in self._personas.values():
            for skill_type in persona.skills.values():
                for skill_instance in skill_type.values():
                    if hasattr(skill_instance, "forget"):
                        skill_instance.forget()
        # Закрываем все браузерные контексты перед закрытием самого браузера
        if "browser_contexts" in self._resources:
            for context in self._resources["browser_contexts"].values():
                context.close()
        if "browser" in self._resources:
            try:
                self._resources["browser"].close()
            except Exception as e:
                logger.warning(f"Ошибка при закрытии браузера: {e}")

        # Удаление сессий Selenoid
        if "selenoid_sessions" in self._resources:
            for session in self._resources["selenoid_sessions"]:
                s_url = session["url"]
                s_id = session["id"]
                try:
                    del_url = f"{s_url.rstrip('/')}/wd/hub/session/{s_id}"
                    logger.info(f"Удаление сессии Selenoid: {s_id}")
                    requests.delete(del_url, timeout=5.0)
                except Exception as e:
                    logger.warning(f"Ошибка удаления сессии Selenoid {s_id}: {e}")
        if "playwright" in self._resources:
            pw = self._resources["playwright"]
            if not hasattr(pw, "stop") or not callable(pw.stop):
                raise RuntimeError(
                    "Playwright-ресурс не имеет метода stop(); нарушен контракт sync_playwright().start()"
                )
            pw.stop()


def pytest_addoption(parser: Any) -> None:
    parser.addoption(
        "--env", action="store", default="dev", help="Окружение: dev/staging/prod"
    )
    parser.addoption(
        "--generate-pages",
        action="store_true",
        default=False,
        help="Генерация PageObject во время тестов (используется с Op GeneratePageObject).",
    )


def pytest_configure(config: Any) -> None:
    """Регистрирует кастомные маркеры и настраивает предупреждения."""
    # 1. Подавляем предупреждения о неизвестных маркерах,
    #    чтобы можно было использовать @tag("any_tag") без редактирования pytest.ini
    config.addinivalue_line("filterwarnings", "ignore::pytest.PytestUnknownMarkWarning")

    # 2. Регистрируем маркер @data_driven из ядра, чтобы не делать это в проекте
    config.addinivalue_line(
        "markers",
        "data_driven: кастомная параметризация теста, управляемая фреймворком",
    )

    # 3. Регистрируем маркер @persona_retry (LCL-37)
    config.addinivalue_line(
        "markers",
        "persona_retry(max_attempts=1, delay=0.0, ...): автоматический перезапуск теста при падении",
    )

    # 4. Пробрасываем выбранное окружение в переменную TAAS_ENV для детерминированности генераторов
    try:
        env_opt = config.getoption("--env")
        if env_opt:
            os.environ["TAAS_ENV"] = env_opt
    except Exception:
        # На очень ранних стадиях инициализации getoption может быть недоступен — оставляем окружение как есть.
        pass


@pytest.fixture(scope="session")
def config(pytestconfig: Any) -> Config:
    """Загружает конфигурацию из файлов в зависимости от окружения."""
    from persona_dsl.utils.config import Config

    env = pytestconfig.getoption("--env")
    return Config.load(env, project_root=pytestconfig.rootpath)


@pytest.fixture(scope="session")
def persona_class() -> Type[Persona]:
    """Возвращает базовый класс Persona для использования в диспетчере."""
    from persona_dsl.persona import Persona

    return Persona


@pytest.fixture(scope="session", autouse=True)
def _validate_config(pytestconfig: Any) -> None:
    """
    Автоматически используемая фикстура для строгой валидации конфигурации проекта
    на основе деклараций в tests/conftest.py (PERSONA_SKILLS, PERSONA_ROLES).
    - Если деклараций нет — конфигурация не требуется и валидация пропускается.
    - Если декларации есть — файл config/{env}.yaml обязателен; при отсутствии/несоответствии — жёсткая ошибка.
    """
    env = pytestconfig.getoption("--env")
    cfg_path = Path(pytestconfig.rootpath) / "config" / f"{env}.yaml"
    plugins = list(pytestconfig.pluginmanager.get_plugins())
    project_skills: List[Any] = []
    project_roles_enum = None
    for mod in plugins:
        ps = getattr(mod, "PERSONA_SKILLS", None)
        pr = getattr(mod, "PERSONA_ROLES", None)
        if ps and not project_skills:
            project_skills = ps
        if pr and project_roles_enum is None:
            project_roles_enum = pr

    # Нет деклараций — ничего не валидируем и не загружаем конфиг
    if not project_skills and not project_roles_enum:
        return

    # Декларации есть — файл обязателен
    if not cfg_path.exists():
        pytest.fail(
            f"Отсутствует файл конфигурации 'config/{env}.yaml', тогда как в conftest.py объявлены "
            f"PERSONA_SKILLS/ROLES. Создайте config/{env}.yaml или уберите декларации.",
            pytrace=False,
        )

    # Загружаем конфиг и валидируем перечисленные навыки/роли
    # Загружаем конфиг и валидируем перечисленные навыки/роли
    from persona_dsl.utils.config import Config

    cfg = Config.load(env, project_root=pytestconfig.rootpath)
    errors = []

    # Проверка навыков
    for skill_item in project_skills:
        if isinstance(skill_item, tuple):
            skill_id, skill_name = skill_item
        else:
            skill_id = skill_item
            skill_name = "default"

        if not _get_skill_config(cfg, skill_id.value, skill_name):
            error_msg = f"  - Именованный навык '{skill_id.value}.{skill_name}'"
            if skill_name == "default":
                error_msg = f"  - Базовый навык '{skill_id.value}'"
            errors.append(error_msg)

    # Проверка ролей
    if project_roles_enum:
        for role_member in project_roles_enum:
            accessible_name = role_member.value
            if not _get_persona_config(cfg, accessible_name):
                errors.append(
                    f"  - Проектная роль '{accessible_name}' (из {project_roles_enum.__name__})"
                )

    if errors:
        pytest.fail(
            f"Отсутствует конфигурация в 'config/{env}.yaml' для следующих сущностей, объявленных в conftest.py:\n"
            + ", ".join(errors),
            pytrace=False,
        )


@pytest.fixture(scope="function")
def persona(
    request: Any, config: Config, persona_class: Type[Persona]
) -> Generator[PersonaDispatcher, None, None]:
    dispatcher = PersonaDispatcher(config, persona_class, request)
    yield dispatcher
    dispatcher._cleanup_resources()


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item: Any, call: Any) -> Generator[None, Any, None]:
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call":
        from persona_dsl.utils.metrics import metrics

        status = "passed" if rep.passed else "failed"
        tags = {"test_name": item.name, "status": status}
        metrics.gauge("test.duration", rep.duration, tags)
        metrics.counter("test.runs", tags).inc()
        if status == "failed" and "persona" in item.fixturenames:
            dispatcher = item.funcargs.get("persona")
            if dispatcher and "browser" in dispatcher._resources:
                cfg = dispatcher.config
                screenshot_on_fail = cfg.reporting.get("screenshot_on_fail", True)
                pagesource_on_fail = cfg.reporting.get("pagesource_on_fail", True)
                if not screenshot_on_fail and not pagesource_on_fail:
                    return

                browser = dispatcher._resources["browser"]
                if not browser.contexts:
                    return

                from persona_dsl.utils.artifacts import artifacts_dir, sanitize_filename

                screenshot_dir = artifacts_dir("screenshots")

                for i, context in enumerate(browser.contexts):
                    if not context.pages:
                        continue
                    page = context.pages[-1]
                    context_name = f"context-{i}"
                    if screenshot_on_fail:
                        screenshot_path = (
                            screenshot_dir
                            / f"{sanitize_filename(item.name)}-{context_name}.png"
                        )
                        page.screenshot(path=str(screenshot_path))
                        allure.attach.file(
                            str(screenshot_path),
                            name=f"screenshot-on-fail-{context_name}",
                            attachment_type=allure.attachment_type.PNG,
                        )
                    if pagesource_on_fail:
                        page_source = page.content()
                        allure.attach(
                            page_source,
                            name=f"page-source-on-fail-{context_name}",
                            attachment_type=allure.attachment_type.HTML,
                        )
    setattr(item, "rep_" + rep.when, rep)


@lru_cache(maxsize=None)
def _load_test_data_file(filename: str) -> List[Any]:
    """Загружает и кеширует тестовые данные из YAML/JSON файла в tests/data."""
    base_dir = Path.cwd() / "tests" / "data"
    name = str(filename)

    # Список кандидатов: если расширение задано — используем его; иначе пробуем .yaml, .yml, затем .json
    if any(name.endswith(ext) for ext in (".yaml", ".yml", ".json")):
        candidates = [base_dir / name]
    else:
        candidates = [
            base_dir / f"{name}.yaml",
            base_dir / f"{name}.yml",
            base_dir / f"{name}.json",
        ]

    for path in candidates:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                if path.suffix.lower() == ".json":
                    data = json.load(f)
                else:
                    data = yaml.safe_load(f)
            if not isinstance(data, list):
                raise DataDrivenError(
                    f"Данные в файле {path} должны быть списком (list)."
                )
            return data

    raise DataDrivenError(
        "Файл с тестовыми данными не найден. Ожидались: "
        + ", ".join(str(p) for p in candidates)
    )


def pytest_sessionstart(session: Any) -> None:
    """Вызывается в начале тестовой сессии для monkey-patching allure.step."""
    if _taas_ready():
        allure.step = _instrumented_allure_step  # type: ignore[assignment]


def pytest_sessionfinish(session: Any) -> None:
    """Вызывается в конце тестовой сессии для восстановления allure.step и отправки финального события."""
    if _taas_ready():
        # Отправляем финальное событие из самого процесса pytest, чтобы избежать гонки состояний
        final_status = "COMPLETED" if session.exitstatus == 0 else "FAILED"
        finish_event = {
            "event": "finish",
            "data": {"status": final_status, "return_code": int(session.exitstatus)},
        }
        try:
            from .utils.taas_integration import publish_taas_event

            publish_taas_event(finish_event)
        except Exception as e:
            try:
                logger.warning("TaaS: не удалось отправить finish событие: %s", e)
            except Exception:
                pass

        allure.step = _original_allure_step


def _resolve_data_driven_expressions(val: Any) -> Any:
    """Рекурсивно вычисляет SystemVar-выражения в данных."""
    # SystemVar-узел: { "kind":"system", "name": "...", "args": { ... } }
    if isinstance(val, dict):
        if val.get("kind") == "system" and "name" in val:
            name = val.get("name")
            args = val.get("args", {}) or {}
            # Разрешаем аргументы рекурсивно (могут содержать вложенные VarRef/SystemVar/литералы)
            resolved_args = {
                k: _resolve_data_driven_expressions(v) for k, v in args.items()
            }
            from persona_dsl.utils import data_providers as _dp

            func = getattr(_dp, str(name), None)
            if callable(func):
                try:
                    return func(**resolved_args)
                except Exception as e:
                    raise ValueError(
                        f"@data_driven expr: ошибка вычисления SystemVar '{name}' с args={resolved_args}: {e}"
                    )
            raise ValueError(
                f"@data_driven expr: неизвестный провайдер SystemVar '{name}'"
            )
        # Обычный словарь — обрабатываем все значения
        return {k: _resolve_data_driven_expressions(v) for k, v in val.items()}
    # Списки — обрабатываем элементы
    if isinstance(val, list):
        return [_resolve_data_driven_expressions(x) for x in val]
    # Прочие типы — возвращаем как есть
    return val


def pytest_generate_tests(metafunc: Any) -> None:
    """Генерирует параметризованные тесты для маркера @data_driven."""
    for marker in metafunc.definition.iter_markers(name="data_driven"):
        source = marker.args[0] if marker.args else marker.kwargs.get("source")
        is_file = marker.kwargs.get("file", False)

        if source is None:
            pytest.fail(
                "Источник данных 'source' для @data_driven не был предоставлен.",
                pytrace=False,
            )

        try:
            scenarios = _load_test_data_file(source) if is_file else source
        except DataDrivenError as e:
            pytest.fail(str(e), pytrace=False)

        if not isinstance(scenarios, list) or not all(
            isinstance(s, dict) for s in scenarios
        ):
            pytest.fail(
                f"Данные для @data_driven должны быть списком словарей. Получено: {type(scenarios)}",
                pytrace=False,
            )

        # Требуем variant_id ('test_id') и формируем стабильные id ДО вычисления выражений
        name_template = marker.kwargs.get("name_template")
        missing = [i for i, s in enumerate(scenarios) if "test_id" not in s]
        if missing:
            pytest.fail(
                f"@data_driven: каждая вариация должна содержать поле 'test_id'. Отсутствует в индексах: {missing}",
                pytrace=False,
            )
        if isinstance(name_template, str) and name_template:

            def _fmt_id(s: Any) -> str:
                try:
                    return name_template.format(**s)
                except Exception:
                    return str(s.get("test_id"))

            ids = [_fmt_id(s) for s in scenarios]
        else:
            ids = [str(s["test_id"]) for s in scenarios]

        # Сначала вычисляем выражения SystemVar/VarRef для всех сценариев.
        # Это важно: ошибки провайдеров должны приводить к немедленной диагностике,
        # даже если далее фильтрация могла бы исключить вариации.
        resolved_scenarios = []
        original_variant_id = os.environ.get("TAAS_VARIANT_ID")
        try:
            for s in scenarios:
                test_id = s.get("test_id")
                if test_id:
                    os.environ["TAAS_VARIANT_ID"] = str(test_id)
                resolved_scenarios.append(_resolve_data_driven_expressions(s))
        except ValueError as e:
            pytest.fail(f"ValueError: {e}", pytrace=False)
        finally:
            # Восстанавливаем окружение и состояние генераторов
            if original_variant_id is None:
                os.environ.pop("TAAS_VARIANT_ID", None)
            else:
                os.environ["TAAS_VARIANT_ID"] = original_variant_id

        # Затем фильтруем вариации по test_id через параметр only и/или переменную окружения TAAS_VARIANT_IDS
        only_marker = marker.kwargs.get("only")
        only_env = os.environ.get("TAAS_VARIANT_IDS")

        is_filtered = False
        active_filter_set: Optional[set] = None

        if only_marker is not None:
            is_filtered = True
            try:
                active_filter_set = {str(x) for x in only_marker}
            except TypeError:
                active_filter_set = set()

        if only_env:  # Skips None and ""
            is_filtered = True
            env_set = {s.strip() for s in only_env.split(",") if s.strip()}
            if active_filter_set is None:
                active_filter_set = env_set
            else:
                active_filter_set.intersection_update(env_set)

        if is_filtered:
            final_scenarios = []
            final_ids = []
            if active_filter_set:  # Filter is not empty
                for s, i in zip(resolved_scenarios, ids):
                    if str(s.get("test_id")) in active_filter_set:
                        final_scenarios.append(s)
                        final_ids.append(i)

            if not final_scenarios:
                pytest.fail(
                    "@data_driven: ни одна вариация не осталась после фильтрации (only/TAAS_VARIANT_IDS).",
                    pytrace=False,
                )
            resolved_scenarios = final_scenarios
            ids = final_ids

        if "scenario" in metafunc.fixturenames:
            if resolved_scenarios:
                metafunc.parametrize("scenario", resolved_scenarios, ids=ids)


def pytest_runtest_setup(item: Any) -> None:
    """
    Перед каждым тестом:
    1. Устанавливаем TAAS_VARIANT_ID для детерминированного seed'а.
    2. (LCL-37) Оборачиваем тестовую функцию в ретрай-декоратор, если задан маркер @persona_retry.
    """
    from persona_dsl.utils.retry import RetryPolicy  # Lazy import for coverage

    # 1. TAAS_VARIANT_ID logic
    prev = os.environ.get("TAAS_VARIANT_ID")
    variant_id = None
    callspec = getattr(item, "callspec", None)
    if callspec and "scenario" in callspec.params:
        scenario = callspec.params["scenario"]

        if isinstance(scenario, dict):
            # Устанавливаем TAAS_VARIANT_ID
            variant_id = str(scenario.get("test_id") or "")

    if variant_id:
        os.environ["TAAS_VARIANT_ID"] = variant_id
    setattr(item, "_prev_taas_variant_id", prev)

    # 2. LCL-37: Retry Logic
    retry_marker = item.get_closest_marker("persona_retry")
    policy = None

    if retry_marker:
        kwargs = retry_marker.kwargs.copy()
        # Простейшая поддержка: передаем kwargs как есть в RetryPolicy
        # Пользователь должен передавать типы исключений в retry_on, если нужно
        policy = RetryPolicy(**kwargs)
    else:
        # Проверяем глобальный конфиг (если доступен через item.config -> Config)
        # Это "мягкая" интеграция: если конфиг загружен и там есть retries.default
        try:
            env = item.config.getoption("--env")
            # Загружаем конфиг (он кешируется внутри Config.load если реализован singleton,
            # но даже если нет - чтение файла допустимо в setup)
            cfg = Config.load(env, project_root=item.config.rootpath)
            default_policy = cfg.retries.get("default") if cfg.retries else None

            if default_policy:
                # Преобразуем dict конфига в RetryPolicy
                # Исключаем поля, которые не принимает конструктор (если есть лишние)
                # Но RetryPolicy принимает **kwargs, так что просто распаковываем
                policy = RetryPolicy(**default_policy)
        except Exception:
            # Если конфиг не загрузился или кривой - игнорируем, работаем без ретраев
            policy = None

    if policy:
        original_func = item.obj

        @functools.wraps(original_func)
        def retrying_test_func(*args: Any, **kwargs: Any) -> Any:
            attempt = 0
            while True:
                attempt += 1
                try:
                    return original_func(*args, **kwargs)
                except Exception as e:
                    if policy.should_retry(attempt, e):
                        logger.warning(
                            f"Тест '{item.name}' упал (попытка {attempt}/{policy.max_attempts}): {e}. Ретрай через {policy.delay}с."
                        )
                        policy.wait(attempt)
                        if policy.on_retry_action:
                            policy.execute_action()
                        continue
                    raise

        item.obj = retrying_test_func


def pytest_runtest_teardown(item: Any, nextitem: Any) -> None:
    """
    Восстанавливаем предыдущее значение TAAS_VARIANT_ID после теста.
    """
    prev = getattr(item, "_prev_taas_variant_id", None)
    if prev is None:
        os.environ.pop("TAAS_VARIANT_ID", None)
    else:
        os.environ["TAAS_VARIANT_ID"] = prev


@pytest.fixture(scope="session")
def testdata() -> Any:
    """Фабричная фикстура для загрузки тестовых данных из `tests/data/*.{yaml,yml,json}`."""
    return _load_test_data_file


def pytest_runtest_logstart(nodeid: str, location: Any) -> None:
    """
    Отправляет JSON-событие в TaaS при старте каждого теста.
    Работает только в контексте TaaS (когда задан TAAS_RUN_ID), чтобы не влиять на обычный вывод pytest.
    """
    if not _taas_ready():
        return
    # Используем имя теста (без пути) как description для корневого узла
    test_name = nodeid.split("::")[-1]
    event_data = {
        "event": "test_start",
        "data": {
            "node_id": nodeid,
            "description": test_name,
            "timestamp": time.time(),
        },
    }
    try:
        from .utils.taas_integration import publish_taas_event

        publish_taas_event(event_data)
    except Exception as e:
        try:
            logger.warning("TaaS: не удалось отправить событие test_start: %s", str(e))
        except Exception:
            pass


def pytest_runtest_logreport(report: Any) -> None:
    """
    Отправляет JSON-событие в stdout по завершении каждой фазы теста (setup, call, teardown).
    Нас интересует только 'call' для отображения итогового статуса.
    Работает только в контексте TaaS (когда задан TAAS_RUN_ID), чтобы не влиять на обычный вывод pytest.
    """
    if not _taas_ready():
        return
    if report.when == "call":
        test_name = report.nodeid.split("::")[-1]
        event_data = {
            "event": "test_end",
            "data": {
                "node_id": report.nodeid,
                "description": test_name,
                "status": report.outcome,
                "duration": report.duration,
                "timestamp": time.time(),
            },
        }
        try:
            from .utils.taas_integration import publish_taas_event

            publish_taas_event(event_data)
        except Exception as e:
            try:
                logger.warning("TaaS: не удалось отправить событие test_end: %s", e)
            except Exception:
                pass
