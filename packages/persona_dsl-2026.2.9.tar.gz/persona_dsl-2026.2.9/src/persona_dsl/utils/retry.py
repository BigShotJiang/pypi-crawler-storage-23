from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Optional, Tuple, Type


@dataclass
class RetryPolicy:
    """
    Политика повторных попыток (ретраев).

    Attributes:
        max_attempts: Максимальное количество попыток (включая первую). По умолчанию 1 (без ретраев).
        delay: Задержка между попытками в секундах.
        backoff_factor: Множитель увеличения задержки (экспоненциальный рост).
        retry_on: Кортеж типов исключений, при которых нужно повторять попытку.
        retry_if: Предикат для проверки экземпляра исключения (вернуть True, если нужно повторить).
        on_retry_action: Коллбек, вызываемый перед каждой повторной попыткой.
    """

    max_attempts: int = 1
    delay: float = 0.0
    backoff_factor: float = 1.0
    retry_on: Tuple[Type[Exception], ...] = (Exception,)
    retry_if: Optional[Callable[[Exception], bool]] = None
    on_retry_action: Optional[Callable[[], None]] = None

    def should_retry(self, attempt: int, exception: Exception) -> bool:
        """Определяет, нужно ли делать ретрай."""
        if attempt >= self.max_attempts:
            return False

        if not isinstance(exception, self.retry_on):
            return False

        if self.retry_if is not None and not self.retry_if(exception):
            return False

        return True

    def wait(self, attempt: int) -> None:
        """Выполняет ожидание перед следующей попыткой."""
        wait_time = self.delay * (self.backoff_factor ** (attempt - 1))
        if wait_time > 0:
            time.sleep(wait_time)

    def execute_action(self) -> None:
        """Выполняет действие перед ретраем (если задано)."""
        if self.on_retry_action:
            self.on_retry_action()
