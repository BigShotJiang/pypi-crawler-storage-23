from __future__ import annotations

from typing import Any, List, Union


class PathSyntaxError(ValueError):
    """Синтаксическая ошибка пути dot/bracket."""


Token = Union[str, int]


def _tokenize(path: str) -> List[Token]:
    """
    Разбивает строку пути на токены:
    - dot:  a.b.c        -> ["a","b","c"]
    - bracket index: [0] -> [0]
    - bracket key:  ["x.y"] или ['z[0]'] -> ["x.y"], ["z[0]"]
    Поддерживает экранирование в кавычках: \" и \'
    """
    if not isinstance(path, str):
        raise PathSyntaxError("Путь должен быть строкой")
    if not path:
        return []
    tokens: List[Token] = []
    buf = ""
    i = 0
    n = len(path)

    def _flush_buf() -> None:
        nonlocal buf
        if buf:
            tokens.append(buf)
            buf = ""

    while i < n:
        c = path[i]
        if c == ".":
            _flush_buf()
            i += 1
            continue
        if c == "[":
            _flush_buf()
            i += 1
            if i >= n:
                raise PathSyntaxError(f"Ожидалось содержимое после '[' в позиции {i-1}")
            # Ключ в кавычках
            if path[i] in ("'", '"'):
                quote = path[i]
                i += 1
                s = ""
                while i < n:
                    ch = path[i]
                    if ch == "\\" and i + 1 < n:
                        s += path[i + 1]
                        i += 2
                        continue
                    if ch == quote:
                        break
                    s += ch
                    i += 1
                if i >= n or path[i] != quote:
                    raise PathSyntaxError(f"Незакрытая кавычка {quote} в позиции {i}")
                i += 1
                if i >= n or path[i] != "]":
                    raise PathSyntaxError(
                        f"Ожидалась закрывающая ']' после ключа в кавычках (позиция {i})"
                    )
                i += 1
                tokens.append(s)
                continue
            # Индекс списка
            j = i
            if j < n and path[j] == "-":
                j += 1
            start_digits = j
            while j < n and path[j].isdigit():
                j += 1
            if j == start_digits:
                raise PathSyntaxError(
                    f"Ожидался числовой индекс после '[' (позиция {i-1})"
                )
            if j >= n or path[j] != "]":
                raise PathSyntaxError(
                    f"Ожидалась закрывающая ']' после индекса (позиция {j})"
                )
            idx = int(path[i:j])
            tokens.append(idx)
            i = j + 1
            continue
        # Обычный символ идентификатора
        if c in ("'", '"'):
            raise PathSyntaxError(
                f"Недопустимый символ кавычки в идентификаторе в позиции {i}"
            )
        buf += c
        i += 1

    _flush_buf()
    return tokens


def tokenize_path(path: str) -> List[Token]:
    """
    Публичный токенайзер пути. Возвращает список токенов (str|int) по dot/bracket‑нотации.
    """
    return _tokenize(path)


def extract_by_path(root: Any, path: str, *, allow_attr: bool = True) -> Any:
    """
    Достаёт значение из dict/list/объекта по пути вида "a.b[0]['x.y']".
    Бросает понятные ошибки при несоответствии структуры/индексов/ключей.
    """
    tokens = _tokenize(path)
    cur = root
    for t in tokens:
        if isinstance(t, int):
            if not isinstance(cur, (list, tuple)):
                raise TypeError(
                    f"Ожидался список/кортеж для индексации [{t}], получено: {type(cur).__name__}"
                )
            try:
                cur = cur[t]
            except IndexError:
                raise IndexError(
                    f"Индекс вне диапазона: [{t}] при длине {len(cur)}"
                ) from None
        else:
            if isinstance(cur, dict):
                if t not in cur:
                    raise KeyError(f"Ключ отсутствует: '{t}'")
                cur = cur[t]
            elif allow_attr and hasattr(cur, t):
                cur = getattr(cur, t)
            else:
                raise TypeError(
                    f"Нельзя обратиться по ключу/атрибуту '{t}' у типа {type(cur).__name__}"
                )
    return cur


def try_extract_by_path(
    root: Any, path: str, *, default: Any = None, allow_attr: bool = True
) -> Any:
    """
    Мягкая версия: вместо исключений возвращает default при любой ошибке.
    """
    try:
        return extract_by_path(root, path, allow_attr=allow_attr)
    except Exception:
        return default


def remove_by_path(obj: Any, path: str, *, strict: bool = False) -> None:
    """
    Удаляет значение по пути из dict/list. Если strict=True — бросает понятные ошибки,
    иначе отсутствующие ветки тихо игнорируются.
    """
    tokens = _tokenize(path)
    if not tokens:
        if strict:
            raise PathSyntaxError("Пустой путь для удаления")
        return
    cur = obj
    # идём до родителя
    try:
        for t in tokens[:-1]:
            if isinstance(t, int):
                if not isinstance(cur, list):
                    raise TypeError(
                        f"Ожидался список для индекса [{t}], получено {type(cur).__name__}"
                    )
                cur = cur[t]
            else:
                if isinstance(cur, dict):
                    cur = cur[t]
                else:
                    raise TypeError(
                        f"Ожидался dict для ключа '{t}', получено {type(cur).__name__}"
                    )
        last = tokens[-1]
        if isinstance(last, int):
            if not isinstance(cur, list):
                raise TypeError(
                    f"Ожидался список для индекса [{last}], получено {type(cur).__name__}"
                )
            del cur[last]
        else:
            if not isinstance(cur, dict):
                raise TypeError(
                    f"Ожидался dict для ключа '{last}', получено {type(cur).__name__}"
                )
            if strict:
                del cur[last]
            else:
                cur.pop(last, None)
    except Exception:
        if strict:
            raise
        # мягкий режим — игнорируем ошибки
        return
