import time
import os
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional


class Reporter(ABC):
    @abstractmethod
    def report(self, metric_name: str, value: float, tags: Dict[str, Any]) -> None:
        pass  # pragma: no cover


class FileReporter(Reporter):
    def __init__(self, output_file: Path):
        self._output_file = output_file

    def report(self, metric_name: str, value: float, tags: Dict[str, Any]) -> None:
        tag_str = ",".join([f"{k}={v}" for k, v in tags.items()])
        with open(self._output_file, "a", encoding="utf-8") as f:
            f.write(f"{metric_name}{{{tag_str}}} {value} {int(time.time())}\n")


logger = logging.getLogger(__name__)


class StdoutReporter(Reporter):
    def report(self, metric_name: str, value: float, tags: Dict[str, Any]) -> None:
        tag_str = ",".join([f"{k}={v}" for k, v in tags.items()])
        logger.info(f"{metric_name}{{{tag_str}}} {value} {int(time.time())}")


class Counter:
    def __init__(self, metrics_system: "Metrics", name: str, tags: Dict[str, Any]):
        self._metrics = metrics_system
        self._name = name
        self._tags = tags

    def inc(self, value: int = 1) -> None:
        self._metrics.report(f"{self._name}.count", value, self._tags)


class Metrics:
    def __init__(self) -> None:
        self._reporters: List[Reporter] = []

    def add_reporter(self, reporter: Reporter) -> None:
        self._reporters.append(reporter)

    def report(self, metric_name: str, value: float, tags: Dict[str, Any]) -> None:
        for reporter in self._reporters:
            reporter.report(metric_name, value, tags)

    def gauge(
        self, name: str, value: float, tags: Optional[Dict[str, Any]] = None
    ) -> None:
        self.report(name, value, tags or {})

    def counter(self, name: str, tags: Optional[Dict[str, Any]] = None) -> "Counter":
        return Counter(self, name, tags or {})


# Глобальный экземпляр для использования в рамках сессии
metrics = Metrics()
log_path = os.getenv("TEST_METRICS_FILE", "test_metrics.log")
metrics.add_reporter(FileReporter(Path(log_path)))
if os.getenv("TEST_METRICS_STDOUT", "0") == "1":
    metrics.add_reporter(StdoutReporter())
