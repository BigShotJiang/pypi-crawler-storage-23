import os
import re
from pathlib import Path


def sanitize_filename(name: str) -> str:
    """Безопасное имя файла для снапшотов/скриншотов."""
    return re.sub(r"[^A-Za-z0-9._-]+", "-", str(name)).strip("-") or "snapshot"


def artifacts_dir(subdir: str) -> Path:
    """Каталог для артефактов запуска: <ARTIFACTS>/<run_id>/<subdir> или локальный ./<subdir>."""
    base_dir = Path(os.getenv("TAAS_ARTIFACTS_DIR", str(Path.cwd())))
    run_id = os.getenv("TAAS_RUN_ID")
    out = (base_dir / run_id / subdir) if run_id else (base_dir / subdir)
    out.mkdir(parents=True, exist_ok=True)
    return out


def screenshots_dir() -> Path:
    """Каталог для скриншотов."""
    return artifacts_dir("screenshots")
