import re


def to_pascal_case(s: str) -> str:
    """Преобразует snake_case или kebab-case (и пути) в PascalCase."""
    parts = re.split(r"[^a-zA-Z0-9]+", s)
    return "".join(p.capitalize() for p in parts if p)


def to_snake_case(name: str) -> str:
    """Преобразует PascalCase или kebab-case в snake_case."""
    name = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    return name.replace("-", "_").lower()
