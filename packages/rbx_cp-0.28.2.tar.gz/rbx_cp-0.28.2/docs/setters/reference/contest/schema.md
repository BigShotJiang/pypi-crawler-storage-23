# Contest schema

## `contest.rbx.yml`

::: rbx.box.contest.schema
    options:
      show_root_heading: false
      show_root_toc_entry: false
      heading_level: 3
      show_labels: false