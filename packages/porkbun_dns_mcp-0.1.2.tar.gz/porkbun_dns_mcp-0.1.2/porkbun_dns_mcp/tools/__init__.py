"""MCP tools for DNS record management."""

from porkbun_dns_mcp.tools.dns_tools import register_dns_tools

__all__ = ["register_dns_tools"]
