"""Hanzo - Complete AI Infrastructure Platform with CLI, Router, MCP, and Agent Runtime."""

__version__ = "0.3.47"
__all__ = ["main", "cli", "__version__"]

from .cli import cli, main
