# Pier Cloud MCP Server

Connect your AI assistant to Pier Cloud data. Query cloud costs, analyze spending, and get insights using natural language.

## What you can do

- Query AWS, Azure, and GCP cost data
- Analyze cloud spending patterns
- Get cost breakdowns by service, account, or time period
- All through natural conversation

## Installation

```bash
# Install pipx if you don't have it
python3 -m pip install --user pipx
python3 -m pipx ensurepath

# Restart your terminal, then:
pipx install piercloud-mcp

# Or without restarting:
python3 -m pipx install piercloud-mcp
```

## Setup for Claude Desktop

**Easy way** (recommended):

```bash
piercloud-mcp --install-claude
```

This will prompt for your credentials and configure Claude automatically.

**Manual way**:

1. Find the installation path:

```bash
which piercloud-mcp
# Output: /Users/yourname/.local/bin/piercloud-mcp (macOS/Linux)
# or C:\Users\yourname\.local\bin\piercloud-mcp.exe (Windows)
```

2. Add to Claude config with the **full path**:

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux**: `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "piercloud": {
      "command": "/Users/yourname/.local/bin/piercloud-mcp",
      "env": {
        "PIERCLOUD_CLIENT_ID": "your-client-id",
        "PIERCLOUD_CLIENT_SECRET": "your-client-secret"
      }
    }
  }
}
```

3. Restart Claude Desktop
