"""Pier MCP Server - A scalable Model Context Protocol server."""

__version__ = "0.1.0"
