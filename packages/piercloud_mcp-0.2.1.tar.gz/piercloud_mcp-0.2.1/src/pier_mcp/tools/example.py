"""Example tools demonstrating the registration pattern."""

from pydantic import BaseModel, Field


class EchoInput(BaseModel):
    """Input schema for echo tool."""
    message: str = Field(description="Message to echo back")
    uppercase: bool = Field(default=False, description="Return in uppercase")


class AddInput(BaseModel):
    """Input schema for add tool."""
    a: float = Field(description="First number")
    b: float = Field(description="Second number")


def register_example_tools(mcp):
    """Register example tools to demonstrate the pattern."""
    
    @mcp.tool("echo", "Echoes a message back, optionally in uppercase", EchoInput)
    async def echo(args: EchoInput) -> str:
        result = args.message
        if args.uppercase:
            result = result.upper()
        return result
    
    @mcp.tool("add", "Adds two numbers together", AddInput)
    async def add(args: AddInput) -> str:
        return str(args.a + args.b)
