"""MCP server entry point - register your tools here."""

import asyncio
import sys
import uvicorn
from pier_mcp.server import MCPServer
from pier_mcp.sse_server import create_sse_server
from pier_mcp.tools.rebilling import register_rebilling_tools
from pier_mcp.tools.cca import register_cca_tools
from pier_mcp import __version__


# Initialize server
mcp = MCPServer("piercloud-mcp-server", __version__)

# Register tools
register_rebilling_tools(mcp)
register_cca_tools(mcp)


def main():
    """Run the MCP server."""
    if "--help" in sys.argv or "-h" in sys.argv:
        print(
            """Pier Cloud MCP Server

Usage:
  piercloud-mcp                    Run in stdio mode (for Claude Desktop)
  piercloud-mcp --sse              Run HTTP/SSE server (production)
  piercloud-mcp --sse --port 8000  Run on custom port
  piercloud-mcp --install-claude   Configure Claude Desktop
  piercloud-mcp --help             Show this help

Environment variables:
  PIERCLOUD_CLIENT_ID        Your Pier Cloud client ID
  PIERCLOUD_CLIENT_SECRET    Your Pier Cloud client secret
"""
        )
        return

    if "--install-claude" in sys.argv:
        from pier_mcp.installer import install_claude
        install_claude()
        return

    if "--sse" in sys.argv:
        # Production mode: HTTP server
        port = 8000
        if "--port" in sys.argv:
            port = int(sys.argv[sys.argv.index("--port") + 1])

        app = create_sse_server(mcp)
        uvicorn.run(app, host="0.0.0.0", port=port)
    else:
        # Local mode: stdio
        asyncio.run(mcp.run())


if __name__ == "__main__":
    main()
