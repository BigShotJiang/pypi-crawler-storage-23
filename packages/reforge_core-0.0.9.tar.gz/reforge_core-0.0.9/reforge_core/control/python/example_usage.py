# example_usage.py
import numpy as np
from pathlib import Path
from reforge_core.control.python.covalent_wrapper import (
    ShaperInterface,
    RobotState,
)

THIS_DIR = Path(__file__).resolve().parent
REPO_ROOT = THIS_DIR.parents[2]

# --- Configuration ---
Ts = 0.0005  # 2 kHz sampling
model_dir = REPO_ROOT / "src/robot/models/current"
num_axes = 3
num_joints = 6
python_src_root = REPO_ROOT / "src"
urdf_filepath = REPO_ROOT / "src/robot/urdf/test_robot.urdf"

# --- Initialize ---
shaper = ShaperInterface(
    sample_time=Ts,
    model_directory=str(model_dir),
    python_src_root=str(python_src_root),
    urdf_filepath=str(urdf_filepath),
    num_axes=num_axes,
    num_joints=num_joints,
)

# --- Example: shape a single position command vector ---
joint_positions = np.array([0.25, -0.3, 0.1, 0.0, 0.0, 0.0], dtype=float)
single_state = RobotState(joint_angles=joint_positions)

single_sample = shaper.shape_sample(joint_positions, single_state)
shaped_positions = single_sample.positions
print("Shaped joint positions:", shaped_positions)

# --- Example: shape an entire trajectory (optional) ---
N = 200
t = np.arange(N) * Ts
# Generate a simple sinusoidal trajectory on 3 shaped joints
trajectory = np.zeros((N, num_joints))
trajectory[:, 0] = 0.25 * np.sin(2 * np.pi * 1.0 * t)  # 1 Hz motion
trajectory[:, 1] = 0.20 * np.sin(2 * np.pi * 0.8 * t + 1)
trajectory[:, 2] = 0.15 * np.sin(2 * np.pi * 1.2 * t + 2)

# Apply the shaper sample-by-sample or as a full
# Sample-by-sample stream
shaper_stream = ShaperInterface(
    sample_time=Ts,
    model_directory=str(model_dir),
    python_src_root=str(python_src_root),
    urdf_filepath=str(urdf_filepath),
    num_axes=num_axes,
    num_joints=num_joints,
)

shaped_series: list[tuple[float, np.ndarray]] = []
last_time = 0.0
for i in range(N):
    cmd = trajectory[i].copy()
    state = RobotState(joint_angles=cmd)
    sample = shaper_stream.shape_sample(cmd, state)
    shaped_series.append((t[i], sample.positions))
    last_time = t[i]

tails = [shaper.finalize() for shaper in shaper_stream.shapers]
max_tail = max(len(tail) for tail in tails)
for tail_idx in range(max_tail):
    tail_time = last_time + (tail_idx + 1) * Ts
    pos = shaped_series[-1][1].copy()
    for axis in range(num_axes):
        if tail_idx < len(tails[axis]):
            y, v, a = tails[axis][tail_idx]
            pos[axis] = y
    shaped_series.append((tail_time, pos))

stream_len = len(shaped_series)

# With a trajectory shaper
shaper_batch = ShaperInterface(
    sample_time=Ts,
    model_directory=str(model_dir),
    python_src_root=str(python_src_root),
    urdf_filepath=str(urdf_filepath),
    num_axes=num_axes,
    num_joints=num_joints,
)

states = [RobotState(joint_angles=trajectory[i].copy()) for i in range(N)]
shaped_traj = shaper_batch.shape_trajectory(trajectory, states, time_vector=list(t))

batch_len = shaped_traj.positions.shape[0]
time_batch = np.arange(0, batch_len) * Ts

print(f"[PyPure] Streaming shaped samples: {stream_len}")
print(f"[PyPure] Batch shaped samples: {batch_len}")
