from __future__ import annotations

import sys
from pathlib import Path


def _ensure_native_extensions_on_path() -> None:
    """
    When running directly from the source tree (e.g. `python -m src...`), the
    compiled pybind11 modules live in ``src/util/native/lib`` rather than next
    to this package. In an installed wheel they are already colocated with the
    Python modules, so this no-op early return is harmless.
    """
    native_lib_dir = Path(__file__).resolve().parent / "native" / "lib"
    if not native_lib_dir.exists():
        return
    lib_path = str(native_lib_dir)

    # Make the native build output discoverable both as a package path and via
    # sys.path (for direct imports of the extension modules).
    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)
    if lib_path not in globals().get("__path__", []):
        __path__.append(lib_path)


_ensure_native_extensions_on_path()
