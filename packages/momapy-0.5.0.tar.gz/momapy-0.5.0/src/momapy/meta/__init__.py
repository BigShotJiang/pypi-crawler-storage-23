"""Meta-model subpackage."""
