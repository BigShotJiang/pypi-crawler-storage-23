from __future__ import annotations


ESIOS_API_URL = "https://api.esios.ree.es/"
