from typing import Literal

import pandas as pd

from datamazing.pandas.types.window import Window

Label = Literal["right", "center"]


class Roller:
    def __init__(
        self,
        df: pd.DataFrame,
        on: str,
        window: Window,
    ):
        if window.label not in ["right", "center"]:
            raise NotImplementedError(
                f"Unsupported label {window.label}."
                "Supported labels are 'right' and 'center'."
            )

        self.df = df
        self.on = on
        self.window = window

    def agg(self, method: str | dict):
        center = self.window.label == "center"

        df = (
            self.df.sort_values(by=self.on)
            .set_index(keys=self.on)
            .rolling(
                window=self.window.duration, center=center, closed=self.window.closed
            )
            .aggregate(method, numeric_only=True)
            .reset_index()
        )

        return df


def rolling(df: pd.DataFrame, on: str, window: Window):
    """Aggregate data using rolling windows.

    Args:
        df (pd.DataFrame): DataFrame
        on (str): Column to roll on.
        window (Window): Window to use for aggregation.
    """
    return Roller(df, on, window)
