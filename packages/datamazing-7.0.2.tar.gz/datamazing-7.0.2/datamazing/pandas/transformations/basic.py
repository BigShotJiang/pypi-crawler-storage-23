from functools import reduce

import numpy as np
import pandas as pd

from datamazing.pandas.types import TimeTravel

# we dont use pd.Timestamp.min and pd.Timestamp.max,
# as these values are too obscure
MIN_TIMESTAMP = pd.Timestamp("1900-01-01T00:00:00")
MAX_TIMESTAMP = pd.Timestamp("2200-01-01T00:00:00")


def fill_empty_periods(df, period: tuple[str, str]):
    df = df.copy()
    min_timestamp = MIN_TIMESTAMP.tz_localize(getattr(df.dtypes[period[0]], "tz", None))
    max_timestamp = MAX_TIMESTAMP.tz_localize(getattr(df.dtypes[period[1]], "tz", None))
    df[period[0]] = df[period[0]].fillna(min_timestamp)
    df[period[1]] = df[period[1]].fillna(max_timestamp)
    return df


def latest(
    df: pd.DataFrame,
    on: str,
):
    s = df.sort_values(by=on).iloc[-1]
    s.name = None
    return s


def earliest(df: pd.DataFrame, on: str):
    s = df.sort_values(by=on).iloc[0]
    s.name = None
    return s


def _absolute_time_travel(
    df: pd.DataFrame,
    as_of_time: pd.Timestamp,
):
    return df[
        (df["valid_from_time_utc"] <= as_of_time)
        & (df["valid_to_time_utc"] > as_of_time)
    ]


def _relative_time_travel(
    df: pd.DataFrame,
    horizon: pd.Timedelta,
    block: pd.Timedelta,
):
    offset = df["time_utc"].dt.floor(block) - horizon
    return df[
        (df["valid_from_time_utc"] <= offset) & (df["valid_to_time_utc"] > offset)
    ]


def time_travel(
    df: pd.DataFrame,
    time_travel: TimeTravel,
) -> pd.DataFrame:
    """Time travel a periodized DataFrame.

    Args:
        df (pd.DataFrame): DataFrame
        interval (tuple[str, str]): Periodization interval columns.
        time_travel (TimeTravel): Time travel.
    """
    if time_travel.tense == "absolute":
        return _absolute_time_travel(df, time_travel.as_of_time)
    else:
        return _relative_time_travel(df, time_travel.horizon, time_travel.block)


def shift_time(
    df: pd.DataFrame,
    on: str,
    period: pd.Timedelta,
):
    df = df.copy()
    df[on] = df[on] + period
    return df


def unique_one(s: pd.Series) -> object:
    if len(s.unique()) > 1:
        raise ValueError("Series has more than one unique value")
    return s.iloc[0]


def concat_by_name(dfs: list[pd.DataFrame]) -> pd.DataFrame:
    columns = [df.columns for df in dfs]
    common_cols = reduce(lambda cols1, cols2: cols1.union(cols2), columns).unique()
    return pd.concat([df.reindex(columns=common_cols) for df in dfs], ignore_index=True)


def unpivot(
    df: pd.DataFrame, on: list[str], variable: str = "variable", value: str = "value"
):
    remaining_cols = df.columns.drop(on).tolist()
    df = df.set_index(remaining_cols)
    df.columns.name = variable
    s = df.stack()
    s.name = value
    df = s.reset_index()
    return df


def switch(
    cases: list[tuple[pd.Series, pd.Series | object]],
    default: pd.Series | object,
) -> pd.Series:
    """Choose among a set of values depending on a set of conditions

    Args:
        cases (list[tuple[pd.Series, pd.Series  |  object]]):
            List of cases, with each element being a tuple
            of the form (when, then). I.e. if `when` is satisfied,
            choose `then`. If multiple cases are satisfied,
            the first one is choosen.
        default (pd.Series | object):
            If no cases are satisfied, this value will be choosen.

    Example:
    >>> df["sign"] = pdz.switch(
    ...     cases=[
    ...         (df["value"] > 0, "positive"),
    ...         (df["value"] < 0, "negative"),
    ...     ],
    ...     default="zero",
    ... )
    """
    array = np.select(
        condlist=[case[0] for case in cases],
        choicelist=[case[1] for case in cases],
        default=default,
    )

    return pd.Series(array)
