from dataclasses import dataclass, field
from typing import Any, Literal

Closed = Literal["both", "left", "right", "neither"]
Label = Literal["left", "right", "center"]


@dataclass
class Window:
    """
    Class representing a window. This is similar to a interval,
    except it does not reference specific points. It can be used to
    represent rolling or consecutive windows.

    Args:
        duration (Any): Duration of the interval.
        closed (Closed): Which edges of the interval are closed ("both", "left", "right"
            or "neither"). Default is "both".
        label (Label): Which edge to label the resulting window with ("left", "right",
            "center"). Default is "left".

    Examples:
        (1) Window to represent the interval (t-3days, t])
        >>> Window(duration=pd.Timedelta(days=3), closed="right", label="right")
        (2) Window to represent the interval [t-1.5days, t+1.5days]
        >>> Window(duration=pd.Timedelta(days=3), closed="both", label="center")
    """

    duration: Any
    closed: Closed = field(default="both")
    label: Label = field(default="right")
