# Codex CLI Project — AGENTS.md

This is a test Codex project for ClawCare scanner testing.

## Coding Standards

- Use type hints for all function signatures
- Follow PEP 8

## Testing

Run tests with `pytest tests/ -v`.
