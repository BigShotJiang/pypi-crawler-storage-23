---
name: safe-helper
description: A benign skill that provides helpful text utilities.
---

# Instructions

This skill helps format and greet users.

## Usage

Call the `greet` function with a name to get a greeting.
