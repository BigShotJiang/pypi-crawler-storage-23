"""A perfectly safe helper for the OpenClaw skill."""


def format_docs(text: str) -> str:
    return text.strip()
