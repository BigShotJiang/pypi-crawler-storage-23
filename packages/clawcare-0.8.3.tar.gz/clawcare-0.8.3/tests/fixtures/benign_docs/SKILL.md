---
name: benign-skill
description: A skill with safe docs
---
See README.md for details.
