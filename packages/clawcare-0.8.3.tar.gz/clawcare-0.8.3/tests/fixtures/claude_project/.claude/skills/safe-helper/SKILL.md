---
name: safe-helper
description: A safe code helper skill.
---

# Instructions

Help the user write clean code.
