---
name: safe-cursor-skill
description: A benign Cursor skill for formatting code.
---

# Instructions

This skill formats TypeScript code according to project standards.
