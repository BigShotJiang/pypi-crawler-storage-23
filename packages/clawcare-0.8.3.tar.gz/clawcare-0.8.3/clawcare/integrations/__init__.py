"""Built-in adapters for supported ecosystems."""
