"""Kioku Agent Kit Lite — zero-Docker personal memory engine."""

__version__ = "0.1.0"
