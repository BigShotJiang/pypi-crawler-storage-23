import json

import click
from click.core import Context as ClickContext

from gable.api.client import GableAPIClient
from gable.cli.options import global_options


@click.command(
    add_help_option=False,
    name="export",
    epilog="""Example:
    gable lineage export""",
)
@global_options(add_endpoint_options=False)
@click.option(
    "--run-id",
    help="Get the cross-service components for a given run-id (now event-id).",
    type=str,
    required=True,
)
@click.pass_context
def lineage_export(
    ctx: ClickContext,
    run_id: str,
):
    """
    Export lineage data from Gable.
    """
    client: GableAPIClient = ctx.obj.client
    cross_service_components = client.get_components_by_run_id(run_id=run_id)
    json_string = json.dumps(cross_service_components, indent=2)
    print(json_string)
