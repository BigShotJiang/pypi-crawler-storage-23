import json
import os
import re

import click
from click.core import Context as ClickContext
from loguru import logger
from pydantic import ValidationError

from gable.api.client import GableAPIClient
from gable.cli.helpers.lineage_api import upload_sca_results_via_api
from gable.cli.helpers.npm import prepare_npm_environment
from gable.cli.helpers.sca_run import DuplicateStartRunConflict, start_sca_run
from gable.cli.options import global_options
from gable.common_types import LineageDataFile
from gable.openapi import CollectionMechanism, CrossServiceDataStore, CrossServiceEdge


def get_lineage_schema(upload_type: str | None):
    if upload_type == "DATA_STORE":
        return CrossServiceDataStore
    elif upload_type == "EDGE":
        return CrossServiceEdge
    return LineageDataFile


@click.command(
    add_help_option=False,
    name="upload",
    epilog="""Example:
    gable lineage upload --project-root ./path/to/project""",
)
@global_options(add_endpoint_options=False)
@click.option(
    "--project-root",
    help="The root directory of the project that will be analyzed.",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--results-file",
    help="The path to the results file.",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--namespace",
    envvar="GABLE_NAMESPACE",
    type=str,
    callback=lambda ctx, _param, value: (
        value
        if value is None or re.fullmatch(r"[a-zA-Z0-9_.\-]+", value)
        else ctx.fail(
            f"Invalid namespace '{value}'. Must only contain alphanumeric characters, underscores, hyphens, and dots."
        )
    ),
    help="INTERNAL: select the namespace you want lineage results to be associated with.",
    required=True,
)
@click.pass_context
def lineage_upload(
    ctx: ClickContext,
    project_root: str,
    results_file: str,
    namespace: str | None,
):
    """
    Upload lineage data to Gable.
    """
    client: GableAPIClient = ctx.obj.client
    with open(results_file, "r") as f:
        results = json.load(f)
    try:
        upload_type = results.get("type")
        metadata = results.get("metadata", None)
        user_job_trigger = (
            None if metadata is None else metadata.get("job_trigger", None)
        )
        LineageFile = get_lineage_schema(upload_type)
        lineage_obj = LineageFile.model_validate(results)
    except ValidationError as e:
        logger.debug(f"Invalid results file: {e}")
        raise click.ClickException(f"Invalid results file: {e}")

    prepare_npm_environment(client)
    external_component_id = getattr(lineage_obj, "external_component_id", None)
    repo_name = getattr(lineage_obj, "name", None)

    env_mechanism = os.environ.get("GABLE_COLLECTION_MECHANISM")
    collection_mechanism = CollectionMechanism(env_mechanism) if env_mechanism else None

    try:
        run_id, _ = start_sca_run(
            client=client,
            project_root=project_root,
            action="upload",
            output=None,
            include_unchanged_assets=None,
            external_component_id=external_component_id,
            upload_type=upload_type,
            repo_name=repo_name,
            namespace=namespace,
            user_job_trigger=user_job_trigger,
            collection_mechanism=collection_mechanism,
        )
    except DuplicateStartRunConflict as err:
        logger.warning(str(err))
        click.echo(
            f"{err}. Skipping upload because this run was already started. Exiting successfully."
        )
        return

    upload_sca_results_via_api(client, run_id, lineage_obj)

    click.echo(
        f"Uploaded lineage data from {results_file} to Gable with run ID: {run_id}"
    )
