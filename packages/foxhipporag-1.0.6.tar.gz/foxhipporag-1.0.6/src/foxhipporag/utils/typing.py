from typing import Tuple

Triple = Tuple[str, str, str]