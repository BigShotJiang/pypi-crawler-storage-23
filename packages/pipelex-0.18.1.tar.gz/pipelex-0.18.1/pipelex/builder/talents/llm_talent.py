from pipelex.types import StrEnum


class LLMTalent(StrEnum):
    DATA_RETRIEVAL = "data-retrieval"
    HR_EXPERT = "hr-expert"
    ACCOUNTING_EXPERT = "accounting-expert"
    CREATIVE_WRITER = "creative-writer"
    ENGINEER = "engineer"
    CODER = "coder"
    CODE_ANALYZER = "code-analyzer"
    VISION_LANGUAGE_MODEL = "vision-language-model"
    VISUAL_DESIGNER = "visual-designer"
