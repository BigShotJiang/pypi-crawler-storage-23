from pipelex.types import StrEnum


class ThinkingMode(StrEnum):
    NONE = "none"
    MANUAL = "manual"
    ADAPTIVE = "adaptive"
