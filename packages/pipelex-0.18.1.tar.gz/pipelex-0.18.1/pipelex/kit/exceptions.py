from pipelex.base_exceptions import PipelexError


class KitError(PipelexError):
    pass
