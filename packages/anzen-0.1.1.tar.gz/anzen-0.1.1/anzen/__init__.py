"""
Anzen — Open-source security layer for agentic AI.

Protects against:
  - Prompt injection (user messages)
  - RAG poisoning (document chunks)
  - Tool abuse (tool calls & parameters)
  - Anomalous session behavior

Usage:
    import anzen

    # Wrap any OpenAI-compatible client
    client = anzen.wrap(openai.OpenAI())

    # Or use guards individually
    from anzen import RAGGuard, ToolGuard, PromptGuard
"""

from .client import Anzen, wrap
from .config import AnzenConfig
from .events import EventBus, GuardEvent, EventAction, GuardType
from .exceptions import (
    BlockedError,
    AnzenError,
    PromptBlockedError,
    RAGBlockedError,
    ToolBlockedError,
)
from .guards.prompt import PromptGuard
from .guards.rag import RAGGuard, ChunkResult
from .guards.tool import ToolGuard, ToolCallResult

__all__ = [
    "Anzen",
    "wrap",
    "BlockedError",
    "AnzenError",
    "PromptBlockedError",
    "RAGBlockedError",
    "ToolBlockedError",
    "PromptGuard",
    "RAGGuard",
    "ChunkResult",
    "ToolGuard",
    "ToolCallResult",
    "AnzenConfig",
    "EventBus",
    "GuardEvent",
    "EventAction",
    "GuardType",
]

__version__ = "0.1.0"
