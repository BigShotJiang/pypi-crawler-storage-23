from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    # Auth
    api_key: str = ""                    # Empty = no auth (dev mode)
    api_key_header: str = "X-Api-Key"

    # Database
    database_url: str = "sqlite+aiosqlite:///./anzen.db"

    # CORS
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # Retention
    events_max_age_days: int = 30
    events_max_count: int = 100_000

    class Config:
        env_prefix = "ANZEN_"
        env_file = ".env"


settings = Settings()
