"""Anzen embedded dashboard server."""
