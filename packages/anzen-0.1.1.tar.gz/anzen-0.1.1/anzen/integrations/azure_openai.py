"""Azure OpenAI integration — wrap an existing AzureOpenAI client.

Azure OpenAI is fully OpenAI-compatible; create() passes through directly.

Usage:
    from openai import AzureOpenAI
    from anzen.integrations import wrap_azure_openai
    from anzen import AnzenConfig

    client = wrap_azure_openai(
        AzureOpenAI(
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
            api_version="2024-02-01",
        ),
        config=AnzenConfig(monitor_url="http://localhost:8000"),
        session_id="my-session",
    )
    r = client.chat.completions.create(
        model="gpt-4o",   # deployment name in Azure
        messages=[{"role": "user", "content": "Hello!"}],
    )
"""

from typing import Optional

from ..client import wrap as _wrap
from ..config import AnzenConfig
from ._base import BaseAdapter, BaseCompletions


class AzureOpenAICompletions(BaseCompletions):
    """Pass-through adapter: AzureOpenAI client is OpenAI-compatible."""

    def create(self, messages=None, **kwargs):
        return self._client.chat.completions.create(messages=messages, **kwargs)

    async def acreate(self, messages=None, **kwargs):
        comp = self._client.chat.completions
        if hasattr(comp, "acreate"):
            return await comp.acreate(messages=messages, **kwargs)
        # AsyncAzureOpenAI uses create() as a coroutine
        coro = comp.create(messages=messages, **kwargs)
        if hasattr(coro, "__await__"):
            return await coro
        raise NotImplementedError(
            "AzureOpenAI sync client does not support async; use AsyncAzureOpenAI"
        )


def wrap_azure_openai(
    client, config: Optional[AnzenConfig] = None, session_id: Optional[str] = None
):
    """Wrap an AzureOpenAI client with Anzen. Returns an Anzen-wrapped client."""
    return _wrap(
        BaseAdapter(AzureOpenAICompletions(client)),
        config=config,
        session_id=session_id,
    )
