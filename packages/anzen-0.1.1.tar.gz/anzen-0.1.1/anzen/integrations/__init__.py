"""
Anzen integrations — drop-in connectors for popular frameworks.

LLM wrappers (wrap_* → BaseAdapter + *Completions):
  - anzen.integrations.openai       (OpenAI)
  - anzen.integrations.azure_openai (Azure OpenAI)
  - anzen.integrations.anthropic    (Anthropic)
  - anzen.integrations.gemini       (Google Gemini)
  - anzen.integrations.ollama       (Ollama)
  - anzen.integrations.groq         (Groq)
  - anzen.integrations.mistral      (Mistral AI)
  - anzen.integrations.cohere       (Cohere)

Framework callbacks:
  - anzen.integrations.langchain  (LangChain CallbackHandler)
  - anzen.integrations.llamaindex (LlamaIndex observer)
"""

from ._base import extract_text
from .openai import wrap_openai
from .azure_openai import wrap_azure_openai
from .anthropic import wrap_anthropic
from .gemini import wrap_gemini
from .ollama import wrap_ollama
from .groq import wrap_groq
from .mistral import wrap_mistral
from .cohere import wrap_cohere

__all__ = [
    "extract_text",
    "wrap_openai",
    "wrap_azure_openai",
    "wrap_anthropic",
    "wrap_gemini",
    "wrap_ollama",
    "wrap_groq",
    "wrap_mistral",
    "wrap_cohere",
]
