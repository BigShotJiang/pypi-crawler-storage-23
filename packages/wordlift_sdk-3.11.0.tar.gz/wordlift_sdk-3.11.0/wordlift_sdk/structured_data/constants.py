DEFAULT_BASE_URL = "https://api.wordlift.io"
