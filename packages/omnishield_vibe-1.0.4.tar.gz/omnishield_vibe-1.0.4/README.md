# 🛡️ OmniShield-Vibe

A professional-grade command-line security toolkit designed to detect vulnerabilities and automatically protect systems in the era of rapid "Vibe Coding".

## 🚀 Features
- **Deep Web Scanning:** Identifies exposed sensitive files (e.g., `.env`, `.git`) common in Laravel, Django, and Nuxt.js projects.
- **Raw Socket Sniffing:** Low-level packet inspection to detect incoming attacks.
- **Auto-Protection:** Automatically blocks IP addresses and kills vulnerable processes.
- **Dynamic Reporting:** Generates Markdown reports for security audits.

## 🛠️ Installation

### Prerequisite (Windows Users)
You **MUST** install [Npcap](https://npcap.com/) for the raw socket sniffer to work. Make sure to check **"Install Npcap in WinPcap API-compatible Mode"** during installation.

### Install via Pip
```bash
pip install omnishield-vibe

💻 Usage
Run your Command Prompt (CMD) or PowerShell as Administrator.

omnishield