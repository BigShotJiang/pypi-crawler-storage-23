from datetime import datetime
import os

class Reporter:
    def __init__(self, target):
        self.target = target
        self.report_dir = "reports"
        self.report_file = f"{self.report_dir}/scan_{target.replace(':', '_')}.md"
        self._ensure_dir()

    def _ensure_dir(self):
        if not os.path.exists(self.report_dir):
            os.makedirs(self.report_dir)

    def generate_initial_report(self):
        with open(self.report_file, "w") as f:
            f.write(f"# OmniShield Security Report\n")
            f.write(f"- **Target:** {self.target}\n")
            f.write(f"- **Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"- **Mode:** Deep Web Scan & Raw Sniffing\n\n")
            f.write(f"## Found Vulnerabilities\n")
            f.write(f"| Timestamp | URL / Path | Severity | Description |\n")
            f.write(f"|-----------|------------|----------|-------------|\n")

    def log_finding(self, url, severity, description):
        timestamp = datetime.now().strftime("%H:%M:%S")
        with open(self.report_file, "a") as f:
            f.write(f"| {timestamp} | `{url}` | **{severity}** | {description} |\n")