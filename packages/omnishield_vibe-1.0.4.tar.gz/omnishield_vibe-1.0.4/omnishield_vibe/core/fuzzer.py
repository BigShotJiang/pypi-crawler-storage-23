# core/fuzzer.py (Versi Kompetitif)
import aiohttp
import asyncio

class OmniScanner:
    def __init__(self, log_callback):
        self.log_callback = log_callback
        # Payload untuk berbagai celah
        self.payloads = {
            "SQLi": ["' OR 1=1 --", '" OR "1"="1'],
            "XSS": ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>"],
            "Sensitive": ["/.env", "/.git/config", "/backup.sql", "/wp-config.php"]
        }

    async def scan_target(self, target_url):
        self.log_callback(f"Initiating Multi-Vector Scan on {target_url}", "SYSTEM")
        async with aiohttp.ClientSession() as session:
            tasks = []
            # 1. Cek File Sensitif
            for path in self.payloads["Sensitive"]:
                tasks.append(self.check_url(session, f"{target_url}{path}", "CRITICAL", "Information Disclosure"))
            
            # 2. Cek Parameter (SQLi/XSS) - Sederhana
            test_url = f"{target_url}/search?q=" 
            for payload in self.payloads["SQLi"]:
                tasks.append(self.check_url(session, f"{test_url}{payload}", "HIGH", "Potential SQL Injection"))
            
            await asyncio.gather(*tasks)

    async def check_url(self, session, url, severity, desc):
        try:
            async with session.get(url, timeout=5) as response:
                if response.status == 200:
                    self.log_callback(f"FOUND {severity}: {desc} at {url}", severity)
        except:
            pass