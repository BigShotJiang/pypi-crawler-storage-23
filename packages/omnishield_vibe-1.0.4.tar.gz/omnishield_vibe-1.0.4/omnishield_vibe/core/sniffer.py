from scapy.all import sniff, get_working_ifaces
import threading

class RawSniffer:
    def __init__(self, log_callback):
        self.log_callback = log_callback
        self.interface = self.auto_detect_interface()

    def auto_detect_interface(self):
        # Otomatis mencari interface dengan traffic aktif
        ifaces = get_working_ifaces()
        # Mengambil interface pertama yang valid (biasanya Wi-Fi atau Ethernet)
        active_iface = ifaces[0].name if ifaces else "None"
        return active_iface

    def packet_callback(self, packet):
        if packet.haslayer('TCP'):
            # Contoh deteksi sederhana: Paket dengan flag aneh (Potential Scan)
            if packet['TCP'].flags == 0x02: # SYN Packet
                self.log_callback(f"Inbound SYN detected from {packet[0][1].src}", "ALERT")

    def start_sniffing(self):
        sniff(iface=self.interface, prn=self.packet_callback, store=0)

# Jalankan di thread terpisah agar UI tidak hang