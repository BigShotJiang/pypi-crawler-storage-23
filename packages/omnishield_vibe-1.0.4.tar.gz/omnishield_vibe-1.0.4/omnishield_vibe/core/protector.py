import subprocess
import os
from plyer import notification # Install via: pip install plyer

class Protector:
    def __init__(self, log_callback):
        self.log_callback = log_callback

    def send_alert_popup(self, title, message):
        # Mengirim notifikasi ke Windows System Tray
        notification.notify(
            title=f"🚨 OMNISHIELD: {title}",
            message=message,
            app_name="OmniShield",
            timeout=10
        )

    def block_ip_firewall(self, remote_ip):
        # Menambahkan rule blokir ke Windows Firewall
        cmd = f'netsh advfirewall firewall add rule name="OmniShield_Block_{remote_ip}" dir=in action=block remoteip={remote_ip}'
        subprocess.run(cmd, shell=True, capture_output=True)
        self.log_callback(f"IP {remote_ip} has been blocked by Firewall.", "PROTECT")

    def kill_vulnerable_process(self, port):
        # Mencari PID yang menggunakan port tertentu dan mematikannya secara paksa
        try:
            # Mencari PID melalui port
            result = subprocess.check_output(f'netstat -ano | findstr :{port}', shell=True).decode()
            if result:
                lines = result.strip().split('\n')
                pid = lines[0].strip().split()[-1]
                # Force Kill
                os.system(f"taskkill /F /PID {pid}")
                self.log_callback(f"Process using port {port} (PID: {pid}) terminated.", "PROTECT")
        except Exception as e:
            self.log_callback(f"Failed to kill process on port {port}.", "ERROR")