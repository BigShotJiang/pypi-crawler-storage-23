import asyncio
import sys
import os
from datetime import datetime
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from rich.table import Table

from omnishield_vibe.core.fuzzer import OmniScanner
from omnishield_vibe.core.protector import Protector
from omnishield_vibe.core.reporter import Reporter

console = Console()

class OmniShieldUI:
    def __init__(self):
        self.layout = Layout()
        self.scanner_logs = []
        self.alert_logs = []
        self.setup_layout()

    def setup_layout(self):
        self.layout.split(
            Layout(name="header", size=3),
            Layout(name="body"),
            Layout(name="footer", size=3)
        )
        self.layout["body"].split_row(
            Layout(name="scanner_view", ratio=2),
            Layout(name="alert_view", ratio=1)
        )

    def generate_header(self, target="None"):
        return Panel(f"[bold green]OMNISHIELD-VIBE v1.0.4[/bold green] | Target: [cyan]{target}[/cyan]", style="green")

    def add_log(self, event, level="INFO"):
        time_str = datetime.now().strftime("%H:%M:%S")
        log_entry = {"time": time_str, "event": event, "level": level}
        
        self.scanner_logs.append(log_entry)
        if level in ["CRITICAL", "ALERT", "WARNING", "HIGH"]:
            self.alert_logs.append(log_entry)

    def make_table(self, logs, title, color):
        table = Table(title=title, style=color, expand=True)
        table.add_column("Time", style="dim", width=10)
        table.add_column("Event", style="bold")
        table.add_column("Lv", width=10)
        for log in logs[-12:]: 
            table.add_row(log['time'], log['event'], log['level'])
        return table

ui = OmniShieldUI()

async def run_shield_session():
    while True:
        console.clear()
        console.print(Panel("[bold green]OMNISHIELD MATRIX TERMINAL[/bold green]\n[dim]Ready for System Audit & Protection[/dim]", expand=False))
        
        # 1. Input Target
        target = console.input("\n[bold yellow]>[/bold yellow] Enter Target Domain/IP (or 'exit'): ")
        
        if target.lower() == 'exit':
            break

        # 2. Inisialisasi Modul
        reporter = Reporter(target)
        fuzzer = OmniScanner(ui.add_log)
        protector = Protector(ui.add_log)
        
        ui.add_log(f"Session started for {target}", "SYSTEM")

        # 3. Live Display & Processing
        with Live(ui.layout, refresh_per_second=4, screen=True):
            ui.layout["header"].update(ui.generate_header(target))
            
            # Jalankan scan sebagai background task
            scan_task = asyncio.create_task(fuzzer.scan_target(target))
            
            while not scan_task.done():
                ui.layout["scanner_view"].update(ui.make_table(ui.scanner_logs, "📡 Network Traffic", "green"))
                ui.layout["alert_view"].update(ui.make_table(ui.alert_logs, "⚠️ Security Alerts", "red"))
                ui.layout["footer"].update(Panel("[blink]SCANNING FOR VULNERABILITIES...[/blink]", style="green"))
                await asyncio.sleep(0.2)
            
            # Tampilkan hasil akhir tetap di dalam mode Live agar UI tidak hilang
            ui.layout["footer"].update(Panel("✅ Scan Complete! Press [bold white]'Enter'[/bold white] to review findings...", style="bold cyan"))
            
            # Menunggu input Enter tanpa menutup screen
            await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)

        # 4. Tahap Tindakan (Setelah UI Live ditutup)
        console.clear()
        if ui.alert_logs:
            console.print(Panel(f"[bold red]DETECTION SUMMARY[/bold red]\nFound {len(ui.alert_logs)} potential vulnerabilities on {target}.", style="red"))
            protector.send_alert_popup("Action Required", f"Issues found on {target}")
            
            confirm = console.input("\n[bold yellow]Execute global protection (Kill Process & Block IP)? (y/n/exit): [/bold yellow]")
            if confirm.lower() == 'y':
                protector.kill_vulnerable_process("ALL")
                ui.add_log("Global lockdown executed.", "SUCCESS")
            elif confirm.lower() == 'exit':
                break
        
        # Cek lokasi laporan
        report_path = os.path.abspath("reports")
        console.print(f"\n[green]Audit complete. Report generated at:[/green] [cyan]{report_path}[/cyan]")
        console.input("\n[bold white]Press Enter to return to main menu...[/bold white]")

def main():
    """Pintu masuk utama untuk perintah konsol 'omnishield'"""
    try:
        # Cek hak akses Administrator
        if os.name == 'nt':
            import ctypes
            if not ctypes.windll.shell32.IsUserAnAdmin():
                console.clear()
                console.print(Panel("[bold red]ACCESS DENIED[/bold red]\n\nPlease run this tool as [bold white]ADMINISTRATOR[/bold white] to enable Firewall & Process Protection.", title="Security Error", border_style="red"))
                sys.exit()
        
        asyncio.run(run_shield_session())
    except KeyboardInterrupt:
        console.print("\n[bold red]Program terminated by user.[/bold red]")
    except Exception as e:
        console.print(f"\n[bold red]CRITICAL ERROR:[/bold red] {e}")

if __name__ == "__main__":
    main()