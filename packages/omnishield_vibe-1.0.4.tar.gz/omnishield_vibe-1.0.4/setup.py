from setuptools import setup, find_packages

setup(
    name='omnishield-vibe',  # Nama paket saat di-pip install
    version='1.0.0',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'scapy',
        'rich',
        'aiohttp',
        'plyer',
    ],
    entry_points={
        'console_scripts': [
            # format: command_yang_diketik_di_cmd = module:fungsi_utama
            'omnishield=main:run_shield_session', 
        ],
    },
    author='Your Name',
    description='Professional Cyber Security Toolkit for Vibe Coding Era',
)