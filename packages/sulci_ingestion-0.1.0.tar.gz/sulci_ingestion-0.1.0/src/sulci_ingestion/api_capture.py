"""Parse OpenAI/Anthropic API payloads into Sulci interactions."""

from sulci_core.models import Interaction

from sulci_ingestion.models import APICapturePayload


def parse_openai_payload(request_body: dict, response_body: dict | None = None) -> APICapturePayload:
    """Parse an OpenAI chat completion request/response into a capture payload."""
    messages = request_body.get("messages", [])
    response_message = None

    if response_body:
        choices = response_body.get("choices", [])
        if choices:
            response_message = choices[0].get("message", {})

    return APICapturePayload(
        provider="openai",
        request_messages=messages,
        response_message=response_message,
        model=request_body.get("model"),
    )


def parse_anthropic_payload(request_body: dict, response_body: dict | None = None) -> APICapturePayload:
    """Parse an Anthropic messages request/response into a capture payload."""
    messages = request_body.get("messages", [])

    # Include system message if present
    system = request_body.get("system")
    if system:
        if isinstance(system, str):
            messages = [{"role": "system", "content": system}] + messages
        elif isinstance(system, list):
            text = " ".join(block.get("text", "") for block in system if block.get("type") == "text")
            messages = [{"role": "system", "content": text}] + messages

    response_message = None
    if response_body:
        content = response_body.get("content", [])
        text_parts = [block.get("text", "") for block in content if block.get("type") == "text"]
        if text_parts:
            response_message = {"role": "assistant", "content": " ".join(text_parts)}

    return APICapturePayload(
        provider="anthropic",
        request_messages=messages,
        response_message=response_message,
        model=request_body.get("model"),
    )


def parse_gemini_payload(request_body: dict, response_body: dict | None = None) -> APICapturePayload:
    """Parse a Google Gemini generateContent request/response into a capture payload."""
    contents = request_body.get("contents", [])
    messages = []

    for part in contents:
        role = part.get("role", "user")
        text_parts = []
        for p in part.get("parts", []):
            if isinstance(p, dict) and "text" in p:
                text_parts.append(p["text"])
            elif isinstance(p, str):
                text_parts.append(p)
        if text_parts:
            # Map Gemini roles to standard roles
            mapped_role = "assistant" if role == "model" else role
            messages.append({"role": mapped_role, "content": " ".join(text_parts)})

    response_message = None
    if response_body:
        candidates = response_body.get("candidates", [])
        if candidates:
            content = candidates[0].get("content", {})
            resp_parts = content.get("parts", [])
            text_parts = [p.get("text", "") for p in resp_parts if isinstance(p, dict) and "text" in p]
            if text_parts:
                response_message = {"role": "assistant", "content": " ".join(text_parts)}

    return APICapturePayload(
        provider="gemini",
        request_messages=messages,
        response_message=response_message,
        model=request_body.get("model"),
    )


def capture_to_interaction(payload: APICapturePayload) -> Interaction:
    """Convert a capture payload into an Interaction."""
    messages = list(payload.request_messages)
    if payload.response_message:
        messages.append(payload.response_message)

    return Interaction(
        source_tool=f"{payload.provider}_proxy",
        messages=messages,
        metadata={
            "provider": payload.provider,
            "model": payload.model,
            **payload.metadata,
        },
    )
