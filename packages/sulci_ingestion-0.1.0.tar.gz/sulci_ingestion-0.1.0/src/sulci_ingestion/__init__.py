"""Sulci Ingestion — adapters for capturing interactions."""

from sulci_ingestion.api_capture import (
    capture_to_interaction,
    parse_anthropic_payload,
    parse_gemini_payload,
    parse_openai_payload,
)
from sulci_ingestion.manual_capture import manual_to_interaction
from sulci_ingestion.models import APICapturePayload, ManualCaptureRequest

__all__ = [
    "APICapturePayload",
    "ManualCaptureRequest",
    "capture_to_interaction",
    "manual_to_interaction",
    "parse_anthropic_payload",
    "parse_gemini_payload",
    "parse_openai_payload",
]
