"""Manual text ingestion."""

from sulci_core.models import Interaction

from sulci_ingestion.models import ManualCaptureRequest


def manual_to_interaction(request: ManualCaptureRequest) -> Interaction:
    """Convert a manual capture request into an Interaction."""
    return Interaction(
        source_tool=request.source_tool,
        messages=[{"role": "user", "content": request.text}],
        metadata={"tags": request.tags},
    )
