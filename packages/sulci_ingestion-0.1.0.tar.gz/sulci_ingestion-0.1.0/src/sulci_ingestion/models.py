"""Ingestion request models."""

from pydantic import BaseModel, Field


class ManualCaptureRequest(BaseModel):
    """Manual text ingestion request."""

    text: str
    source_tool: str = "manual"
    tags: list[str] = Field(default_factory=list)


class APICapturePayload(BaseModel):
    """A captured API request/response pair."""

    provider: str  # "openai", "anthropic", or "gemini"
    request_messages: list[dict]
    response_message: dict | None = None
    model: str | None = None
    metadata: dict = Field(default_factory=dict)
