"""Unit tests for SlackConnector.

Tests that don't require a live Slack connection. SDK calls are mocked.
"""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from appif.domain.messaging.errors import NotAuthorized, NotSupported
from appif.domain.messaging.models import (
    ConnectorCapabilities,
    ConnectorStatus,
    ConversationRef,
    MessageContent,
    MessageEvent,
    Identity,
)


# ---------------------------------------------------------------------------
# Phase 3: Credential validation
# ---------------------------------------------------------------------------


class TestCredentialValidation:
    def test_missing_bot_token_raises(self):
        """StaticTokenAuth.validate() raises when bot token is empty."""
        from appif.adapters.slack._auth import StaticTokenAuth

        auth = StaticTokenAuth(bot_token="", app_token="xapp-test")
        with pytest.raises(NotAuthorized, match="APPIF_SLACK_BOT_OAUTH_TOKEN"):
            auth.validate()

    def test_missing_app_token_raises(self):
        """StaticTokenAuth.validate() raises when app token is empty."""
        from appif.adapters.slack._auth import StaticTokenAuth

        auth = StaticTokenAuth(bot_token="xoxb-test", app_token="")
        with pytest.raises(NotAuthorized, match="APPIF_SLACK_BOT_APP_LEVEL_TOKEN"):
            auth.validate()

    def test_valid_tokens_construct(self):
        """Connector can be constructed with valid tokens (no network call)."""
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        assert connector.get_status() == ConnectorStatus.DISCONNECTED

    def test_custom_auth_provider(self):
        """Connector accepts a pluggable auth implementation."""
        from appif.adapters.slack.connector import SlackConnector

        class FakeAuth:
            @property
            def bot_token(self) -> str:
                return "xoxb-custom"

            @property
            def app_token(self) -> str:
                return "xapp-custom"

            def validate(self) -> None:
                pass  # Always valid

        connector = SlackConnector(auth=FakeAuth())
        assert connector.get_status() == ConnectorStatus.DISCONNECTED
        assert connector._auth.bot_token == "xoxb-custom"

    def test_custom_auth_validation_failure(self):
        """Custom auth that fails validation raises NotAuthorized."""
        from appif.adapters.slack.connector import SlackConnector

        class FailingAuth:
            @property
            def bot_token(self) -> str:
                return ""

            @property
            def app_token(self) -> str:
                return ""

            def validate(self) -> None:
                raise NotAuthorized("slack", reason="custom auth failed")

        with pytest.raises(NotAuthorized, match="custom auth failed"):
            SlackConnector(auth=FailingAuth())


# ---------------------------------------------------------------------------
# Phase 10: Capabilities
# ---------------------------------------------------------------------------


class TestCapabilities:
    def test_capabilities(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        caps = connector.get_capabilities()

        assert isinstance(caps, ConnectorCapabilities)
        assert caps.supports_realtime is True
        assert caps.supports_backfill is True
        assert caps.supports_threads is True
        assert caps.supports_reply is True
        assert caps.supports_auto_send is True
        assert caps.delivery_mode == "AUTOMATIC"


# ---------------------------------------------------------------------------
# Phase 4: Lifecycle status
# ---------------------------------------------------------------------------


class TestLifecycleStatus:
    def test_initial_status_disconnected(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        assert connector.get_status() == ConnectorStatus.DISCONNECTED

    def test_operations_require_connection(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        with pytest.raises(NotSupported, match="not connected"):
            connector.list_targets("T001")

    def test_send_requires_connection(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        ref = ConversationRef(connector="slack", account_id="T001", type="channel", opaque_id={"channel": "C1"})
        content = MessageContent(text="Hello")
        with pytest.raises(NotSupported, match="not connected"):
            connector.send(ref, content)

    def test_list_accounts_empty_when_disconnected(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        assert connector.list_accounts() == []

    def test_disconnect_when_already_disconnected(self):
        """Disconnect on disconnected connector is a no-op."""
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        connector.disconnect()  # Should not raise
        assert connector.get_status() == ConnectorStatus.DISCONNECTED


# ---------------------------------------------------------------------------
# Phase 7: Listener management
# ---------------------------------------------------------------------------


class TestListenerManagement:
    def test_register_and_unregister(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")

        listener = MagicMock()
        connector.register_listener(listener)
        assert listener in connector._listeners

        connector.unregister_listener(listener)
        assert listener not in connector._listeners

    def test_register_idempotent(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        listener = MagicMock()
        connector.register_listener(listener)
        connector.register_listener(listener)  # Second registration
        assert connector._listeners.count(listener) == 1

    def test_unregister_nonexistent_is_noop(self):
        from appif.adapters.slack.connector import SlackConnector

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")
        listener = MagicMock()
        connector.unregister_listener(listener)  # Should not raise

    def test_dispatch_to_listeners(self):
        """Dispatch delivers events to registered listeners."""
        from appif.adapters.slack.connector import SlackConnector
        from datetime import datetime, timezone

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")

        received = []

        class FakeListener:
            def on_message(self, event):
                received.append(event)

        listener = FakeListener()
        connector.register_listener(listener)

        event = MessageEvent(
            message_id="msg-1",
            connector="slack",
            account_id="T001",
            conversation_ref=ConversationRef(connector="slack", account_id="T001", type="channel"),
            author=Identity(id="U1", display_name="Alice", connector="slack"),
            timestamp=datetime(2026, 2, 18, tzinfo=timezone.utc),
            content=MessageContent(text="Hello"),
        )

        # Direct dispatch (no executor since not connected)
        connector._dispatch_to_listeners(event)

        assert len(received) == 1
        assert received[0].message_id == "msg-1"

    def test_crashing_listener_does_not_affect_others(self):
        """A listener that raises does not prevent other listeners from receiving."""
        from appif.adapters.slack.connector import SlackConnector
        from datetime import datetime, timezone

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")

        received = []

        class CrashingListener:
            def on_message(self, event):
                raise RuntimeError("I crashed!")

        class GoodListener:
            def on_message(self, event):
                received.append(event)

        connector.register_listener(CrashingListener())
        connector.register_listener(GoodListener())

        event = MessageEvent(
            message_id="msg-2",
            connector="slack",
            account_id="T001",
            conversation_ref=ConversationRef(connector="slack", account_id="T001", type="channel"),
            author=Identity(id="U1", display_name="Alice", connector="slack"),
            timestamp=datetime(2026, 2, 18, tzinfo=timezone.utc),
            content=MessageContent(text="Test"),
        )

        connector._dispatch_to_listeners(event)

        assert len(received) == 1

    def test_unregistered_listener_stops_receiving(self):
        from appif.adapters.slack.connector import SlackConnector
        from datetime import datetime, timezone

        connector = SlackConnector(bot_token="xoxb-test", app_token="xapp-test")

        received = []

        class TrackingListener:
            def on_message(self, event):
                received.append(event)

        listener = TrackingListener()
        connector.register_listener(listener)

        event = MessageEvent(
            message_id="msg-3",
            connector="slack",
            account_id="T001",
            conversation_ref=ConversationRef(connector="slack", account_id="T001", type="channel"),
            author=Identity(id="U1", display_name="Alice", connector="slack"),
            timestamp=datetime(2026, 2, 18, tzinfo=timezone.utc),
            content=MessageContent(text="First"),
        )

        connector._dispatch_to_listeners(event)
        assert len(received) == 1

        connector.unregister_listener(listener)
        connector._dispatch_to_listeners(event)
        assert len(received) == 1  # No new events