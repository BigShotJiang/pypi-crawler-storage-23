 Larry Dawson  [10:00 AM]
Oops - my bot accidentally sent a test message to you. Sorry. It's called Appif bot.
Brant Elliot  [10:00 AM]
ha - I was wondering that. All good"""Integration tests for SlackConnector against a LIVE Slack workspace.

⚠️  THESE TESTS HIT THE REAL SLACK API — they are NOT mocked.

- Requires APPIF_SLACK_BOT_OAUTH_TOKEN and APPIF_SLACK_BOT_APP_LEVEL_TOKEN
  in ~/.env. Skipped automatically if tokens are missing.
- The only acceptable send target is Larry Dawson (U01NVSBQH40).
  Override via APPIF_SLACK_TEST_USER_ID if needed, but NEVER target
  a coworker or shared channel from automated tests.

Run with: pytest tests/integration/test_slack_integration.py -v
"""

import os
import sys
import time

import pytest
from dotenv import load_dotenv

# Ensure src is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

load_dotenv(os.path.expanduser("~/.env"))

_HAS_TOKENS = bool(
    os.environ.get("APPIF_SLACK_BOT_OAUTH_TOKEN")
    and os.environ.get("APPIF_SLACK_BOT_APP_LEVEL_TOKEN")
)

pytestmark = pytest.mark.skipif(not _HAS_TOKENS, reason="Slack tokens not configured")


from appif.adapters.slack import SlackConnector
from appif.domain.messaging.models import (
    Account,
    ConnectorCapabilities,
    ConnectorStatus,
    ConversationRef,
    MessageContent,
    SendReceipt,
    Target,
)


class TestSlackIntegrationLifecycle:
    """Tests the full connect → query → disconnect lifecycle."""

    def test_connect_and_disconnect(self):
        connector = SlackConnector()
        assert connector.get_status() == ConnectorStatus.DISCONNECTED

        connector.connect()
        assert connector.get_status() == ConnectorStatus.CONNECTED

        connector.disconnect()
        assert connector.get_status() == ConnectorStatus.DISCONNECTED

    def test_capabilities_are_populated(self):
        connector = SlackConnector()
        caps = connector.get_capabilities()
        assert isinstance(caps, ConnectorCapabilities)
        assert caps.supports_realtime is True
        assert caps.supports_backfill is True
        assert caps.supports_threads is True
        assert caps.supports_reply is True

    def test_list_accounts_returns_workspace(self):
        connector = SlackConnector()
        connector.connect()
        try:
            accounts = connector.list_accounts()
            assert len(accounts) >= 1
            acct = accounts[0]
            assert isinstance(acct, Account)
            assert acct.account_id  # non-empty workspace ID
            assert acct.display_name  # non-empty workspace name
            assert acct.connector == "slack"
        finally:
            connector.disconnect()

    def test_list_targets_returns_channels(self):
        connector = SlackConnector()
        connector.connect()
        try:
            accounts = connector.list_accounts()
            assert accounts, "Expected at least one workspace"
            account_id = accounts[0].account_id

            targets = connector.list_targets(account_id)
            assert len(targets) > 0, "Expected at least one conversation"

            target = targets[0]
            assert isinstance(target, Target)
            assert target.target_id  # non-empty channel/DM ID
            assert target.display_name  # non-empty name
            assert target.type in ("channel", "dm", "group_dm", "private_channel")
        finally:
            connector.disconnect()

    def test_listener_registration(self):
        """Register and unregister a listener without errors."""
        connector = SlackConnector()

        received = []

        class TestListener:
            def on_message(self, event):
                received.append(event)

        listener = TestListener()
        connector.register_listener(listener)
        assert listener in connector._listeners

        connector.unregister_listener(listener)
        assert listener not in connector._listeners

    def test_send_to_self_dm(self):
        """Send a message to the test user's own DM and verify receipt.

        Uses conversations.open to get/create a DM channel with the
        bot owner, so we never accidentally message a coworker.
        """
        connector = SlackConnector()
        connector.connect()
        try:
            accounts = connector.list_accounts()
            account_id = accounts[0].account_id

            # Open (or retrieve) a DM channel with the bot owner
            # This is the bot→larry DM, which larry sees as the bot's messages
            owner_user_id = os.environ.get("APPIF_SLACK_TEST_USER_ID", "U01NVSBQH40")
            dm_resp = connector._client.conversations_open(users=[owner_user_id])
            dm_channel = dm_resp["channel"]["id"]

            ref = ConversationRef(
                connector="slack",
                account_id=account_id,
                type="dm",
                opaque_id={"channel": dm_channel},
            )
            content = MessageContent(text="🤖 Integration test — please ignore")

            receipt = connector.send(ref, content)

            assert isinstance(receipt, SendReceipt)
            assert receipt.external_id  # Slack message ts
            assert receipt.timestamp  # datetime populated
        finally:
            connector.disconnect()
