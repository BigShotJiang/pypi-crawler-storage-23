# Design Document: Slack Connector

**Author**: Architect
**Date**: 2026-02-18
**Status**: Draft
**Service**: Slack (via Slack API + Bolt)

---

## 1. Problem Statement

Agents need to participate in Slack conversations — receiving messages from workspaces and sending replies — without any knowledge of Slack's API, SDK, or transport mechanics. Today this requires a human at a keyboard or purpose-built bot code tightly coupled to the Slack platform.

This connector replaces that coupling. It provides a transport adapter that ingests Slack events, normalizes them into a canonical shape, and delivers outbound messages — all behind a stable interface that is identical regardless of whether the upstream system is Slack, Teams, Email, or anything else.

---

## 2. Core Principle

**A connector is a transport adapter.**

It does not reason, store meaning, or decide importance.

A connector:

- Connects to an external system
- Emits normalized inbound events
- Delivers outbound messages
- Exposes capabilities and lifecycle state

Nothing more.

---

## 3. Scope

### In Scope (Connector Responsibilities)

| Responsibility | Description |
|----------------|-------------|
| **Authentication & token lifecycle** | Bot token, app token, OAuth flows, token refresh |
| **Realtime event ingestion** | Receive messages via Socket Mode as they arrive |
| **Historical backfill** | Retrieve conversation history on demand |
| **Normalization** | Transform Slack events into canonical `MessageEvent` shape |
| **Message delivery** | Send messages and replies to channels, threads, and DMs |
| **Retry & rate-limit handling** | Respect Slack rate limits, retry transient failures |
| **Capability advertisement** | Report what this connector supports |
| **Failure surfacing** | Expose typed errors for authentication failures, unavailable targets, transient issues |

### Out of Scope (Lives Upstream)

| Concern | Why excluded |
|---------|-------------|
| Classify ask vs. inform | Interpretation, not transport |
| Track obligations | Memory / reasoning layer |
| Store long-term memory | Persistence layer |
| Infer intent | Agent reasoning |
| Auto-respond | Policy decision, not transport |
| Thread summarization | Content processing |
| Channel management (create, archive, rename) | Administrative mutation — not transport |
| User/group management | Administrative mutation |
| Slash commands, interactive components, modals | Separate interaction surface; may be a future connector extension |

---

## 4. Canonical Event Model

Every inbound message — Slack, Email, Teams, or any future platform — must arrive in this shape. This model is **connector-agnostic**. It is defined here as part of the first connector implementation but applies to all connectors.

### MessageEvent

The top-level event received by listeners.

| Field | Type | Description |
|-------|------|-------------|
| `message_id` | `str` | Connector-scoped unique identifier |
| `connector` | `str` | Source connector name: `"slack"`, `"email"`, `"teams"` |
| `account_id` | `str` | Workspace ID (Slack), mailbox (Email), tenant ID (Teams) |
| `conversation_ref` | `ConversationRef` | Opaque routing key for replies |
| `author` | `Identity` | Who sent the message |
| `timestamp` | `datetime` | When the message was sent (source timestamp) |
| `content` | `MessageContent` | The message body and attachments |
| `metadata` | `dict` | Raw or lightly-normalized platform facts (not interpreted) |

All fields are immutable. `MessageEvent` is a frozen value object.

### ConversationRef

An opaque routing key. The upstream system uses this to reply — it never inspects or constructs it.

| Field | Type | Description |
|-------|------|-------------|
| `connector` | `str` | Which connector owns this reference |
| `account_id` | `str` | Workspace / mailbox / tenant |
| `type` | `str` | `"channel"`, `"thread"`, `"dm"`, `"email_thread"` |
| `opaque_id` | `dict` | Connector-owned routing data; opaque to consumers |

**Rule**: If something is not needed to reply, it does not belong in `ConversationRef`.

For Slack, `opaque_id` will internally contain channel ID and optionally thread timestamp. This structure is private to the Slack connector — consumers never read or write it.

### Identity

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | Platform-scoped user identifier |
| `display_name` | `str` | Human-readable name |
| `connector` | `str` | Which connector resolved this identity |

### MessageContent

| Field | Type | Description |
|-------|------|-------------|
| `text` | `str` | Plain text content (Slack markdown stripped or preserved per connector policy) |
| `attachments` | `list` | File references or structured attachment metadata |

### SendReceipt

Returned after a successful outbound `send()`.

| Field | Type | Description |
|-------|------|-------------|
| `external_id` | `str` | Platform-assigned message identifier |
| `timestamp` | `datetime` | Platform-acknowledged send time |

No guarantees beyond "attempted and acknowledged by platform."

### ConnectorCapabilities

Each connector advertises what it can do. Agent logic branches on capabilities, not connector type.

| Field | Type | Slack value |
|-------|------|-------------|
| `supports_realtime` | `bool` | `True` (Socket Mode) |
| `supports_backfill` | `bool` | `True` (conversations.history) |
| `supports_threads` | `bool` | `True` |
| `supports_reply` | `bool` | `True` |
| `supports_auto_send` | `bool` | `True` |
| `delivery_mode` | `Literal["AUTOMATIC", "ASSISTED", "MANUAL"]` | `"AUTOMATIC"` |

---

## 5. Public Connector Interface

This is the entire surface area any upstream system sees. Nothing here mentions Slack, Bolt, or SDKs.

### Lifecycle

| Method | Description |
|--------|-------------|
| `connect()` | Authenticate and begin receiving events |
| `disconnect()` | Tear down connections, stop event ingestion |
| `get_status()` | Return current lifecycle state (`ConnectorStatus`) |

### Discovery

| Method | Description |
|--------|-------------|
| `list_accounts()` | List configured workspaces / accounts |
| `list_targets(account_id)` | List available channels, DMs, groups within an account |

### Inbound (Listener Registration)

| Method | Description |
|--------|-------------|
| `register_listener(listener)` | Subscribe a `MessageListener` to receive events |
| `unregister_listener(listener)` | Remove a previously registered listener |

### Outbound

| Method | Description |
|--------|-------------|
| `send(conversation_ref, content)` | Send a message to the conversation identified by the ref. Returns `SendReceipt`. |

The caller does not specify "Slack vs. Email." It replies using the `ConversationRef` it received. The connector resolves routing internally.

### Durability

| Method | Description |
|--------|-------------|
| `backfill(account_id, scope)` | Retrieve historical messages for specified scope. Emitted to registered listeners. |

Realtime and backfill are explicitly separate. Realtime events flow through listeners automatically. Backfill is an explicit call — on startup, on schedule, or during failure recovery. This avoids false confidence about message completeness.

### Capability Introspection

| Method | Description |
|--------|-------------|
| `get_capabilities()` | Return `ConnectorCapabilities` for this connector |

---

## 6. Listener Model

### Interface

Listeners implement a single method:

| Method | Description |
|--------|-------------|
| `on_message(event: MessageEvent)` | Called when an inbound message arrives |

### Design Rules

| Rule | Rationale |
|------|-----------|
| **Fire-and-forget** | Connector must not block on listener execution |
| **At-least-once delivery** | Listener code must be idempotent |
| **No return values** | Interpretation happens elsewhere; connector does not act on listener output |
| **No backpressure coupling** | Connector queues internally if a listener is slow |

### Internal Dispatch

Inside the connector, events arrive from the Slack platform, are normalized into `MessageEvent`, and dispatched to listeners via an internal queue or executor. This keeps ingestion resilient — a slow or crashing listener cannot stall the event pipeline.

Ordering guarantees are **per conversation**, not global.

---

## 7. Error Model

The connector raises only connector-level errors. Platform-specific exceptions are caught internally and mapped to typed connector errors.

| Error | When raised |
|-------|-------------|
| `ConnectorError` | Base class for all connector errors |
| `NotAuthorized` | Authentication failure, expired token, revoked access |
| `NotSupported` | Requested operation not available for this connector |
| `TargetUnavailable` | Channel/DM/workspace not reachable |
| `TransientFailure` | Temporary failure (rate limit, network timeout) — safe to retry |

**Never raised outward**: HTTP status codes, SDK exceptions, Slack API error strings. These are logged internally for diagnostics but never leak through the public interface.

---

## 8. Concurrency & Ordering

| Constraint | Description |
|------------|-------------|
| Connector controls its own event loop / threads | No shared event loop with upstream |
| Listener callbacks are isolated | One listener's failure does not affect another |
| Connector must survive slow or crashing listeners | Internal queue absorbs backpressure |
| Ordering guarantees are per conversation, not global | Messages within a channel/thread arrive in order; no cross-conversation ordering promise |

---

## 9. Slack-Specific Internals (Private Boundary)

Everything below is internal to the Slack connector implementation. It is documented here to establish architectural boundaries, not to prescribe implementation. Zero Slack types, imports, or semantics leak through the public interface.

### Technology Stack (Internal)

| Component | Purpose |
|-----------|---------|
| **Bolt for Python** | OAuth, Socket Mode, event routing |
| **slack_sdk** | `conversations.list`, `conversations.history`, `chat.postMessage`, `users.info` |

### Internal Responsibilities

| Concern | Internal component |
|---------|--------------------|
| OAuth & token management | Bolt OAuth flow or pre-configured bot/app tokens |
| Realtime event ingestion | Bolt Socket Mode handler |
| Event normalization | Internal mapper: Slack event → `MessageEvent` |
| Message delivery | `chat.postMessage` / `chat.postEphemeral` via slack_sdk |
| User resolution | `users.info` calls, cached internally |
| Channel/target listing | `conversations.list` via slack_sdk |
| History retrieval | `conversations.history` / `conversations.replies` via slack_sdk |
| Rate-limit handling | Internal retry with backoff, respecting `Retry-After` headers |

### Replaceability Test

If Bolt is deleted tomorrow and replaced with raw HTTP + WebSocket, the public `Connector` interface does not change. No upstream code requires modification.

---

## 10. Credential Configuration

| Environment Variable | Description |
|----------------------|-------------|
| `SLACK_BOT_TOKEN` | Bot user OAuth token (`xoxb-...`) |
| `SLACK_APP_TOKEN` | App-level token for Socket Mode (`xapp-...`) |
| `SLACK_SIGNING_SECRET` | Request signing secret (if using HTTP mode) |

Credentials are loaded from `~/.env` using `python-dotenv`, consistent with the existing project pattern. The project-root `.env.example` documents expected keys. Actual values are never committed.

---

## 11. Serialization Readiness

To keep future HTTP exposure trivial:

| Constraint | Rationale |
|------------|-----------|
| All public inputs/outputs are serializable | JSON-ready without custom encoders |
| No closures in public API | Stateless interface |
| No reliance on shared mutable state | Safe for concurrent access |
| Listener registration is explicit and reversible | Clean lifecycle management |

---

## 12. Relationship to Existing Domain Models

The current domain models (`Article`, `Edition`, `Section` in `models.py`) serve **content-extraction connectors** — the Economist, Foreign Affairs, Irish Times. These are viewer-layer adapters that retrieve and structure published content.

The messaging connector domain (`MessageEvent`, `ConversationRef`, `MessageContent`, `Identity`, `SendReceipt`, `ConnectorCapabilities`) serves a fundamentally different purpose: **bidirectional transport**. These types will live in their own domain area, separate from the content-extraction models.

The `Connector` interface defined in this document is the shared abstraction for all messaging connectors (Slack, Teams, Email). Content-extraction adapters continue to implement the existing `ContentSource` port.

---

## 13. Constraints & Non-Negotiable Decisions

1. **The connector is a transport adapter.** It does not interpret, classify, or auto-respond. All intelligence lives upstream.

2. **The canonical event model is shared.** `MessageEvent` and its component types are not Slack-specific. Any future messaging connector produces the same shapes.

3. **Slack internals are fully encapsulated.** Zero Slack SDK imports or types appear in any code outside the Slack adapter package.

4. **Listeners are fire-and-forget sinks.** The connector dispatches and moves on. Listener failures are the listener's problem.

5. **Realtime and backfill are separate.** No implicit "catch up" behavior. Backfill is an explicit operation.

6. **Errors are typed and connector-scoped.** Platform exceptions never escape.

7. **The public interface is the same for every messaging connector.** You can swap Slack for Teams by changing the connector instance, not the calling code.

---

## 14. What This Buys You

| Benefit | How |
|---------|-----|
| Slack / Teams / Email all look identical upstream | Shared canonical event model + shared connector interface |
| Bolt can be replaced without rewriting the agent | All Slack specifics are internal to the adapter |
| Mímir (or any memory system) plugs in as just another listener | Listener model is a generic sink |
| Auto-respond logic sits cleanly above the connector | Connector does not decide; it transports |
| Testable in isolation | Fake listeners, no platform dependency for interface tests |

### Mental Model

```
Connector = I/O
Listeners = Sinks