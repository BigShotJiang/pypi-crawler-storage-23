"""Outlook / Microsoft 365 messaging connector.

Requires the ``outlook`` extra::

    uv pip install -e ".[outlook]"

All Graph SDK and MSAL internals are encapsulated here.
No Microsoft-specific types leak through the public ``Connector`` interface.

Auth is pluggable via the ``OutlookAuth`` protocol. The default
``MsalAuth`` loads tokens from a persisted MSAL cache file.
"""

try:
    from appif.adapters.outlook._auth import MsalAuth, OutlookAuth
    from appif.adapters.outlook.connector import OutlookConnector
except ImportError as _exc:
    _msg = (
        "Outlook dependencies not installed. "
        "Install with: uv pip install -e \".[outlook]\""
    )
    raise ImportError(_msg) from _exc

__all__ = ["OutlookConnector", "OutlookAuth", "MsalAuth"]