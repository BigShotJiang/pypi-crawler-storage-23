"""Slack connector adapter.

Requires the ``slack`` extra::

    uv pip install -e ".[slack]"
    # or: pipx install '.[slack]'

All Slack SDK and Bolt internals are encapsulated here.
No Slack types leak through the public ``Connector`` interface.

Auth is pluggable via the ``SlackAuth`` protocol. The default
``StaticTokenAuth`` loads tokens from environment variables.
Inject a custom ``SlackAuth`` implementation for OAuth, secrets
managers, or any other credential strategy.
"""

try:
    from appif.adapters.slack._auth import SlackAuth, StaticTokenAuth
    from appif.adapters.slack.connector import SlackConnector

    __all__ = ["SlackConnector", "SlackAuth", "StaticTokenAuth"]
except ImportError:
    # Slack dependencies not installed — submodules that don't need
    # slack_bolt (e.g. _normalizer) remain importable directly.
    __all__ = []