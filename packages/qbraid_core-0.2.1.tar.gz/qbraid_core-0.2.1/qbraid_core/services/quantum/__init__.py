# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""
Module providing client for interacting with qBraid quantum services.

.. currentmodule:: qbraid_core.services.quantum

"""

from qbraid_core._import import LazyLoader

runner = LazyLoader("runner", globals(), "qbraid_core.services.quantum.runner")

__all__ = ["runner"]
