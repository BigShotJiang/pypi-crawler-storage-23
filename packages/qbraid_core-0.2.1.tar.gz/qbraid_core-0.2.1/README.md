# qbraid-core

[![Documentation](https://img.shields.io/badge/Documentation-DF0982)](https://qbraid.github.io/qbraid-core/)
[![codecov](https://codecov.io/gh/qBraid/qbraid-core/graph/badge.svg?token=vnZxySTsW2)](https://codecov.io/gh/qBraid/qbraid-core)
[![PyPI version](https://img.shields.io/pypi/v/qbraid-core.svg?color=blue)](https://pypi.org/project/qbraid-core/)
[![Python verions](https://img.shields.io/pypi/pyversions/qbraid-core.svg?color=blue)](https://pypi.org/project/qbraid-core/)
[![GitHub](https://img.shields.io/badge/issue_tracking-github-blue?logo=github)](https://github.com/qBraid/community/issues)

Python library providing core abstractions for software development within the qBraid ecosystem, and a low-level interface to a growing array of qBraid cloud services. The qbraid-core package forms the foundational base for the [qBraid CLI](https://pypi.org/project/qbraid-cli/), the [qBraid SDK](https://pypi.org/project/qbraid/), and the
[jupyter-environment-manager](https://pypi.org/project/jupyter-environment-manager/).

You can find the latest, most up to date, documentation [here](https://qbraid.github.io/qbraid-core/), including a list of services that are supported.

*See also*: [`qbraid-core-js`](https://qbraid.github.io/qbraid-core-js/)

## Getting Started

You can install qbraid-core from PyPI with:

```bash
python -m pip install qbraid-core
```

### Local configuration

After installing qbraid-core, you must configure your account credentials:

1. Create a qBraid account or log in to your existing account by visiting
   [account.qbraid.com](https://account.qbraid.com/)
2. Navigate to **Account** > **API Keys** in the left-sidebar, and then click "Create API Key". See [API Key docs](https://docs.qbraid.com/v2/home/account#api-keys).
3. Save your API key from step 2 in local [configuration file](https://docs.qbraid.com/v2/cli/user-guide/config-files). On Linux and macOS, this file is located at `~/.qbraid/qbraidrc`, where `~` corresponds to your home (`$HOME`) directory. On Windows, the equivalent default location is `%USERPROFILE%\.qbraid\qbraidrc`.

```ini
[default]
api-key = YOUR_KEY
url = https://api-v2.qbraid.com/api/v1
```

Or generate your `~/.qbraid/qbraidrc` file via the qbraid-core Python interface:

```python
>>> from qbraid_core import QbraidSessionV1
>>> session = QbraidSessionV1(api_key='API_KEY')
>>> session.save_config()
>>> session.get_available_services()
['environments', 'runtime', 'storage']
```

Other credential configuration methods are available using the [qBraid-CLI](https://docs.qbraid.com/v2/cli/api-reference/qbraid_configure).

### Verify setup

After configuring your qBraid credentials, verify your setup by running the following from a Python interpreter:

```python
>>> import qbraid_core
>>> quantum_runtime_client = qbraid_core.client('runtime')
>>> devices = quantum_runtime_client.list_devices()
>>> for device in devices:
...     print(device.qrn, device.status)
```

## Community

- For feature requests and bug reports: [Submit an issue](https://github.com/qBraid/community/issues)
- For discussions and/or specific questions about qBraid services, [join our discord community](https://discord.gg/KugF6Cnncm)
- For questions that are more suited for a forum, post to [Stack Overflow](https://stackoverflow.com/) with the [`qbraid`](https://stackoverflow.com/questions/tagged/qbraid) tag.
