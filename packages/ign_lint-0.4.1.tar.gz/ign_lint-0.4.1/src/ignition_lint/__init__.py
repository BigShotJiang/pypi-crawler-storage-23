# pylint: disable=invalid-name
"""
Init file for ignition_lint package.

This file ensures the directory is recognized as a Python package.
"""
