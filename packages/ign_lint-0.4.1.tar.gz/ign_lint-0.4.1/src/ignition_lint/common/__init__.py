"""
Common utilities and shared functionality for ignition-lint.

This module contains utility functions and classes that are used across
the ignition-lint framework, including JSON processing and shared constants.
"""
