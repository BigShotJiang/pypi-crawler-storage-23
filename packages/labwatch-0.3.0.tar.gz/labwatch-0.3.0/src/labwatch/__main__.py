"""Allow running labwatch as `python -m labwatch`."""

from labwatch.cli import cli

cli()
