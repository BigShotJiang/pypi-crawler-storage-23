"""TeamSecret CLI — pull secrets from your TeamSecret dashboard."""
