"""GHEA Mariam subset font data."""
