"""locstat: Count lines of code"""

__version__ = "1.3.1"
__author__ = "Parth Acharya"
__tool_name__ = "locstat"
