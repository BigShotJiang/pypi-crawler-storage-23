"""Crash reporting — scrub, fingerprint, and POST to server."""
