"""
oh-my-linear (OhMyLinear) - unified Linear MCP via local cache + official fallback.
"""

from .server import main

__version__ = "0.6.1"
__all__ = ["main"]
