"""Atlas GUI — k8scout-style D3.js web interface and report export."""
