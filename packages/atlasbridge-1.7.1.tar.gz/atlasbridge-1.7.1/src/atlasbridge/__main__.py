"""Allow ``python -m atlasbridge`` to launch the CLI."""

from atlasbridge.cli.main import cli

if __name__ == "__main__":
    cli()
