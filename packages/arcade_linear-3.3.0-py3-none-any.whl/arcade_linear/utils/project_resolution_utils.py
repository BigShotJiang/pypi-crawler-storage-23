"""Project resolution helpers shared across tools.

Several tools accept a "project" parameter that may be provided as:
- project UUID
- project slug_id (12-char)
- full project slug (e.g. "<name>-<slug_id>")
- Linear project URL
- project name (with fuzzy matching)

This module centralizes the parsing + fallback lookup logic so individual tools
don't have to re-implement it.
"""

import re
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlparse

from arcade_mcp_server.exceptions import RetryableToolError, ToolExecutionError
from gql.transport.exceptions import TransportQueryError

from arcade_linear.constants import (
    MAX_DISPLAY_SUGGESTIONS,
    MAX_FUZZY_SUGGESTIONS,
    MAX_PAGE_SIZE,
    VALIDATION_PROJECT_LIMIT,
)
from arcade_linear.utils.fuzzy_utils import try_fuzzy_match_by_name

if TYPE_CHECKING:
    from arcade_linear.client import LinearClient


_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
)
_SLUG_ID_RE = re.compile(r"^[a-z0-9]{12}$", re.IGNORECASE)


def looks_like_uuid(value: str) -> bool:
    return bool(_UUID_RE.fullmatch(value.strip()))


def looks_like_project_slug_id(value: str) -> bool:
    return bool(_SLUG_ID_RE.fullmatch(value.strip()))


def extract_project_slug_id(value: str) -> str | None:
    """Extract a Linear project's slug_id from a URL or full slug.

    Supports:
    - slug_id: "d8fd67972015"
    - full slug: "weekly-newsletter-d8fd67972015"
    - URL: "https://linear.app/<org>/project/weekly-newsletter-d8fd67972015"
    """
    candidate = value.strip()
    if not candidate:
        return None

    if candidate.startswith(("http://", "https://")):
        try:
            path = urlparse(candidate).path
        except ValueError:
            path = ""
        parts = [p for p in path.split("/") if p]
        if parts:
            candidate = parts[-1]

    if looks_like_project_slug_id(candidate):
        return candidate

    if "-" in candidate:
        tail = candidate.rsplit("-", 1)[-1]
        if looks_like_project_slug_id(tail):
            return tail

    return None


def format_fuzzy_suggestions_inline(fuzzy_info: Mapping[str, Any] | None) -> str:
    """Format `try_fuzzy_match_by_name` suggestions as a compact inline string."""
    if not fuzzy_info:
        return "none"
    suggestions = fuzzy_info.get("suggestions", [])
    if not suggestions:
        return "none"
    return ", ".join(
        f"{s.get('name')} ({round(float(s.get('confidence', 0)) * 100)}%)"
        for s in list(suggestions)[:MAX_DISPLAY_SUGGESTIONS]
    )


def try_resolve_project_from_list(
    projects: Sequence[Mapping[str, Any]],
    project_input: str,
    auto_accept_matches: bool,
) -> Mapping[str, Any] | None:
    """Best-effort resolution from a pre-fetched project list (no API calls)."""
    project_lower = project_input.lower().strip()

    slug_id = extract_project_slug_id(project_input)
    candidates = [project_input.strip()]
    if slug_id and slug_id not in candidates:
        candidates.append(slug_id)

    for candidate in candidates:
        for project in projects:
            if project.get("id") == candidate:
                return project
            if project.get("slugId") == candidate:
                return project
            name = project.get("name")
            if name and str(name).lower() == project_lower:
                return project

    matched, _fuzzy_info = try_fuzzy_match_by_name(
        list(projects), project_input, auto_accept_matches
    )
    return matched[0] if matched else None


def _is_not_found_or_invalid_transport_error(exc: TransportQueryError) -> bool:
    message = str(exc).lower()
    return "not found" in message or "invalid" in message


async def _safe_get_project_by_id(
    client: "LinearClient",
    project_id: str,
) -> Mapping[str, Any]:
    try:
        return await client.get_project_by_id(project_id)
    except TransportQueryError as e:
        if not _is_not_found_or_invalid_transport_error(e):
            raise
        return {}


async def try_get_project_by_input(
    client: "LinearClient",
    project_input: str,
    *,
    eager_direct_lookup: bool,
) -> Mapping[str, Any]:
    """Try to resolve a project via direct lookup (ID / slug_id / URL)."""
    slug_id = extract_project_slug_id(project_input)
    if slug_id:
        project_data = await _safe_get_project_by_id(client, slug_id)
        if project_data.get("id"):
            return project_data
        return {}

    if looks_like_uuid(project_input):
        project_data = await _safe_get_project_by_id(client, project_input)
        if project_data.get("id"):
            return project_data
        return {}

    if eager_direct_lookup:
        project_data = await _safe_get_project_by_id(client, project_input)
        if project_data.get("id"):
            return project_data

    return {}


async def _paginated_search(
    client: "LinearClient",
    total: int,
    project_filter: dict[str, Any] | None = None,
) -> list[Mapping[str, Any]]:
    """Fetch up to *total* projects, paginating in MAX_PAGE_SIZE chunks."""
    all_nodes: list[Mapping[str, Any]] = []
    cursor: str | None = None
    remaining = total

    while remaining > 0:
        page_size = min(remaining, MAX_PAGE_SIZE)
        response = await client.search_projects(
            project_filter=project_filter, first=page_size, after=cursor
        )
        nodes = cast(list[Mapping[str, Any]], response.get("nodes", []))
        all_nodes.extend(nodes)
        remaining -= len(nodes)

        page_info = response.get("pageInfo") or {}
        if not page_info.get("hasNextPage") or not nodes:
            break
        cursor = page_info.get("endCursor")

    return all_nodes


async def search_projects_with_fallback(
    client: "LinearClient",
    project_query: str,
    *,
    first_filtered: int,
    first_unfiltered: int,
) -> list[Mapping[str, Any]]:
    """Search projects by name, falling back to an unfiltered list for suggestions."""
    projects = await _paginated_search(
        client,
        first_filtered,
        project_filter={"name": {"containsIgnoreCase": project_query}},
    )
    if projects:
        return projects

    return await _paginated_search(client, first_unfiltered)


async def try_resolve_project(
    client: "LinearClient",
    project_input: str,
    auto_accept_matches: bool,
    *,
    validation_projects: Sequence[Mapping[str, Any]] | None = None,
    first_filtered: int,
    first_unfiltered: int,
    eager_direct_lookup: bool,
) -> tuple[Mapping[str, Any] | None, dict[str, Any] | None, list[Mapping[str, Any]]]:
    """Resolve a project input to a project entity with best-effort suggestions."""
    if validation_projects:
        resolved = try_resolve_project_from_list(
            list(validation_projects), project_input, auto_accept_matches
        )
        if resolved:
            return resolved, None, []

    direct = await try_get_project_by_input(
        client, project_input, eager_direct_lookup=eager_direct_lookup
    )
    if direct.get("id"):
        return direct, None, []

    candidates = await search_projects_with_fallback(
        client,
        project_input,
        first_filtered=first_filtered,
        first_unfiltered=first_unfiltered,
    )
    matched, fuzzy_info = try_fuzzy_match_by_name(
        list(candidates), project_input, auto_accept_matches
    )
    if matched:
        return matched[0], None, list(candidates)
    return None, fuzzy_info, list(candidates)


async def resolve_project_or_raise(
    client: "LinearClient",
    project_input: str,
    auto_accept_matches: bool,
    *,
    first_filtered: int,
    first_unfiltered: int,
    eager_direct_lookup: bool,
    not_found_message: str,
) -> Mapping[str, Any]:
    """Resolve a project for non-issue tools (returns entity, raises when not found)."""
    project, fuzzy_info, _candidates = await try_resolve_project(
        client,
        project_input,
        auto_accept_matches,
        first_filtered=first_filtered,
        first_unfiltered=first_unfiltered,
        eager_direct_lookup=eager_direct_lookup,
    )
    if project:
        return project

    if fuzzy_info:
        raise RetryableToolError(
            message=not_found_message,
            additional_prompt_content=(
                f"Suggestions: {format_fuzzy_suggestions_inline(fuzzy_info)}. "
                f"Note: only up to {first_filtered} filtered / {first_unfiltered} unfiltered "
                "projects were checked — the project may still exist beyond this window. "
                "Retry with the project UUID, slug_id, or URL for a direct lookup."
            ),
        )

    raise ToolExecutionError(
        message=(
            f"{not_found_message} "
            f"(searched up to {first_filtered} filtered / {first_unfiltered} unfiltered projects). "
            "It may still exist — retry with the project UUID, slug_id, or URL for a direct lookup."
        )
    )


async def resolve_project_id(
    client: "LinearClient",
    validation_projects: list[Mapping[str, Any]],
    project_input: str,
    auto_accept_matches: bool,
) -> str:
    """Resolve a project input to a project ID (issue tools).

    The issue create/update tools pre-fetch a limited project list for validation.
    That list can exclude valid projects. This resolver:
    - tries the pre-fetched list first (fast path)
    - falls back to direct lookup by ID/slug_id/URL
    - falls back to a name search with fuzzy matching
    """
    project, fuzzy_info, candidates = await try_resolve_project(
        client,
        project_input,
        auto_accept_matches,
        validation_projects=validation_projects,
        first_filtered=VALIDATION_PROJECT_LIMIT,
        first_unfiltered=VALIDATION_PROJECT_LIMIT,
        eager_direct_lookup=False,
    )
    if project and project.get("id"):
        return str(project["id"])

    available = [str(p.get("name") or "") for p in list(candidates)[:MAX_FUZZY_SUGGESTIONS]]
    suggestions_text = format_fuzzy_suggestions_inline(fuzzy_info)
    raise RetryableToolError(
        message=(
            f"Project '{project_input}' not found "
            f"(searched up to {VALIDATION_PROJECT_LIMIT} projects). "
            "It may still exist beyond this window."
        ),
        additional_prompt_content=(
            f"Suggestions: {suggestions_text}. Available projects: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_PROJECT_LIMIT} projects were checked. "
            "Retry with the project UUID, slug_id, or URL for a direct lookup."
        ),
    )
