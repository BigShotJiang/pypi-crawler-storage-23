"""Utility functions for issue tools - validation and entity resolution."""

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from arcade_mcp_server.exceptions import RetryableToolError, ToolExecutionError

if TYPE_CHECKING:
    from arcade_linear.client import LinearClient

from arcade_linear.constants import (
    FUZZY_AUTO_ACCEPT_CONFIDENCE,
    MAX_DISPLAY_SUGGESTIONS,
    MAX_FUZZY_SUGGESTIONS,
    MAX_PAGE_SIZE,
    VALIDATION_CYCLE_LIMIT,
    VALIDATION_LABEL_LIMIT,
    VALIDATION_MEMBER_LIMIT,
    VALIDATION_STATE_LIMIT,
    VALIDATION_TEAM_LIMIT,
)
from arcade_linear.utils.fuzzy_utils import fuzzy_match_entity
from arcade_linear.utils.project_resolution_utils import looks_like_uuid, resolve_project_id


def validate_and_resolve_team(
    teams: list[Mapping[str, Any]],
    team_input: str,
    auto_accept_matches: bool,
) -> str:
    """Validate and resolve team by name/key to team ID."""
    team_input_lower = team_input.lower()

    for team in teams:
        if team.get("id") == team_input:
            return str(team["id"])
        key = team.get("key")
        if key and str(key).lower() == team_input_lower:
            return str(team["id"])
        name = team.get("name")
        if name and str(name).lower() == team_input_lower:
            return str(team["id"])

    suggestions = _fuzzy_match_entities(team_input, list(teams), "name", auto_accept_matches)

    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"])

    available = [f"{t.get('name')} ({t.get('key')})" for t in list(teams)[:MAX_FUZZY_SUGGESTIONS]]
    raise RetryableToolError(
        message=(f"Team '{team_input}' not found (searched up to {VALIDATION_TEAM_LIMIT} teams)"),
        additional_prompt_content=(
            f"Suggestions: {_format_suggestions(suggestions.get('matches', []))}. "
            f"Available teams: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_TEAM_LIMIT} teams were checked — the team may "
            "still exist beyond this window. Retry with the exact team key (e.g. 'ENG') "
            "or UUID for a direct lookup."
        ),
    )


def validate_and_resolve_assignee(
    users: list[Mapping[str, Any]],
    assignee_input: str,
    team_name: str,
    auto_accept_matches: bool,
) -> str:
    """Validate and resolve assignee by name/email to user ID."""
    assignee_lower = assignee_input.lower()

    for user in users:
        if user.get("id") == assignee_input:
            return str(user["id"])
        email = user.get("email")
        if email and str(email).lower() == assignee_lower:
            return str(user["id"])
        name = user.get("name")
        if name and str(name).lower() == assignee_lower:
            return str(user["id"])
        display_name = user.get("displayName")
        if display_name and str(display_name).lower() == assignee_lower:
            return str(user["id"])

    suggestions = _fuzzy_match_entities(assignee_input, list(users), "name", auto_accept_matches)

    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"])

    available = [
        str(u.get("name") or u.get("email") or "") for u in list(users)[:MAX_FUZZY_SUGGESTIONS]
    ]
    raise RetryableToolError(
        message=(
            f"User '{assignee_input}' not found in team '{team_name}' "
            f"(searched up to {VALIDATION_MEMBER_LIMIT} members)"
        ),
        additional_prompt_content=(
            f"Suggestions: {_format_suggestions(suggestions.get('matches', []))}. "
            f"Team members: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_MEMBER_LIMIT} members were checked — the user "
            "may still exist in this team. "
            "Retry with an exact email, or use '@me' to assign to the current user."
        ),
    )


def validate_and_resolve_state(
    states: list[Mapping[str, Any]],
    state_input: str,
    team_name: str,
    auto_accept_matches: bool,
) -> str:
    """Validate and resolve workflow state by name to state ID."""
    state_lower = state_input.lower()

    for state in states:
        if state.get("id") == state_input:
            return str(state["id"])
        name = state.get("name")
        if name and str(name).lower() == state_lower:
            return str(state["id"])

    suggestions = _fuzzy_match_entities(state_input, list(states), "name", auto_accept_matches)

    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"])

    available = [f"{s.get('name')} ({s.get('type')})" for s in states]
    raise RetryableToolError(
        message=(
            f"State '{state_input}' not found for team '{team_name}' "
            f"(searched up to {VALIDATION_STATE_LIMIT} states)"
        ),
        additional_prompt_content=(
            f"Suggestions: {_format_suggestions(suggestions.get('matches', []))}. "
            f"Available states: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_STATE_LIMIT} states were checked — the state "
            "may still exist for this team."
        ),
    )


def _resolve_label_id_from_list(
    labels: list[Mapping[str, Any]],
    label_input: str,
    auto_accept_matches: bool,
) -> tuple[str | None, list[dict[str, Any]]]:
    """Resolve a single label input to an ID using a pre-fetched label list."""
    label_lower = label_input.lower()

    for label in labels:
        if label.get("id") == label_input:
            return str(label["id"]), []
        name = label.get("name")
        if name and str(name).lower() == label_lower:
            return str(label["id"]), []

    suggestions = _fuzzy_match_entities(label_input, list(labels), "name", auto_accept_matches)
    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"]), []

    return None, list(suggestions.get("matches", []))


def _resolve_label_ids_from_list(
    labels: list[Mapping[str, Any]],
    label_inputs: list[str],
    auto_accept_matches: bool,
) -> tuple[list[str | None], list[dict[str, Any]]]:
    """Resolve label inputs to IDs using a pre-fetched label list.

    Returns:
        - resolved_ids: list aligned with label_inputs (None when unresolved)
        - unresolved: list of {index, input, suggestions}
    """
    resolved_ids: list[str | None] = []
    unresolved: list[dict[str, Any]] = []

    for idx, label_input in enumerate(label_inputs):
        resolved_id, suggestions = _resolve_label_id_from_list(
            labels, label_input, auto_accept_matches
        )
        resolved_ids.append(resolved_id)
        if not resolved_id:
            unresolved.append({"index": idx, "input": label_input, "suggestions": suggestions})

    return resolved_ids, unresolved


def _raise_labels_not_found(
    unresolved: list[dict[str, Any]],
    labels: list[Mapping[str, Any]],
) -> None:
    available = [str(lb.get("name") or "") for lb in list(labels)[:MAX_FUZZY_SUGGESTIONS]]
    error_parts = [
        f"'{u['input']}' ({_format_suggestions(u.get('suggestions', []))})" for u in unresolved
    ]
    raise RetryableToolError(
        message=(
            f"Labels not found: {', '.join([u['input'] for u in unresolved])} "
            f"(searched up to {VALIDATION_LABEL_LIMIT} labels)"
        ),
        additional_prompt_content=(
            f"Suggestions for each: {'; '.join(error_parts)}. "
            f"Available labels: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_LABEL_LIMIT} labels were checked — the label "
            "may still exist beyond this window. "
            "Retry with the label UUID for a direct lookup that bypasses name matching."
        ),
    )


async def resolve_label_ids(
    client: "LinearClient",
    validation_labels: list[Mapping[str, Any]],
    label_inputs: list[str],
    auto_accept_matches: bool,
) -> list[str]:
    """Resolve label inputs to label IDs with a fallback fetch.

    The issue create/update tools pre-fetch a limited label list for validation.
    If a label isn't found, fetch more labels and try again.
    """
    if not label_inputs:
        return []

    # Fast path: treat UUID-like inputs as label IDs (no snapshot/list required).
    resolved_ids: list[str | None] = [None] * len(label_inputs)
    name_inputs: list[str] = []
    name_indices: list[int] = []

    for idx, label_input in enumerate(label_inputs):
        if looks_like_uuid(label_input):
            resolved_ids[idx] = label_input.strip()
        else:
            name_inputs.append(label_input)
            name_indices.append(idx)

    if not name_inputs:
        return [str(label_id) for label_id in resolved_ids if label_id]

    resolved, unresolved = _resolve_label_ids_from_list(
        validation_labels, name_inputs, auto_accept_matches
    )
    for idx, resolved_id in enumerate(resolved):
        resolved_ids[name_indices[idx]] = resolved_id

    if unresolved:
        # Only re-resolve the labels that weren't found in the validation snapshot,
        # so we never overwrite already-resolved slots with None.
        unresolved_names = [u["input"] for u in unresolved]
        unresolved_target_indices = [name_indices[u["index"]] for u in unresolved]

        labels_response = await client.get_labels(first=VALIDATION_LABEL_LIMIT)
        labels = labels_response.get("nodes", [])

        resolved, unresolved = _resolve_label_ids_from_list(
            list(labels), unresolved_names, auto_accept_matches
        )
        for i, resolved_id in enumerate(resolved):
            resolved_ids[unresolved_target_indices[i]] = resolved_id

        if unresolved:
            _raise_labels_not_found(unresolved, list(labels))

    return [str(label_id) for label_id in resolved_ids if label_id]


def validate_and_resolve_cycle(
    cycles: list[Mapping[str, Any]],
    cycle_input: str,
    team_name: str,
    auto_accept_matches: bool,
) -> str:
    """Validate and resolve cycle by name/number to cycle ID."""
    cycle_input_clean = cycle_input.strip()
    cycle_lower = cycle_input_clean.lower()
    cycle_number_input = (
        cycle_input_clean[1:] if cycle_input_clean.startswith("#") else cycle_input_clean
    )

    for cycle in cycles:
        if cycle.get("id") == cycle_input_clean:
            return str(cycle["id"])
        if str(cycle.get("number")) == cycle_number_input:
            return str(cycle["id"])
        name = cycle.get("name")
        if name and str(name).lower() == cycle_lower:
            return str(cycle["id"])

    suggestions = _fuzzy_match_entities(cycle_input, list(cycles), "name", auto_accept_matches)

    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"])

    available = [
        f"#{c.get('number')}" + (f" ({c.get('name')})" if c.get("name") else "")
        for c in list(cycles)[:MAX_FUZZY_SUGGESTIONS]
    ]
    raise RetryableToolError(
        message=(
            f"Cycle '{cycle_input}' not found for team '{team_name}' "
            f"(searched up to {VALIDATION_CYCLE_LIMIT} cycles)"
        ),
        additional_prompt_content=(
            f"Suggestions: {_format_suggestions(suggestions.get('matches', []))}. "
            f"Available cycles: {', '.join(available)}. "
            f"Note: only the first {VALIDATION_CYCLE_LIMIT} cycles were checked — the cycle "
            "may still exist for this team. "
            "Retry with the cycle UUID for a direct lookup."
        ),
    )


async def resolve_cycle_id(
    client: "LinearClient",
    team_id: str,
    team_name: str,
    validation_cycles: list[Mapping[str, Any]],
    cycle_input: str,
    auto_accept_matches: bool,
) -> str:
    """Resolve a cycle input to a cycle ID with a fallback fetch.

    The issue create/update tools pre-fetch a limited cycle list per team for validation.
    If a cycle isn't found, fetch more cycles for that team and try again.
    """
    try:
        return validate_and_resolve_cycle(
            validation_cycles, cycle_input, team_name, auto_accept_matches
        )
    except RetryableToolError:
        # Not found in the pre-fetched validation snapshot; fall back to API lookups below.
        pass

    # If the input looks like a UUID, try direct lookup before listing.
    if looks_like_uuid(cycle_input):
        cycle_data = await client.get_cycle_by_id(cycle_input)
        if cycle_data and cycle_data.get("id"):
            return str(cycle_data["id"])

    cycles_response = await client.get_cycles(team_id=team_id, first=VALIDATION_CYCLE_LIMIT)
    cycles = cycles_response.get("nodes", [])
    return validate_and_resolve_cycle(list(cycles), cycle_input, team_name, auto_accept_matches)


def validate_and_resolve_parent_issue(
    issues: list[Mapping[str, Any]],
    parent_input: str,
    auto_accept_matches: bool,
) -> str:
    """Validate and resolve parent issue by identifier to issue ID."""
    parent_upper = parent_input.upper()

    for issue in issues:
        if issue.get("id") == parent_input:
            return str(issue["id"])
        identifier = issue.get("identifier")
        if identifier and str(identifier).upper() == parent_upper:
            return str(issue["id"])

    suggestions = _fuzzy_match_entities(
        parent_input, list(issues), "identifier", auto_accept_matches
    )

    if suggestions.get("auto_accepted_id"):
        return str(suggestions["auto_accepted_id"])

    available = [str(i.get("identifier") or "") for i in list(issues)[:MAX_FUZZY_SUGGESTIONS]]
    raise RetryableToolError(
        message=(
            f"Parent issue '{parent_input}' not found "
            f"(searched the most recent {MAX_PAGE_SIZE} team issues)"
        ),
        additional_prompt_content=(
            f"Suggestions: {_format_suggestions(suggestions.get('matches', []))}. "
            f"Recent issues: {', '.join(available)}. "
            f"Note: only the most recent {MAX_PAGE_SIZE} issues were checked — the issue "
            "may still exist. Retry with the exact issue identifier (e.g. 'ENG-123')."
        ),
    )


def _fuzzy_match_entities(
    query: str,
    entities: list[Mapping[str, Any]],
    name_key: str,
    auto_accept_matches: bool,
) -> dict[str, Any]:
    """Perform fuzzy matching on entities using shared fuzzy_match_entity."""
    result = fuzzy_match_entity(query, list(entities), name_key=name_key)

    if result.exact_match and result.best_match:
        return {"auto_accepted_id": result.best_match.id}

    if (
        auto_accept_matches
        and result.best_match
        and result.best_match.confidence >= FUZZY_AUTO_ACCEPT_CONFIDENCE
    ):
        return {"auto_accepted_id": result.best_match.id}

    return {
        "matches": [
            {"name": s.name, "confidence": round(s.confidence * 100), "id": s.id}
            for s in result.suggestions[:MAX_FUZZY_SUGGESTIONS]
        ]
    }


def _format_suggestions(suggestions: list[dict[str, Any]]) -> str:
    """Format suggestions list for error message."""
    if not suggestions:
        return "none"
    return ", ".join(
        f"{s['name']} ({s['confidence']}%)" for s in suggestions[:MAX_DISPLAY_SUGGESTIONS]
    )


def _add_optional_fields(
    input_data: dict[str, Any],
    fields: list[tuple[str, Any]],
    check_truthy: bool = False,
) -> None:
    """Add optional fields to input dict if they have values."""
    for key, value in fields:
        if check_truthy:
            if value:
                input_data[key] = value
        elif value is not None:
            input_data[key] = value


def build_create_issue_input(
    team_id: str,
    title: str,
    description: str | None,
    assignee_id: str | None,
    label_ids: list[str] | None,
    priority_value: int | None,
    state_id: str | None,
    project_id: str | None,
    cycle_id: str | None,
    parent_id: str | None,
    estimate: int | None,
    due_date: str | None,
) -> dict[str, Any]:
    """Build the input dict for issue creation."""
    input_data: dict[str, Any] = {"teamId": team_id, "title": title}
    _add_optional_fields(
        input_data,
        [
            ("description", description),
            ("assigneeId", assignee_id),
            ("labelIds", label_ids),
            ("stateId", state_id),
            ("projectId", project_id),
            ("cycleId", cycle_id),
            ("parentId", parent_id),
            ("dueDate", due_date),
        ],
        check_truthy=True,
    )
    _add_optional_fields(input_data, [("priority", priority_value), ("estimate", estimate)])
    return input_data


def build_update_issue_input(
    title: str | None,
    description: str | None,
    assignee_id: str | None,
    label_ids: list[str] | None,
    priority_value: int | None,
    state_id: str | None,
    project_id: str | None,
    cycle_id: str | None,
    estimate: int | None,
    due_date: str | None,
) -> dict[str, Any]:
    """Build the input dict for issue update."""
    input_data: dict[str, Any] = {}
    _add_optional_fields(
        input_data,
        [
            ("title", title),
            ("description", description),
            ("assigneeId", assignee_id),
            ("labelIds", label_ids),
            ("priority", priority_value),
            ("stateId", state_id),
            ("projectId", project_id),
            ("cycleId", cycle_id),
            ("estimate", estimate),
            ("dueDate", due_date),
        ],
    )

    return input_data


def resolve_labels_for_update(
    current_label_ids: list[str],
    labels_to_add_ids: list[str] | None,
    labels_to_remove_ids: list[str] | None,
) -> list[str] | None:
    """Resolve labels for an update operation."""
    if not labels_to_add_ids and not labels_to_remove_ids:
        return None

    new_label_ids = set(current_label_ids)

    if labels_to_add_ids:
        new_label_ids.update(labels_to_add_ids)

    if labels_to_remove_ids:
        new_label_ids -= set(labels_to_remove_ids)

    return list(new_label_ids)


async def resolve_create_issue_entities(
    client: Any,
    validation_data: dict[str, Any],
    team_input: str,
    assignee: str | None,
    labels_to_add: list[str] | None,
    state: str | None,
    project: str | None,
    cycle: str | None,
    parent_issue: str | None,
    auto_accept_matches: bool,
) -> dict[str, Any]:
    """Resolve all entity references for issue creation."""
    teams = validation_data["teams"]
    all_labels = validation_data["labels"]
    all_projects = validation_data["projects"]

    team_id = validate_and_resolve_team(teams, team_input, auto_accept_matches)
    team_data: dict[str, Any] = next((t for t in teams if t["id"] == team_id), {})
    team_name = str(team_data.get("name") or team_input)
    members_conn = team_data.get("members", {})
    team_members = members_conn.get("nodes", []) if members_conn else []
    states_conn = team_data.get("states", {})
    team_states = states_conn.get("nodes", []) if states_conn else []
    cycles_conn = team_data.get("cycles", {})
    team_cycles = cycles_conn.get("nodes", []) if cycles_conn else []

    resolved: dict[str, Any] = {"team_id": team_id}

    if assignee:
        if assignee == "@me":
            viewer = await client.get_viewer()
            viewer_id = viewer.get("id")
            if viewer_id:
                resolved["assignee_id"] = str(viewer_id)
        else:
            resolved["assignee_id"] = validate_and_resolve_assignee(
                team_members, assignee, team_name, auto_accept_matches
            )

    if labels_to_add:
        resolved["label_ids"] = await resolve_label_ids(
            client, all_labels, labels_to_add, auto_accept_matches
        )

    if state:
        resolved["state_id"] = validate_and_resolve_state(
            team_states, state, team_name, auto_accept_matches
        )

    if project:
        resolved["project_id"] = await resolve_project_id(
            client, all_projects, project, auto_accept_matches
        )

    if cycle:
        resolved["cycle_id"] = await resolve_cycle_id(
            client, team_id, team_name, team_cycles, cycle, auto_accept_matches
        )

    if parent_issue:
        team_issues = await client.get_team_issues(team_id, first=MAX_PAGE_SIZE)
        resolved["parent_id"] = validate_and_resolve_parent_issue(
            team_issues, parent_issue, auto_accept_matches
        )

    return resolved


async def resolve_update_issue_entities(
    client: Any,
    validation_data: dict[str, Any],
    team_id: str,
    team_name: str,
    assignee: str | None,
    state: str | None,
    project: str | None,
    cycle: str | None,
    auto_accept_matches: bool,
) -> dict[str, Any]:
    """Resolve entity references for issue update."""
    teams = validation_data["teams"]
    all_labels = validation_data["labels"]
    all_projects = validation_data["projects"]

    current_team: dict[str, Any] = next((t for t in teams if t["id"] == team_id), {})
    members_conn = current_team.get("members", {})
    team_members = members_conn.get("nodes", []) if members_conn else []
    states_conn = current_team.get("states", {})
    team_states = states_conn.get("nodes", []) if states_conn else []
    cycles_conn = current_team.get("cycles", {})
    team_cycles = cycles_conn.get("nodes", []) if cycles_conn else []

    resolved: dict[str, Any] = {"all_labels": all_labels}

    if assignee is not None:
        resolved["assignee_id"] = validate_and_resolve_assignee(
            team_members, assignee, team_name, auto_accept_matches
        )

    if state is not None:
        resolved["state_id"] = validate_and_resolve_state(
            team_states, state, team_name, auto_accept_matches
        )

    if project is not None:
        resolved["project_id"] = await resolve_project_id(
            client, all_projects, project, auto_accept_matches
        )

    if cycle is not None:
        resolved["cycle_id"] = await resolve_cycle_id(
            client, team_id, team_name, team_cycles, cycle, auto_accept_matches
        )

    return resolved


async def resolve_issue(client: "LinearClient", issue_input: str) -> "IssueResponse":  # type: ignore[name-defined]  # noqa: F821
    """Resolve issue by ID or identifier and return issue data.

    Raises ToolExecutionError if issue is not found.
    """
    issue = await client.get_issue_by_id(issue_input)
    if not issue:
        raise ToolExecutionError(
            message=f"Issue '{issue_input}' not found",
            developer_message=f"No issue found with ID or identifier: {issue_input}",
        )
    return issue
