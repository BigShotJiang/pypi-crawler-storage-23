"""opendocs — Convert GitHub READMEs into multi-format documentation."""

__version__ = "0.5.1"
