"""Core modules for parsing and structuring README and notebook content."""
