"""DocAgent — agentic document generation from GitHub repositories."""

__version__ = "0.1.0"
