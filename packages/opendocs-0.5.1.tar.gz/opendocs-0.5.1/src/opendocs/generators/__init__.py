"""Document generators — convert DocumentModel → output files."""
