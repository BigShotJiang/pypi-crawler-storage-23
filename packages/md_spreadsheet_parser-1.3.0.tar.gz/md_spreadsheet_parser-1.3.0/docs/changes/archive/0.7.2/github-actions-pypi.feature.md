Add GitHub Actions workflows for PyPI and TestPyPI publishing.
