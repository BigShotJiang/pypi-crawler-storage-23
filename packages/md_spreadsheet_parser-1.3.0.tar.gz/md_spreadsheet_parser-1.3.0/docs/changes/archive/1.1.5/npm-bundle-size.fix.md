Reduced NPM package size by excluding redundant intermediate WASM files.
