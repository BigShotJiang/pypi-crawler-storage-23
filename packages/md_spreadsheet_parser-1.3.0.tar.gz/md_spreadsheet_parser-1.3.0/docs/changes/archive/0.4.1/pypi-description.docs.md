Update PyPI package description to highlight zero-dependency parsing and Excel conversion features.
