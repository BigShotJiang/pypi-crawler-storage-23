Ensure JSON output for CLI and metadata uses Unicode characters instead of escape sequences (e.g. Japanese).
