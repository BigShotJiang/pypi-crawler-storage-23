Update PyPI package keywords to improve discoverability for Excel-related and zero-dependency use cases.
