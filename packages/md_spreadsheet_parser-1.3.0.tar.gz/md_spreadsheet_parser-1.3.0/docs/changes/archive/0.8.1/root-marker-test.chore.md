### Tests

- Added robustness test `test_root_marker_robustness.py` to verify behavior when `# Tables` root marker is missing.
