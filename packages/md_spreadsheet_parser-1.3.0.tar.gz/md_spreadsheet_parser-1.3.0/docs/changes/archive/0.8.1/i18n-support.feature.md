# i18n support and Japanese documentation

Added Japanese translation for `README.md` and `COOKBOOK.md`.
Configured `mkdocs-static-i18n` to support bilingual documentation (English/Japanese).
Added language switcher with globe icon to the documentation site.
