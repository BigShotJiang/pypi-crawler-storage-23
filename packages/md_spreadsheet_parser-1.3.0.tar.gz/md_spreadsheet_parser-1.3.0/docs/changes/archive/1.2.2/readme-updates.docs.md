docs: Add PengSheets announcement and update NPM READMEs

- **Core**: Added PengSheets announcement to `README.md` and `README.ja.md`.
- **Core**: Fixed invalid `update_table_metadata` example in `README.md`.
- **NPM**: Added `packages/npm/README.ja.md` (Japanese translation).
- **NPM**: Updated logic parity claims and Excel limitations text.
