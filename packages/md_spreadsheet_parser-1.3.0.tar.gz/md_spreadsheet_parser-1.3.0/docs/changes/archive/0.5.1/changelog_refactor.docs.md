Refactored `CHANGELOG.md` to point to GitHub Releases and added the "Changelog" link to PyPI metadata in `pyproject.toml`.
