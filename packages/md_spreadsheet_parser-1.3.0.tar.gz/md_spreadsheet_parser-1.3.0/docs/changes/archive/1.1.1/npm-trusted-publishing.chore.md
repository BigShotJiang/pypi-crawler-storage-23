Update NPM publishing workflow to use Trusted Publishing (OIDC) instead of secret tokens.
