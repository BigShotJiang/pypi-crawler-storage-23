### Fixed Docs Links for PyPI

Updated `README.md` to use absolute GitHub URLs for the Cookbook and License. This ensures links work correctly when viewed on the PyPI project page (which does not host the relative files).
