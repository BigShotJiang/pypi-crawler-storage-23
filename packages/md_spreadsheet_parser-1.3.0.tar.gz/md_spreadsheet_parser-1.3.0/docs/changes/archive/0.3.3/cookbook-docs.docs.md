### Added Cookbook to Documentation

Integrated the new `COOKBOOK.md` into the MkDocs site navigation for better accessibility.
