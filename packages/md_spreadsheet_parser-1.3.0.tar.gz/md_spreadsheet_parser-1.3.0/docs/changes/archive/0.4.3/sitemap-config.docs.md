---
type: docs
---

Added `mkdocs-git-revision-date-localized-plugin` to generate accurate `lastmod` dates in `sitemap.xml` for better SEO and Google Search Console integration.
