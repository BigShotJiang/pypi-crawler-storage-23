Updated README.md to highlight suitability for AWS Lambda (Zero Dependency) and the "Markdown as Database" concept based on user feedback.
