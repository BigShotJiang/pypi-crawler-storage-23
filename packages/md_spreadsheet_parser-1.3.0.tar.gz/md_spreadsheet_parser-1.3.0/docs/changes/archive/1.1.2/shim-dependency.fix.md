Move `@bytecodealliance/preview2-shim` to `dependencies` to ensure it is available at runtime. This fixes `ERR_MODULE_NOT_FOUND` when using the package in a fresh environment.
