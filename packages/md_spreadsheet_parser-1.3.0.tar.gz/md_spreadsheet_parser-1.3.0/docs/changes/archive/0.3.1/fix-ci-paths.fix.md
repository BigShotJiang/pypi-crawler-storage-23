### Fix CI/CD Workflow

- **Fixed**: Corrected `paths` and `working-directory` configuration in GitHub Actions workflow to run properly in the `md-spreadsheet-parser` repository root.
