### CI/CD Implementation

- **Added**: GitHub Actions workflow (`.github/workflows/tests.yml`) to run unit tests (`pytest`) for `md-spreadsheet-parser` on push and pull request.
- **Added**: Build status badge to `md-spreadsheet-parser/README.md`.
