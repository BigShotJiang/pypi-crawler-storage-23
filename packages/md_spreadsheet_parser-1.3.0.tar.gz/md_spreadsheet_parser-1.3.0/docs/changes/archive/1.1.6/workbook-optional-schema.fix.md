Fixed `Workbook.to_markdown()` to accept an optional `schema` argument, defaulting to a standard `MultiTableParsingSchema`. This aligns the API with `Sheet.to_markdown()` and `Table.to_markdown()`.
