Remove outdated roadmap and features section from READMEs.
