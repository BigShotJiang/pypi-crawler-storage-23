---
type: docs
---

**Documentation**: Added announcement for the official VS Code Extension **PengSheets** release.
