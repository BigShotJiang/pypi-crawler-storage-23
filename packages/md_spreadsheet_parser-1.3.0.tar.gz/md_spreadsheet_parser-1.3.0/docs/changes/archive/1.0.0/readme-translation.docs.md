Complete README.ja.md translation and update metadata tag example in README.md.
