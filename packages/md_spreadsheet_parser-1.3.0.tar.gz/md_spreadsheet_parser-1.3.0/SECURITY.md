# Security Policy

## Reporting a Vulnerability

Please report security issues via GitHub Security Advisories.

Please do not disclose security issues publicly before a fix is available.
