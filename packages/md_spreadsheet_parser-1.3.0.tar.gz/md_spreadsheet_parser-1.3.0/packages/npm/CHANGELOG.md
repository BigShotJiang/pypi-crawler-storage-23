# Changelog

For the complete list of releases and changes, please see the [GitHub Releases](https://github.com/f-y/md-spreadsheet-parser/releases) page.
