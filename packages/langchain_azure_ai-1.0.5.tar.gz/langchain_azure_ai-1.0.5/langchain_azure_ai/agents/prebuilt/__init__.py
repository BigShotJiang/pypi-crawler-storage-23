"""Prebuilt agents for Azure AI Foundry."""

from langchain_azure_ai.agents.prebuilt.declarative import PromptBasedAgentNode

__all__ = ["PromptBasedAgentNode"]
