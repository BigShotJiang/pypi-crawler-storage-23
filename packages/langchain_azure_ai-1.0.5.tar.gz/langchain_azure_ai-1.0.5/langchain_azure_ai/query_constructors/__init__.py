"""This module defines the query constructors for the Azure AI integrations."""
