#!/usr/bin/env python3
"""
PreToolUse Compliance Gate - Blocks tool execution until requirements met.

Fires BEFORE tool execution to check if pending compliance requirements
would be violated. This is the enforcement layer that "traps" the LLM
until compliance is demonstrated.

Architecture:
    LLM requests tool → PreToolUse Hook → This Script →
        [Check Pending Requirements] → [Evaluate Blocking Rules] →
        [ALLOW or DENY with message] → Claude receives result

Usage:
    Configured in .claude/settings.local.json as PreToolUse hook:
    {
      "hooks": {
        "PreToolUse": [{
          "matcher": "mcp__github__close_issue",
          "hooks": [{"type": "command", "command": "/path/to/pretooluse_compliance_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - tool_name: Name of the tool being called
    - tool_input: Parameters being passed to the tool
    - transcript_path: Path to conversation JSONL file
    - hook_event_name: "PreToolUse"

Output:
    - If ALLOWED: Silent exit (no output), exit code 0
    - If BLOCKED: JSON {"permissionDecision": "deny", "message": "..."} to stdout

Exit Codes:
    0: Success (tool allowed or blocked with message)
    1: Error (logged, tool allowed by default for safety)

Epic #545: Hook-Based Compliance Enforcement
Task #549: PreToolUse Enforcement Gate
"""

import json
import logging
import sqlite3
import sys
import time
from pathlib import Path

# Ensure mcp_server package is importable when run as standalone hook script.
# Hooks are invoked directly by Claude Code, so src/ must be on sys.path.
_src_path = str(Path(__file__).parent.parent.parent)
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

from mcp_server.database.connection import get_connection

# Configure logging to file (not stdout - stdout is for denial messages)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory, worktree-aware."""
    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        import os

        project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Ensure log directory exists and configure dual logging. Called lazily on first use."""
    global _log_initialized
    if _log_initialized:
        return

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        log_dir = _get_log_dir()
        setup_dual_logging(
            log_dir=log_dir,
            hook_name="pretooluse-compliance",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        # Fallback: text-only logging if logging_utils unavailable
        log_dir = _get_log_dir()
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=log_dir / "pretooluse-compliance.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
        except (PermissionError, OSError):
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
    _log_initialized = True


def detect_intent(
    db_path: Path, tool_name: str, tool_input: dict | None = None
) -> tuple[bool, str | None]:
    """Detect the intent of a tool usage via the tool_usage_patterns table.

    Queries the data-driven intent registry to determine if a tool call
    represents a dangerous action (e.g., closing an issue, creating a PR,
    bare pip usage).

    Epic #565: Replaces hardcoded BASH_*_PATTERNS and TOOL_ENFORCEMENT_RULES
    with a queryable, extensible data source.

    Args:
        db_path: Path to the Pongogo database
        tool_name: Name of the tool being called
        tool_input: Tool input parameters (used for Bash command inspection)

    Returns:
        Tuple of (has_patterns, intent):
        - (True, "exempt") → matches exempt pattern, skip enforcement
        - (True, "closure") → dangerous intent detected (e.g., closure, commencement)
        - (True, "unsafe_pip") → unsafe pip intent detected
        - (True, None) → patterns exist for tool but none matched (safe usage)
        - (False, None) → no patterns registered for this tool
    """
    try:
        with get_connection(db_path, readonly=True) as conn:
            patterns = conn.execute(
                """SELECT intent, match_type, pattern, exempt
                FROM tool_usage_patterns
                WHERE tool_name = ? AND enabled = 1
                ORDER BY exempt DESC""",
                (tool_name,),
            ).fetchall()
    except sqlite3.OperationalError:
        # Table doesn't exist (old database) or other DB error → fail-open
        return (False, None)

    if not patterns:
        return (False, None)

    command = ""
    if tool_input:
        command = tool_input.get("command", "")

    for p in patterns:
        matched = False
        match_type = p["match_type"]
        pattern = p["pattern"]

        if (
            match_type == "always"
            or match_type == "contains"
            and pattern
            and pattern in command
            or match_type == "exact"
            and pattern == command
        ):
            matched = True

        if matched:
            if p["exempt"]:
                logger.debug(
                    f"Exempt pattern matched: {pattern} (intent: {p['intent']})"
                )
                return (True, "exempt")
            logger.info(
                f"Intent detected: {p['intent']} "
                f"(tool={tool_name}, pattern={pattern})"
            )
            return (True, p["intent"])

    # Patterns exist for this tool but none matched
    return (True, None)


def get_db_path() -> Path | None:
    """Find the Pongogo database path.

    Search order:
    1. get_data_root() — worktree-aware (resolves to main worktree in linked worktrees)
    2. User home directory fallback
    """
    from mcp_server.database.context import get_data_root

    # Worktree-aware data root (handles PONGOGO_PROJECT_ROOT, linked worktrees, cwd)
    data_root = get_data_root()
    data_db = data_root / ".pongogo" / "pongogo.db"
    if data_db.exists():
        return data_db

    # Fall back to user-level
    user_db = Path.home() / ".pongogo" / "pongogo.db"
    if user_db.exists():
        return user_db

    return None


def get_pending_requirements(
    db_path: Path, session_id: str, branch: str | None = None
) -> list[dict]:
    """Query guidance_fulfillment for pending requirements in this session.

    Returns requirements with status: pending, in_progress, or carried_forward.
    Includes blocked_tools and enforcement_scope for declarative enforcement (Epic #565).

    Branch filtering (Task #640): When branch is provided, returns only rows
    matching the current branch OR rows with NULL branch (pre-Wave-2 backward
    compat). This prevents cross-branch compliance pollution.

    Scope behavior:
    - session: Requirement stays fulfilled for the entire session (default)
    - action: Requirement must be re-fulfilled for each blocked action (stricter)

    Note: action scope is stricter - even 'fulfilled' requirements with action
    scope should be re-verified if the fulfillment is stale. Current implementation
    treats action scope same as session scope; full action scope enforcement
    would require tracking when fulfillment occurred relative to tool calls.
    """
    try:
        with get_connection(db_path, readonly=True) as conn:
            cursor = conn.execute(
                """
                SELECT id, guidance_type, guidance_content, action_type,
                       blocked_tools, enforcement_scope, fulfillment_status,
                       session_id, enforcement_phase, pattern
                FROM guidance_fulfillment
                WHERE session_id = ?
                AND (branch = ? OR branch IS NULL)
                AND fulfillment_status IN ('pending', 'in_progress', 'carried_forward')
                ORDER BY created_at ASC
                """,
                (session_id, branch),
            )
            return [dict(row) for row in cursor.fetchall()]
    except sqlite3.Error as e:
        logger.error(f"Database error querying pending requirements: {e}")
        return []


def _get_blocked_tools_from_requirement(req: dict) -> list[str]:
    """Extract blocked tools from a requirement's declarative spec.

    Epic #565: Requirements declare their own blocked_tools, which may
    contain semantic categories (e.g., "mutating") that get resolved to
    platform-specific tool names via the registry.

    Requirements without blocked_tools (NULL) return empty list — they
    don't participate in category-based blocking. Intent-based blocking
    via tool_usage_patterns handles enforcement for these requirements.

    Args:
        req: Requirement dict with optional 'blocked_tools' JSON field

    Returns:
        List of resolved platform-specific tool names
    """
    from mcp_server.compliance.models import resolve_blocked_tools

    blocked_tools_json = req.get("blocked_tools")

    if blocked_tools_json:
        # Declarative: requirement specifies its own blocked tools
        try:
            raw_tools = json.loads(blocked_tools_json)
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"Invalid blocked_tools JSON: {blocked_tools_json}")
            return []
        # Resolve categories (e.g., "mutating" → ["Edit", "Write", "Bash"])
        return resolve_blocked_tools(raw_tools)

    return []


def check_compliance(
    session_id: str,
    tool_name: str,
    tool_input: dict | None = None,
    db_path: Path | None = None,
    branch: str | None = None,
) -> dict | None:
    """Check if pending requirements block this tool execution.

    Uses a two-step blocking approach (Epic #565):

    1. Intent-based blocking: Query tool_usage_patterns to detect if this
       tool is being used in a dangerous way (e.g., closing an issue, creating
       a PR). If dangerous intent detected + pending requirements → block.

    2. Category-based blocking: Check each requirement's blocked_tools for
       semantic categories (e.g., "mutating" → ["Edit", "Write", "Bash"]).
       If tool matches a category → block.

    Args:
        session_id: Current session identifier
        tool_name: Name of the tool being called
        tool_input: Tool input parameters (used for Bash command inspection)
        db_path: Optional explicit database path (for testing)
        branch: Git branch name for cross-branch isolation (Task #640)

    Returns:
        None if tool is allowed (no blocking requirements)
        Dict with permissionDecision and message if blocked
    """
    # Get DB path if not provided
    if db_path is None:
        db_path = get_db_path()

    if db_path is None:
        logger.debug("No database found, allowing tool execution")
        return None  # No database = no enforcement

    # Step 1: Detect intent via tool_usage_patterns
    has_patterns, intent = detect_intent(db_path, tool_name, tool_input)

    # Task #653: Closure detection override for mcp__github__update_issue(state=closed)
    # The tool_usage_patterns table marks update_issue as "exempt" (Bug #656),
    # but closing via state=closed must still be enforced.
    if (
        intent == "exempt"
        and tool_name == "mcp__github__update_issue"
        and tool_input
        and tool_input.get("state") == "closed"
    ):
        intent = "closure_via_update"
        logger.info(
            "Closure override: mcp__github__update_issue(state=closed) "
            "re-classified as closure_via_update"
        )

    if intent == "exempt":
        logger.debug(f"Tool {tool_name} matches exempt pattern, bypassing enforcement")
        return None  # Explicitly exempt from enforcement

    if has_patterns and intent is None:
        # Patterns exist for this tool but none matched → safe usage
        logger.debug(f"Tool {tool_name} has patterns but none matched, allowing")
        return None

    # Step 2: Get pending requirements for this session (branch-filtered)
    pending = get_pending_requirements(db_path, session_id, branch=branch)
    if not pending:
        logger.debug(f"No pending requirements for session {session_id}, allowing")
        return None  # No pending requirements

    # Task #653: Split requirements by enforcement phase
    blocked_until_reqs = [
        req
        for req in pending
        if (req.get("enforcement_phase") or "blocked_until") == "blocked_until"
    ]
    closure_reqs = [
        req
        for req in pending
        if req.get("enforcement_phase") == "required_before_closure"
    ]

    is_closure_intent = intent in ("closure", "closure_via_update", "commit_closure")

    # Step 3: Determine which requirements block this tool
    blocking_requirements = []

    if is_closure_intent:
        # Closure intent → blocked by ALL pending requirements (both phases)
        blocking_requirements = list(pending)
        logger.info(
            f"Closure intent '{intent}' detected for {tool_name}, "
            f"all {len(pending)} pending requirements apply "
            f"(blocked_until={len(blocked_until_reqs)}, "
            f"closure={len(closure_reqs)})"
        )
    elif intent is not None:
        # Other dangerous intent → only blocked by blocked_until requirements
        blocking_requirements = list(blocked_until_reqs)
        logger.info(
            f"Intent '{intent}' detected for {tool_name}, "
            f"{len(blocked_until_reqs)} blocked_until requirements apply"
        )
    else:
        # No intent detected (no patterns for this tool) →
        # check category-based blocking from blocked_until requirements only
        for req in blocked_until_reqs:
            blocked_tools = _get_blocked_tools_from_requirement(req)
            if tool_name in blocked_tools:
                blocking_requirements.append(req)

    if not blocking_requirements:
        logger.debug(f"No requirements blocking {tool_name}, allowing")
        return None  # No blocking requirements for this specific tool

    # Build the denial message
    requirements_list = "\n".join(
        [
            f"  - [{req['action_type']}] {req['guidance_content'][:100]}"
            for req in blocking_requirements
        ]
    )

    if is_closure_intent and closure_reqs:
        closure_note = "\n\nClosure-required steps still pending:\n" + "\n".join(
            f"  - {req['guidance_content'][:100]}" for req in closure_reqs
        )
    else:
        closure_note = ""

    denial_message = f"""COMPLIANCE GATE: Cannot execute {tool_name}

You must complete these requirements first:
{requirements_list}{closure_note}

To proceed:
1. Read the required instruction file(s) using the Read tool
2. Follow the documented procedures
3. Then retry this action

This enforcement ensures procedural compliance with documented standards."""

    logger.info(
        f"BLOCKING {tool_name}: {len(blocking_requirements)} unmet requirements "
        f"for session {session_id}"
    )

    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": denial_message,
        }
    }


def check_path_enforcement(
    session_id: str,
    tool_name: str,
    tool_input: dict,
    db_path: Path | None = None,
    branch: str | None = None,
) -> dict | None:
    """Check if a Write/Edit targets a path requiring procedural compliance.

    Issue #682: Path-based enforcement. When Write/Edit targets a file matching
    a procedural instruction's applies_to pattern, block until the instruction
    is read.

    Args:
        session_id: Current session identifier.
        tool_name: Must be "Write" or "Edit".
        tool_input: Tool input dict (must contain "file_path").
        db_path: Optional explicit database path (for testing).
        branch: Git branch for cross-branch isolation.

    Returns:
        None if allowed, denial dict if blocked.
    """
    if tool_name not in ("Write", "Edit"):
        return None

    file_path = tool_input.get("file_path", "")
    if not file_path:
        return None

    # Get DB path if not provided
    if db_path is None:
        db_path = get_db_path()
    if db_path is None:
        return None

    # Load path enforcement index
    from mcp_server.compliance.path_index import build_index, load_index, write_index

    # Find .pongogo directory
    from mcp_server.database.context import get_data_root

    data_root = get_data_root()
    pongogo_dir = data_root / ".pongogo"

    index = load_index(pongogo_dir)
    if index is None:
        # Lazy rebuild if missing
        instructions_dir = pongogo_dir / "instructions"
        if instructions_dir.is_dir():
            index = build_index(instructions_dir)
            try:
                write_index(pongogo_dir, index)
            except Exception as e:
                logger.warning(f"Could not write path enforcement index: {e}")
        else:
            return None

    if not index or not index.get("entries"):
        return None

    # Match file_path against index entries
    from mcp_server.hooks.path_utils import glob_match

    matching_entries = []
    for entry in index["entries"]:
        if tool_name not in entry.get(
            "blocked_tools", []
        ) and "mutating" not in entry.get("blocked_tools", []):
            continue
        for pattern in entry.get("patterns", []):
            if glob_match(file_path, pattern):
                matching_entries.append(entry)
                break

    if not matching_entries:
        return None

    # Check fulfillment state for each matching instruction
    blocking_instructions = []
    try:
        with get_connection(db_path, readonly=True) as conn:
            for entry in matching_entries:
                instruction_path = entry["instruction_path"]
                instruction_id = entry["instruction_id"]

                # Check if a fulfillment row already exists for this instruction
                row = conn.execute(
                    """
                    SELECT id, fulfillment_status FROM guidance_fulfillment
                    WHERE session_id = ?
                    AND (branch = ? OR branch IS NULL)
                    AND action_type = 'read_file'
                    AND pattern = ?
                    ORDER BY created_at DESC LIMIT 1
                    """,
                    (session_id, branch, instruction_path),
                ).fetchone()

                if row:
                    status = row["fulfillment_status"]
                    if status == "fulfilled":
                        # Already read — allow
                        logger.debug(
                            f"Path enforcement: {instruction_id} already fulfilled "
                            f"for {file_path}"
                        )
                        continue
                    else:
                        # Pending/in_progress — block (already registered)
                        blocking_instructions.append(entry)
                        logger.info(
                            f"Path enforcement: {instruction_id} pending "
                            f"(status={status}) for {file_path}"
                        )
                else:
                    # No row — register new requirement + block
                    blocking_instructions.append(entry)
                    logger.info(
                        f"Path enforcement: registering {instruction_id} "
                        f"requirement for {file_path}"
                    )

        # Insert new requirements outside the read transaction
        if blocking_instructions:
            with get_connection(db_path) as conn:
                for entry in blocking_instructions:
                    instruction_path = entry["instruction_path"]
                    # Dedup: only insert if no row exists yet
                    existing = conn.execute(
                        """
                        SELECT id FROM guidance_fulfillment
                        WHERE session_id = ?
                        AND (branch = ? OR branch IS NULL)
                        AND action_type = 'read_file'
                        AND pattern = ?
                        """,
                        (session_id, branch, instruction_path),
                    ).fetchone()
                    if not existing:
                        conn.execute(
                            """
                            INSERT INTO guidance_fulfillment (
                                guidance_type, guidance_content, action_type,
                                fulfillment_status, session_id, branch,
                                enforcement_phase, pattern
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                "procedural",
                                f"Read {instruction_path} before writing to matched path",
                                "read_file",
                                "pending",
                                session_id,
                                branch,
                                "blocked_until",
                                instruction_path,
                            ),
                        )
                        logger.info(
                            f"Path enforcement: inserted read_file requirement "
                            f"for {entry['instruction_id']}"
                        )

    except sqlite3.Error as e:
        logger.error(f"Path enforcement database error: {e}")
        return None  # Fail-open

    if not blocking_instructions:
        return None

    # Build denial message
    instructions_list = "\n".join(
        f"  - Read {e['instruction_path']}" for e in blocking_instructions
    )

    denial_message = f"""PATH ENFORCEMENT: Cannot {tool_name} to {Path(file_path).name}

This file matches a procedural instruction's applies_to pattern.
You must read these instruction files first:
{instructions_list}

To proceed:
1. Use the Read tool on each instruction file listed above
2. Follow the documented procedures
3. Then retry this {tool_name} operation"""

    logger.info(
        f"PATH ENFORCEMENT BLOCKED: {tool_name} → {file_path}, "
        f"{len(blocking_instructions)} instructions required"
    )

    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": denial_message,
        }
    }


def load_state_file() -> dict:
    """Load Pongogo state from .pongogo-mcp-state.json."""
    state_file = Path.cwd() / ".pongogo-mcp-state.json"

    # Search parent directories if not found
    if not state_file.exists():
        for parent in Path.cwd().parents:
            candidate = parent / ".pongogo-mcp-state.json"
            if candidate.exists():
                state_file = candidate
                break

    if not state_file.exists():
        return {}

    try:
        with open(state_file) as f:
            return json.load(f)
    except Exception:
        return {}


def main():
    """Main entry point for PreToolUse hook."""
    start_time = time.time()

    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        _ensure_log_dir()
        logger.error("Failed to read JSON from stdin")
        sys.exit(0)  # Allow tool on input error (fail-open for safety)

    session_id = input_data.get("session_id", "")
    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # Detect branch for cross-branch isolation (Task #640)
    from mcp_server.database.context import get_current_branch

    branch = get_current_branch()

    # Initialize dual logging with session context
    _ensure_log_dir(session_id=session_id, branch=branch or "")

    logger.debug(f"PreToolUse check: tool={tool_name}, session={session_id[:16]}...")

    # Check if Pongogo is disabled
    state = load_state_file()
    mode = state.get("mode", "enabled")
    if mode == "disabled":
        logger.debug("Pongogo disabled, allowing tool execution")
        sys.exit(0)

    # Check path-based enforcement for Write/Edit (Issue #682)
    if tool_name in ("Write", "Edit"):
        path_result = check_path_enforcement(
            session_id, tool_name, tool_input, branch=branch
        )
        if path_result:
            elapsed_ms = (time.time() - start_time) * 1000
            logger.info(
                f"PreToolUse PATH BLOCKED: tool={tool_name}, "
                f"session={session_id[:16]}, latency={elapsed_ms:.1f}ms"
            )
            print(json.dumps(path_result))
            sys.exit(0)

    # Check compliance
    result = check_compliance(session_id, tool_name, tool_input, branch=branch)

    elapsed_ms = (time.time() - start_time) * 1000

    if result:
        # BLOCK: Output denial JSON to stdout
        logger.info(
            f"PreToolUse BLOCKED: tool={tool_name}, session={session_id[:16]}, "
            f"latency={elapsed_ms:.1f}ms"
        )
        print(json.dumps(result))
        sys.exit(0)
    else:
        # ALLOW: Silent exit
        logger.debug(
            f"PreToolUse ALLOWED: tool={tool_name}, session={session_id[:16]}, "
            f"latency={elapsed_ms:.1f}ms"
        )
        sys.exit(0)


if __name__ == "__main__":
    main()
