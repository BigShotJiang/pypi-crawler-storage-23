"""Shared path-matching utilities for compliance hooks.

Extracted from posttooluse_compliance_hook.py (Issue #682) so both
PreToolUse (path enforcement) and PostToolUse (fulfillment tracking)
can share the same glob-matching logic.
"""

import fnmatch
from pathlib import Path


def glob_match(file_path: str, pattern: str) -> bool:
    """Check if a file path matches a glob pattern.

    Handles absolute paths by matching the pattern against the path suffix.
    For example, pattern "wiki/Work-Log-*.md" matches
    "/Users/max/Development/pongogo/wiki/Work-Log-2026-02.md".

    Args:
        file_path: Absolute or relative file path to check.
        pattern: Glob pattern to match against.

    Returns:
        True if the path matches the pattern.
    """
    if not file_path or not pattern:
        return False

    # Direct match
    if fnmatch.fnmatch(file_path, pattern):
        return True

    # Suffix match: try matching the end of the absolute path against the pattern
    # This handles absolute vs relative path differences
    path_parts = Path(file_path).parts
    pattern_parts = Path(pattern).parts
    if len(pattern_parts) <= len(path_parts):
        suffix = str(Path(*path_parts[-len(pattern_parts) :]))
        if fnmatch.fnmatch(suffix, pattern):
            return True

    return False
