"""Path-based enforcement index for procedural instructions.

Issue #682: When a Write/Edit targets a file matching a procedural
instruction's applies_to pattern, the agent must read that instruction
first. This module builds and manages the index that maps file-path
patterns to their owning instructions.

Only *path-specific* patterns are indexed. Universal patterns like
``**/*.md`` or ``**/*`` are excluded because they would block every
write operation — those rely on keyword routing instead.
"""

from __future__ import annotations

import json
import logging
import tempfile
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

# Index schema version — bump when format changes
_INDEX_VERSION = 1
_INDEX_FILENAME = "path_enforcement_index.json"


def _is_path_specific(pattern: str) -> bool:
    """Return True if a pattern targets specific paths (not universal).

    Universal patterns have a first component of ``**`` or start with
    ``status_change:``. These would match too broadly and are handled
    by keyword routing instead.

    Examples:
        >>> _is_path_specific("wiki/Work-Log*.md")
        True
        >>> _is_path_specific(".pongogo/instructions/**/*.instructions.md")
        True
        >>> _is_path_specific("**/*.md")
        False
        >>> _is_path_specific("**/*")
        False
        >>> _is_path_specific("status_change:closed")
        False
    """
    if not pattern:
        return False
    if pattern.startswith("status_change:"):
        return False
    first_component = Path(pattern).parts[0] if Path(pattern).parts else ""
    return first_component != "**"


def build_index(instructions_dir: Path) -> dict:
    """Scan instruction files for procedural enforcement with path-specific patterns.

    Args:
        instructions_dir: Path to ``.pongogo/instructions/`` directory.

    Returns:
        Index dict with ``version`` and ``entries`` keys.
    """
    entries: list[dict] = []

    if not instructions_dir.is_dir():
        logger.warning(f"Instructions directory not found: {instructions_dir}")
        return {"version": _INDEX_VERSION, "entries": entries}

    for md_file in sorted(instructions_dir.rglob("*.instructions.md")):
        entry = _parse_instruction(md_file, instructions_dir)
        if entry:
            entries.append(entry)

    logger.info(
        f"Path enforcement index built: {len(entries)} entries "
        f"from {instructions_dir}"
    )
    return {"version": _INDEX_VERSION, "entries": entries}


def _parse_instruction(md_file: Path, instructions_dir: Path) -> dict | None:
    """Parse a single instruction file for path enforcement metadata.

    Returns an index entry dict if the file has procedural enforcement
    with path-specific applies_to patterns, None otherwise.
    """
    try:
        text = md_file.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    # Extract YAML frontmatter
    if not text.startswith("---"):
        return None
    end_idx = text.find("---", 3)
    if end_idx == -1:
        return None

    try:
        frontmatter = yaml.safe_load(text[3:end_idx])
    except yaml.YAMLError:
        return None

    if not isinstance(frontmatter, dict):
        return None

    # Must have enforcement block (procedural: true is common but not strictly
    # required — instruction_file_creation has enforcement without procedural: true)
    enforcement = frontmatter.get("enforcement")
    if not enforcement or not isinstance(enforcement, dict):
        return None

    # Must have blocked_until (otherwise nothing to enforce)
    if not enforcement.get("blocked_until"):
        return None

    applies_to = frontmatter.get("applies_to", [])
    if not isinstance(applies_to, list):
        return None

    # Filter to path-specific patterns only
    specific_patterns = [
        p for p in applies_to if isinstance(p, str) and _is_path_specific(p)
    ]
    if not specific_patterns:
        return None

    # Extract blocked_tools from enforcement
    blocked_tools = enforcement.get("blocked_tools", ["Edit", "Write", "Bash"])
    if not isinstance(blocked_tools, list):
        blocked_tools = ["Edit", "Write", "Bash"]

    # Derive instruction_id from filename
    instruction_id = md_file.stem.replace(".instructions", "")

    # Build relative path from .pongogo root (one level up from instructions_dir)
    pongogo_dir = instructions_dir.parent
    try:
        rel_path = str(md_file.relative_to(pongogo_dir.parent))
    except ValueError:
        rel_path = str(md_file)

    return {
        "instruction_id": instruction_id,
        "instruction_path": rel_path,
        "patterns": specific_patterns,
        "blocked_tools": blocked_tools,
    }


def write_index(pongogo_dir: Path, index: dict) -> Path:
    """Write the path enforcement index to disk atomically.

    Args:
        pongogo_dir: Path to ``.pongogo/`` directory.
        index: Index dict from ``build_index()``.

    Returns:
        Path to the written index file.
    """
    index_path = pongogo_dir / _INDEX_FILENAME
    pongogo_dir.mkdir(parents=True, exist_ok=True)

    # Atomic write
    tmp = tempfile.NamedTemporaryFile(  # noqa: SIM115
        mode="w", dir=pongogo_dir, suffix=".json", delete=False
    )
    try:
        json.dump(index, tmp, indent=2)
        tmp.write("\n")
        tmp.close()
        Path(tmp.name).replace(index_path)
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise

    logger.info(
        f"Path enforcement index written: {len(index.get('entries', []))} entries "
        f"→ {index_path}"
    )
    return index_path


def load_index(pongogo_dir: Path) -> dict | None:
    """Load the path enforcement index from disk.

    Args:
        pongogo_dir: Path to ``.pongogo/`` directory.

    Returns:
        Index dict, or None if not found or invalid.
    """
    index_path = pongogo_dir / _INDEX_FILENAME
    if not index_path.exists():
        return None

    try:
        with open(index_path) as f:
            data = json.load(f)
        if isinstance(data, dict) and "entries" in data:
            return data
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load path enforcement index: {e}")

    return None
