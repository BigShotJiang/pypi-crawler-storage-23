"""Common Bybit REST endpoints (available for both spot and futures)."""

__all__: list[str] = []
