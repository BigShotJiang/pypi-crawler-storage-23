"""Futures-only Bybit REST endpoints."""

__all__: list[str] = []
