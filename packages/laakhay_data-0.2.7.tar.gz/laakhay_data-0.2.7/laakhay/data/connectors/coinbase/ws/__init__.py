"""Coinbase WebSocket connector package."""
