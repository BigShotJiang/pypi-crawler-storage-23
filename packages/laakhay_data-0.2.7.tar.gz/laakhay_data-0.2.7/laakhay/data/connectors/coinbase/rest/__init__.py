"""Coinbase REST connector package."""
