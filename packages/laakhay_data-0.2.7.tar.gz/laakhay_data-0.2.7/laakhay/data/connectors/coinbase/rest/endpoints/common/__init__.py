"""Coinbase common REST endpoints."""
