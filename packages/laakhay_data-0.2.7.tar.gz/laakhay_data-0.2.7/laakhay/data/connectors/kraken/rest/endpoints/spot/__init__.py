"""Spot-specific Kraken REST endpoints."""
