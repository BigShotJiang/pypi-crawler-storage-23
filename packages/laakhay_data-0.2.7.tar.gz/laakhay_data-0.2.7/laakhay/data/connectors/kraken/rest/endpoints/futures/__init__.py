"""Futures-specific Kraken REST endpoints."""
