"""Common Kraken REST endpoints (available for both spot and futures)."""
