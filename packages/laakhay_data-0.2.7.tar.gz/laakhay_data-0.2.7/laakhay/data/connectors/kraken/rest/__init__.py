"""Kraken REST connector package."""
