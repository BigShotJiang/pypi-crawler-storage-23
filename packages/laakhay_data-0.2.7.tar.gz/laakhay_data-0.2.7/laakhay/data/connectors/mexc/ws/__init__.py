"""MEXC WebSocket connector."""

from laakhay.data.connectors.mexc.ws.provider import MEXCWSConnector

__all__ = ["MEXCWSConnector"]
