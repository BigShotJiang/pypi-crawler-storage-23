"""MEXC REST connector."""

from laakhay.data.connectors.mexc.rest.provider import MEXCRESTConnector

__all__ = ["MEXCRESTConnector"]
