"""Common MEXC REST endpoints."""

__all__: list[str] = []
