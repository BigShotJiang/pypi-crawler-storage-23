"""Futures-specific MEXC REST endpoints."""

__all__: list[str] = []
