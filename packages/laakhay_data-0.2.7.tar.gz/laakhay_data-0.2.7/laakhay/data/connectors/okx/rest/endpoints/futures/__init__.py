"""Futures-specific endpoints."""

__all__: list[str] = []
