"""Abstract base class for REST (HTTP) data providers.

This module defines the minimal REST surface used across the data layer.
It is intentionally decoupled from any WebSocket/streaming concepts.

Architecture:
    This module provides the RESTProvider abstract base class that all REST-based
    data providers must implement. It defines a clean interface for synchronous
    data fetching operations (OHLCV, order books, trades, etc.).

Design Decisions:
    - Pure REST interface: No streaming concepts, only request/response
    - Optional methods: Some methods are optional (order_book, trades, etc.)
    - Abstract base class: Enforces consistent interface across providers
    - Async methods: All operations are async for non-blocking I/O

See Also:
    - WSProvider: WebSocket/streaming interface
    - RESTTransport: HTTP transport abstraction
    - Provider implementations: Exchange-specific REST providers
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from ...core.enums import Timeframe
from ...models import OHLCV, FundingRate, OpenInterest, OrderBook, Symbol, Trade


class RESTProvider(ABC):
    """Pure REST interface for market data providers."""

    async def fetch_health(self) -> dict[str, object]:
        """Fetch health of the provider."""
        raise NotImplementedError("fetch_health not implemented for this provider")

    @abstractmethod
    async def fetch_ohlcv(
        self,
        symbol: str,
        interval: Timeframe,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int | None = None,
    ) -> OHLCV:
        """Fetch OHLCV bars for a symbol and timeframe."""
        raise NotImplementedError

    @abstractmethod
    async def get_symbols(
        self, quote_asset: str | None = None, use_cache: bool = True
    ) -> list[Symbol]:
        """List trading symbols, optionally filtered by quote asset."""
        raise NotImplementedError

    # Optional but commonly supported REST endpoints
    async def get_order_book(self, symbol: str, limit: int = 100) -> OrderBook:  # pragma: no cover
        """Fetch current order book. Optional; implement if provider supports it."""
        raise NotImplementedError

    async def get_recent_trades(
        self, symbol: str, limit: int = 500
    ) -> list[Trade]:  # pragma: no cover
        """Fetch recent trades. Optional; implement if provider supports it."""
        raise NotImplementedError

    async def fetch_historical_trades(
        self,
        symbol: str,
        *,
        limit: int | None = None,
        from_id: int | None = None,
    ) -> list[Trade]:  # pragma: no cover
        """Fetch historical trades if provider supports it."""
        raise NotImplementedError

    async def get_funding_rate(
        self,
        symbol: str,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
    ) -> list[FundingRate]:  # pragma: no cover
        """Fetch historical applied funding rates. Futures-only providers typically implement this."""
        raise NotImplementedError

    async def get_open_interest(
        self,
        symbol: str,
        historical: bool = False,
        period: str = "5m",
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 30,
    ) -> list[OpenInterest]:  # pragma: no cover
        """Fetch open interest (current or historical). Futures-only providers typically implement this."""
        raise NotImplementedError

    @abstractmethod
    async def close(self) -> None:
        """Close any underlying HTTP resources/sessions."""
        raise NotImplementedError
