"""
Dictionary update module for PyPLogo
Automatically checks and updates DSSP dictionary files from wwPDB
"""

import os
import re
import json
import warnings
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Dict, Tuple
from datetime import datetime
import urllib.request
import urllib.error
import ssl

DICT_FILES = {
    'mmcif_pdbx.dic': {
        'url': 'https://mmcif.wwpdb.org/dictionaries/ascii/mmcif_pdbx.dic',
        'version_pattern': r'_dictionary\.version\s+(\S+)'
    },
    'mmcif_ma.dic': {
        'url': 'https://mmcif.wwpdb.org/dictionaries/ascii/mmcif_ma.dic',
        'version_pattern': r'_dictionary\.version\s+(\S+)'
    },
    'components.cif': {
        'url': 'https://files.wwpdb.org/pub/pdb/data/monomers/components.cif',
        'version_pattern': None
    }
}

VERSION_FILE = 'dict_versions.json'
TIMEOUT_SECONDS = 30
MAX_RETRIES = 2


def get_dict_dir() -> Path:
    """Get the dictionary directory path, preferring user data directory"""
    base_dir = Path(__file__).parent
    
    user_data_dir = Path.home() / '.pyplogo' / 'dssp_dicts'
    
    if not user_data_dir.exists():
        try:
            user_data_dir.mkdir(parents=True, exist_ok=True)
        except (OSError, PermissionError):
            return base_dir
    
    return user_data_dir


def get_local_version(dict_dir: Path, filename: str) -> Optional[str]:
    """Get the version of a local dictionary file"""
    filepath = dict_dir / filename
    if not filepath.exists():
        return None
    
    config = DICT_FILES.get(filename, {})
    version_pattern = config.get('version_pattern')
    
    if version_pattern is None:
        mod_time = filepath.stat().st_mtime
        return datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d')
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(5000)
            match = re.search(version_pattern, content)
            if match:
                return match.group(1)
    except Exception:
        pass
    
    return None


def get_remote_version(url: str, version_pattern: Optional[str] = None) -> Optional[str]:
    """Get the version from remote dictionary file"""
    try:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = True
        ssl_context.verify_mode = ssl.CERT_REQUIRED
        
        request = urllib.request.Request(url, headers={'User-Agent': 'PyPLogo/1.0'})
        
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=ssl_context) as response:
            if version_pattern is None:
                last_modified = response.headers.get('Last-Modified')
                if last_modified:
                    from email.utils import parsedate_to_datetime
                    try:
                        dt = parsedate_to_datetime(last_modified)
                        return dt.strftime('%Y-%m-%d')
                    except Exception:
                        pass
                return datetime.now().strftime('%Y-%m-%d')
            
            content = response.read(5000).decode('utf-8', errors='ignore')
            match = re.search(version_pattern, content)
            if match:
                return match.group(1)
    
    except Exception:
        pass
    
    return None


def download_file(url: str, dest_path: Path, verbose: bool = False) -> bool:
    """Download a file from URL to destination path"""
    temp_path = None
    try:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive'
        }
        request = urllib.request.Request(url, headers=headers)
        
        temp_path = dest_path.with_suffix(dest_path.suffix + '.tmp')
        
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=ssl_context) as response:
            content_length = response.headers.get('Content-Length', 'unknown')
            if verbose:
                print(f"  响应状态: {response.status}")
                print(f"  内容长度: {content_length}")
            
            with open(temp_path, 'wb') as f:
                shutil.copyfileobj(response, f)
        
        if dest_path.exists():
            dest_path.unlink()
        
        temp_path.rename(dest_path)
        return True
    
    except urllib.error.URLError as e:
        if verbose:
            print(f"  URL错误: {e.reason}")
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass
        return False
    except urllib.error.HTTPError as e:
        if verbose:
            print(f"  HTTP错误: {e.code} - {e.reason}")
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass
        return False
    except Exception as e:
        if verbose:
            print(f"  下载错误: {type(e).__name__}: {e}")
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass
        return False


def load_version_cache(dict_dir: Path) -> Dict:
    """Load cached version information"""
    cache_file = dict_dir / VERSION_FILE
    if cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_version_cache(dict_dir: Path, cache: Dict):
    """Save version information to cache"""
    cache_file = dict_dir / VERSION_FILE
    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache, f, indent=2)
    except Exception:
        pass


def compare_versions(v1: str, v2: str) -> int:
    """Compare two version strings. Returns -1 if v1<v2, 0 if equal, 1 if v1>v2"""
    try:
        parts1 = [int(x) for x in re.findall(r'\d+', v1)]
        parts2 = [int(x) for x in re.findall(r'\d+', v2)]
        
        for p1, p2 in zip(parts1, parts2):
            if p1 < p2:
                return -1
            elif p1 > p2:
                return 1
        
        if len(parts1) < len(parts2):
            return -1
        elif len(parts1) > len(parts2):
            return 1
        
        return 0
    except Exception:
        return 0


def check_and_update_dicts(verbose: bool = True) -> Tuple[Path, Dict]:
    """
    Check and update dictionary files
    
    Returns:
        Tuple of (dictionary_directory, update_status_dict)
    """
    dict_dir = get_dict_dir()
    status = {}
    updates_available = []
    downloads_success = []
    downloads_failed = []
    
    for filename, config in DICT_FILES.items():
        url = config['url']
        version_pattern = config.get('version_pattern')
        
        local_version = get_local_version(dict_dir, filename)
        
        if local_version is None:
            if verbose:
                print(f"[PyPLogo] 字典文件 {filename} 不存在，正在下载...")
                print(f"  下载地址: {url}")
            
            if download_file(url, dict_dir / filename, verbose=verbose):
                downloads_success.append(filename)
                new_version = get_local_version(dict_dir, filename)
                status[filename] = {'status': 'downloaded', 'version': new_version}
                if verbose:
                    print(f"[PyPLogo] 成功下载 {filename}")
            else:
                downloads_failed.append(filename)
                status[filename] = {'status': 'download_failed', 'version': None}
                if verbose:
                    print(f"[PyPLogo] 警告: 无法下载 {filename}，请检查网络连接")
        else:
            try:
                remote_version = get_remote_version(url, version_pattern)
                
                if remote_version:
                    needs_update = False
                    if version_pattern:
                        needs_update = compare_versions(local_version, remote_version) < 0
                    else:
                        needs_update = local_version < remote_version
                    
                    if needs_update:
                        updates_available.append((filename, local_version, remote_version))
                        if verbose:
                            print(f"[PyPLogo] 检测到 {filename} 有新版本 ({local_version} -> {remote_version})，正在更新...")
                        
                        if download_file(url, dict_dir / filename, verbose=verbose):
                            downloads_success.append(filename)
                            status[filename] = {
                                'status': 'updated',
                                'old_version': local_version,
                                'new_version': remote_version
                            }
                            if verbose:
                                print(f"[PyPLogo] 成功更新 {filename}")
                        else:
                            downloads_failed.append(filename)
                            status[filename] = {
                                'status': 'update_failed',
                                'version': local_version,
                                'available_version': remote_version
                            }
                            if verbose:
                                print(f"[PyPLogo] 警告: 无法更新 {filename}，将使用当前版本")
                    else:
                        status[filename] = {'status': 'current', 'version': local_version}
                else:
                    status[filename] = {'status': 'check_failed', 'version': local_version}
                    if verbose:
                        print(f"[PyPLogo] 无法检查 {filename} 的更新，将使用当前版本")
            
            except Exception as e:
                status[filename] = {'status': 'error', 'version': local_version, 'error': str(e)}
                if verbose:
                    print(f"[PyPLogo] 检查 {filename} 更新时出错: {e}")
    
    cache = {
        'last_check': datetime.now().isoformat(),
        'status': status
    }
    save_version_cache(dict_dir, cache)
    
    if verbose:
        if downloads_success:
            print(f"[PyPLogo] 字典文件已更新: {', '.join(downloads_success)}")
        if downloads_failed:
            print(f"[PyPLogo] 警告: 以下字典文件更新失败: {', '.join(downloads_failed)}")
            print("[PyPLogo] 程序将继续使用现有字典文件运行")
    
    return dict_dir, status


def ensure_dicts_exist() -> Path:
    """
    Ensure dictionary files exist, download if necessary.
    This is a simplified version for package initialization.
    
    Returns:
        Path to the dictionary directory
    """
    dict_dir = get_dict_dir()
    
    all_exist = all((dict_dir / f).exists() for f in DICT_FILES.keys())
    
    if not all_exist:
        try:
            check_and_update_dicts(verbose=True)
        except Exception as e:
            warnings.warn(f"无法更新字典文件: {e}。如果字典文件缺失，DSSP功能可能无法正常工作。")
    
    return dict_dir


def get_dict_version_info() -> Dict:
    """Get version information for all dictionary files"""
    dict_dir = get_dict_dir()
    info = {}
    
    for filename in DICT_FILES.keys():
        version = get_local_version(dict_dir, filename)
        info[filename] = {
            'exists': (dict_dir / filename).exists(),
            'version': version,
            'path': str(dict_dir / filename)
        }
    
    return info
