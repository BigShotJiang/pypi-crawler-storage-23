"""
Data module for PyPLogo
Contains data structures for amino acid properties and characteristics
"""

import os
import warnings
from .aa_properties import AA_PROPERTIES, AA_COLORS, SS_COLORS
from .dict_updater import ensure_dicts_exist, get_dict_dir, check_and_update_dicts

_dict_dir = None
_dict_initialized = False


def get_dssp_dict_dir() -> str:
    """
    Get the DSSP dictionary directory path.
    Initializes dictionary files on first call.
    
    Returns:
        str: Path to the dictionary directory
    """
    global _dict_dir, _dict_initialized
    
    if not _dict_initialized:
        try:
            _dict_dir = ensure_dicts_exist()
        except Exception as e:
            warnings.warn(f"初始化字典文件时出错: {e}")
            base_dir = os.path.dirname(os.path.abspath(__file__))
            _dict_dir = os.path.join(base_dir, 'dssp_dicts')
        _dict_initialized = True
    
    return str(_dict_dir)


def update_dicts() -> dict:
    """
    Manually trigger dictionary update check.
    
    Returns:
        dict: Update status for each dictionary file
    """
    _, status = check_and_update_dicts(verbose=True)
    return status


__all__ = [
    'AA_PROPERTIES', 
    'AA_COLORS', 
    'SS_COLORS',
    'get_dssp_dict_dir',
    'update_dicts',
    'ensure_dicts_exist',
    'get_dict_dir',
    'check_and_update_dicts'
]
