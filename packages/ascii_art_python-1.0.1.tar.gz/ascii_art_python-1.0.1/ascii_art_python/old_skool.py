"""
Contains all the tools necessary to manage and convert images and videos into Old School ASCII art.
"""
from . import ascii_base
import cv2
import numpy as np
class Image(ascii_base.Image):
    """
    Class to convert and manipulate a classic image into Old School ASCII art.
    """
    def to_list(self) -> list[str]:
        size = self.size
        array = np.array(self._source_wb.resize(self.size))
        edges = cv2.Canny(array, 50, 150)
        sobel_x = cv2.Sobel(array, cv2.CV_64F, 1, 0)
        sobel_y = cv2.Sobel(array, cv2.CV_64F, 0, 1)
        ascii_list = [""] * size[1]
        for i in range(size[1]):
            for j in range(size[0]):
                if edges[i, j] == 255:
                    y = sobel_y[i, j]
                    x = sobel_x[i, j]
                    angle = np.degrees(np.arctan2(y, x)) % 180
                    if 67.5 <= angle < 112.5:
                        ascii_list[i] += "-"  
                    elif 22.5 <= angle < 67.5:
                        ascii_list[i] += "/" 
                    elif 112.5 <= angle < 157.5:
                        ascii_list[i] += "\\"  
                    else:
                        ascii_list[i] += "|"  
                else:
                    ascii_list[i] += " "
        return ascii_list

class Video(ascii_base.Video):
    def __init__(self, path: str, frame_size: int = 12_000, fps: int = 10):
        super().__init__(path, Image, frame_size, fps)
