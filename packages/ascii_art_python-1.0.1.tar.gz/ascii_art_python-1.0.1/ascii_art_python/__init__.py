"""
Module from https://gitlab.pprriieeuurr.fr/guill_prieur/ascii-art-python
"""
__version__ = "1.0.1"
from . import new_skool
from . import old_skool
from . import full_mode

if __name__ == "__main__":
    print(new_skool.Image.from_string("ASCII Art", 15))
