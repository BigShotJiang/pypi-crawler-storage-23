from fastgenerateapi.data_type.tortoise_type import T_Model


class GetMixin:

    async def set_get_model(self, model: T_Model, *args, **kwargs) -> T_Model:
        """
        修改查询后的model数据
        """
        return model

    async def set_get_schema_model(self, schema_model, *args, **kwargs):
        """
        对于查询的model，展示数据处理
        """
        return schema_model
