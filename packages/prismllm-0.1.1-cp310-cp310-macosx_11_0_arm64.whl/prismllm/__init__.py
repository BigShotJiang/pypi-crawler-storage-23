"""PrismLLM: Any model. Any hardware. Any size.

Hardware-agnostic LLM inference library that runs models of any size
on any device through intelligent tiered memory management.
"""

__version__ = "0.1.1"

from prismllm.model import PrismLLM
from prismllm.config import GenerationConfig, MemoryConfig, ModelConfig
from prismllm.streaming import TokenStream

__all__ = [
    "PrismLLM",
    "GenerationConfig",
    "MemoryConfig",
    "ModelConfig",
    "TokenStream",
]
