"""PrismLLM HuggingFace Hub integration."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from huggingface_hub import hf_hub_download, list_repo_files, snapshot_download
from rich.console import Console
from rich.progress import Progress

console = Console()

PREFERRED_QUANTIZATIONS = [
    "Q4_K_M",
    "Q4_K_S",
    "Q5_K_M",
    "Q5_K_S",
    "Q8_0",
]

SUPPORTED_EXTENSIONS = {
    ".gguf",
    ".safetensors",
    ".bin",
    ".onnx",
}


def resolve_model_path(model_id: str, quantize: Optional[str] = None) -> str:
    """Resolve a model identifier to a local file path.

    Accepts:
    - Local file path (returned as-is if exists)
    - Local directory (searches for model files)
    - HuggingFace repo ID (downloads)
    """
    path = Path(model_id)

    if path.is_file():
        return str(path.resolve())

    if path.is_dir():
        return _find_model_in_dir(path)

    return _download_from_hub(model_id, quantize)


def _find_model_in_dir(directory: Path) -> str:
    """Find a model file in a local directory."""
    for ext in [".gguf", ".safetensors", ".bin"]:
        files = list(directory.glob(f"*{ext}"))
        if files:
            files.sort(key=lambda f: f.stat().st_size, reverse=True)
            return str(files[0].resolve())

    raise FileNotFoundError(
        f"No model files found in {directory}. "
        f"Expected: {', '.join(SUPPORTED_EXTENSIONS)}"
    )


def _download_from_hub(repo_id: str, quantize: Optional[str] = None) -> str:
    """Download a model from HuggingFace Hub."""
    console.print(f"[bold blue]Resolving model:[/] {repo_id}")

    try:
        files = list_repo_files(repo_id)
    except Exception as e:
        raise RuntimeError(f"Failed to list files for {repo_id}: {e}") from e

    gguf_files = [f for f in files if f.endswith(".gguf")]
    if gguf_files:
        target = _select_gguf_file(gguf_files, quantize)
        console.print(f"[bold green]Downloading:[/] {target}")
        local_path = hf_hub_download(repo_id=repo_id, filename=target)
        return local_path

    safetensor_files = [f for f in files if f.endswith(".safetensors")]
    if safetensor_files:
        console.print(f"[bold green]Downloading safetensors model[/]")
        local_dir = snapshot_download(
            repo_id=repo_id,
            allow_patterns=["*.safetensors", "config.json", "tokenizer*"],
        )
        return _find_model_in_dir(Path(local_dir))

    bin_files = [f for f in files if f.endswith(".bin") and "pytorch_model" in f]
    if bin_files:
        console.print(f"[bold green]Downloading PyTorch model[/]")
        local_dir = snapshot_download(
            repo_id=repo_id,
            allow_patterns=["*.bin", "*.json", "tokenizer*"],
        )
        return _find_model_in_dir(Path(local_dir))

    raise RuntimeError(
        f"No supported model files found in {repo_id}. "
        f"Supported formats: {', '.join(SUPPORTED_EXTENSIONS)}"
    )


def _select_gguf_file(files: list[str], quantize: Optional[str] = None) -> str:
    """Select the best GGUF file based on quantization preference."""
    if quantize:
        for f in files:
            if quantize.upper() in f.upper():
                return f

    for quant in PREFERRED_QUANTIZATIONS:
        for f in files:
            if quant in f.upper():
                return f

    files.sort(key=lambda f: len(f))
    return files[0]
