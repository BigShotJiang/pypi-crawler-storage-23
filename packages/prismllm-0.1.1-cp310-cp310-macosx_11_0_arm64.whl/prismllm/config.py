"""PrismLLM Configuration schemas."""
from __future__ import annotations

from typing import Optional, List
from pydantic import BaseModel, Field


class MemoryConfig(BaseModel):
    """Memory budget configuration."""
    vram_budget: Optional[str] = None
    ram_budget: Optional[str] = None
    swap_budget: Optional[str] = None

    def vram_bytes(self) -> int:
        return _parse_size(self.vram_budget) if self.vram_budget else 0

    def ram_bytes(self) -> int:
        return _parse_size(self.ram_budget) if self.ram_budget else 0

    def swap_bytes(self) -> int:
        return _parse_size(self.swap_budget) if self.swap_budget else 0


class GenerationConfig(BaseModel):
    """Generation parameters."""
    max_tokens: int = Field(default=256, ge=1, le=32768)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=0.9, ge=0.0, le=1.0)
    top_k: int = Field(default=40, ge=0)
    repetition_penalty: float = Field(default=1.1, ge=1.0, le=2.0)
    stop_sequences: List[str] = Field(default_factory=list)


class ModelConfig(BaseModel):
    """Full model configuration."""
    model_path: str
    quantize: Optional[str] = None
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    device: Optional[str] = None
    num_threads: Optional[int] = None


def _parse_size(size_str: str) -> int:
    """Parse human-readable size string to bytes."""
    size_str = size_str.strip().upper()
    multipliers = {
        "B": 1,
        "KB": 1024,
        "MB": 1024 ** 2,
        "GB": 1024 ** 3,
        "TB": 1024 ** 4,
    }
    for suffix, mult in sorted(multipliers.items(), key=lambda x: -len(x[0])):
        if size_str.endswith(suffix):
            num = size_str[: -len(suffix)].strip()
            return int(float(num) * mult)
    return int(size_str)
