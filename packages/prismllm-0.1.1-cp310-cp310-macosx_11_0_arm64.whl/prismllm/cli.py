"""PrismLLM CLI — Command-line interface."""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

app = typer.Typer(
    name="prismllm",
    help="PrismLLM: Any model. Any hardware. Any size.",
    no_args_is_help=True,
)
console = Console()


@app.command()
def load(
    model: str = typer.Argument(help="HuggingFace repo ID or local path"),
    prompt: str = typer.Option("Hello, I am", help="Prompt text"),
    max_tokens: int = typer.Option(256, help="Maximum tokens to generate"),
    temperature: float = typer.Option(0.7, help="Sampling temperature"),
    quantize: Optional[str] = typer.Option(None, help="Quantization: int4, int8"),
    vram: Optional[str] = typer.Option(None, help="VRAM budget (e.g. 4GB)"),
    ram: Optional[str] = typer.Option(None, help="RAM budget (e.g. 8GB)"),
):
    """Load a model and generate text."""
    from prismllm import PrismLLM

    model_obj = PrismLLM.load(
        model,
        quantize=quantize,
        vram_budget=vram,
        ram_budget=ram,
    )

    console.print(f"\n[bold]Generating with prompt:[/] {prompt}\n")

    for token in model_obj.stream(prompt, max_tokens=max_tokens, temperature=temperature):
        console.print(token, end="")

    console.print(f"\n\n[dim]{model_obj.tokens_per_second:.1f} tok/s[/]")


@app.command()
def info(
    model: str = typer.Argument(help="HuggingFace repo ID or local path"),
):
    """Show model metadata and system info."""
    from prismllm._core import FormatDetector, Scheduler, TieredMemoryManager

    console.print(f"[bold blue]PrismLLM System Info[/]\n")

    sched = Scheduler()
    console.print(f"[bold]Backends:[/] {sched.backend_count()}")
    for name, dtype in sched.backend_info():
        console.print(f"  • {name} ({dtype})")

    mm = TieredMemoryManager()
    console.print(f"\n[bold]Memory:[/]")
    for tier_name, used, budget, util in mm.tier_stats():
        if budget < 2**60:
            console.print(f"  • {tier_name}: {used / 1e9:.1f} / {budget / 1e9:.1f} GB ({util:.0%})")

    try:
        from prismllm.hub import resolve_model_path
        path = resolve_model_path(model)
        fmt = FormatDetector.detect(path)
        meta = FormatDetector.load_metadata(path)
        console.print(f"\n[bold]Model:[/]")
        console.print(f"  Architecture: {meta.architecture}")
        console.print(f"  Layers: {meta.num_layers}")
        console.print(f"  Hidden size: {meta.hidden_size}")
        console.print(f"  Format: {meta.format_name}")
        console.print(f"  File size: {meta.file_size / 1e9:.2f} GB")
        if meta.is_moe:
            console.print(f"  MoE: {meta.num_active_experts}/{meta.num_experts} experts")
    except Exception as e:
        console.print(f"\n[red]Could not load model info: {e}[/]")


@app.command()
def bench(
    model: str = typer.Argument(help="HuggingFace repo ID or local path"),
    prompt: str = typer.Option("The capital of France is", help="Benchmark prompt"),
    tokens: int = typer.Option(100, help="Tokens to generate"),
    runs: int = typer.Option(3, help="Number of runs to average"),
):
    """Benchmark tokens/second for a model."""
    from prismllm import PrismLLM
    import time

    model_obj = PrismLLM.load(model)
    console.print(f"\n[bold]Benchmarking {model} — {tokens} tokens × {runs} runs[/]")

    results = []
    for run in range(runs):
        t0 = time.perf_counter()
        _ = model_obj.generate(prompt, max_tokens=tokens, temperature=0.0)
        elapsed = time.perf_counter() - t0
        tok_s = tokens / elapsed
        results.append(tok_s)
        console.print(f"  Run {run+1}: {tok_s:.1f} tok/s")

    avg = sum(results) / len(results)
    console.print(f"\n[bold green]Average: {avg:.1f} tok/s[/]")


@app.command()
def setup(
    model: str = typer.Option(
        "bartowski/DeepSeek-V3-0324-GGUF",
        help="Model to download (default: DeepSeek V3 0324)",
    ),
    quant: Optional[str] = typer.Option(
        None,
        help="Quantization override (auto-detected from VRAM if not set)",
    ),
    skip_download: bool = typer.Option(False, help="Skip model download, only verify install"),
):
    """One-command setup: verify install, detect hardware, download model."""
    import subprocess
    import shutil

    console.print("[bold blue]PrismLLM Setup[/]\n")

    # 1. Verify core
    console.print("[bold]1/4  Verifying installation...[/]")
    try:
        from prismllm._core import TieredMemoryManager, Scheduler, HardwareProfile
        mm = TieredMemoryManager()
        sched = Scheduler()
        hw = HardwareProfile()
        console.print(f"  [green]✓[/] Core module OK")
        console.print(f"  [green]✓[/] Backends: {sched.backend_count()}")
        console.print(f"  [green]✓[/] Hardware: {repr(hw)}")
    except Exception as e:
        console.print(f"  [red]✗ Core import failed: {e}[/]")
        console.print("  Try: pip install --upgrade prismllm")
        raise typer.Exit(1)

    # 2. Detect VRAM
    console.print("\n[bold]2/4  Detecting hardware...[/]")
    vram_gb = 0.0
    gpu_name = "none"

    if shutil.which("nvidia-smi"):
        try:
            r = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10,
            )
            if r.returncode == 0:
                for line in r.stdout.strip().splitlines():
                    parts = line.rsplit(",", 1)
                    if len(parts) == 2:
                        gpu_name = parts[0].strip()
                        vram_gb = int(parts[1].strip()) / 1024
                        console.print(f"  [green]✓[/] GPU: {gpu_name} ({vram_gb:.0f} GB VRAM)")
                        break
        except Exception:
            pass
    else:
        import os
        ram_bytes = mm.ram_budget()
        ram_gb = ram_bytes / 1e9
        console.print(f"  No GPU detected — CPU/APU mode")
        console.print(f"  RAM budget: {ram_gb:.0f} GB")
        vram_gb = 0.0

    # 3. Auto-select quant
    if quant is None:
        if vram_gb >= 350:
            quant = "Q4_K_M"
        elif vram_gb >= 170:
            quant = "Q2_K"
        elif vram_gb >= 130:
            quant = "IQ2_XS"
        else:
            quant = "IQ2_XXS"

    console.print(f"  [green]✓[/] Selected quantization: [bold]{quant}[/]")

    # 4. Install optional deps
    console.print("\n[bold]3/4  Installing optional dependencies...[/]")
    try:
        import fastapi  # noqa
        import uvicorn  # noqa
        console.print("  [green]✓[/] fastapi + uvicorn already installed (serve command ready)")
    except ImportError:
        try:
            subprocess.run(
                ["pip", "install", "fastapi", "uvicorn", "--quiet"],
                check=True, timeout=60,
            )
            console.print("  [green]✓[/] Installed fastapi + uvicorn")
        except Exception as e:
            console.print(f"  [yellow]⚠[/] Could not install fastapi/uvicorn: {e}")
            console.print("  The 'serve' command will not be available until installed.")

    # 5. Download model
    if not skip_download:
        console.print(f"\n[bold]4/4  Downloading {model} ({quant})...[/]")
        console.print("  This may take several minutes depending on model size and bandwidth.\n")
        try:
            from prismllm.hub import resolve_model_path
            model_path = resolve_model_path(model, quant)
            console.print(f"\n  [green]✓[/] Model ready at: {model_path}")

            # Quick smoke test: load metadata only
            from prismllm._core import FormatDetector
            fmt = FormatDetector.detect(model_path)
            meta = FormatDetector.load_metadata(model_path)
            console.print(f"  [green]✓[/] Verified: {meta.architecture} | {meta.num_layers} layers | {fmt}")
        except Exception as e:
            console.print(f"\n  [red]✗ Download/verify failed: {e}[/]")
            raise typer.Exit(1)
    else:
        console.print("\n[bold]4/4  Skipped model download (--skip-download)[/]")

    console.print("\n[bold green]Setup complete![/]")
    console.print("\nQuick commands:")
    console.print(f"  prismllm bench {model}")
    console.print(f"  prismllm serve {model}")
    console.print(f"  prismllm load {model} --prompt 'Hello!'")


@app.command()
def serve(
    model: str = typer.Argument(help="HuggingFace repo ID or local path"),
    host: str = typer.Option("0.0.0.0", help="Host to bind"),
    port: int = typer.Option(8000, help="Port to bind"),
):
    """Start an OpenAI-compatible HTTP server."""
    try:
        import uvicorn
        from fastapi import FastAPI
        from pydantic import BaseModel as FBaseModel
    except ImportError:
        console.print("[red]Install fastapi and uvicorn: pip install fastapi uvicorn[/]")
        raise typer.Exit(1)

    from prismllm import PrismLLM

    app_http = FastAPI(title="PrismLLM Server")
    model_instance = PrismLLM.load(model)

    class CompletionRequest(FBaseModel):
        prompt: str
        max_tokens: int = 256
        temperature: float = 0.7
        stream: bool = False

    @app_http.post("/v1/completions")
    def completions(req: CompletionRequest):
        text = model_instance.generate(req.prompt, max_tokens=req.max_tokens, temperature=req.temperature)
        return {
            "object": "text_completion",
            "choices": [{"text": text, "index": 0, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 0, "completion_tokens": req.max_tokens, "total_tokens": req.max_tokens},
        }

    @app_http.get("/v1/models")
    def list_models():
        return {"object": "list", "data": [{"id": model, "object": "model"}]}

    console.print(f"[bold green]PrismLLM server running at http://{host}:{port}[/]")
    uvicorn.run(app_http, host=host, port=port)


if __name__ == "__main__":
    app()
