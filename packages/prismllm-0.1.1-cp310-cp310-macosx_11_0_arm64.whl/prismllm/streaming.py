"""PrismLLM token streaming utilities."""
from __future__ import annotations

from typing import Generator, Optional, Callable


class TokenStream:
    """Wraps a token generator with utilities for streaming output."""

    def __init__(self, generator: Generator[str, None, None]):
        self._generator = generator
        self._collected: list[str] = []
        self._finished = False

    def __iter__(self):
        return self

    def __next__(self) -> str:
        if self._finished:
            raise StopIteration
        try:
            token = next(self._generator)
            self._collected.append(token)
            return token
        except StopIteration:
            self._finished = True
            raise

    def collect(self) -> str:
        """Consume remaining tokens and return full text."""
        if not self._finished:
            for token in self:
                pass
        return "".join(self._collected)

    def on_token(self, callback: Callable[[str], None]) -> str:
        """Stream tokens through a callback, return full text."""
        for token in self:
            callback(token)
        return "".join(self._collected)

    @property
    def text(self) -> str:
        """Text collected so far."""
        return "".join(self._collected)

    @property
    def token_count(self) -> int:
        return len(self._collected)
