"""PrismLLM high-level Model API."""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional, List, Dict, Generator, Union

from rich.console import Console

from prismllm._core import (
    TieredMemoryManager,
    Scheduler,
    FormatDetector,
    InferenceEngine,
    ModelMetadata,
    LlamaSession,
)
from prismllm.config import GenerationConfig, MemoryConfig, _parse_size
from prismllm.hub import resolve_model_path
from prismllm.streaming import TokenStream

console = Console()


class PrismLLM:
    """Hardware-agnostic LLM inference engine.

    Usage:
        model = PrismLLM.load("meta-llama/Llama-3.1-8B-Instruct")
        output = model.generate("Hello world", max_tokens=200)

        for token in model.stream("Tell me a story:"):
            print(token, end="", flush=True)
    """

    def __init__(
        self,
        model_path: str,
        metadata: ModelMetadata,
        engine: InferenceEngine,
        session: Optional[LlamaSession] = None,
        tokenizer=None,
        generation_config: Optional[GenerationConfig] = None,
    ):
        self._model_path = model_path
        self._metadata = metadata
        self._engine = engine
        self._session = session
        self._tokenizer = tokenizer
        self._gen_config = generation_config or GenerationConfig()
        self._last_tok_s: float = 0.0

    @classmethod
    def load(
        cls,
        model: str,
        quantize: Optional[str] = None,
        vram_budget: Optional[str] = None,
        ram_budget: Optional[str] = None,
        device: Optional[str] = None,
        sparse_oracle: bool = True,
        verbose: bool = False,
        tokenizer_repo: Optional[str] = None,
        **kwargs,
    ) -> "PrismLLM":
        """Load a model from HuggingFace Hub or local path.

        Args:
            model: HuggingFace repo ID or local path
            quantize: Quantization level ("int4", "int8", or None)
            vram_budget: VRAM budget (e.g. "4GB")
            ram_budget: RAM budget (e.g. "8GB")
            device: Preferred device ("cpu", "cuda", "auto")
            sparse_oracle: Enable Sparse Oracle optimizations for MoE models
            verbose: Print detailed loading info
            tokenizer_repo: Explicit HF repo for tokenizer (auto-detected if omitted)
        """
        start = time.time()
        console.print(f"[bold blue]PrismLLM[/] Loading model: {model}")

        model_path = resolve_model_path(model, quantize)
        console.print(f"  [dim]Path:[/] {model_path}")

        format_name = FormatDetector.detect(model_path)
        console.print(f"  [dim]Format:[/] {format_name}")

        vram_b = _parse_size(vram_budget) if vram_budget else 0
        ram_b = _parse_size(ram_budget) if ram_budget else 0
        engine = InferenceEngine(vram_budget=vram_b, ram_budget=ram_b)

        metadata = engine.load_model(model_path)
        console.print(
            f"  [dim]Architecture:[/] {metadata.architecture} | "
            f"[dim]Layers:[/] {metadata.num_layers} | "
            f"[dim]Hidden:[/] {metadata.hidden_size}"
        )
        console.print(
            f"  [dim]Backends:[/] {engine.backend_count()} available"
        )

        if sparse_oracle and metadata.is_moe:
            console.print(f"  [dim]Sparse Oracle:[/] enabled ({metadata.num_experts} experts)")

        console.print(f"  [dim]Loading weights...[/]")
        try:
            session = LlamaSession(model_path)
            console.print(
                f"  [dim]Inference:[/] {session.num_layers()} layers, "
                f"hidden={session.hidden_dim()}, vocab={session.vocab_size()}"
            )
        except Exception as e:
            console.print(f"  [yellow]Inference engine failed: {e}[/]")
            session = None

        tok_id = tokenizer_repo or model
        tokenizer = cls._load_tokenizer(tok_id, model_path)
        if tokenizer:
            console.print(f"  [dim]Tokenizer:[/] {tokenizer.get_vocab_size()} tokens")

        elapsed = time.time() - start
        console.print(f"  [bold green]Ready in {elapsed:.1f}s[/]")

        return cls(
            model_path=model_path,
            metadata=metadata,
            engine=engine,
            session=session,
            tokenizer=tokenizer,
        )

    def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> str:
        """Generate text from a prompt."""
        stream = self.stream(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            stop=stop,
            **kwargs,
        )
        return stream.collect()

    def stream(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> TokenStream:
        """Stream tokens from a prompt."""
        config = GenerationConfig(
            max_tokens=max_tokens or self._gen_config.max_tokens,
            temperature=temperature if temperature is not None else self._gen_config.temperature,
            top_p=top_p if top_p is not None else self._gen_config.top_p,
            top_k=top_k if top_k is not None else self._gen_config.top_k,
            stop_sequences=stop or self._gen_config.stop_sequences,
        )

        model_ref = self

        def token_generator() -> Generator[str, None, None]:
            if model_ref._tokenizer is None:
                yield f"[Tokenizer not available for {model_ref._metadata.architecture}]"
                return

            if model_ref._session is None:
                yield f"[Inference engine not loaded]"
                return

            input_ids = model_ref._tokenizer.encode(prompt).ids

            for tid in input_ids[:-1]:
                model_ref._session.generate_next_token(
                    tid, config.temperature, config.top_k, config.top_p,
                )

            current_token = input_ids[-1] if input_ids else 1

            t0 = time.perf_counter()
            count = 0

            for _ in range(config.max_tokens):
                next_token = model_ref._session.generate_next_token(
                    current_token,
                    config.temperature,
                    config.top_k,
                    config.top_p,
                )

                token_str = model_ref._tokenizer.decode([next_token])
                count += 1

                if next_token == 2 or next_token == 0:
                    break

                if any(s in token_str for s in config.stop_sequences):
                    break

                yield token_str
                current_token = next_token

            elapsed = time.perf_counter() - t0
            model_ref._last_tok_s = count / elapsed if elapsed > 0 else 0.0

        return TokenStream(token_generator())

    def chat(
        self,
        messages: List[Dict[str, str]],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs,
    ) -> str:
        """Chat-style generation from a list of messages."""
        prompt = self._format_chat(messages)
        return self.generate(prompt, max_tokens=max_tokens, temperature=temperature, **kwargs)

    @property
    def metadata(self) -> ModelMetadata:
        return self._metadata

    @property
    def model_path(self) -> str:
        return self._model_path

    @property
    def tokens_per_second(self) -> float:
        return self._last_tok_s

    @property
    def model_info(self) -> dict:
        return {
            "architecture": self._metadata.architecture,
            "num_layers": self._metadata.num_layers,
            "hidden_size": self._metadata.hidden_size,
            "vocab_size": self._metadata.vocab_size,
            "format": self._metadata.format_name,
            "file_size_gb": self._metadata.file_size / 1e9,
            "is_moe": self._metadata.is_moe,
            "num_experts": self._metadata.num_experts,
            "tokens_per_second": self.tokens_per_second,
        }

    def _format_chat(self, messages: List[Dict[str, str]]) -> str:
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"<<SYS>>\n{content}\n<</SYS>>\n\n")
            elif role == "user":
                parts.append(f"[INST] {content} [/INST]\n")
            elif role == "assistant":
                parts.append(f"{content}\n")
        return "".join(parts)

    @staticmethod
    def _load_tokenizer(model_id: str, model_path: str):
        try:
            from tokenizers import Tokenizer

            model_dir = Path(model_path).parent

            tokenizer_path = model_dir / "tokenizer.json"
            if tokenizer_path.exists():
                return Tokenizer.from_file(str(tokenizer_path))

            for parent in Path(model_path).parents:
                tp = parent / "tokenizer.json"
                if tp.exists():
                    return Tokenizer.from_file(str(tp))
                if parent.name == ".cache":
                    break

            candidates = [model_id]
            parts = model_id.split("/")
            if len(parts) == 2:
                name = parts[1]
                for suffix in ["-GGUF", "-gguf", "-GPTQ", "-gptq", "-AWQ", "-awq"]:
                    if name.endswith(suffix):
                        base_name = name[:-len(suffix)]
                        candidates.append(f"{parts[0]}/{base_name}")
                        name_parts = base_name.split("-")
                        if name_parts:
                            candidates.append(f"{name_parts[0]}/{base_name}")
                        break

            for candidate in candidates:
                try:
                    return Tokenizer.from_pretrained(candidate)
                except Exception:
                    continue

        except ImportError:
            pass

        return None
