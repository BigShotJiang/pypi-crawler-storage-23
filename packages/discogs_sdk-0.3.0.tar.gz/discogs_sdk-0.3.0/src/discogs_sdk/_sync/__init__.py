# This file is auto-generated from the async version.
# Do not edit directly — edit the corresponding file in _async/ instead.

from discogs_sdk._sync._client import Discogs

__all__ = ["Discogs"]
