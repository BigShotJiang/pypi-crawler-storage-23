from ...core.pipeline import Pipeline

class Display:
    def setup_logging(self, log_level: str):
        pass

    async def run_pipeline(self, pipeline: Pipeline, params: dict):
        pass
