"""Dataset Foundry - A toolkit for building validated datasets using LLM pipelines."""

from importlib.metadata import version

__version__ = version("dataset-foundry")
