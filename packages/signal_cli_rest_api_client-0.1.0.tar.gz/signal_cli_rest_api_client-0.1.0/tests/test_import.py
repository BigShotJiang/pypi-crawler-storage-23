"""Test that the package can be imported."""


def test_can_import_package():
    """Ensure signal_cli_rest_api_client is importable."""
    import signal_cli_rest_api_client  # noqa: F401

    assert signal_cli_rest_api_client is not None
