"""Test Signal client: listen for events and send a message to self; assert an event arrives."""

import asyncio
import os

import pytest

from signal_cli_rest_api_client.client import SignalClient, encode_attachment


def _env(name: str) -> str:
    """Require env var (ensures .env was loaded by conftest)."""
    value = os.environ.get(name)
    if not value:
        pytest.skip(f"Missing {name} (set in .env at project root)")
    return value


async def test_listen_receives_event_after_sending_to_self():
    """
    Create a Signal client, start listening for events, send a message to the same
    number we're listening on, and assert that at least one event arrives within 10s.
    """
    url = _env("SIGNAL_URL")
    phone = _env("SIGNAL_NUMBER")
    user = os.environ.get("SIGNAL_USER")
    password = os.environ.get("SIGNAL_PASSWORD")

    client = SignalClient(url=url, phone=phone, user=user, password=password)
    events: asyncio.Queue = asyncio.Queue()

    async def collect_events() -> None:
        async for payload in client.stream_events():
            await events.put(payload)

    listener_task = asyncio.create_task(collect_events())
    try:
        # Brief delay to allow WebSocket to connect
        await asyncio.sleep(2.0)

        # Send a message to self so we should get an event (e.g. sync or dataMessage)
        await client.send(
            recipients=phone, message="[pytest] listen-and-send self-test"
        )

        # Wait for any event within 10s
        try:
            first_event = await asyncio.wait_for(events.get(), timeout=10.0)
        except asyncio.TimeoutError:
            pytest.fail("No event received within 10s after sending message to self")

        assert first_event is not None
        assert isinstance(first_event, dict)
    finally:
        listener_task.cancel()
        try:
            await listener_task
        except asyncio.CancelledError:
            pass


async def test_delete_message():
    """
    Send a message to self, then remote-delete it using the returned timestamp.
    Asserts delete_message returns a response with a timestamp.
    """
    url = _env("SIGNAL_URL")
    phone = _env("SIGNAL_NUMBER")
    user = os.environ.get("SIGNAL_USER")
    password = os.environ.get("SIGNAL_PASSWORD")

    client = SignalClient(url=url, phone=phone, user=user, password=password)

    # Send a message to self
    send_resp = await client.send(
        recipients=phone,
        message="[pytest] message to be deleted",
    )
    assert isinstance(send_resp, dict)
    ts = send_resp.get("timestamp")
    if not ts:
        pytest.skip("Send response did not include timestamp (unsupported API?)")
    # API may return string or int
    timestamp = int(ts) if isinstance(ts, str) else ts

    # Remote-delete the message
    delete_resp = await client.delete_message(recipient=phone, timestamp=timestamp)
    assert isinstance(delete_resp, dict)
    assert "timestamp" in delete_resp


async def test_set_reaction_and_clear_reaction():
    """
    Send a message to self, set a reaction, clear it, then re-add the reaction
    so it is visible in the client at the end.
    """
    url = _env("SIGNAL_URL")
    phone = _env("SIGNAL_NUMBER")
    user = os.environ.get("SIGNAL_USER")
    password = os.environ.get("SIGNAL_PASSWORD")

    client = SignalClient(url=url, phone=phone, user=user, password=password)

    # Send a message to self (we are both sender and recipient)
    send_resp = await client.send(
        recipients=phone,
        message="[pytest] message to react to",
    )
    assert isinstance(send_resp, dict)
    ts = send_resp.get("timestamp")
    if not ts:
        pytest.skip("Send response did not include timestamp (unsupported API?)")
    timestamp = int(ts) if isinstance(ts, str) else ts

    # React to the message (target_author is self when sending to self)
    await client.set_reaction(
        recipient=phone,
        target_author=phone,
        timestamp=timestamp,
        reaction="👍",
    )

    # Remove the reaction
    await client.clear_reaction(
        recipient=phone,
        target_author=phone,
        timestamp=timestamp,
    )

    # Re-add the reaction so it is visible in the client
    await client.set_reaction(
        recipient=phone,
        target_author=phone,
        timestamp=timestamp,
        reaction="👍",
    )


async def test_send_message_with_attachment_then_fetch_and_delete():
    """
    Send a message to self with a small attachment, wait for the server to store it
    (sync path), fetch the attachment and assert content matches, then delete it
    from the server. The message and its attachment remain visible in Signal.
    """
    url = _env("SIGNAL_URL")
    phone = _env("SIGNAL_NUMBER")
    user = os.environ.get("SIGNAL_USER")
    password = os.environ.get("SIGNAL_PASSWORD")

    client = SignalClient(url=url, phone=phone, user=user, password=password)

    payload = b"[pytest] small attachment content"
    encoded = encode_attachment(
        payload, mime_type="text/plain", filename="pytest-attachment.txt"
    )

    ids_before = set(await client.list_attachments())
    await client.send(
        recipients=phone,
        message="[pytest] message with attachment",
        base64_attachments=[encoded],
    )

    # Server stores the attachment when it processes the incoming/sync message
    new_ids = set()
    for _ in range(15):
        await asyncio.sleep(1)
        ids_after = set(await client.list_attachments())
        new_ids = ids_after - ids_before
        if new_ids:
            break
    if not new_ids:
        pytest.skip(
            "No new attachment appeared on server after sending "
            "(server may not store sent-to-self attachments)"
        )

    attachment_id = next(iter(new_ids))
    fetched = await client.get_attachment(attachment_id)
    assert fetched == payload, "Fetched attachment content should match what we sent"

    await client.delete_attachment(attachment_id)

    ids_final = set(await client.list_attachments())
    assert attachment_id not in ids_final, "Attachment should be removed from server"
