import base64
import json
import mimetypes
from pathlib import Path
from typing import Any, AsyncIterator

import aiohttp


def encode_attachment(
    file_or_bytes: str | Path | bytes,
    mime_type: str | None = None,
    filename: str | None = None,
) -> str:
    """
    Encode a file or raw bytes as a data-URI string for use with send(base64_attachments=...).

    file_or_bytes: Path to a file (str or Path), or raw bytes. If a path, mime type
        and filename are guessed from the file extension and path name.
    mime_type: For bytes input, the MIME type (e.g. "image/png"). Defaults to
        "application/octet-stream" if omitted. Ignored when file_or_bytes is a path.
    filename: Optional filename for the attachment (e.g. "screenshot.png"). Used in
        the data URI so Signal can show a name. For path input, defaults to the
        path's name.

    Returns a string in the form "data:<mime>;filename=<name>;base64,<data>" (or
    without filename if not set), which the Signal API accepts in base64_attachments.
    """
    if isinstance(file_or_bytes, bytes):
        data = file_or_bytes
        mime = mime_type or "application/octet-stream"
        name = filename
    else:
        path = Path(file_or_bytes)
        if not path.is_file():
            raise FileNotFoundError(f"Attachment path is not a file: {path}")
        data = path.read_bytes()
        guessed, _ = mimetypes.guess_type(str(path))
        mime = mime_type or guessed or "application/octet-stream"
        name = filename or path.name

    b64 = base64.b64encode(data).decode("utf-8")
    if name:
        return f"data:{mime};filename={name};base64,{b64}"
    return f"data:{mime};base64,{b64}"


class SendError(Exception):
    """
    Raised when the send API returns 400.

    If the error is due to rate limiting, the server may include challenge_tokens.
    To lift the limit:
    1. Get a CAPTCHA result: open https://signalcaptchas.org/challenge/generate.html
       (for staging: https://signalcaptchas.org/staging/registration/generate.html),
       complete the challenge, and copy the result (it starts with signalcaptcha://).
    2. For each challenge token in this error's challenge_tokens (or use the one
       from the failed send response), call
       client.submit_rate_limit_challenge(challenge_token, captcha).
    3. Retry sending.
    """

    def __init__(
        self,
        message: str,
        account: str | None = None,
        challenge_tokens: list[str] | None = None,
    ):
        super().__init__(message)
        self.account = account
        self.challenge_tokens = challenge_tokens or []


class SignalClient:
    """
    Client for interacting with the Signal CLI REST API.
    - REST API must be in json-rpc mode.
    - Basic HTTP auth is supported.
    - Works with one phone number at a time.
    """

    def __init__(
        self, url: str, phone: str, user: str | None = None, password: str | None = None
    ):
        self.url = url
        self.phone = phone
        self.user = user
        self.password = password

    async def stream_events(self) -> AsyncIterator[dict]:
        """Opens a WebSocket connection and yields incoming events as they arrive."""
        ws_url = self._ws_url()
        headers = self._auth_headers()
        async with aiohttp.ClientSession() as session:
            async with session.ws_connect(
                ws_url,
                headers=headers or None,
                heartbeat=30.0,
            ) as ws:
                async for msg in ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        try:
                            payload = json.loads(msg.data)
                            yield payload
                        except json.JSONDecodeError:
                            continue
                    elif msg.type == aiohttp.WSMsgType.ERROR:
                        raise ConnectionError("WebSocket error") from ws.exception()
                    elif msg.type in (
                        aiohttp.WSMsgType.CLOSE,
                        aiohttp.WSMsgType.CLOSING,
                        aiohttp.WSMsgType.CLOSED,
                    ):
                        break

    async def send(
        self,
        recipients: str | list[str],
        message: str,
        *,
        text_mode: str = "normal",
        base64_attachments: list[str] | None = None,
        view_once: bool | None = None,
        notify_self: bool | None = None,
        quote_timestamp: int | None = None,
        quote_author: str | None = None,
        quote_message: str | None = None,
        edit_timestamp: int | None = None,
        sticker: str | None = None,
        **kwargs: Any,
    ) -> dict:
        """
        Send a Signal message (v2 API).

        recipients: Phone number(s), username(s), or group id(s). Single value or list.
        message: Message text. With text_mode='styled' you can use *italic*, **bold**, ~strikethrough~, ||spoiler||, `monospace`.
        text_mode: 'normal' or 'styled'.
        base64_attachments: Optional list of base64 attachment strings.
        view_once: If True, send as view-once.
        notify_self: If True, send a sync message to yourself.
        quote_*: Optional quote reply fields.
        edit_timestamp: For editing an existing message.
        sticker: Base64-encoded sticker.
        **kwargs: Other optional v2 fields (mentions, quote_mentions, link_preview).

        Returns the API response (e.g. {"timestamp": "..."}) on success.
        Raises SendError on 400 (e.g. rate limit). See SendError docstring for
        how to resolve rate limits using submit_rate_limit_challenge().
        """
        if isinstance(recipients, str):
            recipients = [recipients]
        body = {
            "number": self.phone,
            "recipients": recipients,
            "message": message,
            "text_mode": text_mode,
        }
        if base64_attachments is not None:
            body["base64_attachments"] = base64_attachments
        if view_once is not None:
            body["view_once"] = view_once
        if notify_self is not None:
            body["notify_self"] = notify_self
        if quote_timestamp is not None:
            body["quote_timestamp"] = quote_timestamp
        if quote_author is not None:
            body["quote_author"] = quote_author
        if quote_message is not None:
            body["quote_message"] = quote_message
        if edit_timestamp is not None:
            body["edit_timestamp"] = edit_timestamp
        if sticker is not None:
            body["sticker"] = sticker
        body.update(kwargs)

        url = f"{self._base_url()}/v2/send"
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=headers) as resp:
                if resp.status == 201:
                    return await resp.json()
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(
                        err.get("error", "Bad Request"),
                        account=err.get("account"),
                        challenge_tokens=err.get("challenge_tokens"),
                    )
                resp.raise_for_status()
                return await resp.json()

    async def submit_rate_limit_challenge(
        self, challenge_token: str, captcha: str
    ) -> None:
        """
        Submit a solved CAPTCHA to lift rate-limit restrictions after a SendError.

        Call this when send() raises SendError with challenge_tokens (e.g. rate
        limit). Get the captcha value by completing the challenge at
        https://signalcaptchas.org/challenge/generate.html (staging:
        https://signalcaptchas.org/staging/registration/generate.html). The
        result must start with signalcaptcha://. Use one of the tokens from
        SendError.challenge_tokens as challenge_token.

        Returns None on success (204). Raises on 400 or other errors.
        """
        url = f"{self._base_url()}/v1/accounts/{self.phone}/rate-limit-challenge"
        body = {"challenge_token": challenge_token, "captcha": captcha}
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def show_typing_indicator(self, recipient: str) -> None:
        """
        Show typing indicator to the given recipient (they see that you are typing).

        recipient: Phone number or username to show the typing indicator to.
        Returns None on success (204).
        """
        url = f"{self._base_url()}/v1/typing-indicator/{self.phone}"
        body = {"recipient": recipient}
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.put(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def hide_typing_indicator(self, recipient: str) -> None:
        """
        Hide typing indicator for the given recipient (they no longer see that you are typing).

        recipient: Phone number or username to hide the typing indicator for.
        Returns None on success (204).
        """
        url = f"{self._base_url()}/v1/typing-indicator/{self.phone}"
        body = {"recipient": recipient}
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.delete(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def delete_message(self, recipient: str, timestamp: int) -> dict:
        """
        Delete a Signal message (remote delete for everyone in the conversation).

        recipient: Phone number or username of the conversation where the message was sent.
        timestamp: Timestamp of the message to delete (e.g. from send() response).

        Returns the API response (e.g. {"timestamp": "..."}) on success (201).
        Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/remote-delete/{self.phone}"
        body = {"recipient": recipient, "timestamp": timestamp}
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.delete(url, json=body, headers=headers) as resp:
                if resp.status == 201:
                    return await resp.json()
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()
                return await resp.json()

    async def set_reaction(
        self,
        recipient: str,
        target_author: str,
        timestamp: int,
        reaction: str,
    ) -> None:
        """
        React to a message (set or update reaction).

        recipient: Phone number or username of the conversation.
        target_author: Author of the message to react to (phone or username).
        timestamp: Timestamp of the message to react to (e.g. from send() or event).
        reaction: Emoji string (e.g. "👍", "❤️").

        Returns None on success (204). Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/reactions/{self.phone}"
        body = {
            "recipient": recipient,
            "target_author": target_author,
            "timestamp": timestamp,
            "reaction": reaction,
        }
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def clear_reaction(
        self,
        recipient: str,
        target_author: str,
        timestamp: int,
    ) -> None:
        """
        Remove your reaction from a message.

        recipient: Phone number or username of the conversation.
        target_author: Author of the message (phone or username).
        timestamp: Timestamp of the message (e.g. from send() or event).

        Returns None on success (204). Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/reactions/{self.phone}"
        body = {
            "recipient": recipient,
            "target_author": target_author,
            "timestamp": timestamp,
        }
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.delete(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def send_read_receipt(self, recipient: str, timestamp: int) -> None:
        """
        Send a read receipt for a message to the given recipient.

        recipient: Phone number or username of the conversation/sender.
        timestamp: Timestamp of the message that was read (e.g. from an event).

        Returns None on success (204). Raises SendError on 400.

        Note: Cannot be tested by sending to self (read receipts are not sent
        for your own messages).
        """
        url = f"{self._base_url()}/v1/receipts/{self.phone}"
        body = {
            "receipt_type": "read",
            "recipient": recipient,
            "timestamp": timestamp,
        }
        headers = {**self._auth_headers(), "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    async def list_attachments(self) -> list[str]:
        """
        List all downloaded attachment IDs (for the server/account).

        These IDs are the ones found in incoming WebSocket envelopes (e.g. in
        an attachments array). Use get_attachment(id) to fetch bytes and
        delete_attachment(id) to remove from disk after processing.

        Returns a list of attachment ID strings. Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/attachments"
        headers = self._auth_headers()
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as resp:
                if resp.status == 200:
                    return await resp.json()
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()
                return await resp.json()

    async def get_attachment(self, attachment_id: str) -> bytes:
        """
        Retrieve attachment data by ID (e.g. from an incoming message envelope).

        attachment_id: ID of the attachment (from list_attachments or from the
            WebSocket envelope's attachments array, often under "id" or similar).

        Returns the attachment bytes. The API may return JSON with a base64
        string or raw bytes depending on content-type; this method always
        returns decoded bytes. Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/attachments/{attachment_id}"
        headers = self._auth_headers()
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as resp:
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()
                ct = resp.headers.get("Content-Type", "")
                if "application/json" in ct:
                    raw = await resp.json()
                    if isinstance(raw, str):
                        return base64.b64decode(raw)
                    raise ValueError("Unexpected attachment response: not a string")
                return await resp.read()

    async def delete_attachment(self, attachment_id: str) -> None:
        """
        Remove the attachment from the server filesystem (e.g. after processing).

        attachment_id: ID of the attachment to remove.

        Returns None on success (204). Raises SendError on 400.
        """
        url = f"{self._base_url()}/v1/attachments/{attachment_id}"
        headers = self._auth_headers()
        async with aiohttp.ClientSession() as session:
            async with session.delete(url, headers=headers) as resp:
                if resp.status == 204:
                    return
                if resp.status == 400:
                    err = await resp.json()
                    raise SendError(err.get("error", "Bad Request"))
                resp.raise_for_status()

    def _ws_url(self) -> str:
        base = self.url.strip().rstrip("/")
        if base.startswith("https://"):
            base = "wss://" + base[8:]
        elif base.startswith("http://"):
            base = "ws://" + base[7:]
        elif not base.startswith(("ws://", "wss://")):
            base = "wss://" + base
        return f"{base}/v1/receive/{self.phone}"

    def _auth_headers(self) -> dict[str, str]:
        if self.user is None or self.password is None:
            return {}
        auth_string = f"{self.user}:{self.password}"
        encoded = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        return {"Authorization": f"Basic {encoded}"}

    def _base_url(self) -> str:
        return self.url.strip().rstrip("/")
