# expert_op4grid_recommender/action_evaluation/rules.py
#!/usr/bin/python3
# Copyright (c) 2025-2026, RTE (https://www.rte-france.com)
# See AUTHORS.txt
# This Source Code Form is subject to the terms of the Mozilla Public License, version 2.0.
# If a copy of the Mozilla Public License, version 2.0 was not distributed with this file,
# you can obtain one at http://mozilla.org/MPL/2.0/.
# SPDX-License-Identifier: MPL-2.0
# This file is part of expert_op4grid_recommender, Expert system analyzer based on ExpertOp4Grid principles. ⚡️ This tool builds overflow graphs,
# applies expert rules to filter potential actions, and identifies relevant corrective measures to alleviate line overloads.

import numpy as np
from expert_op4grid_recommender.utils.data_utils import StateInfo
from expert_op4grid_recommender.utils.load_training_data import aux_prevent_asset_reconnection
from expert_op4grid_recommender.action_evaluation.classifier import ActionClassifier #identify_action_type
from expert_op4grid_recommender.utils.simulation import (
    check_rho_reduction, check_rho_reduction_with_baseline,
    create_default_action, compute_baseline_simulation
)
from typing import Dict, Any, List, Tuple, Optional, Callable, Set

class ActionRuleValidator:
    """
    Validates and categorizes grid actions based on expert rules and grid context.

    This class holds the necessary grid context (observation, critical paths, hubs)
    and provides methods to apply filtering rules to a set of candidate actions.
    The main method is `categorize_actions`, which iterates through actions,
    verifies them against rules, and optionally simulates filtered actions to
    check for potential effectiveness. It uses an ActionClassifier instance to determine action types.

    Attributes:
        obs (Any): The Grid2Op observation object for the current state.
        action_space (Callable): The Grid2Op action space object.
        classifier (ActionClassifier): An initialized ActionClassifier instance.
        hubs (List[str]): List of critical hub substation names.
        lines_constrained_path (List[str]): Lines on the constrained path.
        nodes_constrained_path (List[str]): Nodes on the constrained path.
        lines_dispatch (List[str]): Lines on dispatch paths.
        nodes_dispatch_path (List[str]): Nodes on dispatch paths.
        by_description (bool): Flag indicating how to identify action types.
    """
    def __init__(self,
                 obs: Any,  # grid2op.Observation or similar mock
                 action_space: Callable,
                 classifier: ActionClassifier,  # Accept classifier instance
                 hubs: List[str],
                 paths: Tuple[Tuple[List[str], List[str]], Tuple[List[str], List[str]]],
                 by_description: bool = True):
        """
        Initializes the ActionRuleValidator.

        Args:
            obs: The Grid2Op observation object.
            action_space: The Grid2Op action space object.
            classifier: An initialized ActionClassifier instance.
            hubs: List of critical hub substation names.
            paths: Tuple containing constrained and dispatch paths.
            by_description: Flag passed to the classifier's identify_action_type.
        """
        self.obs = obs
        self.action_space = action_space
        self.classifier = classifier  # Store the classifier instance
        self.by_description = by_description  # Store preference for classifier

        # Store lists for compatibility
        self.lines_constrained_path, self.nodes_constrained_path = paths[0]
        self.lines_dispatch, self.nodes_dispatch_path = paths[1]
        self.hubs = hubs

        # Pre-compute sets for O(1) lookup - significant speedup for large grids
        self._lines_constrained_set = set(self.lines_constrained_path)
        self._lines_dispatch_set = set(self.lines_dispatch)
        self._hubs_set = set(hubs)
        self._nodes_constrained_set = set(self.nodes_constrained_path)
        self._nodes_dispatch_set = set(self.nodes_dispatch_path)

        # Cache sub_name to index mapping for fast topology lookups
        self._sub_name_to_idx = {name: idx for idx, name in enumerate(obs.name_sub)}

        # Cache line_status map for line status checks
        self._line_status_map = {name: status for name, status in zip(obs.name_line, obs.line_status)}

    def localize_line_action(self, lines: List[str]) -> str:
        """
        Determines the location category of a line action relative to critical graph paths.

        Uses the pre-computed sets for O(1) lookup.

        Args:
            lines: A list of line identifiers (e.g., names) involved in the action.

        Returns:
            "constrained_path", "dispatch_path", or "out_of_graph".
        """
        # Check intersection with pre-computed sets - O(len(lines)) instead of O(len(lines) * len(paths))
        for line in lines:
            if line in self._lines_constrained_set:
                return "constrained_path"
        for line in lines:
            if line in self._lines_dispatch_set:
                return "dispatch_path"
        return "out_of_graph"

    def localize_coupling_action(self, action_subs: List[str]) -> str:
        """
        Determines the location category of a coupling action relative to critical nodes.

        Uses the pre-computed sets for O(1) lookup.

        Args:
            action_subs: A list containing the name(s) of the substation(s) involved.

        Returns:
            "hubs", "constrained_path", "dispatch_path", or "out_of_graph".
        """
        # Check intersection with pre-computed sets - O(len(subs)) instead of O(len(subs) * len(paths))
        for sub in action_subs:
            if sub in self._hubs_set:
                return "hubs"
        for sub in action_subs:
            if sub in self._nodes_constrained_set:
                return "constrained_path"
        for sub in action_subs:
            if sub in self._nodes_dispatch_set:
                return "dispatch_path"
        return "out_of_graph"

    def check_rules(self, action_type: str, localization: str, subs_topology: List[List[int]]) -> Tuple[bool, Optional[str]]:
        """
        Checks if a given grid action violates predefined expert rules.

        (Docstring identical to the original function - see previous response)

        Args:
            action_type: The type of the action (e.g., "open_line").
            localization: The location category (e.g., "constrained_path").
            subs_topology: List of topology vectors for involved substations (before action).

        Returns:
            Tuple (do_filter_action, broken_rule).
        """
        do_filter_action = False
        broken_rule = None
        if "load" not in action_type:
            is_topo_subs_one_node = all(len(set(sub_topo) - {-1, 0}) == 1 for sub_topo in subs_topology)
            rules = {
                "No action out of the overflow graph": (localization == "out_of_graph"),
                "No line reconnection on constrained path": ("line" in action_type and "close" in action_type and localization == "constrained_path"),
                "No line disconnection on dispatch path": ("line" in action_type and "open" in action_type and localization == "dispatch_path"),
                "No node merging on constrained path": ("coupling" in action_type and "close" in action_type and localization == "constrained_path"),
                "No node splitting on dispatch path": ("coupling" in action_type and "open" in action_type and localization == "dispatch_path" and is_topo_subs_one_node),
            }
            for rule_name, is_broken in rules.items():
                if is_broken:
                    do_filter_action = True
                    broken_rule = rule_name
                    break
        return do_filter_action, broken_rule

    def verify_action(self, action_desc: Dict[str, Any], subs_topology: List[List[int]]) -> Tuple[bool, Optional[str]]:
        """
        Verifies if a single grid action should be filtered based on type, location, and rules.

        Internal method used by `categorize_actions`. Uses instance attributes for context.

        Args:
            action_desc: Dictionary containing the action's description and content.
            subs_topology: List of topology vectors before the action.

        Returns:
            Tuple (do_filter_action, broken_rule).
        """
        action_type = self.classifier.identify_action_type(action_desc, self.by_description)

        do_filter_action = False
        broken_rule = None

        if "line" in action_type:
            grid2op_actions_set_bus = action_desc.get("content", {}).get("set_bus", {})
            lines = list(grid2op_actions_set_bus.get("lines_or_id", {}).keys()) + \
                    list(grid2op_actions_set_bus.get("lines_ex_id", {}).keys())
            if lines:
                # Use cached line_status_map instead of rebuilding it each time
                current_statuses = np.array([self._line_status_map.get(ln, True) for ln in lines])
                if "open" in action_type and np.all(~current_statuses):
                    do_filter_action, broken_rule = True, "No disconnection of a line already disconnected"
                elif "close" in action_type and np.all(current_statuses):
                    do_filter_action, broken_rule = True, "No reconnection of a line already connected"
            localization = self.localize_line_action(lines)

        elif "coupling" in action_type and "VoltageLevelId" in action_desc:
            action_subs = [action_desc["VoltageLevelId"]]
            localization = self.localize_coupling_action(action_subs)
        else:
            localization = "unknown"

        if not do_filter_action:
            do_filter_action, broken_rule_expert = self.check_rules(action_type, localization, subs_topology)
            if do_filter_action:
                broken_rule = broken_rule_expert

        return do_filter_action, broken_rule

    def categorize_actions(self,
                            dict_action: Dict[str, Dict[str, Any]],
                            # Simulation context passed here
                            timestep: int,
                            defauts: List[str],
                            overload_ids: List[int],
                            lines_reco_maintenance: List[str],
                            lines_we_care_about: Optional[List[str]] = None,
                            do_simulation_checks: bool = True,
                            ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
        """
        Categorizes actions from a dictionary into 'filtered' and 'unfiltered' sets.

        Iterates through `dict_action`, calls `self.verify_action` for each, and
        optionally simulates filtered actions using `check_rho_reduction` to gather
        additional information.

        Optimized version with:
        - Baseline simulation computed once and reused for all filtered actions
        - Pre-computed actions (act_defaut, act_reco_maintenance) created once
        - Cached sub_name to index mapping for fast topology lookups

        Args:
            dict_action: Dictionary mapping action IDs to action descriptions.
            timestep: Current simulation timestep for simulation checks.
            defauts: List of contingency line names for simulation checks.
            overload_ids: List of overloaded line indices for simulation checks.
            lines_reco_maintenance: List of maintenance lines for simulation checks.
            lines_we_care_about: Optional list of lines to monitor in simulations.

        Returns:
            Tuple (actions_to_filter, actions_unfiltered).
        """
        actions_to_filter = {}
        actions_unfiltered = {}

        # Pre-compute these once outside the loop (major optimization)
        act_defaut = None
        act_reco_main_obj = None
        baseline_rho = None

        if do_simulation_checks:
            # Create actions once instead of per-filtered-action
            act_defaut = create_default_action(self.action_space, defauts)
            act_reco_main_obj = self.action_space({"set_line_status": [(lr, 1) for lr in lines_reco_maintenance]})

            # Compute baseline simulation once (the biggest optimization!)
            baseline_rho, _ = compute_baseline_simulation(
                self.obs, timestep, act_defaut, act_reco_main_obj, overload_ids
            )

        # Track actions that need simulation checks (deferred processing)
        filtered_actions_needing_simulation = []

        for action_id, action_desc in dict_action.items():
            subs_topology = []
            if "VoltageLevelId" in action_desc:
                action_subs = [action_desc["VoltageLevelId"]]
                # Use cached sub_name_to_idx mapping instead of np.where
                subs_topology = []
                for sn in action_subs:
                    idx = self._sub_name_to_idx.get(sn)
                    if idx is not None:
                        subs_topology.append(self.obs.sub_topology(idx))

            do_filter_action, broken_rule = self.verify_action(action_desc, subs_topology)
            description = action_desc.get("description_unitaire", action_desc.get("description", ""))

            if do_filter_action:
                # Defer simulation to batch processing
                filtered_actions_needing_simulation.append({
                    'action_id': action_id,
                    'action_desc': action_desc,
                    'description': description,
                    'broken_rule': broken_rule
                })
            else:
                actions_unfiltered[action_id] = {"description_unitaire": description}

        # Process simulations for filtered actions using cached baseline
        for item in filtered_actions_needing_simulation:
            action_id = item['action_id']
            action_desc = item['action_desc']
            description = item['description']
            broken_rule = item['broken_rule']

            is_rho_reduction = None
            if do_simulation_checks and baseline_rho is not None:
                try:
                    action = self.action_space(action_desc["content"])
                except Exception as e:
                    print(f"Warning: Could not create action object for {action_id}: {e}")
                    is_rho_reduction = None
                else:
                    state = StateInfo()
                    action = aux_prevent_asset_reconnection(self.obs, state, action)

                    # Use the optimized function with pre-computed baseline
                    is_rho_reduction, _ = check_rho_reduction_with_baseline(
                        self.obs, timestep, act_defaut, action, overload_ids,
                        act_reco_main_obj, baseline_rho, lines_we_care_about,
                        verbose=False  # Reduce output noise for filtered actions
                    )

                if is_rho_reduction:
                    print(f"INFO: Action '{description}' was filtered by rule '{broken_rule}' but showed potential rho reduction.")

            actions_to_filter[action_id] = {
                "description_unitaire": description,
                "broken_rule": broken_rule,
                "is_rho_reduction": is_rho_reduction
            }

        return actions_to_filter, actions_unfiltered