"""Discord transport plugin for takopi."""

from __future__ import annotations

__version__ = "0.4.0"

from .backend import BACKEND

__all__ = ["BACKEND", "__version__"]
