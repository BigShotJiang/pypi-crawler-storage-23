"""
Claude Code Pet Companion - Setup Script

For installation via pip:
    pip install claude-pet-companion

For development:
    pip install -e .
"""
from setuptools import setup, find_packages
from pathlib import Path


# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read version from plugin.json
import json
plugin_file = Path(__file__).parent / ".claude-plugin" / "plugin.json"
if plugin_file.exists():
    with open(plugin_file, "r", encoding="utf-8") as f:
        plugin_data = json.load(f)
        version = plugin_data.get("version", "1.0.0")
else:
    version = "1.0.0"


setup(
    name="claude-pet-companion",
    version=version,
    description="A pixel-art virtual pet plugin for Claude Code",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Claude Code Community",
    author_email="noreply@example.com",
    url="https://github.com/anthropics/claude-pet-companion",
    license="MIT",
    keywords="claude-code plugin pet companion pixel-art gamification",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "claude_pet_companion": [
            "webview/**/*",
            "data/*.json",
            ".claude-plugin/*.json",
            "hooks/*.json",
            "agents/*.md",
            "skills/**/*",
        ],
    },
    install_requires=[
        # No external dependencies - uses only Python standard library
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "mypy>=0.990",
        ],
    },
    entry_points={
        "console_scripts": [
            "claude-pet=claude_pet_companion.cli:main",
            "pet-companion=claude_pet_companion.cli:main",
        ],
    },
    project_urls={
        "Bug Reports": "https://github.com/anthropics/claude-pet-companion/issues",
        "Source": "https://github.com/anthropics/claude-pet-companion",
        "Documentation": "https://github.com/anthropics/claude-pet-companion/blob/main/README.md",
    },
)
