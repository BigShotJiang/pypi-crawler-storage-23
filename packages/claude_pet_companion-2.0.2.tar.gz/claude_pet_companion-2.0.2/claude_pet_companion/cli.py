#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Claude Code Pet Companion - CLI

Command-line interface for the pet companion.
"""
import sys
import os


class PetState:
    """宠物状态类"""
    def __init__(self):
        self.name = 'Claude'
        self.mood = 'happy'
        self.hunger = 100
        self.happiness = 100
        self.energy = 100
        self.level = 1
        self.xp = 0
        self.xp_to_next = 100

    def print_status(self):
        """打印状态"""
        print(f"""
🤖 {self.name} - Level {self.level}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Mood: {self.mood}
   Hunger: {self.hunger}/100
   Happiness: {self.happiness}/100
   Energy: {self.energy}/100
   XP: {self.xp}/{self.xp_to_next}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")


def print_status():
    """打印宠物状态"""
    state = PetState()
    state.print_status()


def main():
    """主入口 - 启动桌面宠物"""
    from claude_pet_companion.claude_pet_hd import ClaudeCodePetHD

    print("Starting Claude Code Pet HD Enhanced...")
    pet = ClaudeCodePetHD()
    pet.run()


if __name__ == "__main__":
    main()
