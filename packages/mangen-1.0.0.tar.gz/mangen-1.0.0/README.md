# mangen ⚡

[![PyPI Version](https://img.shields.io/pypi/v/mangen.svg)](https://pypi.org/project/mangen/)
[![Python Versions](https://img.shields.io/pypi/pyversions/mangen.svg)](https://pypi.org/project/mangen/)
[![CI Status](https://github.com/ash1ra/mangen/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME/actions)

**mangen** is a fast, reliable, and multithreaded CLI tool designed to generate file manifests (lists of file paths) for Machine Learning and Deep Learning datasets.

Whether you are preparing a small local dataset or parsing a massive image corpus like ImageNet, `mangen` handles recursive scanning, multithreading, path formatting, and Train/Val/Test splitting out of the box.

## ✨ Features

* 🚀 **Blazing Fast**: Uses multithreading to parallelize I/O operations and scan huge directory trees efficiently.
* ✂️ **Portable Datasets**: Easily strip absolute path prefixes to generate relative paths (`--strip-prefix`), making your manifests portable across different machines and servers.
* 🔀 **ML-Ready Splits**: Built-in shuffling and automatic Train/Validation/Test dataset splitting (`--split`).
* 🛡️ **Robust & Safe**: Thread-safe operations, strict path validation, and clean fallback mechanisms.

## Motivation

...

## 📦 Installation

You can install `mangen` directly from PyPI using `pip`:

```bash
pip install mangen
```

Or, if you use `uv` (recommended for CLI tools):

```bash
uv tool install mangen
```

## 🚀 Quick Start

Generate a manifest of all images in a dataset directory:

```bash
mangen -i ./datasets/ImageNet/train -o manifest.txt
```

## 💡 Advanced Usage Examples

### 1. Multithreaded Scanning

Speed up scanning for datasets with heavily nested directories (like ImageNet) by utilizing multiple threads and recursive search:

```bash
mangen -i ./datasets/ImageNet/train -o train_paths.txt -t 8 -r
```

### 2. Making Paths Portable (Relative Paths)

If your absolute path is `/Users/ml_engineer/projects/data/images/cat.jpg`, but you want the manifest to only contain `data/images/cat.jpg`:

```bash
mangen -i /Users/ml_engineer/projects/data -o dataset.txt --strip-prefix /Users/ml_engineer/projects/
```

### 3. Creating Train/Val/Test Splits

Automatically shuffle the dataset and split it into training (70%), validation (20%), and testing (10%) sets:

```bash
mangen -i ./dataset -o manifest.txt --shuffle --split 0.7 0.2 0.1
```

### 4. Custom File Extensions

Override the default extensions to scan for audio, text, or any other formats:

```bash
mangen -i ./audio_dataset -o audio_manifest.txt -e wav mp3 flac
```

## 🛠️ CLI Reference


