# SeleniumAuto

A Python wrapper for Selenium WebDriver with simplified API for browser automation.

## Installation

```bash
pip install selenium_auto
```

## Quick Start

```python
from selenium_auto import SeleniumAuto

# Create instance
auto = SeleniumAuto()

# Start browser
driver = auto.get_driver()

# Navigate to webpage
auto.get("https://www.example.com")

# Get element
element = auto.get_element("//input[@id='username']")

# Input text
auto.send_keys("test_user", path="//input[@id='username']")

# Click element
auto.click(path="//button[@id='submit']")

# Close browser
auto.close()
```

## Configure Chrome Driver Path

After first installation, you need to configure Chrome Driver path:

```bash
# Set Chrome Driver path
selenium_auto set_driver "C:\path\to\chromedriver.exe"

# Get current configured path
selenium_auto get_driver

# Check configuration status
selenium_auto check
```

> **Note**: If path is not set on first use, a warning will be displayed and an error will be raised.

## API Reference

### Browser Driver

```python
# Start Chrome (all parameters have default values)
driver = auto.get_driver(
    headless=False,           # Headless mode
    disable_gpu=True,         # Disable GPU
    disable_images=False,     # Disable images
    download_dir=None,       # Download directory
    proxy=None,              # Proxy address
    expire_minute=None,      # Driver expiration time (minutes)
    extension_path=None,     # Extension path
    chrome_driver_path=None  # Driver path (read from config)
)

# Start Edge
driver = auto.get_edge_driver(...)

# Close browser
auto.close(timeout=60)
```

### Element Operations

```python
# Get single element
element = auto.get_element("//xpath/path")
element = auto.get_element("//xpath/path", by='css')

# Get multiple elements
elements = auto.get_elements("//xpath/path")

# Input text
auto.send_keys("text", path="//input[@id='test']")
auto.send_keys("text", element=element, valid=False)

# Click
auto.click(path="//button[@id='submit']")
auto.click(element=element, check_path="//div[@id='result']")

# Clear input
auto.clear(path="//input[@id='test']")
```

### Wait Conditions

```python
# Wait for element to appear
auto.wait_element_appear("//div[@id='content']")

# Wait for element to disappear
auto.wait_element_disappear("//div[@id='loading']")

# Wait for element to be selected
auto.wait_is_selected("//input[@type='checkbox']")

# Wait for URL changes
auto.wait_url("https://example.com/page")
auto.wait_url_contains("/dashboard")
auto.wait_url_startswith("https://")
auto.wait_url_endswith(".html")

# Wait for window number
auto.wait_window_num(2)

# Wait for input value
auto.wait_value(element, "expected_value")
```

### Window Operations

```python
# Switch window
auto.switch_window(1)  # Switch to second window

# Keep one window, close others
auto.keep_one_window(0)  # Keep first window
```

### XPath Query

```python
# Get single result
result = auto.xpath_one("//title/text()")

# Get all results
results = auto.xpath_all("//div[@class='item']")

# Union results
text = auto.xpath_union("//div[@class='item']//text()", sep=', ')
```

### Network Requests

```python
# Navigate to URL
auto.get("https://example.com")
auto.get("https://example.com", check_netloc=True, check_path=True)

# Send async request (via browser)
result = auto.send_request(
    url="https://api.example.com/submit",
    method="POST",
    form_data={"key1": "value1", "key2": "value2"}
)
```

### Print PDF

```python
# Print current page to PDF
auto.download_print_pdf("output.pdf")
auto.download_print_pdf("output.pdf", width=8.27, height=11.69)  # A4
auto.download_print_pdf("output.pdf", print_background=True)
```

### Other Utilities

```python
# Check if driver is expired
if auto.is_expire():
    print("Driver expired")

# Select all matching elements
auto.select_all("//input[@type='checkbox']")
```

## CLI Tools

After installation, you can use `selenium_auto` command directly:

```bash
# Set Chrome Driver path
selenium_auto set_driver "C:\chromedriver.exe"

# Get current path
selenium_auto get_driver

# Check configuration
selenium_auto check
```

## Dependencies

- selenium
- lxml
- psutil

## License

MIT
