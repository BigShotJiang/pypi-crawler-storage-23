"""
等待与重试机制模块
提供各种等待条件和自动重试功能
"""

import time
import urllib.parse as up
from selenium.webdriver.remote import webdriver
from selenium_auto import driver


class Wait(driver.Driver):
    """等待与重试机制类"""

    @staticmethod
    def _retry_inner(function, timeout=10, raise_error=True, retry_delay=0.1):
        """
        内部重试机制

        参数:
            function: 要执行的函数
            timeout: 超时时间（秒）
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔（秒）

        返回:
            函数执行结果
        """
        start_time = time.time()
        while True:
            try:
                result = function()
                if result:
                    return result
            except:
                pass

            if time.time() - start_time >= timeout:
                if raise_error:
                    result = function()
                    if not result:
                        raise Exception('Retry Error')
                    return result
                else:
                    return False
            else:
                time.sleep(retry_delay)

    def wait_element_appear(self, path, by='xpath', timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待元素出现

        参数:
            path: 元素定位路径
            by: 定位方式（默认 xpath）
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            元素出现返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.find_elements(by=by, value=path),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_is_selected(self, path, by='xpath', timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待元素被选中

        参数:
            path: 元素定位路径
            by: 定位方式
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            元素被选中返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.find_element(by=by, value=path).is_selected(),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_is_not_selected(self, path, by='xpath', timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待元素取消选中

        参数:
            path: 元素定位路径
            by: 定位方式
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            元素取消选中返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: not self.driver.find_element(by=by, value=path).is_selected(),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_element_disappear(self, path, by='xpath', timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待元素消失

        参数:
            path: 元素定位路径
            by: 定位方式
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            元素消失返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: not self.driver.find_elements(by=by, value=path),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 完全匹配

        参数:
            url: 目标 URL
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            URL 匹配返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.current_url == url,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_startswith(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 以指定内容开头

        参数:
            url: URL 前缀
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            匹配返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.current_url.startswith(url),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_endswith(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 以指定内容结尾

        参数:
            url: URL 后缀
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            匹配返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.current_url.endswith(url),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_contains(self, content, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 包含指定内容

        参数:
            content: 要包含的内容
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            包含返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: content in self.driver.current_url,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_scheme(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 协议匹配

        参数:
            url: 目标 URL
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            协议匹配返回 True，否则返回 False
        """
        scheme = up.urlsplit(url).scheme
        result = self._retry_inner(
            function=lambda: up.urlsplit(self.driver.current_url).scheme == scheme,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_netloc(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 域名匹配

        参数:
            url: 目标 URL
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            域名匹配返回 True，否则返回 False
        """
        netloc = up.urlsplit(url).netloc
        result = self._retry_inner(
            function=lambda: up.urlsplit(self.driver.current_url).netloc == netloc,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_path(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 路径匹配

        参数:
            url: 目标 URL
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            路径匹配返回 True，否则返回 False
        """
        def inner():
            path = up.urlsplit(url).path
            current_path = up.urlsplit(self.driver.current_url).path
            if path == '/':
                path = ''
            if current_path == '/':
                current_path = ''
            return path == current_path

        result = self._retry_inner(
            function=inner,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_url_query(self, url, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待 URL 查询参数匹配

        参数:
            url: 目标 URL
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            查询参数匹配返回 True，否则返回 False
        """
        query = up.urlsplit(url).query
        result = self._retry_inner(
            function=lambda: up.urlsplit(self.driver.current_url).query == query,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_value(self, element: webdriver.WebElement, value, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待元素值匹配

        参数:
            element: WebElement 实例
            value: 期望的值
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            值匹配返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: element.get_attribute('value') == value,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_window_num(self, window_num: int, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待窗口数量匹配

        参数:
            window_num: 期望的窗口数量
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            数量匹配返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: len(self.driver.window_handles) == window_num,
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False

    def wait_switch_window(self, window_index: int, timeout=10, raise_error=True, retry_delay=0.1) -> bool:
        """
        等待窗口切换完成

        参数:
            window_index: 目标窗口索引
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            切换成功返回 True，否则返回 False
        """
        result = self._retry_inner(
            function=lambda: self.driver.current_window_handle == self.driver.window_handles[window_index],
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return True if result else False
