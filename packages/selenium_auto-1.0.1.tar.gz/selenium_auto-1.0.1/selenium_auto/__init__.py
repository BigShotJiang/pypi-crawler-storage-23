"""
SeleniumAuto - Selenium WebDriver Wrapper Library
Provides simplified API for browser automation
"""

from selenium_auto import action
from selenium_auto import element
from selenium_auto import xpath
from selenium_auto import request
from selenium_auto import wait
from selenium_auto import close
from selenium_auto import config


class SeleniumAuto(
    action.Action,
    element.Element,
    xpath.Xpath,
    request.Request,
    wait.Wait,
):
    """Browser automation main class, inherits all functional modules"""
    pass
