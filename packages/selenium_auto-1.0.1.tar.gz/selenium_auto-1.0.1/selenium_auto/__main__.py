"""
SeleniumAuto CLI Entry Module
Provides CLI commands for configuration management
"""

import sys
from selenium_auto.config import get_driver_path, set_driver_path, config_exists, get_config_path


def main():
    """Main function, handles command line arguments"""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  selenium_auto set_driver <path>  - Set Chrome Driver path")
        print("  selenium_auto get_driver         - Get Chrome Driver path")
        print("  selenium_auto check             - Check configuration status")
        sys.exit(1)

    command = sys.argv[1]

    if command == 'set_driver':
        if len(sys.argv) < 3:
            print("Error: Please provide Chrome Driver path")
            print("Usage: selenium_auto set_driver <path>")
            sys.exit(1)
        driver_path = sys.argv[2]
        set_driver_path(driver_path)
        print(f"Chrome Driver path has been set to: {driver_path}")

    elif command == 'get_driver':
        if config_exists():
            driver_path = get_driver_path()
            if driver_path:
                print(f"Chrome Driver path: {driver_path}")
            else:
                print("CHROME_DRIVER_PATH not found in config file")
                print("Please run 'selenium_auto set_driver <path>' to set it")
        else:
            print("Config file does not exist")
            print("Please run 'selenium_auto set_driver <path>' to set Chrome Driver path")

    elif command == 'check':
        if config_exists():
            config_path = get_config_path()
            print(f"Config file location: {config_path}")
            driver_path = get_driver_path()
            if driver_path:
                print(f"Chrome Driver path: {driver_path}")
            else:
                print("Warning: CHROME_DRIVER_PATH not found in config file")
        else:
            config_path = get_config_path()
            print(f"Config file does not exist")
            print(f"Config file will be created at: {config_path}")
            print("Please run 'selenium_auto set_driver <path>' to set Chrome Driver path")

    else:
        print(f"Unknown command: {command}")
        print("Available commands: set_driver, get_driver, check")
        sys.exit(1)


if __name__ == '__main__':
    main()
