"""
元素定位模块
提供元素查找和获取功能
"""

from selenium_auto import wait


class Element(wait.Wait):
    """元素定位类"""

    def get_element(self, path: str, by='xpath', timeout=20, raise_error=True, retry_delay=0.1):
        """
        获取单个元素

        参数:
            path: 元素定位路径
            by: 定位方式（默认 xpath）
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            WebElement 实例
        """
        element = self._retry_inner(
            function=lambda: self.driver.find_element(by=by, value=path),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return element

    def get_elements(self, path: str, by='xpath', timeout=20, raise_error=True, retry_delay=0.1):
        """
        获取多个元素

        参数:
            path: 元素定位路径
            by: 定位方式
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            WebElement 列表
        """
        elements = self._retry_inner(
            function=lambda: self.driver.find_elements(by=by, value=path),
            raise_error=raise_error,
            timeout=timeout,
            retry_delay=retry_delay,
        )
        return elements
