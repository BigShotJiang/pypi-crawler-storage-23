"""
AutoBase 类模块
保留用于未来扩展的基类
"""


class AutoBase():
    """自动化基类"""

    def __init__(self):
        """初始化基类"""
        pass
