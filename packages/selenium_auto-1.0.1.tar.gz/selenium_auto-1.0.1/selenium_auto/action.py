"""
页面交互操作模块
提供输入、点击、窗口切换等交互功能
"""

import time
from copy import deepcopy
from selenium.webdriver.remote import webdriver
from selenium_auto import element as _element


class Action(_element.Element):
    """页面交互操作类"""

    def clear(self, path=None, element: webdriver.WebElement = None, timeout=10, raise_error=True,
              retry_delay=0.1) -> bool:
        """
        清空输入框内容

        参数:
            path: 元素路径
            element: WebElement 实例（与 path 二选一）
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            成功返回 True，否则返回 False
        """
        if not path and not element:
            msg = 'path与element不能同时为空'
            raise Exception(msg)

        def function():
            if not element:
                this_element = self.get_element(path=path, timeout=timeout, raise_error=raise_error,
                                                retry_delay=retry_delay)
            else:
                this_element = element
            this_element.clear()
            wait_result = self.wait_value(this_element, value='',
                                          timeout=2, raise_error=True, retry_delay=0.1)
            return True if wait_result else False

        return self._retry_inner(
            function=function,
            timeout=timeout,
            raise_error=raise_error,
            retry_delay=retry_delay,
        )

    def send_keys(self, value: str, path: str = None, element: webdriver.WebElement = None, timeout=10,
                  raise_error=True, retry_delay=0.5, valid=True) -> bool:
        """
        向输入框发送文本

        参数:
            value: 要输入的文本
            path: 元素路径
            element: WebElement 实例
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔
            valid: 是否验证输入成功

        返回:
            成功返回 True，否则返回 False
        """
        value = str(value)
        if not path and not element:
            msg = 'path与element不能同时为空'
            raise Exception(msg)
        start_time = time.time()

        def function():
            if not element:
                this_element = self.get_element(path=path, timeout=timeout, raise_error=raise_error,
                                                retry_delay=retry_delay)
            else:
                this_element = element

            timeout_left = int(timeout - time.time() + start_time)
            self.clear(element=this_element, timeout=timeout_left)

            this_element.send_keys(value)
            if not valid:
                return True
            if self.wait_value(element=this_element, value=value,
                               timeout=2, raise_error=True, retry_delay=0.1):
                return True
            return False

        return self._retry_inner(
            function=function,
            timeout=timeout,
            raise_error=raise_error,
            retry_delay=retry_delay,
        )

    def click(self, path: str = None, element: webdriver.WebElement = None, check_path: str = None, check_by='xpath',
              timeout=20, raise_error=True,
              retry_delay=0.5) -> bool:
        """
        点击元素

        参数:
            path: 元素路径
            element: WebElement 实例
            check_path: 点击后等待出现的元素路径
            check_by: 检查元素的定位方式
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            成功返回 True，否则返回 False
        """
        start_time = time.time()

        def function():
            if not element:
                this_element = self.get_element(path=path, timeout=timeout, raise_error=raise_error,
                                                retry_delay=retry_delay)
            else:
                this_element = element

            this_element.click()
            if not check_path:
                return True

            timeout_left = int(timeout - time.time() + start_time)
            return self.wait_element_appear(
                by=check_by,
                path=check_path,
                timeout=timeout_left,
                retry_delay=retry_delay,
            )

        return self._retry_inner(
            function=function,
            timeout=timeout,
            raise_error=raise_error,
            retry_delay=retry_delay,
        )

    def switch_window(self, window_index: int, timeout=10, raise_error=True, retry_delay=0.2) -> bool:
        """
        切换到指定窗口

        参数:
            window_index: 目标窗口索引
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            成功返回 True，否则返回 False
        """
        start_time = time.time()

        def function():
            self.driver.switch_to.window(self.driver.window_handles[window_index])
            timeout_left = int(timeout - time.time() + start_time)
            return self.wait_switch_window(
                window_index=window_index,
                timeout=timeout_left,
                raise_error=raise_error,
                retry_delay=retry_delay,
            )

        return self._retry_inner(
            function=function,
            timeout=timeout,
            raise_error=raise_error,
            retry_delay=retry_delay,
        )

    def keep_one_window(self, window_index: int, timeout=10, raise_error=True, retry_delay=0.2) -> bool:
        """
        保留指定窗口，关闭其他窗口

        参数:
            window_index: 要保留的窗口索引
            timeout: 超时时间
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔

        返回:
            成功返回 True，否则返回 False
        """
        window_handles = deepcopy(self.driver.window_handles)
        keep_window_handle = self.driver.window_handles[window_index]

        def function():
            for window_handle in window_handles:
                if window_handle == keep_window_handle:
                    continue
                else:
                    self.driver.switch_to.window(window_handle)
                    self.driver.close()
            self.driver.switch_to.window(keep_window_handle)
            if self.driver.current_window_handle == keep_window_handle:
                return True
            else:
                return False

        return self._retry_inner(
            function=function,
            timeout=timeout,
            raise_error=raise_error,
            retry_delay=retry_delay,
        )

    def select_all(self, path, timeout=20):
        """
        选择所有匹配的元素

        参数:
            path: 元素路径
            timeout: 超时时间
        """
        start_time = time.time()
        while True:
            is_select_all = True
            elements = self.get_elements(path=path, raise_error=False, timeout=timeout)
            if elements:
                for element in elements:
                    try:
                        if not element.is_selected():
                            is_select_all = False
                            self.click(element=element)
                    except:
                        is_select_all = False
            else:
                is_select_all = False
            if is_select_all:
                return None
            else:
                if time.time() - start_time > timeout:
                    msg = '无法选择全部'
                    raise Exception(msg)
                else:
                    time.sleep(1)
