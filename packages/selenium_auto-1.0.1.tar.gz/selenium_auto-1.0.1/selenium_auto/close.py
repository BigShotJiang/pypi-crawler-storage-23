"""
进程管理模块
提供 Chrome 进程管理和系统资源监控功能
"""

import subprocess
import time
import psutil


def close_chrome_all():
    """关闭所有 Chrome 浏览器进程"""
    subprocess.call("taskkill /F /IM chrome.exe", shell=False)


def count_chrome_processes():
    """
    统计 Chrome 浏览器进程数量

    返回:
        Chrome 进程数量
    """
    chrome_count = 0
    for proc in psutil.process_iter(['pid', 'name']):
        if 'chrome.exe' in proc.info['name'].lower():
            chrome_count += 1
    return chrome_count


def get_cpu_usage_percent():
    """
    获取 CPU 使用率

    返回:
        CPU 使用率百分比
    """
    cpu_usage = psutil.cpu_percent(interval=5)
    return cpu_usage


def close_server(interval_minutes=30, clear_first=False):
    """
    定时关闭 Chrome 浏览器

    参数:
        interval_minutes: 关闭间隔（分钟）
        clear_first: 是否在开始时先关闭一次
    """
    if clear_first:
        close_chrome_all()
    while True:
        time.sleep(interval_minutes * 60)
        close_chrome_all()


if __name__ == '__main__':
    close_chrome_all()
