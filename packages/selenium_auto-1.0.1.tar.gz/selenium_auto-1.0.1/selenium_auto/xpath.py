"""
XPath 解析模块
提供页面源码的 XPath 查询功能
"""

import lxml.etree as le
from selenium_auto import wait


class Xpath(wait.Wait):
    """XPath 解析类"""

    def xpath_one(self, path, content=None, default=None):
        """
        查询单个 XPath 结果

        参数:
            path: XPath 表达式
            content: 可选的页面源码（默认为当前页面）
            default: 未找到时的默认返回值

        返回:
            XPath 匹配的第一个结果
        """
        if content is None:
            content = self.driver.page_source

        if type(content) == str or type(content) == bytes:
            content = le.HTML(content)

        rets = content.xpath(path)
        return rets[0] if rets else default

    def xpath_all(self, path, content=None, strip=False):
        """
        查询多个 XPath 结果

        参数:
            path: XPath 表达式
            content: 可选的页面源码
            strip: 是否去除结果首尾空白

        返回:
            XPath 匹配的结果列表
        """
        if content is None:
            content = self.driver.page_source

        if type(content) == str or type(content) == bytes:
            content = le.HTML(content)

        rets = content.xpath(path)
        if strip:
            ret_strips = []
            for ret in rets:
                ret_strips.append(ret.strip())
            return ret_strips
        else:
            return rets

    def xpath_union(self, path, content=None, sep='', strip=True, default=None):
        """
        合并 XPath 查询结果为字符串

        参数:
            path: XPath 表达式
            content: 可选的页面源码
            sep: 连接符
            strip: 是否去除首尾空白
            default: 未找到时的默认值

        返回:
            合并后的字符串
        """
        rets = self.xpath_all(content=content, path=path, strip=strip)
        if rets:
            return sep.join(rets)
        else:
            return default
