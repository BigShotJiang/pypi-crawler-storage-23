"""
Chrome Driver 管理模块
提供浏览器驱动创建、配置和窗口管理功能
"""

import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium_auto.config import get_driver_path, config_exists


class Driver:
    """浏览器驱动管理类"""

    alive = True

    def __init__(self):
        """初始化驱动管理实例"""
        self.driver = None
        self.driver_ts = None
        self.expire_minute = None

    def get_driver(
            self,
            no_sandbox=True,
            disable_gpu=True,
            disable_images=False,
            headless=False,
            chrome_options=None,
            download_dir: str = None,
            proxy: str = None,
            expire_minute: int = None,
            extension_path: str = None,
            chrome_driver_path: str = None,
    ):
        """
        创建并配置 Chrome 浏览器驱动

        参数:
            no_sandbox: 是否禁用沙箱模式
            disable_gpu: 是否禁用 GPU 硬件加速
            disable_images: 是否禁用图片加载
            headless: 是否使用无头模式运行
            chrome_options: 自定义 Chrome 选项
            download_dir: 下载目录路径
            proxy: 代理地址 (格式: host:port)
            expire_minute: 驱动过期时间（分钟）
            extension_path: 扩展程序路径
            chrome_driver_path: Chrome Driver 路径（默认从配置读取）

        返回:
            WebDriver 实例
        """
        # 获取 Driver 路径：优先使用参数，其次从配置文件读取
        if not chrome_driver_path:
            if config_exists():
                chrome_driver_path = get_driver_path()
            if not chrome_driver_path:
                print("Warning: CHROME_DRIVER_PATH not found in config file")
                print("Please run 'selenium_auto set_driver <path>' to set it")
                raise ValueError("Chrome Driver 路径未配置")

        if not chrome_options:
            chrome_options = webdriver.ChromeOptions()

        # ==================== 反检测设置 ====================
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)

        # 设置真实 User-Agent
        chrome_options.add_argument(
            'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0')

        # 禁用自动化标志
        prefs = {
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False
        }
        chrome_options.add_experimental_option("prefs", prefs)

        # ==================== 下载偏好设置 ====================
        prefs = {
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "plugins.always_open_pdf_externally": True,
            "plugins.plugins_disabled": ["Chrome PDF Viewer"],
            "profile.default_content_setting_values.automatic_downloads": 1,
            "safebrowsing.enabled": False,
            "safebrowsing.disable_download_protection": True,
            "safebrowsing.malware.enabled": False,
            "profile.default_content_setting_values.mixed_script": 1,
            "profile.default_content_setting_values.insecure_forms": 1,
        }
        if download_dir:
            print(f"下载目录: {download_dir}")
            prefs["download.default_directory"] = download_dir
        chrome_options.add_experimental_option("prefs", prefs)

        # ==================== Chrome 启动参数 ====================
        chrome_options.add_argument("--disable-web-security")
        chrome_options.add_argument("--allow-running-insecure-content")
        chrome_options.add_argument("--disable-features=DownloadBubble,DownloadBubbleV2")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")

        # 加载扩展程序
        if extension_path:
            chrome_options.add_argument(f'--load-extension={extension_path}')

        # 可选参数
        if no_sandbox:
            chrome_options.add_argument('--no-sandbox')
        if disable_gpu:
            chrome_options.add_argument('--disable-gpu')
        if disable_images:
            chrome_options.add_argument('blink-settings=imagesEnabled=false')
        if headless:
            chrome_options.add_argument('--headless')

        # 代理设置
        if proxy:
            chrome_options.add_argument(f"proxy-server=socks5://{proxy}")

        # 创建驱动实例
        service = Service(executable_path=chrome_driver_path)
        driver = webdriver.Chrome(
            options=chrome_options,
            service=service,
        )
        driver.set_window_size(1920, 1080)

        # 注入反检测脚本
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": """
            Object.defineProperty(navigator, 'webdriver', {
              get: () => undefined
            })
          """
        })

        self.driver = driver
        self.driver_ts = time.time()
        self.expire_minute = expire_minute
        return self.driver

    def close(self, timeout=60):
        """
        关闭浏览器驱动

        参数:
            timeout: 超时时间（秒）
        """
        self.alive = False
        start_time = time.time()
        while True:
            try:
                self.driver.close()
                self.driver.quit()
                break
            except:
                time.sleep(1)
            if time.time() - start_time >= timeout:
                break

    def is_expire(self) -> bool:
        """
        检查驱动是否已过期

        返回:
            已过期返回 True，未过期返回 False
        """
        if self.expire_minute is None:
            return False
        else:
            return time.time() - self.driver_ts > (self.expire_minute * 60)

    def get_edge_driver(
            self,
            no_sandbox=True,
            disable_gpu=True,
            disable_images=False,
            headless=False,
            chrome_options=None,
            download_dir: str = None,
            proxy: str = None,
            expire_minute: int = None,
            extension_path: str = None,
    ):
        """
        创建并配置 Edge 浏览器驱动

        参数:
            no_sandbox: 是否禁用沙箱模式
            disable_gpu: 是否禁用 GPU 硬件加速
            disable_images: 是否禁用图片加载
            headless: 是否使用无头模式运行
            chrome_options: 自定义 Chrome 选项
            download_dir: 下载目录路径
            proxy: 代理地址
            expire_minute: 驱动过期时间
            extension_path: 扩展程序路径

        返回:
            WebDriver 实例
        """
        if not chrome_options:
            chrome_options = webdriver.ChromeOptions()

        # 加载扩展程序
        if extension_path:
            chrome_options.add_argument(f'--load-extension={extension_path}')

        # 可选参数
        if no_sandbox:
            chrome_options.add_argument('--no-sandbox')
        if disable_gpu:
            chrome_options.add_argument('--disable-gpu')
        if disable_images:
            chrome_options.add_argument('blink-settings=imagesEnabled=false')
        if headless:
            chrome_options.add_argument('--headless')

        # 下载目录
        if download_dir:
            prefs = {"download.default_directory": download_dir}
            chrome_options.add_experimental_option("prefs", prefs)

        # 代理设置
        if proxy:
            chrome_options.add_argument(f"proxy-server=socks5://{proxy}")

        # 创建驱动实例
        driver = webdriver.Edge(
            options=chrome_options,
        )
        driver.set_window_size(1920, 1080)

        # 注入反检测脚本
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": """
            Object.defineProperty(navigator, 'webdriver', {
              get: () => undefined
            })
          """
        })

        self.driver = driver
        self.driver_ts = time.time()
        self.expire_minute = expire_minute
        return self.driver
