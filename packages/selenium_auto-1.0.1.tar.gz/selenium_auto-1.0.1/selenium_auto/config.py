"""
Configuration management module
Handle reading and writing of auto.config config file
"""

import os


# Config file name
CONFIG_FILE = 'auto.config'


def get_config_path():
    """
    Get config file path

    Priority:
    1. Current working directory (user's project directory)
    2. Package directory (in site-packages)
    """
    # Current directory
    config_path = os.path.join(os.getcwd(), CONFIG_FILE)
    if os.path.exists(config_path):
        return config_path

    # Package directory (for pip installed package)
    package_dir = os.path.dirname(os.path.abspath(__file__))
    package_config_path = os.path.join(package_dir, CONFIG_FILE)
    if os.path.exists(package_config_path):
        return package_config_path

    # Return package directory path (even if doesn't exist)
    return package_config_path


def config_exists():
    """检查配置文件是否存在"""
    return os.path.exists(get_config_path())


def get_driver_path():
    """
    从配置文件中读取 Chrome Driver 路径

    返回:
        Chrome Driver 路径字符串
    """
    config_path = get_config_path()
    if not os.path.exists(config_path):
        return None

    with open(config_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line.startswith('CHROME_DRIVER_PATH='):
                return line.split('=', 1)[1].strip()
    return None


def set_driver_path(driver_path):
    """
    将 Chrome Driver 路径写入配置文件

    参数:
        driver_path: Chrome Driver 的路径
    """
    config_path = get_config_path()

    # 如果文件存在，读取现有内容
    lines = []
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

    # 查找并更新或添加 CHROME_DRIVER_PATH
    found = False
    new_lines = []
    for line in lines:
        if line.strip().startswith('CHROME_DRIVER_PATH='):
            new_lines.append(f'CHROME_DRIVER_PATH={driver_path}\n')
            found = True
        else:
            new_lines.append(line)

    if not found:
        new_lines.append(f'CHROME_DRIVER_PATH={driver_path}\n')

    # 写入文件
    with open(config_path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)


def get_driver_path_or_default(default_path=None):
    """
    获取 Driver 路径，如果配置不存在则返回默认路径

    参数:
        default_path: 默认路径

    返回:
        Driver 路径
    """
    driver_path = get_driver_path()
    if driver_path:
        return driver_path
    return default_path


def show_warning():
    """Display configuration warning"""
    if not config_exists():
        print("Warning: Config file auto.config not found")
        print("Please run 'selenium_auto set_driver <path>' to set Chrome Driver path")
        return True
    return False
