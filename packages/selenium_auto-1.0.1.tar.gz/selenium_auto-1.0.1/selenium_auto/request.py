"""
网络请求模块
提供页面导航和异步请求功能
"""

import json
import base64
import os
from selenium_auto import wait


class Request(wait.Wait):
    """网络请求类"""

    def get(self, url, check_scheme=False, check_netloc=True, check_path=True, check_query=True, raise_error=True,
            retry_delay=0.1, timeout=30):
        """
        导航到指定 URL

        参数:
            url: 目标 URL
            check_scheme: 是否检查协议
            check_netloc: 是否检查域名
            check_path: 是否检查路径
            check_query: 是否检查查询参数
            raise_error: 超时后是否抛出异常
            retry_delay: 重试间隔
            timeout: 超时时间

        返回:
            成功返回 True，否则返回 False
        """
        def inner_function():
            self.driver.get(url)
            if check_scheme:
                wait_result = self.wait_url_scheme(
                    url=url, timeout=timeout, retry_delay=retry_delay
                )
                if not wait_result:
                    return wait_result
            if check_netloc:
                wait_result = self.wait_url_netloc(
                    url=url, timeout=timeout, retry_delay=retry_delay
                )
                if not wait_result:
                    return wait_result
            if check_path:
                wait_result = self.wait_url_path(
                    url=url, timeout=timeout, retry_delay=retry_delay
                )
                if not wait_result:
                    return wait_result
            if check_query:
                wait_result = self.wait_url_query(
                    url=url, timeout=timeout, retry_delay=retry_delay
                )
                if not wait_result:
                    return wait_result
            return True

        return self._retry_inner(
            function=inner_function,
            raise_error=raise_error,
            retry_delay=retry_delay,
            timeout=timeout,
        )

    def send_request(self, url, method='POST', form_data=None, timeout=30):
        """
        通过浏览器执行异步 HTTP 请求

        参数:
            url: 请求地址
            method: HTTP 方法（GET/POST）
            form_data: 表单数据字典
            timeout: 超时时间

        返回:
            响应内容（字符串）或错误信息字典
        """
        if form_data is None:
            form_data = {}

        form_data_json = json.dumps(form_data, ensure_ascii=False)

        js_code = f"""
        const formData = new FormData();
        const formDataObj = {form_data_json};

        for (const [key, value] of Object.entries(formDataObj)) {{
            formData.append(key, value);
        }}

        return fetch('{url}', {{
            method: '{method}',
            body: formData
        }})
        .then(res => res.text())
        .then(data => arguments[0](data))
        .catch(err => arguments[0]({{error: err.message}}));
        """

        return self.driver.execute_async_script(js_code)

    def download_print_pdf(self, fp, width=None, height=None, print_background=True, prefer_css_page_size=True,
                            margin_top=None, margin_bottom=None, margin_left=None, margin_right=None):
        """
        将当前页面打印为 PDF 文件

        参数:
            fp: 输出文件路径
            width: 页面宽度（英寸）
            height: 页面高度（英寸）
            print_background: 是否打印背景
            prefer_css_page_size: 是否优先使用 CSS 页面尺寸
            margin_top: 上边距
            margin_bottom: 下边距
            margin_left: 左边距
            margin_right: 右边距
        """
        os.makedirs(os.path.dirname(fp), exist_ok=True)

        options = {
            "printBackground": print_background,
            "preferCSSPageSize": prefer_css_page_size,
        }
        if width is not None:
            options["paperWidth"] = width
        if height is not None:
            options["paperHeight"] = height
        if margin_top is not None:
            options["marginTop"] = margin_top
        if margin_bottom is not None:
            options["marginBottom"] = margin_bottom
        if margin_left is not None:
            options["marginLeft"] = margin_left
        if margin_right is not None:
            options["marginRight"] = margin_right

        pdf_bytes = self.driver.execute_cdp_cmd("Page.printToPDF", options)
        pdf_b64 = pdf_bytes["data"]
        pdf_bytes_decoded = base64.b64decode(pdf_b64)

        with open(fp, "wb") as f:
            f.write(pdf_bytes_decoded)
