"""
Setup configuration file for pip installation
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="selenium_auto",
    version="1.0.1",
    author="decrule",
    author_email="decrule@outlook.com",
    description="A Python wrapper for Selenium WebDriver with simplified API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/decrule/selenium_auto",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "Topic :: Internet :: WWW/HTTP :: Browsers",
    ],
    python_requires=">=3.7",
    install_requires=[
        "selenium>=4.0.0",
        "lxml>=4.9.0",
        "psutil>=5.9.0",
    ],
    entry_points={
        'console_scripts': [
            'selenium_auto=selenium_auto.__main__:main',
        ],
    },
)
