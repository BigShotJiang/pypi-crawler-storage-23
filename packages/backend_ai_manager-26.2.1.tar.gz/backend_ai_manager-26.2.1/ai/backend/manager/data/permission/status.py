from ai.backend.common.data.permission.types import PermissionStatus, RoleStatus

# Re-export RoleStatus from common for backward compatibility
__all__ = ("PermissionStatus", "RoleStatus")
