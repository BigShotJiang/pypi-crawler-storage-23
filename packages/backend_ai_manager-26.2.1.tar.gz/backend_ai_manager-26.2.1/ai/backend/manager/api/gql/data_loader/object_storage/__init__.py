from __future__ import annotations

from .loader import load_object_storages_by_ids

__all__ = [
    "load_object_storages_by_ids",
]
