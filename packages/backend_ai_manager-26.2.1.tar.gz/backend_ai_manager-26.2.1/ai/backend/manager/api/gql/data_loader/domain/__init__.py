from __future__ import annotations

from .loader import load_domains_by_names

__all__ = [
    "load_domains_by_names",
]
