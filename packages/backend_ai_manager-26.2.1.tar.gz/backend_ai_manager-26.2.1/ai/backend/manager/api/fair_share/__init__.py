"""Fair Share REST API package."""

from __future__ import annotations

from .handler import create_app

__all__ = ("create_app",)
