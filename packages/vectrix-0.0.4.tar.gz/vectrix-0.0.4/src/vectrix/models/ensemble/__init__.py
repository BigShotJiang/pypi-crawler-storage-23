"""
Ensemble module
"""

from .variabilityEnsemble import VariabilityPreservingEnsemble

__all__ = ["VariabilityPreservingEnsemble"]
