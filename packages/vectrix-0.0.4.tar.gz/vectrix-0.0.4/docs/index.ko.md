---
template: home.ko.html
title: "Vectrix — 파이썬 제로 설정 시계열 예측"
description: "프로덕션 레벨 시계열 예측 라이브러리. 30+ 모델, 자동 모델 선택, 평탄 예측 방어, Forecast DNA — 한 줄 코드로. 순수 NumPy + SciPy."
hide:
  - navigation
  - toc
---
