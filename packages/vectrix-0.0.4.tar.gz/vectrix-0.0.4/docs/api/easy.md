# Easy API

The simplest way to use Vectrix. One function call for each task.

## Functions

::: vectrix.easy.forecast

::: vectrix.easy.analyze

::: vectrix.easy.regress

::: vectrix.easy.quick_report

## Result Classes

::: vectrix.easy.EasyForecastResult

::: vectrix.easy.EasyAnalysisResult

::: vectrix.easy.EasyRegressionResult
