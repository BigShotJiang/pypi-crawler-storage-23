# Adaptive

Regime detection, self-healing forecasts, business constraints, and Forecast DNA.

## Regime Detection

::: vectrix.adaptive.regime.RegimeDetector

::: vectrix.adaptive.regime.RegimeAwareForecaster

## Forecast DNA

::: vectrix.adaptive.dna.ForecastDNA

## Self-Healing

::: vectrix.adaptive.healing.SelfHealingForecast

## Constraints

::: vectrix.adaptive.constraints.ConstraintAwareForecaster

::: vectrix.adaptive.constraints.Constraint
