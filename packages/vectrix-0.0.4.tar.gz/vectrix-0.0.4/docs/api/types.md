# Types

Core data types and result objects.

::: vectrix.types
