# 비즈니스 인텔리전스

이상치 탐지, What-if 분석, 백테스팅, 비즈니스 지표.

## 이상치 탐지

::: vectrix.business.anomaly.AnomalyDetector

## What-If 분석

::: vectrix.business.whatif.WhatIfAnalyzer

## 백테스팅

::: vectrix.business.backtest.Backtester

## 비즈니스 지표

::: vectrix.business.metrics.BusinessMetrics
