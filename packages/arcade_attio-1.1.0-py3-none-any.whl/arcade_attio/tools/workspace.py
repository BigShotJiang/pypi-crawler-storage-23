"""Attio workspace operations - members and context."""

from typing import Annotated, Any

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Attio

from arcade_attio.tools.records import (
    _attio_request,
    _get_auth_token_or_raise,
)


@tool(
    requires_auth=Attio(scopes=["user_management:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: ToolContext,
) -> Annotated[dict[str, Any], "Authenticated user profile and workspace context"]:
    """
    Get the authenticated user's profile and workspace context.

    CALL THIS FIRST to understand your identity and permissions.
    Returns the current user's name, email, and workspace membership info.
    """
    auth_token = _get_auth_token_or_raise(context)

    # Get workspace members to find current user
    response = await _attio_request("GET", "/workspace_members", auth_token)
    members = response.get("data", [])

    # The API returns the authenticated user's workspace membership info
    # We need to identify which member corresponds to the current auth token
    # For now, return all members and let the caller identify themselves
    # In practice, the auth token owner is typically the first member or
    # can be identified by email matching

    workspace_info = {
        "workspace_member_count": len(members),
        "members": [
            {
                "member_id": m.get("id", {}).get("workspace_member_id", ""),
                "name": f"{m.get('first_name', '')} {m.get('last_name', '')}".strip(),
                "email": m.get("email_address", ""),
                "is_admin": m.get("is_admin", False),
            }
            for m in members
        ],
    }

    return {
        "message": "Use your email to identify yourself from the members list",
        "workspace": workspace_info,
    }


@tool(
    requires_auth=Attio(scopes=["user_management:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_workspace_members(
    context: ToolContext,
) -> Annotated[dict, "All workspace members"]:
    """
    Get all members in the Attio workspace.

    Useful for task assignment and understanding who owns records.
    """
    auth_token = _get_auth_token_or_raise(context)
    response = await _attio_request("GET", "/workspace_members", auth_token)

    members = []
    for m in response.get("data", []):
        members.append({
            "member_id": m.get("id", {}).get("workspace_member_id", ""),
            "name": f"{m.get('first_name', '')} {m.get('last_name', '')}".strip(),
            "email": m.get("email_address", ""),
        })

    return {"members": members}
