"""Attio meeting and call recording operations - list meetings, get transcripts."""

from typing import Annotated, Any

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Attio

from arcade_attio.tools.records import (
    ATTIO_BASE_URL,
    _get_auth_token_or_raise,
)


async def _meeting_request(
    method: str,
    endpoint: str,
    auth_token: str,
    json_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make authenticated request to Attio API for meeting endpoints."""
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient() as client:
        response = await client.request(
            method=method,
            url=f"{ATTIO_BASE_URL}{endpoint}",
            headers=headers,
            json=json_data,
            timeout=60.0,  # Longer timeout for transcripts
        )

        if response.status_code == 404:
            raise ValueError(
                f"Resource not found: {endpoint}. "
                "RECOVERY: Use list_record_meetings to find valid meeting_ids, "
                "then get_meeting to find call_recording_ids."
            )

        if response.status_code == 400:
            try:
                error_data = response.json()
                error_msg = error_data.get("message", str(error_data))
            except Exception:
                error_msg = response.text or "Bad request"
            raise ValueError(
                f"Invalid request: {error_msg}. "
                "RECOVERY: Check that meeting_id and call_recording_id are valid UUIDs."
            )

        if response.status_code == 403:
            raise ValueError(
                "Access denied. Ensure the Attio integration has 'meeting:read' and "
                "'call_recording:read' permissions enabled."
            )

        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result


@tool(
    requires_auth=Attio(scopes=["meeting:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_record_meetings(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to get meetings for. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    record_id: Annotated[str, "Record UUID to get meetings for"],
    limit: Annotated[int, "Max meetings to return (default 20)"] = 20,
    offset: Annotated[int, "Number of meetings to skip (default 0)"] = 0,
) -> Annotated[dict[str, Any], "Meetings with pagination info"]:
    """
    List meetings associated with an Attio record.

    Returns meetings linked to a deal, company, or person including:
    - Meeting ID and title
    - Meeting type (e.g., 'Discovery', 'Demo')
    - Start/end times
    - Whether the meeting has a call recording

    Use this to find meetings before fetching transcripts.
    """
    auth_token = _get_auth_token_or_raise(context)

    # Query meetings filtered by linked record
    endpoint = f"/meetings?limit={limit}&offset={offset}&record_id={record_id}&object={object_type}"
    response = await _meeting_request("GET", endpoint, auth_token)

    meetings = []
    for m in response.get("data", []):
        meeting_id = m.get("id", {}).get("meeting_id", "")
        has_recording = m.get("has_call_recording", False)
        call_recording_data = m.get("call_recording")
        call_recording_id = (
            call_recording_data.get("call_recording_id") if call_recording_data else None
        )

        meeting_data = {
            "meeting_id": meeting_id,
            "title": m.get("title", "Untitled Meeting"),
            "meeting_type": m.get("meeting_type", ""),
            "start_time": m.get("start_time"),
            "end_time": m.get("end_time"),
            "duration_minutes": _calculate_duration(m.get("start_time"), m.get("end_time")),
            "has_call_recording": has_recording,
            "call_recording_id": call_recording_id,
            "web_url": f"https://app.attio.com/meetings/{meeting_id}",
        }

        if has_recording and call_recording_id:
            meeting_data["next_action"] = (
                f"Call get_call_transcript(meeting_id='{meeting_id}', "
                f"call_recording_id='{call_recording_id}')"
            )

        meetings.append(meeting_data)

    return {
        "record_id": record_id,
        "object_type": object_type,
        "meetings": meetings,
        "pagination": {
            "limit": limit,
            "offset": offset,
            "count": len(meetings),
            "has_more": len(meetings) == limit,
        },
    }


@tool(
    requires_auth=Attio(scopes=["meeting:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_meeting(
    context: ToolContext,
    meeting_id: Annotated[str, "Meeting UUID"],
) -> Annotated[dict[str, Any], "Meeting details including call recording info"]:
    """
    Get details of a specific meeting.

    Returns meeting metadata and call recording info if available.
    Use call_recording_id with get_call_transcript to fetch the transcript.
    """
    auth_token = _get_auth_token_or_raise(context)

    response = await _meeting_request("GET", f"/meetings/{meeting_id}", auth_token)
    m = response.get("data", {})

    meeting_id_str = m.get("id", {}).get("meeting_id", "")

    # Extract participants
    participants = []
    for p in m.get("participants", []):
        participants.append({
            "name": p.get("name", ""),
            "email": p.get("email_address", ""),
            "role": p.get("role", ""),  # e.g., 'organizer', 'attendee'
        })

    # Extract call recording info
    call_recording = None
    call_recording_id = None
    if m.get("call_recording"):
        cr = m["call_recording"]
        call_recording_id = cr.get("id", {}).get("call_recording_id", "")
        call_recording = {
            "call_recording_id": call_recording_id,
            "duration_seconds": cr.get("duration_seconds"),
            "status": cr.get("status", ""),  # e.g., 'completed', 'processing'
        }

    result = {
        "meeting_id": meeting_id_str,
        "title": m.get("title", "Untitled Meeting"),
        "meeting_type": m.get("meeting_type", ""),
        "start_time": m.get("start_time"),
        "end_time": m.get("end_time"),
        "duration_minutes": _calculate_duration(m.get("start_time"), m.get("end_time")),
        "participants": participants,
        "call_recording": call_recording,
        "linked_records": _extract_linked_records(m.get("linked_records", [])),
        "web_url": f"https://app.attio.com/meetings/{meeting_id_str}",
    }

    if call_recording_id:
        result["next_action"] = (
            f"Call get_call_transcript(meeting_id='{meeting_id_str}', "
            f"call_recording_id='{call_recording_id}')"
        )

    return result


@tool(
    requires_auth=Attio(scopes=["meeting:read", "call_recording:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_call_transcript(
    context: ToolContext,
    meeting_id: Annotated[str, "Meeting UUID"],
    call_recording_id: Annotated[str, "Call recording UUID"],
    include_timestamps: Annotated[
        bool, "Include start/end times for each segment (default false)"
    ] = False,
) -> Annotated[dict[str, Any], "Call transcript with speaker labels"]:
    """
    Get the full transcript from a call recording.

    Returns the transcript with speaker labels. Use this after finding a meeting
    with a call recording via list_record_meetings or get_meeting.

    The transcript includes:
    - Full raw transcript text
    - Segmented transcript with speaker names
    - Call duration and participant info
    """
    auth_token = _get_auth_token_or_raise(context)

    endpoint = f"/meetings/{meeting_id}/call_recordings/{call_recording_id}/transcript"
    response = await _meeting_request("GET", endpoint, auth_token)

    data = response.get("data", {})

    # Build formatted transcript with speaker labels
    segments = []
    for seg in data.get("transcript", []):
        segment = {
            "speaker": seg.get("speaker", {}).get("name", "Unknown"),
            "text": seg.get("speech", ""),
        }
        if include_timestamps:
            segment["start_time"] = seg.get("start_time")
            segment["end_time"] = seg.get("end_time")
        segments.append(segment)

    # Build speaker-labeled raw transcript for easy reading
    formatted_transcript = ""
    current_speaker = None
    for seg in segments:
        if seg["speaker"] != current_speaker:
            if formatted_transcript:
                formatted_transcript += "\n\n"
            formatted_transcript += f"**{seg['speaker']}:** "
            current_speaker = seg["speaker"]
        else:
            formatted_transcript += " "
        formatted_transcript += seg["text"]

    return {
        "meeting_id": meeting_id,
        "call_recording_id": call_recording_id,
        "raw_transcript": data.get("raw_transcript", ""),
        "formatted_transcript": formatted_transcript,
        "segments": segments,
        "segment_count": len(segments),
        "web_url": f"https://app.attio.com/meetings/{meeting_id}",
    }


@tool(
    requires_auth=Attio(scopes=["meeting:read", "call_recording:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_deal_transcript(
    context: ToolContext,
    deal_record_id: Annotated[str, "Deal record UUID"],
    meeting_index: Annotated[
        int, "Which meeting (0=most recent, 1=second most recent, default 0)"
    ] = 0,
) -> Annotated[dict[str, Any], "Call transcript for the specified deal meeting"]:
    """
    Convenience tool to get a call transcript for a deal in one step.

    Finds meetings for the deal, gets the specified meeting's call recording,
    and returns the full transcript. Defaults to the most recent meeting.

    This combines list_record_meetings + get_call_transcript into one call.
    Returns an error if no meetings with recordings are found.
    """
    auth_token = _get_auth_token_or_raise(context)

    # Step 1: Get meetings for the deal
    endpoint = f"/meetings?limit=10&record_id={deal_record_id}&object=deals"
    meetings_response = await _meeting_request("GET", endpoint, auth_token)

    meetings = meetings_response.get("data", [])
    if not meetings:
        raise ValueError(f"No meetings found for deal {deal_record_id}")

    # Filter to meetings with call recordings
    meetings_with_recordings = [
        m for m in meetings if m.get("has_call_recording") or m.get("call_recording")
    ]

    if not meetings_with_recordings:
        raise ValueError(
            f"No meetings with call recordings found for deal {deal_record_id}. "
            f"Found {len(meetings)} meetings but none have recordings."
        )

    if meeting_index >= len(meetings_with_recordings):
        raise ValueError(
            f"Meeting index {meeting_index} out of range. "
            f"Only {len(meetings_with_recordings)} meetings with recordings available."
        )

    # Get the specified meeting
    meeting = meetings_with_recordings[meeting_index]
    meeting_id = meeting.get("id", {}).get("meeting_id", "")

    # Step 2: Get meeting details for call recording ID
    meeting_response = await _meeting_request("GET", f"/meetings/{meeting_id}", auth_token)
    meeting_data = meeting_response.get("data", {})

    call_recording = meeting_data.get("call_recording")
    if not call_recording:
        raise ValueError(f"Meeting {meeting_id} does not have a call recording")

    call_recording_id = call_recording.get("id", {}).get("call_recording_id", "")

    # Step 3: Get the transcript
    transcript_endpoint = f"/meetings/{meeting_id}/call_recordings/{call_recording_id}/transcript"
    transcript_response = await _meeting_request("GET", transcript_endpoint, auth_token)

    data = transcript_response.get("data", {})

    # Build formatted transcript
    segments = []
    for seg in data.get("transcript", []):
        segments.append({
            "speaker": seg.get("speaker", {}).get("name", "Unknown"),
            "text": seg.get("speech", ""),
        })

    formatted_transcript = ""
    current_speaker = None
    for seg in segments:
        if seg["speaker"] != current_speaker:
            if formatted_transcript:
                formatted_transcript += "\n\n"
            formatted_transcript += f"**{seg['speaker']}:** "
            current_speaker = seg["speaker"]
        else:
            formatted_transcript += " "
        formatted_transcript += seg["text"]

    # Extract participants
    participants = [
        {"name": p.get("name", ""), "email": p.get("email_address", "")}
        for p in meeting_data.get("participants", [])
    ]

    return {
        "deal_record_id": deal_record_id,
        "meeting_id": meeting_id,
        "meeting_title": meeting_data.get("title", "Untitled Meeting"),
        "meeting_type": meeting_data.get("meeting_type", ""),
        "call_date": meeting_data.get("start_time"),
        "duration_minutes": _calculate_duration(
            meeting_data.get("start_time"), meeting_data.get("end_time")
        ),
        "participants": participants,
        "raw_transcript": data.get("raw_transcript", ""),
        "formatted_transcript": formatted_transcript,
        "segment_count": len(segments),
        "web_url": f"https://app.attio.com/meetings/{meeting_id}",
    }


def _calculate_duration(start_time: str | None, end_time: str | None) -> int | None:
    """Calculate duration in minutes from ISO timestamps."""
    if not start_time or not end_time:
        return None
    try:
        from datetime import datetime

        start = datetime.fromisoformat(start_time.replace("Z", "+00:00"))
        end = datetime.fromisoformat(end_time.replace("Z", "+00:00"))
        return int((end - start).total_seconds() / 60)
    except (ValueError, TypeError):
        return None


def _extract_linked_records(linked_records: list[dict]) -> list[dict]:
    """Extract linked record info from meeting."""
    result = []
    for lr in linked_records:
        result.append({
            "object_type": lr.get("target_object", ""),
            "record_id": lr.get("target_record_id", ""),
        })
    return result
