"""Attio record operations - query, get, assert (upsert), and search."""

import json
from typing import Annotated, Any

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Attio
from arcade_tdk.errors import ToolExecutionError

from arcade_attio.enums import SortDirection

ATTIO_BASE_URL = "https://api.attio.com/v2"


def _get_auth_token_or_raise(context: ToolContext) -> str:
    """Return auth token or raise error if missing."""
    token = context.get_auth_token_or_empty()
    if not token:
        raise ToolExecutionError(
            message="Authentication token is required",
            developer_message="Attio OAuth token was not provided",
        )
    return token


async def _attio_request(
    method: str,
    endpoint: str,
    auth_token: str,
    json_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make authenticated request to Attio API with actionable error handling."""
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient() as client:
        response = await client.request(
            method=method,
            url=f"{ATTIO_BASE_URL}{endpoint}",
            headers=headers,
            json=json_data,
            timeout=30.0,
        )

        if response.status_code == 400:
            try:
                error_data = response.json()
                error_code = error_data.get("code", "")
                error_msg = error_data.get("message", "")
                error_path = error_data.get("path", [])
            except Exception:
                raise ValueError(f"Attio API error: {response.text or 'Bad request'}")

            # Provide actionable recovery guidance based on error type
            if error_code == "unknown_filter_select_option_slug":
                field = error_path[0] if error_path else "unknown"
                raise ValueError(
                    f"Invalid filter value for '{field}': {error_msg}. "
                    f"RECOVERY: Call get_object_schema to see valid options for this field."
                )
            elif error_code == "missing_sort_field":
                field = error_path[-1] if error_path else "unknown"
                raise ValueError(
                    f"Filter syntax error for '{field}': {error_msg}. "
                    f"RECOVERY: Some field types require nested syntax. "
                    f"$not_empty NOT supported on record-reference fields. "
                    f"Call get_object_schema for field types and filter syntax."
                )
            else:
                raise ValueError(f"Attio API error: {error_msg}. Path: {error_path}")

        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result


def _extract_location(val: dict[str, Any]) -> str:
    """Extract readable location string from location attribute."""
    parts = [val.get(k) for k in ("locality", "region", "country_code") if val.get(k)]
    return ", ".join(str(p) for p in parts)


def _extract_value(first_val: dict[str, Any]) -> Any:
    """Extract the display value from an Attio attribute value."""
    attr_type = first_val.get("attribute_type", "")

    extractors: dict[str, Any] = {
        "personal-name": lambda v: v.get("full_name", ""),
        "location": _extract_location,
        "status": lambda v: v.get("status", {}).get("title", ""),
        "currency": lambda v: v.get("currency_value", 0),
        "select": lambda v: v.get("option", {}).get("title", ""),
        "record-reference": lambda v: v.get("target_record_id", ""),
        "actor-reference": lambda v: v.get("referenced_actor_id", ""),
        "date": lambda v: v.get("value", ""),
        "timestamp": lambda v: v.get("value", ""),
    }

    if attr_type in extractors:
        return extractors[attr_type](first_val)

    # Default: try common value fields
    for key in ("value", "full_name", "email_address", "domain", "title"):
        if key in first_val:
            return first_val[key]
    return ""


def _flatten_record(record: dict[str, Any]) -> dict[str, Any]:
    """Flatten Attio record values for easier consumption."""
    flat: dict[str, Any] = {"record_id": record.get("id", {}).get("record_id", "")}
    for attr, val in record.get("values", {}).items():
        if val and len(val) > 0:
            first_val = val[0]
            if isinstance(first_val, dict):
                flat[attr] = _extract_value(first_val)
            else:
                flat[attr] = first_val
    return flat


@tool(
    requires_auth=Attio(scopes=["object_configuration:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_objects(
    context: ToolContext,
) -> Annotated[dict[str, Any], "List of all objects in the workspace"]:
    """
    List all objects (tables) in the Attio workspace.

    CALL THIS FIRST to discover what objects exist. Standard objects include
    'people', 'companies', 'deals', 'users'. Custom objects will also appear.

    Returns object slugs (API names) and titles (display names).
    """
    auth_token = _get_auth_token_or_raise(context)
    response = await _attio_request("GET", "/objects", auth_token)
    objects = response.get("data", [])

    return {
        "count": len(objects),
        "objects": [
            {
                "slug": obj.get("api_slug", ""),
                "title": obj.get("singular_noun", obj.get("api_slug", "")),
                "plural": obj.get("plural_noun", ""),
            }
            for obj in objects
        ],
    }


def _get_filter_hint(attr_type: str, attr_name: str) -> str:
    """Return filter syntax hint for an attribute type."""
    hints = {
        "text": f'{{"{attr_name}": {{"$contains": "value"}}}}',
        "number": f'{{"{attr_name}": {{"$gt": 100}}}}',
        "currency": f'{{"{attr_name}": {{"$gt": 10000}}}}',
        "select": f'{{"{attr_name}": {{"$eq": "OptionTitle"}}}} (use exact option title)',
        "status": f'{{"{attr_name}": {{"$eq": "StatusTitle"}}}} (ONLY $eq works for status)',
        "checkbox": f'{{"{attr_name}": {{"$eq": true}}}}',
        "date": f'{{"{attr_name}": {{"$gt": "2024-01-01"}}}}',
        "timestamp": f'{{"{attr_name}": {{"$gt": "2024-01-01T00:00:00Z"}}}}',
        "email": f'{{"{attr_name}": {{"$contains": "@example.com"}}}}',
        "domain": f'{{"{attr_name}": {{"$contains": "example.com"}}}}',
        "phone-number": f'{{"{attr_name}": {{"$contains": "+1"}}}}',
        "location": f'{{"{attr_name}": {{"locality": {{"$contains": "City"}}}}}} (nested!)',
        "personal-name": f'{{"{attr_name}": {{"full_name": {{"$contains": "John"}}}}}} (nested!)',
        "record-reference": f'{{"{attr_name}": {{"$eq": "uuid"}}}} (no $not_empty)',
    }
    return hints.get(attr_type, f'{{"{attr_name}": {{"$eq": "value"}}}}')


@tool(
    requires_auth=Attio(scopes=["object_configuration:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_object_schema(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to get the schema for. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
) -> Annotated[dict[str, Any], "Object schema with filterable attributes and their types"]:
    """
    Get the schema/attributes for an Attio object.

    Call list_objects first to see available objects, then call this to see
    their attributes for filtering. Returns attribute names, types, filter syntax hints,
    and for select/status fields, the available option values to use in filters.

    IMPORTANT: Location and personal-name fields require NESTED filter syntax.
    """
    auth_token = _get_auth_token_or_raise(context)
    response = await _attio_request("GET", f"/objects/{object_type}/attributes", auth_token)
    attributes = response.get("data", [])

    schema: dict[str, Any] = {
        "object_type": object_type,
        "attribute_count": len(attributes),
        "filter_operators": "$eq, $contains, $gt, $lt (status/select: $eq only)",
        "compound_filters": '{"$and": [{...}, {...}]} or {"$or": [{...}, {...}]}',
        "attributes": [],
    }

    for attr in attributes:
        attr_type = attr.get("type", "")
        attr_name = attr.get("api_slug", "")

        attr_info: dict[str, Any] = {
            "name": attr_name,
            "title": attr.get("title", ""),
            "type": attr_type,
            "filter_hint": _get_filter_hint(attr_type, attr_name),
        }

        # Include select options if present
        if attr_type == "select" and attr.get("config", {}).get("options"):
            attr_info["options"] = [opt.get("title", "") for opt in attr["config"]["options"]]

        # Include status options if present
        if attr_type == "status" and attr.get("config", {}).get("statuses"):
            attr_info["statuses"] = [s.get("title", "") for s in attr["config"]["statuses"]]

        schema["attributes"].append(attr_info)

    return schema


@tool(
    requires_auth=Attio(scopes=["record_permission:read", "object_configuration:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def query_records(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to query. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    fields: Annotated[
        list[str], "Fields to return (call get_object_schema to see available fields)"
    ],
    filter_json: Annotated[
        str | None, "JSON filter with operators: $eq, $contains, $gt, $lt"
    ] = None,
    sort_by: Annotated[str | None, "Attribute to sort by"] = None,
    sort_direction: Annotated[SortDirection, "Sort direction (default desc)"] = SortDirection.DESC,
    limit: Annotated[int, "Max records to return (default 25, max 100)"] = 25,
    offset: Annotated[int, "Number of records to skip (default 0)"] = 0,
) -> Annotated[dict[str, Any], "Query results with pagination info"]:
    """
    Query Attio records with filtering and pagination.

    Workflow: 1) list_objects, 2) get_object_schema, 3) query_records with fields.
    """
    auth_token = _get_auth_token_or_raise(context)
    body: dict[str, Any] = {"limit": min(limit, 100), "offset": offset}
    if filter_json:
        try:
            body["filter"] = json.loads(filter_json)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid filter_json: {e}. Must be valid JSON.")
    if sort_by:
        body["sorts"] = [{"attribute": sort_by, "direction": sort_direction.value}]

    response = await _attio_request(
        "POST", f"/objects/{object_type}/records/query", auth_token, body
    )
    records = response.get("data", [])

    flat_records = [_flatten_record(r) for r in records]

    # Always filter to requested fields
    fields_set = set(fields) | {"record_id"}
    flat_records = [{k: v for k, v in r.items() if k in fields_set} for r in flat_records]

    return {
        "records": flat_records,
        "pagination": {
            "limit": limit,
            "offset": offset,
            "count": len(flat_records),
            "has_more": len(flat_records) == limit,
        },
    }


@tool(
    requires_auth=Attio(scopes=["record_permission:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_record(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to get a record for. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    record_id: Annotated[str, "Record UUID"],
) -> Annotated[dict, "Single record with flattened values"]:
    """
    Get a single Attio record by ID.

    Returns the record with flattened values and a direct web URL.
    """
    auth_token = _get_auth_token_or_raise(context)
    url = f"/objects/{object_type}/records/{record_id}"
    response = await _attio_request("GET", url, auth_token)
    record = response.get("data", {})

    return {
        "record_id": record.get("id", {}).get("record_id", ""),
        "web_url": f"https://app.attio.com/{object_type}/{record_id}",
        "values": _flatten_record(record),
    }


@tool(
    requires_auth=Attio(scopes=["record_permission:read-write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE, Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def assert_record(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to upsert a record for. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    matching_attribute: Annotated[
        str, "Unique attribute for upsert match (e.g., 'email_addresses', 'domains')"
    ],
    values: Annotated[dict, "Attribute values to set on the record"],
) -> Annotated[dict, "Created or updated record info"]:
    """
    Create or update (upsert) a record using Attio's assert endpoint.

    This is idempotent - safe to retry. If a record matching the attribute exists,
    it will be updated. Otherwise, a new record is created.

    IMPORTANT: The matching_attribute MUST be a unique attribute on the object.
    Common unique attributes:
    - people: 'email_addresses'
    - companies: 'domains'
    - deals: 'record_id' (name is NOT unique by default)

    To update a deal by name, first query to get the record_id, then use update_record.
    """
    auth_token = _get_auth_token_or_raise(context)
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient() as client:
        response = await client.put(
            f"{ATTIO_BASE_URL}/objects/{object_type}/records",
            headers=headers,
            params={"matching_attribute": matching_attribute},
            json={"data": {"values": values}},
            timeout=30.0,
        )

        if response.status_code == 400:
            try:
                error_data = response.json()
                error_msg = error_data.get("message", str(error_data))
            except Exception:
                error_msg = response.text or "Bad request"

            if "unique" in error_msg.lower() or "matching_attribute" in error_msg.lower():
                raise ValueError(
                    f"Cannot use '{matching_attribute}' as matching_attribute - it must be unique. "
                    f"For deals, use record_id or call update_record instead. Error: {error_msg}"
                )
            raise ValueError(f"Attio API error: {error_msg}")

        response.raise_for_status()
        data = response.json()

    record = data.get("data", {})
    record_id = record.get("id", {}).get("record_id", "")

    return {
        "record_id": record_id,
        "matched_on": matching_attribute,
        "web_url": f"https://app.attio.com/{object_type}/{record_id}",
    }


@tool(
    requires_auth=Attio(scopes=["record_permission:read-write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_record(
    context: ToolContext,
    object_type: Annotated[
        str,
        "The type of object to update a record for. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    record_id: Annotated[str, "Record UUID to update"],
    values: Annotated[dict, "Attribute values to update on the record"],
) -> Annotated[dict, "Updated record info"]:
    """
    Update a record directly by ID.

    Use this when you have the record_id and want to update specific fields.
    Unlike assert_record, this doesn't require a unique matching attribute.

    For status fields like 'stage', pass the status title as a string:
    {"stage": "Closed Won"}

    For date fields, use ISO format:
    {"close_date": "2024-01-15"}
    """
    auth_token = _get_auth_token_or_raise(context)
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient() as client:
        response = await client.patch(
            f"{ATTIO_BASE_URL}/objects/{object_type}/records/{record_id}",
            headers=headers,
            json={"data": {"values": values}},
            timeout=30.0,
        )

        if response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get("message", str(error_data))
            raise ValueError(f"Attio API error: {error_msg}")

        if response.status_code == 404:
            raise ValueError(f"Record not found: {record_id}")

        response.raise_for_status()
        data = response.json()

    record = data.get("data", {})
    updated_id = record.get("id", {}).get("record_id", "")

    return {
        "record_id": updated_id,
        "web_url": f"https://app.attio.com/{object_type}/{updated_id}",
        "values": _flatten_record(record),
    }
