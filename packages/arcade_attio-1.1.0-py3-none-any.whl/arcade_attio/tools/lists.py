"""Attio list operations - list, get entries, add, and remove."""

from typing import Annotated

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Attio

from arcade_attio.tools.records import (
    _attio_request,
    _get_auth_token_or_raise,
)


@tool(
    requires_auth=Attio(scopes=["list_configuration:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_lists(
    context: ToolContext,
    limit: Annotated[int, "Max lists to return (default 25)"] = 25,
    offset: Annotated[int, "Number of lists to skip (default 0)"] = 0,
) -> Annotated[dict, "Lists with pagination info"]:
    """
    Get all lists in the Attio workspace with pagination.

    Returns list metadata including ID, name, and parent object type.
    """
    auth_token = _get_auth_token_or_raise(context)
    response = await _attio_request("GET", f"/lists?limit={limit}&offset={offset}", auth_token)

    lists = []
    for lst in response.get("data", []):
        lists.append({
            "list_id": lst.get("id", {}).get("list_id", ""),
            "name": lst.get("name", ""),
            "parent_object": lst.get("parent_object", ""),
        })

    return {
        "lists": lists,
        "pagination": {
            "limit": limit,
            "offset": offset,
            "count": len(lists),
            "has_more": len(lists) == limit,
        },
    }


@tool(
    requires_auth=Attio(scopes=["list_entry:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_list_entries(
    context: ToolContext,
    list_id: Annotated[str, "List UUID"],
    limit: Annotated[int, "Max entries to return (default 25)"] = 25,
    offset: Annotated[int, "Number of entries to skip (default 0)"] = 0,
) -> Annotated[dict, "List entries with pagination info"]:
    """
    Get entries from an Attio list with pagination.

    Returns entries with their record IDs and flattened list-specific values.
    """
    auth_token = _get_auth_token_or_raise(context)
    response = await _attio_request(
        "POST", f"/lists/{list_id}/entries/query", auth_token, {"limit": limit, "offset": offset}
    )
    entries = response.get("data", [])

    flat_entries = []
    for e in entries:
        flat = {
            "entry_id": e.get("id", {}).get("entry_id", ""),
            "record_id": e.get("record_id", ""),
        }
        for attr, val in e.get("values", {}).items():
            if val and len(val) > 0:
                first_val = val[0]
                if isinstance(first_val, dict):
                    flat[attr] = first_val.get("value", str(first_val))
                else:
                    flat[attr] = first_val
        flat_entries.append(flat)

    return {
        "entries": flat_entries,
        "pagination": {
            "limit": limit,
            "offset": offset,
            "count": len(flat_entries),
            "has_more": len(flat_entries) == limit,
        },
    }


@tool(
    requires_auth=Attio(scopes=["list_entry:read-write", "list_configuration:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def add_to_list(
    context: ToolContext,
    list_id: Annotated[str, "List UUID"],
    record_id: Annotated[str, "Record UUID to add to the list"],
    entry_values: Annotated[dict | None, "List-specific attribute values"] = None,
) -> Annotated[dict, "Created entry info"]:
    """
    Add a record to an Attio list.

    Optionally set list-specific attribute values via entry_values parameter.
    """
    auth_token = _get_auth_token_or_raise(context)

    # First, get the list to determine the parent_object
    list_response = await _attio_request("GET", f"/lists/{list_id}", auth_token)
    parent_object_raw = list_response.get("data", {}).get("parent_object", "")
    # parent_object can be returned as array, extract first element
    if isinstance(parent_object_raw, list):
        parent_object = parent_object_raw[0] if parent_object_raw else ""
    else:
        parent_object = parent_object_raw

    if not parent_object:
        raise ValueError(
            f"List {list_id} has no parent_object configured. "
            "Check the list configuration in Attio."
        )

    body: dict = {
        "data": {
            "parent_record_id": record_id,
            "parent_object": parent_object,
            "entry_values": entry_values or {},
        }
    }

    response = await _attio_request("POST", f"/lists/{list_id}/entries", auth_token, body)
    entry = response.get("data", {})

    return {
        "entry_id": entry.get("id", {}).get("entry_id", ""),
        "status": "added",
    }


@tool(
    requires_auth=Attio(scopes=["list_entry:read-write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.DELETE],
            read_only=False,
            destructive=True,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def remove_from_list(
    context: ToolContext,
    list_id: Annotated[str, "List UUID"],
    entry_id: Annotated[str, "Entry UUID (not record ID)"],
) -> Annotated[dict, "Removal confirmation"]:
    """
    Remove a record from an Attio list.

    Note: Use the entry_id, not the record_id. Get entry_id from get_list_entries.
    """
    auth_token = _get_auth_token_or_raise(context)
    await _attio_request("DELETE", f"/lists/{list_id}/entries/{entry_id}", auth_token)
    return {"status": "removed"}
