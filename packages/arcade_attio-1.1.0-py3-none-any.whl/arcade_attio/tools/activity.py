"""Attio activity operations - notes and tasks."""

from typing import Annotated

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Attio

from arcade_attio.enums import NoteFormat
from arcade_attio.tools.records import (
    _attio_request,
    _get_auth_token_or_raise,
)


@tool(
    requires_auth=Attio(
        scopes=["note:read-write", "object_configuration:read", "record_permission:read"],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_note(
    context: ToolContext,
    parent_object: Annotated[
        str,
        "The type of object to attach the note to. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ],
    parent_record_id: Annotated[str, "Record UUID to attach note to"],
    title: Annotated[str, "Note title"],
    content: Annotated[str, "Note body text"],
    format_type: Annotated[NoteFormat, "Note format (default plaintext)"] = NoteFormat.PLAINTEXT,
) -> Annotated[dict, "Created note info"]:
    """
    Add a note to an Attio record.

    Notes are useful for logging activities, meeting notes, and outreach history.
    """
    auth_token = _get_auth_token_or_raise(context)
    body = {
        "data": {
            "parent_object": parent_object,
            "parent_record_id": parent_record_id,
            "title": title,
            "content": content,
            "format": getattr(format_type, "value", format_type),
        }
    }

    response = await _attio_request("POST", "/notes", auth_token, body)
    note = response.get("data", {})

    return {
        "note_id": note.get("id", {}).get("note_id", ""),
        "status": "created",
    }


@tool(
    requires_auth=Attio(scopes=["task:read-write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_task(
    context: ToolContext,
    content: Annotated[str, "Task description"],
    assignee_id: Annotated[str, "Workspace member UUID"],
    deadline: Annotated[str, "Due date in ISO 8601 format"],
    linked_record_id: Annotated[str | None, "Record UUID to link to the task"] = None,
    linked_record_object: Annotated[
        str | None,
        "The type of object to link to the task. "
        "Standard object types are 'people', 'companies', and 'deals'. "
        "Custom object types are the API slug of the object.",
    ] = None,
) -> Annotated[dict, "Created task info"]:
    """
    Create a task in Attio.

    Tasks are useful for follow-ups, reminders, and action items.
    Optionally link to a record by providing both linked_record_id and linked_record_object.
    """
    auth_token = _get_auth_token_or_raise(context)

    # Build linked_records array if both record info provided
    linked_records = []
    if linked_record_id and linked_record_object:
        linked_records.append({
            "target_object": linked_record_object,
            "target_record_id": linked_record_id,
        })

    body = {
        "data": {
            "content": content,
            "format": "plaintext",
            "is_completed": False,
            "deadline_at": deadline,
            "assignees": [
                {"referenced_actor_type": "workspace-member", "referenced_actor_id": assignee_id}
            ],
            "linked_records": linked_records,
        }
    }

    response = await _attio_request("POST", "/tasks", auth_token, body)
    task = response.get("data", {})

    return {
        "task_id": task.get("id", {}).get("task_id", ""),
        "status": "created",
        "deadline": deadline,
    }


@tool(
    requires_auth=Attio(scopes=["task:read-write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_tasks(
    context: ToolContext,
    assignee_id: Annotated[str | None, "Filter by assignee UUID"] = None,
    is_completed: Annotated[bool | None, "Filter by completion status"] = None,
    limit: Annotated[int, "Max tasks to return (default 25)"] = 25,
    offset: Annotated[int, "Number of tasks to skip (default 0)"] = 0,
) -> Annotated[dict, "Tasks with pagination info"]:
    """
    Get tasks from Attio with optional filtering and pagination.

    Can filter by assignee and/or completion status.
    """
    if limit <= 0:
        raise ValueError("limit must be a positive integer")
    auth_token = _get_auth_token_or_raise(context)
    params = [f"limit={limit}", f"offset={offset}"]
    if assignee_id:
        params.append(f"assignee={assignee_id}")
    if is_completed is not None:
        params.append(f"is_completed={str(is_completed).lower()}")

    query = "&".join(params)
    response = await _attio_request("GET", f"/tasks?{query}", auth_token)

    tasks = []
    for t in response.get("data", []):
        tasks.append({
            "task_id": t.get("id", {}).get("task_id", ""),
            "content": t.get("content", ""),
            "deadline": t.get("deadline_at"),
            "is_completed": t.get("is_completed", False),
        })

    return {
        "tasks": tasks,
        "pagination": {
            "limit": limit,
            "offset": offset,
            "count": len(tasks),
            "has_more": len(tasks) == limit,
        },
    }
