"""Attio toolkit enums for constrained parameter values."""

from enum import Enum


class NoteFormat(str, Enum):
    """Note content format."""

    PLAINTEXT = "plaintext"
    MARKDOWN = "markdown"


class SortDirection(str, Enum):
    """Sort direction for queries."""

    ASC = "asc"
    DESC = "desc"
