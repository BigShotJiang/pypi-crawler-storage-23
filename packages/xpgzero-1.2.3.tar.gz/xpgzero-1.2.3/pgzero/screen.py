import pygame
import pygame.draw
import math
from . import ptext
from .rect import RECT_CLASSES
from . import loaders


def round_pos(pos):
    """Round a tuple position so it can be used for drawing."""
    x, y = pos
    return round(x), round(y)


def make_color(arg):
    if isinstance(arg, tuple):
        return arg
    return tuple(pygame.Color(arg))


            
class SurfacePainter:
    """Interface to pygame.draw that is bound to a surface."""

    def _angle(self, deg):
        """Convert Pygame Zero angle (degrees) to pygame radians."""
        deg = deg % 360
        return math.radians(-deg)
        
    def _to_rect(self, rect, funcname):
        """Convert various rect formats to pygame.Rect."""
        try:
            return pygame.Rect(rect)
        except Exception:
            raise TypeError(f"screen.draw.{funcname}() requires a rect-like argument") from None

    def __init__(self, screen):
        self._screen = screen

    @property
    def _surf(self):
        return self._screen.surface

    def line(self, start, end, color):
        """Draw a line from start to end."""
        start = round_pos(start)
        end = round_pos(end)
        pygame.draw.line(self._surf, make_color(color), start, end, 1)

    def circle(self, pos, radius, color):
        """Draw a circle."""
        pos = round_pos(pos)
        pygame.draw.circle(self._surf, make_color(color), pos, radius, 1)

    def filled_circle(self, pos, radius, color):
        """Draw a filled circle."""
        pos = round_pos(pos)
        pygame.draw.circle(self._surf, make_color(color), pos, radius, 0)

    def ellipse(self, rect, color):
        """Draw an ellipse."""
        rect = self._to_rect(rect, "ellipse")
        pygame.draw.ellipse(self._surf, make_color(color), rect, 1)
    
    
    def filled_ellipse(self, rect, color):
        """Draw a filled ellipse."""
        rect = self._to_rect(rect, "filled_ellipse")
        pygame.draw.ellipse(self._surf, make_color(color), rect, 0)       


    def arc(self, rect, start_angle, end_angle, color):
        """Draw an elliptical arc. Angles in degrees."""
        rect = self._to_rect(rect, "arc")
    
        start = self._angle(start_angle)
        end = self._angle(end_angle)
    
        pygame.draw.arc(self._surf, make_color(color), rect, start, end, 1)
        
    def filled_arc(self, rect, start_angle, end_angle, color, steps=60, mode=0):
        """
        Draw a filled elliptical arc.
    
        mode:
            0 = CHORD (segment)
            1 = PIESLICE (sector)
        Angles follow Pygame Zero convention.
        """
    
        rect = self._to_rect(rect, "filled_arc")
    
        cx = rect.x + rect.width / 2
        cy = rect.y + rect.height / 2
        rx = rect.width / 2
        ry = rect.height / 2
    
        start = self._angle(start_angle)
        end = self._angle(end_angle)
    
        if end < start:
            start, end = end, start
    
        points = []
    
        if mode == 1:
            points.append((cx, cy))
    
        for i in range(steps + 1):
            t = start + (end - start) * i / steps
            x = cx + rx * math.cos(t)
            y = cy + ry * math.sin(t)
            points.append((x, y))
    
        pygame.draw.polygon(self._surf, make_color(color), points, 0)

    def polygon(self, points, color):
        """Draw a polygon."""
        try:
            iter(points)
        except TypeError:
            raise TypeError("screen.draw.filled_polygon() requires an iterable of points to draw") from None # noqa
        points = [round_pos(point) for point in points]
        pygame.draw.polygon(self._surf, make_color(color), points, 1)

    def filled_polygon(self, points, color):
        """Draw a filled polygon."""
        try:
            iter(points)
        except TypeError:
            raise TypeError("screen.draw.filled_polygon() requires an iterable of points to draw") from None # noqa
        points = [round_pos(point) for point in points]
        pygame.draw.polygon(self._surf, make_color(color), points, 0)

    def rect(self, rect, color):
        """Draw a rectangle."""
        rect = self._to_rect(rect, "rect")
        pygame.draw.rect(self._surf, make_color(color), rect, 1)
    
    
    def filled_rect(self, rect, color):
        """Draw a filled rectangle."""
        rect = self._to_rect(rect, "filled_rect")
        pygame.draw.rect(self._surf, make_color(color), rect, 0)

    def text(self, *args, **kwargs):
        """Draw text to the screen."""
        #FIXME: expose ptext parameters, for autocompletion and autodoc
        ptext.draw(*args, surf=self._surf, **kwargs)

    def textbox(self, *args, **kwargs):
        """Draw text to the screen, wrapped to fit a box"""
        #FIXME: expose ptext parameters, for autocompletion and autodoc
        ptext.drawbox(*args, surf=self._surf, **kwargs)


class Screen:
    """Interface to the screen."""
    def __init__(self, surface):
        self.surface = surface
        self.width, self.height = surface.get_size()
        
    def set_at(self, x, y, color):
        """Set the color of a single pixel at (x, y)."""
        self.surface.set_at((x, y), make_color(color))

    def get_at(self, x, y):
        """Get the color of a single pixel at (x, y) as an (R, G, B) tuple."""
        color = self.surface.get_at((x, y))
        return (color.r, color.g, color.b)
        
    def clear(self):
        """Clear the screen to black."""
        self.fill((0, 0, 0))

    def fill(self, color):
        """Fill the screen with a colour."""
        self.surface.fill(make_color(color))

    def blit(self, image, pos):
        """Draw a sprite onto the screen.

        "blit" is an archaic name for this operation, but one that is is still
        frequently used, for example in Pygame. See the `Wikipedia article`__
        for more about the etymology of the term.

        .. __: http://en.wikipedia.org/wiki/Bit_blit

        :param image: A Surface or the name of an image object to load.
        :param pos: The coordinates at which the top-left corner of the sprite
                    will be positioned. This may be given as a pair of
                    coordinates or as a Rect. If a Rect is given the sprite
                    will be drawn at ``rect.topleft``.

        """
        if isinstance(image, str):
            image = loaders.images.load(image)
        self.surface.blit(image, pos)

    def blit_gradient(self, start, stop, dir=0):
        """
        Fill the whole screen with a gradient.
    
        Args:
            start: starting color (RGB tuple or color name)
            stop: ending color (RGB tuple or color name)
            dir: direction (0 = vertical, 1 = horizontal)
        """
    
        surf = self.surface
        w, h = surf.get_size()
    
        start = make_color(start)
        stop = make_color(stop)
    
        compact = pygame.Surface((2, 2))
        px = pygame.PixelArray(compact)
    
        if dir == 0:  # vertical
            # top -> start, bottom -> stop
            px[0][0] = start
            px[1][0] = start
            px[0][1] = stop
            px[1][1] = stop
        else:  # horizontal
            # left -> start, right -> stop
            px[0][0] = start
            px[0][1] = start
            px[1][0] = stop
            px[1][1] = stop
    
        del px
    
        pygame.transform.smoothscale(compact, (w, h), surf)



    @property
    def draw(self):
        return SurfacePainter(self)
