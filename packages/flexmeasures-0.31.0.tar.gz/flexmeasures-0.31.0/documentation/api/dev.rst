.. _dev:

Developer API
=============

These endpoints are still under development and are subject to change in new releases.

Summary
-------

.. qrefflask:: flexmeasures.app:create(env="documentation")
    :modules: flexmeasures.api.dev.assets, flexmeasures.api.dev.sensors
    :order: path
    :include-empty-docstring:

API Details
-----------

.. autoflask:: flexmeasures.app:create(env="documentation")
    :modules: flexmeasures.api.dev.assets, flexmeasures.api.dev.sensors
    :order: path
    :include-empty-docstring:
