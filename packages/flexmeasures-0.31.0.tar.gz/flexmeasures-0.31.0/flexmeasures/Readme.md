# The FlexMeasures package

This directory packages the code which gets installed as `flexmeasures`.