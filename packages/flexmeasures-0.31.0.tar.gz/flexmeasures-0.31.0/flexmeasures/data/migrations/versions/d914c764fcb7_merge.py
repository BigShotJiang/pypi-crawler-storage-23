"""merge

Revision ID: d914c764fcb7
Revises: 75f53d2dbfae, c41beee0c904
Create Date: 2025-08-29 08:46:48.230834

"""

# revision identifiers, used by Alembic.
revision = "d914c764fcb7"
down_revision = ("5bde9835fbe3", "b8f3cda5e023")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
