"""merge

Revision ID: 0af134879301
Revises:
Create Date: 2024-08-23 10:58:49.239866

"""

# revision identifiers, used by Alembic.
revision = "0af134879301"
down_revision = ("9b2b90ee5dbf", "ea84cefba5c0")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
