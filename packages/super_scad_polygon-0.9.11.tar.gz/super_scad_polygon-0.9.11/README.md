# SuperSCAD: Polygon

SuperSCAD widgets for polygons and smooth polygons.

<table>
<thead>
<tr>
<th>Legal</th>
<th>Release</th>
<th>Code</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<a href="https://pypi.org/project/Super-SCAD-Polygon/" target="_blank"><img alt="PyPI - License" src="https://img.shields.io/pypi/l/Super-SCAD-Polygon">
</a>
</td>
<td>
<a href="https://badge.fury.io/py/Super-SCAD-Polygon" target="_blank"><img src="https://badge.fury.io/py/Super-SCAD-Polygon.svg" alt="Latest Stable Version"/></a><br/>
</td>
<td>
<a href="https://codecov.io/gh/SuperSCAD/Polygon" target="_blank"><img src="https://codecov.io/gh/SuperSCAD/Polygon/graph/badge.svg" alt="Code Coverage"/></a>
<a href="https://github.com/SuperSCAD/Polygon/actions/workflows/unit.yml"><img src="https://github.com/SuperSCAD/Polygon/actions/workflows/unit.yml/badge.svg" alt="unit Tests"/></a>
</td>
</tr>
</tbody>
</table>

# License

This project is licensed under the terms of the [MIT license](LICENSE).
