from experimaestro import Param
from .all import ForeignClassB1


class ForeignClassB2(ForeignClassB1):
    y: Param[int]
