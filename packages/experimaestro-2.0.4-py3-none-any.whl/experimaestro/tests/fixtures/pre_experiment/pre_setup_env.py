"""Pre-experiment script that sets an environment variable."""

import os

os.environ["XPM_TEST_PRE_EXPERIMENT"] = "executed"
