"""Pre-experiment script that raises an error."""

raise RuntimeError("Intentional error in pre_experiment")
