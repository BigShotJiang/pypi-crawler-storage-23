# this is parsed by pyproject.toml and defines current mamabuild version
__version__ = "0.10.1"
