"""Platform-level GPU compute router for GreatSky Metaflow.

Monkey-patches KubernetesDecorator to support three GPU targeting kwargs:
  - device: target by GPU model name (e.g. "l4", "h100")
  - vram:   target by minimum VRAM in GB (e.g. 24, 80)
  - pool:   target by named pool (e.g. "gpu")

The compute config is fetched live from METAFLOW_COMPUTE_POOLS (set at
login by the auth API) on every flow launch — no caching.

When gpu >= 1 and no targeting kwarg is given, falls back to default_device.
On any resolution failure, raises with a list of actual available options.
"""

from __future__ import annotations

import json
import sys
from typing import Any, Dict

KUEUE_QUEUE_LABEL = "kueue.x-k8s.io/queue-name"

METAFLOW_DEFAULT_CPU = "1"
METAFLOW_DEFAULT_MEMORY = "4096"


def _warn(msg: str) -> None:
    print("[greatsky:compute] %s" % msg, file=sys.stderr)


def _load_compute_config() -> Dict[str, Any]:
    """Load compute pools config.

    Checks in order:
      1. metaflow_config.COMPUTE_POOLS (injected by auth API remote config)
      2. METAFLOW_COMPUTE_POOLS env var (for local dev / CI override)
    """
    try:
        from metaflow import metaflow_config

        raw = getattr(metaflow_config, "COMPUTE_POOLS", None)
        if raw is None:
            import os

            raw = os.environ.get("METAFLOW_COMPUTE_POOLS")
        if raw is None:
            return {}
        if isinstance(raw, str):
            return json.loads(raw)
        if isinstance(raw, dict):
            return raw
    except Exception as exc:
        _warn("Failed to load compute config: %s" % exc)
    return {}


class ComputeRouterError(Exception):
    pass


def _resolve_by_device(device: str, config: Dict[str, Any], gpu_count: int) -> Dict[str, Any]:
    devices = config.get("devices", {})
    if device not in devices:
        available = sorted(devices.keys())
        raise ComputeRouterError(
            "Unknown device %r. Available devices: %s"
            % (device, ", ".join(available) if available else "(none configured)")
        )
    return _build_result(devices[device], gpu_count)


def _resolve_by_vram(min_vram: int, config: Dict[str, Any], gpu_count: int) -> Dict[str, Any]:
    devices = config.get("devices", {})
    candidates = []
    for name, spec in sorted(devices.items(), key=lambda x: x[1].get("vram_gb", 0)):
        vram = spec.get("vram_gb", 0)
        if vram >= min_vram:
            candidates.append((name, spec))

    if not candidates:
        available = sorted(
            [(n, s.get("vram_gb", 0)) for n, s in devices.items()],
            key=lambda x: x[1],
        )
        options = ", ".join("%s (%dGB)" % (n, v) for n, v in available)
        raise ComputeRouterError(
            "No device with >= %dGB VRAM. Available: %s" % (min_vram, options if options else "(none configured)")
        )

    name, spec = candidates[0]
    return _build_result(spec, gpu_count)


def _resolve_by_pool(pool: str, config: Dict[str, Any], gpu_count: int) -> Dict[str, Any]:
    pools = config.get("pools", {})
    if pool not in pools:
        available = sorted(pools.keys())
        raise ComputeRouterError(
            "Unknown pool %r. Available pools: %s" % (pool, ", ".join(available) if available else "(none configured)")
        )
    pool_cfg = pools[pool]
    pool_devices = pool_cfg.get("devices", [])
    devices = config.get("devices", {})

    first_device = pool_devices[0] if pool_devices else None
    if first_device and first_device in devices:
        result = _build_result(devices[first_device], gpu_count)
    else:
        result = {}

    if pool_cfg.get("queue"):
        result["queue"] = pool_cfg["queue"]
    return result


def _build_result(spec: Dict[str, Any], gpu_count: int) -> Dict[str, Any]:
    return {
        "node_selector": dict(spec.get("node_selector", {})),
        "tolerations": list(spec.get("tolerations", [])),
        "queue": spec.get("queue", ""),
        "cpu_per_gpu": spec.get("cpu_per_gpu", 4),
        "mem_mb_per_gpu": spec.get("mem_mb_per_gpu", 8192),
    }


def _apply_monkey_patch():
    """Inject device/vram/pool kwargs into KubernetesDecorator and wrap init()."""
    try:
        from metaflow.plugins.kubernetes.kubernetes_decorator import (
            KubernetesDecorator,
        )
    except ImportError:
        return

    KubernetesDecorator.defaults["device"] = None
    KubernetesDecorator.defaults["vram"] = None
    KubernetesDecorator.defaults["pool"] = None

    _original_init = KubernetesDecorator.init

    def _patched_init(self):
        _original_init(self)

        device = self.attributes.pop("device", None)
        vram = self.attributes.pop("vram", None)
        pool = self.attributes.pop("pool", None)

        gpu_count = self.attributes.get("gpu")
        if gpu_count is not None:
            try:
                gpu_count = int(gpu_count)
            except (TypeError, ValueError):
                gpu_count = 0
        else:
            gpu_count = 0

        if gpu_count < 1 and not any([device, vram, pool]):
            return

        targeting_modes = sum(bool(x) for x in [device, vram, pool])
        if targeting_modes > 1:
            raise ComputeRouterError(
                "Only one of device=, vram=, pool= may be specified. "
                "Got: %s"
                % ", ".join(
                    filter(
                        None,
                        [
                            "device=%r" % device if device else "",
                            "vram=%r" % vram if vram else "",
                            "pool=%r" % pool if pool else "",
                        ],
                    )
                )
            )

        config = _load_compute_config()
        if not config:
            _warn("No compute pool config found (METAFLOW_COMPUTE_POOLS). GPU routing skipped.")
            return

        if gpu_count < 1:
            gpu_count = 1
            self.attributes["gpu"] = 1

        if device:
            result = _resolve_by_device(device, config, gpu_count)
        elif vram:
            vram_int = int(vram) if not isinstance(vram, int) else vram
            result = _resolve_by_vram(vram_int, config, gpu_count)
        elif pool:
            result = _resolve_by_pool(pool, config, gpu_count)
        else:
            default_device = config.get("default_device")
            if not default_device:
                _warn("No default_device in compute config. GPU routing skipped.")
                return
            result = _resolve_by_device(default_device, config, gpu_count)

        if result.get("node_selector"):
            self.attributes["node_selector"] = result["node_selector"]

        if result.get("tolerations"):
            self.attributes["tolerations"] = result["tolerations"]

        if result.get("queue"):
            if self.attributes.get("labels") is None:
                self.attributes["labels"] = {}
            if isinstance(self.attributes["labels"], str):
                import ast

                try:
                    self.attributes["labels"] = ast.literal_eval(self.attributes["labels"])
                except Exception:
                    self.attributes["labels"] = {}
            self.attributes["labels"][KUEUE_QUEUE_LABEL] = result["queue"]

        cpu_per_gpu = result.get("cpu_per_gpu", 4)
        mem_per_gpu = result.get("mem_mb_per_gpu", 8192)

        if str(self.attributes.get("cpu", "")) == METAFLOW_DEFAULT_CPU:
            max_cpu = int(cpu_per_gpu * gpu_count * 0.9)
            self.attributes["cpu"] = str(max(max_cpu, 1))

        if str(self.attributes.get("memory", "")) == METAFLOW_DEFAULT_MEMORY:
            max_mem = int(mem_per_gpu * gpu_count * 0.9)
            self.attributes["memory"] = str(max(max_mem, 4096))

    KubernetesDecorator.init = _patched_init
