"""GreatSky config extension — injects remote platform config into metaflow_config.

Metaflow's config extension point runs at the END of metaflow_config.py, after all
from_conf() calls have already evaluated. The extension processing copies non-dunder,
non-module globals from this module into metaflow_config's namespace (line 659-660).
We exploit this by resolving the full platform config here and exposing each value
as a module-level global with the METAFLOW_ prefix stripped, matching the names
that from_conf() would have produced.
"""


def _apply():
    import metaflow.metaflow_config_funcs as mf_funcs

    from metaflow_extensions.greatsky.remote_config import init_config

    existing = getattr(mf_funcs, "METAFLOW_CONFIG", None) or {}
    remote = init_config()

    # Merge: remote config wins where present, but preserve any keys already
    # set (e.g. config deserialized from the client when running inside a
    # worker pod where init_config() returns {}).
    merged = {**existing, **remote} if remote else existing

    mf_funcs.METAFLOW_CONFIG = merged
    mf_funcs.init_config = init_config

    for key, value in merged.items():
        if key.startswith("METAFLOW_") and value is not None:
            globals()[key[9:]] = value


_apply()
del _apply
