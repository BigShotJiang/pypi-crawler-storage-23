"""Tests for auth module (mocked HTTP)."""

import httpx
import pytest

from greatsky_internal_metaflow import auth, settings


class MockResponse:
    def __init__(self, status_code, data):
        self.status_code = status_code
        self._data = data
        self.headers = {}

    def json(self):
        return self._data

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("error", request=httpx.Request("GET", "http://x"), response=self)


def test_fetch_bootstrap_config(monkeypatch):
    expected = {"github_client_id": "test123", "domain": "gr8sky.dev", "auth_url": "https://auth.gr8sky.dev"}

    def mock_get(url, **kwargs):
        assert url == settings.BOOTSTRAP_ENDPOINT
        return MockResponse(200, expected)

    monkeypatch.setattr(httpx, "get", mock_get)
    result = auth.fetch_bootstrap_config()
    assert result == expected


def test_fetch_client_config(monkeypatch):
    expected = {"github_client_id": "test123", "domain": "gr8sky.dev"}

    def mock_get(url, **kwargs):
        assert url == settings.CONFIG_ENDPOINT
        return MockResponse(200, expected)

    monkeypatch.setattr(httpx, "get", mock_get)
    result = auth.fetch_client_config()
    assert result == expected


def test_request_device_code(monkeypatch):
    def mock_post(url, **kwargs):
        return MockResponse(
            200,
            {
                "device_code": "dc_123",
                "user_code": "ABCD-1234",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            },
        )

    monkeypatch.setattr(httpx, "post", mock_post)
    dc = auth.request_device_code("test_client_id")
    assert dc.user_code == "ABCD-1234"
    assert dc.device_code == "dc_123"
    assert dc.interval == 5


def test_exchange_token_success(monkeypatch):
    def mock_post(url, **kwargs):
        return MockResponse(
            200,
            {
                "api_key": "gsk_abc",
                "expires_at": "2026-03-05T00:00:00Z",
                "user_info": {
                    "github_user": "alice",
                    "name": "Alice",
                    "access_type": "org_member",
                },
                "metaflow_config": {"METAFLOW_USER": "alice"},
            },
        )

    monkeypatch.setattr(httpx, "post", mock_post)
    creds = auth.exchange_token("ghp_fake")
    assert creds.github_user == "alice"
    assert creds.api_key == "gsk_abc"
    assert creds.metaflow_config == {"METAFLOW_USER": "alice"}


def test_exchange_token_forbidden(monkeypatch):
    def mock_post(url, **kwargs):
        return MockResponse(403, {"error": "Not a member or guest"})

    monkeypatch.setattr(httpx, "post", mock_post)
    with pytest.raises(PermissionError, match="Not a member"):
        auth.exchange_token("ghp_fake")
