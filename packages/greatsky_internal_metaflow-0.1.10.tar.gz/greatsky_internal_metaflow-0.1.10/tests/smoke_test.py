"""Live smoke tests — run against the real GreatSky platform.

Requires the GSM_SERVICE_KEY environment variable to be set.
Skipped automatically when the variable is absent.
"""

from __future__ import annotations

import os

import httpx
import pytest

AUTH_API_BASE = "https://auth.gr8sky.dev"
SERVICE_KEY = os.environ.get("GSM_SERVICE_KEY", "")

pytestmark = pytest.mark.skipif(not SERVICE_KEY, reason="GSM_SERVICE_KEY not set")


def test_auth_api_reachable():
    resp = httpx.get(f"{AUTH_API_BASE}/auth/bootstrap", timeout=10)
    assert resp.status_code == 200
    data = resp.json()
    assert "github_client_id" in data


def test_service_key_valid():
    resp = httpx.get(
        f"{AUTH_API_BASE}/auth/validate-key",
        headers={"X-Api-Key": SERVICE_KEY},
        timeout=10,
    )
    assert resp.status_code == 200, f"Key validation failed: {resp.status_code}"
    assert resp.headers.get("x-auth-user"), "Missing x-auth-user header"


def test_metadata_api_reachable():
    config_resp = httpx.get(
        f"{AUTH_API_BASE}/auth/client-config",
        headers={"X-Api-Key": SERVICE_KEY},
        timeout=10,
    )
    config_resp.raise_for_status()
    mf_config = config_resp.json().get("metaflow_config", {})
    metadata_url = mf_config.get("METAFLOW_SERVICE_URL", "")
    assert metadata_url, "No METAFLOW_SERVICE_URL in client-config"

    resp = httpx.get(
        f"{metadata_url.rstrip('/')}/ping",
        headers={"X-Api-Key": SERVICE_KEY},
        timeout=10,
    )
    assert resp.status_code == 200, f"Metadata ping failed: {resp.status_code}"
