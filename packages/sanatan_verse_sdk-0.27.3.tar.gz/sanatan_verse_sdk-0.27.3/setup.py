from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sanatan-verse-sdk",
    version="0.27.3",
    author="Sanatan Learnings",
    author_email="arun.gupta@gmail.com",
    description="Python SDK for creating verse-based content sites with AI translations, multimedia (images, audio), semantic search, and deployment",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sanatan-learnings/sanatan-verse-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "openai>=1.0.0",
        "elevenlabs>=1.0.0",
        "requests>=2.31.0",
        "Pillow>=10.0.0",
        "python-dotenv>=1.0.0",
        "PyYAML>=6.0.0",
        "sentence-transformers>=2.2.0",
        "torch>=2.0.0",
        "beautifulsoup4>=4.12.0",
    ],
    entry_points={
        'console_scripts': [
            'verse-generate=verse_sdk.cli.generate:main',
            'verse-embeddings=verse_sdk.embeddings.generate_embeddings:main',
            'verse-audio=verse_sdk.audio.generate_audio:main',
            'verse-images=verse_sdk.images.generate_theme_images:main',
            'verse-deploy=verse_sdk.deployment.deploy:main',
            'verse-status=verse_sdk.cli.status:main',
            'verse-sync=verse_sdk.cli.sync:main',
            'verse-translate=verse_sdk.cli.translate:main',
            'verse-init=verse_sdk.cli.init:main',
            'verse-validate=verse_sdk.cli.validate:main',
            'verse-add=verse_sdk.cli.add:main',
            'verse-help=verse_sdk.cli.help:main',
        ],
    },
)
