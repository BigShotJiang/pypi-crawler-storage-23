# mgp: A Tensor micrograd
An educational NumPy-based autodiff engine and neural network library. See this blog post for a breakdown of the key logic.

## Installation
```
pip install microgradpp
```

## How To Use It
- See `train_mnist.py`, where we use mgpp to train a convolutional neural network for MNIST image classification. With the stated hyperparameters, it achieves an accuracy of 0.97+.
- `train_xor.py` runs MLPs built on both the vanilla and NumPy-based engines on the XOR task. The NumPy-based engine trains several times faster.

In general, I tried to make the API as PyTorch-like as possible while keeping it simple.