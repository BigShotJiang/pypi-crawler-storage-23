import numpy as np
from ._utils import unbroadcast

class Tensor:
    def __init__(self, data, parents=()):
        if not isinstance(data, np.ndarray):
            data = np.array(data)
        self.data = data
        self.shape = data.shape
        self.ndim = data.ndim
        self.grad = np.zeros(self.shape, dtype=float)
        self.grad_fn = lambda: None
        self.parents = parents
        
    def __repr__(self):
        return f"Tensor(data={self.data}, grad={self.grad})"

    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        output = Tensor(self.data + other.data, parents=(self, other))
        def grad_fn():
            self.grad += unbroadcast(output.grad, self.shape)
            other.grad += unbroadcast(output.grad, other.shape)
        output.grad_fn = grad_fn
        return output
    
    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        output = Tensor(self.data * other.data, parents=(self, other))
        def grad_fn():
            self.grad += unbroadcast(output.grad * other.data, self.shape)
            other.grad += unbroadcast(output.grad * self.data, other.shape)
        output.grad_fn = grad_fn
        return output
    
    def __matmul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        output = Tensor(self.data @ other.data, parents=(self, other))
        def grad_fn():
            grad = output.grad
            if other.ndim == 1:
                if self.ndim == 1:
                    self.grad += unbroadcast(grad * other.data, self.shape)
                else:
                    self.grad += unbroadcast(grad[..., None] * other.data, self.shape)
            else:
                self.grad += unbroadcast(grad @ other.data.swapaxes(-2, -1), self.shape)
            
            if self.ndim == 1:
                if other.ndim == 1:
                    other.grad += unbroadcast(grad * self.data, other.shape)
                else:
                    other.grad += unbroadcast(np.expand_dims(grad, -2) * np.expand_dims(self.data, -1), other.shape)
            else:
                other.grad += unbroadcast(self.data.swapaxes(-2, -1) @ grad, other.shape)
        output.grad_fn = grad_fn
        return output
    
    def __pow__(self, other: float | int):
        output = Tensor(self.data ** other, parents=(self,))
        def grad_fn():
            self.grad += unbroadcast(output.grad * other * self.data**(other - 1), self.shape)
        output.grad_fn = grad_fn
        return output

    def backward(self, grad=1):
        nodes = []
        visited = set()
        def dfs(node):
            if node not in visited:
                visited.add(node)
                for parent in node.parents:
                    dfs(parent)
                nodes.append(node)
        dfs(self)

        self.grad = np.ones(self.shape) * grad
        for node in reversed(nodes):
            node.grad_fn()
    
    def item(self):
        return self.data.item()

    def detach(self):
        return Tensor(self.data)

    def max(self, dim=None, keepdim=False):
        output = Tensor(self.data.max(axis=dim, keepdims=keepdim), parents=(self,))
        def grad_fn():
            max_vals = self.data.max(axis=dim, keepdims=True)
            mask = (self.data == max_vals).astype(float)
            mask /= mask.sum(axis=dim, keepdims=True)
            grad = output.grad
            if dim is not None and not keepdim:
                if isinstance(dim, int):
                    grad = np.expand_dims(grad, dim)
                else:
                    for ax in sorted(dim):
                        grad = np.expand_dims(grad, ax)
            self.grad += mask * grad
        output.grad_fn = grad_fn
        return output

    def log(self):
        output = Tensor(np.log(self.data), parents=(self,))
        def grad_fn():
            self.grad += unbroadcast(output.grad / self.data, self.shape)
        output.grad_fn = grad_fn
        return output

    def exp(self):
        output = Tensor(np.exp(self.data), parents=(self,))
        def grad_fn():
            self.grad += unbroadcast(output.grad * output.data, self.shape)
        output.grad_fn = grad_fn
        return output

    def sum(self, dim=None, keepdim=False):
        output = Tensor(self.data.sum(axis=dim, keepdims=keepdim), parents=(self,))
        def grad_fn():
            grad = output.grad
            if dim is not None and not keepdim:
                if isinstance(dim, int):
                    grad = np.expand_dims(grad, dim)
                else:
                    for ax in sorted(dim):
                        grad = np.expand_dims(grad, ax)
            self.grad += np.broadcast_to(grad, self.shape)
        output.grad_fn = grad_fn
        return output

    def __neg__(self):
        return self * -1
    
    def __sub__(self, other):
        return self + (-other)

    def __truediv__(self, other):
        return self * other**-1

    def __radd__(self, other):
        return self + other
    
    def __rmul__(self, other):
        return self * other
    
    def __rsub__(self, other):
        return other + (-self)
    
    def __rtruediv__(self, other):
        return other * self**-1

    def relu(self):
        output = Tensor(np.maximum(self.data, 0), parents=(self,))
        def grad_fn():
            self.grad += output.grad * (self.data > 0)
        output.grad_fn = grad_fn
        return output

    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], tuple):
            shape = shape[0]
        output = Tensor(self.data.reshape(shape), parents=(self,))
        def grad_fn():
            self.grad += output.grad.reshape(self.shape)
        output.grad_fn = grad_fn
        return output

    def transpose(self, *axes):
        if len(axes) == 1 and isinstance(axes[0], tuple):
            axes = axes[0]
        output = Tensor(self.data.transpose(axes), parents=(self,))
        def grad_fn():
            inv = [0] * len(axes)
            for i, a in enumerate(axes):
                inv[a] = i
            self.grad += output.grad.transpose(inv)
        output.grad_fn = grad_fn
        return output

    def pad(self, pad_width):
        output = Tensor(np.pad(self.data, pad_width), parents=(self,))
        def grad_fn():
            slices = tuple(slice(p[0], p[0] + s) for s, p in zip(self.shape, pad_width))
            self.grad += output.grad[slices]
        output.grad_fn = grad_fn
        return output

    def unfold(self, dimension, size, step):
        n = self.shape[dimension]
        n_windows = (n - size) // step + 1
        strides = self.data.strides
        new_shape = self.shape[:dimension] + (n_windows,) + self.shape[dimension+1:] + (size,)
        new_strides = strides[:dimension] + (strides[dimension]*step,) + strides[dimension+1:] + (strides[dimension],)
        col = np.lib.stride_tricks.as_strided(
            self.data, shape=new_shape, strides=new_strides,
        ).copy()
        output = Tensor(col, parents=(self,))
        def grad_fn():
            dx = np.zeros(self.shape)
            for i in range(size):
                src = [slice(None)] * output.grad.ndim
                src[-1] = i
                dst = [slice(None)] * self.ndim
                dst[dimension] = slice(i, i + step*n_windows, step)
                dx[tuple(dst)] += output.grad[tuple(src)]
            self.grad += dx
        output.grad_fn = grad_fn
        return output