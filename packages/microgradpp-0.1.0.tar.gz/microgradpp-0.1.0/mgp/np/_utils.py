import numpy as np

def unbroadcast(grad, shape):
    if grad.shape == shape:
        return grad
    
    ndim_grad = grad.ndim
    ndim_shape = len(shape)
    
    # 1. sum out extra leading dimensions
    new_grad = grad.sum(axis=tuple(range(ndim_grad - ndim_shape)), keepdims=False)
    
    # 2. sum out broadcasted dimensions (where shape has 1)
    axes_to_sum = tuple((np.array(shape) != np.array(new_grad.shape)).nonzero()[0])
    new_grad = new_grad.sum(axis=axes_to_sum, keepdims=True)
    return new_grad
