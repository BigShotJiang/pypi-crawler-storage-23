import numpy as np
from .tensor import Tensor

class MSELoss:
    # takes predictions (N, *) and targets (N, *)
    def __call__(self, input: Tensor, target: Tensor):
        N = input.shape[0]
        return ((input - target) ** 2).sum() * (1.0 / N)

class BCELoss:
    # takes probabilities (N, *) and binary targets (N, *)
    def __call__(self, input: Tensor, target: Tensor):
        N = input.shape[0]
        return (-target * input.log() - (1 - target) * (1 - input).log()).sum() * (1.0 / N)

class CrossEntropyLoss:
    # takes logits (N, C, *) and integer labels (N, *)
    def __call__(self, input: Tensor, target: Tensor):
        N, C = input.shape[:2]
        # numerically stable log-softmax along class dim
        max_logits = input.max(dim=1, keepdim=True).detach()
        shifted = input - max_logits
        log_sum_exp = shifted.exp().sum(dim=1, keepdim=True).log()
        log_probs = shifted - log_sum_exp
        # one-hot encode targets for NLL
        one_hot = np.moveaxis(np.eye(C)[target.data], -1, 1)  # (N, *, C) -> (N, C, *)
        loss = -(Tensor(one_hot) * log_probs).sum() * (1.0 / N)
        return loss