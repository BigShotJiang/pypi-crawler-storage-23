from .tensor import Tensor
from .loss import *
import numpy as np

class Module:
    def __init__(self):
        self.parameters = []

    def __setattr__(self, name, value):
        if isinstance(value, Module):
            self.parameters.extend(value.parameters)
        super().__setattr__(name, value)

    def __call__(self, x):
        return x

class Linear(Module):
    def __init__(self, in_features, out_features):
        super().__init__()
        # Kaiming uniform initialization
        self.W = Tensor(np.random.uniform(-np.sqrt(1 / in_features), np.sqrt(1 / in_features), (in_features, out_features)))
        self.b = Tensor(np.random.uniform(-np.sqrt(1 / in_features), np.sqrt(1 / in_features), (out_features,)))
        self.parameters.extend([self.W, self.b])

    def __call__(self, x: Tensor):
        return x @ self.W + self.b

class ReLU(Module):
    def __init__(self):
        super().__init__()

    def __call__(self, x: Tensor):
        return x.relu()

class Conv2d(Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0):
        super().__init__()
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        if isinstance(stride, int):
            stride = (stride, stride)
        if isinstance(padding, int):
            padding = (padding, padding)
        self.stride = stride
        self.padding = padding
        self.kernel_size = kernel_size
        # Kaiming uniform initialization
        fan_in = in_channels * kernel_size[0] * kernel_size[1]
        bound = np.sqrt(1 / fan_in)
        self.W = Tensor(np.random.uniform(-bound, bound, (out_channels, in_channels, *kernel_size)))
        self.b = Tensor(np.random.uniform(-bound, bound, (out_channels,)))
        self.parameters.extend([self.W, self.b])

    def __call__(self, x: Tensor):
        # x: (N, C_in, H, W)
        N, C_in = x.data.shape[:2]
        kH, kW = self.kernel_size
        pH, pW = self.padding
        C_out = self.W.data.shape[0]

        sH, sW = self.stride
        if pH > 0 or pW > 0:
            x = x.pad(((0,0),(0,0),(pH,pH),(pW,pW)))

        # (N, C_in, H, W) -> (N, C_in, H_out, W, kH) -> (N, C_in, H_out, W_out, kH, kW)
        col = x.unfold(2, kH, sH).unfold(3, kW, sW)
        H_out, W_out = col.data.shape[2], col.data.shape[3]

        col = col.transpose(0, 2, 3, 1, 4, 5).reshape(N * H_out * W_out, C_in * kH * kW)
        W_flat = self.W.reshape(C_out, C_in * kH * kW)

        out = col @ W_flat.transpose(1, 0) + self.b
        return out.reshape(N, H_out, W_out, C_out).transpose(0, 3, 1, 2)

class ModuleList(Module):
    def __init__(self, modules):
        super().__init__()
        self.modules = modules
        for module in self.modules:
            self.parameters.extend(module.parameters)

    def __iter__(self):
        return iter(self.modules)