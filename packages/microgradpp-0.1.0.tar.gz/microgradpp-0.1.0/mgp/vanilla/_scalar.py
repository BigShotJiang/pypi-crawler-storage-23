class Scalar:
    def __init__(self, data: float, parents=()):
        self.data = data
        self.grad = 0
        self.grad_fn = lambda: None
        self.parents = parents
    
    def __repr__(self):
        return f"Scalar(data={self.data}, grad={self.grad})"

    def __add__(self, other):
        other = other if isinstance(other, Scalar) else Scalar(other)
        output = Scalar(self.data + other.data, parents=(self, other))
        def grad_fn():
            self.grad += output.grad
            other.grad += output.grad
        output.grad_fn = grad_fn
        return output
        
    def __mul__(self, other):
        other = other if isinstance(other, Scalar) else Scalar(other)
        output = Scalar(self.data * other.data, parents=(self, other))
        def grad_fn():
            self.grad += output.grad * other.data
            other.grad += output.grad * self.data
        output.grad_fn = grad_fn
        return output
    
    def __pow__(self, other: float | int):
        output = Scalar(self.data ** other, parents=(self,))
        def grad_fn():
            self.grad += output.grad * other * self.data**(other - 1)
        output.grad_fn = grad_fn
        return output

    def backward(self, grad=1):
        nodes = []
        visited = set()
        def dfs(node):
            if node not in visited:
                visited.add(node)
                for parent in node.parents:
                    dfs(parent)
                nodes.append(node)
        dfs(self)

        self.grad = grad
        for node in reversed(nodes):
            node.grad_fn()

    def relu(self):
        if self.data > 0:
            output = Scalar(self.data, parents=(self,))
            def grad_fn():
                self.grad += output.grad
            output.grad_fn = grad_fn
        else:
            output = Scalar(0, parents=(self,))
        return output

    def __neg__(self):
        return self * -1
    
    def __sub__(self, other):
        return self + (-other)

    def __truediv__(self, other):
        return self * other**-1

    def __radd__(self, other):
        return self + other
    
    def __rmul__(self, other):
        return self * other
    
    def __rsub__(self, other):
        return other + (-self)
    
    def __rtruediv__(self, other):
        return other * self**-1