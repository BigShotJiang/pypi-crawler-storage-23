from ._scalar import Scalar
import random
import math

class Module:
    def __init__(self):
        self.parameters = []

    def __setattr__(self, name, value):
        if isinstance(value, Module):
            self.parameters.extend(value.parameters)
        super().__setattr__(name, value)

    def __call__(self, x):
        return x

class Neuron(Module):
    def __init__(self, input_dim):
        super().__init__()
        # Kaiming uniform initialization
        self.weights = [Scalar(random.uniform(-math.sqrt(1 / input_dim), math.sqrt(1 / input_dim))) for _ in range(input_dim)]
        self.bias = Scalar(random.uniform(-math.sqrt(1 / input_dim), math.sqrt(1 / input_dim)))
        self.parameters.extend(self.weights + [self.bias])
    
    def __call__(self, x: list[Scalar]):
        return sum([component * weight for component, weight in zip(x, self.weights)]) + self.bias

class ModuleList(Module):
    def __init__(self, modules):
        super().__init__()
        self.modules = modules
        for module in self.modules:
            self.parameters.extend(module.parameters)
    
    def __iter__(self):
        return iter(self.modules)

class Linear(Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.neurons = ModuleList([Neuron(input_dim) for _ in range(output_dim)])

    def __call__(self, x: list[Scalar]):
        return [neuron(x) for neuron in self.neurons]

class ReLU(Module):
    def __init__(self):
        super().__init__()

    def __call__(self, x: list[Scalar]):
        return [component.relu() for component in x]

class MSELoss:
    def __call__(self, output: list[Scalar], target: list):
        return 1/len(output) * sum([(output_i - target_i) ** 2 for output_i, target_i in zip(output, target)])