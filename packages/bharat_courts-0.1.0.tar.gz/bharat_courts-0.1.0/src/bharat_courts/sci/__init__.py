"""Supreme Court of India client (main.sci.gov.in)."""

from bharat_courts.sci.client import SCIClient

__all__ = ["SCIClient"]
