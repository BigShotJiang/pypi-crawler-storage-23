# -*- coding: utf-8 -*-


class ConfigurationError(Exception):
    """設定に関するエラーを表す例外"""

    pass
