"""Alias for ice4 (Poetry does not install symlinks)."""
from genice3.unitcell.ice4 import UnitCell, desc
