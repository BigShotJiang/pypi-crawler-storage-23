"""Alias for Struct54 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct54 import UnitCell, desc
