"""Alias for C14 (Poetry does not install symlinks)."""
from genice3.unitcell.C14 import UnitCell, desc
