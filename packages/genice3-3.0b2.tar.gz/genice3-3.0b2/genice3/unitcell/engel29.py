"""Alias for MAR (Poetry does not install symlinks)."""
from genice3.unitcell.MAR import UnitCell, desc
