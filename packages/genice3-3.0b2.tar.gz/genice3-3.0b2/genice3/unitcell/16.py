"""Alias for CS2 (Poetry does not install symlinks)."""
from genice3.unitcell.CS2 import UnitCell, desc
