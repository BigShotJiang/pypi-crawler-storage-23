"""Alias for Struct37 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct37 import UnitCell, desc
