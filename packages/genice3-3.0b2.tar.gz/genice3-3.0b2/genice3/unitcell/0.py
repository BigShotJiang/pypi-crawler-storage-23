"""Alias for ice0 (Poetry does not install symlinks)."""
from genice3.unitcell.ice0 import UnitCell, desc
