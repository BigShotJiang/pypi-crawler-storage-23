"""Alias for ice14 (Poetry does not install symlinks)."""
from genice3.unitcell.ice14 import UnitCell, desc
