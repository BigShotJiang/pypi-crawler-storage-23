"""Alias for Struct16 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct16 import UnitCell, desc
