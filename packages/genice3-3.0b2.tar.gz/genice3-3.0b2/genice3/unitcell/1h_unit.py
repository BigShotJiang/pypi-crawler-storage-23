"""Alias for ice1h_unit (Poetry does not install symlinks)."""
from genice3.unitcell.ice1h_unit import UnitCell, desc
