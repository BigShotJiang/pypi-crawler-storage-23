"""Alias for ice7 (Poetry does not install symlinks)."""
from genice3.unitcell.ice7 import UnitCell, desc
