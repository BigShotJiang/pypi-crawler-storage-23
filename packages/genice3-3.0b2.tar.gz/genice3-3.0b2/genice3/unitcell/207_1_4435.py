"""Alias for SOD (Poetry does not install symlinks)."""
from genice3.unitcell.SOD import UnitCell, desc
