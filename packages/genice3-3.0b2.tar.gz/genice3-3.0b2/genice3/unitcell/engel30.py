"""Alias for PCOD8324623 (Poetry does not install symlinks)."""
from genice3.unitcell.PCOD8324623 import UnitCell, desc
