"""Alias for iceA (Poetry does not install symlinks)."""
from genice3.unitcell.iceA import UnitCell, desc
