"""Alias for Struct25 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct25 import UnitCell, desc
