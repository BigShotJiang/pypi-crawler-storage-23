#!/usr/bin/python
# coding: utf-8

import numpy as np
from cif2ice import cellvectors
from genice3.util import atomdic, symmetry_operators, waters_and_pairs
import genice3.unitcell
from logging import getLogger
import networkx as nx

desc = {
    "ref": {"M": "Mochizuki 2024"},
    "usage": "No options available.",
    "brief": "A hypothetical hydrogen-ordered high-density ice.",
    "test": ({"options": "--depol=none"},),
}


class UnitCell(genice3.unitcell.UnitCell):
    SUPPORTS_ION_DOPING = False  # 水素秩序氷
    def __init__(self, **kwargs):
        logger = getLogger()

        # only the hydrogen atoms whose locations are confirmed are listed.
        atoms = """
O1     0.34919  0.81250  0.29286  1.00000 Dx,Dy,Dz 
H1     0.51098  0.72368  0.32678  1.00000 Dx,Dy,Dz 
H2     0.45942 -0.08553  0.25446  1.00000 Dx,Dy,Dz 
O2     0.83457  0.87829  0.89464  1.00000 Dx,Dy,Dz 
H3     0.75474 -0.02895 -0.02053  1.00000 Dx,Dy,Dz 
H4     0.00714  0.82829  0.00893  1.00000 Dx,Dy,Dz 
O3     0.37618  0.61447  0.80625  1.00000 Dx,Dy,Dz 
H5     0.21915  0.63619  0.66429  1.00000 Dx,Dy,Dz 
H6     0.52378  0.70921  0.81429  1.00000 Dx,Dy,Dz 
O4     0.14808  0.05789  0.58482  1.00000 Dx,Dy,Dz 
H7     0.03727  0.00066  0.69196  1.00000 Dx,Dy,Dz 
H8     0.21503 -0.03684  0.49553  1.00000 Dx,Dy,Dz 
        """

        # space group: P 1 21 1 No. 4
        # http://img.chem.ucl.ac.uk/sgp/large/004ay1.htm
        symops = """
x,y,z
-x,y+1/2,-z
    """.translate(
            {ord(","): " "}
        )

        a = 4.3 / 10.0  # nm
        b = 7.6 / 10.0  # nm
        c = 5.727 / 10.0  # nm
        A = 90
        B = 102.09
        C = 90

        cell = cellvectors(a, b, c, A, B, C)

        # helper routines to make from CIF-like data
        atomd = atomdic(atoms)
        sops = symmetry_operators(symops)
        waters, fixed, pairs = waters_and_pairs(
            cell, atomd, sops, rep=[2, 1, 2], partial_order=True
        )

        density = 18 * len(waters) / 6.022e23 / (np.linalg.det(cell) * 1e-21)
        coord = "relative"

        super().__init__(
            cell=cell,
            lattice_sites=waters,
            density=density,
            coord=coord,
            graph=nx.Graph(pairs),
            fixed=nx.DiGraph(fixed),
            **kwargs,
        )
