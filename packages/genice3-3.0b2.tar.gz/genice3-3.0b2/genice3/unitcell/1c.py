"""Alias for ice1c (Poetry does not install symlinks)."""
from genice3.unitcell.ice1c import UnitCell, desc
