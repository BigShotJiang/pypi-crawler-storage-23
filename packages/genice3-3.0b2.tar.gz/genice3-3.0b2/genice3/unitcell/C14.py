"""Alias for Struct68 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct68 import UnitCell, desc
