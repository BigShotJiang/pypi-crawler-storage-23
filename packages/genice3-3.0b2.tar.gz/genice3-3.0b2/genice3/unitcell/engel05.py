"""Alias for BSV (Poetry does not install symlinks)."""
from genice3.unitcell.BSV import UnitCell, desc
