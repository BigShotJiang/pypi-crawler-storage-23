"""Alias for Struct38 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct38 import UnitCell, desc
