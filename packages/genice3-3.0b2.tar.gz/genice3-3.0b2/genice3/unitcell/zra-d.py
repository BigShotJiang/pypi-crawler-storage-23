"""Alias for Struct17 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct17 import UnitCell, desc
