"""Alias for SGT (Poetry does not install symlinks)."""
from genice3.unitcell.SGT import UnitCell, desc
