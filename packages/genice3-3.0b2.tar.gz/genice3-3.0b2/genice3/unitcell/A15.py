"""Alias for Struct33 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct33 import UnitCell, desc
