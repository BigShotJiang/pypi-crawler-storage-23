"""Alias for ice6 (Poetry does not install symlinks)."""
from genice3.unitcell.ice6 import UnitCell, desc
