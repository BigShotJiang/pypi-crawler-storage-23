"""Alias for LTA (Poetry does not install symlinks)."""
from genice3.unitcell.LTA import UnitCell, desc
