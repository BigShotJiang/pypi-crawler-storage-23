"""Alias for HS1 (Poetry does not install symlinks)."""
from genice3.unitcell.HS1 import UnitCell, desc
