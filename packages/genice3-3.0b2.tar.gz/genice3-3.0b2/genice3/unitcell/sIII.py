"""Alias for TS1 (Poetry does not install symlinks)."""
from genice3.unitcell.TS1 import UnitCell, desc
