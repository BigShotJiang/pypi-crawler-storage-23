"""Alias for ice12 (Poetry does not install symlinks)."""
from genice3.unitcell.ice12 import UnitCell, desc
