"""Alias for iceB (Poetry does not install symlinks)."""
from genice3.unitcell.iceB import UnitCell, desc
