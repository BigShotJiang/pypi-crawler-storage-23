"""Alias for DDR (Poetry does not install symlinks)."""
from genice3.unitcell.DDR import UnitCell, desc
