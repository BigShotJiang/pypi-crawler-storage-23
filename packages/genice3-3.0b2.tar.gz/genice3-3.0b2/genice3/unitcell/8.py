"""Alias for ice8 (Poetry does not install symlinks)."""
from genice3.unitcell.ice8 import UnitCell, desc
