"""Alias for PCOD8301974 (Poetry does not install symlinks)."""
from genice3.unitcell.PCOD8301974 import UnitCell, desc
