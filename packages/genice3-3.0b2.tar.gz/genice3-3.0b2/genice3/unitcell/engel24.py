"""Alias for PCOD8007225 (Poetry does not install symlinks)."""
from genice3.unitcell.PCOD8007225 import UnitCell, desc
