"""Alias for ice2 (Poetry does not install symlinks)."""
from genice3.unitcell.ice2 import UnitCell, desc
