"""Alias for ice3 (Poetry does not install symlinks)."""
from genice3.unitcell.ice3 import UnitCell, desc
