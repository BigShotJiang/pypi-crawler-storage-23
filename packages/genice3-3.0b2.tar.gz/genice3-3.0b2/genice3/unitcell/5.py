"""Alias for ice5 (Poetry does not install symlinks)."""
from genice3.unitcell.ice5 import UnitCell, desc
