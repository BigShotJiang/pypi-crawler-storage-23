"""Alias for ice13 (Poetry does not install symlinks)."""
from genice3.unitcell.ice13 import UnitCell, desc
