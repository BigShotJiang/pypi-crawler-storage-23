"""Alias for iceM (Poetry does not install symlinks)."""
from genice3.unitcell.iceM import UnitCell, desc
