"""Alias for ice11 (Poetry does not install symlinks)."""
from genice3.unitcell.ice11 import UnitCell, desc
