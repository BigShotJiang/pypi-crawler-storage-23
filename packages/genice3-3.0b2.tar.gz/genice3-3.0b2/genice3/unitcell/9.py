"""Alias for ice9 (Poetry does not install symlinks)."""
from genice3.unitcell.ice9 import UnitCell, desc
