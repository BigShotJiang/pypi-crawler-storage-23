"""Alias for Struct24 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct24 import UnitCell, desc
