"""Alias for ice1h (Poetry does not install symlinks)."""
from genice3.unitcell.ice1h import UnitCell, desc
