"""Alias for Struct04 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct04 import UnitCell, desc
