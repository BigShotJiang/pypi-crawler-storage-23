"""Alias for 151_2_4949650 (Poetry does not install symlinks)."""
import importlib
_real = importlib.import_module("genice3.unitcell.151_2_4949650")
UnitCell = _real.UnitCell
desc = _real.desc
