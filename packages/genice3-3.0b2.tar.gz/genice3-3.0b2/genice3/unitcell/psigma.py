"""Alias for Struct55 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct55 import UnitCell, desc
