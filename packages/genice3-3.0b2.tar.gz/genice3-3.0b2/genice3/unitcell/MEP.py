"""Alias for CS1 (Poetry does not install symlinks)."""
from genice3.unitcell.CS1 import UnitCell, desc
