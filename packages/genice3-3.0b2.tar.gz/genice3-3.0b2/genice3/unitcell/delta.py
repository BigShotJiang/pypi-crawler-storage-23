"""Alias for Struct23 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct23 import UnitCell, desc
