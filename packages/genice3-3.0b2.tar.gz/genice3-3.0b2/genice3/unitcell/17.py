"""Alias for ice17 (Poetry does not install symlinks)."""
from genice3.unitcell.ice17 import UnitCell, desc
