"""Alias for PCOD8321499 (Poetry does not install symlinks)."""
from genice3.unitcell.PCOD8321499 import UnitCell, desc
