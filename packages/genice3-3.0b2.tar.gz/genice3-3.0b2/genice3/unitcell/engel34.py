"""Alias for NON (Poetry does not install symlinks)."""
from genice3.unitcell.NON import UnitCell, desc
