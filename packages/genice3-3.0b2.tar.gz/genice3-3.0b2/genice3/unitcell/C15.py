"""Alias for Struct19 (Poetry does not install symlinks)."""
from genice3.unitcell.Struct19 import UnitCell, desc
