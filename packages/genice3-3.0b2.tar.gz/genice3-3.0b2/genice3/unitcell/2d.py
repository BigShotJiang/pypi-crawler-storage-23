"""Alias for ice2d (Poetry does not install symlinks)."""
from genice3.unitcell.ice2d import UnitCell, desc
