"""Alias for tip3p (Poetry does not install symlinks)."""
from genice3.molecule.tip3p import Molecule, desc
