"""Alias for tip4p (Poetry does not install symlinks)."""
from genice3.molecule.tip4p import Molecule, desc
