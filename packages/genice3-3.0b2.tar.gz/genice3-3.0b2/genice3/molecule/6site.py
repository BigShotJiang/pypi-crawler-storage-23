"""Alias for NvdE (Poetry does not install symlinks)."""

from genice3.molecule.NvdE import Molecule, desc
