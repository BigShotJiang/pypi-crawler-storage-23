"""Alias for tip5p (Poetry does not install symlinks)."""
from genice3.molecule.tip5p import Molecule, desc
