"""Moss Agent Session - Drop-in replacement for LiveKit AgentSession.

Provides a simplified interface that handles provider configuration and
credentials internally based on MOSS_* environment variables.
"""

from typing import TypeVar, Generic, Optional
from livekit.agents import JobContext
from livekit.agents.voice import AgentSession
from livekit import api
import logging
import httpx
import asyncio

from .config import MossConfig
from .providers import create_stt_provider, create_llm_provider, create_tts_provider
from .metrics import MossMetrics
from .diagnostics import MetricsCollector

# Import VAD
from livekit.plugins import silero

logger = logging.getLogger(__name__)


class ModelInfoFilter(logging.Filter):
    """Filter for model names and providers in logs."""

    def __init__(self, models_to_mask=None):
        super().__init__()
        self.models_to_mask = models_to_mask or {}
        # Common provider name mappings
        self.provider_mappings = {
            'Deepgram': 'Moss',
            'Cartesia': 'Moss',
            'Gemini': 'Moss',
            'Google': 'Moss',
            'OpenAI': 'Moss',
        }

    def filter(self, record):
        # Mask model_name and model_provider in extra fields (structured logging)
        if hasattr(record, 'model_name'):
            record.model_name = "moss-managed"
        if hasattr(record, 'model_provider') and record.model_provider in self.provider_mappings:
            record.model_provider = self.provider_mappings[record.model_provider]

        # Mask in message text
        if hasattr(record, 'msg'):
            msg = str(record.msg)
            if 'metrics' in msg.lower():
                # Mask model names
                for model_name in self.models_to_mask.values():
                    if model_name:
                        msg = msg.replace(model_name, 'moss-managed')
                # Mask provider names
                for provider, replacement in self.provider_mappings.items():
                    msg = msg.replace(provider, replacement)
                record.msg = msg

        return True


T = TypeVar("T")


class MossAgentSession(AgentSession[T], Generic[T]):
    """Drop-in replacement for AgentSession that handles configuration internally.

    This class wraps LiveKit's AgentSession and automatically:
    - Reads configuration from platform-injected module (no env vars needed)
    - Creates and configures TTS, STT, and LLM providers
    - Provides LiveKit API credentials
    - Tracks metrics to local file

    The Moss platform automatically injects all configuration during deployment.
    Users don't need to set any environment variables or configuration files.

    Example:
        ```python
        from moss_agent import MossAgentSession

        session = MossAgentSession[InterviewData](
            userdata=interview_data,
            vad=vad,
            turn_detection=turn_detection,
            max_tool_steps=10,
        )

        # Access platform API (credentials from platform)
        platform_api = session.platform_api
        ```
    """

    def __init__(
        self,
        userdata: T,
        vad=None,
        turn_detection=None,
        max_tool_steps: Optional[int] = None,
    ):
        """Initialize MossAgentSession.

        Args:
            userdata: User-defined data object (generic type T)
            vad: Voice Activity Detection instance (optional, auto-created if None)
            turn_detection: Turn detection instance (optional, NOT auto-created)
            max_tool_steps: Maximum number of tool steps (optional)

        Raises:
            RuntimeError: If platform configuration is invalid or missing
        """
        logger.info("Initializing MossAgentSession")

        # Load configuration from platform-injected module
        logger.info("Loading platform configuration")
        self._config = MossConfig.from_platform()
        logger.info(f"Platform config loaded - LLM: {self._config.llm_model}, STT: {self._config.stt_model}, TTS: {self._config.tts_model}")

        # Install log filter to mask proprietary model information
        models_to_mask = {
            'llm': self._config.llm_model,
            'stt': self._config.stt_model,
            'tts': self._config.tts_model,
        }
        livekit_logger = logging.getLogger('livekit.agents')
        livekit_logger.addFilter(ModelInfoFilter(models_to_mask))

        # Create providers internally based on configuration
        logger.info("Creating STT provider")
        stt = create_stt_provider(self._config)
        logger.info(f"STT provider created: {type(stt).__name__}")

        logger.info("Creating LLM provider")
        llm = create_llm_provider(self._config)
        logger.info(f"LLM provider created: {type(llm).__name__}")

        logger.info("Creating TTS provider")
        tts = create_tts_provider(self._config)
        logger.info(f"TTS provider created: {type(tts).__name__}")

        # Set up VAD automatically if not provided
        if vad is None:
            logger.info("VAD not provided, auto-initializing")
            vad = self._setup_vad()
        else:
            logger.info(f"Using provided VAD: {type(vad).__name__}")

        # Turn detection is NOT auto-initialized since it requires downloading model files
        # Users can pass turn_detection explicitly if they have the models downloaded
        if turn_detection is None:
            logger.info("Turn detection not provided and will not be auto-initialized")
        else:
            logger.info(f"Using provided turn detection: {type(turn_detection).__name__}")

        # Initialize parent AgentSession with configured providers
        logger.info("Initializing AgentSession with providers")
        super().__init__(
            userdata=userdata,
            stt=stt,
            llm=llm,
            tts=tts,
            vad=vad,
            turn_detection=turn_detection,
            min_endpointing_delay=self._config.min_endpointing_delay,
            max_endpointing_delay=self._config.max_endpointing_delay,
            preemptive_generation=self._config.preemptive_generation,
            max_tool_steps=max_tool_steps,
        )
        logger.info("AgentSession initialized successfully")

        # Initialize platform API with credentials
        logger.info("Initializing platform API")
        self._platform_api = api.LiveKitAPI(
            url=self._config.platform_ws_url,
            api_key=self._config.platform_api_key,
            api_secret=self._config.platform_api_secret,
        )
        logger.info("Platform API initialized")

        # Initialize metrics tracking
        logger.info(f"Initializing metrics tracker for agent {self._config.agent_id}")
        self._metrics = MossMetrics(agent_id=self._config.agent_id)

        # Initialize detailed diagnostics collector
        logger.info("Initializing diagnostics metrics collector")
        self._diagnostics = MetricsCollector(session_id=self._config.agent_id)

        # Set up metrics collection from LiveKit events if available
        self._setup_metrics_tracking()

        # Store room name for metrics submission (will be set when start() is called)
        self._room_name: Optional[str] = None

        logger.info("MossAgentSession initialization complete")

    @property
    def platform_api(self) -> api.LiveKitAPI:
        """Get platform API client with credentials.

        Returns:
            API client instance configured with Moss platform credentials
        """
        return self._platform_api

    @property
    def metrics(self) -> MossMetrics:
        """Get metrics tracker.

        Returns:
            MossMetrics instance for recording and saving metrics
        """
        return self._metrics

    @property
    def diagnostics(self) -> MetricsCollector:
        """Get diagnostics metrics collector.

        Returns:
            MetricsCollector instance for detailed performance tracking
        """
        return self._diagnostics

    async def start(self, *args, **kwargs):
        """Override start to capture room name and register shutdown callback."""
        # Capture room name from kwargs
        room = kwargs.get('room')
        if room:
            self._room_name = room.name
            logger.info(f"Captured room name for metrics: {self._room_name}")

            # Register shutdown callback to submit metrics
            @room.on("disconnected")
            def on_disconnected():
                """Submit metrics when session ends."""
                if self._room_name:
                    logger.info("Session disconnected, submitting usage metrics...")
                    # Create task to submit metrics
                    asyncio.create_task(self.submit_metrics_to_backend(self._room_name))

        # Call parent start method
        return await super().start(*args, **kwargs)

    def _setup_vad(self):
        """Set up Voice Activity Detection automatically.

        Initializes Silero VAD for voice activity detection.

        Returns:
            VAD instance or None if initialization fails
        """
        try:
            vad = silero.VAD.load()
            logger.info("Silero VAD initialized successfully")
            return vad
        except Exception as e:
            logger.warning(
                f"Failed to initialize Silero VAD: {e}. "
                "Continuing without VAD."
            )
            return None

    def _setup_metrics_tracking(self):
        """Set up automatic metrics tracking from LiveKit events.

        This method hooks into LiveKit's metrics collection events to
        automatically track LLM, TTS, and STT usage.
        """
        @self.on("metrics_collected")
        def _on_metrics_collected(ev):
            """Collect detailed diagnostics metrics from LiveKit events."""
            try:
                # ev.metrics is a SINGLE metric object, not a list
                metric = ev.metrics
                metric_type = type(metric).__name__

                # Skip logging VAD metrics (too frequent)
                if metric_type != "VADMetrics":
                    logger.debug(f"📊 Processing {metric_type}")

                # LLM metrics
                if hasattr(metric, 'ttft'):
                    ttft_ms = metric.ttft * 1000 if metric.ttft else 0
                    # Calculate duration from tokens_per_second if not directly available
                    tokens_output = getattr(metric, 'completion_tokens', 0) or 0
                    tps = getattr(metric, 'tokens_per_second', 0) or 0
                    duration_ms = (tokens_output / tps * 1000) if tps > 0 else 0

                    tokens_input = getattr(metric, 'prompt_tokens', 0) or 0
                    tokens_total = tokens_input + tokens_output

                    if ttft_ms > 0:  # Valid LLM metric
                        logger.info(f"✅ Adding LLM metric: TTFT={ttft_ms:.0f}ms, tokens={tokens_total}")
                        self._diagnostics.add_llm_metric(
                            ttft_ms=ttft_ms,
                            duration_ms=duration_ms,
                            tokens_input=tokens_input,
                            tokens_output=tokens_output,
                            tokens_total=tokens_total
                        )

                # TTS metrics
                if hasattr(metric, 'ttfb'):
                    ttfb_ms = metric.ttfb * 1000 if metric.ttfb else 0
                    audio_duration = getattr(metric, 'audio_duration', 0) or 0
                    audio_duration_ms = audio_duration * 1000 if audio_duration else 0
                    # Duration is roughly ttfb + time to generate audio
                    duration_ms = ttfb_ms + (audio_duration_ms / 10)  # Approximate generation time
                    chars = getattr(metric, 'characters_count', 0) or 0

                    if ttfb_ms > 0:  # Valid TTS metric
                        logger.info(f"✅ Adding TTS metric: TTFB={ttfb_ms:.0f}ms, audio={audio_duration_ms:.0f}ms")
                        self._diagnostics.add_tts_metric(
                            ttfb_ms=ttfb_ms,
                            duration_ms=duration_ms,
                            audio_duration_ms=audio_duration_ms,
                            chars=chars
                        )

                # STT metrics
                if hasattr(metric, 'audio_duration') and not hasattr(metric, 'ttfb'):
                    # STT has audio_duration but not ttfb (differentiates from TTS)
                    audio_duration = getattr(metric, 'audio_duration', 0) or 0
                    delay_ms = audio_duration * 1000 if audio_duration else 0
                    if delay_ms > 0:
                        logger.info(f"✅ Adding STT metric: delay={delay_ms:.0f}ms")
                        self._diagnostics.add_stt_metric(transcription_delay_ms=delay_ms)

                # VAD metrics (if available)
                if hasattr(metric, 'inference_duration'):
                    inference_ms = metric.inference_duration * 1000 if metric.inference_duration else 0
                    idle_ms = getattr(metric, 'idle_duration', 0) * 1000 if hasattr(metric, 'idle_duration') else 0
                    if inference_ms > 0:
                        logger.info(f"✅ Adding VAD metric: inference={inference_ms:.2f}ms")
                        self._diagnostics.add_vad_metric(inference_ms=inference_ms, idle_ms=idle_ms)

                # EOU metrics
                if hasattr(metric, 'end_of_utterance_delay'):
                    eou_delay_ms = metric.end_of_utterance_delay * 1000 if metric.end_of_utterance_delay else 0
                    stt_processing_ms = getattr(metric, 'transcription_delay', 0) * 1000 if hasattr(metric, 'transcription_delay') else 0
                    if eou_delay_ms > 0:
                        logger.info(f"✅ Adding EOU metric: delay={eou_delay_ms:.0f}ms, STT={stt_processing_ms:.0f}ms")
                        self._diagnostics.add_eou_metric(
                            eou_delay_ms=eou_delay_ms,
                            stt_processing_ms=stt_processing_ms
                        )
            except Exception as e:
                logger.error(f"Error in metrics collection handler: {e}", exc_info=True)

    def save_metrics(self):
        """Save metrics to local file.

        Returns:
            Path to saved metrics file
        """
        return self._metrics.save()

    def generate_diagnostics_report(self) -> str:
        """Generate a detailed diagnostics report.

        Returns:
            Formatted string report with all performance metrics
        """
        return self._diagnostics.generate_report()

    def log_diagnostics_report(self):
        """Generate and log the diagnostics report."""
        report = self.generate_diagnostics_report()
        logger.info("\n" + report)

    async def submit_metrics_to_backend(self, room_name: str) -> None:
        """Submit usage metrics to Moss backend for tracking.

        Args:
            room_name: Name of the LiveKit room for this session

        This method is called automatically at session shutdown.
        """
        try:
            # Get usage metrics from diagnostics
            usage_metrics = self._diagnostics.get_usage_metrics(room_name=room_name)

            # Add project and voice agent IDs from config
            usage_metrics["voice_agent_id"] = self._config.voice_agent_id
            usage_metrics["project_id"] = self._config.project_id

            # Determine backend URL
            backend_url = self._config.backend_url
            metrics_endpoint = f"{backend_url}/api/voice-agent/metrics"

            # Submit metrics to backend
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    metrics_endpoint,
                    json=usage_metrics,
                    headers={
                        "X-Project-Id": self._config.project_id,
                        "X-Project-Key": self._config.project_key,
                    },
                )
                response.raise_for_status()
                logger.info(f"✅ Usage metrics submitted successfully")

        except httpx.HTTPError as e:
            logger.error(f"❌ HTTP error submitting usage metrics: {e}")
        except Exception as e:
            logger.error(f"❌ Error submitting usage metrics: {e}", exc_info=True)
