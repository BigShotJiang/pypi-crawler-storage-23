"""Metrics tracking for Moss Agent.

Tracks LLM, TTS, and STT metrics and saves to local file.
"""

import json
from pathlib import Path
from typing import Dict, Any
from datetime import datetime


class MossMetrics:
    """Tracks agent metrics and saves to local file."""

    def __init__(self, agent_id: str, output_dir: str = "."):
        """Initialize metrics tracker.

        Args:
            agent_id: Unique identifier for the agent
            output_dir: Directory to save metrics file (default: current directory)
        """
        self.agent_id = agent_id
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Metrics storage
        self.metrics: Dict[str, Any] = {
            "agent_id": agent_id,
            "session_start": datetime.utcnow().isoformat(),
            "llm": {
                "total_calls": 0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "total_tokens": 0,
            },
            "tts": {
                "total_calls": 0,
                "total_characters": 0,
            },
            "stt": {
                "total_calls": 0,
                "total_duration_seconds": 0,
            },
        }

    def record_llm_call(self, input_tokens: int, output_tokens: int):
        """Record an LLM API call.

        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
        """
        self.metrics["llm"]["total_calls"] += 1
        self.metrics["llm"]["total_input_tokens"] += input_tokens
        self.metrics["llm"]["total_output_tokens"] += output_tokens
        self.metrics["llm"]["total_tokens"] += input_tokens + output_tokens

    def record_tts_call(self, characters: int):
        """Record a TTS API call.

        Args:
            characters: Number of characters synthesized
        """
        self.metrics["tts"]["total_calls"] += 1
        self.metrics["tts"]["total_characters"] += characters

    def record_stt_call(self, duration_seconds: float):
        """Record an STT API call.

        Args:
            duration_seconds: Duration of audio transcribed in seconds
        """
        self.metrics["stt"]["total_calls"] += 1
        self.metrics["stt"]["total_duration_seconds"] += duration_seconds

    def save(self):
        """Save metrics to file.

        Saves to {output_dir}/moss_metrics_{agent_id}_{timestamp}.json
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"moss_metrics_{self.agent_id}_{timestamp}.json"
        filepath = self.output_dir / filename

        # Add session end time
        self.metrics["session_end"] = datetime.utcnow().isoformat()

        # Write to file
        with open(filepath, "w") as f:
            json.dump(self.metrics, f, indent=2)

        return filepath

    def get_summary(self) -> Dict[str, Any]:
        """Get current metrics summary.

        Returns:
            Dictionary with current metrics
        """
        return self.metrics.copy()
