"""Provider factories for TTS, STT, and LLM.

Creates configured provider instances based on MossConfig.
NO fallback defaults - raises errors for unknown configurations.
"""

from livekit.agents import tts, stt, llm
from livekit.plugins import deepgram, google, cartesia

from .config import MossConfig


def create_stt_provider(config: MossConfig) -> stt.STT:
    """Create STT provider based on configuration.

    Args:
        config: MossConfig instance with stt_model and stt_language

    Returns:
        Configured STT provider instance

    Raises:
        ValueError: If stt_model is not supported
    """
    model = config.stt_model
    language = config.stt_language

    # Deepgram models
    if model in ["nova-2-general", "nova-2-meeting", "nova-2-phonecall", "nova-2-finance", "nova-2-conversationalai", "nova-2-voicemail", "nova-2-video", "nova-2-medical", "nova-2-drivethru", "nova-2-automotive"]:
        return deepgram.STT(
            api_key=config.deepgram_api_key,
            model=model,
            language=language,
        )

    raise ValueError(
        f"Unsupported STT model: {model}. "
        f"Supported models: Deepgram Nova-2 series"
    )


def create_llm_provider(config: MossConfig) -> llm.LLM:
    """Create LLM provider based on configuration.

    Args:
        config: MossConfig instance with llm_model

    Returns:
        Configured LLM provider instance

    Raises:
        ValueError: If llm_model is not supported
    """
    model = config.llm_model

    # Google Gemini models
    if model.startswith("gemini-"):
        return google.LLM(
            api_key=config.google_api_key,
            model=model,
        )

    raise ValueError(
        f"Unsupported LLM model: {model}. "
        f"Supported models: Google Gemini series"
    )


def create_tts_provider(config: MossConfig) -> tts.TTS:
    """Create TTS provider based on configuration.

    Args:
        config: MossConfig instance with tts_model and tts_voice

    Returns:
        Configured TTS provider instance

    Raises:
        ValueError: If tts_model is not supported
    """
    model = config.tts_model
    voice = config.tts_voice

    # Cartesia models
    if model in ["sonic", "sonic-english", "sonic-multilingual", "sonic-turbo"]:
        return cartesia.TTS(
            api_key=config.cartesia_api_key,
            model=model,
            voice=voice,
        )

    raise ValueError(
        f"Unsupported TTS model: {model}. "
        f"Supported models: Cartesia Sonic series"
    )
