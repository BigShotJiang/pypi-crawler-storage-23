# Moss Voice Agent Manager

Simplified LiveKit voice agent integration with the Moss platform.

## Features

- **Drop-in replacement** for LiveKit AgentSession
- **Automatic configuration** from Moss platform API
- **Built-in metrics tracking** and diagnostics
- **Secure credential management** - no hardcoded secrets
- **Dynamic runtime config** - models and settings from backend

## Installation

```bash
pip install moss-voice-agent-manager
```

## Quick Start

```python
from moss_voice_agent_manager import MossAgentSession

# Initialize session - config loaded automatically
session = MossAgentSession(
    userdata=your_data,
    vad=vad,  # optional, auto-created if None
    max_tool_steps=10,
)

# Access platform API
api = session.platform_api

# Get metrics
metrics = session.metrics
diagnostics = session.diagnostics

# Save metrics
session.save_metrics()

# Generate diagnostics report
report = session.generate_diagnostics_report()
```

## Environment Variables

Required:
- `MOSS_PROJECT_ID` - Your Moss project ID
- `MOSS_PROJECT_KEY` - Your Moss project key
- `MOSS_VOICE_AGENT_ID` - Voice agent ID

Optional:
- `MOSS_PLATFORM_API_URL` - Platform API URL (defaults to production)

## How It Works

1. Fetches configuration from Moss platform
2. Auto-configures voice providers
3. Tracks metrics and diagnostics

## License

MIT
