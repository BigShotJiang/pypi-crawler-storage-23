# Alpha HWR Control Library

**alpha-hwr** is a Python library and documentation project for controlling **Grundfos ALPHA HWR** (Hot Water Recirculation) pumps via Bluetooth Low Energy (BLE).

It provides both a high-level Python API and a Command Line Interface (CLI) for monitoring and managing these devices.

## Disclaimer

This project is **not affiliated with, endorsed by, or associated with Grundfos**. Use this software at your own risk. Incorrect usage of motor control commands could potentially damage hardware, although safety limits in the pump firmware generally prevent this.

---
*Version: 0.5.0*
