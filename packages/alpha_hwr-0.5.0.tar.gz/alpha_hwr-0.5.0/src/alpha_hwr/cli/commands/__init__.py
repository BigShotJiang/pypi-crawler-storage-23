"""
CLI command modules.

Each module implements a command group for specific functionality.
"""
