"""
CLI package for alpha-hwr.

Provides a modern command-line interface using Typer and Rich.
"""

from .app import app, main

__all__ = ["app", "main"]
