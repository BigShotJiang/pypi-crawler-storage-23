# pyprom-exporters

`pyprom-exporters` provides Prometheus exporters for IoT and smart-home devices.

The current exporter targets TP-Link Tapo smart plugs via `python-kasa`.

```{toctree}
:maxdepth: 2
:caption: Contents

getting-started
configuration
api
```
