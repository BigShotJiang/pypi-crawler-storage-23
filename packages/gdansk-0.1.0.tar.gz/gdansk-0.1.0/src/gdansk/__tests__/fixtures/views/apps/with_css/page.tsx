import "./simple.css";

export default function App() {
    return null;
}
