"""Page package for the FastAPI example."""
