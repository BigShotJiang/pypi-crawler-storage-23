"""SSR example package."""
