"""Get-time example package."""
