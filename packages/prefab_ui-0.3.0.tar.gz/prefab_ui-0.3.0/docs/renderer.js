(function(){var base=window.location.hostname==="localhost"?"/":"https://cdn.jsdelivr.net/npm/@prefecthq/prefab-ui@0.0.0/dist/";window.__prefabReady=import(base+"_chunks/embed-DVX88IE0.mjs");})();
