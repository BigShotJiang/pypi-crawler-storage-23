# PyHashi: Genomic-Inspired Encryption Engine

PyHashi is a high-entropy encryption interface designed for secure data transformation. The library utilizes a genomic-inspired algorithmic approach to provide robust data confidentiality and integrity verification. PyHashi is architected to operate efficiently on Linux-based environments, including Android (via Termux) and Windows Subsystem for Linux (WSL).

For comprehensive technical analysis, benchmarks, and performance testing results, please refer to the official documentation provided by Collepedia Media Agency, a subsidiary of Nanosoft Technologies Agency: [www.collepedia.qzz.io/news/hashi](http://www.collepedia.qzz.io/news/hashi)

## Prerequisites

PyHashi requires system-level cryptographic primitives to function. Ensure the following dependencies are installed on your Linux-based system:

```bash
apt install libssl libargon2
```

# Installation

You can install the package using standard Python distribution methods:
```bash
pip install PyHashi
```

# Library Usage

PyHashi provides a straightforward interface for data encryption and decryption, utilizing a user-defined key and a genomic-sequence-based bias (DNA).

## Initializing and Encrypting
```python
from hashi import Hashi

# Initialize with a key and DNA sequence
cipher = Hashi(key="your-secret-key", dna="ATGC...")

# Encrypting data
encrypted_data = cipher.encrypt("Data to be secured")
print(f"Ciphertext: {encrypted_data}")
```

## Decrypting and Vault Management
```python
# Decrypting data
decrypted_data = cipher.decrypt(encrypted_data)
print(f"Decrypted: {decrypted_data.decode()}")

# Storing credentials in a local vault
cipher.save_vault("config.json")

# Loading from vault
cipher = Hashi.from_vault("config.json")
```

# Command Line Interface (CLI)
PyHashi includes a built-in CLI utility for file-based operations.
## 1. Generating Credentials
Generates a random high-entropy key and a DNA sequence.
```bash
hashi gen
```

## 2. Encrypting a File
```bash
hashi enc -k "secret-key" -d "ATGC..." -i input.txt -o encrypted.bin
```

## 3. Decrypting a File
```bash
hashi dec -k "secret-key" -d "ATGC..." -i encrypted.bin -o decrypted.txt
```

# Technical Specifications
The implementation relies on an underlying architectural state containing multiple internal registers, including:
 * State Array: A 16-element state vector.
 * S-Box: A deterministic substitution box.
 * DNA Bias: A 32-byte sequence providing entropy to the transformation process.
 * Nonce/Counter: Mechanisms to ensure uniqueness and protection against replay attacks.

# Compatibility Notice
 * Supported Systems: Linux, Termux (Android), WSL.
 * MacOS Support: Planned for upcoming release cycles.
 * Windows: Not natively supported (WSL is recommended for Windows environments).

PyHashi is developed and maintained by Nanosoft Technologies Agency. All technical auditing is conducted by Collepedia Media Agency.

