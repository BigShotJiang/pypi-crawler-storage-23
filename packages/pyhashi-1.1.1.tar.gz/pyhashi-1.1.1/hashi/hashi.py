import ctypes
import os

class HashiContext(ctypes.Structure):
    _fields_ = [
        ("state", ctypes.c_uint32 * 16),
        ("key", ctypes.c_uint8 * 32),
        ("mac_key", ctypes.c_uint8 * 32),
        ("sbox", ctypes.c_uint8 * 256),
        ("dna_bias", ctypes.c_uint8 * 32),
        ("nonce", ctypes.c_uint8 * 12),
        ("counter_lo", ctypes.c_uint32),
        ("counter_hi", ctypes.c_uint32),
        ("chain_feedback", ctypes.c_uint32),
        ("dynamic_rounds", ctypes.c_uint32)
    ]

class Hashi:
    def __init__(self, so_path="./libhashi.so"):
        if not os.path.exists(so_path):
            raise FileNotFoundError(f"Library {so_path} not found.")
        self.lib = ctypes.CDLL(so_path)
        
        self.lib.hh_init.argtypes = [
            ctypes.POINTER(HashiContext), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t,
            ctypes.c_char_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8)
        ]
        self.lib.hh_init.restype = ctypes.c_int
        
        self.lib.hh_encrypt.argtypes = [
            ctypes.POINTER(HashiContext), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t
        ]
        self.lib.hh_encrypt.restype = ctypes.c_int
        
        self.lib.hh_decrypt.argtypes = [
            ctypes.POINTER(HashiContext), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t
        ]
        self.lib.hh_decrypt.restype = ctypes.c_int

    def encrypt(self, password, dna, plaintext):
        ctx = HashiContext()
        p_bytes = password.encode() if isinstance(password, str) else password
        d_bytes = dna.encode() if isinstance(dna, str) else dna
        pt_bytes = plaintext.encode() if isinstance(plaintext, str) else plaintext
        
        salt = (ctypes.c_uint8 * 16)(*os.urandom(16))
        nonce = (ctypes.c_uint8 * 12)(*os.urandom(12))
        
        if self.lib.hh_init(ctypes.byref(ctx), p_bytes, len(p_bytes), d_bytes, len(d_bytes), salt, nonce) != 0:
            raise Exception("Initialization failed")
            
        ct = (ctypes.c_uint8 * (len(pt_bytes) + 32))()
        self.lib.hh_encrypt(ctypes.byref(ctx), pt_bytes, ct, len(pt_bytes))
        
        return b"HLX" + bytes(salt) + bytes(nonce) + bytes(ct)

    def decrypt(self, password, dna, ciphertext):
        if not ciphertext.startswith(b"HLX") or len(ciphertext) < 63:
            raise ValueError("Invalid HASHI ciphertext")
            
        ctx = HashiContext()
        p_bytes = password.encode() if isinstance(password, str) else password
        d_bytes = dna.encode() if isinstance(dna, str) else dna
        
        salt = (ctypes.c_uint8 * 16).from_buffer_copy(ciphertext[3:19])
        nonce = (ctypes.c_uint8 * 12).from_buffer_copy(ciphertext[19:31])
        payload = ciphertext[31:]
        
        if self.lib.hh_init(ctypes.byref(ctx), p_bytes, len(p_bytes), d_bytes, len(d_bytes), salt, nonce) != 0:
            raise Exception("Initialization failed")
            
        pt = (ctypes.c_uint8 * (len(payload) - 32))()
        res = self.lib.hh_decrypt(ctypes.byref(ctx), payload, pt, len(payload))
        
        if res == -2:
            raise PermissionError("Integrity failure: Wrong key or corrupted data")
        elif res != 0:
            raise Exception(f"Decryption failed with code {res}")
            
        return bytes(pt)
