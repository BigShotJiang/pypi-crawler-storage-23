import secrets
import string
import base64
import re
import os

def generate_key(length=32):
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(chars) for _ in range(length))

def generate_dna(length=64):
    if length < 6: raise ValueError("DNA length must be >= 6")
    mid = ''.join(secrets.choice("ATGC") for _ in range(length - 6))
    return f"ATC{mid}TAA"

def to_base(n, b):
    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    if b > len(digits): raise ValueError("Base too large")
    if n == 0: return "0"
    res = ""
    while n > 0:
        res = digits[n % b] + res
        n //= b
    return res

def from_base(s, b):
    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    res = 0
    for char in s:
        res = res * b + digits.index(char)
    return res

def to_hex(data): return data.hex()
def from_hex(h): return bytes.fromhex(h)
def to_b64(data): return base64.b64encode(data).decode()
def from_b64(s): return base64.b64decode(s)

def parse_genome(file_path, start=None, end=None, fmt="fasta"):
    if not os.path.exists(file_path): raise FileNotFoundError(f"{file_path} not found")
    with open(file_path, 'r') as f:
        content = f.read()
    if fmt == "fasta":
        seq = "".join(re.findall(r'^[^>].*', content, re.M)).replace("\n", "").replace("\r", "").replace(" ", "")
    elif fmt == "genbank":
        seq = "".join(re.findall(r'ORIGIN\s+(.*)//', content, re.S))
        seq = re.sub(r'[\s0-9]+', '', seq).upper()
    else:
        raise ValueError("Unsupported format. Use 'fasta' or 'genbank'")
    if start is not None and end is not None:
        return seq[start:end]
    return seq
