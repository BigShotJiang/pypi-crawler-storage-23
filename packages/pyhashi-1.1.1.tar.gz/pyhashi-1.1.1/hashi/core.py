import ctypes
import os
import json
import platform

class _HashiContext(ctypes.Structure):
    _fields_ = [
        ("state", ctypes.c_uint32 * 16), ("key", ctypes.c_uint8 * 32),
        ("mac_key", ctypes.c_uint8 * 32), ("sbox", ctypes.c_uint8 * 256),
        ("dna_bias", ctypes.c_uint8 * 32), ("nonce", ctypes.c_uint8 * 12),
        ("counter_lo", ctypes.c_uint32), ("counter_hi", ctypes.c_uint32),
        ("chain_feedback", ctypes.c_uint32), ("dynamic_rounds", ctypes.c_uint32)
    ]

class Hashi:
    def __init__(self, key, dna):
        base_path = os.path.dirname(os.path.abspath(__file__))
        if platform.system() == "Windows" or platform.system() == "Darwin": raise OSError("PyHashi runes on Linux systems (including Android and WSL) but it cannot run in Windows without WSL while MacOS Support is an upcoming feature")
        lib_name = "libhashi_aarch64.so" if platform.machine() == "aarch64" else "libhashi_x86_64.so"
        lib_path = os.path.join(base_path, lib_name)
        self.lib = ctypes.CDLL(lib_path)
        self.key = key.encode() if isinstance(key, str) else key
        self.dna = dna.encode() if isinstance(dna, str) else dna
        self._setup_lib()

    def _setup_lib(self):
        self.lib.hh_init.argtypes = [
            ctypes.POINTER(_HashiContext), ctypes.POINTER(ctypes.c_uint8),
            ctypes.c_size_t, ctypes.c_char_p, ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8)
        ]
        self.lib.hh_encrypt.argtypes = [
            ctypes.POINTER(_HashiContext), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t
        ]
        self.lib.hh_decrypt.argtypes = [
            ctypes.POINTER(_HashiContext), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t
        ]

    def _to_ptr(self, data):
        return (ctypes.c_uint8 * len(data)).from_buffer_copy(data)

    def encrypt(self, data):
        data_bytes = data.encode() if isinstance(data, str) else data
        ctx = _HashiContext()
        salt, nonce = os.urandom(16), os.urandom(12)
        
        k_ptr = self._to_ptr(self.key)
        d_ptr = self.dna
        s_ptr = self._to_ptr(salt)
        n_ptr = self._to_ptr(nonce)
        p_ptr = self._to_ptr(data_bytes)
        
        self.lib.hh_init(ctypes.byref(ctx), k_ptr, len(self.key), d_ptr, len(self.dna), s_ptr, n_ptr)
        
        ct = (ctypes.c_uint8 * (len(data_bytes) + 32))()
        self.lib.hh_encrypt(ctypes.byref(ctx), p_ptr, ct, len(data_bytes))
        
        return b"HLX" + salt + nonce + bytes(ct)

    def decrypt(self, ciphertext):
        if not ciphertext.startswith(b"HLX") or len(ciphertext) < 63:
            raise ValueError("Invalid HASHI data")
            
        ctx = _HashiContext()
        salt, nonce, payload = ciphertext[3:19], ciphertext[19:31], ciphertext[31:]
        
        k_ptr = self._to_ptr(self.key)
        d_ptr = self.dna
        s_ptr = self._to_ptr(salt)
        n_ptr = self._to_ptr(nonce)
        c_ptr = self._to_ptr(payload)
        
        self.lib.hh_init(ctypes.byref(ctx), k_ptr, len(self.key), d_ptr, len(self.dna), s_ptr, n_ptr)
        
        pt = (ctypes.c_uint8 * (len(payload) - 32))()
        if self.lib.hh_decrypt(ctypes.byref(ctx), c_ptr, pt, len(payload)) != 0:
            raise PermissionError("Decryption failed")
            
        return bytes(pt)

    def save_vault(self, path="hashi_vault.json"):
        with open(path, 'w') as f:
            json.dump({
                "key": self.key.decode(errors='ignore') if isinstance(self.key, bytes) else self.key,
                "dna": self.dna.decode() if isinstance(self.dna, bytes) else self.dna
            }, f, indent=4)

    @classmethod
    def from_vault(cls, path="hashi_vault.json"):
        with open(path, 'r') as f:
            cfg = json.load(f)
        return cls(key=cfg['key'], dna=cfg['dna'])
