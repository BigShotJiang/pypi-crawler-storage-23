import argparse
import sys
from .core import Hashi
from .utils import generate_key, generate_dna

def main():
    parser = argparse.ArgumentParser(prog="hashi", description="HASHI CLI Tool")
    subparsers = parser.add_subparsers(dest="cmd", help="Command to run")

    gen_parser = subparsers.add_parser("gen", help="Generate new Key and DNA")

    enc_parser = subparsers.add_parser("enc", help="Encrypt a file")
    enc_parser.add_argument("-k", "--key", required=True)
    enc_parser.add_argument("-d", "--dna", required=True)
    enc_parser.add_argument("-i", "--input", required=True)
    enc_parser.add_argument("-o", "--output", required=True)

    dec_parser = subparsers.add_parser("dec", help="Decrypt a file")
    dec_parser.add_argument("-k", "--key", required=True)
    dec_parser.add_argument("-d", "--dna", required=True)
    dec_parser.add_argument("-i", "--input", required=True)
    dec_parser.add_argument("-o", "--output", required=True)

    args = parser.parse_args()

    if args.cmd == "gen":
        print(f"Generated Key: {generate_key()}")
        print(f"Generated DNA: {generate_dna()}")
    
    elif args.cmd == "enc":
        h = Hashi(args.key, args.dna)
        with open(args.input, "rb") as f: data = f.read()
        with open(args.output, "wb") as f: f.write(h.encrypt(data))
        print(f"File encrypted to {args.output}")

    elif args.cmd == "dec":
        h = Hashi(args.key, args.dna)
        with open(args.input, "rb") as f: data = f.read()
        with open(args.output, "wb") as f: f.write(h.decrypt(data))
        print(f"File decrypted to {args.output}")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
