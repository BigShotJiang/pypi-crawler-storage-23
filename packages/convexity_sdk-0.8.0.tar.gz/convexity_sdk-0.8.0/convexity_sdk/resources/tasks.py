"""Task resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    create_task_v1_tasks_post as _create_task,
)
from convexity_api_client.api.v1 import (
    delete_task_v1_tasks_task_id_delete as _delete_task,
)
from convexity_api_client.api.v1 import (
    get_task_v1_tasks_task_id_get as _get_task,
)
from convexity_api_client.api.v1 import (
    list_tasks_v1_tasks_get as _list_tasks,
)
from convexity_api_client.api.v1 import (
    update_task_v1_tasks_task_id_patch as _update_task,
)
from convexity_api_client.models.create_task_request import CreateTaskRequest
from convexity_api_client.models.notebook_document import NotebookDocument
from convexity_api_client.models.task_list_response import TaskListResponse
from convexity_api_client.models.task_model import TaskModel
from convexity_api_client.models.task_scenario import TaskScenario
from convexity_api_client.models.update_task_request import UpdateTaskRequest
from convexity_api_client.types import UNSET, Unset


class Tasks:
    """Synchronous sub-client for task operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def list(
        self,
        project_id: str,
        *,
        scenario: TaskScenario | None = None,
    ) -> TaskListResponse:
        """List tasks for a project, optionally filtered by scenario."""
        scenario_arg: None | TaskScenario | Unset = UNSET if scenario is None else scenario
        result = _list_tasks.sync(
            client=self._client,
            project_id=project_id,
            scenario=scenario_arg,
        )
        if result is None:
            return TaskListResponse(tasks=[])
        if not isinstance(result, TaskListResponse):
            return TaskListResponse(tasks=[])
        return result

    def get(self, task_id: str) -> TaskModel | None:
        """Get a single task by ID."""
        result = _get_task.sync(task_id, client=self._client)
        if isinstance(result, TaskModel):
            return result
        return None

    def create(
        self,
        *,
        name: str,
        project_id: str,
        scenario: TaskScenario,
        description: str | None = None,
    ) -> TaskModel:
        """Create a new task in a project."""
        body = CreateTaskRequest(
            name=name,
            project_id=project_id,
            scenario=scenario,
            description=description,
        )
        result = _create_task.sync(client=self._client, body=body, project_id=project_id)
        if not isinstance(result, TaskModel):
            raise ValueError(f"Unexpected response when creating task: {result}")
        return result

    def update(
        self,
        task_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        scenario: TaskScenario | None = None,
        notebook: NotebookDocument | None = None,
    ) -> TaskModel:
        """Update an existing task."""
        body = UpdateTaskRequest(
            name=name if name is not None else UNSET,
            description=description if description is not None else UNSET,
            scenario=scenario if scenario is not None else UNSET,
            notebook=notebook if notebook is not None else UNSET,
        )
        result = _update_task.sync(task_id, client=self._client, body=body)
        if not isinstance(result, TaskModel):
            raise ValueError(f"Unexpected response when updating task: {result}")
        return result

    def delete(self, task_id: str) -> None:
        """Delete a task by ID."""
        _delete_task.sync_detailed(task_id, client=self._client)
