"""Connection resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    create_databricks_connection_v1_connections_databricks_post as _create_databricks_connection,
)
from convexity_api_client.api.v1 import (
    list_connections_v1_connections_get as _list_connections,
)
from convexity_api_client.api.v1 import (
    verify_databricks_connection_v1_connections_databricks_connection_id_verify_post as _verify_databricks_connection,
)
from convexity_api_client.models.connection_list_response import ConnectionListResponse
from convexity_api_client.models.create_databricks_connection_request import CreateDatabricksConnectionRequest
from convexity_api_client.models.databricks_connection import DatabricksConnection
from convexity_api_client.models.verify_result import VerifyResult
from convexity_api_client.types import UNSET


class Connections:
    """Synchronous sub-client for connection operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def list(self, project_id: str) -> ConnectionListResponse:
        """List all connections for a project."""
        result = _list_connections.sync(client=self._client, project_id=project_id)
        if not isinstance(result, ConnectionListResponse):
            return ConnectionListResponse(connections=[])
        return result

    def create_databricks(
        self,
        *,
        name: str,
        project_id: str,
        server_hostname: str,
        http_path: str,
        access_token: str,
        db_schema: str | None = None,
        description: str | None = None,
        catalog: str | None = None,
    ) -> DatabricksConnection:
        """Create a Databricks connection."""
        body = CreateDatabricksConnectionRequest(
            name=name,
            project_id=project_id,
            server_hostname=server_hostname,
            http_path=http_path,
            access_token=access_token,
            db_schema=db_schema if db_schema is not None else UNSET,
            description=description if description is not None else UNSET,
            catalog=catalog if catalog is not None else UNSET,
        )
        result = _create_databricks_connection.sync(client=self._client, body=body, project_id=project_id)
        if not isinstance(result, DatabricksConnection):
            raise ValueError(f"Unexpected response when creating Databricks connection: {result}")
        return result

    def verify_databricks(self, connection_id: str) -> VerifyResult:
        """Verify a Databricks connection."""
        result = _verify_databricks_connection.sync(connection_id, client=self._client)
        if not isinstance(result, VerifyResult):
            raise ValueError(f"Unexpected response when verifying Databricks connection: {result}")
        return result
