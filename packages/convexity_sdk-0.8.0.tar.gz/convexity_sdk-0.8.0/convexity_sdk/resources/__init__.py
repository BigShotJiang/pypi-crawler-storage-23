"""Resource sub-clients (connections, tasks, runs, …).

Each resource client is initialised with a shared HTTP transport and
exposes typed methods that return Pydantic models.  Only create resource
files as needed — start lean, grow with samples.
"""
