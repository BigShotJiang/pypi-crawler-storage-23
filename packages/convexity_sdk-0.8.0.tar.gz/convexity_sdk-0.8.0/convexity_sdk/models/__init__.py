"""Shared types, enums, and pagination helpers."""

from __future__ import annotations

from enum import Enum


class ConnectionType(str, Enum):
    DATABASE = "database"
    S3 = "s3"
    API = "api"
    WEBHOOK = "webhook"
    FILE = "file"
    DATABRICKS = "databricks"


class DatabaseType(str, Enum):
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"


class RunStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class DatasetType(str, Enum):
    SQL = "sql"
    JSON = "json"
    CSV = "csv"
    API = "api"
    STATIC = "static"
    DERIVED = "derived"


class ApiKeyPermission(str, Enum):
    READ = "READ"
    WRITE = "WRITE"
    ADMIN = "ADMIN"
