"""
Convexity SDK - Getting Started

This sample demonstrates basic SDK initialisation:
- Constructing a ``ConvexityClient``
- Verifying the resolved base URL
- Checking SDK version information

Configuration is resolved automatically from (in priority order):
1. Explicit arguments
2. Environment variables (CONVEXITY_API_KEY, CONVEXITY_BASE_URL)
3. Local config file (.convexity/config.yaml found by walking up from CWD)
4. Home config file (~/.convexity/config.yaml)
5. Built-in defaults
"""

import convexity_sdk
from convexity_sdk import ConvexityClient

# Reads CONVEXITY_API_KEY and CONVEXITY_BASE_URL from environment / config file.
client = ConvexityClient()

print(f"Convexity SDK version : {convexity_sdk.__version__}")
print(f"Connected to          : {client.base_url}")
print(f"Client repr           : {client!r}")
