# Convexity SDK

Python SDK for the Convexity platform.

## Installation

```bash
pip install convexity-sdk
```

## Usage

```python
import convexity_sdk

client = convexity_sdk.ConvexityClient(api_key="cvx_...")

# List user-scoped API keys
keys = client.api_keys.list()

# Create a key with explicit scopes
created = client.api_keys.create(
	name="automation",
	scopes={"org": "READ", "project": "WRITE"},
)

# Rotate/revoke by key ID
rotated = client.api_keys.rotate(created.id)
client.api_keys.revoke(created.id)
```
