# Copyright © VASP Software GmbH,
# Licensed under the Apache License 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
import pytest

from py4vasp import exception
from py4vasp._util import select


def test_empty_tree():
    assert selections(None) == ((),)
    assert selections("A", filter={"A"}) == ((),)
    assert graph(None) == "graph LR"


def test_one_level():
    selection = "foo bar baz"
    assert selections(selection) == (("foo",), ("bar",), ("baz",))
    expected = """graph LR
    foo
    bar
    baz"""
    assert graph(selection) == expected


def test_multiple_level():
    selection = "foo(bar(baz))"
    assert selections(selection) == (("foo", "bar", "baz"),)
    expected = """graph LR
    foo --> bar
    bar --> baz"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["foo(bar baz)", "  foo   (  bar,   baz  )"])
def test_mixed_selection(selection):
    assert selections(selection) == (("foo", "bar"), ("foo", "baz"))
    expected = """graph LR
    foo --> bar
    foo --> baz"""
    assert graph(selection) == expected


def test_comma_as_separator():
    selection = "foo, bar(1, 2)"
    assert selections(selection) == (("foo",), ("bar", "1"), ("bar", "2"))
    expected = """graph LR
    foo
    bar --> 1
    bar --> 2"""
    assert graph(selection) == expected


def test_no_whitespace():
    selection = "foo(bar)baz"
    assert selections(selection) == (("foo", "bar"), ("baz",))
    expected = """graph LR
    foo --> bar
    baz"""
    assert graph(selection) == expected


def test_ranges():
    selection = "foo(1 : 3) 2 : 6 baz"
    range1 = select.Group(["1", "3"], ":")
    range2 = select.Group(["2", "6"], ":")
    assert selections(selection) == (("foo", range1), (range2,), ("baz",))
    expected = """graph LR
    foo --> _0_[:]
    _0_[:] --> 1
    _0_[:] --> 3
    _1_[:] --> 2
    _1_[:] --> 6
    baz"""
    assert graph(selection) == expected


def test_pair_selection():
    selection = "foo  ~  bar, baz~foo(A)"
    pair1 = select.Group(["foo", "bar"], "~")
    pair2 = select.Group(["baz", "foo"], "~")
    assert selections(selection) == ((pair1,), (pair2, "A"))
    expected = """graph LR
    _0_[~] --> foo
    _0_[~] --> bar
    _1_[~] --> baz
    _1_[~] --> foo
    foo --> A"""
    assert graph(selection) == expected


def test_assignment_selection():
    selection = "foo  =  bar, baz=foo"
    assignment1 = select.Assignment("foo", "bar")
    assignment2 = select.Assignment("baz", "foo")
    assert selections(selection) == ((assignment1,), (assignment2,))
    expected = """graph LR
    _0_[=] --> foo
    _0_[=] --> bar
    _1_[=] --> baz
    _1_[=] --> foo"""
    assert graph(selection) == expected


def test_assignment_with_parenthesis():
    selection = "A(foo=bar) B=C(baz)"
    assignment1 = select.Assignment("foo", "bar")
    assignment2 = select.Assignment("B", "C")
    assert selections(selection) == (("A", assignment1), (assignment2, "baz"))
    expected = """graph LR
    A --> _0_[=]
    _0_[=] --> foo
    _0_[=] --> bar
    _1_[=] --> B
    _1_[=] --> C
    C --> baz"""
    assert graph(selection) == expected


# def test_assignment_with_operator():
#     # one should implement order of operators, such that + is evaluated before =


def test_brackets_escape():
    selection = "foo[a~b] bar[1:3] baz[1+2]"
    assert selections(selection) == (("foo[a~b]",), ("bar[1:3]",), ("baz[1+2]",))
    expected = """\
graph LR
    foo[a~b]
    bar[1:3]
    baz[1+2]"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["a + b, c - d", "a+b c-d"])
def test_addition_and_subtraction(selection):
    operation1 = select.Operation(("a",), "+", ("b",))
    operation2 = select.Operation(("c",), "-", ("d",))
    assert selections(selection) == ((operation1,), (operation2,))
    expected = """graph LR
    _0_[+] --> a
    _0_[+] --> b
    _1_[-] --> c
    _1_[-] --> d"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["foo+bar-baz", "foo + bar - baz"])
def test_longer_equation(selection):
    operation = select.Operation(("foo",), "+", selections("bar - baz")[0])
    assert selections(selection) == ((operation,),)
    expected = """graph LR
    _0_[+] --> foo
    _0_[+] --> _1_[-]
    _1_[-] --> bar
    _1_[-] --> baz"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["-a", "- a", "+a"])
def test_unary_operator(selection):
    operation = select.Operation((), selection[0], ("a",))
    assert selections(selection) == ((operation,),)
    expected = f"""graph LR
    _0_[{selection[0]}] --> a"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["a, -b", "a,-b"])
def test_unary_operator_after_split(selection):
    operation = select.Operation((), "-", ("b",))
    assert selections(selection) == (("a",), (operation,))
    expected = """graph LR
    a
    _0_[-] --> b"""
    assert graph(selection) == expected


@pytest.mark.parametrize("selection", ["A(x + y)", "A ( x+y )"])
def test_operator_in_parenthesis(selection):
    operation = select.Operation(("x",), "+", ("y",))
    assert selections(selection) == (("A", operation),)
    expected = """graph LR
    A --> _0_[+]
    _0_[+] --> x
    _0_[+] --> y"""
    assert graph(selection) == expected


def test_adding_two_parenthesis():
    selection = "A(x) - B(y)"
    operation = select.Operation(("A", "x"), "-", ("B", "y"))
    assert selections(selection) == ((operation,),)
    expected = """graph LR
    _0_[-] --> A
    A --> x
    _0_[-] --> B
    B --> y"""
    assert graph(selection) == expected


def test_nested_operations():
    selection = "A(x y) + B(u v)"
    Ax_Bu = select.Operation(("A", "x"), "+", ("B", "u"))
    Ax_Bv = select.Operation(("A", "x"), "+", ("B", "v"))
    Ay_Bu = select.Operation(("A", "y"), "+", ("B", "u"))
    Ay_Bv = select.Operation(("A", "y"), "+", ("B", "v"))
    assert selections(selection) == ((Ax_Bu,), (Ax_Bv,), (Ay_Bu,), (Ay_Bv,))
    expected = """graph LR
    _0_[+] --> A
    A --> x
    A --> y
    _0_[+] --> B
    B --> u
    B --> v"""
    assert graph(selection) == expected


def test_nested_groups():
    selection = "A(x~y) B:C(z)"
    assert selections(selection) == (
        ("A", select.Group(["x", "y"], "~")),
        (select.Group(["B", "C"], ":"), "z"),
    )
    expected = """graph LR
    A --> _0_[~]
    _0_[~] --> x
    _0_[~] --> y
    _1_[:] --> B
    _1_[:] --> C
    C --> z"""
    assert graph(selection) == expected


def test_operation_with_description():
    selection = "p1/2[+1/2] + d3/2[-3/2]"
    operation = select.Operation(("p1/2[+1/2]",), "+", ("d3/2[-3/2]",))
    assert selections(selection) == ((operation,),)
    expected = """\
graph LR
    _0_[+] --> p1/2[+1/2]
    _0_[+] --> d3/2[-3/2]"""
    assert graph(selection) == expected


def test_complex_nesting():
    selection = "A(B(1:3), C~D(E F)) G(H, J) K"
    expected_selections = (
        ("A", "B", select.Group(["1", "3"], ":")),
        ("A", select.Group(["C", "D"], "~"), "E"),
        ("A", select.Group(["C", "D"], "~"), "F"),
        ("G", "H"),
        ("G", "J"),
        ("K",),
    )
    expected_graph = """graph LR
    A --> B
    B --> _0_[:]
    _0_[:] --> 1
    _0_[:] --> 3
    A --> _1_[~]
    _1_[~] --> C
    _1_[~] --> D
    D --> E
    D --> F
    G --> H
    G --> J
    K"""
    assert selections(selection) == expected_selections
    assert graph(selection) == expected_graph


def test_complex_operation():
    selection = "A(x + y(z)) + B(1:3 u - v) - C~D"
    first_operand = selections("A(x+y(z))")[0]
    second_operands = selections("B(1:3 u-v)")
    third_operand = selections("C~D")[0]
    inner_operation1 = select.Operation(second_operands[0], "-", third_operand)
    inner_operation2 = select.Operation(second_operands[1], "-", third_operand)
    outer_operation1 = select.Operation(first_operand, "+", (inner_operation1,))
    outer_operation2 = select.Operation(first_operand, "+", (inner_operation2,))
    assert selections(selection) == ((outer_operation1,), (outer_operation2,))
    expected = """graph LR
    _1_[+] --> A
    A --> _0_[+]
    _0_[+] --> x
    _0_[+] --> y
    y --> z
    _1_[+] --> _4_[-]
    _4_[-] --> B
    B --> _2_[:]
    _2_[:] --> 1
    _2_[:] --> 3
    B --> _3_[-]
    _3_[-] --> u
    _3_[-] --> v
    _4_[-] --> _5_[~]
    _5_[~] --> C
    _5_[~] --> D"""
    assert graph(selection) == expected


@pytest.mark.parametrize(
    "unfiltered, filtered",
    [
        ("A(B) B(A)", "B B"),
        ("A(B C)", "B C"),
        ("A(B:C) B:C(A)", "B:C B:C"),
        ("A~B B~A", "A~B B~A"),
        ("A(B) + C, B - C(A)", "B + C, B - C"),
        ("A=B", ""),
        ("A=B(C), B=A(D), C=D", "C, D, C=D"),
        ("B=C(A) B(A=C) C(B=A)", "B=C, B, C"),
    ],
)
def test_selection_filter(unfiltered, filtered):
    assert selections(unfiltered, filter={"A"}) == selections(filtered)


@pytest.mark.parametrize(
    "unfiltered, filtered",
    [
        ("A(B(C)), A(C), B(C(A))", "C, C, C"),
        ("A(B)", ""),
        ("B(C) + A(D), A(B(C)) - D", "C + D, C - D"),
        ("A(B=C)", ""),
    ],
)
def test_filter_multiple(unfiltered, filtered):
    assert selections(unfiltered, filter={"A", "B"}) == selections(filtered)


@pytest.mark.parametrize("selection", ("A + B", "B + A", "A - B", "B - A"))
def test_incorrect_combination(selection):
    with pytest.raises(exception.IncorrectUsage):
        selections(selection, filter={"A"})


@pytest.mark.parametrize(
    "input, output",
    [
        (" ", ""),
        ("A(B(1:3), C~D(E F)) G(H, J)", "A(B(1:3)), A(C~D(E)), A(C~D(F)), G(H), G(J)"),
        (
            "A(x+y(z)) + B(1:3 u-v) - C~D",
            "A(x + y(z)) + B(1:3) - C~D, A(x + y(z)) + B(u - v) - C~D",
        ),
        ("foo = bar", "foo=bar"),
    ],
)
def test_selections_to_string(input, output):
    assert select.selections_to_string(selections(input)) == output
    assert selections(input) == selections(output)


@pytest.mark.parametrize(
    "selection, expected",
    [
        ("A, x(A), A~B, B:A, A + B, C - B - A, x(B - A), A(x y), x = A + B", True),
        ("B, y(B), B~C, B:C, B + C, C - B - D, y(B - C), B(x y), x = B + C", False),
    ],
)
def test_contains(selection, expected):
    for selection in selections(selection):
        assert select.contains(selection, choice="A") == expected
        assert select.contains(selection, choice="a", ignore_case=True) == expected


def test_incorrect_selection_raises_error():
    with pytest.raises(exception.IncorrectUsage):
        select.Tree.from_selection(1)


@pytest.mark.parametrize("selection", [":1", "1:", "1:,2", "a~", "a~,b", "~a"])
def test_broken_group_raises_error(selection):
    with pytest.raises(exception.IncorrectUsage):
        select.Tree.from_selection(selection)


@pytest.mark.parametrize("selection", ["A(B):C", "x(A(1) ~ B)"])
def test_group_subselection_on_left_raises_error(selection):
    with pytest.raises(exception.IncorrectUsage):
        selections(selection)


@pytest.mark.parametrize(
    "selection",
    ["(", "A(", "A,(", ")", "A)", "A+B)", "A~B)", "A=B)"],
)
def test_broken_parenthesis(selection):
    with pytest.raises(exception.IncorrectUsage):
        select.Tree.from_selection(selection)


@pytest.mark.parametrize("selection", ["a+", "b-", "a-,b"])
def test_missing_operand(selection):
    with pytest.raises(exception.IncorrectUsage):
        select.Tree.from_selection(selection)


@pytest.mark.parametrize("selection", ["=a", "b=", "a(b)=c"])
def test_broken_assignment_raises_error(selection):
    with pytest.raises(exception.IncorrectUsage):
        selections(selection)


@pytest.mark.parametrize("selection", [None, "string"])
def test_default_constructor_raises_error(selection):
    with pytest.raises(exception._Py4VaspInternalError):
        select.Tree(selection)


def selections(selection, filter={}):
    tree = select.Tree.from_selection(selection)
    return tuple(tree.selections(filter=filter))


def graph(selection):
    tree = select.Tree.from_selection(selection)
    return tree.to_mermaid()
