# Copyright © VASP Software GmbH,
# Licensed under the Apache License 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
import numpy as np

import py4vasp._third_party.graph as _graph
from py4vasp._calculation import base, kpoint, projector
from py4vasp._raw import data as raw_data
from py4vasp._raw.data_db import Dispersion_DB
from py4vasp._util import check, database


class Dispersion(base.Refinery):
    """Generic class for all dispersions (electrons, phonons).

    Provides some utility functionalities common to all dispersions to avoid duplication
    of code."""

    _raw_data: raw_data.Dispersion

    @base.data_access
    def __str__(self):
        return f"""band data:
    {self._kpoints.number_kpoints()} k-points
    {self._raw_data.eigenvalues.shape[-1]} bands"""

    @base.data_access
    def to_dict(self):
        """Read the dispersion into a dictionary.

        Returns
        -------
        dict
            Contains the **k**-point distances and associated labels as well as the
            eigenvalues of all the bands.
        """
        kpoint_labels = self._kpoints.labels()
        labels_dict = {} if kpoint_labels is None else {"kpoint_labels": kpoint_labels}
        return {
            "kpoint_distances": self._kpoints.distances(),
            **labels_dict,
            "eigenvalues": self._raw_data.eigenvalues[:],
        }

    @base.data_access
    def _to_database(self, *args, **kwargs):
        eigenvalues = (
            self._raw_data.eigenvalues[:]
            if not check.is_none(self._raw_data.eigenvalues)
            else None
        )
        min_eigenvalue = float(np.min(eigenvalues)) if eigenvalues is not None else None
        max_eigenvalue = float(np.max(eigenvalues)) if eigenvalues is not None else None

        min_eigenvalue_up, max_eigenvalue_up = None, None
        min_eigenvalue_down, max_eigenvalue_down = None, None
        if self._spin_polarized():
            eigenvalues_up = eigenvalues[0]
            eigenvalues_down = eigenvalues[1]
            min_eigenvalue_up = float(np.min(eigenvalues_up))
            max_eigenvalue_up = float(np.max(eigenvalues_up))
            min_eigenvalue_down = float(np.min(eigenvalues_down))
            max_eigenvalue_down = float(np.max(eigenvalues_down))

        return database.combine_db_dicts(
            {
                "dispersion": Dispersion_DB(
                    eigenvalue_min=min_eigenvalue,
                    eigenvalue_max=max_eigenvalue,
                    eigenvalue_min_up=min_eigenvalue_up,
                    eigenvalue_max_up=max_eigenvalue_up,
                    eigenvalue_min_down=min_eigenvalue_down,
                    eigenvalue_max_down=max_eigenvalue_down,
                ),
            },
            self._kpoints._read_to_database(*args, **kwargs),
        )

    @property
    def _kpoints(self):
        return kpoint.Kpoint.from_data(self._raw_data.kpoints)

    @base.data_access
    def plot(self, projections=None):
        """Generate a graph of the dispersion.

        The bands are plotted along the k-point distances. The k-point labels are added
        as ticks if present. Pass a dictionary with projections to generate a fatband
        plot based on the weights passed.

        Parameters
        ----------
        projections : dict
            The key will be used for the legend of the figure. The values will be used
            to broaden the lines. Must have the same shape as the eigenvalues of the
            dispersion.

        Returns
        -------
        Graph
            Contains the band structure for all the **k** points. If projections are
            passed, the weight of the band is adjusted accordingly.
        """
        data = self.to_dict()
        projections = self._use_projections_or_default(projections)
        return _graph.Graph(
            series=_band_structure(data, projections),
            xticks=_xticks(data, self._kpoints.line_length()),
        )

    def _use_projections_or_default(self, projections):
        if projections is not None:
            return projections
        elif self._spin_polarized():
            return {"up": None, "down": None}
        else:
            return {"bands": None}

    def _spin_polarized(self):
        eigenvalues = self._raw_data.eigenvalues
        return eigenvalues.ndim == 3 and eigenvalues.shape[0] == 2


def _band_structure(data, projections):
    spin_projections = projections.get(projector.SPIN_PROJECTION, [])
    return [
        _make_series(data, label, weight, label in spin_projections)
        for label, weight in projections.items()
        if label != projector.SPIN_PROJECTION
    ]


def _make_series(data, label, weight, is_spin_projection):
    options = {}
    if not check.is_none(weight):
        options["weight"] = weight.T
    if is_spin_projection:
        options["marker"] = "o"
        options["weight_mode"] = "color"
    x = data["kpoint_distances"]
    y = _get_bands(data["eigenvalues"], label)
    return _graph.Series(x, y, label, **options)


def _get_bands(eigenvalues, label):
    if eigenvalues.ndim == 2:
        return eigenvalues.T
    elif "down" in label:
        return eigenvalues[1].T
    else:
        return eigenvalues[0].T


def _xticks(data, line_length):
    ticks, labels = _degenerate_ticks_and_labels(data, line_length)
    return _filter_unique(ticks, labels)


def _degenerate_ticks_and_labels(data, line_length):
    labels = _tick_labels(data)
    mask = _use_labels_and_line_edges(labels, line_length)
    return data["kpoint_distances"][mask], labels[mask]


def _tick_labels(data):
    kpoint_labels = data.get("kpoint_labels")
    if kpoint_labels is None:
        return np.zeros(len(data["kpoint_distances"]), str)
    else:
        return np.array(kpoint_labels)


def _use_labels_and_line_edges(labels, line_length):
    mask = labels != ""
    mask[::line_length] = True
    mask[-1] = True
    return mask


def _filter_unique(ticks, labels):
    result = {}
    for tick, label in zip(ticks, labels):
        if tick in result:
            previous_label = result[tick]
            if previous_label != "" and previous_label != label:
                label = previous_label + "|" + label
        result[tick] = label
    return result
