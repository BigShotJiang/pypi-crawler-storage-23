# Copyright © VASP Software GmbH,
# Licensed under the Apache License 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
from dataclasses import asdict, dataclass
from types import EllipsisType

import numpy as np
from numpy.typing import ArrayLike

from py4vasp import exception, interpolate
from py4vasp._calculation import base, cell
from py4vasp._raw import data as raw_data
from py4vasp._raw.data_db import EffectiveCoulomb_DB
from py4vasp._third_party import graph, numeric
from py4vasp._util import check, convert, index, select


class EffectiveCoulomb(base.Refinery, graph.Mixin):
    """Effective Coulomb interaction U obtained with the constrained random phase approximation (cRPA).

    This class provides post-processing routines to read and visualize first-principles
    results from constrained Random Phase Approximation (cRPA) calculations. After you
    have performed a cRPA calculation using VASP this class can visualize the effective
    Coulomb interaction *U* along the radial or frequency axis. Youy can use this *U*
    mean-field theories like DFT+*U* and Dynamical Mean Field Theory (DMFT).

    The cRPA method is essential for strongly correlated materials, where standard Density
    Functional Theory (DFT) often incorrectly predicts a metallic ground state or fails to
    capture magnetic order. You can activate the cRPA calculation in VASP by setting
    :tag:`ALGO` = `CRPAR` in the INCAR file. The method computes the effective Coulomb
    interaction *U* in real space by excluding screening processes within a predefined
    correlated subspace, typically associated with localized orbitals such as *d* or *f*
    states.

    While different flavors of cRPA exist, we recommend using the spectral cRPA (s-cRPA)
    method that you activate by setting :tag:`LSCRPA` = `.TRUE.`. in the INCAR file. This
    approach overcomes significant limitations of earlier cRPA formulations [1]_, in
    particular numerical instabilities for highly occupied correlated shells or unphysical
    results like negative *U* values.

    References
    ----------
    .. [1] Kaltak, M., *et al.*, Constrained Random Phase Approximation: the spectral
        method, Phys. Rev. B 112, 245102 (2025), https://doi.org/10.1103/m3gh-g6r6
    """

    _raw_data: raw_data.EffectiveCoulomb

    @base.data_access
    def __str__(self):
        data = asdict(self._to_database()["effective_coulomb"])
        return f"""\
averaged bare interaction
bare Hubbard U = {data["bare_V_uppercase"].real:8.4f} {data["bare_V_uppercase"].imag:8.4f}
bare Hubbard u = {data["bare_v_lowercase"].real:8.4f} {data["bare_v_lowercase"].imag:8.4f}
bare Hubbard J = {data["bare_J_uppercase"].real:8.4f} {data["bare_J_uppercase"].imag:8.4f}

averaged interaction parameter
screened Hubbard U = {data["screened_U_uppercase"].real:8.4f} {data["screened_U_uppercase"].imag:8.4f}
screened Hubbard u = {data["screened_u_lowercase"].real:8.4f} {data["screened_u_lowercase"].imag:8.4f}
screened Hubbard J = {data["screened_J_uppercase"].real:8.4f} {data["screened_J_uppercase"].imag:8.4f}
"""

    def _to_database(self, *args, **kwargs) -> dict[str, EffectiveCoulomb_DB]:
        wannier_iiii = self._wannier_indices_iiii()
        wannier_ijji = self._wannier_indices_ijji()
        wannier_ijij = self._wannier_indices_ijij()
        spin_diagonal = slice(None, 2)
        omega_0 = origin = 0
        complex_ = slice(None)
        if self._has_positions and self._has_frequencies:
            access_U = (omega_0, spin_diagonal, wannier_iiii, origin, complex_)
            access_u = (omega_0, spin_diagonal, wannier_ijji, origin, complex_)
            access_J = (omega_0, spin_diagonal, wannier_ijij, origin, complex_)
            access_V = (spin_diagonal, wannier_iiii, origin, complex_)
            access_v = (spin_diagonal, wannier_ijji, origin, complex_)
            access_Vj = (spin_diagonal, wannier_ijij, origin, complex_)
        elif self._has_frequencies:
            access_U = (omega_0, spin_diagonal, wannier_iiii, complex_)
            access_u = (omega_0, spin_diagonal, wannier_ijji, complex_)
            access_J = (omega_0, spin_diagonal, wannier_ijij, complex_)
            access_V = (spin_diagonal, wannier_iiii, complex_)
            access_v = (spin_diagonal, wannier_ijji, complex_)
            access_Vj = (spin_diagonal, wannier_ijij, complex_)
        elif self._has_positions:
            access_U = access_V = (spin_diagonal, wannier_iiii, origin, complex_)
            access_u = access_v = (spin_diagonal, wannier_ijji, origin, complex_)
            access_J = access_Vj = (spin_diagonal, wannier_ijij, origin, complex_)
        else:
            access_U = access_V = (spin_diagonal, wannier_iiii, complex_)
            access_u = access_v = (spin_diagonal, wannier_ijji, complex_)
            access_J = access_Vj = (spin_diagonal, wannier_ijij, complex_)
        U = convert.to_complex(self._raw_data.screened_potential[access_U])
        u = convert.to_complex(self._raw_data.screened_potential[access_u])
        J = convert.to_complex(self._raw_data.screened_potential[access_J])
        V = convert.to_complex(self._raw_data.bare_potential_high_cutoff[access_V])
        v = convert.to_complex(self._raw_data.bare_potential_high_cutoff[access_v])
        Vj = convert.to_complex(self._raw_data.bare_potential_high_cutoff[access_Vj])
        return {
            "effective_coulomb": EffectiveCoulomb_DB(
                screened_U_uppercase=complex(np.average(U)),
                screened_u_lowercase=complex(np.average(u)),
                screened_J_uppercase=complex(np.average(J)),
                bare_V_uppercase=complex(np.average(V)),
                bare_v_lowercase=complex(np.average(v)),
                bare_J_uppercase=complex(np.average(Vj)),
            )
        }

    def _wannier_indices_iiii(self):
        """Return the indices that trace over diagonal of the 4 Wannier states. This
        should be equivalent to `np.einsum('iiii->', data)` if data is a reshaped array
        of 4 Wannier indices."""
        n = self._raw_data.number_wannier_states
        step = n**3 + n**2 + n + 1
        stop = n**4
        return slice(0, stop, step)

    def _wannier_indices_ijij(self):
        """Return the indices that run over pairs of Wannier states. This should be
        equivalent to `np.einsum('ijij->', data` if data is a reshaped array of 4
        Wannier indices and the diagonal is set to 0."""
        n = self._raw_data.number_wannier_states
        stop = n**4
        slice_included = slice(0, stop, n**2 + 1)
        slice_excluded = slice(0, stop, n**3 + n**2 + n + 1)
        indices = np.arange(stop)
        return np.setdiff1d(indices[slice_included], indices[slice_excluded])

    def _wannier_indices_ijji(self):
        """Return the indices that run over pairs of Wannier states. This should be
        equivalent to `np.einsum('ijji->', data` if data is a reshaped array of 4
        Wannier indices and the diagonal is set to 0."""
        n = self._raw_data.number_wannier_states
        stop = n**4
        indices_included = np.concatenate(
            [i * (n**3 + 1) + np.arange(0, n**3, n**2 + n) for i in range(n)]
        )
        slice_excluded = slice(0, stop, n**3 + n**2 + n + 1)
        indices = np.arange(stop)
        return np.setdiff1d(indices_included, indices[slice_excluded])

    @base.data_access
    def to_dict(self) -> dict[str, np.ndarray]:
        """Convert the effective Coulomb object to a dictionary representation.

        The integrals are evaluated over 4 Wannier functions. For the bare Coulomb
        interaction, these integrals can be computed with either a high :tag:`ENCUT`
        or low cutoff :tag:`ENCUTGW` that you set in the INCAR file. The screened Coulomb
        interaction is evaluated with the dielectric function and will have smaller
        values than the bare Coulomb potential. If you set :tag:`TWO_CENTER` = `.TRUE.`
        in the INCAR file, the Coulomb interactions are evaluated also at neighboring
        cells.

        Returns
        -------
        -
            A dictionary containing the effective Coulomb interaction data. In particular,
            it includes the bare Coulomb interaction with high and low cutoffs, the screened
            Coulomb interaction, and optionally the frequencies and positions at which the
            interactions are evaluated.
        """
        return {
            "bare_high_cutoff": self._read_high_cutoff(),
            "bare_low_cutoff": self._read_low_cutoff(),
            "screened": self._read_screened(),
            **self._read_frequencies(),
            **self._read_positions(),
        }

    @property
    def _has_frequencies(self):
        return len(self._raw_data.frequencies) > 1

    @property
    def _has_positions(self):
        return not check.is_none(self._raw_data.positions)

    @property
    def _is_collinear(self):
        return len(self._raw_data.bare_potential_low_cutoff) == 3

    def _read_high_cutoff(self):
        V = convert.to_complex(self._raw_data.bare_potential_high_cutoff[:])
        if self._has_positions:
            V = np.moveaxis(V, -1, 0)
        V = self._unpack_wannier_indices(V)
        if self._has_frequencies:
            V = V[..., np.newaxis]
        return V

    def _read_low_cutoff(self):
        C = convert.to_complex(self._raw_data.bare_potential_low_cutoff[:])
        C = self._unpack_wannier_indices(C)
        if self._has_frequencies:
            C = C[..., np.newaxis]
        return C

    def _read_screened(self):
        U = convert.to_complex(self._raw_data.screened_potential[:])
        if self._has_positions:
            U = np.moveaxis(U, -1, 0)
        U = self._unpack_wannier_indices(U)
        if self._has_frequencies:
            U = np.moveaxis(U, 1 if self._has_positions else 0, -1)
        return U

    def _unpack_wannier_indices(self, data):
        num_wannier = self._raw_data.number_wannier_states
        new_shape = data.shape[:-1] + 4 * (num_wannier,)
        return data.reshape(new_shape)

    def _read_frequencies(self):
        if not self._has_frequencies:
            return {}
        return {"frequencies": convert.to_complex(self._raw_data.frequencies[:])}

    def _read_positions(self):
        if not self._has_positions:
            return {}
        return {
            "lattice_vectors": self._cell().lattice_vectors(),
            "positions": self._raw_data.positions[:],
        }

    def _cell(self):
        return cell.Cell.from_data(self._raw_data.cell)

    @base.data_access
    def to_graph(
        self,
        selection: str = "U J V",
        omega: None | EllipsisType | np.ndarray = None,
        radius: None | EllipsisType | np.ndarray = None,
        radius_max: None | float = None,
        config: interpolate.AAAConfig = interpolate.AAAConfig(),
    ) -> graph.Graph:
        """Generate a graph representation of the effective Coulomb interaction.

        The method automatically determines the plot type based on which parameters
        are provided:

        - If only omega is given: creates a frequency-dependent plot
        - If only radius/radius_max is given: creates a radial-dependent plot
        - If both omega and radius/radius_max are given: creates a frequency plot for all radii

        Parameters
        ----------
        selection
            Specifies which data to plot. Default is "U", "V", and "J". You can also
            select "u" or "v". For collinear calculations, you select a specific spin
            coupling with "up~up" or "up~down". Different choices can be combined, e.g.,
            "U(up~up)" or "J(up~down)". You may prefix the selection with "bare" or
            "screened" to select the bare or screened potential, e.g., "bare(U)". If no
            prefix is given, it is deduced from the selection, e.g., "U" is interpreted
            as "screened(U)".

        omega
            Frequency values for frequency-dependent plots. If not set, or set to
            ellipsis (...), the frequency points along the imaginary axis are used.
            You can also provide specific frequencies on the real axis, then the data
            will be analytically continued and plotted for the selected frequencies.

        radius
            Radial distance values for radial-dependent plots. If not set, the plot
            will be for r=0. If set to ellipsis (...), the radial points used in VASP
            are used. You can also provide specific radii, then the data  will be
            interpolated to the selected radii.

        radius_max
            Maximum radius for radial-dependent plots. If set, all data for radii
            greater than this value will be ignored.

        config
            Configuration for the analytic continuation of the frequency-dependent data.
            Use this if you need to adjust the parameters of the analytic continuation.

        Returns
        -------
        -
            A graph object containing the visualization of the effective Coulomb
            interaction data.
        """
        tree = select.Tree.from_selection(selection)
        plotter = self._make_plotter(omega, radius, radius_max, config)
        potentials = self._get_effective_potentials(tree, plotter)
        series = plotter.make_all_series(potentials)
        return graph.Graph(
            series, xlabel=plotter.xlabel, ylabel="Coulomb potential (eV)"
        )

    def _make_plotter(self, omega, radius, radius_max, config):
        radius_set = radius is not None or radius_max is not None
        if omega is not None and radius_set:
            if radius is not ... and radius is not None:
                raise exception.NotImplemented(
                    "Interpolating radial data for frequency plots is not implemented."
                )
            omega_in = self._read_frequencies().get("frequencies")
            positions = self._read_positions()
            return _OmegaPlotter(omega_in, omega, config, positions, radius_max)
        if radius_set:
            positions = self._read_positions()
            return _RadialPlotter(positions, radius, radius_max)
        else:
            omega_in = self._read_frequencies().get("frequencies")
            return _OmegaPlotter(omega_in, omega, config)

    def _get_effective_potentials(self, tree, plotter):
        return [
            self._get_effective_potential(selection, plotter)
            for selection in tree.selections()
        ]

    def _get_effective_potential(self, selection, plotter):
        if self._bare_potential_selected(selection):
            return self._get_bare_potential(selection, plotter)
        else:
            return self._get_screened_potential(selection, plotter)

    def _bare_potential_selected(self, selection):
        if select.contains(selection, "bare"):
            return True
        if select.contains(selection, "screened"):
            return False
        return select.contains(selection, "V") or select.contains(selection, "v")

    def _get_bare_potential(self, selection, plotter):
        selection = self._filter_component_from_selection(selection)
        maps = self._create_map("bare")
        potential = self._raw_data.bare_potential_high_cutoff
        selector = index.Selector(maps, potential, reduction=np.average)
        V = convert.to_complex(selector[selection])
        V = plotter.interpolate_bare_if_necessary(V)
        return _CoulombPotential("bare", selector.label(selection), V)

    def _get_screened_potential(self, selection, plotter):
        selection = self._filter_component_from_selection(selection)
        maps = self._create_map("screened")
        potential = self._raw_data.screened_potential
        selector = index.Selector(maps, potential, reduction=np.average)
        U = convert.to_complex(selector[selection])
        U = plotter.interpolate_screened_if_necessary(U)
        return _CoulombPotential("screened", selector.label(selection), U)

    def _filter_component_from_selection(self, selection):
        return tuple(part for part in selection if part not in {"bare", "screened"})

    def _create_map(self, component):
        spin_map = self._create_spin_map()
        component_map = self._create_component_map()
        if component == "bare" or not self._has_frequencies:
            return {0: spin_map, 1: component_map}
        else:
            return {1: spin_map, 2: component_map}

    def _create_spin_map(self):
        if self._is_collinear:
            spin_map = {
                convert.text_to_string(label): slice(i, i + 1)
                for i, label in enumerate(self._raw_data.spin_labels[:])
            }
            spin_map[None] = spin_map["total"] = slice(0, 2)
        else:
            spin_map = {None: slice(None), "total": slice(None)}
        return spin_map

    def _create_component_map(self):
        wannier_iiii = self._wannier_indices_iiii()
        wannier_ijij = self._wannier_indices_ijij()
        wannier_ijji = self._wannier_indices_ijji()
        return {
            None: wannier_iiii,
            "U": wannier_iiii,
            "u": wannier_ijji,
            "J": wannier_ijij,
            "V": wannier_iiii,
            "v": wannier_ijji,
        }

    @staticmethod
    def ohno_potential(radius: ArrayLike, delta: float) -> np.ndarray:
        """Ohno potential for given radius/radii and delta.

        This is used to interpolate the Coulomb potential to other radii.

        Parameters
        ----------
        radius
            The radial distance(s) at which to evaluate the potential.
        delta
            The delta parameter for the Ohno potential.

        Returns
        -------
        -
            The Ohno potential evaluated at the given radius/radii.
        """
        delta = np.abs(delta)
        return np.sqrt(delta / (radius + delta))

    @base.data_access
    def selections(self) -> dict[str, list[str]]:
        """Return a dictionary describing what kind of data are available.

        Returns
        -------
        -
            Dictionary containing available selection options with their possible values.
            Keys include the selection criteria "spin", "screening", and "potential".
        """
        spin_map = self._create_spin_map()
        component_map = self._create_component_map()
        return {
            **super().selections(),
            "spin": [str(key) for key in spin_map if key is not None],
            "screening": ["screened", "bare"],
            "potential": [str(key) for key in component_map if key is not None],
        }


@dataclass
class _CoulombPotential:
    component: str
    selector_label: str
    strength: ArrayLike


class _OmegaPlotter:
    def __init__(self, omega_in, omega_out, config, positions=None, radius_max=None):
        self.omega_in = omega_in
        self.interpolate = omega_out is not None and omega_out is not ...
        if omega_in is None:
            raise exception.DataMismatch("The output does not contain frequency data.")
        if positions is not None and not positions:
            raise exception.DataMismatch("The output does not contain position data.")
        self.omega_out = omega_out if self.interpolate else omega_in
        self.xlabel = "ω (eV)" if self.interpolate else "Im(ω) (eV)"
        self.config = config
        if positions is not None:
            self.positions = positions["positions"]
            _, self.mask = transform_positions_to_radial(positions, radius_max)

    def interpolate_bare_if_necessary(self, potential):
        num_omega = len(self.omega_out)
        return np.broadcast_to(potential, (num_omega,) + potential.shape)

    def interpolate_screened_if_necessary(self, potential):
        if not self.interpolate:
            return potential
        return numeric.analytic_continuation(
            self.omega_in,
            potential.T,
            self.omega_out,
            config=self.config,
        ).T

    def make_all_series(self, potentials):
        if hasattr(self, "positions"):
            return [
                self._make_one_series(potential, position=position)
                for potential in potentials
                for position in self.positions[self.mask]
            ]
        else:
            return [self._make_one_series(potential) for potential in potentials]

    def _make_one_series(self, potential, position=None):
        if position is None:
            position_index = 0
            suffix = ""
        else:
            lookup = np.all(self.positions == position, axis=1)
            position_index = np.squeeze(np.where(lookup))
            suffix = f" @ {position}"
        omega = self.omega_out.real if self.interpolate else self.omega_out.imag
        label = f"{potential.component} {potential.selector_label}{suffix}"
        if potential.strength.ndim == 1:
            strength = potential.strength
        else:
            strength = potential.strength[:, position_index]
        return graph.Series(omega, strength.real, label=label)


class _RadialPlotter:
    xlabel = "Radius (Å)"

    def __init__(self, positions, radius_out, radius_max):
        self.radius_in, self.mask = transform_positions_to_radial(positions, radius_max)
        self.interpolate = radius_out is not None and radius_out is not ...
        self.radius_out = radius_out if self.interpolate else self.radius_in
        self.marker = None if self.interpolate else "*"

    def interpolate_bare_if_necessary(self, potential):
        return self._ohno_interpolation(potential)

    def interpolate_screened_if_necessary(self, potential):
        return self._ohno_interpolation(potential)

    def _ohno_interpolation(self, potential):
        potential = potential.real[..., self.mask]
        if not self.interpolate:
            return potential
        if potential.ndim == 2:
            # if multiple frequencies are present, take only omega = 0
            potential = potential[0]
        return potential[0] * numeric.interpolate_with_function(
            EffectiveCoulomb.ohno_potential,
            self.radius_in,
            potential / potential[0],
            self.radius_out,
        )

    def make_all_series(self, potentials):
        return [self._make_one_series(potential) for potential in potentials]

    def _make_one_series(self, potential):
        label = f"{potential.component} {potential.selector_label}"
        if potential.strength.ndim == 1:
            strength = potential.strength
        else:
            # use only omega = 0
            strength = potential.strength[0]
        return graph.Series(self.radius_out, strength, label=label, marker=self.marker)


def transform_positions_to_radial(positions, radius_max):
    if not positions:
        raise exception.DataMismatch("The output does not contain position data.")
    radius = np.linalg.norm(
        positions["lattice_vectors"] @ positions["positions"].T, axis=0
    )
    if radius_max is None:
        return radius, slice(None)
    mask = radius <= radius_max
    return radius[mask], mask
