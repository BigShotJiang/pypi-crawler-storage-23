"""
Salim configuration management.
Stores settings in ~/.salim/config.env with optional encryption.
"""

from __future__ import annotations

import os
import sys
import json
import stat
from pathlib import Path
from typing import Optional

from dotenv import dotenv_values, set_key

CONFIG_DIR  = Path.home() / ".salim"
CONFIG_FILE = CONFIG_DIR / "config.env"
LOG_FILE    = CONFIG_DIR / "salim.log"
SESSIONS_DIR = CONFIG_DIR / "sessions"


class Config:
    """Manages Salim configuration stored in ~/.salim/config.env"""

    def __init__(self):
        CONFIG_DIR.mkdir(mode=0o700, exist_ok=True)
        SESSIONS_DIR.mkdir(mode=0o700, exist_ok=True)

    # ── Raw key-value access ─────────────────────────────────────────
    def get(self, key: str, default: str = "") -> str:
        return dotenv_values(CONFIG_FILE).get(key, os.environ.get(key, default))

    def set(self, key: str, value: str):
        CONFIG_FILE.touch(mode=0o600, exist_ok=True)
        set_key(str(CONFIG_FILE), key, value)
        # Ensure perms stay tight
        CONFIG_FILE.chmod(0o600)

    def all(self) -> dict:
        return dict(dotenv_values(CONFIG_FILE))

    def delete(self, key: str):
        data = self.all()
        data.pop(key, None)
        CONFIG_FILE.write_text(
            "\n".join(f'{k}="{v}"' for k, v in data.items()) + "\n"
        )

    # ── Typed accessors ──────────────────────────────────────────────
    @property
    def bot_token(self) -> str:
        return self.get("SALIM_BOT_TOKEN", "")

    @property
    def allowed_ids(self) -> list[int]:
        raw = self.get("SALIM_ALLOWED_IDS", "")
        if not raw:
            return []
        try:
            return [int(x.strip()) for x in raw.split(",") if x.strip()]
        except ValueError:
            return []

    @property
    def download_dir(self) -> Path:
        raw = self.get("SALIM_DOWNLOAD_DIR", "")
        return Path(raw) if raw else Path.home() / "Downloads"

    @property
    def upload_dir(self) -> Path:
        raw = self.get("SALIM_UPLOAD_DIR", "")
        return Path(raw) if raw else Path.home() / "Desktop"

    @property
    def max_file_mb(self) -> int:
        return int(self.get("SALIM_MAX_FILE_MB", "50"))

    @property
    def shell(self) -> str:
        return self.get("SALIM_SHELL", os.environ.get("SHELL", "/bin/bash"))

    @property
    def log_commands(self) -> bool:
        return self.get("SALIM_LOG_COMMANDS", "true").lower() == "true"

    @property
    def screenshot_quality(self) -> int:
        return int(self.get("SALIM_SCREENSHOT_QUALITY", "85"))

    @property
    def is_configured(self) -> bool:
        return bool(self.bot_token and self.allowed_ids)

    def summary(self) -> dict:
        return {
            "bot_token":   self.bot_token[:10] + "..." if self.bot_token else "(not set)",
            "allowed_ids": self.allowed_ids,
            "download_dir": str(self.download_dir),
            "upload_dir":   str(self.upload_dir),
            "max_file_mb":  self.max_file_mb,
            "shell":        self.shell,
            "log_commands": self.log_commands,
        }
