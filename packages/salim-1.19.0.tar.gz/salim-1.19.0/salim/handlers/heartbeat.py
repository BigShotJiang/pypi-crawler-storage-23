"""
Salim Heartbeat — Autonomous Proactive Agent

Runs a background loop that wakes up at configured intervals and:
  1. Sends daily morning briefing (system status, notes, scheduled tasks)
  2. Executes user-defined proactive tasks on a schedule
  3. Monitors conditions and sends alerts proactively
  4. Learns from usage patterns and adapts over time

Commands:
  /heartbeat              — show status and settings
  /heartbeat on           — enable proactive mode
  /heartbeat off          — disable proactive mode
  /heartbeat brief        — trigger briefing right now
  /heartbeat add <task>   — add a proactive task
  /heartbeat list         — list proactive tasks
  /heartbeat del <id>     — delete a proactive task
"""
from __future__ import annotations

import asyncio
import json
import logging
import platform
import re
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from telegram.ext import Application

from salim.auth import require_auth
from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger("salim.heartbeat")

HEARTBEAT_DIR = Path.home() / ".salim" / "heartbeat"


def _state_file(user_id: int) -> Path:
    HEARTBEAT_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return HEARTBEAT_DIR / f"{user_id}.json"


def load_state(user_id: int) -> dict:
    path = _state_file(user_id)
    if not path.exists():
        return {
            "enabled": False,
            "briefing_time": "08:00",
            "last_briefing": None,
            "tasks": [],
            "chat_id": None,
        }
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def save_state(user_id: int, state: dict):
    path = _state_file(user_id)
    path.write_text(json.dumps(state, indent=2))
    path.chmod(0o600)


def _get_system_snapshot() -> dict:
    """Collect real system metrics — no mocks."""
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        battery = psutil.sensors_battery()
        bat_str = None
        if battery:
            status = "charging" if battery.power_plugged else "on battery"
            bat_str = f"{battery.percent:.0f}% ({status})"
        return {
            "cpu_pct": cpu,
            "ram_pct": mem.percent,
            "ram_used_gb": round(mem.used / 1e9, 1),
            "ram_total_gb": round(mem.total / 1e9, 1),
            "disk_pct": disk.percent,
            "disk_free_gb": round(disk.free / 1e9, 1),
            "battery": bat_str,
            "uptime_hours": round((datetime.now().timestamp() - psutil.boot_time()) / 3600, 1),
        }
    except Exception as e:
        return {"error": str(e)}


def _get_top_processes(n: int = 5) -> list[dict]:
    try:
        import psutil
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                procs.append(p.info)
            except Exception:
                pass
        return sorted(procs, key=lambda x: x.get("cpu_percent", 0), reverse=True)[:n]
    except Exception:
        return []


def _get_disk_alerts() -> list[str]:
    alerts = []
    try:
        import psutil
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                if usage.percent > 90:
                    alerts.append(f"⚠️ Disk {part.mountpoint} at {usage.percent:.0f}% full")
            except Exception:
                pass
    except Exception:
        pass
    return alerts


def _get_network_status() -> str:
    try:
        import psutil
        stats = psutil.net_io_counters()
        return (f"↓ {stats.bytes_recv / 1e9:.2f} GB received  "
                f"↑ {stats.bytes_sent / 1e9:.2f} GB sent")
    except Exception:
        return "unknown"


def _build_briefing(user_id: int) -> str:
    """Build the full proactive morning briefing message."""
    from salim.handlers.memory import load_memory
    from salim.handlers.notes_handler import _load_notes

    mem = load_memory(user_id)
    name = mem.get("name", "")
    greeting = f"Good morning{', ' + name if name else ''}! 🌅"

    now = datetime.now()
    date_str = now.strftime("%A, %B %d %Y · %H:%M")

    lines = [
        f"📰 <b>Daily Briefing</b>",
        f"<i>{date_str}</i>",
        "",
        f"👋 {greeting}",
        "",
        "🖥️ <b>System Status</b>",
    ]

    snap = _get_system_snapshot()
    if "error" not in snap:
        cpu_icon = "🔴" if snap["cpu_pct"] > 80 else "🟡" if snap["cpu_pct"] > 50 else "🟢"
        ram_icon = "🔴" if snap["ram_pct"] > 85 else "🟡" if snap["ram_pct"] > 65 else "🟢"
        disk_icon = "🔴" if snap["disk_pct"] > 90 else "🟡" if snap["disk_pct"] > 75 else "🟢"

        lines += [
            f"  {cpu_icon} CPU: {snap['cpu_pct']}%",
            f"  {ram_icon} RAM: {snap['ram_pct']}% ({snap['ram_used_gb']}/{snap['ram_total_gb']} GB)",
            f"  {disk_icon} Disk: {snap['disk_pct']}% used ({snap['disk_free_gb']} GB free)",
        ]
        if snap.get("battery"):
            lines.append(f"  🔋 Battery: {snap['battery']}")
        lines.append(f"  ⏱ Uptime: {snap['uptime_hours']}h")

    # ── Disk alerts ──────────────────────────────────────────────────────────
    disk_alerts = _get_disk_alerts()
    if disk_alerts:
        lines += [""] + disk_alerts

    # ── Active processes count ────────────────────────────────────────────────
    top = _get_top_processes(3)
    if top:
        lines += ["", "⚙️ <b>Top Processes</b>"]
        for p in top:
            cpu_p = p.get("cpu_percent", 0)
            if cpu_p > 0.5:
                lines.append(f"  • {p.get('name', '?')} — CPU {cpu_p:.1f}%")

    # ── Quick notes reminder ──────────────────────────────────────────────────
    try:
        notes = _load_notes(user_id)
        if notes:
            lines += ["", f"📝 <b>You have {len(notes)} note(s)</b>"]
            for note in notes[:3]:
                content = note.get("content", "")[:80]
                lines.append(f"  • {content}")
            if len(notes) > 3:
                lines.append(f"  <i>... and {len(notes)-3} more. Use /notes to view all.</i>")
    except Exception:
        pass

    # ── Scheduled jobs reminder ───────────────────────────────────────────────
    try:
        from salim.handlers.scheduler_handler import _jobs
        if _jobs:
            lines += ["", f"⏰ <b>{len(_jobs)} scheduled job(s) active</b>"]
            for jid, job in list(_jobs.items())[:3]:
                lines.append(f"  • {job.get('description', jid)}")
    except Exception:
        pass

    # ── Memory-based personalization ─────────────────────────────────────────
    if mem.get("projects"):
        lines += ["", f"📁 <b>Active Projects:</b> {mem['projects']}"]

    lines += [
        "",
        "─────────────────────────────",
        "<i>Have a productive day! Type anything to get started.</i>",
        "<i>/heartbeat off to disable briefings · /memory to see your profile</i>",
    ]

    return "\n".join(lines)


async def _run_proactive_task(task: dict, user_id: int, bot, chat_id: int):
    """Execute a single proactive task and send result to Telegram."""
    task_type = task.get("type", "shell")
    description = task.get("description", "Proactive task")
    cmd = task.get("command", "")

    if not cmd:
        return

    try:
        if task_type == "shell":
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=30
            )
            output = (result.stdout or result.stderr or "(no output)").strip()[:1500]
            await bot.send_message(
                chat_id=chat_id,
                text=f"🤖 <b>Proactive Task:</b> {description}\n\n<pre>{output}</pre>",
                parse_mode="HTML",
            )
    except subprocess.TimeoutExpired:
        await bot.send_message(
            chat_id=chat_id,
            text=f"⏱ Proactive task timed out: {description}",
        )
    except Exception as e:
        logger.error(f"Proactive task error: {e}")


class HeartbeatService:
    """
    Singleton background service that drives all proactive behavior.
    One instance manages all registered users.
    """

    def __init__(self):
        self._running = False
        self._task: asyncio.Task | None = None
        self._app: Application | None = None
        # user_id -> state
        self._users: dict[int, dict] = {}

    def register_user(self, user_id: int, chat_id: int):
        """Register a user for heartbeat monitoring."""
        state = load_state(user_id)
        state["chat_id"] = chat_id
        save_state(user_id, state)
        self._users[user_id] = state
        logger.info(f"Heartbeat: registered user {user_id}")

    def set_app(self, app: Application):
        self._app = app

    def start(self):
        if not self._running:
            self._running = True
            self._task = asyncio.create_task(self._loop())
            logger.info("Heartbeat service started")

    def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()

    async def _loop(self):
        """Main heartbeat loop — runs every 60 seconds."""
        while self._running:
            try:
                await self._tick()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat loop error: {e}")
            await asyncio.sleep(60)  # check every minute

    async def _tick(self):
        """One tick — check all users for pending actions."""
        if not self._app:
            return

        now = datetime.now()
        current_time = now.strftime("%H:%M")

        # Reload user states fresh each tick
        for uid in list(self._users.keys()):
            try:
                state = load_state(uid)
                if not state.get("enabled") or not state.get("chat_id"):
                    continue

                chat_id = state["chat_id"]
                bot = self._app.bot

                # ── Daily briefing ────────────────────────────────────────────
                briefing_time = state.get("briefing_time", "08:00")
                last_briefing = state.get("last_briefing")

                if current_time == briefing_time:
                    # Check we haven't sent one in the last 23 hours
                    should_send = True
                    if last_briefing:
                        try:
                            last_dt = datetime.fromisoformat(last_briefing)
                            if (now - last_dt).total_seconds() < 23 * 3600:
                                should_send = False
                        except Exception:
                            pass

                    if should_send:
                        briefing = _build_briefing(uid)
                        await bot.send_message(
                            chat_id=chat_id, text=briefing, parse_mode="HTML"
                        )
                        state["last_briefing"] = now.isoformat()
                        save_state(uid, state)
                        logger.info(f"Sent daily briefing to user {uid}")

                # ── Proactive tasks ────────────────────────────────────────────
                tasks = state.get("tasks", [])
                for task in tasks:
                    if not task.get("enabled", True):
                        continue
                    task_time = task.get("time")
                    if task_time and current_time == task_time:
                        last_run = task.get("last_run")
                        should_run = True
                        if last_run:
                            try:
                                last_dt = datetime.fromisoformat(last_run)
                                freq = task.get("frequency", "daily")
                                min_gap = 23 * 3600 if freq == "daily" else 7 * 24 * 3600
                                if (now - last_dt).total_seconds() < min_gap:
                                    should_run = False
                            except Exception:
                                pass
                        if should_run:
                            await _run_proactive_task(task, uid, bot, chat_id)
                            task["last_run"] = now.isoformat()
                            save_state(uid, state)

                # ── System health alert (every 15 min if issues) ──────────────
                last_health = state.get("last_health_check")
                should_health = True
                if last_health:
                    try:
                        last_dt = datetime.fromisoformat(last_health)
                        if (now - last_dt).total_seconds() < 900:  # 15 min
                            should_health = False
                    except Exception:
                        pass

                if should_health:
                    snap = _get_system_snapshot()
                    alerts = []
                    if snap.get("cpu_pct", 0) > 90:
                        alerts.append(f"🔴 CPU at {snap['cpu_pct']}%!")
                    if snap.get("ram_pct", 0) > 92:
                        alerts.append(f"🔴 RAM at {snap['ram_pct']}%!")
                    alerts += _get_disk_alerts()
                    if alerts:
                        await bot.send_message(
                            chat_id=chat_id,
                            text="⚠️ <b>Salim Health Alert</b>\n\n" + "\n".join(alerts),
                            parse_mode="HTML",
                        )
                    state["last_health_check"] = now.isoformat()
                    save_state(uid, state)

            except Exception as e:
                logger.error(f"Heartbeat tick error for user {uid}: {e}")


# Module-level singleton
_heartbeat = HeartbeatService()


def get_heartbeat() -> HeartbeatService:
    return _heartbeat


class HeartbeatHandlers:
    """Mixin for SalimBot — adds /heartbeat commands."""

    def _ensure_heartbeat_registered(self, user_id: int, chat_id: int):
        """Register this user with heartbeat on first interaction."""
        _heartbeat.register_user(user_id, chat_id)

    @require_auth
    async def cmd_heartbeat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /heartbeat        — status
        /heartbeat on     — enable proactive mode
        /heartbeat off    — disable
        /heartbeat brief  — trigger briefing now
        /heartbeat time <HH:MM> — set briefing time
        /heartbeat add <HH:MM> <description> :: <shell command>
        /heartbeat list   — list proactive tasks
        /heartbeat del <id> — remove a task
        """
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        user_id = update.effective_user.id
        chat_id = msg.chat_id
        args = ctx.args or []

        # Always keep user registered
        _heartbeat.register_user(user_id, chat_id)
        state = load_state(user_id)
        state["chat_id"] = chat_id

        sub = args[0].lower() if args else ""

        if sub == "on":
            state["enabled"] = True
            save_state(user_id, state)
            briefing_time = state.get("briefing_time", "08:00")
            await msg.reply_text(
                f"✅ <b>Heartbeat enabled!</b>\n\n"
                f"🌅 Daily briefing at <b>{esc(briefing_time)}</b>\n"
                f"🔔 System health checks every 15 minutes\n"
                f"🤖 Proactive tasks running\n\n"
                f"<i>Change briefing time: /heartbeat time 09:00\n"
                f"Add proactive task: /heartbeat add 09:00 Check disk :: df -h\n"
                f"Trigger now: /heartbeat brief</i>",
                parse_mode="HTML",
            )
            return

        if sub == "off":
            state["enabled"] = False
            save_state(user_id, state)
            await msg.reply_text("⏸ <b>Heartbeat disabled.</b>\n<i>No proactive messages will be sent.</i>", parse_mode="HTML")
            return

        if sub == "brief":
            thinking = await msg.reply_text("📰 <i>Generating briefing…</i>", parse_mode="HTML")
            try:
                briefing = _build_briefing(user_id)
                await thinking.edit_text(briefing, parse_mode="HTML")
            except Exception as e:
                await thinking.edit_text(f"⚠️ Briefing failed: {esc(str(e))}", parse_mode="HTML")
            return

        if sub == "time" and len(args) >= 2:
            t = args[1]
            if not re.match(r"^\d{1,2}:\d{2}$", t):
                await msg.reply_text("❌ Use HH:MM format, e.g. /heartbeat time 08:30", parse_mode="HTML")
                return
            state["briefing_time"] = t
            save_state(user_id, state)
            await msg.reply_text(f"✅ Briefing time set to <b>{esc(t)}</b>", parse_mode="HTML")
            return

        if sub == "add" and len(args) >= 2:
            # Format: /heartbeat add <HH:MM> <description> :: <shell command>
            # Or:     /heartbeat add <description> :: <shell command>  (no time = manual only)
            rest = " ".join(args[1:])
            time_match = re.match(r"^(\d{1,2}:\d{2})\s+(.+)$", rest)
            task_time = None
            if time_match:
                task_time = time_match.group(1)
                rest = time_match.group(2)

            if "::" in rest:
                description, command = rest.split("::", 1)
                description = description.strip()
                command = command.strip()
            else:
                description = rest.strip()
                command = ""

            if not command:
                await msg.reply_text(
                    "❌ Include a shell command after ::\n"
                    "Example: <code>/heartbeat add 09:00 Check disk :: df -h /</code>",
                    parse_mode="HTML",
                )
                return

            import hashlib
            task_id = hashlib.md5(f"{description}{time.time()}".encode()).hexdigest()[:6]
            task = {
                "id": task_id,
                "description": description,
                "command": command,
                "type": "shell",
                "time": task_time,
                "frequency": "daily",
                "enabled": True,
                "last_run": None,
            }
            state.setdefault("tasks", []).append(task)
            save_state(user_id, state)
            time_str = f" at <b>{esc(task_time)}</b>" if task_time else " (manual only)"
            await msg.reply_text(
                f"✅ <b>Proactive task added</b> (ID: <code>{esc(task_id)}</code>)\n"
                f"📋 <b>{esc(description)}</b>{time_str}\n"
                f"💻 <code>{esc(command)}</code>\n\n"
                f"<i>/heartbeat list to see all tasks</i>",
                parse_mode="HTML",
            )
            return

        if sub == "list":
            tasks = state.get("tasks", [])
            if not tasks:
                await msg.reply_text(
                    "📋 <b>No proactive tasks.</b>\n\n"
                    "<i>Add one: /heartbeat add 09:00 Description :: shell_command</i>",
                    parse_mode="HTML",
                )
                return
            lines = ["📋 <b>Proactive Tasks</b>\n"]
            for t in tasks:
                status = "✅" if t.get("enabled", True) else "⏸"
                time_str = t.get("time", "manual")
                lines.append(
                    f"{status} <b>{esc(t['description'])}</b> [{esc(t['id'])}]\n"
                    f"   ⏰ {esc(time_str)} · <code>{esc(t.get('command',''))[:60]}</code>"
                )
            lines.append("\n<i>/heartbeat del &lt;id&gt; to remove</i>")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if sub == "del" and len(args) >= 2:
            task_id = args[1]
            tasks = state.get("tasks", [])
            before = len(tasks)
            state["tasks"] = [t for t in tasks if t.get("id") != task_id]
            if len(state["tasks"]) < before:
                save_state(user_id, state)
                await msg.reply_text(f"🗑️ Task <code>{esc(task_id)}</code> deleted.", parse_mode="HTML")
            else:
                await msg.reply_text(f"❌ Task ID <code>{esc(task_id)}</code> not found.", parse_mode="HTML")
            return

        # ── Default: show status ──────────────────────────────────────────────
        enabled = state.get("enabled", False)
        briefing_time = state.get("briefing_time", "08:00")
        tasks = state.get("tasks", [])
        last_briefing = state.get("last_briefing", "Never")
        if last_briefing and last_briefing != "Never":
            try:
                last_briefing = datetime.fromisoformat(last_briefing).strftime("%b %d · %H:%M")
            except Exception:
                pass

        status_icon = "✅ Active" if enabled else "⏸ Inactive"
        await msg.reply_text(
            f"🤖 <b>Heartbeat Status</b>\n\n"
            f"Status: <b>{status_icon}</b>\n"
            f"🌅 Briefing time: <b>{esc(briefing_time)}</b>\n"
            f"📊 Proactive tasks: <b>{len(tasks)}</b>\n"
            f"📰 Last briefing: <i>{esc(str(last_briefing))}</i>\n\n"
            f"<b>Commands:</b>\n"
            f"<code>/heartbeat on</code> — enable\n"
            f"<code>/heartbeat off</code> — disable\n"
            f"<code>/heartbeat brief</code> — trigger now\n"
            f"<code>/heartbeat time 08:00</code> — set briefing time\n"
            f"<code>/heartbeat add 09:00 Check disk :: df -h</code>\n"
            f"<code>/heartbeat list</code> — view tasks\n"
            f"<code>/heartbeat del &lt;id&gt;</code> — remove task",
            parse_mode="HTML",
        )


import time
