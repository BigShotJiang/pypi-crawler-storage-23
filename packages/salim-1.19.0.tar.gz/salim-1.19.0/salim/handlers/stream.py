"""
Salim Live Screen Stream — near-realtime screen monitoring via Telegram.

/stream              — start streaming screenshots (default: every 3s, 60s max)
/stream <interval>   — set interval in seconds (min 1s, max 10s)
/stream <interval> <duration>  — stream for specific duration
/streamstop          — stop active stream for this chat

How it works:
  Takes a screenshot every N seconds, sends as a NEW photo each time.
  Each frame shows: timestamp, frame number, CPU%, screenshot quality indicator.
  Automatically stops after max duration (no runaway streams).
  Per-chat stream tracking — one stream per chat allowed.

Performance tricks:
  - Reduces JPEG quality on slow systems (CPU > 80%) to keep frames coming
  - Skips sending if photo is identical to last frame (saves bandwidth)
  - Uses pyautogui (already required by screen.py)

Limitations:
  Telegram does not support true video streaming — we send sequential photos.
  This gives ~1–5 FPS refresh depending on network speed.
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import io
import logging
import time
from typing import Optional

import psutil

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.stream")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

# Per-chat active streams: chat_id → asyncio.Task
_active_streams: dict[int, asyncio.Task] = {}

DEFAULT_INTERVAL   = 3     # seconds between frames
MIN_INTERVAL       = 1     # minimum allowed interval
MAX_INTERVAL       = 10    # maximum allowed interval
DEFAULT_DURATION   = 60    # default total stream duration in seconds
MAX_DURATION       = 300   # hard cap: 5 minutes
JPEG_QUALITY_BASE  = 70    # base JPEG quality
JPEG_QUALITY_LOW   = 40    # quality when CPU is high


def _take_screenshot_bytes(quality: int = 75) -> bytes:
    """Capture screen and return JPEG bytes."""
    import pyautogui
    shot = pyautogui.screenshot()
    buf = io.BytesIO()
    shot.save(buf, format="JPEG", quality=quality, optimize=True)
    return buf.getvalue()


def _image_hash(data: bytes) -> str:
    """Quick hash to detect identical frames."""
    return hashlib.md5(data).hexdigest()


async def _stream_loop(
    update: Update,
    ctx: ContextTypes.DEFAULT_TYPE,
    interval: float,
    duration: int,
    chat_id: int,
):
    """
    Core stream loop. Sends screenshot every `interval` seconds.
    Runs for `duration` seconds total, then stops.
    """
    msg = update.effective_message
    start_time  = time.time()
    frame_count = 0
    last_hash   = ""
    identical_count = 0

    # Send initial "streaming started" message with stop button
    ctrl_msg = await msg.reply_text(
        f"📡 <b>Screen Stream Started</b>\n"
        f"⏱ Interval: {interval}s · ⏳ Duration: {duration}s\n"
        f"<i>Sending live frames below...</i>",
        parse_mode=H,
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("⏹ Stop Stream", callback_data=f"stream_stop:{chat_id}")
        ]])
    )

    try:
        while True:
            elapsed = time.time() - start_time

            # Check duration limit
            if elapsed >= duration:
                break

            # Check if stream was cancelled externally
            if chat_id not in _active_streams:
                break

            frame_count += 1

            # Adaptive quality based on CPU
            cpu = psutil.cpu_percent(interval=0)
            quality = JPEG_QUALITY_LOW if cpu > 80 else JPEG_QUALITY_BASE

            # Take screenshot (blocking — run in executor)
            try:
                loop = asyncio.get_event_loop()
                jpeg_bytes = await loop.run_in_executor(
                    None, _take_screenshot_bytes, quality
                )
            except Exception as e:
                logger.error(f"Stream screenshot failed: {e}")
                await asyncio.sleep(interval)
                continue

            # Skip if identical to last frame (no activity)
            frame_hash = _image_hash(jpeg_bytes)
            if frame_hash == last_hash:
                identical_count += 1
                # After 10 identical frames, slow down and mention it
                if identical_count == 10:
                    try:
                        await ctrl_msg.edit_text(
                            f"📡 <b>Screen Stream</b> — Frame {frame_count}\n"
                            f"⏱ {interval}s interval · ⏳ {int(duration - elapsed)}s remaining\n"
                            f"<i>Screen unchanged for {identical_count} frames...</i>",
                            parse_mode=H,
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton("⏹ Stop Stream", callback_data=f"stream_stop:{chat_id}")
                            ]])
                        )
                    except Exception:
                        pass
                await asyncio.sleep(interval)
                continue

            identical_count = 0
            last_hash = frame_hash

            # Build caption with live stats
            remaining = int(duration - elapsed)
            mem = psutil.virtual_memory()
            caption = (
                f"📡 Frame {frame_count} · 🕐 {time.strftime('%H:%M:%S')}\n"
                f"⚡ CPU {cpu:.0f}% · 🧠 RAM {mem.percent:.0f}%\n"
                f"⏳ {remaining}s remaining · 💾 {len(jpeg_bytes) // 1024}KB"
            )

            # Send as photo
            try:
                buf = io.BytesIO(jpeg_bytes)
                buf.name = f"frame_{frame_count:04d}.jpg"
                await msg.reply_photo(photo=buf, caption=caption)
            except Exception as e:
                logger.warning(f"Stream send failed frame {frame_count}: {e}")

            # Wait for next frame
            await asyncio.sleep(interval)

    except asyncio.CancelledError:
        logger.info(f"Stream cancelled for chat {chat_id}")
    except Exception as e:
        logger.error(f"Stream loop error: {e}", exc_info=True)
        try:
            await msg.reply_text(f"❌ Stream error: {esc(str(e))}", parse_mode=H)
        except Exception:
            pass
    finally:
        # Cleanup
        _active_streams.pop(chat_id, None)
        elapsed_total = int(time.time() - start_time)
        try:
            await ctrl_msg.edit_text(
                f"⏹ <b>Stream Ended</b>\n"
                f"📊 Sent {frame_count} frames over {elapsed_total}s",
                parse_mode=H,
            )
        except Exception:
            pass


class ScreenStreamHandlers:
    """Mixin handler for live screen streaming."""

    @require_auth
    async def cmd_stream(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /stream                     — default 3s interval, 60s duration
        /stream <interval>          — custom interval (seconds), 60s duration
        /stream <interval> <secs>   — custom interval AND duration
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        # Parse args
        interval = float(DEFAULT_INTERVAL)
        duration = DEFAULT_DURATION

        try:
            if ctx.args:
                interval = float(ctx.args[0])
            if ctx.args and len(ctx.args) >= 2:
                duration = int(ctx.args[1])
        except ValueError:
            await msg.reply_text(
                "❌ Invalid arguments.\n"
                "Usage: <code>/stream [interval_secs] [duration_secs]</code>\n"
                "Example: <code>/stream 2 30</code>",
                parse_mode=H
            )
            return

        # Validate
        interval = max(MIN_INTERVAL, min(MAX_INTERVAL, interval))
        duration = max(5, min(MAX_DURATION, duration))

        # Stop existing stream for this chat
        if chat_id in _active_streams:
            _active_streams[chat_id].cancel()
            try:
                await _active_streams[chat_id]
            except asyncio.CancelledError:
                pass
            _active_streams.pop(chat_id, None)
            await msg.reply_text(
                "⏹ Previous stream stopped. Starting new one...", parse_mode=H
            )

        # Verify pyautogui is available
        try:
            import pyautogui  # noqa
        except ImportError:
            await msg.reply_text(
                "❌ <code>pyautogui</code> not installed.\n"
                "Run: <code>pip install pyautogui</code>",
                parse_mode=H
            )
            return

        # Start stream task
        task = asyncio.create_task(
            _stream_loop(update, ctx, interval, duration, chat_id)
        )
        _active_streams[chat_id] = task
        logger.info(f"Stream started: chat={chat_id}, interval={interval}, duration={duration}")

    @require_auth
    async def cmd_streamstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/streamstop — stop the active stream for this chat."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id in _active_streams:
            _active_streams[chat_id].cancel()
            _active_streams.pop(chat_id, None)
            await msg.reply_text("⏹ <b>Stream stopped.</b>", parse_mode=H)
        else:
            await msg.reply_text("ℹ️ No active stream for this chat.", parse_mode=H)

    async def handle_stream_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle the Stop button callback from the stream control message."""
        query = update.callback_query
        await query.answer("Stopping stream...")
        data = query.data or ""

        if data.startswith("stream_stop:"):
            try:
                chat_id = int(data.split(":", 1)[1])
            except (ValueError, IndexError):
                chat_id = query.message.chat_id

            if chat_id in _active_streams:
                _active_streams[chat_id].cancel()
                _active_streams.pop(chat_id, None)
                await query.edit_message_text("⏹ <b>Stream stopped by user.</b>", parse_mode=H)
            else:
                await query.edit_message_text("⏹ Stream was already stopped.", parse_mode=H)
