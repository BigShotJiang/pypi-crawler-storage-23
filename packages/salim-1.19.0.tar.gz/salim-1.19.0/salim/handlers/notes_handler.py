"""
salim.handlers.notes_handler — Quick Notes / Scratchpad
/note <text>      — Save a quick note
/notes            — List all notes
/notedel <id>     — Delete a note
/noteclear        — Clear all notes
"""
from __future__ import annotations
import json
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)

NOTES_FILE = Path.home() / ".salim" / "notes.json"


def _load() -> list[dict]:
    try:
        if NOTES_FILE.exists():
            return json.loads(NOTES_FILE.read_text())
    except Exception:
        pass
    return []


def _save(notes: list[dict]):
    NOTES_FILE.parent.mkdir(parents=True, exist_ok=True)
    NOTES_FILE.write_text(json.dumps(notes, indent=2))


class NotesHandlers:

    async def cmd_note(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Save a quick note. Usage: /note <text>"""
        text = " ".join(ctx.args) if ctx.args else ""
        if not text:
            await update.message.reply_text("Usage: /note <text>")
            return

        notes = _load()
        note = {
            "id": (max(n["id"] for n in notes) + 1) if notes else 1,
            "text": text,
            "created": datetime.now().isoformat(timespec="seconds"),
        }
        notes.append(note)
        _save(notes)

        await update.message.reply_text(
            f"📝 Note #{note['id']} saved:\n<i>{text[:500]}</i>",
            parse_mode="HTML"
        )

    async def cmd_notes(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List all saved notes."""
        notes = _load()
        if not notes:
            await update.message.reply_text("📭 No notes yet. Use /note <text> to add one.")
            return

        lines = [f"<b>📝 Notes ({len(notes)})</b>\n"]
        for n in notes[-20:]:  # show latest 20
            ts = n.get("created", "")[:16].replace("T", " ")
            preview = n["text"][:80]
            lines.append(f"<b>#{n['id']}</b> <i>{ts}</i>\n{preview}")

        await update.message.reply_text("\n\n".join(lines), parse_mode="HTML")

    async def cmd_notedel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Delete a note by ID. Usage: /notedel <id>"""
        if not ctx.args or not ctx.args[0].isdigit():
            await update.message.reply_text("Usage: /notedel <id>")
            return

        nid = int(ctx.args[0])
        notes = _load()
        new_notes = [n for n in notes if n["id"] != nid]

        if len(new_notes) == len(notes):
            await update.message.reply_text(f"❌ Note #{nid} not found.")
            return

        _save(new_notes)
        await update.message.reply_text(f"🗑 Note #{nid} deleted.")

    async def cmd_noteclear(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Clear all notes."""
        _save([])
        await update.message.reply_text("🗑 All notes cleared.")
