"""
Salim Skills — Dynamic Plugin System

Load custom skills (handlers) from ~/.salim/skills/*.py at runtime.
Each skill file is a Python module that defines a class with Telegram
command handlers — they're automatically discovered and registered.

Like ClawHub, this allows community-written skills to extend Salim
without modifying core code.

Skill format (~/.salim/skills/my_skill.py):
    SKILL_NAME = "weather"
    SKILL_DESCRIPTION = "Get weather forecasts"
    SKILL_COMMANDS = ["weather", "forecast"]

    class WeatherSkill:
        async def cmd_weather(self, update, ctx):
            args = ctx.args or []
            city = " ".join(args) or "London"
            # ... real implementation
            await update.effective_message.reply_text(f"Weather for {city}...")

        async def cmd_forecast(self, update, ctx):
            ...

Commands:
  /skills             — list loaded skills
  /skills reload      — reload all skills from disk
  /skills info <name> — show skill details
  /skills enable <n>  — enable a skill
  /skills disable <n> — disable a skill
  /skilladd <url>     — download and install a skill from a URL (raw Python file)
"""
from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import sys
import traceback
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.skills")

SKILLS_DIR = Path.home() / ".salim" / "skills"
SKILLS_STATE_FILE = Path.home() / ".salim" / "skills_state.json"


def _ensure_skills_dir():
    SKILLS_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    # Create an example skill if directory is empty
    example = SKILLS_DIR / "example_skill.py.disabled"
    if not example.exists():
        example.write_text(EXAMPLE_SKILL_CODE)


def _load_skills_state() -> dict:
    if SKILLS_STATE_FILE.exists():
        try:
            return json.loads(SKILLS_STATE_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_skills_state(state: dict):
    SKILLS_STATE_FILE.write_text(json.dumps(state, indent=2))
    SKILLS_STATE_FILE.chmod(0o600)


class SkillLoader:
    """
    Manages dynamic skill loading and hot-reloading.
    Skills are Python files in ~/.salim/skills/*.py
    """

    def __init__(self):
        self._loaded: dict[str, dict] = {}  # name -> {module, class, instance, commands}
        self._state: dict = {}
        self._app: Application | None = None

    def set_app(self, app: Application):
        self._app = app

    def load_all(self, bot_instance=None) -> list[str]:
        """
        Discover and load all skill files. Returns list of loaded skill names.
        Errors in individual skills are logged but don't crash the loader.
        """
        _ensure_skills_dir()
        self._state = _load_skills_state()
        loaded = []

        for skill_path in sorted(SKILLS_DIR.glob("*.py")):
            if skill_path.name.startswith("_"):
                continue
            try:
                name = skill_path.stem
                # Check if disabled
                if not self._state.get(name, {}).get("enabled", True):
                    logger.info(f"Skill '{name}' is disabled — skipping")
                    continue
                info = self._load_skill_file(skill_path, bot_instance)
                if info:
                    self._loaded[name] = info
                    loaded.append(name)
                    logger.info(f"Loaded skill: {name} ({len(info['commands'])} commands)")
            except Exception as e:
                logger.error(f"Failed to load skill {skill_path.name}: {e}")

        return loaded

    def _load_skill_file(self, path: Path, bot_instance=None) -> dict | None:
        """Load a single skill file and return its info dict."""
        spec = importlib.util.spec_from_file_location(f"salim_skill_{path.stem}", path)
        if not spec or not spec.loader:
            return None

        module = importlib.util.module_from_spec(spec)
        # Make sure the skill can import salim modules
        sys.modules[f"salim_skill_{path.stem}"] = module

        try:
            spec.loader.exec_module(module)
        except Exception as e:
            logger.error(f"Skill {path.name} import error: {e}\n{traceback.format_exc()}")
            return None

        # Find the skill class — look for a class ending in "Skill" or "Handler"
        skill_class = None
        for attr_name in dir(module):
            obj = getattr(module, attr_name)
            if (isinstance(obj, type)
                    and (attr_name.endswith("Skill") or attr_name.endswith("Handler"))
                    and attr_name != "SkillBase"):
                skill_class = obj
                break

        if not skill_class:
            logger.warning(f"Skill {path.name}: no class ending in 'Skill' or 'Handler' found")
            return None

        # Instantiate the skill, optionally passing bot config
        try:
            try:
                instance = skill_class()
            except TypeError:
                instance = skill_class.__new__(skill_class)

            # Give skill access to bot's config if available
            if bot_instance and hasattr(bot_instance, "config"):
                instance.config = bot_instance.config
            if bot_instance and hasattr(bot_instance, "_ai"):
                instance._ai = bot_instance._ai
        except Exception as e:
            logger.error(f"Skill {path.name} instantiation error: {e}")
            return None

        # Discover command handlers (methods starting with cmd_)
        commands = {}
        for method_name in dir(instance):
            if method_name.startswith("cmd_"):
                cmd_name = method_name[4:]  # strip "cmd_"
                commands[cmd_name] = getattr(instance, method_name)

        # Read metadata
        name = getattr(module, "SKILL_NAME", path.stem)
        description = getattr(module, "SKILL_DESCRIPTION", "No description")
        version = getattr(module, "SKILL_VERSION", "1.0")

        return {
            "name": name,
            "path": str(path),
            "module": module,
            "class": skill_class,
            "instance": instance,
            "commands": commands,
            "description": description,
            "version": version,
        }

    def register_with_app(self, app: Application):
        """Register all loaded skill commands with the Telegram app."""
        for skill_name, info in self._loaded.items():
            for cmd, handler in info["commands"].items():
                try:
                    app.add_handler(CommandHandler(cmd, handler))
                    logger.info(f"Registered /{cmd} from skill '{skill_name}'")
                except Exception as e:
                    logger.error(f"Failed to register /{cmd} from {skill_name}: {e}")

    def register_with_bot(self, bot_instance):
        """
        Attach skill command methods directly to the bot instance.
        This allows skills to work alongside existing bot commands.
        """
        for skill_name, info in self._loaded.items():
            for cmd, handler in info["commands"].items():
                method_name = f"cmd_{cmd}"
                if not hasattr(bot_instance, method_name):
                    # Bind the method to the bot instance so 'self' works correctly
                    import types
                    bound = types.MethodType(handler.__func__ if hasattr(handler, '__func__') else handler,
                                            info["instance"])
                    setattr(bot_instance, method_name, bound)
                    logger.info(f"Injected /{cmd} into bot from skill '{skill_name}'")
                else:
                    logger.warning(f"Skill '{skill_name}': /{cmd} already exists on bot — skipping")

    def reload_all(self, bot_instance=None) -> list[str]:
        """Hot-reload all skills."""
        # Unload existing
        for name in list(self._loaded.keys()):
            mod_key = f"salim_skill_{name}"
            sys.modules.pop(mod_key, None)
        self._loaded.clear()
        return self.load_all(bot_instance)

    def get_loaded(self) -> dict:
        return dict(self._loaded)

    def enable_skill(self, name: str):
        self._state.setdefault(name, {})["enabled"] = True
        _save_skills_state(self._state)

    def disable_skill(self, name: str):
        self._state.setdefault(name, {})["enabled"] = False
        _save_skills_state(self._state)


# Module-level singleton
_loader = SkillLoader()


def get_skill_loader() -> SkillLoader:
    return _loader


class SkillsHandlers:
    """Mixin for SalimBot — adds /skills and /skilladd commands."""

    @require_auth
    async def cmd_skills(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /skills           — list loaded skills
        /skills reload    — hot-reload all skills
        /skills info <n>  — details about a skill
        /skills enable <n>
        /skills disable <n>
        """
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        args = ctx.args or []
        sub = args[0].lower() if args else ""

        if sub == "reload":
            thinking = await msg.reply_text("🔄 <i>Reloading skills…</i>", parse_mode="HTML")
            try:
                loaded = _loader.reload_all(self)
                if loaded:
                    _loader.register_with_bot(self)
                await thinking.edit_text(
                    f"✅ <b>Skills reloaded</b>\n"
                    f"Loaded: {', '.join(esc(n) for n in loaded) if loaded else 'none'}",
                    parse_mode="HTML",
                )
            except Exception as e:
                await thinking.edit_text(f"⚠️ Reload error: {esc(str(e))}", parse_mode="HTML")
            return

        if sub == "info" and len(args) >= 2:
            name = args[1]
            info = _loader.get_loaded().get(name)
            if not info:
                await msg.reply_text(f"❌ Skill '{esc(name)}' not loaded.", parse_mode="HTML")
                return
            cmds = ", ".join(f"/{c}" for c in info["commands"])
            await msg.reply_text(
                f"🔌 <b>{esc(info['name'])}</b> v{esc(info['version'])}\n"
                f"📝 {esc(info['description'])}\n"
                f"💻 Commands: <code>{esc(cmds)}</code>\n"
                f"📁 {esc(info['path'])}",
                parse_mode="HTML",
            )
            return

        if sub == "enable" and len(args) >= 2:
            name = args[1]
            _loader.enable_skill(name)
            await msg.reply_text(f"✅ Skill <code>{esc(name)}</code> enabled. Run /skills reload.", parse_mode="HTML")
            return

        if sub == "disable" and len(args) >= 2:
            name = args[1]
            _loader.disable_skill(name)
            await msg.reply_text(f"⏸ Skill <code>{esc(name)}</code> disabled. Run /skills reload.", parse_mode="HTML")
            return

        # ── Default: list all skills ──────────────────────────────────────────
        loaded = _loader.get_loaded()

        # Also show files on disk
        _ensure_skills_dir()
        disk_files = list(SKILLS_DIR.glob("*.py"))

        if not loaded and not disk_files:
            await msg.reply_text(
                "🔌 <b>No skills loaded.</b>\n\n"
                "Skills are Python files in <code>~/.salim/skills/</code>\n\n"
                "📥 Install from URL:\n"
                "<code>/skilladd https://example.com/my_skill.py</code>\n\n"
                f"📁 Skills folder: <code>{esc(str(SKILLS_DIR))}</code>\n\n"
                "<i>An example skill template was created in the skills folder.</i>",
                parse_mode="HTML",
            )
            return

        lines = [f"🔌 <b>Loaded Skills ({len(loaded)})</b>\n"]
        for name, info in loaded.items():
            cmds = " ".join(f"/{c}" for c in list(info["commands"])[:5])
            lines.append(
                f"✅ <b>{esc(info['name'])}</b> v{esc(info['version'])}\n"
                f"   {esc(info['description'])}\n"
                f"   <code>{esc(cmds)}</code>"
            )

        # Show disabled/unloaded skill files
        loaded_paths = {info["path"] for info in loaded.values()}
        unloaded = [f for f in disk_files if str(f) not in loaded_paths]
        if unloaded:
            lines += ["", f"<i>Unloaded skill files: {', '.join(esc(f.name) for f in unloaded)}</i>"]

        lines += [
            "",
            f"📁 Skills dir: <code>{esc(str(SKILLS_DIR))}</code>",
            "<i>/skills reload — hot-reload · /skilladd &lt;url&gt; — install from URL</i>",
        ]
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_skilladd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /skilladd <url>  — download and install a skill from a URL (raw .py file)
        """
        import html as _html
        import httpx
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "📥 <b>Install a skill from a URL</b>\n\n"
                "Usage: <code>/skilladd &lt;raw-python-url&gt;</code>\n\n"
                "The URL must point to a raw Python file (.py) that defines a skill class.\n"
                "The file is downloaded to <code>~/.salim/skills/</code> and loaded immediately.",
                parse_mode="HTML",
            )
            return

        url = args[0].strip()
        if not url.startswith(("http://", "https://")):
            await msg.reply_text("❌ URL must start with http:// or https://", parse_mode="HTML")
            return

        thinking = await msg.reply_text(f"📥 <i>Downloading skill from {esc(url[:60])}…</i>", parse_mode="HTML")

        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(url, follow_redirects=True)
                resp.raise_for_status()
                code = resp.text
        except Exception as e:
            await thinking.edit_text(f"❌ Download failed: {esc(str(e))}", parse_mode="HTML")
            return

        # Basic safety checks — no exec with eval or os.system with arbitrary input
        if len(code) > 200_000:
            await thinking.edit_text("❌ Skill file too large (max 200KB)", parse_mode="HTML")
            return

        # Derive filename from URL
        import os
        fname = os.path.basename(url.split("?")[0])
        if not fname.endswith(".py"):
            fname = fname.replace(".", "_") + ".py"

        # Sanitize filename
        fname = re.sub(r"[^\w.-]", "_", fname)
        dest = SKILLS_DIR / fname
        _ensure_skills_dir()
        dest.write_text(code, encoding="utf-8")
        dest.chmod(0o600)

        # Try to load it immediately
        try:
            info = _loader._load_skill_file(dest, self)
            if info:
                _loader._loaded[dest.stem] = info
                _loader.register_with_bot(self)
                cmds = ", ".join(f"/{c}" for c in info["commands"])
                await thinking.edit_text(
                    f"✅ <b>Skill installed and loaded!</b>\n\n"
                    f"🔌 <b>{esc(info['name'])}</b> v{esc(info['version'])}\n"
                    f"📝 {esc(info['description'])}\n"
                    f"💻 Commands: <code>{esc(cmds)}</code>\n"
                    f"📁 {esc(str(dest))}",
                    parse_mode="HTML",
                )
            else:
                await thinking.edit_text(
                    f"⚠️ File downloaded to <code>{esc(str(dest))}</code> but no skill class found.\n"
                    f"Check the file has a class ending in 'Skill' or 'Handler'.",
                    parse_mode="HTML",
                )
        except Exception as e:
            await thinking.edit_text(
                f"⚠️ Downloaded but failed to load: {esc(str(e))}\n"
                f"File saved to <code>{esc(str(dest))}</code>",
                parse_mode="HTML",
            )


EXAMPLE_SKILL_CODE = '''"""
Example Salim Skill — Template for building your own skills.

Copy this file to ~/.salim/skills/my_skill.py and customize it.
Then run /skills reload in Telegram to load it.
"""

SKILL_NAME = "example"
SKILL_DESCRIPTION = "Example skill — shows how to build Salim skills"
SKILL_VERSION = "1.0"

from telegram import Update
from telegram.ext import ContextTypes


class ExampleSkill:
    """
    Each public method starting with cmd_ becomes a Telegram command.
    /hello → cmd_hello
    /greet → cmd_greet
    """

    async def cmd_hello(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Say hello — try /hello"""
        name = " ".join(ctx.args) if ctx.args else update.effective_user.first_name
        await update.effective_message.reply_text(
            f"👋 Hello, {name}! This is a custom Salim skill."
        )

    async def cmd_greet(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Formal greeting — try /greet"""
        await update.effective_message.reply_text(
            "🎩 Good day! I am a custom Salim skill.\\n"
            "Edit me in ~/.salim/skills/example_skill.py"
        )
'''
