#!/usr/bin/env python3

import os
import sys

from .analyzer.java_class_analyzer import JavaClassAnalyzer
from .scanner.dependency_scanner import DependencyScanner
from .decompiler.decompiler_service import DecompilerService

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("java-class-analyzer")

_scanner = DependencyScanner()
_decompiler = DecompilerService()
_analyzer = JavaClassAnalyzer()


def _ensure_index(project_path: str) -> None:
    """确保索引文件存在，不存在则自动创建"""
    index_path = os.path.join(project_path, ".mcp-class-index.json")
    if not os.path.exists(index_path):
        _scanner.scan_project(project_path, False)


@mcp.tool()
def scan_dependencies(projectPath: str, forceRefresh: bool = False) -> str:
    """扫描Maven项目的所有依赖，建立类名到JAR包的映射索引。

    Args:
        projectPath: Maven项目根目录路径
        forceRefresh: 是否强制刷新索引，默认false
    """
    result = _scanner.scan_project(projectPath, forceRefresh)
    sample = "\n".join(result.sample_entries[:5])
    return (
        f"依赖扫描完成！\n\n"
        f"扫描的JAR包数量: {result.jar_count}\n"
        f"索引的类数量: {result.class_count}\n"
        f"索引文件路径: {result.index_path}\n\n"
        f"示例索引条目:\n{sample}"
    )


@mcp.tool()
def decompile_class(
    className: str,
    projectPath: str,
    useCache: bool = True,
) -> str:
    """反编译指定的Java类文件，返回Java源码。

    Args:
        className: 要反编译的Java类全名，如：com.example.QueryBizOrderDO
        projectPath: Maven项目根目录路径
        useCache: 是否使用缓存，默认true
    """
    _ensure_index(projectPath)
    source_code = _decompiler.decompile_class(className, projectPath, useCache)
    if not source_code or not source_code.strip():
        return f"警告: 类 {className} 的反编译结果为空，可能是CFR工具问题或类文件损坏"
    return f"类 {className} 的反编译源码:\n\n```java\n{source_code}\n```"


@mcp.tool()
def analyze_class(className: str, projectPath: str) -> str:
    """分析Java类的结构、方法、字段等信息。

    Args:
        className: 要分析的Java类全名
        projectPath: Maven项目根目录路径
    """
    _ensure_index(projectPath)
    analysis = _analyzer.analyze_class(className, projectPath)

    result = f"类 {className} 的分析结果:\n\n"
    result += f"包名: {analysis.package_name}\n"
    result += f"类名: {analysis.class_name}\n"
    result += f"修饰符: {' '.join(analysis.modifiers)}\n"
    result += f"父类: {analysis.super_class or '无'}\n"
    result += f"实现的接口: {', '.join(analysis.interfaces) or '无'}\n\n"

    if analysis.fields:
        result += f"字段 ({len(analysis.fields)}个):\n"
        for field in analysis.fields:
            result += f"  - {' '.join(field.modifiers)} {field.type_} {field.name}\n"
        result += "\n"

    if analysis.methods:
        result += f"方法 ({len(analysis.methods)}个):\n"
        for method in analysis.methods:
            result += f"  - {' '.join(method.modifiers)} {method.return_type} {method.name}({', '.join(method.parameters)})\n"

    return result


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
