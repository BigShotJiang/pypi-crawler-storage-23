import os
import sys
import subprocess
import re
from typing import List, Optional, Dict
from dataclasses import dataclass
from ..scanner.dependency_scanner import DependencyScanner


def _debug(msg: str) -> None:
    """仅在 DEBUG 模式下输出到 stderr（不污染 MCP stdout JSON-RPC）"""
    if os.environ.get("LOG_LEVEL", "DEBUG").upper() == "DEBUG":
        print(msg, file=sys.stderr)


@dataclass
class ClassField:
    """类字段"""

    name: str
    type_: str
    modifiers: List[str]


@dataclass
class ClassMethod:
    """类方法"""

    name: str
    return_type: str
    parameters: List[str]
    modifiers: List[str]


@dataclass
class ClassAnalysis:
    """类分析结果"""

    class_name: str
    package_name: str
    modifiers: List[str]
    super_class: Optional[str]
    interfaces: List[str]
    fields: List[ClassField]
    methods: List[ClassMethod]


class JavaClassAnalyzer:
    """Java类分析器"""

    def __init__(self):
        self.scanner = DependencyScanner()

    def analyze_class(self, class_name: str, project_path: str) -> ClassAnalysis:
        """
        分析Java类的结构信息
        """
        try:
            # 1. 获取类文件路径
            jar_path = self.scanner.find_jar_for_class(class_name, project_path)
            if not jar_path:
                raise Exception(f"未找到类 {class_name} 对应的JAR包")

            # 2. 直接使用 javap 分析JAR包中的类
            analysis = self.analyze_class_with_javap(jar_path, class_name)

            return analysis
        except Exception as e:
            _debug(f"分析类 {class_name} 失败: {e}")
            raise e

    def analyze_class_with_javap(self, jar_path: str, class_name: str) -> ClassAnalysis:
        """
        使用 javap 工具分析JAR包中的类结构
        """
        try:
            javap_cmd = self.get_javap_command()

            # 使用 javap -v 获取详细信息（包括参数名称）
            result = subprocess.run(
                [javap_cmd, "-v", "-cp", jar_path, class_name],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                raise Exception(f"javap执行失败: {result.stderr}")

            return self.parse_javap_output(result.stdout, class_name)
        except subprocess.TimeoutExpired:
            raise Exception("javap分析超时")
        except Exception as e:
            _debug(f"javap 分析失败: {e}")
            raise Exception(f"javap 分析失败: {str(e)}")

    def parse_javap_output(self, output: str, class_name: str) -> ClassAnalysis:
        """
        解析 javap 输出
        """
        lines = output.split("\n")
        # 从类全名中提取简单类名
        simple_class_name = class_name.split(".")[-1]
        package_name = ".".join(class_name.split(".")[:-1]) if "." in class_name else ""

        analysis = ClassAnalysis(
            class_name=simple_class_name,
            package_name=package_name,
            modifiers=[],
            super_class=None,
            interfaces=[],
            fields=[],
            methods=[],
        )

        current_method = None
        in_local_variable_table = False
        method_parameters = {}

        for i, line in enumerate(lines):
            trimmed_line = line.strip()

            # 解析类声明
            if any(
                trimmed_line.startswith(prefix)
                for prefix in ["public class", "public interface", "public enum"]
            ):
                self.parse_class_declaration(trimmed_line, analysis)
                continue

            # 解析方法声明
            if (
                (
                    "public " in trimmed_line
                    or "private " in trimmed_line
                    or "protected " in trimmed_line
                )
                and "(" in trimmed_line
                and ")" in trimmed_line
            ):
                current_method = self.parse_method_from_javap(trimmed_line)
                if current_method:
                    analysis.methods.append(current_method)
                    method_parameters = {}
                continue

            # 检测 LocalVariableTable 开始
            if trimmed_line == "LocalVariableTable:":
                in_local_variable_table = True
                continue

            # 解析 LocalVariableTable 中的参数名称
            if in_local_variable_table and current_method:
                if trimmed_line.startswith("Start") or trimmed_line.startswith("Slot"):
                    continue  # 跳过表头

                if trimmed_line == "":
                    # LocalVariableTable 结束，立即更新当前方法的参数名称
                    if method_parameters:
                        updated_params = []
                        for j, param_type in enumerate(current_method.parameters):
                            param_name = method_parameters.get(j, f"param{j + 1}")
                            updated_params.append(f"{param_type} {param_name}")
                        current_method.parameters = updated_params
                    in_local_variable_table = False
                    method_parameters = {}
                    continue

                # 解析参数行: "0       6     0  file   Ljava/io/File;"
                param_match = re.match(
                    r"^\s*(\d+)\s+\d+\s+(\d+)\s+(\w+)\s+(.+)$", trimmed_line
                )
                if param_match:
                    slot = int(param_match.group(2))
                    param_name = param_match.group(3)
                    param_type = param_match.group(4)

                    # 只处理参数（slot >= 0，但排除局部变量）
                    if slot >= 0 and slot < len(current_method.parameters):
                        method_parameters[slot] = param_name

            # 检测方法结束 - 当遇到下一个方法或类结束时
            if current_method and (
                (
                    (
                        "public " in trimmed_line
                        or "private " in trimmed_line
                        or "protected " in trimmed_line
                    )
                    and "(" in trimmed_line
                    and ")" in trimmed_line
                )
                or trimmed_line.startswith("}")
                or trimmed_line.startswith("SourceFile:")
            ):
                # 更新方法的参数名称
                if method_parameters:
                    updated_params = []
                    for j, param_type in enumerate(current_method.parameters):
                        param_name = method_parameters.get(j, f"param{j + 1}")
                        updated_params.append(f"{param_type} {param_name}")
                    current_method.parameters = updated_params
                current_method = None
                in_local_variable_table = False
                method_parameters = {}

        return analysis

    def parse_class_declaration(self, line: str, analysis: ClassAnalysis) -> None:
        """
        解析类声明
        """
        # 提取修饰符
        modifiers = re.findall(
            r"\b(public|private|protected|static|final|abstract|strictfp)\b", line
        )
        analysis.modifiers = modifiers

        # 提取父类
        extends_match = re.search(r"extends\s+([a-zA-Z_$][a-zA-Z0-9_$.]*)", line)
        if extends_match:
            analysis.super_class = extends_match.group(1)

        # 提取接口
        implements_match = re.search(r"implements\s+([^{]+)", line)
        if implements_match:
            interfaces = [
                iface.strip()
                for iface in implements_match.group(1).split(",")
                if iface.strip()
            ]
            analysis.interfaces = interfaces

    def parse_method_from_javap(self, line: str) -> Optional[ClassMethod]:
        """
        从 javap 输出解析方法
        """
        try:
            trimmed_line = line.strip()

            # 提取修饰符
            modifiers = []
            modifier_words = [
                "public",
                "private",
                "protected",
                "static",
                "final",
                "abstract",
                "synchronized",
                "native",
            ]

            # 处理多个修饰符
            remaining_line = trimmed_line
            while True:
                found_modifier = False
                for modifier in modifier_words:
                    if remaining_line.startswith(modifier + " "):
                        modifiers.append(modifier)
                        remaining_line = remaining_line[len(modifier) + 1 :]
                        found_modifier = True
                        break
                if not found_modifier:
                    break

            # 查找方法名和参数部分
            paren_index = trimmed_line.find("(")
            if paren_index == -1:
                return None

            close_paren_index = trimmed_line.find(")", paren_index)
            if close_paren_index == -1:
                return None

            # 提取返回类型和方法名
            before_paren = (
                trimmed_line[
                    trimmed_line.find(modifiers[-1])
                    + len(modifiers[-1])
                    + 1 : paren_index
                ].strip()
                if modifiers
                else trimmed_line[:paren_index].strip()
            )
            last_space_index = before_paren.rfind(" ")
            if last_space_index == -1:
                return None

            return_type = before_paren[:last_space_index].strip()
            method_name = before_paren[last_space_index + 1 :].strip()

            # 提取参数
            params_str = trimmed_line[paren_index + 1 : close_paren_index].strip()
            parameters = []

            if params_str:
                # 处理参数，需要考虑泛型和嵌套类型
                param_parts = self.split_parameters(params_str)
                parameters = [param.strip() for param in param_parts if param.strip()]

            return ClassMethod(
                name=method_name,
                return_type=return_type,
                parameters=parameters,
                modifiers=modifiers,
            )
        except Exception as e:
            _debug(f"解析方法失败: {line}, 错误: {e}")
            return None

    def split_parameters(self, params_str: str) -> List[str]:
        """
        智能分割参数，处理泛型和嵌套类型
        """
        params = []
        current = ""
        angle_bracket_count = 0

        for char in params_str:
            if char == "<":
                angle_bracket_count += 1
            elif char == ">":
                angle_bracket_count -= 1
            elif char == "," and angle_bracket_count == 0:
                params.append(current)
                current = ""
                continue

            current += char

        if current.strip():
            params.append(current)

        return params

    def get_javap_command(self) -> str:
        """
        获取javap命令路径
        """
        java_home = os.environ.get("JAVA_HOME")
        if java_home:
            javap_cmd = "javap.exe" if os.name == "nt" else "javap"
            return os.path.join(java_home, "bin", javap_cmd)
        return "javap"

    def get_inheritance_hierarchy(
        self, class_name: str, project_path: str
    ) -> List[str]:
        """
        获取类的继承层次结构
        """
        analysis = self.analyze_class(class_name, project_path)
        hierarchy = [class_name]

        if analysis.super_class:
            try:
                super_hierarchy = self.get_inheritance_hierarchy(
                    analysis.super_class, project_path
                )
                hierarchy = super_hierarchy + hierarchy
            except Exception:
                # 如果父类不在当前项目中，直接添加
                hierarchy.insert(0, analysis.super_class)

        return hierarchy

    def find_sub_classes(self, class_name: str, project_path: str) -> List[str]:
        """
        查找类的所有子类
        """
        all_classes = self.scanner.get_all_class_names(project_path)
        sub_classes = []

        for cls in all_classes:
            try:
                analysis = self.analyze_class(cls, project_path)
                if analysis.super_class == class_name:
                    sub_classes.append(cls)
            except Exception:
                # 忽略分析失败的类型
                pass

        return sub_classes
