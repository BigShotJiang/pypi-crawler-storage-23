import os
import sys
import subprocess
import shutil
import zipfile
from typing import Dict
from ..scanner.dependency_scanner import DependencyScanner


def _debug(msg: str) -> None:
    """仅在 DEBUG 模式下输出到 stderr（不污染 MCP stdout JSON-RPC）"""
    if os.environ.get("LOG_LEVEL", "DEBUG").upper() == "DEBUG":
        print(msg, file=sys.stderr)


class DecompilerService:
    """Java类反编译服务"""

    def __init__(self):
        self.scanner = DependencyScanner()
        self.cfr_path = ""

    def initialize_cfr_path(self) -> None:
        """初始化CFR工具路径"""
        if not self.cfr_path:
            self.cfr_path = self.find_cfr_jar()
            if not self.cfr_path:
                raise Exception(
                    "未找到CFR反编译工具。请下载CFR jar包到lib目录或设置CFR_PATH环境变量"
                )
            _debug(f"CFR工具路径: {self.cfr_path}")

    def decompile_class(
        self,
        class_name: str,
        project_path: str,
        use_cache: bool = True,
    ) -> str:
        """
        反编译指定的Java类文件
        """
        try:
            self.initialize_cfr_path()

            # 1. 检查缓存
            cache_path = self.get_cache_path(class_name, project_path)
            if use_cache and os.path.exists(cache_path):
                _debug(f"使用缓存的反编译结果: {cache_path}")
                with open(cache_path, "r", encoding="utf-8") as f:
                    return f.read()

            # 2. 查找类对应的JAR包
            _debug(f"查找类 {class_name} 对应的JAR包...")
            jar_path = self.scanner.find_jar_for_class(class_name, project_path)

            if not jar_path:
                raise Exception(
                    f"未找到类 {class_name} 对应的JAR包，请先运行 scan_dependencies 建立类索引"
                )
            _debug(f"找到JAR包: {jar_path}")

            # 3. 从JAR包中提取.class文件
            class_file_path = self.extract_class_file(jar_path, class_name)

            # 4. 使用CFR反编译
            source_code = self.decompile_with_cfr(class_file_path)

            # 5. 保存到缓存
            if use_cache:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, "w", encoding="utf-8") as f:
                    f.write(source_code)
                _debug(f"反编译结果已缓存: {cache_path}")

            # 6. 清理临时文件（只有在不使用缓存时才清理）
            if not use_cache:
                try:
                    os.remove(class_file_path)
                    _debug(f"清理临时文件: {class_file_path}")
                except Exception as e:
                    _debug(f"清理临时文件失败: {e}")

            return source_code
        except Exception as e:
            _debug(f"反编译类 {class_name} 失败: {e}")
            raise e

    def get_cache_path(self, class_name: str, project_path: str) -> str:
        """
        获取缓存文件路径
        """
        package_path = class_name[: class_name.rfind(".")]
        simple_name = class_name[class_name.rfind(".") + 1 :]
        cache_dir = os.path.join(project_path, ".mcp-decompile-cache")
        package_dir = os.path.join(cache_dir, package_path.replace(".", os.sep))
        return os.path.join(package_dir, f"{simple_name}.java")

    def extract_class_file(self, jar_path: str, class_name: str) -> str:
        """
        从JAR包中提取指定的.class文件
        """
        class_file_name = class_name.replace(".", "/") + ".class"
        temp_dir = os.path.join(os.getcwd(), ".mcp-class-temp")
        # 按包名全路径创建目录结构
        package_path = class_name[: class_name.rfind(".")]
        package_dir = os.path.join(temp_dir, package_path.replace(".", os.sep))
        class_file_path = os.path.join(
            package_dir, f"{class_name[class_name.rfind('.') + 1 :]}.class"
        )

        os.makedirs(package_dir, exist_ok=True)

        _debug(f"从JAR包提取类文件: {jar_path} -> {class_file_name}")

        with zipfile.ZipFile(jar_path, "r") as zf:
            try:
                with (
                    zf.open(class_file_name) as source,
                    open(class_file_path, "wb") as target,
                ):
                    shutil.copyfileobj(source, target)
                _debug(f"类文件提取成功: {class_file_path}")
                return class_file_path
            except KeyError:
                raise Exception(f"在JAR包 {jar_path} 中未找到类文件: {class_file_name}")

    def decompile_with_cfr(self, class_file_path: str) -> str:
        """
        使用CFR反编译.class文件
        """
        if not self.cfr_path:
            raise Exception("未找到CFR反编译工具，请确保CFR jar包在classpath中")

        try:
            java_cmd = self.get_java_command()
            _debug(
                f'执行CFR反编译: {java_cmd} -jar "{self.cfr_path}" "{class_file_path}"'
            )

            result = subprocess.run(
                [java_cmd, "-jar", self.cfr_path, class_file_path, "--silent", "true"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.stderr and result.stderr.strip():
                _debug(f"CFR警告: {result.stderr}")

            if not result.stdout or result.stdout.strip() == "":
                raise Exception("CFR反编译返回空结果，可能是类文件损坏或CFR版本不兼容")

            return result.stdout
        except subprocess.TimeoutExpired:
            raise Exception("CFR反编译超时，请检查Java环境和CFR工具")
        except Exception as e:
            _debug(f"CFR反编译执行失败: {e}")
            raise Exception(f"CFR反编译失败: {str(e)}")

    def find_cfr_jar(self) -> str:
        """
        查找CFR jar包路径。
        优先级：① CFR_PATH 环境变量（用户配置）→ ② 包内置 jar（随 pip 安装分发）
        """
        # ① 优先使用用户通过环境变量指定的路径
        cfr_path = os.environ.get("CFR_PATH", "").strip()
        if cfr_path:
            if os.path.isfile(cfr_path):
                _debug(f"使用 CFR_PATH 环境变量指定的路径: {cfr_path}")
                return cfr_path
            else:
                _debug(f"CFR_PATH 指定的文件不存在: {cfr_path}，继续查找内置 jar")

        # ② 使用包内置的 cfr jar（通过 importlib.resources 获取，兼容 pip 安装后的路径）
        try:
            import java_class_analyzer_mcp as _pkg

            pkg_dir = os.path.dirname(os.path.abspath(_pkg.__file__))
            for fname in os.listdir(pkg_dir):
                if fname.lower().startswith("cfr") and fname.endswith(".jar"):
                    found = os.path.join(pkg_dir, fname)
                    _debug(f"找到内置 CFR jar: {found}")
                    return found
        except Exception as e:
            _debug(f"查找内置 CFR jar 失败: {e}")

        return ""

    def decompile_classes(
        self,
        class_names: list,
        project_path: str,
        use_cache: bool = True,
    ) -> Dict[str, str]:
        """
        批量反编译多个类
        """
        results = {}

        for class_name in class_names:
            try:
                source_code = self.decompile_class(class_name, project_path, use_cache)
                results[class_name] = source_code
            except Exception as e:
                _debug(f"反编译类 {class_name} 失败: {e}")
                results[class_name] = f"// 反编译失败: {e}"

        return results

    def get_java_command(self) -> str:
        """
        获取Java命令路径
        """
        java_home = os.environ.get("JAVA_HOME")
        if java_home:
            java_cmd = "java.exe" if os.name == "nt" else "java"
            return os.path.join(java_home, "bin", java_cmd)
        return "java"  # 回退到PATH中的java
