# HeyLead — Real User Story Test (Step-by-Step)

**Date:** 2026-02-17  
**Story:** Sarah is growth lead at **SPhotonix** (long-term data archiving for enterprises). She wants to find and reach out to **VPs of Data Governance** at financial services and healthcare companies. She uses HeyLead in Cursor via MCP.

**Environment:** Backend mode (heylead-api), LinkedIn connected, multiple accounts available.

---

## Step 1 — Check dashboard and account

**Action:** Sarah asks: *"Show my HeyLead status."*

**Tool:** `show_status(campaign_id="")`

**Result:** ✅ **PASS**

- Dashboard shows account health (rating, today’s invitations, weekly cap, free tier usage).
- Lists 6 existing campaigns (e.g. Test Scheduler Campaign, E2E Test, CTO US Mental Health).
- Lists 3 saved ICPs (e.g. Archival Data CTO Outreach 85%, Founders and CEOs B2B SaaS).
- Suggests quick actions (send messages, engage posts, check replies, create campaign, etc.).

**Note:** “No data” for rating/acceptance is expected when no invitations have been sent yet.

---

## Step 2 — See connected LinkedIn accounts

**Action:** Sarah asks: *"Which LinkedIn accounts are connected?"*

**Tool:** `list_linkedin_accounts()`

**Result:** ✅ **PASS**

- Returns a list of connected accounts with IDs and names (e.g. Sam Martsynovskyi, Denys Chumak, Liza Sukholientseva).
- Marks current account (e.g. “Denys Chumak ← current”).
- Suggests: “Use switch_account_to(account_id='...') to switch. Use unlink_account() to disconnect.”

---

## Step 3 — Generate an ICP for the target segment

**Action:** Sarah says: *"Create an ICP for VPs of Data Governance at financial services and healthcare, for SPhotonix."*

**Tool:** `generate_icp(target_description="VPs of Data Governance at financial services and healthcare", company_context="https://sphotonix.com")`

**Result:** ✅ **PASS**

- ICP generated in ~15.6s.
- Title: **Data Governance Outreach**; ICP ID: `6b635451...`.
- **3 personas** with pain points, fears, barriers, LinkedIn targeting (industries, job titles, locations, keywords), and confidence scores (80–90%).
  - Persona 1: Mid-Market Fintech Data Leaders (85%).
  - Persona 2: Enterprise Healthcare Data Guardians (90%).
  - Persona 3: Large Bank Data Compliance Officers (80%).
- Next steps suggested: `create_campaign(icp_id="6b635451...")`, `show_status()`, etc.

---

## Step 4 — Create a campaign from the ICP

**Action:** Sarah says: *"Create a campaign for Data Governance using that ICP."*

**Tool:** `create_campaign(target_description="VPs of Data Governance and compliance leads at financial services companies", campaign_name="SPhotonix Data Governance Outreach", icp_id="b56e48c3", company_context="https://sphotonix.com")`

**Result:** ❌ **FAIL** (known bug in currently installed package)

- Error: `cannot import name 'generate_icp_result_for_campaign' from 'heylead.tools.generate_icp'`.
- **Cause:** The installed HeyLead package (in the venv used by Cursor) still has the old top-level import in `create_campaign`. When the code path runs (or when the module loads), the import fails.
- **Fix (in repo):** `create_campaign` now uses a **lazy import** of `generate_icp_result_for_campaign` only when generating a new ICP inline, and catches `ImportError` with a clear message. Deploying a release that includes this fix (and upgrading the venv) will resolve the failure.
- **Workaround for this test:** Could not create a *new* campaign in this run. Existing campaigns from earlier runs were used for later steps.

---

## Step 5 — Ask what to do next

**Action:** Sarah asks: *"What should I do next?"*

**Tool:** `suggest_next_action(campaign_id="")`

**Result:** ✅ **PASS**

- Returns: “No active campaigns. Create one first: create_campaign("your target description").”
- Behavior is correct when there is no campaign in a state suitable for sending (e.g. after create_campaign fails or when only archived/draft campaigns exist).

---

## Step 6 — Check for replies

**Action:** Sarah asks: *"Any new replies?"*

**Tool:** `check_replies()`

**Result:** ✅ **PASS**

- Returns: “No new messages found.” with tip: “Replies usually take 1-3 days after invitations are accepted. Use show_status to see your campaign progress.”

---

## Step 7 — Export campaign results

**Action:** Sarah asks: *"Export my campaign results."*

**Tool:** `export_campaign(campaign_id="")`

**Result:** ✅ **PASS**

- For the first campaign (e.g. Test Scheduler Campaign): “Campaign 'Test Scheduler Campaign' has no prospects yet. Prospects are added when you run create_campaign().”
- Message is correct when the campaign has no prospects (e.g. never filled by create_campaign or no LinkedIn search run).

---

## Step 8 — Campaign report

**Action:** Sarah asks: *"Give me a campaign report."*

**Tool:** `campaign_report(campaign_id="")`

**Result:** ✅ **PASS**

- Report for “Test Scheduler Campaign”: mode (Autopilot), status (Completed), outcomes (Won: 0, Lost: 0), conversion note, active leads.
- Clear and consistent with dashboard data.

---

## Step 9 — Generate and send (when no active campaign)

**Action:** Sarah says: *"Send messages for my campaign."*

**Tool:** `generate_and_send(campaign_id="", mode="copilot")`

**Result:** ✅ **PASS** (graceful)

- Returns: “No active campaigns. Create one first: create_campaign("your target description").”
- Correct behavior when there is no campaign to send from.

---

## Step 10 — Scheduler status

**Action:** Sarah asks: *"Is the scheduler on?"*

**Tool:** `scheduler_status()`

**Result:** ✅ **PASS**

- Reports: “Scheduler Disabled” and “Cloud Scheduler Disabled.”
- Explains what the scheduler does when enabled (invitations, follow-ups, reply checks, engagement) and how to enable: `toggle_scheduler(enabled=True)` and optionally `toggle_scheduler(enabled=True, cloud=True)`.

---

## Step 11 — Emergency stop (no active campaigns)

**Action:** Sarah says: *"Stop everything."*

**Tool:** `emergency_stop()`

**Result:** ✅ **PASS**

- Returns: “No active campaigns to stop. All campaigns are already paused or completed. Use show_status() to see all campaigns.”
- Correct when nothing is currently active.

---

## Step 12 — Compare campaigns

**Action:** Sarah asks: *"Compare my campaigns."*

**Tool:** `compare_campaigns(campaign_ids="")`

**Result:** ✅ **PASS** (graceful)

- Returns: “Need at least 2 campaigns to compare. Found 0 campaign(s). Create more campaigns or specify IDs: compare_campaigns(campaign_ids='id1,id2').”
- Clear guidance when there are not enough campaigns to compare.

---

## Summary

| Step | Action | Tool | Result |
|------|--------|------|--------|
| 1 | Show status | show_status | ✅ PASS |
| 2 | List LinkedIn accounts | list_linkedin_accounts | ✅ PASS |
| 3 | Generate ICP (Data Governance + SPhotonix) | generate_icp | ✅ PASS |
| 4 | Create campaign from ICP | create_campaign | ❌ FAIL (import bug in installed pkg) |
| 5 | What’s next? | suggest_next_action | ✅ PASS |
| 6 | Any replies? | check_replies | ✅ PASS |
| 7 | Export campaign | export_campaign | ✅ PASS |
| 8 | Campaign report | campaign_report | ✅ PASS |
| 9 | Send messages | generate_and_send | ✅ PASS (no active campaign) |
| 10 | Scheduler status | scheduler_status | ✅ PASS |
| 11 | Emergency stop | emergency_stop | ✅ PASS |
| 12 | Compare campaigns | compare_campaigns | ✅ PASS |

**Working:** 11/12 steps (all tools behaved correctly except create_campaign).  
**Failing:** 1/12 — create_campaign fails in the installed environment due to the known `generate_icp_result_for_campaign` import bug.

---

## Recommended next steps

1. **Upgrade HeyLead** in the Cursor MCP venv to a version that includes:
   - Lazy import and ImportError handling for `generate_icp_result_for_campaign` in create_campaign.
   - Graceful handling of unconfigured client in switch_account_to.
2. **Re-run Step 4** after upgrade: create a campaign with `create_campaign(icp_id="6b635451...", campaign_name="SPhotonix Data Governance Outreach")` (using the ICP from Step 3).
3. **Continue the story:** run `generate_and_send(campaign_id="<new_id>", mode="copilot")`, then approve/skip in copilot, then `check_replies` and `show_conversation(outreach_id="...")` as replies come in.

---

## How to re-run this test

1. In Cursor, open a chat and use the HeyLead MCP (ensure heylead server is connected).
2. Run the steps above in order, using the same or similar prompts and tool arguments.
3. Optionally use a fresh ICP (e.g. from `generate_icp`) and a new campaign name to avoid reusing old data.
