"""Shared wrapper for LinkedIn profile edits with change tracking.

Every profile mutation (headline, summary, photo) goes through
``apply_profile_change`` so we always log the before/after value
in the ``profile_changes`` table.
"""

from __future__ import annotations

import logging
from typing import Any

from ..db.queries import get_setting, log_profile_change, save_setting

logger = logging.getLogger(__name__)


async def apply_profile_change(
    client: Any,
    account_id: str,
    provider_id: str,
    field: str,
    new_value: str,
    source: str = "manual",
    *,
    image_bytes: bytes | None = None,
    content_type: str = "image/jpeg",
) -> dict[str, Any]:
    """Apply a profile change and log it to the history table.

    For text fields (headline, summary) *new_value* is the literal text.
    For photo uploads pass *image_bytes* and *content_type*; *new_value*
    is stored as a human-readable placeholder (e.g. ``"<photo uploaded>"``).

    Returns ``{"success": bool, "error": str, "change_id": str | None}``.
    """
    profile = get_setting("profile", {})
    old_value: str | None = None

    if field == "headline":
        old_value = profile.get("headline")
        result = await client.update_profile_headline(
            account_id, provider_id, new_value,
        )
    elif field == "summary":
        old_value = profile.get("summary")
        result = await client.update_profile_summary(
            account_id, provider_id, new_value,
        )
    elif field == "photo":
        old_value = "<previous photo>"
        if image_bytes is None:
            return {"success": False, "error": "image_bytes required for photo", "change_id": None}
        result = await client.upload_profile_photo(
            account_id, provider_id, image_bytes, content_type,
        )
    else:
        return {"success": False, "error": f"Unsupported field: {field}", "change_id": None}

    if result.get("success"):
        change_id = log_profile_change(field, old_value, new_value, source)
        if field in ("headline", "summary"):
            profile[field] = new_value
            save_setting("profile", profile)
        logger.info("Profile change logged: %s id=%s source=%s", field, change_id, source)
        return {"success": True, "error": "", "change_id": change_id}

    return {"success": False, "error": result.get("error", "unknown error"), "change_id": None}
