"""Tests for profile change history and restore functionality."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, patch

from heylead.db.queries import (
    get_profile_change,
    get_profile_changes,
    get_setting,
    log_profile_change,
    mark_profile_change_reverted,
    save_setting,
)
from heylead.tools.profile_editor import apply_profile_change


# ── Query function tests ──


class TestLogProfileChange:
    def test_creates_record(self):
        change_id = log_profile_change("headline", "Old HL", "New HL", "manual")
        assert len(change_id) == 8
        record = get_profile_change(change_id)
        assert record is not None
        assert record["field"] == "headline"
        assert record["old_value"] == "Old HL"
        assert record["new_value"] == "New HL"
        assert record["source"] == "manual"
        assert record["status"] == "applied"

    def test_null_old_value(self):
        change_id = log_profile_change("summary", None, "New summary", "brand_strategy")
        record = get_profile_change(change_id)
        assert record is not None
        assert record["old_value"] is None
        assert record["source"] == "brand_strategy"


class TestGetProfileChanges:
    def test_returns_entries(self):
        id1 = log_profile_change("headline", "a", "b")
        id2 = log_profile_change("headline", "b", "c")
        changes = get_profile_changes(field="headline", limit=10)
        ids = [c["id"] for c in changes]
        assert id1 in ids
        assert id2 in ids

    def test_filters_by_field(self):
        log_profile_change("headline", "x", "y")
        log_profile_change("summary", "s1", "s2")
        headline_changes = get_profile_changes(field="headline")
        for c in headline_changes:
            assert c["field"] == "headline"

    def test_limit(self):
        for i in range(5):
            log_profile_change("headline", f"old{i}", f"new{i}")
        changes = get_profile_changes(limit=3)
        assert len(changes) <= 3

    def test_all_fields(self):
        log_profile_change("headline", "h1", "h2")
        log_profile_change("summary", "s1", "s2")
        all_changes = get_profile_changes()
        fields = {c["field"] for c in all_changes}
        assert "headline" in fields
        assert "summary" in fields


class TestGetProfileChange:
    def test_found(self):
        cid = log_profile_change("headline", "old", "new")
        assert get_profile_change(cid) is not None

    def test_not_found(self):
        assert get_profile_change("nonexist") is None


class TestMarkReverted:
    def test_marks_reverted(self):
        cid = log_profile_change("headline", "old", "new")
        mark_profile_change_reverted(cid)
        record = get_profile_change(cid)
        assert record["status"] == "reverted"


# ── apply_profile_change wrapper tests ──


class TestApplyProfileChange:
    def test_headline_success(self):
        save_setting("profile", {"headline": "Original HL", "provider_id": "prov1"})
        mock_client = AsyncMock()
        mock_client.update_profile_headline.return_value = {"success": True}

        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(mock_client, "acc1", "prov1", "headline", "New HL", "manual")
        )

        assert result["success"] is True
        assert result["change_id"] is not None
        mock_client.update_profile_headline.assert_called_once_with("acc1", "prov1", "New HL")

        # Verify DB record
        record = get_profile_change(result["change_id"])
        assert record["field"] == "headline"
        assert record["old_value"] == "Original HL"
        assert record["new_value"] == "New HL"

        # Verify cache updated
        profile = get_setting("profile", {})
        assert profile["headline"] == "New HL"

    def test_summary_success(self):
        save_setting("profile", {"summary": "Old summary"})
        mock_client = AsyncMock()
        mock_client.update_profile_summary.return_value = {"success": True}

        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(mock_client, "acc1", "prov1", "summary", "New summary")
        )

        assert result["success"] is True
        record = get_profile_change(result["change_id"])
        assert record["field"] == "summary"
        assert record["old_value"] == "Old summary"

    def test_photo_success(self):
        save_setting("profile", {})
        mock_client = AsyncMock()
        mock_client.upload_profile_photo.return_value = {"success": True}

        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(
                mock_client, "acc1", "prov1", "photo", "<photo uploaded>",
                image_bytes=b"\xff\xd8\xff", content_type="image/jpeg",
            )
        )

        assert result["success"] is True
        mock_client.upload_profile_photo.assert_called_once_with(
            "acc1", "prov1", b"\xff\xd8\xff", "image/jpeg",
        )

    def test_photo_missing_bytes(self):
        mock_client = AsyncMock()
        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(mock_client, "acc1", "prov1", "photo", "<photo>")
        )
        assert result["success"] is False
        assert "image_bytes" in result["error"]

    def test_unsupported_field(self):
        mock_client = AsyncMock()
        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(mock_client, "acc1", "prov1", "location", "NYC")
        )
        assert result["success"] is False
        assert "Unsupported" in result["error"]

    def test_client_failure_no_log(self):
        save_setting("profile", {"headline": "Orig"})
        mock_client = AsyncMock()
        mock_client.update_profile_headline.return_value = {"success": False, "error": "API down"}

        result = asyncio.get_event_loop().run_until_complete(
            apply_profile_change(mock_client, "acc1", "prov1", "headline", "New HL")
        )

        assert result["success"] is False
        assert result["change_id"] is None
        assert "API down" in result["error"]


# ── profile_history tool handler tests ──


class TestProfileHistoryTool:
    def test_history_empty(self):
        from heylead.tools.profile_history import run_profile

        result = asyncio.get_event_loop().run_until_complete(
            run_profile("history", field="nonexistent_field")
        )
        assert "No profile changes" in result

    def test_history_shows_entries(self):
        from heylead.tools.profile_history import run_profile

        log_profile_change("headline", "old", "new", "manual")
        result = asyncio.get_event_loop().run_until_complete(
            run_profile("history")
        )
        assert "Profile Change History" in result
        assert "headline" in result

    def test_current_empty(self):
        from heylead.tools.profile_history import run_profile

        save_setting("profile", {})
        result = asyncio.get_event_loop().run_until_complete(
            run_profile("current")
        )
        # Either shows "No profile cached" or shows the empty profile
        assert "profile" in result.lower()

    def test_current_with_data(self):
        from heylead.tools.profile_history import run_profile

        save_setting("profile", {
            "first_name": "Test",
            "last_name": "User",
            "headline": "Engineer",
            "summary": "About me",
        })
        result = asyncio.get_event_loop().run_until_complete(
            run_profile("current")
        )
        assert "Test" in result
        assert "Engineer" in result

    def test_restore_no_id(self):
        from heylead.tools.profile_history import run_profile

        result = asyncio.get_event_loop().run_until_complete(
            run_profile("restore", change_id="")
        )
        assert "provide" in result.lower()

    def test_restore_not_found(self):
        from heylead.tools.profile_history import run_profile

        result = asyncio.get_event_loop().run_until_complete(
            run_profile("restore", change_id="xxxxxxxx")
        )
        assert "No change found" in result

    def test_restore_already_reverted(self):
        from heylead.tools.profile_history import run_profile

        cid = log_profile_change("headline", "old", "new")
        mark_profile_change_reverted(cid)
        result = asyncio.get_event_loop().run_until_complete(
            run_profile("restore", change_id=cid)
        )
        assert "already been reverted" in result

    def test_restore_photo_blocked(self):
        from heylead.tools.profile_history import run_profile

        cid = log_profile_change("photo", "<prev>", "<new photo>")
        result = asyncio.get_event_loop().run_until_complete(
            run_profile("restore", change_id=cid)
        )
        assert "Cannot auto-restore photos" in result

    def test_unknown_action(self):
        from heylead.tools.profile_history import run_profile

        result = asyncio.get_event_loop().run_until_complete(
            run_profile("invalid_action")
        )
        assert "Unknown action" in result
