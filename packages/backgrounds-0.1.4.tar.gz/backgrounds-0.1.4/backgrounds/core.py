# -*- coding: utf-8 -*-
# Author: Quentin Baghi 2021 <quentin.baghi@protonmail.com>
"""
Code based on Jean-Baptiste Bayle's LISA GW Response to explore possibilities
to extend it to stationnary PSDs.
"""

from typing import Callable
import logging
import numpy as np
from numpy import cos, sin, pi, exp
from numpy.typing import ArrayLike
import healpy
from lisaconstants import c
from lisaorbits import ResampledOrbits

from .utils import multiple_dot, transform_covariance
from .tdi import compute_tdi_tf, aet_mat, convert

LINKS = np.array([12, 23, 31, 13, 32, 21])
SC = np.array([1, 2, 3])

try:
    from lisagwresponse.utils import (
        bspline_interp,
        dot,
        norm,
    )
except ImportError:
    from .utils import (
        bspline_interp,
        dot,
        norm,
    )

logger = logging.getLogger(__name__)
Interpolant = Callable[[np.ndarray], np.ndarray]



class Response:
    """Base class to compute LISA response to gravitational waves.
    """

    def __init__(self, orbits: str | ResampledOrbits, orbit_interp_order: int = 3, ltt=None,
                 tdi_tf_func=compute_tdi_tf):
        """Class constructor.
        Args:
            orbits: Path to orbits file or ResampledOrbits instance.
            orbit_interp_order: Spline interpolation order for orbits.
            ltt: Light travel time interpolants. If provided, override orbits file.
            tdi_tf_func: Function to compute TDI transfer function.
        """

        if isinstance(orbits, str):
            orbits = ResampledOrbits(orbits, interp_order=max(orbit_interp_order, 3))

        #: ResampledOrbits instance.
        self.orbits: ResampledOrbits = orbits
        #: Orbits spline-interpolation order.
        self.orbit_interp_order: int = int(orbit_interp_order)
        # TDI transfer function
        self.tdi_tf_func = tdi_tf_func
        # Light travel times
        if ltt is None:
            self._interpolate_orbits() # let lisaorbits deal with file format
        else:
            self._set_orbits(
                x={sc: 0.0 for sc in SC},
                y={sc: 0.0 for sc in SC},
                z={sc: 0.0 for sc in SC},
                ltt=ltt,
            )

    def _interpolate_orbits(self) -> None:
        """Interpolate orbital information from a resampled orbit object .

        Raises:
            ValueError: If orbit file is not supported.
        """
        logger.info("Computing spline interpolation for orbits")

        def interpolate(t, data) -> Interpolant:
            return bspline_interp(t, data, k=self.orbit_interp_order, ext="raise")

        self.x = {
            sc: interpolate(self.orbits.t_interp,
                            self.orbits.spacecraft_positions[:, i, 0])
            for i, sc in enumerate(SC)
        }
        self.y = {
            sc: interpolate(self.orbits.t_interp,
                            self.orbits.spacecraft_positions[:, i, 1])
            for i, sc in enumerate(SC)
        }
        self.z = {
            sc: interpolate(self.orbits.t_interp,
                            self.orbits.spacecraft_positions[:, i, 2])
            for i, sc in enumerate(SC)
        }

        self.ltt = {
            link: interpolate(self.orbits.t_interp,
                              self.orbits.compute_ltt(self.orbits.t_interp,
                                                      link=[link]).squeeze())
            for link in LINKS
        }

    def _set_orbits(
        self,
        x: dict[int, Interpolant | float],
        y: dict[int, Interpolant | float],
        z: dict[int, Interpolant | float],
        ltt: dict[int, Interpolant | float],
    ) -> None:
        """Set user-provided interpolating functions as orbital information.

        We also accept floats in the dictionaries, standing for constant values.

        Args:
            x: Spacecraft x-position interpolants in ICRS [m].
            y: Spacecraft y-position interpolants in ICRS [m].
            z: Spacecraft z-position interpolants in ICRS [m].
            ltt: Light travel time interpolants [s].
        """
        # pylint: disable=cell-var-from-loop
        # We use default values for `val` in lambdas to capture the values

        def ascallable(a: Interpolant | float) -> Interpolant:
            """Return a callable.

            Scalar values are returned as constant functions.

            Args:
                a: Input value.

            Returns:
                A callable.
            """
            if callable(a):
                return a

            def func(t: np.ndarray) -> np.ndarray:
                return np.full_like(t, float(a))

            return func

        self.x = {sc: ascallable(x[sc]) for sc in SC}
        self.y = {sc: ascallable(y[sc]) for sc in SC}
        self.z = {sc: ascallable(z[sc]) for sc in SC}
        self.ltt = {link: ascallable(ltt[link]) for link in LINKS}

    def compute_tdi_design_matrix(self, freqs, t0, gen='2.0', average=True):
        """Compute the TDI transfer function matrix

        Parameters
        ----------
        freqs : ndarray
            frequency array [Hz]
        t0 : ndarray
            time (or time vector of size nt) where to compute the TDI design matrix or its average.
        gen : str, optional
            TDI generation, by default '2.0'
        average : bool, optional
            if True, compute the average of the design matrix over all times in t0

        Returns
        -------
        tdi_mat_eval
            TDI transfer function matrix for XYZ, array of size nf x 3 x 6 or size nf x nt x 3 x 6

        Raises
        ------
        ValueError
            TDI generation can only be 1.5 or 2.0.
        """
        # If we average over times
        if isinstance(t0, np.ndarray) & average:
            return np.mean(self.tdi_tf_func(freqs, self.ltt, t0, gen=gen), axis=1)
        # Otherwise we output the full matrix
        return self.tdi_tf_func(freqs, self.ltt, t0, gen=gen)


class StochasticPointSourceResponse(Response):
    """Generate response for a point-like gravitational-wave stochastic source.

    The +/x-polarized strains are white Gaussian noise.
    """

    def __init__(self, ra: float, dec: float,
                 **kwargs):
        """Class constructor.

        Parameters
        ----------
        ra: float
            Source right ascension (equatorial longitude) in ICRS [rad].
        dec: float
            Source declination (equatorial latitude) in ICRS [rad].

        """

        super().__init__(**kwargs)

        self.ra = ra
        self.dec = dec
        self.set_position(ra, dec)

    @classmethod
    def from_gw(cls, pt_src):
        """Load StochasticPointSourceResponse arguments from StochasticPointSource object

        Parameters
        ----------
        pt_src : lisagwresponse.StochasticPointSource instance
             instance

        Returns
        -------
        class
            StochasticPointSourceResponse object
        """

        resp = cls(ra=pt_src.ra, dec=pt_src.dec, orbits=pt_src.orbits_path,
                   orbit_interp_order=pt_src.orbit_interp_order)

        return resp

    def set_position(self, ra: float, dec: float) -> None:
        """Set the source position in the sky.

        This triggers the computation of the sour-localization basis vectors.

        Args:
            ra: Source right ascension (equatorial longitude) in ICRS [rad].
            dec: Source declination (equatorial latitude) in ICRS [rad].
        """
        self.ra = float(ra)
        self.dec = float(dec)

        # Compute source-localization vector basis
        self.k = np.array(
            [
                -cos(dec) * cos(ra),
                -cos(dec) * sin(ra),
                -sin(dec),
            ]
        )
        self.u = np.array([sin(ra), -cos(ra), 0])
        self.v = np.array(
            [
                -sin(dec) * cos(ra),
                -sin(dec) * sin(ra),
                cos(dec),
            ]
        )

    def compute_kernel(self, links: ArrayLike, f: ArrayLike, t: ArrayLike,
                       deriv: int=0, t_shift=False):
        """
        Compute LISA's single-link response to monochromatic GWs.

        Parameters
        ----------
        links : array_like
            list of single-links
        f : array_like
            frequency array where to compute the response. If f has more than one element,
            t should have only one element, and vice versa.
        t : array_like
            time array where to compute the response. If t has more than one element,
            f should have only one element, and vice versa.
        deriv : int, optional
            If greater than 0, compute the ith derivative, by default 0
        t_shift : bool, optional
            if t_shift is True, the response is shifted by exp(2*pi*f*t). Default is False.

        Returns
        -------
        g_plus, g_cross : array_like
            Response kernels for + and x polarizations. Should have size len(links) x len(f),
            or len(links) x len(t) x len(f)

        Raises
        ------
        ValueError
            [description]
        """
        # pylint: disable=too-many-locals,too-many-statements
        # # Compute emission and reception time at spacecraft
        trec = t  # (t)
        temi = np.repeat(trec[np.newaxis],
                            len(links), axis=0)  # (link, t)
        for link_index, link in enumerate(links):
            temi[link_index] -= self.ltt[link](t)

        # Compute spacecraft positions at emission and reception
        try:
            xrec = np.empty((len(links), len(t), 3))  # (link, t, coord)
            for link_index, link in enumerate(links):
                receiver = int(str(link)[0])
                xrec[link_index, :, 0] = self.x[receiver](trec)
                xrec[link_index, :, 1] = self.y[receiver](trec)
                xrec[link_index, :, 2] = self.z[receiver](trec)
            xemi = np.empty((len(links), len(t), 3))  # (link, t, coord)
            for link_index, link in enumerate(links):
                emitter = int(str(link)[1])
                xemi[link_index, :, 0] = self.x[emitter](temi[link_index])
                xemi[link_index, :, 1] = self.y[emitter](temi[link_index])
                xemi[link_index, :, 2] = self.z[emitter](temi[link_index])
        except ValueError as error:
            raise ValueError(
                "missing orbit information, use longer orbit file or adjust sampling") from error

        # Compute link unit vector
        n = xrec - xemi  # (link, t, coord)
        n /= norm(n)[..., np.newaxis]

        # Compute equivalent emission and reception time at the Sun
        trec_sun = trec[np.newaxis] - dot(xrec, self.k) / c  # (link, t)
        temi_sun = temi - dot(xemi, self.k) / c  # (link, t)
        # so temi = t - L - r_i.k / c

        # Compute antenna pattern functions
        xiplus = dot(n, self.u)**2 - dot(n, self.v)**2  # (link, t)
        xicross = 2 * dot(n, self.u) * dot(n, self.v)  # (link, t)

        if not t_shift:
            # size (link, t)
            dtrec = trec_sun - t[np.newaxis, :]
            dtemi = temi_sun - t[np.newaxis, :]
        else:
            dtrec = trec_sun[:]
            dtemi = temi_sun[:]

        # dtemi and dtrec have dimension (link, t)
        # g must be (link, t, f)
        g = (2j*pi*dtemi[..., np.newaxis])**deriv * exp(2j*pi*f*dtemi[..., np.newaxis]) - \
            (2j*pi*dtrec[..., np.newaxis])**deriv * exp(2j*pi*f*dtrec[..., np.newaxis])
        # The denominator has size (link, t, f)
        denom = 2 * (1 - dot(n, self.k))
        # g+ and gx have dimension (link, t, f)
        g_plus = g * xiplus[..., np.newaxis] / denom[..., np.newaxis]
        g_cross = g * xicross[..., np.newaxis] / denom[..., np.newaxis]

        # If there is only one time value, then we can get rid of the last dimension
        if t.size == 1:
            return g_plus[:, 0, :], g_cross[:, 0, :]
        # g_plus and g_cross should have dimensions link, t, f
        return g_plus, g_cross

    def compute_correlations(self, links, f, t, deriv=0, t_shift=False):
        """
        Compute the correlation matrices from a stochastic point source, by polarization.

        Parameters
        ----------
        links : array_like
            list of single-links
        f : array_like
            frequency array where to compute the response. If f has more than one element,
            t should have only one element, and vice versa.
        t : array_like
            time array where to compute the response. If t has more than one element,
            f should have only one element, and vice versa.
        deriv : int, optional
            If greater than 0, compute the ith derivative, by default 0
        t_shift : bool, optional
            if t_shift is True, the response is shifted by exp(2*pi*f*t). Default is False.

        Returns
        -------
        g_plus_mat, g_cross_mat : array_like
            Point-source correlation matrix, such that is S(f) is the GW source PSD, then
            the single-link spectrum matrix will be (g_plus_mat + g_cross_mat) * S(f)
            The size of g_plus_mat is nf x nt x 6 x 6

        """
        # Compute pixel response. Has dimension (links, t, f)
        gp, gc = self.compute_kernel(
            links, f, t, deriv=deriv, t_shift=t_shift)
        # Compute cross-PSD model
        g_plus_mat = multiple_dot(gp.T[..., np.newaxis],
                                  np.swapaxes(gp.T[..., np.newaxis].conj(), gp.ndim-1, gp.ndim))
        g_cross_mat = multiple_dot(gc.T[..., np.newaxis],
                                   np.swapaxes(gc.T[..., np.newaxis].conj(), gp.ndim-1, gp.ndim))

        return g_plus_mat, g_cross_mat

    def compute_tdi_kernel(self, fr, t0, tdi_var='aet', gen='2.0'):
        """
        Compute the SGWB covariance matrix in the TDI domain

        Parameters
        ----------
        fr : array_like
            frequency array where to compute the response.
        t0 : array_like
            time array where to compute the response.
        tdi_var : str, optional
            Chosen TDI variables. Default is 'aet', can be 'xyz'.
        gen : str, optional
            TDI generation, by default 2.0

        Returns
        -------
        g_mat : ndarray
            correlation matrix of size nt x nf x 3 x 3 (if t0 is a vector),
            otherwise array of nf x 3 x 3.
        """
        # Compute single-link kernel matrix
        gp, gc = self.compute_correlations(LINKS, fr, np.array([t0]))
        # Compute TDI transfer function
        tdi_mat = self.compute_tdi_design_matrix(fr, t0, gen=gen)
        # Adapt to LISA GW Response ordering
        tdi_mat = tdi_mat[..., convert]

        # Transformation matrix
        if tdi_var == 'aet':
            if isinstance(t0, (np.ndarray, list)):
                tdi_mat = multiple_dot(aet_mat[np.newaxis, np.newaxis, ...], tdi_mat)
            else:
                tdi_mat = multiple_dot(aet_mat[np.newaxis, ...], tdi_mat)
        # Compute TDI kernel
        g_mat = transform_covariance(
            tdi_mat, gp) + transform_covariance(tdi_mat, gc)
        return g_mat


class StochasticBackgroundResponse(Response):
    """Generate response for a stochastic gravitational-wave background.

    The +/x-polarized strains are white Gaussian noise.
    """

    def __init__(self, skymap, **kwargs):

        super().__init__(**kwargs)

        self.skymap = skymap
        self.npix = len(skymap)
        self.nside = healpy.npix2nside(self.npix)
        # To store further computations
        self.links = LINKS
        self.g_plus_mat = None
        self.g_cross_mat = None
        # Instantiate a StochasticPointSourceResponse to use its methods
        self.source_cls = StochasticPointSourceResponse(ra=0.0, dec=0.0, orbits=self.orbits,
                                                        orbit_interp_order=self.orbit_interp_order)

    @classmethod
    def from_gw(cls, sgwb):
        """Instantiate the class from a LISA GW Response's StochasticBackground object

        Parameters
        ----------
        sgwb : StochasticBackground instance
            SGWB LISA Response class
        """

        # Instantiate the StochasticBackgroundResponse class
        resp = cls(skymap=sgwb.skymap, orbits=sgwb.orbits_path,
                   orbit_interp_order=sgwb.orbit_interp_order)

        return resp

    def add_pixel_response(self, pixel, links, f, t, deriv=0, t_shift=False):
        """Add the response of a single pixel to the correlation matrices.
        This used is for sky-averaged response.

        Parameters
        ----------
        pixel : int
            Pixel index in the healpy map
        deriv : int, optional
            _description_, by default 0
        t_shift : bool, optional
            _description_, by default False
        approx : bool, optional
            _description_, by default False
        """

        # Get colatitude and longitude of the pixel (healpy convention)
        theta, phi = healpy.pix2ang(self.nside, pixel)
        # Convert to dec, ra
        dec, ra = np.pi / 2 - theta, phi
        # Set source position
        self.source_cls.set_position(ra, dec)
        # Compute pixel correlations matrix
        gp_mat, gc_mat = self.source_cls.compute_correlations(
            links, f, t, deriv=deriv, t_shift=t_shift)
        # Compute cross-PSD model
        self.g_plus_mat += gc_mat * self.skymap[pixel]**2
        self.g_cross_mat += gp_mat * self.skymap[pixel]**2

    def compute_correlations(self, links, f, t, deriv=0, t_shift=False):
        """
        Compute the correlation matrices from a stochastic GW background, by polarization.

        Parameters
        ----------
        links : array_like
            list of single-links
        f : array_like
            frequency array where to compute the response.
        t : array_like or float
            time array where to compute the response.
        deriv : int, optional
            If greater than 0, compute the ith derivative, by default 0
        t_shift : bool, optional
            if t_shift is True, the response is shifted by exp(2*pi*f*t). Default is False.
        approx : bool, optional
            If True, use the cardinal sine approximation of the response, by default False

        Returns
        -------
        g_plus_mat, g_cross_mat : array_like
            SGWB correlation matrix, such that is S(f) is the GW source PSD, then
            the single-link spectrum matrix will be (g_plus_mat + g_cross_mat) * S(f)
            The size of teh output matrices is nf x nt x 6 x 6
        """

        nf = len(f)
        nt = len(t)
        if nt == 1:
            self.g_plus_mat = np.zeros((nf, len(links), len(links)), dtype=complex)
            self.g_cross_mat = np.zeros((nf, len(links), len(links)), dtype=complex)
        else:
            self.g_plus_mat = np.zeros((nf, nt, len(links), len(links)), dtype=complex)
            self.g_cross_mat = np.zeros((nf, nt, len(links), len(links)), dtype=complex)

        for pixel in range(self.npix):
            self.add_pixel_response(pixel, links, f, t, deriv=deriv, t_shift=t_shift)

        return self.g_plus_mat, self.g_cross_mat

    def compute_tdi_kernel(self, fr, t0, tdi_var='aet', gen='2.0'):
        """
        Compute the SGWB covariance matrix in the TDI domain

        Parameters
        ----------
        fr : array_like
            frequency array where to compute the response, size nf.
        t0 : array_like
            time array where to compute the response, size nt.
        tdi_var : str, optional
            Chosen TDI variables. Default is 'aet', can be 'xyz'.
        gen : str, optional
            TDI generation, by default 2.0

        Returns
        -------
        g_mat : ndarray
            correlation matrix of size nt x nf x 3 x 3 (if t0 is a vector),
            otherwise the size is nf x 3 x 3
        """

        # Compute single-link kernel matrix
        if isinstance(t0, (np.ndarray, list)):
            gp, gc = self.compute_correlations(self.links, fr, t0)
        else:
            gp, gc = self.compute_correlations(self.links, fr, np.asarray([t0]))
        # Compute TDI transfer function
        tdi_mat = self.tdi_tf_func(fr, self.ltt, t0, gen=gen)
        # Make an additional transformation if AET is requested
        if tdi_var == 'aet':
            tdi_mat = multiple_dot(aet_mat[np.newaxis, :, :], tdi_mat)
        # Convert TDI matrix to LISA GW Response ordering
        tdi_mat = tdi_mat[..., convert]
        # Compute TDI kernel
        g_mat = transform_covariance(tdi_mat, gp) + transform_covariance(tdi_mat, gc)

        return g_mat
