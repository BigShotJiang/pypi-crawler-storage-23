# -*- coding: utf-8 -*-
# Author: Quentin Baghi 2021 <quentin.baghi@protonmail.com>
import warnings
import numpy as np
import jax
import jax.numpy as jnp


@jax.jit
def log_uniform_pdf(x, a, b):
    """Compute the log-pdf of a log-uniform distribution

    Parameters
    ----------
    x : ndarray
        points where to evaluate the log-pdf
    a : float
        lower bound of the distribution
    b : float
        upper bound of the distribution

    Returns
    -------
    log_pdf : ndarray
        log-pdf evaluated at x

    """

    x = jnp.asarray(x)

    lower = jnp.all(x > a)
    upper = jnp.all(x < b)

    valid = lower & upper

    return jnp.where(valid, 0.0, -jnp.inf)


class LogUniformPrior:
    """Log-uniform prior distribution
    """

    def __init__(self, a, b):
        """
        Instantiate a log-uniform prior distribution.

        Parameters
        ----------
        a : float
            lower bound of the distribution
        b : float
            upper bound of the distribution

        """
        self.a = a
        self.b = b
        if isinstance(a, np.ndarray):
            self.ndim = self.a.size
        elif isinstance(a, list):
            self.ndim = len(a)
        else:
            self.ndim = 1

        self.batched_evaluate = jax.vmap(self.evaluate)

    def evaluate(self, x):
        """evaluate value of the log-pdf at x

        Parameters
        ----------
        x : ndarray
            points where to evaluate the log-pdf

        Returns
        -------
        log_pdf : ndarray
            log-pdf evaluated at x

        """
        return log_uniform_pdf(x, self.a, self.b)

    def initialize_single_param(self):
        """Initialize one parameter state

        Parameters
        ----------

        Returns
        -------
        p_0 : ndarray
            parameter vector, size ndim
        """

        p_0 = np.random.uniform(low=self.a, high=self.b)

        return np.atleast_1d(p_0)

    def logpdf(self, x):
        """evaluate value of the log-prior distribution for batched argument x
        This is for compatibility with eryn package.

        Parameters
        ----------
        x : jnp.ndarray
            Spline coefficients

        Returns
        -------
        logpdf : float
            Log-prior value at x

        """

        return np.asarray(self.batched_evaluate(x))

    def rvs(self, size=1):

        """Generate random variates from the prior distribution

        Parameters
        ----------
        size : int, optional
            Number of samples to generate, by default 1

        Returns
        -------
        samples : jnp.ndarray
            Samples drawn from the prior distribution

        """

        if not isinstance(size, int) and not isinstance(size, tuple):
            raise ValueError("size must be an integer or tuple of ints.")

        if isinstance(size, int):
            size = (size,)

        logpdf_values = np.concatenate([self.initialize_single_param()
                                        for _ in range(np.prod(size))])

        return logpdf_values.reshape(size + (self.ndim,))


@jax.jit
def conditional_beta_logpdf(x, alphas, betas, x_min, x_max, delta_min=0):
    """
    Compute the log-pdf of a Beta distribution on [x_min, x_max]

    Parameters
    ----------
    x : ndarray
        points where to evaluate the log-pdf
    a : float
        alpha parameter of the Beta distribution
    b : float
        beta parameter of the Beta distribution
    x_min : float
        minimum of the support
    x_max : float
        maximum of the support
    delta_min : float, optional
        minimum spacing between two knots, by default 0

    Returns
    -------
    log_pdf : ndarray
        log-pdf evaluated at x

    """
    # Convert to jax array if needed
    x_knots = jnp.asarray(x)

    # Check bounds using jax conditionals
    in_bounds = jnp.all(x_min <= x_knots) & jnp.all(x_max >= x_knots)

    # Compute the log-prior value
    x0 = jnp.concatenate([x_min, x_knots[0:-1]])
    x1 = x_knots[:]

    logps = (alphas - 1) * jnp.log(x1 - x0)
    logps -= (alphas + betas - 1) * jnp.log(x_max - x0)
    logps += (betas - 1) * jnp.log(x_max - x1)
    log_prior_value = jnp.sum(logps)

    # Check spacing constraint
    x_knots_full = jnp.concatenate([x_min, jnp.sort(x_knots), x_max])
    spacing_ok = jnp.all(jnp.diff(x_knots_full) >= delta_min)

    # Combine all conditions
    valid = in_bounds & spacing_ok & jnp.isfinite(log_prior_value)

    # Return -inf if invalid, otherwise return log_prior
    return jnp.where(valid, log_prior_value, -jnp.inf)


class KnotLocationPrior:
    """
    Impements only the Beta conditional distribution on
    spline knots locations (without accounting for
    the coefficient values).

    """

    def __init__(self, x_min, x_max, n_knots,
                 delta_min=0, alphas_dirichlet=None):

        self.x_min = jnp.atleast_1d(jnp.asarray(x_min))
        self.x_max = jnp.atleast_1d(jnp.asarray(x_max))
        self.n_knots = n_knots
        self.ndim = n_knots

        if alphas_dirichlet is None:
            self.alphas_dirichlet = 2*jnp.ones(self.n_knots+1)
        else:
            self.alphas_dirichlet = jnp.asarray(alphas_dirichlet)

        # Minimum knot interval
        self.delta_min = delta_min
        # Parameters of the conditional beta distributions
        self.alphas = jnp.ones(self.n_knots) * 2
        self.betas = self.n_knots - jnp.arange(1, self.n_knots+1) + 2

        # For jax vectorization
        self.batched_evaluate = jax.vmap(self.evaluate)

    def evaluate(self, x_knots):
        """evaluate value of the log-prior distribution at x

        Parameters
        ----------
        x_knots : ndarray
            knot locations

        Returns
        -------
        log_prior : float
            value of the log-prior at parameter value x

        """

        return conditional_beta_logpdf(x_knots, self.alphas, self.betas,
                                       self.x_min, self.x_max, self.delta_min)

    def initialize_single_param(self, n_draws=10000):
        """Initialize one parameter state

        Parameters
        ----------

        Returns
        -------
        p_0 : ndarray
            parameter vector, size ndim
        """

        ok = False
        i = 0

        while (not ok) & (i < n_draws):
            # Intialize the knot locations
            deltas = np.random.dirichlet(self.alphas_dirichlet)
            p_0_knot_x_ordered = self.x_min + \
                (self.x_max - self.x_min) * \
                np.cumsum(deltas)[0:self.n_knots]
            # Full vector including exterior knots
            knots_x = np.concatenate(
                [self.x_min, p_0_knot_x_ordered, self.x_max])
            # Knots intervals
            dknots = np.diff(knots_x)
            if np.all(dknots >= self.delta_min):
                ok = True
            else:
                i += 1
        if not ok:
            warnings.warn("Could not find a good starting point.")

        return p_0_knot_x_ordered

    def logpdf(self, x):
        """evaluate value of the log-prior distribution at x

        Parameters
        ----------
        x : jnp.ndarray
            Knot locations (interior knots only)

        Returns
        -------
        logpdf : float
            Log-prior value at x

        """

        return np.asarray(self.batched_evaluate(x))

    def rvs(self, size=1):

        """Generate random variates from the prior distribution

        Parameters
        ----------
        size : int, optional
            Number of samples to generate, by default 1

        Returns
        -------
        samples : jnp.ndarray
            Samples drawn from the prior distribution

        """
        if not isinstance(size, int) and not isinstance(size, tuple):
            raise ValueError("size must be an integer or tuple of ints.")

        if isinstance(size, int):
            size = (size,)

        logpdf_values = np.concatenate([self.initialize_single_param() 
                                        for _ in range(np.prod(size))])

        return logpdf_values.reshape(size + (self.ndim,))
