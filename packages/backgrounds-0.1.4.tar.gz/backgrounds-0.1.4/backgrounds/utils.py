# -*- coding: utf-8 -*-
# Author: Quentin Baghi 2021 <quentin.baghi@protonmail.com>
import warnings
from typing import Any, Callable
import jax
import jax.numpy as jnp
import numpy as np
from numpy.typing import ArrayLike
from scipy import interpolate, integrate
from scipy.interpolate import make_interp_spline
from interpax import Interpolator1D, Interpolator2D
# FTT modules
try:
    from pyfftw.interfaces.numpy_fft import ifft
except ImportError:
    from numpy.fft import ifft


def order2kind(interp_order):
    """
    Convert interpolation order to interpolation kind.
    """

    # Create interpolating function
    if interp_order == 1:
        kind = 'linear'
    elif interp_order == 2:
        kind = 'quadratic'
    elif interp_order == 3:
        kind = 'cubic'
    else:
        raise TypeError(
            f"invalid interpolation order '{interp_order}', must be 1, 2 or 3")

    return kind


def generate_noise(psd_func, n_data, fs, n_psd=None, f_zero=None):
    """
    Noise generator from arbitrary power spectral density.
    Uses a Gaussian random generation in the frequency domain.

    Parameters
    ----------
    psd_func: callable
        one-sided PSD function in A^2 / Hz, where A is the unit of the desired
        output time series. Can also return a p x p spectrum matrix
    n_data: int
        size of output time series
    fs: float
        sampling frequency in Hz
    n_psd : int
        number of random points to generate in the frequency domain
        if None, the default is 2 x n_data.
    f_zero: float or None
        the value to use for the zero frequency. If None (default), the zero frequency is chosen
        equal to the frequency resolution fs / n_data.

    Returns
    -------
    tseries: ndarray
        generated time series

    """

    # Number of points to generate in the frequency domain (circulant embedding)
    if n_psd is None:
        n_psd = 2 * n_data
    # Number of positive frequencies
    n_fft = int((n_psd-1)/2)
    # Frequency array
    f = np.fft.fftfreq(n_psd)*fs
    # Avoid zero frequency as it sometimes makes the PSD infinite
    if f_zero is None:
        f[0] = f[1]
    else:
        f[0] = f_zero
    # Compute the PSD (or the spectrum matrix)
    psd_f = psd_func(np.abs(f))

    if psd_f.ndim == 1:
        psd_sqrt = np.sqrt(psd_f)
        # Real part of the Noise fft : it is a gaussian random variable
        noise_tf_real = np.sqrt(0.5) * psd_sqrt[0:n_fft + 1] * np.random.normal(
            loc=0.0, scale=1.0, size=n_fft + 1)
        # Imaginary part of the Noise fft :
        noise_tf_im = np.sqrt(0.5) * psd_sqrt[0:n_fft + 1] * np.random.normal(
            loc=0.0,  scale=1.0, size=n_fft + 1)
        # The Fourier transform must be real in f = 0
        noise_tf_im[0] = 0.
        noise_tf_real[0] = noise_tf_real[0]*np.sqrt(2.)
        # Create the NoiseTF complex numbers for positive frequencies
        noise_tf = noise_tf_real + 1j*noise_tf_im
    elif psd_f.ndim == 3:
        # Number of variables
        p = psd_f.shape[1]
        # Form the covariance matrices in the Fourier domain
        cov = psd_f[0:n_fft + 1]
        # Perform Cholesky factorization of the correlation matrices C_m
        psd_sqrt = np.linalg.cholesky(cov)
        # Real part of the Noise fft : it is a gaussian random variable
        w_real = np.sqrt(0.5) * np.random.multivariate_normal(
            np.zeros(p), np.eye(p), size=n_fft + 1)
        w_imag = np.sqrt(0.5) * np.random.multivariate_normal(
            np.zeros(p), np.eye(p), size=n_fft + 1)
        # Generate the Z_m in the Fourier domain
        noise_tf = multiple_dot_vect(psd_sqrt, w_real + 1j*w_imag)
        # The Fourier transform must be real in f = 0
        noise_tf[0].imag = 0
        noise_tf[0].real = noise_tf[0].real*np.sqrt(2.)

    # To get a real valued signal we must have NoiseTF(-f) = NoiseTF*
    if (n_psd % 2 == 0) & (psd_f.ndim == 1):
        # The TF at Nyquist frequency must be real in the case of an even
        # number of data
        noise_sym0 = np.array([psd_sqrt[n_fft + 1] * np.random.normal(0, 1)])
        # Add the symmetric part corresponding to negative frequencies
        noise_tf = np.hstack((noise_tf, noise_sym0,
                              np.conj(noise_tf[1:n_fft+1])[::-1]))
    elif (n_psd % 2 != 0) & (psd_f.ndim == 1):
        noise_tf = np.hstack((noise_tf, np.conj(noise_tf[1:n_fft+1])[::-1]))

    elif (n_psd % 2 == 0) & (psd_f.ndim == 3):
        noise_sym0 = np.random.multivariate_normal(np.zeros(p), psd_f[n_fft + 1].real)
        noise_tf = np.concatenate((noise_tf, noise_sym0[np.newaxis, :],
                                   np.conj(noise_tf[1:n_fft+1])[::-1]))

    elif (n_psd % 2 != 0) & (psd_f.ndim == 3):
        noise_tf = np.concatenate((noise_tf, np.conj(noise_tf[1:n_fft+1])[::-1]))
    else:
        warnings.WarningMessage("Invalid spectrum dimension", UserWarning, "invalid_dim", 149)

    tseries = ifft(np.sqrt(n_psd*fs/2.) * noise_tf, axis=0)

    return tseries[0:n_data].real


@jax.jit
def multiple_dot(a_mat, b_mat):
    """
    Perform the matrix multiplication of two list of matrices.

    Parameters
    ----------
    a : ndarray
        series of m x n matrices (array of size p x m x n)
    b : ndarray
        series of n x k matrices (array of size p x n x k)

    Returns
    -------
    c : ndarray
        array of size p x m x k containg the dot products of all matrices
        contained in a and b.


    """
    return jnp.einsum("...jk, ...kl", a_mat, b_mat)


@jax.jit
def multiple_dot_vect(a_mat, b_vect):
    """
    Performs matrix-to-vector multiplication on a array of matrices and vectors

    Parameters
    ----------
    a : ndarray
        series of m x n matrices (array of size p x m x n)
    b : ndarray
        series of n x k vectors (array of size p x n)

    Returns
    -------
    c : ndarray
        array of size p x m containg the dot products of all vectors
        contained in a and b.


    """
    return jnp.einsum("...jk, ...k", a_mat, b_vect)

@jax.jit
def transform_covariance(tf, cov):
    """
    Compute the product tf cov tf^H for an array of matrices and a covariances.

    Parameters
    ----------
    tf : ndarray
        transfer function matrix, size nf x p x q
    cov : covariance matrix
        covariance matrix, size nf x q x q

    Returns
    -------
    tfcovtft : ndarray
        matrix product tf cov tf^H, size nf x p x p
    """

    return multiple_dot(tf, multiple_dot(cov, jnp.conj(jnp.swapaxes(tf, cov.ndim-2, cov.ndim-1))))

@jax.jit
def compute_covariances(link_psd, tdi_corr):
    """
    Calculate the full covariances at frequencies finds.

    Parameters
    ----------
    link_psd : ndarray
        Link PSD of size nf
    tdi_corr : ndarray
        Correlation matrix of size nf x nt x 3 x 3

    Returns
    -------
    cov : ndarray
        matrix of covariances for all channels, size nf x 3 x 3 
        (if t0 is a float or average is True) or size nf x nt x 3 x 3
    """

    # Apply TDI transfer matrix to the single-link PSDs
    cov_tdi = jnp.multiply(tdi_corr.T, link_psd).T

    return cov_tdi

@jax.jit
def sum_covariances(cov_list):
    """
    Sum a list of covariance matrices.

    Parameters
    ----------
    cov_list : list of ndarray
        List of covariance matrices to sum.

    Returns
    -------
    cov_sum : ndarray
        Sum of the covariance matrices.
    """
    return jnp.sum(jnp.array(cov_list), axis=0)

@jax.jit
def sym_matrix_inv_from_rows(a, b, c, e, f, i):
    """_summary_

    Parameters
    ----------
    a : array_like, size n_mat
        00 element
    b : array_like
        01 element
    c : array_like
        02 element
    e : array_like
        11 element
    f : array_like
        12 element
    i : array_like
        22 element

    Returns
    -------
    mat_inv : ndarray
        array of inverse matrices
    det : ndarray
        array of matrix determinants
    """

    big_a = e*i - jnp.abs(f)**2
    big_b = -(jnp.conj(b)*i - f*jnp.conj(c))
    big_c = jnp.conj(b)*jnp.conj(f) - e*jnp.conj(c)
    big_e = a*i - jnp.abs(c)**2
    big_f = -(a*jnp.conj(f) - b*jnp.conj(c))
    big_i = a*e - jnp.abs(b)**2

    det = a*big_a + b*big_b + c*big_c

    mat_inv = jnp.array([[big_a.T, big_b.T, big_c.T],
                         [jnp.conj(big_b).T, big_e.T, big_f.T],
                         [jnp.conj(big_c).T, jnp.conj(big_f).T, big_i.T]])
    mat_inv = (1.0 / det[..., jnp.newaxis, jnp.newaxis]) * jnp.transpose(mat_inv)

    return mat_inv, det

@jax.jit
def sym_matrix_inv(mat):
    """

    Efficiently computes the inverse of a 
    series of 3 x 3 symmetric matrices.

    Parameters
    ----------
    mat : ndarray
        series of matrices n_mat x 3 x 3

    Returns
    -------
    mat_inv : ndarray
        series of matrix inverses (size n_mat x 3 x 3)
    det : ndarray, optional
        series of determinants (size n_mat)
    """

    a = mat[..., 0, 0]
    b = mat[..., 0, 1]
    c = mat[..., 0, 2]
    e = mat[..., 1, 1]
    f = mat[..., 1, 2]
    i = mat[..., 2, 2]

    return sym_matrix_inv_from_rows(a, b, c, e, f, i)


class CovarianceInterpolator:
    """Interpolate frequency-domain covariance matrices (assumed to be Hermitian)
    """

    def __init__(self, x, mat, kind='cubic', fill_value="extrapolate") -> None:
        """
        Class constructor.

        Parameters
        ----------
        x : array_like
            interpolation points
        mat : array_like
            covariance matrices to interpolate, size n_freq x n x m
        kind : str, optinal
            interpolation kind, default is 'cubic'
        fill_value : str, optional
            value to use for points outside the interpolation range.

        """

        # Number of rows
        self.n = mat.shape[-2]
        # Number of columns
        self.m = mat.shape[-1]

        # Gather the upper triangular part of the matrix, excluding the diagonal
        self.triu_idx = np.triu_indices(self.n, k=1)
        # Gather the diagonal indices
        self.diag_idx = np.diag_indices(self.n)

        if fill_value == "extrapolate":
            extrap = True
        else:
            extrap = False

        # Create an interpolator of the diagonal elements
        self.diag_interpolators = Interpolator1D(x,
                                                 mat[..., self.diag_idx[0], self.diag_idx[1]].real,
                                                 method=kind, extrap=extrap)
        # Create an interpolator of the upper triangular elements, real part
        self.offr_interpolators = Interpolator1D(x,
                                                 mat[..., self.triu_idx[0], self.triu_idx[1]].real,
                                                 method=kind, extrap=extrap)
        # Create an interpolator of the upper triangular elements, imaginary part
        self.offi_dinterpolators = Interpolator1D(x,
                                                 mat[..., self.triu_idx[0], self.triu_idx[1]].imag,
                                                 method=kind, extrap=extrap)

    def __call__(self, x_new):
        """Evaluate the covariance at new points

        Parameters
        ----------
        x_new : array_like
            new inteprolation points
        """
        # Evaluate the upper triangular part of the matrix
        mat_triu = self.offr_interpolators(x_new) + 1j*self.offi_dinterpolators(x_new)
        # Create an empty array
        mat = np.zeros(x_new.shape + (self.n, self.m), dtype=mat_triu.dtype)
        # Fill the diaogonal part
        mat[..., self.diag_idx[0], self.diag_idx[1]] = self.diag_interpolators(x_new)
        # Fill the upper triangular part
        mat[..., self.triu_idx[0], self.triu_idx[1]] = mat_triu
        # Fill the lower triangular part by symmetry
        mat[..., self.triu_idx[1], self.triu_idx[0]] = np.conj(mat_triu)

        return mat


class Covariance2DInterpolator:
    """Interpolate time-frequency-domain covariance matrices (assumed to be Hermitian)
    """
    def __init__(self, x, y, mat, kind='cubic', fill_value="extrapolate") -> None:
        """
        Interpolates a time-frequency matrix function.
        """

        # Number of rows
        self.n = mat.shape[-2]
        # Number of columns
        self.m = mat.shape[-1]

        # Gather the upper triangular part of the matrix, excluding the diagonal
        self.triu_idx = np.triu_indices(self.n, k=1)
        # Gather the diagonal indices
        self.diag_idx = np.diag_indices(self.n)

        if fill_value == "extrapolate":
            extrap = True
        else:
            extrap = False

        # Create an interpolator of the diagonal elements
        self.diag_interpolators = Interpolator2D(x, y,
                                                 mat[..., self.diag_idx[0], self.diag_idx[1]].real,
                                                 method=kind, extrap=extrap)
        # Create an interpolator of the upper triangular elements, real part
        self.offr_interpolators = Interpolator2D(x, y,
                                                 mat[..., self.triu_idx[0], self.triu_idx[1]].real,
                                                 method=kind, extrap=extrap)
        # Create an interpolator of the upper triangular elements, imaginary part
        self.offi_dinterpolators = Interpolator2D(x, y,
                                                 mat[..., self.triu_idx[0], self.triu_idx[1]].imag,
                                                 method=kind, extrap=extrap)

    def __call__(self, x_new, y_new):
        """Evaluate the covariance at new points

        Parameters
        ----------
        x_new : array_like
            new inteprolation points on the first axis (size N)
        y_new : array_like
            new inteprolation points on the second axis (size N)

        Returns
        -------
        mat : ndarray
            interpolated covariance matrices at (x_new, y_new). The output shape is (N, n, m)
        """
        # Evaluate the upper triangular part of the matrix
        mat_triu = self.offr_interpolators(x_new, y_new) + 1j*self.offi_dinterpolators(x_new, y_new)
        # Create an empty array
        mat = np.zeros((x_new.size, self.n, self.m), dtype=mat_triu.dtype)
        # Fill the diaogonal part
        mat[:, self.diag_idx[0], self.diag_idx[1]] = self.diag_interpolators(x_new, y_new)
        # Fill the upper triangular part
        mat[:, self.triu_idx[0], self.triu_idx[1]] = mat_triu
        # Fill the lower triangular part by symmetry
        mat[:, self.triu_idx[1], self.triu_idx[0]] = np.conj(mat_triu)

        return mat


class MatrixInterpolator:

    def __init__(self, x, mat, kind='cubic') -> None:

        # Output type
        dtype = type(interpolate.interp1d([0, 1], [0, 1]))

        # If the array is 3D, we assume n_freq x n x m
        if len(mat.shape) == 3:
            # Number of rows
            self.n = mat.shape[1]
            # Number of columns
            self.m = mat.shape[2]
            # Inteprolator matrix
            self.mat_real = np.empty((self.n, self.m), dtype=dtype)
            self.mat_imag = np.empty((self.n, self.m), dtype=dtype)
            # Diagonal elements
            for i in range(self.n):
                for j in range(self.m):
                    self.mat_real[i, j] = interpolate.interp1d(x, mat.real[:, i, j],
                                                               kind=kind,
                                                               fill_value="extrapolate")
                    self.mat_imag[i, j] = interpolate.interp1d(x, mat.imag[:, i, j],
                                                               kind=kind,
                                                               fill_value="extrapolate")

        else:
            raise ValueError("The array provided should have 3 dimensions.")

    def __call__(self, x_new):

        mat = np.zeros((len(x_new), self.n, self.m), dtype=complex)

        for i in range(self.n):
            for j in range(self.m):
                mat[:, i, j] = self.mat_real[i, j](
                    x_new) + 1j * self.mat_imag[i, j](x_new)

        return mat


def hypertriangulate(x, bounds=(0, 1)):
    """
    Transform a vector of numbers from a cube to a hypertriangle.
    The hypercube is the space the samplers work in, and the hypertriangle is
    the physical space where the components of x are ordered such that
    x0 < x1 < ... < xn. The (unit) transformation is defined by:
    .. math::
        X_j = 1 - \\prod_{i=0}^{j} (1 - x_i)^{1/(K-i)}
    Parameters
    ----------
    x: array
        The hypercube parameter values
    bounds: tuple
        Lower and upper bounds of parameter space. Default is to transform
        between the unit hypercube and unit hypertriangle.
    Returns
    -------
    X: array
        The hypertriangle parameter values

    Reference
    ---------
    Riccardo Buscicchio et al, 10.5281/zenodo.3351629


    """

    # transform to the unit hypercube
    unit_x = (np.array(x) - bounds[0]) / (bounds[1] - bounds[0])

    # hypertriangle transformation
    with warnings.catch_warnings():
        # this specific warning is raised when unit_x goes outside [0, 1]
        warnings.filterwarnings('error', 'invalid value encountered in power')
        try:
            K = np.size(unit_x)
            index = np.arange(K)
            inner_term = np.power(1 - unit_x, 1/(K - index))
            unit_X = 1 - np.cumprod(inner_term)
        except RuntimeWarning as exc:
            raise ValueError('Values outside bounds passed to hypertriangulate') from exc

    # re-apply orginal scaling, offset
    X = bounds[0] + unit_X * (bounds[1] - bounds[0])

    return X


def hypertriangulate_reverse(X, bounds=(0, 1)):

    unit_X = (np.array(X) - bounds[0]) / (bounds[1] - bounds[0])

    K = np.size(unit_X)
    index = np.arange(K)

    unit_X_ext = np.concatenate([[0], unit_X])

    unit_x = 1 - np.power(1 - unit_X_ext[0:-1], -(K - index)) * \
        np.power(1 - unit_X_ext[1:], (K - index))

    x = bounds[0] + unit_x * (bounds[1] - bounds[0])

    return x


def compute_log_evidence(logpvals, beta_ladder):
    """

    Parameters
    ----------
    logpvals : numpy array
        ntemps x nsamples matrix containing all the samples at different temperatures.
        from temperature T=1 to temperature T=inf  (beta = 1 to beta=0)
    beta_ladder : numpy array
        inverse temperature ladder


    Returns
    -------
    loge: scalar float
        logarithm of the evidence
    loge_std : scalar float
        estimated standard deviation of the log-evidence


    References
    ----------
    Lartillot, Nicolas and Philippe, Herve, Computing Bayes Factors Using Thermodynamic Integration,
    2006


    """

    # Sample average of log(p|theta)
    eu = np.mean(logpvals, axis=1)
    # Number of samples
    n_samples = logpvals.shape[1]
    # Sample variance of log(p|theta)
    vu = np.var(logpvals, axis=1)/n_samples

    # Integral over beta
    beta_max = np.max(beta_ladder)
    beta_min = np.min(beta_ladder)
    ntemps = len(beta_ladder)
    loge_std = (beta_max - beta_min) / ntemps * np.sqrt(np.sum(vu))
    loge = integrate.simps(eu[::-1], beta_ladder[::-1])

    return loge, loge_std


def initialize_params(config, initialize_single_param, **kwargs):
    """Initialize sampler parameter state

    Parameters
    ----------
    config : _type_
        _description_
    initialize_single_param : callable
        function that initializes one parameter instance


    """

    if config["sampler"].get("Sampler") == 'ptemcee':

        ntemps = config["sampler"].getint("Temperatures")
        nwalkers = config["sampler"].getint("Walkers")
        # Intialize the parameter state
        p0 = np.array([[initialize_single_param(**kwargs)
                        for j in range(nwalkers)]
                       for i in range(ntemps)])

    elif config["sampler"].get("Sampler") == 'ptmcmc':
        # Intialize the parameter state
        p0 = initialize_single_param()

    return p0


def reorganise(freqs, eigenvalues, eigenvectors, sep=6e-2):
    """
    Re-order the frequency-dependent eigenvalues to ensure continuity.
    TODO: needs extension to handle any possible case.

    Parameters
    ----------
    freqs : ndarray
        frequency vector, size nf
    eigenvalues : ndarray
        eigenvalues array, size nf x nv
    eigenvectors : ndarray
        eigenvector matrix series, size nf x nv x nv
    sep : float
        frequency after which re-ordering is needed again.
        the code will try to find two discontinuities: one before sep, 
        and one after sep.

    Returns
    -------
    i_min_1 : int
        Frequency index of first discontinuity
    i_min_2 : int
        Frequency index of second discontinuity
    eigenvalues_new : ndarray
        Re-ordered eigenvalues
    eigenvectors_new : ndarray
        Re-ordered eigenvectors

    """
    # Get the index of the separation frequency
    i_sep = np.argmin(np.abs(freqs - sep))
    eigenvalues_new = np.copy(eigenvalues)
    eigenvectors_new = np.copy(eigenvectors)
    # Compute the difference between eigenvalues
    diff = eigenvalues[:, 0].real - eigenvalues[:, 3].real
    # Locate the turning points (index of the difference before it reaches zero)
    i_min_1 = np.argmin(diff[0:i_sep])
    i_min_2 = i_sep + np.argmin(diff[i_sep:])
    # Now flip the roles in-between
    for i in range(3):
        eigenvalues_new[i_min_1:i_min_2, i] = eigenvalues[i_min_1:i_min_2, i+3]
        eigenvalues_new[i_min_1:i_min_2, i+3] = eigenvalues[i_min_1:i_min_2, i]

        eigenvectors_new[i_min_1:i_min_2, :,
                         i] = eigenvectors[i_min_1:i_min_2, :, i+3]
        eigenvectors_new[i_min_1:i_min_2, :, i +
                         3] = eigenvectors[i_min_1:i_min_2, :, i]

    return i_min_1, i_min_2, eigenvalues_new, eigenvectors_new


def reformat_chains(chains, keep):
    """Flatten MCMC chains from ptemcee.

    Parameters
    ----------
    chains : ndarray
        parameter sample chains, 
        size ntemps x nwalkers x nstep x ndim
    keep : int
        number of steps to keep in the falattened chain

    Returns
    -------
    ndarray
        flattened chain, size nwalkers*keep x ndim
    """

    _, nwalkers, _, ndim = np.shape(chains)

    chains_reshaped = np.reshape(chains[0, :, -keep:, :],
                                 (nwalkers*keep, ndim))

    return chains_reshaped


# LISA GW Response functions
def dot(a: ArrayLike, b: ArrayLike) -> np.ndarray:
    """Dot product on the last axis.

    Args:
        a: Input array.
        b: Input array.
    """
    a = np.asanyarray(a)
    b = np.asanyarray(b)
    return np.einsum("...j, ...j", a, b)


def norm(a: ArrayLike) -> Any:
    """Norm on the last axis.

    Args:
        a: Input array.
    """
    return np.linalg.norm(a, axis=-1)


def arrayindex(x: ArrayLike, a: ArrayLike) -> np.ndarray:
    """Return the array indices for ``x`` in ``a``.

    >>> a = [1, 3, 5, 7]
    >>> arrayindex([3, 7, 1], a)
    array([1, 3, 0])

    Args:
        x: Elements to search for, of shape ``(N,)``.
        a: Array in which elements are searched for.

    Returns:
        Indices of elements in ``a``, of shape ``(N,)``.

    Raises:
        ValueError: If not all elements of ``x`` cannot be found in ``a``.
    """
    if not np.all(np.isin(x, a)):
        raise ValueError("cannot find all items")
    return np.searchsorted(a, x)


def bspline_interp(
    t: ArrayLike, data: ArrayLike, k: int = 5, ext: str = "zeros"
) -> Callable[[ArrayLike], np.ndarray]:
    """Compute B-spline interpolants with control over extrapolation mode.

    Parameters
    ----------
    t : Array-like of shape (N,)
        Time coordinates between which to interpolate.
    data : Array-like of shape (N,)
        Data samples to interpolate (the spline interpolant will pass through
        those points).
    k : int
        Degree of the spline.
    ext : str, 'zeros' or 'raise'
        Controls the extrapolation mode for elements not in the interval
        defined by ``t``. If set to 'zeros', return 0. If set to 'raise',
        raise a ValueError.

    Returns
    -------
    Callable
        Spline interpolant as a callable object.

    Raises
    ------
    ValueError
        If the ``t`` and ``data`` sizes are not the same.
        If the ``ext`` parameter is not 'zeros' or 'raise'.
    """
    t = np.asanyarray(t)
    data = np.asanyarray(data)

    if t.size != data.size:
        raise ValueError("time and data sizes must be the same")

    scipy_interp = make_interp_spline(t, data, k=k)

    # Builds the interpolant function wth zero padding
    def interp_zeros(x: ArrayLike) -> np.ndarray:
        x = np.asarray(x)
        y = np.zeros_like(x)
        int_indices = np.logical_and(x >= t[0], x <= t[-1])
        y[int_indices] = scipy_interp(x[int_indices])
        return y

    # Builds the interpolant function with exception raising
    def interp_raise(x: ArrayLike) -> np.ndarray:
        x = np.asarray(x)
        if np.any(x < t[0]) or np.any(x > t[-1]):
            out_of_bound = x[(x < t[0]) | (x > t[-1])][0]
            raise ValueError(
                f"Interpolated times out of the allowed time range [{t[0]}, {t[-1]}] "
                f"(for example, {out_of_bound} is outside the range). Use ext='zeros' "
                "to get 0 for out-of-range values."
            )
        return scipy_interp(x)

    if ext == "zeros":
        return interp_zeros
    if ext == "raise":
        return interp_raise

    raise ValueError(
        f"Invalid option for 'ext': got '{ext}', expected 'zeros' or 'raise'."
    )
