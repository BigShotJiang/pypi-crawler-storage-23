from dep_orbits import lib

def main():
    lib.main()
