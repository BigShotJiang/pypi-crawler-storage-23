# Trunkate AI Python SDK

The official Trunkate AI Python SDK provides synchronous bindings for Python 3.9+. It utilizes `httpx` internally for lightning-fast networking.

## Installation

```bash
pip install trunkate-ai
```

## Setup & Configuration

The SDK automatically reads the `TRUNKATE_API_KEY` from your environment.

```python
import os
from trunkate_ai import Trunkate

# Initializes using os.environ.get("TRUNKATE_API_KEY")
client = Trunkate()

# Alternatively, pass it explicitly:
# client = Trunkate(api_key="tk_live_...")
```

## Usage

```python
# 1. Define your long prompt
prompt = "Your very long context..."

# 2. Optimize the prompt for a specific task
optimized = client.optimize(
    text=prompt,
    task="Summarize this document",
    budget=500,
    model="gpt-4o"
)

print(f"Reduced token count by {optimized.stats.reduction_percent}%")
```

## Parameters

| Parameter | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `text` | `str` | Yes | The raw, unoptimized prompt. |
| `task` | `str` | No | Instructions on what the LLM should do with the prompt. |
| `budget` | `int` | No | Target maximum token count (default: varies by model). |
| `model` | `str` | No | The target LLM (default: `gpt-4o`). |
 
