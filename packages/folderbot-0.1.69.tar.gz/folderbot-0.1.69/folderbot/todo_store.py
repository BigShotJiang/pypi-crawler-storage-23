"""SQLite-backed todo storage for procrastinator-friendly task management."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import builtins
from typing import Any

# Alias to avoid shadowing by TodoStore.list method
_list = builtins.list

EFFORT_LEVELS = ("tiny", "small", "medium", "large", "epic")
STATUSES = ("todo", "in_progress", "done")


@dataclass(frozen=True)
class TodoItem:
    """A single todo item."""

    id: int
    user_id: int
    title: str
    description: str
    status: str  # "todo", "in_progress", "done"
    effort: str  # "tiny", "small", "medium", "large", "epic"
    tags: list[str]
    created_at: str
    updated_at: str
    completed_at: str | None


class TodoStore:
    """SQLite storage for todo items."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        """Create the todos table if it doesn't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS todos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'todo',
                    effort TEXT NOT NULL DEFAULT 'medium',
                    tags TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_todos_user_status
                ON todos (user_id, status)
            """)
            conn.commit()

    def _get_connection(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    @staticmethod
    def _row_to_item(row: tuple) -> TodoItem:
        return TodoItem(
            id=row[0],
            user_id=row[1],
            title=row[2],
            description=row[3],
            status=row[4],
            effort=row[5],
            tags=json.loads(row[6]),
            created_at=row[7],
            updated_at=row[8],
            completed_at=row[9],
        )

    def add(
        self,
        user_id: int,
        title: str,
        description: str = "",
        effort: str = "medium",
        tags: _list[str] | None = None,
    ) -> TodoItem:
        """Add a new todo item.

        Args:
            user_id: Owner of the todo.
            title: Short title for the task.
            description: Optional longer description.
            effort: Effort level (tiny/small/medium/large/epic).
            tags: Optional list of tags for categorization.

        Returns:
            The created TodoItem.

        Raises:
            ValueError: If effort is not a valid level.
        """
        if effort not in EFFORT_LEVELS:
            raise ValueError(
                f"Invalid effort '{effort}'. Must be one of: {', '.join(EFFORT_LEVELS)}"
            )
        now = datetime.now().isoformat()
        tags_json = json.dumps(tags or [])
        with self._get_connection() as conn:
            cursor = conn.execute(
                """INSERT INTO todos
                   (user_id, title, description, effort, tags, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (user_id, title, description, effort, tags_json, now, now),
            )
            conn.commit()
            assert cursor.lastrowid is not None
            return TodoItem(
                id=cursor.lastrowid,
                user_id=user_id,
                title=title,
                description=description,
                status="todo",
                effort=effort,
                tags=tags or [],
                created_at=now,
                updated_at=now,
                completed_at=None,
            )

    def get(self, todo_id: int, user_id: int) -> TodoItem | None:
        """Get a single todo by ID, scoped to a user."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT id, user_id, title, description, status, effort, "
                "tags, created_at, updated_at, completed_at "
                "FROM todos WHERE id = ? AND user_id = ?",
                (todo_id, user_id),
            )
            row = cursor.fetchone()
            return self._row_to_item(row) if row else None

    def list(
        self,
        user_id: int,
        status: str | None = None,
        max_effort: str | None = None,
        tag: str | None = None,
        search: str | None = None,
        include_done: bool = False,
    ) -> _list[TodoItem]:
        """List todos with optional filters.

        Args:
            user_id: Owner of the todos.
            status: Filter by exact status (overrides include_done).
            max_effort: Maximum effort level (includes all levels up to this).
            tag: Filter by tag (item must contain this tag).
            search: Search in title and description (case-insensitive).
            include_done: If False (default), exclude done items.

        Returns:
            List of matching TodoItems, ordered by created_at.
        """
        conditions = ["user_id = ?"]
        params: _list[Any] = [user_id]

        if status is not None:
            conditions.append("status = ?")
            params.append(status)
        elif not include_done:
            conditions.append("status != 'done'")

        if max_effort is not None:
            idx = EFFORT_LEVELS.index(max_effort)
            allowed = EFFORT_LEVELS[: idx + 1]
            placeholders = ", ".join("?" for _ in allowed)
            conditions.append(f"effort IN ({placeholders})")
            params.extend(allowed)

        if search is not None:
            conditions.append(
                "(title LIKE ? COLLATE NOCASE OR description LIKE ? COLLATE NOCASE)"
            )
            pattern = f"%{search}%"
            params.extend([pattern, pattern])

        where = " AND ".join(conditions)
        query = (
            f"SELECT id, user_id, title, description, status, effort, "
            f"tags, created_at, updated_at, completed_at "
            f"FROM todos WHERE {where} ORDER BY created_at"
        )

        with self._get_connection() as conn:
            cursor = conn.execute(query, params)
            items = [self._row_to_item(row) for row in cursor.fetchall()]

        # Filter by tag in Python (JSON column)
        if tag is not None:
            items = [i for i in items if tag in i.tags]

        return items

    def update(
        self,
        todo_id: int,
        user_id: int,
        title: str | None = None,
        description: str | None = None,
        status: str | None = None,
        effort: str | None = None,
        tags: _list[str] | None = None,
    ) -> TodoItem | None:
        """Update a todo item.

        Args:
            todo_id: ID of the todo to update.
            user_id: Owner of the todo (for scoping).
            title: New title (if provided).
            description: New description (if provided).
            status: New status (if provided).
            effort: New effort level (if provided).
            tags: New tags list (if provided).

        Returns:
            The updated TodoItem, or None if not found.

        Raises:
            ValueError: If status or effort is invalid.
        """
        if status is not None and status not in STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. Must be one of: {', '.join(STATUSES)}"
            )
        if effort is not None and effort not in EFFORT_LEVELS:
            raise ValueError(
                f"Invalid effort '{effort}'. Must be one of: {', '.join(EFFORT_LEVELS)}"
            )

        existing = self.get(todo_id, user_id)
        if existing is None:
            return None

        now = datetime.now().isoformat()
        sets: _list[str] = ["updated_at = ?"]
        params: _list[Any] = [now]

        if title is not None:
            sets.append("title = ?")
            params.append(title)
        if description is not None:
            sets.append("description = ?")
            params.append(description)
        if effort is not None:
            sets.append("effort = ?")
            params.append(effort)
        if tags is not None:
            sets.append("tags = ?")
            params.append(json.dumps(tags))
        if status is not None:
            sets.append("status = ?")
            params.append(status)
            if status == "done":
                sets.append("completed_at = ?")
                params.append(now)
            else:
                sets.append("completed_at = NULL")

        set_clause = ", ".join(sets)
        params.extend([todo_id, user_id])

        with self._get_connection() as conn:
            conn.execute(
                f"UPDATE todos SET {set_clause} WHERE id = ? AND user_id = ?",
                params,
            )
            conn.commit()

        return self.get(todo_id, user_id)

    def remove(self, todo_id: int, user_id: int) -> bool:
        """Remove a todo item. Returns True if deleted."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "DELETE FROM todos WHERE id = ? AND user_id = ?",
                (todo_id, user_id),
            )
            conn.commit()
            return cursor.rowcount > 0

    def stats(self, user_id: int) -> dict[str, int]:
        """Get counts by status for a user."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT status, COUNT(*) FROM todos WHERE user_id = ? GROUP BY status",
                (user_id,),
            )
            counts = {s: 0 for s in STATUSES}
            for row in cursor.fetchall():
                counts[row[0]] = row[1]
            counts["total"] = sum(counts.values())
            return counts
