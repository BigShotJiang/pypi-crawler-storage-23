"""Web tools for searching and fetching content from the web."""

from typing import Any

from .base import ToolResult
from .registry import folder_bot
from .web_fetch import WebFetchRequest, is_available as fetch_available, web_fetch
from .web_search import WebSearchRequest, is_available as search_available, web_search

# Re-export for backward compatibility
WebSearchInput = WebSearchRequest
WebFetchInput = WebFetchRequest

__all__ = [
    "WebFetchInput",
    "WebFetchRequest",
    "WebSearchInput",
    "WebSearchRequest",
    "WebTools",
    "web_fetch",
    "web_search",
]


class WebTools:
    """Tools for web search and content fetching (legacy interface)."""

    def __init__(self) -> None:
        self._search_available = search_available()
        self._fetch_available = fetch_available()

    def is_available(self) -> bool:
        """Check if any web tools are available."""
        return self._search_available or self._fetch_available

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """Get tool definitions for available web tools."""
        definitions = []
        if self._search_available:
            tool = folder_bot.get_tool("web_search")
            if tool:
                definitions.append(tool.get_schema())
        if self._fetch_available:
            tool = folder_bot.get_tool("web_fetch")
            if tool:
                definitions.append(tool.get_schema())
        return definitions

    async def execute(
        self, tool_name: str, tool_input: dict[str, Any]
    ) -> ToolResult | None:
        """Execute a web tool. Returns None if tool not found."""
        if tool_name == "web_search" and self._search_available:
            return await folder_bot.execute_tool(tool_name, tool_input)
        if tool_name == "web_fetch" and self._fetch_available:
            return await folder_bot.execute_tool(tool_name, tool_input)
        return None
