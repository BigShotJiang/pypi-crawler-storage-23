"""Backward-compat: renamed to llm_client.py.

All functionality has been moved to folderbot.llm_client.
"""

from .llm_client import LLMClient as ClaudeClient  # noqa: F401
from .llm_client import trim_history_to_budget  # noqa: F401
