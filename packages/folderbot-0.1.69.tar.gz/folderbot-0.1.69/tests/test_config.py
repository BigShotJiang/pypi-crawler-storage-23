"""Tests for configuration loading."""

from pathlib import Path

import pytest
import tomlkit

from folderbot.config import Config, ReadRules, find_config_path, migrate_yaml_to_toml


class TestReadRules:
    def test_default_values(self):
        rules = ReadRules()
        assert "**/*.md" in rules.include
        assert "**/*.txt" in rules.include
        assert ".git/**" in rules.exclude

    def test_default_append_allowed_no_logs(self):
        """Default append_allowed should not include logs/*.md."""
        rules = ReadRules()
        assert "logs/*.md" not in rules.append_allowed
        assert "**/todo.md" in rules.append_allowed
        assert "**/todos.md" in rules.append_allowed

    def test_custom_values(self):
        rules = ReadRules(include=["*.py"], exclude=["test_*"])
        assert rules.include == ["*.py"]
        assert rules.exclude == ["test_*"]


class TestConfig:
    def test_load_from_toml(self, tmp_path: Path):
        config_data = {
            "telegram_token": "test_token_123",
            "api_key": "test_api_key_456",
            "allowed_user_ids": [12345],
            "root_folder": str(tmp_path),
        }

        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.telegram_token == "test_token_123"
        assert config.api_key == "test_api_key_456"
        assert config.allowed_user_ids == [12345]
        assert config.root_folder == tmp_path

    def test_load_from_env_vars(self, tmp_path: Path, monkeypatch):
        # Create minimal config file
        config_data = {"allowed_user_ids": [99999]}
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        # Set env vars
        monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "env_token")
        monkeypatch.setenv("FOLDERBOT_API_KEY", "env_api_key")

        config = Config.load(config_file)

        assert config.telegram_token == "env_token"
        assert config.api_key == "env_api_key"

    def test_env_vars_override_yaml(self, tmp_path: Path, monkeypatch):
        config_data = {
            "telegram_token": "yaml_token",
            "api_key": "yaml_api_key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "env_token")

        config = Config.load(config_file)

        # Env var overrides yaml
        assert config.telegram_token == "env_token"
        # Yaml value used when no env var
        assert config.api_key == "yaml_api_key"

    def test_missing_telegram_token_raises(self, tmp_path: Path):
        config_data = {
            "api_key": "test_key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        with pytest.raises(ValueError, match="TELEGRAM_BOT_TOKEN"):
            Config.load(config_file)

    def test_missing_api_key_defaults_to_empty(self, tmp_path: Path):
        """api_key is optional — instructor will try the provider's env var."""
        config_data = {
            "telegram_token": "test_token",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)
        assert config.api_key == ""

    def test_provider_specific_api_key_anthropic(self, tmp_path: Path):
        """anthropic_api_key should be loaded for anthropic/ models."""
        config_data = {
            "telegram_token": "test_token",
            "anthropic_api_key": "ant-key-123",
            "allowed_user_ids": [12345],
            "model": "anthropic/claude-sonnet-4-20250514",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)
        assert config.api_key == "ant-key-123"

    def test_provider_specific_api_key_openai(self, tmp_path: Path):
        """openai_api_key should be loaded for openai/ models."""
        config_data = {
            "telegram_token": "test_token",
            "openai_api_key": "sk-openai-123",
            "allowed_user_ids": [12345],
            "model": "openai/gpt-4o",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)
        assert config.api_key == "sk-openai-123"

    def test_provider_specific_api_key_groq(self, tmp_path: Path):
        """groq_api_key should be loaded for groq/ models."""
        config_data = {
            "telegram_token": "test_token",
            "groq_api_key": "groq-key-123",
            "allowed_user_ids": [12345],
            "model": "groq/llama-3.1-70b",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)
        assert config.api_key == "groq-key-123"

    def test_generic_api_key_still_works(self, tmp_path: Path):
        """Generic api_key field should work as fallback."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "generic-key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)
        assert config.api_key == "generic-key"

    def test_folderbot_api_key_env_var(self, tmp_path: Path, monkeypatch):
        """FOLDERBOT_API_KEY env var should be picked up."""
        config_data = {
            "telegram_token": "test_token",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        monkeypatch.setenv("FOLDERBOT_API_KEY", "fb-key-123")
        config = Config.load(config_file)
        assert config.api_key == "fb-key-123"

    def test_env_var_overrides_yaml_key(self, tmp_path: Path, monkeypatch):
        """FOLDERBOT_API_KEY env var takes priority over YAML key."""
        config_data = {
            "telegram_token": "test_token",
            "anthropic_api_key": "yaml-key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        monkeypatch.setenv("FOLDERBOT_API_KEY", "env-key")
        config = Config.load(config_file)
        assert config.api_key == "env-key"

    def test_missing_allowed_user_ids_raises(self, tmp_path: Path):
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        with pytest.raises(ValueError, match="allowed_user_ids"):
            Config.load(config_file)

    def test_custom_read_rules(self, tmp_path: Path):
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "read_rules": {
                "include": ["*.py", "*.md"],
                "exclude": ["__pycache__/**"],
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.read_rules.include == ["*.py", "*.md"]
        assert config.read_rules.exclude == ["__pycache__/**"]

    def test_default_model(self, tmp_path: Path):
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.model == "anthropic/claude-sonnet-4-20250514"

    def test_custom_model(self, tmp_path: Path):
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "model": "claude-3-haiku-20240307",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.model == "claude-3-haiku-20240307"

    def test_root_folder_defaults_to_cwd(self, tmp_path: Path, monkeypatch):
        """When root_folder is not specified, it should default to cwd, not site-packages."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            # No root_folder specified
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        # Change to tmp_path to simulate user's working directory
        monkeypatch.chdir(tmp_path)

        config = Config.load(config_file)

        # Should be cwd, not some path inside site-packages
        assert config.root_folder == tmp_path
        assert "site-packages" not in str(config.root_folder)

    def test_root_folder_from_config(self, tmp_path: Path):
        """When root_folder is specified in config, it should be used."""
        target_folder = tmp_path / "my_folder"
        target_folder.mkdir()

        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "root_folder": str(target_folder),
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.root_folder == target_folder

    def test_root_folder_from_env_var(self, tmp_path: Path, monkeypatch):
        """SELF_BOT_ROOT env var should override config file."""
        config_folder = tmp_path / "config_folder"
        config_folder.mkdir()
        env_folder = tmp_path / "env_folder"
        env_folder.mkdir()

        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "root_folder": str(config_folder),
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        monkeypatch.setenv("SELF_BOT_ROOT", str(env_folder))

        config = Config.load(config_file)

        # Env var should override config file
        assert config.root_folder == env_folder

    def test_root_folder_expands_tilde(self, tmp_path: Path, monkeypatch):
        """root_folder should expand ~ to home directory."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "root_folder": "~/some_folder",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        # Should expand ~ to actual home path
        assert "~" not in str(config.root_folder)
        assert str(Path.home()) in str(config.root_folder)

    def test_user_name_default(self, tmp_path: Path):
        """user_name should default to 'User'."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.user_name == "User"

    def test_user_name_from_config(self, tmp_path: Path):
        """user_name should be loaded from config."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "user_name": "Alice",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.user_name == "Alice"

    def test_whisper_model_default(self, tmp_path: Path):
        """whisper_model should default to 'base' when not configured."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.whisper_model == "base"

    def test_whisper_model_from_config(self, tmp_path: Path):
        """whisper_model should be loaded from config."""
        config_data = {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "whisper_model": "small",
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.whisper_model == "small"


class TestMultiBotConfig:
    """Tests for global + per-bot configuration structure."""

    def test_load_bot_with_global_anthropic_key(self, tmp_path: Path):
        """Global api_key should be used when loading a specific bot."""
        work_folder = tmp_path / "work"
        work_folder.mkdir()

        config_data = {
            "api_key": "global_api_key",
            "bots": {
                "work": {
                    "telegram_token": "work_bot_token",
                    "root_folder": str(work_folder),
                    "allowed_user_ids": [123],
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file, bot_name="work")

        assert config.api_key == "global_api_key"
        assert config.telegram_token == "work_bot_token"
        assert config.root_folder == work_folder
        assert config.allowed_user_ids == [123]

    def test_load_multiple_bots(self, tmp_path: Path):
        """Should be able to load different bots from the same config."""
        work_folder = tmp_path / "work"
        work_folder.mkdir()
        personal_folder = tmp_path / "personal"
        personal_folder.mkdir()

        config_data = {
            "api_key": "shared_api_key",
            "bots": {
                "work": {
                    "telegram_token": "work_token",
                    "root_folder": str(work_folder),
                    "allowed_user_ids": [111],
                },
                "personal": {
                    "telegram_token": "personal_token",
                    "root_folder": str(personal_folder),
                    "allowed_user_ids": [222],
                },
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        work_config = Config.load(config_file, bot_name="work")
        personal_config = Config.load(config_file, bot_name="personal")

        assert work_config.telegram_token == "work_token"
        assert work_config.root_folder == work_folder

        assert personal_config.telegram_token == "personal_token"
        assert personal_config.root_folder == personal_folder

        # Both should share the same API key
        assert work_config.api_key == "shared_api_key"
        assert personal_config.api_key == "shared_api_key"

    def test_bot_can_override_global_settings(self, tmp_path: Path):
        """Bot-specific settings should override global defaults."""
        folder = tmp_path / "notes"
        folder.mkdir()

        config_data = {
            "api_key": "global_key",
            "model": "claude-sonnet-4-20250514",  # Global default
            "bots": {
                "work": {
                    "telegram_token": "token",
                    "root_folder": str(folder),
                    "allowed_user_ids": [123],
                    "model": "claude-3-haiku-20240307",  # Bot-specific override
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file, bot_name="work")

        assert config.model == "claude-3-haiku-20240307"

    def test_backward_compatible_with_flat_config(self, tmp_path: Path):
        """Old flat config format should still work (no bot_name needed)."""
        config_data = {
            "telegram_token": "flat_token",
            "api_key": "flat_key",
            "allowed_user_ids": [123],
            "root_folder": str(tmp_path),
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        # Should work without specifying bot_name
        config = Config.load(config_file)

        assert config.telegram_token == "flat_token"
        assert config.api_key == "flat_key"

    def test_error_when_bot_not_found(self, tmp_path: Path):
        """Should raise error when specified bot doesn't exist."""
        config_data = {
            "api_key": "key",
            "bots": {
                "work": {
                    "telegram_token": "token",
                    "root_folder": str(tmp_path),
                    "allowed_user_ids": [123],
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        with pytest.raises(ValueError, match="Bot 'nonexistent' not found"):
            Config.load(config_file, bot_name="nonexistent")

    def test_error_when_bots_config_but_no_bot_name(self, tmp_path: Path):
        """Should raise helpful error when config has multiple bots but no bot_name specified."""
        config_data = {
            "api_key": "key",
            "bots": {
                "work": {
                    "telegram_token": "token1",
                    "root_folder": str(tmp_path),
                    "allowed_user_ids": [123],
                },
                "personal": {
                    "telegram_token": "token2",
                    "root_folder": str(tmp_path),
                    "allowed_user_ids": [456],
                },
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        with pytest.raises(ValueError, match="specify which bot"):
            Config.load(config_file)

    def test_single_bot_loads_automatically(self, tmp_path: Path):
        """When there's only one bot, it should load automatically without bot_name."""
        folder = tmp_path / "notes"
        folder.mkdir()

        config_data = {
            "api_key": "key",
            "bots": {
                "default": {
                    "telegram_token": "token",
                    "root_folder": str(folder),
                    "allowed_user_ids": [123],
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))

        # Should auto-select the only bot
        config = Config.load(config_file)

        assert config.telegram_token == "token"
        assert config.root_folder == folder


class TestFindConfigPath:
    """Tests for config path resolution."""

    def test_finds_local_config_in_cwd(self, tmp_path: Path):
        """Should find .folderbot/config.toml in the given directory."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_file.write_text('telegram_token = "test"\n')

        result = find_config_path(start_dir=tmp_path)
        assert result == config_file

    def test_returns_local_path_when_nothing_exists(self, tmp_path: Path):
        """When no config exists, returns .folderbot/config.toml in start_dir."""
        result = find_config_path(start_dir=tmp_path)
        assert result == tmp_path / ".folderbot" / "config.toml"

    def test_defaults_to_cwd(self, tmp_path: Path, monkeypatch):
        """When start_dir is None, uses Path.cwd()."""
        monkeypatch.chdir(tmp_path)

        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_file.write_text('telegram_token = "test"\n')

        result = find_config_path()
        assert result == config_file

    def test_nonexistent_defaults_to_cwd(self, tmp_path: Path, monkeypatch):
        """When nothing exists and start_dir is None, returns PWD/.folderbot/config.toml."""
        monkeypatch.chdir(tmp_path)

        result = find_config_path()
        assert result == tmp_path / ".folderbot" / "config.toml"


class TestYamlToTomlMigration:
    """Tests for automatic YAML → TOML config migration."""

    def test_migrate_simple_yaml(self, tmp_path: Path):
        """Should convert a simple YAML config to TOML."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        yaml_file = dotfolder / "config.yaml"
        yaml_file.write_text(
            'telegram_token: "test_token"\n'
            "allowed_user_ids:\n"
            "  - 12345\n"
            'model: "anthropic/claude-sonnet-4-20250514"\n'
        )

        result = migrate_yaml_to_toml(yaml_file)

        assert result is not None
        toml_file = dotfolder / "config.toml"
        assert toml_file.exists()
        assert not yaml_file.exists()  # Original should be removed
        # Verify TOML content is valid
        config = Config.load(toml_file)
        assert config.telegram_token == "test_token"
        assert config.allowed_user_ids == [12345]

    def test_migrate_yaml_with_nested_sections(self, tmp_path: Path):
        """Should convert YAML with nested dicts to TOML tables."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        yaml_file = dotfolder / "config.yaml"
        yaml_file.write_text(
            'telegram_token: "tok"\n'
            "allowed_user_ids:\n"
            "  - 999\n"
            "read_rules:\n"
            '  include:\n    - "**/*.md"\n'
            '  exclude:\n    - ".git/**"\n'
        )

        result = migrate_yaml_to_toml(yaml_file)

        assert result is not None
        config = Config.load(result)
        assert config.read_rules.include == ["**/*.md"]
        assert config.read_rules.exclude == [".git/**"]

    def test_migrate_skipped_when_toml_exists(self, tmp_path: Path):
        """Should not migrate if config.toml already exists."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        yaml_file = dotfolder / "config.yaml"
        yaml_file.write_text('telegram_token: "old"\n')
        toml_file = dotfolder / "config.toml"
        toml_file.write_text('telegram_token = "new"\n')

        result = migrate_yaml_to_toml(yaml_file)

        assert result is None  # No migration needed
        assert yaml_file.exists()  # YAML not deleted
        # TOML should be unchanged
        assert 'telegram_token = "new"' in toml_file.read_text()

    def test_migrate_returns_none_when_no_yaml(self, tmp_path: Path):
        """Should return None when YAML file doesn't exist."""
        yaml_file = tmp_path / ".folderbot" / "config.yaml"
        result = migrate_yaml_to_toml(yaml_file)
        assert result is None

    def test_find_config_path_triggers_migration(self, tmp_path: Path):
        """find_config_path should auto-migrate YAML to TOML."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        yaml_file = dotfolder / "config.yaml"
        yaml_file.write_text('telegram_token: "migrated"\nallowed_user_ids:\n  - 42\n')

        result = find_config_path(start_dir=tmp_path)

        assert result == dotfolder / "config.toml"
        assert result.exists()
        assert not yaml_file.exists()
        # Verify it loads correctly
        config = Config.load(result)
        assert config.telegram_token == "migrated"

    def test_find_config_path_prefers_existing_toml(self, tmp_path: Path):
        """find_config_path should prefer existing TOML over YAML migration."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        (dotfolder / "config.yaml").write_text('telegram_token: "yaml"\n')
        (dotfolder / "config.toml").write_text('telegram_token = "toml"\n')

        result = find_config_path(start_dir=tmp_path)

        assert result == dotfolder / "config.toml"
        # YAML should still exist (not deleted when TOML already exists)
        assert (dotfolder / "config.yaml").exists()


class TestLocalConfig:
    """Tests for loading config from .folderbot/config.toml."""

    def test_load_from_local_config(self, tmp_path: Path):
        """Config.load() should work with .folderbot/config.toml."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_data = {
            "telegram_token": "local_token",
            "api_key": "local_key",
            "allowed_user_ids": [12345],
        }
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.telegram_token == "local_token"
        # root_folder should be the parent of .folderbot/
        assert config.root_folder == tmp_path

    def test_local_config_root_folder_is_parent_of_dotfolder(self, tmp_path: Path):
        """When loading from .folderbot/config.toml, root_folder defaults to its parent."""
        notes = tmp_path / "my_notes"
        notes.mkdir()
        dotfolder = notes / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_data = {
            "telegram_token": "token",
            "api_key": "key",
            "allowed_user_ids": [123],
        }
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.root_folder == notes

    def test_local_config_explicit_root_folder_overrides(self, tmp_path: Path):
        """Explicit root_folder in local config should override the implicit parent."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        other_folder = tmp_path / "other"
        other_folder.mkdir()
        config_file = dotfolder / "config.toml"
        config_data = {
            "telegram_token": "token",
            "api_key": "key",
            "allowed_user_ids": [123],
            "root_folder": str(other_folder),
        }
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.root_folder == other_folder

    def test_local_config_db_path_relative_to_root(self, tmp_path: Path):
        """DB path should be relative to root_folder when using local config."""
        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_data = {
            "telegram_token": "token",
            "api_key": "key",
            "allowed_user_ids": [123],
        }
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load(config_file)

        assert config.db_path == tmp_path / ".folderbot" / "sessions.db"

    def test_load_without_explicit_path_finds_local(self, tmp_path: Path, monkeypatch):
        """Config.load() without config_path should find .folderbot/config.toml in PWD."""
        monkeypatch.chdir(tmp_path)

        dotfolder = tmp_path / ".folderbot"
        dotfolder.mkdir()
        config_file = dotfolder / "config.toml"
        config_data = {
            "telegram_token": "auto_found",
            "anthropic_api_key": "key",
            "allowed_user_ids": [999],
        }
        config_file.write_text(tomlkit.dumps(config_data))

        config = Config.load()

        assert config.telegram_token == "auto_found"
        assert config.root_folder == tmp_path


class TestToolsConfig:
    """Tests for [tools] config section."""

    def _make_config(self, tmp_path: Path, config_data: dict) -> Config:
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(config_data))
        return Config.load(config_file)

    def _base_config(self, tmp_path: Path) -> dict:
        return {
            "telegram_token": "test_token",
            "api_key": "test_key",
            "allowed_user_ids": [12345],
            "root_folder": str(tmp_path),
        }

    def test_tools_empty_by_default(self, tmp_path: Path):
        """tools dict should be empty when no [tools] section exists."""
        config = self._make_config(tmp_path, self._base_config(tmp_path))
        assert config.tools == {}

    def test_tools_section_parsed(self, tmp_path: Path):
        """[tools] section should be parsed into tools dict."""
        data = self._base_config(tmp_path)
        data["tools"] = {
            "web_search": {"google_api_key": "gk-123", "google_cx": "cx-456"},
            "whisper": {"model": "small"},
        }
        config = self._make_config(tmp_path, data)

        assert config.tools["web_search"]["google_api_key"] == "gk-123"
        assert config.tools["web_search"]["google_cx"] == "cx-456"
        assert config.tools["whisper"]["model"] == "small"

    def test_tools_web_search_populates_flat_fields(self, tmp_path: Path):
        """[tools.web_search] should populate flat google_api_key/google_cx fields."""
        data = self._base_config(tmp_path)
        data["tools"] = {
            "web_search": {"google_api_key": "gk-tools", "google_cx": "cx-tools"},
        }
        config = self._make_config(tmp_path, data)

        assert config.google_api_key == "gk-tools"
        assert config.google_cx == "cx-tools"

    def test_tools_web_search_overrides_flat_fields(self, tmp_path: Path):
        """[tools.web_search] should take priority over flat google_api_key/google_cx."""
        data = self._base_config(tmp_path)
        data["google_api_key"] = "flat-key"
        data["google_cx"] = "flat-cx"
        data["tools"] = {
            "web_search": {"google_api_key": "tools-key", "google_cx": "tools-cx"},
        }
        config = self._make_config(tmp_path, data)

        assert config.google_api_key == "tools-key"
        assert config.google_cx == "tools-cx"

    def test_flat_google_keys_still_work(self, tmp_path: Path):
        """Flat google_api_key/google_cx should still work without [tools] section."""
        data = self._base_config(tmp_path)
        data["google_api_key"] = "flat-key"
        data["google_cx"] = "flat-cx"
        config = self._make_config(tmp_path, data)

        assert config.google_api_key == "flat-key"
        assert config.google_cx == "flat-cx"

    def test_env_vars_override_tools_section(self, tmp_path: Path, monkeypatch):
        """Environment variables should override [tools.web_search] values."""
        data = self._base_config(tmp_path)
        data["tools"] = {
            "web_search": {"google_api_key": "tools-key", "google_cx": "tools-cx"},
        }
        monkeypatch.setenv("GOOGLE_API_KEY", "env-key")
        monkeypatch.setenv("GOOGLE_CX", "env-cx")
        config = self._make_config(tmp_path, data)

        assert config.google_api_key == "env-key"
        assert config.google_cx == "env-cx"

    def test_tools_whisper_populates_flat_field(self, tmp_path: Path):
        """[tools.whisper].model should populate flat whisper_model field."""
        data = self._base_config(tmp_path)
        data["tools"] = {"whisper": {"model": "large-v3"}}
        config = self._make_config(tmp_path, data)

        assert config.whisper_model == "large-v3"

    def test_tools_whisper_overrides_flat_field(self, tmp_path: Path):
        """[tools.whisper].model should take priority over flat whisper_model."""
        data = self._base_config(tmp_path)
        data["whisper_model"] = "base"
        data["tools"] = {"whisper": {"model": "small"}}
        config = self._make_config(tmp_path, data)

        assert config.whisper_model == "small"

    def test_tools_section_in_multi_bot_config(self, tmp_path: Path):
        """[tools] section should work in multi-bot configs."""
        folder = tmp_path / "work"
        folder.mkdir()
        data = {
            "api_key": "shared",
            "tools": {"web_search": {"google_api_key": "global-gk"}},
            "bots": {
                "work": {
                    "telegram_token": "work_token",
                    "root_folder": str(folder),
                    "allowed_user_ids": [123],
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(data))
        config = Config.load(config_file, bot_name="work")

        assert config.tools["web_search"]["google_api_key"] == "global-gk"
        assert config.google_api_key == "global-gk"

    def test_bot_tools_override_global_tools(self, tmp_path: Path):
        """Bot-specific [tools] should override global [tools]."""
        folder = tmp_path / "work"
        folder.mkdir()
        data = {
            "api_key": "shared",
            "tools": {
                "web_search": {"google_api_key": "global-gk", "google_cx": "global-cx"}
            },
            "bots": {
                "work": {
                    "telegram_token": "work_token",
                    "root_folder": str(folder),
                    "allowed_user_ids": [123],
                    "tools": {
                        "web_search": {
                            "google_api_key": "bot-gk",
                            "google_cx": "bot-cx",
                        }
                    },
                }
            },
        }
        config_file = tmp_path / "config.toml"
        config_file.write_text(tomlkit.dumps(data))
        config = Config.load(config_file, bot_name="work")

        assert config.tools["web_search"]["google_api_key"] == "bot-gk"
        assert config.google_api_key == "bot-gk"

    def test_arbitrary_tool_config(self, tmp_path: Path):
        """Any tool name should be storable in [tools] section."""
        data = self._base_config(tmp_path)
        data["tools"] = {
            "my_custom_tool": {"api_url": "https://example.com", "timeout": 30},
        }
        config = self._make_config(tmp_path, data)

        assert config.tools["my_custom_tool"]["api_url"] == "https://example.com"
        assert config.tools["my_custom_tool"]["timeout"] == 30
