"""Tests for file upload support."""

import hashlib
import sqlite3
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from folderbot.config import Config, ReadRules, WatchConfig
from folderbot.session_manager import SessionManager, UploadRecord
from folderbot.telegram_handler import TelegramBot
from folderbot.tools.upload_tools import UploadServices


@pytest.fixture
def session_manager(tmp_path: Path) -> SessionManager:
    db_path = tmp_path / "test_sessions.db"
    return SessionManager(db_path)


# --- UploadRecord ---


class TestUploadRecord:
    def test_frozen(self):
        record = UploadRecord(
            id=1,
            user_id=123,
            original_filename="test.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=1024,
            mime_type="application/pdf",
            created_at="2025-01-01T00:00:00",
        )
        with pytest.raises(AttributeError):
            record.file_size = 2048  # type: ignore


# --- SessionManager upload methods ---


class TestSessionManagerUploads:
    def test_uploads_table_created(self, tmp_path: Path):
        db_path = tmp_path / "test.db"
        SessionManager(db_path)
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='uploads'"
            )
            assert cursor.fetchone() is not None

    def test_save_upload(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=5000,
        )
        assert record.user_id == 12345
        assert record.original_filename == "report.pdf"
        assert record.hash_filename == "abc123"
        assert record.extension == ".pdf"
        assert record.file_size == 5000
        assert record.mime_type == "application/pdf"
        assert record.id is not None
        assert record.created_at is not None

    def test_save_upload_custom_mime_type(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="doc.pdf",
            hash_filename="xyz",
            extension=".pdf",
            file_size=100,
            mime_type="application/x-pdf",
        )
        assert record.mime_type == "application/x-pdf"

    def test_get_uploads_empty(self, session_manager: SessionManager):
        uploads = session_manager.get_uploads(user_id=12345)
        assert uploads == []

    def test_get_uploads_returns_records(self, session_manager: SessionManager):
        session_manager.save_upload(
            user_id=12345,
            original_filename="a.pdf",
            hash_filename="hash_a",
            extension=".pdf",
            file_size=100,
        )
        session_manager.save_upload(
            user_id=12345,
            original_filename="b.pdf",
            hash_filename="hash_b",
            extension=".pdf",
            file_size=200,
        )
        uploads = session_manager.get_uploads(user_id=12345)
        assert len(uploads) == 2

    def test_get_uploads_isolated_per_user(self, session_manager: SessionManager):
        session_manager.save_upload(
            user_id=111,
            original_filename="a.pdf",
            hash_filename="hash_a",
            extension=".pdf",
            file_size=100,
        )
        session_manager.save_upload(
            user_id=222,
            original_filename="b.pdf",
            hash_filename="hash_b",
            extension=".pdf",
            file_size=200,
        )
        assert len(session_manager.get_uploads(111)) == 1
        assert len(session_manager.get_uploads(222)) == 1

    def test_get_upload_by_id(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=5000,
        )
        found = session_manager.get_upload_by_id(record.id, user_id=12345)
        assert found is not None
        assert found.id == record.id
        assert found.original_filename == "report.pdf"

    def test_get_upload_by_id_wrong_user(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=5000,
        )
        assert session_manager.get_upload_by_id(record.id, user_id=99999) is None

    def test_get_upload_by_id_not_found(self, session_manager: SessionManager):
        assert session_manager.get_upload_by_id(999, user_id=12345) is None

    def test_delete_upload(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=5000,
        )
        assert session_manager.delete_upload(record.id, user_id=12345) is True
        assert session_manager.get_uploads(12345) == []

    def test_delete_upload_wrong_user(self, session_manager: SessionManager):
        record = session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename="abc123",
            extension=".pdf",
            file_size=5000,
        )
        assert session_manager.delete_upload(record.id, user_id=99999) is False
        assert len(session_manager.get_uploads(12345)) == 1

    def test_delete_upload_not_found(self, session_manager: SessionManager):
        assert session_manager.delete_upload(999, user_id=12345) is False


# --- Telegram handler: handle_document ---


@pytest.fixture
def mock_config(tmp_path: Path) -> Config:
    config = MagicMock(spec=Config)
    config.telegram_token = "test_token"
    config.api_key = "test_api_key"
    config.root_folder = tmp_path
    config.allowed_user_ids = [12345]
    config.read_rules = ReadRules()
    config.watch_config = WatchConfig()
    config.db_path = tmp_path / "sessions.db"
    config.model = "anthropic/claude-sonnet-4-20250514"
    config.max_context_chars = 10000
    config.max_history_chars = 50000
    config.user_name = "User"
    config.tools = {}
    return config


@pytest.fixture
def bot(mock_config: Config) -> TelegramBot:
    with patch("folderbot.llm_client.instructor"):
        return TelegramBot(mock_config)


@pytest.fixture
def mock_doc_update():
    update = MagicMock()
    update.effective_user = MagicMock()
    update.effective_user.id = 12345
    update.message = MagicMock()
    update.message.reply_text = AsyncMock()
    update.message.document = MagicMock()
    update.message.document.file_name = "report.pdf"
    update.message.document.mime_type = "application/pdf"
    update.message.document.get_file = AsyncMock()
    file_mock = MagicMock()
    file_mock.download_as_bytearray = AsyncMock(return_value=bytearray(b"%PDF-test"))
    update.message.document.get_file.return_value = file_mock
    return update


class TestHandleDocument:
    @pytest.mark.asyncio
    async def test_unauthorized_upload(self, bot, mock_doc_update):
        mock_doc_update.effective_user.id = 99999
        await bot.handle_document(mock_doc_update, MagicMock())
        mock_doc_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_no_document_returns_early(self, bot, mock_doc_update):
        mock_doc_update.message.document = None
        await bot.handle_document(mock_doc_update, MagicMock())
        mock_doc_update.message.reply_text.assert_not_called()

    @pytest.mark.asyncio
    async def test_successful_upload_saves_file(
        self, bot, mock_doc_update, mock_config
    ):
        await bot.handle_document(mock_doc_update, MagicMock())

        uploads_dir = mock_config.root_folder / ".folderbot" / "uploads"
        assert uploads_dir.exists()

        expected_hash = hashlib.sha256(b"%PDF-test").hexdigest()
        saved_file = uploads_dir / expected_hash
        assert saved_file.exists()
        assert saved_file.read_bytes() == b"%PDF-test"

    @pytest.mark.asyncio
    async def test_successful_upload_creates_db_record(
        self, bot, mock_doc_update, mock_config
    ):
        await bot.handle_document(mock_doc_update, MagicMock())

        uploads = bot.session_manager.get_uploads(12345)
        assert len(uploads) == 1
        assert uploads[0].original_filename == "report.pdf"
        assert uploads[0].extension == ".pdf"
        assert uploads[0].file_size == len(b"%PDF-test")
        assert uploads[0].mime_type == "application/pdf"

    @pytest.mark.asyncio
    async def test_successful_upload_replies(self, bot, mock_doc_update):
        await bot.handle_document(mock_doc_update, MagicMock())

        call_args = mock_doc_update.message.reply_text.call_args[0][0]
        assert "report.pdf" in call_args

    @pytest.mark.asyncio
    async def test_accepts_non_pdf_files(self, bot, mock_doc_update):
        mock_doc_update.message.document.file_name = "data.csv"
        mock_doc_update.message.document.mime_type = "text/csv"
        await bot.handle_document(mock_doc_update, MagicMock())

        uploads = bot.session_manager.get_uploads(12345)
        assert len(uploads) == 1
        assert uploads[0].original_filename == "data.csv"
        assert uploads[0].extension == ".csv"
        assert uploads[0].mime_type == "text/csv"

    @pytest.mark.asyncio
    async def test_download_error_replies_with_error(self, bot, mock_doc_update):
        mock_doc_update.message.document.get_file = AsyncMock(
            side_effect=Exception("Network error")
        )
        await bot.handle_document(mock_doc_update, MagicMock())

        call_args = mock_doc_update.message.reply_text.call_args[0][0]
        assert "Error downloading file" in call_args

    @pytest.mark.asyncio
    async def test_missing_filename_defaults(self, bot, mock_doc_update):
        mock_doc_update.message.document.file_name = None
        await bot.handle_document(mock_doc_update, MagicMock())

        uploads = bot.session_manager.get_uploads(12345)
        assert uploads[0].original_filename == "unknown"


# --- Telegram handler: handle_photo ---


@pytest.fixture
def mock_photo_update():
    update = MagicMock()
    update.effective_user = MagicMock()
    update.effective_user.id = 12345
    update.message = MagicMock()
    update.message.reply_text = AsyncMock()
    update.message.caption = None
    # Photo is a list of PhotoSize objects; last one is largest
    photo_obj = MagicMock()
    photo_obj.get_file = AsyncMock()
    file_mock = MagicMock()
    file_mock.download_as_bytearray = AsyncMock(
        return_value=bytearray(b"\xff\xd8\xff\xe0fake-jpeg-data")
    )
    photo_obj.get_file.return_value = file_mock
    update.message.photo = [MagicMock(), photo_obj]  # smallest, largest
    return update


class TestHandlePhoto:
    @pytest.mark.asyncio
    async def test_unauthorized_photo(self, bot, mock_photo_update):
        mock_photo_update.effective_user.id = 99999
        await bot.handle_photo(mock_photo_update, MagicMock())
        mock_photo_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_no_photo_returns_early(self, bot, mock_photo_update):
        mock_photo_update.message.photo = None
        await bot.handle_photo(mock_photo_update, MagicMock())
        mock_photo_update.message.reply_text.assert_not_called()

    @pytest.mark.asyncio
    async def test_photo_saves_to_uploads(self, bot, mock_photo_update, mock_config):
        await bot.handle_photo(mock_photo_update, MagicMock())
        uploads_dir = mock_config.root_folder / ".folderbot" / "uploads"
        assert uploads_dir.exists()
        expected_hash = hashlib.sha256(b"\xff\xd8\xff\xe0fake-jpeg-data").hexdigest()
        saved_file = uploads_dir / expected_hash
        assert saved_file.exists()

    @pytest.mark.asyncio
    async def test_photo_creates_db_record(self, bot, mock_photo_update):
        await bot.handle_photo(mock_photo_update, MagicMock())
        uploads = bot.session_manager.get_uploads(12345)
        assert len(uploads) == 1
        assert uploads[0].extension == ".jpg"
        assert uploads[0].mime_type == "image/jpeg"

    @pytest.mark.asyncio
    async def test_photo_queues_for_processing(self, bot, mock_photo_update):
        """Photo should queue a message for LLM processing with image data."""
        with patch.object(bot, "_start_processing", new_callable=AsyncMock):
            await bot.handle_photo(mock_photo_update, MagicMock())
        # Should have queued a pending message
        assert 12345 in bot._pending_messages or bot._start_processing.called

    @pytest.mark.asyncio
    async def test_photo_with_caption(self, bot, mock_photo_update):
        """Caption text should be used as the user message."""
        mock_photo_update.message.caption = "What does this say?"
        with patch.object(bot, "_start_processing", new_callable=AsyncMock):
            await bot.handle_photo(mock_photo_update, MagicMock())
        # Pending messages should contain the caption
        if 12345 in bot._pending_messages:
            combined = " ".join(bot._pending_messages[12345])
            assert "What does this say?" in combined

    @pytest.mark.asyncio
    async def test_photo_stores_image_data(self, bot, mock_photo_update):
        """Image data should be stored for multimodal LLM processing."""
        with patch.object(bot, "_start_processing", new_callable=AsyncMock):
            await bot.handle_photo(mock_photo_update, MagicMock())
        # Should have image data in pending images
        assert 12345 in bot._pending_images
        assert len(bot._pending_images[12345]) == 1
        img = bot._pending_images[12345][0]
        assert img["media_type"] == "image/jpeg"
        assert len(img["data"]) > 0  # base64 data

    @pytest.mark.asyncio
    async def test_photo_download_error(self, bot, mock_photo_update):
        mock_photo_update.message.photo[-1].get_file = AsyncMock(
            side_effect=Exception("Network error")
        )
        await bot.handle_photo(mock_photo_update, MagicMock())
        call_args = mock_photo_update.message.reply_text.call_args[0][0]
        assert "Error" in call_args


# --- Upload tools ---


@pytest.fixture
def upload_services(session_manager: SessionManager, tmp_path: Path) -> UploadServices:
    uploads_dir = tmp_path / "uploads"
    uploads_dir.mkdir()
    return UploadServices(
        session_manager=session_manager,
        uploads_dir=uploads_dir,
        send_document=AsyncMock(),
        chat_id=42,
    )


def _make_context(upload_services: UploadServices, user_id: int = 12345):
    from folderbot.bot import BotContext

    ctx = BotContext(query="", user_id=user_id)
    ctx.services["uploads"] = upload_services
    return ctx


def _save_file(upload_services: UploadServices, content: bytes = b"hello") -> str:
    """Save a file to the uploads dir and return the hash."""
    file_hash = hashlib.sha256(content).hexdigest()
    (upload_services.uploads_dir / file_hash).write_bytes(content)
    return file_hash


class TestListUploads:
    @pytest.mark.asyncio
    async def test_empty(self, upload_services):
        from folderbot.tools.upload_tools import list_uploads, ListUploadsRequest

        ctx = _make_context(upload_services)
        result = await list_uploads(ListUploadsRequest(), ctx)
        assert result.content == "No uploaded files."

    @pytest.mark.asyncio
    async def test_lists_files(self, upload_services):
        from folderbot.tools.upload_tools import list_uploads, ListUploadsRequest

        upload_services.session_manager.save_upload(
            user_id=12345,
            original_filename="a.pdf",
            hash_filename="hash_a",
            extension=".pdf",
            file_size=100,
        )
        ctx = _make_context(upload_services)
        result = await list_uploads(ListUploadsRequest(), ctx)
        assert "a.pdf" in result.content
        assert "100" in result.content


class TestDeleteUpload:
    @pytest.mark.asyncio
    async def test_delete_existing(self, upload_services):
        from folderbot.tools.upload_tools import delete_upload, DeleteUploadRequest

        file_hash = _save_file(upload_services)
        record = upload_services.session_manager.save_upload(
            user_id=12345,
            original_filename="a.pdf",
            hash_filename=file_hash,
            extension=".pdf",
            file_size=5,
        )
        ctx = _make_context(upload_services)
        result = await delete_upload(DeleteUploadRequest(upload_id=record.id), ctx)
        assert not result.is_error
        assert "Deleted" in result.content
        assert not (upload_services.uploads_dir / file_hash).exists()
        assert upload_services.session_manager.get_uploads(12345) == []

    @pytest.mark.asyncio
    async def test_delete_not_found(self, upload_services):
        from folderbot.tools.upload_tools import delete_upload, DeleteUploadRequest

        ctx = _make_context(upload_services)
        result = await delete_upload(DeleteUploadRequest(upload_id=999), ctx)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_delete_wrong_user(self, upload_services):
        from folderbot.tools.upload_tools import delete_upload, DeleteUploadRequest

        file_hash = _save_file(upload_services)
        record = upload_services.session_manager.save_upload(
            user_id=12345,
            original_filename="a.pdf",
            hash_filename=file_hash,
            extension=".pdf",
            file_size=5,
        )
        ctx = _make_context(upload_services, user_id=99999)
        result = await delete_upload(DeleteUploadRequest(upload_id=record.id), ctx)
        assert result.is_error
        # File should still exist
        assert (upload_services.uploads_dir / file_hash).exists()


class TestSendUpload:
    @pytest.mark.asyncio
    async def test_send_existing(self, upload_services):
        from folderbot.tools.upload_tools import send_upload, SendUploadRequest

        file_hash = _save_file(upload_services, b"pdf-content")
        record = upload_services.session_manager.save_upload(
            user_id=12345,
            original_filename="report.pdf",
            hash_filename=file_hash,
            extension=".pdf",
            file_size=11,
        )
        ctx = _make_context(upload_services)
        result = await send_upload(SendUploadRequest(upload_id=record.id), ctx)
        assert not result.is_error
        assert "Sent" in result.content
        upload_services.send_document.assert_called_once_with(
            42,
            upload_services.uploads_dir / file_hash,
            "report.pdf",
        )

    @pytest.mark.asyncio
    async def test_send_not_found(self, upload_services):
        from folderbot.tools.upload_tools import send_upload, SendUploadRequest

        ctx = _make_context(upload_services)
        result = await send_upload(SendUploadRequest(upload_id=999), ctx)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_send_missing_file_on_disk(self, upload_services):
        from folderbot.tools.upload_tools import send_upload, SendUploadRequest

        record = upload_services.session_manager.save_upload(
            user_id=12345,
            original_filename="gone.pdf",
            hash_filename="nonexistent",
            extension=".pdf",
            file_size=5,
        )
        ctx = _make_context(upload_services)
        result = await send_upload(SendUploadRequest(upload_id=record.id), ctx)
        assert result.is_error
        assert "missing" in result.content.lower()
