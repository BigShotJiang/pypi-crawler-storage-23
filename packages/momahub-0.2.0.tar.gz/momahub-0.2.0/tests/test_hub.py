"""Unit tests for MoMaHub v0.2 — registry, circuit breakers, routing."""

import asyncio
import tempfile
from pathlib import Path

import pytest

from momahub import (
    CircuitBreaker,
    CircuitState,
    MoMaHub,
    NodeInfo,
    NodeStatus,
)


@pytest.fixture
def hub(tmp_path: Path) -> MoMaHub:
    return MoMaHub(db_path=tmp_path / "registry.db")


@pytest.fixture
def node() -> NodeInfo:
    return NodeInfo(
        node_id="test-gpu-0",
        url="http://localhost:11434",
        gpu_model="GTX 1080 Ti",
        vram_gb=11.0,
        models=["qwen2.5:7b", "mistral:7b"],
    )


# ------------------------------------------------------------------
# Registry
# ------------------------------------------------------------------

def test_register_and_list(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    nodes = hub.list_nodes()
    assert len(nodes) == 1
    assert nodes[0].node_id == "test-gpu-0"


def test_persistence(tmp_path: Path, node: NodeInfo) -> None:
    db = tmp_path / "registry.db"
    h1 = MoMaHub(db_path=db)
    h1.register(node)
    h1.close()
    # Reload from DB
    h2 = MoMaHub(db_path=db)
    nodes = h2.list_nodes()
    assert len(nodes) == 1
    assert nodes[0].node_id == "test-gpu-0"


def test_deregister(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    assert hub.deregister("test-gpu-0") is True
    assert hub.list_nodes() == []


def test_deregister_missing(hub: MoMaHub) -> None:
    assert hub.deregister("nonexistent") is False


def test_heartbeat_updates_queue_depth(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    hub.heartbeat("test-gpu-0", queue_depth=3, tokens_delta=100)
    n = hub.get_node("test-gpu-0")
    assert n.queue_depth == 3
    assert n.tokens_served == 100


def test_heartbeat_resets_circuit(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    # Force circuit open
    for _ in range(3):
        hub._breakers["test-gpu-0"].record_failure()
    assert hub._breakers["test-gpu-0"].state == CircuitState.OPEN
    # Heartbeat should reset it
    hub.heartbeat("test-gpu-0")
    assert hub._breakers["test-gpu-0"].state == CircuitState.CLOSED


def test_expire_stale_nodes(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    # Force last_seen to be ancient via registry
    hub._registry._conn.execute(
        "UPDATE nodes SET last_seen = 0 WHERE node_id = ?", (node.node_id,)
    )
    hub._registry._conn.commit()
    stale = hub.expire_stale_nodes()
    assert "test-gpu-0" in stale
    assert hub.get_node("test-gpu-0").status == NodeStatus.OFFLINE


# ------------------------------------------------------------------
# Stats
# ------------------------------------------------------------------

def test_stats_empty(hub: MoMaHub) -> None:
    s = hub.stats()
    assert s.total_nodes == 0
    assert s.total_tokens_served == 0


def test_stats_aggregates_tokens(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    hub.heartbeat("test-gpu-0", tokens_delta=500)
    s = hub.stats()
    assert s.total_tokens_served == 500


# ------------------------------------------------------------------
# Circuit breaker
# ------------------------------------------------------------------

def test_circuit_opens_after_failures() -> None:
    cb = CircuitBreaker(failure_threshold=3)
    for _ in range(3):
        cb.record_failure()
    assert cb.state == CircuitState.OPEN
    assert cb.allow_request() is False


def test_circuit_half_open_after_timeout() -> None:
    import time
    cb = CircuitBreaker(failure_threshold=1, open_timeout_s=0.05)
    cb.record_failure()
    assert cb.state == CircuitState.OPEN
    time.sleep(0.1)
    assert cb.allow_request() is True
    assert cb.state == CircuitState.HALF_OPEN


def test_circuit_closes_after_successes() -> None:
    cb = CircuitBreaker(failure_threshold=1, success_threshold=2, open_timeout_s=0.05)
    cb.record_failure()
    import time; time.sleep(0.1)
    cb.allow_request()  # transitions to HALF_OPEN
    cb.record_success()
    cb.record_success()
    assert cb.state == CircuitState.CLOSED


def test_circuit_state_exposed_by_hub(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    assert hub.circuit_state("test-gpu-0") == "closed"
    for _ in range(3):
        hub._breakers["test-gpu-0"].record_failure()
    assert hub.circuit_state("test-gpu-0") == "open"


# ------------------------------------------------------------------
# Routing — weighted selection
# ------------------------------------------------------------------

def test_routing_prefers_low_queue(hub: MoMaHub) -> None:
    busy = NodeInfo(node_id="busy", url="http://localhost:11434",
                    models=["qwen2.5:7b"], queue_depth=10)
    free = NodeInfo(node_id="free", url="http://localhost:11435",
                    models=["qwen2.5:7b"], queue_depth=0)
    hub.register(busy)
    hub.register(free)
    # With queue_depth weighting, "free" should always win
    candidates = hub._candidates("qwen2.5:7b")
    assert candidates[0].node_id == "free"


def test_circuit_open_node_excluded(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    for _ in range(3):
        hub._breakers["test-gpu-0"].record_failure()
    candidates = hub._candidates("qwen2.5:7b")
    assert all(c.node_id != "test-gpu-0" for c in candidates)
