# MoMa Hub — Architecture Research & Design

> **"A democratic AI inference stack built on consumer GPUs is more resilient
> than a monopoly of a few large providers — just as bulk matter is more
> resilient than a single crystal."**

---

## 1. The Physics Analogy (Formal)

The four-level hierarchy maps directly onto established distributed-systems
concepts. Using physics as the mental model keeps the design honest: each
level has emergent properties that the level below cannot exhibit alone.

| Physics | MoMa Hub entity | Distributed-systems analogue |
|---------|----------------|------------------------------|
| **Atom** | Single GPU card running one Ollama instance | Leaf node / replica |
| **Molecule** | One owner's co-located GPU set (same host or LAN segment) | Shard group / availability unit |
| **Crystal** | LAN cluster of molecules (home lab, office) | Availability zone |
| **Bulk material** | Internet-scale contributor community | Global DHT overlay |

**Key emergent property at each level:**

- **Atom → Molecule**: load-balancing, redundancy within one trust domain
- **Molecule → Crystal**: intra-LAN low-latency routing (<1 ms), shared
  bandwidth cap becomes visible, ISP becomes a single point of failure
- **Crystal → Material**: geographic diversity, partition tolerance, percolation

**Percolation theory baseline:**
In a random graph with average degree *k*, the giant connected component
persists above the critical threshold p_c ≈ 1/*k* even under random node
failures. The internet is closer to a Barabási–Albert scale-free graph
(degree distribution follows a power law), which makes it highly robust
to *random* failure but vulnerable to *targeted* attacks on hubs. MoMa Hub
must therefore avoid hard dependence on any single hub (no single bootstrap
node, no single registry).

---

## 2. Reference Architectures Survey

### 2.1 Petals (BigScience, 2022)

**What it is:** Distributed inference for models too large for one GPU
(BLOOM-176B). Each volunteer server hosts a contiguous block of transformer
layers; the client stitches them together in sequence.

**Node discovery:** Kademlia DHT (via the Hivemind library). Servers
announce which *layer range* they serve. Clients query the DHT to find a
path through all layers.

**Routing:** Sequential — the client must route through servers in layer order.
Uses a spanning-tree algorithm to find the minimum-latency path.

**Fault tolerance:** If a mid-path server goes down, the client rebuilds
the path. Timeout + retry with an alternate server covering the same layers.

**Relevance to MoMa Hub:**
- The DHT discovery mechanism is directly reusable.
- Sequential routing is **not** needed for MoMa Hub: 7B models fit in one
  GTX 1080 Ti, so requests are fully served by a single atom. We need
  *parallel* routing (many independent requests → many atoms), not
  *sequential* routing (one request → chain of servers).
- Key borrow: **Kademlia DHT keyed by model_id → set of serving nodes**.

### 2.2 Hivemind (Learning@Home, 2020)

**What it is:** DHT-based infrastructure for decentralized ML training and
mixture-of-experts (MoE) routing.

**Node discovery:** Kademlia DHT with 160-bit node IDs. Each node maintains
a k-bucket routing table: O(log N) hops to any key in an N-node network.
Bootstrap via a known seed node; once in the DHT, no seed needed.

**Routing (MoE):** "Expert UIDs" are hashed to DHT keys. A client looks
up the nearest live node to the key, which serves that expert. Handles
expert failures transparently.

**Relevance to MoMa Hub:**
- MoE routing ≈ model routing: hash(model_id) → DHT key → serving node.
- The Hivemind `dht` module is available as a Python library — usable
  directly in MoMa Hub v0.4.
- Key borrow: **DHT-based model-to-node mapping with O(log N) lookup**.

### 2.3 exo (2024)

**What it is:** Run LLMs across heterogeneous personal devices
(iPhone + MacBook + etc.) on a LAN.

**Node discovery:** mDNS/Bonjour for zero-config LAN discovery. No
manual IP configuration needed.

**Model partitioning:** Ring topology — each device holds a shard.
Automatic shard allocation proportional to device capability (FLOPS, RAM).

**Relevance to MoMa Hub:**
- **mDNS is the right choice for Crystal-level discovery** — zero-config,
  works on any home network, no firewall rules needed.
- Model partitioning across devices is not needed for 7B models, but
  the ring topology is a useful reference for multi-GPU model sharding
  in MoMa Hub v0.5 (70B+ models across multiple molecules).
- Key borrow: **mDNS for Crystal level, capability-proportional allocation**.

### 2.4 BOINC (Berkeley, 2002)

**What it is:** Volunteer computing platform (SETI@home, Folding@home, etc.)

**Architecture:** Central scheduler server + volunteer clients. Clients
request "work units" (WUs) from the server. WUs have a deadline; if the
client misses it, the server reassigns.

**Fault tolerance:**
- **Redundant computation**: each WU is sent to 2–3 clients; results
  compared by checksum. If they agree → accepted. If not → tie-breaker.
- **Lease-based assignment**: client must return result before deadline or
  WU is reassigned. Handles slow/disconnected clients gracefully.

**Relevance to MoMa Hub:**
- Lease-based work assignment is ideal for async inference jobs (v0.3+).
- Redundant computation for result validation is the right model for
  building trust in untrusted contributor nodes (v0.4+).
- The central scheduler is a SPOF — MoMa Hub must make the registry
  federated (multiple hub servers, DHT-backed).
- Key borrow: **work-unit leases + optional redundant validation**.

### 2.5 BitTorrent DHT / Kademlia

**Core algorithm:** Each node has a 160-bit ID. Distance = XOR of IDs.
Each node maintains a *k-bucket* routing table: for each bit-prefix length i,
store up to k nodes whose IDs differ from ours at bit i. This gives
O(log N) routing in N-node networks with O(k·log N) state per node.

**Node join:** Contact any known bootstrap node → find_node(own_id) →
populate k-buckets → announce presence.

**Key lookup:** find_value(key) → iterative alpha-parallel lookups converge
on k nearest nodes to the key.

**Resilience:** With k=20, the DHT tolerates the simultaneous failure of
any 19 of the 20 closest nodes to a key. The network self-heals as new
nodes join.

**Relevance to MoMa Hub:**
- Full Kademlia DHT is the right backbone for Material-level discovery.
- Python libraries: `kademlia` (asyncio-based), or use `libp2p` (Go/Rust,
  Python bindings via `py-libp2p`).
- Key borrow: **Kademlia for global model→node index**.

### 2.6 SWIM Gossip Protocol (2002)

**What it is:** Scalable Weakly-consistent Infection-style Membership
protocol. Used by Consul, HashiCorp Serf, Cassandra, Kubernetes (etcd
uses Raft, but memberlist uses SWIM).

**Failure detection:**
1. Node A pings node B directly.
2. If B doesn't respond within timeout, A asks k random other nodes to
   ping B *indirectly* (avoiding false positives from A's network partition).
3. If none get a response, B is marked *suspected*, then *failed* after
   a grace period.

**Membership dissemination:** Changes (join/leave/fail) are piggybacked
on ping/ack messages — epidemic broadcast. Each node eventually learns
about all changes with O(log N) message rounds.

**Complexity:** O(1) messages per node per round (unlike heartbeat-to-all
which is O(N)). Scales to thousands of nodes.

**Relevance to MoMa Hub:**
- Molecule-level and Crystal-level membership tracking.
- Python implementation: `memberlist` (Go, wrappable) or implement
  lightweight SWIM in ~200 lines of asyncio Python for MoMa Hub.
- Key borrow: **SWIM for Crystal-level membership; gossip for topology
  dissemination**.

### 2.7 Consistent Hashing (Karger, 1997)

**Core idea:** Map both nodes and keys onto a ring [0, 2^32). A key is
served by the first node clockwise from the key on the ring. When a node
joins/leaves, only its immediate neighbours are affected.

**Virtual nodes (vnodes):** Each physical node is represented by V virtual
positions on the ring, improving load balance for heterogeneous nodes.
Higher-VRAM atoms get more vnodes.

**Relevance to MoMa Hub:**
- Assign each (model_id, request_id) to a primary atom via consistent hash.
- Node join/leave → only ~1/N of requests re-route. No thundering herd.
- VRAM-proportional vnodes: GTX 1080 Ti (11 GB) gets fewer vnodes than
  RTX 3090 (24 GB).
- Key borrow: **consistent hashing for stable model→atom assignment**.

### 2.8 Hedged Requests (Google, Jeff Dean 2013)

**Problem:** In large distributed systems, a small fraction of servers are
"stragglers" — temporarily slow due to GC, swap, etc. These inflate P99
latency dramatically.

**Solution:** After 95th-percentile expected latency passes with no response,
send the *same* request to a second replica. Return whichever responds first;
cancel the other. This costs ~5% extra load but cuts P99 latency by 50–80%.

**Relevance to MoMa Hub:**
- GTX 1080 Ti on a home internet connection is a classic straggler scenario
  (thermal throttling, other GPU users, ISP jitter).
- For latency-sensitive requests (interactive apps), hedging to 2 atoms
  dramatically improves user experience.
- Key borrow: **hedged requests at the hub router for P99 latency**.

### 2.9 Circuit Breaker (Nygard 2007 / Netflix Hystrix)

**State machine:**
```
CLOSED ──(N failures in window)──► OPEN ──(timeout)──► HALF-OPEN
  ▲                                                         │
  └──────────────(success)─────────────────────────────────┘
                                    │
                             (failure)──► OPEN
```

- **CLOSED**: requests flow normally; failures are counted.
- **OPEN**: all requests to this node are immediately failed/rerouted;
  no traffic hits the sick node.
- **HALF-OPEN**: one probe request is let through; if it succeeds, return
  to CLOSED; if not, back to OPEN.

**Relevance to MoMa Hub:**
- Each atom has its own circuit breaker in the molecule coordinator.
- Prevents one sick GPU from dragging down the whole molecule.
- Key borrow: **circuit breaker per atom in the molecule coordinator**.

### 2.10 Bittensor (2021)

**What it is:** Blockchain-based incentive layer for a decentralized ML
network. Miners serve inference; validators score quality; TAO tokens
are awarded by consensus (Yuma consensus).

**Strengths:** Robust Sybil resistance, meritocratic incentives.

**Weaknesses:** High complexity, token economics introduce misaligned
incentives, smart contract overhead adds latency.

**Relevance to MoMa Hub:**
- The *concept* of contribution scoring + free-quota reward is right.
- Blockchain is overkill for the MVP and introduces unnecessary friction.
- v0.4+: a lightweight signed contribution ledger (no blockchain needed)
  achieves 80% of the benefit at 5% of the complexity.
- Key borrow: **contribution score → free inference quota, without blockchain**.

---

## 3. MoMa Hub Architecture Design

### 3.1 Four-Tier Overlay

```
┌─────────────────────────────────────────────────────────────────┐
│  MATERIAL  (Internet DHT — Kademlia)                            │
│  model_id  ──DHT lookup──►  set of Crystal relays               │
│                                                                 │
│  ┌──────────────────────────────────┐                           │
│  │  CRYSTAL  (LAN — mDNS + SWIM)    │  ×  many worldwide        │
│  │  molecule relays gossip topology │                           │
│  │                                  │                           │
│  │  ┌──────────────────────────┐    │                           │
│  │  │  MOLECULE  (host/owner)  │ ×M │                           │
│  │  │  coordinator + circuit   │    │                           │
│  │  │  breaker per atom        │    │                           │
│  │  │                          │    │                           │
│  │  │  ┌────┐ ┌────┐ ┌────┐   │    │                           │
│  │  │  │GPU0│ │GPU1│ │GPU2│   │    │                           │
│  │  │  │ A  │ │ A  │ │ A  │   │    │                           │
│  │  │  └────┘ └────┘ └────┘   │    │                           │
│  │  │  ATOMS (Ollama :port)    │    │                           │
│  │  └──────────────────────────┘    │                           │
│  └──────────────────────────────────┘                           │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.2 Atom (Single GPU / Ollama Instance)

**Identity:** `{owner_id}.{host_id}.{gpu_index}` — e.g. `alice.homelab.0`

**State:**
```python
@dataclass
class AtomState:
    atom_id: str
    ollama_url: str          # http://localhost:11434
    gpu_model: str           # "GTX 1080 Ti"
    vram_gb: float           # 11.0
    models: list[str]        # ["qwen2.5:7b", "mistral:7b"]
    queue_depth: int         # current pending requests
    status: AtomStatus       # ONLINE | BUSY | CIRCUIT_OPEN | OFFLINE
    tokens_served: int       # contribution counter
    last_heartbeat: float    # unix timestamp
```

**Responsibilities:**
- Serve Ollama inference requests
- Emit heartbeat to parent molecule coordinator every 5 s
- Report queue depth (enables load-aware routing)

**Failure modes:** GPU OOM, thermal throttle, Ollama crash, host reboot.
All handled at the molecule level — atom is passive.

---

### 3.3 Molecule (Owner's GPU Set)

**Identity:** `{owner_id}.{host_id}` — e.g. `alice.homelab`

**Components:**
1. **Coordinator process** — lightweight FastAPI server (the current
   MoMa Hub server is already this)
2. **Circuit breaker** per atom (CLOSED/OPEN/HALF-OPEN state machine)
3. **Atom health monitor** — heartbeat watchdog, marks atoms offline
4. **Intra-molecule router** — weighted round-robin with queue-depth weights

**Routing algorithm (intra-molecule):**
```
score(atom) = (1 / (queue_depth + 1)) × uptime_weight × vram_weight
route to atom with highest score
```

**Circuit breaker thresholds (recommended):**
- Open after: 3 consecutive failures OR >50% failure rate in 60 s window
- Half-open probe after: 30 s
- Close after: 2 consecutive successes in HALF-OPEN

**Molecule announces to Crystal:**
- mDNS service: `_momahub._tcp.local.` with TXT records:
  `models=qwen2.5:7b,mistral:7b`, `vram=11`, `atoms=4`

---

### 3.4 Crystal (LAN Cluster)

**Identity:** Hash of local subnet CIDR — e.g. `crystal.192.168.1.0/24`

**Discovery:** mDNS/DNS-SD via `python-zeroconf`. Zero configuration.
Every molecule on the LAN automatically discovers every other molecule
within ~1 s of coming online.

**Topology maintenance:** Lightweight SWIM-inspired gossip:
- Each molecule pings 3 random peer molecules every 10 s
- Failure detected after 2 missed pings + 1 indirect probe
- Membership updates piggybacked on pings (epidemic)

**Crystal relay election:**
- The molecule with the longest uptime + most atoms becomes the Crystal relay
- Relay is the Crystal's representative in the Material-level DHT
- If relay fails, new election in O(log N) gossip rounds

**Crystal-level routing (between molecules):**
- Consistent hash ring keyed by (model_id, request_id)
- Molecule with hash-closest ID to the key is primary
- If primary circuit is OPEN, use consistent-hash successor

**Single ISP outage:** Takes the whole crystal offline. The Material DHT
detects this when the relay's DHT record expires (TTL-based). Requests
route to other crystals automatically — this is the core resilience
property of the hierarchy.

---

### 3.5 Material (Global DHT)

**Algorithm:** Kademlia (160-bit keys, k=20, α=3 parallel lookups)

**What is stored in the DHT:**
```
key = SHA1(model_id)          →  value = [CrystalRelayInfo, ...]
key = SHA1("hub:stats")       →  value = aggregate stats
key = SHA1("hub:bootstrap")   →  value = [well-known relay IPs]
```

**Bootstrap:** 3–5 stable, well-known relay nodes (donated by core
contributors). Once in the DHT, no further dependence on bootstrap nodes.

**TTL / freshness:** Crystal relay re-announces every 60 s. Records expire
after 5 min. Dead crystals automatically evaporate from the DHT.

**Client lookup flow:**
```
1. Client: DHT.get(SHA1("qwen2.5:7b"))
        → returns list of (crystal_relay_url, latency_hint)
2. Client pings top-3 relays, picks lowest-latency
3. Crystal relay: consistent-hash → molecule coordinator
4. Molecule coordinator: circuit-breaker-filtered → atom
5. Atom: Ollama inference → response
```

**End-to-end routing latency budget:**
- DHT lookup (O(log N) hops): 50–200 ms (one-time, cached 60 s)
- Crystal relay → molecule: 1–5 ms (LAN)
- Molecule → atom: 0.1 ms (localhost)
- Ollama inference: 500 ms – 30 s (model-dependent)

---

### 3.6 Routing Algorithm (Full Stack)

```python
async def route_request(req: InferenceRequest) -> InferenceResponse:
    # 1. Check local molecule cache (fastest path)
    atom = local_molecule.pick_atom(req.model)
    if atom:
        return await atom.infer(req)

    # 2. Check Crystal (LAN peers)
    molecule = await crystal.pick_molecule(req.model)
    if molecule:
        return await molecule.infer(req)

    # 3. Fall back to Material DHT
    relay = await material_dht.lookup(req.model)
    return await relay.infer(req)          # relay repeats steps 1-2 locally
```

**Hedged requests (latency-sensitive mode):**
```python
async def hedged_infer(req, candidates, hedge_delay_ms=500):
    # Send to primary immediately
    primary = asyncio.create_task(candidates[0].infer(req))
    # After hedge_delay_ms, send to backup if primary hasn't responded
    await asyncio.sleep(hedge_delay_ms / 1000)
    if not primary.done():
        backup = asyncio.create_task(candidates[1].infer(req))
        done, pending = await asyncio.wait(
            [primary, backup], return_when=asyncio.FIRST_COMPLETED
        )
        for p in pending:
            p.cancel()
        return done.pop().result()
    return await primary
```

---

### 3.7 Fault Tolerance Matrix

| Failure event | Detected by | Recovery mechanism | Downtime |
|---------------|-------------|-------------------|---------|
| Single atom crash | Molecule heartbeat watchdog | Circuit breaker OPEN → route to next atom | <5 s |
| All atoms on molecule crash | Crystal SWIM probe | Molecule marked failed → reroute via ring | <15 s |
| Crystal offline (ISP outage) | DHT TTL expiry | DHT routes to other crystals | <5 min |
| Bootstrap nodes all down | N/A | DHT is self-healing once seeded | 0 (DHT persists) |
| Central registry down | N/A | No central registry in v0.3+ | 0 |
| Model not available anywhere | DHT miss | Return "no capacity" to client | Immediate |

---

### 3.8 Trust Model

**MVP (v0.1–v0.2):** Trusted contributor network. No validation. Accept
all results. Suitable for closed community (friends, colleagues).

**v0.3 — Signed responses:**
- Each atom signs its response with an Ed25519 key
- Molecule verifies signatures before forwarding
- Client can verify provenance end-to-end
- Prevents MITM response injection

**v0.4 — Reputation system:**
- Each atom accumulates a reputation score from verified result quality
- Spot-checking: ~5% of requests are sent to 2 nodes; if results diverge
  significantly (embedding cosine sim < 0.7), flag the outlier
- Reputation decays over time without activity

**v0.5+ — Optional redundant computation (BOINC model):**
- High-value requests (paid tier) sent to 2–3 independent atoms
- Results compared; Byzantine majority accepted
- Adds latency but provides strong result integrity guarantees

---

### 3.9 Incentive Model

**No token/blockchain required.** Simple signed contribution ledger:

```
contribution_score(atom) =
    tokens_served × model_size_factor(model)
    × uptime_factor(last_30_days)
    × quality_factor(reputation_score)
```

**Reward tiers:**

| Tier | Monthly contribution | Benefit |
|------|---------------------|---------|
| Seed | 0 tokens served | 10K free tokens/month |
| Bronze | 100K tokens | 500K free tokens/month |
| Silver | 1M tokens | 5M free tokens/month |
| Gold | 10M tokens | Unlimited + priority routing |

**Free quota:** Paid to the community hub; anyone can use without registering
a node. Subsidised by Gold-tier contributors.

---

### 3.10 SPL Integration (v0.3+)

MoMa Hub becomes a first-class routing target in SPL scripts:

```sql
-- Route to MoMa Hub instead of a named provider
WITH
  analysis AS (
    PROMPT "Analyse this paper abstract: {abstract}"
    USING MODEL "qwen2.5:7b"
    USING HUB "momahub://crystal/default"   -- NEW: hub routing directive
    MAX TOKENS 512
  )
SELECT content FROM analysis
```

The `USING HUB` directive instructs the SPL executor to route through
MoMa Hub's routing stack instead of calling OpenRouter or Ollama directly.
This makes MoMa Hub invisible to SPL script authors — they just specify
a model name and the hub finds the best atom.

---

## 4. Technology Stack Recommendations

### By tier and version

| Tier | v0.1 (now) | v0.2 | v0.3 | v0.4 |
|------|-----------|------|------|------|
| Atom | Ollama REST | Ollama REST | Ollama REST | Ollama REST |
| Molecule | FastAPI + in-memory | FastAPI + SQLite + circuit-breaker | + heartbeat daemon | + signed responses |
| Crystal | — | — | mDNS (zeroconf) + gossip | + SWIM membership |
| Material | Manual registration | Manual + multi-hub | — | Kademlia DHT |

### Python library choices

| Component | Library | Rationale |
|-----------|---------|-----------|
| mDNS discovery | `zeroconf` (pure Python) | Zero-config LAN discovery, no deps |
| DHT | `kademlia` (asyncio) | Pure Python Kademlia, 500 LOC, easy to embed |
| Gossip/SWIM | Custom ~200 LOC asyncio | No good pure-Python SWIM lib; easy to write |
| HTTP | `httpx` (async) | Already a dep; supports connection pooling |
| Registry persistence | `sqlite3` (stdlib) | Zero dep, fast, sufficient for molecule scale |
| Signing | `cryptography` (Ed25519) | Standard, well-audited |
| Consistent hashing | `uhashring` or 50 LOC custom | Trivial to implement |

---

## 5. Roadmap Aligned to Hierarchy

### v0.1 — Atom level (DONE)
- [x] Single Ollama node registration
- [x] Round-robin routing
- [x] FastAPI REST server
- [x] CLI + Python SDK
- [x] `pip install momahub`

### v0.2 — Molecule level
- [ ] SQLite-persistent node registry
- [ ] Circuit breaker per atom (CLOSED/OPEN/HALF-OPEN)
- [ ] Heartbeat daemon with auto-deregister on TTL expiry
- [ ] Queue-depth-weighted routing
- [ ] `momahub node daemon` background process
- [ ] Per-atom contribution counter (tokens_served)

### v0.3 — Crystal level
- [ ] mDNS auto-discovery (`python-zeroconf`)
- [ ] Gossip-based Crystal membership (~200 LOC SWIM subset)
- [ ] Crystal relay election (longest-uptime wins)
- [ ] Consistent hash ring at Crystal level
- [ ] SPL `USING HUB` directive integration
- [ ] Simple web dashboard (Streamlit or static HTML)

### v0.4 — Material level
- [ ] Kademlia DHT backbone (`kademlia` library)
- [ ] Bootstrap node list (3 stable donated nodes)
- [ ] DHT record: model_id → crystal relay set
- [ ] Hedged requests for P99 latency
- [ ] Ed25519 signed atom responses
- [ ] Reputation scoring + contribution leaderboard

### v0.5 — Production hardening
- [ ] Internet federation via Tailscale/WireGuard (NAT traversal)
- [ ] Public MoMa Hub registry (hub.momahub.ai)
- [ ] Redundant computation for result validation
- [ ] Multi-molecule 70B model sharding (ring topology, exo-inspired)
- [ ] USING HUB published to PyPI as spl extension

---

## 6. Home Lab Setup (GTX 1080 Ti × 4)

For the author's immediate MVP, the 4-GPU home cluster operates at the
**Molecule level** — all 4 atoms are under one owner on one LAN:

```
Host machine
├── GPU 0: Ollama :11434  (atom: home.lab.0)  qwen2.5:7b
├── GPU 1: Ollama :11435  (atom: home.lab.1)  mistral:7b
├── GPU 2: Ollama :11436  (atom: home.lab.2)  qwen2.5:7b
└── GPU 3: Ollama :11437  (atom: home.lab.3)  deepseek-r1:7b

Molecule coordinator: momahub serve :8765
  ├── circuit breakers × 4
  ├── round-robin with queue weights
  └── SQLite: atom states + contribution counters
```

**To start 4 Ollama instances on separate GPU indices:**
```bash
CUDA_VISIBLE_DEVICES=0 OLLAMA_HOST=0.0.0.0:11434 ollama serve &
CUDA_VISIBLE_DEVICES=1 OLLAMA_HOST=0.0.0.0:11435 ollama serve &
CUDA_VISIBLE_DEVICES=2 OLLAMA_HOST=0.0.0.0:11436 ollama serve &
CUDA_VISIBLE_DEVICES=3 OLLAMA_HOST=0.0.0.0:11437 ollama serve &
```

Each Ollama instance can serve ~2–4 concurrent 7B requests on 11 GB VRAM
(depending on context length). 4 atoms = ~8–16 parallel inference streams
from a single home machine — already exceeds a single OpenAI API call in
throughput for community-scale workloads.

---

## 7. Anti-Monopoly Thesis

Current AI landscape risk: 3–5 companies control frontier model training,
inference infrastructure, and pricing. A coordinated outage, regulatory
action, or pricing change can disrupt all downstream users simultaneously.

MoMa Hub's distributed architecture provides structural resilience:

1. **No single owner**: thousands of independent contributors
2. **No single geography**: crystals on every continent
3. **No single model provider**: open-weight models (Qwen, Mistral,
   LLaMA, DeepSeek) run on commodity hardware
4. **Graceful degradation**: percolation theory guarantees that the
   network remains connected as long as >1/k of nodes are online
5. **Cost floor**: GTX 1080 Ti runs qwen2.5:7b at ~$0.00003/1K tokens
   (electricity only at $0.12/kWh) vs $0.15–0.60/1K tokens at tier-1 providers
   — a 5,000–20,000× cost advantage for the contributor community

The physics analogy holds: **bulk matter cannot be "turned off" by
attacking any single atom or molecule**. That is the goal.
