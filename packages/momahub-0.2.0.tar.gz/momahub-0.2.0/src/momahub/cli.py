"""MoMa Hub CLI — momahub <command>."""

from __future__ import annotations

import asyncio
import json
import signal
import sys
import time

import click
import httpx


HUB_URL_DEFAULT = "http://localhost:8765"


@click.group()
@click.option("--hub", default=HUB_URL_DEFAULT, envvar="MOMAHUB_URL", show_default=True,
              help="MoMa Hub server URL")
@click.pass_context
def main(ctx: click.Context, hub: str) -> None:
    """MoMa Hub — distributed AI inference on consumer GPUs."""
    ctx.ensure_object(dict)
    ctx.obj["hub"] = hub


# ------------------------------------------------------------------
# Server management
# ------------------------------------------------------------------

@main.command()
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--port", default=8765, show_default=True)
@click.option("--db", default=".momahub/registry.db", show_default=True,
              help="SQLite registry path")
def serve(host: str, port: int, db: str) -> None:
    """Start the MoMa Hub registry server."""
    try:
        import uvicorn
        from momahub.hub import get_hub
        from momahub.server import app
        # Pre-initialise hub with the requested DB path
        get_hub(db)
    except ImportError:
        click.echo("uvicorn / fastapi required: pip install momahub", err=True)
        sys.exit(1)
    click.echo(f"Starting MoMa Hub on http://{host}:{port}  (db: {db})")
    uvicorn.run(app, host=host, port=port)


# ------------------------------------------------------------------
# Node management
# ------------------------------------------------------------------

@main.command("register")
@click.option("--node-id", required=True, help="Unique node identifier, e.g. home-gpu-0")
@click.option("--url", required=True, help="Ollama base URL, e.g. http://localhost:11434")
@click.option("--gpu", default="unknown", help="GPU model name")
@click.option("--vram", default=11.0, type=float, help="Usable VRAM in GB")
@click.option("--models", multiple=True, help="Pre-pulled model tags (repeat for multiple)")
@click.pass_context
def register_node(ctx: click.Context, node_id: str, url: str, gpu: str,
                  vram: float, models: tuple) -> None:
    """Register an Ollama node with the hub."""
    hub = ctx.obj["hub"]
    payload = {
        "node_id": node_id,
        "url": url,
        "gpu_model": gpu,
        "vram_gb": vram,
        "models": list(models),
    }
    resp = httpx.post(f"{hub}/nodes/register", json=payload)
    resp.raise_for_status()
    click.echo(f"Registered: {json.dumps(resp.json(), indent=2)}")


@main.command("nodes")
@click.pass_context
def list_nodes(ctx: click.Context) -> None:
    """List all registered nodes."""
    hub_url = ctx.obj["hub"]
    resp = httpx.get(f"{hub_url}/nodes")
    resp.raise_for_status()
    nodes = resp.json()
    if not nodes:
        click.echo("No nodes registered.")
        return
    for n in nodes:
        circuit = n.get("circuit", "?")
        click.echo(
            f"  [{n['status']}|cb:{circuit}] {n['node_id']}  {n['url']}\n"
            f"    gpu={n['gpu_model']}  vram={n['vram_gb']}GB  "
            f"queue={n['queue_depth']}  tokens={n['tokens_served']}\n"
            f"    models={n['models']}"
        )


@main.command("stats")
@click.pass_context
def hub_stats(ctx: click.Context) -> None:
    """Show hub statistics."""
    hub_url = ctx.obj["hub"]
    resp = httpx.get(f"{hub_url}/stats")
    resp.raise_for_status()
    click.echo(json.dumps(resp.json(), indent=2))


# ------------------------------------------------------------------
# Heartbeat daemon
# ------------------------------------------------------------------

@main.command("daemon")
@click.option("--node-id", required=True, help="Node ID to maintain heartbeat for")
@click.option("--interval", default=10, type=int, show_default=True,
              help="Heartbeat interval in seconds")
@click.option("--ollama-url", default="http://localhost:11434", show_default=True,
              help="Local Ollama URL (used to measure queue depth)")
@click.pass_context
def daemon(ctx: click.Context, node_id: str, interval: int, ollama_url: str) -> None:
    """Run a heartbeat daemon for a registered node.

    Keep a node alive in the hub registry. Sends periodic heartbeats
    with current queue depth. Graceful shutdown on SIGINT/SIGTERM.

    Example:
        momahub daemon --node-id home-gpu-0 --interval 10
    """
    hub_url = ctx.obj["hub"]
    click.echo(f"Heartbeat daemon starting — node={node_id}  hub={hub_url}  "
               f"interval={interval}s")

    stop = False

    def _shutdown(sig, frame):  # noqa: ARG001
        nonlocal stop
        stop = True
        click.echo("\nShutting down daemon...")

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    consecutive_errors = 0
    while not stop:
        try:
            queue_depth = _get_ollama_queue(ollama_url)
            resp = httpx.post(
                f"{hub_url}/nodes/{node_id}/heartbeat",
                json={"queue_depth": queue_depth, "tokens_delta": 0},
                timeout=5.0,
            )
            if resp.status_code == 200:
                consecutive_errors = 0
            else:
                click.echo(f"[warn] heartbeat {resp.status_code}: {resp.text}", err=True)
                consecutive_errors += 1
        except Exception as exc:
            click.echo(f"[error] heartbeat failed: {exc}", err=True)
            consecutive_errors += 1

        if consecutive_errors >= 5:
            click.echo("[fatal] 5 consecutive heartbeat failures — exiting", err=True)
            sys.exit(1)

        time.sleep(interval)

    click.echo("Daemon stopped.")


def _get_ollama_queue(ollama_url: str) -> int:
    """Estimate queue depth by querying Ollama's running models."""
    try:
        resp = httpx.get(f"{ollama_url}/api/ps", timeout=2.0)
        if resp.status_code == 200:
            data = resp.json()
            return len(data.get("models", []))
    except Exception:
        pass
    return 0


# ------------------------------------------------------------------
# Inference
# ------------------------------------------------------------------

@main.command("infer")
@click.option("--model", required=True, help="Ollama model tag, e.g. qwen2.5:7b")
@click.option("--prompt", required=True, help="Prompt text")
@click.option("--system", default=None, help="System prompt")
@click.option("--hedged", is_flag=True, help="Use hedged requests (send to 2 nodes)")
@click.pass_context
def infer(ctx: click.Context, model: str, prompt: str,
          system: str | None, hedged: bool) -> None:
    """Send an inference request through the hub."""
    hub_url = ctx.obj["hub"]
    payload: dict = {"model": model, "prompt": prompt, "hedged": hedged}
    if system:
        payload["system"] = system
    resp = httpx.post(f"{hub_url}/infer", json=payload, timeout=120.0)
    resp.raise_for_status()
    data = resp.json()
    click.echo(data["content"])
    click.echo(
        f"\n[node={data['node_id']}  latency={data['latency_ms']:.0f}ms  "
        f"tokens={data['input_tokens']}+{data['output_tokens']}]",
        err=True,
    )


if __name__ == "__main__":
    main()
