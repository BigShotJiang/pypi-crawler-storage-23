"""Per-atom circuit breaker — CLOSED / OPEN / HALF-OPEN state machine."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class CircuitState(str, Enum):
    CLOSED = "closed"       # normal operation
    OPEN = "open"           # failing — skip this atom
    HALF_OPEN = "half_open" # probing — let one request through


@dataclass
class CircuitBreaker:
    """CLOSED → (N failures) → OPEN → (timeout) → HALF_OPEN → (success) → CLOSED.

    Args:
        failure_threshold: consecutive failures to open the circuit
        open_timeout_s:    seconds before trying a probe in HALF_OPEN
        success_threshold: successes in HALF_OPEN needed to close circuit
    """
    failure_threshold: int = 3
    open_timeout_s: float = 30.0
    success_threshold: int = 2

    state: CircuitState = field(default=CircuitState.CLOSED, init=False)
    _failure_count: int = field(default=0, init=False, repr=False)
    _success_count: int = field(default=0, init=False, repr=False)
    _opened_at: float = field(default=0.0, init=False, repr=False)

    def allow_request(self) -> bool:
        """Return True if a request should be allowed through."""
        if self.state == CircuitState.CLOSED:
            return True
        if self.state == CircuitState.OPEN:
            if time.monotonic() - self._opened_at >= self.open_timeout_s:
                self.state = CircuitState.HALF_OPEN
                self._success_count = 0
                return True
            return False
        # HALF_OPEN: allow exactly one probe at a time
        return True

    def record_success(self) -> None:
        if self.state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.success_threshold:
                self.state = CircuitState.CLOSED
                self._failure_count = 0
                self._success_count = 0
        elif self.state == CircuitState.CLOSED:
            # decay failure count on success
            self._failure_count = max(0, self._failure_count - 1)

    def record_failure(self) -> None:
        self._failure_count += 1
        self._opened_at = time.monotonic()
        if self.state == CircuitState.CLOSED:
            if self._failure_count >= self.failure_threshold:
                self.state = CircuitState.OPEN
        elif self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN

    def reset(self) -> None:
        self.state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
