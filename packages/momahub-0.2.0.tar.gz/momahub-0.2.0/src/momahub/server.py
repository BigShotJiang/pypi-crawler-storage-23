"""FastAPI server for the MoMa Hub registry + proxy API (v0.2)."""

from __future__ import annotations

import asyncio

from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager

from .hub import get_hub
from .models import HeartbeatPayload, InferenceRequest, NodeInfo, NodeStatus


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Background watchdog: mark stale nodes offline every 15 s
    async def _watchdog():
        while True:
            await asyncio.sleep(15)
            stale = get_hub().expire_stale_nodes()
            if stale:
                print(f"[watchdog] marked offline: {stale}")

    task = asyncio.create_task(_watchdog())
    yield
    task.cancel()


app = FastAPI(
    title="MoMa Hub",
    description="Distributed AI inference hub — Mixture of Models on Ollama",
    version="0.2.0",
    lifespan=lifespan,
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "version": "0.2.0"}


@app.get("/stats")
def stats() -> dict:
    return get_hub().stats().model_dump()


# ------------------------------------------------------------------
# Node registry
# ------------------------------------------------------------------

@app.get("/nodes")
def list_nodes(status: str | None = None) -> list[dict]:
    s = NodeStatus(status) if status else None
    hub = get_hub()
    result = []
    for n in hub.list_nodes(status=s):
        d = n.model_dump()
        d["circuit"] = hub.circuit_state(n.node_id)
        result.append(d)
    return result


@app.post("/nodes/register", status_code=201)
def register_node(node: NodeInfo) -> dict:
    registered = get_hub().register(node)
    return registered.model_dump()


@app.delete("/nodes/{node_id}")
def deregister_node(node_id: str) -> dict:
    removed = get_hub().deregister(node_id)
    if not removed:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    return {"removed": node_id}


@app.post("/nodes/{node_id}/heartbeat")
def heartbeat(node_id: str, payload: HeartbeatPayload = HeartbeatPayload()) -> dict:
    ok = get_hub().heartbeat(node_id,
                              queue_depth=payload.queue_depth,
                              tokens_delta=payload.tokens_delta)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    return {"node_id": node_id, "status": "online"}


# ------------------------------------------------------------------
# Inference proxy
# ------------------------------------------------------------------

@app.post("/infer")
async def infer(request: InferenceRequest) -> dict:
    response = await get_hub().infer(request)
    if response.error:
        raise HTTPException(status_code=503, detail=response.error)
    return response.model_dump()
