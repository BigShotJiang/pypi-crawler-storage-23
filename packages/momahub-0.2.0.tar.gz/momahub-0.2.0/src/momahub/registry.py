"""SQLite-backed node registry — survives hub restarts."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Optional

from .models import NodeInfo, NodeStatus

_DDL = """
CREATE TABLE IF NOT EXISTS nodes (
    node_id       TEXT PRIMARY KEY,
    url           TEXT NOT NULL,
    gpu_model     TEXT NOT NULL DEFAULT 'unknown',
    vram_gb       REAL NOT NULL DEFAULT 11.0,
    models        TEXT NOT NULL DEFAULT '[]',   -- JSON list
    status        TEXT NOT NULL DEFAULT 'online',
    tokens_served INTEGER NOT NULL DEFAULT 0,
    queue_depth   INTEGER NOT NULL DEFAULT 0,
    registered_at REAL NOT NULL,
    last_seen     REAL NOT NULL
);
"""


class NodeRegistry:
    """Thin SQLite wrapper; all reads/writes are synchronous (thread-safe via WAL).

    The hub uses this as its authoritative store. The in-memory dict in MoMaHub
    is a hot cache populated from here on startup.
    """

    def __init__(self, db_path: str | Path = ".momahub/registry.db") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(_DDL)
        self._conn.commit()

    # ------------------------------------------------------------------

    def upsert(self, node: NodeInfo) -> None:
        now = time.time()
        self._conn.execute(
            """
            INSERT INTO nodes
              (node_id, url, gpu_model, vram_gb, models, status,
               tokens_served, queue_depth, registered_at, last_seen)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(node_id) DO UPDATE SET
              url           = excluded.url,
              gpu_model     = excluded.gpu_model,
              vram_gb       = excluded.vram_gb,
              models        = excluded.models,
              status        = excluded.status,
              tokens_served = nodes.tokens_served + excluded.tokens_served,
              queue_depth   = excluded.queue_depth,
              last_seen     = excluded.last_seen
            """,
            (
                node.node_id,
                node.url,
                node.gpu_model,
                node.vram_gb,
                json.dumps(node.models),
                node.status.value,
                node.tokens_served,
                node.queue_depth,
                now,
                now,
            ),
        )
        self._conn.commit()

    def delete(self, node_id: str) -> bool:
        cur = self._conn.execute("DELETE FROM nodes WHERE node_id = ?", (node_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def get(self, node_id: str) -> Optional[NodeInfo]:
        row = self._conn.execute(
            "SELECT * FROM nodes WHERE node_id = ?", (node_id,)
        ).fetchone()
        return self._row_to_node(row) if row else None

    def list_all(self) -> list[NodeInfo]:
        rows = self._conn.execute("SELECT * FROM nodes ORDER BY registered_at").fetchall()
        return [self._row_to_node(r) for r in rows]

    def heartbeat(self, node_id: str, queue_depth: int = 0,
                  tokens_delta: int = 0) -> bool:
        now = time.time()
        cur = self._conn.execute(
            """UPDATE nodes
               SET last_seen     = ?,
                   status        = 'online',
                   queue_depth   = ?,
                   tokens_served = tokens_served + ?
               WHERE node_id = ?""",
            (now, queue_depth, tokens_delta, node_id),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def mark_stale(self, ttl_s: float = 30.0) -> list[str]:
        """Mark nodes that missed heartbeats as offline. Return affected IDs."""
        cutoff = time.time() - ttl_s
        cur = self._conn.execute(
            """UPDATE nodes SET status = 'offline'
               WHERE last_seen < ? AND status != 'offline'
               RETURNING node_id""",
            (cutoff,),
        )
        stale_ids = [row[0] for row in cur.fetchall()]
        self._conn.commit()
        return stale_ids

    def add_tokens(self, node_id: str, tokens: int) -> None:
        self._conn.execute(
            "UPDATE nodes SET tokens_served = tokens_served + ? WHERE node_id = ?",
            (tokens, node_id),
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_node(row: tuple) -> NodeInfo:
        (node_id, url, gpu_model, vram_gb, models_json, status,
         tokens_served, queue_depth, registered_at, last_seen) = row
        return NodeInfo(
            node_id=node_id,
            url=url,
            gpu_model=gpu_model,
            vram_gb=vram_gb,
            models=json.loads(models_json),
            status=NodeStatus(status),
            tokens_served=tokens_served,
            queue_depth=queue_depth,
        )
