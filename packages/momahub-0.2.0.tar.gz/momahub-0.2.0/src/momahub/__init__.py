"""MoMa Hub v0.2 — distributed AI inference on consumer GPUs.

Quick start:
    from momahub import MoMaHub, NodeInfo, InferenceRequest

    hub = MoMaHub()                           # persistent SQLite registry
    hub.register(NodeInfo(
        node_id="gpu0", url="http://localhost:11434",
        gpu_model="GTX 1080 Ti", models=["qwen2.5:7b"],
    ))

    import asyncio
    resp = asyncio.run(hub.infer(InferenceRequest(model="qwen2.5:7b", prompt="Hello")))
    print(resp.content)
"""

from .circuit_breaker import CircuitBreaker, CircuitState
from .hub import MoMaHub, get_hub
from .models import (
    HeartbeatPayload,
    HubStats,
    InferenceRequest,
    InferenceResponse,
    NodeInfo,
    NodeStatus,
)
from .registry import NodeRegistry

__version__ = "0.2.0"
__all__ = [
    "MoMaHub",
    "get_hub",
    "NodeInfo",
    "NodeStatus",
    "HeartbeatPayload",
    "InferenceRequest",
    "InferenceResponse",
    "HubStats",
    "CircuitBreaker",
    "CircuitState",
    "NodeRegistry",
]
