"""MoMa Hub v0.2 — SQLite-backed registry, circuit breakers, weighted routing."""

from __future__ import annotations

import asyncio
import random
import time
from pathlib import Path
from typing import Optional

import httpx

from .circuit_breaker import CircuitBreaker, CircuitState
from .models import (
    HubStats,
    InferenceRequest,
    InferenceResponse,
    NodeInfo,
    NodeStatus,
)
from .registry import NodeRegistry

# How long without a heartbeat before a node is marked offline
NODE_TTL_S = 30.0
# Delay (ms) before sending a hedged duplicate request
HEDGE_DELAY_MS = 500


class MoMaHub:
    """Central registry and router for Ollama inference nodes.

    v0.2: SQLite-backed persistence, per-atom circuit breakers,
    queue-depth-weighted routing, contribution tracking.
    """

    def __init__(self, db_path: str | Path = ".momahub/registry.db") -> None:
        self._registry = NodeRegistry(db_path)
        # Hot cache: node_id → NodeInfo (populated from DB on startup)
        self._nodes: dict[str, NodeInfo] = {
            n.node_id: n for n in self._registry.list_all()
        }
        # Per-node circuit breakers (not persisted — reset on restart is fine)
        self._breakers: dict[str, CircuitBreaker] = {
            n.node_id: CircuitBreaker() for n in self._nodes.values()
        }

    # ------------------------------------------------------------------
    # Registry operations
    # ------------------------------------------------------------------

    def register(self, node: NodeInfo) -> NodeInfo:
        self._nodes[node.node_id] = node
        if node.node_id not in self._breakers:
            self._breakers[node.node_id] = CircuitBreaker()
        self._registry.upsert(node)
        return node

    def deregister(self, node_id: str) -> bool:
        if node_id not in self._nodes:
            return False
        del self._nodes[node_id]
        self._breakers.pop(node_id, None)
        return self._registry.delete(node_id)

    def get_node(self, node_id: str) -> Optional[NodeInfo]:
        return self._nodes.get(node_id)

    def list_nodes(self, status: Optional[NodeStatus] = None) -> list[NodeInfo]:
        nodes = list(self._nodes.values())
        if status is not None:
            nodes = [n for n in nodes if n.status == status]
        return nodes

    def heartbeat(self, node_id: str, queue_depth: int = 0,
                  tokens_delta: int = 0) -> bool:
        node = self._nodes.get(node_id)
        if node is None:
            return False
        node.status = NodeStatus.ONLINE
        node.queue_depth = queue_depth
        node.tokens_served += tokens_delta
        # Reset circuit breaker if node is coming back online
        if self._breakers[node_id].state != CircuitState.CLOSED:
            self._breakers[node_id].reset()
        self._registry.heartbeat(node_id, queue_depth, tokens_delta)
        return True

    def expire_stale_nodes(self) -> list[str]:
        """Mark nodes that missed heartbeats as offline. Called by watchdog."""
        stale_ids = self._registry.mark_stale(NODE_TTL_S)
        for node_id in stale_ids:
            if node_id in self._nodes:
                self._nodes[node_id].status = NodeStatus.OFFLINE
        return stale_ids

    def circuit_state(self, node_id: str) -> Optional[str]:
        b = self._breakers.get(node_id)
        return b.state.value if b else None

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def _candidates(self, model: str) -> list[NodeInfo]:
        """Return online, circuit-CLOSED nodes serving `model`, weighted-sorted."""
        nodes = [
            n for n in self._nodes.values()
            if n.status == NodeStatus.ONLINE
            and self._breakers.get(n.node_id, CircuitBreaker()).allow_request()
        ]
        # Filter to nodes that have the model; fall back to all online nodes
        # (Ollama will pull the model on demand if not present)
        with_model = [n for n in nodes if model in n.models]
        pool = with_model if with_model else nodes
        # Sort by weighted score descending: prefer low queue depth, high VRAM
        pool.sort(
            key=lambda n: (1.0 / (n.queue_depth + 1)) * (n.vram_gb / 11.0),
            reverse=True,
        )
        return pool

    async def infer(self, request: InferenceRequest) -> InferenceResponse:
        candidates = self._candidates(request.model)
        if not candidates:
            return InferenceResponse(
                node_id="none", model=request.model, content="",
                error="No online nodes available for model: " + request.model,
            )

        if request.hedged and len(candidates) >= 2:
            return await self._hedged_infer(request, candidates[:2])

        node = candidates[0]
        return await self._call_node(node, request)

    async def _hedged_infer(self, request: InferenceRequest,
                            pair: list[NodeInfo]) -> InferenceResponse:
        """Send to primary; if slow, also send to backup and return fastest."""
        primary_task = asyncio.create_task(self._call_node(pair[0], request))
        try:
            return await asyncio.wait_for(asyncio.shield(primary_task),
                                          timeout=HEDGE_DELAY_MS / 1000)
        except asyncio.TimeoutError:
            pass
        # Hedge: fire backup
        backup_task = asyncio.create_task(self._call_node(pair[1], request))
        done, pending = await asyncio.wait(
            [primary_task, backup_task],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
        return done.pop().result()

    async def _call_node(self, node: NodeInfo,
                         request: InferenceRequest) -> InferenceResponse:
        breaker = self._breakers.get(node.node_id, CircuitBreaker())
        if not breaker.allow_request():
            return InferenceResponse(
                node_id=node.node_id, model=request.model, content="",
                error=f"Circuit OPEN for node {node.node_id}",
            )

        node.queue_depth += 1
        t0 = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                payload: dict = {
                    "model": request.model,
                    "prompt": request.prompt,
                    "stream": False,
                    "options": {
                        "temperature": request.temperature,
                        "num_predict": request.max_tokens,
                    },
                }
                if request.system:
                    payload["system"] = request.system

                resp = await client.post(f"{node.url}/api/generate", json=payload)
                resp.raise_for_status()
                data = resp.json()

            latency_ms = (time.monotonic() - t0) * 1000
            out_tokens = data.get("eval_count", 0)
            in_tokens = data.get("prompt_eval_count", 0)

            # Update contribution counter
            node.tokens_served += in_tokens + out_tokens
            self._registry.add_tokens(node.node_id, in_tokens + out_tokens)

            breaker.record_success()
            return InferenceResponse(
                node_id=node.node_id,
                model=request.model,
                content=data.get("response", ""),
                input_tokens=in_tokens,
                output_tokens=out_tokens,
                latency_ms=latency_ms,
            )
        except Exception as exc:
            breaker.record_failure()
            return InferenceResponse(
                node_id=node.node_id, model=request.model, content="",
                error=str(exc),
            )
        finally:
            node.queue_depth = max(0, node.queue_depth - 1)

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> HubStats:
        nodes = list(self._nodes.values())
        all_models: list[str] = []
        total_tokens = 0
        for n in nodes:
            all_models.extend(n.models)
            total_tokens += n.tokens_served
        return HubStats(
            total_nodes=len(nodes),
            online_nodes=sum(1 for n in nodes if n.status == NodeStatus.ONLINE),
            total_models=len(all_models),
            unique_models=sorted(set(all_models)),
            total_tokens_served=total_tokens,
        )

    def close(self) -> None:
        self._registry.close()


# Module-level singleton for single-process use
_default_hub: Optional[MoMaHub] = None


def get_hub(db_path: str = ".momahub/registry.db") -> MoMaHub:
    global _default_hub
    if _default_hub is None:
        _default_hub = MoMaHub(db_path)
    return _default_hub
