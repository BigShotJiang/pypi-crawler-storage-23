"""Pydantic models for MoMa Hub."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class NodeStatus(str, Enum):
    ONLINE = "online"
    BUSY = "busy"
    OFFLINE = "offline"


class NodeInfo(BaseModel):
    """A registered inference node (one Ollama instance on one GPU)."""

    node_id: str                            # e.g. "home-gpu-0"
    url: str                                # e.g. "http://192.168.1.10:11434"
    gpu_model: str = "unknown"              # e.g. "GTX 1080 Ti"
    vram_gb: float = 11.0                   # usable VRAM in GB
    models: list[str] = Field(default_factory=list)
    status: NodeStatus = NodeStatus.ONLINE
    queue_depth: int = 0                    # current pending requests
    tokens_served: int = 0                  # lifetime contribution counter


class HeartbeatPayload(BaseModel):
    queue_depth: int = 0
    tokens_delta: int = 0                   # tokens served since last heartbeat


class InferenceRequest(BaseModel):
    """A single inference request routed through MoMa Hub."""

    model: str
    prompt: str
    system: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 512
    stream: bool = False
    hedged: bool = False                    # send to 2 nodes, return fastest


class InferenceResponse(BaseModel):
    """Result from a node inference call."""

    node_id: str
    model: str
    content: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
    error: Optional[str] = None


class HubStats(BaseModel):
    """Aggregate stats for the hub registry."""

    total_nodes: int
    online_nodes: int
    total_models: int
    unique_models: list[str] = Field(default_factory=list)
    total_tokens_served: int = 0
