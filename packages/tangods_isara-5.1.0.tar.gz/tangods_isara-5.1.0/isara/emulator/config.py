"""Configuration handling for the Isara emulator."""

import dataclasses
import tomllib
from collections.abc import Iterator
from dataclasses import dataclass, field, fields
from enum import StrEnum
from io import BufferedIOBase

from isara.emulator.base import PUCKS_NUM, Position

_DEFAULT_PUCKS_PRESENT: list = []
_DEFAULT_OPERATE_PORT = 10000
_DEFAULT_MONITOR_PORT = 1000
_DEFAULT_INITIAL_POSITION = Position.HOME


class InvalidConfiguration(Exception):
    """Exception raised for invalid configuration files."""


class _MissingConfigurationField(InvalidConfiguration):
    def __init__(self, field_name: str) -> None:
        super().__init__(f"Missing '{field_name}' configuration field.")


class IsaraModel(StrEnum):
    """Supported Isara models."""

    Isara1 = "ISARA1"
    Isara2 = "ISARA2"


def _no_pucks_present() -> list[bool]:
    return [False] * PUCKS_NUM


@dataclass
class Config:
    """Configuration for the Isara emulator."""

    model: IsaraModel
    initial_tool: str

    #
    # optional configs
    #
    pucks_present: list[bool] = field(default_factory=_no_pucks_present)
    operate_port: int = _DEFAULT_OPERATE_PORT
    monitor_port: int = _DEFAULT_OPERATE_PORT
    initial_position: Position = _DEFAULT_INITIAL_POSITION


def _validate_model(model: str) -> IsaraModel:
    """Check that the specified Isara model is valid.

    If valid, model is converted to Isara model enum.
    """
    try:
        return IsaraModel(model)
    except ValueError as exc:
        msg = (
            f"Invalid model: {model}. "
            f"It must be one of: {[model.value for model in IsaraModel]}."
        )
        raise InvalidConfiguration(msg) from exc


def _validate_initial_position(initial_position: str) -> Position:
    """Check that specified initial position is valid.

    if valid, position is converted to Position enum.
    """
    try:
        return Position(initial_position)
    except ValueError as exc:
        msg = (
            f"Invalid initial position of Robot Arm: {initial_position}. "
            f"It must be one of: {[pos.value for pos in Position]}."
        )
        raise InvalidConfiguration(msg) from exc


def _validate_pucks_present(pucks: list[int]) -> list[bool]:
    """Validate and transform `pucks_present` configurable.

    Check that all present puck positions are valid.

    Converts 'pucks present' from a list of positions to a boolean list.
    This new list is PUCKS_NUM long, with True representing
    a present puck and False representing absent one.
    """
    res = _no_pucks_present()

    for puck_num in pucks:
        if puck_num < 1 or puck_num > PUCKS_NUM:
            msg = (
                f"Invalid puck position {puck_num} in 'pucks_present', "
                f"must be a number between 1 and {PUCKS_NUM}."
            )
            raise InvalidConfiguration(msg)

        res[puck_num - 1] = True

    return res


def _validate_required_fields(config_data: dict) -> None:
    """Check that all required configuration fields are present."""

    def required_config_fields() -> Iterator[str]:
        """List all required configuration fields."""
        for f in fields(Config):
            if (
                f.default is dataclasses.MISSING
                and f.default_factory is dataclasses.MISSING
            ):
                yield f.name

    for required_key in required_config_fields():
        if required_key not in config_data:
            raise _MissingConfigurationField(required_key)


def _validate(config: dict) -> Config:
    """Check that specified configuration is valid.

    If valid, a Config object is created.
    """
    _validate_required_fields(config)

    return Config(
        model=_validate_model(config["model"]),
        initial_tool=config["initial_tool"],
        pucks_present=_validate_pucks_present(
            config.get("pucks_present", _DEFAULT_PUCKS_PRESENT)
        ),
        operate_port=config.get("operate_port", _DEFAULT_OPERATE_PORT),
        monitor_port=config.get("monitor_port", _DEFAULT_MONITOR_PORT),
        initial_position=_validate_initial_position(
            config.get("initial_position", _DEFAULT_INITIAL_POSITION)
        ),
    )


def load_config(file_content: BufferedIOBase) -> Config:
    """Loads and validates content of a config toml file.

    Example of config file could be found in readme.md Configuration section.

    Args:
        file_content: Binary content of the TOML configuration file.

    Returns:
        A Config object containing the configuration.

    Raises:
        InvalidConfiguration: If the configuration is invalid.
    """
    config_data = tomllib.load(file_content)["isara_configuration"]
    return _validate(config_data)
