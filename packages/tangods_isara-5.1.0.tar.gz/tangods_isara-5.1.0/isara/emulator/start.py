from isara.emulator.base import (
    log,
    logging_enable,
)
from isara.emulator.config import Config, IsaraModel
from isara.emulator.isara1 import Isara1Emulator
from isara.emulator.isara2 import Isara2Emulator


def start_emulator(config: Config, enable_logging=False):
    logging_enable(enable_logging)

    def init_model():
        classes = {
            IsaraModel.Isara1: Isara1Emulator,
            IsaraModel.Isara2: Isara2Emulator,
        }
        klass = classes[config.model]

        return klass(
            config.operate_port,
            config.monitor_port,
            config.initial_position,
            config.initial_tool,
            config.pucks_present,
        )

    isara = init_model()

    log(
        f"emulating {config.model} API\n"
        f" operate port: {config.operate_port}\n"
        f" monitor port: {config.monitor_port}\n"
        f" initial position: {config.initial_position}\n"
        f" initial tool: {config.initial_tool}"
    )

    isara.start()

    return isara
