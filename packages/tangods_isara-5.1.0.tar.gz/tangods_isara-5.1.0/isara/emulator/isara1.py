"""Emulator for ISARA1."""

from isara.client.isara1 import Isara1ConnectionClient

from .base import (
    CommandName,
    InvalidToolNumber,
    IsaraBaseEmulator,
    Paths,
    encode,
    get_command_args,
    log,
)


class Isara1Emulator(IsaraBaseEmulator):
    """Emulator for Isara1 robot, the first model, aka the blue robot at BioMAX."""

    TOOL_MAPPING = Isara1ConnectionClient.TOOL_MAPPING

    def _handle_state_command(self) -> str:
        def sample_vals(sample, no_sample="") -> tuple[str, str]:
            if sample is None:
                return no_sample, no_sample

            return str(sample.puck), str(sample.pin)

        puck_on_diff, pin_on_diff = sample_vals(self._robot_arm.get_sample_on_diff())
        puck_on_tool_a, pin_on_tool_a = sample_vals(
            self._robot_arm.get_sample_on_tool_a()
        )
        puck_on_tool_b, pin_on_tool_b = sample_vals(
            self._robot_arm.get_sample_on_tool_b(), "0"
        )

        state = [
            encode(self._power_on),  # 0 = power
            encode(self._remote_mode),  # 1 = auto mode status
            "0",  # 2 = default status
            f"{self._current_tool_name}",  # 3 = tool name
            self._robot_arm.get_path_name(),  # 4 = path name
            puck_on_tool_a,  # 5 = puck number of sample mounted on tool
            pin_on_tool_a,  # 6 = number of the sample on tool
            puck_on_diff,  # 7 = puck number of sample mounted on diffractometer
            pin_on_diff,  # 8 = number of sample mounted on diffractometer
            "",  # 9 = number of plate on tool
            "",  # 10 = not used
            "",  # 11 = barcode number
            encode(self._robot_arm.is_moving()),  # 12 = path running
            "0",  # 13 = LN2 regulation running Dewar
            "",  # 14 = not used
            f"{self._robot_arm.speed.ratio}",  # 15 = robot speed ratio (%)
            "1.16",  # 16 = Goniometer position (X)
            "1.17",  # 17 = Goniometer position (Y)
            "1.18",  # 18 = Goniometer position (Z)
            "",  # 19 = not used
            # 20 = puck number of sample mounted on tool 2 (double gripper)
            puck_on_tool_b,
            # 21 = number of the sample on tool 2 (double gripper)
            pin_on_tool_b,
            "",  # 22 = soak counter
        ]

        return f"state({','.join(state)})"

    def _handle_di_command(self) -> str:
        return "di(" + "0" * 99 + ")"

    def _handle_do_command(self) -> str:
        return "do(" + "0" * 99 + ")"

    def _handle_di2_command(self) -> str:
        values = [encode(value) for value in self._pucks_present]
        return f"di2({''.join(values)})"

    def _handle_clear_memory_command(self) -> str:
        return "clear memory"

    def _handle_remote_speed_off_command(self) -> str:
        return "remotespeedoff"

    def _handle_remote_speed_on_command(self) -> str:
        return "remotespeedon"

    def _handle_home_command(self, *args) -> str:
        tool_number = int(args[0])
        self._robot_arm.run_path(Paths.HOME)
        try:
            self.set_tool_by_number(tool_number)
        except InvalidToolNumber as exc:
            log(f"invalid tool number {tool_number=} {exc=}")
            return "Inconsistent parameters"
        return "home"

    def _handle_toolcal_command(self, _tool_no) -> str:
        return "toolcal"

    def _handle_position_command(self) -> str:
        return "position(0.1,0.2,0.3,0.4,0.5,0.6)"

    def _handle_monitor_command(self, command: str) -> str:
        # handle ISARA1 specific monitor commands
        if command == CommandName.POSITION:
            return self._handle_position_command()
        if command == CommandName.DI2:
            return self._handle_di2_command()

        return super()._handle_monitor_command(command)

    def _handle_get_plate_command(self) -> str:
        return "getplate"

    def _handle_get_put_plate_command(self) -> str:
        return "getputplate"

    def _handle_put_plate_command(self) -> str:
        return "putplate"

    # This could use a rewrite so that there fewer `return` statements (PLR0911).
    def _handle_operate_command(self, command: str) -> str:  # noqa: PLR0911
        if command.startswith(CommandName.HOME):
            args = get_command_args(CommandName.HOME, command)
            return self._handle_home_command(*args)

        if command.startswith(CommandName.TOOLCAL):
            (tool_no,) = get_command_args(CommandName.TOOLCAL, command)
            return self._handle_toolcal_command(tool_no)

        if command == CommandName.CLEAR_MEMORY:
            return self._handle_clear_memory_command()

        if command == CommandName.REMOTE_SPEED_OFF:
            return self._handle_remote_speed_off_command()

        if command == CommandName.REMOTE_SPEED_ON:
            return self._handle_remote_speed_on_command()

        # Plate operations
        if command.startswith(CommandName.GET_PLATE):
            return self._handle_get_plate_command()
        if command.startswith(CommandName.GET_PUT_PLATE):
            return self._handle_get_put_plate_command()
        if command.startswith(CommandName.PUT_PLATE):
            return self._handle_put_plate_command()

        return super()._handle_operate_command(command)
