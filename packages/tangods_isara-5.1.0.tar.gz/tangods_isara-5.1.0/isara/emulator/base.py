import asyncio
import sys
import traceback
from asyncio import (
    Event,
    IncompleteReadError,
    StreamReader,
    StreamWriter,
)
from enum import StrEnum
from queue import Queue

from isara.client.base import Sample

from .runner import Runner
from .watchable_attrs import WatchableAttrsMixin

PUCKS_NUM = 29

#
# Travel time between robot arm positions, in seconds.
# This is time at 100% speed setting.
#
NOMINAL_TRAVEL_TIME = 1.2

#
# Time it take to exchange sample on the diffractometer, in seconds.
#
SAMPLE_EXCHANGE_TIME = 0.5

_logging_enabled = False


class CommandName(StrEnum):
    """Command names."""

    DI = "di"
    DO = "do"
    ON = "on"
    DI2 = "di2"
    GET = "get"
    OFF = "off"
    PUT = "put"
    HOME = "home"
    TRAJ = "traj"
    ABORT = "abort"
    STATE = "state"
    RESET = "reset"
    TOOLCAL = "toolcal"
    MESSAGE = "message"
    OPENLID = "openlid"
    SPEEDUP = "speedup"
    CLOSELID = "closelid"
    POSITION = "position"
    GET_PLATE = "getplate"
    GET_PUT_PLATE = "getputplate"
    PUT_PLATE = "putplate"
    SPEEDDOWN = "speeddown"
    CLEARMEMORY = "clearmemory"  # Isara2
    CLEAR_MEMORY = "clear memory"  # Isara1
    REMOTE_SPEED_ON = "remotespeedon"  # Isara1 only
    REMOTE_SPEED_OFF = "remotespeedoff"  # Isara1 only


def logging_enable(enable: bool) -> None:
    global _logging_enabled
    _logging_enabled = enable


def log(msg: str):
    if _logging_enabled:
        print(msg)
        sys.stdout.flush()


class InvalidToolName(Exception):
    """Tool name is invalid."""


class InvalidToolNumber(Exception):
    """Tool number is invalid."""


async def _read_command(connection_name: str, reader: StreamReader) -> str:
    cmd = await reader.readuntil(b"\r")
    log(f"{connection_name}> {cmd!r}")

    # chop off trailing \r and make a string
    return cmd[:-1].decode()


async def _write_reply(connection_name: str, writer: StreamWriter, reply: str):
    data = (reply + "\r").encode()
    writer.write(data)
    await writer.drain()

    log(f"{connection_name}< {data!r}")


def _encode_list(lst) -> str:
    encoded = [encode(v) for v in lst]
    return ",".join(encoded)


def encode(val):
    t = type(val)

    if t == bool:
        return "1" if val else "0"

    if t == list:
        return _encode_list(val)
    return None


def get_command_args(command_name: str, command: str) -> list:
    args_str = command[len(command_name) + 1 : -1]
    return args_str.split(",")


class Position(StrEnum):
    """Position names."""

    HOME = "HOME"
    SOAK = "SOAK"


class Paths(StrEnum):
    """Path names."""

    HOME = "home"
    SOAK = "soak"
    GET = "get"
    PUT = "put"
    GETPUT = "getput"


PATH_POSITIONS = {
    Paths.HOME: Position.HOME,
    Paths.SOAK: Position.SOAK,
}


class Messages(StrEnum):
    """Emulated messages in the 'state' reply."""

    # system nominal
    SYSTEM_OK = "System OK for operation"

    # message for 'empty mount' error on Put command
    PUT_EMPTY_MOUNT_ERR = "ERROR 2130 - User acknowledgement required"

    # message for 'empty mount' error on GetPut command
    GETPUT_EMPTY_MOUNT_ERR = "ERROR 4130 - User acknowledgement required"


class _Speed:
    # TODO: check with the real robot for supported speed ratios
    RATIOS = ["0.01", "1.0", "10.0", "50.0", "75.0", "100.0"]

    def __init__(self):
        self._current_ration_idx = self._max_idx()

    def _max_idx(self):
        return len(self.RATIOS) - 1

    @property
    def ratio(self) -> str:
        return self.RATIOS[self._current_ration_idx]

    @property
    def decimal_ratio(self) -> float:
        """Current speed ratio as decimal percentage number.

        Returns:
            value between 0.0 and 1.0
        """
        return float(self.ratio) / 100.0

    def increase(self):
        if self._current_ration_idx == self._max_idx():
            # already at highest possible ratio
            return

        self._current_ration_idx += 1

    def decrease(self):
        if self._current_ration_idx == 0:
            # already at lowest possible speed ratio
            return

        self._current_ration_idx -= 1


class _RobotArm:
    def __init__(self, initial_position: Position):
        self._position: None | Position = initial_position
        self._path: Paths | None = None
        self._sample_on_diff: Sample | None = None
        self._sample_on_tool_a: Sample | None = None
        self._sample_on_tool_b: Sample | None = None
        self.speed: _Speed = _Speed()

    def run_path(self, path: Paths):
        assert self._position is not None
        assert self._path is None
        asyncio.create_task(self._run_trajectory(path))

    def do_get(self):
        asyncio.create_task(self._run_get_command())

    def do_put(self, puck_number: int, pin_number: int):
        asyncio.create_task(self._run_put_command(puck_number, pin_number))

    def do_getput(self, puck_number: int, pin_number: int):
        asyncio.create_task(self._run_getput_command(puck_number, pin_number))

    async def _emulate_travel_time(self) -> None:
        """Emulate that it take time to reach new position."""
        # Scale travel time according to current speed ratio.
        await asyncio.sleep(NOMINAL_TRAVEL_TIME / self.speed.decimal_ratio)

    async def _run_get_command(self):
        # emulate moving to diffractometer
        self._start_trajectory(Paths.GET)
        await self._emulate_travel_time()

        # the sample has been removed from the diffractometer
        self._sample_on_diff = None

        # emulate going back to soak position
        await self._emulate_travel_time()
        self._trajectory_finished(Paths.SOAK)

    async def _run_put_command(self, puck_number: int, pin_number: int):
        # emulate moving to diffractometer
        self._start_trajectory(Paths.PUT)
        await self._emulate_travel_time()

        # the sample have been mounted on the diffractometer
        self._sample_on_diff = Sample(puck_number, pin_number)

        # emulate going back to soak position
        await self._emulate_travel_time()
        self._trajectory_finished(Paths.SOAK)

    async def _run_getput_command(self, puck_number: int, pin_number: int):
        # emulate moving to diffractometer
        self._start_trajectory(Paths.GETPUT)
        await self._emulate_travel_time()

        # emulate exchanging sample on the diffractometer
        self._sample_on_diff = None
        await asyncio.sleep(SAMPLE_EXCHANGE_TIME)
        self._sample_on_diff = Sample(puck_number, pin_number)

        # emulate going back to soak position
        await self._emulate_travel_time()
        self._trajectory_finished(Paths.SOAK)

    def _start_trajectory(self, path: Paths):
        # start moving to new position
        log(f"running path {path.value}")
        self._position = None
        self._path = path

    def _trajectory_finished(self, path: Paths):
        # we have arrived at our new position
        self._position = PATH_POSITIONS.get(path)
        self._path = None
        log(f"reached {self._position}")

    async def _run_trajectory(self, path: Paths):
        self._start_trajectory(path)
        await self._emulate_travel_time()
        self._trajectory_finished(path)

    def is_moving(self) -> bool:
        return self._position is None

    def get_position(self) -> None | Position:
        return self._position

    def get_position_name(self) -> str:
        if self._position is None:
            return "UNDEFINED"

        return self._position.value

    def get_path_name(self) -> str:
        if self._path is None:
            return ""

        return self._path.value

    def get_sample_on_diff(self) -> Sample | None:
        return self._sample_on_diff

    def set_sample_on_diff(self, sample: Sample | None):
        self._sample_on_diff = sample

    def set_sample_on_tool_a(self, sample: Sample | None):
        self._sample_on_tool_a = sample

    def get_sample_on_tool_a(self) -> Sample | None:
        return self._sample_on_tool_a

    def set_sample_on_tool_b(self, sample: Sample | None):
        self._sample_on_tool_b = sample

    def get_sample_on_tool_b(self) -> Sample | None:
        return self._sample_on_tool_b

    def has_sample_on_diff(self) -> bool:
        return self._sample_on_diff is not None

    def change_speed(self, increase_speed: bool):
        if increase_speed:
            self.speed.increase()
        else:
            self.speed.decrease()


class _DewarLid:
    OPEN_POS = 10
    CLOSED_POS = 0

    def __init__(self):
        self._position = self.OPEN_POS
        self._target_position = None
        self._target_position_set = Event()

    def start(self):
        asyncio.create_task(self._run())

    def is_moving(self) -> bool:
        return self._target_position is not None

    async def _run(self):
        async def move_lid():
            while self._position != self._target_position:
                step = 1 if self._position < self._target_position else -1
                self._position += step
                await asyncio.sleep(0.6)

            self._target_position = None
            self._target_position_set.clear()

        while True:
            await self._target_position_set.wait()
            await move_lid()

    def open(self):
        self._target_position = self.OPEN_POS
        self._target_position_set.set()

    def close(self):
        self._target_position = self.CLOSED_POS
        self._target_position_set.set()


class IsaraBaseEmulator(Runner, WatchableAttrsMixin):
    """Contains code shared by Isara1 and Isara2 emulators."""

    TOOL_MAPPING: dict[int, str] = {}

    # some emulated empty positions
    EMPTY_POSITIONS = {
        (1, 15),
        (1, 16),
    }

    def __init__(
        self,
        operate_port: int,
        monitor_port: int,
        initial_position: Position,
        initial_tool_name: str,
        pucks_present: list[bool],
    ):
        super().__init__()

        # TCP ports to use
        self._operate_port = operate_port
        self._monitor_port = monitor_port

        self._message = Messages.SYSTEM_OK
        #
        # emulates the robot PLC modes, i.e. the key switch modes
        #
        # we only emulate:
        # * remote mode: `_remote_mode == True`
        # * manual mode: `_remote_mode == False`
        #
        self._remote_mode = True
        self._door_closed = True
        self._power_on = True

        self.set_tool_by_name(initial_tool_name)
        self._pucks_present = pucks_present

        self._robot_arm = _RobotArm(initial_position)
        self._dewar_lid = _DewarLid()

    #
    # public API for changing the state of the ISARA
    #

    def set_remote_mode(self):
        self._remote_mode = True

    def set_manual_mode(self):
        self._remote_mode = False

    def set_door_closed(self, is_closed: bool):
        self._door_closed = is_closed

    def set_tool_by_name(self, tool_name: str) -> None:
        if tool_name in self.TOOL_MAPPING.values():
            self._current_tool_name = tool_name
        else:
            raise InvalidToolName

    def set_tool_by_number(self, tool_number: int) -> None:
        try:
            name = self.TOOL_MAPPING[tool_number]
        except KeyError as exc:
            raise InvalidToolNumber from exc
        else:
            self.set_tool_by_name(name)

    def set_pucks(self, pucks: list[bool]) -> None:
        """Set which pucks are present in the emulated sample changer's dewar."""
        if len(pucks) == PUCKS_NUM:
            self._pucks_present = pucks
        else:
            raise ValueError(f"Invalid number of pucks, expected number: {PUCKS_NUM}")

    def set_sample_on_diff(self, sample: Sample | None) -> None:
        self._robot_arm.set_sample_on_diff(sample)

    def set_sample_on_tool_a(self, sample: Sample | None) -> None:
        self._robot_arm.set_sample_on_tool_a(sample)

    def set_sample_on_tool_b(self, sample: Sample | None) -> None:
        self._robot_arm.set_sample_on_tool_b(sample)

    #
    # ISARA and ISARA2 common emulation code
    #

    def _is_empty_position(self, puck_number, pin_number):
        return (puck_number, pin_number) in self.EMPTY_POSITIONS

    def _handle_state_command(self):
        # needs model specific implementation
        raise NotImplementedError

    def _handle_di_command(self):
        # needs model specific implementation
        raise NotImplementedError

    def _handle_do_command(self):
        # needs model specific implementation
        raise NotImplementedError

    def _check_plc(self) -> str | None:
        if not self._remote_mode:
            return "Remote mode requested"

        if not self._door_closed:
            return "Doors must be closed"

        return None

    def _handle_on_command(self) -> str:
        plc_err = self._check_plc()
        if plc_err is not None:
            return plc_err

        self._power_on = True
        return "on"

    def _handle_off_command(self) -> str:
        plc_err = self._check_plc()
        if plc_err is not None:
            return plc_err

        self._power_on = False
        return "off"

    def _handle_message_command(self) -> str:
        return "System OK for operation"

    def _handle_speed_command(self, command: str):
        plc_err = self._check_plc()
        if plc_err is not None:
            return plc_err

        self._robot_arm.change_speed(command == CommandName.SPEEDUP)

        return command

    def _handle_reset_command(self) -> str:
        return "reset"

    def _handle_operate_command(self, command: str) -> str:
        if command == CommandName.ON:
            return self._handle_on_command()
        if command == CommandName.OFF:
            return self._handle_off_command()
        if command == CommandName.ABORT:
            return "abort"
        if command in [CommandName.SPEEDUP, CommandName.SPEEDDOWN]:
            return self._handle_speed_command(command)
        if command == CommandName.RESET:
            return self._handle_reset_command()

        assert False, f"unexpected command {command} on operate connection"

    def _handle_monitor_command(self, command: str) -> str:
        if command == CommandName.STATE:
            return self._handle_state_command()
        if command == CommandName.DI:
            return self._handle_di_command()
        if command == CommandName.DO:
            return self._handle_do_command()
        if command == CommandName.MESSAGE:
            return self._handle_message_command()

        assert False, f"unexpected command {command} on monitor connection"

    async def _new_operate_connection(self, reader: StreamReader, writer: StreamWriter):
        log("new operate connection")
        try:
            while True:
                cmd = await _read_command("operate", reader)
                reply = self._handle_operate_command(cmd)

                await _write_reply("operate", writer, reply)
        except IncompleteReadError:
            # connection closed, we are done here
            return
        except:  # noqa: E722
            print(traceback.format_exc())
        finally:
            writer.close()
            await writer.wait_closed()

    async def _new_monitor_connection(self, reader: StreamReader, writer: StreamWriter):
        log("new monitor connection")
        try:
            while True:
                cmd = await _read_command("monitor", reader)
                reply = self._handle_monitor_command(cmd)

                await _write_reply("monitor", writer, reply)
        except IncompleteReadError:
            # connection closed, we are done here
            return
        except:  # noqa: E722
            # unexpected exception
            print(traceback.format_exc())
        finally:
            writer.close()
            await writer.wait_closed()

    async def _run(self, backchannel: Queue):
        self._dewar_lid.start()

        op_srv = await asyncio.start_server(
            self._new_operate_connection, host="0.0.0.0", port=self._operate_port
        )

        mon_srv = await asyncio.start_server(
            self._new_monitor_connection, host="0.0.0.0", port=self._monitor_port
        )

        asyncio.gather(
            op_srv.serve_forever(),
            mon_srv.serve_forever(),
        )

        loop = asyncio.get_running_loop()
        exit_event = asyncio.Event()
        backchannel.put((loop, exit_event))

        await exit_event.wait()
