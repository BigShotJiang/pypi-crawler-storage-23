"""CLI for the Isara emulator."""

import argparse

import isara.emulator.start
from isara.emulator.config import InvalidConfiguration, load_config


def _build_args_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument(
        "config_file",
        type=argparse.FileType("br"),
        metavar="config.toml",
        help="TOML file containing isara configuration.",
    )
    parser.add_argument("--enable-logging", action="store_true")
    return parser


def main() -> None:
    """Main entry point routine for the CLI."""
    args_parser = _build_args_parser()
    args = args_parser.parse_args()
    try:
        isara.emulator.start.start_emulator(
            config=load_config(args.config_file),
            enable_logging=args.enable_logging,
        )
    except InvalidConfiguration as exc:
        print(f"{args.config_file.name}: {exc}")  # noqa: T201
