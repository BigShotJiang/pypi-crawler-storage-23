"""Connection client for robot model "ISARA2"."""

from typing_extensions import override

from .base import (
    IsaraBaseConnectionClient,
    _Attr,
)
from .commands import (
    CommandCache,
    CommandSocket,
)
from .errors import CanNotRunTrajectoryFromSoak


class Isara2ConnectionClient(IsaraBaseConnectionClient):
    """Connection client for robot model "ISARA2"."""

    # Override
    model_name: str = "isara2"

    # Override
    TOOL_MAPPING = {
        0: "ToolChanger",
        1: "Cryotong",
        2: "SingleGripper",
        3: "DoubleGripper",
        4: "MiniSpineGripper",
        5: "RotatingGripper",
        6: "PlateGripper",
        7: "Spare",
        8: "LaserTool",
    }

    #: Offset to the first *puck presence* element in the ``do`` reply values.
    _DO_PUCK_PRESENCE_OFFSET = 56

    # Indices for 'sample on diffractometer' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_DIFF_IDX = 12
    STATE_SAMPLE_PIN_ON_DIFF_IDX = 13

    # Indices for 'sample on tool A' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_TOOL_A_IDX = 8
    STATE_SAMPLE_PIN_ON_TOOL_A_IDX = 9

    # Indices for 'sample on tool B' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_TOOL_B_IDX = 10
    STATE_SAMPLE_PIN_ON_TOOL_B_IDX = 11

    # Override
    _ATTRIBUTES = [
        *IsaraBaseConnectionClient._ATTRIBUTES,
        # state
        _Attr("state", 4, str, "PositionName"),
        _Attr("state", 5, str, "Path"),
        _Attr("state", STATE_SAMPLE_PUCK_ON_TOOL_A_IDX, int, "PuckNumberOnTool"),
        _Attr("state", STATE_SAMPLE_PIN_ON_TOOL_A_IDX, int, "SampleNumberOnTool"),
        _Attr("state", STATE_SAMPLE_PUCK_ON_TOOL_B_IDX, int, "PuckNumberOnToolB"),
        _Attr("state", STATE_SAMPLE_PIN_ON_TOOL_B_IDX, int, "SampleNumberOnToolB"),
        _Attr("state", STATE_SAMPLE_PUCK_ON_DIFF_IDX, int, "PuckNumberOnDiff"),
        _Attr("state", STATE_SAMPLE_PIN_ON_DIFF_IDX, int, "SampleNumberOnDiff"),
        _Attr("state", 14, str, "PlateNumberOnTool"),
        _Attr("state", 15, str, "PlateNumberOnDiff"),
        _Attr("state", 16, str, "Barcode"),
        _Attr("state", 17, bool, "PathRunning"),
        _Attr("state", 18, bool, "PathPause"),
        _Attr("state", 19, float, "SpeedRatio"),
        _Attr("state", 20, bool, "LN2Regulation"),
        _Attr("state", 21, str, "CurrentNumberOfSoaking"),
        _Attr("state", 22, float, "LN2Level"),
        _Attr("state", 26, bool, "GripperDrying"),
        _Attr("state", 28, str, "Message"),
        _Attr("state", 29, str, "BinaryAlarms"),
        _Attr("state", 30, float, "PoseX"),
        _Attr("state", 31, float, "PoseY"),
        _Attr("state", 32, float, "PoseZ"),
        _Attr("state", 33, float, "PoseRX"),
        _Attr("state", 34, float, "PoseRY"),
        _Attr("state", 35, float, "PoseRZ"),
        _Attr("state", 44, str, "CryoVisionData"),
        _Attr("state", 46, bool, "HeatingCablesOn"),
        # do
        _Attr("do", 24, bool, "SampleDetectedOnGonio"),
        _Attr("do", 43, bool, "PathSafe"),  # Arm is parked
        *[  # Puck detection
            _Attr("do", i, bool)
            for i in range(
                _DO_PUCK_PRESENCE_OFFSET,
                _DO_PUCK_PRESENCE_OFFSET + IsaraBaseConnectionClient.PUCKS_NUM,
            )
        ],
    ]

    def __init__(
        self,
        process_sock: CommandSocket,
        status_sock: CommandSocket,
        command_cache_timeout: float,
    ):
        """Initialize instance."""
        super().__init__(process_sock, status_sock)

        self._add_command_cache(
            "state", CommandCache(self._state, command_cache_timeout)
        )
        self._add_command_cache("do", CommandCache(self._do, command_cache_timeout))
        self._add_command_cache("di", CommandCache(self._di, command_cache_timeout))

    # Status commands

    def _di(self) -> list[bool]:
        return self._get_status_command("di", self._DI_REPLY_RE)

    def _do(self) -> list[bool]:
        return self._get_status_command("do", self._DO_REPLY_RE)

    @override
    def get_puck_presence(self) -> list[bool]:
        # Extract the slice of the `do` reply values that contains puck presence info
        first = self._DO_PUCK_PRESENCE_OFFSET
        last = first + self.PUCKS_NUM
        do_values = self._command_caches["do"].value
        return do_values[first:last]

    # General commands

    @override
    def speed_up(self):
        return self._operate("speedup")

    @override
    def speed_down(self):
        return self._operate("speeddown")

    @override
    def openlid(self):
        return self._operate("openlid")

    @override
    def closelid(self):
        return self._operate("closelid")

    @override
    def open_tool_b(self):
        return self._operate("opentoolb")

    @override
    def close_tool_b(self):
        return self._operate("closetoolb")

    # Trajectory commands

    @override
    def home(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()

        cmd = f"traj(home,{tool_number})"
        return self._traj(cmd)

    @override
    def recover(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()

        cmd = f"traj(recover,{tool_number})"
        return self._traj(cmd)

    @override
    def put(self, puck, sample, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        args = f"{tool_number},{puck},{sample},{datamatrix_scan},0,0,0,0,0,0,0,0,0"
        cmd = f"traj(put,{args})"
        return self._traj(cmd)

    @override
    def get(self, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        cmd = f"traj(get,{tool_number},0,0,{datamatrix_scan},0,0,0,0,0,0,0,0,0)"
        return self._traj(cmd)

    @override
    def getput(self, puck, sample, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        args = f"{tool_number},{puck},{sample},{datamatrix_scan},0,0,0,0,0,0,0,0,0"
        cmd = f"traj(getput,{args})"
        return self._traj(cmd)

    @override
    def pick(self, puck, sample, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        cmd = f"traj(pick,{tool_number},{puck},{sample},{datamatrix_scan},0,0,0,0,0)"
        return self._traj(cmd)

    @override
    def datamatrix(self, puck, sample):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        cmd = f"traj(datamatrix,{tool_number},{puck},{sample},0,0,0,0,0,0,0)"
        return self._traj(cmd)

    @override
    def back(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()

        cmd = f"traj(back,{tool_number})"
        return self._traj(cmd)

    @override
    def soak(self, tool_number=None):
        if self.is_in_soak():  # Is this really necessary on Isara2?
            raise CanNotRunTrajectoryFromSoak("soak")
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(soak,{tool_number})"
        return self._traj(cmd)

    @override
    def dry(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(dry,{tool_number})"
        return self._traj(cmd)

    @override
    def teachgonio(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(teachgonio,{tool_number})"
        return self._traj(cmd)

    @override
    def teachpuck(self, puck, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(teachpuck,{tool_number},{puck})"
        return self._traj(cmd)

    @override
    def teachdewar(self, puck, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(teachdewar,{tool_number},{puck})"
        return self._traj(cmd)

    @override
    def change_tool(self, tool_number):
        cmd = f"traj(changetool,{tool_number})"
        return self._traj(cmd)

    @override
    def change_tool_and_calibrate(self, tool_number: int) -> str:
        raise NotImplementedError

    @override
    def toolcal(self):
        tool_number = self._get_current_tool()

        cmd = f"traj(toolcal,{tool_number})"
        return self._traj(cmd)

    @override
    def gotodiff(self, puck, sample):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        cmd = f"traj(gotodiff,{tool_number},{puck},{sample},0,0,0,0,0,0)"
        return self._traj(cmd)

    # Maintenance commands

    @override
    def clear_memory(self):
        return self._operate("clearmemory")

    # Hot puck commands

    @override
    def putht(self, puck, sample, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        args = f"{tool_number},{puck},{sample},{datamatrix_scan},0,0,0,0,0,0,0,0,0"
        cmd = f"traj(putht,{args})"
        return self._traj(cmd)

    @override
    def getht(self, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        cmd = f"traj(getht,{tool_number},0,0,{datamatrix_scan},0,0,0,0,0,0,0,0,0)"
        return self._traj(cmd)

    @override
    def getputht(self, puck, sample, datamatrix_scan=0):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()

        args = f"{tool_number},{puck},{sample},{datamatrix_scan},0,0,0,0,0,0,0,0,0"
        cmd = f"traj(getputht,{args})"
        return self._traj(cmd)

    @override
    def backht(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()

        cmd = f"traj(backht,{tool_number})"
        return self._traj(cmd)

    @override
    def teachhotpuck(self, puck, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"traj(teachhotpuck,{tool_number},{puck})"
        return self._traj(cmd)

    # Plate

    @override
    def get_plate(self) -> str:
        raise NotImplementedError

    @override
    def get_put_plate(self, plate_number: int) -> str:
        raise NotImplementedError

    @override
    def put_plate(self, plate_number: int) -> str:
        raise NotImplementedError

    # Checks for unexpected commands

    @override
    def is_in_soak(self) -> bool:
        return self.get_attribute_value("PositionName") == "Soak"
