"""Connection client for robot model "ISARA1" (BioMAX)."""

import dataclasses
import re

from typing_extensions import override

from .base import (
    IsaraBaseConnectionClient,
    Pose,
    Sample,
    _Attr,
)
from .commands import (
    CommandCache,
    CommandSocket,
)
from .errors import CanNotRunTrajectoryFromSoak


@dataclasses.dataclass
class _IntAttrWithFallback(_Attr[int]):
    """Integer attribute with fallback value of `-1` for empty string."""

    # Override
    data_type: type[int] = int

    @override
    def parse(self, token: str) -> int:
        return -1 if token == "" else int(token)


class Isara1ConnectionClient(IsaraBaseConnectionClient):
    """Connection client for ISARA robot model "ISARA1" (BioMAX)."""

    # Override
    model_name: str = "isara1"

    # Override
    TOOL_MAPPING = {
        0: "Flange",  # No tool
        1: "Capillaries",  # ex-HotTool, Capillaries is name from robot state
        2: "SSX",  # ex-"EMBL/ESRF gripper", installed on BioMAX late 2025
        3: "Plate",
        4: "Laser",
        5: "Double",
    }

    # Indices for 'sample on diffractometer' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_DIFF_IDX = 7
    STATE_SAMPLE_PIN_ON_DIFF_IDX = 8

    # Indices for 'sample on tool A' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_TOOL_A_IDX = 5
    STATE_SAMPLE_PIN_ON_TOOL_A_IDX = 6

    # Indices for 'sample on tool B' fields in state command reply.
    STATE_SAMPLE_PUCK_ON_TOOL_B_IDX = 20
    STATE_SAMPLE_PIN_ON_TOOL_B_IDX = 21

    # Override
    _ATTRIBUTES = [
        *IsaraBaseConnectionClient._ATTRIBUTES,
        # di
        _Attr("di", 10, bool, "SampleDetectedOnGonio"),
        # di2
        *[
            _Attr("di2", i, bool) for i in range(IsaraBaseConnectionClient.PUCKS_NUM)
        ],  # Puck detection
        # do
        _Attr("do", 7, bool, "PathSafe"),  # Arm is parked
        # message
        _Attr("message", 0, str, "Message"),
        # position
        _Attr("position", 0, float, "PoseX"),
        _Attr("position", 1, float, "PoseY"),
        _Attr("position", 2, float, "PoseZ"),
        _Attr("position", 3, float, "PoseRX"),
        _Attr("position", 4, float, "PoseRY"),
        _Attr("position", 5, float, "PoseRZ"),
        # state
        _Attr("state", 4, str, "Path"),
        _IntAttrWithFallback(
            "state", STATE_SAMPLE_PUCK_ON_TOOL_A_IDX, name="PuckNumberOnTool"
        ),
        _IntAttrWithFallback(
            "state", STATE_SAMPLE_PIN_ON_TOOL_A_IDX, name="SampleNumberOnTool"
        ),
        _IntAttrWithFallback(
            "state", STATE_SAMPLE_PUCK_ON_DIFF_IDX, name="PuckNumberOnDiff"
        ),
        _IntAttrWithFallback(
            "state", STATE_SAMPLE_PIN_ON_DIFF_IDX, name="SampleNumberOnDiff"
        ),
        _Attr("state", 9, str, "PlateNumberOnTool"),
        _Attr("state", 11, str, "Barcode"),
        _Attr("state", 12, bool, "PathRunning"),
        _Attr("state", 13, bool, "LN2Regulation"),
        _Attr("state", 15, float, "SpeedRatio"),
        _Attr("state", 16, float, "GonioX"),
        _Attr("state", 17, float, "GonioY"),
        _Attr("state", 18, float, "GonioZ"),
        _Attr("state", STATE_SAMPLE_PUCK_ON_TOOL_B_IDX, int, "PuckNumberOnToolB"),
        _Attr("state", STATE_SAMPLE_PIN_ON_TOOL_B_IDX, int, "SampleNumberOnToolB"),
        _Attr("state", 22, str, "CurrentNumberOfSoaking"),
    ]

    #: Expected format of the reply to the ``di2`` command.
    _DI2_REPLY_RE = re.compile(r"^di2\((.+)\)$")

    #: Expected format of the reply to the ``position`` command.
    _POSITION_REPLY_RE = re.compile(r"^position\((.+)\)$")

    def __init__(
        self,
        process_sock: CommandSocket,
        status_sock: CommandSocket,
        command_cache_timeout: float,
    ):
        """Initialize instance."""
        super().__init__(process_sock, status_sock)

        self._add_command_cache("di", CommandCache(self._di, command_cache_timeout))
        self._add_command_cache("di2", CommandCache(self._di2, command_cache_timeout))
        self._add_command_cache("do", CommandCache(self._do, command_cache_timeout))
        self._add_command_cache(
            "message", CommandCache(self._message, command_cache_timeout)
        )
        self._add_command_cache(
            "position", CommandCache(self._position, command_cache_timeout)
        )
        self._add_command_cache(
            "state", CommandCache(self._state, command_cache_timeout)
        )

        self._soak_pose: Pose | None = None

    def set_soak_pose(self, pose: Pose) -> None:
        self._soak_pose = pose

    # Status commands

    def _di(self) -> list[bool]:
        return self._get_status_command("di", self._DI_REPLY_RE, comma_separated=False)

    def _di2(self) -> list[bool]:
        return self._get_status_command(
            "di2",
            self._DI2_REPLY_RE,
            comma_separated=False,
        )

    def _do(self) -> list[bool]:
        return self._get_status_command("do", self._DO_REPLY_RE, comma_separated=False)

    def _message(self) -> list[str]:
        return [self._monitor("message")]

    def _position(self):
        return self._get_status_command("position", self._POSITION_REPLY_RE)

    @override
    def get_puck_presence(self):
        return self._command_caches["di2"].value

    @override
    def get_sample_on_tool_b(self) -> Sample | None:
        """Get 'sample on tool b' for Isara1.

        Deals with the special case of Isara1 API for reading mounted
        sample on tool B.

        Isara1 uses '0' to represent case when there is no sample on
        tool b.
        """
        return self._get_sample_from_state(
            self.STATE_SAMPLE_PUCK_ON_TOOL_B_IDX,
            self.STATE_SAMPLE_PIN_ON_TOOL_B_IDX,
            no_sample=0,
        )

    def compute_position_name(self) -> str:
        """Compute a position name.

        Isara1 itself does not deliver a position name,
        so the position name has to be computed based on the robot arm's pose.

        This should copy the behavior of Isara2 as close as possible.

        Returns:
            Position name.
        """
        return "SOAK" if self.is_in_soak() else "UNDEFINED"

    # General commands

    def _remote_speed_on(self):
        return self._operate("remotespeedon")

    def _remote_speed_off(self):
        return self._operate("remotespeedoff")

    @override
    def speed_up(self):
        # The possibility of changing the speed when in remote mode
        # must be enabled explicitly beforehand.
        self._remote_speed_on()
        result = self._operate("speedup")
        self._remote_speed_off()
        return result

    @override
    def speed_down(self):
        # The possibility of changing the speed when in remote mode
        # must be enabled explicitly beforehand.
        self._remote_speed_on()
        result = self._operate("speeddown")
        self._remote_speed_off()
        return result

    @override
    def openlid(self):
        return self._operate("openlid1")

    @override
    def closelid(self):
        return self._operate("closelid1")

    @override
    def open_tool_b(self):
        return self._operate("opentool2")

    @override
    def close_tool_b(self):
        return self._operate("closetool2")

    # Trajectory commands

    @override
    def home(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"home({tool_number})"
        return self._traj(cmd)

    @override
    def recover(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"safe({tool_number})"
        return self._traj(cmd)

    @override
    def put(self, puck, sample, datamatrix_scan=0):
        tool_number = self._get_current_tool()
        if datamatrix_scan:
            cmd = f"put_bcrd({tool_number},{puck},{sample})"
        else:
            cmd = f"put({tool_number},{puck},{sample})"
        return self._traj(cmd)

    @override
    def get(self, datamatrix_scan=0):
        if datamatrix_scan != 0:
            raise NotImplementedError
        tool_number = self._get_current_tool()

        cmd = f"get({tool_number})"
        return self._traj(cmd)

    @override
    def getput(self, puck, sample, datamatrix_scan=0):
        if datamatrix_scan != 0:
            raise NotImplementedError
        tool_number = self._get_current_tool()
        cmd = f"getput({tool_number},{puck},{sample})"
        return self._traj(cmd)

    @override
    def pick(self, puck, sample, datamatrix_scan=0):
        if datamatrix_scan != 0:
            raise NotImplementedError

        tool_number = self._get_current_tool()

        if self.TOOL_MAPPING[tool_number] != "Double":
            raise RuntimeError("Command only allowed for DoubleGripper")

        cmd = f"pick({tool_number},{puck},{sample})"
        return self._traj(cmd)

    @override
    def datamatrix(self, puck, sample):
        # ignoring next sample preloading
        tool_number = self._get_current_tool()
        cmd = f"barcode({tool_number},{puck},{sample})"
        return self._traj(cmd)

    @override
    def back(self, tool_number=None):
        if self.is_in_soak():
            raise CanNotRunTrajectoryFromSoak("back")
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"back({tool_number})"
        return self._traj(cmd)

    @override
    def soak(self, tool_number=None):
        if self.is_in_soak():
            raise CanNotRunTrajectoryFromSoak("soak")
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"soak({tool_number})"
        return self._traj(cmd)

    @override
    def dry(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"dry({tool_number})"
        return self._traj(cmd)

    @override
    def gotodiff(self, puck, sample):
        tool_number = self._get_current_tool()
        cmd = f"gotodiff({tool_number},{puck},{sample})"
        return self._traj(cmd)

    @override
    def teachgonio(self, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        if tool_number != 4:  # noqa: PLR2004
            raise RuntimeError("TeachGonio is allowed only for Laser tool")
        cmd = f"teach_gonio({tool_number})"
        return self._traj(cmd)

    @override
    def teachpuck(self, puck, tool_number=None):
        if tool_number is None:
            tool_number = self._get_current_tool()
        cmd = f"teach_puck({tool_number},{puck})"
        return self._traj(cmd)

    @override
    def teachdewar(self, puck, tool_number=None):
        raise NotImplementedError("No `teachdewar` command on Isara1")

    @override
    def change_tool(self, tool_number):
        current_tool_number = self._get_current_tool()
        if (tool_number == 2) != (current_tool_number == 2):  # noqa: PLR2004
            raise RuntimeError("SSX tool must be exchanged manually")
        cmd = f"home({tool_number})"
        return self._traj(cmd)

    @override
    def change_tool_and_calibrate(self, tool_number):
        current_tool_number = self._get_current_tool()
        if (tool_number == 2) != (current_tool_number == 2):  # noqa: PLR2004
            raise RuntimeError("SSX tool must be exchanged manually")
        cmd = f"toolcal({tool_number})"
        return self._traj(cmd)

    @override
    def toolcal(self):
        tool_number = self._get_current_tool()
        cmd = f"toolcal({tool_number})"
        return self._traj(cmd)

    # Maintenance commands

    @override
    def clear_memory(self):
        return self._operate("clear memory")

    # Hot puck commands

    @override
    def putht(self, puck, sample, datamatrix_scan=0):
        raise NotImplementedError("No hot puck features on Isara1")

    @override
    def getht(self, datamatrix_scan=0):
        raise NotImplementedError("No hot puck features on Isara1")

    @override
    def getputht(self, puck, sample, datamatrix_scan=0):
        raise NotImplementedError("No hot puck features on Isara1")

    @override
    def backht(self, tool_number=None):
        raise NotImplementedError("No hot puck features on Isara1")

    @override
    def teachhotpuck(self, puck, tool_number=None):
        raise NotImplementedError("No hot puck features on Isara1")

    # Plate commands

    @override
    def get_plate(self) -> str:
        cmd = "getplate(3)"
        return self._traj(cmd)

    @override
    def get_put_plate(self, plate_number: int) -> str:
        cmd = f"getputplate(3,0,0,0,0,{plate_number})"
        return self._traj(cmd)

    @override
    def put_plate(self, plate_number: int) -> str:
        cmd = f"putplate(3,0,0,0,0,{plate_number})"
        return self._traj(cmd)

    # Checks for unexpected commands

    @override
    def is_in_soak(self) -> bool:
        # The chosen solution on Isara1 is to check
        # if the arm is close to the reference soak pose (preset via Tango properties).
        #
        # If the current pose is very different from the reference soak pose
        # (in other words: `self.is_in_soak() == False`)
        # then it is safe to assume that a "trajectory" command must be ongoing
        # and that the robot would reject any new "trajectory" command anyway.

        if self._soak_pose:
            pose_x = self.get_attribute_value("PoseX")
            pose_y = self.get_attribute_value("PoseY")
            pose_z = self.get_attribute_value("PoseZ")
            pose_rx = self.get_attribute_value("PoseRX")
            pose_ry = self.get_attribute_value("PoseRY")
            pose_rz = self.get_attribute_value("PoseRZ")

            x_in_soak = self._soak_pose.pose_x - 1 < pose_x < self._soak_pose.pose_x + 1
            y_in_soak = self._soak_pose.pose_y - 1 < pose_y < self._soak_pose.pose_y + 1
            z_in_soak = self._soak_pose.pose_z - 1 < pose_z < self._soak_pose.pose_z + 1
            rx_in_soak = (
                self._soak_pose.pose_rx - 1 < pose_rx < self._soak_pose.pose_rx + 1
            )
            ry_in_soak = (
                self._soak_pose.pose_ry - 1 < pose_ry < self._soak_pose.pose_ry + 1
            )
            rz_in_soak = (
                self._soak_pose.pose_rz - 1 < pose_rz < self._soak_pose.pose_rz + 1
            )

            in_soak = (
                x_in_soak & y_in_soak & z_in_soak & rx_in_soak & ry_in_soak & rz_in_soak
            )

        else:
            raise Exception("No soak pose")

        return in_soak
