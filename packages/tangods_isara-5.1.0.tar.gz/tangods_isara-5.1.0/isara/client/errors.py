"""Exceptions."""


class IsaraException(Exception):
    """Base class for Isara exceptions.

    Derived classes must have a string attribute `error_message`.

    Attributes:
        error_message: Error message to be displayed to the user.
    """

    error_message: str


class CanNotRunTrajectoryFromSoak(IsaraException):
    """Raised when initiating a trajectory from soak that would cause a collision.

    While most trajectories are handled properly by Isara1
    when they are started from the soaking position (grippper soaking),
    some trajectories provoke a collision:
    the robot arm does an horizontal movement before the gripper is out.
    Known problematic trajectories (on Isara1) are: ``back`` and ``soak`` itself.
    """

    def __init__(self, trajectory: str) -> None:
        self.error_message = (
            f"Can not run trajectory '{trajectory}' from soak position."
        )
        super().__init__(self.error_message)


class CommandErrorException(IsaraException):
    """Raised on error reply from Isara.

    Attributes:
        command: The command that was sent to Isara robot.
        error_message: The error reply from Isara robot.
    """

    def __init__(self, command: str, error_message: str):
        self.command = command
        self.error_message = error_message
        super().__init__(f"Command '{command}' failed: '{error_message}'.")


class NoToolException(IsaraException):
    """Raised when no tool mounted on Isara robot."""

    def __init__(self) -> None:
        self.error_message = "No tool on Isara robot"
        super().__init__(self.error_message)


class NoAttributeWithName(IsaraException):
    """Raised when trying to access an attribute whose name can not be found."""
