"""Test for speed commands."""

import pytest

from tests.utils import poll_attribute_until


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_speed_commands(isarax, device):
    """Test 'SpeedUp' and 'SpeedDown' commands."""
    current_speed = device.SpeedRatio

    # we assume that we start at max possible speed ratio
    assert current_speed == 100.0

    # check that reducing speed ratio works
    device.SpeedDown()
    poll_attribute_until(device, "SpeedRatio", lambda v: v < current_speed)

    # check that increasing speed ratio works
    current_speed = device.SpeedRatio
    device.SpeedUp()
    poll_attribute_until(device, "SpeedRatio", lambda v: v > current_speed)
