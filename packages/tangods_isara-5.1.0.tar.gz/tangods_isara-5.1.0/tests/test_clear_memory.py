"""Tests for the "clear memory" command."""

import pytest


@pytest.mark.parametrize(
    ("isarax", "response_str"),
    [("isara1", "clear memory"), ("isara2", "clearmemory")],
    indirect=["isarax"],
)
def test_clear_memory(isarax, response_str, device):
    """Test the "clear memory" command."""
    response = device.ClearMemory()
    assert response == response_str
