"""Tests for puck presence."""

from time import sleep

import pytest

import isara.client
from tests.utils import COMMAND_CACHE_TIMEOUT

MIXED_STATE = [
    True,
    *[False] * (isara.client.IsaraBaseConnectionClient.PUCKS_NUM - 2),
    True,
]

ALL_FULL = [True] * isara.client.IsaraBaseConnectionClient.PUCKS_NUM

ALL_EMPTY = [False] * isara.client.IsaraBaseConnectionClient.PUCKS_NUM


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_puck_presence(isarax, device):
    """Test the puck presence via the `CassettePresence` Tango device attribute."""
    isarax.set_pucks(MIXED_STATE)
    sleep(COMMAND_CACHE_TIMEOUT * 1.1)
    pucks = device.CassettePresence
    assert pucks.tolist() == MIXED_STATE

    isarax.set_pucks(ALL_EMPTY)
    sleep(COMMAND_CACHE_TIMEOUT * 1.1)
    pucks = device.CassettePresence
    assert pucks.tolist() == ALL_EMPTY

    isarax.set_pucks(ALL_FULL)
    sleep(COMMAND_CACHE_TIMEOUT * 1.1)
    pucks = device.CassettePresence
    assert pucks.tolist() == ALL_FULL
