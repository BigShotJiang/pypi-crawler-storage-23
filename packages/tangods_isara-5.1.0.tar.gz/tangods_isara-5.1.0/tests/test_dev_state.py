"""Test tango device State() command."""

import pytest
from tango import DeviceProxy, DevState

from isara.emulator.base import IsaraBaseEmulator, Paths


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=["isarax"])
def test_state_on(isarax: IsaraBaseEmulator, device: DeviceProxy) -> None:
    """Check that we get 'ON' state when robot is idle."""
    assert not isarax._robot_arm.is_moving()  # noqa: SLF001
    assert device.State() == DevState.ON


def test_state_running(isara2: IsaraBaseEmulator, device: DeviceProxy) -> None:
    """Check that we get 'RUNNING' state when robot arm is moving."""
    #
    # Note:
    # We don't test this for Isara1 case.
    # This is due to limitation in the emulator,
    # we should fix the emulator.
    #

    # emulate moving to 'home' position
    isara2._robot_arm._start_trajectory(Paths.HOME)  # noqa: SLF001

    # state should be 'running' when moving
    assert device.State() == DevState.RUNNING
