"""Tests for the `ToolCal` Tango command."""

import pytest


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=("isarax",))
def test_tool_cal_with_init_tool(isarax, device):
    """The `ToolCal` Tango command should succeed with the initial tool."""
    reply = device.ToolCal()
    assert reply == "toolcal"


@pytest.mark.parametrize(
    ("isarax", "tool_name"),
    [("isara1", "Laser"), ("isara2", "LaserTool")],
    indirect=("isarax",),
)
def test_tool_cal(isarax, tool_name, device):
    """The `ToolCal` Tango command should succeed after change of a tool."""
    isarax.set_tool_by_name(tool_name)
    reply = device.ToolCal()
    assert reply == "toolcal"
