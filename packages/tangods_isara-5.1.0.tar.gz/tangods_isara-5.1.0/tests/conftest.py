import pytest
from tango.test_context import DeviceTestContext

from isara.client.isara1 import Isara1ConnectionClient
from isara.client.isara2 import Isara2ConnectionClient
from isara.dev.tangods import Isara
from isara.emulator.base import Position
from isara.emulator.config import Config, IsaraModel
from isara.emulator.start import start_emulator
from tests.utils import COMMAND_CACHE_TIMEOUT

OPERATE_PORT = 2222
MONITOR_PORT = 3333


def _start_emulator(model: IsaraModel, initial_tool_name: str):
    config = Config(
        model=model,
        operate_port=OPERATE_PORT,
        monitor_port=MONITOR_PORT,
        initial_position=Position.HOME,
        initial_tool=initial_tool_name,
    )
    return start_emulator(config=config, enable_logging=False)


@pytest.fixture
def isara1_initial_tool():
    return Isara1ConnectionClient.TOOL_MAPPING[0]


@pytest.fixture
def isara2_initial_tool():
    return Isara2ConnectionClient.TOOL_MAPPING[0]


@pytest.fixture
def isara1(isara1_initial_tool):
    emu = _start_emulator(IsaraModel.Isara1, isara1_initial_tool)

    yield emu

    emu.stop()


@pytest.fixture
def isara2(isara2_initial_tool):
    emu = _start_emulator(IsaraModel.Isara2, isara2_initial_tool)

    yield emu

    emu.stop()


@pytest.fixture
def isarax(request):
    """Indirection for parametrization of the Isara emulator fixtures.

    This combined with a decorator like below on the test function,
    allows to run the same test on multiple Isara implementations,
    where `isara1` and `isara2` are the names of the pytest fixture functions
    and `isarax` is the variable name to be used to access the current fixture
    from within the code of the test function:

        @pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
        def test_something(isarax):
            isarax.set_manual_mode()
    """
    return request.getfixturevalue(request.param)


@pytest.fixture
def device():
    properties = {
        "host": "localhost",
        "operate_port": OPERATE_PORT,
        "monitor_port": MONITOR_PORT,
        "command_cache_timeout": COMMAND_CACHE_TIMEOUT,
        "soak_pose_x": 100.0,
        "soak_pose_y": 100.0,
        "soak_pose_z": 100.0,
        "soak_pose_rx": 100.0,
        "soak_pose_ry": 100.0,
        "soak_pose_rz": 100.0,
    }
    with DeviceTestContext(Isara, properties=properties, process=True) as dev:
        yield dev
