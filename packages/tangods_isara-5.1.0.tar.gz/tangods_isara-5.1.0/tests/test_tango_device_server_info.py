"""Tests for the TangoDeviceServerInfo attribute."""

import pytest


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_tango_device_server_info(isarax, device):
    """Test the TangoDeviceServerInfo attribute."""
    info = device.TangoDeviceServerInfo
    assert "Name: tangods-isara" in info
    assert "Version: " in info
