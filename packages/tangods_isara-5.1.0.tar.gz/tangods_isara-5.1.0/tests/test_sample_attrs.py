"""Test on Sample related attributes."""

import pytest
from tango import DeviceProxy

from isara.client.base import Sample
from isara.emulator.base import IsaraBaseEmulator

from .utils import poll_attribute_until

TEST_SAMPLE = Sample(12, 3)


def _no_sample(sample: list) -> bool:
    return len(sample) == 0


def _sample_mounted(sample: list) -> bool:
    return len(sample) != 0


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_sample_on_diff(isarax: IsaraBaseEmulator, device: DeviceProxy) -> None:
    """Test reading ``SampleOnDiff`` attribute."""
    # no sample on diffractometer
    isarax.set_sample_on_diff(None)
    poll_attribute_until(device, "SampleOnDiff", _no_sample)

    # sample mounted on diffractometer
    isarax.set_sample_on_diff(TEST_SAMPLE)
    poll_attribute_until(device, "SampleOnDiff", _sample_mounted)

    puck, pin = device.SampleOnDiff
    assert puck == TEST_SAMPLE.puck
    assert pin == TEST_SAMPLE.pin


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_sample_on_tool_a(isarax: IsaraBaseEmulator, device: DeviceProxy) -> None:
    """Test reading ``SampleOnToolA`` attribute."""
    # no sample on diffractometer
    isarax.set_sample_on_tool_a(None)
    poll_attribute_until(device, "SampleOnToolA", _no_sample)

    # sample mounted on diffractometer
    isarax.set_sample_on_tool_a(TEST_SAMPLE)
    poll_attribute_until(device, "SampleOnToolA", _sample_mounted)

    puck, pin = device.SampleOnToolA
    assert puck == TEST_SAMPLE.puck
    assert pin == TEST_SAMPLE.pin


@pytest.mark.parametrize("isarax", ["isara1", "isara2"], indirect=True)
def test_sample_on_tool_b(isarax: IsaraBaseEmulator, device: DeviceProxy) -> None:
    """Test reading ``SampleOnToolB`` attribute."""
    # no sample on diffractometer
    isarax.set_sample_on_tool_b(None)
    poll_attribute_until(device, "SampleOnToolB", _no_sample)

    # sample mounted on diffractometer
    isarax.set_sample_on_tool_b(TEST_SAMPLE)
    poll_attribute_until(device, "SampleOnToolB", _sample_mounted)

    puck, pin = device.SampleOnToolB
    assert puck == TEST_SAMPLE.puck
    assert pin == TEST_SAMPLE.pin
