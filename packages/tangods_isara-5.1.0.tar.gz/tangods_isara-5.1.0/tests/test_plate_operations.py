"""Tests for plate operations."""

import tango.server

import isara.emulator.base


def test_get_plate(
    isara1: isara.emulator.base.IsaraBaseEmulator,  # noqa: ARG001
    device: tango.DeviceProxy,
) -> None:
    """Test the ``GetPlate`` command."""
    response = device.GetPlate()
    assert response == "getplate"


def test_get_put_plate(
    isara1: isara.emulator.base.IsaraBaseEmulator,  # noqa: ARG001
    device: tango.DeviceProxy,
) -> None:
    """Test the ``GetPutPlate`` command."""
    response = device.GetPutPlate(1)
    assert response == "getputplate"


def test_put_plate(
    isara1: isara.emulator.base.IsaraBaseEmulator,  # noqa: ARG001
    device: tango.DeviceProxy,
) -> None:
    """Test the ``PutPlate`` command."""
    response = device.PutPlate(1)
    assert response == "putplate"
