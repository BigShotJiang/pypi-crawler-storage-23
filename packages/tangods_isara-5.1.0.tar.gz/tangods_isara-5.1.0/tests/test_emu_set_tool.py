import pytest

from isara import emulator


def test_set_tool_by_name_isara2(isara2, isara2_initial_tool):
    assert isara2._current_tool_name == isara2_initial_tool

    isara2.set_tool_by_name("SingleGripper")
    assert isara2._current_tool_name == "SingleGripper"

    isara2.set_tool_by_number(1)
    assert isara2._current_tool_name == "Cryotong"

    with pytest.raises(emulator.base.InvalidToolName):
        isara2.set_tool_by_name("something")
    assert isara2._current_tool_name == "Cryotong"  # Check tool has not changed

    with pytest.raises(emulator.base.InvalidToolNumber):
        isara2.set_tool_by_number(777)
    assert isara2._current_tool_name == "Cryotong"  # Check tool has not changed


def test_set_tool_by_name_isara1(isara1, isara1_initial_tool):
    assert isara1._current_tool_name == isara1_initial_tool

    isara1.set_tool_by_name("SSX")
    assert isara1._current_tool_name == "SSX"

    isara1.set_tool_by_number(1)
    assert isara1._current_tool_name == "Capillaries"

    with pytest.raises(emulator.base.InvalidToolName):
        isara1.set_tool_by_name("something")
    assert isara1._current_tool_name == "Capillaries"  # Check tool has not changed

    with pytest.raises(emulator.base.InvalidToolNumber):
        isara1.set_tool_by_number(777)
    assert isara1._current_tool_name == "Capillaries"  # Check tool has not changed
