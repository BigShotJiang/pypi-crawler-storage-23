import pytest
from tango import DevFailed

from tests.utils import (
    get_isara_command_error,
    poll_attribute_until,
)


def test_put_at_home_position(isara2, device):
    """For ISARA2 robot, test putting sample on gonio at 'HOME' position."""
    assert device.PositionName == "HOME"

    with pytest.raises(DevFailed) as excinfo:
        device.Put(["1", "1"])

    err_msg = get_isara_command_error(excinfo.value)
    assert err_msg == "Rejected - Trajectory must start at position: SOAK"


def test_put_at_soak_position(isara2, device):
    """For ISARA2 robot, test moving to 'SOAK' position and puting a sample on gonio."""
    assert device.PositionName == "HOME"
    assert device.SpeedRatio == 100.0

    # goto 'SOAK' position
    device.Soak()
    poll_attribute_until(device, "PositionName", "SOAK")

    # put sample 1 from puck 1 on gonio
    device.Put(["1", "1"])
