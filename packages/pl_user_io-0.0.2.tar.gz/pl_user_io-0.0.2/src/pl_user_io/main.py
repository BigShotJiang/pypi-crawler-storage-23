def main() -> None:
    print("Hello, world!")
