"""Serve package: assemble and render ArchProfile, ContextBundle, and ComparisonResult outputs."""

from __future__ import annotations

# TODO: Implement in Phase 3
