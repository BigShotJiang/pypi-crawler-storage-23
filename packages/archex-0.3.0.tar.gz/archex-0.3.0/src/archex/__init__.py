"""archex — architecture extraction and analysis toolkit."""

from __future__ import annotations

from archex.api import analyze, compare, query

__version__ = "0.3.0"

__all__ = ["analyze", "query", "compare", "__version__"]
