"""CLI package: click command group and subcommand modules."""

from __future__ import annotations
