from tapl_lang.lib import tapl_dev

def union_print(a):
    tapl_dev.log(a)
union_print(123)
union_print('hello')
