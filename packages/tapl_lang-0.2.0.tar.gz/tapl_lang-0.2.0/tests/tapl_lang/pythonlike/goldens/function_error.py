def one():
    return 0
