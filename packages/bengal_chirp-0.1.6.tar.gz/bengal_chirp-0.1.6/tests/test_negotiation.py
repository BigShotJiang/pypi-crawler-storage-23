"""Tests for chirp.server.negotiation — content negotiation dispatch."""

import json
from pathlib import Path

import pytest
from kida import Environment, FileSystemLoader

from chirp.config import AppConfig
from chirp.http.request import Request
from chirp.http.response import Redirect, Response
from chirp.pages.shell_actions import ShellAction, ShellActions, ShellActionZone
from chirp.realtime.events import EventStream
from chirp.server.negotiation import negotiate
from chirp.templating.composition import PageComposition
from chirp.templating.integration import create_environment
from chirp.templating.returns import (
    OOB,
    Action,
    FormAction,
    Fragment,
    LayoutPage,
    LayoutSuspense,
    Page,
    Stream,
    Suspense,
    Template,
    ValidationError,
)

TEMPLATES_DIR = Path(__file__).parent / "templates"


@pytest.fixture
def kida_env() -> Environment:
    return Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)))


@pytest.fixture
def kida_env_with_packages() -> Environment:
    return create_environment(
        AppConfig(template_dir=TEMPLATES_DIR),
        filters={},
        globals_={},
    )


class TestNegotiatePassthrough:
    def test_response_passthrough(self) -> None:
        original = Response(body="hello", status=201)
        result = negotiate(original)
        assert result is original

    def test_redirect(self) -> None:
        result = negotiate(Redirect("/login"))
        assert result.status == 302
        assert ("Location", "/login") in result.headers

    def test_redirect_301(self) -> None:
        result = negotiate(Redirect("/new", status=301))
        assert result.status == 301


class TestNegotiateTemplateTypes:
    def test_template_rendering(self, kida_env: Environment) -> None:
        result = negotiate(Template("page.html", title="Home"), kida_env=kida_env)
        assert result.status == 200
        assert "text/html" in result.content_type
        assert "<title>Home</title>" in result.text
        assert "<h1>Home</h1>" in result.text
        assert result.render_intent == "full_page"

    def test_template_with_list(self, kida_env: Environment) -> None:
        result = negotiate(
            Template("page.html", title="List", items=["a", "b", "c"]),
            kida_env=kida_env,
        )
        assert "<li>a</li>" in result.text
        assert "<li>b</li>" in result.text
        assert "<li>c</li>" in result.text

    def test_fragment_rendering(self, kida_env: Environment) -> None:
        result = negotiate(
            Fragment("search.html", "results_list", results=["one", "two"]),
            kida_env=kida_env,
        )
        assert result.status == 200
        assert "text/html" in result.content_type
        assert '<div id="results">' in result.text
        assert "one" in result.text
        assert "two" in result.text
        # Fragment should NOT include the full page wrapper
        assert "<form>" not in result.text
        assert result.render_intent == "fragment"
        assert result.header("HX-Reselect") == "*"

    def test_page_intent_tracks_fragment_request(self, kida_env: Environment) -> None:
        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/",
                "headers": [(b"hx-request", b"true")],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )
        result = negotiate(
            Page("search.html", "results_list", results=["one"]),
            kida_env=kida_env,
            request=request,
        )
        assert result.render_intent == "fragment"

    def test_page_composition_renders_fragment(self, kida_env: Environment) -> None:
        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/",
                "headers": [(b"hx-request", b"true")],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )
        comp = PageComposition(
            template="search.html",
            fragment_block="results_list",
            context={"results": ["a", "b"]},
        )
        result = negotiate(comp, kida_env=kida_env, request=request)
        assert result.render_intent == "fragment"
        assert "a" in result.text
        assert "b" in result.text

    def test_page_composition_renders_full_page(self, kida_env: Environment) -> None:
        comp = PageComposition(
            template="page.html",
            fragment_block="content",
            page_block="content",
            context={"title": "Composed", "items": []},
        )
        result = negotiate(comp, kida_env=kida_env)
        assert result.render_intent == "full_page"
        assert "<title>Composed</title>" in result.text

    def test_page_boosted_request_prefers_page_block_name(self, tmp_path: Path) -> None:
        env = Environment(loader=FileSystemLoader(str(tmp_path)))
        (tmp_path / "base.html").write_text(
            '{% block page_root %}<div class="page-root">{% block panel %}{% endblock %}</div>{% endblock %}'
        )
        (tmp_path / "child.html").write_text(
            '{% extends "base.html" %}{% block panel %}<div id="panel">{{ message }}</div>{% endblock %}'
        )

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-boosted", b"true"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )
        result = negotiate(
            Page("child.html", "panel", page_block_name="page_root", message="Hello"),
            kida_env=env,
            request=request,
        )
        assert result.render_intent == "fragment"
        assert 'class="page-root"' in result.text
        assert 'id="panel"' in result.text
        assert "Hello" in result.text

    def test_template_without_env_raises(self) -> None:
        from chirp.errors import ConfigurationError

        with pytest.raises(ConfigurationError, match="requires kida integration"):
            negotiate(Template("page.html", title="Home"))

    def test_fragment_without_env_raises(self) -> None:
        from chirp.errors import ConfigurationError

        with pytest.raises(ConfigurationError, match="requires kida integration"):
            negotiate(Fragment("search.html", "results"))

    def test_stream_without_env_raises(self) -> None:
        from chirp.errors import ConfigurationError

        with pytest.raises(ConfigurationError, match="requires kida integration"):
            negotiate(Stream("dashboard.html"))

    def test_stream_returns_streaming_response(self, tmp_path) -> None:
        from chirp.http.response import StreamingResponse

        env = Environment(loader=FileSystemLoader(str(tmp_path)))
        (tmp_path / "dash.html").write_text("Hello {{ name }}")
        result = negotiate(Stream("dash.html", name="World"), kida_env=env)
        assert isinstance(result, StreamingResponse)
        assert result.content_type == "text/html; charset=utf-8"
        assert "".join(result.chunks) == "Hello World"

    def test_event_stream_returns_sse_response(self) -> None:
        from chirp.http.response import SSEResponse

        async def gen():
            yield "hello"

        result = negotiate(EventStream(generator=gen()))
        assert isinstance(result, SSEResponse)
        assert result.event_stream.generator is not None


class TestNegotiateValidationError:
    """Tests for ValidationError negotiation — 422 + fragment + optional HX-Retarget."""

    def test_renders_fragment_with_422(self, kida_env: Environment) -> None:
        result = negotiate(
            ValidationError(
                "form.html",
                "form_body",
                errors={"email": ["Required"]},
                form={"email": ""},
            ),
            kida_env=kida_env,
        )
        assert result.status == 422
        assert "text/html" in result.content_type
        assert "email: Required" in result.text
        # Should be a fragment, not the full page
        assert "<html>" not in result.text
        assert result.header("HX-Reselect") == "*"

    def test_without_retarget_has_no_hx_header(self, kida_env: Environment) -> None:
        result = negotiate(
            ValidationError("form.html", "form_body", errors={}),
            kida_env=kida_env,
        )
        assert result.status == 422
        assert result.header("HX-Reselect") == "*"
        header_names = {name for name, _ in result.headers}
        assert "HX-Retarget" not in header_names

    def test_with_retarget_sets_header(self, kida_env: Environment) -> None:
        result = negotiate(
            ValidationError(
                "form.html",
                "form_errors",
                retarget="#error-banner",
                errors={"email": ["Invalid"]},
            ),
            kida_env=kida_env,
        )
        assert result.status == 422
        assert result.header("HX-Reselect") == "*"
        assert ("HX-Retarget", "#error-banner") in result.headers
        assert "email: Invalid" in result.text

    def test_without_env_raises(self) -> None:
        from chirp.errors import ConfigurationError

        with pytest.raises(ConfigurationError, match="requires kida integration"):
            negotiate(ValidationError("form.html", "form_body", errors={}))


class TestNegotiateAction:
    def test_action_defaults_to_204_no_content(self) -> None:
        result = negotiate(Action())
        assert result.status == 204
        assert result.text == ""
        assert "text/html" in result.content_type

    def test_action_sets_hx_headers(self) -> None:
        result = negotiate(Action(trigger="saved", refresh=True))
        assert result.status == 204
        assert ("HX-Trigger", "saved") in result.headers
        assert ("HX-Refresh", "true") in result.headers

    def test_action_trigger_payload_dict(self) -> None:
        result = negotiate(Action(trigger={"saved": {"ok": True}}))
        assert result.status == 204
        assert ("HX-Trigger", json.dumps({"saved": {"ok": True}})) in result.headers


class TestNegotiateFormAction:
    """Tests for FormAction negotiation — progressive enhancement for form success."""

    @staticmethod
    def _plain_request() -> Request:
        """Create a plain (non-htmx) request."""

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        return Request.from_asgi(
            {
                "type": "http",
                "method": "POST",
                "path": "/submit",
                "headers": [],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

    @staticmethod
    def _htmx_request() -> Request:
        """Create a fake htmx request (is_fragment=True)."""

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        return Request.from_asgi(
            {
                "type": "http",
                "method": "POST",
                "path": "/submit",
                "headers": [(b"hx-request", b"true")],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

    def test_non_htmx_redirects(self) -> None:
        request = self._plain_request()
        result = negotiate(FormAction("/thanks"), request=request)
        assert result.status == 303
        assert ("Location", "/thanks") in result.headers

    def test_non_htmx_custom_status(self) -> None:
        request = self._plain_request()
        result = negotiate(FormAction("/moved", status=301), request=request)
        assert result.status == 301
        assert ("Location", "/moved") in result.headers

    def test_non_htmx_ignores_fragments(self, kida_env: Environment) -> None:
        request = self._plain_request()
        result = negotiate(
            FormAction(
                "/contacts",
                Fragment("search.html", "results_list", results=["a"]),
            ),
            kida_env=kida_env,
            request=request,
        )
        assert result.status == 303
        assert ("Location", "/contacts") in result.headers

    def test_htmx_no_fragments_sends_hx_redirect(self) -> None:
        request = self._htmx_request()
        result = negotiate(FormAction("/dashboard"), request=request)
        assert result.status == 200
        assert ("HX-Redirect", "/dashboard") in result.headers

    def test_htmx_with_fragments_renders_html(self, kida_env: Environment) -> None:
        request = self._htmx_request()
        result = negotiate(
            FormAction(
                "/contacts",
                Fragment("search.html", "results_list", results=["alpha", "beta"]),
            ),
            kida_env=kida_env,
            request=request,
        )
        assert result.status == 200
        assert "alpha" in result.text
        assert "beta" in result.text
        header_names = {name for name, _ in result.headers}
        assert "HX-Redirect" not in header_names

    def test_htmx_with_trigger(self, kida_env: Environment) -> None:
        request = self._htmx_request()
        result = negotiate(
            FormAction(
                "/contacts",
                Fragment("search.html", "results_list", results=[]),
                trigger="contactAdded",
            ),
            kida_env=kida_env,
            request=request,
        )
        assert ("HX-Trigger", "contactAdded") in result.headers

    def test_htmx_without_trigger(self, kida_env: Environment) -> None:
        request = self._htmx_request()
        result = negotiate(
            FormAction(
                "/contacts",
                Fragment("search.html", "results_list", results=[]),
            ),
            kida_env=kida_env,
            request=request,
        )
        header_names = {name for name, _ in result.headers}
        assert "HX-Trigger" not in header_names

    def test_htmx_multiple_fragments(self, kida_env: Environment) -> None:
        request = self._htmx_request()
        result = negotiate(
            FormAction(
                "/ok",
                Fragment("search.html", "results_list", results=["x"]),
                Fragment("cart.html", "counter", count=42),
            ),
            kida_env=kida_env,
            request=request,
        )
        assert "x" in result.text
        assert "42" in result.text
        assert result.render_intent == "fragment"


class TestNegotiateOOB:
    """Tests for OOB multi-fragment out-of-band swap responses."""

    def test_single_oob_fragment(self, kida_env: Environment) -> None:
        result = negotiate(
            OOB(
                Fragment("search.html", "results_list", results=["main"]),
                Fragment("cart.html", "counter", count=5),
            ),
            kida_env=kida_env,
        )
        assert result.status == 200
        assert "text/html" in result.content_type
        # Main fragment rendered first
        assert "main" in result.text
        # OOB fragment wrapped with hx-swap-oob
        assert 'hx-swap-oob="true"' in result.text
        assert 'id="counter"' in result.text
        assert "5" in result.text

    def test_multiple_oob_fragments(self, kida_env: Environment) -> None:
        result = negotiate(
            OOB(
                Fragment("search.html", "results_list", results=["primary"]),
                Fragment("cart.html", "counter", count=3),
                Fragment("cart.html", "summary", total=7),
            ),
            kida_env=kida_env,
        )
        text = result.text
        # Both OOB fragments present
        assert 'id="counter"' in text
        assert 'id="summary"' in text
        assert text.count('hx-swap-oob="true"') == 2

    def test_oob_uses_block_name_as_default_target(self, kida_env: Environment) -> None:
        result = negotiate(
            OOB(
                Fragment("search.html", "results_list", results=[]),
                Fragment("cart.html", "counter", count=0),
            ),
            kida_env=kida_env,
        )
        # block_name "counter" used as target ID
        assert 'id="counter"' in result.text

    def test_oob_explicit_target_overrides_block_name(self, kida_env: Environment) -> None:
        result = negotiate(
            OOB(
                Fragment("search.html", "results_list", results=[]),
                Fragment("cart.html", "counter", target="cart-counter", count=0),
            ),
            kida_env=kida_env,
        )
        # Explicit target used instead of block name
        assert 'id="cart-counter"' in result.text
        assert 'id="counter"' not in result.text

    def test_main_as_template(self, kida_env: Environment) -> None:
        result = negotiate(
            OOB(
                Template("page.html", title="Full"),
                Fragment("cart.html", "counter", count=1),
            ),
            kida_env=kida_env,
        )
        # Full template rendered as main
        assert "<title>Full</title>" in result.text
        # OOB fragment appended
        assert 'hx-swap-oob="true"' in result.text

    def test_without_env_raises(self) -> None:
        from chirp.errors import ConfigurationError

        with pytest.raises(ConfigurationError, match="requires kida integration"):
            negotiate(
                OOB(
                    Fragment("search.html", "results_list", results=[]),
                    Fragment("cart.html", "counter", count=0),
                )
            )


class TestNegotiatePrimitives:
    def test_string_to_html(self) -> None:
        result = negotiate("Hello, World!")
        assert result.body == "Hello, World!"
        assert "text/html" in result.content_type
        assert result.status == 200

    def test_bytes_to_octet_stream(self) -> None:
        result = negotiate(b"\x00\x01\x02")
        assert result.body == b"\x00\x01\x02"
        assert "octet-stream" in result.content_type

    def test_dict_to_json(self) -> None:
        result = negotiate({"key": "value"})
        assert "application/json" in result.content_type
        parsed = json.loads(result.text)
        assert parsed == {"key": "value"}

    def test_list_to_json(self) -> None:
        result = negotiate([1, 2, 3])
        assert "application/json" in result.content_type
        parsed = json.loads(result.text)
        assert parsed == [1, 2, 3]


class TestNegotiateTuples:
    def test_value_with_status(self) -> None:
        result = negotiate(("Created", 201))
        assert result.status == 201
        assert result.body == "Created"

    def test_dict_with_status(self) -> None:
        result = negotiate(({"id": 1}, 201))
        assert result.status == 201
        assert "application/json" in result.content_type

    def test_value_with_status_and_headers(self) -> None:
        result = negotiate(("Created", 201, {"Location": "/users/42"}))
        assert result.status == 201
        assert ("Location", "/users/42") in result.headers

    def test_template_in_tuple(self, kida_env: Environment) -> None:
        result = negotiate((Template("page.html", title="Created"), 201), kida_env=kida_env)
        assert result.status == 201
        assert "<title>Created</title>" in result.text


class TestNegotiateEdgeCases:
    """Edge cases for ValidationError and OOB negotiation."""

    def test_validation_error_in_tuple_preserves_422(self, kida_env: Environment) -> None:
        """Wrapping ValidationError in a (value, 422) tuple still returns 422."""
        result = negotiate(
            (ValidationError("form.html", "form_body", errors={"x": ["err"]}), 422),
            kida_env=kida_env,
        )
        assert result.status == 422
        assert result.header("HX-Reselect") == "*"

    def test_validation_error_tuple_can_override_status(self, kida_env: Environment) -> None:
        """A tuple can override ValidationError's default 422 to another code."""
        result = negotiate(
            (ValidationError("form.html", "form_body", errors={}), 400),
            kida_env=kida_env,
        )
        assert result.status == 400
        assert result.header("HX-Reselect") == "*"

    def test_oob_with_zero_fragments(self, kida_env: Environment) -> None:
        """OOB with only a main and no OOB fragments renders normally."""
        result = negotiate(
            OOB(Fragment("search.html", "results_list", results=["only"])),
            kida_env=kida_env,
        )
        assert result.status == 200
        assert "only" in result.text
        assert "hx-swap-oob" not in result.text

    def test_fragment_tuple_422(self, kida_env: Environment) -> None:
        """Plain Fragment in a (value, 422) tuple works for manual validation."""
        result = negotiate(
            (Fragment("search.html", "results_list", results=["err"]), 422),
            kida_env=kida_env,
        )
        assert result.status == 422
        assert "err" in result.text
        assert result.header("HX-Reselect") == "*"


class TestLayoutPageSlotContext:
    """Integration test: page vars in nested macro slots via LayoutPage negotiation.

    Mirrors Dori skills page: container → stack → form from chirpui-style
    templates. If selected_tags/all_tags are undefined in the form slot,
    negotiation would raise UndefinedError. This test ensures the full
    Chirp negotiation path (LayoutPage, render_block, FileSystemLoader)
    propagates context into slot bodies.
    """

    def test_layout_page_slot_context_inheritance(self, kida_env: Environment) -> None:
        """selected_tags and all_tags in nested slots render without UndefinedError."""
        result = negotiate(
            LayoutPage(
                "skills/page.html",
                "page_content",
                q="search",
                selected_tags=["a", "b"],
                all_tags=["a", "b", "c"],
            ),
            kida_env=kida_env,
        )
        assert result.status == 200
        assert "a,b" in result.text
        assert "abc" in result.text
        assert 'action="/skills"' in result.text
        assert "Skills" in result.text

    def test_layout_page_boosted_navigation_appends_shell_actions_oob(
        self,
        kida_env_with_packages: Environment,
    ) -> None:
        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/skills",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-boosted", b"true"),
                    (b"hx-target", b"main"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

        result = negotiate(
            LayoutPage(
                "skills/page.html",
                "page_content",
                shell_actions=ShellActions(
                    primary=ShellActionZone(
                        items=(ShellAction(id="new-skill", label="New skill", href="/skills/new"),)
                    )
                ),
                q="search",
                selected_tags=["a", "b"],
                all_tags=["a", "b", "c"],
            ),
            kida_env=kida_env_with_packages,
            request=request,
        )

        assert result.render_intent == "fragment"
        assert 'id="chirp-shell-actions"' in result.text
        assert 'hx-swap-oob="innerHTML"' in result.text
        assert 'href="/skills/new"' in result.text

    def test_layout_page_boosted_navigation_clears_shell_actions_when_missing(
        self,
        kida_env_with_packages: Environment,
    ) -> None:
        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/skills",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-boosted", b"true"),
                    (b"hx-target", b"main"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

        result = negotiate(
            LayoutPage(
                "skills/page.html",
                "page_content",
                q="search",
                selected_tags=["a", "b"],
                all_tags=["a", "b", "c"],
            ),
            kida_env=kida_env_with_packages,
            request=request,
        )

        assert 'id="chirp-shell-actions"' in result.text
        assert 'hx-swap-oob="innerHTML"></div>' in result.text

    def test_template_extending_chirpui_app_shell_layout_renders(
        self,
        tmp_path: Path,
    ) -> None:
        (tmp_path / "page.html").write_text(
            '{% extends "chirpui/app_shell_layout.html" %}'
            "{% block brand %}Shell App{% end %}"
            "{% block sidebar %}"
            '{% from "chirpui/sidebar.html" import sidebar, sidebar_link, sidebar_section %}'
            "{% call sidebar() %}"
            '{% call sidebar_section("Main") %}'
            '{{ sidebar_link("/", "Home") }}'
            "{% end %}"
            "{% end %}"
            "{% end %}"
            "{% block content %}<div>Hello shell</div>{% end %}",
            encoding="utf-8",
        )
        env = create_environment(AppConfig(template_dir=tmp_path), filters={}, globals_={})

        result = negotiate(Template("page.html"), kida_env=env)

        assert result.status == 200
        assert "Shell App" in result.text
        assert "Hello shell" in result.text
        assert 'class="chirpui-app-shell' in result.text

    def test_template_extending_chirpui_app_shell_layout_keeps_collapsible_override(
        self,
        tmp_path: Path,
    ) -> None:
        (tmp_path / "page.html").write_text(
            '{% extends "chirpui/app_shell_layout.html" %}'
            "{% block sidebar_collapsible %}true{% end %}"
            "{% block brand %}Shell App{% end %}"
            "{% block content %}<div>Hello shell</div>{% end %}",
            encoding="utf-8",
        )
        env = create_environment(AppConfig(template_dir=tmp_path), filters={}, globals_={})

        result = negotiate(Template("page.html"), kida_env=env)

        assert result.status == 200
        assert 'data-sidebar-collapsible="true"' in result.text

    @pytest.mark.asyncio
    async def test_layout_suspense_boosted_navigation_appends_shell_actions_oob(
        self,
        tmp_path: Path,
    ) -> None:
        from chirp.http.response import StreamingResponse
        from chirp.pages.types import LayoutChain, LayoutInfo

        (tmp_path / "dashboard.html").write_text(
            "<h1>{{ title }}</h1>"
            '<div id="stats">{% block stats %}'
            "{% if stats %}<p>{{ stats[0] }}</p>{% else %}<p>Loading stats...</p>{% end %}"
            "{% end %}</div>",
            encoding="utf-8",
        )
        (tmp_path / "_layout.html").write_text(
            "{# target: body #}"
            '<html><body><div id="chirp-shell-actions"></div><main id="main">{% block content %}{% end %}</main></body></html>',
            encoding="utf-8",
        )
        env = create_environment(AppConfig(template_dir=tmp_path), filters={}, globals_={})

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/dashboard",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-boosted", b"true"),
                    (b"hx-target", b"main"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

        async def _stats():
            return ["ready"]

        result = negotiate(
            LayoutSuspense(
                Suspense("dashboard.html", title="Dashboard", stats=_stats()),
                LayoutChain(layouts=(LayoutInfo("_layout.html", "body", 0),)),
                context={
                    "shell_actions": ShellActions(
                        primary=ShellActionZone(
                            items=(ShellAction(id="deploy", label="Deploy", href="/deploy"),)
                        )
                    )
                },
                request=request,
            ),
            kida_env=env,
            request=request,
        )

        assert isinstance(result, StreamingResponse)
        chunks = [chunk async for chunk in result.chunks]
        combined = "".join(chunks)
        assert "Loading stats..." in combined
        assert 'id="chirp-shell-actions"' in combined
        assert 'hx-swap-oob="innerHTML"' in combined
        assert 'href="/deploy"' in combined

    def test_layout_page_boosted_navigation_prefers_page_block_name(self, tmp_path: Path) -> None:
        env = Environment(loader=FileSystemLoader(str(tmp_path)))
        (tmp_path / "base.html").write_text(
            '{% block page_root %}<section class="page-root">{% block panel %}{% endblock %}</section>{% endblock %}'
        )
        (tmp_path / "child.html").write_text(
            '{% extends "base.html" %}{% block panel %}<div id="panel">{{ body }}</div>{% endblock %}'
        )

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/child",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-boosted", b"true"),
                    (b"hx-target", b"main"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

        result = negotiate(
            LayoutPage("child.html", "panel", page_block_name="page_root", body="Hello"),
            kida_env=env,
            request=request,
        )

        assert result.render_intent == "fragment"
        assert 'class="page-root"' in result.text
        assert 'id="panel"' in result.text
        assert "Hello" in result.text

    def test_layout_page_non_boosted_fragment_keeps_fragment_block(self, tmp_path: Path) -> None:
        env = Environment(loader=FileSystemLoader(str(tmp_path)))
        (tmp_path / "base.html").write_text(
            '{% block page_root %}<section class="page-root">{% block panel %}{% endblock %}</section>{% endblock %}'
        )
        (tmp_path / "child.html").write_text(
            '{% extends "base.html" %}{% block panel %}<div id="panel">{{ body }}</div>{% endblock %}'
        )

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        request = Request.from_asgi(
            {
                "type": "http",
                "method": "GET",
                "path": "/child",
                "headers": [
                    (b"hx-request", b"true"),
                    (b"hx-target", b"panel"),
                ],
                "query_string": b"",
                "http_version": "1.1",
                "server": ("127.0.0.1", 8000),
                "client": ("127.0.0.1", 1234),
            },
            receive=_receive,
        )

        result = negotiate(
            LayoutPage("child.html", "panel", page_block_name="page_root", body="Hello"),
            kida_env=env,
            request=request,
        )

        assert result.render_intent == "fragment"
        assert 'id="panel"' in result.text
        assert "Hello" in result.text
        assert 'class="page-root"' not in result.text


class TestNegotiateErrors:
    def test_unknown_type_raises(self) -> None:
        with pytest.raises(TypeError, match="Cannot convert"):
            negotiate(42)

    def test_error_message_helpful(self) -> None:
        with pytest.raises(TypeError, match="int"):
            negotiate(42)
