"""Copyright (C) 2025-2025 Pico Technology Ltd. See LICENSE file for terms."""
__version__ = "1.7.1"
