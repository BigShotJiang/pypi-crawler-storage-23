import aiohttp
import re
import json
import urllib.parse
from typing import Dict, Any, Optional
from .base import BaseExtractor

class YouTubeExtractor(BaseExtractor):
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

    def matches(self, url: str) -> bool:
        return "youtube.com" in url or "youtu.be" in url

    async def extract(self, url: str) -> Dict[str, Any]:
        """Extract YouTube video metadata without using external libraries."""
        video_id = self.get_video_id(url)
        if not video_id:
            raise ValueError(f"Could not extract video ID from URL: {url}")
            
        async with aiohttp.ClientSession(headers=self.headers) as session:
            # Fetch the video page to get initial player response
            async with session.get(f"https://www.youtube.com/watch?v={video_id}") as response:
                html = await response.text()
                
                # Extract ytInitialPlayerResponse JSON
                match = re.search(r'ytInitialPlayerResponse\s*=\s*({.+?});', html)
                if not match:
                    # Alternative pattern
                    match = re.search(r'var\s+ytInitialPlayerResponse\s*=\s*({.+?});', html)
                
                if not match:
                    raise ValueError("Could not find video metadata in page.")
                
                player_response = json.loads(match.group(1))
                streaming_data = player_response.get('streamingData', {})
                video_details = player_response.get('videoDetails', {})
                
                # Process formats
                formats = streaming_data.get('formats', []) + streaming_data.get('adaptiveFormats', [])
                
                # Find best video and audio separately (for highest quality)
                best_video = None
                best_audio = None
                
                for f in formats:
                    mime_type = f.get('mimeType', '')
                    if 'video' in mime_type:
                        if not best_video or f.get('width', 0) > best_video.get('width', 0):
                            best_video = f
                    if 'audio' in mime_type:
                        if not best_audio or f.get('averageBitrate', 0) > best_audio.get('averageBitrate', 0):
                            best_audio = f
                
                return {
                    'title': video_details.get('title', 'YouTube Video'),
                    'video_url': best_video.get('url') if best_video else None,
                    'audio_url': best_audio.get('url') if best_audio else None,
                    'thumbnail': video_details.get('thumbnail', {}).get('thumbnails', [{}])[-1].get('url'),
                    'duration': int(video_details.get('lengthSeconds', 0)),
                    'ext': 'mp4',
                    'original_info': player_response
                }

    def get_video_id(self, url: str) -> Optional[str]:
        """Extract the video ID from a YouTube URL."""
        if 'youtu.be' in url:
            return url.split('/')[-1].split('?')[0]
        elif 'youtube.com' in url:
            parsed_url = urllib.parse.urlparse(url)
            query = urllib.parse.parse_qs(parsed_url.query)
            return query.get('v', [None])[0]
        return None
