from abc import ABC, abstractmethod
from typing import Dict, Any

class BaseExtractor(ABC):
    @abstractmethod
    async def extract(self, url: str) -> Dict[str, Any]:
        """Extract video information from the URL."""
        pass

    @abstractmethod
    def matches(self, url: str) -> bool:
        """Check if this extractor can handle the given URL."""
        pass
