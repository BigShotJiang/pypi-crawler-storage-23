import asyncio
import os
import subprocess

class Transmuxer:
    def __init__(self, ffmpeg_path: str = "ffmpeg"):
        self.ffmpeg_path = ffmpeg_path

    async def merge(self, video_path: str, audio_path: str, output_path: str):
        """Merge separate video and audio files into a single output file."""
        if not audio_path:
            # If no audio, just rename video_path to output_path
            os.rename(video_path, output_path)
            return output_path
        
        # Build the ffmpeg command
        # Use .mp4 as a safe default container if merging different formats
        if not output_path.endswith('.mp4'):
            output_path = os.path.splitext(output_path)[0] + ".mp4"

        command = [
            self.ffmpeg_path,
            "-y",
            "-i", video_path,
            "-i", audio_path,
            "-c:v", "copy",
            "-c:a", "aac", # Re-encode audio to aac for maximum compatibility in mp4
            "-strict", "experimental",
            output_path
        ]
        
        # Execute ffmpeg
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            raise RuntimeError(f"FFmpeg failed with error: {stderr.decode()}")
        
        # Cleanup temporary files
        os.remove(video_path)
        os.remove(audio_path)
        
        return output_path
