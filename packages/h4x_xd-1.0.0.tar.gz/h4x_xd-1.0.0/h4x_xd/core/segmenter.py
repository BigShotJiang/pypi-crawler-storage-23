import asyncio
import aiohttp
import os
import time
from typing import Optional, Callable

class Segmenter:
    def __init__(self, url: str, output_path: str, num_chunks: int = 16, timeout: int = 30):
        self.url = url
        self.output_path = output_path
        self.num_chunks = num_chunks
        self.timeout = timeout
        self.file_size = 0
        self.downloaded_bytes = 0

    async def get_info(self, session: aiohttp.ClientSession):
        async with session.head(self.url, allow_redirects=True, timeout=self.timeout) as response:
            self.file_size = int(response.headers.get('Content-Length', 0))
            return response.headers.get('Accept-Ranges') == 'bytes'

    async def download_chunk(self, session: aiohttp.ClientSession, start: int, end: int, chunk_id: int, progress_callback: Optional[Callable] = None):
        headers = {'Range': f'bytes={start}-{end}'}
        chunk_path = f"{self.output_path}.part{chunk_id}"
        
        try:
            async with session.get(self.url, headers=headers, timeout=self.timeout) as response:
                if response.status not in (200, 206):
                    raise Exception(f"Failed to download chunk {chunk_id}: HTTP {response.status}")
                
                with open(chunk_path, 'wb') as f:
                    async for chunk in response.content.iter_chunked(1024 * 64): # 64KB chunks
                        f.write(chunk)
                        self.downloaded_bytes += len(chunk)
                        if progress_callback:
                            progress_callback(self.downloaded_bytes, self.file_size)
            return chunk_path
        except Exception as e:
            if os.path.exists(chunk_path):
                os.remove(chunk_path)
            raise e

    async def download(self, progress_callback: Optional[Callable] = None):
        connector = aiohttp.TCPConnector(limit=self.num_chunks)
        async with aiohttp.ClientSession(connector=connector) as session:
            supports_ranges = await self.get_info(session)
            
            if not supports_ranges or self.file_size == 0:
                # Fallback to single connection
                async with session.get(self.url, timeout=self.timeout) as response:
                    with open(self.output_path, 'wb') as f:
                        async for chunk in response.content.iter_chunked(1024 * 64):
                            f.write(chunk)
                            self.downloaded_bytes += len(chunk)
                            if progress_callback:
                                progress_callback(self.downloaded_bytes, self.file_size)
                return self.output_path

            chunk_size = self.file_size // self.num_chunks
            tasks = []
            for i in range(self.num_chunks):
                start = i * chunk_size
                end = (i + 1) * chunk_size - 1 if i < self.num_chunks - 1 else self.file_size - 1
                tasks.append(self.download_chunk(session, start, end, i, progress_callback))

            chunk_paths = await asyncio.gather(*tasks)

            # Merge chunks efficiently
            with open(self.output_path, 'wb') as outfile:
                for chunk_path in sorted(chunk_paths, key=lambda x: int(x.split('.part')[-1])):
                    with open(chunk_path, 'rb') as infile:
                        while chunk := infile.read(1024 * 1024): # 1MB buffer
                            outfile.write(chunk)
                    os.remove(chunk_path)

            return self.output_path
