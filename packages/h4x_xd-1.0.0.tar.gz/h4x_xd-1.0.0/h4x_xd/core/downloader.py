import os
import asyncio
from typing import Optional, List
from .segmenter import Segmenter
from .transmuxer import Transmuxer
from ..extractors.youtube import YouTubeExtractor
from ..extractors.base import BaseExtractor

class Downloader:
    def __init__(self, output_dir: str = "downloads", num_chunks: int = 8):
        self.output_dir = output_dir
        self.num_chunks = num_chunks
        self.extractors: List[BaseExtractor] = [YouTubeExtractor()]
        self.transmuxer = Transmuxer()
        
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    async def download(self, url: str, filename: Optional[str] = None) -> str:
        # 1. Extract info
        extractor = None
        for ext in self.extractors:
            if ext.matches(url):
                extractor = ext
                break
        
        if not extractor:
            raise ValueError(f"No extractor found for URL: {url}")
            
        info = await extractor.extract(url)
        title = filename or info['title'].replace('/', '_')
        ext = info.get('ext', 'mp4')
        
        # 2. Download video and audio separately
        video_path = os.path.join(self.output_dir, f"{title}_video.tmp")
        audio_path = os.path.join(self.output_dir, f"{title}_audio.tmp") if info['audio_url'] else None
        
        tasks = [Segmenter(info['video_url'], video_path, self.num_chunks).download()]
        if audio_path:
            tasks.append(Segmenter(info['audio_url'], audio_path, self.num_chunks).download())
            
        await asyncio.gather(*tasks)
        
        # 3. Merge
        final_path = os.path.join(self.output_dir, f"{title}.{ext}")
        await self.transmuxer.merge(video_path, audio_path, final_path)
        
        return final_path
