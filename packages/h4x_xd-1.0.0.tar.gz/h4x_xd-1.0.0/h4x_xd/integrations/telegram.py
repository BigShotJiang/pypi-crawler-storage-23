import io
import asyncio
from typing import AsyncGenerator
from ..core.downloader import Downloader

class TelegramHelper:
    def __init__(self, downloader: Downloader = None):
        self.downloader = downloader or Downloader()

    async def stream_to_buffer(self, url: str) -> io.BytesIO:
        """Download a video and return it as an in-memory buffer (BytesIO)."""
        path = await self.downloader.download(url)
        buffer = io.BytesIO()
        with open(path, 'rb') as f:
            buffer.write(f.read())
        buffer.seek(0)
        # Cleanup file after reading into memory
        import os
        os.remove(path)
        return buffer

    async def get_stream(self, url: str) -> AsyncGenerator[bytes, None]:
        """Generator for streaming video content directly."""
        path = await self.downloader.download(url)
        with open(path, 'rb') as f:
            while chunk := f.read(8192):
                yield chunk
        import os
        os.remove(path)
