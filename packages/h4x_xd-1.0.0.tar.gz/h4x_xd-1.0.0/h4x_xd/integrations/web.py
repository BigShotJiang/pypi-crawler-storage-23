from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from ..core.downloader import Downloader
from .telegram import TelegramHelper

router = APIRouter()
downloader = Downloader()
telegram_helper = TelegramHelper(downloader)

@router.get("/download")
async def web_download(url: str):
    """API endpoint to download and stream video directly to the user's browser."""
    try:
        # Get a generator for the video file
        async def video_generator():
            async for chunk in telegram_helper.get_stream(url):
                yield chunk
        
        return StreamingResponse(
            video_generator(), 
            media_type="video/mp4",
            headers={"Content-Disposition": f"attachment; filename=video.mp4"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
