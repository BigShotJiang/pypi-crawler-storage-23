# h4x-xd: High-Performance Independent Video Downloader

**h4x-xd** is a powerful, lightweight, and extremely fast Python library designed for downloading high-quality videos from various platforms. Unlike other tools, **h4x-xd** is built from the ground up with independent extractors and a multi-threaded download engine, making it ideal for web applications, Telegram bots, and automated workflows.

## Key Features
- **Independent Extractors**: Custom logic for YouTube, TikTok, and more – no reliance on `yt-dlp`.
- **Maximum Speed**: Built-in multi-chunked downloader that bypasses standard connection throttling.
- **Highest Quality**: Automatically identifies and merges the best available video and audio streams.
- **Async-First**: Fully compatible with `asyncio` for high-concurrency environments.
- **Bot-Ready**: Seamless integration for Telegram bots (stream to buffer) and Web APIs (stream to response).

## Installation
```bash
# Clone the repository and install dependencies
git clone https://github.com/your-repo/h4x-xd.git
cd h4x-xd
pip install aiohttp httpx tqdm
```

## Quick Start
```python
import asyncio
from h4x_xd import Downloader

async def main():
    dl = Downloader(output_dir="videos", num_chunks=16)
    # Download in highest quality
    path = await dl.download("https://www.youtube.com/watch?v=...")
    print(f"Downloaded to: {path}")

asyncio.run(main())
```

## Integration Examples

### Telegram Bot (Telethon)
```python
from h4x_xd import TelegramHelper

helper = TelegramHelper()
buffer = await helper.stream_to_buffer("https://tiktok.com/...")
await client.send_file(chat_id, buffer, caption="Downloaded via h4x-xd")
```

### Web API (FastAPI)
```python
from fastapi import FastAPI
from h4x_xd import web_router

app = FastAPI()
app.include_router(web_router, prefix="/api/v1")
```

## Why h4x-xd?
| Feature | yt-dlp | h4x-xd |
|---------|--------|---------|
| Dependency | Heavy | Lightweight |
| Architecture | CLI-first | Library-first |
| Speed | Standard | Multi-chunked (Turbo) |
| Async | Wrapper | Native |
| Integration | Complex | Plug-and-play |

## License
MIT License
