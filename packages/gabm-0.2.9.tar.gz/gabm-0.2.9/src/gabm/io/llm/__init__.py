"""GABM: Generative Agent-Based Model framework llm package."""
__version__ = "1.0.0"