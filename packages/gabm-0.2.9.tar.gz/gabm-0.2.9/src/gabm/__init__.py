"""GABM: Generative Agent-Based Model framework gabm package."""
__version__ = "0.2.9"