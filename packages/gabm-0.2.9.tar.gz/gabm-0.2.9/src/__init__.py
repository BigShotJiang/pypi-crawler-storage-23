"""GABM: Generative Agent-Based Model framework src package."""
__version__ = "0.2.9"