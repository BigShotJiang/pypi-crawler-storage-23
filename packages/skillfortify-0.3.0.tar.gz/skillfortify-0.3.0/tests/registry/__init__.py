"""Tests for the SkillFortify registry scanning module."""
