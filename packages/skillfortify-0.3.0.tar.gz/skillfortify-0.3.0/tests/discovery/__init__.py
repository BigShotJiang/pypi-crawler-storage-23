"""Tests for the discovery module — system auto-discovery scanner."""
