"""
Percentage type for stackraise models.

Stores values in the 0–1 range internally (DB / API) while being
semantically annotated so the frontend knows to present them as 0–100.

Usage in domain models::

    class Campaign(db.Document):
        agency_fee: Annotated[
            model.Percentage,
            model.Field(description="Agency fee percentage"),
        ]

The Pydantic validator ensures the value stays within [0, 1].
"""

from typing import Annotated
from pydantic import Field as PydanticField

__all__ = ["Percentage"]

Percentage = Annotated[
    float,
    PydanticField(ge=0, le=1, description="A percentage value stored in the 0–1 range"),
]
