"""Archived legacy v1 modules kept for compatibility."""
