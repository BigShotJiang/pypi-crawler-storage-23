"""FastAPI application with MCP server (Streamable HTTP transport)."""

from __future__ import annotations

import logging
import logging.config
from contextlib import asynccontextmanager

# Configure root logger so all cube_cloud.* loggers emit to stderr
logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(name)s: %(message)s")

import uvicorn
from fastapi import FastAPI
from mcp.server.lowlevel import Server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from mcp.types import Tool, TextContent
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount
from starlette.websockets import WebSocket, WebSocketDisconnect

from cube_common.apollo_client import ApolloClient, ApolloError
from cube_cloud.auth.middleware import APIKeyMiddleware
from cube_cloud.config import settings
from cube_cloud.tools import (
    environments, entities, acr, clusters, kubectl_exec, apps,
    products, change_requests, modules, secrets,
)
from cube_cloud._request_context import current_request

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MCP Server definition
# ---------------------------------------------------------------------------

mcp_server = Server("cube-cloud")


@mcp_server.list_tools()
async def list_tools() -> list[Tool]:
    # Import tool schemas from the shared proxy_tools definitions.
    # proxy_tools.py is the single source of truth for tool schemas;
    # cube-cloud just needs to accept and dispatch them.
    from cube_agent.remote.proxy_tools import REMOTE_TOOLS
    return list(REMOTE_TOOLS)


@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Route tool calls to the appropriate handler.

    Credentials come from request.state (set by APIKeyMiddleware).
    Threaded via contextvars since MCP handlers don't receive the request.
    """
    req = current_request.get()
    client_id = req.state.apollo_client_id
    client_secret = req.state.apollo_client_secret

    async with ApolloClient(client_id, client_secret) as client:
        try:
            result = await _dispatch(client, name, arguments)
        except ApolloError as e:
            result = f"Error: {e}"

    return [TextContent(type="text", text=result)]


async def _dispatch(client: ApolloClient, name: str, args: dict) -> str:
    match name:
        # --- Environment management ---
        case "list_environments":
            return await environments.list_environments(client, args.get("search"))
        case "create_environment":
            return await environments.create_environment(
                client, args["name"], args.get("accreditation", "DEV")
            )
        case "replicate_environment":
            return await environments.replicate_environment(
                client, args["source"], args["target"], args.get("accreditation", "DEV")
            )
        case "delete_environment":
            return await environments.delete_environment(client, args["environment"])
        case "reset_environment_agents":
            return await environments.reset_environment_agents(client, args["environment"])

        # --- Entity management ---
        case "install_entity":
            return await environments.install_entity(
                client,
                args["environment"],
                args["entity_name"],
                args["product_id"],
                args.get("k8s_namespace", "default"),
                args.get("config_overrides"),
            )
        case "uninstall_entity":
            return await environments.uninstall_entity(
                client, args["environment"], args["entity_name"]
            )
        case "update_entity_config":
            return await environments.update_entity_config(
                client, args["environment"], args["entity_name"], args["config"]
            )
        case "enforce_entity_config":
            return await environments.enforce_entity_config(
                client, args["environment"], args["entity_name"]
            )
        case "entity_health":
            return await entities.entity_health(
                client, args["environment"], args.get("entity_id")
            )
        case "plan_details":
            return await entities.plan_details(
                client, args["environment"], args["entity_name"], args.get("plan_index", 0)
            )

        # --- Module management ---
        case "list_modules":
            return await modules.list_modules(
                client, args["environment"], args.get("search")
            )
        case "install_module":
            return await modules.install_module(
                client,
                args["environment"],
                args["maven_coordinate"],
                args.get("variables"),
                args.get("display_name"),
                args.get("ignore_secret_requirements", False),
            )
        case "uninstall_module":
            return await modules.uninstall_module(
                client, args["environment"], args["module_name"]
            )
        case "update_module_variables":
            return await modules.update_module_variables(
                client, args["environment"], args["module_name"], args["variables"]
            )

        # --- Secret management ---
        case "create_secret":
            return await secrets.create_secret(
                client,
                args["environment"],
                args["entity_name"],
                args["secret_name"],
                args.get("secret_value"),
                args.get("secret_keys"),
                args.get("description"),
            )
        case "update_secret":
            return await secrets.update_secret(
                client,
                args["environment"],
                args["entity_name"],
                args["secret_name"],
                args.get("secret_value"),
                args.get("secret_key"),
                args.get("secret_key_value"),
                args.get("description"),
            )

        # --- Product management ---
        case "list_products":
            return await products.list_products(
                client, args.get("search"), args.get("page_size", 50)
            )
        case "compare_product_versions":
            return await products.compare_product_versions(
                client, args["product_id"], args["environments"]
            )
        case "get_product_releases":
            return await products.get_product_releases(
                client, args["product_id"], args.get("page_size", 10)
            )
        case "set_label_on_product":
            return await products.set_label_on_product(
                client, args["product_id"], args["label_id"], args["label_value"]
            )
        case "remove_label_from_product":
            return await products.remove_label_from_product(
                client, args["product_id"], args["label_id"]
            )

        # --- Release channel management ---
        case "list_release_channels":
            return await products.list_release_channels(
                client, args.get("search"), args.get("include_env_specific", False)
            )
        case "add_product_to_release_channel":
            return await products.add_product_to_release_channel(
                client,
                args["product_id"],
                args["version"],
                args["channels"],
                args.get("rationale"),
            )
        case "remove_product_from_release_channel":
            return await products.remove_product_from_release_channel(
                client,
                args["product_id"],
                args["version"],
                args["channels"],
                args.get("rationale"),
            )

        # --- Change request management ---
        case "list_change_requests":
            return await change_requests.list_change_requests(
                client,
                args.get("environment"),
                args.get("status"),
                args.get("page_size", 10),
            )
        case "review_change_request":
            return await change_requests.review_change_request(
                client, args["rid"], args["action"], args.get("comment")
            )

        # --- ACR / publish ---
        case "acr_get_token":
            return await acr.acr_get_token(client)
        case "apollo_publish_manifest":
            return await acr.apollo_publish_manifest(client, args["manifest_yaml"])

        # --- Teleport / kubectl (no Apollo client needed) ---
        case "cube_status" | "cube_list" | "kubectl_exec" | "app_list" | "cube_cluster_login":
            return await _dispatch_teleport(name, args)

        case _:
            return f"Unknown tool: {name}"


async def _dispatch_teleport(name: str, args: dict) -> str:
    """Dispatch tools that use server-side tbot/kubectl (no Apollo client needed)."""
    match name:
        case "cube_status":
            return await clusters.cube_status(args.get("cluster"))
        case "cube_list":
            return await clusters.cube_list()
        case "kubectl_exec":
            return await kubectl_exec.kubectl_exec(
                args["command"], cluster=args.get("cluster")
            )
        case "app_list":
            return await apps.app_list(args.get("company"))
        case "cube_cluster_login":
            return await clusters.cube_cluster_login(args["cluster"])
        case _:
            return f"Unknown teleport tool: {name}"


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(title="cube-cloud", version="0.1.0")
app.add_middleware(APIKeyMiddleware)


@app.get("/health")
async def health():
    from cube_cloud.teleport.tbot_manager import tbot
    return {"status": "ok", "tbot": tbot.status(), "tunnel": _tunnel_conn_mgr.status()}


# ---------------------------------------------------------------------------
# Browser login flow (Cognito)
# ---------------------------------------------------------------------------

from pathlib import Path
from starlette.staticfiles import StaticFiles
from cube_cloud.auth.login_flow import auth_login, auth_authenticate, auth_session, setup_page

app.add_api_route("/auth/login", auth_login, methods=["GET"])
app.add_api_route("/auth/authenticate", auth_authenticate, methods=["POST"])
app.add_api_route("/auth/session/{session_id}", auth_session, methods=["GET"])
app.add_api_route("/setup", setup_page, methods=["GET"])
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")


# ---------------------------------------------------------------------------
# Tunnel relay (Phase 4) — WebSocket endpoint for app proxy
# ---------------------------------------------------------------------------

from cube_cloud.tunnel.connection_manager import ConnectionManager
from cube_cloud.tunnel.relay import TunnelRelay

_tunnel_conn_mgr = ConnectionManager()


@app.websocket("/tunnel")
async def tunnel_endpoint(ws: WebSocket):
    """WebSocket tunnel endpoint for cube-agent app proxy.

    The agent opens a WebSocket here, then sends CONNECT frames to
    request TCP connections to Teleport apps. Data is relayed
    bidirectionally via binary frames.
    """
    # Validate API key from query param or header
    api_key = ws.query_params.get("token") or ws.headers.get("authorization", "").removeprefix("Bearer ").strip()
    if not api_key:
        await ws.close(code=4001, reason="Missing authentication")
        return

    from cube_cloud.auth.api_keys import validate_key
    try:
        profile = await validate_key(api_key)
    except Exception as e:
        logger.error("Tunnel auth error: %s", e)
        await ws.close(code=4001, reason="Auth error")
        return
    if not profile:
        logger.warning("Tunnel auth failed: invalid API key")
        await ws.close(code=4001, reason="Invalid API key")
        return

    logger.info("Tunnel WebSocket authenticated, profile=%s", profile.get("profile"))
    await ws.accept()

    try:
        relay = TunnelRelay(ws, _tunnel_conn_mgr)
        await relay.run()
    except Exception as e:
        logger.error("Tunnel endpoint error: %s", e)


# ---------------------------------------------------------------------------
# Mount MCP at /mcp using StreamableHTTPSessionManager
# ---------------------------------------------------------------------------
# The session manager is an ASGI app that handles session lifecycle.
# We wrap it to inject the Starlette Request into a contextvar so MCP
# tool handlers can access auth state.

session_manager = StreamableHTTPSessionManager(
    app=mcp_server,
    json_response=True,
    stateless=True,
)


async def mcp_asgi_with_context(scope, receive, send):
    """ASGI wrapper that sets the current_request contextvar."""
    if scope["type"] == "http":
        request = Request(scope, receive, send)
        token = current_request.set(request)
        try:
            await session_manager.handle_request(scope, receive, send)
        finally:
            current_request.reset(token)
    else:
        await session_manager.handle_request(scope, receive, send)


app.mount("/mcp", mcp_asgi_with_context)


# ---------------------------------------------------------------------------
# Lifespan — start the MCP session manager's internal task group
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    async with session_manager.run():
        logger.info("MCP session manager started")
        yield
    logger.info("MCP session manager stopped")


app.router.lifespan_context = lifespan


def cli():
    """Entry point for the cube-cloud CLI."""
    uvicorn.run(
        "cube_cloud.main:app",
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level,
    )


if __name__ == "__main__":
    cli()
