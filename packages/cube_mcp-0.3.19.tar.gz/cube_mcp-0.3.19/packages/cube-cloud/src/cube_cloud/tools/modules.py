"""Module management tools."""

from __future__ import annotations

import json

from cube_common.apollo_client import ApolloClient, ApolloError
from cube_common import apollo_queries as Q

from cube_cloud.tools.environments import _resolve_environment


async def list_modules(
    client: ApolloClient, environment: str, search: str | None = None
) -> str:
    env_info = await _resolve_environment(client, environment)
    env_id = env_info["id"]
    env_name = env_info.get("name", environment)

    data = await client.graphql(Q.LIST_MODULES, {"id": env_id})
    modules = (
        data.get("apollo", {})
        .get("environmentById", {})
        .get("moduleInstallationsV2", {})
        .get("moduleInstallations", [])
    )

    if search:
        search_lower = search.lower()
        modules = [
            m for m in modules
            if search_lower in (m.get("displayName") or "").lower()
            or search_lower in (m.get("moduleMavenCoordinate") or "").lower()
        ]

    if not modules:
        suffix = f' matching "{search}"' if search else ""
        return f"No modules found on {env_name}{suffix}."

    lines = [f"Modules on {env_name} ({len(modules)})", "=" * 60]
    for m in modules:
        name = m.get("displayName") or "(unnamed)"
        coord = m.get("moduleMavenCoordinate", "?")
        rid = m.get("rid", "")
        state = (
            m.get("state", {})
            .get("__typename", "")
            .replace("ApolloProductModuleInstallationStateV2_", "")
        )
        variables = m.get("variables", [])

        lines.append(f"  {name}")
        lines.append(f"    Coordinate: {coord}")
        lines.append(f"    State:      {state}")
        lines.append(f"    RID:        {rid}")
        if variables:
            for v in variables:
                vname = v.get("variableName", "?")
                vval = v.get("variableValue", {}).get("value", "?")
                lines.append(f"    Var: {vname} = {vval}")

    return "\n".join(lines)


def _find_module(modules: list, search: str) -> dict | None:
    """Find a module by display name or coordinate substring."""
    search_lower = search.lower()

    # Exact match first
    for m in modules:
        if (m.get("displayName") or "").lower() == search_lower:
            return m
        if (m.get("moduleMavenCoordinate") or "").lower() == search_lower:
            return m

    # Substring match
    matches = [
        m for m in modules
        if search_lower in (m.get("displayName") or "").lower()
        or search_lower in (m.get("moduleMavenCoordinate") or "").lower()
    ]
    if len(matches) == 1:
        return matches[0]

    return None


async def install_module(
    client: ApolloClient,
    environment: str,
    maven_coordinate: str,
    variables: str | None = None,
    display_name: str | None = None,
    ignore_secret_requirements: bool = False,
) -> str:
    env_info = await _resolve_environment(client, environment)
    env_id = env_info["id"]
    env_name = env_info.get("name", environment)

    var_inputs = []
    if variables:
        try:
            var_dict = json.loads(variables)
        except json.JSONDecodeError:
            return f"Error: variables must be valid JSON. Got: {variables[:200]}"

        for k, v in var_dict.items():
            var_inputs.append({
                "variableName": k,
                "variableValue": {"stringValue": str(v)},
            })

    request: dict = {
        "apolloEnvironmentId": env_id,
        "mavenCoordinate": maven_coordinate,
        "variables": var_inputs,
        "options": [],
    }
    if display_name:
        request["displayName"] = display_name
    if ignore_secret_requirements:
        request["ignoreSecretRequirements"] = True

    data = await client.graphql(Q.INSTALL_MODULE, {"request": request})
    result = data.get("apollo", {}).get("installModuleV2", {})
    state = (
        result.get("state", {})
        .get("__typename", "")
        .replace("ApolloProductModuleInstallationStateV2_", "")
    )

    return (
        f"Module installed on {env_name}\n"
        f"  Coordinate: {maven_coordinate}\n"
        f"  Display:    {result.get('displayName', display_name or '')}\n"
        f"  RID:        {result.get('rid', '')}\n"
        f"  State:      {state}"
    )


async def uninstall_module(
    client: ApolloClient, environment: str, module_name: str
) -> str:
    env_info = await _resolve_environment(client, environment)
    env_id = env_info["id"]
    env_name = env_info.get("name", environment)

    data = await client.graphql(Q.LIST_MODULES, {"id": env_id})
    modules = (
        data.get("apollo", {})
        .get("environmentById", {})
        .get("moduleInstallationsV2", {})
        .get("moduleInstallations", [])
    )

    module = _find_module(modules, module_name)
    if not module:
        names = [
            m.get("displayName") or m.get("moduleMavenCoordinate", "?")
            for m in modules
        ]
        return (
            f"Module '{module_name}' not found on {env_name}.\n"
            f"Available modules:\n" + "\n".join(f"  - {n}" for n in names)
        )

    module_rid = module["rid"]
    display = module.get("displayName") or module.get("moduleMavenCoordinate", "?")

    await client.graphql(Q.UNINSTALL_MODULE, {"rid": module_rid})
    return f"Module unlinked from {env_name}: {display}\n  RID: {module_rid}"


async def update_module_variables(
    client: ApolloClient,
    environment: str,
    module_name: str,
    variables: str,
) -> str:
    env_info = await _resolve_environment(client, environment)
    env_id = env_info["id"]
    env_name = env_info.get("name", environment)

    try:
        var_dict = json.loads(variables)
    except json.JSONDecodeError:
        return f"Error: variables must be valid JSON. Got: {variables[:200]}"

    data = await client.graphql(Q.LIST_MODULES, {"id": env_id})
    modules = (
        data.get("apollo", {})
        .get("environmentById", {})
        .get("moduleInstallationsV2", {})
        .get("moduleInstallations", [])
    )

    module = _find_module(modules, module_name)
    if not module:
        names = [
            m.get("displayName") or m.get("moduleMavenCoordinate", "?")
            for m in modules
        ]
        return (
            f"Module '{module_name}' not found on {env_name}.\n"
            f"Available modules:\n" + "\n".join(f"  - {n}" for n in names)
        )

    module_rid = module["rid"]
    display = module.get("displayName") or module.get("moduleMavenCoordinate", "?")

    var_inputs = []
    for k, v in var_dict.items():
        var_inputs.append({
            "variableName": k,
            "variableValue": {"stringValue": str(v)},
        })

    result_data = await client.graphql(
        Q.UPDATE_MODULE_VARIABLES, {"rid": module_rid, "variables": var_inputs}
    )
    result = result_data.get("apollo", {}).get("updateModuleVariablesV2", {})
    state = (
        result.get("state", {})
        .get("__typename", "")
        .replace("ApolloProductModuleInstallationStateV2_", "")
    )

    lines = [
        f"Module variables updated on {env_name}: {display}",
        f"  RID:   {module_rid}",
        f"  State: {state}",
        f"  Updated variables:",
    ]
    for k, v in var_dict.items():
        lines.append(f"    {k} = {v}")

    return "\n".join(lines)
