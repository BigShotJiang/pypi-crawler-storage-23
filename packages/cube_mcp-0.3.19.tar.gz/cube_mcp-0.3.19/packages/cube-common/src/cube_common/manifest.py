"""Generate Apollo manifest.yml — replaces apollo-cli for manifest generation.

Apollo expects a manifest.yml with product metadata for publishing Helm charts
as Apollo entities. This module generates that YAML without the apollo-cli binary.
"""

from __future__ import annotations


def generate_manifest(
    chart_name: str,
    version: str,
    group_id: str,
    oci_url: str,
) -> str:
    """Generate an Apollo-compatible manifest.yml string.

    Args:
        chart_name: Helm chart name (e.g. "mosquitto")
        version: Chart version (e.g. "1.2.3")
        group_id: Maven group ID (e.g. "com.edgescaleai-cube")
        oci_url: OCI registry URL for the chart

    Returns:
        YAML string for the manifest.
    """
    maven_coordinate = f"{group_id}:{chart_name}:{version}"

    return f"""manifest-version: "1.0"
product-type: helm-chart.v1
product-group: "{group_id}"
product-name: "{chart_name}"
product-version: "{version}"
extensions:
  helm-chart:
    helm-chart-name: "{chart_name}"
    helm-chart-version: "{version}"
    helm-repository-url: "{oci_url}"
"""
