# cube-mcp

MCP (Model Context Protocol) server for EdgescaleAI Cube cluster management and Apollo deployments.

## Quick Start

```bash
# Run directly with npx
npx cube-mcp

# Or install globally
npm install -g cube-mcp
cube-mcp
```

## Register with Claude Code

```bash
claude mcp add cube -- npx cube-mcp
```

## Requirements

This package requires either `uv` or `pipx` to run the Python backend:

```bash
# Install uv (recommended)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Or install pipx
brew install pipx  # macOS
pip install pipx   # other
```

## Available Tools

Once registered with Claude Code, you can use these tools:

- **cube_login** - Authenticate to a Cube cluster via Teleport SSO
- **cube_list** - List available Cube clusters
- **cube_status** - Get Cube node status
- **acr_login** - Login to Apollo Container Registry
- **build_and_publish_to_apollo** - Build and publish your app to Apollo

## Environment Variables

For Apollo operations, set these in your shell:

```bash
export APOLLO_CLIENT="<your-client-id>"
export APOLLO_SECRET="<your-client-secret>"
```

## Links

- [GitHub Repository](https://github.com/edgescaleai/cube-mcp)
- [PyPI Package](https://pypi.org/project/cube-mcp/)
