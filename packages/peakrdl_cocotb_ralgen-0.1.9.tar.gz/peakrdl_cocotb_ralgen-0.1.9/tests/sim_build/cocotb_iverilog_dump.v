module cocotb_iverilog_dump();
initial begin
    $dumpfile("sim_build/mkMDMA.fst");
    $dumpvars(0, mkMDMA);
end
endmodule
