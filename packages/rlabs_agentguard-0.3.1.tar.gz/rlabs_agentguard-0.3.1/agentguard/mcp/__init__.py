"""AgentGuard MCP server package."""

from __future__ import annotations
