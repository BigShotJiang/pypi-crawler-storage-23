import json
import os

from typing import Any, Dict, List, Tuple
from python_on_whales import docker, Image, DockerException
from python_on_whales.utils import run
from python_on_whales.docker_client import DockerClient
from .config.build_config import ImageBuildConfig


HMD_HOME = os.environ.get("HMD_HOME", "/hmd")
if HMD_HOME.endswith("/"):
    HMD_HOME = HMD_HOME[:-1]


def get_client():
    if os.environ.get("HMD_DOCKER_USE_NERDCTL", "false") == "false":
        print("USING DOCKER")
        return docker
    print("USING NERDCTL")
    return DockerClient(client_call=["hmd_nerdctl"])


def build_image_dest(tag: str):
    return f"{HMD_HOME}/.cache/{tag.replace('/', '_').replace(':', '_')}.tar"


def build_platform_tag(tag: str, version: str, platform: str):
    return f"{tag}:{version}-{platform.replace('/', '-')}"


def get_buildkit_worker_host(platform: str) -> str:
    """Get the buildkit worker host for a given platform.

    Returns the Kubernetes service DNS name for the appropriate buildkit worker.
    Falls back to local buildkit if remote workers are not configured.
    """
    use_remote_workers = os.environ.get("HMD_USE_REMOTE_BUILDKIT", "false") == "true"
    if not use_remote_workers:
        return None

    # Map platform to worker service
    if "arm64" in platform or "aarch64" in platform:
        return "tcp://buildkit-worker-arm64.clst-build-workers-buildkit-workers-app-aaa.svc.cluster.local:1234"
    elif "amd64" in platform or "x86_64" in platform:
        return "tcp://buildkit-worker-amd64.clst-build-workers-buildkit-workers-app-aaa.svc.cluster.local:1234"
    else:
        print(f"Warning: Unknown platform {platform}, using local buildkit")
        return None


def build_image(tag: str, version: str, config: ImageBuildConfig) -> List[Image]:
    docker = get_client()
    images: List[Image] = []
    build_args = {**config.build_args}
    use_remote_workers = os.environ.get("HMD_USE_REMOTE_BUILDKIT", "false") == "true"

    if config.cache:
        cache_to = f"type=local,dest={HMD_HOME}/.cache/docker,oci-mediatypes=true,image-manifest=true"
        cache_from = f"type=local,src={HMD_HOME}/.cache/docker"
    else:
        cache_to = None
        cache_from = None
    if os.environ.get("HMD_DOCKER_USE_NERDCTL", "false") == "false":
        buildx_builder = docker.buildx.create(
            use=True,
            driver="docker-container",
            driver_options={"network": "host"},
            buildkitd_flags="--allow-insecure-entitlement network.host",  # Allows for network host option for building in Argo
        )

        with buildx_builder:
            for platform in config.platforms:
                print(f"Building image {tag}:{version} for platform {platform}")
                image = docker.build(
                    config.context_dir,
                    build_args={**build_args, "PLATFORM": platform.split("/")[-1]},
                    tags=build_platform_tag(tag, version, platform),
                    cache=config.cache,
                    cache_to=cache_to,
                    cache_from=cache_from,
                    file=config.dockerfile,
                    secrets=[
                        (
                            f"id={secret.id},src={secret.src}"
                            if secret.src is not None
                            else f"id={secret.id}"
                        )
                        for secret in config.secrets
                    ],
                    platforms=[platform],
                    progress=config.progress,
                    network=config.network,
                    output={
                        "type": "docker",
                        "name": build_platform_tag(tag, version, platform),
                    },
                )

                images.append(image)
        if len(images) == 1:
            if isinstance(images[0], str):
                docker.tag(images[0], f"{tag}:{version}")
            else:
                images[0].tag(f"{tag}:{version}")
    else:
        print(f"Building image {tag}:{version} for platform {config.platforms}")
        quiet = config.progress == "quiet"
        if config.progress == "quiet":
            print("Using quiet progress mode for nerdctl build")
            config.progress = "plain"

        # lines = docker.build(
        #     config.context_dir,
        #     build_args=config.build_args,
        #     tags=f"{tag}:{version}",
        #     cache=config.cache,
        #     cache_to=cache_to,
        #     cache_from=cache_from,
        #     file=config.dockerfile,
        #     secrets=[
        #         (
        #             f"id={secret.id},src={secret.src}"
        #             if secret.src is not None
        #             else f"id={secret.id}"
        #         )
        #         for secret in config.secrets
        #     ],
        #     platforms=config.platforms,
        #     progress=config.progress,
        #     stream_logs=config.progress != False,
        # )
        # for ln in lines:
        #     if not quiet:
        #         print(ln)

        # Build the image for each platform using remote workers if enabled
        for platform in config.platforms:
            buildkit_host = get_buildkit_worker_host(platform)

            if buildkit_host and use_remote_workers:
                print(f"Building {platform} on remote worker: {buildkit_host}")
                # Use buildctl directly for remote builds
                # Export to OCI tar that we can import locally
                import tempfile

                output_tar = tempfile.mktemp(suffix=".tar", dir=f"{HMD_HOME}/.cache")

                buildctl_cmd = [
                    "buildctl",
                    "--addr",
                    buildkit_host,
                    "build",
                    "--frontend",
                    "dockerfile.v0",
                    "--local",
                    f"context={config.context_dir}",
                    "--local",
                    f"dockerfile={os.path.dirname(config.dockerfile)}",
                    "--opt",
                    f"filename={os.path.basename(config.dockerfile)}",
                    "--opt",
                    f"platform={platform}",
                    "--output",
                    f"type=oci,dest={output_tar}",
                ]

                # Add build args
                for key, value in {
                    **build_args,
                    "PLATFORM": platform.split("/")[-1],
                }.items():
                    buildctl_cmd.extend(["--opt", f"build-arg:{key}={value}"])

                # Add secrets
                for secret in config.secrets:
                    if secret.src is not None:
                        buildctl_cmd.extend(
                            ["--secret", f"id={secret.id},src={secret.src}"]
                        )
                    else:
                        buildctl_cmd.extend(["--secret", f"id={secret.id}"])

                # Run buildctl command
                print(f"Running: {' '.join(buildctl_cmd)}")
                result = run(buildctl_cmd)
                if not quiet:
                    print(result)

                # Import the built image into local containerd
                platform_tag = build_platform_tag(tag, version, platform)
                print(f"Importing {platform_tag} from {output_tar}")
                import_cmd = [
                    "nerdctl",
                    "load",
                    f"--platform={platform}",
                    "-i",
                    output_tar,
                ]
                result = run(import_cmd)
                if not quiet:
                    print(result)

                # Extract the digest from the load output
                # Output format: "Loaded image: overlayfs@sha256:..."
                import re

                digest_match = re.search(r"Loaded image: (.+)", result)
                if digest_match:
                    loaded_ref = digest_match.group(1).strip()
                    print(f"Tagging {loaded_ref} as {platform_tag}")
                    docker.tag(loaded_ref, platform_tag)
                else:
                    # Fallback: try tagging from {tag}:latest
                    print(
                        f"Warning: Could not extract digest from load output, trying {tag}:latest"
                    )
                    docker.tag(f"{tag}:latest", platform_tag)

                # Clean up tar file
                os.remove(output_tar)
            else:
                # Use nerdctl for local builds
                print(f"Building {platform} locally with nerdctl")
                lines = docker.build(
                    config.context_dir,
                    build_args={**build_args, "PLATFORM": platform.split("/")[-1]},
                    tags=build_platform_tag(tag, version, platform),
                    cache=True,
                    cache_to=cache_to,
                    cache_from=cache_from,
                    file=config.dockerfile,
                    secrets=[
                        (
                            f"id={secret.id},src={secret.src}"
                            if secret.src is not None
                            else f"id={secret.id}"
                        )
                        for secret in config.secrets
                    ],
                    platforms=[platform],
                    progress=config.progress,
                    stream_logs=config.progress != False,
                )
                for ln in lines:
                    if not quiet:
                        print(ln)

            images.append(build_platform_tag(tag, version, platform))
    return images


def publish_image(tag: str, version: str, config: ImageBuildConfig):
    images = []
    latest_images = []
    docker = get_client()

    if os.environ.get("HMD_DOCKER_USE_NERDCTL", "false") == "false":
        for platform in config.platforms:
            img_tag = build_platform_tag(tag, version, platform)
            docker.push(img_tag)
            images.append(img_tag)

            latest_tag = build_platform_tag(tag, "latest", platform)
            docker.tag(img_tag, latest_tag)
            docker.push(latest_tag)
            latest_images.append(latest_tag)
        docker.manifest.create(name=f"{tag}:{version}", manifests=images)

        docker.manifest.push(f"{tag}:{version}", purge=True)

        docker.manifest.create(name=f"{tag}:latest", manifests=latest_images)

        docker.manifest.push(f"{tag}:latest", purge=True)
    else:
        for platform in config.platforms:
            platform_tag = build_platform_tag(tag, version, platform)
            docker.push(platform_tag)
            images.append(platform_tag)
            latest_tag = build_platform_tag(tag, "latest", platform)
            docker.tag(platform_tag, latest_tag)
            docker.push(latest_tag)
            latest_images.append(latest_tag)

        try:
            manifest_cmd = [
                "manifest-tool",
                "push",
                "from-args",
                "--platforms",
                ",".join(config.platforms),
                "--template",
                f"{tag}:{version}-OS-ARCH",
                "--tags",
                "latest",
                "--target",
                f"{tag}:{version}",
            ]
            print("Pushing manifest with command:", manifest_cmd)
            run(manifest_cmd)
        except DockerException as e:
            print(f"Failed to push manifest for {tag}:{version} with error: {e}")
            raise e


def pull_images(
    tag: str, version, config: ImageBuildConfig, platforms: List[str] = None
) -> Dict[str, str]:
    images = {}

    docker = get_client()
    if platforms is None:
        platforms = config.platforms

    for platform in platforms:
        try:
            img_tag = build_platform_tag(tag, version, platform)
            img = docker.pull(img_tag)
            images[platform] = img_tag
            continue
        except DockerException as e:
            pass

        try:
            img_tag = build_platform_tag(tag, version, platform)
            print(
                docker.docker_cmd
                + ["pull", f"--platform={platform}", f"{tag}:{version}"]
            )
            ret = run(
                docker.docker_cmd
                + ["pull", f"--platform={platform}", f"{tag}:{version}"]
            )
            print(ret)
            docker.tag(f"{tag}:{version}", img_tag)
            images[platform] = img_tag
            continue
        except DockerException as e:
            print(
                f'Failed running: {docker.docker_cmd + ["pull", "--platform", platform, f"{tag}:{version}"]}'
            )
            pass

    if len(images) == 0:
        img_tag = f"{tag}:{version}"
        docker.pull(f"{tag}:{version}")
        images["none"] = img_tag

    print(images)
    return images


def deploy_images(
    image_dict: Dict[str, str],
    target_tag: str,
    version: str,
    config: ImageBuildConfig,
    target_platform: str = None,
):
    docker = get_client()
    images = []

    if "none" in image_dict:
        img = image_dict.get("none")

        if img is not None:
            new_tag = f"{target_tag}:{version}"
            docker.tag(img, new_tag)
            docker.push(new_tag)

            return
    if target_platform is not None:
        img = image_dict.get(target_platform)
        print(img)
        if img is None:
            raise Exception(
                f"Cannot find image for {target_tag}:{version} on target platform {target_platform}"
            )

        new_tag = f"{target_tag}:{version}"
        print(new_tag)
        docker.tag(img, new_tag)
        docker.push(new_tag)
    else:
        for platform in config.platforms:
            img = image_dict.get(platform)

            if img is not None:
                new_tag = build_platform_tag(target_tag, version, platform)
                docker.tag(img, new_tag)
                docker.push(new_tag)
                images.append(new_tag)

        docker.manifest.create(name=f"{target_tag}:{version}", manifests=images)
        print("PUSHING MANIFEST", images)
        docker.manifest.push(f"{target_tag}:{version}", purge=True)


def run_container(
    image: str,
    name: str = None,
    entrypoint: str = None,
    command: List[str] = None,
    network: str = None,
    environment: Dict[str, Any] = {},
    volumes: List[Tuple[str, str]] = [],
    detach: bool = False,
    cap_add: List[str] = None,
):
    """Run a container with the specified configuration.

    Args:
        image: Container image to run
        name: Optional container name
        entrypoint: Optional entrypoint override
        command: Optional command to run
        network: Network to connect to
        environment: Environment variables
        volumes: Volume mounts as list of (host_path, container_path) tuples
        detach: Run container in detached mode
        cap_add: Linux capabilities to add (e.g., ["NET_ADMIN", "SYS_TIME"])

    Returns:
        Container object (if detached) or container output string
    """
    client = get_client()
    envs = {}

    for k, v in environment.items():
        if isinstance(v, dict):
            envs[k] = json.dumps(v)
        elif isinstance(v, list):
            envs[k] = json.dumps(v)
        else:
            envs[k] = v

    run_args = {"image": image, "envs": envs, "volumes": volumes, "detach": detach}

    if name is not None:
        run_args["name"] = name

    if entrypoint is not None:
        run_args["entrypoint"] = entrypoint

    if command is not None:
        run_args["command"] = command

    if network is not None:
        run_args["networks"] = [network]

    if cap_add is not None:
        run_args["cap_add"] = cap_add

    return client.run(**run_args)


def exec_container(
    container,
    command: List[str],
    user: str = None,
    workdir: str = None,
    environment: Dict[str, Any] = None,
    detach: bool = False,
    tty: bool = False,
    privileged: bool = False,
):
    """Execute a command in a running container.

    Args:
        container: Container object or name/ID
        command: Command to execute as a list (e.g., ["ls", "-la"])
        user: Optional user to run the command as
        workdir: Optional working directory
        environment: Optional environment variables
        detach: Run command in detached mode
        tty: Allocate a pseudo-TTY
        privileged: Run command with elevated privileges

    Returns:
        Command output string (if not detached) or None (if detached)
    """
    client = get_client()

    # Convert container object to string identifier if needed
    if not isinstance(container, str):
        # Handle python-on-whales container objects
        if hasattr(container, "name"):
            container = container.name
        elif hasattr(container, "id"):
            container = container.id
        else:
            # Last resort: convert to string
            container = str(container)

    envs = {}
    if environment:
        for k, v in environment.items():
            if isinstance(v, dict):
                envs[k] = json.dumps(v)
            elif isinstance(v, list):
                envs[k] = json.dumps(v)
            else:
                envs[k] = v

    exec_args = {"command": command}

    if user is not None:
        exec_args["user"] = user

    if workdir is not None:
        exec_args["workdir"] = workdir

    if envs:
        exec_args["envs"] = envs

    if tty:
        exec_args["tty"] = tty

    if privileged:
        exec_args["privileged"] = privileged

    if detach:
        exec_args["detach"] = detach

    return client.execute(container, **exec_args)


def kill_container(container):
    """Kill a running container.

    Args:
        container: Container object or name/ID
    """
    client = get_client()

    # Convert container object to string identifier if needed
    if not isinstance(container, str):
        # Handle python-on-whales container objects
        if hasattr(container, "name"):
            container = container.name
        elif hasattr(container, "id"):
            container = container.id
        else:
            # Last resort: convert to string
            container = str(container)

    client.kill(container)
