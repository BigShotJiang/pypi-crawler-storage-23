from datetime import datetime
from typing import Optional

from sqlalchemy import (
    String,
    JSON,
    DateTime,
)
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from core_alo.models import BaseModel, TimeAuditModelMixin


class SandboxModel(BaseModel, TimeAuditModelMixin):
    __tablename__ = "sandbox"

    user_email: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True, index=True
    )
    context_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True, index=True
    )

    remote_id: Mapped[str] = mapped_column(String(255), nullable=True)
    url: Mapped[str] = mapped_column(String(255), nullable=True)
    last_timeout_check: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    files: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    injected_skills: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=[]
    )
