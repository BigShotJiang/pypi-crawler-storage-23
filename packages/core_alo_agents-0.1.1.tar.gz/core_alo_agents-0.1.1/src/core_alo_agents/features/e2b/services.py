import json
import logging
import httpx
from datetime import datetime, timedelta, timezone

from e2b.exceptions import SandboxException
from e2b_code_interpreter import AsyncSandbox
from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi import Request

from core_alo.services import BaseService
from core_alo.schemas import UserPublic

from ...config import settings
from ...features.e2b.schemas import (
    RunSandboxCommand,
    SandboxCreate,
    SandboxStatus,
    SandboxStatusData,
    SandboxUpdate,
)
from ...features.e2b.script_constants import (
    INSTALL_DEPENDENCIES_SCRIPT,
    RUN_COMMAND_SCRIPT,
    SETUP_PYTHON_ENV_SCRIPT,
)
from ...features.e2b.models import SandboxModel


class E2BSandboxService(BaseService):
    """Service for creating and managing E2B sandboxes with React/Vite setup."""

    model = SandboxModel

    def __init__(
        self,
        db: Session,
        request: Request | None = None,
        user: UserPublic | None = None,
    ):
        super().__init__(db=db, user=user, request=request)
        self.timeout = settings.E2B_TIMEOUT_SECONDS
        self.python_port = 8000

    async def create_sandbox(
        self,
        context_id: str | None = None,
    ) -> tuple[SandboxModel, AsyncSandbox]:
        """
        Create a new E2B sandbox with React/Vite setup.

        Args:
            context_id: Optional context ID for execution-scoped sandboxes (e.g., workflow executions).
                       If provided, creates an ephemeral sandbox tied to this context.
                       If None, creates a user-scoped persistent sandbox.

        Returns:
            Tuple of (SandboxModel, AsyncSandbox)
        """
        if context_id:
            query_filter = SandboxModel.context_id == context_id
            create_data = {
                "context_id": context_id,
                "user_email": self.user.email if self.user else None,
            }
        elif self.user:
            query_filter = SandboxModel.user_email == self.user.email
            create_data = {
                "user_email": self.user.email,
                "context_id": None,
            }
        else:
            assert False, (
                "Either context_id or user must be provided for sandbox creation"
            )

        sandbox_db = self.db.scalars(select(SandboxModel).where(query_filter)).first()
        sandbox = None

        try:
            if not sandbox_db:
                sandbox_db = self.create_object(SandboxCreate(), update=create_data)

            if sandbox_db.remote_id:
                sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)

            if not sandbox:
                metadata = {
                    "projectTechicalName": settings.PROJECT_TECHNICAL_NAME,
                }
                if context_id:
                    metadata["contextId"] = context_id
                if self.user:
                    metadata["userId"] = self.user.email

                sandbox = await self.create_e2b_sandbox(metadata=metadata)
                host = sandbox.get_host(self.python_port)
                sandbox_db = self.update_object(
                    SandboxUpdate(
                        remote_id=sandbox.sandbox_id,
                        url=f"https://{host}",
                        injected_skills=[],
                    ),
                    obj=sandbox_db,
                )
            logging.info(f"[e2b-service] Sandbox created: {sandbox.sandbox_id}")
            logging.info(f"[e2b-service] Sandbox ready at: {sandbox_db.url}")

            return sandbox_db, sandbox

        except Exception as error:
            logging.error(f"[e2b-service] Error: {error}")
            self._cleanup_existing_sandbox(sandbox_db)
            raise error

    async def create_e2b_sandbox(self, metadata: dict | None = None) -> AsyncSandbox:
        """Create E2B sandbox with optional metadata"""
        sandbox = await AsyncSandbox.create(
            timeout=self.timeout, metadata=metadata or {}
        )

        response = await self._setup_python_env(sandbox)
        logging.info(
            f"[e2b-service] Set sandbox timeout to {settings.E2B_TIMEOUT_MINUTES} minutes"
        )
        await sandbox.set_timeout(self.timeout)

        return sandbox

    async def _setup_python_env(self, sandbox: AsyncSandbox):
        """Set up Python environment."""
        logging.info("[e2b-service] Setting up Python environment...")
        return await sandbox.run_code(SETUP_PYTHON_ENV_SCRIPT)

    async def _install_dependencies(self, sandbox: AsyncSandbox):
        """Install npm dependencies."""
        logging.info("[e2b-service] Installing dependencies...")
        return await sandbox.run_code(INSTALL_DEPENDENCIES_SCRIPT)

    async def get_e2b_sandbox_safe(self, sandbox_remote_id: str) -> AsyncSandbox | None:
        retries = 3
        sandbox = None

        while retries > 0:
            try:
                sandbox = await AsyncSandbox.connect(
                    sandbox_id=sandbox_remote_id, timeout=self.timeout
                )
                break
            except httpx.ReadError as e:
                retries -= 1
                if retries > 0:
                    logging.warning(
                        f"[get-e2b-sandbox-safe] httpx.ReadError connecting to sandbox "
                        f"{sandbox_remote_id}. Retrying... ({retries} attempts left)"
                    )
                else:
                    logging.error(
                        f"[get-e2b-sandbox-safe] Failed to connect after 3 attempts "
                        f"due to httpx.ReadError: {e}"
                    )
            except (SandboxException, ValueError) as e:
                logging.error(f"[get-e2b-sandbox-safe] Error: {e}")
                break

        return sandbox

    async def delete_sandbox(self, sandbox_db: int | SandboxModel) -> bool:
        if isinstance(sandbox_db, int):
            sandbox_db = self.get_object(sandbox_db, model=SandboxModel)
        sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)

        try:
            if sandbox:
                await sandbox.kill()
            self.delete_object(obj=sandbox_db)
            return True
        except Exception as e:
            logging.error(f"Failed to close sandbox: {e}")

        return True

    async def delete_sandbox_by_context(self, context_id: str) -> dict:
        """
        Delete sandbox by context_id (for execution-scoped sandboxes).

        Args:
            context_id: The context ID to search for

        Returns:
            Dict with success status and message
        """
        sandbox_db = self.db.scalars(
            select(SandboxModel).where(
                SandboxModel.context_id == context_id,
            )
        ).first()

        if not sandbox_db:
            return {
                "success": False,
                "message": f"No sandbox found for context: {context_id}",
                "sandbox_id": None,
            }

        await self.delete_sandbox(sandbox_db)
        return {
            "success": True,
            "message": f"Sandbox {context_id} stopped successfully",
            "sandbox_id": sandbox_db.remote_id,
        }

    async def delete_remote_sandbox(self, sandbox_id: int) -> bool:
        sandbox_db: SandboxModel = self.get_object(sandbox_id)
        sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)

        if sandbox:
            await sandbox.kill()
        return True

    async def _cleanup_existing_sandbox(self, sandbox_db: SandboxModel) -> bool:
        """Clean up any existing sandbox."""
        logging.info("[e2b-service] Killing existing sandbox...")
        try:
            if sandbox_db.remote_id and (
                sandbox := await self.get_e2b_sandbox_safe(sandbox_db.remote_id)
            ):
                await sandbox.kill()
            return True
        except Exception as e:
            logging.error(f"Failed to close existing sandbox: {e}")
        return False

    async def get_sandbox_status(self, sandbox_id: int) -> SandboxStatus:
        """Get the status of a sandbox."""

        # Check if sandbox exists
        sandbox_db: SandboxModel = self.get_object(sandbox_id)
        sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)

        # if can connect to sandbox, it is healthy
        sandbox_healthy = sandbox is not None

        if sandbox_healthy:
            return SandboxStatus(
                active=sandbox_db.is_active,
                healthy=sandbox_healthy,
                sandboxData=SandboxStatusData(
                    sandbox_id=sandbox_db.remote_id,
                    url=sandbox_db.url,
                    files_tracked=sandbox_db.app.existing_files,
                ),
                message=(
                    "Sandbox is active and healthy"
                    if sandbox_healthy
                    else "Sandbox exists but is not responding"
                ),
            )
        return SandboxStatus(
            active=sandbox_db.is_active,
            healthy=sandbox_healthy,
            message="Sandbox is not responding",
        )

    async def run_sandbox_command(
        self, sandbox_id: int, command: str
    ) -> RunSandboxCommand:
        """Run a command in the sandbox."""
        sandbox_db = self.get_object(sandbox_id)
        sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)
        if not sandbox:
            return RunSandboxCommand(
                success=False,
                error="No active sandbox",
            )

        logging.info(f"[run-command] Executing: {command}")

        try:
            # Create the command script to run in the sandbox
            result = await sandbox.run_code(
                RUN_COMMAND_SCRIPT.format(command_parts=json.dumps(command.split()))
            )

            # Get the output
            output = self.get_output_from_sandbox_code(result, "\\n")

            return RunSandboxCommand(
                success=True,
                output=output,
                message="Command executed successfully",
            )

        except Exception as error:
            logging.error(f"[run-command] Error: {error}")
            return RunSandboxCommand(
                success=False,
                error=str(error),
            )

    async def is_sandbox_running(self, sandbox_id: int) -> bool:
        sandbox_db = self.get_object(sandbox_id, raise404=False)
        if not sandbox_db:
            return False
        sandbox = await self.get_e2b_sandbox_safe(sandbox_db.remote_id)

        if sandbox:
            await self.extend_sandbox_timeout(sandbox_db, sandbox)

        # If sandbox instance is returned, it means the sandbox is running
        return sandbox is not None

    async def extend_sandbox_timeout(
        self, sandbox_db: SandboxModel, sandbox: AsyncSandbox
    ) -> bool:
        # Check every 10 minutes from last timeout check
        ten_minutes_ago = datetime.now() - timedelta(minutes=10)
        should_check_timeout = (
            sandbox_db.last_timeout_check is None
            or sandbox_db.last_timeout_check <= ten_minutes_ago
        )
        if not should_check_timeout:
            return False

        sandbox_info = await sandbox.get_info()

        now_utc = datetime.now(timezone.utc)
        time_until_end = (sandbox_info.end_at - now_utc).total_seconds()
        ten_minutes_in_seconds = 10 * 60

        if time_until_end > ten_minutes_in_seconds:
            # Update last timeout check even if we don't extend
            self.update_object(
                SandboxUpdate(last_timeout_check=datetime.now()),
                obj=sandbox_db,
            )
            return False

        # Extend timeout to 20 minutes from now
        twenty_minutes_from_now = now_utc + timedelta(minutes=20)
        timeout_extension_seconds = int(
            (twenty_minutes_from_now - sandbox_info.end_at).total_seconds()
        )

        # Only extend if we're actually extending the timeout
        extended = False
        if timeout_extension_seconds > 0:
            await sandbox.set_timeout(timeout_extension_seconds)
            extended = True

        # Update last timeout check
        self.update_object(
            SandboxUpdate(last_timeout_check=datetime.now()),
            obj=sandbox_db,
        )

        return extended

    def get_output_from_sandbox_code(self, result, join_separator: str = "") -> str:
        output = ""
        if hasattr(result, "logs") and hasattr(result.logs, "stdout"):
            output = join_separator.join(result.logs.stdout)
        elif hasattr(result, "output"):
            output = result.output
        return output
