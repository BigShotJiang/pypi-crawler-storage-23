SETUP_PYTHON_ENV_SCRIPT = """
import subprocess
import sys

print('Setting up Python environment with UV...')

# Install uv globally
print('Installing uv...')
try:
    # Check if uv is already available
    result = subprocess.run(['uv', '--version'], capture_output=True, text=True)
    if result.returncode == 0:
        print('✓ uv is already installed')
    else:
        raise FileNotFoundError
except FileNotFoundError:
    # Install uv
    result = subprocess.run([sys.executable, '-m', 'pip', 'install', 'uv'], capture_output=True, text=True)
    if result.returncode == 0:
        print('✓ uv installed successfully')
    else:
        print(f'✗ Failed to install uv: {result.stderr}')
        exit(1)

# Install packages globally using uv pip
print('Installing packages globally...')
packages = [
    'pandas', 
    'numpy',
    'matplotlib', 
    'matplotlib-inline', 
    'seaborn', 
    'scipy', 
    'scikit-learn', 
    'openpyxl',
    'xlsxwriter',
    'pillow',
    'tabulate',
    'playwright',
    'moviepy',
]

result = subprocess.run(['uv', 'pip', 'install'] + packages + ['--system'], capture_output=True, text=True)
if result.returncode == 0:
    print('✓ All packages installed successfully')
    print('Installed packages:', ', '.join(packages))
else:
    print(f'✗ Failed to install packages: {result.stderr}')
    print(f'stdout: {result.stdout}')

# Install Playwright chromium browser with dependencies
print('\\nInstalling Playwright chromium browser...')
result = subprocess.run(['playwright', 'install', 'chromium', '--with-deps'], capture_output=True, text=True)
if result.returncode == 0:
    print('✓ Playwright chromium installed successfully')
else:
    print(f'✗ Failed to install Playwright chromium: {result.stderr}')
    print(f'stdout: {result.stdout}')

# Quick test to verify installation
print('\\nVerifying installation...')
try:
    import pandas as pd
    import numpy as np
    import matplotlib
    print(f'✓ pandas {pd.__version__}')
    print(f'✓ numpy {np.__version__}')
    print(f'✓ matplotlib {matplotlib.__version__}')
    print('\\n🎉 Python environment setup completed successfully!')
    result = "setup_complete"
except ImportError as e:
    print(f'✗ Import test failed: {e}')
    result = "setup_failed"
"""


INSTALL_DEPENDENCIES_SCRIPT = """
import subprocess
import sys
import os

os.chdir('/home/user/app')
print('Installing Python packages with uv...')

# First ensure uv is available
try:
    subprocess.run(['uv', '--version'], check=True, capture_output=True)
    print('✓ uv is available')
except (subprocess.CalledProcessError, FileNotFoundError):
    print('Installing uv...')
    subprocess.run(['pip', 'install', 'uv'], check=True)

# Create virtual environment if it doesn't exist
if not os.path.exists('.venv'):
    print('Creating virtual environment...')
    result = subprocess.run(
        ['uv', 'venv'],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print('✓ Virtual environment created')
    else:
        print(f'⚠ Warning: uv venv had issues: {{result.stderr}}')

# Install dependencies
print('Installing dependencies...')
result = subprocess.run(
    ['uv', 'sync'],
    capture_output=True,
    text=True
)

if result.returncode == 0:
    print('✓ Dependencies installed successfully')
    print(result.stdout)
else:
    print(f'⚠ Warning: uv sync had issues: {{result.stderr}}')
    # Try with pip as fallback
    print('Trying with pip as fallback...')
    pip_result = subprocess.run(
        ['pip', 'install', '-r', 'requirements.txt'],
        capture_output=True,
        text=True
    )
    if pip_result.returncode == 0:
        print('✓ Dependencies installed with pip')
    else:
        print(f'✗ Both uv and pip failed: {{pip_result.stderr}}')
"""

RUN_COMMAND_SCRIPT = """
import subprocess
import os
import json

os.chdir('/home/user/app')

# Split command into parts for subprocess
command_parts = {command_parts}

try:
    result = subprocess.run(
        command_parts,
        capture_output=True,
        text=True,
        shell=False,
        timeout=30  # 30 second timeout
    )

    output_data = {{
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode
    }}

    print("STDOUT:")
    print(result.stdout)
    if result.stderr:
        print("\\nSTDERR:")
        print(result.stderr)
    print(f"\\nReturn code: {{result.returncode}}")

except subprocess.TimeoutExpired:
    print("STDERR:")
    print("Command timed out after 30 seconds")
    print("\\nReturn code: 124")
except Exception as e:
    print("STDERR:")
    print(f"Error executing command: {{str(e)}}")
    print("\\nReturn code: 1")
"""


PY_IMPORT_REGEX = r"""(?:^|\n)\s*(?:from\s+([a-zA-Z_][\w.]*)|import\s+([a-zA-Z_][\w.]*(?:\s*,\s*[a-zA-Z_][\w.]*)*))(?:\s+as\s+\w+)?(?:\s*,|\s*$)"""
DETECT_PACKAGES_SCRIPT = '''
import re
import json

files = {files_json}

# Extract all import statements from the files
imports = set()
import_regex = r"""{py_import_regex}"""
require_regex = r"""require\s*\(["']([^"']+)["']\)"""

for file_path, content in files.items():
    if not isinstance(content, str):
        continue

    # Skip non-Python files
    if not file_path.endswith(".py"):
        continue

    # Find Python imports
    for match in re.finditer(import_regex, content, re.MULTILINE):
        if match.group(1):  # from import
            imports.add(match.group(1).split('.')[0])
        elif match.group(2):  # direct import
            import_list = match.group(2)
            for imp in import_list.split(','):
                imp = imp.strip().split('.')[0]
                if imp:
                    imports.add(imp)

print("Found imports:", list(imports))

# Filter out built-in modules and standard library
packages = []
builtins = [
    'os', 'sys', 'json', 'datetime', 'time', 'math', 'random', 'collections',
    'itertools', 'functools', 'operator', 'copy', 'pickle', 'csv', 'sqlite3',
    'http', 'urllib', 'socket', 'threading', 'multiprocessing', 'subprocess',
    'logging', 'warnings', 're', 'string', 'io', 'pathlib', 'glob', 'shutil',
    'tempfile', 'gzip', 'zipfile', 'tarfile', 'base64', 'hashlib', 'hmac',
    'secrets', 'uuid', 'enum', 'dataclasses', 'typing', 'types', 'inspect',
    'importlib', 'pkgutil', 'site', 'sysconfig', 'platform', 'gc', 'weakref',
    'ast', 'dis', 'code', 'codeop', 'compile', 'unicodedata', 'locale', 'gettext'
]

for imp in imports:
    # Skip built-in modules
    if imp in builtins:
        continue
    
    # Skip relative imports (shouldn't happen with this regex, but just in case)
    if imp.startswith('.'):
        continue
        
    packages.append(imp)

# Remove duplicates
unique_packages = list(set(packages))

print("Packages to install:", unique_packages)
print(json.dumps({{"packages": unique_packages}}))
'''


CHECK_PACKAGES_SCRIPT = """
import os
import json
import subprocess
import sys

installed = []
missing = []
packages = {packages_json}

# Check if we're in a virtual environment
venv_path = '/home/user/app/.venv'
if os.path.exists(venv_path):
    # Use uv to check installed packages
    try:
        result = subprocess.run(
            ['uv', 'pip', 'list', '--format=json'],
            cwd='/home/user/app',
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            installed_packages = json.loads(result.stdout)
            installed_names = {{pkg['name'].lower().replace('-', '_') for pkg in installed_packages}}
            
            for package in packages:
                package_normalized = package.lower().replace('-', '_')
                if package_normalized in installed_names:
                    installed.append(package)
                else:
                    missing.append(package)
        else:
            # Fallback: try importing each package
            for package in packages:
                try:
                    __import__(package)
                    installed.append(package)
                except ImportError:
                    missing.append(package)
    except Exception:
        # Fallback: try importing each package
        for package in packages:
            try:
                __import__(package)
                installed.append(package)
            except ImportError:
                missing.append(package)
else:
    # No virtual environment, check system packages
    for package in packages:
        try:
            __import__(package)
            installed.append(package)
        except ImportError:
            missing.append(package)

result = {{
    'installed': installed,
    'missing': missing
}}

print(json.dumps(result))
"""


INSTALL_PACKAGES_SCRIPT = """
import subprocess
import os
import json

os.chdir('/home/user/app')
packages_to_install = {missing_packages_json}

if not packages_to_install:
    print("No packages to install")
    result_data = {{
        'installed': [],
        'failed': [],
        'returncode': 0,
        'stdout': 'No packages needed',
        'stderr': ''
    }}
    print(json.dumps(result_data))
else:
    print(f"Installing Python packages: {{packages_to_install}}")
    
    # Ensure virtual environment exists
    if not os.path.exists('.venv'):
        print('Creating virtual environment...')
        subprocess.run(['uv', 'venv'], cwd='/home/user/app')
    
    # Install packages using uv
    result = subprocess.run(
        ['uv', 'add'] + packages_to_install,
        capture_output=True,
        text=True,
        cwd='/home/user/app',
        timeout=120
    )
    
    print("uv pip install stdout:", result.stdout)
    if result.stderr:
        print("uv pip install stderr:", result.stderr)
    print("Return code:", result.returncode)
    
    # Verify installation by trying to import
    installed = []
    failed = []
    
    for package in packages_to_install:
        try:
            # Try to import the package
            __import__(package)
            installed.append(package)
            print(f"✓ Verified installation of {{package}}")
        except ImportError:
            failed.append(package)
            print(f"✗ Failed to verify installation of {{package}}")
    
    result_data = {{
        'installed': installed,
        'failed': failed,
        'returncode': result.returncode,
        'stdout': result.stdout,
        'stderr': result.stderr
    }}
    
    print("\\nInstall Result:", json.dumps(result_data))
"""
