from enum import StrEnum
from dataclasses import dataclass
import datetime
import logging
from typing import AsyncGenerator, Sequence
import uuid
import json
from pathlib import Path
import base64
from io import BytesIO

import httpx
import pandas as pd

from fastapi import APIRouter, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from pydantic import BaseModel, ValidationError
from pydantic_ai.agent import Agent as PAIAgent, AgentRunResult, AgentRun
from pydantic_ai.messages import (
    ModelMessage as PAIModelMessage,
    ModelResponse as PAIModelResponse,
    ModelRequest as PAIModelRequest,
    TextPart as PAITextPart,
    UserPromptPart as PAIUserPromptPart,
    SystemPromptPart as PAISystemPromptPart,
    ThinkingPart as PAIThinkingPart,
    UserContent as PAIUserContent,
    ToolCallPart as PAIToolCallPart,
    ToolReturnPart as PAIToolReturnPart,
    PartDeltaEvent,
    TextPartDelta,
    ThinkingPartDelta,
    PartStartEvent,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
)
from pydantic_ai import (
    AbstractToolset,
    ImageUrl,
    DocumentUrl,
    AudioUrl,
    VideoUrl,
    BinaryContent,
    RunContext,
    ToolDefinition,
)
import logfire

from schemas import UserPublic

from ..connectors.constants import ConnectorProvider
from .utils import PartialMerger
from ..data_sources.semantic_layer_prompt import build_semantic_layer_prompt
from .types import AgentInternalMessage
from .constants import (
    WORKFLOW_ROUTER_PREFIX,
    ExtMimeType,
    JsonRpcErrorCode,
    PartialMessageType,
    ALLOWED_LLM_MODELS,
    DEFAULT_LLM_MODEL,
)

from .mixins import UserCBVMixin
from .a2a_types import (
    AgentCapabilities,
    AgentCard,
    Message,
    MessageSendParams,
    SendStreamingMessageResponse,
    Task,
    TextPart,
    FilePart,
    FileWithUri,
    FileWithBytes,
    JSONRPCError,
    JSONRPCRequest,
    JSONRPCResponse,
    PartialMessage,
    DataPart,
)
from .models import AgentConfig
from .schemas import (
    AgentConfigCreatePayload,
    AgentConfigUpdatePayload,
    OTLPAction,
    AgentConfigPublic,
    AgentConfigCreate,
    AgentConfigUpdate,
    AgentConfigBase,
    ModelConfigResponse,
    StopSandboxRequest,
    StopSandboxResponse,
)
from .constants import OTLPActions, OTLP_ACTION_LABELS
from .services import AgentConfigService
from ..connectors.google_calendar.toolset import google_calendar_toolset
from ..connectors.google_drive.toolset import google_drive_toolset
from ..e2b.services import E2BSandboxService
from ..authz.routers import authz_router
from core_alo.keycloak_auth import login_endpoint
from core_alo.mixins import ApiTokenCBVMixin, BaseCBVMixin
from core_alo.exceptions import DefaultHTTPException
from ...config import Settings
from ...cbv import cbv
from ...middlewares import _add_user_to_trace_middleware, _user_auth_middleware
from ...features.authz.services import SystemPermissionsService
from ..data_sources.schemas import DataSourceConnection
from .types import ToolReturn
from ..integrations import INTEGRATIONS, IntegrationType, IntegrationActionType

"""
# A2A definitions:
## agent card:
- urls: 
    /.well-known/agent.json

## tasks:
- rpc_methods:
    tasks/get
    tasks/cancel
    tasks/pushNotificationConfig/set -> webhook
    tasks/pushNotificationConfig/get
    tasks/resubscribe -> resub to stream/sse
- lifecycle statuses: submitted, working, input-required, completed, failed

## messages:
- rpc_methods:
    /message/send
    /message/stream

## Agents:
- rpc_methods:
    agents/authenticatedExtendedCard
"""


# Only implemented methods for now.
RPC_METHOD_TO_FUNC = {
    "message/send": "message_send",
    "message/stream": "message_stream",
}


@dataclass
class AgentDeps:
    db: Session | None = None
    user: UserPublic | None = None
    request: Request | None = None
    payload: MessageSendParams | None = None
    settings: Settings | None = None


def get_today_datetime() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


class Agent:
    def __init__(
        self,
        *,
        agent_card: AgentCard,
        capabilities: AgentCapabilities = AgentCapabilities(
            streaming=True, pushNotifications=True
        ),
        pydanticai_args: dict,
        deps_args: dict | None = None,
        settings: Settings,
        otlp_actions: StrEnum = OTLPActions,
        otlp_action_labels: dict = OTLP_ACTION_LABELS,
        skill_path: str | Path | None = None,
    ):
        pydanticai_args["tools"] = pydanticai_args.get("tools", []) + [
            get_today_datetime
        ]

        self.deps_args = deps_args or {}
        self.skill_path = skill_path

        self._agent = PAIAgent(
            **{
                "deps_type": AgentDeps,
                **pydanticai_args,
            }
        )
        self.deps_args = deps_args or {}
        self._default_agent_model = pydanticai_args.get("model", DEFAULT_LLM_MODEL)

        self.capabilities = capabilities
        self.agent_card = agent_card
        self.agent_card.documentationUrl = (
            self.agent_card.documentationUrl
            or f"{settings.AGENT_URL}/.well-known/documentation.md"
        )
        self.md_documentation_path = Path(__file__).parent / "agent_documentation.md"

        self.settings = settings

        # TODO: perhaps use from db ?
        self.otlp_actions = {
            otlp_action.value: otlp_action_labels.get(
                otlp_action.value, otlp_action.value
            )
            for otlp_action in otlp_actions or []
        }

        @self._agent.instructions
        def get_agent_config_instructions(ctx: RunContext[AgentDeps]) -> str:
            agent_type = None
            if ctx.deps.payload and ctx.deps.payload.message.metadata:
                agent_type = ctx.deps.payload.message.metadata.get("agent_type")
            if not agent_type:
                return ""

            agent_config = ctx.deps.db.scalars(
                select(AgentConfig).where(AgentConfig.type == agent_type)
            ).first()
            return getattr(agent_config, "instructions", "")

        # TODO: Improve the prompt here on source usages (e.g. fetch metadat before, etc.)
        @self._agent.instructions
        def data_source_specific_prompt(ctx: RunContext[AgentDeps]) -> str:
            data_connection = (
                ctx.deps.payload
                and ctx.deps.payload.message
                and (ctx.deps.payload.message.metadata or {}).get("data_connection")
            )
            if not data_connection:
                return ""
            data_connection = DataSourceConnection.model_validate(data_connection)

            return f"""
            # Data source context:
            - Data source name: {data_connection.name}
            - Data source type: {data_connection.connector_key}
            - Data source instructions: \n{data_connection.instructions_prompt}
            """

        @self._agent.instructions
        def semantic_layer_prompt(ctx: RunContext[AgentDeps]) -> str:
            data_connection = (
                ctx.deps.payload
                and ctx.deps.payload.message
                and (ctx.deps.payload.message.metadata or {}).get("data_connection")
            )
            if not data_connection:
                return ""

            semantic_layer = data_connection.get("semantic_layer")
            if not semantic_layer:
                return ""

            return build_semantic_layer_prompt(semantic_layer)

        # Lazy import to avoid circular dependency
        from ..data_sources.tools import (
            query_data_source as _query_data_source,
            get_data_source_metadata as _get_data_source_metadata,
        )

        @self._agent.tool(prepare=self._data_sources_enabled)
        async def get_data_source_metadata(ctx: RunContext[AgentDeps]) -> ToolReturn:
            return await _get_data_source_metadata(ctx)

        @self._agent.tool(prepare=self._data_sources_enabled)
        async def query_data_source(
            ctx: RunContext[AgentDeps], query: dict, save_results: bool = True
        ) -> ToolReturn:
            return await _query_data_source(ctx, query, save_results)

    async def _data_sources_enabled(
        self, ctx: RunContext[AgentDeps], tool_def: ToolDefinition
    ) -> ToolDefinition | None:
        if (
            ctx.deps.payload
            and ctx.deps.payload.message
            and (ctx.deps.payload.message.metadata or {}).get("data_connection")
        ):
            return tool_def

    def get_connector_toolsets(self, deps: AgentDeps) -> list[AbstractToolset]:
        """
        Dynamically build connector toolsets based on active_connectors in metadata.
        """
        if not deps.payload or not deps.payload.message.metadata:
            return []

        active_connectors = deps.payload.message.metadata.get("active_connectors", [])
        if not active_connectors:
            return []

        toolsets = []
        for connector in active_connectors:
            match connector:
                case ConnectorProvider.GOOGLE_CALENDAR:
                    toolsets.append(google_calendar_toolset)
                case ConnectorProvider.GOOGLE_DRIVE:
                    toolsets.append(google_drive_toolset)

        return toolsets

    def _validate_and_get_model(self, deps: AgentDeps) -> str:
        """
        Validate and get the model from payload metadata.
        Returns the validated model string or the default model if not provided/invalid.
        Only allows model switching if llm_switch_enabled is True for the agent config.
        """
        if not deps.payload or not deps.payload.message.metadata:
            return self._default_agent_model

        model = deps.payload.message.metadata.get("model")
        if not model:
            return self._default_agent_model

        if model in ALLOWED_LLM_MODELS:
            return model

        return self._default_agent_model

    def get_a2a_app(self, enable_telemetry: bool = False) -> FastAPI:
        if enable_telemetry:
            logfire.configure(
                # advanced=logfire.AdvancedOptions(
                # base_url=self.settings.BASE_OTEL_URL,
                # ),
                console=False,
                send_to_logfire=False,
                scrubbing=False,
                service_name=self.settings.PROJECT_TECHNICAL_NAME,
                service_version="0.1.0",  # TODO: move to settings
                environment=self.settings.ENVIRONMENT,
            )
            try:
                # not all agents have db
                logfire.instrument_psycopg()
            except ImportError:
                pass
            logfire.instrument_httpx()
            logfire.instrument_pydantic_ai()
            logfire.instrument_google_genai()
            logfire.instrument_anthropic()
            logfire.instrument_openai()

        app = FastAPI()

        # Add CORS middleware to handle preflight OPTIONS requests
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.settings.all_cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        app_cbv, router, auth_router = self.get_a2a_app_cbv()
        app.include_router(router)
        app.include_router(auth_router)
        app.include_router(authz_router)

        if enable_telemetry:
            # Preserve order of middleware execution
            @app.middleware("http")
            async def add_user_to_trace_middleware(request: Request, call_next):
                return await _add_user_to_trace_middleware(request, call_next)

            @app.middleware("http")
            async def user_auth_middleware(request: Request, call_next):
                return await _user_auth_middleware(request, call_next)

            logfire.instrument_fastapi(
                app,
                excluded_urls=["/otlp-actions/"],
            )

        return app

    def get_a2a_app_cbv(self):
        agent_instance = self

        router = APIRouter()

        auth_router = APIRouter(
            prefix="/auth",
            tags=["Auth"],
        )

        @auth_router.post("/token")
        async def login(request: Request):
            return await login_endpoint(request)

        # TODO: remove BaseCBVMixin; just for testing
        @cbv(router)
        class IntegrationsCBV(BaseCBVMixin):
            @router.post("/integrations/{integration_type}/events")
            async def handle_integration_event(self, integration_type: IntegrationType):
                return await agent_instance._handle_integration(
                    self, integration_type, IntegrationActionType.EVENT
                )

            @router.post("/integrations/{integration_type}/command")
            async def handle_integration_command(
                self, integration_type: IntegrationType
            ):
                return await agent_instance._handle_integration(
                    self, integration_type, IntegrationActionType.COMMAND
                )

        @cbv(router)
        class A2AAppCBV(UserCBVMixin):
            @router.get("/.well-known/agent.json", response_model=AgentCard)
            async def get_agent_card(self, agent_type: str | None = None):
                return agent_instance._get_agent_card(self, agent_type)

            @router.get("/.well-known/documentation.md")
            async def get_documentation(self):
                with open(agent_instance.md_documentation_path, "r") as f:
                    file_content = f.read()
                return PlainTextResponse(
                    content=file_content, media_type="text/markdown"
                )

            @router.post("/jsonrpc")
            async def handle_jsonrpc(self, request: JSONRPCRequest):
                return await agent_instance._handle_jsonrpc(self, request)

            @router.get("/otlp-actions/", response_model=list[OTLPAction])
            async def get_otlp_actions(self):
                return [
                    OTLPAction(
                        technical_name=action,
                        label=agent_instance.otlp_actions[action],
                    )
                    for action in agent_instance.otlp_actions
                ]

            @router.get("/model-config/", response_model=ModelConfigResponse)
            async def get_model_config(self):
                """Get default model and allowed models configuration."""
                from .constants import DEFAULT_LLM_MODEL, ALLOWED_LLM_MODELS

                return ModelConfigResponse(
                    default_model=DEFAULT_LLM_MODEL,
                    allowed_models=list(ALLOWED_LLM_MODELS),
                )

            # ==== Agent Config Management ===
            @router.get("/agent-configs/", response_model=list[AgentConfigPublic])
            async def list_agent_configs(self):
                return agent_instance._list_agent_configs(self)

            @router.post(
                "/agent-configs/",
                response_model=AgentConfigPublic,
                status_code=201,
            )
            async def create_agent_config(self, payload: AgentConfigCreatePayload):
                return agent_instance._create_agent_config(self, payload)

            @router.get(
                "/agent-configs/{agent_type}/", response_model=AgentConfigPublic
            )
            async def get_agent_config(self, agent_type: str):
                return agent_instance._get_agent_config(self, agent_type)

            @router.patch(
                "/agent-configs/{agent_type}/", response_model=AgentConfigPublic
            )
            async def update_agent_config(
                self,
                agent_type: str,
                payload: AgentConfigUpdatePayload,
                disable: bool | None = None,
            ):
                """
                Update agent config with skills support.

                Query parameters:
                - disable: if True, removes skills from enabled_skills; if False/None, adds them
                """
                return agent_instance._update_agent_config(
                    self, agent_type, payload, disable
                )

            @router.delete("/agent-configs/{agent_type}/", status_code=204)
            async def delete_agent_config(self, agent_type: str):
                service = AgentConfigService(
                    db=self.db, request=self.request, user=self.user
                )
                obj = service.get_object(filters=(AgentConfig.type == agent_type,))
                return service.delete_object(obj=obj)

        @cbv(router)
        class ApiTokenCBV(ApiTokenCBVMixin):
            @router.get(
                f"{WORKFLOW_ROUTER_PREFIX}/.well-known/agent.json",
                response_model=AgentCard,
            )
            async def get_agent_card(self, agent_type: str | None = None):
                return agent_instance._get_agent_card(self, agent_type)

            @router.post(f"{WORKFLOW_ROUTER_PREFIX}/jsonrpc")
            async def handle_jsonrpc(self, request: JSONRPCRequest):
                return await agent_instance._handle_jsonrpc(self, request)

            @router.post(
                f"{WORKFLOW_ROUTER_PREFIX}/sandbox/stop",
                response_model=StopSandboxResponse,
            )
            async def stop_workflow_sandbox(
                self, payload: StopSandboxRequest
            ) -> StopSandboxResponse:
                """
                Stop and cleanup a workflow execution sandbox.
                Called by aloflow when workflow execution completes.
                """
                sandbox_service = E2BSandboxService(
                    db=self.db, user=None, request=self.request
                )
                result = await sandbox_service.delete_sandbox_by_context(
                    payload.context_id
                )
                return StopSandboxResponse(**result)

        return A2AAppCBV, router, auth_router

    def _get_agent_card(self, cbv, agent_type: str | None = None) -> AgentCard:
        if not agent_type:
            return self.agent_card

        agent_config = cbv.db.scalars(
            select(AgentConfig).where(AgentConfig.type == agent_type)
        ).first()
        if not agent_config:
            return self.agent_card

        return self.agent_card.model_copy(update={"name": agent_config.name})

    async def _handle_jsonrpc(self, cbv, request: JSONRPCRequest) -> JSONRPCResponse:
        system_permissions_service = SystemPermissionsService(
            db=cbv.db, user=getattr(cbv, "user", None)
        )
        system_permissions_service.check_permission(
            action="send_jsonrpc", resource_type="system"
        )

        if request.method not in RPC_METHOD_TO_FUNC:
            return JSONRPCResponse(
                id=request.id,
                error=JSONRPCError(
                    code=JsonRpcErrorCode.METHOD_NOT_FOUND,
                    message="Method not found",
                    data=f"Unknown method: {request.method}",
                ),
            )
        if not request.params:
            return JSONRPCResponse(
                id=request.id,
                error=JSONRPCError(
                    code=JsonRpcErrorCode.INVALID_PARAMS,
                    message="Invalid params",
                    data="Missing params",
                ),
            )

        method_func = getattr(self, RPC_METHOD_TO_FUNC[request.method])
        msg_send_params = self.validate_model_with_rpc_error(
            MessageSendParams, request.params
        )
        if isinstance(msg_send_params, JSONRPCError):
            return JSONRPCResponse(
                id=request.id,
                error=msg_send_params,
            )

        return await method_func(
            msg_send_params,
            db=cbv.db,
            user=getattr(cbv, "user", None),
            request=cbv.request,
        )

    async def _handle_integration(
        self, cbv, integration_type: IntegrationType, type: IntegrationActionType
    ) -> dict:
        """Handle events from third-party integrations (Slack, Jira, etc.)."""
        integration_class = INTEGRATIONS[integration_type]

        if not integration_class.is_available():
            raise DefaultHTTPException(
                detail=f"Integration {integration_type} is not available",
            )

        try:
            integration = integration_class(
                agent=self,
                db=cbv.db,
                user=getattr(cbv, "user", None),
                request=cbv.request,
            )
        except RuntimeError as e:
            raise DefaultHTTPException(
                detail=f"Integration {integration_type} is not available",
            )

        is_authenticated = await integration.verify_auth()
        if not is_authenticated:
            return {"status": "error", "message": "Authentication failed"}

        return await getattr(integration, f"handle_{type}")()

    def _list_agent_configs(self, cbv) -> list[AgentConfigPublic]:
        service = AgentConfigService(db=cbv.db, request=cbv.request, user=cbv.user)
        configs = service.get_objects()
        return [AgentConfigPublic.model_validate(cfg) for cfg in configs]

    def _create_agent_config(
        self, cbv, payload: AgentConfigCreatePayload
    ) -> AgentConfigPublic:
        service = AgentConfigService(db=cbv.db, request=cbv.request, user=cbv.user)
        agent_create_payload = AgentConfigCreate(**payload.model_dump())
        config = service.create_object(payload=agent_create_payload)
        return AgentConfigPublic.model_validate(config)

    def _get_agent_config(self, cbv, agent_type: str) -> AgentConfigPublic:
        service = AgentConfigService(db=cbv.db, request=cbv.request, user=cbv.user)
        agent_config = service.get_object(filters=(AgentConfig.type == agent_type,))
        return AgentConfigPublic.model_validate(agent_config)

    def _update_agent_config(
        self,
        cbv,
        agent_type: str,
        payload: AgentConfigUpdatePayload,
        disable: bool | None = None,
    ) -> AgentConfigPublic:
        agent_update_payload = AgentConfigUpdate(
            **payload.model_dump(exclude_unset=True)
        )
        service = AgentConfigService(db=cbv.db, request=cbv.request, user=cbv.user)
        return service.update_object(
            payload=agent_update_payload, filters=(AgentConfig.type == agent_type,)
        )

    # A2A message/send
    async def message_send(
        self,
        data: MessageSendParams,
        db: Session | None,
        user: UserPublic | None,
        request: Request | None,
        deps: AgentDeps | None = None,
        deps_args: dict | None = None,
    ) -> Task | Message:
        context_id = data.message.contextId or str(uuid.uuid4())
        input_metadata = data.message.metadata or {}

        pai_msg = self.a2a_message_to_pydantic_ai_message(data.message)[0]
        user_prompt = [content for part in pai_msg.parts for content in part.content]
        pai_history = self.get_history(
            getattr(data.configuration, "historyLength", None),
            input_metadata.get("history", []),
        )

        deps_args = {
            **self.deps_args,
            **(deps_args or {}),
        }
        deps = deps or self._agent._deps_type(
            db=db,
            user=user,
            request=request,
            payload=data,
            settings=self.settings,
            **deps_args,
        )

        result = await self.run_pai_agent(
            user_prompt=user_prompt,
            message_history=pai_history,
            deps=deps,
        )

        response_metadata = {}
        response_text = result.output

        if input_metadata.get("show_internal_messages"):
            response_metadata["internal_messages"] = self.get_agent_messages_sync(
                result
            )

        response_msg = Message(
            role="agent",
            parts=[TextPart(text=response_text)],
            messageId=str(uuid.uuid4()),
            metadata=response_metadata,
        )

        # TODO: handle async blocking tasks
        # blocking = data.configuration.blocking if data.configuration else None
        # if blocking:
        #     task_id = data.message.taskId or str(uuid.uuid4())
        #     contextId = data.message.contextId or str(uuid.uuid4())
        #     response_task = Task(
        #         id=task_id,
        #         contextId=contextId,
        #         status=TaskStatus(state=TaskState.SUBMITTED),
        #         history=history,
        #     )
        #     return response_task

        return response_msg

    async def message_stream(
        self,
        data: MessageSendParams,
        db: Session | None,
        user: UserPublic | None,
        request: Request | None,
        deps: AgentDeps | None = None,
        deps_args: dict | None = None,
    ) -> StreamingResponse:
        """
        Public method that wraps _message_stream and returns StreamingResponse for HTTP.
        """

        async def generate_stream():
            async for partial_message in self._message_stream(
                data, db, user, request, deps, deps_args
            ):
                yield (
                    json.dumps(
                        partial_message.model_dump(mode="json", exclude_none=True)
                    ).encode()
                    + b"\n"
                )

        return StreamingResponse(generate_stream(), media_type="text/event-stream")

    async def _message_stream(
        self,
        data: MessageSendParams,
        db: Session | None,
        user: UserPublic | None,
        request: Request | None,
        deps: AgentDeps | None = None,
        deps_args: dict | None = None,
    ):
        """
        Internal method that returns async generator of PartialMessage objects.
        Used by both message_stream (for HTTP streaming) and direct calls.
        """
        if not self.capabilities.streaming:
            error_response = SendStreamingMessageResponse(
                error=JSONRPCError(
                    code=JsonRpcErrorCode.METHOD_NOT_ALLOWED,
                    message="Streaming is not supported",
                ),
            )
            yield PartialMessage(
                messageId="error",
                role="agent",
                parts=[],
                metadata={"error": error_response.model_dump()},
            )
            return

        context_id = data.message.contextId or str(uuid.uuid4())
        input_metadata = data.message.metadata or {}
        pai_msg = self.a2a_message_to_pydantic_ai_message(data.message)[0]
        user_prompt = [content for part in pai_msg.parts for content in part.content]
        pai_history = self.get_history(
            getattr(data.configuration, "historyLength", None),
            input_metadata.get("history", []),
        )

        deps_args = {
            **self.deps_args,
            **(deps_args or {}),
        }

        deps = deps or self._agent._deps_type(
            db=db,
            user=user,
            request=request,
            payload=data,
            settings=self.settings,
            **deps_args,
        )

        await self.before_message_stream(deps=deps)

        message_id = str(uuid.uuid4())

        async for partial_message in self.run_pai_agent_stream(
            message_id,
            context_id,
            input_metadata,
            user_prompt=user_prompt,
            message_history=pai_history,
            deps=deps,
        ):
            yield partial_message

    # event before message stream
    async def before_message_stream(self, *args, **kwargs):
        pass

    async def run_pai_agent(
        self,
        user_prompt: str | Sequence[PAIUserContent] | None = None,
        message_history: list[PAIModelMessage] | None = None,
        deps: AgentDeps | None = None,
    ) -> AgentRunResult:
        # Track message count to detect new messages in real-time
        previous_message_count = 1
        toolsets = self.get_connector_toolsets(deps) if deps else []

        # Get model from payload and create agent if needed
        model = self._validate_and_get_model(deps) if deps else DEFAULT_LLM_MODEL

        async with self._agent.iter(
            user_prompt=user_prompt,
            message_history=message_history,
            deps=deps,
            toolsets=toolsets,
            model=model,
        ) as agent_run:
            async for node in agent_run:
                previous_message_count, _ = self.log_new_pai_agent_messages_on_node(
                    agent_run, previous_message_count
                )
                s = "s"

        assert agent_run.result is not None, "The graph run did not finish properly"
        return agent_run.result

    # Based on:
    # https://github.com/pydantic/pydantic-ai/issues/1007
    # https://ai.pydantic.dev/agents/#async-for-iteration
    async def run_pai_agent_stream(
        self,
        message_id: str,
        context_id: str,
        input_metadata: dict,
        user_prompt: str | Sequence[PAIUserContent] | None = None,
        message_history: list[PAIModelMessage] | None = None,
        deps: AgentDeps | None = None,
    ) -> AsyncGenerator[PartialMessage, None]:
        # nodes: Sequence[PAIBaseNode | PAIEndNode] = []
        # Track message count to detect new messages in real-time
        previous_message_count = 1
        final_response_content = ""
        show_internal_messages = input_metadata.get("show_internal_messages", False)
        toolsets = self.get_connector_toolsets(deps) if deps else []

        model = (
            self._validate_and_get_model(deps) if deps else self._default_agent_model
        )

        yield PartialMessage(
            role="agent",
            messageId=message_id,
            contextId=context_id,
            metadata={"type": PartialMessageType.START},
        )

        async with self._agent.iter(
            user_prompt=user_prompt,
            message_history=message_history,
            deps=deps,
            toolsets=toolsets,
            model=model,
        ) as agent_run:
            # TODO: move to process_stream_node
            async for node in agent_run:
                # nodes.append(node)

                previous_message_count, new_messages = (
                    self.log_new_pai_agent_messages_on_node(
                        agent_run, previous_message_count
                    )
                )

                # Stream of internal messages
                if show_internal_messages and new_messages:
                    metadata = {
                        "type": PartialMessageType.INTERNAL,
                        "internal_messages": self.get_agent_messages_stream(
                            new_messages, final_response_content
                        ),
                    }
                    if metadata["internal_messages"]:
                        yield PartialMessage(
                            metadata=metadata,
                        )

                if PAIAgent.is_user_prompt_node(node):
                    # A user prompt node => The user has provided input
                    logging.info(f"UserPromptNode: {node.user_prompt}")

                elif PAIAgent.is_model_request_node(node):
                    # For debugging
                    # events = []

                    async with node.stream(agent_run.ctx) as request_stream:
                        try:
                            async for event in request_stream:
                                partial_message = (
                                    await self.process_model_request_stream_node_event(
                                        event,
                                        show_internal_messages,
                                        final_response_content,
                                    )
                                )
                                if partial_message:
                                    yield partial_message
                        except AssertionError as e:
                            logging.error(f"Internal error in pydantic-ai: {e}")
                            yield PartialMessage(
                                parts=[TextPart(text="")],
                                metadata={"type": PartialMessageType.TEXT_DELTA},
                                kind=None,
                            )
                elif PAIAgent.is_call_tools_node(node):
                    async with node.stream(agent_run.ctx) as handle_stream:
                        async for event in handle_stream:
                            if isinstance(event, FunctionToolCallEvent):
                                logging.info(
                                    f"[Tools] The LLM calls tool={event.part.tool_name!r} with args={event.part.args} (tool_call_id={event.part.tool_call_id!r})"
                                )

                            elif isinstance(event, FunctionToolResultEvent):
                                logging.info(
                                    f"[Tools] Tool call {event.tool_call_id!r}"
                                )

                                if isinstance(event.result.content, AsyncGenerator):
                                    partial_merger = PartialMerger()
                                    async for chunk in event.result.content:
                                        partial_merger.merge_update(chunk)

                                        if isinstance(chunk, BaseModel):
                                            chunk = chunk.model_dump(mode="json")

                                        yield PartialMessage(
                                            parts=[DataPart(data={"data": chunk})],
                                            metadata={
                                                "type": PartialMessageType.TOOL_DELTA
                                            },
                                            kind=None,
                                        )
                                    event.result.content = (
                                        partial_merger.get_accumulated()
                                    )

                elif PAIAgent.is_end_node(node):
                    # Once an End node is reached, the agent run is complete
                    # assert agent_run.result is not None
                    # assert agent_run.result.output == node.data.output
                    logging.info(f"Agent Output: {agent_run.result.output}")

        yield PartialMessage(
            role="agent",
            messageId=message_id,
            contextId=context_id,
            metadata={"type": PartialMessageType.END},
        )

    async def process_model_request_stream_node_event(
        self,
        event: PartDeltaEvent,
        show_internal_messages: bool,
        final_response_content: str,
    ) -> PartialMessage | None:
        # events.append(event)

        # PartStartEvent is the start of the Deltas
        if isinstance(event, PartStartEvent):
            if (
                show_internal_messages
                and isinstance(event.part, PAIThinkingPart)
                and event.part.content
            ):
                return PartialMessage(
                    parts=[TextPart(text=event.part.content)],
                    metadata={"type": PartialMessageType.THINKING_DELTA},
                    kind=None,
                )
            elif isinstance(event.part, PAITextPart) and event.part.content:
                return PartialMessage(
                    parts=[TextPart(text=event.part.content)],
                    metadata={"type": PartialMessageType.TEXT_DELTA},
                    kind=None,
                )

        elif isinstance(event, PartDeltaEvent):
            if isinstance(event.delta, TextPartDelta):
                delta = event.delta.content_delta
                if delta:
                    final_response_content += delta
                    return PartialMessage(
                        parts=[TextPart(text=delta)],
                        metadata={"type": PartialMessageType.TEXT_DELTA},
                        kind=None,
                    )
            elif show_internal_messages and isinstance(event.delta, ThinkingPartDelta):
                delta = event.delta.content_delta
                if delta:
                    return PartialMessage(
                        parts=[TextPart(text=delta)],
                        metadata={"type": PartialMessageType.THINKING_DELTA},
                        kind=None,
                    )

    def log_new_pai_agent_messages_on_node(
        self, agent_run: AgentRun, previous_message_count: int
    ) -> tuple[int, list[PAIModelMessage]]:
        current_messages = agent_run.ctx.state.message_history
        current_count = len(current_messages) or 1
        if current_count <= previous_message_count:
            return current_count, []
        new_messages = current_messages[previous_message_count:]
        self.log_pai_agent_messages(new_messages, previous_message_count)
        return current_count, new_messages

    def log_pai_agent_messages(
        self, messages: list[PAIModelMessage], previous_message_count: int
    ):
        # Log internal agent messages in real-time
        for i, msg in enumerate(messages):
            logging.info(f"New message #{previous_message_count + i + 1}: {type(msg).__name__} ({len(msg.parts)} parts)")
            for j, part in enumerate(msg.parts):
                logging.info(f"Part {j + 1}: {part}")

    def get_agent_messages_sync(
        self, result: AgentRunResult
    ) -> list[AgentInternalMessage]:
        agent_history = result._state.message_history

        res = []
        for msg in agent_history:
            internal_msg = AgentInternalMessage(kind=msg.kind, parts=[])
            for part in msg.parts:
                if isinstance(part, (PAISystemPromptPart, PAIUserPromptPart)):
                    continue

                internal_msg.parts.append(part)

            res.append(internal_msg)

        # Remove last message as its the final response of the agent
        res = res[:-1]
        # Remove messages with no parts
        res = [msg for msg in res if msg.parts]
        return res

    def get_agent_messages_stream(
        self, new_messages: list[PAIModelMessage], final_response_content: str
    ) -> list[AgentInternalMessage]:
        res = []
        for msg in new_messages:
            internal_msg = AgentInternalMessage(kind=msg.kind, parts=[])
            for part in msg.parts:
                if isinstance(
                    part,
                    (
                        PAISystemPromptPart,
                        PAIUserPromptPart,
                        PAIThinkingPart,
                        PAITextPart,
                    ),
                ) or (
                    isinstance(part, (PAIToolReturnPart, PAIToolCallPart))
                    and hasattr(part, "_from_history")
                ):
                    continue
                internal_msg.parts.append(part)

            res.append(internal_msg)

        # Remove messages with no parts
        res = [msg for msg in res if msg.parts]
        return res

    def validate_model_with_rpc_error(
        self, model: BaseModel, data: MessageSendParams
    ) -> MessageSendParams | JSONRPCError:
        try:
            return model.model_validate(data)
        except ValidationError as e:
            return JSONRPCError(
                code=JsonRpcErrorCode.INVALID_PARAMS,
                message="Invalid params",
                data=e.errors(),
            )

    def get_history(
        self, history_length: int | None, history: list[dict] | list[Message]
    ) -> list[PAIModelMessage]:
        if history and isinstance(history[0], dict):
            history = [Message.model_validate(msg) for msg in history]

        pai_history = []
        for msg in history:
            pai_history.extend(self.a2a_message_to_pydantic_ai_message(msg))
        pai_history = pai_history[:history_length] if history_length else pai_history
        return pai_history

    def a2a_message_to_pydantic_ai_message(self, msg: Message) -> list[PAIModelMessage]:
        model_messages = []

        match msg.role:
            case "agent":
                # Process tools from metadata if present
                if msg.metadata and msg.metadata.get("tools"):
                    tools_data = msg.metadata.get("tools", []) or []
                    for tool in tools_data:
                        tool_call_part = PAIToolCallPart(
                            tool_name=tool.get("name", ""),
                            args=tool.get("args", {}),
                            tool_call_id=tool.get("id", ""),
                        )
                        tool_call_part._from_history = True
                        model_messages.append(PAIModelResponse(parts=[tool_call_part]))

                        content = tool.get("content", "")
                        if isinstance(content, dict) and content.get("internal"):
                            # removing internal part from sending to llm context
                            del content["internal"]

                        tool_return_part = PAIToolReturnPart(
                            tool_name=tool.get("name", ""),
                            content=content,
                            tool_call_id=tool.get("id", ""),
                        )
                        tool_return_part._from_history = True
                        model_messages.append(PAIModelRequest(parts=[tool_return_part]))

                pai_parts = []
                for part in msg.parts:
                    match part.kind:
                        # TODO: not user for now
                        # case "data":
                        #     ...
                        # case "file":
                        #     ...
                        case _:  # Default text part
                            pai_parts.append(PAITextPart(content=part.text or ""))
                model_messages.append(PAIModelResponse(parts=pai_parts))
            case "user":
                pai_parts = []
                content_parts = []
                for part in msg.parts:
                    match part.kind:
                        case "file":
                            file_parts = self.a2a_file_part_to_pydantic_ai(part)
                            content_parts.extend(file_parts or [])
                        case "text":
                            content_parts.append(part.text or "")
                        case _:
                            logging.warning(f"Unsupported part kind: {part.kind}")
                pai_parts.append(PAIUserPromptPart(content=content_parts))
                model_messages.append(PAIModelRequest(parts=pai_parts))

        return model_messages

    # TODO: decide if do from here OR on upload from core_central_hub and pass directly .csv urls;
    #   this can fuck up memory? but also check out direct passing of gs:// to the Gemini to never load in memory
    def convert_excel_to_csv_parts(
        self, file_uri: str, filename: str
    ) -> list[BinaryContent | str]:
        """Convert Excel file to CSV BinaryContent parts (one per sheet).

        Args:
            file_uri: Presigned URL or HTTP(S) URL of the Excel file
            filename: Original filename for logging

        Returns:
            List of BinaryContent parts (one for each sheet), or a list with an error message string
        """
        csv_parts = []
        try:
            response = httpx.get(file_uri, timeout=30.0, follow_redirects=True)
            response.raise_for_status()
            file_bytes = response.content

            # Load Excel file
            excel_file = BytesIO(file_bytes)
            excel_data = pd.ExcelFile(excel_file)

            csv_parts = []
            for sheet_name in excel_data.sheet_names:
                df = pd.read_excel(excel_data, sheet_name=sheet_name)

                csv_buffer = BytesIO()
                df.to_csv(csv_buffer, index=False)
                csv_bytes = csv_buffer.getvalue()

                # Add sheet name as header
                csv_with_header = f"Sheet: {sheet_name}\n".encode() + csv_bytes
                csv_parts.append(
                    BinaryContent(
                        data=csv_with_header,
                        media_type="text/csv",
                    )
                )

            logging.info(
                f"Converted Excel file {filename} to {len(csv_parts)} CSV parts"
            )

        except Exception as e:
            logging.error(f"Error loading Excel document '{filename}': {str(e)}.")
            csv_parts.append(
                f"Error loading Excel document '{filename}'. This is likely related to the Excel format or file accessibility. Tell to user that there is an erorr."
            )

        return csv_parts

    def a2a_file_part_to_pydantic_ai(self, part: FilePart) -> list:
        """Convert an a2a FilePart to appropriate PydanticAI file type(s).

        Returns:
            List of file parts. For most files, returns a list with a single item.
            For Excel files, returns multiple BinaryContent parts (one per sheet).
        """

        file_data = part.file
        mime_type = file_data.mimeType or ""

        # this allows the file to be skipped from agent's config but still be uploaded to the sandbox
        #   for agent processing with code exec
        is_known_mime_type = mime_type and mime_type != "application/octet-stream"
        if not is_known_mime_type:
            return []

        if isinstance(file_data, FileWithUri) and file_data.uri:
            if mime_type.startswith("image/"):
                return [ImageUrl(url=file_data.uri)]
            elif mime_type.startswith("audio/"):
                return [AudioUrl(url=file_data.uri)]
            elif mime_type.startswith("video/"):
                return [VideoUrl(url=file_data.uri)]
            else:
                if mime_type == ExtMimeType.xlsx:
                    filename = file_data.name or file_data.uri
                    return self.convert_excel_to_csv_parts(file_data.uri, filename)
                # Default to document for unknown types
                return [DocumentUrl(url=file_data.uri)]
        elif isinstance(file_data, FileWithBytes) and file_data.bytes:
            binary_data = base64.b64decode(file_data.bytes)
            return [
                BinaryContent(
                    data=binary_data, media_type=mime_type
                )
            ]

        return []

    def pydantic_ai_message_to_a2a_message(
        self, pai_msg: PAIModelMessage, message_id: str = None, context_id: str = None
    ) -> Message:
        a2a_parts = []
        for part in pai_msg.parts:
            match part.part_kind:
                case "system-prompt":
                    pass
                case "text":
                    a2a_parts.append(TextPart(text=part.content))
                case _:
                    logging.warning(f"Unsupported part kind: {part.part_kind}")

        match pai_msg:
            case PAIModelResponse():
                role = "agent"
            case _:
                role = "user"

        return Message(
            role=role,
            parts=a2a_parts,
            messageId=message_id or str(uuid.uuid4()),
            contextId=context_id,
        )
