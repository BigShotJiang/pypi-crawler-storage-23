import json
import logging
from typing import Any
from pydantic import BaseModel
from . import skill_registry as registry_module


from core_alo.exceptions import HTTPNotFoundException, DefaultHTTPException
from pydantic_ai import Agent as PAIAgent


def get_agent_host_port(url: str) -> tuple[str, int]:
    host, port = url.rsplit(":", 1)
    if "http" in host:
        host = host.replace("http://", "")
        host = host.replace("https://", "")
    return host, int(port)


async def genai_response_to_dict(response: str) -> dict:
    """
    Convert a GenAI response to a dictionary.
    """

    if response.strip().startswith("```json"):
        json_str = response.strip()[7:-3].strip()
    elif response.strip().startswith("{"):
        json_str = response.strip()
    else:
        json_str = response

    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        parse_agent = PAIAgent(
            model="gemini-2.5-flash",
            instructions="You are a helpful assistant that parses JSON. Make sure to return the JSON string that will be possible to parse by json.loads() in python. Do not include any other text or comments.",
        )
        parsed_result = await parse_agent.run(
            f"Parse the following JSON string: {json_str}.\nCurrent Error: {e}"
        )
        try:
            return json.loads(parsed_result.output)
        except json.JSONDecodeError as e:
            logging.error(f"Error parsing JSON: {e}")
            return {}


def provide_enabled_skills(
    agent_config, skills_set: list[str], disable_parameter: bool
) -> list:
    # Current skills for the configuration
    current_skills = agent_config.enabled_skills or []

    if not current_skills and disable_parameter:
        logging.error("The configuration has no enabled skills")
        raise DefaultHTTPException(
            detail="Impossible to disable skills beacuse the configuration has no enabled skills"
        )

    # Retrieve all the available skills set
    available_skills_set = [
        skill.name for skill in registry_module.skill_registry.get_all_skills().values()
    ]

    # Collect all skill functions for all requested skill sets
    all_skills_to_process = []
    
    for skill_set_name in skills_set:
        if skill_set_name not in available_skills_set:
            logging.error(
                f"The skills set provided by the user, {skill_set_name} is not present in the skills list"
            )
            raise HTTPNotFoundException(item=f"Skills set: {skill_set_name}")

        # Get all the skill functions associated with the skills set
        skills = get_functions_by_skill_set(
            registry_module.skill_registry.get_all_skills().values(), skill_set_name
        )
        all_skills_to_process.extend(skills)

    # If disable parameter is provided, modify enabled_skills
    if disable_parameter:
        skills_are_present = all(skill in current_skills for skill in all_skills_to_process)

        if not skills_are_present:
            logging.error(f"The skills provided by the user, {all_skills_to_process} are not enabled")
            raise DefaultHTTPException(
                detail="The skills provided are not enabled in the configuration."
            )

        enabled_skills = [skill for skill in current_skills if skill not in all_skills_to_process]

    else:
        current_skills.extend(all_skills_to_process)
        enabled_skills = list(set(current_skills))

    return enabled_skills


def get_functions_by_skill_set(skills_data, target_name):
    for skill in skills_data:
        if skill.name == target_name:
            # Return list of function names for backward compatibility
            return list(skill.functions.keys())
    return []


def get_skill_sets_from_enabled_skills(enabled_skills: list[str]) -> list[str]:
    """
    Infer skill-set names (e.g. 'pdf', 'ppt') from a list of enabled skills.

    The `enabled_skills` list can contain either:
    - skill names (matching SkillDefinition.name), or
    - function names (present in SkillDefinition.functions).
    """
    if not enabled_skills:
        return []

    skills_map = registry_module.skill_registry.get_all_skills()
    result: set[str] = set()

    for item in enabled_skills:
        # If it's directly a skill name, keep it
        if item in skills_map:
            result.add(item)
            continue

        # Otherwise, try to resolve it as a function name
        for skill_name, skill_def in skills_map.items():
            if item in skill_def.functions:
                result.add(skill_name)
                break

    return list(result)


class PartialMerger:
    """Handles merging of partial updates for dicts and Pydantic models"""

    def __init__(self):
        self.accumulated = None
        self.target_type = None

    def merge_update(self, update: Any) -> Any:
        """Merge a partial update into the accumulated result"""

        if isinstance(update, str):
            if self.accumulated is None:
                self.accumulated = ""
                self.target_type = str
            self.accumulated += update
            return self.accumulated

        if isinstance(update, BaseModel):
            if self.target_type is None:
                self.target_type = type(update)
            update = update.model_dump(mode="json")

        if isinstance(update, dict):
            if self.accumulated is None:
                self.accumulated = {}
                if self.target_type is None:
                    self.target_type = dict

            self.accumulated = self._deep_merge(self.accumulated, update)

            if isinstance(self.target_type, type(BaseModel)):
                return self.target_type.model_validate(self.accumulated)
            return self.accumulated.copy()

        # raise or is ok?
        self.accumulated = update
        return update

    def _deep_merge(self, base: dict, update: dict) -> dict:
        # TODO: need deecopy?
        result = base.copy()

        for key, value in update.items():
            if key not in result:
                result[key] = value
                continue

            existing = result[key]

            if isinstance(existing, str) and isinstance(value, str):
                result[key] = existing + value
            elif isinstance(existing, list) and isinstance(value, list):
                result[key] = existing + value
            elif isinstance(existing, dict) and isinstance(value, dict):
                result[key] = self._deep_merge(existing, value)
            # TODO: perhaps add some handling of numbers?? not sure can merge though
            # For other types, replace with new value if it's not empty/None
            elif value is not None:
                result[key] = value

        return result

    def get_accumulated(self) -> Any:
        if isinstance(self.target_type, type(BaseModel)):
            return self.target_type.model_validate(self.accumulated)
        return self.accumulated
