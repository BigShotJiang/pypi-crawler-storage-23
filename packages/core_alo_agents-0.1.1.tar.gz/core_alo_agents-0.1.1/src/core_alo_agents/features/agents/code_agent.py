import logging
import base64
import httpx
import uuid
import mimetypes
from urllib.parse import urlparse
from pathlib import Path
from pydantic_ai import RunContext
from sqlalchemy import select
from fastapi import APIRouter, File, UploadFile
from datetime import datetime, timezone
from dataclasses import dataclass
from e2b_code_interpreter import AsyncSandbox


from ...cbv import cbv
from core_alo.services import GCStorage
from core_alo.exceptions import DefaultHTTPException
from ...features.agents.tools.code_generation.code_executor import CodeExecutor
from ...features.agents.types import ToolReturn
from ...features.agents.agents import Agent
from ...features.agents.mixins import UserCBVMixin
from ...features.agents.schemas import (
    AgentConfigCreatePayload,
    AgentConfigUpdatePayload,
    FilePresignedUrlResponse,
    AvailableSkillsResponse,
    SkillInfo,
    AgentConfigPublic,
)
from ...features.agents.tools.code_generation.schemas import FileUploadInfo
from ...features.agents.a2a_types import (
    FilePart,
    FileWithUri,
    FileWithBytes,
    Message,
    AgentCapabilities,
)
from ...features.agents.agents import AgentDeps
from ...features.agents.models import AgentConfig
from ...features.agents.tools.code_generation.constants import USER_FILES_FOLDER
from ...features.e2b.services import E2BSandboxService
from ...features.e2b.models import SandboxModel
from ...features.e2b.constants import SANDBOX_ROOT_PATH
from ...features.agents import skill_registry as registry_module
from ...features.agents.utils import (
    get_functions_by_skill_set,
    get_skill_sets_from_enabled_skills,
    provide_enabled_skills,
)
from ...features.agents.services import AgentConfigService
from ...features.agents.constants import (
    CODE_AGENT_UPLOADED_FILES_CONTEXT,
    CODE_AGENT_SKILLS_CONTEXT,
)


@dataclass
class CodeAgentDeps(AgentDeps):
    sandbox: AsyncSandbox | None = None
    gcs_service: GCStorage | None = None


class CodeAgent(Agent):
    def __init__(
        self,
        *,
        agent_card,
        capabilities=None,
        pydanticai_args,
        deps_args=None,
        settings,
        otlp_actions=None,
        otlp_action_labels=None,
        skill_path: str | Path | None = None,
    ):
        # Initialize skill registry with additional path BEFORE calling super()
        if skill_path:
            # TODO: for now is ok, but review if we want to keep it as global instance?
            registry_module.skill_registry = registry_module.SkillRegistry(
                additional_skill_path=skill_path
            )
        if capabilities is None:
            capabilities = AgentCapabilities(streaming=True, pushNotifications=True)

        super().__init__(
            agent_card=agent_card,
            capabilities=capabilities,
            pydanticai_args=pydanticai_args,
            deps_args=deps_args,
            settings=settings,
            otlp_actions=otlp_actions,
            otlp_action_labels=otlp_action_labels,
            skill_path=skill_path,
        )

        # Override the get_enabled_skills_context decorator
        @self._agent.instructions
        def get_enabled_skills_context(ctx: RunContext[AgentDeps]) -> str:
            """Inject enabled skills context into agent instructions"""

            agent_type = None
            if ctx.deps.payload and ctx.deps.payload.message.metadata:
                agent_type = ctx.deps.payload.message.metadata.get("agent_type")
                logging.info(
                    f"[SKILLS-CONTEXT-DECORATOR] agent_type from metadata: {agent_type}"
                )

            if not agent_type:
                logging.info(
                    "[SKILLS-CONTEXT-DECORATOR] No agent_type found, returning empty context"
                )
                return ""

            agent_config = ctx.deps.db.scalars(
                select(AgentConfig).where(AgentConfig.type == agent_type)
            ).first()

            if not agent_config:
                return ""

            # Get the skill context - use registry_module to get the updated registry
            context = registry_module.skill_registry.get_skill_prompt_context(
                agent_config.enabled_skills
            )

            # Add imperative prefix to encourage skill usage
            full_context = CODE_AGENT_SKILLS_CONTEXT.format(context=context)

            # full_context = imperative_prefix + context

            # DEBUG: Log what the agent sees
            logging.info(
                f"[SKILLS-CONTEXT] Injecting skills context for agent_type={agent_type}"
            )
            logging.info(f"[SKILLS-CONTEXT] Context length: {len(full_context)} chars")
            # logging.info(f"[SKILLS-CONTEXT] Full context:\n{full_context}")

            return full_context

        @self._agent.instructions
        def get_uploaded_files_context(ctx: RunContext[AgentDeps]) -> str:
            """Inject uploaded files path mapping into agent instructions"""

            if not ctx.deps.user and not (
                ctx.deps.payload and ctx.deps.payload.message.contextId
            ):
                return ""

            filter = (
                SandboxModel.user_email == ctx.deps.user.email
                if ctx.deps.user
                else SandboxModel.context_id == ctx.deps.payload.message.contextId
            )
            sandbox_db = ctx.deps.db.scalars(select(SandboxModel).where(filter)).first()
            if not sandbox_db or not sandbox_db.files:
                return ""

            file_list = []
            for filename, file_info in sandbox_db.files.items():
                sandbox_path = file_info.get("sandbox_path", "")
                if sandbox_path:
                    file_list.append(f"- '{filename}' → {sandbox_path}")

            if not file_list:
                return ""

            files_context = "\n".join(file_list)

            return CODE_AGENT_UPLOADED_FILES_CONTEXT.format(files_context=files_context)

    def get_a2a_app(self, enable_telemetry: bool = False):
        """Override to add custom sandbox file upload endpoint and skills endpoint"""
        agent_instance = self
        app = super().get_a2a_app(enable_telemetry=enable_telemetry)

        # Add skills router with skills endpoint and agent config endpoints with skills support
        skills_router = APIRouter(tags=["Skills"])

        @cbv(skills_router)
        class SkillsCBV(UserCBVMixin):
            @skills_router.get("/skills/", response_model=AvailableSkillsResponse)
            async def list_available_skills(self):
                """Get list of all available skills that can be enabled for agents."""
                skills_list = [
                    SkillInfo(
                        name=skill.name,
                        description=skill.description,
                        functions=skill.functions,
                    )
                    for skill in registry_module.skill_registry.get_all_skills().values()
                ]
                return AvailableSkillsResponse(skills=skills_list)

        app.include_router(skills_router)

        # Add sandbox router
        sandbox_router = APIRouter(prefix="/sandbox", tags=["Sandbox"])

        @cbv(sandbox_router)
        class SandboxCBV(UserCBVMixin):
            @sandbox_router.post("/files/")
            async def upload_files(self, files: list[UploadFile] = File(...)):
                """Upload files directly to user's sandbox (outside of chat context)"""
                if not self.user:
                    return {"error": "User not authenticated"}

                sandbox_service = E2BSandboxService(
                    db=self.db, user=self.user, request=self.request
                )
                sandbox_db, sandbox = await sandbox_service.create_sandbox()

                uploaded_files = []
                for file in files:
                    file_content = await file.read()
                    write_info = await sandbox.files.write(
                        f"{SANDBOX_ROOT_PATH}/{USER_FILES_FOLDER}/{file.filename}",
                        file_content,
                    )

                    uploaded_files.append(
                        {
                            "filename": file.filename,
                            "sandbox_path": write_info.path,
                            "mime_type": file.content_type
                            or "application/octet-stream",
                            "file_size": len(file_content),
                        }
                    )

                if uploaded_files:
                    sandbox_db_record = self.db.scalars(
                        select(SandboxModel).where(
                            SandboxModel.user_email == self.user.email
                        )
                    ).first()
                    if sandbox_db_record:
                        existing_files = sandbox_db_record.files or {}
                        for file_info in uploaded_files:
                            if "error" not in file_info:
                                existing_files[file_info["filename"]] = {
                                    "sandbox_path": file_info["sandbox_path"],
                                    "gcs_path": None,
                                    "bucket_name": None,
                                    "mime_type": file_info["mime_type"],
                                    "file_size": file_info["file_size"],
                                    "uploaded_at": datetime.now(
                                        timezone.utc
                                    ).isoformat(),
                                    "type": "direct_upload",
                                }

                        sandbox_db_record.files = existing_files
                        self.db.commit()

                return {
                    "uploaded_files": uploaded_files,
                    "sandbox_id": sandbox_db.id if sandbox_db else None,
                }

            @sandbox_router.post(
                "/files/presigned-url/", response_model=FilePresignedUrlResponse
            )
            async def get_gcs_presigned_url(
                self, gcs_path: str
            ) -> FilePresignedUrlResponse:
                """Get a presigned URL for a GCS file by path and bucket name."""
                # Check that file is from sandbox and belongs to user
                if not gcs_path.startswith((f"sandbox/{self.user.id}", f"generated_images/{self.user.id}")):
                    raise DefaultHTTPException(
                        status_code=400, detail="Invalid file path"
                    )

                expires_in_minutes = 60
                gcs_service = GCStorage(
                    bucket_name=agent_instance.settings.GC_BUCKET_NAME,
                    settings=agent_instance.settings,
                )
                presigned_url = gcs_service.get_presigned_url(
                    gcs_path, expires_in_minutes=expires_in_minutes
                )
                return FilePresignedUrlResponse(
                    url=presigned_url,
                    expires_in_minutes=expires_in_minutes,
                )

        # Include the sandbox router in the app
        app.include_router(sandbox_router)

        return app

    def _list_agent_configs(self, cbv) -> list[AgentConfigPublic]:
        configs = super()._list_agent_configs(cbv)

        for cfg in configs:
            cfg.skills_set = get_skill_sets_from_enabled_skills(
                getattr(cfg, "enabled_skills", []) or []
            )
        return configs

    def _create_agent_config(
        self, cbv, payload: AgentConfigCreatePayload
    ) -> AgentConfigPublic:
        payload.enabled_skills = self.get_enabled_skills(payload.skills_set or [])

        config = super()._create_agent_config(cbv, payload)
        return AgentConfigPublic.model_validate(config)

    def get_enabled_skills(self, skills_set: list[str]) -> list[str]:
        enabled_skills = []
        try:
            # Collect all skill functions for all requested skill sets
            for skill_set_name in skills_set:
                skills = get_functions_by_skill_set(
                    registry_module.skill_registry.get_all_skills().values(),
                    skill_set_name,
                )
                enabled_skills.extend(skills)
            # Remove duplicates
            enabled_skills = list(set(enabled_skills))
        except (AttributeError, KeyError) as e:
            # Registry might not be available for base Agent class
            logging.warning(f"Could not retrieve skills from registry: {e}")
            enabled_skills = []
        return enabled_skills

    def _get_agent_config(self, cbv, agent_type: str) -> AgentConfigPublic:
        config = super()._get_agent_config(cbv, agent_type)
        config.skills_set = get_skill_sets_from_enabled_skills(
            getattr(config, "enabled_skills", []) or []
        )
        return config

    def _update_agent_config(
        self,
        cbv,
        agent_type: str,
        payload: AgentConfigUpdatePayload,
        disable: bool | None = None,
    ) -> AgentConfigPublic:
        if payload.skills_set:
            # Get current agent config to calculate new enabled_skills
            service = AgentConfigService(db=cbv.db, request=cbv.request, user=cbv.user)
            agent_config = service.get_object(filters=(AgentConfig.type == agent_type,))

            payload.enabled_skills = self.update_enabled_skills(
                agent_config, payload.skills_set, disable or False
            )

        return super()._update_agent_config(cbv, agent_type, payload, disable)

    def update_enabled_skills(
        self, agent_config, skills_set: list[str], disable: bool
    ) -> list[str]:
        try:
            enabled_skills = provide_enabled_skills(
                agent_config=agent_config,
                skills_set=skills_set,
                disable_parameter=disable,
            )
            logging.info(f"Updating skills to: {enabled_skills}")
            return enabled_skills
        except (AttributeError, KeyError) as e:
            logging.warning(f"Could not update skills from registry: {e}")
        return []

    async def message_send(
        self,
        data,
        db,
        user,
        request,
        deps=None,
        deps_args=None,
    ):
        """
        Override message_send to handle sandbox creation with context_id for workflows.

        For workflows (context_id starts with "workflow-"), creates execution-scoped sandboxes.
        For user chats, uses default user-scoped sandbox behavior.
        """
        context_id = data.message.contextId or str(uuid.uuid4())
        deps_args = deps_args or {}

        sandbox_service = E2BSandboxService(db=db, user=user, request=request)
        sandbox_db, sandbox = await sandbox_service.create_sandbox(
            context_id=None if self.user else context_id
        )
        deps_args["sandbox"] = sandbox

        return await super().message_send(
            data=data,
            db=db,
            user=user,
            request=request,
            deps=deps,
            deps_args=deps_args,
        )

    async def before_message_stream(self, *args, **kwargs):
        deps = kwargs.get("deps")

        message = getattr(deps.payload, "message", None) if deps.payload else None
        has_files = self._message_has_files(message) if message else False

        if not has_files:
            logging.info("No files to upload, skipping sandbox creation")
            return

        sandbox_service = E2BSandboxService(
            db=deps.db, user=deps.user, request=deps.request
        )
        # Get context_id from payload for workflow execution sandboxes
        context_id = deps.payload.message.contextId if deps.payload else None
        sandbox_db, sandbox = await sandbox_service.create_sandbox(
            context_id=None if deps.user else context_id
        )
        deps.sandbox = sandbox

        file_upload_infos = await self.upload_user_files_to_sandbox(deps, message)
        if file_upload_infos:
            await self._save_user_uploaded_files_to_db(deps, file_upload_infos)

    def _message_has_files(self, message: Message) -> bool:
        """Check if message contains file uploads"""
        if not hasattr(message, "parts"):
            return False
        return any(isinstance(part, FilePart) for part in message.parts)

    async def upload_user_files_to_sandbox(
        self, deps: AgentDeps, message: Message
    ) -> list[FileUploadInfo]:
        res = []

        for i, part in enumerate(message.parts):
            if not isinstance(part, FilePart):
                continue

            file_data = part.file
            filename = file_data.name or f"uploaded_file_{i}"
            mime_type = file_data.mimeType or "application/octet-stream"
            gcs_path = None

            if isinstance(file_data, FileWithBytes) and file_data.bytes:
                file_bytes = base64.b64decode(file_data.bytes)
            elif isinstance(file_data, FileWithUri) and file_data.uri:
                response = await httpx.AsyncClient().get(file_data.uri, timeout=30.0)
                try:
                    response.raise_for_status()
                except Exception as e:
                    logging.error(f"Error downloading file from URI: {e}")
                    res.append(
                        FileUploadInfo(
                            filename=filename,
                            mime_type=mime_type,
                            file_size=0,
                            path=None,
                            error=str(e),
                        )
                    )
                    continue
                file_bytes = response.content
                gcs_path = self._extract_gcs_path_from_uri(file_data.uri)

            # Upload to E2B sandbox
            write_info = await deps.sandbox.files.write(
                f"{SANDBOX_ROOT_PATH}/{USER_FILES_FOLDER}/{filename}", file_bytes
            )

            res.append(
                FileUploadInfo(
                    filename=write_info.name,
                    mime_type=mime_type,
                    file_size=len(file_bytes),
                    path=write_info.path,
                    error=None,
                    gcs_path=gcs_path,
                )
            )

        return res

    def _extract_gcs_path_from_uri(self, uri: str) -> str:
        """
        Extract GCS path from signed URL.

        Example URI:
        https://storage.googleapis.com/central-hub-bucket-pub/files/user/uuid/file.pdf?X-Goog-Algorithm=...

        Returns: files/user/uuid/file.pdf
        """
        parsed = urlparse(uri)
        # Get the path part (without query params)
        path = parsed.path
        # Remove leading slash and bucket name
        # Path format: /bucket-name/files/user/uuid/file.pdf
        parts = path.split(
            "/", 2
        )  # Split into ['', 'bucket-name', 'files/user/uuid/file.pdf']
        if len(parts) >= 3:
            return parts[2]  # Return 'files/user/uuid/file.pdf'
        return path.lstrip("/")

    async def _save_user_uploaded_files_to_db(
        self, deps: AgentDeps, file_infos: list[FileUploadInfo]
    ):
        """
        Save user-uploaded file mappings to sandbox database record.

        Args:
            deps: Agent dependencies
            file_infos: List of FileUploadInfo objects
        """
        # Get sandbox record
        filter = (
            SandboxModel.user_email == deps.user.email
            if deps.user
            else SandboxModel.context_id == deps.payload.message.contextId
        )

        sandbox_db = deps.db.scalars(select(SandboxModel).where(filter)).first()

        if not sandbox_db:
            logging.error("Sandbox record not found in database")
            return

        existing_files = sandbox_db.files or {}
        for file_info in file_infos:
            if file_info.error:
                continue

            # TODO:?
            bucket_name = None
            if file_info.gcs_path:
                if file_info.gcs_path.startswith("gs://"):
                    bucket_name = file_info.gcs_path.split("/")[2]
                else:
                    bucket_name = "central-hub-bucket-pub"

            existing_files[file_info.filename] = {
                "sandbox_path": file_info.path,
                "gcs_path": file_info.gcs_path,
                "bucket_name": bucket_name,
                "mime_type": file_info.mime_type,
                "file_size": file_info.file_size,
                "uploaded_at": datetime.now(timezone.utc).isoformat(),
                "type": "user_upload",
            }

        sandbox_db.files = existing_files
        deps.db.commit()
        logging.info(f"Saved {len(file_infos)} user-uploaded files to sandbox database")


async def _upload_generated_files_to_gcs(
    deps: AgentDeps, file_paths: list[str], sandbox_path_prefix: str
) -> list[dict]:
    """
    Upload generated files from sandbox to GCS.

    Args:
        deps: Agent dependencies
        file_paths: List of file paths in the sandbox

    Returns:
        List of dicts with file info: {sandbox_path, gcs_path, filename}
    """
    uploaded_files = []

    # Initialize GCS service if not already done
    if not deps.gcs_service:
        deps.gcs_service = GCStorage(
            bucket_name=deps.settings.GC_BUCKET_NAME, settings=deps.settings
        )

    for file_path in file_paths:
        file_content = await deps.sandbox.files.read(file_path, format="bytes")
        if isinstance(file_content, bytearray):
            file_content = bytes(file_content)

        filename = file_path.split("/")[-1]
        mime_type, _ = mimetypes.guess_type(filename)
        if not mime_type:
            mime_type = "application/octet-stream"
        gcs_path = f"sandbox/{sandbox_path_prefix}/output/{filename}"

        full_gcs_path = deps.gcs_service.upload_file(
            source=file_content,
            destination_path=gcs_path,
            content_type=mime_type,
        )

        uploaded_files.append(
            {
                "sandbox_path": file_path,
                "gcs_path": gcs_path,
                "bucket_name": deps.settings.GC_BUCKET_NAME,
                "filename": filename,
            }
        )

        logging.info(f"Uploaded {filename} to GCS: {full_gcs_path} (type: {mime_type})")

    return uploaded_files


async def _save_files_to_sandbox_db(deps: AgentDeps, file_infos: list[dict]):
    """
    Save file mappings to sandbox database record.

    Args:
        deps: Agent dependencies
        file_infos: List of file info dicts
    """
    try:
        filter = (
            SandboxModel.user_email == deps.user.email
            if deps.user
            else SandboxModel.context_id == deps.payload.message.contextId
        )
        # Get sandbox record
        stmt = select(SandboxModel).where(filter)
        result = deps.db.execute(stmt)
        sandbox_db = result.scalar_one_or_none()

        if not sandbox_db:
            logging.error("Sandbox record not found in database")
            return

        # Get existing files or initialize empty dict
        existing_files = sandbox_db.files or {}

        # Add new files to the mapping
        for file_info in file_infos:
            filename = file_info["filename"]
            existing_files[filename] = {
                "sandbox_path": file_info["sandbox_path"],
                "gcs_path": file_info["gcs_path"],
                "bucket_name": file_info["bucket_name"],
                "uploaded_at": datetime.now(timezone.utc).isoformat(),
                "type": "generated",
            }

        # Update database
        sandbox_db.files = existing_files
        deps.db.commit()

        logging.info(f"Saved {len(file_infos)} files to sandbox database record")

    except Exception as e:
        logging.error(f"Error saving files to sandbox database: {e}")


async def execute_code(ctx: RunContext[AgentDeps], code: str) -> ToolReturn:
    """
    Execute Python code in the sandbox.

    Args:
        code: Python code to execute. Must set a 'result' dict variable with 'message' and 'generated_files' keys.

    Returns:
        Execution results including generated files
    """
    deps = ctx.deps

    # Get enabled_skills from agent_config if available
    enabled_skills = []
    if deps.payload and deps.payload.message.metadata:
        agent_type = deps.payload.message.metadata.get("agent_type")
        if agent_type:
            agent_config = deps.db.scalars(
                select(AgentConfig).where(AgentConfig.type == agent_type)
            ).first()
            if agent_config:
                enabled_skills = agent_config.enabled_skills or []

    sandbox_service = E2BSandboxService(
        db=deps.db, user=deps.user, request=deps.request
    )

    if not deps.sandbox:
        # Get context_id from payload for workflow execution sandboxes
        context_id = deps.payload.message.contextId if deps.payload else None
        sandbox_db, sandbox = await sandbox_service.create_sandbox(
            context_id=None if deps.user else context_id
        )
        deps.sandbox = sandbox
    else:
        sandbox = deps.sandbox
        if deps.user:
            sandbox_db = deps.db.scalars(
                select(SandboxModel).where(SandboxModel.user_email == deps.user.email)
            ).first()
        elif deps.payload:
            context_id = deps.payload.message.contextId
            sandbox_db = deps.db.scalars(
                select(SandboxModel).where(SandboxModel.context_id == context_id)
            ).first()

    if not sandbox_db:
        assert False, "Sandbox record not found in database, this should never happen"

    code_executor = CodeExecutor(db=deps.db)

    result = await code_executor.execute(
        code=code,
        sandbox=sandbox,
        sandbox_db=sandbox_db,
        enabled_skills=enabled_skills,
    )

    generated_files = result.get("generated_files", [])
    result.pop("generated_code", None)

    generated_files_paths = []
    sandbox_path_prefix = (
        deps.user.id if deps.user else f"context-id:{deps.payload.message.contextId}"
    )

    if generated_files:
        uploaded_files = await _upload_generated_files_to_gcs(
            deps, generated_files, sandbox_path_prefix
        )
        await _save_files_to_sandbox_db(deps, uploaded_files)

        # Collect file paths for later presigned URL generation
        for file_info in uploaded_files:
            generated_files_paths.append(
                {
                    "filename": file_info["filename"],
                    "gcs_path": file_info["gcs_path"],
                    "bucket_name": file_info["bucket_name"],
                }
            )

    # Add generated files paths to result (for later presigned URL generation)
    result["generated_files_paths"] = generated_files_paths

    return ToolReturn(
        data=result,
    )
