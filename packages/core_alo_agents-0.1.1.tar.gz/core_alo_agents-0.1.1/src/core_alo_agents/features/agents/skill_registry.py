"""
Skill Registry - Manages available skills and their metadata.

Skills are Python files containing reusable functions that can be injected into
the E2B sandbox environment, allowing agents to leverage pre-written code instead
of generating everything from scratch.
"""

from dataclasses import dataclass
from pathlib import Path
import ast
import logging
from ...config import settings


@dataclass
class SkillDefinition:
    """Definition of a skill with metadata for the agent."""
    
    name: str
    file_path: str  # Path in sandbox (e.g., /home/user/skills/pdf.py)
    description: str
    functions: dict[str, str]  # Dictionary mapping function names to their docstrings
    required_packages: list[str]  # List of pip packages required by this skill


class SkillRegistry:
    """Registry for managing available skills."""
    
    def __init__(self, additional_skill_path: str | Path | None = None):
        self.skills: dict[str, SkillDefinition] = {}
        self.additional_skill_path = additional_skill_path
        self._load_skills()
    
    def _load_skills(self):
        """Automatically discover and register skills from the skills directory."""
        # Default skills directory (in core_alo_agents)
        default_skills_dir = settings.ROOT_PATH / "skills"
        
        # Collect all paths to scan
        paths_to_scan = [default_skills_dir]
        
        # Add additional path from external agent if provided
        if self.additional_skill_path:
            skill_path = Path(self.additional_skill_path) if isinstance(self.additional_skill_path, str) else self.additional_skill_path
            if skill_path.exists() and skill_path.is_dir():
                paths_to_scan.append(skill_path)
            else:
                logging.warning(f"Skill path does not exist or is not a directory: {skill_path}")
        
        # Load skills from all paths
        for skills_dir in paths_to_scan:
            self._load_skills_from_directory(skills_dir)
    
    def _load_skills_from_directory(self, skills_dir: Path):
        """Load skills from a specific directory using AST parsing (no import needed)."""
        if not skills_dir.exists():
            logging.warning(f"Warning: Skills directory does not exist: {skills_dir}")
            return
        
        # TODO: decide if we need to do loading on start always, or only when inject to sandbox?
        logging.info(f"[SKILL-REGISTRY] Loading skills from: {skills_dir}")
        
        for skill_file in skills_dir.glob("*.py"):
            if skill_file.name.startswith("_") or skill_file.stem in ["registry"]:
                logging.info(f"[SKILL-REGISTRY] Skipping file: {skill_file.name}")
                continue
            
            skill_name = skill_file.stem
            logging.info(f"[SKILL-REGISTRY] Processing skill file: {skill_file.name} (name: {skill_name})")
            
            # Parse the file using AST (this removes the need to install skill-related dependencies on the agent server)
            try:
                with open(skill_file, 'r', encoding='utf-8') as f:
                    file_content = f.read()
                
                # Parse the AST
                tree = ast.parse(file_content)
                
                # Get module docstring
                description = ast.get_docstring(tree) or f"Skills for {skill_name}"
                description = description.strip()
                
                required_packages = self._extract_required_packages(tree)
                
                # Extract all public function definitions with their docstrings
                # Only look at top-level functions (tree.body), not nested functions
                functions = {}
                for node in tree.body:
                    # Skip non-function nodes
                    if not isinstance(node, ast.FunctionDef):
                        continue
                    
                    func_name = node.name
                    # Skip private functions (starting with _)
                    if func_name.startswith("_"):
                        continue
                    
                    # Get the function's docstring
                    docstring = ast.get_docstring(node) or ""
                    functions[func_name] = docstring
                
                # Skip if no public functions found
                if not functions:
                    logging.info(f"[SKILL-REGISTRY] No public functions found in {skill_name}, skipping")
                    continue
                
                # Path in sandbox (will be uploaded to /home/user/skills/)
                sandbox_path = f"/home/user/skills/{skill_file.name}"
                
                self.skills[skill_name] = SkillDefinition(
                    name=skill_name,
                    file_path=sandbox_path,
                    description=description,
                    functions=functions,
                    required_packages=required_packages,
                )
                
                packages_info = f" (requires: {', '.join(required_packages)})" if required_packages else ""
                logging.info(f"[SKILL-REGISTRY] Successfully loaded skill '{skill_name}' with {len(functions)} functions{packages_info}")
                
            except Exception as e:
                # Skip files that can't be parsed
                logging.warning(f"[SKILL-REGISTRY] Warning: Could not parse skill {skill_name}: {e}")
                import traceback
                traceback.print_exc()
                continue
    
    def _extract_required_packages(self, tree: ast.AST) -> list[str]:
        """Extract REQUIRED_PACKAGES list from AST."""
        required_packages = []
        
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            
            for target in node.targets:
                if not isinstance(target, ast.Name) or target.id != "REQUIRED_PACKAGES":
                    continue
                
                if not isinstance(node.value, ast.List):
                    break
                for elt in node.value.elts:
                    if isinstance(elt, ast.Constant):
                        required_packages.append(elt.value)
        
        return required_packages

    def get_skill(self, name: str) -> SkillDefinition | None:
        """Get a skill definition by name."""
        return self.skills.get(name)
    
    def get_all_skills(self) -> dict[str, SkillDefinition]:
        """Get all available skills."""
        return self.skills
    
    def get_skill_prompt_context(self, enabled_skills: list[str]) -> str:
        """Generate prompt context for enabled skills.
        
        Args:
            enabled_skills: List of skill names OR function names to include in the prompt
            
        Returns:
            Formatted string describing available skills for the agent
        """
        if not enabled_skills:
            return ""
        
        # First, map function names to skill names (same logic as get_skill_files)
        skills_to_include = set()
        
        for item in enabled_skills:
            # First, check if it's a skill name
            skill = self.get_skill(item)
            if skill:
                skills_to_include.add(item)
            else:
                # If not a skill name, search for which skill contains this function
                for skill_name, skill_def in self.skills.items():
                    if item in skill_def.functions:
                        skills_to_include.add(skill_name)
                        break
        
        if not skills_to_include:
            return ""
        
        context_parts = ["\n## Available Skills"]
        
        for skill_name in skills_to_include:
            skill = self.get_skill(skill_name)
            if not skill:
                continue
            
            context_parts.append(f"\n### {skill_name}")
            context_parts.append(f"{skill.description}")
            context_parts.append("\nAvailable functions:")
            
            # List each function with its docstring
            for func_name, func_docstring in skill.functions.items():
                context_parts.append(f"\n- **{func_name}**")
                if func_docstring:
                    # Indent the docstring for better readability
                    indented_docstring = '\n  '.join(func_docstring.split('\n'))
                    context_parts.append(f"  {indented_docstring}")
            
            context_parts.append(f"\nImport with: `from skills.{skill_name} import <function_name>`\n")
        
        return "\n".join(context_parts)
    
    def get_skill_files(self, enabled_skills: list[str]) -> dict[str, Path]:
        """Get file paths for enabled skills to upload to sandbox.
        
        Args:
            enabled_skills: List of skill names OR function names to get files for
            
        Returns:
            Dictionary mapping sandbox paths to local file paths
        """
        files = {}
        
        # Collect all possible skill directories
        default_skills_dir = Path(__file__).parent.parent / "skills"
        all_skill_dirs = [default_skills_dir]
        
        # Add additional path from external agent if provided
        if self.additional_skill_path:
            skill_path = Path(self.additional_skill_path) if isinstance(self.additional_skill_path, str) else self.additional_skill_path
            if skill_path.exists() and skill_path.is_dir():
                all_skill_dirs.append(skill_path)
        
        skills_to_include = set()
        
        for item in enabled_skills:
            # First, check if it's a skill name
            skill = self.get_skill(item)
            if skill:
                skills_to_include.add(item)
                logging.info(f"[SKILL-FILES] '{item}' is a skill name")
            else:
                # If not a skill name, search for which skill contains this function
                for skill_name, skill_def in self.skills.items():
                    if item in skill_def.functions:
                        skills_to_include.add(skill_name)
                        logging.info(f"[SKILL-FILES] Function '{item}' found in skill '{skill_name}'")
                        break
                else:
                    logging.warning(f"[SKILL-FILES] WARNING: '{item}' not found as skill or function")
        
        logging.info(f"[SKILL-FILES] Skills to include: {skills_to_include}")
        
        # Now get the file paths for all identified skills
        for skill_name in skills_to_include:
            skill = self.get_skill(skill_name)
            if skill:
                # Search for the skill file in all directories
                for skills_dir in all_skill_dirs:
                    local_path = skills_dir / f"{skill_name}.py"
                    logging.info(f"[SKILL-FILES] Looking for {skill_name}.py in {skills_dir}")
                    if local_path.exists():
                        files[skill.file_path] = local_path
                        logging.info(f"[SKILL-FILES] Found: {local_path}")
                        break
                else:
                    logging.error(f"[SKILL-FILES] ERROR: Could not find file for skill '{skill_name}'")
        
        logging.info(f"[SKILL-FILES] Final files mapping: {files}")
        return files
    
    def get_required_packages(self, enabled_skills: list[str]) -> set[str]:
        """Get all required packages for enabled skills.
        
        Args:
            enabled_skills: List of skill names OR function names
            
        Returns:
            List of unique package names required by the enabled skills
        """

        enabled_skill_defs = [self.get_skill(skill) for skill in enabled_skills]
        return set(
            package
            for skill_def in enabled_skill_defs
            if skill_def
            for package in skill_def.required_packages
        )


# TODO: for now is ok, but review if we want to keep it as global instance?
#   at some point skills are probably gonna be user/db configurable, 
#   so we will need to move it to agent instance; perhaps pre-caching the default ones from files or sth
# TODO: also dont need to load if not using CodeAgent agent?
# Global registry instance
skill_registry = SkillRegistry()
