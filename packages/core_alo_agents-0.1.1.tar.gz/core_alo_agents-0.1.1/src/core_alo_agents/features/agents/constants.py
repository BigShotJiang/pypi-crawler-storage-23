# JSON-RPC 2.0 Error Codes
from enum import IntEnum, StrEnum


WORKFLOW_ROUTER_PREFIX = "/workflows"


class ExtMimeType(StrEnum):
    xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


class JsonRpcErrorCode(IntEnum):
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    SERVER_ERROR = (
        -32000
    )  # -32000 to -32099 are reserved for implementation-defined server-errors


class PartialMessageType(StrEnum):
    START = "start"
    END = "end"
    TEXT_DELTA = "text-delta"
    THINKING_DELTA = "thinking-delta"
    TOOL_DELTA = "tool-delta"
    INTERNAL = "internal"


class McpServerName(StrEnum):
    BRAVE_SEARCH = "brave_search"
    FETCH = "fetch"
    LINKEDIN = "linkedin"
    FMP = "financial_modeling_prep"


class OTLPActions(StrEnum):
    SEND_MESSAGE = "POST /jsonrpc"


OTLP_ACTION_LABELS = {
    OTLPActions.SEND_MESSAGE: "Send message",
}


class AllowedLLMModels(StrEnum):
    """Allowed LLM models for runtime switching."""

    GEMINI_2_5_FLASH = "gemini-2.5-flash"
    GEMINI_2_5_PRO = "gemini-2.5-pro"
    GEMINI_3_0_PRO_PREVIEW = "gemini-3-pro-preview"
    GEMINI_3_0_FLASH = "gemini-3-flash-preview"


ALLOWED_LLM_MODELS = {model for model in AllowedLLMModels}
DEFAULT_LLM_MODEL = AllowedLLMModels.GEMINI_3_0_FLASH


CODE_AGENT_SKILLS_CONTEXT = """
# CODE GENERATION INSTRUCTION - READ CAREFULLY
Before writing ANY code, you MUST check the "Available Skills" section below.
If ANY function you need exists in the skills, you MUST import and use it.
NEVER write your own implementation if a skill function exists.

{context}

# Example:
WRONG ❌:
import math
result = math.factorial(10)

CORRECT ✅:
from skills.math import factorial
result = factorial(10)

This is MANDATORY. Always prefer skills functions over standard library or custom implementations.
"""


CODE_AGENT_UPLOADED_FILES_CONTEXT = """
# UPLOADED FILES - IMPORTANT
The following files have been uploaded and are available in your sandbox:

{files_context}

CRITICAL: When working with uploaded files, you MUST use the sandbox path shown above (the path after →).
DO NOT use file IDs or URIs from the upload - always use the actual filename in /home/user/user_files/

Example:
If you see: 'document.pdf' → /home/user/user_files/document.pdf
Then use: /home/user/user_files/document.pdf (or just 'document.pdf' if in that directory)
"""
