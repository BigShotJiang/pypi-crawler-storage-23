OUTPUT_FOLDER = "output"
USER_FILES_FOLDER = "user_files"
