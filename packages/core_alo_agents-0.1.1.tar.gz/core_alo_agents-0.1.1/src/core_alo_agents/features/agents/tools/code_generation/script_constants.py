# not safe for now w/ secrets
GENERATE_IMAGE_FUNCTION = """
import os
from google import genai

try:
    # 1. Initialize Client (API Key is injected automatically in environment)
    api_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("API_KEY")
    if not api_key:
        raise ValueError("API key not found in environment")

    client = genai.Client(api_key=api_key)

    # 2. Define the Prompt
    prompt_text = "Detailed description of the image in English"
    
    # 3. Generate Content
    # Using gemini-2.5-flash-image model - returns images directly without config
    response = client.models.generate_content(
        model="gemini-2.5-flash-image",
        contents=prompt_text
    )

    # 4. Extract and Save to Analysis Folder
    # We iterate through parts to find the binary image data
    image_saved = False
    filename = "generated_image.png"
    save_path = f"{analysis_folder}/{filename}"

    if response.candidates and response.candidates[0].content.parts:
        for part in response.candidates[0].content.parts:
            if part.inline_data and part.inline_data.data:
                with open(save_path, "wb") as f:
                    f.write(part.inline_data.data)
                image_saved = True
                break # Stop after finding the first image

    if image_saved:
        result = f"Image generated successfully"
    else:
        result = "Error: No image data found in the response."

except Exception as e:
    result = f"Error generating image: {str(e)}"
"""
