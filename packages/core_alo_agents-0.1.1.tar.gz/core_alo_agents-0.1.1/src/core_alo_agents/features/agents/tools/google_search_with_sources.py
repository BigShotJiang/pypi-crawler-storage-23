import httpx
import asyncio

from typing import Literal
from pydantic import BaseModel
from google.genai import Client as GoogleClient
from google.genai import types as genai_types


class SourceLink(BaseModel):
    url: str
    title: str


class GoogleWebSearchWithSourcesResult(BaseModel):
    result: str
    result_with_citations: str | None = None
    source_links: list[SourceLink]


async def google_search_with_sources(
    google_client: GoogleClient,
    prompt: str,
    with_citations: bool = False,
    citations_format: Literal["standard", "jira"] = "standard",
    resolve_urls: bool = False,
) -> GoogleWebSearchWithSourcesResult:
    """
    Perform a Google search to find the answer to the user's question.
    """
    tools = [{"url_context": {}}, {"google_search": {}}]

    # Make the request to Google GenAI
    response = await google_client.aio.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
        config=genai_types.GenerateContentConfig(
            tools=tools,
        ),
    )

    result = GoogleWebSearchWithSourcesResult(
        result=response.text or "", source_links=[]
    )

    candidate = response.candidates[0]
    if candidate.grounding_metadata:
        grounding_chunks = (
            getattr(candidate.grounding_metadata, "grounding_chunks", []) or []
        )
        for chunk in grounding_chunks:
            result.source_links.append(
                SourceLink(url=chunk.web.uri, title=chunk.web.title)
            )

    if with_citations:
        result.result_with_citations = add_citations(response, citations_format)

    # Resolve URLs in parallel if requested
    if resolve_urls and result.source_links:
        tasks = [resolve_redirect_url(link.url) for link in result.source_links]
        resolved_urls = await asyncio.gather(*tasks)

        # Substitute the result.source_links with the resolved versions
        for i, resolved_url in enumerate(resolved_urls):
            result.source_links[i].url = resolved_url

    return result


CITATION_FORMATS = {
    "standard": "[{index}]({url})",
    "jira": "[{index}|{url}]",
}


# Based on https://ai.google.dev/gemini-api/docs/google-search#attributing_sources_with_inline_citations
def add_citations(response, format: Literal["standard", "jira"] = "standard"):
    text = response.text
    supports = response.candidates[0].grounding_metadata.grounding_supports or []
    chunks = response.candidates[0].grounding_metadata.grounding_chunks or []

    # Sort supports by end_index in descending order to avoid shifting issues when inserting.
    sorted_supports = sorted(supports, key=lambda s: s.segment.end_index, reverse=True)

    for support in sorted_supports:
        end_index = support.segment.end_index
        if support.grounding_chunk_indices:
            # Create citation string like [1](link1)[2](link2)
            citation_links = []
            for i in support.grounding_chunk_indices or []:
                if i < len(chunks):
                    uri = chunks[i].web.uri
                    citation_links.append(
                        CITATION_FORMATS[format].format(index=i + 1, url=uri)
                    )

            citation_string = ", ".join(citation_links)
            text = text[:end_index] + citation_string + text[end_index:]

    return text


# Resolve urls with domain vertexaisearch
async def resolve_redirect_url(url: str) -> str:
    """Follows the Vertex AI redirect to get the actual URL."""
    if "vertexaisearch.cloud.google.com" not in url:
        return url

    try:
        # Use a HEAD request to follow redirects without downloading body
        async with httpx.AsyncClient() as client:
            resp = await client.head(url, follow_redirects=True, timeout=2.0)
            return str(resp.url)
    except Exception as e:
        # If resolution fails, return the original redirect link as fallback
        return url
