from fastapi import Depends

from core_alo.mixins import BaseCBVMixin
from core_alo.schemas import UserPublic
from ...deps import get_auth_deps
from ...config import settings


class UserCBVMixin(BaseCBVMixin):
    user: UserPublic | None = Depends(get_auth_deps(settings))
