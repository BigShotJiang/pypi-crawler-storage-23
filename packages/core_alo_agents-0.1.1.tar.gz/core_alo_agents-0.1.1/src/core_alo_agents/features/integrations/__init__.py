"""Third-party platform integrations for agents."""

from .base import IntegrationBase
from .constants import IntegrationType, IntegrationActionType
from .slack import SlackIntegration

# Registry of available integrations
INTEGRATIONS = {
    IntegrationType.SLACK: SlackIntegration,
}

__all__ = [
    "IntegrationBase",
    "IntegrationType",
    "IntegrationActionType",
    "SlackIntegration",
    "INTEGRATIONS",
]
