# Slack Bot Setup

## 1. Create App

- Go to api.slack.com/apps → Create New App → From scratch
- Name it with the name of the agent (e.g., "Prime") and select workspace

## 2. Add OAuth Scopes

Navigate to **OAuth & Permissions** → **Bot Token Scopes**, add:

- `app_mentions:read`
- `channels:history`
- `channels:read`
- `chat:write`
- `commands`
- `files:write`
- `files:read`
- `groups:history`
- `im:history`
- `im:read`
- `users.profile:read`
- `users:read`
- `users:read.email`

## 3. Install to Workspace

- Click **Install to Workspace** → Allow
- Copy **Bot User OAuth Token** (starts with `xoxb-`)

## 4. Enable Direct Messages
Navigate to **App Home**:
- (optional) Enable **Always Show My Bot as Online**
- Under **Show Tabs** section
- Toggle **Allow users to send Slash commands and messages from the messages tab** → On
- (Optional) Customize Home Tab if needed

## 5. Enable Events

Navigate to **Event Subscriptions**:

- Toggle **Enable Events** → On
- Request URL: `{agent_base_url}/integrations/slack/events`
- Subscribe to bot events:
    - `app_mention`
    - `message.im`
- Save Changes

## 6. Get Signing Secret

- **Basic Information** → **App Credentials** → Copy **Signing Secret**

## 7. Environment Variables

```dotenv
SLACK_BOT_TOKEN=xoxb-your-token-here
SLACK_SIGNING_SECRET=your-secret-here
```

## 8. Test

- Invite bot to channel: `/invite @your_bot_name`
- Mention bot: `@your_bot_name hello`
