"""Base integration class for third-party platform integrations."""

import logging
from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

from fastapi import Request
from sqlalchemy.orm import Session
from pydantic_ai.messages import (
    ToolCallPart as PAIToolCallPart,
    ToolReturnPart as PAIToolReturnPart,
    RetryPromptPart as PAIRetryPromptPart,
)

from schemas import UserPublic
from .constants import IntegrationType
from ..agents.a2a_types import Message, MessageSendParams, Part, TextPart
from ..agents.types import AgentInternalMessage, MessageTool
from ..agents.constants import PartialMessageType


if TYPE_CHECKING:
    from ..agents.agents import Agent


class IntegrationBase(ABC):
    """Base class for all integrations (Slack, Jira, Linear, etc.)."""

    integration_type: IntegrationType

    def __init__(
        self,
        agent: "Agent",
        db: Session,
        user: UserPublic | None = None,
        request: Request | None = None,
    ):
        """
        Initialize the integration with an agent instance.

        Args:
            agent: The Agent this integration will communicate with
        """
        self.agent = agent
        self.db = db
        self.user = user
        self.request = request

        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

    @classmethod
    def is_available(cls) -> bool:
        """
        Check if the integration dependencies are installed.

        Returns:
            True if dependencies are available, False otherwise
        """
        return True

    @abstractmethod
    async def verify_auth(self) -> Any:
        """
        Verify the authentication of the integration platform.
        """
        pass

    @abstractmethod
    async def handle_event(self) -> Any:
        """
        Handle incoming events from the integration platform.

        Args:
            request: FastAPI request object
            db: Database session
            user: Optional user context

        Returns:
            Response appropriate for the integration platform
        """
        pass

    @abstractmethod
    async def handle_command(self) -> Any:
        """
        Handle incoming commands from the integration platform.
        """
        pass

    @abstractmethod
    async def send_message(self, text: str, **kwargs) -> Any:
        """
        Send a message through the integration platform.

        Args:
            text: Message text to send
            **kwargs: Additional platform-specific parameters

        Returns:
            Platform-specific response
        """
        pass

    @abstractmethod
    async def get_history(self, **kwargs) -> list[Message]:
        """
        Retrieve conversation history from the integration platform.

        This method should be overridden by subclasses to implement
        platform-specific history retrieval logic.

        Args:
            **kwargs: Platform-specific parameters (e.g., channel, thread_ts, etc.)

        Returns:
            List of Message objects representing conversation history.
            Default implementation returns empty list.
        """
        pass

    async def ask_agent(
        self,
        parts: list[Part],
        context_id: str,
        message_id: str,
        history: list[Message] | None = None,
        **kwargs,
    ) -> tuple[str, str, list[AgentInternalMessage]]:
        """
        Send a message through the integration platform.

        Args:
            parts: Message parts
            context_id: Context ID
            message_id: Message ID
            history: Message history
            **kwargs: Additional platform-specific parameters

        Returns:
            Full text, full reasoning, and internal messages
        """
        history = history if history is not None else await self.get_history(**kwargs)

        message = Message(
            contextId=context_id,
            messageId=message_id,
            role="user",
            parts=parts,
            metadata={
                "history": history,
                "show_internal_messages": True,
            },
        )
        payload = MessageSendParams(message=message, configuration=None)

        message_stream = self.agent._message_stream(
            data=payload,
            db=self.db,
            user=self.user,
            request=self.request,
        )

        full_text = ""
        full_reasoning = ""
        internal_messages = []
        async for partial_message in message_stream:
            metadata_type = (
                partial_message.metadata.get("type")
                if partial_message.metadata
                else None
            )

            # Collect text deltas
            if metadata_type == PartialMessageType.TEXT_DELTA:
                if partial_message.parts:
                    for part in partial_message.parts:
                        if isinstance(part, TextPart):
                            full_text += part.text

            # Collect thinking/reasoning deltas
            elif metadata_type == PartialMessageType.THINKING_DELTA:
                if partial_message.parts:
                    for part in partial_message.parts:
                        if isinstance(part, TextPart):
                            full_reasoning += part.text

            # Collect internal messages (for reasoning display)
            elif metadata_type == PartialMessageType.INTERNAL:
                if partial_message.metadata.get("internal_messages"):
                    internal_messages.extend(
                        partial_message.metadata["internal_messages"]
                    )

            # Log other events
            elif metadata_type == PartialMessageType.TOOL_DELTA:
                logging.info(f"Tool called: {partial_message.parts}")

        return full_text, full_reasoning, internal_messages

    def extract_tools_from_internal_messages(
        self, internal_messages: list[AgentInternalMessage]
    ) -> dict[str, MessageTool]:
        tools: dict[str, MessageTool] = {}

        for internal_message in internal_messages:
            for part in internal_message.parts:
                if isinstance(
                    part,
                    (
                        PAIToolCallPart,
                        PAIToolReturnPart,
                        PAIRetryPromptPart,
                    ),
                ):
                    tool_call_id = part.tool_call_id
                    if isinstance(part, PAIToolCallPart):
                        tool = MessageTool(
                            id=tool_call_id,
                            name=part.tool_name,
                            args=part.args,
                        )
                        tools[tool_call_id] = tool
                    elif isinstance(
                        part,
                        (
                            PAIToolReturnPart,
                            PAIRetryPromptPart,
                        ),
                    ):
                        if tool_call_id in tools:
                            tools[tool_call_id].content = part.content

        return tools

    def extract_generated_files_from_tools(
        self, tools: dict[str, MessageTool]
    ) -> list[dict]:
        # Use dict to track unique files by (gcs_path, bucket_name)
        unique_files = {}
        for tool_id, tool in tools.items():
            if tool.name == "execute_code":
                files = tool.content.data.get("generated_files_paths", [])
                for file_info in files:
                    key = (file_info["gcs_path"], file_info["bucket_name"])
                    if key not in unique_files:
                        unique_files[key] = file_info
        return list(unique_files.values())
