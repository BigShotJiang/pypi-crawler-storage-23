from enum import StrEnum


HISTORY_LENGTH = 20
ACKNOWLEDGMENT_MESSAGE = "Working on it..."


class IntegrationType(StrEnum):
    SLACK = "slack"
    # JIRA = "jira"
    # LINEAR = "linear"
    # WHATSAPP = "whatsapp"
    # TELEGRAM = "telegram"


class SlackIntegrationCommand(StrEnum):
    CLEAR_CONVERSATION = "clear_conversation"


class IntegrationActionType(StrEnum):
    EVENT = "event"
    COMMAND = "command"
