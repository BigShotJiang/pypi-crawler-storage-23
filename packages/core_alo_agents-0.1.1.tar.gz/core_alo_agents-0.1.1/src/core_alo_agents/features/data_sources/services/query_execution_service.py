"""Query Execution Service - The Execution Layer.

Orchestrates query execution and metadata retrieval by managing credentials,
connector lifecycle, timeouts, and error handling.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable

from sqlalchemy.orm import Session

from ..connectors.base import BaseConnector
from ..exceptions import QueryExecutionException, ExecutionTimeoutException
from ..logging import log_query_execution
from ..schemas import DataSourceMetadata, DataSourceConnection
from ..services.crypto_service import CryptoService
from ..connectors.connector_factory import ConnectorFactory


logger = logging.getLogger(__name__)


class QueryExecutionService:
    """Service for executing queries and retrieving metadata from data sources."""

    MAX_TIMEOUT = 300

    def __init__(self, db: Session, crypto_service: CryptoService):
        self.db = db
        self.crypto_service = crypto_service
        self.connector_factory = ConnectorFactory()

    async def execute_query(
        self,
        connection: DataSourceConnection,
        query: dict[str, Any],
        user_id: int,
        timeout: int = 30,
    ) -> Any:
        """Execute a query on the specified connection.

        Args:
            connection_id: ID of the connection to use
            query: Query payload (connector-specific format)
            user_id: ID of the user making the request
            timeout: Maximum execution time in seconds (default 30, max 300)

        Returns:
            Query results (connector-specific format)
        """
        return await self._execute_with_connector(
            connection=connection,
            user_id=user_id,
            timeout=timeout,
            operation=lambda connector: connector.execute_query(query),
            error_prefix="Query execution",
        )

    async def get_metadata(
        self, connection: DataSourceConnection, user_id: int, timeout: int = 30
    ) -> DataSourceMetadata:
        """Retrieve metadata (schema/tables/columns) from the data source.

        Args:
            connection_id: ID of the connection
            user_id: ID of the user making the request
            timeout: Maximum execution time in seconds (default 30, max 300)

        Returns:
            DataSourceMetadata with tables and columns
        """
        return await self._execute_with_connector(
            connection=connection,
            user_id=user_id,
            timeout=timeout,
            operation=lambda connector: connector.get_metadata(),
            error_prefix="Metadata retrieval",
        )

    async def _execute_with_connector(
        self,
        connection: DataSourceConnection,
        user_id: int,
        timeout: int,
        operation: Callable[[BaseConnector], Awaitable[Any]],
        error_prefix: str,
    ) -> Any:
        """Execute an operation with a connector instance.

        Handles connection setup, credential decryption, timeout enforcement, and cleanup.
        """
        connection_id = connection.id
        timeout = min(timeout, self.MAX_TIMEOUT)
        credentials = self.crypto_service.decrypt_connection_credentials(
            connection, self.crypto_service
        )

        connector = self.connector_factory.create_connector(connection.connector_key)

        try:
            await connector.connect(credentials)
            result = await asyncio.wait_for(operation(connector), timeout=timeout)
            log_query_execution(
                user_id=user_id,
                agent_id=getattr(self, "agent_id", None) or 0,
                connection_id=connection.id,
                connector_key=connection.connector_key,
                query_type="select" if "Query" in error_prefix else "metadata",
                result="success",
                duration_ms=None,
                rows_returned=None,
                details=None,
            )
            return result

        except asyncio.TimeoutError as exc:
            log_query_execution(
                user_id=user_id,
                agent_id=getattr(self, "agent_id", None) or 0,
                connection_id=connection.id,
                connector_key=connection.connector_key,
                query_type="select" if "Query" in error_prefix else "metadata",
                result="failure",
                duration_ms=None,
                rows_returned=None,
                details="timeout",
            )
            raise ExecutionTimeoutException(
                timeout_seconds=timeout, error_prefix=error_prefix
            ) from exc

        except QueryExecutionException:
            log_query_execution(
                user_id=user_id,
                agent_id=getattr(self, "agent_id", None) or 0,
                connection_id=connection_id,
                connector_key=connection.connector_key,
                query_type="select" if "Query" in error_prefix else "metadata",
                result="failure",
                duration_ms=None,
                rows_returned=None,
                details="query_error",
            )
            raise

        except Exception:
            log_query_execution(
                user_id=user_id,
                agent_id=getattr(self, "agent_id", None) or 0,
                connection_id=connection_id,
                connector_key=connection.connector_key,
                query_type="select" if "Query" in error_prefix else "metadata",
                result="failure",
                duration_ms=None,
                rows_returned=None,
                details="unexpected_error",
            )
            logger.exception(
                "%s failed for connection_id=%s", error_prefix, connection_id
            )
            raise QueryExecutionException(f"{error_prefix} failed")
