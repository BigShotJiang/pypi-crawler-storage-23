from __future__ import annotations


def format_condition_to_sql(condition: dict) -> str:
    """Convert a DefinitionCondition to SQL-like syntax."""
    field = condition.get("field", "")
    operator = condition.get("operator", "")
    value = condition.get("value")

    operator_map = {
        "equals": "=",
        "not_equals": "!=",
        "contains": "LIKE",
        "greater_than": ">",
        "less_than": "<",
        "in": "IN",
        "not_in": "NOT IN",
    }

    sql_op = operator_map.get(operator, "=")

    if operator == "contains":
        return f"{field} LIKE '%{value}%'"
    if operator in ("in", "not_in") and isinstance(value, list):
        formatted_values = ", ".join(
            f"'{v}'" if isinstance(v, str) else str(v) for v in value
        )
        return f"{field} {sql_op} ({formatted_values})"
    if isinstance(value, str):
        return f"{field} {sql_op} '{value}'"
    return f"{field} {sql_op} {value}"


def build_semantic_layer_prompt(semantic_layer: dict) -> str:
    """Build semantic layer prompt context from metadata."""
    if not semantic_layer:
        return ""

    prompt_sections: list[str] = []
    prompt_sections.append("# Semantic Layer Context")
    prompt_sections.append(
        "Use the following business context to write accurate SQL queries:\n"
    )

    tables = semantic_layer.get("tables", [])
    if tables:
        prompt_sections.append("## Available Tables")
        for table in tables:
            if not table.get("is_included", True):
                continue
            table_entry = f"- **{table['name']}**"
            if table.get("display_name"):
                table_entry += f" ({table['display_name']})"
            if table.get("purpose"):
                table_entry += f": {table['purpose']}"
            if table.get("domain"):
                table_entry += f" [Domain: {table['domain']}]"
            prompt_sections.append(table_entry)
        prompt_sections.append("")

    relationships = semantic_layer.get("relationships", [])
    if relationships:
        prompt_sections.append("## Table Relationships (Use for JOINs)")
        prompt_sections.append(
            "IMPORTANT: Always use these relationships when joining tables:\n"
        )
        for rel in relationships:
            from_cols = ", ".join(rel["from_columns"])
            to_cols = ", ".join(rel["to_columns"])
            join_info = f"- **{rel['from_table']}** -> **{rel['to_table']}**"
            join_info += (
                f"\n  - Join: `{rel['from_table']}.{from_cols}` = "
                f"`{rel['to_table']}.{to_cols}`"
            )
            join_info += f"\n  - Cardinality: {rel.get('cardinality', '1:N')}"
            join_info += f"\n  - Join Type: {rel.get('join_type', 'LEFT')} JOIN"
            if rel.get("when_to_use"):
                join_info += f"\n  - When to use: {rel['when_to_use']}"
            prompt_sections.append(join_info)
        prompt_sections.append("")

    definitions = semantic_layer.get("definitions", [])
    if definitions:
        prompt_sections.append("## Business Definitions")
        prompt_sections.append(
            "IMPORTANT: Apply these definitions when users reference these terms:\n"
        )
        for defn in definitions:
            defn_entry = f"- **{defn['name']}**: {defn['description']}"
            if defn.get("domain"):
                defn_entry += f" [Domain: {defn['domain']}]"

            conditions = defn.get("conditions", [])
            if conditions:
                sql_conditions = [
                    format_condition_to_sql(condition)
                    for condition in conditions
                    if format_condition_to_sql(condition)
                ]
                if sql_conditions:
                    defn_entry += (
                        "\n  - SQL Condition: `"
                        + " AND ".join(sql_conditions)
                        + "`"
                    )
            prompt_sections.append(defn_entry)
        prompt_sections.append("")

    kpis = semantic_layer.get("kpis", [])
    if kpis:
        prompt_sections.append("## Pre-defined KPIs & Metrics")
        prompt_sections.append(
            "When users ask about these metrics, use the provided SQL:\n"
        )
        for kpi in kpis:
            kpi_entry = f"- **{kpi['name']}**"
            if kpi.get("description"):
                kpi_entry += f": {kpi['description']}"
            if kpi.get("formula"):
                kpi_entry += f"\n  - Formula: `{kpi['formula']}`"
            if kpi.get("sql"):
                kpi_entry += f"\n  - SQL: ```sql\n{kpi['sql']}\n```"
            if kpi.get("tables"):
                kpi_entry += f"\n  - Tables: {', '.join(kpi['tables'])}"
            prompt_sections.append(kpi_entry)
        prompt_sections.append("")

    return "\n".join(prompt_sections)
