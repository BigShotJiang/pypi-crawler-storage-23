from fastapi import HTTPException


class RetryableException(HTTPException):
    """Base for errors that may succeed on retry.

    Sets the standard HTTP Retry-After header when retry_after_seconds is provided.
    Use this for timeouts, rate limits, and other transient failures.
    """

    def __init__(
        self,
        status_code: int,
        detail: str,
        retry_after_seconds: int | None = None,
    ):
        headers = (
            {"Retry-After": str(retry_after_seconds)} if retry_after_seconds else None
        )
        super().__init__(status_code=status_code, detail=detail, headers=headers)
        self.retry_after_seconds = retry_after_seconds


class ConnectorNotFoundException(HTTPException):
    """404 - Connector does not exist."""

    def __init__(self, connector_key: str | None = None):
        detail = (
            f"Connector with key '{connector_key}' not found."
            if connector_key
            else "Connector not found."
        )
        super().__init__(status_code=404, detail=detail)


class ExternalServiceException(HTTPException):
    """502 - External service returned an error (sanitized).

    Example:
        raise ExternalServiceException("Snowflake", operation="executing query")
        # → "Error communicating with Snowflake while executing query. Please try again later."
    """

    def __init__(
        self, service_name: str = "external service", operation: str | None = None
    ):
        detail = f"Error communicating with {service_name}"
        if operation:
            detail += f" while {operation}"
        detail += ". Please try again later."
        super().__init__(status_code=502, detail=detail)


class ExternalServiceAuthException(HTTPException):
    """401 - Authentication to external service failed.

    Example:
        raise ExternalServiceAuthException("Snowflake")
        # → "Authentication to Snowflake failed. Please check your credentials."

        raise ExternalServiceAuthException("Snowflake", reason="credentials expired")
        # → "Authentication to Snowflake failed: credentials expired."
    """

    def __init__(
        self, service_name: str = "external service", reason: str | None = None
    ):
        detail = f"Authentication to {service_name} failed"
        if reason:
            detail += f": {reason}"
        else:
            detail += ". Please check your credentials."
        super().__init__(status_code=401, detail=detail)


class QueryExecutionException(HTTPException):
    """400 - Query validation failed."""

    def __init__(self, detail: str):
        super().__init__(status_code=400, detail=detail)


class ExecutionTimeoutException(RetryableException):
    """504 - Execution timed out."""

    def __init__(self, timeout_seconds: int = 30, error_prefix: str | None = None):
        detail = f"Execution timed out after {timeout_seconds} seconds. Please retry."
        if error_prefix:
            detail = f"{error_prefix} timed out after {timeout_seconds} seconds. Please retry."
        super().__init__(
            status_code=504,
            detail=detail,
            retry_after_seconds=timeout_seconds,
        )
