import logging
from typing import Literal

logger = logging.getLogger(__name__)

ConnectorOperation = Literal["enabled", "disabled"]
ConnectionOperation = Literal["created", "updated", "deleted", "tested"]
QueryType = Literal["select", "metadata"]
OperationResult = Literal["success", "failure"]
CredentialAccessPurpose = Literal[
    "query_execution", "connection_test", "metadata_retrieval"
]


def _get_log_fn(result: OperationResult):
    """Choose log function based on result."""
    return logger.info if result == "success" else logger.error


def _format_log_message(event_type: str, **kwargs) -> str:
    """Format log message with key=value pairs, omitting None values."""
    parts = [event_type]
    for key, value in kwargs.items():
        if value is not None:
            parts.append(f"{key}={value}")
    return " ".join(parts)


def log_connector_operation(
    operation: ConnectorOperation,
    admin_user_id: int,
    connector_key: str,
    result: OperationResult,
    details: str | None = None,
) -> None:
    """Log connector enable/disable events."""
    log_fn = _get_log_fn(result)
    message = _format_log_message(
        f"CONNECTOR_{operation.upper()}",
        admin_user_id=admin_user_id,
        connector_key=connector_key,
        result=result,
        details=details,
    )
    log_fn(message)


def log_connection_operation(
    operation: ConnectionOperation,
    user_id: int,
    connection_id: int | None,
    connector_key: str,
    result: OperationResult,
    details: str | None = None,
) -> None:
    """Log connection CRUD and test operations."""
    log_fn = _get_log_fn(result)
    message = _format_log_message(
        f"CONNECTION_{operation.upper()}",
        user_id=user_id,
        connection_id=connection_id,
        connector_key=connector_key,
        result=result,
        details=details,
    )
    log_fn(message)


def log_query_execution(
    user_id: int,
    agent_id: int,
    connection_id: int,
    connector_key: str,
    query_type: QueryType,
    result: OperationResult,
    duration_ms: float | None = None,
    rows_returned: int | None = None,
    details: str | None = None,
) -> None:
    """Log query execution with performance metrics."""
    log_fn = _get_log_fn(result)
    message = _format_log_message(
        "QUERY_EXECUTED",
        user_id=user_id,
        agent_id=agent_id,
        connection_id=connection_id,
        connector_key=connector_key,
        query_type=query_type,
        result=result,
        duration_ms=duration_ms,
        rows_returned=rows_returned,
        details=details,
    )
    log_fn(message)


def log_credential_access(
    user_id: int,
    connection_id: int,
    connector_key: str,
    purpose: CredentialAccessPurpose,
    agent_id: int | None = None,
) -> None:
    """Log credential decryption for security audit."""
    message = _format_log_message(
        "CREDENTIALS_DECRYPTED",
        user_id=user_id,
        agent_id=agent_id,
        connection_id=connection_id,
        connector_key=connector_key,
        purpose=purpose,
    )
    logger.info(message)
