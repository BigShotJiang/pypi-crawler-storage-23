from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import psycopg
from psycopg import Connection as PsycopgConnection

from .base import BaseConnector
from .connector_factory import register_connector
from ..exceptions import (
    ExternalServiceAuthException,
    ExternalServiceException,
    QueryExecutionException,
)
from ..query_validator import QueryValidator
from ..schemas import (
    AuthStrategy,
    ColumnMetadata,
    CredentialDetails,
    DataSourceMetadata,
    DocumentationLink,
    FieldDefinition,
    TableMetadata,
)
from ..constants import ConnectorType

logger = logging.getLogger(__name__)


class _PostgreSQLConnection:
    """Internal PostgreSQL connection handler (synchronous operations)."""

    def __init__(self, connection_data: dict[str, Any]) -> None:
        """Initialize the connection handler with connection configuration.

        Args:
            connection_data: Dictionary containing connection parameters.
                Required: 'host', 'port', 'dbname', 'user', 'password'
        """
        self.connection_data = connection_data.copy()
        self.connection: PsycopgConnection | None = None
        self.is_connected: bool = False

    def connect(self) -> PsycopgConnection:
        """Establish a connection to PostgreSQL.

        Returns:
            The PostgreSQL connection object.

        Raises:
            psycopg.errors.Error: If connection fails.
        """
        if self.is_connected and self.connection is not None:
            return self.connection

        self.connection = psycopg.connect(
            host=self.connection_data["host"],
            port=self.connection_data["port"],
            dbname=self.connection_data["dbname"],
            user=self.connection_data["user"],
            password=self.connection_data["password"],
        )
        self.is_connected = True
        return self.connection

    def disconnect(self) -> None:
        """Close the connection to PostgreSQL."""
        if not self.is_connected or self.connection is None:
            return

        self.connection.close()
        self.connection = None
        self.is_connected = False

    def check_connection(self) -> bool:
        """Check if the connection is valid by executing a simple query.

        Returns:
            True if connection is valid, False otherwise.
        """
        try:
            connection = self.connect()
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
            return True
        except psycopg.errors.OperationalError:
            self.is_connected = False
            self.connection = None
            return False

    def execute_query(
        self,
        query: str,
        params: dict[str, Any] | tuple[Any, ...] | None = None,
        retry_count: int = 0,
        retry_delay: float = 1.0,
    ) -> list[tuple[Any, ...]]:
        """Execute a SQL query with optional retry logic.

        Args:
            query: The SQL query to execute
            params: Optional parameters to bind to the query
            retry_count: Number of retry attempts on failure (default: 0)
            retry_delay: Delay in seconds between retries (default: 1.0)

        Returns:
            List of result rows as tuples

        Raises:
            Exception: If the query fails after all retry attempts
        """
        last_error: Exception | None = None
        attempts = retry_count + 1  # Total attempts = initial + retries

        for attempt in range(attempts):
            try:
                connection = self.connect()
                with connection.cursor() as cursor:
                    if params is not None:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)

                    connection.commit()

                    if cursor.description:
                        return cursor.fetchall()
                    else:
                        return []
            except Exception as e:
                last_error = e
                # Don't retry on the last attempt
                if attempt < attempts - 1:
                    time.sleep(retry_delay)
                    # Reset connection state for retry
                    self.is_connected = False
                    self.connection = None

        # All attempts failed, raise the last error
        raise last_error  # type: ignore[misc]


@register_connector("postgresql")
class PostgreSQLConnector(BaseConnector):
    """PostgreSQL connector with async interface and metadata support."""

    connector_type: ConnectorType = ConnectorType.DATABASE
    name: str = "PostgreSQL"
    description: str = "PostgreSQL database connector supporting standard SQL queries."
    version: str = "0.1.0"
    logo_url: str | None = None

    instructions_prompt: str = """You are querying a PostgreSQL database. Key points:
- Use standard SQL syntax (PostgreSQL supports full ANSI SQL)
- PostgreSQL is case-sensitive for quoted identifiers, case-insensitive otherwise
- Use double quotes for identifiers: "TableName", "columnName"
- Use single quotes for string literals: 'text value'
- Common functions: NOW(), CURRENT_USER, CURRENT_DATABASE()
- Window functions are fully supported
- Use LIMIT and OFFSET for pagination
- Date/time functions: DATE_TRUNC(), AGE(), EXTRACT()
- String functions: CONCAT(), SUBSTRING(), LOWER(), UPPER()
- Aggregate functions: COUNT(), SUM(), AVG(), MIN(), MAX()
- Use %s for positional parameters in queries
- Use %(param_name)s for named parameters
- PostgreSQL supports JSON/JSONB data types with operators: ->, ->>, #>, #>>
- Use RETURNING clause with INSERT/UPDATE/DELETE to get affected rows
- Always specify schema if not using 'public' schema
- Use pg_catalog and information_schema for metadata queries"""

    credential_details: CredentialDetails = CredentialDetails(
        auth_strategies=[
            AuthStrategy(
                type="basic",
                label="Username and Password",
                description="Authenticate using username and password",
                fields=[
                    FieldDefinition(
                        name="password",
                        label="Password",
                        type="password",
                        required=True,
                        is_sensitive=True,
                        description="Your PostgreSQL password",
                    ),
                ],
            ),
        ],
        common_fields=[
            FieldDefinition(
                name="host",
                label="Host",
                type="text",
                required=True,
                is_sensitive=False,
                description="PostgreSQL server hostname or IP address",
                placeholder="localhost",
            ),
            FieldDefinition(
                name="port",
                label="Port",
                type="text",
                required=True,
                is_sensitive=False,
                description="PostgreSQL server port",
                placeholder="5432",
            ),
            FieldDefinition(
                name="dbname",
                label="Database Name",
                type="text",
                required=True,
                is_sensitive=False,
                description="Name of the database to connect to",
            ),
            FieldDefinition(
                name="user",
                label="Username",
                type="text",
                required=True,
                is_sensitive=False,
                description="Your PostgreSQL username",
            ),
        ],
        documentation_links=[
            DocumentationLink(
                label="PostgreSQL Documentation",
                url="https://www.postgresql.org/docs/",
            ),
            DocumentationLink(
                label="Psycopg Documentation",
                url="https://www.psycopg.org/psycopg3/docs/",
            ),
        ],
    )

    def __init__(self):
        super().__init__()
        self._connection_impl: _PostgreSQLConnection | None = None

    async def connect(self, credentials: dict[str, Any]) -> None:
        """Establish an async connection to PostgreSQL.

        Args:
            credentials: Dictionary containing connection credentials

        Raises:
            ExternalServiceAuthException: If authentication fails
            ExternalServiceException: If connection fails for other reasons
        """
        try:
            if self._connection_impl and self._connection_impl.is_connected:
                await asyncio.to_thread(self._connection_impl.disconnect)
            self._connection_impl = await asyncio.to_thread(
                _PostgreSQLConnection, credentials
            )
            await asyncio.to_thread(self._connection_impl.connect)
            self.connection = self._connection_impl
        except psycopg.errors.OperationalError as e:
            logger.exception("PostgreSQL connection failed")
            raise ExternalServiceException("PostgreSQL", operation="connecting") from e
        except psycopg.errors.DatabaseError as e:
            logger.exception("PostgreSQL authentication failed")
            raise ExternalServiceAuthException("PostgreSQL") from e
        except Exception as e:
            logger.exception("Unexpected error connecting to PostgreSQL")
            raise ExternalServiceException("PostgreSQL", operation="connecting") from e

    async def execute_query(self, query: dict[str, Any]) -> Any:
        """Execute a SQL query asynchronously.

        Args:
            query: Dictionary containing 'sql' or 'query' key with SQL string,
                   and optional 'params' key with query parameters

        Returns:
            List of result rows as tuples

        Raises:
            QueryExecutionException: If not connected or query fails
            ExternalServiceException: If connection error occurs during query
        """
        if not self.connection or not isinstance(
            self.connection, _PostgreSQLConnection
        ):
            raise QueryExecutionException("Not connected to PostgreSQL")

        sql = QueryValidator.extract_sql(query)

        if not sql:
            raise QueryExecutionException(
                f"Query must contain one of: {', '.join(QueryValidator.SQL_KEYS)}"
            )

        params = query.get("params")

        try:
            results = await asyncio.to_thread(
                self.connection.execute_query, sql, params
            )
            return {"success": True, "data": results}
        except psycopg.errors.Error as e:
            logger.exception("PostgreSQL query execution failed")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e
        except Exception as e:
            logger.exception("Unexpected error executing PostgreSQL query")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e

    async def test_connection(self, credentials: dict[str, Any]) -> bool:
        """Test if connection credentials are valid.

        Args:
            credentials: Dictionary containing connection credentials

        Returns:
            True if connection succeeds, False otherwise
        """
        try:
            connection_impl = await asyncio.to_thread(
                _PostgreSQLConnection, credentials
            )
            result = await asyncio.to_thread(connection_impl.check_connection)
            await asyncio.to_thread(connection_impl.disconnect)
            return result
        except Exception:
            return False

    async def get_metadata(self) -> DataSourceMetadata:
        """Retrieve database metadata including tables, columns, and constraints.

        Returns:
            DataSourceMetadata containing table and column information

        Raises:
            QueryExecutionException: If not connected or metadata retrieval fails
            ExternalServiceException: If connection error occurs
        """
        if not self.connection or not isinstance(
            self.connection, _PostgreSQLConnection
        ):
            raise QueryExecutionException("Not connected to PostgreSQL")

        try:
            # Get all tables and views (excluding system schemas)
            tables_query = """
                SELECT 
                    table_schema,
                    table_name,
                    table_type
                FROM information_schema.tables
                WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
                ORDER BY table_schema, table_name
            """

            tables_result = await asyncio.to_thread(
                self.connection.execute_query, tables_query
            )

            tables_map: dict[str, TableMetadata] = {}

            for row in tables_result:
                if len(row) < 3:
                    continue
                table_schema, table_name, table_type = row[0], row[1], row[2]
                if not all([table_schema, table_name]):
                    continue
                full_name = f"{table_schema}.{table_name}"
                tables_map[full_name] = TableMetadata(
                    name=full_name,
                    display_name=str(table_name),
                    is_view=table_type == "VIEW",
                    columns=[],
                    primary_key=None,
                    foreign_keys=[],
                )

            if not tables_map:
                return DataSourceMetadata(tables=[])

            # Get columns for all tables
            columns_query = """
                SELECT 
                    table_schema,
                    table_name,
                    column_name,
                    data_type,
                    is_nullable,
                    column_default,
                    character_maximum_length,
                    numeric_precision,
                    numeric_scale
                FROM information_schema.columns
                WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
                ORDER BY table_schema, table_name, ordinal_position
            """

            columns_result = await asyncio.to_thread(
                self.connection.execute_query, columns_query
            )

            for row in columns_result:
                if len(row) < 9:
                    continue
                table_schema, table_name = row[0], row[1]
                full_name = f"{table_schema}.{table_name}"
                if full_name in tables_map:
                    col_name = row[2]
                    data_type = row[3]
                    is_nullable = row[4] == "YES" if row[4] else True
                    default_value = row[5]

                    canonical_type = self._map_postgresql_type(
                        str(data_type) if data_type else "text"
                    )

                    tables_map[full_name].columns.append(
                        ColumnMetadata(
                            name=col_name,
                            data_type=canonical_type,
                            nullable=is_nullable,
                            default_value=str(default_value) if default_value else None,
                            description=None,
                        )
                    )

            # Get primary keys
            pk_query = """
                SELECT 
                    tc.table_schema,
                    tc.table_name,
                    kcu.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                    ON tc.constraint_name = kcu.constraint_name
                    AND tc.table_schema = kcu.table_schema
                WHERE tc.constraint_type = 'PRIMARY KEY'
                    AND tc.table_schema NOT IN ('pg_catalog', 'information_schema')
                ORDER BY tc.table_schema, tc.table_name, kcu.ordinal_position
            """

            pk_result = await asyncio.to_thread(self.connection.execute_query, pk_query)

            # Group primary key columns by table
            pk_map: dict[str, list[str]] = {}
            for row in pk_result:
                if len(row) < 3:
                    continue
                table_schema, table_name, column_name = row[0], row[1], row[2]
                full_name = f"{table_schema}.{table_name}"
                if full_name not in pk_map:
                    pk_map[full_name] = []
                pk_map[full_name].append(str(column_name))

            # Assign primary keys to tables
            for full_name, pk_columns in pk_map.items():
                if full_name in tables_map:
                    tables_map[full_name].primary_key = pk_columns

            return DataSourceMetadata(tables=list(tables_map.values()))

        except psycopg.errors.Error as e:
            logger.exception("PostgreSQL metadata query failed")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e
        except Exception as e:
            logger.exception("Unexpected error retrieving PostgreSQL metadata")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e

    @staticmethod
    def _map_postgresql_type(pg_type: str) -> str:
        """Map PostgreSQL data types to canonical types.

        Args:
            pg_type: PostgreSQL data type name

        Returns:
            Canonical type name (string, number, datetime, date, time, boolean, binary, json, array)
        """
        type_mapping = [
            ("timestamp with time zone", "datetime"),
            ("timestamp without time zone", "datetime"),
            ("timestamptz", "datetime"),
            ("timestamp", "datetime"),
            ("double precision", "number"),
            ("integer", "number"),
            ("bigint", "number"),
            ("smallint", "number"),
            ("decimal", "number"),
            ("numeric", "number"),
            ("real", "number"),
            ("serial", "number"),
            ("bigserial", "number"),
            ("smallserial", "number"),
            ("money", "number"),
            ("character varying", "string"),
            ("varchar", "string"),
            ("character", "string"),
            ("char", "string"),
            ("text", "string"),
            ("date", "date"),
            ("time with time zone", "time"),
            ("time without time zone", "time"),
            ("timetz", "time"),
            ("time", "time"),
            ("boolean", "boolean"),
            ("bool", "boolean"),
            ("bytea", "binary"),
            ("jsonb", "json"),
            ("json", "json"),
            ("array", "array"),
            ("uuid", "string"),
        ]
        pg_type_lower = pg_type.lower()
        for pg_t, canonical in type_mapping:
            if pg_type_lower.startswith(pg_t):
                return canonical
        return "string"
