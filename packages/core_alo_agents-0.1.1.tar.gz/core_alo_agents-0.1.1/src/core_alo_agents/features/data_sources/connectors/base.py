from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any, ClassVar

from google.auth.transport.requests import Request
from google.oauth2 import service_account
from google.oauth2.credentials import Credentials

from ..schemas import CredentialDetails, DataSourceMetadata
from ..constants import ConnectorType


class BaseConnector(ABC):
    """Base contract for all connectors.

    Each connector must expose:
    - instructions_prompt: Connector-specific guidance to help the agent craft queries/code
    - credential_details: Declares supported authentication strategies and form fields
    - connect: Establishes and stores a live connection on the connector instance
    - execute_query: Perform a connector-specific query (should use self.connection or self.connect if needed)
    - test_connection: Validate that provided credentials work
    - get_metadata: Return source schema so the agent can plan queries
    """

    connector_key: ClassVar[str]
    connector_type: ClassVar[ConnectorType]
    name: ClassVar[str]
    description: ClassVar[str]
    version: ClassVar[str]
    logo_url: ClassVar[str | None]
    instructions_prompt: ClassVar[str]
    credential_details: ClassVar[CredentialDetails]

    # Holds the live connection object after `connect` is called.
    connection: Any | None = None

    @abstractmethod
    async def connect(self, credentials: dict[str, Any]) -> None:
        """Establish a live connection (e.g., DB client) and store it on `self.connection`.

        Implementations SHOULD set `self.connection` to the established client/object.
        """

    @abstractmethod
    async def execute_query(self, query: dict[str, Any]) -> Any:
        """Execute a connector-specific query for the given connection."""

    @abstractmethod
    async def test_connection(self, credentials: dict[str, Any]) -> bool:
        """Return True if the provided credentials are valid for this connector."""

    @abstractmethod
    async def get_metadata(self) -> DataSourceMetadata:
        """Return metadata describing the data source (tables/columns)."""

    def generate_auth_url(
        self,
        redirect_uri: str,
        state: str,
        credentials: dict[str, Any] | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Generate an OAuth authorization URL for this connector.

        Returns both the URL and any connector-specific state data required to
        finalize the OAuth flow (e.g., PKCE verifier, account info).
        """
        raise NotImplementedError(
            "This connector does not support OAuth initialization."
        )

    async def finalize_oauth(
        self,
        state_data: dict[str, Any],
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Exchange an authorization code for credentials.

        Connectors that support OAuth must override this to return a credential
        payload suitable for persisting a connection.
        """
        raise NotImplementedError(
            "This connector does not support OAuth callback handling."
        )


# TODO: to move shared logic from google_sheets, google_drive
class GoogleBaseConnector(BaseConnector):
    """Base class for Google API connectors (Drive, Sheets, etc.)."""
    pass


class GoogleConnectionBase:
    """Base class for Google API connection implementations.
    
    Provides common functionality for connecting to Google APIs using
    either OAuth2 or service account authentication.
    
    Subclasses should define:
    - SCOPES: List of required OAuth scopes
    - _BASE_PARAMS: Frozenset of base connection parameters
    - _AUTH_PARAMS: Dict mapping auth types to their parameter sets
    """
    
    # Subclasses must define these
    SCOPES: list[str] = []
    _BASE_PARAMS: frozenset[str] = frozenset({"auth_type"})
    _AUTH_PARAMS: dict[str, frozenset[str]] = {}
    
    def __init__(self, connection_data: dict[str, Any]) -> None:
        """Initialize connection with configuration data."""
        self.connection_data = connection_data.copy()
        self.credentials: Credentials | service_account.Credentials | None = None
        self.is_connected: bool = False
        self._config: dict[str, Any] | None = None
    
    def _resolve_auth_type(self) -> str:
        """Determine which auth mode to use based on provided data.
        
        Returns:
            The resolved auth type (e.g., 'oauth2', 'key-pair')
        """
        explicit = self.connection_data.get("auth_type")
        if isinstance(explicit, str) and explicit.strip():
            return explicit.strip()

        if "service_account_key" in self.connection_data:
            return "key-pair"

        # Default to OAuth if available, otherwise key-pair
        if "oauth2" in self._AUTH_PARAMS:
            return "oauth2"
        return "key-pair"
    
    def _build_config(self) -> dict[str, Any]:
        """Build and validate connection configuration.

        Filters connection_data to only include parameters that are:
        - In _BASE_PARAMS (always allowed)
        - In _AUTH_PARAMS[auth_type] (specific to the auth method)

        Returns:
            Filtered configuration dictionary with only valid parameters
        """
        auth_type = self._resolve_auth_type()
        allowed_params = set(self._BASE_PARAMS)
        auth_params = self._AUTH_PARAMS.get(auth_type)

        if auth_params is None:
            return {**self.connection_data, "auth_type": auth_type}

        allowed_params.update(auth_params)

        config = {
            key: value
            for key, value in self.connection_data.items()
            if key in allowed_params
        }

        # Always embed the resolved auth_type for downstream usage
        config["auth_type"] = auth_type

        return config
    
    def _build_oauth_credentials(self) -> Credentials:
        """Build OAuth2 credentials from filtered config.
        
        Returns:
            Google OAuth2 Credentials object
            
        Raises:
            ValueError: If OAuth configuration is invalid or missing
        """
        if not self._config:
            raise ValueError("Configuration not built. Call connect() first.")

        creds_data: dict[str, Any] = {
            "token": self._config.get("token"),
            "refresh_token": self._config.get("refresh_token"),
            "token_uri": self._config.get(
                "token_uri", "https://oauth2.googleapis.com/token"
            ),
            "client_id": self._config.get("client_id"),
            "client_secret": self._config.get("client_secret"),
        }

        token = creds_data.get("token")
        refresh_token = creds_data.get("refresh_token")
        if not token and not refresh_token:
            raise ValueError(
                "OAuth credentials are missing an access token or refresh token"
            )

        # Remove None values
        creds_data = {k: v for k, v in creds_data.items() if v is not None}

        credentials = Credentials(
            token=creds_data.get("token"),
            refresh_token=creds_data.get("refresh_token"),
            token_uri=creds_data.get("token_uri"),
            client_id=creds_data.get("client_id"),
            client_secret=creds_data.get("client_secret"),
            scopes=self.SCOPES,
        )

        return credentials
    
    def _build_service_account_credentials(self) -> service_account.Credentials:
        """Build service account credentials from filtered config.
        
        Returns:
            Google service account Credentials object
            
        Raises:
            ValueError: If service account configuration is invalid or missing
        """
        if not self._config:
            raise ValueError("Configuration not built. Call connect() first.")

        key_data = self._config.get("service_account_key")
        if not key_data:
            raise ValueError(
                "service_account_key is required for service account authentication"
            )

        # Parse JSON key if it's a string
        if isinstance(key_data, str):
            try:
                key_data = json.loads(key_data)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid service account key JSON: {e}")

        # Create credentials from service account info
        credentials = service_account.Credentials.from_service_account_info(
            key_data,
            scopes=self.SCOPES,
        )

        # Optionally impersonate a user (domain-wide delegation)
        subject = self._config.get("subject")
        if subject:
            credentials = credentials.with_subject(subject)

        return credentials
    
    def _build_credentials(self) -> Credentials | service_account.Credentials:
        """Build Google credentials from filtered config.
        
        Returns:
            OAuth2 or service account credentials based on auth_type
        """
        auth_type = self._resolve_auth_type()

        if auth_type == "key-pair":
            return self._build_service_account_credentials()
        return self._build_oauth_credentials()
    
    def _refresh_credentials_if_needed(self) -> None:
        """Refresh OAuth credentials if expired and refresh token is available."""
        if (
            isinstance(self.credentials, Credentials)
            and self.credentials.expired
            and self.credentials.refresh_token is not None
        ):
            self.credentials.refresh(Request())  # type: ignore[no-untyped-call]
