from __future__ import annotations

import asyncio
import base64
import csv
import hashlib
import io
import json
import logging
import secrets
from typing import Any, cast
from urllib.parse import urlencode

import httpx

from fastapi import HTTPException

from googleapiclient.discovery import build  # type: ignore[import-untyped]
from googleapiclient.errors import HttpError  # type: ignore[import-untyped]

from ....config import settings
from .base import BaseConnector, GoogleConnectionBase
from .connector_factory import register_connector
from ..exceptions import (
    ExternalServiceAuthException,
    ExternalServiceException,
    QueryExecutionException,
)
from ..schemas import (
    AuthStrategy,
    ColumnMetadata,
    CredentialDetails,
    DataSourceMetadata,
    DocumentationLink,
    FieldDefinition,
    OAuthConfig,
    TableMetadata,
)
from ..constants import ConnectorType

logger = logging.getLogger(__name__)


def _get_access_not_configured_service(exc: HttpError) -> str | None:
    status = getattr(getattr(exc, "resp", None), "status", None)
    if status != 403:
        return None

    content = getattr(exc, "content", None)
    content_text = (
        content.decode("utf-8", errors="ignore")
        if isinstance(content, (bytes, bytearray))
        else str(content or "")
    )
    combined_text = f"{exc} {content_text}"
    if not any(
        token in combined_text
        for token in (
            "accessNotConfigured",
            "ACCESS_NOT_CONFIGURED",
            "access_not_configured",
        )
    ):
        return None

    # Try to infer service from the JSON error payload.
    service: str | None = None
    try:
        payload = json.loads(content_text) if content_text else None
    except Exception:
        payload = None

    if isinstance(payload, dict):
        payload_dict = cast(dict[str, Any], payload)
        error = payload_dict.get("error")
        if isinstance(error, dict):
            error_dict = cast(dict[str, Any], error)
            details = error_dict.get("details")
            if isinstance(details, list):
                for item in cast(list[dict[str, Any]], details):
                    metadata = item.get("metadata")
                    if isinstance(metadata, dict):
                        metadata_dict = cast(dict[str, Any], metadata)
                        service = metadata_dict.get("service")
                        if isinstance(service, str) and service.strip():
                            return service.strip()
            message = str(error_dict.get("message") or "").lower()
            if "drive" in message:
                return "drive.googleapis.com"
            if "sheets" in message or "spreadsheets" in message:
                return "sheets.googleapis.com"

    lower_text = combined_text.lower()
    if "drive" in lower_text:
        return "drive.googleapis.com"
    if "sheets" in lower_text or "spreadsheets" in lower_text:
        return "sheets.googleapis.com"
    return None


def _access_not_configured_detail_for_service(service: str | None) -> str:
    if service == "drive.googleapis.com":
        return (
            "Google API access is not configured for this OAuth client/project. "
            "Enable the Google Drive API in the Google Cloud Console, then retry."
        )
    if service == "sheets.googleapis.com":
        return (
            "Google API access is not configured for this OAuth client/project. "
            "Enable the Google Sheets API in the Google Cloud Console, then retry."
        )
    return (
        "Google API access is not configured for this OAuth client/project. "
        "Enable the required Google APIs in the Google Cloud Console, then retry."
    )


class _GoogleSheetsConnection(GoogleConnectionBase):
    """Internal connection class for Google Sheets API."""

    # Required scopes for reading spreadsheets
    SCOPES = [
        "https://www.googleapis.com/auth/drive.readonly",
        "https://www.googleapis.com/auth/spreadsheets.readonly",
    ]

    _BASE_PARAMS: frozenset[str] = frozenset({"auth_type"})

    _AUTH_PARAMS: dict[str, frozenset[str]] = {
        "oauth2": frozenset(
            {
                "token",
                "refresh_token",
                "token_uri",
                "client_id",
                "client_secret",
                "expiry",
            }
        ),
        "key-pair": frozenset(
            {
                "service_account_key",
                "subject",
            }
        ),
    }

    def __init__(self, connection_data: dict[str, Any]) -> None:
        super().__init__(connection_data)
        self.drive_service: Any = None
        self.sheets_service: Any = None

    def connect(self) -> None:
        """Establish a connection to Google Drive and Sheets APIs."""
        if self.is_connected and self.credentials is not None:
            return

        # Build and validate configuration
        self._config = self._build_config()
        self.credentials = self._build_credentials()

        # Refresh credentials if expired and refresh token is available (OAuth only)
        self._refresh_credentials_if_needed()

        # Build service clients
        self.drive_service = build("drive", "v3", credentials=self.credentials)
        self.sheets_service = build("sheets", "v4", credentials=self.credentials)
        self.is_connected = True

    def disconnect(self) -> None:
        """Close the connection to Google APIs."""
        if not self.is_connected:
            return

        self.credentials = None
        self.drive_service = None
        self.sheets_service = None
        self.is_connected = False

    def check_connection(self) -> bool:
        """Check if the connection is valid by listing files."""
        try:
            self.connect()
            # Try to list 1 file to verify connection
            self.drive_service.files().list(pageSize=1).execute()
            return True
        except (HttpError, Exception):
            self.is_connected = False
            self.credentials = None
            return False

    def find_spreadsheet_by_name(self, filename: str) -> dict[str, str] | None:
        """Find a spreadsheet file by name in Google Drive."""
        self.connect()

        # Search for Google Sheets files with the given name
        query = (
            f"name = '{filename}' and "
            "mimeType = 'application/vnd.google-apps.spreadsheet' and "
            "trashed = false"
        )

        results = (
            self.drive_service.files()
            .list(
                q=query,
                pageSize=1,
                fields="files(id, name)",
            )
            .execute()
        )

        files = results.get("files", [])
        if files:
            return {"id": files[0]["id"], "name": files[0]["name"]}
        return None

    def get_spreadsheet_data(
        self,
        spreadsheet_id: str | None = None,
        spreadsheet_name: str | None = None,
        sheet_name: str | None = None,
        range_notation: str | None = None,
    ) -> list[list[Any]]:
        """Get spreadsheet data as a 2D list of values.

        Args:
            spreadsheet_id: The Google Sheets spreadsheet ID
            spreadsheet_name: Alternative to ID, find spreadsheet by name
            sheet_name: Optional name of a specific sheet to read
            range_notation: Optional A1 notation range to read (e.g., 'A1:D10')

        Returns:
            2D list of cell values

        Raises:
            ValueError: If spreadsheet is not found or parameters are invalid
            HttpError: If the API request fails
        """
        self.connect()

        # Resolve spreadsheet ID
        if not spreadsheet_id and spreadsheet_name:
            file_info = self.find_spreadsheet_by_name(spreadsheet_name)
            if not file_info:
                raise ValueError(
                    f"Spreadsheet '{spreadsheet_name}' not found in Google Drive"
                )
            spreadsheet_id = file_info["id"]
        elif not spreadsheet_id:
            raise ValueError(
                "Either spreadsheet_id or spreadsheet_name must be provided"
            )

        # Build the range string
        if sheet_name and range_notation:
            range_str = f"'{sheet_name}'!{range_notation}"
        elif sheet_name:
            range_str = f"'{sheet_name}'"
        elif range_notation:
            range_str = range_notation
        else:
            # Get all data from the first sheet
            range_str = None

        # Get spreadsheet values
        if range_str:
            result = (
                self.sheets_service.spreadsheets()
                .values()
                .get(spreadsheetId=spreadsheet_id, range=range_str)
                .execute()
            )
        else:
            # Get spreadsheet metadata to find first sheet name
            spreadsheet = (
                self.sheets_service.spreadsheets()
                .get(spreadsheetId=spreadsheet_id)
                .execute()
            )
            first_sheet = spreadsheet["sheets"][0]["properties"]["title"]
            result = (
                self.sheets_service.spreadsheets()
                .values()
                .get(spreadsheetId=spreadsheet_id, range=f"'{first_sheet}'")
                .execute()
            )

        return result.get("values", [])

    def list_spreadsheets(self, max_results: int = 100) -> list[dict[str, str]]:
        """List spreadsheet files in Google Drive."""
        self.connect()

        query = (
            "mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false"
        )

        results = (
            self.drive_service.files()
            .list(
                q=query,
                pageSize=max_results,
                fields="files(id, name)",
                orderBy="modifiedTime desc",
            )
            .execute()
        )

        files = results.get("files", [])
        return [{"id": f["id"], "name": f["name"]} for f in files]

    def get_spreadsheet_metadata(self, spreadsheet_id: str) -> dict[str, Any]:
        """Get metadata about a spreadsheet including all sheets."""
        self.connect()

        spreadsheet = (
            self.sheets_service.spreadsheets()
            .get(spreadsheetId=spreadsheet_id)
            .execute()
        )

        return spreadsheet


@register_connector("google_sheets")
class GoogleSheetsConnector(BaseConnector):
    connector_type: ConnectorType = ConnectorType.FILE
    name: str = "Google Sheets"
    description: str = "Google Sheets connector for reading spreadsheet data."
    version: str = "0.1.0"
    logo_url: str | None = None
    instructions_prompt: str = """You are querying Google Sheets spreadsheets. Key points:
- Each spreadsheet contains one or more sheets (tabs)
- Each sheet is treated as a separate table
- Use spreadsheet_id or spreadsheet_name to identify the spreadsheet
- Use sheet_name to specify which sheet to read (defaults to first sheet)
- Use range notation (A1:D10) to read specific cell ranges
- Data is returned as CSV format
- Column names are typically in the first row
- All data is read-only
- Query format: {"spreadsheet_id": "...", "sheet_name": "...", "range": "A1:D10"}
- Or: {"spreadsheet_name": "...", "sheet_name": "..."}
- Spreadsheet names must match exactly (case-sensitive)
- Sheet names must match exactly (case-sensitive)"""

    credential_details: CredentialDetails = CredentialDetails(
        auth_strategies=[
            AuthStrategy(
                type="oauth2",
                label="OAuth 2.0",
                description="Authenticate using OAuth 2.0. You will be redirected to Google to log in.",
                oauth_config=OAuthConfig(
                    authorization_url="https://accounts.google.com/o/oauth2/v2/auth",
                    token_url="https://oauth2.googleapis.com/token",
                    scopes=[
                        "https://www.googleapis.com/auth/drive.readonly",
                        "https://www.googleapis.com/auth/spreadsheets.readonly",
                    ],
                ),
                # OAuth tokens are obtained through the OAuth flow; no manual inputs needed.
                fields=[],
            ),
            AuthStrategy(
                type="key-pair",
                label="Service Account",
                description="Authenticate using a Google service account JSON key",
                fields=[
                    FieldDefinition(
                        name="service_account_key",
                        label="Service Account Key (JSON)",
                        type="text",
                        required=True,
                        is_sensitive=True,
                        description="Service account JSON key as string (entire JSON object)",
                    ),
                    FieldDefinition(
                        name="subject",
                        label="Subject (Optional)",
                        type="text",
                        required=False,
                        is_sensitive=False,
                        description="User email to impersonate (for domain-wide delegation)",
                    ),
                ],
            ),
        ],
        common_fields=[],
        documentation_links=[
            DocumentationLink(
                label="Google Sheets API Documentation",
                url="https://developers.google.com/sheets/api",
            ),
            DocumentationLink(
                label="Google Drive API Documentation",
                url="https://developers.google.com/drive/api",
            ),
            DocumentationLink(
                label="OAuth 2.0 Setup Guide",
                url="https://developers.google.com/identity/protocols/oauth2",
            ),
        ],
    )

    def __init__(self):
        super().__init__()
        self._connection_impl: _GoogleSheetsConnection | None = None

    def generate_auth_url(
        self,
        redirect_uri: str,
        state: str,
        credentials: dict[str, Any] | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Generate Google OAuth authorization URL using PKCE (no client secret required)."""

        oauth_strategy = next(
            (s for s in self.credential_details.auth_strategies if s.type == "oauth2"),
            None,
        )
        if not oauth_strategy or not oauth_strategy.oauth_config:
            raise ValueError("OAuth strategy not configured for this connector")

        # Client ID/secret are configuration values defined in project settings
        client_id = settings.GOOGLE_CLIENT_ID
        client_id = str(client_id).strip() if client_id is not None else ""
        client_secret = settings.GOOGLE_CLIENT_SECRET or None
        client_secret = (
            str(client_secret).strip() if client_secret is not None else None
        )

        if not client_id:
            raise ValueError(
                "Google Sheets OAuth not configured. Server admin must set GOOGLE_CLIENT_ID in project settings."
            )

        config = oauth_strategy.oauth_config
        base_url = str(config.authorization_url)

        code_verifier = secrets.token_urlsafe(64)
        code_challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest())
            .decode()
            .rstrip("=")
        )

        scopes: list[str] = []
        if config.scopes:
            scopes.extend(config.scopes)

        params = {
            "client_id": client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "access_type": "offline",
            "prompt": "consent",
        }

        if scopes:
            params["scope"] = " ".join(scopes)

        token_url = (
            str(config.token_url)
            if config.token_url
            else "https://oauth2.googleapis.com/token"
        )

        state_data = {
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier,
            "token_url": token_url,
        }

        return f"{base_url}?{urlencode(params)}", state_data

    async def finalize_oauth(
        self, state_data: dict[str, Any], payload: dict[str, Any]
    ) -> dict[str, Any]:
        code = payload.get("code")
        redirect_uri = payload.get("redirect_uri") or state_data.get("redirect_uri")

        # Client ID/secret come from project settings (never from user-supplied state_data)
        client_id = settings.GOOGLE_CLIENT_ID
        client_id = str(client_id).strip() if client_id is not None else ""
        client_secret = settings.GOOGLE_CLIENT_SECRET or None
        client_secret = (
            str(client_secret).strip() if client_secret is not None else None
        )
        token_url = state_data.get("token_url")
        code_verifier = state_data.get("code_verifier")

        if (
            not code
            or not redirect_uri
            or not token_url
            or not client_id
            or not code_verifier
        ):
            raise ValueError(
                "Missing authorization code or OAuth context for Google Sheets callback"
            )

        token_data: dict[str, str] = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": str(redirect_uri),
            "code_verifier": code_verifier,
            "client_id": client_id,
        }

        if client_secret:
            token_data["client_secret"] = client_secret

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    token_url, data=token_data, headers=headers
                )
                response.raise_for_status()
                token_response = response.json()
        except httpx.HTTPStatusError as exc:  # type: ignore[catching-any]
            logger.exception("Google Sheets OAuth token exchange failed")
            detail = exc.response.text if exc.response else str(exc)
            raise ExternalServiceAuthException("Google Sheets", reason=detail) from exc
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected Google Sheets OAuth callback error")
            raise ExternalServiceAuthException("Google Sheets") from exc

        access_token = token_response.get("access_token")
        refresh_token = token_response.get("refresh_token")

        if not access_token:
            raise ExternalServiceAuthException("Google Sheets")

        credentials: dict[str, Any] = {
            "auth_type": "oauth2",
            "token": access_token,
            "refresh_token": refresh_token,
            "token_uri": token_url,
        }

        return credentials

    async def connect(self, credentials: dict[str, Any]) -> None:
        """Establish a connection to Google Sheets API."""
        try:
            if self._connection_impl and self._connection_impl.is_connected:
                await asyncio.to_thread(self._connection_impl.disconnect)
            self._connection_impl = await asyncio.to_thread(
                _GoogleSheetsConnection, credentials
            )
            await asyncio.to_thread(self._connection_impl.connect)
            self.connection = self._connection_impl
        except HttpError as e:
            if e.resp.status == 401:
                logger.exception("Google Sheets authentication failed")
                raise ExternalServiceAuthException("Google Sheets") from e
            logger.exception("Google Sheets connection failed")
            raise ExternalServiceException(
                "Google Sheets", operation="connecting"
            ) from e
        except ValueError as e:
            logger.exception("Google Sheets connection configuration error")
            raise ExternalServiceAuthException("Google Sheets", reason=str(e)) from e
        except Exception as e:
            logger.exception("Unexpected error connecting to Google Sheets")
            raise ExternalServiceException(
                "Google Sheets", operation="connecting"
            ) from e

    async def execute_query(self, query: dict[str, Any]) -> Any:
        """Execute a query to read spreadsheet data.

        Query format:
        {
            "spreadsheet_id": "..." (optional, use spreadsheet_name instead),
            "spreadsheet_name": "..." (optional, use spreadsheet_id instead),
            "sheet_name": "..." (optional, defaults to first sheet),
            "range": "A1:D10" (optional, defaults to all data)
        }

        Returns CSV-formatted string of the data.
        """
        if not self.connection or not isinstance(
            self.connection, _GoogleSheetsConnection
        ):
            raise QueryExecutionException("Not connected to Google Sheets")

        spreadsheet_id = query.get("spreadsheet_id")
        spreadsheet_name = query.get("spreadsheet_name")
        sheet_name = query.get("sheet_name")
        range_notation = query.get("range")

        if not spreadsheet_id and not spreadsheet_name:
            raise QueryExecutionException(
                "Query must contain either 'spreadsheet_id' or 'spreadsheet_name'"
            )

        try:
            values = await asyncio.to_thread(
                self.connection.get_spreadsheet_data,
                spreadsheet_id=spreadsheet_id,
                spreadsheet_name=spreadsheet_name,
                sheet_name=sheet_name,
                range_notation=range_notation,
            )

            # Convert to CSV
            if not values:
                return ""

            output = io.StringIO()
            writer = csv.writer(output, quoting=csv.QUOTE_MINIMAL)

            # Normalize rows to have the same number of columns
            max_cols = max(len(row) for row in values) if values else 0
            for row in values:
                # Pad row with empty strings if needed
                normalized_row = row + [""] * (max_cols - len(row))
                writer.writerow(normalized_row)

            return {"success": True, "data": output.getvalue()}
        except ValueError as e:
            logger.exception("Google Sheets query validation failed")
            raise QueryExecutionException(f"Query validation failed: {str(e)}") from e
        except HttpError as e:
            service = _get_access_not_configured_service(e)
            if service is not None:
                raise HTTPException(
                    status_code=502,
                    detail=_access_not_configured_detail_for_service(service),
                ) from e
            if e.resp.status == 404:
                logger.exception("Google Sheets spreadsheet not found")
                raise QueryExecutionException(f"Spreadsheet not found: {str(e)}") from e
            logger.exception("Google Sheets query execution failed")
            raise ExternalServiceException(
                "Google Sheets", operation="executing query"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error executing Google Sheets query")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e

    async def test_connection(self, credentials: dict[str, Any]) -> bool:
        """Test if the provided credentials are valid."""
        auth_type = credentials.get("auth_type", "oauth2")

        if auth_type == "key-pair":
            # For service accounts, just try to connect and list 1 file
            try:
                conn = _GoogleSheetsConnection(credentials)
                conn.connect()
                valid = conn.check_connection()
                conn.disconnect()
                if not valid:
                    raise ExternalServiceAuthException(
                        "Google Sheets",
                        reason="Service account credentials are invalid.",
                    )
                return True
            except Exception as e:
                raise ExternalServiceAuthException(
                    "Google Sheets", reason=str(e)
                ) from e

        # OAuth2 default
        try:
            # IMPORTANT: Creating/saving a connection should not require the Drive API
            # to be enabled. Users can OAuth successfully and only use spreadsheet_id
            # based reads (Sheets API) later.
            token = credentials.get("token")
            if not isinstance(token, str) or not token.strip():
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason="Missing OAuth access token. Reconnect with OAuth.",
                )

            # Validate token + scopes via Google OAuth token introspection.
            # This does not depend on Drive/Sheets APIs being enabled.
            tokeninfo_url = "https://oauth2.googleapis.com/tokeninfo"
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    tokeninfo_url, params={"access_token": token}
                )

            if response.status_code != 200:
                try:
                    payload = response.json()
                except Exception:
                    payload = None

                reason: str | None = None
                if isinstance(payload, dict):
                    payload_dict = cast(dict[str, Any], payload)
                    reason_value = payload_dict.get(
                        "error_description"
                    ) or payload_dict.get("error")
                    reason = str(reason_value) if reason_value else None
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason=str(reason or "OAuth token is invalid or expired"),
                )

            info = response.json()
            if not isinstance(info, dict):
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason="Unable to validate OAuth token.",
                )

            # Optional: ensure token was issued for this client.
            expected_aud = str(settings.GOOGLE_CLIENT_ID or "").strip()
            info_dict = cast(dict[str, Any], info)
            aud = info_dict.get("aud")
            if (
                expected_aud
                and isinstance(aud, str)
                and aud.strip()
                and aud.strip() != expected_aud
            ):
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason="OAuth token was not issued for this application. Reconnect with the correct Google client.",
                )

            scope_str = info_dict.get("scope")
            token_scopes: set[str] = set()
            if isinstance(scope_str, str) and scope_str.strip():
                token_scopes = {s for s in scope_str.split() if s}

            required_scopes = set(_GoogleSheetsConnection.SCOPES)
            missing = sorted(required_scopes - token_scopes)
            if missing:
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason=f"Missing required OAuth scopes: {', '.join(missing)}",
                )

            return True
        except ValueError as e:
            logger.exception("Google Sheets connection configuration error during test")
            raise ExternalServiceAuthException("Google Sheets", reason=str(e)) from e

    async def get_metadata(self) -> DataSourceMetadata:
        """Get metadata about available spreadsheets and sheets.

        Each spreadsheet is treated as a database, and each sheet within
        a spreadsheet is treated as a table. For simplicity, we'll list
        all spreadsheets and their first sheet, or we can list all sheets
        from a specific spreadsheet if one is connected.
        """
        if not self.connection or not isinstance(
            self.connection, _GoogleSheetsConnection
        ):
            raise QueryExecutionException("Not connected to Google Sheets")

        try:
            # List all spreadsheets
            spreadsheets = await asyncio.to_thread(
                self.connection.list_spreadsheets, max_results=100
            )

            tables: list[TableMetadata] = []

            # For each spreadsheet, get its sheets
            for spreadsheet in spreadsheets:
                spreadsheet_id = spreadsheet["id"]
                spreadsheet_name = spreadsheet["name"]

                try:
                    metadata = await asyncio.to_thread(
                        self.connection.get_spreadsheet_metadata, spreadsheet_id
                    )

                    sheets = metadata.get("sheets", [])
                    for sheet in sheets:
                        sheet_props = sheet.get("properties", {})
                        sheet_title = sheet_props.get("title", "Sheet1")

                        # Get a sample of data to infer column names and types
                        # Read first row for column names, limit to first 100 rows for type inference
                        try:
                            sample_data = await asyncio.to_thread(
                                self.connection.get_spreadsheet_data,
                                spreadsheet_id=spreadsheet_id,
                                sheet_name=sheet_title,
                                range_notation="A1:Z100",  # Sample first 100 rows, up to column Z
                            )
                        except Exception:
                            # If we can't read data, still include the sheet with empty columns
                            sample_data = []

                        columns: list[ColumnMetadata] = []

                        if sample_data:
                            # First row is typically headers
                            headers = sample_data[0] if sample_data else []
                            data_rows = sample_data[1:] if len(sample_data) > 1 else []

                            # Infer column types from data
                            for col_idx, header in enumerate(headers):
                                header_str = (
                                    str(header) if header else f"Column{col_idx + 1}"
                                )

                                # Try to infer type from sample data
                                data_type = "string"  # Default
                                if data_rows:
                                    sample_values = [
                                        row[col_idx] if col_idx < len(row) else None
                                        for row in data_rows
                                    ]
                                    sample_values = [
                                        v
                                        for v in sample_values
                                        if v is not None and str(v).strip()
                                    ]

                                    if sample_values:
                                        # Simple type inference
                                        first_val = str(sample_values[0])
                                        if (
                                            first_val.replace(".", "", 1)
                                            .replace("-", "", 1)
                                            .isdigit()
                                        ):
                                            data_type = "number"
                                        elif first_val.lower() in ("true", "false"):
                                            data_type = "boolean"

                                columns.append(
                                    ColumnMetadata(
                                        name=header_str,
                                        data_type=data_type,
                                        nullable=True,
                                        default_value=None,
                                        description=None,
                                    )
                                )

                        # Create table name as "SpreadsheetName.SheetName"
                        table_name = f"{spreadsheet_name}.{sheet_title}"

                        tables.append(
                            TableMetadata(
                                name=table_name,
                                display_name=f"{spreadsheet_name} - {sheet_title}",
                                is_view=False,
                                columns=columns,
                                primary_key=None,
                                foreign_keys=[],
                            )
                        )
                except HttpError as e:
                    # If APIs are not enabled or auth is invalid, fail loudly.
                    service = _get_access_not_configured_service(e)
                    if service is not None:
                        raise HTTPException(
                            status_code=502,
                            detail=_access_not_configured_detail_for_service(service),
                        ) from e
                    if getattr(getattr(e, "resp", None), "status", None) == 401:
                        raise ExternalServiceAuthException(
                            "Google Sheets",
                            reason="OAuth token is invalid or expired",
                        ) from e

                    # Otherwise, log but continue with other spreadsheets.
                    logger.warning(
                        "Failed to get metadata for spreadsheet %s (%s): %s",
                        spreadsheet_name,
                        spreadsheet_id,
                        str(e),
                    )
                    continue
                except Exception as e:
                    # Log but continue with other spreadsheets
                    logger.warning(
                        "Failed to get metadata for spreadsheet %s (%s): %s",
                        spreadsheet_name,
                        spreadsheet_id,
                        str(e),
                    )
                    continue

            return DataSourceMetadata(tables=tables)

        except HttpError as e:
            service = _get_access_not_configured_service(e)
            if service is not None:
                raise HTTPException(
                    status_code=502,
                    detail=_access_not_configured_detail_for_service(service),
                ) from e
            if getattr(getattr(e, "resp", None), "status", None) == 401:
                raise ExternalServiceAuthException(
                    "Google Sheets",
                    reason="OAuth token is invalid or expired",
                ) from e
            logger.exception("Google Sheets metadata retrieval failed")
            raise ExternalServiceException(
                "Google Sheets", operation="retrieving metadata"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error retrieving Google Sheets metadata")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e
