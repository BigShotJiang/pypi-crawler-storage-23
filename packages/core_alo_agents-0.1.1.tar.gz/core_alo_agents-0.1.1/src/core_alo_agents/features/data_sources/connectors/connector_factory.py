"""Connector Factory for managing and instantiating data source connectors.

This module provides a centralized factory for all connector implementations.
Connectors can be registered using the @register_connector decorator.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Type

from ..exceptions import ConnectorNotFoundException

if TYPE_CHECKING:
    from .base import BaseConnector


# Global registry for connectors
_CONNECTORS: dict[str, Type["BaseConnector"]] = {}


def register_connector(connector_type: str):
    """Decorator to register a connector implementation.

    Usage:
        @register_connector("postgres")
        class PostgresConnector(BaseConnector):
            ...

    Args:
        connector_type: Unique identifier for the connector
    """

    def decorator(cls: Type["BaseConnector"]) -> Type["BaseConnector"]:
        if connector_type in _CONNECTORS:
            raise ValueError(f"Connector type '{connector_type}' is already registered")
        if not getattr(cls, "connector_key", None):
            setattr(cls, "connector_key", connector_type)
        _CONNECTORS[connector_type] = cls
        return cls

    return decorator


class ConnectorFactory:
    """Factory for instantiating connector instances."""

    @staticmethod
    def get_connector_class(connector_type: str) -> Type["BaseConnector"]:
        """Return the registered connector class without instantiating it."""
        if connector_type not in _CONNECTORS:
            available = ", ".join(_CONNECTORS.keys()) if _CONNECTORS else "none"
            raise ConnectorNotFoundException(
                f"Connector type '{connector_type}' not found. "
                f"Available connectors: {available}"
            )

        return _CONNECTORS[connector_type]

    @staticmethod
    def create_connector(connector_type: str) -> "BaseConnector":
        """Create a new instance of the specified connector.

        Args:
            connector_type: The type of connector to instantiate

        Returns:
            A new instance of the connector

        Raises:
            ConnectorNotFoundException: If connector_type is not registered
        """
        if connector_type not in _CONNECTORS:
            available = ", ".join(_CONNECTORS.keys()) if _CONNECTORS else "none"
            raise ConnectorNotFoundException(
                f"Connector type '{connector_type}' not found. "
                f"Available connectors: {available}"
            )

        connector_class = _CONNECTORS[connector_type]
        return connector_class()

    @staticmethod
    def list_available_connectors() -> list[str]:
        """List all available connector types.

        Returns:
            List of registered connector type identifiers
        """
        return list(_CONNECTORS.keys())

    @staticmethod
    def is_registered(connector_type: str) -> bool:
        """Check if a connector type is registered.

        Args:
            connector_type: The connector type identifier

        Returns:
            True if registered, False otherwise
        """
        return connector_type in _CONNECTORS
