from typing import Optional, List, Literal, Any
from pydantic import BaseModel, Field, field_validator, AnyUrl


from core_alo.schemas import BaseSchema


class FieldDefinition(BaseModel):
    """Form field definition for connector credential collection."""

    name: str = Field(
        ...,
        pattern=r"^[a-z_][a-z0-9_]*$",
        description="Unique field identifier (snake_case)",
    )
    label: str
    type: Literal["text", "password", "number", "boolean", "select"]
    required: bool = False
    is_sensitive: bool = False
    description: Optional[str] = None
    placeholder: Optional[str] = None
    default_value: Optional[Any] = None
    options: Optional[List[dict[str, str]]] = None


class OAuthConfig(BaseModel):
    """OAuth specific configuration for auth strategies of type oauth2."""

    authorization_url: Optional[AnyUrl] = None
    token_url: Optional[AnyUrl] = None
    scopes: Optional[List[str]] = None

class AuthStrategy(BaseModel):
    type: Literal["basic", "oauth2", "sso", "token", "key-pair"]
    label: str
    description: Optional[str] = None
    fields: List[FieldDefinition] = Field(default_factory=list)
    oauth_config: Optional[OAuthConfig] = None


class ColumnMetadata(BaseModel):
    name: str
    data_type: str
    nullable: bool = True
    default_value: Optional[str] = None
    description: Optional[str] = None


class ForeignKeyMetadata(BaseModel):
    columns: Optional[List[str]] = None
    referenced_table: Optional[str] = None
    referenced_columns: Optional[List[str]] = None


class TableMetadata(BaseModel):
    name: str
    display_name: Optional[str] = None
    description: Optional[str] = None
    is_view: bool = False
    columns: List[ColumnMetadata]
    primary_key: Optional[List[str]] = None
    foreign_keys: List[ForeignKeyMetadata] = Field(default_factory=list)


# Does it accurately describe tha shape of the database? What about csv or excel files? We treat every Sheet as a Table?
class DataSourceMetadata(BaseModel):
    """Metadata describing tables/columns for a connection."""

    tables: List[TableMetadata]


class QueryExecutionRequest(BaseSchema):
    """Payload for executing a query against a connection."""

    query: dict[str, Any] = Field(
        ..., description="Query execution definition for the connector"
    )
    timeout_seconds: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Maximum seconds to wait before aborting execution",
    )

    @field_validator("query")
    @classmethod
    def _validate_query(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise TypeError("query must be an object")
        if not value:
            raise ValueError("query cannot be empty")
        return value


class MetadataRequest(BaseSchema):
    """Payload for metadata discovery requests."""

    timeout_seconds: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Maximum seconds to wait before aborting metadata discovery",
    )


class DocumentationLink(BaseModel):
    label: str
    url: AnyUrl


class CredentialDetails(BaseModel):
    """Schema defining authentication requirements for a connector."""

    auth_strategies: List[AuthStrategy]
    common_fields: List[FieldDefinition] = Field(default_factory=list)
    documentation_links: List[DocumentationLink] = Field(default_factory=list)



class DataSourceConnection(BaseModel):
    id: int
    name: str
    connector_key: str
    auth_type: str
    credentials: dict[str, Any]
    instructions_prompt: str = ""
    semantic_layer: Optional[dict[str, Any]] = None
