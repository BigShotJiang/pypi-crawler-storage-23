"""SQL Query Validator for enforcing read-only query restrictions.

This module provides validation to ensure that only safe, read-only queries
are executed. It rejects DDL (CREATE, DROP, ALTER) and DML (INSERT, UPDATE, DELETE)
statements to prevent data modification or schema changes.
"""

from __future__ import annotations

import re
from typing import Any

from .exceptions import QueryExecutionException


class QueryValidator:
    """Validator for SQL queries to enforce security policies."""

    # Common keys that might contain SQL
    SQL_KEYS = ["sql", "query", "code", "statement"]

    # SQL keywords that indicate write operations or schema changes
    FORBIDDEN_KEYWORDS = {
        # DDL - Data Definition Language
        "CREATE",
        "ALTER",
        "DROP",
        "TRUNCATE",
        "RENAME",
        # DML - Data Manipulation Language (writes)
        "INSERT",
        "UPDATE",
        "DELETE",
        "MERGE",
        "UPSERT",
        # DCL - Data Control Language
        "GRANT",
        "REVOKE",
        # Transaction control that could be dangerous
        "COMMIT",
        "ROLLBACK",
        "SAVEPOINT",
        # Other dangerous operations
        "EXEC",
        "EXECUTE",
        "CALL",
        "DO",
    }

    # Allowed read-only keywords
    ALLOWED_KEYWORDS = {
        "SELECT",
        "WITH",  # For CTEs (Common Table Expressions)
        "SHOW",  # For database metadata
        "DESCRIBE",
        "DESC",
        "EXPLAIN",
    }

    # INFORMATION_SCHEMA views that expose cross-database/account-level information
    # These should be blocked when database scoping is enforced
    RESTRICTED_INFO_SCHEMA_VIEWS = {
        "DATABASES",  # Shows all databases in the account
        "APPLICABLE_ROLES",  # Shows roles across account
        "ENABLED_ROLES",  # Shows enabled roles
        "REPLICATION_DATABASES",  # Shows replication info
    }

    # Regex pattern to detect three-part identifiers: DB.SCHEMA.TABLE
    # This catches cross-database access attempts like OTHER_DB.PUBLIC.USERS
    THREE_PART_IDENTIFIER_PATTERN = re.compile(
        r"""
        (?<![.\w])                           # Not preceded by dot or word char
        (                                     # Group 1: Database name
            (?:[A-Za-z_][A-Za-z0-9_$]*)|      # Unquoted identifier
            (?:"[^"]+")                        # Double-quoted identifier
        )
        \.                                    # First dot
        (                                     # Group 2: Schema name
            (?:[A-Za-z_][A-Za-z0-9_$]*)|
            (?:"[^"]+")
        )
        \.                                    # Second dot
        (                                     # Group 3: Table name
            (?:[A-Za-z_][A-Za-z0-9_$]*)|
            (?:"[^"]+")
        )
        (?![.\w])                            # Not followed by dot or word char
        """,
        re.VERBOSE | re.IGNORECASE,
    )

    # Regex pattern to extract table names from FROM and JOIN clauses
    # Matches: FROM table, FROM schema.table, JOIN table, etc.
    TABLE_REFERENCE_PATTERN = re.compile(
        r"""
        (?:FROM|JOIN)\s+                      # FROM or JOIN keyword
        (
            (?:[A-Za-z_][A-Za-z0-9_$]*        # First identifier (could be schema or table)
                (?:\.[A-Za-z_][A-Za-z0-9_$]*)*  # Optional .identifier parts
            )|
            (?:"[^"]+"                         # Double-quoted identifier
                (?:\."[^"]+")*                 # Optional ."identifier" parts
            )
        )
        """,
        re.VERBOSE | re.IGNORECASE,
    )

    @classmethod
    def validate_sql_query(cls, query: str) -> None:
        """Validate that a SQL query is read-only.

        Args:
            query: The SQL query string to validate

        Raises:
            QueryExecutionException: If the query contains forbidden operations
        """
        if not query or not query.strip():
            raise QueryExecutionException("Empty query provided")

        # Normalize query: remove comments and extra whitespace
        normalized_query = cls._normalize_query(query)

        # Extract the first significant keyword
        first_keyword = cls._get_first_keyword(normalized_query)

        if not first_keyword:
            raise QueryExecutionException("Unable to parse query")

        # Check if first keyword is allowed
        if first_keyword in cls.ALLOWED_KEYWORDS:
            # Additional check: ensure no forbidden keywords appear anywhere
            if cls._contains_forbidden_keywords(normalized_query):
                raise QueryExecutionException(
                    f"Query contains forbidden operations. Only read-only queries (SELECT, WITH, SHOW, DESCRIBE, EXPLAIN) are allowed."
                )
            return

        # If first keyword is forbidden
        if first_keyword in cls.FORBIDDEN_KEYWORDS:
            raise QueryExecutionException(
                f"Query type '{first_keyword}' is not allowed. Only read-only queries (SELECT, WITH, SHOW, DESCRIBE, EXPLAIN) are permitted."
            )

        # Unknown keyword - be conservative and reject
        raise QueryExecutionException(
            f"Query type '{first_keyword}' is not recognized as a safe read-only operation."
        )

    @classmethod
    def extract_sql(cls, query: dict[str, Any]) -> str | None:
        """Extract SQL string from query dict using valid SQL keys.

        Args:
            query: Query payload dictionary

        Returns:
            SQL string if found, None otherwise
        """
        for key in cls.SQL_KEYS:
            if key in query:
                value = query[key]
                if isinstance(value, str):
                    return value
                else:
                    raise QueryExecutionException(
                        f"Query must be a string, got {type(value)}"
                    )
        return None

    @classmethod
    def validate_query_payload(cls, query: dict[str, Any]) -> None:
        """Validate a query payload that may contain SQL.

        This method handles different query formats:
        - {"sql": "SELECT ..."}
        - {"query": "SELECT ..."}
        - {"code": "SELECT ..."}

        Args:
            query: Query payload dictionary

        Raises:
            QueryExecutionException: If validation fails
        """
        sql_query = cls.extract_sql(query)

        if sql_query is None:
            # No SQL found - may be a different query format (e.g., REST API params)
            # In this case, skip SQL validation
            return

        cls.validate_sql_query(sql_query)

    @staticmethod
    def _normalize_query(query: str) -> str:
        """Normalize query by removing comments and extra whitespace.

        Args:
            query: Raw SQL query

        Returns:
            Normalized query string
        """
        # Remove single-line comments (-- comment)
        query = re.sub(r"--[^\n]*", "", query)

        # Remove multi-line comments (/* comment */)
        query = re.sub(r"/\*.*?\*/", "", query, flags=re.DOTALL)

        # Remove extra whitespace
        query = " ".join(query.split())

        return query.strip().upper()

    @staticmethod
    def _get_first_keyword(normalized_query: str) -> str | None:
        """Extract the first SQL keyword from a normalized query.

        Args:
            normalized_query: Uppercase, normalized SQL query

        Returns:
            The first keyword or None
        """
        words = normalized_query.split()
        if not words:
            return None

        return words[0]

    @classmethod
    def _contains_forbidden_keywords(cls, normalized_query: str) -> bool:
        """Check if query contains any forbidden keywords.

        Args:
            normalized_query: Uppercase, normalized SQL query

        Returns:
            True if forbidden keywords found, False otherwise
        """
        # Use word boundaries to avoid false positives
        for keyword in cls.FORBIDDEN_KEYWORDS:
            # Match keyword as whole word using regex word boundaries
            pattern = r"\b" + keyword + r"\b"
            if re.search(pattern, normalized_query):
                return True

        return False

    @classmethod
    def validate_database_scope(
        cls,
        query: str,
        allowed_database: str | None,
        enforce: bool = True,
    ) -> None:
        """Validate that query only accesses the allowed database.

        This method detects three-part identifiers (DATABASE.SCHEMA.TABLE) in SQL
        queries and rejects queries that reference databases other than the
        configured/allowed database.

        Args:
            query: The SQL query string
            allowed_database: The database the connection is restricted to
            enforce: Whether to enforce the restriction (default: True)

        Raises:
            QueryExecutionException: If cross-database access is detected
        """
        if not enforce or not allowed_database:
            return

        normalized_query = cls._normalize_query(query)
        allowed_db_upper = allowed_database.upper().strip('"')

        # Block INFORMATION_SCHEMA views that expose cross-database information
        for view in cls.RESTRICTED_INFO_SCHEMA_VIEWS:
            # Match patterns like INFORMATION_SCHEMA.DATABASES or DB.INFORMATION_SCHEMA.DATABASES
            pattern = rf"\bINFORMATION_SCHEMA\.{view}\b"
            if re.search(pattern, normalized_query):
                raise QueryExecutionException(
                    f"Access to INFORMATION_SCHEMA.{view} is restricted. "
                    f"This view exposes information beyond the configured database '{allowed_database}'. "
                    f"Use get_data_source_metadata() to discover available tables and schemas."
                )

        # Find all three-part identifiers (DATABASE.SCHEMA.TABLE)
        matches = cls.THREE_PART_IDENTIFIER_PATTERN.findall(normalized_query)

        for match in matches:
            detected_db = match[0].upper().strip('"')
            if detected_db != allowed_db_upper:
                raise QueryExecutionException(
                    f"Cross-database access denied. Query references database '{match[0]}' "
                    f"but this connection is restricted to database '{allowed_database}'."
                )

    @classmethod
    def extract_tables_from_sql(cls, query: str) -> set[str]:
        """Extract table names referenced in a SQL query.

        Parses FROM and JOIN clauses to identify table references.
        Preserves schema.table when present and drops any database prefix.

        Args:
            query: The SQL query string

        Returns:
            Set of table names (uppercase), including schema.table when present
        """
        # Remove comments first
        query = re.sub(r"--[^\n]*", "", query)
        query = re.sub(r"/\*.*?\*/", "", query, flags=re.DOTALL)

        tables: set[str] = set()
        matches = cls.TABLE_REFERENCE_PATTERN.findall(query)

        for match in matches:
            # Keep schema.table when present; drop database if included.
            parts = [part.strip().strip('"') for part in match.split(".")]
            if len(parts) >= 2:
                table_name = ".".join(parts[-2:])
            else:
                table_name = parts[0]

            tables.add(table_name.upper())

        return tables

    @classmethod
    def validate_table_access(
        cls,
        query: str,
        enabled_tables: set[str] | None,
        enforce: bool = True,
    ) -> None:
        """Validate that a query only accesses enabled tables from the semantic layer.

        This method extracts table references from the SQL query and checks them
        against the list of enabled tables defined in the semantic layer.

        Args:
            query: The SQL query string
            enabled_tables: Set of table names that are enabled (is_included=True).
                           If None or empty, validation is skipped.
            enforce: Whether to enforce the restriction (default: True)

        Raises:
            QueryExecutionException: If query references disabled tables
        """
        if not enforce or not enabled_tables:
            return

        enabled_tables_upper = {t.upper().strip('"') for t in enabled_tables}
        enabled_tables_bare = {t.split(".")[-1] for t in enabled_tables_upper}
        # Build a schema.table set (last two parts) for matching references
        # that had their database prefix stripped by extract_tables_from_sql.
        enabled_tables_schema = {
            ".".join(t.split(".")[-2:]) for t in enabled_tables_upper if "." in t
        }
        referenced_tables = cls.extract_tables_from_sql(query)

        disabled_tables: set[str] = set()
        for ref in referenced_tables:
            if "." in ref:
                if ref not in enabled_tables_upper and ref not in enabled_tables_schema:
                    if ref.split(".")[-1] not in enabled_tables_bare:
                        disabled_tables.add(ref)
            else:
                if ref not in enabled_tables_bare:
                    disabled_tables.add(ref)

        if disabled_tables:
            disabled_list = ", ".join(sorted(disabled_tables))
            enabled_list = ", ".join(sorted(enabled_tables_upper))
            raise QueryExecutionException(
                f"Access to table(s) '{disabled_list}' is not allowed. "
                f"These tables are not enabled in the semantic layer. "
                f"Enabled tables: {enabled_list}"
            )

    @classmethod
    def validate_query_with_semantic_layer(
        cls,
        query: dict[str, Any],
        semantic_layer: dict[str, Any] | None,
    ) -> None:
        """Validate a query payload against semantic layer table restrictions.

        This is a convenience method that extracts enabled tables from the
        semantic layer configuration and validates the query against them.

        Args:
            query: Query payload dictionary
            semantic_layer: Semantic layer configuration dict with 'tables' key
                           containing list of table configs with 'is_included' flag

        Raises:
            QueryExecutionException: If validation fails
        """
        # First run standard SQL validation
        cls.validate_query_payload(query)

        # Extract SQL from payload
        sql_query = cls.extract_sql(query)
        if sql_query is None:
            # No SQL found - skip table validation (e.g., Google Sheets query)
            return

        # Extract enabled tables from semantic layer
        if not semantic_layer:
            return

        tables_config = semantic_layer.get("tables", [])
        if not tables_config:
            return

        enabled_tables: set[str] = set()
        for table in tables_config:
            # Check is_included flag (defaults to True if not present)
            is_included = table.get("is_included", True)
            if is_included:
                table_name = table.get("name", "")
                if table_name:
                    enabled_tables.add(table_name)

        # Validate table access
        cls.validate_table_access(sql_query, enabled_tables)
