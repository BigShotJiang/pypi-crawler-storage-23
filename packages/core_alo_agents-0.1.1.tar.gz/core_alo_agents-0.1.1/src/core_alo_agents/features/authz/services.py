import logging
import importlib.util
import copy

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from core_alo.services import BaseService
from core_alo.exceptions import (
    HTTPNotFoundException,
    DefaultHTTPException,
)
from ...config import parent_settings
from .models import Permission
from .schemas import (
    PermissionCreate,
    PermissionUpdate,
)
from .permissions import SystemPermissions
from .default_permissions import DEFAULT_PERMISSIONS


class SystemPermissionsService(SystemPermissions, BaseService):
    pass


class PermissionService(BaseService):
    model = Permission

    def get_all_permissions(
        self,
        role_slugs: list[str] | None = None,
        resource_types: list[str] | None = None,
        actions: list[str] | None = None,
    ) -> list[Permission]:
        """Get all permissions with optional filters"""

        query = select(self.model)

        if role_slugs:
            # Filter permissions that have any of the specified role slugs
            query = query.where(self.model.role_slugs.overlap(role_slugs))

        if resource_types:
            query = query.where(self.model.resource_type.in_(resource_types))

        if actions:
            query = query.where(self.model.action.in_(actions))

        db_permissions = self.db.scalars(query).all()
        return db_permissions

    def get_permissions_for_user(
        self,
        resource_type: str | None = None,
        action: str | None = None,
    ) -> list[Permission]:
        """
        Get all permissions for a user based on their Keycloak role slugs.

        Args:
            user_id: The user ID (not actually used, kept for interface compatibility)
            resource_type: Optional filter by resource type (e.g., 'agent', 'chat')
            action: Optional filter by action (e.g., 'list', 'create', 'delete')

        Returns:
            List of permissions assigned to the user through their role slugs
        """
        realm_roles = self.user._keycloak_user.realm_roles or []
        if not realm_roles:
            logging.info(f"No realm roles found for user {self.user.id}")
            return []

        # Find permissions that match any of the user's role slugs
        query = select(self.model).where(self.model.role_slugs.overlap(realm_roles))

        # Apply optional filters
        if resource_type:
            query = query.where(self.model.resource_type == resource_type)

        if action:
            query = query.where(self.model.action == action)

        query = query.distinct()

        permissions = self.db.scalars(query).all()

        filter_info = []
        if resource_type:
            filter_info.append(f"resource_type={resource_type}")
        if action:
            filter_info.append(f"action={action}")

        log_msg = (
            f"Found {len(permissions)} permissions for user {self.user.id} "
            f"across {len(realm_roles)} role slugs"
        )
        if filter_info:
            log_msg += f" (filters: {', '.join(filter_info)})"

        logging.info(log_msg)
        return list(permissions)

    def get_permission_by_id(self, permission_id: int) -> Permission:
        """Get a single permission by ID"""
        permission = self.get_object(permission_id)
        if not permission:
            raise HTTPNotFoundException(item="Permission")

        return permission

    def update_permission(
        self, permission_id: int, payload: PermissionUpdate
    ) -> Permission:
        """Update an existing permission"""
        permission = self.get_object(permission_id)
        if not permission:
            raise HTTPNotFoundException(item="Permission")

        # Update only provided fields
        self.update_object(payload, obj=permission)
        logging.info(f"Updated permission {permission_id}")
        return permission

    def create_permission(self, payload: PermissionCreate) -> Permission:
        """Create a new permission"""
        try:
            permission = self.create_object(payload)
            scope = (
                "all resources"
                if payload.attribute_field is None
                else f"{payload.attribute_field}={payload.attribute_value}"
            )
            logging.info(
                f"Created permission: {payload.action} on "
                f"{payload.resource_type} ({scope})"
            )
        except IntegrityError as e:
            logging.error(f"Error creating permission: {e}")
            raise DefaultHTTPException(
                detail="Error creating permission",
                status_code=500,
            )
        return permission

    def delete_permission(self, permission_id: int) -> bool:
        """Delete a specific permission (cascade deletes links)"""
        permission = self.get_object(permission_id)
        if not permission:
            raise HTTPNotFoundException(item="Permission")

        self.delete_object(obj=permission)
        logging.info(f"Deleted permission {permission_id}")
        return True


class AuthzAdminService(BaseService):
    """Service for authorization system administration"""

    model = Permission

    def _load_agent_default_permissions(self) -> dict[str, list[dict]]:
        """
        Load and merge default permissions from both:
        1. Base authz default permissions (from authz feature)
        2. Agent-specific default permissions (from settings.DEFAULT_PERMISSIONS_PATH)

        Returns:
            Merged dictionary of default permissions
        """
        merged_permissions = copy.deepcopy(DEFAULT_PERMISSIONS)

        if not parent_settings or not parent_settings.DEFAULT_PERMISSIONS_PATH:
            return merged_permissions

        spec = importlib.util.spec_from_file_location(
            "agent_default_permissions", parent_settings.DEFAULT_PERMISSIONS_PATH
        )
        agent_defaults_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(agent_defaults_module)

        if not hasattr(agent_defaults_module, "DEFAULT_PERMISSIONS"):
            return merged_permissions

        agent_perms = agent_defaults_module.DEFAULT_PERMISSIONS
        for resource_type, permissions_list in agent_perms.items():
            if resource_type in merged_permissions:
                merged_permissions[resource_type].extend(permissions_list)
            else:
                merged_permissions[resource_type] = permissions_list

        return merged_permissions

    def populate_default_permissions(self) -> dict[str, any]:
        """
        Populate database with default permissions from merged config.

        This will:
        1. Read default permissions from base authz config
        2. Read and merge agent-specific default permissions (from settings)
        3. Create permissions in database if they don't exist
        4. Assign role slugs to permissions

        This function is idempotent - safe to run multiple times.

        Returns:
            Dictionary with population statistics
        """

        stats = {
            "permissions_created": 0,
            "permissions_skipped": 0,
            "role_slugs_added": 0,
            "errors": [],
        }

        logging.info("Starting default permissions population...")

        merged_permissions = self._load_agent_default_permissions()
        for resource_type, permissions_list in merged_permissions.items():
            for perm_config in permissions_list:
                # Check if permission already exists by name; idk if stable, for now should suffice
                existing_perm = self.db.scalars(
                    select(Permission).where(Permission.name == perm_config["name"])
                ).first()

                if existing_perm:
                    stats["permissions_skipped"] += 1
                    permission = existing_perm
                    logging.info(
                        f"⊘ Skipped existing permission '{perm_config['name']}'"
                    )
                else:
                    permission_create = PermissionCreate(
                        name=perm_config["name"],
                        description=perm_config.get("description"),
                        resource_type=perm_config["resource_type"],
                        action=perm_config["action"],
                        has_access=perm_config.get("has_access", True),
                        role_slugs=perm_config.get("role_slugs", []),
                        attribute_field=None,
                        attribute_value=None,
                    )
                    permission = self.create_object(
                        permission_create, model=Permission, commit=False
                    )
                    stats["permissions_created"] += 1
                    logging.info(f"✓ Created permission '{perm_config['name']}'")

                # Update role slugs for existing permissions
                desired_role_slugs = perm_config.get("role_slugs", [])
                if desired_role_slugs:
                    current_slugs = set(permission.role_slugs or [])
                    new_slugs = set(desired_role_slugs) - current_slugs
                    if new_slugs:
                        permission.role_slugs = sorted(current_slugs | new_slugs)
                        stats["role_slugs_added"] += len(new_slugs)
                        logging.info(
                            f"✓ Added roles {sorted(new_slugs)} to permission '{perm_config['name']}'"
                        )

        self.db.commit()

        logging.info(
            f"Default permissions population complete: "
            f"{stats['permissions_created']} created, "
            f"{stats['permissions_skipped']} skipped, "
            f"{stats['role_slugs_added']} role slugs added"
        )

        if stats["errors"]:
            logging.warning(f"Population completed with {len(stats['errors'])} errors")

        return stats
