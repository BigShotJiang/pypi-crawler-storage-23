from fastapi import APIRouter, status, Query
from ...cbv import cbv

from core_alo.mixins import AdminCBVMixin
from .schemas import PermissionCreate, PermissionUpdate, PermissionPublic
from .services import PermissionService, AuthzAdminService


authz_router = APIRouter(
    tags=["Authorization"],
    prefix="/authz",
)


@cbv(authz_router)
class PermissionCBV(AdminCBVMixin):
    """Permission Management"""

    service_class = PermissionService

    # @authz_router.get("/permissions/", response_model=list[PermissionPublicResponse])
    @authz_router.get("/permissions/", response_model=list[PermissionPublic])
    def list_permissions(
        self,
        role_slugs: list[str] = Query(None),
        resource_types: list[str] = Query(None),
        actions: list[str] = Query(None),
    ):
        """
        Get all permissions with optional filters.

        Returns both database permissions and standard permissions from code.

        Query Parameters:
            role_slugs: Filter by role slugs (only returns DB permissions when set)
            resource_types: Filter by resource types (e.g., "agent", "system")
            actions: Filter by actions (e.g., "list", "detail", "view_observability")

        Response includes:
            - Permissions: Defined in database
        """
        return self.get_service().get_all_permissions(
            role_slugs=role_slugs,
            resource_types=resource_types,
            actions=actions,
        )

    @authz_router.get("/permissions/me/", response_model=list[PermissionPublic])
    def get_my_permissions(
        self,
        resource_type: str | None = Query(
            None, description="Filter by resource type (e.g., 'agent', 'chat')"
        ),
        action: str | None = Query(
            None, description="Filter by action (e.g., 'list', 'create', 'delete')"
        ),
    ):
        """Get all permissions for the current user, optionally filtered by resource_type and action"""
        return self.get_service().get_permissions_for_user(
            resource_type=resource_type, action=action
        )

    @authz_router.get("/permissions/{permission_id}/", response_model=PermissionPublic)
    def get_permission(self, permission_id: int):
        """Get a single permission by ID"""
        return self.get_service().get_permission_by_id(permission_id)

    @authz_router.patch(
        "/permissions/{permission_id}/", response_model=PermissionPublic
    )
    def update_permission(self, permission_id: int, payload: PermissionUpdate):
        """
        Update a permission.

        Only provided fields will be updated.

        Example:
            {
                "name": "Updated permission name",
                "description": "Updated description"
            }
        """
        return self.get_service().update_permission(permission_id, payload)

    @authz_router.post(
        "/permissions/",
        response_model=PermissionPublic,
        status_code=status.HTTP_201_CREATED,
    )
    def create_permission(self, payload: PermissionCreate):
        """
        Create a permission with role slugs.

        Examples:
            # Allow viewing all agents (wildcard - NULL attribute fields)
            {
                "name": "View all agents",
                "action": "list",
                "resource_type": "agent",
                "role_slugs": ["admins"]
            }

            # Allow viewing specific agent by ID
            {
                "name": "View agent 5",
                "action": "detail",
                "resource_type": "agent",
                "attribute_field": "id",
                "attribute_value": "5",
                "role_slugs": ["admins"]
            }

            # Attribute-based permission (slug-based)
            {
                "name": "View jade agent",
                "action": "list",
                "resource_type": "agent",
                "attribute_field": "slug",
                "attribute_value": "agent-jade",
                "role_slugs": ["admins"]
            }

            # Custom permission: view observability (wildcard)
            {
                "name": "View observability",
                "action": "view_observability",
                "resource_type": "system",
                "role_slugs": ["admins"]
            }
        """
        return self.get_service().create_permission(payload)

    @authz_router.delete(
        "/permissions/{permission_id}/", status_code=status.HTTP_204_NO_CONTENT
    )
    def delete_permission(self, permission_id: int):
        """Delete a permission"""
        self.get_service().delete_permission(permission_id)
        return None


@cbv(authz_router)
class AuthzAdminCBV(AdminCBVMixin):
    """Authorization Admin Management"""

    service_class = AuthzAdminService

    @authz_router.post("/populate-default-permissions/", status_code=status.HTTP_200_OK)
    def populate_default_permissions(self):
        """
        Populate database with default permissions from configuration.

        This endpoint will:
        1. Read default permissions from DEFAULT_PERMISSIONS config
        2. Create permissions in database if they don't exist
        3. Assign role slugs to permissions

        This is idempotent and safe to run multiple times.

        **When to use:**
        - When adding new default permissions to the config
        - To ensure all default permissions are in the database
        - When setting up authorization for the first time

        **Note:**
        Role slugs are stored directly on the permission records.

        Returns:
            Summary of populated items including:
            - permissions_created: New permissions created in database
            - permissions_skipped: Permissions that already exist
            - role_slugs_added: Number of role slugs added to existing permissions
            - errors: List of any errors encountered

        Example response:
            {
                "message": "Default permissions populated successfully",
                "details": {
                    "permissions_created": 7,
                    "permissions_skipped": 0,
                    "role_slugs_added": 7,
                    "errors": []
                }
            }
        """
        result = self.get_service().populate_default_permissions()

        # Check if there were errors
        has_errors = len(result.get("errors", [])) > 0
        status_msg = (
            "Default permissions populated with errors"
            if has_errors
            else "Default permissions populated successfully"
        )

        return {
            "message": status_msg,
            "details": result,
        }
