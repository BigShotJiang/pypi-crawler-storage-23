from typing import TypeVar, Type
import uuid

from core_alo.models import BaseModel


ModelType = TypeVar("ModelType", bound=BaseModel)


class PermissionsServiceMixin:
    """
    Enhanced BaseService with strict separation of concerns:
    1. check_permission: Verifies capability (Raises 403 Forbidden)
    2. get_authz_filters: Restricts data scope (Results in 404 Not Found / Empty List)
    """

    def get_objects(
        self,
        filters: tuple = (),
        model: Type[ModelType] | None = None,
        order_by: tuple = (),
    ):
        self.check_permission("list")

        authz_filters = self.get_authz_filters("list")
        combined_filters = (*filters, *authz_filters)

        return super().get_objects(
            filters=combined_filters, model=model, order_by=order_by
        )

    def get_object(
        self,
        obj_id: int | uuid.UUID | None = None,
        raise404: bool = True,
        filters: tuple = (),
        model: Type[ModelType] | None = None,
    ):
        self.check_permission("detail")

        authz_filters = self.get_authz_filters("detail")
        combined_filters = (*filters, *authz_filters)

        return super().get_object(
            obj_id=obj_id, raise404=raise404, filters=combined_filters, model=model
        )

    def create_object(
        self,
        payload,
        update: dict | None = None,
        model: Type[ModelType] | None = None,
        commit: bool = True,
    ):
        self.check_permission("create")
        return super().create_object(payload, update, model, commit)

    def update_object(
        self,
        payload,
        obj_id: int | uuid.UUID | None = None,
        obj=None,
        update: dict | None = None,
        model: Type[ModelType] | None = None,
        filters: tuple = (),
        commit: bool = True,
    ):
        self.check_permission("edit")

        authz_filters = self.get_authz_filters("edit")
        combined_filters = (*filters, *authz_filters)

        return super().update_object(
            payload,
            obj_id,
            obj,
            update,
            model,
            filters=combined_filters,
            commit=commit,
        )

    def delete_object(
        self,
        obj_id: int | uuid.UUID | None = None,
        obj=None,
        model: Type[ModelType] | None = None,
        filters: tuple = (),
    ):
        self.check_permission("delete")

        authz_filters = self.get_authz_filters("delete")
        combined_filters = (*filters, *authz_filters)

        return super().delete_object(obj_id, obj, model, filters=combined_filters)
