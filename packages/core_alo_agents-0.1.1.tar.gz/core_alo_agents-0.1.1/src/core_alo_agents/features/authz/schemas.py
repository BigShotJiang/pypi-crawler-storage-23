from typing import Literal
from pydantic import BaseModel, Field
from core_alo.schemas import TimeAuditSchemaMixin, BaseSchema
from .constants import PermissionOperator


# Permission Schemas
class PermissionBase(BaseSchema):
    name: str = Field(..., description="Permission name")
    description: str | None = Field(None, description="Permission description")
    resource_type: str = Field(
        ..., description="Resource type (e.g., 'agent', 'chat', 'system')"
    )
    action: str = Field(
        ...,
        description="Action (e.g., 'list', 'detail', 'edit', 'delete', 'view_observability')",
    )
    role_slugs: list[str] = Field(
        default_factory=list,
        description="Role slugs that have this permission (e.g., ['admins', 'developers'])",
    )
    attribute_field: str | None = Field(
        None,
        description="Field name for attribute-based filtering (e.g., 'id', 'slug'). NULL for wildcard (all resources).",
    )
    attribute_value: str | list | dict | None = Field(
        None,
        description="Value to match against attribute_field. NULL for wildcard (all resources).",
    )
    attribute_operator: str = Field(
        default=PermissionOperator.EQUALS,
        description="Comparison operator (eq, ne, in, nin, etc.)",
    )
    has_access: bool = Field(default=True, description="Global access value")


class PermissionCreate(PermissionBase):
    pass


class PermissionUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    resource_type: str | None = None
    action: str | None = None
    role_slugs: list[str] | None = None
    attribute_field: str | None = None
    attribute_value: str | list | dict | None = None
    attribute_operator: str | None = None
    has_access: bool | None = None


class PermissionPublic(TimeAuditSchemaMixin, PermissionBase):
    id: int


class AuthzDefaultInfo(BaseModel):
    value: bool = Field(..., description="Value")
    name: str = Field(..., description="Description")
