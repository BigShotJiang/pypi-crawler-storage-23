from enum import StrEnum


class PermissionAction(StrEnum):
    """
    Standard CRUD+ actions.
    """

    LIST = "list"
    DETAIL = "detail"
    CREATE = "create"
    EDIT = "edit"
    DELETE = "delete"


class PermissionOperator(StrEnum):
    EQUALS = "eq"
    NOT_EQUALS = "ne"
    GREATER_THAN = "gt"
    LESS_THAN = "lt"
    GREATER_THAN_OR_EQUAL = "gte"
    LESS_THAN_OR_EQUAL = "lte"
    IN = "in"
    NOT_IN = "nin"


RESOURCE_ID_WILDCARD = "*"
