"""
Mathematical and geometric operations - Tools for advanced mathematical computations, statistics, geometry, and linear algebra.
"""

import math
import statistics
from typing import List, Dict, Any, Tuple


# ============================================================================
# STATISTICAL OPERATIONS
# ============================================================================

def calculate_statistics(numbers: List[float]) -> Dict[str, float]:
    """
    Calculate comprehensive statistics for a dataset.
    
    Args:
        numbers: List of numerical values
        
    Returns:
        Dictionary with mean, median, mode, std_dev, variance, min, max, range
    """
    if not numbers:
        raise ValueError("Cannot calculate statistics on empty list")
    
    stats = {
        'count': len(numbers),
        'sum': sum(numbers),
        'mean': statistics.mean(numbers),
        'median': statistics.median(numbers),
        'std_dev': statistics.stdev(numbers) if len(numbers) > 1 else 0,
        'variance': statistics.variance(numbers) if len(numbers) > 1 else 0,
        'min': min(numbers),
        'max': max(numbers),
        'range': max(numbers) - min(numbers)
    }
    
    try:
        stats['mode'] = statistics.mode(numbers)
    except statistics.StatisticsError:
        stats['mode'] = None  # No unique mode
    
    return stats


def calculate_percentiles(numbers: List[float], percentiles: List[int]) -> Dict[str, float]:
    """
    Calculate specified percentiles for a dataset.
    
    Args:
        numbers: List of numerical values
        percentiles: List of percentile values to calculate (e.g., [25, 50, 75])
        
    Returns:
        Dictionary mapping percentile to its value
    """
    if not numbers:
        raise ValueError("Cannot calculate percentiles on empty list")
    
    sorted_numbers = sorted(numbers)
    result = {}
    
    for p in percentiles:
        if p < 0 or p > 100:
            raise ValueError(f"Percentile must be between 0 and 100, got {p}")
        result[f'p{p}'] = statistics.quantiles(sorted_numbers, n=100)[p-1] if p > 0 else sorted_numbers[0]
    
    return result


def calculate_correlation(x: List[float], y: List[float]) -> float:
    """
    Calculate Pearson correlation coefficient between two datasets.
    
    Args:
        x: First dataset
        y: Second dataset
        
    Returns:
        Correlation coefficient (-1 to 1)
    """
    if len(x) != len(y):
        raise ValueError("Datasets must have the same length")
    if len(x) < 2:
        raise ValueError("Need at least 2 data points")
    
    return statistics.correlation(x, y)


# ============================================================================
# GEOMETRIC OPERATIONS - 2D
# ============================================================================

def calculate_distance_2d(point1: Tuple[float, float], point2: Tuple[float, float]) -> float:
    """
    Calculate Euclidean distance between two points in 2D space.
    
    Args:
        point1: Tuple (x1, y1)
        point2: Tuple (x2, y2)
        
    Returns:
        Distance between the points
    """
    return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)


def calculate_circle_properties(radius: float) -> Dict[str, float]:
    """
    Calculate properties of a circle given its radius.
    
    Args:
        radius: Radius of the circle
        
    Returns:
        Dictionary with area, circumference, and diameter
    """
    if radius < 0:
        raise ValueError("Radius cannot be negative")
    
    return {
        'radius': radius,
        'diameter': 2 * radius,
        'circumference': 2 * math.pi * radius,
        'area': math.pi * radius**2
    }


def calculate_triangle_area(base: float, height: float) -> float:
    """
    Calculate area of a triangle given base and height.
    
    Args:
        base: Base of the triangle
        height: Height of the triangle
        
    Returns:
        Area of the triangle
    """
    if base < 0 or height < 0:
        raise ValueError("Base and height must be non-negative")
    
    return 0.5 * base * height


def calculate_triangle_area_heron(a: float, b: float, c: float) -> float:
    """
    Calculate area of a triangle using Heron's formula given three sides.
    
    Args:
        a: First side length
        b: Second side length
        c: Third side length
        
    Returns:
        Area of the triangle
    """
    if a <= 0 or b <= 0 or c <= 0:
        raise ValueError("All sides must be positive")
    if a + b <= c or a + c <= b or b + c <= a:
        raise ValueError("Invalid triangle: sum of two sides must be greater than the third")
    
    s = (a + b + c) / 2  # semi-perimeter
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area


def calculate_rectangle_properties(length: float, width: float) -> Dict[str, float]:
    """
    Calculate properties of a rectangle.
    
    Args:
        length: Length of the rectangle
        width: Width of the rectangle
        
    Returns:
        Dictionary with area, perimeter, and diagonal
    """
    if length < 0 or width < 0:
        raise ValueError("Length and width must be non-negative")
    
    return {
        'length': length,
        'width': width,
        'area': length * width,
        'perimeter': 2 * (length + width),
        'diagonal': math.sqrt(length**2 + width**2)
    }


def calculate_polygon_area(vertices: List[Tuple[float, float]]) -> float:
    """
    Calculate area of a polygon using the Shoelace formula.
    
    Args:
        vertices: List of (x, y) tuples representing polygon vertices in order
        
    Returns:
        Area of the polygon
    """
    if len(vertices) < 3:
        raise ValueError("A polygon must have at least 3 vertices")
    
    n = len(vertices)
    area = 0.0
    
    for i in range(n):
        j = (i + 1) % n
        area += vertices[i][0] * vertices[j][1]
        area -= vertices[j][0] * vertices[i][1]
    
    return abs(area) / 2.0


# ============================================================================
# GEOMETRIC OPERATIONS - 3D
# ============================================================================

def calculate_distance_3d(point1: Tuple[float, float, float], 
                         point2: Tuple[float, float, float]) -> float:
    """
    Calculate Euclidean distance between two points in 3D space.
    
    Args:
        point1: Tuple (x1, y1, z1)
        point2: Tuple (x2, y2, z2)
        
    Returns:
        Distance between the points
    """
    return math.sqrt((point2[0] - point1[0])**2 + 
                     (point2[1] - point1[1])**2 + 
                     (point2[2] - point1[2])**2)


def calculate_sphere_properties(radius: float) -> Dict[str, float]:
    """
    Calculate properties of a sphere given its radius.
    
    Args:
        radius: Radius of the sphere
        
    Returns:
        Dictionary with surface_area, volume, and diameter
    """
    if radius < 0:
        raise ValueError("Radius cannot be negative")
    
    return {
        'radius': radius,
        'diameter': 2 * radius,
        'surface_area': 4 * math.pi * radius**2,
        'volume': (4/3) * math.pi * radius**3
    }


def calculate_cylinder_properties(radius: float, height: float) -> Dict[str, float]:
    """
    Calculate properties of a cylinder.
    
    Args:
        radius: Radius of the cylinder base
        height: Height of the cylinder
        
    Returns:
        Dictionary with surface_area, volume, and lateral_area
    """
    if radius < 0 or height < 0:
        raise ValueError("Radius and height must be non-negative")
    
    return {
        'radius': radius,
        'height': height,
        'base_area': math.pi * radius**2,
        'lateral_area': 2 * math.pi * radius * height,
        'surface_area': 2 * math.pi * radius * (radius + height),
        'volume': math.pi * radius**2 * height
    }


def calculate_cone_properties(radius: float, height: float) -> Dict[str, float]:
    """
    Calculate properties of a cone.
    
    Args:
        radius: Radius of the cone base
        height: Height of the cone
        
    Returns:
        Dictionary with surface_area, volume, and slant_height
    """
    if radius < 0 or height < 0:
        raise ValueError("Radius and height must be non-negative")
    
    slant_height = math.sqrt(radius**2 + height**2)
    
    return {
        'radius': radius,
        'height': height,
        'slant_height': slant_height,
        'base_area': math.pi * radius**2,
        'lateral_area': math.pi * radius * slant_height,
        'surface_area': math.pi * radius * (radius + slant_height),
        'volume': (1/3) * math.pi * radius**2 * height
    }


def calculate_rectangular_prism_properties(length: float, width: float, height: float) -> Dict[str, float]:
    """
    Calculate properties of a rectangular prism (box).
    
    Args:
        length: Length of the prism
        width: Width of the prism
        height: Height of the prism
        
    Returns:
        Dictionary with surface_area, volume, and space_diagonal
    """
    if length < 0 or width < 0 or height < 0:
        raise ValueError("Dimensions must be non-negative")
    
    return {
        'length': length,
        'width': width,
        'height': height,
        'surface_area': 2 * (length * width + length * height + width * height),
        'volume': length * width * height,
        'space_diagonal': math.sqrt(length**2 + width**2 + height**2)
    }


# ============================================================================
# LINEAR ALGEBRA - VECTORS
# ============================================================================

def vector_add(v1: List[float], v2: List[float]) -> List[float]:
    """
    Add two vectors.
    
    Args:
        v1: First vector
        v2: Second vector
        
    Returns:
        Sum of the two vectors
    """
    if len(v1) != len(v2):
        raise ValueError("Vectors must have the same dimension")
    
    return [a + b for a, b in zip(v1, v2)]


def vector_subtract(v1: List[float], v2: List[float]) -> List[float]:
    """
    Subtract second vector from first vector.
    
    Args:
        v1: First vector
        v2: Second vector
        
    Returns:
        Difference of the vectors (v1 - v2)
    """
    if len(v1) != len(v2):
        raise ValueError("Vectors must have the same dimension")
    
    return [a - b for a, b in zip(v1, v2)]


def vector_dot_product(v1: List[float], v2: List[float]) -> float:
    """
    Calculate dot product of two vectors.
    
    Args:
        v1: First vector
        v2: Second vector
        
    Returns:
        Dot product
    """
    if len(v1) != len(v2):
        raise ValueError("Vectors must have the same dimension")
    
    return sum(a * b for a, b in zip(v1, v2))


def vector_magnitude(v: List[float]) -> float:
    """
    Calculate magnitude (length) of a vector.
    
    Args:
        v: Vector
        
    Returns:
        Magnitude of the vector
    """
    return math.sqrt(sum(x**2 for x in v))


def vector_normalize(v: List[float]) -> List[float]:
    """
    Normalize a vector to unit length.
    
    Args:
        v: Vector
        
    Returns:
        Normalized vector
    """
    mag = vector_magnitude(v)
    if mag == 0:
        raise ValueError("Cannot normalize zero vector")
    
    return [x / mag for x in v]


def vector_cross_product(v1: List[float], v2: List[float]) -> List[float]:
    """
    Calculate cross product of two 3D vectors.
    
    Args:
        v1: First 3D vector [x, y, z]
        v2: Second 3D vector [x, y, z]
        
    Returns:
        Cross product vector
    """
    if len(v1) != 3 or len(v2) != 3:
        raise ValueError("Cross product is only defined for 3D vectors")
    
    return [
        v1[1] * v2[2] - v1[2] * v2[1],
        v1[2] * v2[0] - v1[0] * v2[2],
        v1[0] * v2[1] - v1[1] * v2[0]
    ]


def vector_angle(v1: List[float], v2: List[float], degrees: bool = False) -> float:
    """
    Calculate angle between two vectors.
    
    Args:
        v1: First vector
        v2: Second vector
        degrees: If True, return angle in degrees; otherwise in radians
        
    Returns:
        Angle between vectors
    """
    if len(v1) != len(v2):
        raise ValueError("Vectors must have the same dimension")
    
    dot = vector_dot_product(v1, v2)
    mag1 = vector_magnitude(v1)
    mag2 = vector_magnitude(v2)
    
    if mag1 == 0 or mag2 == 0:
        raise ValueError("Cannot calculate angle with zero vector")
    
    cos_angle = dot / (mag1 * mag2)
    # Handle floating point errors
    cos_angle = max(-1, min(1, cos_angle))
    
    angle = math.acos(cos_angle)
    
    return math.degrees(angle) if degrees else angle


# ============================================================================
# LINEAR ALGEBRA - MATRICES
# ============================================================================

def matrix_add(m1: List[List[float]], m2: List[List[float]]) -> List[List[float]]:
    """
    Add two matrices.
    
    Args:
        m1: First matrix
        m2: Second matrix
        
    Returns:
        Sum of the matrices
    """
    if len(m1) != len(m2) or len(m1[0]) != len(m2[0]):
        raise ValueError("Matrices must have the same dimensions")
    
    return [[m1[i][j] + m2[i][j] for j in range(len(m1[0]))] for i in range(len(m1))]


def matrix_multiply(m1: List[List[float]], m2: List[List[float]]) -> List[List[float]]:
    """
    Multiply two matrices.
    
    Args:
        m1: First matrix (m x n)
        m2: Second matrix (n x p)
        
    Returns:
        Product matrix (m x p)
    """
    if len(m1[0]) != len(m2):
        raise ValueError(f"Cannot multiply: m1 columns ({len(m1[0])}) != m2 rows ({len(m2)})")
    
    result = [[0 for _ in range(len(m2[0]))] for _ in range(len(m1))]
    
    for i in range(len(m1)):
        for j in range(len(m2[0])):
            for k in range(len(m2)):
                result[i][j] += m1[i][k] * m2[k][j]
    
    return result


def matrix_transpose(m: List[List[float]]) -> List[List[float]]:
    """
    Transpose a matrix.
    
    Args:
        m: Matrix to transpose
        
    Returns:
        Transposed matrix
    """
    return [[m[j][i] for j in range(len(m))] for i in range(len(m[0]))]


def matrix_determinant_2x2(m: List[List[float]]) -> float:
    """
    Calculate determinant of a 2x2 matrix.
    
    Args:
        m: 2x2 matrix
        
    Returns:
        Determinant value
    """
    if len(m) != 2 or len(m[0]) != 2:
        raise ValueError("Matrix must be 2x2")
    
    return m[0][0] * m[1][1] - m[0][1] * m[1][0]


def matrix_determinant_3x3(m: List[List[float]]) -> float:
    """
    Calculate determinant of a 3x3 matrix.
    
    Args:
        m: 3x3 matrix
        
    Returns:
        Determinant value
    """
    if len(m) != 3 or len(m[0]) != 3:
        raise ValueError("Matrix must be 3x3")
    
    return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
            m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
            m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))


# ============================================================================
# ADVANCED MATHEMATICAL OPERATIONS
# ============================================================================

def is_prime(n: int) -> bool:
    """
    Check if a number is prime.
    
    Args:
        n: Integer to check
        
    Returns:
        True if prime, False otherwise
    """
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    
    return True


def prime_factors(n: int) -> List[int]:
    """
    Find all prime factors of a number.
    
    Args:
        n: Integer to factorize
        
    Returns:
        List of prime factors
    """
    if n < 2:
        return []
    
    factors = []
    d = 2
    
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1
    
    if n > 1:
        factors.append(n)
    
    return factors


def factorial(n: int) -> int:
    """
    Calculate factorial of a number.
    
    Args:
        n: Non-negative integer
        
    Returns:
        Factorial of n
    """
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    
    return math.factorial(n)


def fibonacci(n: int) -> int:
    """
    Calculate nth Fibonacci number.
    
    Args:
        n: Position in Fibonacci sequence (0-indexed)
        
    Returns:
        nth Fibonacci number
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return n
    
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    
    return b


def fibonacci_sequence(n: int) -> List[int]:
    """
    Generate first n Fibonacci numbers.
    
    Args:
        n: Number of Fibonacci numbers to generate
        
    Returns:
        List of first n Fibonacci numbers
    """
    if n <= 0:
        return []
    if n == 1:
        return [0]
    
    sequence = [0, 1]
    for i in range(2, n):
        sequence.append(sequence[i-1] + sequence[i-2])
    
    return sequence


def gcd(a: int, b: int) -> int:
    """
    Calculate Greatest Common Divisor of two numbers.
    
    Args:
        a: First integer
        b: Second integer
        
    Returns:
        GCD of a and b
    """
    return math.gcd(abs(a), abs(b))


def lcm(a: int, b: int) -> int:
    """
    Calculate Least Common Multiple of two numbers.
    
    Args:
        a: First integer
        b: Second integer
        
    Returns:
        LCM of a and b
    """
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcd(a, b)


def power_mod(base: int, exponent: int, modulus: int) -> int:
    """
    Calculate (base^exponent) % modulus efficiently.
    
    Args:
        base: Base number
        exponent: Exponent
        modulus: Modulus
        
    Returns:
        Result of modular exponentiation
    """
    if modulus <= 0:
        raise ValueError("Modulus must be positive")
    
    return pow(base, exponent, modulus)


def solve_quadratic(a: float, b: float, c: float) -> Dict[str, Any]:
    """
    Solve quadratic equation ax² + bx + c = 0.
    
    Args:
        a: Coefficient of x²
        b: Coefficient of x
        c: Constant term
        
    Returns:
        Dictionary with discriminant and roots (real or complex)
    """
    if a == 0:
        raise ValueError("Coefficient 'a' cannot be zero in a quadratic equation")
    
    discriminant = b**2 - 4*a*c
    
    result = {
        'discriminant': discriminant,
        'a': a,
        'b': b,
        'c': c
    }
    
    if discriminant > 0:
        root1 = (-b + math.sqrt(discriminant)) / (2*a)
        root2 = (-b - math.sqrt(discriminant)) / (2*a)
        result['roots'] = [root1, root2]
        result['root_type'] = 'real_distinct'
    elif discriminant == 0:
        root = -b / (2*a)
        result['roots'] = [root]
        result['root_type'] = 'real_repeated'
    else:
        real_part = -b / (2*a)
        imaginary_part = math.sqrt(-discriminant) / (2*a)
        result['roots'] = [
            {'real': real_part, 'imaginary': imaginary_part},
            {'real': real_part, 'imaginary': -imaginary_part}
        ]
        result['root_type'] = 'complex'
    
    return result


def combinaciones(n: int, k: int) -> int:
    """
    Calculate number of combinations (n choose k).
    
    Args:
        n: Total number of items
        k: Number of items to choose
        
    Returns:
        Number of combinations
    """
    if k < 0 or k > n:
        return 0
    if k == 0 or k == n:
        return 1
    
    return math.comb(n, k)


def permutations_count(n: int, k: int) -> int:
    """
    Calculate number of permutations (n P k).
    
    Args:
        n: Total number of items
        k: Number of items to arrange
        
    Returns:
        Number of permutations
    """
    if k < 0 or k > n:
        return 0
    
    return math.perm(n, k)
