from datetime import datetime
from pydantic import BaseModel


class ConnectorCredentials(BaseModel):
    id: int
    provider: str
    access_token_expires_at: datetime
    refresh_token_expires_at: datetime
    scopes: list[str]
    access_token: str
    refresh_token: str
