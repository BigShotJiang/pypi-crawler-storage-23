from dataclasses import dataclass

from pydantic_ai import RunContext
from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings
import uvicorn
from dotenv import load_dotenv

from core_alo_agents.features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from core_alo_agents.features.agents.agents import Agent, AgentDeps
from core_alo_agents.features.agents.constants import McpServerName
from core_alo_agents.features.agents.mcp_servers import get_stdio_mcp_server
from core_alo_agents.features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from core_alo_agents.config import Settings

settings = Settings()
settings.PROJECT_NAME = "Brave Hello World test agent"
settings.PROJECT_TECHNICAL_NAME = "brave-hello-world-test-agent"


SYSTEM_PROMPT = """
# Persona:
You are a helpful assistant that can answer questions and help with tasks.
"""

MCP_SERVERS = [
    # get_stdio_mcp_server(McpServerName.BRAVE_SEARCH),
    # get_stdio_mcp_server(McpServerName.FETCH),
]


@dataclass
class BraveHWAgentDeps(AgentDeps):
    hello_world_dep: str = "Hello World Dependency text"


async def hello_world_tool(ctx: RunContext[BraveHWAgentDeps]):
    return ctx.deps.hello_world_dep


agent = Agent(
    agent_card=AgentCard(
        name=settings.PROJECT_NAME,
        technicalName=settings.PROJECT_TECHNICAL_NAME,
        description="A simple agent that can answer questions and help with tasks using Brave Search.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="hello_world",
                name="Hello World String",
                description="A simple tool that returns a string",
            ),
            AgentSkill(
                id="brave_search",
                name="Brave Search",
                description="A tool that can search the web",
            ),
            AgentSkill(
                id="fetch",
                name="Fetch",
                description="A tool that can fetch data from the web",
            ),
        ],
    ),
    pydanticai_args={
        # -- Example: OpenAI no reasoning
        # "model": "openai:gpt-4o",
        # -- Example: Openai with reasoning
        # "model": OpenAIResponsesModel("o4-mini"),
        # "model_settings": OpenAIResponsesModelSettings(
        #     openai_reasoning_effort="medium",
        #     openai_reasoning_summary="detailed",
        # ),
        # -- Example: Google Gemini with reasoning
        "model": GoogleModel("gemini-2.5-flash"),
        # "model": GoogleModel("gemini-2.5-pro"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        # -- Example: Anthropic with reasoning
        # "model": AnthropicModel("claude-sonnet-4-20250514"),
        # "model_settings": AnthropicModelSettings(
        #     anthropic_thinking={"type": "enabled", "budget_tokens": 1024},
        # ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": BraveHWAgentDeps,
        "toolsets": MCP_SERVERS,
        "tools": [hello_world_tool],
    },
    settings=settings,
)


agent_app = agent.get_a2a_app(
    enable_telemetry=True,
)

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
