from dataclasses import dataclass

from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
import uvicorn
from dotenv import load_dotenv

from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.constants import McpServerName
from ..features.agents.mcp_servers import get_stdio_mcp_server
from ..features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
# Manual overwrite to run multiple agents locally
settings.AGENT_URL = "http://0.0.0.0:8003"


SYSTEM_PROMPT = """
# Persona:
You are a helpful assistant that can answer questions and help with tasks.

# Instructions:
- When user asks for company information:
  - Find sector of the company on the web
  - Find name of the CEO on the web and find his email and his work experience on the Linkedin
"""

MCP_SERVERS = [
    get_stdio_mcp_server(McpServerName.BRAVE_SEARCH),
    get_stdio_mcp_server(McpServerName.FETCH),
    get_stdio_mcp_server(McpServerName.LINKEDIN),
]


@dataclass
class LinkedinAgentDeps(AgentDeps):
    pass


agent = Agent(
    agent_card=AgentCard(
        name="Company Linkedin CEO Search agent",
        description="A simple agent that can answer questions and help with tasks using Brave Search and Linkedin.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="brave_search",
                name="Brave Search",
                description="A tool that can search the web",
            ),
            AgentSkill(
                id="fetch",
                name="Fetch",
                description="A tool that can fetch data from the web",
            ),
        ],
    ),
    pydanticai_args={
        "model": OpenAIResponsesModel("o4-mini"),
        "model_settings": OpenAIResponsesModelSettings(
            openai_reasoning_effort="medium",
            openai_reasoning_summary="detailed",
        ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": LinkedinAgentDeps,
        "toolsets": MCP_SERVERS,
    },
    settings=settings,
)


agent_app = agent.get_a2a_app()

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
