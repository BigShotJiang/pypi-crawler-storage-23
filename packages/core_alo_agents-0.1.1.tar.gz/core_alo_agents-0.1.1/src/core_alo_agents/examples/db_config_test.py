from dataclasses import dataclass

from pydantic_ai import RunContext
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
import uvicorn
from dotenv import load_dotenv

from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
settings.PROJECT_NAME = "Brave Hello World test agent"
settings.PROJECT_TECHNICAL_NAME = "brave-hello-world-test-agent"


SYSTEM_PROMPT = """
Helpful assistant.
"""


@dataclass
class BraveHWAgentDeps(AgentDeps):
    hello_world_dep: str = "Hello World Dependency text"


async def hello_world_tool(ctx: RunContext[BraveHWAgentDeps]):
    return ctx.deps.hello_world_dep


agent = Agent(
    agent_card=AgentCard(
        name=settings.PROJECT_NAME,
        technicalName=settings.PROJECT_TECHNICAL_NAME,
        description="A simple agent that can answer questions and help with tasks.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="hello_world",
                name="Hello World String",
                description="A simple tool that returns a string",
            ),
        ],
    ),
    pydanticai_args={
        "model": GoogleModel("gemini-2.5-flash"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": BraveHWAgentDeps,
        "tools": [hello_world_tool],
    },
    settings=settings,
)


agent_app = agent.get_a2a_app(
    enable_telemetry=True,
)

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
