from dataclasses import dataclass
import logging
import json
from typing import List, Any, Optional

from pydantic_ai import RunContext, Agent as PAIAgent
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
import google.genai as genai
from google.genai.types import Tool, GenerateContentConfig, GoogleSearch
from google.genai import types

import uvicorn
from dotenv import load_dotenv

from core_alo_agents.features.agents.utils import get_agent_host_port

from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.constants import McpServerName
from ..features.agents.mcp_servers import get_stdio_mcp_server


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
# Manual overwrite to run multiple agents locally
settings.AGENT_URL = "http://0.0.0.0:8008"


SYSTEM_PROMPT = """
You are an autonomous **Portfolio-Proposal Agent** for a private bank.

When a user asks for portfolio proposals, you should use the available tools to:
1. Get investor data using get_investors() or get_investor(name)
2. Get funds data using get_funds() 
3. Generate proposals using generate_portfolio_proposals(investor_names, what_if_scenario)

The generate_portfolio_proposals tool follows this process:

INPUT ❶ —  INVESTORS_DB (array of JSON objects)
Each investor row contains:
    id, name, age, country, investable_assets_usd, annual_income_usd,
    monthly_contribution_usd, goal, time_horizon_yrs, risk_tolerance (1-10),
    ethical_constraints (array), current_portfolio (array<ticker, weight>).

INPUT ❷ —  FUNDS_DB (array of JSON objects)
Each fund row contains:
    ticker, name, asset_class, domicile_country, expense_ratio,
    esg_flag, aum_usd_bn, 3yr_volatility, 5yr_return_ann, factsheet_url.

INPUT ❸ —  optional WHAT_IF — applies to *all* investors
Example:
    WHAT_IF: "Macro regime = rising rates & high volatility"

YOUR TASKS
━━━━━━━━━━
1. **Macro & Volatility Context**
   • Use the Google Search tool to fetch the latest readings for:
       ▸ CBOE VIX level
       ▸ US 10Y Treasury yield
       ▸ Inflation trend (CPI YoY)
   • Summarise in ≤ 3 bullets with evidence links.
   • Classify environment tag: { "risk_on", "risk_off", "neutral" }.

2. **Iterate Through INVESTORS_DB**
   For each investor:
   a. Check for missing critical fields; if missing → skip & log `"status": "incomplete_profile"`.
   b. Map `risk_tolerance` to baseline stock/bond/cash targets (use table below).
   c. Adjust baseline ± 10 pp if macro_environment is "risk_off" or "risk_on".
   d. From FUNDS_DB select up to **six** funds that:
        • Fit the target asset-class buckets.
        • Domiciled in investor's *country* (or UCITS if country ≠ US/EU).
        • Satisfy ethical_constraints.
        • Have volatility ≤ investor risk bucket limit (see table).
        • Among the lowest expense ratios in sleeve.
        • Provide at least one ESG option if ESG requested.
      *Use Google Search for each chosen fund to confirm expense ratio & any major news
      (closure, soft-close, style drift) within last 12 months.*
   e. Construct a **proposed_portfolio**: list of {ticker, weight}.
      • Don't exceed 15 positions.
      • Keep cash ≥ 5 % for liquidity unless risk_tolerance ≥ 9.
      • Sum weights = 1.00.

3. **Generate Client-Friendly Proposal**
   For each investor output:
     • `allocation_summary`: equity %, bond %, alt %, cash %.
     • `projected_return_std`: based on weighted 5-yr returns / volatility from FUNDS_DB.
     • `notable_macro_considerations`: 1-2 bullets referencing Task 1 findings.
     • `next_steps`: funding instructions, digital-signature link placeholder, meeting offer.

4. Output the result with the following schema, but make it human readable in bullet-points:
{
  "run_metadata": {
    "macro_environment": "risk_off",
    "macro_bullets": [
      "VIX at 28 (> long-run mean 20) — market nervous",
      "US 10-year at 4.9 % — highest since 2007",
      "US CPI cooling to 3.1 % YoY"
    ],
    "evidence_links": [ "https://finance.yahoo.com/...", "https://fred.stlouisfed.org/..." ]
  },
  "investor_proposals": [
    {
      "investor_id": 101,
      "status": "ok",
      "proposed_portfolio": [
        { "ticker": "VTI",   "weight": 0.40 },
        { "ticker": "VXUS",  "weight": 0.20 },
        { "ticker": "BND",   "weight": 0.25 },
        { "ticker": "VMBS",  "weight": 0.05 },
        { "ticker": "BIL",   "weight": 0.05 },
        { "ticker": "ICLN",  "weight": 0.05 }
      ],
      "allocation_summary": { "equity": 0.60, "bond": 0.30, "cash": 0.05, "alt": 0.05 },
      "projected_return_std": { "exp_return": 0.053, "stdev": 0.105 },
      "notable_macro_considerations": [
        "Elevated volatility — equity sleeve tilted to global mega-caps",
        "Rising yields — added mortgage-backed bond ETF for duration neutral"
      ],
      "next_steps": [
        "Client to e-sign IPS by 15 May",
        "Set recurring ACH $1 500 / month",
        "Schedule semi-annual review"
      ],
      "evidence_links": [
        "https://investor.vanguard.com/product/vti",
        ...
      ]
    },
    ...
  ],
  "what_if": { …only present if supplied… }
}

RISK‑BUCKET TABLE (modifiable in prompt)
┌──────────────┬──────────────┬──────────────────────┐
│ risk_tolerance │ equity% │ vol_cap (3yr σ) │
├──────────────┼──────────────┼──────────────────────┤
│ 1-2 │ 10 │ ≤ 6 % │
│ 3-4 │ 30 │ ≤ 9 % │
│ 5-6 │ 50 │ ≤ 12 % │
│ 7-8 │ 70 │ ≤ 15 % │
│ 9-10 │ 90 │ ≤ 20 % │
└──────────────┴──────────────┴──────────────────────┘

GUIDELINES
• **MANDATORY** — every selected fund must trigger a Google-Search call; attach at least one authoritative link.
• Bullet points ≤ 18 words.
• Skip tax/legal specifics; add disclaimer below.

DISCLAIMER
The output is educational, not personalised tax or legal advice. Investors should consult qualified professionals.

"""


async def genai_response_to_dict(response: str) -> dict:
    """
    Convert a GenAI response to a dictionary.
    """

    if response.strip().startswith("```json"):
        json_str = response.strip()[7:-3].strip()
    elif response.strip().startswith("{"):
        json_str = response.strip()
    else:
        json_str = response

    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        parse_agent = PAIAgent(
            model="google-gla:gemini-2.5-flash",
            instructions="You are a helpful assistant that parses JSON. Make sure to return the JSON string that will be possible to parse by json.loads() in python. Do not include any other text or comments.",
        )
        parsed_result = await parse_agent.run(
            f"Parse the following JSON string: {json_str}.\nCurrent Error: {e}"
        )
        try:
            return json.loads(parsed_result.output)
        except json.JSONDecodeError as e:
            logging.error(f"Error parsing JSON: {e}")
            return {}


MCP_SERVERS = [
    # get_stdio_mcp_server(McpServerName.BRAVE_SEARCH),
    get_stdio_mcp_server(McpServerName.FETCH),
]


@dataclass
class PortfolioProposalResult:
    result: str
    evidence_links: List[str]


@dataclass
class BankPortfolioAgentDeps(AgentDeps):
    google_client: Any = None


# Mock data for investors and funds
MOCK_INVESTORS = [
    {
        "id": 101,
        "name": "Jordan Doe",
        "age": 35,
        "country": "United States",
        "investable_assets_usd": 85000,
        "annual_income_usd": 120000,
        "monthly_contribution_usd": 1500,
        "goal": "Retire at 60 with $2M",
        "time_horizon_yrs": 25,
        "risk_tolerance": 7,
        "ethical_constraints": ["ESG", "No Tobacco"],
        "current_portfolio": [],
    },
    {
        "id": 102,
        "name": "Maria López",
        "age": 52,
        "country": "Spain",
        "investable_assets_usd": 420000,
        "annual_income_usd": 90000,
        "monthly_contribution_usd": 0,
        "goal": "Fund daughter's MBA in 3 yrs",
        "time_horizon_yrs": 3,
        "risk_tolerance": 4,
        "ethical_constraints": [],
        "current_portfolio": [],
    },
]

MOCK_FUNDS = [
    {
        "ticker": "VTI",
        "name": "Vanguard Total Stock Market ETF",
        "asset_class": "US Equity",
        "domicile_country": "United States",
        "expense_ratio": 0.0003,
        "esg_flag": False,
        "aum_usd_bn": 350,
        "3yr_volatility": 0.16,
        "5yr_return_ann": 0.12,
        "factsheet_url": "https://investor.vanguard.com/product/vti",
    },
    {
        "ticker": "VXUS",
        "name": "Vanguard Total Intl Stock ETF",
        "asset_class": "Intl Equity",
        "domicile_country": "United States",
        "expense_ratio": 0.0007,
        "esg_flag": False,
        "aum_usd_bn": 65,
        "3yr_volatility": 0.14,
        "5yr_return_ann": 0.06,
        "factsheet_url": "https://investor.vanguard.com/product/vxus",
    },
    {
        "ticker": "BND",
        "name": "Vanguard Total Bond Market ETF",
        "asset_class": "US IG Bonds",
        "domicile_country": "United States",
        "expense_ratio": 0.0003,
        "esg_flag": False,
        "aum_usd_bn": 300,
        "3yr_volatility": 0.05,
        "5yr_return_ann": 0.01,
        "factsheet_url": "https://investor.vanguard.com/product/bnd",
    },
    {
        "ticker": "ESGV",
        "name": "Vanguard ESG U.S. Stock ETF",
        "asset_class": "US Equity",
        "domicile_country": "United States",
        "expense_ratio": 0.0012,
        "esg_flag": True,
        "aum_usd_bn": 6,
        "3yr_volatility": 0.17,
        "5yr_return_ann": 0.13,
        "factsheet_url": "https://investor.vanguard.com/product/esgv",
    },
]


async def get_investors(ctx: RunContext[BankPortfolioAgentDeps]) -> List[dict]:
    """
    Get all investors from the mock database.

    Returns:
        List of investor dictionaries with their profiles
    """
    logging.info("Retrieving all investors")
    return MOCK_INVESTORS


async def get_investor(
    ctx: RunContext[BankPortfolioAgentDeps], investor_name: str
) -> Optional[dict]:
    """
    Get a specific investor by name.

    Args:
        investor_name: Name of the investor to retrieve

    Returns:
        Investor dictionary if found, None otherwise
    """
    logging.info(f"Retrieving investor: {investor_name}")
    for investor in MOCK_INVESTORS:
        if investor["name"].lower() == investor_name.lower():
            return investor
    return None


async def get_funds(ctx: RunContext[BankPortfolioAgentDeps]) -> List[dict]:
    """
    Get all available funds from the mock database.

    Returns:
        List of fund dictionaries with their details
    """
    logging.info("Retrieving all funds")
    return MOCK_FUNDS


async def web_search_macro_data(
    ctx: RunContext[BankPortfolioAgentDeps], query: str
) -> PortfolioProposalResult:
    """
    Perform a Google search to find macro economic data like VIX, Treasury yields, CPI.

    Args:
        query: The search query string for macro data

    Returns:
        PortfolioProposalResult containing search results and evidence links
    """
    logging.info(f"Bank Portfolio Agent Web Search: {query}")

    google_search_tool = Tool(google_search=GoogleSearch())
    search_system_prompt = """
    # Instructions:
    Use Google Search Tool to find the answer to the user's question about macro economic data.
    Return the search results with relevant information to the user query, and include all links to sources.
    Focus on current market data, financial indicators, and economic metrics.

    # Output:
    You MUST Output JSON ONLY in the following schema:
    {{
      "result": "...",
      "evidence_links": [
        "https://www.example.com/...",
        "https://www.example.com/..."
      ]
    }}

    Inside "result" field, you MUST include the answer to the user's question you found.
    """

    if not ctx.deps.google_client:
        return PortfolioProposalResult(
            result="Google client not available", evidence_links=[]
        )

    response = await ctx.deps.google_client.aio.models.generate_content(
        model="gemini-2.5-pro",
        contents=[types.Content(role="user", parts=[types.Part(text=query)])],
        config=GenerateContentConfig(
            system_instruction=[search_system_prompt],
            tools=[google_search_tool],
            response_modalities=["TEXT"],
        ),
    )

    google_search_response = await genai_response_to_dict(response.text)
    text_result = google_search_response.get("result", "No answer found")
    evidence_links = google_search_response.get("evidence_links", [])

    return PortfolioProposalResult(
        result=text_result,
        evidence_links=evidence_links,
    )


async def web_search_fund_data(
    ctx: RunContext[BankPortfolioAgentDeps], fund_ticker: str
) -> PortfolioProposalResult:
    """
    Search for specific fund information including expense ratios and recent news.

    Args:
        fund_ticker: The fund ticker symbol to search for

    Returns:
        PortfolioProposalResult containing fund research and evidence links
    """
    query = f"{fund_ticker} ETF expense ratio recent news closure soft close style drift 2024"
    logging.info(f"Bank Portfolio Agent Fund Search: {query}")

    google_search_tool = Tool(google_search=GoogleSearch())
    search_system_prompt = """
    # Instructions:
    Use Google Search Tool to find information about the specified fund/ETF.
    Look for expense ratios, recent news, closures, soft-closes, style drift, and performance data.
    Return the search results with relevant information and include all links to sources.

    # Output:
    You MUST Output JSON ONLY in the following schema:
    {{
      "result": "...",
      "evidence_links": [
        "https://www.example.com/...",
        "https://www.example.com/..."
      ]
    }}

    Inside "result" field, you MUST include the fund information you found.
    """

    if not ctx.deps.google_client:
        return PortfolioProposalResult(
            result="Google client not available", evidence_links=[]
        )

    response = await ctx.deps.google_client.aio.models.generate_content(
        model="gemini-2.5-pro",
        contents=[types.Content(role="user", parts=[types.Part(text=query)])],
        config=GenerateContentConfig(
            system_instruction=[search_system_prompt],
            tools=[google_search_tool],
            response_modalities=["TEXT"],
        ),
    )

    google_search_response = await genai_response_to_dict(response.text)
    text_result = google_search_response.get("result", "No fund data found")
    evidence_links = google_search_response.get("evidence_links", [])

    return PortfolioProposalResult(
        result=text_result,
        evidence_links=evidence_links,
    )


# async def generate_portfolio_proposals(
#     ctx: RunContext[BankPortfolioAgentDeps],
#     investor_names: List[str] = None,
#     what_if_scenario: str = None,
# ) -> dict:
#     """
#     Generate portfolio proposals for specified investors or all investors.

#     Args:
#         investor_names: List of investor names to generate proposals for (optional, defaults to all)
#         what_if_scenario: Optional scenario analysis string

#     Returns:
#         Dictionary containing portfolio proposals with macro context
#     """
#     logging.info(
#         f"Generating portfolio proposals for: {investor_names or 'all investors'}"
#     )

#     # Get investors data
#     if investor_names:
#         investors = []
#         for name in investor_names:
#             investor = await get_investor(ctx, name)
#             if investor:
#                 investors.append(investor)
#     else:
#         investors = await get_investors(ctx)

#     # Get funds data
#     funds = await get_funds(ctx)

#     # Get macro data
#     vix_search = await web_search_macro_data(
#         ctx, "current CBOE VIX volatility index level"
#     )
#     treasury_search = await web_search_macro_data(
#         ctx, "current US 10 year Treasury yield rate"
#     )
#     cpi_search = await web_search_macro_data(ctx, "latest US CPI inflation rate YoY")

#     # Determine macro environment
#     macro_environment = "neutral"  # Default, could be enhanced with actual analysis

#     # Generate proposals for each investor
#     investor_proposals = []
#     for investor in investors:
#         # Risk tolerance mapping
#         risk_tolerance = investor.get("risk_tolerance", 5)
#         if risk_tolerance <= 2:
#             base_equity = 0.10
#         elif risk_tolerance <= 4:
#             base_equity = 0.30
#         elif risk_tolerance <= 6:
#             base_equity = 0.50
#         elif risk_tolerance <= 8:
#             base_equity = 0.70
#         else:
#             base_equity = 0.90

#         # Simple portfolio construction (can be enhanced)
#         proposed_portfolio = [
#             {"ticker": "VTI", "weight": base_equity * 0.6},
#             {"ticker": "VXUS", "weight": base_equity * 0.4},
#             {"ticker": "BND", "weight": (1 - base_equity) * 0.8},
#             {"ticker": "BIL", "weight": (1 - base_equity) * 0.2},
#         ]

#         # Add ESG fund if requested
#         if "ESG" in investor.get("ethical_constraints", []):
#             proposed_portfolio.append({"ticker": "ESGV", "weight": 0.05})
#             # Adjust other weights proportionally
#             for position in proposed_portfolio[:-1]:
#                 position["weight"] *= 0.95

#         investor_proposals.append(
#             {
#                 "investor_id": investor["id"],
#                 "investor_name": investor["name"],
#                 "status": "ok",
#                 "proposed_portfolio": proposed_portfolio,
#                 "allocation_summary": {
#                     "equity": sum(
#                         p["weight"]
#                         for p in proposed_portfolio
#                         if any(
#                             f["ticker"] == p["ticker"]
#                             and f["asset_class"] in ["US Equity", "Intl Equity"]
#                             for f in funds
#                         )
#                     ),
#                     "bond": sum(
#                         p["weight"]
#                         for p in proposed_portfolio
#                         if any(
#                             f["ticker"] == p["ticker"] and "Bond" in f["asset_class"]
#                             for f in funds
#                         )
#                     ),
#                     "cash": sum(
#                         p["weight"]
#                         for p in proposed_portfolio
#                         if any(
#                             f["ticker"] == p["ticker"] and f["ticker"] == "BIL"
#                             for f in funds
#                         )
#                     ),
#                     "alt": 0.0,
#                 },
#                 "projected_return_std": {"exp_return": 0.06, "stdev": 0.12},
#                 "notable_macro_considerations": [
#                     f"VIX analysis: {vix_search.result[:50]}...",
#                     f"Treasury yield context: {treasury_search.result[:50]}...",
#                 ],
#                 "next_steps": [
#                     "Client to review and approve portfolio allocation",
#                     f"Set up monthly contribution of ${investor.get('monthly_contribution_usd', 0)}",
#                     "Schedule quarterly portfolio review",
#                 ],
#                 "evidence_links": vix_search.evidence_links
#                 + treasury_search.evidence_links,
#             }
#         )

#     result = {
#         "run_metadata": {
#             "macro_environment": macro_environment,
#             "macro_bullets": [
#                 f"VIX: {vix_search.result[:80]}...",
#                 f"Treasury: {treasury_search.result[:80]}...",
#                 f"CPI: {cpi_search.result[:80]}...",
#             ],
#             "evidence_links": vix_search.evidence_links
#             + treasury_search.evidence_links
#             + cpi_search.evidence_links,
#         },
#         "investor_proposals": investor_proposals,
#     }

#     if what_if_scenario:
#         result["what_if"] = {"scenario": what_if_scenario}

#     return result


agent = Agent(
    agent_card=AgentCard(
        name="Bank Portfolio Proposal Agent",
        description="An autonomous portfolio proposal agent for private banks that generates personalized investment proposals based on investor profiles, market conditions, and available funds.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="Google"),
        skills=[
            AgentSkill(
                id="investor_data",
                name="Investor Data Retrieval",
                description="Retrieve investor profiles and information from database",
            ),
            AgentSkill(
                id="fund_data",
                name="Fund Data Retrieval",
                description="Retrieve available investment funds and their details",
            ),
            AgentSkill(
                id="macro_analysis",
                name="Macro Economic Analysis",
                description="Search and analyze current macro economic indicators like VIX, Treasury yields, and inflation",
            ),
            AgentSkill(
                id="fund_research",
                name="Fund Research",
                description="Research individual funds for expense ratios, recent news, and performance data",
            ),
            AgentSkill(
                id="portfolio_generation",
                name="Portfolio Generation",
                description="Generate personalized portfolio proposals based on investor profiles and risk tolerance",
            ),
        ],
    ),
    pydanticai_args={
        "model": GoogleModel("gemini-2.5-pro"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": BankPortfolioAgentDeps,
        "toolsets": MCP_SERVERS,
        "tools": [
            get_investors,
            get_investor,
            get_funds,
            web_search_macro_data,
            web_search_fund_data,
        ],
    },
    deps_args={
        "google_client": genai.Client(),
    },
    settings=settings,
)


agent_app = agent.get_a2a_app()

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
