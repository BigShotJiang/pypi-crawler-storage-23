from dataclasses import dataclass

from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings

import uvicorn
from dotenv import load_dotenv

from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.constants import McpServerName
from ..features.agents.mcp_servers import get_stdio_mcp_server
from ..features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
# Manual overwrite to run multiple agents locally
settings.AGENT_URL = "http://0.0.0.0:8004"


SYSTEM_PROMPT = """
# Persona:
You are a professional financial analyst and investment advisor with deep expertise in financial markets, 
company analysis, and investment strategies. You provide accurate, data-driven financial insights and recommendations.

# Instructions:
- When analyzing companies or stocks:
  - Use Financial Modeling Prep API to get real-time financial data, earnings, ratios, and metrics
  - Provide comprehensive financial analysis including income statements, balance sheets, and cash flow
  - Calculate and interpret key financial ratios (P/E, ROE, debt-to-equity, etc.)
  - Analyze trends over multiple periods when available
  
- When researching markets or news:
  - Use web search to find recent market news, analyst reports, and economic indicators
  - Fetch additional data from reliable financial sources when needed
  
- Always provide:
  - Clear, actionable insights based on data
  - Risk assessments and potential red flags
  - Context about market conditions and sector performance
  - Disclaimers about investment risks when appropriate

- Format responses clearly with:
  - Key metrics and ratios in tables when relevant
  - Executive summary of findings
  - Supporting data and sources
"""

MCP_SERVERS = [
    get_stdio_mcp_server(McpServerName.FMP),  # Financial Modeling Prep API
    get_stdio_mcp_server(
        McpServerName.BRAVE_SEARCH
    ),  # Web search for news and research
    get_stdio_mcp_server(
        McpServerName.FETCH
    ),  # Fetch additional financial data sources
]


@dataclass
class FinancialAgentDeps(AgentDeps):
    pass


agent = Agent(
    agent_card=AgentCard(
        name="Financial Analysis Agent",
        description="A professional financial analyst agent that provides comprehensive financial analysis using real-time market data, company financials, and market research capabilities.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="financial_data",
                name="Financial Data Analysis",
                description="Access real-time financial data, company metrics, earnings, and financial statements via Financial Modeling Prep API",
            ),
            AgentSkill(
                id="market_research",
                name="Market Research",
                description="Search for financial news, analyst reports, and market information",
            ),
            AgentSkill(
                id="data_fetching",
                name="Data Fetching",
                description="Fetch additional financial data from web sources and APIs",
            ),
            AgentSkill(
                id="financial_analysis",
                name="Financial Analysis",
                description="Perform comprehensive financial analysis including ratio analysis, trend analysis, and valuation",
            ),
        ],
    ),
    pydanticai_args={
        "model": GoogleModel("gemini-2.5-flash"),
        # "model": GoogleModel("gemini-2.5-pro"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        # "model": AnthropicModel("claude-sonnet-4-20250514"),
        # "model_settings": AnthropicModelSettings(
        #     anthropic_thinking={"type": "enabled", "budget_tokens": 1024},
        # ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": FinancialAgentDeps,
        "toolsets": MCP_SERVERS,
    },
    settings=settings,
)


agent_app = agent.get_a2a_app()

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
