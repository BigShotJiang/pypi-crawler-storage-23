from enum import StrEnum


class UserType(StrEnum):
    OWNER = "OWNER"
    USER = "USER"
    AI = "AI"


class CreateUserType(StrEnum):
    OWNER = "OWNER"
    AGENT = "AGENT"


class UserStatus(StrEnum):
    ENABLED = "ENABLED"
    DISABLED = "DISABLED"


class FileSystemType(StrEnum):
    FOLDER = "folder"
    FILE = "file"


class LogsFilter(StrEnum):
    NONE = "NONE"
    USER = "USER"
    API_KEY_HASH = "API_KEY_HASH"


class UsageFilter(StrEnum):
    ORGANIZATION = "ORGANIZATION"
    INTEGRATION = "INTEGRATION"
    API_KEY_HASH = "API_KEY_HASH"


class FileAccessType(StrEnum):
    READ = "READ"
    WRITE = "WRITE"


class FileCheckStatus(StrEnum):
    FILE_NAME = "File with the same name"
    FILE_CONTENT = "File with the same content"
    PARENT_FOLDER = "Parent folder exists"
    FILE_UUID = "File with the same UUID"
    SOURCE_DOCUMENTS = "Source documents exist"


class FileSystemError(StrEnum):
    FOLDER_CAN_NOT_BE_DOWNLOADED = "Folder can not be downloaded"
    FILE_IS_PRIVATE = "File is private"
    CAN_NOT_BE_PROCESSED = "You can not process this file"
    CAN_NOT_CHANGE_ACCESS_RIGHTS = "You can not change access rights"
    CAN_NOT_CHANGE_ACCESS_RIGHTS_OF_FILE_CREATOR = "You can not change access rights of a file creator"
    CLOUD_STORAGE_OR_VECTORIZATION_MUST_BE_SELECTED = "Either cloud storage or vectorization must be selected"
    DOWNLOAD_LINK_HAS_EXPIRED = "Download link has expired"
    INVALID_OBJECT_NAME_FORMAT = "Invalid object name format"
    FOLDER_ALREADY_EXISTS = "Folder with the same name is already created"
    FILE_NAME_CONFLICT = "File with the same name is already created"
    FILE_OR_FOLDER_NAME_CONFLICT = "File or Folder with the same name is already created"
    FILE_CONTENT_CONFLICT = "File with the same content is already created"
    PARENT_FOLDER_NOT_FOUND = "Parent folder does not exist"
    FILE_OR_FOLDER_NOT_FOUND = "Folder or file does not exist"
    FILE_OR_FOLDER_IS_PRIVATE = "Folder or file is private"
    TARGET_IS_PRIVATE = "Target folder or file is private"
    ONLY_EMPTY_FOLDER_DELETABLE = "Only an empty folder can be deleted"
    FOLDER_CANNOT_BE_MOVED = "Folder can not be moved"
    TARGET_FOLDER_NOT_FOUND = "The target folder does not exist"
    DELETION_FAILED = "Failed to delete a file or a folder"
    FILE_NOT_FOUND = "File not found"
    INVALID_PAYLOAD = "Invalid payload"
    INVALID_PAYLOAD_FORMAT = "Invalid payload format"
    UPLOAD_URL_HAS_EXPIRED = "Upload URL has expired"
    FILE_UUID_EXISTS = "File with the same UUID already exists"
    INVALID_EXPIRATION_FORMAT = "Invalid expiration format"


class ReferenceTagOperation(StrEnum):
    SET = "set"
    ADD = "add"
    REMOVE = "remove"
