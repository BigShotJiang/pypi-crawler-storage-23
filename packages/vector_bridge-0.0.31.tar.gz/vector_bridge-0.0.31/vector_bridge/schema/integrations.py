from datetime import datetime

from pydantic import BaseModel, ConfigDict

DEFAULT_INTEGRATION = "default"


class Integration(BaseModel):
    organization_id: str
    integration_id: str
    integration_name: str
    integration_description: str
    created_at: datetime
    created_by: str
    updated_at: datetime
    updated_by: str

    @property
    def uuid(self):
        return self.integration_id


class IntegrationCreate(BaseModel):
    integration_name: str
    integration_description: str


class IntegrationUpdate(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    integration_name: str | None = None
    integration_description: str | None = None
