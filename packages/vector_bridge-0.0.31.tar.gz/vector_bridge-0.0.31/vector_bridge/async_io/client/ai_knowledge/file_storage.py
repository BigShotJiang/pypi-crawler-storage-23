import json
import os
from typing import Any

import aiofiles
import aiohttp
from vector_bridge import AsyncVectorBridgeClient
from vector_bridge.schema.ai_knowledge.filesystem import (
    AIKnowledgeFileSystemItem,
    AIKnowledgeFileSystemItemCreate,
    AIKnowledgeFileSystemItemsList,
    AIKnowledgeFileSystemItemUpdate,
    FileSystemItemAggregatedCount,
)
from vector_bridge.schema.ai_knowledge.filesystem import (
    AsyncStreamingResponse as FilesystemAsyncStreamingResponse,
)
from vector_bridge.schema.errors.ai_knowledge import raise_for_ai_knowledge_detail
from vector_bridge.schema.helpers.enums import FileAccessType, ReferenceTagOperation
from vector_bridge.schema.queries import Query
from weaviate.collections.classes.filters import _Filters
from weaviate.collections.classes.grpc import _Sorting


class AsyncFileStorageAIKnowledge:
    """Async client for AI Knowledge file storage management."""

    def __init__(self, client: AsyncVectorBridgeClient):
        self.client = client

    async def create_folder(
        self,
        file_data: AIKnowledgeFileSystemItemCreate,
        folder_description: str,
        integration_name: str | None = None,
    ) -> AIKnowledgeFileSystemItem:
        """
        Create a new folder.

        Args:
            file_data: Folder metadata object containing name, tags, parent_id, etc.
            folder_description: Description of the folder
            integration_name: The name of the Integration

        Returns:
            Created folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/folder"
        params: dict[str, Any] = {
            "folder_name": file_data.name,
            "folder_description": folder_description,
            "integration_name": integration_name,
            "private": str(file_data.private).lower(),
        }

        if file_data.parent_id:
            params["parent_id"] = file_data.parent_id
        if file_data.tags:
            params["tags"] = file_data.tags
        if file_data.file_extension is not None:
            params["file_extension"] = file_data.file_extension
        if file_data.token_count is not None:
            params["token_count"] = file_data.token_count
        if file_data.line_from is not None:
            params["line_from"] = file_data.line_from
        if file_data.line_to is not None:
            params["line_to"] = file_data.line_to
        if file_data.repository_id is not None:
            params["repository_id"] = file_data.repository_id
        if file_data.path is not None:
            params["path"] = file_data.path

        headers = self.client._get_auth_headers()

        async with self.client.session.post(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result)

    async def upload_file(
        self,
        file_data: AIKnowledgeFileSystemItemCreate,
        file_path: str | None = None,
        url: str | None = None,
        item_id: str | None = None,
        content_uniqueness_check: bool = True,
        integration_name: str | None = None,
    ) -> FilesystemAsyncStreamingResponse:
        """
        Upload and process a file in one step.

        Exactly one of ``file_path`` or ``url`` must be provided.

        Args:
            file_data: File metadata object containing name, tags, parent_id, etc.
            file_path: Path to the file to upload
            url: URL to a file to upload (mutually exclusive with file_path)
            item_id: Optional custom UUID for the file. If not provided, a new UUID will be auto-generated
            content_uniqueness_check: Check for content uniqueness
            integration_name: The name of the Integration

        Returns:
            Streaming response with progress updates and the processed file
        """
        if (file_path is None) == (url is None):
            raise ValueError("Exactly one of 'file_path' or 'url' must be provided.")

        if integration_name is None:
            integration_name = self.client.integration_name

        await self.client._ensure_session()

        file_name = file_data.name
        if file_name is None and file_path is not None:
            file_name = os.path.basename(file_path)

        endpoint = f"{self.client.base_url}/v1/ai-knowledge/files"
        headers = self.client._get_auth_headers()

        data = aiohttp.FormData()
        data.add_field("integration_name", integration_name)
        data.add_field("content_uniqueness_check", str(content_uniqueness_check).lower())
        data.add_field("tags", json.dumps(file_data.tags or []))
        data.add_field("source_documents_ids", json.dumps(file_data.source_documents_ids or []))
        data.add_field("private", str(file_data.private).lower())

        if file_data.parent_id:
            data.add_field("parent_id", file_data.parent_id)
        if item_id:
            data.add_field("item_id", item_id)
        if file_data.file_extension is not None:
            data.add_field("file_extension", file_data.file_extension)
        if file_data.token_count is not None:
            data.add_field("token_count", str(file_data.token_count))
        if file_data.line_from is not None:
            data.add_field("line_from", str(file_data.line_from))
        if file_data.line_to is not None:
            data.add_field("line_to", str(file_data.line_to))
        if file_data.repository_id is not None:
            data.add_field("repository_id", file_data.repository_id)
        if file_data.path is not None:
            data.add_field("path", file_data.path)

        if url is not None:
            data.add_field("url", url)
            if file_name:
                data.add_field("file_name", file_name)
        else:
            assert file_path is not None
            async with aiofiles.open(file_path, "rb") as f:
                file_bytes = await f.read()
            data.add_field("file", file_bytes, filename=file_name)

        response = await self.client.session.post(endpoint, headers=headers, data=data)
        if response.status >= 400:
            await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)

        return FilesystemAsyncStreamingResponse(response)

    async def create_files_reference(
        self,
        from_uuid: str,
        to_uuid: str,
        tags: list[str] | None = None,
        meta: dict[str, Any] | None = None,
        integration_name: str | None = None,
    ) -> None:
        """
        Create a reference between two files.

        Args:
            from_uuid: Source file UUID
            to_uuid: Target file UUID
            tags: Tags for the reference
            meta: Additional metadata for the reference
            integration_name: The name of the Integration

        Returns:
            None
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{from_uuid}/references"
        params = {
            "to_uuid": to_uuid,
            "integration_name": integration_name,
        }

        body: dict[str, Any] = {}
        if tags is not None:
            body["tags"] = tags
        if meta is not None:
            body["meta"] = meta

        headers = self.client._get_auth_headers()

        async with self.client.session.post(url, headers=headers, params=params, json=body) as response:
            await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
        return None

    async def update_reference_tags(
        self,
        from_uuid: str,
        to_uuid: str,
        tags: list[str],
        operation: ReferenceTagOperation = ReferenceTagOperation.SET,
        integration_name: str | None = None,
    ) -> None:
        """
        Update tags on an existing reference between two files.

        Args:
            from_uuid: Source file UUID
            to_uuid: Target file UUID (the file being referenced)
            tags: Tags to set, add, or remove
            operation: Operation: 'set' (replace all tags), 'add' (add new tags), or 'remove' (remove specific tags)
            integration_name: The name of the Integration

        Returns:
            None
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{from_uuid}/references/{to_uuid}/tags"
        params = {"integration_name": integration_name}

        body = {
            "tags": tags,
            "operation": operation,
        }

        headers = self.client._get_auth_headers()

        async with self.client.session.patch(url, headers=headers, params=params, json=body) as response:
            await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
        return None

    async def delete_files_reference(
        self,
        from_uuid: str,
        to_uuid: str,
        integration_name: str | None = None,
    ) -> None:
        """
        Delete a reference between two files.

        Args:
            from_uuid: Source file UUID
            to_uuid: Target file UUID (the file being referenced)
            integration_name: The name of the Integration

        Returns:
            None
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{from_uuid}/references/{to_uuid}"
        params = {"integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.delete(url, headers=headers, params=params) as response:
            await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
        return None

    async def rename_file_or_folder(
        self, item_id: str, new_name: str, integration_name: str | None = None
    ) -> AIKnowledgeFileSystemItem:
        """
        Rename a file or folder.

        Args:
            item_id: The ID of the file or folder to rename
            new_name: The new name for the file or folder
            integration_name: The name of the Integration

        Returns:
            Updated file or folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}/name"
        params = {
            "new_name": new_name,
            "integration_name": integration_name,
        }

        headers = self.client._get_auth_headers()

        async with self.client.session.patch(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result)

    async def update_file_or_folder(
        self,
        item_id: str,
        updated_properties: AIKnowledgeFileSystemItemUpdate,
        integration_name: str | None = None,
    ) -> AIKnowledgeFileSystemItem:
        """
        Update a file or folder.

        Args:
            item_id: The ID of the file or folder to update
            updated_properties: The new properties for the file or folder
            integration_name: The name of the Integration

        Returns:
            Updated file or folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}"
        params = {
            "integration_name": integration_name,
        }

        _json = updated_properties.to_dict()
        headers = self.client._get_auth_headers()

        async with self.client.session.patch(url, headers=headers, params=params, json=_json) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result)

    async def delete_file_or_folder(self, item_id: str, integration_name: str | None = None) -> None:
        """
        Delete a file or folder.

        Args:
            item_id: The ID of the file or folder to delete
            integration_name: The name of the Integration
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}"
        params = {"integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.delete(url, headers=headers, params=params) as response:
            await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)

    async def get_file_or_folder(self, item_id: str, integration_name: str | None = None) -> AIKnowledgeFileSystemItem:
        """
        Get details of a file or folder.

        Args:
            item_id: The ID of the file or folder
            integration_name: The name of the Integration

        Returns:
            File or folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}"
        params = {"integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.get(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result)

    async def get_file_or_folder_path(
        self, item_id: str, integration_name: str | None = None
    ) -> list[AIKnowledgeFileSystemItem]:
        """
        Get the path of a file or folder.

        Args:
            item_id: The ID of the file or folder
            integration_name: The name of the Integration

        Returns:
            List of path components as objects
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}/path"
        params = {"integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.get(url, headers=headers, params=params) as response:
            results = await self.client._handle_response(
                response=response, error_callable=raise_for_ai_knowledge_detail
            )
            return [AIKnowledgeFileSystemItem.model_validate(result) for result in results]

    async def execute_files_and_folders_list_query(
        self,
        integration_name: str | None = None,
        target_vector: str = "default",
        near_text: str | None = None,
        filters: _Filters | None = None,
        sort: _Sorting | None = None,
        limit: int = 100,
        offset: int | None = None,
        **kwargs,
    ) -> AIKnowledgeFileSystemItemsList:
        """
        List files and folders.

        Args:
            integration_name: The name of the Integration
            target_vector: The named vector to query against
            near_text: The query text
            filters: The filters to apply to the query
            sort: The sort to apply to the query
            limit: The maximum number of results to return
            offset: The offset to start with

        Returns:
            Dictionary with items, pagination info, etc.
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        query_payload = Query(
            target_vector=target_vector,
            near_text=near_text,
            filters=filters,
            sort=sort,
            limit=limit,
            offset=offset,
            kwargs=kwargs,
        )

        url = f"{self.client.base_url}/v1/ai-knowledge/items/search"
        params = {"integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.post(
            url,
            headers=headers,
            params=params,
            json=query_payload.serialize_bytes(),
        ) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItemsList.model_validate(result)

    async def count_files_and_folders(
        self, parents: list[str], integration_name: str | None = None
    ) -> FileSystemItemAggregatedCount:
        """
        Count files and folders.

        Args:
            parents: List of parent folder IDs
            integration_name: The name of the Integration

        Returns:
            Dictionary with count information
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/statistics"
        params = {"parents": parents, "integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.get(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return FileSystemItemAggregatedCount.model_validate(result)

    async def grant_or_revoke_user_access(
        self,
        item_id: str,
        user_id: str,
        has_access: bool,
        access_type: FileAccessType = FileAccessType.READ,
        integration_name: str | None = None,
    ) -> None | AIKnowledgeFileSystemItem:
        """
        Grant or revoke user access to a file or folder.

        Args:
            item_id: The ID of the file or folder
            user_id: The ID of the user
            has_access: Whether to grant (True) or revoke (False) access
            access_type: Type of access ("READ" or "WRITE")
            integration_name: The name of the Integration

        Returns:
            Updated file or folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}/permissions/users/{user_id}"
        params = {
            "has_access": str(has_access).lower(),
            "access_type": access_type,
            "integration_name": integration_name,
        }

        headers = self.client._get_auth_headers()

        async with self.client.session.put(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result) if result else None

    async def grant_or_revoke_security_group_access(
        self,
        item_id: str,
        group_id: str,
        has_access: bool,
        access_type: FileAccessType = FileAccessType.READ,
        integration_name: str | None = None,
    ) -> None | AIKnowledgeFileSystemItem:
        """
        Grant or revoke security group access to a file or folder.

        Args:
            item_id: The ID of the file or folder
            group_id: The ID of the security group
            has_access: Whether to grant (True) or revoke (False) access
            access_type: Type of access ("READ" or "WRITE")
            integration_name: The name of the Integration

        Returns:
            Updated file or folder object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/ai-knowledge/items/{item_id}/permissions/groups/{group_id}"
        params = {
            "has_access": str(has_access).lower(),
            "access_type": access_type,
            "integration_name": integration_name,
        }

        headers = self.client._get_auth_headers()

        async with self.client.session.put(url, headers=headers, params=params) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_ai_knowledge_detail)
            return AIKnowledgeFileSystemItem.model_validate(result) if result else None
