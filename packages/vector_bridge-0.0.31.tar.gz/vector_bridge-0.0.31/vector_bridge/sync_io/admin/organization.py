from vector_bridge import VectorBridgeClient
from vector_bridge.schema.errors.organization import raise_for_organization_detail
from vector_bridge.schema.organization import Organization, OrganizationUpdate


class OrganizationAdmin:
    """Admin client for organization management endpoints."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client

    def get_my_organization(self) -> Organization:
        """
        Retrieve detailed information about the organization linked to the currently authenticated user's account.

        Returns:
            Organization details
        """
        url = f"{self.client.base_url}/v1/admin/organization/me"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        data = self.client._handle_response(response=response, error_callable=raise_for_organization_detail)
        return Organization.model_validate(data)

    def update_organization(self, organization_data: OrganizationUpdate) -> Organization:
        """
        Update the organization linked to the currently authenticated user's account.

        Args:
            organization_data: The organization data to update

        Returns:
            Updated organization details
        """
        url = f"{self.client.base_url}/v1/admin/organization/update"
        headers = self.client._get_auth_headers()
        response = self.client.session.put(url, headers=headers, json=organization_data.model_dump(exclude_none=True))
        data = self.client._handle_response(response=response, error_callable=raise_for_organization_detail)
        return Organization.model_validate(data)

    def delete_organization(self) -> None:
        """
        Permanently delete the organization associated with the currently authenticated user's account.
        """
        url = f"{self.client.base_url}/v1/admin/organization/delete"
        headers = self.client._get_auth_headers()
        response = self.client.session.delete(url, headers=headers)
        self.client._handle_response(response=response, error_callable=raise_for_organization_detail)
