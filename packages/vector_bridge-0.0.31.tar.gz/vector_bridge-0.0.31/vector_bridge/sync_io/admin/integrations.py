from typing import Any

from vector_bridge import VectorBridgeClient
from vector_bridge.schema.errors.integrations import raise_for_integration_detail
from vector_bridge.schema.integrations import Integration, IntegrationCreate
from vector_bridge.schema.user_integrations import UserIntegrationList


class IntegrationsAdmin:
    """Admin client for integrations management endpoints."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client

    def get_integrations_list(self) -> list[Integration]:
        """
        Get a list of all integrations.

        Returns:
            List of integration objects
        """
        url = f"{self.client.base_url}/v1/admin/integrations"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        data = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return [Integration.model_validate(item) for item in data]

    def get_integration_by_id(self, integration_id: str) -> Integration | None:
        """
        Get integration by ID.

        Args:
            integration_id: The integration ID

        Returns:
            Integration object
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        if response.status_code in [403, 404]:
            return None

        data = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return Integration.model_validate(data)

    def get_integration_by_name(self, integration_name: str | None = None) -> Integration | None:
        """
        Get integration by name.

        Args:
            integration_name: The integration name

        Returns:
            Integration object
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        if response.status_code in [403, 404]:
            return None

        data = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return Integration.model_validate(data)

    def add_integration(self, integration_data: IntegrationCreate) -> Integration:
        """
        Add a new integration.

        Args:
            integration_data: Integration details

        Returns:
            Created integration object
        """
        url = f"{self.client.base_url}/v1/admin/integration/add"
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, json=integration_data.model_dump())
        data = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return Integration.model_validate(data)

    def delete_integration(self, integration_name: str | None = None) -> list[Integration]:
        """
        Delete an integration.

        Args:
            integration_name: The name of the integration to delete

        Returns:
            List of remaining integrations
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/delete"
        params = {"integration_name": integration_name}
        headers = self.client._get_auth_headers()
        response = self.client.session.delete(url, headers=headers, params=params)
        data = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return [Integration.model_validate(item) for item in data]

    # --- User management by integration ID ---

    def add_user_to_integration_by_id(
        self,
        integration_id: str,
        user_id: str,
        security_group_ids: list[str],
    ) -> UserIntegrationList:
        """
        Add user to an Integration by integration ID.

        Args:
            integration_id: The integration ID
            user_id: The user id
            security_group_ids: The Security Groups

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/add-user/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def remove_user_from_integration_by_id(
        self,
        integration_id: str,
        user_id: str,
    ) -> UserIntegrationList:
        """
        Remove user from an Integration by integration ID.

        Args:
            integration_id: The integration ID
            user_id: The user id

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/remove-user/{user_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def update_users_security_group_by_id(
        self,
        integration_id: str,
        user_id: str,
        security_group_ids: list[str],
    ) -> UserIntegrationList:
        """
        Update user's security group in an integration by integration ID.

        Args:
            integration_id: The integration ID
            user_id: The user id
            security_group_ids: The Security Groups

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/update-users-security-group/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def get_users_from_integration_by_id(
        self,
        integration_id: str,
        limit: int = 25,
        last_evaluated_key: str | None = None,
    ) -> UserIntegrationList:
        """
        Get users in an Integration by integration ID.

        Args:
            integration_id: The integration ID
            limit: Number of users to return
            last_evaluated_key: Last evaluated key for pagination

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/users"
        params: dict[str, Any] = {"limit": limit}
        if last_evaluated_key:
            params["last_evaluated_key"] = last_evaluated_key

        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    # --- User management by integration name ---

    def add_user_to_integration_by_name(
        self,
        user_id: str,
        security_group_ids: list[str],
        integration_name: str | None = None,
    ) -> UserIntegrationList:
        """
        Add user to the Integration by name.

        Args:
            integration_name: The integration name
            user_id: The user id
            security_group_ids: The Security Groups

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/add-user/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    add_user_to_integration = add_user_to_integration_by_name

    def remove_user_from_integration_by_name(
        self,
        user_id: str,
        integration_name: str | None = None,
    ) -> UserIntegrationList:
        """
        Remove user from Integration by name.

        Args:
            integration_name: The integration name
            user_id: The user id

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/remove-user/{user_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    remove_user_from_integration = remove_user_from_integration_by_name

    def update_users_security_group_by_name(
        self,
        user_id: str,
        security_group_ids: list[str],
        integration_name: str | None = None,
    ) -> UserIntegrationList:
        """
        Update user's security group in an integration by name.

        Args:
            integration_name: The integration name
            user_id: The user id
            security_group_ids: The Security Groups

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = (
            f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/update-users-security-group/{user_id}"
        )
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    update_users_security_group = update_users_security_group_by_name

    def get_users_from_integration_by_name(
        self,
        limit: int = 25,
        integration_name: str | None = None,
        last_evaluated_key: str | None = None,
    ) -> UserIntegrationList:
        """
        Get users in an Integration by name.

        Args:
            integration_name: The integration name
            limit: Number of users to return
            last_evaluated_key: Last evaluated key for pagination

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/users"
        params: dict[str, Any] = {"limit": limit}
        if last_evaluated_key:
            params["last_evaluated_key"] = last_evaluated_key

        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    get_users_from_integration = get_users_from_integration_by_name

    # --- Security groups by ID ---

    def add_security_groups_by_id(
        self,
        integration_id: str,
        user_id: str,
        security_group_ids: list[str],
    ) -> UserIntegrationList:
        """
        Add security groups to a user-integration by integration ID.

        Appends the provided security groups without removing existing ones. Duplicates are skipped.

        Args:
            integration_id: The integration ID
            user_id: The user id
            security_group_ids: List of security group IDs to add

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/add-security-groups/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def add_security_groups_by_name(
        self,
        user_id: str,
        security_group_ids: list[str],
        integration_name: str | None = None,
    ) -> UserIntegrationList:
        """
        Add security groups to a user-integration by integration name.

        Appends the provided security groups without removing existing ones. Duplicates are skipped.

        Args:
            user_id: The user id
            security_group_ids: List of security group IDs to add
            integration_name: The integration name

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/add-security-groups/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def remove_security_groups_by_id(
        self,
        integration_id: str,
        user_id: str,
        security_group_ids: list[str],
    ) -> UserIntegrationList:
        """
        Remove security groups from a user-integration by integration ID.

        Removes only the specified security groups, leaving the rest intact.

        Args:
            integration_id: The integration ID
            user_id: The user id
            security_group_ids: List of security group IDs to remove

        Returns:
            Users list
        """
        url = f"{self.client.base_url}/v1/admin/integration/id/{integration_id}/remove-security-groups/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def remove_security_groups_by_name(
        self,
        user_id: str,
        security_group_ids: list[str],
        integration_name: str | None = None,
    ) -> UserIntegrationList:
        """
        Remove security groups from a user-integration by integration name.

        Removes only the specified security groups, leaving the rest intact.

        Args:
            user_id: The user id
            security_group_ids: List of security group IDs to remove
            integration_name: The integration name

        Returns:
            Users list
        """
        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/integration/name/{integration_name}/remove-security-groups/{user_id}"
        params = {"security_group_ids": security_group_ids}
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return UserIntegrationList.model_validate(result)

    def get_integration_names_of_a_user(self, user_id: str) -> dict[str, str]:
        """
        Get integration names that a user belongs to.

        Args:
            user_id: The user id

        Returns:
            Dictionary mapping integration IDs to integration names
        """
        url = f"{self.client.base_url}/v1/admin/integration_names/user/id/{user_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        result = self.client._handle_response(response=response, error_callable=raise_for_integration_detail)
        return result
