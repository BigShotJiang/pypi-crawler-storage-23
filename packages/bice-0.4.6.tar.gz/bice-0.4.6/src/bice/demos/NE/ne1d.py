"""1D Nikolaevskiy Equation demo using Pseudospectral method."""

#!/usr/bin/python3
import os
import shutil

import matplotlib.pyplot as plt
import numpy as np

from bice import Problem, time_steppers
from bice.pde import PseudospectralEquation


class NikolaevskiyEquation(PseudospectralEquation):
    r"""
    Pseudospectral implementation of the 1-dimensional Nikolaevskiy Equation.

    equation, a nonlinear PDE
    \partial t h &= -\Delta (r - (1+\Delta)^2) h - 1/2 (\nabla h)^2.
    """

    def __init__(self, N):
        """Initialize the equation."""
        # make sure N is even
        N = int(np.floor(N / 2) * 2)
        super().__init__(shape=N)
        # parameters
        self.r = 0.5  # drive
        self.m = 10  # characteristic system length
        # space and fourier space
        self.x = [np.linspace(0, 1, N)]
        self.build_kvectors(real_fft=True)
        # initial condition
        rng = np.random.default_rng()
        self.u = 2 * (rng.random(N) - 0.5) * 1e-5

    @property
    def L0(self):
        """Calculate characteristic length scale."""
        return 2 * np.pi / np.sqrt(1 + np.sqrt(self.r))

    def rhs(self, u):
        """Calculate the right-hand side of the equation."""
        # calculate the system length
        L = self.L0 * self.m
        # include length scale in the k-vector
        k = self.k[0] / L
        ksq = k**2
        # fourier transform
        u_k = np.fft.rfft(u)
        # calculate linear part (in fourier space)
        lin = ksq * (self.r - (1 - ksq) ** 2) * u_k
        # calculate nonlinear part (in real space)
        nonlin = np.fft.irfft(1j * k * u_k) ** 2
        # sum up and return
        return np.fft.irfft(lin) - 0.5 * nonlin

    def du_dx(self, u, direction=0):
        """Calculate the spatial derivative."""
        du_dx = 1j * self.k[direction] * np.fft.rfft(u)
        return np.fft.irfft(du_dx)

    def plot(self, ax):
        """Plot the solution."""
        ax.set_xlabel("x")
        ax.set_ylabel("h(x,t)")
        L = self.L0 * self.m
        ax.plot(self.x[0] * L, self.u)


class NikolaevskiyProblem(Problem):
    """Problem class for the 1D Nikolaevskiy equation."""

    def __init__(self, N):
        """Initialize the problem."""
        super().__init__()
        # Add the Nikolaevskiy equation to the problem
        self.ne = NikolaevskiyEquation(N)
        self.add_equation(self.ne)
        # initialize time stepper
        # self.time_stepper = time_steppers.RungeKutta4(dt=1e-7)
        # self.time_stepper = time_steppers.RungeKuttaFehlberg45(dt=1e-7, error_tolerance=1e-4)
        # self.time_stepper = time_steppers.BDF2(dt=1e-3)
        self.time_stepper = time_steppers.BDF(self, dt_max=1e-1)
        # assign the continuation parameter
        self.continuation_parameter = (self.ne, "m")

    def dealias(self, fraction=1.0 / 2.0):
        """Set higher modes to null, for numerical stability."""
        u_k = np.fft.rfft(self.ne.u)
        N = len(u_k)
        k = int(N * fraction)
        u_k[k + 1 :] = 0
        u_k[0] = 0
        self.ne.u = np.fft.irfft(u_k)

    def norm(self):
        """Return the L2-norm of the solution."""
        return np.linalg.norm(self.ne.u)


if __name__ == "__main__":
    # create output folder
    shutil.rmtree("out", ignore_errors=True)
    os.makedirs("out/img", exist_ok=True)

    # create problem
    problem = NikolaevskiyProblem(N=64)
    problem.ne.r = 0.5
    problem.ne.m = 1.1

    # create figure
    fig, ax = plt.subplots(1, 1, figsize=(16, 9))
    plotID = 0

    # time-stepping
    n = 0
    plotevery = 10
    dudtnorm = 1
    T = 100 / problem.ne.r
    while problem.time < T:
        # plot
        if n % plotevery == 0:
            problem.plot(ax)
            fig.savefig(f"out/img/{plotID:05d}.svg")
            plotID += 1
            print(f"step #: {n}")
            print(f"time:   {problem.time}")
            print(f"dt:     {problem.time_stepper.dt}")
            print(f"|dudt|: {dudtnorm}")
        n += 1
        # perform timestep
        problem.time_step()
        # perform dealiasing
        problem.dealias()
        # calculate the new norm
        dudtnorm = np.linalg.norm(problem.rhs(problem.u))
        # catch divergent solutions
        if np.max(problem.u) > 1e12:
            print("diverged")
            break
    # save the state, so we can reload it later
    problem.save("initial_state.npz")
