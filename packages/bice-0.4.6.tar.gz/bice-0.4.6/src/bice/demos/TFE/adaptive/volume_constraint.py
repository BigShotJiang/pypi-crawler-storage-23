"""Volume constraint implementation for the adaptive substrate TFE demo."""

import numpy as np
import scipy.sparse as sp

from bice.continuation import ConstraintEquation


class VolumeConstraint(ConstraintEquation):
    """
    A volume constraint (or mass constraint) for the adaptive substrate TFE.

    Assures the conservation of the integral of the unknowns of some given equation
    when solving the system. We may even prescribe the target volume (or mass)
    with a parameter, but we don't have to. The constraint equation comes with an
    additional (unknown) Lagrange multiplier that can be interpreted as an influx
    into the system.
    """

    def __init__(self, reference_equation):
        """Initialize the constraint."""
        super().__init__(shape=(1,))
        # on which equation/unknowns should the constraint be imposed?
        self.ref_eq = reference_equation
        # this equation brings a single extra degrees of freedom (influx Lagrange multiplier)
        self.u = np.zeros(1)
        # This parameter allows for prescribing a fixed volume (unless it is None)
        self.fixed_volume = None

    def rhs(self, u):
        """Calculate the right-hand side of the constraint."""
        # generate empty vector of residual contributions
        res = np.zeros(u.size)
        # reference to the indices of the unknowns that we work on
        self_idx = self.group.idx[self]
        eq_idx = self.group.idx[self.ref_eq]
        # split it into the parts that are referenced by the first two variables
        var_ndofs = np.prod(self.ref_eq.shape[1:])
        eq_idx1 = slice(eq_idx.start + 0 * var_ndofs, eq_idx.start + 1 * var_ndofs)
        slice(eq_idx.start + 1 * var_ndofs, eq_idx.start + 2 * var_ndofs)
        # employ the constraint equation
        # calculate the difference in volumes between current
        # and previous unknowns of the reference equation
        x = self.ref_eq.x[0]
        res[self_idx] = np.array(
            [
                np.trapezoid(u[eq_idx1] - self.group.u[eq_idx1], x),
            ]
        )
        # res[self_idx] = np.array([
        #     np.trapezoid(u[eq_idx1] + u[eq_idx2] -
        #              self.group.u[eq_idx1] - self.group.u[eq_idx2], x),
        # ])
        # Add the constraint to the reference equation: unknown influx is the Langrange multiplier
        res[eq_idx1] = u[self_idx][0]
        # res[eq_idx2] = u[self_idx][0]
        return res

    def jacobian(self, u):
        """Calculate the Jacobian of the constraint."""
        # TODO: implement analytical / semi-analytical Jacobian
        # convert FD Jacobian to sparse matrix
        return sp.csr_matrix(super().jacobian(u))
