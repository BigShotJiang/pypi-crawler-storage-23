"""Data structures for Solutions, Branches and BifurcationDiagrams."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .types import Array, Axes, DataDict, RealArray

if TYPE_CHECKING:
    from bice.core.problem import Problem


class Solution:
    """
    Stores the solution of a problem.

    Includes the relevant parameters and some information on the solution.
    """

    # static variable counting the total number of Solutions
    _solution_count = 0

    def __init__(self, problem: Problem | None = None) -> None:
        """
        Initialize the Solution.

        Parameters
        ----------
        problem
            The problem instance to store the state from.
        """
        # generate solution ID
        Solution._solution_count += 1
        #: unique identifier of the solution
        self.id = Solution._solution_count
        # TODO: storing each solution's data may eat up some memory
        #       do we need to save every solution? maybe save bifurcations only
        #: The current problem state as a dictionary of data (equation's unknowns and
        #: parameters)
        self.data: DataDict = problem.save() if problem is not None else {}

        # safely get continuation parameter if it exists
        if problem is not None and problem.continuation_parameter is not None:
            self.p: float = float(problem.get_continuation_parameter())
        else:
            self.p = 0.0

        #: value of the solution norm
        self.norm: float = float(problem.norm()) if problem is not None else 0.0
        #: number of true positive eigenvalues
        self.nunstable_eigenvalues: int | None = None
        #: number of true positive and imaginary eigenvalues
        self.nunstable_imaginary_eigenvalues: int | None = None
        #: optional reference to the corresponding branch
        self.branch: Branch | None = None
        # cache for the bifurcation type
        self._bifurcation_type: str | None = None

    @property
    def neigenvalues_crossed(self) -> int | None:
        """
        Return how many eigenvalues have crossed the imaginary axis.

        Returns
        -------
        int or None
            The number of eigenvalues crossed, or None if unknown.
        """
        # if we do not know the number of unstable eigenvalues, we have no result
        if self.branch is None or self.nunstable_eigenvalues is None:
            return None
        # else, compare with the nearest previous neighbor that has info on
        # eigenvalues
        # get branch points with eigenvalue info
        bps = [s for s in self.branch.solutions if s.nunstable_eigenvalues is not None]
        # find index of previous solution
        index = bps.index(self) - 1
        if index < 0:
            # if there is no previous solution with info on eigenvalues, we have no result
            return None
        # return the difference in unstable eigenvalues to the previous solution
        prev_neig = bps[index].nunstable_eigenvalues
        assert self.nunstable_eigenvalues is not None
        assert prev_neig is not None
        return self.nunstable_eigenvalues - prev_neig

    @property
    def nimaginary_eigenvalues_crossed(self) -> int | None:
        """
        Return how many eigenvalues have crossed the imaginary axis.

        Returns
        -------
        int or None
            The number of eigenvalues crossed, or None if unknown.
        """
        # if we do not know the number of unstable eigenvalues, we have no result
        if self.branch is None or self.nunstable_imaginary_eigenvalues is None:
            return None
        # else, compare with the nearest previous neighbor that has info on
        # eigenvalues
        # get branch points with eigenvalue info
        bps = [s for s in self.branch.solutions if s.nunstable_imaginary_eigenvalues is not None]
        # find index of previous solution
        index = bps.index(self) - 1
        if index < 0:
            # if there is no previous solution with info on eigenvalues, we have no result
            return None
        # return the difference in unstable eigenvalues to the previous solution
        prev_neig = bps[index].nunstable_imaginary_eigenvalues
        assert self.nunstable_imaginary_eigenvalues is not None
        assert prev_neig is not None
        return self.nunstable_imaginary_eigenvalues - prev_neig

    def is_stable(self) -> bool | None:
        """
        Check if the solution is stable.

        Returns
        -------
        bool or None
            True if stable, False if unstable, None if unknown.
        """
        # if we don't know the number of eigenvalues, return None
        if self.nunstable_eigenvalues is None:
            return None
        # if there is any true positive eigenvalues, the solution is not stable
        if self.nunstable_eigenvalues > 0:
            return False
        # otherwise, the solution is considered to be stable (or metastable at least)
        return True

    def is_bifurcation(self) -> bool:
        """
        Check if the solution point is a bifurcation.

        Returns
        -------
        bool
            True if it is a bifurcation point.
        """
        # get bifurcation type (possibly from cache)
        bif_type = self.bifurcation_type()
        # if it is not a regular point, return True
        return bif_type not in [None, ""]

    # TODO: rename to "type" ? bifurcation.bifurcation_type() looks weird...
    def bifurcation_type(self, update: bool = False) -> str:
        """
        Return the type of bifurcation.

        Parameters
        ----------
        update
            Force update of the cached type.

        Returns
        -------
        str
            The bifurcation type string (e.g., "BP", "HP", "+", "-").
        """
        # check if bifurcation type is cached
        if self._bifurcation_type is not None and not update:
            return self._bifurcation_type
        # check for number of eigenvalues that crossed zero
        nev_crossed = self.neigenvalues_crossed
        # if unknown or no eigenvalues crossed zero, the point is no bifurcation
        if nev_crossed is None or nev_crossed == 0:
            self._bifurcation_type = ""
            return self._bifurcation_type
        # otherwise it is some kind of bifurcation point (BP)
        # self._bifurcation_type = "BP"
        # use +/- signs corresponding to their null-eigenvalues as type for
        # regular bifurcations
        n = nev_crossed
        self._bifurcation_type = "+" * n if n > 0 else "-" * (-n)
        # check for Hopf bifurcations by number of imaginary eigenvalues that
        # crossed zero
        nev_imag_crossed = self.nimaginary_eigenvalues_crossed
        # if it is not unknown or zero or one, this must be a Hopf point
        if nev_imag_crossed not in [None, 0, 1]:
            self._bifurcation_type = "HP"
        # return type
        return self._bifurcation_type

    def get_neighboring_solution(self, distance: int) -> Solution | None:
        """
        Get access to the neighboring solution in the branch.

        Parameters
        ----------
        distance
            The index distance (can be negative).

        Returns
        -------
        Solution or None
            The neighboring solution or None if not found/out of bounds.
        """
        # if we don't know the branch, there is no neighboring solutions
        if self.branch is None:
            return None
        index = self.branch.solutions.index(self) + distance
        # if index out of range, there is no neighbor at requested distance
        if index < 0 or index >= len(self.branch.solutions):
            return None
        # else, return the neighbor
        return self.branch.solutions[index]


class Branch:
    """Stores a list of solution objects from a parameter continuation."""

    # static variable counting the number of Branch instances
    _branch_count = 0

    def __init__(self) -> None:
        """Initialize the Branch."""
        # generate branch ID
        Branch._branch_count += 1
        #: unique identifier of the branch
        self.id = Branch._branch_count
        #: list of solutions along the branch
        self.solutions: list[Solution] = []

    def is_empty(self) -> bool:
        """Check if the current branch is empty."""
        return len(self.solutions) == 0

    def add_solution_point(self, solution: Solution) -> None:
        """
        Add a solution to the branch.

        Parameters
        ----------
        solution
            The solution object to add.
        """
        # assign this branch as the solution's branch
        solution.branch = self
        # add solution to list
        self.solutions.append(solution)

    def remove_solution_point(self, solution: Solution) -> None:
        """
        Remove a solution from the branch.

        Parameters
        ----------
        solution
            The solution object to remove.
        """
        self.solutions.remove(solution)

    def parameter_vals(self) -> RealArray:
        """
        List of continuation parameter values along the branch.

        Returns
        -------
        RealArray
            Array of parameter values.
        """
        return np.array([s.p for s in self.solutions], dtype=np.float64)

    def norm_vals(self) -> RealArray:
        """
        List of solution norm values along the branch.

        Returns
        -------
        RealArray
            Array of norm values.
        """
        return np.array([s.norm for s in self.solutions], dtype=np.float64)

    def bifurcations(self) -> list[Solution]:
        """
        List all bifurcation points on the branch.

        Returns
        -------
        list
            List of solutions that are bifurcation points.
        """
        return [s for s in self.solutions if s.is_bifurcation()]

    def data(self, only: str | None = None) -> tuple[RealArray, RealArray]:
        """
        Return the list of parameters and norms of the branch.

        Parameters
        ----------
        only
            Optional filter: "stable", "unstable", or "bifurcations".

        Returns
        -------
        tuple[RealArray, RealArray]
            Tuple of (parameter values, norm values).
        """
        condition: list[bool] | Array = np.array([False] * len(self.solutions))
        if only == "stable":
            condition = [not s.is_stable() for s in self.solutions]
        elif only == "unstable":
            condition = [bool(s.is_stable()) for s in self.solutions]
        elif only == "bifurcations":
            condition = [not s.is_bifurcation() for s in self.solutions]
        # mask lists where condition is met and return
        cond_arr = np.asarray(condition, dtype=bool)
        pvals = np.ma.masked_where(cond_arr, self.parameter_vals())
        nvals = np.ma.masked_where(cond_arr, self.norm_vals())
        return (np.asanyarray(pvals), np.asanyarray(nvals))

    def save(self, filename: str) -> None:
        """
        Store the branch to the disk.

        Parameters
        ----------
        filename
            The filename to save to.
        """
        # dict of data to store
        data: DataDict = {}
        data["solution_data"] = [s.data for s in self.solutions]
        data["norm"] = [s.norm for s in self.solutions]
        data["p"] = [s.p for s in self.solutions]
        data["nunstable_eigenvalues"] = [s.nunstable_eigenvalues for s in self.solutions]
        # save everything to the file
        np.savez(
            filename,
            solution_data=np.array([s.data for s in self.solutions], dtype=object),
            norm=np.array([s.norm for s in self.solutions]),
            p=np.array([s.p for s in self.solutions]),
            nunstable_eigenvalues=np.array([s.nunstable_eigenvalues for s in self.solutions]),
            nunstable_imaginary_eigenvalues=np.array([s.nunstable_imaginary_eigenvalues for s in self.solutions]),
        )


class BifurcationDiagram:
    """
    Manages a collection of branches.

    Includes methods for plotting.
    """

    def __init__(self) -> None:
        """Initialize the BifurcationDiagram."""
        #: list of branches
        self.branches: list[Branch] = []
        #: storage for the currently active branch
        self.active_branch: Branch = self.new_branch()
        #: name of the continuation parameter
        self.parameter_name: str | None = None
        #: name of the norm
        self.norm_name = "norm"
        #: x-limits of the diagram
        self.xlim: tuple[float, float] | None = None
        #: y-limits of the diagram
        self.ylim: tuple[float, float] | None = None

    def new_branch(self, active: bool = True) -> Branch:
        """
        Create a new branch.

        Parameters
        ----------
        active
            Whether to set the new branch as active.

        Returns
        -------
        Branch
            The newly created branch.
        """
        branch = Branch()
        self.branches.append(branch)
        if active:
            self.active_branch = branch
        return branch

    def current_solution(self) -> Solution:
        """
        Return the latest solution in the diagram.

        Returns
        -------
        Solution
            The latest solution of the active branch.
        """
        return self.active_branch.solutions[-1]

    def get_branch_by_ID(self, branch_id: int) -> Branch | None:
        """
        Return a branch by its ID.

        Parameters
        ----------
        branch_id
            The ID of the branch.

        Returns
        -------
        Branch or None
            The branch object or None if not found.
        """
        for branch in self.branches:
            if branch.id == branch_id:
                return branch
        return None

    def remove_branch_by_ID(self, branch_id: int) -> None:
        """
        Remove a branch from the BifurcationDiagram by its ID.

        Parameters
        ----------
        branch_id
            The ID of the branch to remove.
        """
        self.branches = [b for b in self.branches if b.id != branch_id]

    def plot(self, ax: Axes) -> None:
        """
        Plot the bifurcation diagram.

        Parameters
        ----------
        ax
            The matplotlib axes to plot onto.
        """
        if self.xlim is not None:
            ax.set_xlim(self.xlim)
        if self.ylim is not None:
            ax.set_ylim(self.ylim)
        # plot every branch separately
        for branch in self.branches:
            p, norm = branch.data()
            # ax.plot(p, norm, "o", color="C0")
            ax.plot(p, norm, linewidth=0.7, color="C0")
            p, norm = branch.data(only="stable")
            ax.plot(p, norm, linewidth=1.8, color="C0")
            p, norm = branch.data(only="bifurcations")
            ax.plot(p, norm, "*", color="C2")
            # annotate bifurcations with their types
            for bif in branch.bifurcations():
                s = bif.bifurcation_type()
                ax.annotate(" " + s, (bif.p, bif.norm))
        ax.plot(np.nan, np.nan, "*", color="C2", label="bifurcations")
        ax.set_xlabel(self.parameter_name if self.parameter_name else "parameter")
        ax.set_ylabel(self.norm_name)
        ax.legend()

    def load_branch(self, filename: str) -> None:
        """
        Load a branch from a file into the diagram.

        The file should have been stored with Branch.save(filename).

        Parameters
        ----------
        filename
            The filename to load from.
        """
        # create a new branch
        branch = self.new_branch(active=False)
        # load data dictionary from the file
        data = np.load(filename, allow_pickle=True)
        # restore the solutions and their data
        for i in range(len(data["norm"])):
            sol = Solution()
            sol.data = data["solution_data"][i]
            sol.norm = data["norm"][i]
            sol.p = data["p"][i]
            sol.nunstable_eigenvalues = data["nunstable_eigenvalues"][i]
            sol.nunstable_imaginary_eigenvalues = data["nunstable_imaginary_eigenvalues"][i]
            branch.add_solution_point(sol)
