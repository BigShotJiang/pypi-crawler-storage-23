"""Export a trained Q-table to a valid workflow JSON.

Reads a checkpoint directory (qtable.npz + training_config.json + metadata.json),
infers AP dependencies from visit patterns, and produces a workflow JSON that
can be loaded by ``build_workflow()``.

Usage::

    uv run python -m atomicguard.tools.export_workflow \\
        --checkpoint output/rl_training/<run>/latest \\
        --base-workflow examples/swe_bench_common/workflows/31_django_full_discovery.json \\
        --output exported_workflow.json

The ``--base-workflow`` provides generator, guard, guard_config, description,
artifact_type, and other AP metadata that the Q-table does not capture. The
exported workflow preserves all base fields and overrides ``requires`` with
dependencies inferred from the Q-table's visit patterns.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from collections import deque
from pathlib import Path
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_training_artifacts(
    checkpoint_dir: Path,
) -> tuple[Any, dict[str, Any], dict[str, Any]]:
    """Load Q-table, training config, and checkpoint metadata.

    Args:
        checkpoint_dir: Path to a checkpoint directory (containing qtable.npz)
            or to the top-level run directory (with latest/ symlink).

    Returns:
        Tuple of (policy, training_config, metadata).
    """
    from atomicguard.infrastructure.rl.policy import TabularPolicy

    # Resolve to the actual checkpoint dir
    if (checkpoint_dir / "latest").exists():
        checkpoint_dir = (checkpoint_dir / "latest").resolve()

    qtable_path = checkpoint_dir / "qtable.npz"
    if not qtable_path.exists():
        raise FileNotFoundError(f"No qtable.npz found in {checkpoint_dir}")

    # Load Q-table to get AP IDs
    data = np.load(qtable_path, allow_pickle=True)
    ap_ids = tuple(str(x) for x in data["ap_ids"])
    n = len(ap_ids)

    policy = TabularPolicy(num_action_pairs=n, action_pair_ids=ap_ids)
    policy.load(checkpoint_dir)

    # Load training config (may be in parent dir)
    config_path = checkpoint_dir / "training_config.json"
    if not config_path.exists():
        config_path = checkpoint_dir.parent / "training_config.json"
    training_config = {}
    if config_path.exists():
        training_config = json.loads(config_path.read_text())

    # Load metadata
    meta_path = checkpoint_dir / "metadata.json"
    metadata = {}
    if meta_path.exists():
        metadata = json.loads(meta_path.read_text())

    return policy, training_config, metadata


# ---------------------------------------------------------------------------
# Dependency inference
# ---------------------------------------------------------------------------


def infer_dependencies(policy: Any, ap_ids: tuple[str, ...]) -> dict[str, list[str]]:
    """Infer AP dependencies from Q-table visit patterns.

    For each target AP (index i), looks at all states where the policy
    visited that action (visit_count[:, i] > 0). If another AP (index j)
    has its bit set in ALL those visited states, then j is a required
    dependency of i.

    Args:
        policy: A TabularPolicy with Q and visit_count arrays.
        ap_ids: Ordered tuple of AP ID strings.

    Returns:
        Dict mapping AP ID -> list of required dependency AP IDs.
    """
    visit_count = policy.visit_count
    deps: dict[str, list[str]] = {ap_id: [] for ap_id in ap_ids}

    for i, target_ap in enumerate(ap_ids):
        # Find all state indices where this AP was visited
        visited_mask = visit_count[:, i] > 0
        visited_states = np.where(visited_mask)[0]

        if len(visited_states) == 0:
            continue

        for j, candidate_ap in enumerate(ap_ids):
            if i == j:
                continue
            # Check if bit j is set in ALL visited states
            bit_mask = 1 << j
            all_set = all(int(s) & bit_mask for s in visited_states)
            if all_set:
                deps[target_ap].append(candidate_ap)

    return deps


def extract_greedy_ordering(policy: Any, ap_ids: tuple[str, ...]) -> list[str]:
    """Follow greedy policy from empty state to get happy-path AP ordering.

    Simulates execution from an empty satisfied set, greedily picking
    the highest Q-value action at each step.

    Args:
        policy: A TabularPolicy.
        ap_ids: Ordered tuple of AP ID strings.

    Returns:
        List of AP IDs in greedy execution order.
    """
    from atomicguard.domain.rl.state import State

    n = len(ap_ids)
    satisfied: frozenset[str] = frozenset()
    ordering: list[str] = []

    for _ in range(n):
        available = frozenset(ap_id for ap_id in ap_ids if ap_id not in satisfied)
        if not available:
            break

        state = State(satisfied=satisfied, available=available)
        state_idx = policy.encode_state(state)

        # Find best valid action
        q_values = policy.Q[state_idx]
        best_idx = -1
        best_q = -float("inf")
        for idx, ap_id in enumerate(ap_ids):
            if ap_id in available and q_values[idx] > best_q:
                best_q = q_values[idx]
                best_idx = idx

        if best_idx < 0:
            break

        selected = ap_ids[best_idx]
        ordering.append(selected)
        satisfied = satisfied | {selected}

    return ordering


# ---------------------------------------------------------------------------
# Workflow JSON construction
# ---------------------------------------------------------------------------


def build_workflow_json(
    ap_ids: tuple[str, ...],
    inferred_deps: dict[str, list[str]],
    base_workflow: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Merge inferred dependencies onto a base workflow JSON.

    Preserves all fields from the base workflow (generator, guard,
    guard_config, description, artifact_type, group, r_patience, etc.)
    and overrides ``requires`` with the inferred dependencies.

    APs present in ap_ids but missing from base_workflow are included
    with minimal stub entries. APs in base_workflow but not in ap_ids
    are dropped.

    Args:
        ap_ids: Ordered tuple of AP IDs from the trained policy.
        inferred_deps: Dict mapping AP ID -> list of dependency AP IDs.
        base_workflow: Parsed base workflow JSON dict.
        metadata: Optional training metadata to include in output.

    Returns:
        Complete workflow JSON dict ready for serialization.
    """
    base_aps = base_workflow.get("action_pairs", {})

    # Build output action_pairs preserving AP ordering from training
    output_aps: dict[str, Any] = {}
    for ap_id in ap_ids:
        if ap_id in base_aps:
            entry = dict(base_aps[ap_id])
        else:
            # Stub for APs not in base workflow
            entry = {
                "generator": "UnknownGenerator",
                "guard": "unknown",
                "guard_config": {},
                "description": f"AP {ap_id} (no base workflow entry)",
            }

        # Override requires with inferred dependencies
        deps = inferred_deps.get(ap_id, [])
        if deps:
            entry["requires"] = deps
        elif "requires" in entry:
            del entry["requires"]

        output_aps[ap_id] = entry

    output: dict[str, Any] = {
        "name": base_workflow.get("name", "Exported Workflow"),
        "description": base_workflow.get("description", "Exported from Q-table"),
        "model": base_workflow.get("model", ""),
        "provider": base_workflow.get("provider", ""),
        "rmax": base_workflow.get("rmax", 3),
        "action_pairs": output_aps,
    }

    if metadata:
        output["_export_metadata"] = {
            "total_episodes": metadata.get("total_episodes"),
            "mean_reward": metadata.get("mean_reward"),
            "epsilon": metadata.get("epsilon"),
        }

    return output


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_workflow(workflow_json: dict[str, Any]) -> list[str]:
    """Validate referential integrity and check for cycles.

    Args:
        workflow_json: Parsed workflow JSON dict.

    Returns:
        List of warning/error strings. Empty means valid.
    """
    warnings: list[str] = []
    aps = workflow_json.get("action_pairs", {})
    ap_ids = set(aps.keys())

    # Check referential integrity
    for ap_id, config in aps.items():
        for dep in config.get("requires", []):
            if dep not in ap_ids:
                warnings.append(
                    f"AP '{ap_id}' requires '{dep}' which is not in the workflow"
                )
        for dep in config.get("escalate_feedback_to", []):
            if dep not in ap_ids:
                warnings.append(
                    f"AP '{ap_id}' escalates to '{dep}' which is not in the workflow"
                )

    # Check for cycles via topological sort attempt
    in_degree: dict[str, int] = dict.fromkeys(ap_ids, 0)
    for ap_id, config in aps.items():
        for dep in config.get("requires", []):
            if dep in in_degree:
                in_degree[ap_id] += 1

    queue: deque[str] = deque(ap_id for ap_id, d in in_degree.items() if d == 0)
    sorted_count = 0
    while queue:
        current = queue.popleft()
        sorted_count += 1
        for ap_id, config in aps.items():
            if current in config.get("requires", []):
                in_degree[ap_id] -= 1
                if in_degree[ap_id] == 0:
                    queue.append(ap_id)

    if sorted_count < len(ap_ids):
        cycle_members = [ap_id for ap_id, d in in_degree.items() if d > 0]
        warnings.append(f"Dependency cycle detected involving: {cycle_members}")

    return warnings


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point for Q-table to workflow JSON export."""
    parser = argparse.ArgumentParser(
        description="Export a trained Q-table to a workflow JSON file.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        required=True,
        help="Path to checkpoint directory (containing qtable.npz) or run directory",
    )
    parser.add_argument(
        "--base-workflow",
        type=Path,
        required=True,
        help="Base workflow JSON to merge AP metadata from",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output file path (default: stdout)",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate the base workflow, don't export",
    )
    parser.add_argument(
        "--show-ordering",
        action="store_true",
        help="Print the greedy policy ordering",
    )

    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    # Load base workflow
    base_workflow = json.loads(args.base_workflow.read_text())

    if args.validate_only:
        warnings = validate_workflow(base_workflow)
        if warnings:
            for w in warnings:
                print(f"  WARNING: {w}", file=sys.stderr)
            sys.exit(1)
        else:
            print("Workflow is valid.")
            sys.exit(0)

    # Load training artifacts
    policy, training_config, metadata = load_training_artifacts(args.checkpoint)
    ap_ids = tuple(training_config.get("ap_ids", []))
    if not ap_ids:
        # Fall back to policy's AP IDs
        ap_ids = policy._ap_ids

    logger.info("Loaded Q-table with %d APs: %s", len(ap_ids), list(ap_ids))

    # Show greedy ordering if requested
    if args.show_ordering:
        ordering = extract_greedy_ordering(policy, ap_ids)
        print("Greedy policy ordering:")
        for i, ap_id in enumerate(ordering, 1):
            print(f"  {i}. {ap_id}")
        print()

    # Infer dependencies
    inferred_deps = infer_dependencies(policy, ap_ids)
    logger.info("Inferred dependencies:")
    for ap_id, deps in inferred_deps.items():
        if deps:
            logger.info("  %s requires %s", ap_id, deps)

    # Build workflow JSON
    workflow = build_workflow_json(ap_ids, inferred_deps, base_workflow, metadata)

    # Validate
    warnings = validate_workflow(workflow)
    if warnings:
        for w in warnings:
            print(f"  WARNING: {w}", file=sys.stderr)

    # Output
    output_json = json.dumps(workflow, indent=2) + "\n"
    if args.output:
        args.output.write_text(output_json)
        logger.info("Exported workflow to %s", args.output)
    else:
        print(output_json)
