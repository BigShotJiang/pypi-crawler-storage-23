"""Entry point for ``python -m atomicguard.tools``."""

from atomicguard.tools.export_workflow import main

main()
