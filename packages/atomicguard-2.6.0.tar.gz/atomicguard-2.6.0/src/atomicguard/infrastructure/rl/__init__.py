"""
RL infrastructure implementations.

Contains framework-specific code (gymnasium, torch) that implements
domain interfaces. These modules require the 'rl' optional dependency group.
"""
