"""
Policy checkpoint save/load utilities.

Handles serialization of policy state and training metadata (JSON)
for resumable training. Depends on PersistablePolicyInterface domain
port, not on any concrete policy implementation.

Requires: numpy (transitive dep)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import PersistablePolicyInterface


@dataclass(frozen=True)
class CheckpointMetadata:
    """Metadata stored alongside policy weights."""

    epoch: int
    total_episodes: int
    mean_reward: float
    checkpoint_path: str
    epsilon: float = 0.0
    env_state: dict | None = None


def save_checkpoint(
    path: Path,
    policy: PersistablePolicyInterface,
    metadata: CheckpointMetadata,
) -> Path:
    """Save policy state and metadata to directory.

    Writes:
    - Policy state (format determined by implementation)
    - metadata.json — training progress

    Args:
        path: Directory to save checkpoint into.
        policy: Policy implementing PersistablePolicyInterface.
        metadata: Training metadata.

    Returns:
        Path to saved checkpoint directory.
    """
    policy.save(path)

    meta_dict: dict = {
        "epoch": metadata.epoch,
        "total_episodes": metadata.total_episodes,
        "mean_reward": metadata.mean_reward,
        "checkpoint_path": str(path),
        "epsilon": metadata.epsilon,
    }
    if metadata.env_state is not None:
        meta_dict["env_state"] = metadata.env_state
    with open(path / "metadata.json", "w") as f:
        json.dump(meta_dict, f, indent=2)

    return path


def load_checkpoint(
    path: Path,
    policy: PersistablePolicyInterface,
) -> CheckpointMetadata:
    """Load policy state and metadata from directory.

    Args:
        path: Path to checkpoint directory.
        policy: Policy implementing PersistablePolicyInterface.

    Returns:
        CheckpointMetadata from the saved checkpoint.
    """
    policy.load(path)

    with open(path / "metadata.json") as f:
        meta_dict = json.load(f)

    return CheckpointMetadata(
        epoch=meta_dict["epoch"],
        total_episodes=meta_dict["total_episodes"],
        mean_reward=meta_dict["mean_reward"],
        checkpoint_path=meta_dict["checkpoint_path"],
        epsilon=meta_dict.get("epsilon", 0.0),
        env_state=meta_dict.get("env_state"),
    )
