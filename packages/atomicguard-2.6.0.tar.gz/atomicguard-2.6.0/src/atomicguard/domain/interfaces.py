"""
Domain interfaces (Ports) for the Dual-State Framework.

These abstract base classes define the contracts that implementations must satisfy.
They have no external dependencies and represent the core domain boundaries.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from pathlib import Path

    from atomicguard.domain.models import (
        Artifact,
        Context,
        GuardResult,
    )
    from atomicguard.domain.prompts import PromptTemplate
    from atomicguard.domain.rl.reward import RewardSignal
    from atomicguard.domain.rl.state import State
    from atomicguard.domain.rl.transitions import Transition


class GeneratorInterface(ABC):
    """
    Port for artifact generation.

    Implementations connect to LLMs or other generation sources.

    Note (Hierarchical Composition & Semantic Agency):
        The generator is not constrained to a single inference step. It may be
        instantiated as an autonomous Semantic Agent (ReAct loop, CoT reasoning,
        multi-tool orchestration) operating within the stochastic environment.
        From the workflow's perspective, this agentic process is atomic — the
        Workflow State tracks only the final artifact's validity via the Guard.

    Note (Side Effects & Idempotency):
        While generate() formally produces an artifact, implementations
        may induce side effects (filesystem I/O, API calls). In such cases:
        1. The artifact serves as a receipt/manifest of the operation
        2. Guards act as sensors verifying environmental state
        3. Side-effecting generators MUST be idempotent for retry safety
    """

    @abstractmethod
    def generate(
        self,
        context: "Context",
        template: "PromptTemplate",
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> "Artifact":
        """
        Generate an artifact based on context.

        Args:
            context: The generation context including specification and feedback
            template: Prompt template for structured generation
            action_pair_id: Identifier for the action pair requesting generation
            workflow_id: UUID of the workflow execution instance
            workflow_ref: Content-addressed workflow hash (Extension 01, Def 11)

        Returns:
            A new Artifact containing the generated content
        """
        pass


class GuardInterface(ABC):
    """
    Port for artifact validation.

    Guards are deterministic validators that return ⊤ (pass) or ⊥ (fail with feedback).
    """

    @abstractmethod
    def validate(
        self, artifact: "Artifact", **dependencies: "Artifact"
    ) -> "GuardResult":
        """
        Validate an artifact.

        Args:
            artifact: The artifact to validate
            **dependencies: Artifacts from prior workflow steps (key -> Artifact)

        Returns:
            GuardResult with passed=True/False and optional feedback
        """
        pass


class PolicyInterface(ABC):
    """
    Port for RL policy inference — the learned workflow.

    A trained policy IS a workflow. It maps state (which action pairs
    are satisfied, which are available) to the next action pair index
    to execute. Following a trained policy produces a sequence of
    action pair executions — which is exactly what a workflow is.

    Hand-crafted JSON workflow configs and trained policies are two
    representations of the same concept: "given this state, execute
    this action pair next."

    The policy is stateless at inference time — all state is in the State.
    """

    @abstractmethod
    def select_action(self, state: "State") -> int:
        """
        Select which action pair to execute next.

        This is the core workflow-discovery decision: given which action
        pairs have been satisfied and which are available, which one
        should the agent execute next?

        Args:
            state: Current workflow state — which action pairs are
                satisfied and which are available.

        Returns:
            Index into the action pair pool.
        """
        pass


class TrainablePolicyInterface(PolicyInterface):
    """
    Port for RL policy training — learning to build workflows.

    Extends PolicyInterface with the learning contract: state encoding,
    Q-value access, learning updates, and exploration control.

    During training, the agent explores different action pair sequences
    (i.e., different workflows) and learns which sequences solve tasks.
    The Q-values encode "how good is it to select action pair X in state S?"
    — converged Q-values define the optimal workflow.

    Inference-only consumers (RLAgent) use PolicyInterface.
    Training consumers (Trainer) use TrainablePolicyInterface.
    """

    @abstractmethod
    def encode_state(self, state: "State") -> int:
        """Encode a State into a discrete state index.

        Each policy implementation defines its own encoding strategy.
        For tabular Q-learning, this maps the satisfied/available
        frozensets to an integer index.

        Args:
            state: Current workflow state (satisfied + available APs).

        Returns:
            Integer state index for the policy's internal representation.
        """
        pass

    @abstractmethod
    def get_max_q_value(self, state_idx: int) -> float:
        """Return the maximum Q-value for a given state.

        Used for computing TD targets during training.

        Args:
            state_idx: Encoded state index.

        Returns:
            Maximum Q-value across all actions for this state.
        """
        pass

    @abstractmethod
    def update(self, state_idx: int, action_idx: int, td_target: float) -> None:
        """Update the policy given a training signal.

        Args:
            state_idx: Encoded state index.
            action_idx: Action index.
            td_target: The TD target value.
        """
        pass

    @abstractmethod
    def set_exploration(self, enabled: bool) -> None:
        """Toggle exploration on or off.

        Used during evaluation to disable epsilon-greedy (or equivalent).

        Args:
            enabled: True for exploration mode, False for greedy mode.
        """
        pass

    @abstractmethod
    def get_exploration_rate(self) -> float:
        """Return current exploration rate (for logging).

        Returns:
            Current exploration rate (e.g., epsilon value).
        """
        pass


class ActionPairPoolInterface(ABC):
    """
    Port exposing available action pairs for RL training environments.

    Provides the set of action pairs the RL agent can choose from.
    During training, the agent learns which action pairs to select
    and in what order — effectively discovering a workflow. This
    interface exposes the action pair pool, not a fixed execution plan.
    """

    @abstractmethod
    def get_available_action_pair_count(self) -> int:
        """Return the number of available action pairs in the pool."""
        pass

    @abstractmethod
    def get_max_retries(self) -> int:
        """Return the maximum retry count (rmax) per action pair."""
        pass

    @abstractmethod
    def get_available_action_pairs(self) -> tuple["ActionPairInfo", ...]:
        """Return the pool of action pairs the agent can choose from.

        Returns:
            Tuple of ActionPairInfo objects — the agent's action space.
        """
        pass

    @abstractmethod
    def get_satisfied_action_pairs(self) -> tuple[str, ...]:
        """Return IDs of action pairs whose guards have passed.

        Returns:
            Tuple of action pair ID strings for satisfied action pairs.
        """
        pass


class PersistablePolicyInterface(TrainablePolicyInterface):
    """
    Port for RL policy persistence — saving and loading learned workflows.

    A saved policy is a portable workflow that any agent can load and
    follow. Extends TrainablePolicyInterface with save/load contract
    for checkpointing during training and deployment at inference time.
    """

    @abstractmethod
    def save(self, path: "Path") -> None:
        """Save policy state to a directory.

        Args:
            path: Directory to save into.
        """
        pass

    @abstractmethod
    def load(self, path: "Path") -> None:
        """Load policy state from a directory or file.

        Args:
            path: Path to checkpoint directory or file.
        """
        pass


class ActionPairInfo:
    """
    Domain-level view of an available action pair for RL environments.

    Represents one action pair the RL agent can choose to execute.
    Decouples infrastructure (TrainingEnvironment) from application-layer
    WorkflowStep by exposing only the attributes needed for RL training.
    """

    __slots__ = (
        "action_pair_id",
        "action_pair",
        "requires",
        "escalate_feedback_to",
        "r_patience",
        "requires_any",
        "group",
        "artifact_type",
    )

    def __init__(
        self,
        action_pair_id: str,
        action_pair: "ActionPairInterface",
        requires: tuple[str, ...] = (),
        escalate_feedback_to: tuple[str, ...] = (),
        r_patience: int | None = None,
        requires_any: tuple[tuple[str, ...], ...] = (),
        group: str | None = None,
        artifact_type: str | None = None,
    ) -> None:
        self.action_pair_id = action_pair_id
        self.action_pair = action_pair
        self.requires = requires
        self.escalate_feedback_to = escalate_feedback_to
        self.r_patience = r_patience
        self.requires_any = requires_any
        self.group = group
        self.artifact_type = artifact_type


class ActionPairInterface(ABC):
    """
    Port for the generate-then-validate transaction.

    Allows TrainingEnvironment to call execute() without coupling to the
    concrete ActionPair in the application layer.
    """

    @abstractmethod
    def execute(
        self,
        context: "Context",
        dependencies: dict[str, "Artifact"],
        action_pair_id: str,
        workflow_id: str,
        artifact_type: str | None = None,
    ) -> tuple["Artifact", "GuardResult"]:
        """Execute the generate-then-validate transaction.

        Args:
            context: The generation context.
            dependencies: Artifacts from prior workflow steps.
            action_pair_id: Identifier for this action pair.
            workflow_id: UUID of the workflow execution instance.
            artifact_type: Semantic type tag for the produced artifact.

        Returns:
            Tuple of (artifact, guard_result).
        """
        pass


class EnvironmentInterface(ABC):
    """
    Port for RL training environments — where the agent discovers workflows.

    Each episode is one attempt at solving a task by selecting action pairs.
    The agent observes which action pairs are satisfied and available,
    selects which action pair index to execute next, and receives reward
    from guards. A successful episode trace IS a discovered workflow.

    Defines the state-action-reward loop contract that the Trainer drives.
    Decouples the training layer from infrastructure (TrainingEnvironment).
    """

    @abstractmethod
    def reset(self) -> "State":
        """Reset to the start of a fresh episode (no action pairs satisfied).

        Returns:
            Initial state with all action pairs available, none satisfied.
        """
        pass

    @abstractmethod
    def execute_step(self, action: int) -> tuple["State", "RewardSignal", bool]:
        """Execute one agent decision and return the outcome.

        The agent selects an action pair index to execute. The environment
        runs it, the guard evaluates, and the resulting state reflects
        which action pairs are now satisfied.

        Args:
            action: Index into the action pair pool — which AP to execute.

        Returns:
            Tuple of (next_state, reward_signal, done).
        """
        pass

    @abstractmethod
    def get_episode_stats(self) -> dict[str, Any]:
        """Return environment-level episode statistics.

        Called by the Trainer after each episode to collect metrics
        that only the environment can observe (e.g. total LLM tokens,
        backtrack count).

        Returns:
            Dict with environment-specific metrics.
        """
        pass

    def get_state(self) -> dict[str, Any]:
        """Return serialisable environment state for checkpoint persistence.

        Override in subclasses that track episode-level counters
        (e.g. ``_episode_number``, ``_current_idx``) to enable
        correct resume after checkpoint reload.

        Returns:
            Dict of state to persist (empty by default).
        """
        return {}

    def set_state(self, state: dict[str, Any]) -> None:  # noqa: B027
        """Restore environment state from a checkpoint.

        Args:
            state: Dict previously returned by :meth:`get_state`.
        """


class ExperienceBufferInterface(ABC):
    """
    Port for experience replay storage.

    Decouples the training layer from infrastructure (ReplayBuffer).
    """

    @abstractmethod
    def push(self, transition: "Transition") -> None:
        """Store a transition.

        Args:
            transition: Experience tuple to store.
        """
        pass

    @abstractmethod
    def sample(self, batch_size: int) -> list["Transition"]:
        """Sample a random batch of transitions.

        Args:
            batch_size: Number of transitions to sample.

        Returns:
            List of sampled transitions.
        """
        pass

    @abstractmethod
    def __len__(self) -> int:
        """Return the number of stored transitions."""
        pass


class ArtifactDAGInterface(ABC):
    """
    Port for artifact persistence.

    Implementations provide append-only storage for the Versioned Repository (Definition 4).
    """

    @abstractmethod
    def store(self, artifact: "Artifact") -> str:
        """
        Store an artifact in the DAG.

        Args:
            artifact: The artifact to store

        Returns:
            The artifact_id
        """
        pass

    @abstractmethod
    def get_artifact(self, artifact_id: str) -> "Artifact":
        """
        Retrieve an artifact by ID.

        Args:
            artifact_id: The unique identifier

        Returns:
            The artifact

        Raises:
            KeyError: If artifact not found
        """
        pass

    @abstractmethod
    def get_provenance(self, artifact_id: str) -> list["Artifact"]:
        """
        Trace the retry chain via previous_attempt_id.

        Args:
            artifact_id: Starting artifact

        Returns:
            List of artifacts from oldest to newest in the chain
        """
        pass

    @abstractmethod
    def get_latest_for_action_pair(
        self, action_pair_id: str, workflow_id: str
    ) -> Optional["Artifact"]:
        """
        Get the most recent artifact for an action pair in a workflow.

        Args:
            action_pair_id: The action pair identifier (e.g., 'g_test')
            workflow_id: UUID of the workflow execution instance

        Returns:
            The most recent artifact, or None if not found
        """
        pass

    @abstractmethod
    def get_all_for_action_pair(
        self, action_pair_id: str, workflow_id: str
    ) -> list["Artifact"]:
        """Get all artifacts for an action pair in a specific workflow.

        Args:
            action_pair_id: The action pair identifier (e.g., 'g_test')
            workflow_id: UUID of the workflow execution instance

        Returns:
            List of artifacts sorted by created_at ascending.
        """
        pass

    @abstractmethod
    def get_all(self) -> list["Artifact"]:
        """
        Return all artifacts in the DAG.

        Used by extraction queries that need to filter across all artifacts.
        Implementations should return artifacts in a consistent order (e.g., by created_at).

        Returns:
            List of all artifacts in the repository.
        """
        pass
