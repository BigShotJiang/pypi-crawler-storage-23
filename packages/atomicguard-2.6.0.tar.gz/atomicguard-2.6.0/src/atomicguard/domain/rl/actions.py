"""
RL action space definition for workflow discovery.

The RL agent's action is selecting which action pair to execute next
from the available pool. The action is an integer index into the pool.
ActionSpace provides a validity mask — not all action pairs are valid
in every state (e.g., some may already be satisfied).

Pure data — no framework deps.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionSpace:
    """Available action pair selections in the current state.

    The mask encodes which action pairs are valid to select right now.
    Validity depends on which action pairs have their preconditions met
    and haven't already been satisfied.
    """

    num_actions: int  # Total number of action pairs in the pool
    mask: tuple[
        bool, ...
    ]  # True = action pair can be selected, indexed by pool position

    def is_valid(self, action_index: int) -> bool:
        """Check if selecting action pair at index is valid."""
        return 0 <= action_index < len(self.mask) and self.mask[action_index]
