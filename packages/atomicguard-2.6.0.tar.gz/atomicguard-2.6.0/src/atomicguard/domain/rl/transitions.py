"""
Domain-level transition model for RL experience storage.

Each transition records: the agent was in state S, selected action pair
at index a, received reward R, and arrived at state S'. The sequence of
transitions in a successful episode encodes a discovered workflow.
Pure data structure — no infrastructure dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.domain.rl.reward import RewardSignal
    from atomicguard.domain.rl.state import State


@dataclass(frozen=True)
class Transition:
    """Single experience tuple for replay buffer storage.

    Records one step of workflow discovery: the agent observed state,
    selected an action pair index, received reward, and transitioned
    to next_state. Lives in the domain layer so that both training
    and infrastructure can reference it without cross-layer imports.
    """

    state: State
    action: int  # Index into the action pair pool
    reward: RewardSignal
    next_state: State
    done: bool
