"""
RL domain models for the AtomicGuard framework.

Pure data structures defining the RL agent's world model for
workflow discovery. The agent observes which action pairs have
been satisfied and which are available, selects which action pair
to execute next (by index), and receives reward from guards.
The trained policy IS the workflow — it encodes the learned
sequence of action pairs.

No external framework dependencies (no torch, no gymnasium).
"""

from atomicguard.domain.rl.actions import ActionSpace
from atomicguard.domain.rl.reward import RewardFunctionInterface, RewardSignal
from atomicguard.domain.rl.state import State

__all__ = [
    "ActionSpace",
    "State",
    "RewardSignal",
    "RewardFunctionInterface",
]
