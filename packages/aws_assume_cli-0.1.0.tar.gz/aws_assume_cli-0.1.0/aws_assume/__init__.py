"""AWS assume - CLI for AWS SSO credential management."""

__version__ = "0.1.0"
