_installed_version = '0.7.1'
_installed_git_hash = '28077ce90d6820749a7d8635bf1025442540c9f2'
_version_setup_depth = 1
