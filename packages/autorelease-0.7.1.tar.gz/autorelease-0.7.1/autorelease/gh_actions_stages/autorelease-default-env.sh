# Vendored from Autorelease $VERSION
# Update by updating Autorelease and running `autorelease vendor actions`
INSTALL_AUTORELEASE="python -m pip install autorelease==$VERSION"
if [ -f autorelease-env.sh ]; then
    source autorelease-env.sh
fi

