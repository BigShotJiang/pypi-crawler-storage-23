# correct version.py is writted by setup.py
# this is just to give us a backup module in case we don't have this

version = "Unknown"
git_hash = "Unknown"
full_version = \
        "Unknown: Incorrect installation. Use pip or setup.py to install"
