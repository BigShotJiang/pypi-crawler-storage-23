class TestCheckRunner(object):
    def test_placeholder(self):
        #placeholder so we have at least one test
        pass
