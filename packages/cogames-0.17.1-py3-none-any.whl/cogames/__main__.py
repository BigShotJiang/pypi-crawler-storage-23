from cogames.main import app

if __name__ == "__main__":
    app(prog_name="cogames")
