"""Demo plugin for kikusan - example third-party plugin."""

from kikusan_demo.plugin import DemoPlugin

__version__ = "0.1.0"
__all__ = ["DemoPlugin"]
