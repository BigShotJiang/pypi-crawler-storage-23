"""Kikusan plugin system."""

from kikusan.plugins.registry import discover_plugins

# Auto-discover plugins on import
discover_plugins()
