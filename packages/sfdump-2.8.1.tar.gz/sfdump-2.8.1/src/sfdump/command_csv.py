from __future__ import annotations

import os
import sys
from typing import List, Optional

import click

from .api import SalesforceAPI, SFConfig
from .dumper import dump_object_to_csv, fieldnames_for_object
from .exceptions import MissingCredentialsError
from .utils import ensure_dir

# Try to auto-load a .env if python-dotenv is available
try:
    from dotenv import load_dotenv  # type: ignore

    load_dotenv()
except Exception:
    pass


def _supports_unicode_emoji() -> bool:
    enc = getattr(sys.stdout, "encoding", "") or ""
    return "UTF-8" in enc.upper()


# Certain objects need extra fields for downstream tooling (e.g. docs-index).
# We force-include these when auto-resolving fields.
ALWAYS_INCLUDE_FIELDS = {
    "Opportunity": ["AccountId"],
    # You can add more later, e.g.:
    # "Contact": ["AccountId"],
    # "Case": ["AccountId"],
}

# Some Salesforce objects have "implementation restrictions" and must be
# queried with an explicit WHERE on Id / ContentDocumentId / LinkedEntityId.
IMPLEMENTATION_RESTRICTED_OBJECTS = {
    "ContentDocumentLink",
}


@click.command("csv")
@click.option("--object", "object_name", required=True, help="sObject name (e.g. Account).")
@click.option(
    "--out",
    "out_dir",
    required=True,
    type=click.Path(file_okay=False),
    help="Output directory.",
)
@click.option(
    "--fields",
    help=(
        "Comma-separated field list; if omitted, auto-resolve fields from describe(). "
        "Auto mode always includes reference Id fields (e.g. OwnerId, AccountId)."
    ),
)
@click.option(
    "--where",
    help=(
        "Optional SOQL WHERE clause (without the 'WHERE'). "
        "For some objects (e.g. ContentDocumentLink) this is required due to "
        "Salesforce implementation restrictions."
    ),
)
@click.option("--limit", type=int, help="Optional row limit (client-side stop).")
@click.option(
    "--relationships/--no-relationships",
    default=True,
    show_default=True,
    help="Also include relationship display fields like Owner.Name, Account.Name (non-polymorphic only).",
)
def csv_cmd(
    object_name: str,
    out_dir: str,
    fields: Optional[str],
    where: Optional[str],
    limit: Optional[int],
    relationships: bool,
) -> None:
    """Dump a single sObject to CSV."""
    api = SalesforceAPI(SFConfig.from_env())
    try:
        api.connect()
    except MissingCredentialsError as e:
        missing = ", ".join(e.missing)
        msg = (
            f"Missing Salesforce credentials: {missing}\n\n"
            "Set environment variables or create a .env file with:\n"
            "  SF_CLIENT_ID, SF_CLIENT_SECRET, SF_USERNAME, SF_PASSWORD\n"
            "Note: SF_PASSWORD should include your security token if required."
        )
        raise click.ClickException(msg) from e

    ensure_dir(out_dir)
    resolved_fields: Optional[List[str]] = None

    if fields:
        # Explicit field list from CLI – do NOT touch it.
        resolved_fields = [f.strip() for f in fields.split(",") if f.strip()]
    else:
        # Auto-resolve fields from object description.
        try:
            try:
                resolved_fields = fieldnames_for_object(
                    api,
                    object_name,
                    include_relationship_fields=relationships,
                    relationship_subfields=["Name"],
                )
            except TypeError as e:
                if "unexpected keyword argument" not in str(e):
                    raise
                resolved_fields = fieldnames_for_object(api, object_name)
        except Exception as err:
            raise click.ClickException(f"Failed to describe object '{object_name}'.") from err

        # Force-include key fields for some objects
        extra = ALWAYS_INCLUDE_FIELDS.get(object_name, [])
        if extra:
            existing = set(resolved_fields or [])
            for f in extra:
                if f not in existing:
                    resolved_fields.append(f)

    # Apply WHERE clause
    effective_where = where

    # For implementation-restricted objects, force the user to provide a WHERE
    if object_name in IMPLEMENTATION_RESTRICTED_OBJECTS and not effective_where:
        raise click.ClickException(
            "ContentDocumentLink has a Salesforce implementation restriction and "
            "must be queried with an explicit WHERE clause on Id, LinkedEntityId "
            "or ContentDocumentId.\n\n"
            "Example:\n"
            "  sfdump csv --out ./exports/... --object ContentDocumentLink \\\n"
            "      --where \"LinkedEntityId = '001xxxxxxxxxxxxAAA'\""
        )

    try:
        csv_path, n = dump_object_to_csv(
            api=api,
            object_name=object_name,
            out_dir=os.path.join(out_dir, "csv"),
            fields=resolved_fields,
            where=effective_where,
            limit=limit,
        )
    except Exception as err:
        raise click.ClickException(f"Failed to dump {object_name} to CSV.") from err

    if _supports_unicode_emoji():
        tick = "✅"
        arrow = "→"
    else:
        tick = "[OK]"
        arrow = "->"

    click.echo(f"{tick} Wrote {n} rows {arrow} {csv_path}")
