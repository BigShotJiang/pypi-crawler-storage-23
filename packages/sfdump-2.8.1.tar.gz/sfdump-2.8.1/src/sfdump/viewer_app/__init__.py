"""Streamlit viewer app package (UI/services/preview split)."""
