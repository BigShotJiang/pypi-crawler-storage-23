from .mnist import *
from .cifar import *
