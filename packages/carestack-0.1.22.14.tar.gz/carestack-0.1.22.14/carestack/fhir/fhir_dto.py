from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, ConfigDict, Field


class Base64Document(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    file_name: str = Field(..., alias="fileName")
    data: str
    mime_type: str = Field(..., alias="mimeType")


class BundlePatient(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    first_name: str = Field(..., alias="firstName")
    middle_name: Optional[str] = Field(None, alias="middleName")
    last_name: str = Field(..., alias="lastName")
    birth_date: str = Field(..., alias="birthDate")
    gender: str
    mobile_number: str = Field(..., alias="mobileNumber")
    email_id: Optional[str] = Field(None, alias="emailId")
    address: str
    pincode: str
    state: str
    wants_to_link_whatsapp: Optional[bool] = Field(None, alias="wantsToLinkWhatsapp")
    photo: Optional[str] = None
    id_number: str = Field(..., alias="idNumber")
    id_type: str = Field(..., alias="idType")
    abha_address: Optional[str] = Field(None, alias="abhaAddress")
    resource_id: Optional[str] = Field(None, alias="resourceId")


class BundlePractitioner(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    first_name: str = Field(..., alias="firstName")
    middle_name: Optional[str] = Field(None, alias="middleName")
    last_name: str = Field(..., alias="lastName")
    birth_date: str = Field(..., alias="birthDate")
    gender: str
    mobile_number: str = Field(..., alias="mobileNumber")
    email_id: Optional[str] = Field(None, alias="emailId")
    address: str
    pincode: str
    state: str
    wants_to_link_whatsapp: Optional[bool] = Field(None, alias="wantsToLinkWhatsapp")
    photo: Optional[str] = None
    designation: str
    joining_date: Optional[str] = Field(None, alias="joiningDate")
    department: str
    registration_id: str = Field(..., alias="registrationId")
    hpr_id: Optional[str] = Field(None, alias="hprId")
    resource_id: Optional[str] = Field(None, alias="resourceId")


class CreateBundleRequestItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    file: Base64Document
    patient: BundlePatient
    practitioner: List[BundlePractitioner]


class ProcessedDocument(BaseModel):
    type: str
    fhir: Dict[str, Any]


class ProcessedDocumentResponse(BaseModel):
    documents: List[ProcessedDocument]
