# Opt4Deck

Opt4Deck is a small optimization toolkit that provides:
- Simplex (linear)
- BFGS (nonlinear)
- Genetic algorithm
- Adjoint-based optimization

## Installation
```bash
pip install Opt4Deck
```
