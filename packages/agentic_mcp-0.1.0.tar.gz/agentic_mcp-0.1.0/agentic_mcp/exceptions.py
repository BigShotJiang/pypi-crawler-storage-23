class InvalidRetrieverError(TypeError):
    pass


class InvalidDatasetError(TypeError):
    pass
