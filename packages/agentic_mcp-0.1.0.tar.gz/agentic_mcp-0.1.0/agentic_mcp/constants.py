from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from agentic_mcp.settings import EvidenceBuilderSettings, MCPRunnerSettings


TCMCPRunner = TypeVar("TCMCPRunner", bound="MCPRunnerSettings")
TCEvidenceBuilder = TypeVar("TCEvidenceBuilder", bound="EvidenceBuilderSettings")
