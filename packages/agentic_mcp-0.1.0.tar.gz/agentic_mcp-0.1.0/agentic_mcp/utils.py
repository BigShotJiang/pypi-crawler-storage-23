from typing import Any

import yaml
from agentic_base.constants import CONFIG_PATH
from agentic_base.utils import load_class

from agentic_mcp import MCPRunner


def get_runner(config_path: str = CONFIG_PATH) -> "MCPRunner":
    with open(config_path) as f:
        yaml_config = yaml.safe_load(f)
        klass = load_class(yaml_config["module_path"])
        return klass.from_settings()  # type: ignore[no-any-return]
