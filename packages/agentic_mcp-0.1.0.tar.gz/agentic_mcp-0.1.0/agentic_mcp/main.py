import logging

from agentic_mcp import MCPRunner
from agentic_mcp.settings import MCPRunnerSettings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
)


if __name__ == "__main__":
    MCPRunner(MCPRunnerSettings()).run()  # type: ignore[call-arg]
