# eric-kraus

a resume validated by Pydantic.

## What Is This?

This is the resume of **Eric Kraus** ... structured, typed, and validated using [Pydantic](https://docs.pydantic.dev)!

I've also prepared an interactive terminal (UI) styled by [Rich](https://rich.readthedocs.io).

Every data point comes from a Pydantic model.

The instance of my resume is instantiated from a BaseModel called: `IdealCandidate`.

**Every property is validated.**

> Because unvalidated data is a liability — in pipelines... and in `hiring`.

## Quick Start

**Install Package**
```bash
# With uv (fastest)
uvx eric-kraus

# With pip
pip install eric-kraus

# Then run:
eric-kraus
```

OR

**Clone repo and run from root:**

```bash
uv run python3 -c "from eric_kraus.data import build_eric; print(build_eric().model_dump_json(indent=2))"
```

## For the Curious

```python
from eric_kraus.data import build_eric

eric = build_eric()

# the Pydantic model
print(eric.model_dump_json(indent=2))

# validator that matters
from eric_kraus.models import QuotaResult
QuotaResult(year=2024, attainment_pct=50)  # ValidationError: "Candidate without track record. Must not be Eric Kraus!"
```

## Interactive Menu

```
--------------------------------------------------
  eric-kraus — a resume, validated by Pydantic
--------------------------------------------------

--- MENU ---
  1  Overview
  2  Experience
  3  Technical Projects
  4  Why Pydantic?
  5  Education & Languages
  6  Contact
  7  Export as JSON
  a  Show Everything
  q  Quit
```

## License

MIT
