"""eric-kraus: 20 years of enterprise sales, validated by Pydantic!"""

from eric_kraus.data import build_eric
from eric_kraus.models import IdealCandidate

__all__ = ["IdealCandidate", "build_eric"]
