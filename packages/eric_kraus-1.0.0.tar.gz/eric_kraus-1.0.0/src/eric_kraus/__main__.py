"""Support `python -m eric_kraus`."""
from eric_kraus.cli import main

main()
