"""
Eric Kraus (IdealCandidate) — fully validated.

Every claim in this resume is structured, typed, and validated using Pydantic.

Because unvalidated data is a liability in pipelines -AND- in hiring!
"""

from datetime import date

from eric_kraus.models import (
    Education,
    IdealCandidate,
    QuotaResult,
    Role,
    Strengths,
    TechnicalProject,
)


# all my data here
def build_eric() -> IdealCandidate:
    """The full picture of me"""
    return IdealCandidate(
        name="Eric Kraus",
        email="eric.kraus@gmail.com",
        phone="612.432.1237",
        location="Minnesota (at his desk working by 7am ET daily)",
        location_note="Regarding Timezone: I'm already working ET hours — up at 5am CT, every day",
        years_experience=20,
        available_for_work=True,
        strengths=[s for s in Strengths],
        why_pydantic="[royal_blue1]from[/royal_blue1] [orchid]pydantic[/orchid] [royal_blue1]import[/royal_blue1] PositiveInt[dim]ent[/dim]\n\n"
        "There are no [italic]free rides[/italic] on rocketships! 🚀\n\n"
        "I want to help [underline]build[/underline] the sales playbook at a company with great people, "
        "shaping the future of [italic]developers building[/italic] with agents.\n\n"
        "I've spent 20 years learning how enterprises buy — the politics, the budgets, the procurement gauntlet.\n"
        "\nI use Pydantic in my own projects. I speak users' language because -- [italic light_goldenrod3]I am one[/italic light_goldenrod3].\n\n"
        "Pydantic has the product and the community. "
        "I'll bring the pipeline, the process, and the closes. \n\n"
        "[italic light_yellow3]Let's build the future together![/italic light_yellow3]",
        experience=[
            Role(
                company="66degrees",
                title="Client Partner — Enterprise Sales",
                start=date(2023, 3, 1),
                sold_to=[
                    "Business Executives",
                    "CIO",
                    "CTO",
                    "VP Engineering",
                    "Chief Data / AI Officer",
                ],
                largest_deal="$4M (largest in company history, avg deal size: $175k)",
                highlights=[
                    "'Trailblazer' award for thought leadership and GTM contributions (2025)",
                    "9 new logos in Q4 2024 alone (earned award: Most New Logos)",
                    "Maintain strategic account plans for top enterprise ($1B+ annual rev) clients",
                    "Sources majority of pipeline through personal hunting and strategic acquisition",
                    "Create (proactive) POV proposals, Develop MVP demos and pitches",
                    "Creatively design, write and negotiate multi-year contracts ($1M+)",
                    "Built Claude Code agents for MEDDPICC scoring and CRM automation",
                    "Built AI-powered prospecting tools: LinkedIn research, dynamic outreach",
                    "Develop GTM strategies and assets, Advise leadership on new trends/challenges",
                ],
                quota_results=[
                    QuotaResult(
                        year=2025,
                        attainment_pct=100,
                        highlight="Trailblazer award; ask me about two strategic 'turn-around' client stories!",
                    ),
                    QuotaResult(
                        year=2024, attainment_pct=167, highlight="Club + New Logo Award"
                    ),
                    QuotaResult(
                        year=2023,
                        attainment_pct=110,
                        highlight="Exceeded goals in short/transition year",
                    ),
                ],
                end=None,
            ),
            Role(
                company="Google",
                title="Enterprise Account Executive — Google Cloud",
                start=date(2020, 3, 1),
                end=date(2023, 3, 1),
                sold_to=[
                    "CIO",
                    "Bus. C-Suite",
                    "VP Engineering",
                    "Other IT Leadership",
                ],
                largest_deal="Greenfield (Fortune 50 company) New Logo: zero relationship -> signed MSA and commit spend",
                highlights=[
                    "Broke into a Fortune 50 pure greenfield account with mature, established competitive hyper-scaler",
                    "Earned highest MRR and month-over-month growth across team (2022)",
                    "Facilitated a joint-venture with execs from 4 largest companies in food supply chain",
                    "Rebuilt a damaged client relationship into signed master agreement + cloud adoption",
                    "Developed Google Cloud GTM strategy for Agriculture and Sustainability verticals",
                    "Two peer awards + discretionary management bonus for leadership",
                ],
                quota_results=[
                    QuotaResult(
                        year=2022,
                        attainment_pct=100,
                        highlight="Large Greenfield New logo!",
                    ),
                    QuotaResult(
                        year=2021,
                        attainment_pct=100,
                        highlight="Three ($1B+) MSAs + commit to spend",
                    ),
                    QuotaResult(
                        year=2020,
                        attainment_pct=105,
                        highlight="Met sales objectives (logo acquisitions) despite short year + COVID!",
                    ),
                ],
            ),
            Role(
                company="Microsoft",
                title="Director, Modern Workplace Sales <- Account Technology Strategist",
                start=date(2008, 1, 1),
                end=date(2020, 3, 1),
                sold_to=["CIO", "CISO", "CTO", "VP IT", "Other IT Capability Leaders"],
                largest_deal="$20M+ multi-year enterprise agreements (routine)",
                highlights=[
                    "Met or exceeded quota/billable hrs target 12 straight years!",
                    "Managed $50M/yr revenue portfolio in M365 cloud technologies",
                    "Gold Club recipient for sales excellence (2018)",
                    "Tier 1 Minnesota accounts: Cargill, Target, US Bank, Best Buy, General Mills, Mayo Clinic",
                    "One of top E5 (SKU) upsell ($) sellers among peers",
                    "Microsoft Leadership Development (<1% of company nominated)",
                    "Architected business-driven solutions and ran executive briefings",
                    "Led highly-competitive takeaway opportunities including technical evaluations and negotiations",
                    "Mentored new hires on role success, culture, and sales process",
                ],
                quota_results=[
                    QuotaResult(
                        year=2019,
                        attainment_pct=100,
                        highlight="One of largest E5 growth sellers",
                    ),
                    QuotaResult(
                        year=2018,
                        attainment_pct=157,
                        highlight="Gold Club - 2nd largest deal for year",
                    ),
                    QuotaResult(
                        year=2017,
                        attainment_pct=105,
                        highlight="Closed nearly $60M of net new + renewals",
                    ),
                ],
            ),
            Role(
                company="Sogeti / Capgemini",
                title="Principal Consultant & Senior Software Engineer",
                start=date(2004, 5, 1),
                end=date(2008, 1, 1),
                highlights=[
                    "Software engineer .NET (yeah, don't laugh)",
                    "Quickly promoted to Senior, then Principal",
                    "Owned product delivery: backlog management, custom dev, executive QBRs",
                    "Led an offshore managed service team supporting mission-critical finance apps for Fortune 100",
                ],
            ),
        ],
        technical_projects=[
            TechnicalProject(
                name="Agentic Workflow Orchestration Platform",
                description="Custom agent harness for scheduling and observing AI workflows",
                technologies=["Python", "Pydantic", "Claude Code"],
            ),
            TechnicalProject(
                name="Claude Code Plugin Marketplace",
                description="Published plugins that automate agentic project work",
                technologies=["Claude Code", "Python", "Markdown"],
            ),
            TechnicalProject(
                name="AI Sales Automation Pipeline",
                description="End-to-end workflow: leads → outreach → deal qualification → CRM sync",
                technologies=["Python", "n8n", "Claude Code"],
            ),
            TechnicalProject(
                name="MEDDPICC Deal Scoring Agent",
                description="Claude Code agent that scores pipeline deals and syncs hygiene to Salesforce",
                technologies=["Claude Code", "MCP", "Salesforce API"],
            ),
            TechnicalProject(
                name="eric-kraus (this package)",
                description="My CLI resume, validated by Pydantic, rendered by Rich.",
                technologies=["Python", "Pydantic", "Rich"],
            ),
        ],
        education=Education(
            degree="Bachelor of Business Administration",
            major="Management Information Systems",
            minors=["Business Telecommunications", "Advanced Business Communications"],
            school="University of Wisconsin - Eau Claire",
        ),
        languages=["English", "German (A2->B1) - learning!"],
    )
