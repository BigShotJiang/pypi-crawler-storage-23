# HeyLead — Product Listing Copy

Reusable marketing copy for directory submissions, review platforms, and launch events.

---

## Taglines

**Short:** Your AI sales rep. One command to fill your pipeline.

**Medium:** MCP-native autonomous LinkedIn SDR — AI-powered lead generation, voice-matched outreach, and campaign analytics inside your code editor.

---

## One-liner

HeyLead is an AI LinkedIn SDR that runs inside Cursor or Claude Code, finding prospects, sending personalized outreach, following up, and tracking replies — all through natural language commands.

---

## Short Description (~100 words)

For: Futurepedia, There's An AI For That, AlternativeTo, StackShare

HeyLead is an MCP-native autonomous LinkedIn SDR that runs inside Cursor, Claude Code, or any MCP-compatible editor. No dashboard, no web app — just tell your AI "find me CTOs at fintech startups" and watch it work. It generates buyer personas with RAG-powered ICP analysis, sends voice-matched connection invitations that sound like you wrote them, follows up automatically, classifies reply sentiment, and tracks deal outcomes. 31 specialized tools cover the full SDR workflow. Free tier: 50 invitations/month. Pro: $29/mo unlimited.

---

## Long Description (~250 words)

For: Product Hunt, G2, DevHunt

Most LinkedIn automation tools give you another dashboard to manage. HeyLead takes a different approach: it's an AI sales rep that lives inside your code editor.

Built on the Model Context Protocol (MCP), HeyLead gives AI assistants like Claude and Cursor 31 specialized tools covering the entire SDR workflow — from prospect discovery to deal closing.

**How it works:**
1. Tell your AI who you want to reach: "Find me CTOs at Series A fintech startups in New York"
2. HeyLead searches LinkedIn, scores prospects by fit, and generates personalized connection requests that match your writing style
3. After connections are accepted, it follows up with multi-touch drip sequences
4. When prospects reply, it classifies sentiment and either advances toward meetings or gracefully closes

**What makes it different:**
- **Voice matching** — analyzes your LinkedIn profile and posts to capture your tone. Messages sound like you, not a template
- **RAG-powered ICP generation** — crawls company context to build buyer personas with pain points, fears, and barriers
- **Full warm-up sequence** — follows, endorses skills, engages with posts before sending invitations
- **24/7 autonomous scheduling** — cloud scheduler runs even when your laptop is off
- **Copilot & Autopilot modes** — review every message or let the AI handle it

Free: 50 invitations/month, 1 campaign. Pro ($29/mo): unlimited campaigns, 5 LinkedIn accounts, cloud scheduler.

Open source (MIT). Install in 10 seconds: `claude mcp add heylead -- uvx heylead`

---

## Key Features (bulleted)

- Voice-matched messaging — analyzes your LinkedIn profile to capture your writing style
- RAG-powered ICP generation — buyer personas with pain points, fears, barriers, and LinkedIn targeting
- Multi-touch drip sequences — follow, endorse, engage, invite, follow-up DM, InMail
- Sentiment-aware reply handling — auto-advances positive leads toward meetings
- 24/7 autonomous scheduling — cloud scheduler runs even when your laptop is off
- Copilot & Autopilot modes — review every message or let AI handle it
- 31 specialized MCP tools — full SDR workflow from prospecting to deal closing
- Company enrichment — fetches company data for better message personalization
- Adaptive rate limiting — respects LinkedIn safety limits, adjusts based on acceptance rate

---

## Categories & Tags

**Primary categories:** Sales Automation, LinkedIn Automation, Lead Generation, SDR Tools, AI Sales

**Tags:** mcp, model-context-protocol, linkedin, outreach, sdr, leads, sales, ai, automation, prospecting, campaign, lead-generation, cold-outreach, b2b, icp, buyer-persona, social-selling, linkedin-automation

---

## Comparison Keywords

Alternative to: LinkedIn Sales Navigator, Dripify, Expandi, Lemlist, PhantomBuster, Waalaxy, Octopus CRM, Dux-Soup, Apollo.io, Salesloft, Outreach.io

---

## Awesome-MCP-Servers Entry

Ready to copy-paste for PR submissions:

**wong2/awesome-mcp-servers:**
```markdown
- **[HeyLead](https://github.com/D4umak/heylead)** - Autonomous LinkedIn SDR with AI-powered lead generation, voice-matched outreach, multi-touch drip sequences, and campaign analytics
```

**TensorBlock/awesome-mcp-servers:**
```markdown
- [D4umak/heylead](https://github.com/D4umak/heylead): MCP-native autonomous LinkedIn SDR with ICP generation, voice-matched personalized messaging, multi-touch drip sequences, engagement warm-ups, and 24/7 campaign scheduling.
```

**punkpeye/awesome-mcp-servers:**
```markdown
- [HeyLead](https://github.com/D4umak/heylead) - Autonomous LinkedIn SDR. AI-powered lead generation, ICP generation with buyer personas, voice-matched messaging, multi-touch sequences, engagement warm-ups, and campaign analytics. `MIT` `Python`
```

---

## llms-txt-hub PR Entry

For submitting to `thedaviddias/llms-txt-hub`:

**File:** `content/websites/heylead.mdx`
```mdx
---
domain: "heylead-api-141730336364.us-central1.run.app"
name: "HeyLead"
category: "Developer Tools"
llmsTxtUrl: "https://heylead-api-141730336364.us-central1.run.app/llms.txt"
llmsFullTxtUrl: "https://heylead-api-141730336364.us-central1.run.app/llms-full.txt"
---
```

---

## Platform-Specific Notes

### Product Hunt
- Best launch day: Tuesday or Wednesday
- Needs: logo, 3-5 screenshots/GIFs of terminal usage, maker profile
- Topics: Sales, AI, Developer Tools, LinkedIn, Automation, MCP
- Hunter tip: reach out to hunters who've launched similar tools

### G2
- Category: "Sales Automation" or "LinkedIn Automation"
- Need minimum 10 reviews to appear in reports
- Free listing available at sell.g2.com
- Focus on getting early user reviews

### DevHunt
- Developer-focused Product Hunt alternative
- Better fit for CLI/MCP tools than Product Hunt
- Less competitive, more engaged dev audience

### Futurepedia / TAAFT
- Simple submission forms
- Category: Sales / Productivity / AI Automation
- Use the 100-word short description

### AlternativeTo
- Position as alternative to: Dripify, Expandi, Waalaxy, PhantomBuster
- Highlight: open source, no dashboard, AI-native
