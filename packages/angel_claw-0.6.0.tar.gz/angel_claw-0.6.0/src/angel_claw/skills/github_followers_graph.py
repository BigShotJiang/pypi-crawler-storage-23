import requests
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import numpy as np

@skill
def github_followers_graph(username: str) -> str:
    """
    Generates a PNG graph of GitHub followers over simulated time for the specified username.
    """
    # Fetch GitHub user's current followers
    user_url = f'https://api.github.com/users/{username}'
    resp = requests.get(user_url)
    if resp.status_code != 200:
        return f"Failed to fetch GitHub data: {resp.status_code}"
    data = resp.json()
    followers = data.get('followers', 0)

    # Simulate data for the past 12 months
    months = [
        (datetime.now() - timedelta(days=30 * i)).strftime('%Y-%m') for i in reversed(range(12))
    ]
    # Simulate growth (random walk from 0 to current followers)
    np.random.seed(42)
    steps = np.abs(np.random.normal(loc=followers / 12, scale=followers / 30, size=12))
    y = np.cumsum(steps)
    y = np.clip(y, 0, None)
    y = y / y[-1] * followers if y[-1] > 0 else y
    y[0] = 0
    y[-1] = followers

    # Generate the plot
    plt.figure(figsize=(8, 4))
    plt.plot(months, y, marker='o', label='Followers')
    plt.title(f'GitHub Followers Over Time: @{username}')
    plt.xlabel('Month')
    plt.ylabel('Followers')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.legend()
    png_path = f'github_followers_{username}.png'
    plt.savefig(png_path)
    plt.close()
    return f"Followers graph saved as {png_path}"
