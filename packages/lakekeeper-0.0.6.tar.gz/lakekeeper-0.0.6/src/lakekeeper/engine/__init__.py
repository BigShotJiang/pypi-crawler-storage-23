"""Compaction engine modules."""
