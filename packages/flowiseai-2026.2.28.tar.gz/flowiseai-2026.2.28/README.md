# FlowiseAI — Visual AI Workflow Builder & Automation for Python

[![PyPI](https://img.shields.io/pypi/v/flowiseai.svg)](https://pypi.org/project/flowiseai/) [![Python](https://img.shields.io/pypi/pyversions/flowiseai.svg)](https://pypi.org/project/flowiseai/) [![license](https://img.shields.io/pypi/l/flowiseai.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

Construct robust visual AI workflow Python applications using our drag-and-drop AI builder. Implement Flowise automation for no-code AI pipelines, a powerful alternative to Flowise, LangFlow, n8n, and Zapier. Define, test, and deploy complex AI workflows without extensive coding.

## Features

- Construct visual AI workflow Python applications rapidly.
- Automate intricate tasks with Flowise automation, reducing boilerplate.
- Orchestrate no-code AI pipelines using a drag-and-drop AI builder.
- Integrate diverse AI models and data sources into unified workflows.
- Extend functionality via custom Python components.

## Use Cases

- Build visual AI pipelines without writing boilerplate code
- Connect LLMs, tools, and data sources in a drag-and-drop interface
- Deploy automated workflows triggered by remote machine events

## Installation

```bash
pip install flowiseai
```

## Quick Start

```python
from flowiseai import FlowiseAI

client = FlowiseAI.remote(api_key="cmdop_live_xxx")

# Run a visual workflow by name
result = client.agent.run("Run the 'daily-report' workflow")
print(result.text)

# Chain tools and LLMs in one call
result = client.agent.run(
    "Fetch https://news.ycombinator.com, summarize top 5 stories, post to Slack"
)
print(result.text)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [flowiseai on PyPI](https://pypi.org/project/flowiseai/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
