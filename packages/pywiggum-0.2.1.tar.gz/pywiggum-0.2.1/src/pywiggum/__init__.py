"""
PyWiggum - AI Agent Orchestrator with Dashboard

"Me fail English? That's unpossible!" — Ralph Wiggum
Chief Wiggum oversees Ralph. PyWiggum oversees your AI coding agents.
"""

__version__ = "0.2.1"

from pywiggum.config import WiggumConfig
from pywiggum.kanban import KanbanManager, Milestone, Task
from pywiggum.routing import AgentLevel, Router, RoutingConfig
from pywiggum.runner import Runner

__all__ = [
    "__version__",
    "WiggumConfig",
    "KanbanManager",
    "Milestone",
    "Task",
    "Runner",
    "Router",
    "RoutingConfig",
    "AgentLevel",
]
