"""Dashboard web interface for PyWiggum."""

from pywiggum.dashboard.server import start_server

__all__ = ["start_server"]
