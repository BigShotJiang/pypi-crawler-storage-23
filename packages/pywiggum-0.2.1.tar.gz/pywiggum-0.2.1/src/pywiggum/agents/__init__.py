"""Agent backend implementations."""

from pywiggum.agents.base import AgentResult, BaseAgent

__all__ = ["BaseAgent", "AgentResult"]
