# Installation Guide

## Quick Install

### Option 1: Direct Python Install (Recommended)

```bash
# Clone or download the plugin
cd claude-pet-companion

# Run the installer
python install.py
```

### Option 2: Pip Install

```bash
# From the plugin directory
pip install -e .

# Or from a remote repository
pip install git+https://github.com/your-repo/claude-pet-companion.git
```

### Option 3: Manual Install

```bash
# Copy to Claude plugins directory
# Default locations:
# macOS: ~/.claude/plugins/
# Windows: %APPDATA%\Claude\plugins\
# Linux: ~/.claude/plugins/

cp -r claude-pet-companion ~/.claude/plugins/
```

## Verification

After installation, verify it's working:

```bash
# Check pet status
pet-companion status

# Or using Claude Code
claude --help | grep pet
```

## Claude Code Commands

Once installed, use these commands in Claude Code:

```
/pet:status  - Check your pet's stats
/pet:feed    - Feed your pet
/pet:play    - Play with your pet
/pet:sleep   - Toggle sleep mode
```

## Uninstall

```bash
# If installed via pip
pip uninstall claude-pet-companion

# If installed via install.py
python install.py uninstall
```

## Troubleshooting

### Plugin not showing up

1. Make sure Claude Code is restarted after installation
2. Check the plugin is in the correct directory:
   ```bash
   echo $CLAUDE_PLUGINS_PATH  # or check default location
   ```

### State not saving

1. Check write permissions on the data directory
2. Ensure the `data/` folder exists in the plugin directory

### Import errors

1. Verify Python 3.8+ is installed: `python --version`
2. Reinstall the plugin: `pip install -e . --force-reinstall`
