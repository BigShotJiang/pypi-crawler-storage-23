#!/usr/bin/env python3
"""
简化版终端宠物 - 直接显示可互动的像素宠物

在 Claude Code 终端内运行，支持鼠标和键盘互动
"""
import sys
import time
import os
from pathlib import Path

# ANSI 颜色和光标控制
ANSI = {
    'up': '\033[A',
    'down': '\033[B',
    'right': '\033[C',
    'left': '\033[D',
    'clear': '\033[2J',
    'home': '\033[H',
    'hide_cursor': '\033[?25l',
    'show_cursor': '\033[?25h',
    'reset': '\033[0m',
    'yellow': '\033[93m',
    'cyan': '\033[96m',
    'magenta': '\033[95m',
    'white': '\033[97m',
    'green': '\033[92m',
}

# 像素宠物精灵
PET_ART = {
    'idle': [
        "     ╭─────╮",
        "    ╭┴┐ ┌┴╮",
        "   │ └─┘ │",
        "  ╭─┤ ◉ ├─╮",
        "  │ └─┘ └─┘ │",
        "   ╰──┬──┘",
        "    ╰─╯",
    ],
    'happy': [
        "     ╭─────╮",
        "    ╭┴┐ ┌┴╮",
        "   │ ●   ● │",
        "  ╭─┤ └┬┘ ├─╮",
        "  │ └──┴──┘ │",
        "   ╰──┬──┘",
        "    ╰─╯",
    ],
    'sleep': [
        "     ╭─────╮",
        "    ╭┴┐ ┌┴╮",
        "   │ ─   ─ │",
        "  ╭─┤ ─ ─ ├─╮",
        "  │ └──┴──┘ │",
        "   zzz┬zzz",
        "    ╰─╯",
    ],
    'eating': [
        "     ╭─────╮",
        "    ╭┴┐ ┌┴╮",
        "   │ ◉   ◉ │",
        "  ╭─┤ ┬┬┬├─╮",
        "  │ └─┴─┴─┘ │",
        "   ╰──┬──┘",
        "    ╰─╯",
    ],
    'love': [
        "     ╭─────╮",
        "  ❤️ ╭┴┐ ┌┴╮ ❤️",
        "   │ ♥   ♥ │",
        "  ╭─┤ ─┬─ ├─╮",
        "  │ └──┴──┘ │",
        "   ╰──┬──┘",
        "    ╰─╯",
    ],
}


class TerminalPet:
    def __init__(self, x=10, y=5):
        self.x = x
        self.y = y
        self.mood = 'happy'
        self.frame = 0
        self.running = True
        self.last_art = []

        # 状态
        self.hunger = 100
        self.happiness = 100
        self.level = 1
        self.xp = 0

    def clear(self):
        """清除宠物显示"""
        for i in range(len(self.last_art)):
            print(f"\033[{self.y + i};{self.x}H" + " " * 30)
        self.last_art = []

    def render(self):
        """渲染宠物"""
        art = PET_ART.get(self.mood, PET_ART['idle'])
        self.last_art = art

        # 根据等级选择颜色
        if self.level >= 10:
            color = ANSI['magenta']
        elif self.level >= 5:
            color = ANSI['cyan']
        else:
            color = ANSI['yellow']

        for i, line in enumerate(art):
            print(f"\033[{self.y + i};{self.x}H" + color + line + ANSI['reset'])

    def animate(self):
        """动画循环"""
        frames = ['idle', 'happy', 'idle', 'idle']
        idx = 0

        while self.running:
            if self.hunger < 30:
                self.mood = 'sleep'
            elif self.happiness > 80:
                self.mood = 'happy'
            else:
                self.mood = frames[idx % len(frames)]

            self.render()
            self.show_stats()

            idx += 1
            time.sleep(0.5)

    def show_stats(self):
        """显示状态栏"""
        stats = f"Lv.{self.level} | ❤️ {self.happiness} | 🍖 {self.hunger} | XP: {self.xp}"
        print(f"\033[{self.y + 10};{self.x}H" + ANSI['green'] + stats + ANSI['reset'])

    def show_speech(self, text):
        """显示对话"""
        bubble = f" 💬 {text} "
        print(f"\033[{self.y - 1};{self.x}H" + ANSI['yellow'] + bubble + ANSI['reset'])
        time.sleep(1)
        print(f"\033[{self.y - 1};{self.x}H" + " " * len(bubble))

    def feed(self):
        """喂食"""
        self.hunger = min(100, self.hunger + 30)
        self.happiness = min(100, self.happiness + 5)
        self.xp += 10
        self.mood = 'eating'
        self.show_speech("好吃! 🍖")
        self.check_level()

    def play(self):
        """玩耍"""
        self.happiness = min(100, self.happiness + 25)
        self.xp += 15
        self.mood = 'happy'
        self.show_speech("好开心! 🎉")
        self.check_level()

    def pet(self):
        """摸摸"""
        import random
        self.mood = 'love'
        self.happiness = min(100, self.happiness + 10)
        responses = ["❤️", "嘿!", "真开心!", "*蹭蹭*", "你真棒!"]
        self.show_speech(random.choice(responses))

    def sleep(self):
        """睡觉"""
        import random
        self.mood = 'sleep'
        self.show_speech(random.choice(["晚安... 😴", "Zzz...", "好困..."]))

    def check_level(self):
        """检查升级"""
        if self.xp >= self.level * 100:
            self.xp -= self.level * 100
            self.level += 1
            self.show_speech(f"升级! Lv.{self.level}! 🎉")

    def move(self, dx, dy):
        """移动宠物"""
        self.clear()
        self.x = max(1, min(self.x + dx, 80))
        self.y = max(1, min(self.y + dy, 20))
        self.render()

    def run(self):
        """运行宠物"""
        import threading
        import msvcrt

        # 清屏
        print(ANSI['clear'])
        print(ANSI['hide_cursor'])

        print("""
        ╔════════════════════════════════════════╗
        ║     🐾 Claude Code 终端宠物 🐾        ║
        ║                                        ║
        ║  控制:                                 ║
        ║   空格 - 摸摸    F - 喂食              ║
        ║   P - 玩耍      S - 睡觉              ║
        ║   方向键 - 移动  Q - 退出              ║
        ║                                        ║
        ╚════════════════════════════════════════╝
        """)

        print("按任意键开始...")
        msvcrt.getch()

        print("\n正在召唤你的宠物... 🐾")
        time.sleep(1)

        # 启动动画线程
        anim_thread = threading.Thread(target=self.animate, daemon=True)
        anim_thread.start()

        # 主循环 - 处理输入
        while self.running:
            if msvcrt.kbhit():
                key = msvcrt.getch()

                if key == b'q' or key == b'Q':
                    self.running = False
                elif key == b' ':
                    self.pet()
                elif key == b'f' or key == b'F':
                    self.feed()
                elif key == b'p' or key == b'P':
                    self.play()
                elif key == b's' or key == b'S':
                    self.sleep()
                elif key == b'\xe0':  # 方向键前缀
                    key = msvcrt.getch()
                    if key == b'H':  # 上
                        self.move(0, -1)
                    elif key == b'P':  # 下
                        self.move(0, 1)
                    elif key == b'K':  # 左
                        self.move(-1, 0)
                    elif key == b'M':  # 右
                        self.move(1, 0)

            time.sleep(0.05)

        # 清理
        self.clear()
        print(ANSI['show_cursor'])
        print(ANSI['clear'])
        print(f"\n再见! {self.name} 的状态已保存 💾")


def main():
    pet = TerminalPet(x=30, y=8)
    pet.run()


if __name__ == "__main__":
    main()
