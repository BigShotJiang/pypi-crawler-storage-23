#!/usr/bin/env python3
"""
Terminal Pet Renderer - 显示在终端内的可拖拽像素宠物

使用 ANSI 颜色代码在终端渲染像素小人
支持鼠标拖拽和移动到桌面
"""
import os
import sys
import time
import threading
import json
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict

# Windows 终端支持
if sys.platform == "win32":
    import ctypes
    import msvcrt

    # 启用 ANSI 颜色和虚拟终端处理
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 0x0007 | 0x0002)
    ENABLE_MOUSE_INPUT = 0x0010
    ENABLE_QUICK_EDIT_MODE = 0x0040


@dataclass
class PetState:
    """宠物状态"""
    name: str = "Pixel"
    x: int = 10
    y: int = 5
    mood: str = "happy"
    frame: int = 0
    level: int = 1
    xp: int = 0
    hunger: int = 100
    happiness: int = 100
    is_sleeping: bool = False
    evolution_stage: int = 0

    @classmethod
    def get_state_file(cls):
        return Path.home() / ".claude-pet-companion" / "pet_state.json"

    @classmethod
    def load(cls):
        f = cls.get_state_file()
        if f.exists():
            try:
                with open(f, 'r', encoding='utf-8') as f:
                    return cls(**json.load(f))
            except:
                pass
        return cls()

    def save(self):
        self.get_state_file().parent.mkdir(parents=True, exist_ok=True)
        with open(self.get_state_file(), 'w', encoding='utf-8') as f:
            json.dump(asdict(self), f, indent=2, ensure_ascii=False)


class TerminalPetRenderer:
    """终端宠物渲染器"""

    # ANSI 颜色代码
    COLORS = {
        'reset': '\033[0m',
        'black': '\033[30m',
        'red': '\033[31m',
        'green': '\033[32m',
        'yellow': '\033[33m',
        'blue': '\033[34m',
        'magenta': '\033[35m',
        'cyan': '\033[36m',
        'white': '\033[37m',
        'bright_yellow': '\033[93m',
        'bright_red': '\033[91m',
        'bright_green': '\033[92m',
        'bright_blue': '\033[94m',
        'bright_magenta': '\033[95m',
        'bright_cyan': '\033[96m',
        'bright_white': '\033[97m',
        # 背景色
        'bg_yellow': '\033[43m',
        'bg_red': '\033[41m',
        'bg_green': '\033[42m',
        'bg_blue': '\033[44m',
        'bg_magenta': '\033[45m',
        'bg_cyan': '\033[46m',
        'bg_white': '\033[47m',
        # 特殊
        'bold': '\033[1m',
        'dim': '\033[2m',
        'underline': '\033[4m',
        'blink': '\033[5m',
    }

    # 像素艺术数据 (使用字符块渲染)
    # 使用双字符宽度获得更好的像素效果
    SPRITES = {
        'idle': [
            "     ▄▄▄▄▄▄▄     ",
            "    ████████    ",
            "   ██████████   ",
            "  ████████████  ",
            "  ████████████  ",
            "  ██▀██▀██▀██  ",
            "   ███   ███   ",
            "    ███████    ",
            "     █   █     ",
        ],
        'happy': [
            "     ▄▄▄▄▄▄▄     ",
            "    ████████    ",
            "   ██████████   ",
            "  ████████████  ",
            "  ████████████  ",
            "  ███  █  ███  ",
            "   █████████   ",
            "    ███████    ",
            "     █   █     ",
        ],
        'sleep': [
            "     ▄▄▄▄▄▄▄     ",
            "    ████████    ",
            "   ██████████   ",
            "  ████████████  ",
            "  ████████████  ",
            "  ███ ─ ─ ███  ",
            "   ███   ███   ",
            "    zZZZZZZ    ",
            "     z   z     ",
        ],
        'eating': [
            "     ▄▄▄▄▄▄▄     ",
            "    ████████    ",
            "   ██████████   ",
            "  ████████████  ",
            "  ████████████  ",
            "  ██▄██▀██▀██  ",
            "   ███◉███   ",
            "    ███████    ",
            "     █   █     ",
        ],
        'egg': [
            "     ▄▄▄▄▄      ",
            "   ████████     ",
            "  ██████████    ",
            "  ██████████    ",
            "  ██████████    ",
            "  ██████████    ",
            "   ████████     ",
            "    ▀▀▀▀▀      ",
        ],
    }

    # 进化后的精灵
    EVOLVED_SPRITES = {
        1: 'baby',  # Baby
        2: 'child', # Child
        3: 'teen',  # Teen
        4: 'adult', # Adult
    }

    def __init__(self, state=None):
        self.state = state or PetState.load()
        self.running = True
        self.last_position = (self.state.x, self.state.y)
        self.dragging = False
        self.click_pos = None

    def get_sprite(self):
        """获取当前精灵"""
        if self.state.is_sleeping:
            return self.SPRITES['sleep']
        elif self.state.evolution_stage == 0:
            return self.SPRITES['egg']
        else:
            return self.SPRITES['idle']

    def render_at(self, x=None, y=None):
        """在指定位置渲染宠物"""
        if x is None:
            x = self.state.x
        if y is None:
            y = self.state.y

        sprite = self.get_sprite()
        lines = sprite

        # 清除旧位置
        old_y = self.last_position[1]
        if old_y != y:
            self.clear_position(self.last_position[0], old_y)

        # 渲染新位置
        sys.stdout.write(f"\033[{y};0f")  # 移动到指定行
        for i, line in enumerate(lines):
            # 使用上箭头移动行
            if i > 0:
                sys.stdout.write("\033[1B")

        # 使用双字符宽度和颜色渲染
        sys.stdout.write(f"\033[{y};{x}H")  # 移动到起始位置

        # 根据心情选择颜色
        if self.state.is_sleeping:
            color = self.COLORS['bright_cyan']
        elif self.state.mood == 'happy':
            color = self.COLORS['bright_yellow']
        elif self.state.evolution_stage >= 1:
            color = self.COLORS['bright_magenta']
        else:
            color = self.COLORS['bright_white']

        for i, line in enumerate(lines):
            # 每一行移动到正确位置
            sys.stdout.write(f"\033[{y + i};{x}H")
            sys.stdout.write(color + line + self.COLORS['reset'])
            sys.stdout.flush()

        self.last_position = (x, y)
        self.state.x = x
        self.state.y = y

    def clear_position(self, x, y):
        """清除指定位置"""
        sprite = self.get_sprite()
        for i in range(len(sprite)):
            sys.stdout.write(f"\033[{y + i};{x}H")
            sys.stdout.write(" " * len(sprite[0]))
        sys.stdout.flush()

    def animate(self):
        """动画循环"""
        frames = ['idle', 'happy', 'idle', 'idle']
        frame_idx = 0

        while self.running:
            if not self.state.is_sleeping:
                frame_idx = (frame_idx + 1) % len(frames)
                self.state.frame = frame_idx

            self.render_at()
            time.sleep(0.5)

    def handle_mouse(self):
        """处理鼠标输入"""
        if sys.platform == "win32":
            self._handle_windows_mouse()
        else:
            self._handle_unix_mouse()

    def _handle_windows_mouse(self):
        """处理 Windows 鼠标事件"""
        import ctypes.wintypes

        class MOUSE_EVENT_RECORD(ctypes.Structure):
            _fields_ = [
                ("dwMousePosition", ctypes.wintypes.DWORD * 2),
                ("dwButtonState", ctypes.wintypes.DWORD),
                ("dwControlKeyState", ctypes.wintypes.DWORD),
                ("dwEventFlags", ctypes.wintypes.DWORD),
            ]

        class INPUT_RECORD(ctypes.Structure):
            _fields_ = [
                ("EventType", ctypes.wintypes.DWORD),
                ("Event", ctypes.wintypes.BYTE * 16),
            ]

        # 读取控制台输入
        STD_INPUT_HANDLE = -10
        hstdin = kernel32.GetStdHandle(STD_INPUT_HANDLE)

        # 启用鼠标输入
        mode = ctypes.wintypes.DWORD()
        kernel32.GetConsoleMode(hstdin, ctypes.byref(mode))
        kernel32.SetConsoleMode(hstdin, mode | 0x0010)  # ENABLE_MOUSE_INPUT

        print("\n🖱️ 鼠标控制已启用!")
        print("   - 点击宠物可以互动")
        print("   - 按住拖动可以移动宠物")
        print("   - 按 'q' 键退出")
        print("\033[?1003h")  # 启用鼠标跟踪

        last_click_time = 0
        last_click_pos = None
        double_click_distance = 5

        try:
            while self.running:
                # 检查键盘输入
                if msvcrt.kbhit():
                    key = msvcrt.getch()
                    if key == b'q' or key == b'Q':
                        self.running = False
                        break
                    elif key == b'f':
                        # 喂食
                        self.feed()
                    elif key == b'p':
                        # 玩耍
                        self.play()
                    elif key == b's':
                        # 睡觉
                        self.toggle_sleep()
                    elif key == b' ':
                        # 空格互动
                        self.interact()

                # 简单的鼠标检测 - 使用位置
                # 在真实环境中需要更复杂的实现
                time.sleep(0.1)

        except KeyboardInterrupt:
            pass
        finally:
            print("\033[?1003l")  # 禁用鼠标跟踪
            self.clear_position(self.state.x, self.state.y)

    def _handle_unix_mouse(self):
        """处理 Unix 鼠标事件"""
        print("\033[?1003h")  # 启用鼠标跟踪
        print("\n🖱️ 点击宠物互动，按 'q' 退出")

        try:
            while self.running:
                # 检查输入
                import select
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    ch = sys.stdin.read(1)
                    if ch == 'q':
                        self.running = False
                    elif ch == ' ':
                        self.interact()
                    elif ch == 'f':
                        self.feed()
                    elif ch == 'p':
                        self.play()
                    elif ch == 's':
                        self.toggle_sleep()
        except KeyboardInterrupt:
            pass
        finally:
            print("\033[?1003l")
            self.clear_position(self.state.x, self.state.y)

    def feed(self):
        """喂食"""
        self.state.hunger = min(100, self.state.hunger + 30)
        self.state.happiness = min(100, self.state.happiness + 5)
        self.state.xp += 10
        self.state.mood = "happy"
        self.show_speech("好吃! 🍖")
        self.render_at()
        self.state.save()

    def play(self):
        """玩耍"""
        self.state.happiness = min(100, self.state.happiness + 25)
        self.state.energy = max(0, self.state.energy - 10)
        self.state.xp += 15
        self.state.mood = "happy"
        self.show_speech("好开心! 🎉")
        self.render_at()
        self.state.save()

    def toggle_sleep(self):
        """切换睡眠状态"""
        self.state.is_sleeping = not self.state.is_sleeping
        if self.state.is_sleeping:
            self.state.energy = min(100, self.state.energy + 30)
            self.state.mood = "sleepy"
            self.show_speech("晚安... 😴")
        else:
            self.state.mood = "happy"
            self.show_speech("早安! ☀️")
        self.render_at()
        self.state.save()

    def interact(self):
        """互动"""
        responses = ["❤️", "嘿!", "真开心!", "*蹭蹭*", "你真棒!", "摸摸~"]
        import random
        self.show_speech(random.choice(responses))
        self.state.happiness = min(100, self.state.happiness + 5)
        self.render_at()
        self.state.save()

    def show_speech(self, text):
        """显示对话气泡"""
        speech_y = self.state.y - 2
        if speech_y < 1:
            speech_y = 1

        sys.stdout.write(f"\033[{speech_y};{self.state.x}H")
        sys.stdout.write(self.COLORS['bright_yellow'] + " 💬 " + text + self.COLORS['reset'])
        sys.stdout.flush()

        time.sleep(1.5)

        # 清除对话
        sys.stdout.write(f"\033[{speech_y};{self.state.x}H")
        sys.stdout.write(" " * (len(text) + 4))
        sys.stdout.flush()

    def show_status(self):
        """显示状态"""
        status_lines = [
            f"\n{'='*40}",
            f"  🐾 {self.state.name} - Level {self.state.level}",
            f"{'='*40}",
            f"  心情: {self.state.mood}  |  饱食: {self.state.hunger}",
            f"  快乐: {self.state.happiness} |  能量: {self.state.energy}",
            f"  XP: {self.state.xp}",
            f"{'='*40}",
            f"  按 F: 喂食 | P: 玩耍 | S: 睡觉 | 空格: 互动",
            f"  按 Q: 退出",
        ]

        for line in status_lines:
            print(line)


def show_welcome():
    """显示欢迎信息"""
    print("""
    ╔════════════════════════════════════════╗
    ║                                        ║
    ║      🐾 Claude Code 宠物伴侣 🐾       ║
    ║                                        ║
    ║        你的像素宠物来啦!               ║
    ║                                        ║
    ╚════════════════════════════════════════╝
    """)


def main():
    """主函数"""
    show_welcome()

    state = PetState.load()
    renderer = TerminalPetRenderer(state)
    renderer.show_status()

    print("\n正在启动宠物...")
    time.sleep(1)

    # 清屏并渲染
    print("\033[2J")  # 清屏
    print("\033[?25l")  # 隐藏光标

    try:
        # 启动动画线程
        import threading
        anim_thread = threading.Thread(target=renderer.animate, daemon=True)
        anim_thread.start()

        # 处理鼠标输入
        renderer.handle_mouse()

    except KeyboardInterrupt:
        pass
    finally:
        renderer.running = False
        print("\033[?25h")  # 显示光标
        print("\033[2J")  # 清屏
        print("\n再见! 你的宠物状态已保存 💾")
        print(f"下次见, {state.name}! 🐾")


if __name__ == "__main__":
    main()
