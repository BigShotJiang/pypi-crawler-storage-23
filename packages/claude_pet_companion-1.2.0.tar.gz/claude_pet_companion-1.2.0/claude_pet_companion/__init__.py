"""
Claude Code Pet Companion

A pixel-art virtual pet plugin for Claude Code.
"""

__version__ = "1.0.1"
__author__ = "Claude Code Community"
__license__ = "MIT"

# Import functions from CLI module for standalone use
from .cli import print_status, PetState

__all__ = [
    "PetState",
    "print_status",
]
