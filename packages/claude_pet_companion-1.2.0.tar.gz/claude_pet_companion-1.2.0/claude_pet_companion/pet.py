#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Terminal Pet - 终端内像素宠物 (纯ASCII版本)
"""
import sys
import time
import threading

# 强制UTF-8输出
if sys.platform == "win32":
    import ctypes
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 0x0007)

# 纯ASCII宠物艺术
PET_ART = {
    'idle': [
        "     ,-----.",
        "    / .   . \\",
        "   |   ^   |",
        "  ,--.---.--.",
        " /   |   |   \\",
        "     \\---/",
        "     '---'",
    ],
    'happy': [
        "     ,-----.",
        "    / O   O \\",
        "   |   ^   |",
        "  ,--.---.--.",
        " / \\---/   \\",
        "     \\---/",
        "     '---'",
    ],
    'sleep': [
        "     ,-----.",
        "    / -   - \\",
        "   |   -   |",
        "  ,--.---.--.",
        " / zzz...zz \\",
        "     \\---/",
        "     '---'",
    ],
    'love': [
        "     ,-----.",
        "    < O   O >",
        "   |   v   |",
        "  ,--.---.--.",
        " / \\---/   \\",
        "     \\---/",
        "     '---'",
    ],
}


class TerminalPet:
    def __init__(self, x=10, y=5):
        self.x = x
        self.y = y
        self.mood = 'happy'
        self.running = True
        self.last_lines = 0
        self.hunger = 100
        self.happiness = 100
        self.level = 1
        self.xp = 0
        self.name = "Pixel"

    def clear(self):
        """清除宠物显示"""
        for i in range(8):
            print(f"\033[{self.y + i};{self.x}H" + " " * 20)

    def render(self):
        """渲染宠物"""
        art = PET_ART.get(self.mood, PET_ART['idle'])
        for i, line in enumerate(art):
            print(f"\033[{self.y + i};{self.x}H" + line)
        self.last_lines = len(art)

    def show_stats(self):
        """显示状态"""
        stats = f"Lv.{self.level} | <3 {self.happiness} | )( {self.hunger} | XP: {self.xp}"
        print(f"\033[{self.y + 9};{self.x}H" + stats)

    def show_speech(self, text):
        """显示对话"""
        bubble = f" \" {text} \""
        print(f"\033[{self.y - 1};{self.x}H" + bubble)
        time.sleep(1)
        print(f"\033[{self.y - 1};{self.x}H" + " " * len(bubble))

    def feed(self):
        self.hunger = min(100, self.hunger + 30)
        self.happiness = min(100, self.happiness + 5)
        self.xp += 10
        self.show_speech("Yummy!")
        self.check_level()
        self.render()
        self.show_stats()

    def play(self):
        self.happiness = min(100, self.happiness + 25)
        self.xp += 15
        self.show_speech("Yay!")
        self.check_level()
        self.render()
        self.show_stats()

    def pet(self):
        import random
        self.happiness = min(100, self.happiness + 10)
        self.show_speech(random.choice(["<3", "Hey!", "Yay!", "Hehe"]))
        self.render()
        self.show_stats()

    def sleep(self):
        import random
        self.mood = 'sleep'
        self.show_speech(random.choice(["Zzz...", "Night..."]))
        self.render()
        self.show_stats()

    def check_level(self):
        if self.xp >= self.level * 100:
            self.xp -= self.level * 100
            self.level += 1
            self.show_speech(f"Level Up! Lv.{self.level}")

    def move(self, dx, dy):
        self.clear()
        self.x = max(1, min(self.x + dx, 80))
        self.y = max(1, min(self.y + dy, 20))
        self.render()
        self.show_stats()

    def animate(self):
        """动画循环"""
        while self.running:
            time.sleep(0.5)

    def run(self):
        """运行宠物"""
        print("\033[2J\033[H")  # 清屏
        print("""
        ========================================
        |      Claude Code Terminal Pet       |
        |                                      |
        |  Controls:                          |
        |   SPACE - pet    F - feed           |
        |   P - play       S - sleep          |
        |   Arrow keys - move                 |
        |   Q - quit                           |
        ========================================
        """)
        print("Press any key to start...")
        try:
            input()
        except:
            pass

        print("\nSpawning your pet...")
        time.sleep(1)

        # 启动动画
        import threading
        anim_thread = threading.Thread(target=self.animate, daemon=True)
        anim_thread.start()

        self.render()
        self.show_stats()

        # 主循环
        try:
            if sys.platform == "win32":
                import msvcrt
                while self.running:
                    if msvcrt.kbhit():
                        key = msvcrt.getch()
                        if key == b'q' or key == b'Q':
                            break
                        elif key == b' ':
                            self.pet()
                        elif key == b'f' or key == b'F':
                            self.feed()
                        elif key == b'p' or key == b'P':
                            self.play()
                        elif key == b's' or key == b'S':
                            self.sleep()
                        elif key == b'\xe0':
                            key = msvcrt.getch()
                            if key == b'H':
                                self.move(0, -1)
                            elif key == b'P':
                                self.move(0, 1)
                            elif key == b'K':
                                self.move(-1, 0)
                            elif key == b'M':
                                self.move(1, 0)
                    time.sleep(0.05)
            else:
                import select
                import tty
                old_settings = termios.tcgetattr(sys.stdin)
                try:
                    tty.setraw(sys.stdin.fileno())
                    while self.running:
                        if select.select([sys.stdin], [], [], 0.1)[0]:
                            key = sys.stdin.read(1)
                            if key == 'q':
                                break
                            elif key == ' ':
                                self.pet()
                            elif key == 'f':
                                self.feed()
                            elif key == 'p':
                                self.play()
                            elif key == 's':
                                self.sleep()
                            elif key == '\033':  # ANSI escape
                                key = sys.stdin.read(2)
                                if key == '[A':
                                    self.move(0, -1)
                                elif key == '[B':
                                    self.move(0, 1)
                                elif key == '[D':
                                    self.move(-1, 0)
                                elif key == '[C':
                                    self.move(1, 0)
                finally:
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        except KeyboardInterrupt:
            pass

        self.clear()
        print("\033[2J\033[H")
        print(f"\nBye! Your pet {self.name} saved!")
        print(f"Level: {self.level} | XP: {self.xp} | Hunger: {self.hunger} | Happiness: {self.happiness}")


if __name__ == "__main__":
    if sys.platform != "win32":
        import termios
    pet = TerminalPet(x=35, y=6)
    pet.run()
