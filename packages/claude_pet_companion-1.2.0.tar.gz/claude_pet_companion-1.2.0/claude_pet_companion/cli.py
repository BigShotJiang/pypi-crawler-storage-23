#!/usr/bin/env python3
"""
Claude Code Pet Companion - CLI

Command-line interface for the pet companion.
"""
import sys
import argparse
import json
import os
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict


@dataclass
class PetState:
    """Core pet state class that manages all pet attributes and persistence."""

    # Basic Info
    name: str = "Pixel"
    species: str = "code-companion"

    # Level System
    level: int = 1
    xp: int = 0
    xp_to_next_level: int = 100
    total_xp: int = 0

    # Core Stats (0-100)
    hunger: int = 100
    happiness: int = 100
    energy: int = 100

    # State
    mood: str = "content"
    is_sleeping: bool = False
    is_active: bool = True

    # Evolution
    evolution_stage: int = 0
    evolution_name: str = "Egg"

    # Progress
    achievements: list = field(default_factory=list)

    # Coding Stats
    files_created: int = 0
    files_modified: int = 0
    commands_run: int = 0
    errors_fixed: int = 0
    consecutive_successes: int = 0
    consecutive_failures: int = 0
    total_sessions: int = 0

    # Interaction Stats
    times_fed: int = 0
    times_played: int = 0
    times_slept: int = 0

    # Timestamps
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    last_meal_time: str = None
    last_sleep_time: str = None
    last_interaction: str = None

    # Position for UI
    position: dict = field(default_factory=lambda: {"left": 100, "top": 100})

    def __post_init__(self):
        """Initialize derived values after creation."""
        self.update_evolution_name()

    def update_evolution_name(self):
        """Update evolution name based on stage."""
        evolution_names = {
            0: "Egg",
            1: "Baby",
            2: "Child",
            3: "Teen",
            4: "Adult",
            5: "Elder",
            6: "Ancient"
        }
        self.evolution_name = evolution_names.get(self.evolution_stage, "Unknown")

    @classmethod
    def get_state_file(cls) -> Path:
        """Get the path to the state file."""
        home = Path.home()
        return home / ".claude-pet-companion" / "pet_state.json"

    @classmethod
    def load(cls) -> 'PetState':
        """Load pet state from file, or create new if doesn't exist."""
        state_file = cls.get_state_file()

        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return cls(**data)
            except (json.JSONDecodeError, TypeError) as e:
                print(f"Error loading state file: {e}. Creating new state.")
                return cls()
        else:
            # Ensure directory exists
            state_file.parent.mkdir(parents=True, exist_ok=True)
            return cls()

    def save(self) -> bool:
        """Save pet state to file."""
        try:
            state_file = self.get_state_file()
            state_file.parent.mkdir(parents=True, exist_ok=True)

            self.last_updated = datetime.now().isoformat()

            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Error saving state: {e}")
            return False

    def to_dict(self) -> dict:
        """Convert state to dictionary."""
        return asdict(self)


def get_state() -> PetState:
    """Get the current pet state."""
    return PetState.load()


def print_status(state):
    """Print pet status as ASCII art."""
    mood_emojis = {
        "content": "😊",
        "happy": "😄",
        "excited": "🤩",
        "worried": "😟",
        "sad": "😢",
        "sleepy": "😴",
        "hungry": "😋",
        "ecstatic": "🥳",
        "confused": "😕",
        "proud": "😎",
        "lonely": "😔"
    }

    emoji = mood_emojis.get(state.mood, "🐾")
    sleep_status = " (Sleeping)" if state.is_sleeping else ""

    print(f"""
╔═════════════════════════════╗
║   {state.name} the {state.evolution_name}   ║
║      Level {state.level} {emoji}{' ' * (15 - len(str(state.level)) - len(state.evolution_name) - 6)}║
╠═════════════════════════════╣
║ Mood: {state.mood.capitalize():12} {' ' * (10 - len(state.mood))} ║
║ Hunger: {'█' * (state.hunger // 10)}{' ' * (10 - state.hunger // 10)} {state.hunger:3}/100 ║
║ Happy:  {'█' * (state.happiness // 10)}{' ' * (10 - state.happiness // 10)} {state.happiness:3}/100 ║
║ Energy: {'█' * (state.energy // 10)}{' ' * (10 - state.energy // 10)} {state.energy:3}/100 ║
║ XP: {state.xp:4}/{state.xp_to_next_level:4}{' ' * (9 - len(str(state.xp)) - len(str(state.xp_to_next_level)))} ║
╠═════════════════════════════╣
║ Files: {state.files_created} created | {state.files_modified} edited ║
║ Session #{state.total_sessions}{' ' * (7 - len(str(state.total_sessions)))} ║
╚═════════════════════════════╝{sleep_status}
    """.strip())


def cmd_status(args):
    """Show pet status."""
    state = get_state()
    print_status(state)


def cmd_feed(args):
    """Feed the pet."""
    from datetime import datetime

    state = get_state()
    amount = args.amount or 30

    # Check meal time
    hour = datetime.now().hour
    is_meal_time = (7 <= hour <= 9) or (12 <= hour <= 14) or (18 <= hour <= 20)
    meal_name = ""
    if 7 <= hour <= 9:
        meal_name = "Breakfast"
    elif 12 <= hour <= 14:
        meal_name = "Lunch"
    elif 18 <= hour <= 20:
        meal_name = "Dinner"

    # Feed
    state.hunger = min(100, state.hunger + amount)
    if is_meal_time:
        state.hunger = min(100, state.hunger + 15)
        state.xp += 20

    state.happiness = min(100, state.happiness + 5)
    state.times_fed += 1
    state.last_meal_time = datetime.now().isoformat()
    state.last_interaction = datetime.now().isoformat()
    state.mood = "content"

    state.save()

    print(f"🍖 Feeding {state.name}...")
    print(f"   Hunger: {state.hunger}/100")

    if is_meal_time:
        print(f"   🎉 {meal_name} time bonus! +15 hunger, +20 XP")

    print(f"   {state.name} is satisfied!")


def cmd_play(args):
    """Play with the pet."""
    from datetime import datetime

    state = get_state()

    if state.is_sleeping:
        print(f"😴 {state.name} is sleeping! Use 'pet-companion sleep' to wake them up first.")
        return

    # Play
    state.happiness = min(100, state.happiness + 25)
    state.energy = max(0, state.energy - 10)
    state.hunger = max(0, state.hunger - 5)
    state.xp += 15
    state.times_played += 1
    state.last_interaction = datetime.now().isoformat()
    state.mood = "happy"

    state.save()

    print(f"🎾 Playing with {state.name}...")
    print(f"   Happiness: {state.happiness}/100")
    print(f"   Energy: {state.energy}/100")
    print(f"   +15 XP")
    print(f"   {state.name} had fun!")


def cmd_sleep(args):
    """Toggle pet sleep."""
    from datetime import datetime

    state = get_state()

    if state.is_sleeping:
        # Wake up
        state.is_sleeping = False
        state.energy = max(0, state.energy - 10)
        state.mood = "content"
        state.save()
        print(f"☀️ {state.name} woke up!")
        print(f"   Energy: {state.energy}/100")
    else:
        # Go to sleep
        state.is_sleeping = True
        state.times_slept += 1
        state.last_sleep_time = datetime.now().isoformat()

        # Immediate energy recovery
        recovered = min(100 - state.energy, 30)
        state.energy += recovered
        state.mood = "sleepy"
        state.save()

        print(f"😴 {state.name} fell asleep...")
        print(f"   Energy recovered: +{recovered}")
        print(f"   Energy: {state.energy}/100")
        print(f"   Energy will continue recovering during sleep")


def cmd_reset(args):
    """Reset pet to default state."""
    if args.force:
        PetState.get_state_file().unlink(missing_ok=True)
        state = PetState()
        state.save()
        print("🔄 Pet has been reset to default state")
    else:
        response = input("Are you sure you want to reset your pet? (y/N): ")
        if response.lower() == 'y':
            PetState.get_state_file().unlink(missing_ok=True)
            state = PetState()
            state.save()
            print("🔄 Pet has been reset to default state")
        else:
            print("Reset cancelled")


def cmd_export(args):
    """Export pet state as JSON."""
    state = get_state()
    output = args.output or "pet_state_export.json"

    with open(output, 'w') as f:
        json.dump(state.to_dict(), f, indent=2, default=str)

    print(f"✓ Pet state exported to {output}")


def cmd_import(args):
    """Import pet state from JSON."""
    state = get_state()

    with open(args.input, 'r') as f:
        data = json.load(f)

    # Update state with imported data
    for key, value in data.items():
        if hasattr(state, key):
            setattr(state, key, value)

    state.save()
    print(f"✓ Pet state imported from {args.input}")


def cmd_open(args):
    """Open the pet in terminal."""
    import subprocess
    import sys

    if args.simple:
        # 使用简化版终端宠物
        subprocess.run([sys.executable, "-m", "claude_pet_companion.simple_pet"])
    else:
        # 使用完整版终端宠物
        subprocess.run([sys.executable, "-m", "claude_pet_companion.terminal_pet"])


def cmd_start(args):
    """Start pet in terminal (alias for open)"""
    import subprocess
    import sys

    # 启动桌面宠物（独立窗口）
    subprocess.Popen([sys.executable, "-m", "claude_pet_companion.desktop_pet"])


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Claude Code Pet Companion - CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pet-companion status      Show pet status
  pet-companion feed        Feed the pet
  pet-companion play        Play with the pet
  pet-companion sleep       Toggle sleep mode
  pet-companion open        Open visual pet panel 🎨
  pet-companion reset       Reset pet to default
  pet-companion export      Export state to JSON
  pet-companion import      Import state from JSON
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Status command
    subparsers.add_parser('status', help='Show pet status')

    # Feed command
    feed_parser = subparsers.add_parser('feed', help='Feed the pet')
    feed_parser.add_argument('-a', '--amount', type=int, help='Amount to feed (default: 30)')

    # Play command
    subparsers.add_parser('play', help='Play with the pet')

    # Sleep command
    subparsers.add_parser('sleep', help='Toggle sleep mode')

    # Open command
    open_parser = subparsers.add_parser('open', help='Open pet visual panel')
    open_parser.add_argument('--simple', action='store_true', help='Use simple terminal pet')

    # Start command (直接在终端启动宠物)
    subparsers.add_parser('start', help='Start pet in terminal')

    # Reset command
    reset_parser = subparsers.add_parser('reset', help='Reset pet to default state')
    reset_parser.add_argument('-f', '--force', action='store_true', help='Skip confirmation')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export pet state')
    export_parser.add_argument('-o', '--output', help='Output file (default: pet_state_export.json)')

    # Import command
    import_parser = subparsers.add_parser('import', help='Import pet state')
    import_parser.add_argument('input', help='Input JSON file')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    commands = {
        'status': cmd_status,
        'feed': cmd_feed,
        'play': cmd_play,
        'sleep': cmd_sleep,
        'open': cmd_open,
        'start': cmd_start,
        'reset': cmd_reset,
        'export': cmd_export,
        'import': cmd_import,
    }

    command = commands.get(args.command)
    if command:
        try:
            command(args)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
