#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Desktop Pet - 独立窗口宠物

可拖拽到桌面任意位置的像素宠物窗口
"""
import tkinter as tk
from tkinter import ttk
import json
import time
import threading
from pathlib import Path
from datetime import datetime


class DesktopPet:
    """桌面宠物主窗口"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Pet Companion")

        # 窗口设置 - 无边框、置顶
        self.root.overrideredirect(True)  # 无边框
        self.root.attributes('-topmost', True)  # 置顶
        self.root.attributes('-transparentcolor', 'white')

        # 窗口大小和位置
        self.width = 200
        self.height = 250
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        self.x = screen_width // 2 - 100
        self.y = screen_height // 2 - 125
        self.root.geometry(f"{self.width}x{self.height}+{self.x}+{self.y}")

        # 宠物状态
        self.state = {
            'name': 'Pixel',
            'mood': 'happy',
            'hunger': 100,
            'happiness': 100,
            'energy': 100,
            'level': 1,
            'xp': 0,
            'is_sleeping': False,
            'evolution_stage': 0
        }

        # 加载保存的状态
        self.load_state()

        # 拖拽相关
        self.dragging = False
        self.drag_start_x = 0
        self.drag_start_y = 0

        # 创建UI
        self.create_widgets()

        # 绑定事件
        self.setup_events()

        # 启动动画
        self.animate()

        # 自动保存
        self.auto_save()

    def create_widgets(self):
        """创建界面元素"""
        # 主容器
        self.main_frame = tk.Frame(self.root, bg='white', highlightthickness=0)
        self.main_frame.pack(fill='both', expand=True)

        # 宠物画布 - 用于绘制像素宠物
        self.canvas = tk.Canvas(
            self.main_frame,
            width=150,
            height=150,
            bg='white',
            highlightthickness=0
        )
        self.canvas.pack(pady=5)

        # 绘制宠物
        self.draw_pet()

        # 状态栏
        self.status_frame = tk.Frame(self.main_frame, bg='white')
        self.status_frame.pack(fill='x', padx=5)

        # 状态文字
        self.status_label = tk.Label(
            self.status_frame,
            text=f"Lv.{self.state['level']} | <3 {self.state['happiness']}",
            bg='white',
            font=('Arial', 9)
        )
        self.status_label.pack()

        # 提示
        self.hint_label = tk.Label(
            self.main_frame,
            text="Right-click for menu",
            bg='white',
            fg='gray',
            font=('Arial', 7)
        )
        self.hint_label.pack(side='bottom', pady=2)

    def draw_pet(self):
        """绘制像素宠物"""
        self.canvas.delete("all")

        mood = self.state['mood']
        if self.state['is_sleeping']:
            mood = 'sleep'

        # 根据心情绘制不同表情
        if mood == 'happy':
            self.draw_happy_pet()
        elif mood == 'sleep':
            self.draw_sleeping_pet()
        elif mood == 'eating':
            self.draw_eating_pet()
        else:
            self.draw_idle_pet()

    def draw_idle_pet(self):
        """绘制待机状态宠物"""
        c = self.canvas
        # 身体
        body = c.create_oval(30, 30, 120, 120, fill='#f0e6d3', outline='')
        # 眼睛
        c.create_oval(55, 60, 65, 70, fill='#333', outline='')
        c.create_oval(85, 60, 95, 70, fill='#333', outline='')
        c.create_oval(57, 62, 60, 65, fill='white', outline='')
        c.create_oval(87, 62, 90, 65, fill='white', outline='')
        # 嘴巴
        c.create_arc(60, 75, 90, 85, start=0, extent=180, style='arc', width=2, outline='#c9987a')
        # 腮红
        c.create_oval(45, 80, 50, 85, fill='#ffb6c1', outline='')
        c.create_oval(100, 80, 105, 85, fill='#ffb6c1', outline='')

    def draw_happy_pet(self):
        """绘制开心宠物"""
        c = self.canvas
        # 身体
        c.create_oval(30, 30, 120, 120, fill='#f0e6d3', outline='')
        # 开心的眼睛 ^^
        c.create_line(55, 65, 60, 60, fill='#333', width=2)
        c.create_line(60, 60, 65, 65, fill='#333', width=2)
        c.create_line(85, 65, 90, 60, fill='#333', width=2)
        c.create_line(90, 60, 95, 65, fill='#333', width=2)
        # 大笑
        c.create_arc(55, 70, 95, 90, start=0, extent=180, style='arc', width=3, outline='#c9987a')
        # 高兴的表情线
        c.create_line(40, 50, 45, 45, fill='#ffb6c1', width=2)
        c.create_line(110, 50, 105, 45, fill='#ffb6c1', width=2)

    def draw_sleeping_pet(self):
        """绘制睡觉宠物"""
        c = self.canvas
        # 身体
        c.create_oval(30, 30, 120, 120, fill='#e8d5f0', outline='')
        # 闭眼 - -
        c.create_line(55, 65, 65, 65, fill='#666', width=2)
        c.create_line(87, 65, 93, 65, fill='#666', width=2)
        # 小嘴
        c.create_oval(70, 80, 80, 85, fill='#aaa', outline='')
        # Zzz
        c.create_text(125, 40, text='Z', fill='#999', font=('Arial', 12, 'bold'))
        c.create_text(130, 30, text='z', fill='#bbb', font=('Arial', 10))

    def draw_eating_pet(self):
        """绘制吃东西宠物"""
        c = self.canvas
        # 身体
        c.create_oval(30, 30, 120, 120, fill='#f0e6d3', outline='')
        # 眼睛
        c.create_oval(55, 60, 65, 70, fill='#333', outline='')
        c.create_oval(85, 60, 95, 70, fill='#333', outline='')
        # 吃东西的嘴
        c.create_oval(65, 75, 85, 85, fill='#c9987a', outline='')
        c.create_oval(60, 80, 75, 85, fill='#c9987a', outline='')
        c.create_oval(80, 80, 85, 85, fill='#c9987a', outline='')
        # 食物
        c.create_oval(45, 90, 55, 100, fill='#ff6b6b', outline='')
        c.create_oval(50, 95, 60, 105, fill='#ff8e53', outline='')

    def setup_events(self):
        """设置事件"""
        # 左键拖拽
        self.main_frame.bind('<Button-1>', self.on_drag_start)
        self.main_frame.bind('<B1-Motion>', self.on_drag_motion)
        self.main_frame.bind('<ButtonRelease-1>', self.on_drag_end)

        # 右键菜单
        self.main_frame.bind('<Button-3>', self.show_menu)

    def on_drag_start(self, event):
        self.dragging = True
        self.drag_start_x = event.x
        self.drag_start_y = event.y

    def on_drag_motion(self, event):
        if self.dragging:
            dx = event.x - self.drag_start_x
            dy = event.y - self.drag_start_y
            x = self.root.winfo_x() + dx
            y = self.root.winfo_y() + dy
            self.root.geometry(f"+{x}+{y}")

    def on_drag_end(self, event):
        self.dragging = False

    def show_menu(self, event):
        """显示右键菜单"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="喂食 (F)", command=self.feed)
        menu.add_command(label="玩耍 (P)", command=self.play)
        menu.add_command(label="睡觉 (S)", command=self.toggle_sleep)
        menu.add_separator()
        menu.add_command(label="状态", command=self.show_status)
        menu.add_separator()
        menu.add_command(label="退出", command=self.quit)
        menu.post(event.x_root, event.y_root)

    def feed(self):
        self.state['hunger'] = min(100, self.state['hunger'] + 30)
        self.state['happiness'] = min(100, self.state['happiness'] + 5)
        self.state['xp'] += 10
        self.state['mood'] = 'eating'
        self.update_status()
        self.draw_pet()

        # 1秒后恢复正常
        self.root.after(1000, lambda: self.set_mood('happy'))

    def play(self):
        self.state['happiness'] = min(100, self.state['happiness'] + 25)
        self.state['energy'] = max(0, self.state['energy'] - 10)
        self.state['xp'] += 15
        self.state['mood'] = 'happy'
        self.update_status()
        self.draw_pet()

        # 跳动动画
        for i in range(3):
            y_offset = -10 if i % 2 == 0 else 0
            self.root.geometry(f"{self.width}x{self.height}+{self.root.winfo_x()}+{self.root.winfo_y() + y_offset}")
            self.root.update()
            time.sleep(0.1)

    def toggle_sleep(self):
        self.state['is_sleeping'] = not self.state['is_sleeping']
        if self.state['is_sleeping']:
            self.state['energy'] = min(100, self.state['energy'] + 30)
            self.state['mood'] = 'sleep'
        else:
            self.state['mood'] = 'happy'
        self.update_status()
        self.draw_pet()

    def show_status(self):
        """显示状态对话框"""
        status = tk.Toplevel(self.root)
        status.title(f"{self.state['name']} Status")
        status.geometry('250x200')
        status.configure(bg='#f0f0f0')

        info = f"""名称: {self.state['name']}
等级: {self.state['level']}
经验: {self.state['xp']}

饱食度: {self.state['hunger']}/100
快乐值: {self.state['happiness']}/100
能量: {self.state['energy']}/100

心情: {self.state['mood']}
睡眠: {'是' if self.state['is_sleeping'] else '否'}
"""

        tk.Label(status, text=info, bg='#f0f0f0', font=('Arial', 10), justify='left').pack(padx=20, pady=20)
        tk.Button(status, text='关闭', command=status.destroy).pack(pady=10)

    def set_mood(self, mood):
        self.state['mood'] = mood
        self.draw_pet()

    def update_status(self):
        self.status_label.config(text=f"Lv.{self.state['level']} | <3 {self.state['happiness']}")

    def animate(self):
        """动画循环"""
        self.animation_frame = 0

        def anim():
            if not self.root.winfo_exists():
                return

            # 根据心情切换动画
            if not self.state['is_sleeping'] and self.state['mood'] == 'happy':
                self.animation_frame += 1
                if self.animation_frame % 60 == 0:  # 每60帧眨眼
                    self.blink()

            self.root.after(100, anim)

        anim()

    def blink(self):
        """眨眼动画"""
        self.canvas.delete("all")
        # 眨眼时的身体
        self.canvas.create_oval(30, 30, 120, 120, fill='#f0e6d3', outline='')
        # 闭眼
        self.canvas.create_line(55, 65, 65, 65, fill='#333', width=2)
        self.canvas.create_line(87, 65, 93, 65, fill='#333', width=2)
        # 闭眼时的嘴
        self.canvas.create_arc(60, 75, 90, 85, start=0, extent=180, style='arc', width=2, outline='#c9987a')

        # 100ms后恢复
        self.root.after(100, self.draw_pet)

    def load_state(self):
        """加载状态"""
        state_file = Path.home() / '.claude-pet-companion' / 'pet_state.json'
        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    saved = json.load(f)
                    self.state.update(saved)
            except:
                pass

    def save_state(self):
        """保存状态"""
        state_file = Path.home() / '.claude-pet-companion' / 'pet_state.json'
        state_file.parent.mkdir(parents=True, exist_ok=True)
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, indent=2, ensure_ascii=False)

    def auto_save(self):
        """自动保存"""
        def save():
            if self.root.winfo_exists():
                self.save_state()
                self.root.after(30000, save)  # 每30秒保存

        save()

    def quit(self):
        """退出"""
        self.save_state()
        self.root.destroy()

    def run(self):
        """运行宠物"""
        self.root.mainloop()


def main():
    pet = DesktopPet()
    pet.run()


if __name__ == "__main__":
    main()
