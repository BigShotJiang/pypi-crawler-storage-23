"""Tests for default HttpTransport retry wiring from VedaTraceConfig."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace import VedaTrace
from vedatrace.config import RetryConfig, VedaTraceConfig
from vedatrace.transports.http import HttpTransport


class DummyTransport:
    def emit(self, records):  # type: ignore[no-untyped-def]
        _ = records
        return None

    def close(self) -> None:
        return None


class TestDefaultTransportsRetry(unittest.TestCase):
    def test_default_http_transport_receives_retry_and_on_error(self) -> None:
        seen: list[Exception] = []

        def on_error(exc: Exception) -> None:
            seen.append(exc)

        retry = RetryConfig(max_retries=3, retry_delay_seconds=0.25)
        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            console_enabled=False,
            retry=retry,
            on_error=on_error,
        )
        logger = VedaTrace(
            api_key="ignored-key",
            service="ignored-service",
            config=config,
        )

        transports = logger._engine._transports
        self.assertEqual(len(transports), 1)
        self.assertIsInstance(transports[0], HttpTransport)
        http_transport = transports[0]
        self.assertIs(http_transport._retry, retry)
        self.assertIs(http_transport._on_error, on_error)
        self.assertEqual(seen, [])

    def test_custom_transports_bypass_default_http_transport_creation(self) -> None:
        custom_transport = DummyTransport()
        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            retry=RetryConfig(max_retries=5, retry_delay_seconds=0.5),
            transports=[custom_transport],
        )
        logger = VedaTrace(
            api_key="ignored-key",
            service="ignored-service",
            config=config,
        )

        transports = logger._engine._transports
        self.assertEqual(len(transports), 1)
        self.assertIs(transports[0], custom_transport)
        self.assertFalse(any(isinstance(transport, HttpTransport) for transport in transports))


if __name__ == "__main__":
    unittest.main()
