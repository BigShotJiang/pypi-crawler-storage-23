"""Smoke tests for README-style examples without real network calls."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace import BatchingConfig, VedaTrace, VedaTraceConfig
from vedatrace.models import LogRecord


class _RecordingTransport:
    def __init__(self) -> None:
        self.batches: list[list[LogRecord]] = []

    def emit(self, records: list[LogRecord]) -> None:
        self.batches.append(list(records))

    def close(self) -> None:
        return None


class TestReadmeExamples(unittest.TestCase):
    def test_default_style_logger_with_custom_transport_does_not_raise(self) -> None:
        transport = _RecordingTransport()
        config = VedaTraceConfig(
            api_key="YOUR_API_KEY",
            service="my-service",
            console_enabled=False,
            transports=[transport],
        )
        logger = VedaTrace(
            api_key="YOUR_API_KEY",
            service="my-service",
            config=config,
        )

        logger.info("hello from vedatrace", metadata={"request_id": "123"})
        logger.debug("debug event", metadata={"module": "api"})

    def test_batching_example_path_does_not_raise(self) -> None:
        transport = _RecordingTransport()
        config = VedaTraceConfig(
            api_key="YOUR_API_KEY",
            service="my-service",
            console_enabled=False,
            transports=[transport],
            batching=BatchingConfig(
                enabled=True,
                batch_size=2,
                flush_interval_seconds=0.0,
            ),
        )
        logger = VedaTrace(
            api_key="YOUR_API_KEY",
            service="my-service",
            config=config,
        )

        logger.info("batched one", metadata={"step": 1})
        logger.info("batched two", metadata={"step": 2})
        logger.flush()

    def test_child_logger_example_path_does_not_raise(self) -> None:
        transport = _RecordingTransport()
        config = VedaTraceConfig(
            api_key="YOUR_API_KEY",
            service="my-service",
            console_enabled=False,
            transports=[transport],
        )
        parent = VedaTrace(
            api_key="YOUR_API_KEY",
            service="my-service",
            config=config,
        )
        api_logger = parent.child({"module": "api"})

        api_logger.info("request handled", {"request_id": "123"})
        api_logger.debug("processing")
        api_logger.flush()
        api_logger.close()


if __name__ == "__main__":
    unittest.main()
