"""Tests for HttpTransport retry wiring scaffolding."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.config import RetryConfig
from vedatrace.transports.http import HttpTransport


class TestHttpTransportRetryWiring(unittest.TestCase):
    def test_constructor_accepts_and_stores_retry_config(self) -> None:
        retry = RetryConfig(max_retries=3, retry_delay_seconds=0.25)
        seen: list[Exception] = []

        def on_error(exc: Exception) -> None:
            seen.append(exc)

        transport = HttpTransport(
            api_key="k",
            retry=retry,
            on_error=on_error,
        )

        self.assertIs(transport._retry, retry)
        self.assertIs(transport._on_error, on_error)
        self.assertEqual(seen, [])

    def test_constructor_default_retry_is_none(self) -> None:
        transport = HttpTransport(api_key="k")

        self.assertIsNone(transport._retry)


if __name__ == "__main__":
    unittest.main()
