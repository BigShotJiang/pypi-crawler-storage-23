"""Tests for default transport wiring in the VedaTrace factory."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace import VedaTrace
from vedatrace.config import VedaTraceConfig
from vedatrace.transports.console import ConsoleTransport
from vedatrace.transports.http import HttpTransport


class DummyTransport:
    def emit(self, records):  # type: ignore[no-untyped-def]
        return None

    def close(self) -> None:
        return None


class TestDefaultTransports(unittest.TestCase):
    def test_defaults_include_console_and_http_when_console_enabled(self) -> None:
        logger = VedaTrace(api_key="test-key", service="orders")
        transports = logger._engine._transports

        self.assertEqual(len(transports), 2)
        self.assertIsInstance(transports[0], ConsoleTransport)
        self.assertIsInstance(transports[1], HttpTransport)

    def test_defaults_include_only_http_when_console_disabled(self) -> None:
        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            console_enabled=False,
        )
        logger = VedaTrace(
            api_key="ignored-key",
            service="ignored-service",
            config=config,
        )
        transports = logger._engine._transports

        self.assertEqual(len(transports), 1)
        self.assertIsInstance(transports[0], HttpTransport)

    def test_user_provided_transports_disable_defaults(self) -> None:
        custom_transport = DummyTransport()
        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            transports=[custom_transport],
        )
        logger = VedaTrace(
            api_key="ignored-key",
            service="ignored-service",
            config=config,
        )
        transports = logger._engine._transports

        self.assertEqual(len(transports), 1)
        self.assertIs(transports[0], custom_transport)
