"""Tests for Phase 1 model enums and typing aliases."""

from __future__ import annotations

import pathlib
import sys
import unittest
from unittest import mock


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.models import LogLevel, LogRecord


class TestLogLevel(unittest.TestCase):
    def test_wire_values_are_lowercase(self) -> None:
        expected = {
            LogLevel.DEBUG: "debug",
            LogLevel.INFO: "info",
            LogLevel.WARNING: "warning",
            LogLevel.ERROR: "error",
            LogLevel.FATAL: "fatal",
        }
        self.assertEqual({level: level.value for level in LogLevel}, expected)

    def test_iterating_levels_yields_expected_members(self) -> None:
        expected = {
            LogLevel.DEBUG,
            LogLevel.INFO,
            LogLevel.WARNING,
            LogLevel.ERROR,
            LogLevel.FATAL,
        }
        self.assertEqual(set(LogLevel), expected)


class TestLogRecord(unittest.TestCase):
    def test_create_fills_timestamp_and_metadata_defaults(self) -> None:
        expected_timestamp = "2026-02-19T17:42:47.957694Z"
        with mock.patch(
            "vedatrace.models.now_utc_iso8601",
            return_value=expected_timestamp,
        ):
            record = LogRecord.create(
                level=LogLevel.INFO,
                message="hello",
                service="orders",
            )

        self.assertEqual(record.timestamp, expected_timestamp)
        self.assertEqual(record.metadata, {})

    def test_to_wire_emits_expected_schema(self) -> None:
        metadata = {
            "request_id": "abc-123",
            "attempt": 1,
            "nested": {"ok": True},
        }
        record = LogRecord.create(
            level=LogLevel.ERROR,
            message="failed request",
            service="orders",
            timestamp="2026-02-19T17:42:47.957694Z",
            metadata=metadata,
        )

        self.assertEqual(
            record.to_wire(),
            {
                "level": "error",
                "message": "failed request",
                "service": "orders",
                "timestamp": "2026-02-19T17:42:47.957694Z",
                "metadata": metadata,
            },
        )
