"""Tests for Phase 1 time utilities."""

from __future__ import annotations

import pathlib
import sys
import unittest
from datetime import datetime


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.time import now_utc_iso8601


class TestNowUtcIso8601(unittest.TestCase):
    def test_returns_rfc3339_like_utc_string(self) -> None:
        value = now_utc_iso8601()
        self.assertIsInstance(value, str)
        self.assertIn("T", value)
        self.assertTrue(value.endswith("Z"))

    def test_parses_back_as_utc_datetime(self) -> None:
        value = now_utc_iso8601()
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        self.assertIsNotNone(parsed.tzinfo)
        self.assertEqual(parsed.utcoffset().total_seconds(), 0.0)

    def test_two_calls_are_monotonic_non_decreasing(self) -> None:
        first = now_utc_iso8601()
        second = now_utc_iso8601()
        first_dt = datetime.fromisoformat(first.replace("Z", "+00:00"))
        second_dt = datetime.fromisoformat(second.replace("Z", "+00:00"))
        self.assertLessEqual(first_dt, second_dt)
