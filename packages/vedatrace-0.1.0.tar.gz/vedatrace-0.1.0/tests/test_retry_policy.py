"""Unit tests for retry policy behavior."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.retry import RetryPolicy


class TestRetryPolicy(unittest.TestCase):
    def test_should_retry_never_when_max_retries_is_zero(self) -> None:
        policy = RetryPolicy(max_retries=0, retry_delay_seconds=0.5)

        self.assertFalse(policy.should_retry(1, RuntimeError("x")))
        self.assertFalse(policy.should_retry(2, RuntimeError("x")))

    def test_should_retry_respects_max_retries(self) -> None:
        policy = RetryPolicy(max_retries=2, retry_delay_seconds=0.5)

        self.assertTrue(policy.should_retry(1, RuntimeError("x")))
        self.assertTrue(policy.should_retry(2, RuntimeError("x")))
        self.assertFalse(policy.should_retry(3, RuntimeError("x")))

    def test_delay_seconds_returns_fixed_delay(self) -> None:
        policy = RetryPolicy(max_retries=3, retry_delay_seconds=1.25)

        self.assertEqual(policy.delay_seconds(1), 1.25)
        self.assertEqual(policy.delay_seconds(5), 1.25)

    def test_invalid_max_retries_raises(self) -> None:
        with self.assertRaises(ValueError):
            RetryPolicy(max_retries=-1, retry_delay_seconds=0.0)

    def test_invalid_retry_delay_seconds_raises(self) -> None:
        with self.assertRaises(ValueError):
            RetryPolicy(max_retries=0, retry_delay_seconds=-0.1)


if __name__ == "__main__":
    unittest.main()
