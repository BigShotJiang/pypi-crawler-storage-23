"""Tests for Phase 1 configuration models."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.config import BatchingConfig, RetryConfig, VedaTraceConfig


class DummyTransport:
    def emit(self, records: list[object]) -> None:
        return None

    def close(self) -> None:
        return None


class TestVedaTraceConfig(unittest.TestCase):
    def test_defaults_include_batched_disabled_and_no_retries(self) -> None:
        config = VedaTraceConfig(api_key="test-key", service="orders")
        self.assertFalse(config.batching.enabled)
        self.assertEqual(config.retry.max_retries, 0)
        self.assertEqual(config.retry.retry_delay_seconds, 0.0)

    def test_invalid_batching_values_raise(self) -> None:
        with self.assertRaises(ValueError):
            BatchingConfig(batch_size=0)
        with self.assertRaises(ValueError):
            BatchingConfig(flush_interval_seconds=-1.0)

    def test_invalid_retry_values_raise(self) -> None:
        with self.assertRaises(ValueError):
            RetryConfig(max_retries=-1)
        with self.assertRaises(ValueError):
            RetryConfig(retry_delay_seconds=-0.1)

    def test_invalid_required_strings_raise(self) -> None:
        with self.assertRaises(ValueError):
            VedaTraceConfig(api_key="", service="orders")
        with self.assertRaises(ValueError):
            VedaTraceConfig(api_key="test-key", service="  ")

    def test_on_error_is_stored(self) -> None:
        captured: list[Exception] = []

        def on_error(exc: Exception) -> None:
            captured.append(exc)

        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            on_error=on_error,
        )
        self.assertIs(config.on_error, on_error)

    def test_transports_default_to_none(self) -> None:
        config = VedaTraceConfig(api_key="test-key", service="orders")
        self.assertIsNone(config.transports)

    def test_transports_are_copied_from_caller_list(self) -> None:
        caller_transports = [DummyTransport()]
        config = VedaTraceConfig(
            api_key="test-key",
            service="orders",
            transports=caller_transports,
        )

        self.assertIsNotNone(config.transports)
        self.assertEqual(len(config.transports or []), 1)
        self.assertIsNot(config.transports, caller_transports)
