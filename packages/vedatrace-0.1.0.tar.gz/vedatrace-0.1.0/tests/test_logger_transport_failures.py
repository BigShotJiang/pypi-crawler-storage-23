"""Integration tests for Logger -> Engine -> failing transport safety."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace._engine import Engine
from vedatrace.config import VedaTraceConfig
from vedatrace.logger import Logger


class FailingTransport:
    def emit(self, records):  # type: ignore[no-untyped-def]
        raise RuntimeError("transport failure")

    def close(self) -> None:
        return None


class TestLoggerTransportFailures(unittest.TestCase):
    def test_logger_info_swallow_failure_and_calls_on_error_once(self) -> None:
        seen: list[Exception] = []

        def on_error(exc: Exception) -> None:
            seen.append(exc)

        config = VedaTraceConfig(
            api_key="k",
            service="s",
            transports=[FailingTransport()],
            on_error=on_error,
        )
        logger = Logger(config, Engine(config))

        logger.info("x")

        self.assertEqual(len(seen), 1)
        self.assertIsInstance(seen[0], RuntimeError)

    def test_logger_info_failure_does_not_break_subsequent_calls(self) -> None:
        seen: list[Exception] = []

        def on_error(exc: Exception) -> None:
            seen.append(exc)

        config = VedaTraceConfig(
            api_key="k",
            service="s",
            transports=[FailingTransport()],
            on_error=on_error,
        )
        logger = Logger(config, Engine(config))

        logger.info("x")
        logger.info("x")

        self.assertEqual(len(seen), 2)
