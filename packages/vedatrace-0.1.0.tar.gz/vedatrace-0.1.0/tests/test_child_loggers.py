"""Tests for child logger metadata precedence and shared engine semantics."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace._engine import Engine
from vedatrace.config import VedaTraceConfig
from vedatrace.logger import Logger


class TestChildLoggers(unittest.TestCase):
    def setUp(self) -> None:
        self.config = VedaTraceConfig(api_key="test-key", service="orders")
        self.engine = Engine(self.config)
        self.parent = Logger(
            self.config,
            self.engine,
            default_metadata={"env": "prod", "region": "us"},
        )

    def test_parent_default_metadata_appears_in_child_logs(self) -> None:
        child = self.parent.child()

        child.info("child-log")

        record = self.engine._test_records[0]
        self.assertEqual(record.metadata["env"], "prod")
        self.assertEqual(record.metadata["region"], "us")

    def test_child_defaults_override_parent(self) -> None:
        child = self.parent.child(default_metadata={"region": "eu", "team": "core"})

        child.info("child-log")

        record = self.engine._test_records[0]
        self.assertEqual(record.metadata["env"], "prod")
        self.assertEqual(record.metadata["region"], "eu")
        self.assertEqual(record.metadata["team"], "core")

    def test_call_metadata_overrides_parent_and_child(self) -> None:
        child = self.parent.child(default_metadata={"region": "eu", "request_id": "child"})

        child.info(
            "child-log",
            metadata={"region": "call", "request_id": "call"},
        )

        record = self.engine._test_records[0]
        self.assertEqual(record.metadata["env"], "prod")
        self.assertEqual(record.metadata["region"], "call")
        self.assertEqual(record.metadata["request_id"], "call")

    def test_parent_logs_use_parent_defaults_only(self) -> None:
        _ = self.parent.child(default_metadata={"team": "core"})

        self.parent.info("parent-log")

        record = self.engine._test_records[0]
        self.assertEqual(record.metadata, {"env": "prod", "region": "us"})

    def test_child_uses_shared_engine_instance(self) -> None:
        child = self.parent.child(default_metadata={"team": "core"})

        self.assertIs(child._engine, self.parent._engine)

    def test_child_close_does_not_close_shared_engine(self) -> None:
        child = self.parent.child(default_metadata={"team": "core"})

        child.close()
        self.parent.info("still-open")

        self.assertEqual(len(self.engine._test_records), 1)
        self.assertEqual(self.engine._test_records[0].message, "still-open")

    def test_child_inherits_service_unless_overridden(self) -> None:
        inherited = self.parent.child()
        overridden = self.parent.child(service="payments")

        inherited.info("inherits")
        overridden.info("overrides")

        first = self.engine._test_records[0]
        second = self.engine._test_records[1]
        self.assertEqual(first.service, "orders")
        self.assertEqual(second.service, "payments")


if __name__ == "__main__":
    unittest.main()
