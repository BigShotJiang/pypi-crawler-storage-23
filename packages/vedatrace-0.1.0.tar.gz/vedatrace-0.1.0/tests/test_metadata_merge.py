"""Tests for internal metadata merge helper."""

from __future__ import annotations

import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from vedatrace.logger import merge_metadata


class TestMetadataMerge(unittest.TestCase):
    def test_parent_keys_are_present_when_not_overwritten(self) -> None:
        merged = merge_metadata(
            parent={"request_id": "req-1"},
            child={},
            call={},
        )

        self.assertEqual(merged, {"request_id": "req-1"})

    def test_child_overrides_parent(self) -> None:
        merged = merge_metadata(
            parent={"env": "prod", "region": "us-east"},
            child={"env": "staging"},
            call={},
        )

        self.assertEqual(merged["env"], "staging")
        self.assertEqual(merged["region"], "us-east")

    def test_call_overrides_parent_and_child(self) -> None:
        merged = merge_metadata(
            parent={"trace_id": "p"},
            child={"trace_id": "c"},
            call={"trace_id": "call"},
        )

        self.assertEqual(merged["trace_id"], "call")

    def test_inputs_are_not_mutated(self) -> None:
        parent = {"a": 1}
        child = {"b": 2}
        call = {"c": 3}

        merged = merge_metadata(parent=parent, child=child, call=call)
        merged["a"] = 10
        merged["b"] = 20
        merged["c"] = 30

        self.assertEqual(parent, {"a": 1})
        self.assertEqual(child, {"b": 2})
        self.assertEqual(call, {"c": 3})


if __name__ == "__main__":
    unittest.main()
