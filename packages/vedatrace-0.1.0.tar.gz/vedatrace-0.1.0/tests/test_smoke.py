import importlib
import pathlib
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class SmokeTest(unittest.TestCase):
    def test_import_and_version(self) -> None:
        module = importlib.import_module("vedatrace")
        self.assertTrue(hasattr(module, "__version__"))

    def test_phase1_public_exports_import(self) -> None:
        from vedatrace import (
            BatchingConfig,
            ConsoleTransport,
            HttpTransport,
            Logger,
            LogLevel,
            LogRecord,
            RetryConfig,
            Transport,
            VedaTrace,
            VedaTraceConfig,
            now_utc_iso8601,
            safe_call,
        )

        self.assertTrue(isinstance(LogLevel.INFO.value, str))
        self.assertTrue(callable(now_utc_iso8601))
        self.assertTrue(callable(safe_call))
        self.assertTrue(callable(LogRecord.create))
        self.assertTrue(callable(BatchingConfig))
        self.assertTrue(callable(RetryConfig))
        self.assertTrue(callable(VedaTraceConfig))
        self.assertTrue(callable(Transport))
        self.assertTrue(callable(ConsoleTransport))
        self.assertTrue(callable(HttpTransport))
        self.assertTrue(callable(Logger))
        self.assertTrue(callable(VedaTrace))

    def test_factory_logger_can_log_without_raising(self) -> None:
        from vedatrace import VedaTrace, VedaTraceConfig

        config = VedaTraceConfig(
            api_key="smoke-key",
            service="smoke-service",
            console_enabled=False,
        )
        logger = VedaTrace(
            api_key="smoke-key",
            service="smoke-service",
            config=config,
        )
        logger.info("hello")


if __name__ == "__main__":
    unittest.main()
