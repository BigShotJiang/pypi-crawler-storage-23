"""VedaTrace Python SDK public package surface."""

from vedatrace.config import BatchingConfig, RetryConfig
from vedatrace.config import VedaTraceConfig
from vedatrace.logger import Logger
from vedatrace.models import LogLevel, LogRecord
from vedatrace.safe import safe_call
from vedatrace.time import now_utc_iso8601
from vedatrace.transports import ConsoleTransport, HttpTransport, Transport

__version__ = "0.1.0"


def VedaTrace(
    api_key: str,
    service: str,
    *,
    config: VedaTraceConfig | None = None,
) -> Logger:
    """Create a logger instance with configured transports."""

    from vedatrace._engine import Engine
    from vedatrace.transports.console import ConsoleTransport
    from vedatrace.transports.http import HttpTransport

    resolved_config = (
        config
        if config is not None
        else VedaTraceConfig(api_key=api_key, service=service)
    )

    if resolved_config.transports is not None:
        transports = list(resolved_config.transports)
    else:
        transports = []
        if resolved_config.console_enabled:
            transports.append(ConsoleTransport())
        transports.append(
            HttpTransport(
                api_key=resolved_config.api_key,
                retry=resolved_config.retry,
                on_error=resolved_config.on_error,
            )
        )

    return Logger(resolved_config, Engine(resolved_config, transports=transports))

__all__ = [
    "__version__",
    "LogLevel",
    "LogRecord",
    "VedaTraceConfig",
    "BatchingConfig",
    "RetryConfig",
    "Transport",
    "ConsoleTransport",
    "HttpTransport",
    "now_utc_iso8601",
    "safe_call",
    "Logger",
    "VedaTrace",
]
