"""Retry policy primitives for HTTP retry behavior."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Fixed-delay retry policy."""

    max_retries: int
    retry_delay_seconds: float

    def __post_init__(self) -> None:
        if self.max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if self.retry_delay_seconds < 0:
            raise ValueError("retry_delay_seconds must be >= 0")

    def should_retry(self, attempt: int, exc: Exception) -> bool:
        """Return True when the failure attempt should be retried."""

        _ = exc
        return attempt <= self.max_retries

    def delay_seconds(self, attempt: int) -> float:
        """Return fixed delay in seconds for the next retry."""

        _ = attempt
        return self.retry_delay_seconds
