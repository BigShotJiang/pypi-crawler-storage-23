"""Time utilities for VedaTrace Phase 1."""

# TODO(phase-1): Add clock abstraction for deterministic testing in logger core.

from __future__ import annotations

from datetime import datetime, timezone


def now_utc_iso8601() -> str:
    """Return current UTC time in ISO-8601 format with trailing Z."""

    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace(
        "+00:00",
        "Z",
    )
