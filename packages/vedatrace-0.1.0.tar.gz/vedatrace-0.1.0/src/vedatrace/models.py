"""Domain models for VedaTrace Phase 1."""

# TODO(phase-1): Extend model validation rules once logger core is added.

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TypeAlias

from vedatrace.time import now_utc_iso8601


JSONPrimitive: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = "JSONPrimitive | list[JSONValue] | dict[str, JSONValue]"
Metadata: TypeAlias = dict[str, JSONValue]


class LogLevel(str, Enum):
    """Supported log levels using lowercase wire values."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    FATAL = "fatal"


@dataclass(frozen=True, slots=True)
class LogRecord:
    """Immutable log record schema used across the SDK."""

    level: LogLevel
    message: str
    service: str
    timestamp: str
    metadata: Metadata = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Copy metadata to prevent external mutation after construction.
        object.__setattr__(self, "metadata", dict(self.metadata))

    @staticmethod
    def create(
        level: LogLevel,
        message: str,
        service: str,
        *,
        timestamp: str | None = None,
        metadata: Metadata | None = None,
    ) -> "LogRecord":
        """Create a record with sensible defaults for timestamp and metadata."""

        return LogRecord(
            level=level,
            message=message,
            service=service,
            timestamp=timestamp if timestamp is not None else now_utc_iso8601(),
            metadata={} if metadata is None else metadata,
        )

    def to_wire(self) -> dict[str, JSONValue]:
        """Return wire-ready schema suitable for JSON serialization."""

        return {
            "level": self.level.value,
            "message": self.message,
            "service": self.service,
            "timestamp": self.timestamp,
            "metadata": dict(self.metadata),
        }
