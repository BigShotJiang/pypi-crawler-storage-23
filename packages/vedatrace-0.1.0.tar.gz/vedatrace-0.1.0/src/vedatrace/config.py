"""Configuration models for VedaTrace Phase 1."""

# TODO(phase-1): Add stricter validation and serialization helpers.

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, TypeAlias

from vedatrace.transports.base import Transport


ErrorCallback: TypeAlias = Callable[[Exception], None]


@dataclass(frozen=True, slots=True)
class BatchingConfig:
    """Batching behavior configuration."""

    enabled: bool = False
    batch_size: int = 10
    flush_interval_seconds: float = 5.0

    def __post_init__(self) -> None:
        if self.batch_size <= 0:
            raise ValueError("batch_size must be > 0")
        if self.flush_interval_seconds < 0:
            raise ValueError("flush_interval_seconds must be >= 0")


@dataclass(frozen=True, slots=True)
class RetryConfig:
    """Retry policy configuration."""

    max_retries: int = 0
    retry_delay_seconds: float = 0.0

    def __post_init__(self) -> None:
        if self.max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if self.retry_delay_seconds < 0:
            raise ValueError("retry_delay_seconds must be >= 0")


@dataclass(frozen=True, slots=True)
class VedaTraceConfig:
    """Root SDK configuration for Phase 1 surfaces."""

    api_key: str
    service: str
    console_enabled: bool = True
    batching: BatchingConfig = field(default_factory=BatchingConfig)
    retry: RetryConfig = field(default_factory=RetryConfig)
    transports: list[Transport] | None = None
    on_error: ErrorCallback | None = None

    def __post_init__(self) -> None:
        if not self.api_key.strip():
            raise ValueError("api_key must be non-empty")
        if not self.service.strip():
            raise ValueError("service must be non-empty")
        if self.transports is not None:
            object.__setattr__(self, "transports", list(self.transports))
