"""Base transport protocol for VedaTrace."""

from __future__ import annotations

from typing import Protocol

from vedatrace.models import LogRecord


class Transport(Protocol):
    """Transport interface for batched record delivery."""

    def emit(self, records: list[LogRecord]) -> None:
        """Emit one or more records."""

    def close(self) -> None:
        """Release transport resources."""
