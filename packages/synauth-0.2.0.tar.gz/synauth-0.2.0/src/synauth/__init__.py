"""SynAuth SDK — Human-approved AI agent actions via TOTP or Face ID."""

__version__ = "0.2.0"

from synauth.client import (
    SynAuthClient,
    SynAuthAdmin,
    SynAuthError,
    SynAuthAPIError,
    RateLimitError,
    ActionExpiredError,
    ActionDeniedError,
    ApprovalTimeoutError,
    VaultExecutionError,
    compute_content_hash,
)
from synauth.pay import SynPayClient

# Backward compatibility
AgentAuthClient = SynAuthClient
