# Granite Code 8B Deployment Guide

This guide covers deploying the Granite Code 8B model for use with Sanicode's LLM-powered analysis features on OpenShift.

## Prerequisites

- OpenShift 4.12+ cluster with GPU-enabled worker nodes
- NVIDIA GPU Operator installed (provides `nvidia.com/gpu` resource)
- At least 24 GiB GPU memory (1x NVIDIA A10G, A100, or equivalent)
- `granite-code` namespace created: `oc new-project granite-code`

## Deployment

Apply the manifests in order:

```bash
NAMESPACE=granite-code
oc apply -f models/granite-code-8b/manifests/deployment.yaml -n $NAMESPACE
oc apply -f models/granite-code-8b/manifests/service.yaml -n $NAMESPACE
oc apply -f models/granite-code-8b/manifests/pdb.yaml -n $NAMESPACE
oc apply -f models/granite-code-8b/manifests/servicemonitor.yaml -n $NAMESPACE
```

Wait for the pod to become ready (initial model download takes 5-10 minutes on first deploy):

```bash
oc rollout status deployment/granite-code-8b -n $NAMESPACE --timeout=600s
```

Verify the endpoint:

```bash
oc port-forward svc/granite-code-8b 8080:8080 -n $NAMESPACE &
bash scripts/validate-granite.sh
```

## Air-Gapped Deployment

In disconnected environments, model weights cannot be downloaded at startup. Pre-stage them on a PVC.

### 1. Create a PVC for Model Weights

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: granite-code-weights
  namespace: granite-code
spec:
  accessModes: [ReadWriteOnce]
  resources:
    requests:
      storage: 20Gi
  storageClassName: gp3-csi  # Adjust to your cluster's StorageClass
```

### 2. Stage Model Weights

Use a one-shot Job to download the weights into the PVC. On an internet-connected workstation:

```bash
# Download to a local cache
pip install huggingface-hub
huggingface-cli download ibm-granite/granite-8b-code-instruct-128k --local-dir ./granite-weights
```

Transfer to the PVC (via a staging pod, `oc rsync`, or an init container):

```bash
oc run weight-stager --image=registry.redhat.io/ubi9/ubi-minimal:latest \
    --restart=Never --overrides='{
  "spec": {
    "containers": [{
      "name": "weight-stager",
      "image": "registry.redhat.io/ubi9/ubi-minimal:latest",
      "command": ["sleep", "3600"],
      "volumeMounts": [{"name": "weights", "mountPath": "/weights"}]
    }],
    "volumes": [{"name": "weights", "persistentVolumeClaim": {"claimName": "granite-code-weights"}}]
  }
}' -n granite-code

oc rsync ./granite-weights/ weight-stager:/weights/hub/models--ibm-granite--granite-8b-code-instruct-128k/ -n granite-code
oc delete pod weight-stager -n granite-code
```

### 3. Update Deployment to Use PVC

In the deployment manifest, replace the `emptyDir` volume with the PVC:

```yaml
volumes:
  - name: model-cache
    persistentVolumeClaim:
      claimName: granite-code-weights
```

The HuggingFace cache layout expected by vLLM is:

```
/root/.cache/huggingface/
└── hub/
    └── models--ibm-granite--granite-8b-code-instruct-128k/
        ├── config.json
        ├── tokenizer.json
        ├── model-00001-of-00004.safetensors
        └── ...
```

## Sanicode Configuration

Configure Sanicode to use the deployed model in `sanicode.toml`:

```toml
[llm.fast]
endpoint = "http://granite-code-8b.granite-code.svc.cluster.local:8080/v1"
model = "granite-code-8b"

[llm.analysis]
endpoint = "http://granite-code-8b.granite-code.svc.cluster.local:8080/v1"
model = "granite-code-8b"
```

For tiered setups with a larger model for reasoning:

```toml
[llm.reasoning]
endpoint = "http://llama-3-70b.llm-serving.svc.cluster.local:8080/v1"
model = "llama-3.1-70b-instruct"
```

## Validation

Run the automated validation script:

```bash
GRANITE_ENDPOINT=http://localhost:8080 bash scripts/validate-granite.sh
```

Run the integration test suite:

```bash
SANICODE_TEST_LLM_ENDPOINT=http://localhost:8080/v1 pytest tests/integration/ -m integration -v
```

## Troubleshooting

### Model Name Mismatch

vLLM serves the model under the `--served-model-name` argument. If Sanicode reports `model not found`, verify the served name:

```bash
curl http://granite-code-8b.granite-code.svc.cluster.local:8080/v1/models | python3 -m json.tool
```

Ensure `sanicode.toml` `model` field matches the `id` in the response.

### GPU Out of Memory

Granite Code 8B requires ~16 GiB GPU memory. If the pod is OOMKilled:

- Reduce `--max-model-len` (default 8192) to 4096 in the deployment args
- Ensure no other GPU workloads compete on the same node
- Check GPU memory with: `oc exec <pod> -n granite-code -- nvidia-smi`

### Tokenizer Not Found (Air-Gapped)

vLLM requires the tokenizer files alongside the model weights. Ensure the PVC contains `tokenizer.json`, `tokenizer_config.json`, and `special_tokens_map.json` in the model directory. The `--trust-remote-code` flag in the deployment enables custom tokenizer configs used by Granite models.

### Slow First Request

The first request after pod startup may take 30-60s while vLLM loads the model into GPU memory. Subsequent requests use the cached model. The readiness probe accounts for this with `initialDelaySeconds: 60`.
