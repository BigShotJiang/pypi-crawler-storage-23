"""Tests for import analysis and framework detection."""

from __future__ import annotations

from pathlib import Path

from sanicode.scanner.imports import (
    ImportInfo,
    detect_frameworks,
)
from sanicode.scanner.languages.python import PythonPlugin

FAKE_PATH = Path("test.py")

plugin = PythonPlugin()


def _parse(code: str):
    return plugin.parse_source(code.encode())


class TestDetectImports:
    """Test import extraction from parse trees via PythonPlugin."""

    def test_simple_import(self):
        tree = _parse("import os")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "os"
        assert result[0].is_from is False
        assert result[0].names == []

    def test_dotted_import(self):
        tree = _parse("import os.path")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "os.path"

    def test_aliased_import(self):
        tree = _parse("import numpy as np")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "numpy"
        assert result[0].aliases == {"np": "numpy"}

    def test_from_import(self):
        tree = _parse("from flask import Flask, request")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "flask"
        assert result[0].names == ["Flask", "request"]
        assert result[0].is_from is True

    def test_from_import_with_alias(self):
        tree = _parse("from datetime import datetime as dt")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].aliases == {"dt": "datetime"}

    def test_multiple_imports(self):
        code = "import os\nimport sys\nfrom pathlib import Path"
        tree = _parse(code)
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 3

    def test_relative_import(self):
        tree = _parse("from . import utils")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        # tree-sitter captures the relative import dot as the module string
        assert result[0].module == "."
        assert result[0].names == ["utils"]

    def test_star_import(self):
        tree = _parse("from os.path import *")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert len(result) == 1
        assert result[0].names == ["*"]

    def test_empty_file(self):
        tree = _parse("")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert result == []

    def test_file_path_recorded(self):
        p = Path("/src/app.py")
        tree = _parse("import os")
        result = plugin.detect_imports(tree, p)
        assert result[0].file == p

    def test_line_number_recorded(self):
        tree = _parse("# comment\nimport os")
        result = plugin.detect_imports(tree, FAKE_PATH)
        assert result[0].line == 2


class TestDetectFrameworks:
    """Test framework detection from aggregated imports."""

    def test_flask_detected(self):
        imports = [
            ImportInfo(module="flask", names=["Flask"], file=FAKE_PATH, line=1, is_from=True),
        ]
        frameworks = detect_frameworks(imports)
        assert len(frameworks) == 1
        assert frameworks[0].name == "flask"

    def test_django_detected(self):
        imports = [
            ImportInfo(module="django.db", names=["models"], file=FAKE_PATH, line=1, is_from=True),
            ImportInfo(
                module="rest_framework.views",
                names=["APIView"],
                file=FAKE_PATH,
                line=2,
                is_from=True,
            ),
        ]
        frameworks = detect_frameworks(imports)
        assert len(frameworks) == 1
        assert frameworks[0].name == "django"
        assert "django.db" in frameworks[0].modules
        assert "rest_framework.views" in frameworks[0].modules

    def test_sqlalchemy_detected(self):
        imports = [
            ImportInfo(
                module="sqlalchemy",
                names=["create_engine"],
                file=FAKE_PATH,
                line=1,
                is_from=True,
            ),
        ]
        frameworks = detect_frameworks(imports)
        assert any(fw.name == "sqlalchemy" for fw in frameworks)

    def test_fastapi_detected(self):
        imports = [
            ImportInfo(
                module="fastapi",
                names=["FastAPI"],
                file=FAKE_PATH,
                line=1,
                is_from=True,
            ),
        ]
        frameworks = detect_frameworks(imports)
        assert any(fw.name == "fastapi" for fw in frameworks)

    def test_no_framework_for_stdlib(self):
        imports = [
            ImportInfo(module="os", names=[], file=FAKE_PATH, line=1),
            ImportInfo(module="sys", names=[], file=FAKE_PATH, line=2),
            ImportInfo(module="json", names=["dumps"], file=FAKE_PATH, line=3, is_from=True),
        ]
        frameworks = detect_frameworks(imports)
        assert frameworks == []

    def test_multiple_frameworks(self):
        imports = [
            ImportInfo(module="flask", names=["Flask"], file=FAKE_PATH, line=1, is_from=True),
            ImportInfo(
                module="sqlalchemy",
                names=["create_engine"],
                file=FAKE_PATH,
                line=2,
                is_from=True,
            ),
        ]
        frameworks = detect_frameworks(imports)
        names = {fw.name for fw in frameworks}
        assert names == {"flask", "sqlalchemy"}

    def test_empty_imports(self):
        assert detect_frameworks([]) == []

    def test_deduplicates_framework_modules(self):
        imports = [
            ImportInfo(module="flask", names=["Flask"], file=FAKE_PATH, line=1, is_from=True),
            ImportInfo(
                module="flask.views",
                names=["MethodView"],
                file=FAKE_PATH,
                line=2,
                is_from=True,
            ),
        ]
        frameworks = detect_frameworks(imports)
        assert len(frameworks) == 1
        assert frameworks[0].name == "flask"
        assert "flask" in frameworks[0].modules
        assert "flask.views" in frameworks[0].modules
