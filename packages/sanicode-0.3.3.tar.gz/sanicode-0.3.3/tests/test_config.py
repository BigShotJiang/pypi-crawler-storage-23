"""Tests for config loading and the `sanicode config` CLI command."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
from typer.testing import CliRunner

from sanicode.cli import app
from sanicode.config import (
    _DEFAULT_SEARCH_PATHS,
    SanicodeConfig,
    find_writable_config_path,
    load_config,
    write_llm_tier,
)

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[no-redef]

runner = CliRunner()

# ---------------------------------------------------------------------------
# Unit tests for load_config()
# ---------------------------------------------------------------------------


def test_load_config_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """load_config() with no file present returns defaults."""
    monkeypatch.chdir(tmp_path)
    cfg = load_config()
    assert isinstance(cfg, SanicodeConfig)
    assert cfg._source_path is None
    assert cfg.scan.include_extensions == [".py"]
    assert cfg.scan.max_file_size_kb == 512
    assert "owasp-asvs" in cfg.compliance.profiles
    assert cfg.llm.fast.endpoint == ""
    assert cfg.output.formats == ["markdown", "sarif"]


def test_load_config_from_file(tmp_path: Path) -> None:
    """load_config() with an explicit TOML populates fields correctly."""
    toml_content = """\
[llm.fast]
endpoint = "http://localhost:11434/v1"
model = "granite3-dense:2b"

[scan]
include_extensions = [".py", ".js"]
max_file_size_kb = 256

[output]
formats = ["sarif"]
output_dir = "my-reports"

[compliance]
profiles = ["owasp-asvs"]
"""
    cfg_file = tmp_path / "sanicode.toml"
    cfg_file.write_text(toml_content, encoding="utf-8")

    cfg = load_config(cfg_file)

    assert cfg._source_path == cfg_file
    assert cfg.llm.fast.endpoint == "http://localhost:11434/v1"
    assert cfg.llm.fast.model == "granite3-dense:2b"
    assert cfg.llm.analysis.endpoint == ""  # not set in file
    assert cfg.scan.include_extensions == [".py", ".js"]
    assert cfg.scan.max_file_size_kb == 256
    assert cfg.output.formats == ["sarif"]
    assert cfg.output.output_dir == "my-reports"
    assert cfg.compliance.profiles == ["owasp-asvs"]


def test_load_config_provider_field(tmp_path: Path) -> None:
    """provider field is parsed from TOML and defaults to 'openai' when omitted."""
    toml_content = """\
[llm.fast]
provider = "anthropic"
model = "claude-haiku-4-5-20251001"

[llm.analysis]
endpoint = "http://localhost:11434/v1"
model = "granite-code:8b"
"""
    cfg_file = tmp_path / "sanicode.toml"
    cfg_file.write_text(toml_content, encoding="utf-8")

    cfg = load_config(cfg_file)

    # Explicit provider
    assert cfg.llm.fast.provider == "anthropic"
    assert cfg.llm.fast.model == "claude-haiku-4-5-20251001"
    assert cfg.llm.fast.endpoint == ""
    # Default provider when omitted
    assert cfg.llm.analysis.provider == "openai"
    # Tier not in TOML gets default
    assert cfg.llm.reasoning.provider == "openai"


def test_load_config_explicit_missing(tmp_path: Path) -> None:
    """load_config() raises FileNotFoundError when explicit path doesn't exist."""
    missing = tmp_path / "nonexistent.toml"
    with pytest.raises(FileNotFoundError, match="nonexistent.toml"):
        load_config(missing)


def test_load_config_from_env_var(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """load_config() reads from SANICODE_CONFIG when set."""
    cfg_file = tmp_path / "custom.toml"
    cfg_file.write_text(
        '[scan]\nmax_file_size_kb = 128\n', encoding="utf-8"
    )
    monkeypatch.setenv("SANICODE_CONFIG", str(cfg_file))
    # Ensure no sanicode.toml exists in cwd to rule out search-path hits.
    monkeypatch.chdir(tmp_path)

    cfg = load_config()

    assert cfg._source_path == cfg_file
    assert cfg.scan.max_file_size_kb == 128


def test_load_config_env_var_missing_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """load_config() raises FileNotFoundError when SANICODE_CONFIG points to a nonexistent file."""
    monkeypatch.setenv("SANICODE_CONFIG", str(tmp_path / "ghost.toml"))
    monkeypatch.chdir(tmp_path)

    with pytest.raises(FileNotFoundError, match="SANICODE_CONFIG"):
        load_config()


def test_load_config_env_var_takes_precedence_over_cwd(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """SANICODE_CONFIG wins over sanicode.toml found in the current directory."""
    cwd_file = tmp_path / "sanicode.toml"
    cwd_file.write_text('[scan]\nmax_file_size_kb = 999\n', encoding="utf-8")

    env_file = tmp_path / "env-config.toml"
    env_file.write_text('[scan]\nmax_file_size_kb = 42\n', encoding="utf-8")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("SANICODE_CONFIG", str(env_file))

    cfg = load_config()

    assert cfg._source_path == env_file
    assert cfg.scan.max_file_size_kb == 42


def test_load_config_etc_path_in_search_paths() -> None:
    """/etc/sanicode/config.toml is present in _DEFAULT_SEARCH_PATHS."""
    etc_path = Path("/etc/sanicode/config.toml")
    assert etc_path in _DEFAULT_SEARCH_PATHS


# ---------------------------------------------------------------------------
# CLI tests for `sanicode config`
# ---------------------------------------------------------------------------


def test_config_show_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config --show with no config file shows defaults section headers."""
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["config", "--show"])
    assert result.exit_code == 0, result.output
    assert "defaults" in result.output
    assert "Scan" in result.output
    assert "LLM" in result.output


def test_config_no_flags_shows_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config with no flags also displays the resolved configuration."""
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["config"])
    assert result.exit_code == 0, result.output
    assert "Scan" in result.output
    assert "LLM" in result.output


def test_config_show_with_file(tmp_path: Path) -> None:
    """config --show --config <path> displays the configured LLM endpoint."""
    toml_content = """\
[llm.analysis]
endpoint = "http://granite.example.com/v1"
model = "granite-code:8b"
"""
    cfg_file = tmp_path / "sanicode.toml"
    cfg_file.write_text(toml_content, encoding="utf-8")

    result = runner.invoke(
        app, ["config", "--show", "--config", str(cfg_file)], env={"COLUMNS": "200"}
    )
    assert result.exit_code == 0, result.output
    assert "http://granite.example.com/v1" in result.output
    assert "granite-code:8b" in result.output


def test_config_init_creates_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config --init writes sanicode.toml with valid TOML content."""
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["config", "--init"])
    assert result.exit_code == 0, result.output

    dest = tmp_path / "sanicode.toml"
    assert dest.exists(), "sanicode.toml was not created"

    # Must be parseable TOML.
    with open(dest, "rb") as fh:
        parsed = tomllib.load(fh)

    # Template has scan and output sections uncommented.
    assert "scan" in parsed
    assert "output" in parsed
    assert "compliance" in parsed


def test_config_init_refuses_overwrite(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config --init exits 1 and warns when sanicode.toml already exists."""
    monkeypatch.chdir(tmp_path)
    existing = tmp_path / "sanicode.toml"
    existing.write_text("[scan]\n", encoding="utf-8")

    result = runner.invoke(app, ["config", "--init"])
    assert result.exit_code == 1, result.output
    assert "already exists" in result.output


@pytest.mark.parametrize(
    ("endpoint", "model"),
    [
        ("http://localhost:11434/v1", "granite3-dense:2b"),
        ("http://custom.host/v1", "llama3.1:70b"),
    ],
)
def test_config_show_llm_tier_values(tmp_path: Path, endpoint: str, model: str) -> None:
    """config --show reflects LLM tier endpoint and model from the config file."""
    toml_content = f"""\
[llm.fast]
endpoint = "{endpoint}"
model = "{model}"
"""
    cfg_file = tmp_path / "sanicode.toml"
    cfg_file.write_text(toml_content, encoding="utf-8")

    result = runner.invoke(app, ["config", "--config", str(cfg_file)], env={"COLUMNS": "200"})
    assert result.exit_code == 0, result.output
    assert endpoint in result.output
    assert model in result.output


def test_config_show_missing_explicit_file(tmp_path: Path) -> None:
    """config --config <nonexistent> exits 1 with an error message."""
    missing = tmp_path / "nope.toml"
    result = runner.invoke(app, ["config", "--config", str(missing)])
    assert result.exit_code == 1, result.output
    assert "nope.toml" in result.output


# ---------------------------------------------------------------------------
# Unit tests for write_llm_tier()
# ---------------------------------------------------------------------------


def test_write_llm_tier_creates_file(tmp_path: Path) -> None:
    """write_llm_tier creates a new file with the expected section when path doesn't exist."""
    cfg_path = tmp_path / "sanicode.toml"
    assert not cfg_path.exists()

    write_llm_tier(cfg_path, "fast", provider="anthropic", model="claude-haiku-4-5-20251001")

    assert cfg_path.exists(), "write_llm_tier did not create the file"
    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)

    assert "llm" in parsed, f"Expected 'llm' key in TOML, got: {list(parsed)}"
    assert "fast" in parsed["llm"], f"Expected 'fast' tier in llm table, got: {list(parsed['llm'])}"
    assert parsed["llm"]["fast"]["provider"] == "anthropic"
    assert parsed["llm"]["fast"]["model"] == "claude-haiku-4-5-20251001"


def test_write_llm_tier_preserves_existing(tmp_path: Path) -> None:
    """write_llm_tier leaves untouched sections intact when updating a different section."""
    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text("[scan]\nmax_file_size_kb = 256\n", encoding="utf-8")

    write_llm_tier(cfg_path, "fast", provider="openai", model="gpt-4o-mini")

    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)

    assert parsed["scan"]["max_file_size_kb"] == 256, (
        f"scan.max_file_size_kb was altered: {parsed['scan']}"
    )
    assert parsed["llm"]["fast"]["provider"] == "openai"
    assert parsed["llm"]["fast"]["model"] == "gpt-4o-mini"


def test_write_llm_tier_partial_update(tmp_path: Path) -> None:
    """write_llm_tier with only some kwargs leaves existing keys in the section untouched."""
    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text(
        "[llm.fast]\nprovider = \"anthropic\"\nmodel = \"old-model\"\n",
        encoding="utf-8",
    )

    write_llm_tier(cfg_path, "fast", model="new-model")

    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)

    assert parsed["llm"]["fast"]["provider"] == "anthropic", (
        f"provider was unexpectedly changed: {parsed['llm']['fast']}"
    )
    assert parsed["llm"]["fast"]["model"] == "new-model", (
        f"model was not updated: {parsed['llm']['fast']}"
    )


@pytest.mark.parametrize("tier_name", ["fast", "analysis", "reasoning"])
def test_write_llm_tier_all_tiers(tmp_path: Path, tier_name: str) -> None:
    """write_llm_tier correctly writes each supported tier name."""
    cfg_path = tmp_path / "sanicode.toml"

    write_llm_tier(cfg_path, tier_name, provider="openai", model="gpt-4o")

    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)

    assert tier_name in parsed["llm"], (
        f"Expected tier '{tier_name}' in llm table, got: {list(parsed['llm'])}"
    )
    assert parsed["llm"][tier_name]["provider"] == "openai"
    assert parsed["llm"][tier_name]["model"] == "gpt-4o"


# ---------------------------------------------------------------------------
# Unit tests for find_writable_config_path()
# ---------------------------------------------------------------------------


def test_write_llm_tier_creates_parent_dirs(tmp_path: Path) -> None:
    """write_llm_tier creates parent directories when they don't exist."""
    cfg_path = tmp_path / "nested" / "subdir" / "sanicode.toml"

    write_llm_tier(cfg_path, "fast", provider="anthropic", model="claude-haiku-4-5-20251001")

    assert cfg_path.exists(), f"File was not created: {cfg_path}"
    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)
    assert parsed["llm"]["fast"]["provider"] == "anthropic"


def test_find_writable_config_path_existing_cwd(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """find_writable_config_path returns the existing config from the search order."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_file = tmp_path / "sanicode.toml"
    cfg_file.write_text("[scan]\n", encoding="utf-8")

    result = find_writable_config_path()

    # _DEFAULT_SEARCH_PATHS uses Path("sanicode.toml") (relative), so
    # _source_path is relative. Compare resolved to avoid the mismatch.
    assert result.resolve() == cfg_file.resolve()


def test_find_writable_config_path_explicit(tmp_path: Path) -> None:
    """find_writable_config_path returns the explicit path unchanged when one is provided."""
    explicit = tmp_path / "my-config.toml"
    result = find_writable_config_path(explicit)
    assert result == explicit


def test_find_writable_config_path_cwd_fallback(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """find_writable_config_path falls back to sanicode.toml in cwd when no config is found."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)

    result = find_writable_config_path()

    assert result == Path("sanicode.toml"), f"Unexpected fallback path: {result}"


def test_find_writable_config_path_etc_refusal(monkeypatch: pytest.MonkeyPatch) -> None:
    """find_writable_config_path raises PermissionError for /etc/ configs."""
    # Use the resolved /etc path so the check works on macOS where /etc → /private/etc.
    etc_path = Path("/etc").resolve() / "sanicode" / "config.toml"
    mock_cfg = SanicodeConfig(_source_path=etc_path)
    monkeypatch.setattr("sanicode.config.load_config", lambda: mock_cfg)
    with pytest.raises(PermissionError, match="--config"):
        find_writable_config_path()


# ---------------------------------------------------------------------------
# CLI tests for `sanicode config set`
# ---------------------------------------------------------------------------


def test_config_set_valid_key(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config set writes the value for a valid llm.* key."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    result = runner.invoke(
        app,
        ["config", "set", "llm.fast.provider", "anthropic", "--config", str(cfg_path)],
    )

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)
    assert parsed["llm"]["fast"]["provider"] == "anthropic"


def test_config_set_invalid_key(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config set exits 1 and lists valid keys for an unrecognised field."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    result = runner.invoke(
        app,
        ["config", "set", "llm.fast.invalid_field", "value", "--config", str(cfg_path)],
    )

    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}"
    assert "Valid keys" in result.output, f"Expected 'Valid keys' in output: {result.output!r}"


def test_config_set_bad_structure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config set exits 1 when the key doesn't follow the llm.<tier>.<field> structure."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    result = runner.invoke(
        app,
        ["config", "set", "scan.include_extensions", "['.py']", "--config", str(cfg_path)],
    )

    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}"


def test_config_set_timeout_validates_integer(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """config set exits 1 with an 'integer' hint when timeout_seconds receives a non-integer."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    result = runner.invoke(
        app,
        ["config", "set", "llm.fast.timeout_seconds", "abc", "--config", str(cfg_path)],
    )

    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}"
    assert "integer" in result.output, (
        f"Expected 'integer' in error output: {result.output!r}"
    )


def test_config_set_timeout_valid(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config set stores timeout_seconds as an integer in the TOML file."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    result = runner.invoke(
        app,
        ["config", "set", "llm.fast.timeout_seconds", "60", "--config", str(cfg_path)],
    )

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)
    timeout = parsed["llm"]["fast"]["timeout_seconds"]
    assert timeout == 60, f"Expected integer 60, got {timeout!r} (type={type(timeout).__name__})"
    assert isinstance(timeout, int), f"Expected int, got {type(timeout).__name__}"


# ---------------------------------------------------------------------------
# CLI tests for `sanicode config setup`
# ---------------------------------------------------------------------------


def test_config_setup_all_tiers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config setup wizard writes all three tiers when the user chooses all_tiers=yes."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    # New wizard prompt sequence:
    #   1. provider: "anthropic"
    #   2. apply same model to all tiers?: "y"
    #   3. model: "claude-haiku-4-5-20251001"
    #   4. api_key: "" (blank = use env var)
    #   5. confirm write: "y"
    result = runner.invoke(
        app,
        ["config", "setup", "--config", str(cfg_path)],
        input="anthropic\ny\nclaude-haiku-4-5-20251001\n\ny\n",
    )

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"

    with open(cfg_path, "rb") as fh:
        parsed = tomllib.load(fh)

    for tier in ("fast", "analysis", "reasoning"):
        assert tier in parsed["llm"], (
            f"Expected tier '{tier}' in llm table; got: {list(parsed['llm'])}\n"
            f"Full output:\n{result.output}"
        )
        assert parsed["llm"][tier]["provider"] == "anthropic", (
            f"tier={tier}, provider={parsed['llm'][tier].get('provider')!r}"
        )
        assert parsed["llm"][tier]["model"] == "claude-haiku-4-5-20251001", (
            f"tier={tier}, model={parsed['llm'][tier].get('model')!r}"
        )


def test_config_setup_cancelled(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config setup does not write the config file when the user declines the final confirmation."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    cfg_path = tmp_path / "sanicode.toml"

    # Same prompts as above but final confirmation is "n".
    result = runner.invoke(
        app,
        ["config", "setup", "--config", str(cfg_path)],
        input="anthropic\ny\nclaude-haiku-4-5-20251001\n\nn\n",
    )

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    assert not cfg_path.exists(), (
        f"Config file should not have been created after cancellation, but {cfg_path} exists."
    )


# ---------------------------------------------------------------------------
# CLI tests for `sanicode config test`
# ---------------------------------------------------------------------------


def test_config_test_no_tiers_configured(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """config test with no tiers configured exits 0 with informational message."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)

    # Empty config — no LLM tiers.
    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text("[scan]\n", encoding="utf-8")

    result = runner.invoke(app, ["config", "test", "--config", str(cfg_path)])

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    assert "No LLM tiers configured" in result.output


def test_config_test_success(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """config test reports success when test_connection passes."""
    from unittest.mock import patch

    from sanicode.llm.client import LLMResponse

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)

    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text(
        '[llm.fast]\nprovider = "anthropic"\nmodel = "claude-haiku-4-5-20251001"\n',
        encoding="utf-8",
    )

    mock_response = LLMResponse(
        content="ok", model="claude-haiku-4-5-20251001", tier="fast",
        usage={"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
    )

    with patch("sanicode.llm.client.LLMClient") as MockClient:
        instance = MockClient.from_config.return_value
        instance.has_tier.side_effect = lambda t: t == "fast"
        instance.test_connection.return_value = mock_response

        result = runner.invoke(app, ["config", "test", "--config", str(cfg_path)])

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    assert "ok" in result.output


def test_config_test_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """config test exits 1 when a tier's connectivity check fails."""
    from unittest.mock import patch

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)

    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text(
        '[llm.fast]\nprovider = "anthropic"\nmodel = "claude-haiku-4-5-20251001"\n',
        encoding="utf-8",
    )

    with patch("sanicode.llm.client.LLMClient") as MockClient:
        instance = MockClient.from_config.return_value
        instance.has_tier.side_effect = lambda t: t == "fast"
        instance.test_connection.side_effect = ConnectionError("refused")

        result = runner.invoke(app, ["config", "test", "--config", str(cfg_path)])

    assert result.exit_code == 1, f"exit_code={result.exit_code}, output={result.output!r}"
    assert "FAIL" in result.output


def test_config_test_env_var_warning(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """config test warns when provider's auth env vars are not set."""
    from unittest.mock import patch

    from sanicode.llm.client import LLMResponse

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SANICODE_CONFIG", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    cfg_path = tmp_path / "sanicode.toml"
    cfg_path.write_text(
        '[llm.fast]\nprovider = "anthropic"\nmodel = "claude-haiku-4-5-20251001"\n',
        encoding="utf-8",
    )

    mock_response = LLMResponse(
        content="ok", model="claude-haiku-4-5-20251001", tier="fast",
        usage={"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
    )

    with patch("sanicode.llm.client.LLMClient") as MockClient:
        instance = MockClient.from_config.return_value
        instance.has_tier.side_effect = lambda t: t == "fast"
        instance.test_connection.return_value = mock_response

        result = runner.invoke(app, ["config", "test", "--config", str(cfg_path)])

    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output!r}"
    assert "ANTHROPIC_API_KEY" in result.output
