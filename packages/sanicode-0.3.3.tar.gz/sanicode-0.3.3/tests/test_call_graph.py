"""Tests for cross-file and cross-function data flow analysis."""

from __future__ import annotations

from pathlib import Path

from sanicode.graph.builder import KnowledgeGraph
from sanicode.scanner.call_graph import (
    CallSiteInfo,
    FunctionDefInfo,
    resolve_calls,
)
from sanicode.scanner.imports import ImportInfo
from sanicode.scanner.languages.python import PythonPlugin

plugin = PythonPlugin()


def _parse(code: str, filename: str = "test.py"):
    return plugin.parse_source(code.encode(), filename=filename)


class TestCollectDefinitions:
    """Test function definition collection."""

    def test_simple_function(self):
        tree = _parse("def greet(name):\n    return f'Hello {name}'")
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.greet" in defs
        assert defs["test.greet"].params == ["name"]

    def test_class_method(self):
        code = "class Foo:\n    def bar(self, x):\n        pass"
        tree = _parse(code)
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.Foo.bar" in defs
        assert defs["test.Foo.bar"].params == ["self", "x"]

    def test_async_function(self):
        code = "async def fetch(url):\n    pass"
        tree = _parse(code)
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.fetch" in defs

    def test_multi_file(self):
        tree1 = _parse("def func_a():\n    pass", "routes.py")
        tree2 = _parse("def func_b():\n    pass", "service.py")
        defs = plugin.collect_definitions([
            (Path("routes.py"), tree1),
            (Path("service.py"), tree2),
        ])
        assert "routes.func_a" in defs
        assert "service.func_b" in defs

    def test_short_name_registered(self):
        tree = _parse("def unique_func():\n    pass")
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        # Both qualified and short name should resolve
        assert "unique_func" in defs
        assert "test.unique_func" in defs


class TestCollectCallSites:
    """Test call site collection."""

    def test_simple_call(self):
        code = "def main():\n    greet('world')"
        tree = _parse(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "greet" and s.caller == "main" for s in sites)

    def test_method_call(self):
        code = "def main():\n    db.execute(query)"
        tree = _parse(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "db.execute" for s in sites)

    def test_nested_call_tracking(self):
        code = "def outer():\n    def inner():\n        foo()\n    bar()"
        tree = _parse(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        foo_site = next(s for s in sites if s.target == "foo")
        bar_site = next(s for s in sites if s.target == "bar")
        assert foo_site.caller == "inner"
        assert bar_site.caller == "outer"

    def test_module_level_call(self):
        code = "setup()"
        tree = _parse(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "setup" and s.caller == "" for s in sites)

    def test_args_captured(self):
        code = "def f():\n    greet(name, 42)"
        tree = _parse(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        greet_site = next(s for s in sites if s.target == "greet")
        assert "name" in greet_site.args
        assert "<expr>" in greet_site.args


class TestResolveCalls:
    """Test call resolution using definitions and imports."""

    def test_direct_resolution(self):
        defs = {
            "greet": FunctionDefInfo(
                name="greet", qualified_name="utils.greet",
                file=Path("utils.py"), line=1,
            ),
        }
        sites = [
            CallSiteInfo(target="greet", file=Path("main.py"), line=5, caller="main"),
        ]
        resolved = resolve_calls(defs, sites, [])
        assert len(resolved) == 1
        assert resolved[0][1].name == "greet"

    def test_import_resolution(self):
        defs = {
            "service.process_data": FunctionDefInfo(
                name="process_data", qualified_name="service.process_data",
                file=Path("service.py"), line=10,
            ),
        }
        sites = [
            CallSiteInfo(
                target="svc.process_data", file=Path("main.py"), line=5, caller="handler",
            ),
        ]
        imports = [
            ImportInfo(module="service", names=[], aliases={"svc": "service"},
                       file=Path("main.py"), line=1, is_from=False),
        ]
        resolved = resolve_calls(defs, sites, imports)
        assert len(resolved) == 1
        assert resolved[0][1].qualified_name == "service.process_data"

    def test_from_import_resolution(self):
        defs = {
            "utils.sanitize": FunctionDefInfo(
                name="sanitize", qualified_name="utils.sanitize",
                file=Path("utils.py"), line=1,
            ),
            "sanitize": FunctionDefInfo(
                name="sanitize", qualified_name="utils.sanitize",
                file=Path("utils.py"), line=1,
            ),
        }
        sites = [
            CallSiteInfo(target="sanitize", file=Path("main.py"), line=5, caller="handler"),
        ]
        imports = [
            ImportInfo(module="utils", names=["sanitize"], aliases={},
                       file=Path("main.py"), line=1, is_from=True),
        ]
        resolved = resolve_calls(defs, sites, imports)
        assert len(resolved) == 1

    def test_unresolved_call_skipped(self):
        defs = {}
        sites = [
            CallSiteInfo(target="unknown_func", file=Path("main.py"), line=5, caller="main"),
        ]
        resolved = resolve_calls(defs, sites, [])
        assert len(resolved) == 0


class TestCrossFileBuildGraph:
    """Integration tests: multi-file fixtures with cross-file data flow."""

    def test_route_to_service_to_db(self):
        """Route handler calls service, service calls DB — should create cross-file edges."""
        route_code = '''
from flask import Flask, request
app = Flask(__name__)

@app.route("/users")
def get_users():
    query = request.args.get("q")
    result = search_users(query)
    return result
'''
        service_code = '''
def search_users(query):
    cursor.execute(f"SELECT * FROM users WHERE name = '{query}'")
'''
        route_tree = _parse(route_code, "routes.py")
        service_tree = _parse(service_code, "service.py")

        kg = KnowledgeGraph.from_parsed([
            (Path("routes.py"), route_tree),
            (Path("service.py"), service_tree),
        ])

        # Should have entry points (route handler) and sinks (SQL injection)
        entries = kg.nodes_by_kind("entry_point")
        sinks = kg.nodes_by_kind("sink")
        assert len(entries) > 0, "Should detect HTTP handler entry point"
        assert len(sinks) > 0, "Should detect SQL injection sink"

        # Should have cross-function edges connecting entry to sink
        graph_data = kg.to_dict()
        edges = graph_data.get("links", [])
        call_graph_edges = [e for e in edges if e.get("confidence") == "call_graph"]
        assert len(call_graph_edges) > 0, (
            "Should create cross-function edges from route entry to service sink"
        )

    def test_no_cross_edge_without_call(self):
        """If functions don't call each other, no cross-function edges."""
        file1_code = '''
from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return "hello"
'''
        file2_code = '''
def unrelated():
    eval(input())
'''
        tree1 = _parse(file1_code, "routes.py")
        tree2 = _parse(file2_code, "other.py")

        kg = KnowledgeGraph.from_parsed([
            (Path("routes.py"), tree1),
            (Path("other.py"), tree2),
        ])

        graph_data = kg.to_dict()
        edges = graph_data.get("links", [])
        call_graph_edges = [e for e in edges if e.get("confidence") == "call_graph"]
        assert len(call_graph_edges) == 0, "No call graph edges for unrelated functions"

    def test_cross_function_edge_confidence(self):
        """Cross-function edges should have confidence='call_graph'."""
        code1 = '''
from flask import Flask, request
app = Flask(__name__)

@app.route("/exec")
def run_cmd():
    cmd = request.args.get("cmd")
    execute_command(cmd)
'''
        code2 = '''
import os
def execute_command(cmd):
    os.system(cmd)
'''
        tree1 = _parse(code1, "api.py")
        tree2 = _parse(code2, "executor.py")

        kg = KnowledgeGraph.from_parsed([
            (Path("api.py"), tree1),
            (Path("executor.py"), tree2),
        ])

        graph_data = kg.to_dict()
        edges = graph_data.get("links", [])
        call_graph_edges = [e for e in edges if e.get("confidence") == "call_graph"]
        assert all(e["confidence"] == "call_graph" for e in call_graph_edges)

    def test_heuristic_edges_still_exist(self):
        """Intra-function heuristic edges should still be created."""
        code = '''
from flask import Flask, request
app = Flask(__name__)

@app.route("/users")
def get_users():
    q = request.args.get("q")
    cursor.execute(f"SELECT * FROM users WHERE name = '{q}'")
'''
        tree = _parse(code)
        kg = KnowledgeGraph.from_parsed([(Path("test.py"), tree)])

        graph_data = kg.to_dict()
        edges = graph_data.get("links", [])
        heuristic_edges = [e for e in edges if e.get("confidence") == "heuristic"]
        assert len(heuristic_edges) > 0, "Heuristic intra-function edges should still exist"


class TestModuleNameFromPath:
    """Test _module_name_from_path with and without project_root."""

    def test_with_project_root(self):
        from sanicode.scanner.call_graph import _module_name_from_path
        result = _module_name_from_path(
            Path("src/sanicode/scanner/data_flow.py"), project_root=Path("src")
        )
        assert result == "sanicode.scanner.data_flow"

    def test_init_with_project_root(self):
        from sanicode.scanner.call_graph import _module_name_from_path
        result = _module_name_from_path(
            Path("src/sanicode/__init__.py"), project_root=Path("src")
        )
        assert result == "sanicode"

    def test_nested_init_with_project_root(self):
        from sanicode.scanner.call_graph import _module_name_from_path
        result = _module_name_from_path(
            Path("src/sanicode/scanner/__init__.py"), project_root=Path("src")
        )
        assert result == "sanicode.scanner"

    def test_without_root_fallback(self):
        from sanicode.scanner.call_graph import _module_name_from_path
        result = _module_name_from_path(Path("src/sanicode/scanner/data_flow.py"))
        assert result == "data_flow"

    def test_outside_root_fallback(self):
        from sanicode.scanner.call_graph import _module_name_from_path
        result = _module_name_from_path(
            Path("/tmp/standalone.py"), project_root=Path("src")
        )
        assert result == "standalone"


class TestFindPackageRoot:
    """Test find_package_root helper."""

    def test_package_hierarchy(self, tmp_path):
        from sanicode.scanner.call_graph import find_package_root
        # Create src/mypkg/sub/__init__.py structure
        pkg = tmp_path / "src" / "mypkg" / "sub"
        pkg.mkdir(parents=True)
        (tmp_path / "src" / "mypkg" / "__init__.py").touch()
        (tmp_path / "src" / "mypkg" / "sub" / "__init__.py").touch()
        target = pkg / "module.py"
        target.touch()

        root = find_package_root(target)
        assert root == tmp_path / "src"

    def test_no_packages(self, tmp_path):
        from sanicode.scanner.call_graph import find_package_root
        target = tmp_path / "standalone.py"
        target.touch()
        root = find_package_root(target)
        assert root is None

    def test_single_level_package(self, tmp_path):
        from sanicode.scanner.call_graph import find_package_root
        pkg = tmp_path / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").touch()
        target = pkg / "module.py"
        target.touch()

        root = find_package_root(target)
        assert root == tmp_path


class TestCollectDefinitionsWithRoot:
    """Test that collect_definitions uses project_root for qualified names."""

    def test_qualified_names_with_nested_path(self, tmp_path):
        # Create a package structure on disk
        pkg = tmp_path / "src" / "mypkg" / "sub"
        pkg.mkdir(parents=True)
        (tmp_path / "src" / "mypkg" / "__init__.py").touch()
        (tmp_path / "src" / "mypkg" / "sub" / "__init__.py").touch()

        code = "def helper(x):\n    return x + 1"
        file_path = pkg / "utils.py"
        file_path.write_text(code)
        tree = _parse(code, str(file_path))

        defs = plugin.collect_definitions(
            [(file_path, tree)],
            project_root=tmp_path / "src",
        )
        assert "mypkg.sub.utils.helper" in defs

    def test_backward_compat_without_root(self):
        """Without project_root, collect_definitions uses stem-only names."""
        code = "def foo():\n    pass"
        tree = _parse(code)
        defs = plugin.collect_definitions([(Path("some/deep/path/module.py"), tree)])
        assert "module.foo" in defs
