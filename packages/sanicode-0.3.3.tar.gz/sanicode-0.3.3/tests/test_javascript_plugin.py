"""Tests for the tree-sitter-backed JavaScriptPlugin and TypeScriptPlugin.

Covers import detection, framework detection, entry point detection, sink
detection, sanitizer detection, call graph collection, and TypeScript support.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from sanicode.scanner.languages.javascript import JavaScriptPlugin, TypeScriptPlugin

plugin = JavaScriptPlugin()
FILE = Path("<test>")


def _tree(source: str):
    """Parse a dedented source string into a tree-sitter Tree."""
    return plugin.parse_source(dedent(source).encode())


# ---------------------------------------------------------------------------
# Import detection
# ---------------------------------------------------------------------------


class TestImportDetection:
    def test_es6_default_import(self):
        tree = _tree("import express from 'express'")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert result[0].module == "express"
        assert result[0].is_from is True

    def test_es6_named_imports(self):
        tree = _tree("import { Router, Request } from 'express'")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert "Router" in result[0].names
        assert "Request" in result[0].names

    def test_es6_named_import_with_alias(self):
        tree = _tree("import { Router as R } from 'express'")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert "R" in result[0].aliases
        assert result[0].aliases["R"] == "Router"

    def test_namespace_import(self):
        tree = _tree("import * as fs from 'fs'")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert result[0].module == "fs"
        assert "*" in result[0].names

    def test_require_call(self):
        tree = _tree("const express = require('express')")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert result[0].module == "express"
        assert result[0].is_from is False

    def test_require_double_quotes(self):
        tree = _tree('const path = require("path")')
        result = plugin.detect_imports(tree, FILE)
        assert len(result) == 1
        assert result[0].module == "path"

    def test_multiple_imports(self):
        source = """\
            import express from 'express';
            import { readFile } from 'fs';
            const path = require('path');
        """
        result = plugin.detect_imports(_tree(source), FILE)
        assert len(result) == 3
        modules = {r.module for r in result}
        assert modules == {"express", "fs", "path"}

    def test_line_number_recorded(self):
        source = """\
            // comment
            import express from 'express';
        """
        result = plugin.detect_imports(_tree(source), FILE)
        assert result[0].line == 2

    def test_file_path_recorded(self):
        tree = _tree("import x from 'y'")
        p = Path("/src/app.js")
        result = plugin.detect_imports(tree, p)
        assert result[0].file == p

    def test_empty_file_no_crash(self):
        result = plugin.detect_imports(_tree(""), FILE)
        assert result == []

    def test_dynamic_import_no_crash(self):
        # Dynamic import() is harder to detect — just verify no exception
        tree = _tree("const mod = import('./module')")
        plugin.detect_imports(tree, FILE)
        # May or may not detect; must not crash


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------


class TestFrameworkDetection:
    @pytest.mark.parametrize(
        ("source", "expected_fw"),
        [
            ("import express from 'express'", "express"),
            ("const express = require('express')", "express"),
            ("import React from 'react'", "react"),
            ("import { createApp } from 'vue'", "vue"),
            ("import fastify from 'fastify'", "fastify"),
            ("import Koa from 'koa'", "koa"),
            ("import Hapi from '@hapi/hapi'", "hapi"),
        ],
        ids=["express-import", "express-require", "react", "vue", "fastify", "koa", "hapi"],
    )
    def test_framework_detected(self, source: str, expected_fw: str):
        tree = _tree(source)
        imports = plugin.detect_imports(tree, FILE)
        frameworks = plugin.detect_frameworks(imports)
        names = {fw.name for fw in frameworks}
        assert expected_fw in names, f"Expected {expected_fw!r} in {names}"

    def test_no_framework_for_stdlib(self):
        tree = _tree("import fs from 'fs'\nimport path from 'path'")
        imports = plugin.detect_imports(tree, FILE)
        frameworks = plugin.detect_frameworks(imports)
        assert frameworks == []

    def test_empty_imports(self):
        frameworks = plugin.detect_frameworks([])
        assert frameworks == []


# ---------------------------------------------------------------------------
# Entry point detection
# ---------------------------------------------------------------------------


class TestEntryPointDetection:
    def test_express_get_route(self):
        source = """\
            app.get('/users', (req, res) => {
                res.json([])
            })
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        http = [r for r in results if r.kind == "http_handler"]
        assert http, f"Expected HTTP handler, got: {results}"
        assert http[0].name == "app.get"

    def test_express_post_route(self):
        source = "router.post('/login', handler)"
        results = plugin.detect_entry_points(_tree(source), FILE)
        http = [r for r in results if r.kind == "http_handler"]
        assert http, "POST route should be detected as http_handler"

    def test_all_http_methods_detected(self):
        methods = ["get", "post", "put", "delete", "patch"]
        for method in methods:
            source = f"app.{method}('/path', handler)"
            results = plugin.detect_entry_points(_tree(source), FILE)
            http = [r for r in results if r.kind == "http_handler"]
            assert http, f"app.{method}() should be detected as http_handler"

    def test_process_env_member(self):
        source = "const key = process.env.API_KEY"
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "process.env.API_KEY should be detected as env_var"

    def test_process_env_base(self):
        source = "const val = process.env['SECRET']"
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "process.env access should be detected"

    def test_process_argv(self):
        source = "const args = process.argv"
        results = plugin.detect_entry_points(_tree(source), FILE)
        cli = [r for r in results if r.kind == "cli_arg"]
        assert cli, "process.argv should be detected as cli_arg"
        assert cli[0].name == "process.argv"

    def test_req_body(self):
        source = """\
            function handler(req, res) {
                const data = req.body;
            }
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        http_input = [r for r in results if r.kind == "http_input"]
        assert http_input, "req.body should be detected as http_input"

    def test_req_query(self):
        source = "const q = req.query.search"
        results = plugin.detect_entry_points(_tree(source), FILE)
        http_input = [r for r in results if r.kind == "http_input"]
        assert http_input, "req.query should be detected as http_input"

    def test_entry_point_line_number(self):
        source = """\
            // comment
            const key = process.env.KEY;
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "process.env.KEY should be detected"
        assert env[0].line == 2, f"Expected line 2, got {env[0].line}"

    def test_enclosing_function_captured(self):
        source = """\
            function setup() {
                const key = process.env.API_KEY;
            }
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "process.env should be detected inside function"
        assert env[0].function == "setup", (
            f"Expected function='setup', got {env[0].function!r}"
        )

    def test_module_level_has_no_function(self):
        source = "const key = process.env.KEY;"
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "process.env at module level should be detected"
        assert env[0].function is None, (
            f"Module-level entry point should have function=None, got {env[0].function!r}"
        )


# ---------------------------------------------------------------------------
# Sink detection
# ---------------------------------------------------------------------------


class TestSinkDetection:
    @pytest.mark.parametrize(
        ("source", "expected_name", "expected_kind", "expected_cwe"),
        [
            ('eval("alert(1)")', "eval", "eval", 94),
            ("child_process.exec(cmd)", "child_process.exec", "command", 78),
            ("child_process.execSync(cmd)", "child_process.execSync", "command", 78),
            ("child_process.spawn(cmd, args)", "child_process.spawn", "command", 78),
            ("fetch(url)", "fetch", "network", 918),
            ("axios.get(url)", "axios.get", "network", 918),
            ("axios.post(url, data)", "axios.post", "network", 918),
            ("res.render('template', data)", "res.render", "template", 79),
            ("document.write(html)", "document.write", "xss", 79),
        ],
        ids=[
            "eval",
            "child_process.exec",
            "child_process.execSync",
            "child_process.spawn",
            "fetch",
            "axios.get",
            "axios.post",
            "res.render",
            "document.write",
        ],
    )
    def test_sink_detected(
        self,
        source: str,
        expected_name: str,
        expected_kind: str,
        expected_cwe: int,
    ):
        results = plugin.detect_sinks(_tree(source), FILE)
        matches = [r for r in results if r.name == expected_name and r.kind == expected_kind]
        assert matches, (
            f"No SinkInfo name={expected_name!r}, kind={expected_kind!r} in {results}"
        )
        assert matches[0].cwe_id == expected_cwe, (
            f"Expected CWE {expected_cwe}, got {matches[0].cwe_id}"
        )

    def test_innerhtml_assignment(self):
        source = "el.innerHTML = userInput"
        results = plugin.detect_sinks(_tree(source), FILE)
        xss = [r for r in results if r.kind == "xss"]
        assert xss, "innerHTML assignment should be detected as xss sink"
        assert xss[0].cwe_id == 79

    def test_outerhtml_assignment(self):
        source = "el.outerHTML = html"
        results = plugin.detect_sinks(_tree(source), FILE)
        xss = [r for r in results if r.kind == "xss"]
        assert xss, "outerHTML assignment should be detected as xss sink"

    def test_sql_template_literal(self):
        source = "db.query(`SELECT * FROM ${table}`)"
        results = plugin.detect_sinks(_tree(source), FILE)
        sql = [r for r in results if r.kind == "sql"]
        assert sql, "db.query with template literal should be detected as sql sink"
        assert sql[0].cwe_id == 89

    def test_sql_plain_string_not_flagged(self):
        # Plain string (not a template literal) is not a risk
        source = "db.query('SELECT * FROM users')"
        results = plugin.detect_sinks(_tree(source), FILE)
        sql = [r for r in results if r.kind == "sql"]
        assert not sql, "db.query with plain string should not be flagged"

    def test_sink_line_number(self):
        source = """\
            // comment
            eval("bad")
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        eval_sinks = [r for r in results if r.name == "eval"]
        assert eval_sinks, "eval should be detected"
        assert eval_sinks[0].line == 2, f"Expected line 2, got {eval_sinks[0].line}"

    def test_sink_enclosing_function(self):
        source = """\
            function run(cmd) {
                child_process.exec(cmd)
            }
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert cmd_sinks, "child_process.exec should be detected"
        assert cmd_sinks[0].function == "run", (
            f"Expected function='run', got {cmd_sinks[0].function!r}"
        )


# ---------------------------------------------------------------------------
# Sanitizer detection
# ---------------------------------------------------------------------------


class TestSanitizerDetection:
    @pytest.mark.parametrize(
        ("source", "expected_name", "expected_kind"),
        [
            ("const s = encodeURIComponent(userInput)", "encodeURIComponent", "url_encode"),
            ("const s = encodeURI(url)", "encodeURI", "url_encode"),
            ("const clean = DOMPurify.sanitize(dirty)", "DOMPurify.sanitize", "html_escape"),
            ("const safe = validator.escape(html)", "validator.escape", "html_escape"),
        ],
        ids=["encodeURIComponent", "encodeURI", "DOMPurify.sanitize", "validator.escape"],
    )
    def test_sanitizer_detected(
        self, source: str, expected_name: str, expected_kind: str
    ):
        results = plugin.detect_sanitizers(_tree(source), FILE)
        matches = [r for r in results if r.name == expected_name and r.kind == expected_kind]
        assert matches, (
            f"No SanitizerInfo name={expected_name!r}, kind={expected_kind!r} in {results}"
        )

    def test_sanitizer_line_number(self):
        source = """\
            // comment
            const s = encodeURIComponent(x);
        """
        results = plugin.detect_sanitizers(_tree(source), FILE)
        san = [r for r in results if r.name == "encodeURIComponent"]
        assert san, "encodeURIComponent should be detected"
        assert san[0].line == 2, f"Expected line 2, got {san[0].line}"

    def test_sanitizer_enclosing_function(self):
        source = """\
            function clean(text) {
                return DOMPurify.sanitize(text);
            }
        """
        results = plugin.detect_sanitizers(_tree(source), FILE)
        san = [r for r in results if r.name == "DOMPurify.sanitize"]
        assert san, "DOMPurify.sanitize should be detected"
        assert san[0].function == "clean", (
            f"Expected function='clean', got {san[0].function!r}"
        )

    def test_no_sanitizer_for_plain_call(self):
        source = "console.log(x)"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        assert not results, f"console.log should not be a sanitizer: {results}"


# ---------------------------------------------------------------------------
# collect_definitions
# ---------------------------------------------------------------------------


class TestCollectDefinitions:
    def test_function_declaration(self):
        tree = _tree("function greet(name) { return name }")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.greet" in defs, f"Expected 'test.greet' in {set(defs.keys())}"

    def test_function_declaration_params(self):
        tree = _tree("function greet(name, age) { return name }")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert defs["test.greet"].params == ["name", "age"]

    def test_arrow_function(self):
        tree = _tree("const greet = (name) => name")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.greet" in defs, f"Expected 'test.greet' in {set(defs.keys())}"

    def test_function_expression(self):
        tree = _tree("const greet = function(name) { return name }")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.greet" in defs, f"Expected 'test.greet' in {set(defs.keys())}"

    def test_class_method(self):
        source = """\
            class Foo {
                bar(x) { return x }
            }
        """
        tree = _tree(source)
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.Foo.bar" in defs, f"Expected 'test.Foo.bar' in {set(defs.keys())}"

    def test_class_method_params(self):
        source = """\
            class Service {
                fetch(url, opts) {}
            }
        """
        tree = _tree(source)
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert defs["test.Service.fetch"].params == ["url", "opts"]

    def test_short_name_registered(self):
        tree = _tree("function uniqueFn() {}")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "uniqueFn" in defs
        assert "test.uniqueFn" in defs

    def test_multi_file(self):
        tree1 = _tree("function funcA() {}")
        tree2 = _tree("function funcB() {}")
        defs = plugin.collect_definitions([
            (Path("routes.js"), tree1),
            (Path("service.js"), tree2),
        ])
        assert "routes.funcA" in defs
        assert "service.funcB" in defs

    def test_default_params(self):
        tree = _tree("function greet(name, age = 0) {}")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.greet" in defs
        assert "name" in defs["test.greet"].params
        assert "age" in defs["test.greet"].params

    def test_rest_params(self):
        tree = _tree("function log(msg, ...args) {}")
        defs = plugin.collect_definitions([(Path("test.js"), tree)])
        assert "test.log" in defs
        assert "msg" in defs["test.log"].params
        assert "args" in defs["test.log"].params


# ---------------------------------------------------------------------------
# collect_call_sites
# ---------------------------------------------------------------------------


class TestCollectCallSites:
    def test_simple_call(self):
        tree = _tree("function main() { greet('world') }")
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        assert any(s.target == "greet" for s in sites), (
            f"Expected 'greet' call in {sites}"
        )

    def test_method_call(self):
        tree = _tree("function main() { db.execute(query) }")
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        assert any(s.target == "db.execute" for s in sites), (
            f"Expected 'db.execute' in {sites}"
        )

    def test_caller_captured(self):
        tree = _tree("function main() { greet('world') }")
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        greet_site = next((s for s in sites if s.target == "greet"), None)
        assert greet_site is not None
        assert greet_site.caller == "main", (
            f"Expected caller='main', got {greet_site.caller!r}"
        )

    def test_module_level_caller_empty_string(self):
        tree = _tree("setup()")
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        assert any(s.target == "setup" and s.caller == "" for s in sites), (
            f"Module-level call should have caller=''; got {sites}"
        )

    def test_args_captured(self):
        tree = _tree("function f() { greet(name, 42) }")
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        greet = next((s for s in sites if s.target == "greet"), None)
        assert greet is not None
        assert "name" in greet.args, f"Expected 'name' in args, got {greet.args}"
        assert "<expr>" in greet.args, f"Expected '<expr>' in args, got {greet.args}"

    def test_arrow_function_caller(self):
        source = """\
            const handle = (req, res) => {
                validate(req.body)
            }
        """
        tree = _tree(source)
        sites = plugin.collect_call_sites([(Path("test.js"), tree)])
        validate_site = next((s for s in sites if s.target == "validate"), None)
        assert validate_site is not None
        assert validate_site.caller == "handle", (
            f"Expected caller='handle', got {validate_site.caller!r}"
        )


# ---------------------------------------------------------------------------
# resolve_calls
# ---------------------------------------------------------------------------


class TestResolveCalls:
    def test_simple_resolution(self):
        src_defs = _tree("function greet(name) {}")
        src_calls = _tree("function main() { greet('world') }")
        defs = plugin.collect_definitions([(Path("defs.js"), src_defs)])
        sites = plugin.collect_call_sites([(Path("calls.js"), src_calls)])
        resolved = plugin.resolve_calls(defs, sites, [])
        assert any(d.name == "greet" for _, d in resolved), (
            f"Expected greet to be resolved: {[(s.target, d.name) for s, d in resolved]}"
        )

    def test_unresolved_not_included(self):
        src_calls = _tree("unknownFunc()")
        sites = plugin.collect_call_sites([(Path("test.js"), src_calls)])
        resolved = plugin.resolve_calls({}, sites, [])
        assert resolved == []


# ---------------------------------------------------------------------------
# find_package_root
# ---------------------------------------------------------------------------


class TestFindPackageRoot:
    def test_finds_package_json(self, tmp_path: Path):
        pkg_json = tmp_path / "package.json"
        pkg_json.write_text('{"name": "test"}')
        src_file = tmp_path / "src" / "index.js"
        src_file.parent.mkdir()
        src_file.touch()
        root = plugin.find_package_root(src_file)
        assert root == tmp_path

    def test_returns_none_when_absent(self, tmp_path: Path):
        src_file = tmp_path / "index.js"
        src_file.touch()
        root = plugin.find_package_root(src_file)
        assert root is None


# ---------------------------------------------------------------------------
# TypeScriptPlugin
# ---------------------------------------------------------------------------


class TestTypeScriptPlugin:
    ts = TypeScriptPlugin()

    def test_name(self):
        assert self.ts.name == "typescript"

    def test_extensions(self):
        assert ".ts" in self.ts.extensions
        assert ".tsx" in self.ts.extensions
        assert ".js" not in self.ts.extensions

    def test_parses_type_annotations(self):
        source = b"function greet(name: string): string { return name }"
        tree = self.ts.parse_source(source)
        assert tree.root_node is not None
        assert not tree.root_node.has_error, (
            "TypeScript with type annotations should parse without errors"
        )

    def test_parses_interface(self):
        source = b"interface User { name: string; age: number }"
        tree = self.ts.parse_source(source)
        assert not tree.root_node.has_error

    def test_detects_imports(self):
        source = "import express from 'express'"
        tree = self.ts.parse_source(dedent(source).encode())
        result = self.ts.detect_imports(tree, FILE)
        assert len(result) == 1
        assert result[0].module == "express"

    def test_detects_sinks(self):
        source = b'eval("bad")'
        tree = self.ts.parse_source(source)
        sinks = self.ts.detect_sinks(tree, FILE)
        assert any(s.kind == "eval" for s in sinks), f"eval should be detected in TS: {sinks}"

    def test_collects_ts_definitions(self):
        source = b"function greet(name: string) { return name }"
        tree = self.ts.parse_source(source)
        defs = self.ts.collect_definitions([(Path("test.ts"), tree)])
        assert "test.greet" in defs, f"Expected 'test.greet' in {set(defs.keys())}"
