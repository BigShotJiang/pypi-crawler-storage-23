"""Tests for Python pattern detection rules SC009-SC015.

Uses data-driven parametrize where patterns repeat; one-off tests for
cases requiring individual assertions (e.g. field values).
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from sanicode.scanner.languages.python import PythonPlugin

FILE = Path("<test>")
plugin = PythonPlugin()


def _tree(source: str):
    return plugin.parse_source(dedent(source).encode())


def _findings_for(source: str, rule_id: str):
    return [f for f in plugin.check_patterns(_tree(source), FILE) if f.rule_id == rule_id]


# ---------------------------------------------------------------------------
# SC009 — CWE-79: XSS via mark_safe / Markup
# ---------------------------------------------------------------------------


class TestXssDetection:
    """SC009: mark_safe/Markup with non-literal arguments."""

    @pytest.mark.parametrize(
        "source",
        [
            "mark_safe(user_input)",
            "mark_safe(request.POST['content'])",
            "Markup(content)",
            "Markup(html_string)",
            "django.utils.safestring.mark_safe(val)",
            "markupsafe.Markup(data)",
        ],
        ids=[
            "mark_safe-variable",
            "mark_safe-subscript",
            "markup-variable",
            "markup-html-string",
            "dotted-mark_safe",
            "dotted-markup",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC009")
        assert matches, f"SC009 not detected for: {source!r}"
        assert matches[0].cwe_id == 79
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'mark_safe("<br>")',
            'mark_safe("<strong>bold</strong>")',
            'Markup("<em>text</em>")',
        ],
        ids=["mark_safe-literal-br", "mark_safe-literal-strong", "markup-literal"],
    )
    def test_literal_arg_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC009")
        assert not matches, f"SC009 should not trigger for literal arg: {source!r}"


# ---------------------------------------------------------------------------
# SC010 — CWE-22: open() with variable path
# ---------------------------------------------------------------------------


class TestOpenVariablePath:
    """SC010: open() with a non-literal file path."""

    @pytest.mark.parametrize(
        "source",
        [
            "open(user_path)",
            "open(request.args['file'])",
            "open(filename, 'r')",
            "open(base + '/config')",
        ],
        ids=["bare-variable", "subscript", "variable-with-mode", "concat"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC010")
        assert matches, f"SC010 not detected for: {source!r}"
        assert matches[0].cwe_id == 22
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'open("config.txt")',
            'open("/etc/hosts", "r")',
            'open("data/input.csv", mode="r")',
        ],
        ids=["relative-literal", "absolute-literal", "mode-keyword-literal"],
    )
    def test_literal_path_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC010")
        assert not matches, f"SC010 should not trigger for literal path: {source!r}"

    def test_does_not_match_dotted_open(self) -> None:
        # Path.open() is an attribute call, not the bare built-in
        matches = _findings_for("some_path.open('r')", "SC010")
        assert not matches, "SC010 must not match attribute .open() calls"


# ---------------------------------------------------------------------------
# SC011 — CWE-22: os.path.join with variable segments
# ---------------------------------------------------------------------------


class TestOsPathJoin:
    """SC011: os.path.join() with any variable segment."""

    @pytest.mark.parametrize(
        "source",
        [
            "os.path.join(base_dir, user_input)",
            "os.path.join('/var/data', filename)",
            "os.path.join(root, subdir, name)",
        ],
        ids=["variable-second", "variable-first-literal-second", "multi-variable"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC011")
        assert matches, f"SC011 not detected for: {source!r}"
        assert matches[0].cwe_id == 22
        assert matches[0].severity == "medium"

    @pytest.mark.parametrize(
        "source",
        [
            'os.path.join("/tmp", "safe.txt")',
            'os.path.join("/var", "log", "app.log")',
        ],
        ids=["two-literals", "three-literals"],
    )
    def test_all_literals_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC011")
        assert not matches, f"SC011 should not trigger for all-literal join: {source!r}"


# ---------------------------------------------------------------------------
# SC012 — CWE-798: Hardcoded credentials
# ---------------------------------------------------------------------------


class TestHardcodedCredentials:
    """SC012: string literal assigned to a secret-named variable."""

    @pytest.mark.parametrize(
        "source",
        [
            'password = "supersecret123"',
            'passwd = "hunter2"',
            'api_key = "sk-abc123def456"',
            'apikey = "live_12345678"',
            'api_secret = "xoxb-token-value"',
            'token = "ghp_PAT_abc123"',
            'auth_token = "Bearer xyzzy"',
            'access_key = "AKIAIOSFODNN7EXAMPLE"',
            'private_key = "-----BEGIN RSA PRIVATE KEY-----"',
            'credentials = "user:pass"',
            'db_pass = "dbpassword"',
            'DB_PASSWORD = "prod_secret_value"',
        ],
        ids=[
            "password", "passwd", "api_key", "apikey", "api_secret",
            "token", "auth_token", "access_key", "private_key",
            "credentials", "db_pass", "DB_PASSWORD",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC012")
        assert matches, f"SC012 not detected for: {source!r}"
        assert matches[0].cwe_id == 798
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'password = ""',
            "password = get_password()",
            "password = os.environ.get('DB_PASSWORD')",
            "password = config['password']",
            'name = "Alice"',
            'username = "admin"',
            'password = "changeme"',
            'password = "CHANGE_ME"',
        ],
        ids=[
            "empty-string",
            "function-call",
            "env-var",
            "dict-lookup",
            "normal-name",
            "username",
            "changeme-placeholder",
            "change_me-placeholder",
        ],
    )
    def test_safe_patterns(self, source: str) -> None:
        matches = _findings_for(source, "SC012")
        assert not matches, f"SC012 should not trigger for: {source!r}"


# ---------------------------------------------------------------------------
# SC013 — CWE-327: Weak cryptographic hash
# ---------------------------------------------------------------------------


class TestWeakCrypto:
    """SC013: MD5 or SHA1 via hashlib."""

    @pytest.mark.parametrize(
        "source",
        [
            "hashlib.md5(data)",
            "hashlib.md5(data).hexdigest()",
            "hashlib.sha1(data)",
            'hashlib.new("md5")',
            'hashlib.new("sha1")',
            "hashlib.new('md5', data)",
        ],
        ids=[
            "md5-direct", "md5-chained", "sha1-direct",
            "new-md5-double", "new-sha1-double", "new-md5-single",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC013")
        assert matches, f"SC013 not detected for: {source!r}"
        assert matches[0].cwe_id == 327
        assert matches[0].severity == "medium"

    @pytest.mark.parametrize(
        "source",
        [
            "hashlib.sha256(data)",
            "hashlib.sha512(data)",
            "hashlib.blake2b(data)",
            'hashlib.new("sha256")',
            'hashlib.new("sha512")',
        ],
        ids=["sha256", "sha512", "blake2b", "new-sha256", "new-sha512"],
    )
    def test_strong_algo_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC013")
        assert not matches, f"SC013 should not trigger for strong hash: {source!r}"


# ---------------------------------------------------------------------------
# SC014 — CWE-330: Insecure random
# ---------------------------------------------------------------------------


class TestInsecureRandom:
    """SC014: random module calls that are not cryptographically secure."""

    @pytest.mark.parametrize(
        "source",
        [
            "random.random()",
            "random.randint(0, 100)",
            "random.choice(items)",
            "random.randrange(256)",
            "random.uniform(0.0, 1.0)",
            "random.getrandbits(128)",
            "random.shuffle(lst)",
            "random.sample(population, k)",
        ],
        ids=[
            "random", "randint", "choice", "randrange",
            "uniform", "getrandbits", "shuffle", "sample",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC014")
        assert matches, f"SC014 not detected for: {source!r}"
        assert matches[0].cwe_id == 330
        assert matches[0].severity == "medium"

    @pytest.mark.parametrize(
        "source",
        [
            "secrets.token_hex()",
            "secrets.choice(items)",
            "secrets.randbelow(100)",
            "os.urandom(32)",
        ],
        ids=["secrets-token-hex", "secrets-choice", "secrets-randbelow", "os-urandom"],
    )
    def test_secure_alternatives_are_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC014")
        assert not matches, f"SC014 should not trigger for secure RNG: {source!r}"


# ---------------------------------------------------------------------------
# SC015 — CWE-918: SSRF
# ---------------------------------------------------------------------------


class TestSsrf:
    """SC015: HTTP request functions with variable URL arguments."""

    @pytest.mark.parametrize(
        "source",
        [
            "requests.get(user_url)",
            "requests.post(url, data=body)",
            "requests.put(endpoint)",
            "requests.delete(target_url)",
            "requests.patch(url)",
            "requests.head(url)",
            "requests.request(method, url)",
            "httpx.get(user_url)",
            "httpx.post(url)",
            "httpx.put(url)",
            "httpx.delete(url)",
            "urllib.request.urlopen(url)",
        ],
        ids=[
            "requests-get", "requests-post", "requests-put",
            "requests-delete", "requests-patch", "requests-head",
            "requests-request", "httpx-get", "httpx-post",
            "httpx-put", "httpx-delete", "urllib-urlopen",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC015")
        assert matches, f"SC015 not detected for: {source!r}"
        assert matches[0].cwe_id == 918
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'requests.get("https://api.example.com/v1/data")',
            'requests.post("https://internal.svc/endpoint")',
            'httpx.get("https://api.example.com")',
            'urllib.request.urlopen("https://example.com")',
        ],
        ids=[
            "requests-get-literal",
            "requests-post-literal",
            "httpx-get-literal",
            "urllib-literal",
        ],
    )
    def test_literal_url_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC015")
        assert not matches, f"SC015 should not trigger for literal URL: {source!r}"
