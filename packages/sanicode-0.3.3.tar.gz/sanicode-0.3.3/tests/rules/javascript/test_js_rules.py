"""Tests for JavaScript pattern detection rules (SC201-SC210).

Uses data-driven parametrize for conciseness; individual tests for
assertions on finding metadata (cwe_id, severity).
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from sanicode.scanner.languages.javascript import JavaScriptPlugin

FILE = Path("<test>")
plugin = JavaScriptPlugin()


def _tree(source: str):
    return plugin.parse_source(dedent(source).encode())


def _findings_for(source: str, rule_id: str):
    return [f for f in plugin.check_patterns(_tree(source), FILE) if f.rule_id == rule_id]


# ---------------------------------------------------------------------------
# SC201 — CWE-78: eval()
# ---------------------------------------------------------------------------


class TestEval:
    """SC201: eval() is flagged regardless of argument."""

    @pytest.mark.parametrize(
        "source",
        [
            "eval(userInput)",
            "eval(req.body.code)",
            "eval('1 + 1')",
        ],
        ids=["variable", "member-expr", "literal"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC201")
        assert matches, f"SC201 not detected for: {source!r}"
        assert matches[0].cwe_id == 78
        assert matches[0].severity == "critical"

    def test_other_identifier_not_matched(self) -> None:
        matches = _findings_for("evaluate(x)", "SC201")
        assert not matches, "SC201 must not match 'evaluate()'"

    def test_eval_attribute_not_flagged(self) -> None:
        """obj.eval(x) should NOT be flagged (not a bare eval call)."""
        matches = _findings_for("obj.eval(x)", "SC201")
        assert not matches, "attribute eval should not be flagged"


# ---------------------------------------------------------------------------
# SC202 — CWE-94: new Function()
# ---------------------------------------------------------------------------


class TestNewFunction:
    """SC202: new Function() constructor."""

    @pytest.mark.parametrize(
        "source",
        [
            "new Function(code)",
            "new Function('return 1')",
            "new Function('a', 'b', 'return a + b')",
        ],
        ids=["variable", "literal-body", "multi-arg"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC202")
        assert matches, f"SC202 not detected for: {source!r}"
        assert matches[0].cwe_id == 94
        assert matches[0].severity == "critical"

    def test_new_other_class_not_matched(self) -> None:
        matches = _findings_for("new Map()", "SC202")
        assert not matches, "SC202 must not match 'new Map()'"


# ---------------------------------------------------------------------------
# SC203 — CWE-78: child_process exec/spawn
# ---------------------------------------------------------------------------


class TestChildProcessExec:
    """SC203: child_process.exec and related calls."""

    @pytest.mark.parametrize(
        "source",
        [
            "child_process.exec(cmd)",
            "child_process.execSync(cmd)",
            "child_process.spawn(cmd, args)",
            "child_process.spawnSync(cmd)",
        ],
        ids=["exec", "execSync", "spawn", "spawnSync"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC203")
        assert matches, f"SC203 not detected for: {source!r}"
        assert matches[0].cwe_id == 78
        assert matches[0].severity == "high"

    def test_unrelated_exec_not_matched(self) -> None:
        # A bare exec() without child_process. prefix should NOT be SC203
        # (it has no dotted prefix; the rule only targets the dotted forms).
        matches = _findings_for("exec(cmd)", "SC203")
        assert not matches, "SC203 must not match bare exec()"


# ---------------------------------------------------------------------------
# SC204 — CWE-79: innerHTML / outerHTML
# ---------------------------------------------------------------------------


class TestInnerHtml:
    """SC204: assignment to innerHTML or outerHTML."""

    @pytest.mark.parametrize(
        "source",
        [
            "el.innerHTML = userInput",
            "el.outerHTML = content",
            "document.body.innerHTML = html",
        ],
        ids=["innerHTML-variable", "outerHTML-variable", "nested-member"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC204")
        assert matches, f"SC204 not detected for: {source!r}"
        assert matches[0].cwe_id == 79
        assert matches[0].severity == "high"

    def test_textcontent_not_matched(self) -> None:
        # textContent is safe — it doesn't parse HTML.
        matches = _findings_for("el.textContent = value", "SC204")
        assert not matches, "SC204 must not match .textContent assignment"


# ---------------------------------------------------------------------------
# SC205 — CWE-79: document.write / writeln
# ---------------------------------------------------------------------------


class TestDocumentWrite:
    """SC205: document.write() and document.writeln()."""

    @pytest.mark.parametrize(
        "source",
        [
            "document.write(html)",
            "document.writeln(content)",
            'document.write("<b>" + data + "</b>")',
        ],
        ids=["write-variable", "writeln-variable", "write-concat"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC205")
        assert matches, f"SC205 not detected for: {source!r}"
        assert matches[0].cwe_id == 79
        assert matches[0].severity == "high"

    def test_document_query_not_matched(self) -> None:
        matches = _findings_for("document.querySelector('.foo')", "SC205")
        assert not matches, "SC205 must not match document.querySelector"


# ---------------------------------------------------------------------------
# SC207 — CWE-22: fs.* with variable path
# ---------------------------------------------------------------------------


class TestFsPathTraversal:
    """SC207: fs operations with non-literal path argument."""

    @pytest.mark.parametrize(
        "source",
        [
            "fs.readFile(userPath, cb)",
            "fs.readFileSync(filePath)",
            "fs.writeFile(path, data, cb)",
            "fs.writeFileSync(dest, contents)",
            "fs.readdir(dir, cb)",
            "fs.unlink(target, cb)",
            "fs.stat(p, cb)",
            "fs.access(p)",
        ],
        ids=["readFile", "readFileSync", "writeFile", "writeFileSync",
             "readdir", "unlink", "stat", "access"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC207")
        assert matches, f"SC207 not detected for: {source!r}"
        assert matches[0].cwe_id == 22
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'fs.readFile("config.json", cb)',
            'fs.readFileSync("/etc/hosts")',
            'fs.writeFile("output.txt", data, cb)',
        ],
        ids=["readFile-literal", "readFileSync-literal", "writeFile-literal"],
    )
    def test_literal_path_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC207")
        assert not matches, f"SC207 should not trigger for literal path: {source!r}"

    def test_fs_readfile_template_with_interpolation(self) -> None:
        """fs.readFile with interpolated template literal should be flagged."""
        matches = _findings_for("fs.readFile(`/files/${userInput}`, cb)", "SC207")
        assert matches, "fs.readFile with interpolated template should be detected"

    def test_fs_readfile_plain_template_safe(self) -> None:
        """fs.readFile with plain template literal (no interpolation) should be safe."""
        matches = _findings_for("fs.readFile(`/config/app.json`, cb)", "SC207")
        assert not matches, "fs.readFile with plain template should be safe"


# ---------------------------------------------------------------------------
# SC208 — CWE-798: Hardcoded credentials
# ---------------------------------------------------------------------------


class TestHardcodedCredentials:
    """SC208: string literal assigned to a secret-named variable."""

    @pytest.mark.parametrize(
        "source",
        [
            'const password = "supersecret"',
            "let password = 'hunter2'",
            'var passwd = "mypassword123"',
            'const api_key = "sk-1234567890"',
            'let apikey = "live_token_abc"',
            'const api_secret = "xoxb-secret"',
            'var token = "ghp_PATabcdef"',
            'const auth_token = "Bearer xyzzy"',
            'let access_key = "AKIAIOSFODNN7"',
            'const private_key = "-----BEGIN RSA"',
            'var credentials = "user:pass"',
            'const db_pass = "prodpassword"',
        ],
        ids=[
            "password-double", "password-single", "passwd-var",
            "api_key", "apikey", "api_secret",
            "token", "auth_token", "access_key",
            "private_key", "credentials", "db_pass",
        ],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC208")
        assert matches, f"SC208 not detected for: {source!r}"
        assert matches[0].cwe_id == 798
        assert matches[0].severity == "high"

    @pytest.mark.parametrize(
        "source",
        [
            'const name = "Alice"',
            'const username = "admin"',
            'const password = ""',
            'const password = "ch"',
            "const password = getPassword()",
            "const password = process.env.DB_PASSWORD",
        ],
        ids=[
            "normal-name", "username", "empty-password",
            "too-short", "function-call", "env-var",
        ],
    )
    def test_safe_patterns(self, source: str) -> None:
        matches = _findings_for(source, "SC208")
        assert not matches, f"SC208 should not trigger for: {source!r}"


# ---------------------------------------------------------------------------
# SC209 — CWE-327: Weak cryptographic hash
# ---------------------------------------------------------------------------


class TestWeakCrypto:
    """SC209: crypto.createHash() with MD5 or SHA1."""

    @pytest.mark.parametrize(
        "source",
        [
            'crypto.createHash("md5")',
            "crypto.createHash('sha1')",
            'crypto.createHash("MD5")',
            'crypto.createHash("SHA1")',
        ],
        ids=["md5-double", "sha1-single", "MD5-upper", "SHA1-upper"],
    )
    def test_detected(self, source: str) -> None:
        matches = _findings_for(source, "SC209")
        assert matches, f"SC209 not detected for: {source!r}"
        assert matches[0].cwe_id == 327
        assert matches[0].severity == "medium"

    @pytest.mark.parametrize(
        "source",
        [
            'crypto.createHash("sha256")',
            'crypto.createHash("sha512")',
            'crypto.createHash("sha3-256")',
        ],
        ids=["sha256", "sha512", "sha3-256"],
    )
    def test_strong_algo_is_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC209")
        assert not matches, f"SC209 should not trigger for strong hash: {source!r}"

    def test_variable_algo_not_matched(self) -> None:
        # We only flag when we can statically see the algorithm name.
        matches = _findings_for("crypto.createHash(algoVar)", "SC209")
        assert not matches, "SC209 must not flag unknown algo (non-literal)"

    def test_sha_hyphen_1(self) -> None:
        """crypto.createHash('sha-1') should be flagged."""
        matches = _findings_for("crypto.createHash('sha-1')", "SC209")
        assert matches, "sha-1 should be detected as weak"


# ---------------------------------------------------------------------------
# SC210 — CWE-330: Math.random()
# ---------------------------------------------------------------------------


class TestInsecureRandom:
    """SC210: Math.random() is not cryptographically secure."""

    def test_detected(self) -> None:
        matches = _findings_for("Math.random()", "SC210")
        assert matches, "SC210 not detected for Math.random()"
        assert matches[0].cwe_id == 330
        assert matches[0].severity == "medium"

    def test_in_expression(self) -> None:
        matches = _findings_for("const n = Math.random() * 100", "SC210")
        assert matches, "SC210 not detected when Math.random() is inside expression"

    @pytest.mark.parametrize(
        "source",
        [
            "crypto.randomBytes(16)",
            "crypto.randomInt(100)",
            "crypto.getRandomValues(buf)",
        ],
        ids=["randomBytes", "randomInt", "getRandomValues"],
    )
    def test_secure_alternatives_are_safe(self, source: str) -> None:
        matches = _findings_for(source, "SC210")
        assert not matches, f"SC210 should not trigger for secure RNG: {source!r}"
