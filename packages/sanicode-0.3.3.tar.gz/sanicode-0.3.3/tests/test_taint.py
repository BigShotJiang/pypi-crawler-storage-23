"""Tests for intra- and inter-procedural taint propagation.

Each test parses a focused code snippet with tree-sitter, runs entry/sink/sanitizer
detection via PythonPlugin, then verifies taint paths produced by the analyzer.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

from sanicode.scanner.languages.python import PythonPlugin
from sanicode.scanner.registry import get_registry
from sanicode.scanner.taint import (
    TaintPath,
    analyze_file_taint,
    analyze_interprocedural_taint,
)

FILE = Path("<test>")
plugin = PythonPlugin()


def _parse(source: str):
    return plugin.parse_source(dedent(source).encode())


def _analyze(source: str) -> list[TaintPath]:
    """Parse source, detect data-flow primitives, and run taint analysis."""
    source = dedent(source)
    tree = plugin.parse_source(source.encode())
    entry_points = plugin.detect_entry_points(tree, FILE)
    sinks = plugin.detect_sinks(tree, FILE)
    sanitizers = plugin.detect_sanitizers(tree, FILE)
    return analyze_file_taint(FILE, tree, plugin, entry_points, sinks, sanitizers)


# ---------------------------------------------------------------------------
# Basic taint propagation
# ---------------------------------------------------------------------------


class TestTaintPropagation:
    """Taint flows from sources through assignments to sinks."""

    def test_direct_source_to_sink(self):
        """Tainted entry-point call flows directly to sink in same assignment chain."""
        paths = _analyze("""\
            def handle(request):
                user_input = request.args.get("name")
                query = "SELECT * FROM users WHERE name = " + user_input
                cursor.execute(f"SELECT {query}")
        """)
        assert len(paths) >= 1, f"Expected at least one taint path, got {paths}"
        tp = paths[0]
        assert not tp.is_sanitized
        assert tp.sink_name == "cursor.execute"
        assert tp.sink_kind == "sql"

    def test_taint_through_assignment_chain(self):
        """Taint flows through a chain: a -> b -> c -> sink."""
        paths = _analyze("""\
            def handle(request):
                a = request.form["cmd"]
                b = a
                c = b
                os.system(c)
        """)
        assert len(paths) >= 1, f"Expected taint path, got {paths}"
        tp = paths[0]
        assert tp.sink_name == "os.system"
        assert not tp.is_sanitized

    def test_taint_from_env_var(self):
        """os.environ.get() is a taint source, flows to eval sink."""
        paths = _analyze("""\
            def load():
                config = os.environ.get("CMD")
                eval(config)
        """)
        assert len(paths) >= 1, f"Expected taint path from env var, got {paths}"
        tp = paths[0]
        assert tp.source.source_kind == "env_var"
        assert tp.sink_name == "eval"
        assert not tp.is_sanitized

    def test_taint_from_input(self):
        """input() is a taint source."""
        paths = _analyze("""\
            def prompt():
                name = input("Enter: ")
                eval(name)
        """)
        assert len(paths) >= 1
        assert paths[0].source.source_kind == "stdin"
        assert paths[0].sink_name == "eval"

    def test_taint_through_binary_operator(self):
        """Taint propagates through string concatenation."""
        paths = _analyze("""\
            def handle(request):
                user = request.args.get("name")
                msg = "Hello " + user
                eval(msg)
        """)
        assert len(paths) >= 1
        assert paths[0].sink_name == "eval"
        assert not paths[0].is_sanitized


# ---------------------------------------------------------------------------
# Sanitizer handling
# ---------------------------------------------------------------------------


class TestSanitizerKill:
    """Sanitizer calls remove or mark taint as clean."""

    def test_sanitizer_marks_path_as_sanitized(self):
        """html.escape kills taint for XSS-relevant sinks."""
        paths = _analyze("""\
            def handle(request):
                user_input = request.args.get("name")
                safe = html.escape(user_input)
                render_template("page.html", name=safe)
        """)
        # The path should exist but be marked sanitized.
        sanitized = [p for p in paths if p.is_sanitized]
        assert len(sanitized) >= 1, (
            f"Expected sanitized path, got {paths}"
        )
        assert "html.escape" in sanitized[0].sanitizers

    def test_sanitizer_does_not_affect_other_vars(self):
        """Sanitizing one variable does not affect a different tainted variable."""
        paths = _analyze("""\
            def handle(request):
                a = request.args.get("x")
                b = request.args.get("y")
                safe_a = html.escape(a)
                eval(b)
        """)
        # b is still tainted and unsanitized.
        unsanitized = [p for p in paths if not p.is_sanitized]
        assert len(unsanitized) >= 1, (
            f"Expected unsanitized path for b, got {paths}"
        )

    def test_shlex_quote_sanitizes_command_sink(self):
        """shlex.quote sanitizes for command injection sinks."""
        paths = _analyze("""\
            def handle(request):
                cmd = request.args.get("cmd")
                safe = shlex.quote(cmd)
                os.system(safe)
        """)
        sanitized = [p for p in paths if p.is_sanitized]
        assert len(sanitized) >= 1
        assert "shlex.quote" in sanitized[0].sanitizers


# ---------------------------------------------------------------------------
# No taint / false positive avoidance
# ---------------------------------------------------------------------------


class TestNoTaint:
    """No taint paths when there are no external sources."""

    def test_no_source_no_path(self):
        """Pure computation with no external input produces no paths."""
        paths = _analyze("""\
            def compute():
                x = 42
                y = x + 1
                eval(str(y))
        """)
        # eval is a sink but x/y are not tainted from any entry point.
        assert len(paths) == 0, f"Expected no taint paths, got {paths}"

    def test_literal_to_sink_no_path(self):
        """Passing a literal string to a sink is not a taint path."""
        paths = _analyze("""\
            def query():
                cursor.execute(f"SELECT 1")
        """)
        assert len(paths) == 0

    def test_untainted_function_no_path(self):
        """A function without entry-point parameters has no tainted params."""
        paths = _analyze("""\
            def helper(config):
                os.system(config)
        """)
        # 'config' is not a known tainted param name and the function
        # is not an HTTP handler, so no paths.
        assert len(paths) == 0


# ---------------------------------------------------------------------------
# Augmented assignment
# ---------------------------------------------------------------------------


class TestAugmentedAssignment:

    def test_augmented_assignment_propagates_taint(self):
        """``x += tainted`` makes x tainted."""
        paths = _analyze("""\
            def handle(request):
                cmd = request.args.get("cmd")
                prefix = "echo "
                prefix += cmd
                os.system(prefix)
        """)
        assert len(paths) >= 1
        assert paths[0].sink_name == "os.system"
        assert not paths[0].is_sanitized


# ---------------------------------------------------------------------------
# Control flow (conservative union)
# ---------------------------------------------------------------------------


class TestControlFlow:
    """Taint propagates into nested blocks conservatively."""

    def test_taint_in_if_body(self):
        """Sink inside an if block still detects taint from outer scope."""
        paths = _analyze("""\
            def handle(request):
                data = request.args.get("x")
                if True:
                    eval(data)
        """)
        assert len(paths) >= 1
        assert paths[0].sink_name == "eval"

    def test_taint_in_with_block(self):
        """Sink inside a with block detects taint."""
        paths = _analyze("""\
            def handle(request):
                data = request.args.get("x")
                with open("/dev/null", "w") as f:
                    eval(data)
        """)
        assert len(paths) >= 1


# ---------------------------------------------------------------------------
# analyze_file_taint integration
# ---------------------------------------------------------------------------


class TestAnalyzeFileTaint:
    """Test the file-level integration function."""

    def test_multiple_functions(self):
        """analyze_file_taint processes all functions in a file."""
        paths = _analyze("""\
            def handler1(request):
                x = request.args.get("a")
                eval(x)

            def handler2(request):
                y = request.args.get("b")
                os.system(y)
        """)
        sink_names = {p.sink_name for p in paths}
        assert "eval" in sink_names, f"Expected eval sink, got {sink_names}"
        assert "os.system" in sink_names, f"Expected os.system sink, got {sink_names}"

    def test_decorated_function(self):
        """Decorated functions are correctly analyzed."""
        paths = _analyze("""\
            @app.route("/test")
            def handle():
                data = os.environ.get("X")
                eval(data)
        """)
        assert len(paths) >= 1
        assert paths[0].sink_name == "eval"


# ---------------------------------------------------------------------------
# TaintPath data structure
# ---------------------------------------------------------------------------


class TestTaintPathStructure:

    def test_path_fields(self):
        """Verify TaintPath carries complete source and sink metadata."""
        paths = _analyze("""\
            def handle(request):
                x = os.environ.get("KEY")
                eval(x)
        """)
        assert len(paths) >= 1
        tp = paths[0]
        assert tp.source.file == FILE
        assert tp.source.source_kind == "env_var"
        assert tp.source.source_name == "os.environ.get"
        assert tp.sink_name == "eval"
        assert tp.sink_kind == "eval"
        assert tp.sink_line > 0
        assert tp.sanitizers == []
        assert tp.is_sanitized is False


# ---------------------------------------------------------------------------
# Inter-procedural taint analysis
# ---------------------------------------------------------------------------


_INTERPROC_FILE = Path("test_interproc.py")


def _analyze_interprocedural(source: str) -> list[TaintPath]:
    """Parse source, run inter-procedural taint analysis, and return cross-function paths."""
    source = dedent(source)
    tree = plugin.parse_source(source.encode())
    registry = get_registry()
    file_trees = [(_INTERPROC_FILE, tree)]
    return analyze_interprocedural_taint(file_trees, registry)


class TestInterproceduralTaint:
    """Tests for cross-function taint propagation via function summaries."""

    def test_taint_through_helper_to_sql_sink(self):
        """Taint flows from HTTP handler through a helper into a SQL sink.

        Note: cursor.execute is only detected as a sink when it uses string
        formatting (f-string, %, .format) — parameterized queries are safe.
        """
        paths = _analyze_interprocedural("""\
            def run_query(name):
                cursor.execute(f"SELECT * FROM users WHERE name = {name}")

            @app.route("/search")
            def search(request):
                name = request.args.get("name")
                run_query(name)
        """)
        cross = [p for p in paths if p.via_call == "run_query"]
        assert cross, (
            f"Expected a cross-function path via run_query, got {paths}"
        )
        tp = cross[0]
        assert tp.sink_name == "cursor.execute"
        assert tp.sink_kind == "sql"
        assert not tp.is_sanitized
        assert tp.source.source_kind == "http_handler"

    def test_taint_through_helper_to_command_sink(self):
        """Taint flows from HTTP handler through helper into os.system."""
        paths = _analyze_interprocedural("""\
            def execute_cmd(cmd):
                os.system(cmd)

            @app.route("/run")
            def run_cmd(request):
                cmd = request.args.get("cmd")
                execute_cmd(cmd)
        """)
        cross = [p for p in paths if p.via_call == "execute_cmd"]
        assert cross, f"Expected cross-function path via execute_cmd, got {paths}"
        assert cross[0].sink_kind == "command"
        assert not cross[0].is_sanitized

    def test_sanitizer_in_handler_before_call_marks_path_sanitized(self):
        """When the handler sanitizes before calling the helper, path is marked sanitized."""
        paths = _analyze_interprocedural("""\
            def run_eval(x):
                eval(x)

            @app.route("/search")
            def search(request):
                name = request.args.get("name")
                safe = shlex.quote(name)
                run_eval(safe)
        """)
        cross = [p for p in paths if p.via_call == "run_eval"]
        assert cross, f"Expected cross-function path via run_eval, got {paths}"
        assert cross[0].is_sanitized, (
            f"Expected sanitized path, got is_sanitized={cross[0].is_sanitized}, "
            f"sanitizers={cross[0].sanitizers}"
        )
        assert "shlex.quote" in cross[0].sanitizers

    def test_no_cross_function_path_when_no_handler(self):
        """No inter-procedural paths when the caller has no tainted entry-point params."""
        paths = _analyze_interprocedural("""\
            def run_query(name):
                cursor.execute(f"SELECT * FROM users WHERE name = {name}")

            def process(config):
                val = config.get("name")
                run_query(val)
        """)
        # 'process' is not an HTTP handler and 'config' is not a tainted param
        # name, so no inter-procedural path should be emitted.
        cross = [p for p in paths if p.via_call == "run_query"]
        assert not cross, f"Expected no cross-function paths, got {cross}"

    def test_untainted_arg_to_sink_helper_no_path(self):
        """Passing a literal / untainted arg to a helper with a sink emits no path."""
        paths = _analyze_interprocedural("""\
            def helper(x):
                eval(x)

            @app.route("/search")
            def search(request):
                helper("admin")
        """)
        cross = [p for p in paths if p.via_call == "helper"]
        assert not cross, f"Expected no cross-function paths, got {cross}"

    def test_via_call_field_set(self):
        """TaintPath.via_call names the intermediate function."""
        paths = _analyze_interprocedural("""\
            def helper(x):
                eval(x)

            @app.route("/")
            def handler(request):
                val = request.args.get("x")
                helper(val)
        """)
        cross = [p for p in paths if p.via_call is not None]
        assert cross, f"Expected at least one cross-function path, got {paths}"
        assert cross[0].via_call == "helper"


class TestFunctionSummary:
    """Unit tests for the FunctionSummary dataclass and summarize_function method."""

    def test_summary_captures_sink_reachable_from_param(self):
        """summarize_function records params that can reach a sink."""
        from sanicode.scanner.taint import TaintAnalyzer, _walk_functions

        source = dedent("""\
            def helper(name):
                cursor.execute(f"SELECT * FROM users WHERE name = {name}")
        """)
        tree = plugin.parse_source(source.encode())
        entry_points = plugin.detect_entry_points(tree, FILE)
        sinks = plugin.detect_sinks(tree, FILE)
        sanitizers = plugin.detect_sanitizers(tree, FILE)

        analyzer = TaintAnalyzer(plugin)
        funcs = _walk_functions(tree.root_node)
        assert funcs, "Expected at least one function node"

        summary = analyzer.summarize_function(funcs[0], FILE, entry_points, sinks, sanitizers)
        assert summary.func_name == "helper"
        assert "name" in summary.tainted_params_to_sinks, (
            f"Expected 'name' in tainted_params_to_sinks, got {summary.tainted_params_to_sinks}"
        )

    def test_summary_return_carries_taint(self):
        """summarize_function detects when a parameter taints the return value."""
        from sanicode.scanner.taint import TaintAnalyzer, _walk_functions

        source = dedent("""\
            def get_name(request):
                return request.args.get("name")
        """)
        tree = plugin.parse_source(source.encode())
        entry_points = plugin.detect_entry_points(tree, FILE)
        sinks = plugin.detect_sinks(tree, FILE)
        sanitizers = plugin.detect_sanitizers(tree, FILE)

        analyzer = TaintAnalyzer(plugin)
        funcs = _walk_functions(tree.root_node)
        summary = analyzer.summarize_function(funcs[0], FILE, entry_points, sinks, sanitizers)
        # 'request' is a known tainted param name, so it should appear in return taint.
        assert "request" in summary.tainted_params_to_return, (
            "Expected 'request' in tainted_params_to_return, "
            f"got {summary.tainted_params_to_return}"
        )
