"""Tests for the tree-sitter-backed PythonPlugin.

Covers pattern detection, entry point detection, sink detection, sanitizer
detection, import detection, framework detection, and call graph collection.
Also includes Python 2 syntax cases that ast.parse() would reject but
tree-sitter handles gracefully.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from sanicode.scanner.languages.python import PythonPlugin

plugin = PythonPlugin()
FILE = Path("<test>")


def _tree(source: str):
    """Parse a source string into a tree-sitter Tree."""
    return plugin.parse_source(dedent(source).encode())


# ---------------------------------------------------------------------------
# Pattern detection (SC001-SC008)
# ---------------------------------------------------------------------------


class TestPatternDetectionPositive:
    """Each known-bad rule must be detected with the correct fields."""

    @pytest.mark.parametrize(
        ("source", "rule_id", "cwe_id", "severity"),
        [
            ("eval('code')", "SC001", 78, "critical"),
            ("exec('code')", "SC002", 78, "high"),
            ("os.system('ls')", "SC003", 78, "high"),
            ("subprocess.call('ls', shell=True)", "SC004", 78, "high"),
            ("pickle.loads(data)", "SC005", 502, "high"),
            ('cursor.execute(f"SELECT * FROM {table}")', "SC006", 89, "high"),
            ("__import__('os')", "SC007", 94, "medium"),
            ("yaml.load(data)", "SC008", 502, "high"),
        ],
        ids=[
            "SC001-eval",
            "SC002-exec",
            "SC003-os.system",
            "SC004-subprocess-shell",
            "SC005-pickle",
            "SC006-sql-fstring",
            "SC007-import",
            "SC008-yaml-load",
        ],
    )
    def test_rule_detected(
        self, source: str, rule_id: str, cwe_id: int, severity: str
    ) -> None:
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == rule_id]
        assert matches, f"Expected {rule_id} finding for: {source!r}"
        f = matches[0]
        assert f.cwe_id == cwe_id, f"Expected CWE {cwe_id}, got {f.cwe_id}"
        assert f.severity == severity, f"Expected severity {severity!r}, got {f.severity!r}"
        assert f.file == FILE
        assert f.line > 0, f"Expected line > 0, got {f.line}"


class TestPatternDetectionNegative:
    """Safe variants must produce no findings."""

    @pytest.mark.parametrize(
        ("source", "description"),
        [
            ("yaml.load(data, Loader=yaml.SafeLoader)", "yaml.load with Loader"),
            ("subprocess.call(['ls', '-la'])", "subprocess without shell=True"),
            ("print('hello')", "normal function call"),
            ("obj.method()", "normal method call"),
            (
                'cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))',
                "parameterized SQL",
            ),
        ],
        ids=["yaml-safe", "subprocess-safe", "print", "method-call", "parameterized-sql"],
    )
    def test_no_findings(self, source: str, description: str) -> None:
        findings = plugin.check_patterns(_tree(source), FILE)
        assert not findings, f"Expected no findings for {description}, got: {findings}"


class TestPatternFindingFields:
    """Verify all Finding fields are correctly populated."""

    def test_fields_complete(self) -> None:
        source = """\
            x = 1
            eval("code")
        """
        findings = plugin.check_patterns(_tree(source), FILE)
        assert len(findings) == 1, f"Expected exactly 1 finding, got: {findings}"
        f = findings[0]
        assert f.file == FILE
        assert f.line == 2, f"Expected eval on line 2, got line {f.line}"
        assert f.column >= 0, f"Expected non-negative column, got {f.column}"
        assert f.rule_id == "SC001"
        assert f.cwe_id == 78
        assert f.severity == "critical"
        assert "eval" in f.message, f"Expected 'eval' in message, got: {f.message!r}"

    def test_multiple_findings_in_one_file(self) -> None:
        source = """\
            eval("x")
            exec("y")
            os.system("z")
        """
        findings = plugin.check_patterns(_tree(source), FILE)
        rule_ids = {f.rule_id for f in findings}
        assert {"SC001", "SC002", "SC003"} <= rule_ids, (
            f"Expected at least {{SC001, SC002, SC003}}, got: {rule_ids}"
        )


# ---------------------------------------------------------------------------
# Entry point detection
# ---------------------------------------------------------------------------


class TestEntryPointDetection:
    """Entry point detection: HTTP handlers, env vars, stdin, file reads."""

    def test_decorator_http_handler(self) -> None:
        """Flask-style @app.route decorator must be detected as an HTTP handler."""
        source = """\
            @app.route("/login")
            def handle_login():
                pass
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        http_handlers = [r for r in results if r.kind == "http_handler"]
        assert len(http_handlers) == 1, (
            f"Expected 1 http_handler for @app.route, got {len(http_handlers)}: {http_handlers}"
        )
        assert http_handlers[0].name == "handle_login"

    def test_fastapi_router_decorator(self) -> None:
        """FastAPI-style @router.get decorator must be detected as an HTTP handler."""
        source = """\
            @router.get("/users")
            async def list_users():
                pass
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        http_handlers = [r for r in results if r.kind == "http_handler"]
        assert len(http_handlers) == 1, (
            f"Expected 1 http_handler for @router.get, got {len(http_handlers)}: {http_handlers}"
        )

    @pytest.mark.parametrize(
        ("source", "expected_name", "expected_kind", "expected_line", "expected_fn"),
        [
            # 'request' parameter — bare function, no decorator
            (
                """\
                def view(request):
                    pass
                """,
                "view",
                "http_handler",
                1,
                None,
            ),
            # os.environ["KEY"] subscript
            (
                """\
                def setup():
                    val = os.environ["SECRET"]
                """,
                "os.environ",
                "env_var",
                2,
                "setup",
            ),
            # os.getenv call
            (
                """\
                def load():
                    token = os.getenv("TOKEN")
                """,
                "os.getenv",
                "env_var",
                2,
                "load",
            ),
            # os.environ.get call
            (
                """\
                def load():
                    token = os.environ.get("TOKEN")
                """,
                "os.environ.get",
                "env_var",
                2,
                "load",
            ),
            # sys.argv access
            (
                """\
                def main():
                    args = sys.argv
                """,
                "sys.argv",
                "cli_arg",
                2,
                "main",
            ),
            # input() call
            (
                """\
                def prompt():
                    name = input("Enter name: ")
                """,
                "input",
                "stdin",
                2,
                "prompt",
            ),
            # open() in read mode (default — no mode arg)
            (
                """\
                def read_cfg():
                    f = open("config.txt")
                """,
                "open",
                "file_read",
                2,
                "read_cfg",
            ),
        ],
        ids=[
            "request-param",
            "environ-subscript",
            "os-getenv",
            "os-environ-get",
            "sys-argv",
            "input-call",
            "open-read",
        ],
    )
    def test_entry_point_detected(
        self,
        source: str,
        expected_name: str,
        expected_kind: str,
        expected_line: int,
        expected_fn: str | None,
    ) -> None:
        results = plugin.detect_entry_points(_tree(source), FILE)
        matches = [
            r for r in results if r.name == expected_name and r.kind == expected_kind
        ]
        assert matches, (
            f"No EntryPointInfo with name={expected_name!r}, kind={expected_kind!r}"
            f" in {results}"
        )
        ep = matches[0]
        assert ep.line == expected_line, f"Expected line {expected_line}, got {ep.line}"
        assert ep.function == expected_fn, (
            f"Expected function {expected_fn!r}, got {ep.function!r}"
        )
        assert ep.file == FILE

    def test_request_param_produces_one_entry_point(self) -> None:
        """A function with 'request' param must not double-count the HTTP handler."""
        source = """\
            def handle_login(request):
                pass
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        http_handlers = [r for r in results if r.kind == "http_handler"]
        assert len(http_handlers) == 1, (
            f"Expected exactly 1 http_handler, got {len(http_handlers)}: {http_handlers}"
        )

    def test_open_write_is_not_file_read_entry_point(self) -> None:
        """open() in write mode must NOT be flagged as a file_read entry point."""
        source = """\
            def write_it():
                with open("out.txt", "w") as f:
                    f.write("data")
        """
        results = plugin.detect_entry_points(_tree(source), FILE)
        file_reads = [r for r in results if r.kind == "file_read"]
        assert not file_reads, f"Unexpected file_read entry points: {file_reads}"

    def test_module_level_entry_point_has_no_enclosing_function(self) -> None:
        """Entry points at module scope must have function=None."""
        source = "val = os.getenv('HOME')\n"
        results = plugin.detect_entry_points(_tree(source), FILE)
        env_vars = [r for r in results if r.kind == "env_var"]
        assert env_vars, "os.getenv at module level should be detected"
        assert env_vars[0].function is None, (
            f"Module-level entry point should have function=None, got {env_vars[0].function!r}"
        )


# ---------------------------------------------------------------------------
# Sink detection
# ---------------------------------------------------------------------------


class TestSinkDetection:
    """Dangerous sink detection."""

    @pytest.mark.parametrize(
        "source, expected_name, expected_kind, expected_cwe, expected_line, expected_fn",
        [
            # eval()
            (
                """\
                def run_code(user_input):
                    eval(user_input)
                """,
                "eval",
                "eval",
                94,
                2,
                "run_code",
            ),
            # exec()
            (
                """\
                def execute(code):
                    exec(code)
                """,
                "exec",
                "eval",
                94,
                2,
                "execute",
            ),
            # os.system()
            (
                """\
                def run(cmd):
                    os.system(cmd)
                """,
                "os.system",
                "command",
                78,
                2,
                "run",
            ),
            # subprocess.call with shell=True
            (
                """\
                def run_shell(cmd):
                    subprocess.call(cmd, shell=True)
                """,
                "subprocess.call",
                "command",
                78,
                2,
                "run_shell",
            ),
            # cursor.execute with f-string
            (
                """\
                def query(table):
                    cursor.execute(f"SELECT * FROM {table}")
                """,
                "cursor.execute",
                "sql",
                89,
                2,
                "query",
            ),
            # pickle.loads
            (
                """\
                def load_data(data):
                    pickle.loads(data)
                """,
                "pickle.loads",
                "eval",
                502,
                2,
                "load_data",
            ),
            # yaml.load without Loader
            (
                """\
                def load_yaml(data):
                    yaml.load(data)
                """,
                "yaml.load",
                "eval",
                502,
                2,
                "load_yaml",
            ),
            # render_template
            (
                """\
                def show(val):
                    render_template("page.html", user_input=val)
                """,
                "render_template",
                "template",
                79,
                2,
                "show",
            ),
            # requests.get
            (
                """\
                def fetch(url):
                    requests.get(url)
                """,
                "requests.get",
                "network",
                918,
                2,
                "fetch",
            ),
        ],
        ids=[
            "eval",
            "exec",
            "os.system",
            "subprocess-shell",
            "cursor-execute-fstring",
            "pickle.loads",
            "yaml.load-no-loader",
            "render_template",
            "requests.get",
        ],
    )
    def test_sink_detected(
        self,
        source: str,
        expected_name: str,
        expected_kind: str,
        expected_cwe: int,
        expected_line: int,
        expected_fn: str | None,
    ) -> None:
        results = plugin.detect_sinks(_tree(source), FILE)
        matches = [r for r in results if r.name == expected_name and r.kind == expected_kind]
        assert matches, (
            f"No SinkInfo with name={expected_name!r}, kind={expected_kind!r} in {results}"
        )
        sink = matches[0]
        assert sink.cwe_id == expected_cwe, f"Expected CWE {expected_cwe}, got {sink.cwe_id}"
        assert sink.line == expected_line, f"Expected line {expected_line}, got {sink.line}"
        assert sink.function == expected_fn, (
            f"Expected fn {expected_fn!r}, got {sink.function!r}"
        )
        assert sink.file == FILE

    def test_yaml_load_with_loader_is_safe(self) -> None:
        """yaml.load(data, Loader=yaml.SafeLoader) must NOT be flagged as a sink."""
        source = """\
            def safe_load(data):
                yaml.load(data, Loader=yaml.SafeLoader)
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        yaml_sinks = [r for r in results if r.name == "yaml.load"]
        assert not yaml_sinks, f"yaml.load with Loader should not be a sink: {yaml_sinks}"

    def test_subprocess_without_shell_is_safe(self) -> None:
        """subprocess.call without shell=True must NOT be flagged."""
        source = """\
            def run(cmd):
                subprocess.call(["ls", "-la"])
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert not cmd_sinks, (
            f"subprocess without shell=True should not be a sink: {cmd_sinks}"
        )

    def test_open_write_is_file_write_sink(self) -> None:
        """open() in write mode must be identified as a file_write sink."""
        source = """\
            def write_it(path, content):
                with open(path, "w") as f:
                    f.write(content)
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        file_writes = [r for r in results if r.kind == "file_write"]
        assert file_writes, f"open('w') should produce a file_write sink: {results}"

    def test_non_subprocess_run_not_flagged(self) -> None:
        """obj.run(shell=True) must NOT be flagged when receiver is not subprocess."""
        source = """\
            def process(obj):
                obj.run("task", shell=True)
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert not cmd_sinks, (
            f"Non-subprocess .run(shell=True) should not produce sinks: {cmd_sinks}"
        )

    def test_non_subprocess_call_not_flagged(self) -> None:
        """obj.call(shell=True) must NOT be flagged when receiver is not subprocess."""
        source = """\
            def process(obj):
                obj.call("task", shell=True)
        """
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert not cmd_sinks, (
            f"Non-subprocess .call(shell=True) should not produce sinks: {cmd_sinks}"
        )


# ---------------------------------------------------------------------------
# Sanitizer detection
# ---------------------------------------------------------------------------


class TestSanitizerDetection:
    """Sanitizer detection: escape calls and parameterized queries."""

    @pytest.mark.parametrize(
        ("source", "expected_name", "expected_kind", "expected_line", "expected_fn"),
        [
            # html.escape
            (
                """\
                def safe_html(text):
                    return html.escape(text)
                """,
                "html.escape",
                "html_escape",
                2,
                "safe_html",
            ),
            # shlex.quote
            (
                """\
                def safe_cmd(cmd):
                    return shlex.quote(cmd)
                """,
                "shlex.quote",
                "shell_quote",
                2,
                "safe_cmd",
            ),
            # markupsafe.escape
            (
                """\
                def safe_markup(text):
                    return markupsafe.escape(text)
                """,
                "markupsafe.escape",
                "html_escape",
                2,
                "safe_markup",
            ),
            # cursor.execute with parameterized tuple
            (
                """\
                def get_user(user_id):
                    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
                """,
                "cursor.execute",
                "parameterized_query",
                2,
                "get_user",
            ),
            # urllib.parse.quote
            (
                """\
                def encode_url(text):
                    return urllib.parse.quote(text)
                """,
                "urllib.parse.quote",
                "url_encode",
                2,
                "encode_url",
            ),
        ],
        ids=[
            "html.escape", "shlex.quote", "markupsafe.escape",
            "cursor-parameterized", "urllib.parse.quote",
        ],
    )
    def test_sanitizer_detected(
        self,
        source: str,
        expected_name: str,
        expected_kind: str,
        expected_line: int,
        expected_fn: str | None,
    ) -> None:
        results = plugin.detect_sanitizers(_tree(source), FILE)
        matches = [r for r in results if r.name == expected_name and r.kind == expected_kind]
        assert matches, (
            f"No SanitizerInfo with name={expected_name!r}, kind={expected_kind!r}"
            f" in {results}"
        )
        san = matches[0]
        assert san.line == expected_line, f"Expected line {expected_line}, got {san.line}"
        assert san.function == expected_fn, (
            f"Expected fn {expected_fn!r}, got {san.function!r}"
        )
        assert san.file == FILE

    def test_cursor_execute_fstring_is_not_sanitizer(self) -> None:
        """cursor.execute with a raw f-string must NOT be a sanitizer (it is a sink)."""
        source = """\
            def bad_query(table):
                cursor.execute(f"SELECT * FROM {table}")
        """
        results = plugin.detect_sanitizers(_tree(source), FILE)
        parameterized = [r for r in results if r.kind == "parameterized_query"]
        assert not parameterized, (
            f"cursor.execute with f-string should not be a sanitizer: {parameterized}"
        )


# ---------------------------------------------------------------------------
# Import detection
# ---------------------------------------------------------------------------


class TestImportDetection:
    """Import extraction from tree-sitter parse trees."""

    FAKE_PATH = Path("test.py")

    def test_simple_import(self) -> None:
        tree = _tree("import os")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "os"
        assert result[0].is_from is False
        assert result[0].names == []

    def test_dotted_import(self) -> None:
        tree = _tree("import os.path")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "os.path"

    def test_aliased_import(self) -> None:
        tree = _tree("import numpy as np")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "numpy"
        assert result[0].aliases == {"np": "numpy"}

    def test_from_import(self) -> None:
        tree = _tree("from flask import Flask, request")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "flask"
        assert "Flask" in result[0].names
        assert "request" in result[0].names
        assert result[0].is_from is True

    def test_from_import_with_alias(self) -> None:
        tree = _tree("from datetime import datetime as dt")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].aliases == {"dt": "datetime"}

    def test_multiple_imports(self) -> None:
        code = "import os\nimport sys\nfrom pathlib import Path"
        tree = _tree(code)
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 3

    def test_relative_import(self) -> None:
        tree = _tree("from . import utils")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert "utils" in result[0].names

    def test_star_import(self) -> None:
        tree = _tree("from os.path import *")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert len(result) == 1
        assert result[0].module == "os.path"
        assert result[0].names == ["*"]

    def test_empty_file(self) -> None:
        tree = _tree("")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert result == []

    def test_file_path_recorded(self) -> None:
        p = Path("/src/app.py")
        tree = _tree("import os")
        result = plugin.detect_imports(tree, p)
        assert result[0].file == p

    def test_line_number_recorded(self) -> None:
        tree = _tree("# comment\nimport os")
        result = plugin.detect_imports(tree, self.FAKE_PATH)
        assert result[0].line == 2


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------


class TestFrameworkDetection:
    """Framework detection delegates to the pure-logic function; smoke test it."""

    FAKE_PATH = Path("test.py")

    def test_flask_detected_via_plugin(self) -> None:
        tree = _tree("from flask import Flask")
        imports = plugin.detect_imports(tree, self.FAKE_PATH)
        frameworks = plugin.detect_frameworks(imports)
        assert any(fw.name == "flask" for fw in frameworks), (
            f"Expected flask framework, got: {frameworks}"
        )

    def test_no_framework_for_stdlib(self) -> None:
        tree = _tree("import os\nimport sys")
        imports = plugin.detect_imports(tree, self.FAKE_PATH)
        frameworks = plugin.detect_frameworks(imports)
        assert frameworks == []


# ---------------------------------------------------------------------------
# Call graph: collect_definitions
# ---------------------------------------------------------------------------


class TestCollectDefinitions:
    """Function definition collection via the plugin."""

    def test_simple_function(self) -> None:
        tree = _tree("def greet(name):\n    return f'Hello {name}'")
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.greet" in defs
        assert defs["test.greet"].params == ["name"]

    def test_class_method(self) -> None:
        code = "class Foo:\n    def bar(self, x):\n        pass"
        tree = _tree(code)
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.Foo.bar" in defs
        assert defs["test.Foo.bar"].params == ["self", "x"]

    def test_async_function(self) -> None:
        code = "async def fetch(url):\n    pass"
        tree = _tree(code)
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "test.fetch" in defs, (
            f"Expected 'test.fetch' in definitions, got: {set(defs.keys())}"
        )

    def test_multi_file(self) -> None:
        tree1 = _tree("def func_a():\n    pass")
        tree2 = _tree("def func_b():\n    pass")
        defs = plugin.collect_definitions([
            (Path("routes.py"), tree1),
            (Path("service.py"), tree2),
        ])
        assert "routes.func_a" in defs
        assert "service.func_b" in defs

    def test_short_name_registered(self) -> None:
        tree = _tree("def unique_func():\n    pass")
        defs = plugin.collect_definitions([(Path("test.py"), tree)])
        assert "unique_func" in defs
        assert "test.unique_func" in defs


# ---------------------------------------------------------------------------
# Call graph: collect_call_sites
# ---------------------------------------------------------------------------


class TestCollectCallSites:
    """Call site collection via the plugin."""

    def test_simple_call(self) -> None:
        code = "def main():\n    greet('world')"
        tree = _tree(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "greet" and s.caller == "main" for s in sites), (
            f"Expected greet called from main; got {sites}"
        )

    def test_method_call(self) -> None:
        code = "def main():\n    db.execute(query)"
        tree = _tree(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "db.execute" for s in sites), (
            f"Expected db.execute in call sites; got {sites}"
        )

    def test_nested_call_tracking(self) -> None:
        code = "def outer():\n    def inner():\n        foo()\n    bar()"
        tree = _tree(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        foo_site = next((s for s in sites if s.target == "foo"), None)
        bar_site = next((s for s in sites if s.target == "bar"), None)
        assert foo_site is not None, f"Expected foo in call sites; got {sites}"
        assert bar_site is not None, f"Expected bar in call sites; got {sites}"
        assert foo_site.caller == "inner", f"Expected foo.caller='inner', got {foo_site.caller!r}"
        assert bar_site.caller == "outer", f"Expected bar.caller='outer', got {bar_site.caller!r}"

    def test_module_level_call(self) -> None:
        code = "setup()"
        tree = _tree(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        assert any(s.target == "setup" and s.caller == "" for s in sites), (
            f"Expected module-level setup call; got {sites}"
        )

    def test_args_captured(self) -> None:
        code = "def f():\n    greet(name, 42)"
        tree = _tree(code)
        sites = plugin.collect_call_sites([(Path("test.py"), tree)])
        greet_site = next((s for s in sites if s.target == "greet"), None)
        assert greet_site is not None, f"Expected greet in call sites; got {sites}"
        assert "name" in greet_site.args, (
            f"Expected 'name' in greet args, got {greet_site.args}"
        )
        assert "<expr>" in greet_site.args, (
            f"Expected '<expr>' in greet args for literal 42, got {greet_site.args}"
        )


# ---------------------------------------------------------------------------
# Python 2 syntax — tree-sitter handles these, ast.parse() would fail
# ---------------------------------------------------------------------------


class TestPython2Syntax:
    """tree-sitter parses Python 2 constructs without raising exceptions."""

    def test_print_statement(self) -> None:
        """Python 2 print statement is parsed without error."""
        tree = plugin.parse_source(b'print "hello"')
        # tree-sitter may produce an error node but must not raise
        root = tree.root_node
        assert root is not None
        assert root.type == "module"

    def test_exec_statement(self) -> None:
        """Python 2 exec as a statement is parsed without exception."""
        tree = plugin.parse_source(b'exec "code"')
        root = tree.root_node
        assert root is not None
        assert root.type == "module"

    def test_except_comma_syntax(self) -> None:
        """Python 2 except-clause comma syntax is parsed without exception."""
        source = b"try:\n    pass\nexcept Exception, e:\n    pass"
        tree = plugin.parse_source(source)
        root = tree.root_node
        assert root is not None
        assert root.type == "module"
