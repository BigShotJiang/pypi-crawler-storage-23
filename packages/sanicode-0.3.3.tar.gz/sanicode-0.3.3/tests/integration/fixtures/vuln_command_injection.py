"""Vulnerable: OS command injection via os.system (SC003 / CWE-78).

Expected: sanicode detects SC003, LLM retains as true positive.
"""

import os


def run_user_command(user_input):
    """Execute user-provided command — VULNERABLE to command injection."""
    os.system("echo " + user_input)
