"""Integration tests for Granite Code 8B (or compatible) LLM endpoint.

Run with:
    SANICODE_TEST_LLM_ENDPOINT=http://host:port/v1 pytest tests/integration/ -m integration -v

All tests are skipped when SANICODE_TEST_LLM_ENDPOINT is not set.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import httpx
import pytest

from sanicode.config import SanicodeConfig
from sanicode.llm.client import LLMClient
from sanicode.scanner.executor import run_scan

_log = logging.getLogger(__name__)

pytestmark = pytest.mark.integration


class TestModelEndpointHealth:
    """Verify the LLM endpoint is alive and serving the expected model."""

    def test_models_endpoint(
        self, llm_provider: str, llm_endpoint: str | None, llm_model_name: str,
    ) -> None:
        if llm_provider != "openai":
            pytest.skip(
                f"GET /models health check not applicable for provider {llm_provider!r}"
            )
        assert llm_endpoint is not None
        resp = httpx.get(f"{llm_endpoint}/models", timeout=10)
        assert resp.status_code == 200, f"GET /v1/models returned {resp.status_code}"
        data = resp.json()
        model_ids = [m["id"] for m in data.get("data", [])]
        assert llm_model_name in model_ids, (
            f"Expected model {llm_model_name!r} in {model_ids}"
        )


class TestClassificationTier:
    """Test the fast tier with a classification prompt."""

    def test_classify_returns_valid_json(self, llm_client: LLMClient) -> None:
        prompt = (
            "You are a code security classifier. Analyze the following finding "
            "and respond ONLY with JSON: {\"is_true_positive\": true/false, "
            "\"confidence\": 0.0-1.0, \"reasoning\": \"...\"}\n\n"
            "Finding: SC001 — eval() call at app.py:10\n"
            "Code: eval(user_input)\n"
            "Severity: critical\nCWE: 94"
        )
        response = llm_client.classify(prompt)
        assert response.content, "Empty response from LLM"
        # Attempt JSON parse — LLM may wrap in markdown fences
        content = response.content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        result = json.loads(content)
        assert "is_true_positive" in result
        assert "confidence" in result
        assert "reasoning" in result


class TestFalsePositiveFiltering:
    """Test LLM-based false positive filtering on known fixtures."""

    def test_safe_parameterized_filtered(
        self, integration_config: SanicodeConfig, fixtures_dir: Path,
    ) -> None:
        """eval(CONSTANT) should be filtered by LLM as false positive."""
        safe_file = fixtures_dir / "safe_parameterized.py"

        # Scan WITHOUT LLM — should find SC001
        no_llm_cfg = SanicodeConfig()
        no_llm_output = run_scan(safe_file, no_llm_cfg)
        static_sc001 = [f for f in no_llm_output.enriched_findings if f.rule_id == "SC001"]
        assert len(static_sc001) > 0, "Static analysis should detect SC001 on eval()"

        # Scan WITH LLM — SC001 should be filtered out
        llm_output = run_scan(safe_file, integration_config)
        llm_sc001 = [f for f in llm_output.enriched_findings if f.rule_id == "SC001"]
        if llm_sc001:
            _log.warning(
                "LLM did not filter SC001 on safe_parameterized.py — "
                "model may need prompt tuning (non-deterministic, not a hard failure)"
            )

    def test_vuln_command_injection_retained(
        self, integration_config: SanicodeConfig, fixtures_dir: Path,
    ) -> None:
        """os.system(user_input) should be retained by LLM as true positive."""
        vuln_file = fixtures_dir / "vuln_command_injection.py"
        output = run_scan(vuln_file, integration_config)
        sc003 = [f for f in output.enriched_findings if f.rule_id == "SC003"]
        assert len(sc003) > 0, "LLM should retain SC003 for real command injection"

    def test_vuln_sql_injection_retained(
        self, integration_config: SanicodeConfig, fixtures_dir: Path,
    ) -> None:
        """SQL injection via string formatting should be retained by LLM."""
        vuln_file = fixtures_dir / "vuln_sql_injection.py"
        output = run_scan(vuln_file, integration_config)
        sc006 = [f for f in output.enriched_findings if f.rule_id == "SC006"]
        assert len(sc006) > 0, "LLM should retain SC006 for real SQL injection"


class TestFullScanPipeline:
    """Test a complete scan of the fixtures directory with LLM enabled."""

    def test_scan_fixtures_directory(
        self, integration_config: SanicodeConfig, fixtures_dir: Path,
    ) -> None:
        output = run_scan(fixtures_dir, integration_config)

        assert output.enriched_findings, "Scan should produce findings"
        assert output.result.summary["total_findings"] > 0
        assert len(output.graph_data.get("nodes", [])) > 0

        # LLM should reduce findings vs pure static analysis
        no_llm_output = run_scan(fixtures_dir, SanicodeConfig())
        assert len(output.enriched_findings) <= len(no_llm_output.enriched_findings), (
            "LLM-enabled scan should have equal or fewer findings than static-only"
        )


class TestResponseQuality:
    """Validate LLM response quality characteristics."""

    def test_reasoning_non_empty(self, llm_client: LLMClient) -> None:
        prompt = (
            "You are a code security classifier. Analyze the following finding "
            "and respond ONLY with JSON: {\"is_true_positive\": true/false, "
            "\"confidence\": 0.0-1.0, \"reasoning\": \"...\"}\n\n"
            "Finding: SC003 — os.system() call at handler.py:42\n"
            "Code: os.system('echo ' + request.args.get('cmd'))\n"
            "Severity: high\nCWE: 78"
        )
        response = llm_client.classify(prompt)
        content = response.content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        try:
            result = json.loads(content)
            reasoning = result.get("reasoning", "")
            assert len(reasoning) > 10, f"Reasoning too short: {reasoning!r}"
        except json.JSONDecodeError:
            _log.warning("LLM response was not valid JSON: %s", content[:200])

    def test_latency_acceptable(self, llm_client: LLMClient) -> None:
        import time

        prompt = "Respond with: {\"status\": \"ok\"}"
        start = time.monotonic()
        llm_client.classify(prompt)
        elapsed = time.monotonic() - start
        assert elapsed < 30, f"LLM response took {elapsed:.1f}s (limit: 30s)"

    def test_usage_reported(self, llm_client: LLMClient) -> None:
        response = llm_client.classify("Say hello.")
        assert response.usage["prompt_tokens"] > 0, "Expected prompt_tokens > 0"
        assert response.usage["completion_tokens"] > 0, "Expected completion_tokens > 0"
