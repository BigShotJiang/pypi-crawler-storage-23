"""Tests for YAML-based custom rule loading and the `sanicode rules` CLI command.

Covers:
- Loading valid single and multi-rule YAML files.
- Rule detection (pattern matching) via the loaded CallRule instances.
- Validation errors for invalid YAML specs.
- discover_yaml_rules directory scanning.
- CLI: `sanicode rules --list` and `sanicode rules --validate`.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest
from typer.testing import CliRunner

from sanicode.cli import app
from sanicode.rules.custom import discover_yaml_rules, load_yaml_rules
from sanicode.scanner.languages.python import PythonPlugin

runner = CliRunner()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_PLUGIN = PythonPlugin()


def _findings(source: str, rule):
    """Run *rule* against *source* code; return list of Finding."""
    tree = _PLUGIN.parse_source(dedent(source).encode())
    return rule.check(tree, Path("<test>"), _PLUGIN)


def _write_yaml(path: Path, content: str) -> Path:
    """Write *content* to *path* and return *path*."""
    path.write_text(dedent(content), encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# TestYamlRuleLoading
# ---------------------------------------------------------------------------


class TestYamlRuleLoading:
    """Unit tests for load_yaml_rules()."""

    def test_load_single_call_rule(self, tmp_path: Path) -> None:
        """Load a YAML file with one call-pattern rule."""
        yaml_file = _write_yaml(
            tmp_path / "single.yaml",
            """
            rules:
              - id: CUSTOM001
                cwe_id: 502
                severity: high
                language: python
                message: "Unsafe yaml.load (CWE-502)"
                pattern:
                  type: call
                  targets:
                    - "yaml.load"
            """,
        )

        rules = load_yaml_rules(yaml_file)
        assert len(rules) == 1, f"Expected 1 rule, got {len(rules)}"

        rule = rules[0]
        assert rule.rule_id == "CUSTOM001"
        assert rule.cwe_id == 502
        assert rule.severity == "high"
        assert rule.language == "python"
        assert "yaml.load" in rule.message.lower() or "CWE-502" in rule.message

    def test_load_multiple_rules(self, tmp_path: Path) -> None:
        """Load a YAML file with multiple rules."""
        yaml_file = _write_yaml(
            tmp_path / "multi.yaml",
            """
            rules:
              - id: MULTI001
                cwe_id: 78
                severity: critical
                language: python
                message: "os.popen shell injection (CWE-78)"
                pattern:
                  type: call
                  targets:
                    - "os.popen"
              - id: MULTI002
                cwe_id: 502
                severity: high
                language: python
                message: "pickle.load (CWE-502)"
                pattern:
                  type: call
                  targets:
                    - "pickle.load"
                    - "pickle.loads"
            """,
        )

        rules = load_yaml_rules(yaml_file)
        assert len(rules) == 2, f"Expected 2 rules, got {len(rules)}"

        ids = {r.rule_id for r in rules}
        assert ids == {"MULTI001", "MULTI002"}

    def test_yaml_rule_detects_pattern(self, tmp_path: Path) -> None:
        """A loaded YAML rule actually detects the target pattern in source code."""
        yaml_file = _write_yaml(
            tmp_path / "detect.yaml",
            """
            rules:
              - id: DETECT001
                cwe_id: 78
                severity: critical
                language: python
                message: "os.popen() is dangerous"
                pattern:
                  type: call
                  targets:
                    - "os.popen"
            """,
        )

        rules = load_yaml_rules(yaml_file)
        assert len(rules) == 1
        rule = rules[0]

        # Should detect the dangerous pattern.
        findings = _findings("os.popen('ls -la')", rule)
        assert len(findings) == 1, (
            f"Expected 1 finding for os.popen(), got {len(findings)}"
        )
        assert findings[0].rule_id == "DETECT001"
        assert findings[0].cwe_id == 78
        assert findings[0].severity == "critical"

        # Should not fire on an unrelated call.
        no_findings = _findings("os.path.join('/tmp', 'safe')", rule)
        assert not no_findings, "DETECT001 should not fire on os.path.join()"

    def test_yaml_rule_detects_simple_identifier(self, tmp_path: Path) -> None:
        """A rule with a non-dotted target detects bare identifier calls."""
        yaml_file = _write_yaml(
            tmp_path / "simple.yaml",
            """
            rules:
              - id: SIMPLE001
                cwe_id: 78
                severity: critical
                language: python
                message: "eval() is dangerous"
                pattern:
                  type: call
                  targets:
                    - "eval"
            """,
        )

        rules = load_yaml_rules(yaml_file)
        rule = rules[0]

        findings = _findings("eval(user_input)", rule)
        assert len(findings) == 1, f"Expected 1 finding, got {len(findings)}"
        assert findings[0].rule_id == "SIMPLE001"

    def test_yaml_rule_required_keywords(self, tmp_path: Path) -> None:
        """A rule with required_keywords only fires when those kwargs are present."""
        yaml_file = _write_yaml(
            tmp_path / "kw.yaml",
            """
            rules:
              - id: KW001
                cwe_id: 78
                severity: high
                language: python
                message: "subprocess.run with shell=True"
                pattern:
                  type: call
                  targets:
                    - "subprocess.run"
                  required_keywords:
                    shell: "True"
            """,
        )

        rules = load_yaml_rules(yaml_file)
        rule = rules[0]

        # Should fire when shell=True is present.
        findings = _findings("subprocess.run(['ls'], shell=True)", rule)
        assert len(findings) == 1, (
            f"Expected 1 finding with shell=True, got {len(findings)}"
        )

        # Should NOT fire when shell=True is absent.
        no_findings = _findings("subprocess.run(['ls'])", rule)
        assert not no_findings, "KW001 must not fire without shell=True"

    def test_invalid_yaml_rule_raises(self, tmp_path: Path) -> None:
        """Invalid YAML rule spec raises ValueError with a descriptive message."""
        yaml_file = _write_yaml(
            tmp_path / "bad.yaml",
            """
            rules:
              - id: BAD001
                cwe_id: "not-an-int"
                severity: high
                language: python
                message: "Missing integer cwe_id"
                pattern:
                  type: call
                  targets:
                    - "os.system"
            """,
        )

        with pytest.raises(ValueError, match="cwe_id"):
            load_yaml_rules(yaml_file)

    def test_invalid_severity_raises(self, tmp_path: Path) -> None:
        """An unrecognised severity value raises ValueError."""
        yaml_file = _write_yaml(
            tmp_path / "badsev.yaml",
            """
            rules:
              - id: SEV001
                cwe_id: 78
                severity: extreme
                language: python
                message: "bad severity"
                pattern:
                  type: call
                  targets:
                    - "os.system"
            """,
        )

        with pytest.raises(ValueError, match="severity"):
            load_yaml_rules(yaml_file)

    def test_missing_targets_raises(self, tmp_path: Path) -> None:
        """A rule with an empty targets list raises ValueError."""
        yaml_file = _write_yaml(
            tmp_path / "notargets.yaml",
            """
            rules:
              - id: NT001
                cwe_id: 78
                severity: high
                language: python
                message: "no targets"
                pattern:
                  type: call
                  targets: []
            """,
        )

        with pytest.raises(ValueError, match="targets"):
            load_yaml_rules(yaml_file)

    def test_missing_rules_key_raises(self, tmp_path: Path) -> None:
        """A YAML file without a top-level 'rules' key raises ValueError."""
        yaml_file = _write_yaml(
            tmp_path / "norules.yaml",
            """
            something_else:
              - foo
            """,
        )

        with pytest.raises(ValueError, match="'rules'"):
            load_yaml_rules(yaml_file)

    def test_file_not_found_raises(self, tmp_path: Path) -> None:
        """load_yaml_rules raises FileNotFoundError for missing files."""
        with pytest.raises(FileNotFoundError):
            load_yaml_rules(tmp_path / "nonexistent.yaml")

    def test_discover_from_directory(self, tmp_path: Path) -> None:
        """discover_yaml_rules finds rules in a directory."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()

        _write_yaml(
            rules_dir / "first.yaml",
            """
            rules:
              - id: DISC001
                cwe_id: 78
                severity: high
                language: python
                message: "discovered rule 1"
                pattern:
                  type: call
                  targets:
                    - "os.popen"
            """,
        )
        _write_yaml(
            rules_dir / "second.yaml",
            """
            rules:
              - id: DISC002
                cwe_id: 502
                severity: medium
                language: python
                message: "discovered rule 2"
                pattern:
                  type: call
                  targets:
                    - "pickle.load"
            """,
        )

        discovered = discover_yaml_rules(search_dirs=[rules_dir])
        ids = {r.rule_id for r in discovered}
        assert "DISC001" in ids, f"Expected DISC001 in discovered rules, got {ids}"
        assert "DISC002" in ids, f"Expected DISC002 in discovered rules, got {ids}"

    def test_discover_recurses_subdirectories(self, tmp_path: Path) -> None:
        """discover_yaml_rules recurses into subdirectories."""
        sub = tmp_path / "rules" / "custom"
        sub.mkdir(parents=True)

        _write_yaml(
            sub / "nested.yaml",
            """
            rules:
              - id: NESTED001
                cwe_id: 78
                severity: high
                language: python
                message: "nested rule"
                pattern:
                  type: call
                  targets:
                    - "os.system"
            """,
        )

        discovered = discover_yaml_rules(search_dirs=[tmp_path / "rules"])
        ids = {r.rule_id for r in discovered}
        assert "NESTED001" in ids, f"Expected NESTED001 in discovered rules, got {ids}"

    def test_discover_skips_invalid_files(self, tmp_path: Path) -> None:
        """discover_yaml_rules skips invalid files and loads the rest."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()

        # One good file.
        _write_yaml(
            rules_dir / "good.yaml",
            """
            rules:
              - id: GOOD001
                cwe_id: 78
                severity: high
                language: python
                message: "good rule"
                pattern:
                  type: call
                  targets:
                    - "os.system"
            """,
        )
        # One bad file.
        _write_yaml(
            rules_dir / "bad.yaml",
            """
            not_rules:
              - whatever
            """,
        )

        discovered = discover_yaml_rules(search_dirs=[rules_dir])
        ids = {r.rule_id for r in discovered}
        assert "GOOD001" in ids
        # The bad file is skipped; we still get the good rule.
        assert len(discovered) == 1, f"Expected 1 rule, got {len(discovered)}: {ids}"

    def test_discover_empty_search_list(self) -> None:
        """Passing an empty search_dirs list returns no rules."""
        result = discover_yaml_rules(search_dirs=[])
        assert result == []


# ---------------------------------------------------------------------------
# TestRulesCommand
# ---------------------------------------------------------------------------


class TestRulesCommand:
    """CLI tests for `sanicode rules`."""

    def test_rules_list(self) -> None:
        """sanicode rules --list shows registered rules in a table."""
        result = runner.invoke(app, ["rules", "--list"])
        assert result.exit_code == 0, (
            f"Expected exit code 0, got {result.exit_code}:\n{result.output}"
        )
        # Built-in rules should appear in the table.
        assert "SC001" in result.output, (
            f"Expected SC001 in --list output:\n{result.output}"
        )
        assert "CWE-78" in result.output, (
            f"Expected CWE-78 in --list output:\n{result.output}"
        )

    def test_rules_no_flags_shows_hint(self) -> None:
        """sanicode rules with no flags prints a usage hint and exits 0."""
        result = runner.invoke(app, ["rules"])
        assert result.exit_code == 0, (
            f"Expected exit code 0, got {result.exit_code}:\n{result.output}"
        )
        assert "--list" in result.output or "--validate" in result.output

    def test_rules_validate_valid(self, tmp_path: Path) -> None:
        """sanicode rules --validate on a valid YAML file exits 0 and prints OK."""
        yaml_file = _write_yaml(
            tmp_path / "valid.yaml",
            """
            rules:
              - id: VALID001
                cwe_id: 78
                severity: high
                language: python
                message: "valid custom rule"
                pattern:
                  type: call
                  targets:
                    - "os.popen"
            """,
        )

        result = runner.invoke(app, ["rules", "--validate", str(yaml_file)])
        assert result.exit_code == 0, (
            f"Expected exit code 0 for valid YAML, got {result.exit_code}:\n{result.output}"
        )
        assert "OK" in result.output or "valid" in result.output.lower(), (
            f"Expected success indicator in output:\n{result.output}"
        )
        assert "VALID001" in result.output, (
            f"Expected rule ID in --validate output:\n{result.output}"
        )

    def test_rules_validate_invalid(self, tmp_path: Path) -> None:
        """sanicode rules --validate on invalid YAML exits 1 and reports errors."""
        yaml_file = _write_yaml(
            tmp_path / "invalid.yaml",
            """
            rules:
              - id: BAD001
                cwe_id: "not-an-integer"
                severity: high
                language: python
                message: "bad rule"
                pattern:
                  type: call
                  targets:
                    - "os.system"
            """,
        )

        result = runner.invoke(app, ["rules", "--validate", str(yaml_file)])
        assert result.exit_code == 1, (
            f"Expected exit code 1 for invalid YAML, got {result.exit_code}:\n{result.output}"
        )
        assert "error" in result.output.lower() or "fail" in result.output.lower(), (
            f"Expected error indicator in output:\n{result.output}"
        )

    def test_rules_validate_missing_file(self, tmp_path: Path) -> None:
        """sanicode rules --validate on a missing file exits 1."""
        missing = tmp_path / "nonexistent.yaml"
        result = runner.invoke(app, ["rules", "--validate", str(missing)])
        assert result.exit_code == 1, (
            f"Expected exit code 1 for missing file, got {result.exit_code}:\n{result.output}"
        )

    def test_rules_help(self) -> None:
        """sanicode rules --help exits 0."""
        result = runner.invoke(app, ["rules", "--help"])
        assert result.exit_code == 0, (
            f"Expected exit code 0 for --help, got {result.exit_code}:\n{result.output}"
        )
        assert "rules" in result.output.lower()
