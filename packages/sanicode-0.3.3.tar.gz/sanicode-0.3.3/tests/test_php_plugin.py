"""Tests for the tree-sitter-backed PHPPlugin."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

from sanicode.scanner.languages.php import PHPPlugin

plugin = PHPPlugin()
FILE = Path("<test>")


def _tree(source: str):
    """Parse PHP source, prepending ``<?php`` if absent."""
    code = dedent(source)
    if not code.strip().startswith("<?php"):
        code = "<?php\n" + code
    return plugin.parse_source(code.encode())


# ---------------------------------------------------------------------------
# Import detection
# ---------------------------------------------------------------------------


class TestImportDetection:
    def test_require(self):
        tree = _tree('require "vendor/autoload.php";')
        result = plugin.detect_imports(tree, FILE)
        assert len(result) >= 1
        assert any(r.module == "vendor/autoload.php" for r in result)

    def test_include(self):
        tree = _tree('include "config.php";')
        result = plugin.detect_imports(tree, FILE)
        assert len(result) >= 1
        assert any(r.module == "config.php" for r in result)

    def test_require_once(self):
        tree = _tree('require_once "vendor/autoload.php";')
        result = plugin.detect_imports(tree, FILE)
        assert any(r.module == "vendor/autoload.php" for r in result)

    def test_use_namespace(self):
        tree = _tree(r"use Illuminate\Http\Request;")
        result = plugin.detect_imports(tree, FILE)
        assert len(result) >= 1
        laravel = [r for r in result if "Illuminate" in r.module]
        assert laravel, f"Expected Illuminate import, got: {result}"


# ---------------------------------------------------------------------------
# Entry point detection
# ---------------------------------------------------------------------------


class TestEntryPointDetection:
    def test_get_superglobal(self):
        source = '$name = $_GET["name"];'
        results = plugin.detect_entry_points(_tree(source), FILE)
        http = [r for r in results if r.kind == "http_input"]
        assert http, f"$_GET should be detected as http_input, got: {results}"

    def test_post_superglobal(self):
        source = '$data = $_POST["data"];'
        results = plugin.detect_entry_points(_tree(source), FILE)
        http = [r for r in results if r.kind == "http_input"]
        assert http, "$_POST should be detected as http_input"

    def test_request_superglobal(self):
        source = '$val = $_REQUEST["val"];'
        results = plugin.detect_entry_points(_tree(source), FILE)
        http = [r for r in results if r.kind == "http_input"]
        assert http, "$_REQUEST should be detected as http_input"

    def test_getenv(self):
        source = '$key = getenv("API_KEY");'
        results = plugin.detect_entry_points(_tree(source), FILE)
        env = [r for r in results if r.kind == "env_var"]
        assert env, "getenv() should be detected as env_var"

    def test_file_get_contents_entry(self):
        source = '$content = file_get_contents("/etc/passwd");'
        results = plugin.detect_entry_points(_tree(source), FILE)
        file_reads = [r for r in results if r.kind == "file_read"]
        assert file_reads, "file_get_contents() should be detected as file_read entry point"


# ---------------------------------------------------------------------------
# Sink detection
# ---------------------------------------------------------------------------


class TestSinkDetection:
    def test_eval(self):
        source = "eval($code);"
        results = plugin.detect_sinks(_tree(source), FILE)
        eval_sinks = [r for r in results if r.kind == "eval" and r.name == "eval"]
        assert eval_sinks, f"eval() should be detected as eval sink, got: {results}"

    def test_system(self):
        source = "system($cmd);"
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert cmd_sinks, "system() should be detected as command sink"

    def test_exec(self):
        source = "exec($cmd, $output);"
        results = plugin.detect_sinks(_tree(source), FILE)
        cmd_sinks = [r for r in results if r.kind == "command"]
        assert cmd_sinks, "exec() should be detected as command sink"

    def test_mysql_query(self):
        source = "mysql_query($sql);"
        results = plugin.detect_sinks(_tree(source), FILE)
        sql_sinks = [r for r in results if r.kind == "sql"]
        assert sql_sinks, "mysql_query() should be detected as sql sink"

    def test_echo_statement(self):
        source = "echo $user_input;"
        results = plugin.detect_sinks(_tree(source), FILE)
        xss_sinks = [r for r in results if r.kind == "xss"]
        assert xss_sinks, "echo should be detected as xss sink"

    def test_unserialize(self):
        source = "unserialize($data);"
        results = plugin.detect_sinks(_tree(source), FILE)
        # unserialize maps to kind="eval" with cwe_id=502
        found = [r for r in results if r.name == "unserialize"]
        assert found, f"unserialize() should be detected as a sink, got: {results}"
        assert found[0].cwe_id == 502

    def test_file_put_contents(self):
        source = 'file_put_contents("/tmp/out.txt", $data);'
        results = plugin.detect_sinks(_tree(source), FILE)
        fw = [r for r in results if r.kind == "file_write"]
        assert fw, "file_put_contents() should be detected as file_write sink"

    def test_header(self):
        source = 'header("Location: " . $url);'
        results = plugin.detect_sinks(_tree(source), FILE)
        hdr = [r for r in results if r.kind == "header"]
        assert hdr, "header() should be detected as header sink"


# ---------------------------------------------------------------------------
# Sanitizer detection
# ---------------------------------------------------------------------------


class TestSanitizerDetection:
    def test_htmlspecialchars(self):
        source = "$safe = htmlspecialchars($input);"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        html = [r for r in results if r.kind == "html_escape"]
        assert html, "htmlspecialchars should be detected as html_escape sanitizer"

    def test_htmlentities(self):
        source = "$safe = htmlentities($input);"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        html = [r for r in results if r.kind == "html_escape"]
        assert html, "htmlentities should be detected as html_escape sanitizer"

    def test_escapeshellarg(self):
        source = "$safe = escapeshellarg($arg);"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        shell = [r for r in results if r.kind == "shell_quote"]
        assert shell, "escapeshellarg should be detected as shell_quote sanitizer"

    def test_intval(self):
        source = "$id = intval($input);"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        casts = [r for r in results if r.kind == "type_cast"]
        assert casts, "intval should be detected as type_cast sanitizer"

    def test_urlencode(self):
        source = "$encoded = urlencode($input);"
        results = plugin.detect_sanitizers(_tree(source), FILE)
        url = [r for r in results if r.kind == "url_encode"]
        assert url, "urlencode should be detected as url_encode sanitizer"


# ---------------------------------------------------------------------------
# Pattern detection (rules SC101-SC106)
# ---------------------------------------------------------------------------


class TestPatternDetection:
    def test_system_detected(self):
        source = 'system("ls -la");'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC101"]
        assert matches, "system() should trigger SC101"

    def test_exec_detected(self):
        source = "exec($cmd);"
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC101"]
        assert matches, "exec() should trigger SC101"

    def test_eval_detected(self):
        source = "eval($code);"
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC102"]
        assert matches, "eval() should trigger SC102"

    def test_mysql_query_detected(self):
        source = "mysql_query($sql);"
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC103"]
        assert matches, "mysql_query() should trigger SC103"

    def test_mysql_query_literal_safe(self):
        """mysql_query with a literal string should NOT be flagged."""
        source = 'mysql_query("SELECT 1 FROM users");'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC103"]
        assert not matches, "mysql_query with literal SQL should not trigger SC103"

    def test_unserialize_detected(self):
        source = "unserialize($data);"
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC104"]
        assert matches, "unserialize() should trigger SC104"

    def test_echo_variable_detected(self):
        source = "echo $user_input;"
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC105"]
        assert matches, "echo $var should trigger SC105"

    def test_echo_string_literal_safe(self):
        source = 'echo "Hello World";'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC105"]
        assert not matches, "echo with string literal only should NOT trigger SC105"

    def test_hardcoded_password(self):
        source = '$password = "supersecret123";'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC106"]
        assert matches, "hardcoded $password should trigger SC106"

    def test_hardcoded_apikey(self):
        source = '$api_key = "sk-abc12345";'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC106"]
        assert matches, "hardcoded $api_key should trigger SC106"

    def test_hardcoded_short_value_ignored(self):
        source = '$password = "ab";'
        findings = plugin.check_patterns(_tree(source), FILE)
        matches = [f for f in findings if f.rule_id == "SC106"]
        assert not matches, "Very short string should not trigger SC106 (likely placeholder)"


# ---------------------------------------------------------------------------
# Call graph: collect_definitions
# ---------------------------------------------------------------------------


class TestCollectDefinitions:
    def test_function_definition(self):
        source = "function greet($name) { return $name; }"
        tree = _tree(source)
        defs = plugin.collect_definitions([(Path("test.php"), tree)])
        assert any("greet" in k for k in defs), f"greet should be in defs, got: {list(defs.keys())}"

    def test_function_params_extracted(self):
        source = "function add($a, $b) { return $a + $b; }"
        tree = _tree(source)
        defs = plugin.collect_definitions([(Path("test.php"), tree)])
        add_def = defs.get("add") or defs.get("test.add")
        assert add_def is not None, f"add() not found in defs: {list(defs.keys())}"
        assert "$a" in add_def.params or "a" in str(add_def.params)

    def test_class_method(self):
        source = dedent("""\
            class Foo {
                public function bar($x) { return $x; }
            }
        """)
        tree = _tree(source)
        defs = plugin.collect_definitions([(Path("test.php"), tree)])
        assert any("Foo" in k and "bar" in k for k in defs), (
            f"Foo.bar should appear in defs, got: {list(defs.keys())}"
        )

    def test_multiple_files(self):
        src_a = _tree("function alpha($x) { return $x; }")
        src_b = _tree("function beta($y) { return $y; }")
        defs = plugin.collect_definitions([
            (Path("a.php"), src_a),
            (Path("b.php"), src_b),
        ])
        assert any("alpha" in k for k in defs)
        assert any("beta" in k for k in defs)


# ---------------------------------------------------------------------------
# Call graph: collect_call_sites
# ---------------------------------------------------------------------------


class TestCollectCallSites:
    def test_simple_call(self):
        source = "greet($name);"
        tree = _tree(source)
        sites = plugin.collect_call_sites([(Path("test.php"), tree)])
        assert any(s.target == "greet" for s in sites), (
            f"greet() call site not found: {[(s.target, s.args) for s in sites]}"
        )

    def test_call_with_args(self):
        source = "system($cmd);"
        tree = _tree(source)
        sites = plugin.collect_call_sites([(Path("test.php"), tree)])
        system_sites = [s for s in sites if s.target == "system"]
        assert system_sites
        assert system_sites[0].args  # should have at least one arg

    def test_call_inside_function(self):
        source = dedent("""\
            function wrapper($x) {
                return system($x);
            }
        """)
        tree = _tree(source)
        sites = plugin.collect_call_sites([(Path("test.php"), tree)])
        system_calls = [s for s in sites if s.target == "system"]
        assert system_calls
        assert system_calls[0].caller == "wrapper"


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------


class TestFrameworkDetection:
    def test_laravel_detected(self):
        from sanicode.scanner.imports import ImportInfo

        imports = [
            ImportInfo(
                module=r"Illuminate\Http\Request",
                names=["Request"],
                aliases={},
                file=FILE,
                line=1,
                is_from=True,
            )
        ]
        frameworks = plugin.detect_frameworks(imports)
        names = [fw.name for fw in frameworks]
        assert "laravel" in names, f"Laravel not detected from Illuminate import, got: {names}"

    def test_symfony_detected(self):
        from sanicode.scanner.imports import ImportInfo

        imports = [
            ImportInfo(
                module=r"Symfony\Component\HttpFoundation\Response",
                names=["Response"],
                aliases={},
                file=FILE,
                line=1,
                is_from=True,
            )
        ]
        frameworks = plugin.detect_frameworks(imports)
        names = [fw.name for fw in frameworks]
        assert "symfony" in names, f"Symfony not detected, got: {names}"

    def test_no_frameworks(self):
        from sanicode.scanner.imports import ImportInfo

        imports = [
            ImportInfo(
                module="config.php",
                names=[],
                aliases={},
                file=FILE,
                line=1,
                is_from=False,
            )
        ]
        frameworks = plugin.detect_frameworks(imports)
        assert frameworks == []
