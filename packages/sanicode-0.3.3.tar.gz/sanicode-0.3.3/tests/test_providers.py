"""Tests for the LLM provider registry in sanicode.llm.providers."""

from __future__ import annotations

import pytest

from sanicode.llm.providers import (
    PROVIDER_REGISTRY,
    ProviderInfo,
    cloud_providers,
    get_provider,
    list_providers,
    self_hosted_providers,
)

_VALID_TIERS = {"fast", "analysis", "reasoning"}


# ---------------------------------------------------------------------------
# Registry-wide invariants
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("name,info", list(PROVIDER_REGISTRY.items()))
class TestRegistryEntryConsistency:
    """Each entry in PROVIDER_REGISTRY must satisfy basic structural invariants."""

    def test_name_is_nonempty(self, name: str, info: ProviderInfo) -> None:
        assert info.name, f"provider '{name}': name is empty"

    def test_display_name_is_nonempty(self, name: str, info: ProviderInfo) -> None:
        assert info.display_name, f"provider '{name}': display_name is empty"

    def test_litellm_prefix_is_nonempty(self, name: str, info: ProviderInfo) -> None:
        assert info.litellm_prefix, f"provider '{name}': litellm_prefix is empty"

    def test_name_matches_dict_key(self, name: str, info: ProviderInfo) -> None:
        assert info.name == name, (
            f"registry key '{name}' does not match info.name '{info.name}'"
        )


# ---------------------------------------------------------------------------
# Self-hosted providers: endpoint_hint must be present
# ---------------------------------------------------------------------------


_SELF_HOSTED = [
    pytest.param(info, id=info.name)
    for info in PROVIDER_REGISTRY.values()
    if info.requires_endpoint
]


@pytest.mark.parametrize("info", _SELF_HOSTED)
def test_requires_endpoint_has_endpoint_hint(info: ProviderInfo) -> None:
    assert info.endpoint_hint, (
        f"provider '{info.name}' requires_endpoint=True but endpoint_hint is empty"
    )


# ---------------------------------------------------------------------------
# Cloud providers: auth_env_vars must be populated
# ---------------------------------------------------------------------------


_CLOUD = [
    pytest.param(info, id=info.name)
    for info in PROVIDER_REGISTRY.values()
    if info.needs_api_key
]


@pytest.mark.parametrize("info", _CLOUD)
def test_needs_api_key_has_auth_env_vars(info: ProviderInfo) -> None:
    assert len(info.auth_env_vars) >= 1, (
        f"provider '{info.name}' needs_api_key=True but auth_env_vars is empty"
    )


# ---------------------------------------------------------------------------
# get_provider()
# ---------------------------------------------------------------------------


def test_get_provider_known() -> None:
    result = get_provider("anthropic")
    assert result is not None
    assert isinstance(result, ProviderInfo)
    assert result.name == "anthropic"


def test_get_provider_unknown() -> None:
    assert get_provider("nonexistent_provider_xyz") is None


# ---------------------------------------------------------------------------
# cloud_providers() and self_hosted_providers()
# ---------------------------------------------------------------------------


def test_cloud_providers_no_endpoint_required() -> None:
    for info in cloud_providers():
        assert not info.requires_endpoint, (
            f"cloud provider '{info.name}' has requires_endpoint=True"
        )


def test_self_hosted_providers_require_endpoint() -> None:
    for info in self_hosted_providers():
        assert info.requires_endpoint, (
            f"self-hosted provider '{info.name}' has requires_endpoint=False"
        )


def test_cloud_and_self_hosted_cover_all() -> None:
    assert len(cloud_providers()) + len(self_hosted_providers()) == len(PROVIDER_REGISTRY)


# ---------------------------------------------------------------------------
# list_providers()
# ---------------------------------------------------------------------------


def test_list_providers_returns_all() -> None:
    assert len(list_providers()) == len(PROVIDER_REGISTRY)


# ---------------------------------------------------------------------------
# TierSuggestion validity
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("name,info", list(PROVIDER_REGISTRY.items()))
def test_suggestions_have_valid_tiers(name: str, info: ProviderInfo) -> None:
    for suggestion in info.suggestions:
        assert suggestion.tier in _VALID_TIERS, (
            f"provider '{name}': suggestion has invalid tier '{suggestion.tier}'"
        )
        assert suggestion.model, (
            f"provider '{name}': suggestion for tier '{suggestion.tier}' has empty model"
        )
