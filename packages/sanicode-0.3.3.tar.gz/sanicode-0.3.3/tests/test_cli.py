"""Smoke tests for the Sanicode CLI.

Verifies that the CLI surface is importable and each subcommand's help
text is accessible. These tests do not exercise actual scan logic.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from sanicode import __version__
from sanicode.cli import app

runner = CliRunner()


def test_help() -> None:
    """--help should exit 0 and mention the tool name."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0, result.output
    assert "sanicode" in result.output.lower()


def test_version() -> None:
    """--version should print the current version string."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0, result.output
    assert __version__ in result.output


@pytest.mark.parametrize(
    "subcommand",
    ["config", "scan", "report", "recommend", "graph", "serve"],
)
def test_subcommand_help(subcommand: str) -> None:
    """Each subcommand should respond to --help without error."""
    result = runner.invoke(app, [subcommand, "--help"])
    assert result.exit_code == 0, (
        f"'{subcommand} --help' exited with {result.exit_code}:\n{result.output}"
    )
    assert subcommand in result.output.lower()


# ---------------------------------------------------------------------------
# scan integration tests
# ---------------------------------------------------------------------------


def test_scan_detects_findings(tmp_path) -> None:
    """Scan a directory with known-bad code and verify findings appear in output."""
    bad_file = tmp_path / "bad.py"
    bad_file.write_text("eval(input())\n", encoding="utf-8")

    result = runner.invoke(app, ["scan", str(tmp_path)])
    assert result.exit_code == 0, (
        f"Unexpected exit code: {result.exit_code}\n{result.output}"
    )
    assert "Knowledge Graph" in result.output, (
        f"Expected 'Knowledge Graph' in output:\n{result.output}"
    )
    assert "SC001" in result.output, (
        f"Expected 'SC001' in output:\n{result.output}"
    )


def test_scan_nonexistent_path() -> None:
    """Scanning a path that does not exist should exit with code 1."""
    result = runner.invoke(app, ["scan", "/nonexistent/path/xyz"])
    assert result.exit_code == 1, (
        f"Expected exit code 1, got {result.exit_code}:\n{result.output}"
    )
    assert "does not exist" in result.output, (
        f"Expected 'does not exist' in output:\n{result.output}"
    )


def test_scan_clean_code_no_findings(tmp_path) -> None:
    """Scanning code with no bad patterns should report 0 findings."""
    clean_file = tmp_path / "clean.py"
    clean_file.write_text("x = 1 + 2\n", encoding="utf-8")

    result = runner.invoke(app, ["scan", str(tmp_path)])
    assert result.exit_code == 0, (
        f"Unexpected exit code: {result.exit_code}\n{result.output}"
    )
    assert "Findings:" in result.output, (
        f"Expected 'Findings:' in output:\n{result.output}"
    )
    # The count line reads "Findings: 0" (with possible Rich markup spacing).
    assert "0" in result.output, (
        f"Expected '0' findings count in output:\n{result.output}"
    )


# ---------------------------------------------------------------------------
# --fail-on flag tests
# ---------------------------------------------------------------------------


def test_scan_fail_on_triggers_exit_code_1(tmp_path) -> None:
    """--fail-on=high exits 1 when a high/critical finding is present."""
    bad_file = tmp_path / "bad.py"
    bad_file.write_text("eval(input())\n", encoding="utf-8")

    result = runner.invoke(app, ["scan", str(tmp_path), "--fail-on", "high"])
    assert result.exit_code == 1, (
        f"Expected exit code 1 with --fail-on=high and a high finding present:\n{result.output}"
    )
    assert "FAIL" in result.output, (
        f"Expected 'FAIL' in output:\n{result.output}"
    )


def test_scan_fail_on_no_breach(tmp_path) -> None:
    """--fail-on=critical exits 0 when only medium/low findings are present."""
    # SC001 (eval) is typically 'high', so --fail-on=critical should not trigger.
    bad_file = tmp_path / "bad.py"
    bad_file.write_text("eval(input())\n", encoding="utf-8")

    result = runner.invoke(app, ["scan", str(tmp_path), "--fail-on", "critical"])
    # This should succeed unless eval findings are classified as critical.
    # The test is parameterised by the actual severity returned; we accept 0 or 1
    # but check that an invalid-severity error was NOT the cause of any failure.
    assert "Invalid --fail-on severity" not in result.output, (
        f"Got invalid-severity error for 'critical':\n{result.output}"
    )


def test_scan_fail_on_invalid_severity(tmp_path) -> None:
    """--fail-on with an unrecognised severity string exits 1 with an error message."""
    clean_file = tmp_path / "clean.py"
    clean_file.write_text("x = 1\n", encoding="utf-8")

    result = runner.invoke(app, ["scan", str(tmp_path), "--fail-on", "bogus"])
    assert result.exit_code == 1, (
        f"Expected exit code 1 for invalid severity 'bogus':\n{result.output}"
    )
    assert "Invalid --fail-on severity" in result.output, (
        f"Expected error message in output:\n{result.output}"
    )


# ---------------------------------------------------------------------------
# action.yml validation
# ---------------------------------------------------------------------------


def test_action_yml_is_valid() -> None:
    """The GitHub Action manifest should be valid YAML with required fields."""
    action_path = Path(__file__).parent.parent / "action.yml"
    if not action_path.exists():
        pytest.skip("action.yml not found")
    with open(action_path) as f:
        data = yaml.safe_load(f)
    assert data["name"] == "Sanicode Security Scan"
    assert "inputs" in data
    assert "runs" in data


# ---------------------------------------------------------------------------
# pre-commit hooks manifest tests
# ---------------------------------------------------------------------------


def test_pre_commit_hooks_yaml_is_valid() -> None:
    """The pre-commit hooks manifest should be valid YAML with required fields."""
    hooks_path = Path(__file__).parent.parent / ".pre-commit-hooks.yaml"
    if not hooks_path.exists():
        pytest.skip(".pre-commit-hooks.yaml not found")
    with open(hooks_path) as f:
        data = yaml.safe_load(f)
    assert isinstance(data, list), (
        f"Expected a YAML list at top level, got {type(data).__name__}"
    )
    assert len(data) >= 1, "Expected at least one hook definition"
    hook = data[0]
    assert hook["id"] == "sanicode", (
        f"Expected hook id 'sanicode', got {hook.get('id')!r}"
    )
    assert hook["language"] == "python", (
        f"Expected language 'python', got {hook.get('language')!r}"
    )
    assert "entry" in hook, "Hook must define an 'entry' field"
