"""Tests for the graph HTML visualizer (src/sanicode/graph/visualize.py)."""

from __future__ import annotations

import json
import re

from sanicode.graph.visualize import generate_html

# ---------------------------------------------------------------------------
# Test data helpers
# ---------------------------------------------------------------------------


def _sample_graph() -> dict:
    """Return a realistic node-link graph dict with four nodes and two edges."""
    return {
        "directed": True,
        "multigraph": False,
        "graph": {"frameworks": []},
        "nodes": [
            {
                "id": "entry_1",
                "kind": "entry_point",
                "label": "request_handler",
                "file": "/path/to/file.py",
                "line": 42,
            },
            {
                "id": "sink_2",
                "kind": "sink",
                "label": "db_query",
                "file": "/path/to/db.py",
                "line": 17,
                "cwe_id": 89,
            },
            {
                "id": "sanitizer_3",
                "kind": "sanitizer",
                "label": "html.escape",
                "file": "/path/to/template.py",
                "line": 5,
            },
            {
                "id": "import_4",
                "kind": "import",
                "label": "os",
                "file": "/path/to/app.py",
                "line": 1,
            },
        ],
        "links": [
            {
                "source": "entry_1",
                "target": "sanitizer_3",
                "confidence": "heuristic",
                "kind": "data_flow",
            },
            {
                "source": "sanitizer_3",
                "target": "sink_2",
                "confidence": "call_graph",
                "kind": "data_flow",
            },
        ],
    }


def _empty_graph() -> dict:
    return {"directed": True, "multigraph": False, "graph": {}, "nodes": [], "links": []}


# ---------------------------------------------------------------------------
# Helper: extract the embedded graphData JSON from the HTML output
# ---------------------------------------------------------------------------


def _extract_graph_json(html: str) -> dict:
    """Parse the ``const graphData = ...;`` block out of the HTML and return it as a dict."""
    match = re.search(r"const graphData = (.*?);\n", html, re.DOTALL)
    assert match, "Could not find 'const graphData = ...' in HTML output"
    return json.loads(match.group(1))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestGenerateHtml:
    def test_returns_valid_html(self) -> None:
        html = generate_html(_sample_graph())
        assert html.startswith("<!DOCTYPE html>"), (
            f"Expected output to start with '<!DOCTYPE html>', got: {html[:50]!r}"
        )
        assert html.rstrip().endswith("</html>"), (
            f"Expected output to end with '</html>', got: {html[-50:]!r}"
        )
        assert "<title>" in html and "Sanicode" in html, (
            "Expected <title> element containing 'Sanicode' in HTML output"
        )

    def test_cytoscape_cdn_loaded(self) -> None:
        html = generate_html(_sample_graph())
        for fragment in ("cytoscape", "dagre.min.js", "cytoscape-dagre.js"):
            assert fragment in html, (
                f"Expected CDN reference to '{fragment}' in HTML <script> tags"
            )

    def test_graph_data_embedded(self) -> None:
        graph = _sample_graph()
        html = generate_html(graph)
        for node in graph["nodes"]:
            assert node["id"] in html, (
                f"Expected node id {node['id']!r} to appear in embedded HTML JSON"
            )

    def test_filter_checkboxes_present(self) -> None:
        html = generate_html(_sample_graph())
        for kind in ("entry_point", "sink", "sanitizer", "import"):
            expected_id = f'id="chk-{kind}"'
            assert expected_id in html, (
                f"Expected filter checkbox with {expected_id!r} in HTML"
            )

    def test_import_checkbox_unchecked_by_default(self) -> None:
        html = generate_html(_sample_graph())

        # Find the import checkbox element — look for the input tag that has chk-import
        import_input_match = re.search(r'<input[^>]*id="chk-import"[^>]*>', html)
        assert import_input_match, "Could not find <input> with id='chk-import' in HTML"
        import_tag = import_input_match.group(0)
        assert "checked" not in import_tag, (
            f"Import checkbox should NOT have 'checked' attribute by default; got: {import_tag!r}"
        )

        # The other three kinds should all be checked
        for kind in ("entry_point", "sink", "sanitizer"):
            match = re.search(rf'<input[^>]*id="chk-{kind}"[^>]*>', html)
            assert match, f"Could not find <input> with id='chk-{kind}' in HTML"
            tag = match.group(0)
            assert "checked" in tag, (
                f"Checkbox for '{kind}' should have 'checked' attribute; got: {tag!r}"
            )

    def test_stats_elements_present(self) -> None:
        html = generate_html(_sample_graph())
        element_ids = (
            "stat-nodes", "stat-edges", "stat-entry",
            "stat-sinks", "stat-sanitizers"
        )
        for element_id in element_ids:
            assert f'id="{element_id}"' in html, (
                f"Expected element with id='{element_id}' in HTML stats bar"
            )

    def test_empty_graph_no_crash(self) -> None:
        html = generate_html(_empty_graph())
        assert html.startswith("<!DOCTYPE html>"), (
            "generate_html(_empty_graph()) should return valid HTML without crashing"
        )
        assert html.rstrip().endswith("</html>")

    def test_node_data_round_trips_through_json(self) -> None:
        html = generate_html(_sample_graph())
        data = _extract_graph_json(html)

        nodes_by_id = {n["id"]: n for n in data.get("nodes", [])}
        assert "sink_2" in nodes_by_id, (
            f"Expected node 'sink_2' in embedded graphData.nodes; got ids: {list(nodes_by_id)}"
        )
        sink = nodes_by_id["sink_2"]
        assert sink.get("cwe_id") == 89, (
            f"Expected cwe_id=89 on embedded sink_2 node, got: {sink.get('cwe_id')!r}"
        )

    def test_sidebar_elements_present(self) -> None:
        html = generate_html(_sample_graph())
        for element_id in ("sidebar", "sidebar-title", "sidebar-content", "sidebar-close"):
            assert f'id="{element_id}"' in html, (
                f"Expected element with id='{element_id}' in HTML sidebar"
            )
