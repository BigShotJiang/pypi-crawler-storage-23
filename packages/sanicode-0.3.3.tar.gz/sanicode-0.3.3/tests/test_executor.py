"""Tests for the scan pipeline executor."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from sanicode.compliance.enrichment import EnrichedFinding
from sanicode.compliance.mapper import ComplianceMapping
from sanicode.config import SanicodeConfig
from sanicode.graph.builder import KnowledgeGraph
from sanicode.llm.client import LLMClient, LLMResponse
from sanicode.scanner.executor import (
    ScanOutput,
    _build_compliance_context,
    _build_data_flow_context,
    _llm_analyze_data_flow,
    _llm_reason_compliance,
    collect_files,
    run_scan,
)


class TestCollectFiles:
    """Tests for collect_files()."""

    def test_finds_python_files(self, tmp_path: Path) -> None:
        (tmp_path / "a.py").write_text("x = 1\n", encoding="utf-8")
        (tmp_path / "b.py").write_text("y = 2\n", encoding="utf-8")
        (tmp_path / "readme.md").write_text("# Hi\n", encoding="utf-8")

        cfg = SanicodeConfig()
        files = collect_files(tmp_path, cfg)
        names = [f.name for f in files]
        assert "a.py" in names
        assert "b.py" in names
        assert "readme.md" not in names

    def test_respects_exclude_patterns(self, tmp_path: Path) -> None:
        sub = tmp_path / "vendor"
        sub.mkdir()
        (sub / "lib.py").write_text("pass\n", encoding="utf-8")
        (tmp_path / "main.py").write_text("pass\n", encoding="utf-8")

        cfg = SanicodeConfig()
        cfg.scan.exclude_patterns = ["vendor/**"]
        files = collect_files(tmp_path, cfg)
        names = [f.name for f in files]
        assert "main.py" in names
        assert "lib.py" not in names

    def test_respects_max_file_size(self, tmp_path: Path) -> None:
        small = tmp_path / "small.py"
        small.write_text("x = 1\n", encoding="utf-8")
        big = tmp_path / "big.py"
        big.write_text("x = 1\n" * 100_000, encoding="utf-8")

        cfg = SanicodeConfig()
        cfg.scan.max_file_size_kb = 1  # 1 KB
        files = collect_files(tmp_path, cfg)
        names = [f.name for f in files]
        assert "small.py" in names
        assert "big.py" not in names


class TestRunScan:
    """Tests for run_scan()."""

    def test_detects_findings(self, tmp_path: Path) -> None:
        (tmp_path / "bad.py").write_text("eval(input())\n", encoding="utf-8")
        cfg = SanicodeConfig()
        output = run_scan(tmp_path, cfg)

        assert isinstance(output, ScanOutput)
        assert output.file_count == 1
        assert len(output.enriched_findings) > 0
        assert output.enriched_findings[0].rule_id == "SC001"

    def test_clean_code_no_findings(self, tmp_path: Path) -> None:
        (tmp_path / "clean.py").write_text("x = 1 + 2\n", encoding="utf-8")
        cfg = SanicodeConfig()
        output = run_scan(tmp_path, cfg)

        assert output.file_count == 1
        assert len(output.enriched_findings) == 0

    def test_nonexistent_path_raises(self) -> None:
        cfg = SanicodeConfig()
        with pytest.raises(FileNotFoundError):
            run_scan(Path("/nonexistent/xyz"), cfg)

    def test_parse_errors_collected(self, tmp_path: Path) -> None:
        (tmp_path / "bad_syntax.py").write_text("def (\n", encoding="utf-8")
        (tmp_path / "good.py").write_text("x = 1\n", encoding="utf-8")
        cfg = SanicodeConfig()
        output = run_scan(tmp_path, cfg)

        assert len(output.parse_errors) == 1
        assert "bad_syntax.py" in output.parse_errors[0]
        assert output.file_count == 1  # Only good.py parsed

    def test_graph_data_populated(self, tmp_path: Path) -> None:
        (tmp_path / "app.py").write_text("eval(input())\n", encoding="utf-8")
        cfg = SanicodeConfig()
        output = run_scan(tmp_path, cfg)

        assert isinstance(output.graph_data, dict)
        assert "nodes" in output.graph_data

    def test_scan_result_has_summary(self, tmp_path: Path) -> None:
        (tmp_path / "app.py").write_text("eval(input())\n", encoding="utf-8")
        cfg = SanicodeConfig()
        output = run_scan(tmp_path, cfg)

        assert output.result.summary["total_findings"] > 0
        from sanicode.version import __version__

        assert output.result.sanicode_version == __version__


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_finding(
    file: Path,
    line: int = 10,
    rule_id: str = "SC001",
    severity: str = "high",
    cwe_id: int = 94,
    derived_severity: str = "high",
    remediation: str = "",
) -> EnrichedFinding:
    """Build a minimal EnrichedFinding for testing."""
    mapping = ComplianceMapping(
        cwe_id=cwe_id,
        cwe_name="Code Injection",
        owasp_asvs=[{"id": "v5.0.0-V1-5.2.4", "title": "Code eval", "level": "L1"}],
        nist_800_53=["SI-10"],
        asd_stig=[{"id": "APSC-DV-002510", "cat": "CAT I", "title": "Cmd injection"}],
        pci_dss=["6.2.4"],
        asvs_level="L1",
        stig_category="CAT I",
        remediation="Avoid eval.",
    )
    return EnrichedFinding(
        file=file,
        line=line,
        column=0,
        rule_id=rule_id,
        message=f"Dangerous use of {rule_id}",
        severity=severity,  # type: ignore[arg-type]
        cwe_id=cwe_id,
        cwe_name="Code Injection",
        compliance=mapping,
        derived_severity=derived_severity,
        remediation=remediation,
    )


def _make_llm(tier: str, response_content: str) -> LLMClient:
    """Return an LLMClient mock that answers with *response_content* for *tier*."""
    resp = LLMResponse(content=response_content, model="mock", tier=tier, usage={})
    llm = MagicMock(spec=LLMClient)
    llm.has_tier.side_effect = lambda t: t == tier
    if tier == "analysis":
        llm.analyze.return_value = resp
    elif tier == "reasoning":
        llm.reason.return_value = resp
    return llm


# ---------------------------------------------------------------------------
# _llm_analyze_data_flow tests
# ---------------------------------------------------------------------------

class TestLLMAnalyzeDataFlow:
    """Tests for _llm_analyze_data_flow()."""

    def test_skips_without_tier(self, tmp_path: Path) -> None:
        """Returns findings unchanged when analysis tier is not configured."""
        finding = _make_finding(tmp_path / "app.py", derived_severity="high")
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.return_value = False
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        llm.analyze.assert_not_called()
        assert result == [finding]
        assert result[0].derived_severity == "high"

    def test_confirmed_assessment_keeps_severity(self, tmp_path: Path) -> None:
        """A 'confirmed' LLM assessment does not change severity."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="high")
        payload = json.dumps({"assessment": "confirmed", "confidence": 0.9, "reasoning": "direct"})
        llm = _make_llm("analysis", payload)
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert result[0].derived_severity == "high"

    def test_mitigated_high_confidence_downgrades_severity(self, tmp_path: Path) -> None:
        """A 'mitigated' response with confidence >= 0.7 reduces derived_severity."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="high")
        payload = json.dumps(
            {"assessment": "mitigated", "confidence": 0.85, "reasoning": "sanitized"}
        )
        llm = _make_llm("analysis", payload)
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert result[0].derived_severity == "medium", (
            f"Expected 'medium' after downgrade, got {result[0].derived_severity!r}"
        )

    def test_mitigated_low_confidence_keeps_severity(self, tmp_path: Path) -> None:
        """A 'mitigated' response with confidence < 0.7 does not downgrade."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical")
        payload = json.dumps(
            {"assessment": "mitigated", "confidence": 0.5, "reasoning": "uncertain"}
        )
        llm = _make_llm("analysis", payload)
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert result[0].derived_severity == "critical"

    def test_llm_error_keeps_finding(self, tmp_path: Path) -> None:
        """A failure in the LLM call retains the finding unchanged."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical")
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.side_effect = lambda t: t == "analysis"
        llm.analyze.side_effect = RuntimeError("connection refused")
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert len(result) == 1
        assert result[0].derived_severity == "critical"

    def test_invalid_json_keeps_finding(self, tmp_path: Path) -> None:
        """Non-JSON LLM response retains the finding unchanged."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="high")
        resp = LLMResponse(content="sorry, I cannot help", model="mock", tier="analysis", usage={})
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.side_effect = lambda t: t == "analysis"
        llm.analyze.return_value = resp
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert result[0].derived_severity == "high"

    def test_review_assessment_keeps_severity(self, tmp_path: Path) -> None:
        """A 'review' assessment leaves severity unchanged."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical")
        payload = json.dumps({"assessment": "review", "confidence": 0.6, "reasoning": "unclear"})
        llm = _make_llm("analysis", payload)
        kg = KnowledgeGraph()

        result = _llm_analyze_data_flow(llm, [finding], kg)

        assert result[0].derived_severity == "critical"


# ---------------------------------------------------------------------------
# _llm_reason_compliance tests
# ---------------------------------------------------------------------------

class TestLLMReasonCompliance:
    """Tests for _llm_reason_compliance()."""

    def test_skips_without_tier(self, tmp_path: Path) -> None:
        """Returns findings unchanged when reasoning tier is not configured."""
        finding = _make_finding(tmp_path / "app.py", derived_severity="critical")
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.return_value = False
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        llm.reason.assert_not_called()
        assert result == [finding]

    def test_skips_low_severity_findings(self, tmp_path: Path) -> None:
        """Findings with severity 'medium' or below are not sent to the reasoning tier."""
        f = tmp_path / "app.py"
        f.write_text("x = 1\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="medium")
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.side_effect = lambda t: t == "reasoning"
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        llm.reason.assert_not_called()
        assert result[0].derived_severity == "medium"

    def test_populates_remediation_for_high_severity(self, tmp_path: Path) -> None:
        """Reasoning LLM output is written into finding.remediation."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="high", remediation="")
        payload = json.dumps({
            "cwe_valid": True,
            "additional_controls": ["NIST AC-4"],
            "remediation": "Replace eval() with ast.literal_eval() for safe parsing.",
        })
        llm = _make_llm("reasoning", payload)
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        expected = "Replace eval() with ast.literal_eval() for safe parsing."
        assert result[0].remediation == expected, (
            f"Expected LLM remediation text, got {result[0].remediation!r}"
        )

    def test_populates_remediation_for_critical_severity(self, tmp_path: Path) -> None:
        """Critical findings also receive LLM remediation guidance."""
        f = tmp_path / "app.py"
        f.write_text("os.system(user_input)\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical", remediation="")
        payload = json.dumps({
            "cwe_valid": True,
            "additional_controls": [],
            "remediation": "Use subprocess.run with a list of arguments, never a shell string.",
        })
        llm = _make_llm("reasoning", payload)
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        assert "subprocess" in result[0].remediation

    def test_empty_remediation_not_overwritten(self, tmp_path: Path) -> None:
        """An empty LLM remediation does not blank out existing text."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical", remediation="Existing advice.")
        payload = json.dumps({"cwe_valid": True, "additional_controls": [], "remediation": ""})
        llm = _make_llm("reasoning", payload)
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        assert result[0].remediation == "Existing advice."

    def test_llm_error_keeps_finding(self, tmp_path: Path) -> None:
        """A failure in the reasoning LLM call retains the finding unchanged."""
        f = tmp_path / "app.py"
        f.write_text("eval(input())\n", encoding="utf-8")
        finding = _make_finding(f, derived_severity="critical", remediation="Original.")
        llm = MagicMock(spec=LLMClient)
        llm.has_tier.side_effect = lambda t: t == "reasoning"
        llm.reason.side_effect = RuntimeError("timeout")
        kg = KnowledgeGraph()

        result = _llm_reason_compliance(llm, [finding], kg)

        assert len(result) == 1
        assert result[0].remediation == "Original."


# ---------------------------------------------------------------------------
# _build_data_flow_context tests
# ---------------------------------------------------------------------------

class TestBuildDataFlowContext:
    """Tests for _build_data_flow_context()."""

    def test_empty_graph_returns_no_nodes_message(self, tmp_path: Path) -> None:
        finding = _make_finding(tmp_path / "app.py")
        kg = KnowledgeGraph()

        ctx = _build_data_flow_context(finding, kg)

        assert "No data flow nodes" in ctx

    def test_includes_nodes_from_finding_file(self, tmp_path: Path) -> None:
        f = tmp_path / "app.py"
        finding = _make_finding(f)
        kg = KnowledgeGraph()
        kg.add_sink(label="eval", file=f, line=10, cwe_id=94)

        ctx = _build_data_flow_context(finding, kg)

        assert "eval" in ctx
        assert "sink" in ctx

    def test_excludes_nodes_from_other_files(self, tmp_path: Path) -> None:
        f1 = tmp_path / "app.py"
        f2 = tmp_path / "other.py"
        finding = _make_finding(f1)
        kg = KnowledgeGraph()
        kg.add_sink(label="eval", file=f2, line=5, cwe_id=94)

        ctx = _build_data_flow_context(finding, kg)

        assert "No data flow nodes" in ctx


# ---------------------------------------------------------------------------
# _build_compliance_context tests
# ---------------------------------------------------------------------------

class TestBuildComplianceContext:
    """Tests for _build_compliance_context()."""

    def test_no_compliance_mapping(self, tmp_path: Path) -> None:
        finding = _make_finding(tmp_path / "app.py")
        finding.compliance = None

        ctx = _build_compliance_context(finding)

        assert "No compliance mapping" in ctx

    def test_includes_all_frameworks(self, tmp_path: Path) -> None:
        finding = _make_finding(tmp_path / "app.py")

        ctx = _build_compliance_context(finding)

        assert "OWASP ASVS" in ctx
        assert "NIST 800-53" in ctx
        assert "ASD STIG" in ctx
        assert "PCI DSS" in ctx
        assert "CAT I" in ctx
