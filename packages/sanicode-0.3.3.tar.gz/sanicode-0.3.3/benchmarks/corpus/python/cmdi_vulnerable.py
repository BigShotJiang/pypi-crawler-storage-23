"""Command injection test cases — all vulnerable."""
import os
import subprocess


def ping_host(host):
    # Vulnerable: os.system with user input
    os.system(f"ping -c 1 {host}")


def run_command(cmd):
    # Vulnerable: shell=True
    subprocess.call(cmd, shell=True)


def eval_input(data):
    # Vulnerable: eval
    return eval(data)
