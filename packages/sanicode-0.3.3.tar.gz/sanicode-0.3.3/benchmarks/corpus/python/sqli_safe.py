"""SQL injection test cases — all safe (parameterized)."""
import sqlite3


def search_users(name):
    conn = sqlite3.connect("db.sqlite")
    cursor = conn.cursor()
    # Safe: parameterized query
    cursor.execute("SELECT * FROM users WHERE name = ?", (name,))
    return cursor.fetchall()
