#!/usr/bin/env bash
# scaffold.sh — Create the Sanicode project directory structure.
# Idempotent: safe to run multiple times.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Scaffolding Sanicode project at: $REPO_ROOT"

mkdir -p \
  "$REPO_ROOT/src/sanicode/scanner" \
  "$REPO_ROOT/src/sanicode/graph" \
  "$REPO_ROOT/src/sanicode/compliance" \
  "$REPO_ROOT/src/sanicode/llm" \
  "$REPO_ROOT/src/sanicode/report" \
  "$REPO_ROOT/src/sanicode/server" \
  "$REPO_ROOT/data" \
  "$REPO_ROOT/rules" \
  "$REPO_ROOT/prompts" \
  "$REPO_ROOT/tests" \
  "$REPO_ROOT/docs" \
  "$REPO_ROOT/scripts"

echo "Directory structure created successfully."
