"""Scoring harness for evaluating sanicode against ground-truth vulnerability catalogs."""
