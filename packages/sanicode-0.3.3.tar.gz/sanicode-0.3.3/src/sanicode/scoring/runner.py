"""Scoring pipeline orchestrator — scan repos, score, judge, report."""

from __future__ import annotations

import logging
from pathlib import Path

from sanicode.config import SanicodeConfig
from sanicode.llm.client import LLMClient
from sanicode.scoring.ground_truth import GroundTruth, load_ground_truth
from sanicode.scoring.judge import (
    format_findings,
    format_ground_truth_tier1,
    format_ground_truth_tier2,
    format_mechanical_score_tier1,
    format_mechanical_score_tier2,
    judge_repo,
)
from sanicode.scoring.report import RepoScore, ScoringReport
from sanicode.scoring.rubric import score_tier1, score_tier2

_log = logging.getLogger(__name__)


def run_scoring(
    repos_dir: Path,
    scoring_dir: Path,
    output_dir: Path,
    cfg: SanicodeConfig,
    repos_filter: list[str] | None = None,
    skip_llm_judge: bool = False,
) -> ScoringReport:
    """Run the full evaluation pipeline against all repos in the ground truth.

    Scans each repo, applies mechanical scoring, and optionally asks the LLM
    judge for a qualitative assessment. Individual scan failures are logged and
    skipped; a single bad repo does not abort the run.

    Args:
        repos_dir: Root of the unsanitary-code-examples repo clone.
        scoring_dir: Directory containing the ground-truth YAML files.
        output_dir: Destination for saved reports (used by caller, not here).
        cfg: Sanicode configuration (LLM endpoints, scan settings, etc.).
        repos_filter: If set, only score repos/projects whose ID or name
            appears in this list. Comparison is case-sensitive.
        skip_llm_judge: When True, skip the LLM judge step entirely.

    Returns:
        A ScoringReport populated with one RepoScore per processed repo.
    """
    from sanicode.scanner.executor import run_scan

    ground_truth: GroundTruth = load_ground_truth(scoring_dir)
    llm = LLMClient.from_config(cfg)
    report = ScoringReport(repos_dir=str(repos_dir))

    # --- Tier 1: synthetic projects with line-level ground truth ---------------

    for project in ground_truth.synthetic_projects:
        if repos_filter is not None and project.id not in repos_filter:
            continue

        repo_path = repos_dir / project.base_path
        if not repo_path.exists():
            _log.warning("Tier 1 repo path does not exist, skipping: %s", repo_path)
            continue

        _log.info("Scanning Tier 1 project: %s (%s)", project.name, repo_path)

        try:
            scan_output = run_scan(repo_path, cfg)
        except Exception as exc:
            _log.warning("Scan failed for %s: %s", project.name, exc)
            continue

        findings = scan_output.result.findings
        had_scannable_files = scan_output.file_count > 0

        tier1_result = score_tier1(findings, project, repos_dir)

        assessment = None
        if not skip_llm_judge and findings:
            assessment = judge_repo(
                llm,
                project.name,
                format_ground_truth_tier1(project),
                format_findings(findings),
                format_mechanical_score_tier1(tier1_result),
            )

        report.per_repo.append(
            RepoScore(
                name=project.name,
                tier=1,
                had_scannable_files=had_scannable_files,
                findings_count=len(findings),
                tier1_result=tier1_result,
                judge_assessment=assessment,
            )
        )

    # --- Tier 2: real repos with categorical ground truth ----------------------

    for repo in ground_truth.real_repos:
        if not repo.scorable:
            continue

        if repos_filter is not None and repo.name not in repos_filter:
            continue

        repo_path = repos_dir / repo.name
        if not repo_path.exists():
            _log.warning("Tier 2 repo path does not exist, skipping: %s", repo_path)
            continue

        _log.info("Scanning Tier 2 repo: %s (%s)", repo.name, repo_path)

        try:
            scan_output = run_scan(repo_path, cfg)
        except Exception as exc:
            _log.warning("Scan failed for %s: %s", repo.name, exc)
            continue

        findings = scan_output.result.findings
        had_scannable_files = scan_output.file_count > 0

        tier2_result = score_tier2(findings, repo)

        assessment = None
        if not skip_llm_judge and findings:
            assessment = judge_repo(
                llm,
                repo.name,
                format_ground_truth_tier2(repo),
                format_findings(findings),
                format_mechanical_score_tier2(tier2_result),
            )

        report.per_repo.append(
            RepoScore(
                name=repo.name,
                tier=2,
                had_scannable_files=had_scannable_files,
                findings_count=len(findings),
                tier2_result=tier2_result,
                judge_assessment=assessment,
            )
        )

    return report
