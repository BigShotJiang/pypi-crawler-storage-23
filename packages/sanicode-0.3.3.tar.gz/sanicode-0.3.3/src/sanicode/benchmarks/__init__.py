"""Benchmark suite for comparing sanicode against external tools."""
