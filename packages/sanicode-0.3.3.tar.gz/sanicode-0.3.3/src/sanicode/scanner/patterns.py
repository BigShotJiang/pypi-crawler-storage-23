"""Static pattern detection constants and data types for the sanicode scanner.

Defines the shared ``Finding`` dataclass, severity type, and the
``KNOWN_BAD_PATTERNS`` registry. Actual detection logic lives in the
language plugin implementations (e.g. ``sanicode.scanner.languages.python``).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

Severity = Literal["critical", "high", "medium", "low", "info"]


@dataclass
class Finding:
    """A single security finding produced by the scanner."""

    file: Path
    line: int
    column: int
    rule_id: str
    message: str
    severity: Severity
    cwe_id: int


# Known-bad patterns: maps rule_id -> human-readable description.
# Static baseline — extended dynamically by init_known_bad_patterns().
KNOWN_BAD_PATTERNS: dict[str, str] = {
    "SC001": "Use of eval() \u2014 arbitrary code execution via unsanitized input (CWE-78)",
    "SC002": "Use of exec() \u2014 arbitrary code execution via unsanitized input (CWE-78)",
    "SC003": "Use of os.system() \u2014 command injection risk (CWE-78)",
    "SC004": "Use of subprocess with shell=True \u2014 command injection risk (CWE-78)",
    "SC005": "Use of pickle.loads() \u2014 deserialization of untrusted data (CWE-502)",
    "SC006": "String formatting in SQL context \u2014 potential SQL injection (CWE-89)",
    "SC007": "Use of __import__() \u2014 dynamic import from untrusted input (CWE-94)",
    "SC008": "Use of yaml.load() without Loader \u2014 deserialization of untrusted data (CWE-502)",
}


def init_known_bad_patterns() -> None:
    """Extend KNOWN_BAD_PATTERNS with rules from the rule registry.

    Safe to call multiple times; new rules are merged in additively.
    """
    from sanicode.rules import get_rule_registry, init_rules

    init_rules()
    registry = get_rule_registry()
    KNOWN_BAD_PATTERNS.update(registry.known_bad_patterns())
