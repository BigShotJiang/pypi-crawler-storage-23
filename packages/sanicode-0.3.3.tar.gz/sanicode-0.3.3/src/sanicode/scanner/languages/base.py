"""Base class for tree-sitter-backed language plugins.

Provides parse_file/parse_source and common query/node helpers.
Subclasses set ``_language_name`` and implement detection methods.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Query, QueryCursor, Tree
from tree_sitter_language_pack import get_language, get_parser


class TreeSitterPlugin:
    """Base class for tree-sitter-backed language scanner plugins.

    Subclasses must set ``_language_name`` to a language name supported by
    ``tree-sitter-language-pack`` (e.g. ``"python"``, ``"javascript"``).
    """

    _language_name: str

    def __init__(self) -> None:
        self._language = get_language(self._language_name)
        self._parser = get_parser(self._language_name)

    def parse_file(self, path: Path) -> Tree:
        """Parse a file from disk and return the tree-sitter ``Tree``."""
        return self.parse_source(path.read_bytes(), filename=str(path))

    def parse_source(self, source: bytes, filename: str = "<string>") -> Tree:
        """Parse raw source bytes and return the tree-sitter ``Tree``."""
        return self._parser.parse(source)

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def query(self, pattern: str) -> Query:
        """Compile an S-expression query pattern for this language."""
        return Query(self._language, pattern)

    def captures(self, pattern: str, node: Node) -> dict[str, list[Node]]:
        """Run a query against *node* and return ``{capture_name: [nodes]}``."""
        q = self.query(pattern)
        cursor = QueryCursor(q)
        return cursor.captures(node)

    def matches(self, pattern: str, node: Node) -> list[tuple[int, dict[str, list[Node]]]]:
        """Run a query against *node* and return match tuples.

        Each match is ``(pattern_index, {capture_name: [nodes]})``.
        """
        q = self.query(pattern)
        cursor = QueryCursor(q)
        return cursor.matches(node)

    # ------------------------------------------------------------------
    # Node helpers
    # ------------------------------------------------------------------

    @staticmethod
    def node_text(node: Node) -> str:
        """Return the source text of *node* as a UTF-8 string."""
        return node.text.decode("utf-8") if node.text else ""

    @staticmethod
    def start_position(node: Node) -> tuple[int, int]:
        """Return the 1-based ``(line, column)`` of *node*'s start.

        tree-sitter uses 0-based rows; our dataclasses use 1-based lines.
        """
        return (node.start_point.row + 1, node.start_point.column)
