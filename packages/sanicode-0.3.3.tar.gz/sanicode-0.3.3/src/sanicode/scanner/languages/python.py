"""Tree-sitter-backed Python language plugin for the sanicode scanner.

Replaces all ``ast``-based detection logic with tree-sitter queries and
programmatic post-filtering.  Implements every method required by the
:class:`~sanicode.scanner.plugin.LanguagePlugin` protocol.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.scanner.call_graph import (
    CallSiteInfo,
    FunctionDefInfo,
    _module_name_from_path,
    find_package_root,
)
from sanicode.scanner.call_graph import (
    resolve_calls as _resolve_calls,
)
from sanicode.scanner.data_flow import EntryPointInfo, SanitizerInfo, SinkInfo
from sanicode.scanner.imports import (
    FrameworkInfo,
    ImportInfo,
)
from sanicode.scanner.imports import (
    detect_frameworks as _detect_frameworks,
)
from sanicode.scanner.languages.base import TreeSitterPlugin
from sanicode.scanner.patterns import Finding

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SUBPROCESS_FUNCS = frozenset({"call", "run", "Popen", "check_output", "check_call"})

_NETWORK_SINKS = frozenset(
    {
        "requests.get",
        "requests.post",
        "requests.put",
        "requests.delete",
        "requests.patch",
        "requests.head",
        "httpx.get",
        "httpx.post",
        "httpx.put",
        "httpx.delete",
        "httpx.patch",
        "urllib.request.urlopen",
    }
)

_TEMPLATE_RENDER_FUNCS = frozenset({"render_template", "render"})

_HTTP_HANDLER_DECORATORS = frozenset(
    {"route", "get", "post", "put", "delete", "patch", "head", "options"}
)

_ENV_VAR_CALLS = frozenset({"os.environ.get", "os.getenv"})

_HTML_ESCAPE_CALLS = frozenset(
    {"html.escape", "markupsafe.escape", "bleach.clean", "escape", "strip_tags"}
)

_URL_ENCODE_CALLS = frozenset({"urllib.parse.quote", "urllib.parse.urlencode"})

_READ_MODES = frozenset({"r", "rb", "rt"})
_WRITE_MODES = frozenset({"w", "wb", "wt", "a", "ab", "at", "x", "xb", "xt"})


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _dotted_name(node: Node) -> str:
    """Build a dotted name from a tree-sitter node.

    - ``identifier`` -> its text
    - ``attribute`` -> ``_dotted_name(object) + "." + attr_text``
    - anything else -> ``""``
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "attribute":
        obj = node.child_by_field_name("object")
        attr = node.child_by_field_name("attribute")
        if obj is None or attr is None:
            return ""
        prefix = _dotted_name(obj)
        suffix = attr.text.decode("utf-8") if attr.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def _enclosing_function(node: Node) -> str | None:
    """Walk the parent chain to find the nearest function_definition ancestor."""
    current = node.parent
    while current is not None:
        if current.type in ("function_definition", "function_definition"):
            name_node = current.child_by_field_name("name")
            if name_node and name_node.text:
                return name_node.text.decode("utf-8")
        current = current.parent
    return None


def _has_keyword(call_node: Node, name: str, value: str | None = None) -> bool:
    """Check whether *call_node* has a keyword argument with the given *name*.

    If *value* is provided, also checks that the keyword's value text matches.
    """
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return False
    for child in args_node.children:
        if child.type == "keyword_argument":
            kw_name = child.child_by_field_name("name")
            kw_value = child.child_by_field_name("value")
            if kw_name and kw_name.text and kw_name.text.decode("utf-8") == name:
                if value is None:
                    return True
                if kw_value and kw_value.text:
                    return kw_value.text.decode("utf-8") == value
    return False


def _call_arguments(call_node: Node) -> list[Node]:
    """Return the positional argument nodes from a call expression."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        # Skip parens, commas, keyword_argument, and other non-positional pieces.
        if child.type in (
            "(",
            ")",
            ",",
            "keyword_argument",
            "dictionary_splat",
            "list_splat",
        ):
            continue
        results.append(child)
    return results


def _is_formatted_sql(call_node: Node) -> bool:
    """Check if the first argument to a call shows string formatting.

    Detects:
    - f-strings (string nodes containing ``interpolation`` children)
    - %-formatting (``binary_operator`` with ``%``)
    - ``.format()`` calls on a string
    """
    args = _call_arguments(call_node)
    if not args:
        return False
    first = args[0]

    # f-string: tree-sitter parses these as "string" nodes with "interpolation" children
    if first.type == "string":
        for child in first.children:
            if child.type == "interpolation":
                return True

    # Also check concatenated_string for f-strings
    if first.type == "concatenated_string":
        for child in first.children:
            if child.type == "string":
                for grandchild in child.children:
                    if grandchild.type == "interpolation":
                        return True

    # %-formatting: binary_operator with %
    if first.type == "binary_operator":
        op = first.child_by_field_name("operator")
        if op and op.text and op.text.decode("utf-8") == "%":
            return True

    # .format() call on a string
    if first.type == "call":
        func = first.child_by_field_name("function")
        if func and func.type == "attribute":
            attr = func.child_by_field_name("attribute")
            if attr and attr.text and attr.text.decode("utf-8") == "format":
                return True

    return False


def _open_mode(call_node: Node) -> str | None:
    """Return the mode string from an open() call, or None if indeterminate.

    Checks the second positional argument or a ``mode=`` keyword.
    """
    args = _call_arguments(call_node)
    # Check keyword first
    args_container = call_node.child_by_field_name("arguments")
    if args_container:
        for child in args_container.children:
            if child.type == "keyword_argument":
                kw_name = child.child_by_field_name("name")
                kw_value = child.child_by_field_name("value")
                if (
                    kw_name
                    and kw_name.text
                    and kw_name.text.decode("utf-8") == "mode"
                    and kw_value
                    and kw_value.type == "string"
                    and kw_value.text
                ):
                    return _strip_string_quotes(kw_value.text.decode("utf-8"))

    # Second positional argument
    if len(args) >= 2:
        mode_node = args[1]
        if mode_node.type == "string" and mode_node.text:
            return _strip_string_quotes(mode_node.text.decode("utf-8"))

    return None


def _strip_string_quotes(s: str) -> str:
    """Strip surrounding quotes from a tree-sitter string literal."""
    for q in ('"""', "'''", '"', "'"):
        if s.startswith(q) and s.endswith(q):
            return s[len(q) : -len(q)]
    return s


def _is_orm_execute(call_node: Node) -> bool:
    """Return True when execute() looks like an ORM call (select/text pattern)."""
    args = _call_arguments(call_node)
    if not args:
        return False
    first = args[0]
    if first.type == "call":
        func = first.child_by_field_name("function")
        if func is None:
            return False
        name = _dotted_name(func)
        final = name.rsplit(".", 1)[-1] if "." in name else name
        return final in ("select", "text")
    return False


def _has_parameterized_second_arg(call_node: Node) -> bool:
    """Check if the call has a tuple/list as its second positional arg or params kwarg."""
    args = _call_arguments(call_node)
    if len(args) >= 2 and args[1].type in ("tuple", "list"):
        return True
    # Check for params=(...) keyword
    args_container = call_node.child_by_field_name("arguments")
    if args_container:
        for child in args_container.children:
            if child.type == "keyword_argument":
                kw_name = child.child_by_field_name("name")
                kw_value = child.child_by_field_name("value")
                if (
                    kw_name
                    and kw_name.text
                    and kw_name.text.decode("utf-8") == "params"
                    and kw_value
                    and kw_value.type in ("tuple", "list")
                ):
                    return True
    return False


def _walk(node: Node) -> list[Node]:
    """Depth-first walk of all descendants of *node*, including *node* itself."""
    result: list[Node] = [node]
    for child in node.children:
        result.extend(_walk(child))
    return result


# ---------------------------------------------------------------------------
# PythonPlugin
# ---------------------------------------------------------------------------


class PythonPlugin(TreeSitterPlugin):
    """Tree-sitter-backed scanner plugin for Python source files."""

    _language_name = "python"

    @property
    def name(self) -> str:
        return "python"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".py", ".pyw"})

    # ------------------------------------------------------------------
    # Pattern checks (SC001-SC008)
    # ------------------------------------------------------------------

    def check_patterns(self, tree: Tree, file_path: Path) -> list[Finding]:
        from sanicode.rules import get_rule_registry, init_rules

        init_rules()
        registry = get_rule_registry()
        findings: list[Finding] = []
        for rule in registry.rules_for("python"):
            findings.extend(rule.check(tree, file_path, self))
        return findings

    # ------------------------------------------------------------------
    # Import detection
    # ------------------------------------------------------------------

    def detect_imports(self, tree: Tree, file_path: Path) -> list[ImportInfo]:
        results: list[ImportInfo] = []
        root = tree.root_node

        # import X / import X as Y
        for node in _walk(root):
            if node.type == "import_statement":
                results.extend(self._parse_import_statement(node, file_path))
            elif node.type == "import_from_statement":
                results.extend(self._parse_import_from_statement(node, file_path))

        return results

    def _parse_import_statement(
        self, node: Node, file_path: Path
    ) -> list[ImportInfo]:
        """Parse ``import X`` or ``import X as Y`` statements."""
        results: list[ImportInfo] = []
        line, _ = self.start_position(node)

        # Children: "import" keyword, then dotted_name / aliased_import nodes
        for child in node.children:
            if child.type == "dotted_name":
                module = self.node_text(child)
                results.append(
                    ImportInfo(
                        module=module,
                        names=[],
                        aliases={},
                        file=file_path,
                        line=line,
                        is_from=False,
                    )
                )
            elif child.type == "aliased_import":
                name_node = child.child_by_field_name("name")
                alias_node = child.child_by_field_name("alias")
                module = self.node_text(name_node) if name_node else ""
                alias = self.node_text(alias_node) if alias_node else ""
                aliases = {alias: module} if alias else {}
                results.append(
                    ImportInfo(
                        module=module,
                        names=[],
                        aliases=aliases,
                        file=file_path,
                        line=line,
                        is_from=False,
                    )
                )

        return results

    def _parse_import_from_statement(
        self, node: Node, file_path: Path
    ) -> list[ImportInfo]:
        """Parse ``from X import Y`` statements."""
        line, _ = self.start_position(node)
        module = ""
        names: list[str] = []
        aliases: dict[str, str] = {}

        # Find the module name (dotted_name or relative_import)
        module_node = node.child_by_field_name("module_name")
        if module_node:
            module = self.node_text(module_node)

        # Find imported names
        for child in node.children:
            if child.type == "dotted_name" and child != module_node:
                names.append(self.node_text(child))
            elif child.type == "aliased_import":
                name_node = child.child_by_field_name("name")
                alias_node = child.child_by_field_name("alias")
                original = self.node_text(name_node) if name_node else ""
                alias = self.node_text(alias_node) if alias_node else ""
                names.append(original)
                if alias:
                    aliases[alias] = original
            elif child.type == "wildcard_import":
                names.append("*")
            elif child.type == "import_prefix":
                # Relative import dots — already part of module or prefix
                pass
            elif child.type == "identifier":
                # Simple imported name (no dotted_name wrapper)
                # Skip the 'from' and 'import' keywords which are also children
                text = self.node_text(child)
                if text not in ("from", "import"):
                    names.append(text)

        return [
            ImportInfo(
                module=module,
                names=names,
                aliases=aliases,
                file=file_path,
                line=line,
                is_from=True,
            )
        ]

    # ------------------------------------------------------------------
    # Framework detection (delegates to pure-logic function)
    # ------------------------------------------------------------------

    def detect_frameworks(self, imports: list[ImportInfo]) -> list[FrameworkInfo]:
        return _detect_frameworks(imports)

    # ------------------------------------------------------------------
    # Entry point detection
    # ------------------------------------------------------------------

    def detect_entry_points(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[EntryPointInfo]:
        results: list[EntryPointInfo] = []
        root = tree.root_node

        # Track functions already captured as HTTP handlers via decorator
        _decorator_captured: set[str] = set()

        # 1. Function definitions with HTTP handler decorators or "request" param
        for node in _walk(root):
            if node.type == "function_definition":
                self._check_function_entry_point(
                    node, file_path, results, _decorator_captured
                )

        # 2. Call-based entry points and attribute access
        for node in _walk(root):
            if node.type == "call":
                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue
                dotted = _dotted_name(func_node)
                fn = _enclosing_function(node)

                # os.environ.get / os.getenv
                if dotted in _ENV_VAR_CALLS:
                    results.append(
                        EntryPointInfo(
                            name=dotted,
                            kind="env_var",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=fn,
                        )
                    )

                # input()
                elif dotted == "input":
                    results.append(
                        EntryPointInfo(
                            name="input",
                            kind="stdin",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=fn,
                        )
                    )

                # open() for reading
                elif dotted == "open":
                    mode = _open_mode(node)
                    if mode is None or mode in _READ_MODES:
                        results.append(
                            EntryPointInfo(
                                name="open",
                                kind="file_read",
                                file=file_path,
                                line=self.start_position(node)[0],
                                function=fn,
                            )
                        )

                # Path.read_text()
                elif (
                    func_node.type == "attribute"
                    and func_node.child_by_field_name("attribute") is not None
                    and (
                        func_node.child_by_field_name("attribute").text or b""
                    ).decode("utf-8")
                    == "read_text"
                ):
                    results.append(
                        EntryPointInfo(
                            name="Path.read_text",
                            kind="file_read",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=fn,
                        )
                    )

            # os.environ["KEY"] subscript access
            elif node.type == "subscript":
                value_node = node.child_by_field_name("value")
                if value_node and _dotted_name(value_node) == "os.environ":
                    results.append(
                        EntryPointInfo(
                            name="os.environ",
                            kind="env_var",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                        )
                    )

            # sys.argv / sys.stdin attribute access
            elif node.type == "attribute":
                dotted = _dotted_name(node)
                if dotted == "sys.argv":
                    results.append(
                        EntryPointInfo(
                            name="sys.argv",
                            kind="cli_arg",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                        )
                    )
                elif dotted == "sys.stdin":
                    results.append(
                        EntryPointInfo(
                            name="sys.stdin",
                            kind="stdin",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                        )
                    )

        return results

    def _check_function_entry_point(
        self,
        node: Node,
        file_path: Path,
        results: list[EntryPointInfo],
        captured: set[str],
    ) -> None:
        """Check a function_definition for HTTP handler decorators or 'request' param."""
        name_node = node.child_by_field_name("name")
        func_name = self.node_text(name_node) if name_node else ""
        line = self.start_position(node)[0]

        # Check decorators — tree-sitter places decorator nodes on the
        # ``decorated_definition`` parent, not as children of ``function_definition``.
        parent = node.parent
        decorator_parent = parent if parent and parent.type == "decorated_definition" else node
        for child in decorator_parent.children:
            if child.type == "decorator":
                for dec_child in child.children:
                    expr = dec_child
                    # Unwrap call: @app.get("/path") -> the function is app.get
                    if expr.type == "call":
                        expr = expr.child_by_field_name("function") or expr
                    if expr.type == "attribute":
                        attr = expr.child_by_field_name("attribute")
                        if (
                            attr
                            and attr.text
                            and attr.text.decode("utf-8") in _HTTP_HANDLER_DECORATORS
                        ):
                            results.append(
                                EntryPointInfo(
                                    name=func_name,
                                    kind="http_handler",
                                    file=file_path,
                                    line=line,
                                    function=_enclosing_function(node),
                                )
                            )
                            captured.add(func_name)
                            return  # One match is enough

        # Check for "request" parameter
        params_node = node.child_by_field_name("parameters")
        if params_node and func_name not in captured:
            for param_child in params_node.children:
                if param_child.type == "identifier":
                    if self.node_text(param_child) == "request":
                        results.append(
                            EntryPointInfo(
                                name=func_name,
                                kind="http_handler",
                                file=file_path,
                                line=line,
                                function=_enclosing_function(node),
                            )
                        )
                        captured.add(func_name)
                        return
                # Typed parameter: name: type
                elif param_child.type in (
                    "typed_parameter",
                    "typed_default_parameter",
                ):
                    pname = param_child.child_by_field_name("name")
                    if pname and self.node_text(pname) == "request":
                        results.append(
                            EntryPointInfo(
                                name=func_name,
                                kind="http_handler",
                                file=file_path,
                                line=line,
                                function=_enclosing_function(node),
                            )
                        )
                        captured.add(func_name)
                        return
                # Default parameter: name=value
                elif param_child.type == "default_parameter":
                    pname = param_child.child_by_field_name("name")
                    if pname and self.node_text(pname) == "request":
                        results.append(
                            EntryPointInfo(
                                name=func_name,
                                kind="http_handler",
                                file=file_path,
                                line=line,
                                function=_enclosing_function(node),
                            )
                        )
                        captured.add(func_name)
                        return

    # ------------------------------------------------------------------
    # Sink detection
    # ------------------------------------------------------------------

    def detect_sinks(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[SinkInfo]:
        results: list[SinkInfo] = []
        root = tree.root_node
        fw_names = frozenset(fw.name for fw in (frameworks or []))

        call_captures = self.captures("(call) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            fn = _enclosing_function(call_node)
            line = self.start_position(call_node)[0]

            def _add(
                name: str,
                kind: str,
                cwe_id: int | None,
                *,
                _line: int = line,
                _fn: str | None = fn,
            ) -> None:
                results.append(
                    SinkInfo(
                        name=name,
                        kind=kind,
                        file=file_path,
                        line=_line,
                        function=_fn,
                        cwe_id=cwe_id,
                    )
                )

            # Simple name calls
            if func_node.type == "identifier":
                if dotted == "eval":
                    _add("eval", "eval", 94)
                elif dotted == "exec":
                    _add("exec", "eval", 94)
                elif dotted == "__import__":
                    _add("__import__", "eval", 94)
                elif dotted in _TEMPLATE_RENDER_FUNCS:
                    _add(dotted, "template", 79)
                elif dotted == "open":
                    mode = _open_mode(call_node)
                    if mode is not None and mode in _WRITE_MODES:
                        _add("open", "file_write", 73)

            # Attribute calls
            elif func_node.type == "attribute":
                attr_node = func_node.child_by_field_name("attribute")
                attr_text = (
                    attr_node.text.decode("utf-8")
                    if attr_node and attr_node.text
                    else ""
                )

                if dotted == "os.system":
                    _add("os.system", "command", 78)

                elif (
                    dotted.startswith("subprocess.")
                    and attr_text in _SUBPROCESS_FUNCS
                    and _has_keyword(call_node, "shell", "True")
                ):
                    _add(f"subprocess.{attr_text}", "command", 78)

                elif attr_text == "execute" and _is_formatted_sql(call_node):
                    # ORM false-positive suppression
                    if not (
                        fw_names & {"sqlalchemy", "django"}
                        and _is_orm_execute(call_node)
                    ):
                        _add("cursor.execute", "sql", 89)

                elif dotted == "pickle.loads":
                    _add("pickle.loads", "eval", 502)

                elif dotted == "yaml.load" and not _has_keyword(
                    call_node, "Loader"
                ):
                    _add("yaml.load", "eval", 502)

                elif (
                    attr_text == "render_template"
                    or dotted.endswith(".render")
                ):
                    _add(dotted or attr_text, "template", 79)

                elif dotted in _NETWORK_SINKS:
                    _add(dotted, "network", 918)

                elif attr_text == "write_text":
                    _add("Path.write_text", "file_write", 73)

                elif attr_text == "open":
                    mode = _open_mode(call_node)
                    if mode is not None and mode in _WRITE_MODES:
                        _add("open", "file_write", 73)

        return results

    # ------------------------------------------------------------------
    # Sanitizer detection
    # ------------------------------------------------------------------

    def detect_sanitizers(self, tree: Tree, file_path: Path) -> list[SanitizerInfo]:
        results: list[SanitizerInfo] = []
        root = tree.root_node

        call_captures = self.captures("(call) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            fn = _enclosing_function(call_node)
            line = self.start_position(call_node)[0]

            if dotted in _HTML_ESCAPE_CALLS:
                results.append(
                    SanitizerInfo(
                        name=dotted,
                        kind="html_escape",
                        file=file_path,
                        line=line,
                        function=fn,
                    )
                )

            elif dotted == "shlex.quote":
                results.append(
                    SanitizerInfo(
                        name="shlex.quote",
                        kind="shell_quote",
                        file=file_path,
                        line=line,
                        function=fn,
                    )
                )

            elif dotted in _URL_ENCODE_CALLS:
                results.append(
                    SanitizerInfo(
                        name=dotted,
                        kind="url_encode",
                        file=file_path,
                        line=line,
                        function=fn,
                    )
                )

            elif (
                func_node.type == "attribute"
                and func_node.child_by_field_name("attribute") is not None
                and (
                    func_node.child_by_field_name("attribute").text or b""
                ).decode("utf-8")
                == "execute"
            ):
                if _has_parameterized_second_arg(call_node):
                    results.append(
                        SanitizerInfo(
                            name="cursor.execute",
                            kind="parameterized_query",
                            file=file_path,
                            line=line,
                            function=fn,
                        )
                    )

        return results

    # ------------------------------------------------------------------
    # Call graph: definitions
    # ------------------------------------------------------------------

    def collect_definitions(
        self,
        file_trees: list[tuple[Path, Tree]],
        project_root: Path | None = None,
    ) -> dict[str, FunctionDefInfo]:
        defs: dict[str, FunctionDefInfo] = {}

        for file_path, tree in file_trees:
            module_name = _module_name_from_path(file_path, project_root=project_root)
            root = tree.root_node

            func_captures = self.captures(
                "(function_definition) @func", root
            )
            for func_node in func_captures.get("func", []):
                name_node = func_node.child_by_field_name("name")
                func_name = self.node_text(name_node) if name_node else ""
                if not func_name:
                    continue

                # Determine class scope via parent chain
                class_parts: list[str] = []
                parent = func_node.parent
                while parent is not None:
                    if parent.type == "class_definition":
                        cls_name_node = parent.child_by_field_name("name")
                        if cls_name_node:
                            class_parts.insert(0, self.node_text(cls_name_node))
                    parent = parent.parent

                qualified = ".".join([module_name, *class_parts, func_name])

                # Extract parameter names
                params: list[str] = []
                params_node = func_node.child_by_field_name("parameters")
                if params_node:
                    for p in params_node.children:
                        if p.type == "identifier":
                            params.append(self.node_text(p))
                        elif p.type in (
                            "typed_parameter",
                            "typed_default_parameter",
                            "default_parameter",
                        ):
                            pname = p.child_by_field_name("name")
                            if pname:
                                params.append(self.node_text(pname))

                line = self.start_position(func_node)[0]
                info = FunctionDefInfo(
                    name=func_name,
                    qualified_name=qualified,
                    params=params,
                    file=file_path,
                    line=line,
                )
                defs[qualified] = info
                if func_name not in defs:
                    defs[func_name] = info

        return defs

    # ------------------------------------------------------------------
    # Call graph: call sites
    # ------------------------------------------------------------------

    def collect_call_sites(
        self, file_trees: list[tuple[Path, Tree]]
    ) -> list[CallSiteInfo]:
        sites: list[CallSiteInfo] = []

        for file_path, tree in file_trees:
            root = tree.root_node
            call_captures = self.captures("(call) @call", root)

            for call_node in call_captures.get("call", []):
                func_node = call_node.child_by_field_name("function")
                if func_node is None:
                    continue

                target = _dotted_name(func_node)
                if not target:
                    continue

                # Extract argument names/expressions
                args: list[str] = []
                for arg_node in _call_arguments(call_node):
                    if arg_node.type == "identifier" and arg_node.text:
                        args.append(arg_node.text.decode("utf-8"))
                    else:
                        args.append("<expr>")

                caller = _enclosing_function(call_node) or ""
                line = self.start_position(call_node)[0]

                sites.append(
                    CallSiteInfo(
                        target=target,
                        args=args,
                        file=file_path,
                        line=line,
                        caller=caller,
                    )
                )

        return sites

    # ------------------------------------------------------------------
    # Call resolution (delegates to pure-logic function)
    # ------------------------------------------------------------------

    def resolve_calls(
        self,
        definitions: dict[str, FunctionDefInfo],
        call_sites: list[CallSiteInfo],
        imports: list[ImportInfo],
    ) -> list[tuple[CallSiteInfo, FunctionDefInfo]]:
        return _resolve_calls(definitions, call_sites, imports)

    # ------------------------------------------------------------------
    # Package root (delegates to pure-logic function)
    # ------------------------------------------------------------------

    def find_package_root(self, file_path: Path) -> Path | None:
        return find_package_root(file_path)
