"""Language-specific scanner plugins backed by tree-sitter."""
