"""Scan pipeline executor — reusable scan logic decoupled from CLI output.

This module provides the core scan pipeline (file collection, AST parsing,
knowledge graph construction, pattern detection, compliance enrichment, and
optional LLM-based classification) as a pure function that can be called
from both the CLI and the API server.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from sanicode.compliance.enrichment import (
    EnrichedFinding,
    compute_compliance_score,
    compute_control_status,
    enrich_findings,
)
from sanicode.compliance.mapper import ComplianceMapper
from sanicode.config import SanicodeConfig
from sanicode.graph.builder import KnowledgeGraph
from sanicode.graph.reasoning import (
    assess_threat_paths,
    collect_code_snippets,
    extract_threat_paths,
)
from sanicode.llm.client import LLMClient, LLMNotConfiguredError
from sanicode.llm.prompts import render_prompt
from sanicode.metrics import (
    COMPLIANCE_SCORE,
    CONTROLS_FAILING,
    CONTROLS_PASSING,
    FINDINGS_BY_CATEGORY,
    GRAPH_BUILD_DURATION,
    GRAPH_EDGES_TOTAL,
    GRAPH_NODES_TOTAL,
)
from sanicode.report.persist import ScanResult, build_scan_result
from sanicode.scanner.imports import FrameworkInfo
from sanicode.scanner.patterns import Finding
from sanicode.scanner.registry import get_registry

_log = logging.getLogger(__name__)


@dataclass
class ScanOutput:
    """Container for the complete output of a scan run."""

    result: ScanResult
    graph_data: dict
    enriched_findings: list[EnrichedFinding]
    file_count: int
    parse_errors: list[str] = field(default_factory=list)


def collect_files(target: Path, cfg: SanicodeConfig) -> list[Path]:
    """Collect files to scan based on config-driven filtering.

    Walks the target directory, matching files by extension and filtering
    by exclusion patterns and max file size from the scan configuration.

    Args:
        target: Root directory to scan.
        cfg: Sanicode configuration (uses scan.include_extensions,
            scan.exclude_patterns, and scan.max_file_size_kb).

    Returns:
        Sorted, deduplicated list of file paths to scan.
    """
    scan_cfg = cfg.scan
    max_bytes = scan_cfg.max_file_size_kb * 1024
    files: list[Path] = []
    for ext in scan_cfg.include_extensions:
        for f in target.rglob(f"*{ext}"):
            rel = str(f.relative_to(target))
            if any(fnmatch(rel, pat) for pat in scan_cfg.exclude_patterns):
                continue
            if f.stat().st_size > max_bytes:
                continue
            files.append(f)
    return sorted(set(files))


def _read_code_snippet(file_path: Path, line: int, context: int = 5) -> str:
    """Read a code snippet centered around a given line number.

    Args:
        file_path: Path to the source file.
        line: 1-based line number of the finding.
        context: Number of lines before and after to include.

    Returns:
        Numbered lines as a string, or an error message if unreadable.
    """
    try:
        lines = file_path.read_text(encoding="utf-8").splitlines()
        start = max(0, line - context - 1)
        end = min(len(lines), line + context)
        numbered = [f"{i + 1:4d} | {lines[i]}" for i in range(start, end)]
        return "\n".join(numbered)
    except (OSError, UnicodeDecodeError):
        return f"<unable to read {file_path}:{line}>"


def _llm_classify(
    llm: LLMClient,
    findings: list[EnrichedFinding],
    file_trees: list[tuple[Path, Any]],
) -> list[EnrichedFinding]:
    """Use the fast LLM tier to filter false positives.

    Sends each finding to the LLM for classification. Findings the LLM
    determines are false positives with high confidence (>= 0.8) are removed.
    Any LLM error causes the finding to be retained — we never silently drop
    findings due to LLM failures.

    Args:
        llm: Configured LLMClient.
        findings: Enriched findings from static analysis.
        file_trees: Parsed AST modules (unused directly, passed for future use).

    Returns:
        Filtered list with high-confidence false positives removed.
        Returns findings unchanged if the fast tier is not configured.
    """
    if not llm.has_tier("fast"):
        return findings

    filtered: list[EnrichedFinding] = []
    for finding in findings:
        try:
            prompt = render_prompt(
                "classify",
                rule_id=finding.rule_id,
                message=finding.message,
                file=str(finding.file),
                line=finding.line,
                severity=finding.severity,
                cwe_id=finding.cwe_id,
                code_snippet=_read_code_snippet(finding.file, finding.line),
            )
            response = llm.classify(prompt)
            result = json.loads(response.content)
            if result.get("is_true_positive", True):
                filtered.append(finding)
            else:
                confidence = result.get("confidence", 0.0)
                if confidence < 0.8:
                    # Low confidence in FP classification — keep the finding
                    filtered.append(finding)
                else:
                    _log.info(
                        "LLM classified %s at %s:%d as false positive (confidence=%.2f)",
                        finding.rule_id,
                        finding.file,
                        finding.line,
                        confidence,
                    )
        except (LLMNotConfiguredError, FileNotFoundError):
            filtered.append(finding)
        except Exception as exc:
            _log.warning("LLM classify failed for %s: %s", finding.rule_id, exc)
            filtered.append(finding)

    return filtered


def _build_data_flow_context(finding: EnrichedFinding, kg: KnowledgeGraph) -> str:
    """Summarise graph nodes and edges relevant to a specific finding.

    Looks for nodes whose ``file`` attribute matches the finding's file, then
    collects any directly connected edges to build a compact textual summary
    the LLM can reason over.

    Args:
        finding: The enriched finding to build context for.
        kg: The knowledge graph from the scan.

    Returns:
        A human-readable text block describing relevant graph context, or a
        short message if no matching nodes are found.
    """
    file_str = str(finding.file)
    graph_dict = kg.to_dict()
    nodes_by_id = {n["id"]: n for n in graph_dict.get("nodes", [])}

    # Find nodes from the same file.
    relevant_ids: set[str] = set()
    for node_id, attrs in nodes_by_id.items():
        if attrs.get("file") == file_str:
            relevant_ids.add(node_id)

    if not relevant_ids:
        return "No data flow nodes detected in this file."

    lines: list[str] = []

    # Summarise relevant nodes grouped by kind.
    by_kind: dict[str, list[str]] = {}
    for node_id in sorted(relevant_ids):
        attrs = nodes_by_id[node_id]
        kind = attrs.get("kind", "unknown")
        label = attrs.get("label", node_id)
        node_line = attrs.get("line")
        desc = f"{label} (line {node_line})" if node_line else label
        by_kind.setdefault(kind, []).append(desc)

    for kind, descs in sorted(by_kind.items()):
        lines.append(f"{kind}: {', '.join(descs)}")

    # Summarise edges touching relevant nodes.
    edge_lines: list[str] = []
    for link in graph_dict.get("links", []):
        src = link.get("source")
        tgt = link.get("target")
        if src not in relevant_ids and tgt not in relevant_ids:
            continue
        src_label = nodes_by_id.get(src, {}).get("label", src)
        tgt_label = nodes_by_id.get(tgt, {}).get("label", tgt)
        confidence = link.get("confidence", "heuristic")
        sanitized = link.get("sanitized", False)
        edge_desc = f"  {src_label} -> {tgt_label} [{confidence}, sanitized={sanitized}]"
        edge_lines.append(edge_desc)

    if edge_lines:
        lines.append("data flows:")
        lines.extend(edge_lines)

    return "\n".join(lines)


def _build_compliance_context(finding: EnrichedFinding) -> str:
    """Serialise the current compliance mapping for the reasoning prompt.

    Args:
        finding: An enriched finding with a populated compliance field.

    Returns:
        A compact text representation of the current compliance controls.
    """
    if finding.compliance is None:
        return "No compliance mapping available."

    c = finding.compliance
    parts: list[str] = []

    if c.owasp_asvs:
        ids = [
            (e.get("id", str(e)) if isinstance(e, dict) else str(e))
            for e in c.owasp_asvs
        ]
        parts.append(f"OWASP ASVS: {', '.join(ids)}")

    if c.nist_800_53:
        parts.append(f"NIST 800-53: {', '.join(c.nist_800_53)}")

    if c.asd_stig:
        ids = [
            (e.get("id", str(e)) if isinstance(e, dict) else str(e))
            for e in c.asd_stig
        ]
        cats = [
            (e.get("cat", "") if isinstance(e, dict) else "")
            for e in c.asd_stig
        ]
        stig_parts = [f"{i} ({cat})" if cat else i for i, cat in zip(ids, cats, strict=True)]
        parts.append(f"ASD STIG: {', '.join(stig_parts)}")

    if c.pci_dss:
        parts.append(f"PCI DSS: {', '.join(c.pci_dss)}")

    if c.asvs_level:
        parts.append(f"ASVS level: {c.asvs_level}")

    if c.stig_category:
        parts.append(f"STIG category: {c.stig_category}")

    return "\n".join(parts) if parts else "No controls mapped."


# Severity downgrade table: when the analysis tier determines a finding is
# mitigated, we reduce severity by one step rather than removing it entirely.
_SEVERITY_DOWNGRADE: dict[str, str] = {
    "critical": "medium",
    "high": "medium",
    "medium": "low",
    "low": "info",
    "info": "info",
}


def _llm_analyze_data_flow(
    llm: LLMClient,
    enriched: list[EnrichedFinding],
    kg: KnowledgeGraph,
) -> list[EnrichedFinding]:
    """Use the analysis LLM tier to assess data flow context for findings.

    For each finding, builds a summary of graph nodes and edges relevant to
    its source file, then asks the LLM to determine whether the data flow path
    is confirmed exploitable, mitigated by existing sanitizers, or uncertain.

    Findings the LLM determines are mitigated have their ``derived_severity``
    downgraded one step (e.g. critical -> medium). Findings the LLM marks
    "confirmed" or "review", or any finding where the LLM call fails, are
    returned unchanged.

    Args:
        llm: Configured LLMClient.
        enriched: Enriched findings after false-positive classification.
        kg: Knowledge graph built during the current scan.

    Returns:
        The findings list with ``derived_severity`` adjusted for mitigated paths.
        Returns findings unchanged if the analysis tier is not configured.
    """
    if not llm.has_tier("analysis"):
        return enriched

    updated: list[EnrichedFinding] = []
    for finding in enriched:
        try:
            context = _build_data_flow_context(finding, kg)
            prompt = render_prompt(
                "analyze",
                rule_id=finding.rule_id,
                message=finding.message,
                file=str(finding.file),
                line=finding.line,
                cwe_id=finding.cwe_id,
                code_snippet=_read_code_snippet(finding.file, finding.line),
                data_flow_context=context,
            )
            response = llm.analyze(prompt)
            result = json.loads(response.content)
            assessment = result.get("assessment", "review")
            if assessment == "mitigated":
                confidence = result.get("confidence", 0.0)
                if confidence >= 0.7:
                    current_sev = (finding.derived_severity or str(finding.severity)).lower()
                    new_sev = _SEVERITY_DOWNGRADE.get(current_sev, current_sev)
                    finding.derived_severity = new_sev
                    _log.info(
                        "LLM data flow analysis: %s at %s:%d downgraded to %s "
                        "(confidence=%.2f, reason=%s)",
                        finding.rule_id,
                        finding.file,
                        finding.line,
                        new_sev,
                        confidence,
                        result.get("reasoning", ""),
                    )
        except (LLMNotConfiguredError, FileNotFoundError):
            pass
        except Exception as exc:
            _log.warning("LLM analyze failed for %s: %s", finding.rule_id, exc)
        updated.append(finding)

    return updated


def _llm_reason_compliance(
    llm: LLMClient,
    enriched: list[EnrichedFinding],
    kg: KnowledgeGraph,
) -> list[EnrichedFinding]:
    """Use the reasoning LLM tier to enhance compliance mapping for high-severity findings.

    For each finding whose effective severity is "critical" or "high", asks the
    reasoning model to validate the CWE classification, identify additional
    applicable controls, and generate context-aware remediation guidance.

    The LLM's remediation text is written into ``finding.remediation`` when it
    is non-empty. Existing compliance control IDs are not modified — the
    additional controls from the LLM response are appended to the log for
    operator review (full DB writes are a Phase 2 concern).

    Args:
        llm: Configured LLMClient.
        enriched: Enriched findings after data flow analysis.
        kg: Knowledge graph built during the current scan (unused directly;
            passed for signature consistency and future graph-aware reasoning).

    Returns:
        The findings list with ``remediation`` populated for high/critical findings.
        Returns findings unchanged if the reasoning tier is not configured.
    """
    if not llm.has_tier("reasoning"):
        return enriched

    updated: list[EnrichedFinding] = []
    for finding in enriched:
        effective_sev = (finding.derived_severity or str(finding.severity)).lower()
        if effective_sev not in ("critical", "high"):
            updated.append(finding)
            continue

        try:
            compliance_ctx = _build_compliance_context(finding)
            prompt = render_prompt(
                "reason",
                rule_id=finding.rule_id,
                cwe_id=finding.cwe_id,
                cwe_name=finding.cwe_name or f"CWE-{finding.cwe_id}",
                severity=effective_sev,
                code_snippet=_read_code_snippet(finding.file, finding.line),
                compliance_context=compliance_ctx,
            )
            response = llm.reason(prompt)
            result = json.loads(response.content)

            remediation = result.get("remediation", "")
            if remediation:
                finding.remediation = remediation

            additional = result.get("additional_controls", [])
            if additional:
                _log.info(
                    "LLM compliance reasoning: %s at %s:%d — additional controls: %s",
                    finding.rule_id,
                    finding.file,
                    finding.line,
                    ", ".join(str(c) for c in additional),
                )

            if not result.get("cwe_valid", True):
                _log.warning(
                    "LLM compliance reasoning: CWE-%d may be misclassified for %s at %s:%d",
                    finding.cwe_id,
                    finding.rule_id,
                    finding.file,
                    finding.line,
                )
        except (LLMNotConfiguredError, FileNotFoundError):
            pass
        except Exception as exc:
            _log.warning("LLM reason failed for %s: %s", finding.rule_id, exc)
        updated.append(finding)

    return updated


def _llm_graph_reasoning(
    llm: LLMClient,
    enriched: list[EnrichedFinding],
    kg: KnowledgeGraph,
    target: Path,
) -> list[EnrichedFinding]:
    """Use LLM reasoning over the knowledge graph to assess threat paths.

    Extracts all entry-to-sink paths from the graph, sends them in batches to
    the reasoning LLM, and upgrades the ``derived_severity`` of any finding
    whose graph path is assessed as exploitable.

    Specifically, when the LLM assesses a path as exploitable with high
    confidence (>= 0.7), any finding whose source file matches the sink node's
    file on that path will have its derived_severity raised to match the
    assessed risk level — but only if the new severity is *higher* than the
    current one.  This prevents the graph reasoning step from inadvertently
    *downgrading* findings that were already confirmed by earlier stages.

    Args:
        llm: Configured LLMClient.
        enriched: Findings after the compliance reasoning stage.
        kg: The knowledge graph built during this scan.
        target: The scan target path (used for logging).

    Returns:
        The findings list with ``derived_severity`` potentially upgraded for
        paths the LLM confirms as exploitable.  Returns findings unchanged if
        the reasoning tier is not configured or no threat paths exist.
    """
    if not llm.has_tier("reasoning"):
        return enriched

    paths = extract_threat_paths(kg)
    if not paths:
        _log.debug("Graph reasoning: no entry-to-sink paths found in graph")
        return enriched

    _log.info("Graph reasoning: assessing %d threat path(s) in %s", len(paths), target)

    snippets = collect_code_snippets(paths)
    assessments = assess_threat_paths(llm, paths, code_snippets=snippets)

    if not assessments:
        return enriched

    # Build a lookup: sink file -> list of (risk_level, confidence) from exploitable paths.
    _SEVERITY_ORDER = ["info", "low", "medium", "high", "critical"]

    def _sev_rank(sev: str) -> int:
        return _SEVERITY_ORDER.index(sev) if sev in _SEVERITY_ORDER else -1

    # Map sink file -> highest confirmed risk from graph reasoning.
    sink_file_risk: dict[str, str] = {}
    for assessment in assessments:
        if not assessment.is_exploitable or assessment.confidence < 0.7:
            continue
        risk = assessment.risk_level
        if risk == "none" or risk not in _SEVERITY_ORDER:
            continue
        # Find the corresponding path to get its sink file.
        matching_path = next(
            (p for p in paths if p.path_id == assessment.path_id), None
        )
        if matching_path is None:
            continue
        sink_file = matching_path.sink_node.get("file")
        if not sink_file:
            continue

        existing = sink_file_risk.get(sink_file)
        if existing is None or _sev_rank(risk) > _sev_rank(existing):
            sink_file_risk[sink_file] = risk
            _log.info(
                "Graph reasoning: path %s — sink in %s assessed as %s "
                "(confidence=%.2f, reason=%s)",
                assessment.path_id,
                sink_file,
                risk,
                assessment.confidence,
                assessment.reasoning,
            )

    # Upgrade finding severities where the graph confirms a higher risk.
    updated: list[EnrichedFinding] = []
    for finding in enriched:
        file_str = str(finding.file)
        graph_risk = sink_file_risk.get(file_str)
        if graph_risk is not None:
            current_sev = (finding.derived_severity or str(finding.severity)).lower()
            if _sev_rank(graph_risk) > _sev_rank(current_sev):
                finding.derived_severity = graph_risk
                _log.info(
                    "Graph reasoning: upgraded %s at %s:%d from %s to %s",
                    finding.rule_id,
                    finding.file,
                    finding.line,
                    current_sev,
                    graph_risk,
                )
        updated.append(finding)

    return updated


def run_scan(target: Path, cfg: SanicodeConfig) -> ScanOutput:
    """Execute the full scan pipeline on a target path.

    Steps: file collection -> AST parse -> knowledge graph build ->
    pattern detection -> compliance enrichment -> LLM classification
    -> LLM data flow analysis -> LLM compliance reasoning
    (all LLM stages optional, skipped in degraded mode) -> ScanResult assembly.

    Args:
        target: Path to a file or directory to scan.
        cfg: Sanicode configuration.

    Returns:
        A ScanOutput containing the scan result, graph data, enriched
        findings, file count, and any parse errors encountered.

    Raises:
        FileNotFoundError: If the target path does not exist.
    """
    target = target.resolve()
    if not target.exists():
        raise FileNotFoundError(f"Path does not exist: {target}")

    # Populate KNOWN_BAD_PATTERNS from the rule registry before running the scan.
    # This is deferred (not done at scanner package init) to avoid a circular import.
    from sanicode.scanner.patterns import init_known_bad_patterns
    init_known_bad_patterns()

    registry = get_registry()
    file_trees: list[tuple[Path, Any]] = []
    parse_errors: list[str] = []

    if target.is_file():
        plugin = registry.for_extension(target.suffix)
        if plugin is not None:
            tree = plugin.parse_file(target)
            if tree.root_node.has_error:
                parse_errors.append(f"{target}: tree-sitter parse error")
            else:
                file_trees.append((target, tree))
    else:
        files = collect_files(target, cfg)
        for f in files:
            plugin = registry.for_extension(f.suffix)
            if plugin is None:
                continue
            tree = plugin.parse_file(f)
            if tree.root_node.has_error:
                parse_errors.append(f"{f}: tree-sitter parse error")
            else:
                file_trees.append((f, tree))

    # Build knowledge graph.
    graph_start = time.monotonic()
    kg = KnowledgeGraph.from_parsed(file_trees)
    GRAPH_BUILD_DURATION.observe(time.monotonic() - graph_start)

    # Record graph metrics.
    for kind, count in kg.node_counts_by_kind().items():
        GRAPH_NODES_TOTAL.labels(type=kind).set(count)
    GRAPH_EDGES_TOTAL.set(kg.edge_count)

    # Extract detected frameworks from the knowledge graph.
    frameworks: list[FrameworkInfo] = []
    for fw in kg.detected_frameworks:
        frameworks.append(FrameworkInfo(name=fw["name"], modules=fw["modules"]))

    # Run static pattern detection via plugin dispatch.
    findings: list[Finding] = []
    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is not None:
            findings.extend(plugin.check_patterns(tree, file_path))

    # Enrich findings with compliance cross-references.
    mapper = ComplianceMapper()
    enriched = enrich_findings(findings, mapper)

    # LLM enhancement stages (optional, skipped in degraded mode).
    llm = LLMClient.from_config(cfg)
    enriched = _llm_classify(llm, enriched, file_trees)
    enriched = _llm_analyze_data_flow(llm, enriched, kg)
    enriched = _llm_reason_compliance(llm, enriched, kg)
    enriched = _llm_graph_reasoning(llm, enriched, kg, target)

    # Record compliance metrics.
    namespace = target.name
    score = compute_compliance_score(enriched)
    COMPLIANCE_SCORE.labels(profile="default", namespace=namespace).set(score)

    control_status = compute_control_status(enriched, mapper)
    for framework, counts in control_status.items():
        CONTROLS_PASSING.labels(framework=framework).set(counts["passing"])
        CONTROLS_FAILING.labels(framework=framework).set(counts["failing"])

    # Record findings by category.
    category_counts: dict[str, int] = {}
    for ef in enriched:
        sev = (ef.derived_severity or ef.severity).lower()
        category_counts[sev] = category_counts.get(sev, 0) + 1
    for category, count in category_counts.items():
        FINDINGS_BY_CATEGORY.labels(category=category, namespace=namespace).set(count)

    # Build scan result.
    result = build_scan_result(enriched, target, kg)

    return ScanOutput(
        result=result,
        graph_data=kg.to_dict(),
        enriched_findings=enriched,
        file_count=len(file_trees),
        parse_errors=parse_errors,
    )
