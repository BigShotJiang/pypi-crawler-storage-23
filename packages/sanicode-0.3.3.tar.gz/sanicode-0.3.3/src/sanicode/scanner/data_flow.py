"""Data flow primitive dataclasses for the sanicode scanner.

Defines the shared dataclasses that represent external entry points, dangerous
sinks, and sanitization points.  Detection logic lives in the language plugin
implementations (e.g. ``sanicode.scanner.languages.python``).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class EntryPointInfo:
    """A location where external data enters the program."""

    name: str           # e.g. "handle_login", "os.environ.get"
    kind: str           # "http_handler", "cli_arg", "env_var", "stdin", "file_read"
    file: Path
    line: int
    function: str | None   # enclosing function name, or None at module scope


@dataclass
class SinkInfo:
    """A location where data is consumed in a potentially dangerous way."""

    name: str           # e.g. "cursor.execute", "eval"
    kind: str           # "sql", "command", "eval", "template", "file_write", "network"
    file: Path
    line: int
    function: str | None
    cwe_id: int | None


@dataclass
class SanitizerInfo:
    """A location where data is cleaned or escaped before use."""

    name: str           # e.g. "html.escape", "shlex.quote"
    kind: str           # "html_escape", "shell_quote", "parameterized_query", etc.
    file: Path
    line: int
    function: str | None
