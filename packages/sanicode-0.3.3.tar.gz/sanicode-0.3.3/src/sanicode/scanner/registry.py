"""Plugin registry for language-specific scanner plugins.

Maintains a mapping from file extensions and language names to
:class:`LanguagePlugin` instances. Thread-safe for use under uvicorn workers.

Typical usage::

    from sanicode.scanner.registry import register_plugin, get_registry

    register_plugin(PythonPlugin())
    plugin = get_registry().for_extension(".py")
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.scanner.plugin import LanguagePlugin


class PluginRegistry:
    """Registry mapping extensions and language names to :class:`LanguagePlugin` instances."""

    def __init__(self) -> None:
        self._by_extension: dict[str, LanguagePlugin] = {}
        self._by_name: dict[str, LanguagePlugin] = {}
        self._lock = threading.Lock()

    def register(self, plugin: LanguagePlugin) -> None:
        """Register a plugin for its declared language name and file extensions.

        Raises:
            ValueError: If the plugin's language name or any of its extensions
                are already registered by a different plugin.
        """
        language_key = plugin.name.lower()
        with self._lock:
            if language_key in self._by_name:
                existing = self._by_name[language_key]
                raise ValueError(
                    f"Language '{plugin.name}' is already registered by plugin "
                    f"'{existing.name}'"
                )
            for ext in plugin.extensions:
                normalized = _normalize_ext(ext)
                if normalized in self._by_extension:
                    owner = self._by_extension[normalized]
                    raise ValueError(
                        f"Extension '{normalized}' is already registered by plugin "
                        f"'{owner.name}'"
                    )
            # All checks passed — commit.
            self._by_name[language_key] = plugin
            for ext in plugin.extensions:
                self._by_extension[_normalize_ext(ext)] = plugin

    def for_extension(self, ext: str) -> LanguagePlugin | None:
        """Return the plugin registered for *ext*, or ``None`` if unknown.

        The extension is normalized before lookup: a leading dot is added if
        absent (e.g. ``"py"`` → ``".py"``).
        """
        key = _normalize_ext(ext)
        with self._lock:
            return self._by_extension.get(key)

    def for_language(self, name: str) -> LanguagePlugin | None:
        """Return the plugin registered for *name* (case-insensitive), or ``None``."""
        with self._lock:
            return self._by_name.get(name.lower())

    def supported_extensions(self) -> frozenset[str]:
        """Return a frozenset of all registered file extensions."""
        with self._lock:
            return frozenset(self._by_extension)

    def registered_languages(self) -> list[str]:
        """Return a sorted list of all registered language names."""
        with self._lock:
            return sorted(self._by_name)


def _normalize_ext(ext: str) -> str:
    """Ensure *ext* starts with a dot (e.g. ``"py"`` → ``".py"``)."""
    return ext if ext.startswith(".") else f".{ext}"


# ---------------------------------------------------------------------------
# Module-level singleton and convenience helpers
# ---------------------------------------------------------------------------

_registry = PluginRegistry()


def get_registry() -> PluginRegistry:
    """Return the global :class:`PluginRegistry` singleton."""
    return _registry


def register_plugin(plugin: LanguagePlugin) -> None:
    """Register *plugin* in the global registry.

    Delegates to :meth:`PluginRegistry.register`; raises :exc:`ValueError` on
    duplicate extension or language name.
    """
    _registry.register(plugin)
