"""Import analysis and framework detection for scanned codebases.

Defines the shared ``ImportInfo`` and ``FrameworkInfo`` dataclasses, the
``_FRAMEWORK_SIGNATURES`` registry, and the ``detect_frameworks()`` pure-logic
function.  Import extraction from parse trees is handled by the language plugin
implementations (e.g. ``sanicode.scanner.languages.python``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ImportInfo:
    """A single import statement extracted from a Python file."""

    module: str  # "os.path" or "flask"
    names: list[str]  # ["join", "exists"] or ["Flask", "request"]
    aliases: dict[str, str] = field(default_factory=dict)  # {"np": "numpy"}
    file: Path = field(default_factory=Path)
    line: int = 0
    is_from: bool = False  # True for 'from X import Y', False for 'import X'


@dataclass
class FrameworkInfo:
    """A detected framework or library with security-relevant behavior."""

    name: str  # "django", "flask", "sqlalchemy", "fastapi"
    version: str | None = None
    modules: list[str] = field(default_factory=list)  # detected framework modules


# Framework detection signatures: maps framework name to sets of module prefixes
_FRAMEWORK_SIGNATURES: dict[str, frozenset[str]] = {
    "django": frozenset(
        {
            "django",
            "rest_framework",
        }
    ),
    "flask": frozenset(
        {
            "flask",
        }
    ),
    "sqlalchemy": frozenset(
        {
            "sqlalchemy",
        }
    ),
    "fastapi": frozenset(
        {
            "fastapi",
        }
    ),
}


def detect_frameworks(imports: list[ImportInfo]) -> list[FrameworkInfo]:
    """Identify frameworks/libraries based on import patterns.

    Matches import module names against known framework signatures.

    Args:
        imports: Aggregated imports from all scanned files.

    Returns:
        List of detected FrameworkInfo objects (deduplicated by name).
    """
    # Collect all imported module root names
    detected: dict[str, list[str]] = {}

    for imp in imports:
        root_module = imp.module.split(".")[0] if imp.module else ""

        for fw_name, prefixes in _FRAMEWORK_SIGNATURES.items():
            if root_module in prefixes:
                if fw_name not in detected:
                    detected[fw_name] = []
                if imp.module not in detected[fw_name]:
                    detected[fw_name].append(imp.module)

    return [
        FrameworkInfo(name=name, modules=sorted(modules))
        for name, modules in sorted(detected.items())
    ]
