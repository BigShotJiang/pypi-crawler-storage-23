"""Scanner subpackage \u2014 tree-sitter-backed parsing and pattern detection."""

from sanicode.scanner.languages.javascript import JavaScriptPlugin, TypeScriptPlugin
from sanicode.scanner.languages.php import PHPPlugin
from sanicode.scanner.languages.python import PythonPlugin
from sanicode.scanner.registry import register_plugin

register_plugin(PythonPlugin())
register_plugin(JavaScriptPlugin())
register_plugin(TypeScriptPlugin())
register_plugin(PHPPlugin())

# Note: init_known_bad_patterns() is intentionally NOT called here.
# Calling it at scanner package init time creates a circular import:
#   rules.base → scanner.patterns → scanner.__init__ →
#   init_known_bad_patterns → init_rules → discover → rules.base (still loading)
# The scan executor calls init_known_bad_patterns() at the right time instead.
