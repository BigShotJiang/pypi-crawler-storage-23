"""Sanicode CLI — entry point for all subcommands."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from sanicode import __version__

app = typer.Typer(
    name="sanicode",
    help="AI-assisted code sanitization scanner with compliance mapping.",
    no_args_is_help=True,
)
console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"sanicode {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Sanicode — AI-assisted code sanitization scanner."""


config_app = typer.Typer(
    name="config",
    help="Configure the LLM backend and scanner settings.",
    invoke_without_command=True,
)
app.add_typer(config_app)


@config_app.callback(invoke_without_command=True)
def config(
    ctx: typer.Context,
    show: bool = typer.Option(False, "--show", help="Print the resolved configuration."),
    init: bool = typer.Option(
        False, "--init", help="Create a starter sanicode.toml in the current directory."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Configure the LLM backend and scanner settings."""
    if ctx.invoked_subcommand is not None:
        return

    from sanicode.config import DEFAULT_CONFIG_TEMPLATE, load_config

    if init:
        dest = Path("sanicode.toml")
        if dest.exists():
            console.print(
                "[red]Error:[/red] sanicode.toml already exists in the current directory."
            )
            raise typer.Exit(code=1)
        dest.write_text(DEFAULT_CONFIG_TEMPLATE, encoding="utf-8")
        console.print(f"[green]Created[/green] {dest.resolve()}")
        console.print(
            "Edit the file to configure your LLM endpoints,"
            " then run [bold]sanicode scan[/bold]."
        )
        return

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    source_label = (
        str(cfg._source_path) if cfg._source_path else "defaults (no config file found)"
    )
    console.print(Panel(
        f"[bold]Sanicode Configuration[/bold]\nSource: {source_label}",
        expand=False,
    ))

    # LLM tiers
    llm_table = Table(title="LLM Tiers", show_lines=False)
    llm_table.add_column("Tier", style="bold")
    llm_table.add_column("Provider")
    llm_table.add_column("Endpoint", no_wrap=True)
    llm_table.add_column("Model")
    llm_table.add_column("API Key")
    for tier_name in ("fast", "analysis", "reasoning"):
        tier = getattr(cfg.llm, tier_name)
        if tier.model:
            api_key_display = "[hidden]" if tier.api_key else "[dim]—[/dim]"
            llm_table.add_row(
                tier_name,
                tier.provider,
                tier.endpoint or "[dim]—[/dim]",
                tier.model,
                api_key_display,
            )
        else:
            llm_table.add_row(
                tier_name,
                "[dim]—[/dim]",
                "[dim]—[/dim]",
                "[dim]not configured[/dim]",
                "[dim]—[/dim]",
            )
    console.print(llm_table)

    # Scan
    scan_table = Table(title="Scan", show_lines=False)
    scan_table.add_column("Setting", style="bold")
    scan_table.add_column("Value")
    scan_table.add_row("Extensions", ", ".join(cfg.scan.include_extensions))
    scan_table.add_row("Max file size", f"{cfg.scan.max_file_size_kb} KB")
    excl = ", ".join(cfg.scan.exclude_patterns) if cfg.scan.exclude_patterns else "(none)"
    scan_table.add_row("Exclusions", excl)
    console.print(scan_table)

    # Output
    out_table = Table(title="Output", show_lines=False)
    out_table.add_column("Setting", style="bold")
    out_table.add_column("Value")
    out_table.add_row("Formats", ", ".join(cfg.output.formats))
    out_table.add_row("Output dir", cfg.output.output_dir)
    console.print(out_table)

    # Compliance
    comp_table = Table(title="Compliance", show_lines=False)
    comp_table.add_column("Setting", style="bold")
    comp_table.add_column("Value")
    comp_table.add_row("Profiles", ", ".join(cfg.compliance.profiles))
    console.print(comp_table)


_LLM_TIERS = ("fast", "analysis", "reasoning")
_LLM_FIELDS = ("provider", "model", "endpoint", "api_key", "timeout_seconds")
_VALID_KEYS = frozenset(
    f"llm.{tier}.{field}" for tier in _LLM_TIERS for field in _LLM_FIELDS
)


@config_app.command("set")
def set_(
    key: str = typer.Argument(..., help="Dotted config key (e.g. llm.fast.provider)."),
    value: str = typer.Argument(..., help="Value to set."),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Set a single configuration value by dotted path."""
    from sanicode.config import find_writable_config_path, write_llm_tier

    parts = key.split(".")
    if len(parts) != 3 or parts[0] != "llm":
        console.print(
            f"[red]Error:[/red] Invalid key [bold]{key}[/bold]. "
            "Key must be in the form [bold]llm.<tier>.<field>[/bold]."
        )
        console.print("Valid keys:")
        for vk in sorted(_VALID_KEYS):
            console.print(f"  {vk}")
        raise typer.Exit(code=1)

    _, tier_name, field_name = parts

    if key not in _VALID_KEYS:
        console.print(
            f"[red]Error:[/red] Invalid key [bold]{key}[/bold]."
        )
        console.print("Valid keys:")
        for vk in sorted(_VALID_KEYS):
            console.print(f"  {vk}")
        raise typer.Exit(code=1)

    coerced_value: str | int = value
    if field_name == "timeout_seconds":
        try:
            coerced_value = int(value)
        except ValueError:
            console.print(
                f"[red]Error:[/red] [bold]timeout_seconds[/bold] must be an integer, "
                f"got {value!r}."
            )
            raise typer.Exit(code=1) from None

    try:
        path = find_writable_config_path(config_file)
    except PermissionError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    write_llm_tier(path, tier_name, **{field_name: coerced_value})

    display_value = "[hidden]" if field_name == "api_key" else value
    console.print(f"[green]Set[/green] {key} = {display_value}")
    console.print(f"Written to {path}")


@config_app.command()
def setup(
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to write the config file."
    ),
) -> None:
    """Interactive wizard to configure LLM providers and models."""
    from rich.prompt import Confirm, Prompt

    from sanicode.config import find_writable_config_path, write_llm_tier
    from sanicode.llm.providers import (
        cloud_providers,
        get_provider,
        self_hosted_providers,
    )

    # Step 1: Show grouped provider list.
    cloud = cloud_providers()
    self_hosted = self_hosted_providers()

    console.print("\n[bold]Cloud providers:[/bold]")
    for p in cloud:
        console.print(f"  {p.name:<14} {p.display_name}")
    console.print("\n[bold]Self-hosted:[/bold]")
    for p in self_hosted:
        console.print(f"  {p.name:<14} {p.display_name}")
    console.print()

    all_names = [p.name for p in cloud] + [p.name for p in self_hosted]
    provider_name = Prompt.ask(
        "Provider",
        choices=all_names + ["other"],
        default="anthropic",
    )

    provider_info = get_provider(provider_name)

    # Step 2: Endpoint URL (self-hosted or unknown providers).
    endpoint = None
    if provider_info and provider_info.requires_endpoint:
        endpoint = Prompt.ask(
            "Inference endpoint URL",
            default=provider_info.endpoint_hint,
        )
    elif provider_info is None and provider_name != "other":
        # Unknown provider — might need an endpoint.
        endpoint = Prompt.ask("Inference endpoint URL (leave blank for cloud)", default="")
        if not endpoint:
            endpoint = None
    elif provider_name == "other":
        endpoint = Prompt.ask("Inference endpoint URL (leave blank for cloud)", default="")
        if not endpoint:
            endpoint = None

    # Step 3: Model per tier (with suggestions if available).
    tier_names = ("fast", "analysis", "reasoning")
    suggestion_map: dict[str, str] = {}
    if provider_info and provider_info.suggestions:
        for s in provider_info.suggestions:
            suggestion_map[s.tier] = s.model

    all_tiers = Confirm.ask("Apply the same model to all tiers?", default=False)

    tier_configs: list[dict] = []
    if all_tiers:
        default_model = suggestion_map.get("analysis", suggestion_map.get("fast"))
        model = Prompt.ask("Model name", default=default_model)
        for name in tier_names:
            tier_configs.append({"tier": name, "model": model, "endpoint": endpoint})
    else:
        for name in tier_names:
            console.print(f"\n[bold]{name}[/bold] tier:")
            default_model = suggestion_map.get(name)
            tier_model = Prompt.ask("  Model", default=default_model)
            tier_endpoint = endpoint
            if provider_info and provider_info.requires_endpoint:
                tier_endpoint = Prompt.ask("  Endpoint URL", default=endpoint or "")
                if not tier_endpoint:
                    tier_endpoint = None
            tier_configs.append({"tier": name, "model": tier_model, "endpoint": tier_endpoint})

    # Step 4: API key (only for providers that need one).
    api_key = None
    if provider_info is None or provider_info.needs_api_key:
        api_key = Prompt.ask(
            "API key (leave blank to use environment variable)",
            default="",
        )
        if not api_key:
            api_key = None
            if provider_info and provider_info.auth_env_vars:
                env_hint = ", ".join(provider_info.auth_env_vars)
                console.print(f"[dim]Hint: set {env_hint} in your environment.[/dim]")

    # Step 5: Determine write path.
    try:
        path = find_writable_config_path(config_file)
    except PermissionError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Step 6: Summary and confirmation.
    summary = Table(title="Configuration Summary")
    summary.add_column("Tier", style="bold")
    summary.add_column("Provider")
    summary.add_column("Model")
    summary.add_column("Endpoint")
    summary.add_column("API Key")

    for tier_cfg in tier_configs:
        api_key_display = "[hidden]" if api_key else "(env var)"
        if provider_info and not provider_info.needs_api_key:
            api_key_display = "(not required)"
        endpoint_display = tier_cfg["endpoint"] or "[dim]—[/dim]"
        summary.add_row(
            tier_cfg["tier"],
            provider_name,
            tier_cfg["model"],
            endpoint_display,
            api_key_display,
        )

    console.print(summary)

    if not Confirm.ask("Write this configuration?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        raise typer.Exit()

    # Write each tier.
    for tier_cfg in tier_configs:
        write_llm_tier(
            path,
            tier_cfg["tier"],
            provider=provider_name,
            model=tier_cfg["model"],
            endpoint=tier_cfg["endpoint"],
            api_key=api_key,
        )

    console.print(f"\n[green]Configuration written to[/green] [bold]{path}[/bold]")


@config_app.command()
def test(
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Test connectivity to configured LLM endpoints."""
    import os
    import time

    from sanicode.config import load_config
    from sanicode.llm.client import LLMClient
    from sanicode.llm.providers import get_provider

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    llm = LLMClient.from_config(cfg)
    tier_names = ("fast", "analysis", "reasoning")
    configured = [t for t in tier_names if llm.has_tier(t)]

    if not configured:
        console.print("No LLM tiers configured. Nothing to test.")
        console.print("Run [bold]sanicode config setup[/bold] to configure endpoints.")
        raise typer.Exit()

    results = Table(title="LLM Connectivity Test")
    results.add_column("Tier", style="bold")
    results.add_column("Provider")
    results.add_column("Model")
    results.add_column("Status")
    results.add_column("Latency", justify="right")

    any_failed = False

    for tier_name in configured:
        tier_cfg = getattr(cfg.llm, tier_name)
        provider_info = get_provider(tier_cfg.provider)

        # Check auth env vars.
        if provider_info and provider_info.needs_api_key and not tier_cfg.api_key:
            missing = [v for v in provider_info.auth_env_vars if not os.environ.get(v)]
            if missing:
                console.print(
                    f"[yellow]Warning:[/yellow] {tier_name} tier uses "
                    f"{provider_info.display_name} but these env vars are not set: "
                    f"{', '.join(missing)}"
                )

        start = time.monotonic()
        try:
            llm.test_connection(tier_name)
            elapsed = time.monotonic() - start
            results.add_row(
                tier_name,
                tier_cfg.provider,
                tier_cfg.model,
                "[green]ok[/green]",
                f"{elapsed:.1f}s",
            )
        except Exception as exc:
            elapsed = time.monotonic() - start
            any_failed = True
            results.add_row(
                tier_name,
                tier_cfg.provider,
                tier_cfg.model,
                f"[red]FAIL[/red] {type(exc).__name__}: {exc}",
                f"{elapsed:.1f}s",
            )

    console.print(results)

    if any_failed:
        raise typer.Exit(code=1)


@app.command()
def scan(
    path: Path = typer.Argument(
        Path("."), help="Path to the codebase to scan."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
    output_format: list[str] = typer.Option(
        ["markdown"], "--format", "-f", help="Output format(s): markdown, json, sarif, html."
    ),
    fail_on: str | None = typer.Option(
        None, "--fail-on",
        help="Exit non-zero if findings at or above this severity "
             "(critical, high, medium, low).",
    ),
) -> None:
    """Scan a codebase, build a knowledge graph, and identify findings."""
    from sanicode.config import load_config
    from sanicode.scanner.executor import run_scan

    target = path.resolve()
    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    console.print(f"Scanning [bold]{target}[/bold] ...")

    try:
        output = run_scan(target, cfg)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    for err in output.parse_errors:
        console.print(f"[yellow]Warning:[/yellow] Skipping {err}")

    # Write report files.
    from sanicode.report.json_report import generate_json
    from sanicode.report.markdown import generate_markdown
    from sanicode.report.persist import save_scan_result
    from sanicode.report.sarif import generate_sarif

    output_dir = Path(cfg.output.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    save_scan_result(output.result, output_dir)

    report_files: list[str] = []
    for fmt in output_format:
        if fmt == "sarif":
            sarif_path = output_dir / "report.sarif"
            content = json.dumps(generate_sarif(output.result), indent=2)
            sarif_path.write_text(content, encoding="utf-8")
            report_files.append("report.sarif")
        elif fmt == "json":
            json_path = output_dir / "report.json"
            content = json.dumps(generate_json(output.result), indent=2)
            json_path.write_text(content, encoding="utf-8")
            report_files.append("report.json")
        elif fmt == "markdown":
            md_path = output_dir / "report.md"
            md_path.write_text(generate_markdown(output.result), encoding="utf-8")
            report_files.append("report.md")
        elif fmt == "html":
            from sanicode.report.html import generate_html
            html_path = output_dir / "report.html"
            html_path.write_text(
                generate_html(output.result, graph_data=output.graph_data),
                encoding="utf-8",
            )
            report_files.append("report.html")

    written = ["scan-result.json"] + report_files
    console.print(f"\n[green]Reports written to[/green] [bold]{output_dir}/[/bold]")
    for fname in written:
        console.print(f"  {fname}")

    # Print summary.
    summary = output.result.summary
    console.print()
    console.print("[bold]Knowledge Graph[/bold]")
    console.print(f"  Nodes: {summary.get('graph_nodes', 0)}  "
                  f"(entry points: {summary.get('graph_entry_points', 0)}, "
                  f"sinks: {summary.get('graph_sinks', 0)}, "
                  f"sanitizers: {summary.get('graph_sanitizers', 0)})")
    console.print(f"  Edges: {summary.get('graph_edges', 0)}")

    enriched = output.enriched_findings
    console.print()
    console.print(f"[bold]Findings:[/bold] {len(enriched)}")

    if enriched:
        # Per-finding detail table.
        detail_table = Table(title="Findings", show_lines=False)
        detail_table.add_column("File", style="cyan", no_wrap=True)
        detail_table.add_column("Line", justify="right")
        detail_table.add_column("Severity")
        detail_table.add_column("Rule", style="bold")
        detail_table.add_column("CWE", style="bold")
        detail_table.add_column("Message")

        for ef in enriched:
            sev = ef.derived_severity or ef.severity
            if sev in ("critical", "high"):
                sev_style = f"[red]{sev}[/red]"
            elif sev == "medium":
                sev_style = f"[yellow]{sev}[/yellow]"
            else:
                sev_style = f"[dim]{sev}[/dim]"

            rel_file = str(ef.file)
            try:
                rel_file = str(ef.file.relative_to(target))
            except ValueError:
                pass

            cwe_label = f"CWE-{ef.cwe_id}"
            if ef.cwe_name:
                cwe_label += f" ({ef.cwe_name})"

            detail_table.add_row(
                rel_file, str(ef.line), sev_style, ef.rule_id, cwe_label, ef.message
            )

        console.print(detail_table)
        console.print()

        # Top CWEs table.
        cwe_counts: Counter[str] = Counter()
        for ef in enriched:
            label = f"CWE-{ef.cwe_id}"
            if ef.cwe_name:
                label += f" ({ef.cwe_name})"
            cwe_counts[label] += 1

        table = Table(title="Top CWEs", show_lines=False)
        table.add_column("CWE", style="bold")
        table.add_column("Count", justify="right")
        for cwe_label, count in cwe_counts.most_common(10):
            table.add_row(cwe_label, str(count))
        console.print(table)

    # Check --fail-on threshold.
    if fail_on:
        severity_order = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        threshold = severity_order.get(fail_on.lower())
        if threshold is None:
            console.print(f"[red]Error:[/red] Invalid --fail-on severity: {fail_on}")
            console.print("Valid values: critical, high, medium, low")
            raise typer.Exit(code=1)
        breaching = [
            ef for ef in enriched
            if severity_order.get(
                (ef.derived_severity or ef.severity).lower(), 0
            ) >= threshold
        ]
        if breaching:
            console.print(
                f"\n[red]FAIL:[/red] {len(breaching)} finding(s) at or above "
                f"'{fail_on}' severity."
            )
            raise typer.Exit(code=1)


@app.command()
def report(
    scan_result_path: Path = typer.Argument(
        ..., help="Path to a scan-result.json file."
    ),
    output_format: list[str] = typer.Option(
        ["markdown", "sarif"], "--format", "-f",
        help="Output format(s): markdown, json, sarif, html."
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o",
        help="Output directory (default: same as scan-result.json)."
    ),
    severity_filter: str | None = typer.Option(
        None, "--severity", "-s", help="Minimum severity threshold: critical, high, medium, low."
    ),
    cwe_filter: list[int] | None = typer.Option(
        None, "--cwe", help="Filter to specific CWE IDs (repeatable)."
    ),
) -> None:
    """Generate reports from a saved scan-result.json file."""
    from sanicode.report.json_report import generate_json
    from sanicode.report.markdown import generate_markdown
    from sanicode.report.persist import ScanResult, load_scan_result
    from sanicode.report.sarif import generate_sarif

    try:
        result = load_scan_result(scan_result_path)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        console.print(f"[red]Error:[/red] Invalid scan result file: {exc}")
        raise typer.Exit(code=1) from exc

    # Apply filters to findings
    filtered = result.findings

    if severity_filter:
        severity_levels = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        threshold = severity_levels.get(severity_filter.lower())
        if threshold is None:
            console.print(f"[red]Error:[/red] Unknown severity: {severity_filter}")
            raise typer.Exit(code=1)
        filtered = [
            f for f in filtered
            if severity_levels.get(
                f.get("derived_severity") or f.get("severity", "info"), 0
            ) >= threshold
        ]

    if cwe_filter:
        cwe_set = set(cwe_filter)
        filtered = [f for f in filtered if f.get("cwe_id") in cwe_set]

    # Build a filtered ScanResult (update summary counts)
    by_severity: dict[str, int] = {}
    by_cwe: dict[str, int] = {}
    for f in filtered:
        sev = f.get("derived_severity") or f.get("severity", "info")
        by_severity[sev] = by_severity.get(sev, 0) + 1
        cwe_key = str(f.get("cwe_id", ""))
        by_cwe[cwe_key] = by_cwe.get(cwe_key, 0) + 1

    filtered_summary = dict(result.summary)
    filtered_summary["total_findings"] = len(filtered)
    filtered_summary["by_severity"] = by_severity
    filtered_summary["by_cwe"] = by_cwe

    filtered_result = ScanResult(
        sanicode_version=result.sanicode_version,
        scan_id=result.scan_id,
        scanned_path=result.scanned_path,
        scan_timestamp=result.scan_timestamp,
        summary=filtered_summary,
        findings=filtered,
    )

    # Determine output directory
    dest = output_dir if output_dir else scan_result_path.parent
    dest.mkdir(parents=True, exist_ok=True)

    # Generate reports
    report_files: list[str] = []
    for fmt in output_format:
        if fmt == "sarif":
            out = dest / "report.sarif"
            out.write_text(json.dumps(generate_sarif(filtered_result), indent=2), encoding="utf-8")
            report_files.append("report.sarif")
        elif fmt == "json":
            out = dest / "report.json"
            out.write_text(json.dumps(generate_json(filtered_result), indent=2), encoding="utf-8")
            report_files.append("report.json")
        elif fmt == "markdown":
            out = dest / "report.md"
            out.write_text(generate_markdown(filtered_result), encoding="utf-8")
            report_files.append("report.md")
        elif fmt == "html":
            from sanicode.report.html import generate_html
            out = dest / "report.html"
            out.write_text(generate_html(filtered_result), encoding="utf-8")
            report_files.append("report.html")

    console.print(f"[green]Reports written to[/green] [bold]{dest}/[/bold]")
    for fname in report_files:
        console.print(f"  {fname}")


@app.command()
def recommend(
    scan_id: str | None = typer.Argument(None, help="Scan ID to generate recommendations for."),
    top_n: int = typer.Option(10, "--top", "-n", help="Number of top recommendations to show."),
) -> None:
    """Output prioritized remediation recommendations from a scan."""
    typer.echo("Not yet implemented: recommend")


@app.command()
def graph(
    path: Path = typer.Argument(
        Path("."), help="Path to the codebase to build a graph from."
    ),
    export: Path | None = typer.Option(
        None, "--export", "-e", help="Export graph to this file (JSON). Omit for stdout."
    ),
    visualize: Path | None = typer.Option(
        None, "--visualize", "--viz",
        help="Generate an interactive HTML visualization at this path."
    ),
) -> None:
    """Build and inspect or export the knowledge graph."""
    from sanicode.graph.builder import KnowledgeGraph

    target = path.resolve()
    if not target.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {target}")
        raise typer.Exit(code=1)

    kg = KnowledgeGraph.from_source(target)
    data = kg.to_dict()

    if export:
        export.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        console.print(f"Graph exported to [bold]{export}[/bold] "
                      f"({kg.node_count} nodes, {kg.edge_count} edges)")

    if visualize:
        from sanicode.graph.visualize import generate_html
        html_content = generate_html(data)
        visualize.write_text(html_content, encoding="utf-8")
        console.print(f"Visualization written to [bold]{visualize}[/bold] "
                      f"({kg.node_count} nodes, {kg.edge_count} edges)")

    if not export and not visualize:
        console.print_json(json.dumps(data, default=str))


@app.command()
def rules(
    list_rules: bool = typer.Option(False, "--list", "-l", help="List all registered rules."),
    validate: Path | None = typer.Option(
        None, "--validate", help="Validate a YAML rules file and report any errors."
    ),
) -> None:
    """List or validate detection rules."""
    from sanicode.rules import get_rule_registry, init_rules
    from sanicode.rules.custom import load_yaml_rules

    if validate is not None:
        # Initialise the built-in rule registry before validating user YAML.
        # This ensures sanicode.rules.base is loaded so _spec_to_rule can
        # import CallRule without any import-order surprises.
        init_rules()
        # Validate mode — parse the file and report errors without touching the registry.
        try:
            loaded = load_yaml_rules(validate)
        except FileNotFoundError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
        except ValueError as exc:
            from rich.markup import escape
            console.print(f"[red]Validation failed:[/red] {escape(str(exc))}")
            raise typer.Exit(code=1) from exc

        console.print(
            f"[green]OK[/green] {validate} — {len(loaded)} rule(s) valid"
        )
        for rule in loaded:
            console.print(
                f"  {rule.rule_id}  [{rule.language}]  CWE-{rule.cwe_id}  {rule.severity}"
            )
        return

    if not list_rules:
        # Neither flag given — show help excerpt.
        console.print("Use [bold]--list[/bold] to show all rules or "
                      "[bold]--validate <file>[/bold] to validate a YAML rules file.")
        raise typer.Exit()

    # List mode — discover and display all registered rules.
    init_rules()
    registry = get_rule_registry()
    all_registered = registry.all_rules()

    if not all_registered:
        console.print("No rules registered.")
        raise typer.Exit()

    table = Table(title=f"Registered Rules ({len(all_registered)} total)", show_lines=False)
    table.add_column("ID", style="bold", no_wrap=True)
    table.add_column("CWE", no_wrap=True)
    table.add_column("Severity")
    table.add_column("Language")
    table.add_column("Message")

    severity_styles = {
        "critical": "red",
        "high": "red",
        "medium": "yellow",
        "low": "dim",
        "info": "dim",
    }

    for rule in sorted(all_registered, key=lambda r: r.rule_id):
        sev = rule.severity
        sev_styled = f"[{severity_styles.get(sev, '')}]{sev}[/{severity_styles.get(sev, '')}]"
        table.add_row(
            rule.rule_id,
            f"CWE-{rule.cwe_id}",
            sev_styled,
            rule.language,
            rule.message,
        )

    console.print(table)


@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", "--host", help="Host to bind the API server to."),
    port: int = typer.Option(8080, "--port", "-p", help="Port to listen on."),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Start the Sanicode FastAPI server for remote/hybrid scan mode."""
    import uvicorn

    from sanicode.config import load_config
    from sanicode.server.app import app as fastapi_app
    from sanicode.server.app import configure

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    configure(cfg)
    console.print(f"Starting Sanicode API server on {host}:{port}")
    console.print(f"  Docs: http://{host}:{port}/api/v1/docs")
    console.print(f"  Metrics: http://{host}:{port}/metrics")
    uvicorn.run(fastapi_app, host=host, port=port)


@app.command()
def score(
    repos_dir: Path = typer.Argument(..., help="Path to the unsanitary-code-examples repo."),
    scoring_dir: Path | None = typer.Option(
        None, "--scoring-dir", help="Path to scoring/ directory. Default: repos_dir/scoring/."
    ),
    output_dir: Path = typer.Option(
        Path("./sanicode-scores"), "--output-dir", "-o", help="Output directory for score reports."
    ),
    repos: list[str] | None = typer.Option(
        None, "--repos", "-r", help="Only score these repos (by name). Repeatable."
    ),
    no_llm_judge: bool = typer.Option(
        False, "--no-llm-judge", help="Skip LLM judge (mechanical scoring only)."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Score sanicode against ground-truth vulnerability catalogs."""
    from sanicode.config import load_config
    from sanicode.scoring.report import generate_summary, save_report
    from sanicode.scoring.runner import run_scoring

    # Resolve scoring directory
    resolved_scoring = scoring_dir if scoring_dir else repos_dir / "scoring"
    if not resolved_scoring.exists():
        console.print(
            f"[red]Error:[/red] Scoring directory not found: {resolved_scoring}"
        )
        raise typer.Exit(code=1)

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    console.print(f"Scoring against repos at [bold]{repos_dir}[/bold]")
    console.print(f"Ground truth from [bold]{resolved_scoring}[/bold]")
    if no_llm_judge:
        console.print("[dim]LLM judge disabled — mechanical scoring only[/dim]")

    report = run_scoring(
        repos_dir=repos_dir.resolve(),
        scoring_dir=resolved_scoring.resolve(),
        output_dir=output_dir.resolve(),
        cfg=cfg,
        repos_filter=repos if repos else None,
        skip_llm_judge=no_llm_judge,
    )

    # Print summary to terminal
    console.print()
    console.print(generate_summary(report))

    # Save JSON report
    json_path = save_report(report, output_dir.resolve())
    console.print()
    console.print(f"[green]Report saved to[/green] [bold]{json_path}[/bold]")


@app.command()
def benchmark(
    corpus_dir: Path | None = typer.Argument(
        None, help="Path to benchmark corpus directory (default: bundled)."
    ),
    tools: list[str] = typer.Option(
        ["sanicode"], "--tool", "-t",
        help="Tools to benchmark. Repeatable. Choices: sanicode, bandit, semgrep.",
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Save raw results to this JSON file."
    ),
) -> None:
    """Run benchmarks comparing sanicode against other security tools."""
    from sanicode.benchmarks.runner import (
        bundled_corpus_dir,
        bundled_ground_truth_path,
        compare_results,
        load_ground_truth,
        run_bandit_benchmark,
        run_sanicode_benchmark,
        run_semgrep_benchmark,
    )

    resolved_corpus = (corpus_dir or bundled_corpus_dir()).resolve()
    if not resolved_corpus.exists():
        console.print(f"[red]Error:[/red] Corpus directory not found: {resolved_corpus}")
        raise typer.Exit(code=1)

    ground_truth_path = bundled_ground_truth_path()
    if not ground_truth_path.exists():
        console.print(f"[red]Error:[/red] Ground truth file not found: {ground_truth_path}")
        raise typer.Exit(code=1)

    ground_truth = load_ground_truth(ground_truth_path)
    console.print(
        f"Corpus: [bold]{resolved_corpus}[/bold] "
        f"({len(ground_truth)} files in ground truth)"
    )

    valid_tools = {"sanicode", "bandit", "semgrep"}
    invalid = set(tools) - valid_tools
    if invalid:
        console.print(
            f"[red]Error:[/red] Unknown tool(s): {', '.join(sorted(invalid))}. "
            f"Valid choices: {', '.join(sorted(valid_tools))}"
        )
        raise typer.Exit(code=1)

    all_results: dict = {}

    if "sanicode" in tools:
        console.print("Running [bold]sanicode[/bold] ...")
        all_results["sanicode"] = run_sanicode_benchmark(resolved_corpus, ground_truth)

    if "bandit" in tools:
        console.print("Running [bold]bandit[/bold] ...")
        all_results["bandit"] = run_bandit_benchmark(resolved_corpus, ground_truth)
        if not all_results["bandit"]:
            console.print("[yellow]  bandit not installed — skipped[/yellow]")

    if "semgrep" in tools:
        console.print("Running [bold]semgrep[/bold] ...")
        all_results["semgrep"] = run_semgrep_benchmark(resolved_corpus, ground_truth)
        if not all_results["semgrep"]:
            console.print("[yellow]  semgrep not installed — skipped[/yellow]")

    console.print()
    console.print(compare_results(all_results))

    if output:
        import dataclasses as _dc
        import json as _json
        serializable = {
            tool: [_dc.asdict(r) for r in res]
            for tool, res in all_results.items()
        }
        output.write_text(_json.dumps(serializable, indent=2), encoding="utf-8")
        console.print(f"[green]Results saved to[/green] [bold]{output}[/bold]")


def main() -> None:
    """Entrypoint wrapper required by the pyproject.toml script declaration."""
    app()
