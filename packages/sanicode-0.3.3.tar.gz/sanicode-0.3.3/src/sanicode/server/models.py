"""Pydantic request/response schemas for the Sanicode API."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class ScanStatus(str, Enum):
    """Lifecycle status of an asynchronous scan job."""

    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"


class ScanRequest(BaseModel):
    """POST /api/v1/scan — submit a new scan."""

    path: str = Field(..., description="Path to the codebase to scan.")
    config_path: str | None = Field(None, description="Optional path to sanicode.toml.")


class ScanSubmitResponse(BaseModel):
    """Response from POST /api/v1/scan."""

    scan_id: str
    status: ScanStatus


class ScanStatusResponse(BaseModel):
    """Response from GET /api/v1/scan/{id}."""

    scan_id: str
    status: ScanStatus
    target_path: str
    summary: dict | None = None
    error: str | None = None


class FindingsResponse(BaseModel):
    """Response from GET /api/v1/scan/{id}/findings."""

    scan_id: str
    findings: list[dict]
    total: int


class GraphResponse(BaseModel):
    """Response from GET /api/v1/scan/{id}/graph."""

    scan_id: str
    nodes: int
    edges: int
    graph: dict


class AnalyzeRequest(BaseModel):
    """POST /api/v1/analyze — synchronous snippet analysis."""

    code: str = Field(..., description="Python source code to analyze.")
    filename: str = Field("snippet.py", description="Virtual filename for findings.")


class AnalyzeResponse(BaseModel):
    """Response from POST /api/v1/analyze."""

    filename: str
    findings: list[dict]
    total: int


class HealthResponse(BaseModel):
    """Response from GET /api/v1/health."""

    status: str
    version: str
    llm_tiers: dict[str, str]
