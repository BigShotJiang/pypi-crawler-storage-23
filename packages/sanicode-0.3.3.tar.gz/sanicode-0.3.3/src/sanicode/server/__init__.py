"""Server subpackage — FastAPI application for remote/hybrid scan mode."""

from sanicode.server.app import app as app
from sanicode.server.app import configure as configure
