"""Version information for sanicode."""

__version__ = "0.3.3"
