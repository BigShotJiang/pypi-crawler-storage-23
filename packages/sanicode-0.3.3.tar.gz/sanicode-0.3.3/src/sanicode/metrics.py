"""Centralized Prometheus metrics for Sanicode.

All metric objects are defined here to avoid circular imports — the LLM
client, scan executor, and FastAPI server all record metrics by importing
from this module.  The /metrics endpoint uses make_asgi_app() which picks
up every metric registered on the default CollectorRegistry automatically.
"""

from prometheus_client import Counter, Gauge, Histogram

# ---------------------------------------------------------------------------
# Scan metrics
# ---------------------------------------------------------------------------

SCANS_TOTAL = Counter(
    "sanicode_scans_total",
    "Total scan jobs submitted",
    ["profile", "status"],
)

SCAN_DURATION = Histogram(
    "sanicode_scan_duration_seconds",
    "Scan duration in seconds",
    ["profile", "llm_tier"],
)

ACTIVE_SCANS = Gauge(
    "sanicode_scans_in_progress",
    "Number of currently running scans",
)

# ---------------------------------------------------------------------------
# Finding metrics
# ---------------------------------------------------------------------------

FINDINGS_TOTAL = Counter(
    "sanicode_findings_total",
    "Total findings detected",
    ["severity", "cwe_id", "namespace"],
)

FINDINGS_BY_CATEGORY = Gauge(
    "sanicode_findings_by_category",
    "Findings grouped by category",
    ["category", "namespace"],
)

FINDINGS_RESOLVED_TOTAL = Counter(
    "sanicode_findings_resolved_total",
    "Total findings resolved (Phase 3)",
)

FINDINGS_REGRESSED_TOTAL = Counter(
    "sanicode_findings_regressed_total",
    "Total findings regressed (Phase 3)",
)

EXCEPTIONS_ACTIVE = Gauge(
    "sanicode_exceptions_active",
    "Active SanicodeException CRs (Phase 3)",
)

# ---------------------------------------------------------------------------
# Compliance metrics
# ---------------------------------------------------------------------------

COMPLIANCE_SCORE = Gauge(
    "sanicode_compliance_score",
    "Compliance score (0-100, higher is better)",
    ["profile", "namespace"],
)

CONTROLS_PASSING = Gauge(
    "sanicode_controls_passing",
    "Number of passing compliance controls",
    ["framework"],
)

CONTROLS_FAILING = Gauge(
    "sanicode_controls_failing",
    "Number of failing compliance controls",
    ["framework"],
)

# ---------------------------------------------------------------------------
# LLM metrics
# ---------------------------------------------------------------------------

LLM_REQUESTS_TOTAL = Counter(
    "sanicode_llm_requests_total",
    "Total LLM requests",
    ["model", "tier"],
)

LLM_REQUEST_DURATION = Histogram(
    "sanicode_llm_request_duration_seconds",
    "LLM request duration in seconds",
    ["tier"],
)

LLM_ERRORS_TOTAL = Counter(
    "sanicode_llm_errors_total",
    "Total LLM errors",
    ["model", "error_type"],
)

LLM_TOKENS_CONSUMED = Counter(
    "sanicode_llm_tokens_consumed_total",
    "Total LLM tokens consumed",
    ["tier", "direction"],
)

# ---------------------------------------------------------------------------
# Knowledge graph metrics
# ---------------------------------------------------------------------------

GRAPH_NODES_TOTAL = Gauge(
    "sanicode_graph_nodes_total",
    "Number of knowledge graph nodes",
    ["type"],
)

GRAPH_EDGES_TOTAL = Gauge(
    "sanicode_graph_edges_total",
    "Number of knowledge graph edges",
)

GRAPH_BUILD_DURATION = Histogram(
    "sanicode_graph_build_duration_seconds",
    "Knowledge graph build duration in seconds",
)

# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------

ANALYZE_TOTAL = Counter(
    "sanicode_analyze_total",
    "Total snippet analysis requests",
)
