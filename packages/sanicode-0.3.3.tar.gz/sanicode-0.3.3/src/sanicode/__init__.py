"""Sanicode — AI-assisted code sanitization scanner."""

from sanicode.version import __version__ as __version__
