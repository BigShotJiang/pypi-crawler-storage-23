"""Self-contained HTML security dashboard generator for sanicode.

Generates a single-file HTML report with an executive summary, compliance
posture, interactive charts (Chart.js), a filterable findings table, and an
optional Canvas 2D knowledge-graph visualization.  All CSS and JS are
inlined or loaded from CDNs so the file can be opened directly in a browser.
"""

from __future__ import annotations

import json

from sanicode.report.persist import ScanResult

# ---------------------------------------------------------------------------
# Severity weights — same as enrichment.py
# ---------------------------------------------------------------------------

_SEVERITY_WEIGHTS: dict[str, int] = {
    "critical": 25,
    "high": 10,
    "medium": 3,
    "low": 1,
    "info": 0,
}

_SEVERITY_ORDER: list[str] = ["critical", "high", "medium", "low", "info"]


# ---------------------------------------------------------------------------
# Data preparation helpers
# ---------------------------------------------------------------------------

def _compute_compliance_score(findings: list[dict]) -> float:
    """Compute a 0-100 compliance score from serialized findings."""
    penalty = 0
    for f in findings:
        sev = (f.get("derived_severity") or f.get("severity", "info")).lower()
        penalty += _SEVERITY_WEIGHTS.get(sev, 1)
    return max(0.0, 100.0 - penalty)


def _extract_compliance_posture(findings: list[dict]) -> dict:
    """Aggregate unique controls per compliance framework from findings."""
    owasp_ids: set[str] = set()
    owasp_levels: set[str] = set()
    nist_ids: set[str] = set()
    stig_ids: set[str] = set()
    stig_cats: set[str] = set()
    pci_ids: set[str] = set()

    for f in findings:
        comp = f.get("compliance")
        if not comp:
            continue
        for entry in comp.get("owasp_asvs", []):
            if isinstance(entry, dict):
                owasp_ids.add(entry.get("id", ""))
                owasp_levels.add(entry.get("level", ""))
            else:
                owasp_ids.add(str(entry))
        for ctrl in comp.get("nist_800_53", []):
            nist_ids.add(ctrl)
        for entry in comp.get("asd_stig", []):
            if isinstance(entry, dict):
                stig_ids.add(entry.get("id", ""))
                stig_cats.add(entry.get("cat", ""))
            else:
                stig_ids.add(str(entry))
        for ctrl in comp.get("pci_dss", []):
            pci_ids.add(ctrl)

    # Discard empty strings that may have slipped through
    owasp_ids.discard("")
    owasp_levels.discard("")
    nist_ids.discard("")
    stig_ids.discard("")
    stig_cats.discard("")
    pci_ids.discard("")

    return {
        "owasp_asvs": {
            "controls": sorted(owasp_ids),
            "levels": sorted(owasp_levels),
        },
        "nist_800_53": {
            "controls": sorted(nist_ids),
        },
        "asd_stig": {
            "controls": sorted(stig_ids),
            "categories": sorted(stig_cats),
        },
        "pci_dss": {
            "controls": sorted(pci_ids),
        },
    }


def _build_recommendations(findings: list[dict], limit: int = 5) -> list[dict]:
    """Produce top-N actionable recommendations grouped by CWE.

    Groups findings by CWE, sorts by highest severity then frequency,
    and returns the top ``limit`` entries.
    """
    groups: dict[int, list[dict]] = {}
    for f in findings:
        cwe = f.get("cwe_id", 0)
        groups.setdefault(cwe, []).append(f)

    recs: list[dict] = []
    for cwe_id, group in groups.items():
        # Use the highest severity in the group
        best_sev = "info"
        for f in group:
            sev = (f.get("derived_severity") or f.get("severity", "info")).lower()
            if _SEVERITY_ORDER.index(sev) < _SEVERITY_ORDER.index(best_sev):
                best_sev = sev
        recs.append({
            "cwe_id": cwe_id,
            "cwe_name": group[0].get("cwe_name", ""),
            "count": len(group),
            "severity": best_sev,
            "remediation": group[0].get("remediation", ""),
        })

    # Sort: severity rank ascending (critical first), then count descending
    recs.sort(key=lambda r: (_SEVERITY_ORDER.index(r["severity"]), -r["count"]))
    return recs[:limit]


def _prepare_report_data(result: ScanResult, graph_data: dict | None) -> dict:
    """Build the data dict injected into the HTML template as JSON."""
    findings = result.findings or []
    summary = result.summary or {}

    return {
        "meta": {
            "scanned_path": result.scanned_path,
            "scan_timestamp": result.scan_timestamp,
            "scan_id": result.scan_id,
            "sanicode_version": result.sanicode_version,
        },
        "summary": summary,
        "findings": findings,
        "compliance_score": _compute_compliance_score(findings),
        "compliance_posture": _extract_compliance_posture(findings),
        "recommendations": _build_recommendations(findings),
    }


# ---------------------------------------------------------------------------
# HTML template
#
# Uses str.format() with two placeholders: {report_json} and {graph_json}.
# All CSS/JS braces are doubled ({{ }}) to survive str.format().
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sanicode &mdash; Security Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
CYTOSCAPE_SCRIPTS
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #0d1117;
    color: #e0e0e0;
    line-height: 1.5;
  }}

  a {{ color: #4A90D9; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}

  /* ── header ── */
  .header {{
    background: #1a1a2e;
    border-bottom: 1px solid #30363d;
    padding: 16px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
  }}

  .header h1 {{
    font-size: 1.25rem;
    font-weight: 600;
    color: #4A90D9;
  }}

  .header-meta {{
    font-size: 0.78rem;
    color: #aaa;
    display: flex;
    gap: 18px;
    flex-wrap: wrap;
  }}

  .header-meta span {{
    white-space: nowrap;
  }}

  /* ── main content ── */
  .dashboard {{
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
  }}

  /* ── section headings ── */
  .section-title {{
    font-size: 1rem;
    font-weight: 600;
    color: #e0e0e0;
    margin: 32px 0 16px 0;
    padding-bottom: 6px;
    border-bottom: 1px solid #30363d;
  }}

  /* ── executive summary cards ── */
  .cards-row {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
  }}

  .card {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
  }}

  .card-label {{
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #aaa;
    margin-bottom: 8px;
  }}

  .card-value {{
    font-size: 2rem;
    font-weight: 700;
    line-height: 1.1;
  }}

  .card-sub {{
    font-size: 0.72rem;
    color: #aaa;
    margin-top: 6px;
  }}

  .score-green  {{ color: #2ed573; }}
  .score-yellow {{ color: #ffa502; }}
  .score-red    {{ color: #ff4757; }}

  /* ── charts row ── */
  .charts-row {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin-bottom: 24px;
  }}

  @media (max-width: 800px) {{
    .charts-row {{ grid-template-columns: 1fr; }}
  }}

  .chart-panel {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px;
  }}

  .chart-panel h3 {{
    font-size: 0.85rem;
    font-weight: 600;
    color: #e0e0e0;
    margin-bottom: 12px;
  }}

  .chart-container {{
    position: relative;
    height: 220px;
  }}

  /* ── compliance table ── */
  .compliance-table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 0.82rem;
    margin-bottom: 24px;
  }}

  .compliance-table th,
  .compliance-table td {{
    padding: 10px 14px;
    text-align: left;
    border-bottom: 1px solid #30363d;
  }}

  .compliance-table th {{
    background: #161b22;
    color: #aaa;
    text-transform: uppercase;
    font-size: 0.72rem;
    letter-spacing: 0.05em;
  }}

  .compliance-table td {{
    background: #0d1117;
    vertical-align: top;
  }}

  .tag {{
    display: inline-block;
    background: #1a1a2e;
    border: 1px solid #30363d;
    border-radius: 4px;
    padding: 2px 6px;
    margin: 2px;
    font-size: 0.72rem;
    white-space: nowrap;
  }}

  /* ── recommendations ── */
  .rec-list {{
    list-style: none;
    padding: 0;
    margin-bottom: 24px;
  }}

  .rec-item {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 14px 18px;
    margin-bottom: 8px;
    display: grid;
    grid-template-columns: auto 1fr auto;
    gap: 14px;
    align-items: start;
  }}

  .rec-severity {{
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    padding: 3px 8px;
    border-radius: 4px;
    white-space: nowrap;
  }}

  .sev-critical {{ background: #ff4757; color: #fff; }}
  .sev-high     {{ background: #ff6348; color: #fff; }}
  .sev-medium   {{ background: #ffa502; color: #1a1a2e; }}
  .sev-low      {{ background: #2ed573; color: #1a1a2e; }}
  .sev-info     {{ background: #70a1ff; color: #1a1a2e; }}

  .rec-body h4 {{
    font-size: 0.85rem;
    margin-bottom: 4px;
  }}

  .rec-body p {{
    font-size: 0.78rem;
    color: #aaa;
    margin: 0;
  }}

  .rec-count {{
    font-size: 0.78rem;
    color: #aaa;
    white-space: nowrap;
  }}

  /* ── findings table ── */
  .findings-controls {{
    display: flex;
    gap: 12px;
    margin-bottom: 12px;
    flex-wrap: wrap;
  }}

  .findings-controls select,
  .findings-controls input {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    color: #e0e0e0;
    padding: 6px 10px;
    font-size: 0.82rem;
  }}

  .findings-controls input {{
    flex: 1;
    min-width: 200px;
  }}

  .findings-table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 0.78rem;
    margin-bottom: 24px;
  }}

  .findings-table th {{
    background: #161b22;
    color: #aaa;
    text-transform: uppercase;
    font-size: 0.7rem;
    letter-spacing: 0.05em;
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid #30363d;
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
  }}

  .findings-table th:hover {{
    color: #e0e0e0;
  }}

  .findings-table td {{
    padding: 8px 12px;
    border-bottom: 1px solid #21262d;
    vertical-align: top;
  }}

  .findings-table tr.finding-row {{
    cursor: pointer;
  }}

  .findings-table tr.finding-row:hover {{
    background: #161b22;
  }}

  .findings-table tr.detail-row {{
    display: none;
  }}

  .findings-table tr.detail-row.open {{
    display: table-row;
  }}

  .findings-table tr.detail-row td {{
    background: #161b22;
    padding: 14px 20px;
    font-size: 0.78rem;
    color: #aaa;
  }}

  .detail-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px 24px;
  }}

  @media (max-width: 700px) {{
    .detail-grid {{ grid-template-columns: 1fr; }}
  }}

  .detail-grid dt {{
    font-size: 0.7rem;
    color: #4A90D9;
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }}

  .detail-grid dd {{
    margin: 0 0 6px 0;
    color: #e0e0e0;
  }}

  /* ── severity badges in table ── */
  .sev-badge {{
    display: inline-block;
    padding: 2px 7px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
  }}

  .sev-badge-critical {{ background: #ff4757; color: #fff; }}
  .sev-badge-high     {{ background: #ff6348; color: #fff; }}
  .sev-badge-medium   {{ background: #ffa502; color: #1a1a2e; }}
  .sev-badge-low      {{ background: #2ed573; color: #1a1a2e; }}
  .sev-badge-info     {{ background: #70a1ff; color: #1a1a2e; }}

  /* ── graph section ── */
  .graph-section {{
    margin-bottom: 24px;
  }}

  .graph-toolbar {{
    display: flex;
    justify-content: flex-end;
    margin-bottom: 8px;
  }}

  .graph-toolbar button {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    color: #e0e0e0;
    padding: 5px 12px;
    font-size: 0.78rem;
    cursor: pointer;
  }}

  .graph-toolbar button:hover {{
    background: #1a1a2e;
    border-color: #4A90D9;
  }}

  #graph-container {{
    position: relative;
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    height: 400px;
    overflow: hidden;
    transition: all 0.3s ease;
  }}

  #graph-container.fullscreen {{
    position: fixed;
    inset: 0;
    z-index: 100;
    height: 100vh;
    border-radius: 0;
  }}

  #graph-canvas {{
    display: block;
    width: 100%;
    height: 100%;
  }}

  /* graph overlay panels */
  .graph-legend {{
    position: absolute;
    top: 12px;
    left: 12px;
    background: rgba(22,27,34,0.92);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 12px 14px;
    font-size: 0.75rem;
    z-index: 2;
    backdrop-filter: blur(8px);
  }}

  .graph-legend h4 {{
    font-size: 0.78rem;
    margin-bottom: 8px;
    color: #e0e0e0;
    font-weight: 600;
  }}

  .legend-row {{
    display: flex;
    align-items: center;
    gap: 7px;
    margin: 4px 0;
    color: #aaa;
  }}

  .legend-swatch {{
    width: 12px;
    height: 12px;
    border-radius: 3px;
    flex-shrink: 0;
  }}

  .legend-line {{
    width: 20px;
    height: 0;
    flex-shrink: 0;
  }}

  .graph-stats {{
    position: absolute;
    top: 12px;
    right: 12px;
    background: rgba(22,27,34,0.92);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 12px 14px;
    font-size: 0.75rem;
    z-index: 2;
    backdrop-filter: blur(8px);
  }}

  .graph-stats h4 {{
    font-size: 0.78rem;
    margin-bottom: 8px;
    color: #e0e0e0;
    font-weight: 600;
  }}

  .stat-row {{
    display: flex;
    justify-content: space-between;
    gap: 16px;
    margin: 3px 0;
    color: #aaa;
  }}

  .stat-row span:last-child {{
    color: #c9d1d9;
    font-weight: 500;
  }}

  .graph-tooltip {{
    position: absolute;
    display: none;
    background: rgba(22,27,34,0.96);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 12px 16px;
    font-size: 0.75rem;
    z-index: 20;
    pointer-events: none;
    backdrop-filter: blur(8px);
    max-width: 300px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
  }}

  .graph-tooltip h4 {{
    color: #4A90D9;
    margin-bottom: 6px;
    font-size: 0.82rem;
  }}

  .graph-tooltip .meta {{
    color: #8b949e;
    line-height: 1.6;
  }}

  .graph-tooltip .meta span {{
    color: #c9d1d9;
  }}

  .kind-badge {{
    display: inline-block;
    padding: 1px 7px;
    border-radius: 10px;
    font-size: 0.68rem;
    font-weight: 600;
    margin-left: 4px;
  }}

  .kind-entry_point {{ background: #1a2e4a; color: #4A90D9; }}
  .kind-sink        {{ background: #4a1a1a; color: #D94A4A; }}
  .kind-sanitizer   {{ background: #1a4a1a; color: #4AD94A; }}
  .kind-import      {{ background: #2a2a2a; color: #999; }}

  .graph-info {{
    position: absolute;
    bottom: 12px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(22,27,34,0.85);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 6px 16px;
    font-size: 0.72rem;
    color: #8b949e;
    z-index: 2;
    white-space: nowrap;
    backdrop-filter: blur(8px);
  }}

  /* ── empty state ── */
  .empty-state {{
    text-align: center;
    padding: 48px 24px;
    color: #aaa;
    font-size: 0.9rem;
  }}

  .hidden {{ display: none !important; }}
</style>
</head>
<body>

<!-- ═══════════ A. Header ═══════════ -->
<div class="header">
  <h1>Sanicode &mdash; Security Dashboard</h1>
  <div class="header-meta" id="header-meta"></div>
</div>

<div class="dashboard">

<!-- ═══════════ B. Executive Summary Cards ═══════════ -->
<div class="cards-row" id="summary-cards"></div>

<!-- ═══════════ C. Charts ═══════════ -->
<div id="charts-section">
  <h2 class="section-title">Distribution</h2>
  <div class="charts-row">
    <div class="chart-panel">
      <h3>Severity Distribution</h3>
      <div class="chart-container"><canvas id="severity-chart"></canvas></div>
    </div>
    <div class="chart-panel">
      <h3>Top CWEs</h3>
      <div class="chart-container"><canvas id="cwe-chart"></canvas></div>
    </div>
  </div>
</div>

<!-- ═══════════ D. Compliance Posture ═══════════ -->
<div id="compliance-section">
  <h2 class="section-title">Compliance Posture</h2>
  <table class="compliance-table" id="compliance-table">
    <thead>
      <tr><th>Framework</th><th>Controls Triggered</th><th>Details</th></tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<!-- ═══════════ E. Recommendations ═══════════ -->
<div id="recommendations-section">
  <h2 class="section-title">Top Recommendations</h2>
  <ul class="rec-list" id="rec-list"></ul>
</div>

<!-- ═══════════ F. Findings Table ═══════════ -->
<div id="findings-section">
  <h2 class="section-title">Findings</h2>
  <div class="findings-controls">
    <select id="sev-filter">
      <option value="all">All Severities</option>
      <option value="critical">Critical</option>
      <option value="high">High</option>
      <option value="medium">Medium</option>
      <option value="low">Low</option>
      <option value="info">Info</option>
    </select>
    <input type="text" id="text-search" placeholder="Search findings...">
  </div>
  <table class="findings-table" id="findings-table">
    <thead>
      <tr>
        <th data-col="severity">Severity</th>
        <th data-col="location">File:Line</th>
        <th data-col="rule">Rule</th>
        <th data-col="cwe">CWE</th>
        <th data-col="message">Message</th>
        <th data-col="compliance">Compliance</th>
      </tr>
    </thead>
    <tbody id="findings-body"></tbody>
  </table>
</div>

<!-- ═══════════ G. Knowledge Graph (conditional) ═══════════ -->
GRAPH_SECTION_HTML

</div><!-- .dashboard -->

<script>
// ── injected data ────────────────────────────────────────────────────────
const R = {report_json};
const G = {graph_json};

const SEV_ORDER = ['critical','high','medium','low','info'];
const SEV_COLORS = {{
  critical: '#ff4757',
  high:     '#ff6348',
  medium:   '#ffa502',
  low:      '#2ed573',
  info:     '#70a1ff',
}};

// ── A. Header meta ──────────────────────────────────────────────────────
(function renderMeta() {{
  const m = R.meta || {{}};
  const el = document.getElementById('header-meta');
  const items = [
    ['Path', m.scanned_path],
    ['Date', m.scan_timestamp ? new Date(m.scan_timestamp).toLocaleString() : ''],
    ['Scan ID', m.scan_id],
    ['Version', m.sanicode_version],
  ];
  el.innerHTML = items
    .filter(([, v]) => v)
    .map(([k, v]) => '<span><strong>' + k + ':</strong> ' + escHtml(v) + '</span>')
    .join('');
}})();

// ── B. Summary cards ────────────────────────────────────────────────────
(function renderCards() {{
  const el = document.getElementById('summary-cards');
  const score = R.compliance_score != null ? R.compliance_score : 100;
  const scoreClass = score >= 80 ? 'score-green' : (score >= 50 ? 'score-yellow' : 'score-red');
  const summary = R.summary || {{}};
  const bySev = summary.by_severity || {{}};
  const critHigh = (bySev.critical || 0) + (bySev.high || 0);

  const graphNodes = summary.graph_nodes;
  const hasGraph = graphNodes != null;
  const graphText = hasGraph
    ? graphNodes + ' nodes / ' + (summary.graph_edges || 0) + ' edges'
    : 'N/A';
  const graphSub = hasGraph
    ? (summary.graph_entry_points || 0) + ' entry pts, '
      + (summary.graph_sinks || 0) + ' sinks, '
      + (summary.graph_sanitizers || 0) + ' sanitizers'
    : '';

  el.innerHTML =
    card('Compliance Score', Math.round(score), '/100', scoreClass) +
    card('Total Findings', summary.total_findings || 0, '') +
    card('Critical / High', critHigh, '',
      critHigh > 0 ? 'score-red' : 'score-green') +
    card('Knowledge Graph', graphText, graphSub);
}})();

function card(label, value, sub, cls) {{
  return '<div class="card">' +
    '<div class="card-label">' + escHtml(label) + '</div>' +
    '<div class="card-value ' + (cls || '') + '">' + escHtml(String(value)) + '</div>' +
    (sub ? '<div class="card-sub">' + escHtml(sub) + '</div>' : '') +
    '</div>';
}}

// ── C. Charts ───────────────────────────────────────────────────────────
(function renderCharts() {{
  const findings = R.findings || [];
  if (findings.length === 0) {{
    document.getElementById('charts-section').classList.add('hidden');
    return;
  }}

  // Severity chart
  const summary = R.summary || {{}};
  const bySev = summary.by_severity || {{}};
  const sevLabels = SEV_ORDER.filter(s => (bySev[s] || 0) > 0);
  const sevData = sevLabels.map(s => bySev[s] || 0);
  const sevColors = sevLabels.map(s => SEV_COLORS[s]);

  new Chart(document.getElementById('severity-chart'), {{
    type: 'bar',
    data: {{
      labels: sevLabels.map(s => s.charAt(0).toUpperCase() + s.slice(1)),
      datasets: [{{ data: sevData, backgroundColor: sevColors, borderWidth: 0 }}],
    }},
    options: {{
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{
          ticks: {{ color: '#aaa', stepSize: 1 }},
          grid: {{ color: '#21262d' }},
        }},
        y: {{
          ticks: {{ color: '#e0e0e0' }},
          grid: {{ display: false }},
        }},
      }},
    }},
  }});

  // CWE chart — top 10
  const byCwe = summary.by_cwe || {{}};
  const cweEntries = Object.entries(byCwe)
    .map(([id, count]) => {{
      const name = cweName(id, findings);
      return {{ label: 'CWE-' + id + (name ? ' (' + name + ')' : ''), count: count }};
    }})
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  new Chart(document.getElementById('cwe-chart'), {{
    type: 'bar',
    data: {{
      labels: cweEntries.map(e => e.label),
      datasets: [{{
        data: cweEntries.map(e => e.count),
        backgroundColor: '#4A90D9', borderWidth: 0,
      }}],
    }},
    options: {{
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{
          ticks: {{ color: '#aaa', stepSize: 1 }},
          grid: {{ color: '#21262d' }},
        }},
        y: {{
          ticks: {{ color: '#e0e0e0', font: {{ size: 11 }} }},
          grid: {{ display: false }},
        }},
      }},
    }},
  }});
}})();

function cweName(cweId, findings) {{
  for (const f of findings) {{
    if (String(f.cwe_id) === String(cweId) && f.cwe_name) return f.cwe_name;
  }}
  return '';
}}

// ── D. Compliance posture ───────────────────────────────────────────────
(function renderCompliance() {{
  const cp = R.compliance_posture || {{}};
  const tbody = document.querySelector('#compliance-table tbody');

  const rows = [
    {{
      name: 'OWASP ASVS',
      controls: (cp.owasp_asvs || {{}}).controls || [],
      details: ((cp.owasp_asvs || {{}}).levels || []).length
        ? 'Levels: ' + ((cp.owasp_asvs || {{}}).levels || []).join(', ')
        : '',
    }},
    {{
      name: 'NIST 800-53',
      controls: (cp.nist_800_53 || {{}}).controls || [],
      details: '',
    }},
    {{
      name: 'ASD STIG',
      controls: (cp.asd_stig || {{}}).controls || [],
      details: ((cp.asd_stig || {{}}).categories || []).length
        ? 'CAT levels: ' + ((cp.asd_stig || {{}}).categories || []).join(', ')
        : '',
    }},
    {{
      name: 'PCI DSS',
      controls: (cp.pci_dss || {{}}).controls || [],
      details: '',
    }},
  ];

  rows.forEach(r => {{
    const tr = document.createElement('tr');
    const tags = r.controls.length > 0
      ? r.controls.map(c => '<span class="tag">' + escHtml(c) + '</span>').join(' ')
      : '<span style="color:#666">None</span>';
    tr.innerHTML =
      '<td>' + escHtml(r.name) + '</td>' +
      '<td>' + tags + '</td>' +
      '<td>' + escHtml(r.details) + '</td>';
    tbody.appendChild(tr);
  }});
}})();

// ── E. Recommendations ──────────────────────────────────────────────────
(function renderRecommendations() {{
  const recs = R.recommendations || [];
  const el = document.getElementById('rec-list');
  if (recs.length === 0) {{
    document.getElementById('recommendations-section').classList.add('hidden');
    return;
  }}
  recs.forEach(r => {{
    const li = document.createElement('li');
    li.className = 'rec-item';
    li.innerHTML =
      '<span class="rec-severity sev-' + r.severity + '">' + escHtml(r.severity) + '</span>' +
      '<div class="rec-body">' +
        '<h4>CWE-' + r.cwe_id + (r.cwe_name ? ': ' + escHtml(r.cwe_name) : '') + '</h4>' +
        '<p>' + escHtml(r.remediation || 'No remediation guidance available.') + '</p>' +
      '</div>' +
      '<span class="rec-count">' + r.count + ' finding' + (r.count !== 1 ? 's' : '') + '</span>';
    el.appendChild(li);
  }});
}})();

// ── F. Findings table ───────────────────────────────────────────────────
const allFindings = R.findings || [];
let sortCol = null;
let sortAsc = true;

(function renderFindings() {{
  if (allFindings.length === 0) {{
    document.getElementById('findings-section').innerHTML =
      '<h2 class="section-title">Findings</h2>' +
      '<div class="empty-state">No findings detected. Your codebase looks clean.</div>';
    return;
  }}
  buildFindingsRows(allFindings);
}})();

function buildFindingsRows(findings) {{
  const tbody = document.getElementById('findings-body');
  tbody.innerHTML = '';

  findings.forEach((f, idx) => {{
    const sev = (f.derived_severity || f.severity || 'info').toLowerCase();
    const loc = escHtml(f.file || '') + ':' + (f.line || 0);
    const cweLabel = f.cwe_id ? 'CWE-' + f.cwe_id : '';

    // Compliance summary for the table cell
    const compParts = [];
    if (f.compliance) {{
      const c = f.compliance;
      if (c.owasp_asvs && c.owasp_asvs.length)
        compParts.push('ASVS');
      if (c.nist_800_53 && c.nist_800_53.length)
        compParts.push('NIST');
      if (c.asd_stig && c.asd_stig.length)
        compParts.push('STIG');
      if (c.pci_dss && c.pci_dss.length)
        compParts.push('PCI');
    }}
    const compCell = compParts.length ? compParts.join(', ') : '';

    // Main row
    const tr = document.createElement('tr');
    tr.className = 'finding-row';
    tr.dataset.sev = sev;
    tr.dataset.idx = idx;
    tr.innerHTML =
      '<td><span class="sev-badge sev-badge-' + sev + '">' + escHtml(sev) + '</span></td>' +
      '<td>' + loc + '</td>' +
      '<td>' + escHtml(f.rule_id || '') + '</td>' +
      '<td>' + escHtml(cweLabel) + '</td>' +
      '<td>' + escHtml(f.message || '') + '</td>' +
      '<td>' + escHtml(compCell) + '</td>';
    tbody.appendChild(tr);

    // Detail row (hidden until clicked)
    const detailTr = document.createElement('tr');
    detailTr.className = 'detail-row';
    detailTr.id = 'detail-' + idx;
    detailTr.innerHTML = '<td colspan="6">' + buildDetailHtml(f) + '</td>';
    tbody.appendChild(detailTr);

    tr.addEventListener('click', function() {{
      detailTr.classList.toggle('open');
    }});
  }});
}}

function buildDetailHtml(f) {{
  let html = '<dl class="detail-grid">';

  html += dt('File') + dd(f.file || '');
  html += dt('Line : Column') + dd((f.line || 0) + ' : ' + (f.column || 0));
  html += dt('Rule') + dd(f.rule_id || '');
  html += dt('Severity') + dd((f.derived_severity || f.severity || ''));
  const cweTxt = f.cwe_id
    ? 'CWE-' + f.cwe_id + (f.cwe_name ? ' \u2014 ' + f.cwe_name : '') : '';
  html += dt('CWE') + dd(cweTxt);
  html += dt('Message') + dd(f.message || '');

  if (f.compliance) {{
    const c = f.compliance;
    if (c.owasp_asvs && c.owasp_asvs.length) {{
      const ids = c.owasp_asvs.map(e => typeof e === 'object' ? (e.id + ' (L' + e.level + ')') : e);
      html += dt('OWASP ASVS') + dd(ids.join(', '));
    }}
    if (c.nist_800_53 && c.nist_800_53.length)
      html += dt('NIST 800-53') + dd(c.nist_800_53.join(', '));
    if (c.asd_stig && c.asd_stig.length) {{
      const ids = c.asd_stig.map(e => typeof e === 'object' ? (e.id + ' (CAT ' + e.cat + ')') : e);
      html += dt('ASD STIG') + dd(ids.join(', '));
    }}
    if (c.pci_dss && c.pci_dss.length)
      html += dt('PCI DSS') + dd(c.pci_dss.join(', '));
  }}

  if (f.remediation)
    html += dt('Remediation') + dd(f.remediation);

  html += '</dl>';
  return html;
}}

function dt(label) {{ return '<dt>' + escHtml(label) + '</dt>'; }}
function dd(value) {{ return '<dd>' + escHtml(String(value)) + '</dd>'; }}

// ── Filtering ───────────────────────────────────────────────────────────
document.getElementById('sev-filter').addEventListener('change', applyFilters);
document.getElementById('text-search').addEventListener('input', applyFilters);

function applyFilters() {{
  const sevVal = document.getElementById('sev-filter').value;
  const query = document.getElementById('text-search').value.toLowerCase().trim();
  const rows = document.querySelectorAll('#findings-body tr.finding-row');

  rows.forEach(tr => {{
    const idx = parseInt(tr.dataset.idx, 10);
    const f = allFindings[idx];
    const sev = (f.derived_severity || f.severity || 'info').toLowerCase();

    let visible = true;
    if (sevVal !== 'all' && sev !== sevVal) visible = false;
    if (query) {{
      const haystack = [
        f.file, f.rule_id, f.message, f.cwe_name,
        f.cwe_id ? 'CWE-' + f.cwe_id : '',
      ].join(' ').toLowerCase();
      if (haystack.indexOf(query) === -1) visible = false;
    }}

    tr.style.display = visible ? '' : 'none';
    // Also hide associated detail row when filtering
    const detail = document.getElementById('detail-' + idx);
    if (detail && !visible) {{
      detail.classList.remove('open');
      detail.style.display = 'none';
    }} else if (detail) {{
      detail.style.display = '';
    }}
  }});
}}

// ── Column sorting ──────────────────────────────────────────────────────
document.querySelectorAll('#findings-table th').forEach(th => {{
  th.addEventListener('click', function() {{
    const col = this.dataset.col;
    if (!col) return;
    if (sortCol === col) {{
      sortAsc = !sortAsc;
    }} else {{
      sortCol = col;
      sortAsc = true;
    }}

    const sorted = [...allFindings].sort((a, b) => {{
      const va = sortKey(a, col);
      const vb = sortKey(b, col);
      if (va < vb) return sortAsc ? -1 : 1;
      if (va > vb) return sortAsc ? 1 : -1;
      return 0;
    }});

    buildFindingsRows(sorted);
    applyFilters();
  }});
}});

function sortKey(f, col) {{
  switch (col) {{
    case 'severity':
      return SEV_ORDER.indexOf((f.derived_severity || f.severity || 'info').toLowerCase());
    case 'location':
      return (f.file || '') + ':' + String(f.line || 0).padStart(6, '0');
    case 'rule':
      return (f.rule_id || '').toLowerCase();
    case 'cwe':
      return f.cwe_id || 0;
    case 'message':
      return (f.message || '').toLowerCase();
    case 'compliance':
      return f.compliance ? 1 : 0;
    default:
      return '';
  }}
}}

// ── G. Knowledge Graph ──────────────────────────────────────────────────
GRAPH_INIT_JS

// ── Utilities ───────────────────────────────────────────────────────────
function escHtml(str) {{
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}}
</script>
</body>
</html>
"""

# ---------------------------------------------------------------------------
# Conditional HTML / JS fragments
# ---------------------------------------------------------------------------

_CYTOSCAPE_SCRIPTS = ""

_GRAPH_SECTION_HTML = """\
<div class="graph-section" id="graph-section">
  <h2 class="section-title">Knowledge Graph</h2>
  <div class="graph-toolbar">
    <button id="graph-fullscreen">Full Screen</button>
  </div>
  <div id="graph-container">
    <canvas id="graph-canvas"></canvas>
    <div class="graph-legend">
      <h4>Node Kind</h4>
      <div class="legend-row"><div class="legend-swatch" style="background:#4A90D9"></div>
        Entry Point</div>
      <div class="legend-row"><div class="legend-swatch" style="background:#D94A4A"></div>
        Sink</div>
      <div class="legend-row"><div class="legend-swatch" style="background:#4AD94A"></div>
        Sanitizer</div>
      <div class="legend-row"><div class="legend-swatch" style="background:#999"></div> Import</div>
      <div class="legend-row"><div class="legend-swatch" style="background:#666"></div> Other</div>
      <div style="margin-top:8px;border-top:1px solid #30363d;padding-top:6px;">
        <h4>Edge Confidence</h4>
        <div class="legend-row"><div class="legend-line" style="border-top:2px solid #555"></div>
          call_graph</div>
        <div class="legend-row"><div class="legend-line" style="border-top:2px dashed #555"></div>
          heuristic</div>
      </div>
    </div>
    <div class="graph-stats">
      <h4>Graph Stats</h4>
      <div id="graph-stats-content"></div>
    </div>
    <div class="graph-tooltip" id="graph-tooltip"></div>
    <div class="graph-info">Drag nodes to rearrange &middot; Scroll to zoom
      &middot; Click a node to highlight connections</div>
  </div>
</div>"""

_GRAPH_INIT_JS = """\
(function initGraph() {{
  if (!G) return;

  // ── Data ──
  const KIND_COLOR = {{
    entry_point: '#4A90D9',
    sink:        '#D94A4A',
    sanitizer:   '#4AD94A',
    'import':    '#999999',
    other:       '#666666',
  }};

  // Build adjacency for fan-in/fan-out
  const fanIn  = {{}};
  const fanOut = {{}};
  (G.nodes || []).forEach(n => {{ fanIn[n.id] = 0; fanOut[n.id] = 0; }});
  (G.links || []).forEach(e => {{
    fanOut[e.source] = (fanOut[e.source] || 0) + 1;
    fanIn[e.target]  = (fanIn[e.target]  || 0) + 1;
  }});

  // Cluster by source-file directory
  const clusterMap = {{}};
  (G.nodes || []).forEach(n => {{
    const f = n.file || '';
    const parts = f.replace(/\\\\/g, '/').split('/');
    const dir = parts.length > 1 ? parts.slice(0, -1).join('/') : '(root)';
    if (!clusterMap[dir]) clusterMap[dir] = [];
    clusterMap[dir].push(n.id);
  }});
  const clusterNames = Object.keys(clusterMap);
  const clusterColors = {{}};
  clusterNames.forEach((name, i) => {{
    const hue = (i * 137.508) % 360;
    clusterColors[name] = 'hsl(' + hue + ', 55%, 55%)';
  }});
  const nodeCluster = {{}};
  clusterNames.forEach((name, ci) => {{
    clusterMap[name].forEach(id => {{ nodeCluster[id] = ci; }});
  }});

  // Build simulation nodes
  const nodes = (G.nodes || []).map((n, i) => {{
    const kind = n.kind || 'other';
    const fi = fanIn[n.id] || 0;
    const fo = fanOut[n.id] || 0;
    const ci = nodeCluster[n.id] != null ? nodeCluster[n.id] : 0;
    const angle = (ci / Math.max(clusterNames.length, 1)) * Math.PI * 2 - Math.PI / 2;
    const members = clusterMap[clusterNames[ci]] || [];
    const mi = members.indexOf(n.id);
    const spread = 50 + members.length * 14;
    const subAngle = (mi / Math.max(members.length, 1)) * Math.PI * 2;
    const cx = Math.cos(angle) * 200;
    const cy = Math.sin(angle) * 200;
    return {{
      id: n.id,
      label: n.label || n.id || '',
      kind: kind,
      file: n.file || '',
      line: n.line || 0,
      func: n.func_name || n.function || '',
      fi: fi,
      fo: fo,
      ci: ci,
      x: cx + Math.cos(subAngle) * spread + (Math.random() - 0.5) * 20,
      y: cy + Math.sin(subAngle) * spread + (Math.random() - 0.5) * 20,
      vx: 0, vy: 0,
      r: Math.max(6, Math.sqrt(fi + fo) * 4 + 4),
      color: KIND_COLOR[kind] || KIND_COLOR.other,
    }};
  }});
  const nodeById = {{}};
  nodes.forEach(n => {{ nodeById[n.id] = n; }});

  const edges = (G.links || []).map((e, idx) => ({{
    id: e.id || ('e_' + idx),
    source: nodeById[e.source],
    target: nodeById[e.target],
    confidence: e.confidence || 'heuristic',
  }})).filter(e => e.source && e.target);

  // ── Canvas setup ──
  const container = document.getElementById('graph-container');
  const canvas = document.getElementById('graph-canvas');
  const gCtx = canvas.getContext('2d');
  let gW, gH, dpr;

  function resizeCanvas() {{
    const rect = container.getBoundingClientRect();
    dpr = window.devicePixelRatio || 1;
    gW = rect.width;
    gH = rect.height;
    canvas.width = gW * dpr;
    canvas.height = gH * dpr;
    canvas.style.width = gW + 'px';
    canvas.style.height = gH + 'px';
    gCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }}
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  let camX = 0, camY = 0, camScale = 1;

  function screenToWorld(sx, sy) {{
    const rect = container.getBoundingClientRect();
    const lx = sx - rect.left;
    const ly = sy - rect.top;
    return {{
      x: (lx - gW / 2) / camScale + camX,
      y: (ly - gH / 2) / camScale + camY,
    }};
  }}

  // ── Force simulation ──
  function simulate() {{
    const friction = 0.88;
    const alpha = 0.3;

    // Repulsion (O(n^2))
    for (let i = 0; i < nodes.length; i++) {{
      for (let j = i + 1; j < nodes.length; j++) {{
        let dx = nodes[j].x - nodes[i].x;
        let dy = nodes[j].y - nodes[i].y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1) d2 = 1;
        const f = 1200 / d2;
        const dist = Math.sqrt(d2);
        const fx = (dx / dist) * f;
        const fy = (dy / dist) * f;
        nodes[i].vx -= fx; nodes[i].vy -= fy;
        nodes[j].vx += fx; nodes[j].vy += fy;
      }}
    }}

    // Edge attraction
    for (const e of edges) {{
      const dx = e.target.x - e.source.x;
      const dy = e.target.y - e.source.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const f = (d - 80) * 0.008;
      const fx = (dx / d) * f;
      const fy = (dy / d) * f;
      e.source.vx += fx; e.source.vy += fy;
      e.target.vx -= fx; e.target.vy -= fy;
    }}

    // Cluster gravity
    const cc = {{}};
    for (const n of nodes) {{
      if (!cc[n.ci]) cc[n.ci] = {{ x: 0, y: 0, count: 0 }};
      cc[n.ci].x += n.x;
      cc[n.ci].y += n.y;
      cc[n.ci].count++;
    }}
    for (const k in cc) {{
      cc[k].x /= cc[k].count;
      cc[k].y /= cc[k].count;
    }}
    for (const n of nodes) {{
      const c = cc[n.ci];
      if (c) {{
        n.vx += (c.x - n.x) * 0.005;
        n.vy += (c.y - n.y) * 0.005;
      }}
    }}

    // Center gravity
    for (const n of nodes) {{
      n.vx -= n.x * 0.0005;
      n.vy -= n.y * 0.0005;
    }}

    // Integrate
    for (const n of nodes) {{
      if (n === gDragNode) continue;
      n.vx *= friction; n.vy *= friction;
      n.x += n.vx * alpha;
      n.y += n.vy * alpha;
    }}
  }}

  // ── Drawing ──
  let gSelectedNode = null;
  let gHoverNode = null;
  let gDragNode = null;
  let gIsDragging = false;
  let gIsPanning = false;
  let gLastMouse = null;

  function getNodeAt(sx, sy) {{
    const {{ x, y }} = screenToWorld(sx, sy);
    for (let i = nodes.length - 1; i >= 0; i--) {{
      const n = nodes[i];
      const dx = n.x - x, dy = n.y - y;
      if (dx * dx + dy * dy < (n.r + 4) * (n.r + 4)) return n;
    }}
    return null;
  }}

  function drawArrow(x1, y1, x2, y2, color, width, globalAlpha, dashed) {{
    const dx = x2 - x1, dy = y2 - y1;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len < 1) return;
    const ux = dx / len, uy = dy / len;
    const targetR = 8;
    const ex = x2 - ux * targetR, ey = y2 - uy * targetR;

    gCtx.save();
    gCtx.globalAlpha = globalAlpha;
    gCtx.strokeStyle = color;
    gCtx.lineWidth = width;
    if (dashed) gCtx.setLineDash([4, 3]);
    gCtx.beginPath();
    gCtx.moveTo(x1, y1);
    gCtx.lineTo(ex, ey);
    gCtx.stroke();
    if (dashed) gCtx.setLineDash([]);

    const headLen = 5 * width;
    gCtx.fillStyle = color;
    gCtx.beginPath();
    gCtx.moveTo(ex, ey);
    gCtx.lineTo(ex - ux * headLen - uy * headLen * 0.4, ey - uy * headLen + ux * headLen * 0.4);
    gCtx.lineTo(ex - ux * headLen + uy * headLen * 0.4, ey - uy * headLen - ux * headLen * 0.4);
    gCtx.closePath();
    gCtx.fill();
    gCtx.restore();
  }}

  function drawGraph() {{
    gCtx.clearRect(0, 0, gW, gH);
    gCtx.save();
    gCtx.translate(gW / 2, gH / 2);
    gCtx.scale(camScale, camScale);
    gCtx.translate(-camX, -camY);

    // Highlighted set
    const hlNodes = new Set();
    const hlEdges = new Set();
    if (gSelectedNode) {{
      hlNodes.add(gSelectedNode.id);
      for (const e of edges) {{
        if (e.source.id === gSelectedNode.id || e.target.id === gSelectedNode.id) {{
          hlNodes.add(e.source.id);
          hlNodes.add(e.target.id);
          hlEdges.add(e);
        }}
      }}
    }}

    // Cluster hulls
    const groups = {{}};
    for (const n of nodes) {{
      if (!groups[n.ci]) groups[n.ci] = [];
      groups[n.ci].push(n);
    }}
    for (const [ci, group] of Object.entries(groups)) {{
      if (group.length < 2) continue;
      const gcx = group.reduce((s, n) => s + n.x, 0) / group.length;
      const gcy = group.reduce((s, n) => s + n.y, 0) / group.length;
      let maxR = 0;
      for (const n of group) {{
        const d = Math.sqrt(Math.pow(n.x - gcx, 2) + Math.pow(n.y - gcy, 2)) + n.r + 20;
        if (d > maxR) maxR = d;
      }}
      const cName = clusterNames[ci] || '';
      const cColor = clusterColors[cName] || '#555';
      gCtx.save();
      gCtx.globalAlpha = 0.06;
      gCtx.fillStyle = cColor;
      gCtx.beginPath();
      gCtx.arc(gcx, gcy, maxR, 0, Math.PI * 2);
      gCtx.fill();
      gCtx.globalAlpha = 0.15;
      gCtx.strokeStyle = cColor;
      gCtx.lineWidth = 1;
      gCtx.setLineDash([4, 4]);
      gCtx.stroke();
      gCtx.setLineDash([]);
      gCtx.restore();

      // Cluster label
      gCtx.save();
      gCtx.globalAlpha = 0.35;
      gCtx.fillStyle = cColor;
      gCtx.font = 'bold 10px -apple-system, system-ui, sans-serif';
      gCtx.textAlign = 'center';
      const dirLabel = cName.split('/').pop() || cName;
      gCtx.fillText(dirLabel, gcx, gcy - maxR + 8);
      gCtx.restore();
    }}

    // Edges
    for (const e of edges) {{
      const isHL = hlEdges.has(e);
      const dimmed = gSelectedNode && !isHL;
      const a = dimmed ? 0.07 : (isHL ? 0.7 : 0.2);
      const w = e.confidence === 'call_graph' ? (isHL ? 2 : 1.2) : (isHL ? 1.5 : 0.8);
      const c = isHL ? e.source.color : '#30363d';
      const dashed = e.confidence !== 'call_graph';
      drawArrow(e.source.x, e.source.y, e.target.x, e.target.y, c, w, a, dashed);
    }}

    // Nodes
    for (const n of nodes) {{
      const dimmed = gSelectedNode && !hlNodes.has(n.id);
      const isSelected = n === gSelectedNode;
      const isHover = n === gHoverNode;

      gCtx.save();
      gCtx.globalAlpha = dimmed ? 0.15 : 1;

      if (isSelected && !dimmed) {{
        gCtx.shadowColor = n.color;
        gCtx.shadowBlur = 20;
      }}

      gCtx.fillStyle = n.color;
      gCtx.beginPath();
      gCtx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      gCtx.fill();

      gCtx.shadowBlur = 0;

      // Hover ring
      if (isHover && !dimmed) {{
        gCtx.strokeStyle = '#fff';
        gCtx.lineWidth = 1.5;
        gCtx.beginPath();
        gCtx.arc(n.x, n.y, n.r + 2, 0, Math.PI * 2);
        gCtx.stroke();
      }}

      // Label
      if (!dimmed || isSelected) {{
        const label = n.label.split('.').pop() || n.label;
        gCtx.fillStyle = dimmed ? 'rgba(139,148,158,0.4)' : '#e1e4e8';
        gCtx.font = (isSelected || isHover ? '600' : '400') +
          ' 9px -apple-system, system-ui, sans-serif';
        gCtx.textAlign = 'center';
        gCtx.fillText(label, n.x, n.y + n.r + 12);
      }}

      gCtx.restore();
    }}

    gCtx.restore();
  }}

  // ── Interactions ──
  canvas.addEventListener('mousedown', function(ev) {{
    const node = getNodeAt(ev.clientX, ev.clientY);
    if (node) {{
      gDragNode = node;
      gIsDragging = false;
    }} else {{
      gIsPanning = true;
    }}
    gLastMouse = {{ x: ev.clientX, y: ev.clientY }};
  }});

  canvas.addEventListener('mousemove', function(ev) {{
    const dx = ev.clientX - (gLastMouse ? gLastMouse.x : ev.clientX);
    const dy = ev.clientY - (gLastMouse ? gLastMouse.y : ev.clientY);

    if (gDragNode) {{
      gIsDragging = true;
      gDragNode.x += dx / camScale;
      gDragNode.y += dy / camScale;
      gDragNode.vx = 0; gDragNode.vy = 0;
    }} else if (gIsPanning) {{
      camX -= dx / camScale;
      camY -= dy / camScale;
    }}
    gLastMouse = {{ x: ev.clientX, y: ev.clientY }};

    // Hover detection
    const node = getNodeAt(ev.clientX, ev.clientY);
    gHoverNode = node;
    canvas.style.cursor = node ? 'grab' : (gIsPanning ? 'grabbing' : 'default');

    // Tooltip
    const tip = document.getElementById('graph-tooltip');
    if (node && tip) {{
      const kindBadge = '<span class="kind-badge kind-' + node.kind + '">' +
        node.kind.replace('_', ' ') + '</span>';
      const inEdges = edges.filter(function(e) {{ return e.target.id === node.id; }});
      const outEdges = edges.filter(function(e) {{ return e.source.id === node.id; }});

      let html = '<h4>' + escHtml(node.label) + ' ' + kindBadge + '</h4>';
      html += '<div class="meta">';
      if (node.file) html += '<strong>' + escHtml(node.file) +
        (node.line ? ':' + node.line : '') + '</strong><br>';
      if (node.func) html += 'Function: <span>' + escHtml(node.func) + '</span><br>';
      html += 'Fan in: <span>' + node.fi + '</span> &middot; Fan out: <span>' + node.fo + '</span>';
      if (outEdges.length) {{
        html += '<br><br><strong>Flows to:</strong><br>';
        outEdges.forEach(function(e) {{
          html += '&rarr; <span>' + escHtml(e.target.label) + '</span><br>';
        }});
      }}
      if (inEdges.length) {{
        html += '<br><strong>Flows from:</strong><br>';
        inEdges.forEach(function(e) {{
          html += '&larr; <span>' + escHtml(e.source.label) + '</span><br>';
        }});
      }}
      html += '</div>';
      tip.innerHTML = html;
      tip.style.display = 'block';

      const rect = container.getBoundingClientRect();
      let tx = ev.clientX - rect.left + 16;
      let ty = ev.clientY - rect.top + 16;
      if (tx + 300 > gW) tx = ev.clientX - rect.left - 310;
      if (ty + 200 > gH) ty = ev.clientY - rect.top - 200;
      tip.style.left = tx + 'px';
      tip.style.top = ty + 'px';
    }} else if (tip) {{
      tip.style.display = 'none';
    }}
  }});

  canvas.addEventListener('mouseup', function(ev) {{
    if (gDragNode && !gIsDragging) {{
      gSelectedNode = gSelectedNode === gDragNode ? null : gDragNode;
    }}
    gDragNode = null;
    gIsPanning = false;
    gIsDragging = false;
  }});

  canvas.addEventListener('wheel', function(ev) {{
    ev.preventDefault();
    const factor = ev.deltaY > 0 ? 0.92 : 1.08;
    camScale = Math.max(0.1, Math.min(8, camScale * factor));
  }}, {{ passive: false }});

  // ── Stats ──
  var statsEl = document.getElementById('graph-stats-content');
  if (statsEl) {{
    var entryPts = nodes.filter(function(n) {{ return n.kind === 'entry_point'; }}).length;
    var sinks = nodes.filter(function(n) {{ return n.kind === 'sink'; }}).length;
    var sanitizers = nodes.filter(function(n) {{ return n.kind === 'sanitizer'; }}).length;
    var imports = nodes.filter(function(n) {{ return n.kind === 'import'; }}).length;
    statsEl.innerHTML =
      '<div class="stat-row"><span>Nodes</span><span>' + nodes.length + '</span></div>' +
      '<div class="stat-row"><span>Edges</span><span>' + edges.length + '</span></div>' +
      '<div class="stat-row"><span>Entry points</span><span>' + entryPts + '</span></div>' +
      '<div class="stat-row"><span>Sinks</span><span>' + sinks + '</span></div>' +
      '<div class="stat-row"><span>Sanitizers</span><span>' + sanitizers + '</span></div>' +
      '<div class="stat-row"><span>Imports</span><span>' + imports + '</span></div>' +
      '<div class="stat-row"><span>Clusters</span><span>' + clusterNames.length + '</span></div>';
  }}

  // ── Fullscreen toggle ──
  var fsBtn = document.getElementById('graph-fullscreen');
  if (fsBtn) {{
    fsBtn.addEventListener('click', function() {{
      container.classList.toggle('fullscreen');
      var isFs = container.classList.contains('fullscreen');
      fsBtn.textContent = isFs ? 'Exit Full Screen' : 'Full Screen';
      setTimeout(resizeCanvas, 350);
    }});
  }}

  // ── Animation loop ──
  function graphLoop() {{
    simulate();
    drawGraph();
    requestAnimationFrame(graphLoop);
  }}
  graphLoop();
}})();"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_html(result: ScanResult, graph_data: dict | None = None) -> str:
    """Generate a self-contained HTML security dashboard from scan results.

    Produces a single HTML file with an executive summary, compliance posture
    table, interactive charts (Chart.js), a filterable findings table, and an
    optional Canvas 2D knowledge-graph visualization.

    Args:
        result: A ScanResult from a completed scan.
        graph_data: Optional knowledge-graph dict (NetworkX node-link format
            with ``edges="links"``).  When provided, a Canvas 2D graph
            visualization is included in the dashboard.

    Returns:
        A complete HTML document as a string.
    """
    report_data = _prepare_report_data(result, graph_data)
    report_json = json.dumps(report_data, indent=2, default=str)
    graph_json = json.dumps(graph_data, indent=2, default=str) if graph_data else "null"

    # Conditionally inject Cytoscape scripts and graph section
    if graph_data is not None:
        cytoscape_scripts = _CYTOSCAPE_SCRIPTS
        graph_section_html = _GRAPH_SECTION_HTML
        graph_init_js = _GRAPH_INIT_JS
    else:
        cytoscape_scripts = ""
        graph_section_html = ""
        graph_init_js = ""

    # Two-pass substitution: first replace structural placeholders that live
    # outside the {{ }}-escaped JS/CSS, then inject the JSON data.
    html = _HTML_TEMPLATE.replace("CYTOSCAPE_SCRIPTS", cytoscape_scripts)
    html = html.replace("GRAPH_SECTION_HTML", graph_section_html)
    html = html.replace("GRAPH_INIT_JS", graph_init_js)
    html = html.format(report_json=report_json, graph_json=graph_json)

    return html
