"""Compliance subpackage — cross-reference mapping for CWE, OWASP ASVS, NIST, ASD STIG."""
