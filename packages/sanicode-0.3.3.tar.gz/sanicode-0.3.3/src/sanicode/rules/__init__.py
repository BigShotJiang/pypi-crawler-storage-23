"""Rule registry with auto-discovery for sanicode pattern detection rules.

Rules are organized by language in subpackages (e.g. ``rules.python``,
``rules.javascript``). The registry discovers Rule subclasses automatically
by walking these subpackages.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from pathlib import Path

_log = logging.getLogger(__name__)


class RuleRegistry:
    """Discovers and indexes rules by language."""

    def __init__(self) -> None:
        self._rules: dict[str, list] = {}  # language -> [Rule, ...]
        self._by_id: dict[str, object] = {}  # rule_id -> Rule

    def register(self, rule) -> None:
        """Register a single Rule instance."""
        from sanicode.rules.base import Rule
        if not isinstance(rule, Rule):
            raise TypeError(f"Expected Rule instance, got {type(rule).__name__}")
        if rule.rule_id in self._by_id:
            existing = self._by_id[rule.rule_id]
            raise ValueError(
                f"Rule ID {rule.rule_id!r} already registered by "
                f"{type(existing).__name__}"
            )
        self._rules.setdefault(rule.language, []).append(rule)
        self._by_id[rule.rule_id] = rule

    def discover(self) -> None:
        """Walk rules subpackages and register all Rule subclasses found.

        Scans src/sanicode/rules/<lang>/ packages, imports each module,
        finds all Rule subclasses, instantiates and registers them.

        After discovering built-in Python rules, also loads any YAML-defined
        custom rules from the standard search locations (``rules/`` in cwd and
        ``~/.config/sanicode/rules/``).
        """
        from sanicode.rules.base import Rule

        rules_pkg_path = Path(__file__).parent
        for _lang_finder, lang_name, lang_is_pkg in pkgutil.iter_modules([str(rules_pkg_path)]):
            if not lang_is_pkg:
                continue
            # Skip non-language packages (like __pycache__)
            if lang_name.startswith("_"):
                continue

            lang_pkg_name = f"sanicode.rules.{lang_name}"
            try:
                lang_pkg = importlib.import_module(lang_pkg_name)
            except ImportError as exc:
                _log.warning("Failed to import rule package %s: %s", lang_pkg_name, exc)
                continue

            lang_pkg_path = Path(lang_pkg.__file__).parent
            for _mod_finder, mod_name, _mod_is_pkg in pkgutil.iter_modules([str(lang_pkg_path)]):
                if mod_name.startswith("_"):
                    continue
                full_mod_name = f"{lang_pkg_name}.{mod_name}"
                try:
                    mod = importlib.import_module(full_mod_name)
                except ImportError as exc:
                    _log.warning("Failed to import rule module %s: %s", full_mod_name, exc)
                    continue

                for attr_name in dir(mod):
                    obj = getattr(mod, attr_name)
                    if (
                        isinstance(obj, type)
                        and issubclass(obj, Rule)
                        and obj is not Rule
                        and not getattr(obj, "__abstractmethods__", set())
                        and hasattr(obj, "rule_id")
                        and obj.rule_id  # skip base classes with no rule_id
                    ):
                        try:
                            instance = obj()
                            self.register(instance)
                        except Exception as exc:
                            _log.warning(
                                "Failed to register rule %s from %s: %s",
                                attr_name, full_mod_name, exc,
                            )

        # Discover YAML-defined custom rules from standard locations.
        from sanicode.rules.custom import discover_yaml_rules

        for rule in discover_yaml_rules():
            try:
                self.register(rule)
            except ValueError:
                _log.warning("Skipping duplicate YAML rule: %s", rule.rule_id)

    def rules_for(self, language: str) -> list:
        """Return all registered rules for a language."""
        return list(self._rules.get(language, []))

    def get_rule(self, rule_id: str):
        """Return a rule by its ID, or None."""
        return self._by_id.get(rule_id)

    def all_rules(self) -> list:
        """Return all registered rules across all languages."""
        result = []
        for rules in self._rules.values():
            result.extend(rules)
        return result

    def known_bad_patterns(self) -> dict[str, str]:
        """Build a KNOWN_BAD_PATTERNS-compatible dict from registered rules.

        Returns:
            Dict mapping rule_id -> human-readable message, matching the
            format of the legacy KNOWN_BAD_PATTERNS constant.
        """
        return {rule.rule_id: rule.message for rule in self.all_rules()}

    @property
    def languages(self) -> list[str]:
        """Return sorted list of languages with registered rules."""
        return sorted(self._rules.keys())


# Module-level singleton
_registry = RuleRegistry()


def get_rule_registry() -> RuleRegistry:
    """Return the global RuleRegistry singleton."""
    return _registry


def init_rules() -> None:
    """Discover and register all rules. Safe to call multiple times."""
    if not _registry.all_rules():
        _registry.discover()
