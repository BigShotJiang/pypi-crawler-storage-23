"""Base classes for sanicode pattern detection rules.

Provides:
- ``Rule`` — abstract base class all rules must extend
- ``CallRule`` — declarative helper for function-call-based detection rules
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.scanner.patterns import Finding, Severity

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin


class Rule(ABC):
    """Abstract base class for a single pattern detection rule."""

    rule_id: str = ""
    cwe_id: int = 0
    severity: Severity = "medium"
    language: str = ""
    message: str = ""

    @abstractmethod
    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        """Run this rule against a parsed tree-sitter tree.

        Args:
            tree: The parsed tree-sitter Tree.
            file_path: Path to the source file being checked.
            plugin: The language plugin (provides query helpers).

        Returns:
            List of Finding instances for any matches.
        """
        ...

    def _make_finding(self, node: Node, plugin: TreeSitterPlugin, file_path: Path) -> Finding:
        """Create a Finding from this rule's metadata and a matched node."""
        line, col = plugin.start_position(node)
        return Finding(
            file=file_path,
            line=line,
            column=col,
            rule_id=self.rule_id,
            message=self.message,
            severity=self.severity,
            cwe_id=self.cwe_id,
        )


def _dotted_name(node: Node) -> str:
    """Build a dotted name from a tree-sitter node.

    Handles identifier and attribute nodes, recursing for chained attributes.
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "attribute":
        obj = node.child_by_field_name("object")
        attr = node.child_by_field_name("attribute")
        if obj is None or attr is None:
            return ""
        prefix = _dotted_name(obj)
        suffix = attr.text.decode("utf-8") if attr.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def _has_keyword(call_node: Node, name: str, value: str | None = None) -> bool:
    """Check whether a call node has a keyword argument with the given name.

    If value is provided, also checks that the keyword's value text matches.
    """
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return False
    for child in args_node.children:
        if child.type == "keyword_argument":
            kw_name = child.child_by_field_name("name")
            kw_value = child.child_by_field_name("value")
            if kw_name and kw_name.text and kw_name.text.decode("utf-8") == name:
                if value is None:
                    return True
                if kw_value and kw_value.text:
                    return kw_value.text.decode("utf-8") == value
    return False


def _call_arguments(call_node: Node) -> list[Node]:
    """Return the positional argument nodes from a call expression."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ",", "keyword_argument", "dictionary_splat", "list_splat"):
            continue
        results.append(child)
    return results


def _is_formatted_sql(call_node: Node) -> bool:
    """Check if the first argument to a call shows string formatting.

    Detects f-strings, %-formatting, and .format() calls.
    """
    args = _call_arguments(call_node)
    if not args:
        return False
    first = args[0]

    if first.type == "string":
        for child in first.children:
            if child.type == "interpolation":
                return True

    if first.type == "concatenated_string":
        for child in first.children:
            if child.type == "string":
                for grandchild in child.children:
                    if grandchild.type == "interpolation":
                        return True

    if first.type == "binary_operator":
        op = first.child_by_field_name("operator")
        if op and op.text and op.text.decode("utf-8") == "%":
            return True

    if first.type == "call":
        func = first.child_by_field_name("function")
        if func and func.type == "attribute":
            attr = func.child_by_field_name("attribute")
            if attr and attr.text and attr.text.decode("utf-8") == "format":
                return True

    return False


def _walk(node: Node) -> list[Node]:
    """Depth-first walk of *node* and all its descendants."""
    result: list[Node] = [node]
    for child in node.children:
        result.extend(_walk(child))
    return result


class CallRule(Rule):
    """Declarative rule for detecting dangerous function calls.

    Subclasses set class attributes to describe what to match.
    The base class handles tree-sitter query execution and filtering.

    Class attributes:
        target_functions: Simple function names to match (e.g. {"eval", "exec"}).
        dotted_targets: Dotted names to match (e.g. {"os.system", "pickle.loads"}).
        check_identifier_only: If True, only match when func_node is an identifier
            (not an attribute). Default False.
        required_keywords: Dict of keyword args that must be present.
            Key is arg name, value is required value (or None for any value).
    """

    target_functions: frozenset[str] = frozenset()
    dotted_targets: frozenset[str] = frozenset()
    check_identifier_only: bool = False
    required_keywords: dict[str, str | None] = {}

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)

            # Check identifier-only targets
            if self.check_identifier_only and func_node.type != "identifier":
                if dotted not in self.dotted_targets:
                    continue

            # Match against targets
            matched = False
            if func_node.type == "identifier" and dotted in self.target_functions:
                matched = True
            elif dotted in self.dotted_targets:
                matched = True

            if not matched:
                continue

            # Check required keywords
            if self.required_keywords:
                all_kw_match = all(
                    _has_keyword(call_node, kw_name, kw_value)
                    for kw_name, kw_value in self.required_keywords.items()
                )
                if not all_kw_match:
                    continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
