"""Cross-site scripting detection rules (CWE-79).

Detects patterns that bypass HTML auto-escaping.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _call_arguments, _dotted_name
from sanicode.scanner.patterns import Finding


class MarkSafeRule(Rule):
    """Detect mark_safe() / Markup() with non-literal arguments.

    Both Django's ``mark_safe()`` and Jinja2/MarkupSafe's ``Markup()``
    bypass the framework's automatic HTML escaping.  Flagging calls where
    the argument is not a string literal catches the common pattern of
    passing user-controlled data directly.
    """

    rule_id = "SC009"
    cwe_id = 79
    severity = "high"
    language = "python"
    message = (
        "Use of mark_safe()/Markup() with non-literal argument \u2014 "
        "auto-escaping bypass, potential XSS (CWE-79)"
    )

    _TARGETS: frozenset[str] = frozenset({"mark_safe", "Markup"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            # Match bare name or fully-qualified name (e.g. django.utils.safestring.mark_safe)
            simple = dotted.rsplit(".", 1)[-1] if "." in dotted else dotted
            if simple not in self._TARGETS:
                continue

            # Only flag when the argument is not a plain string literal
            args = _call_arguments(call_node)
            if args and args[0].type == "string":
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
