"""Command injection detection rules (CWE-78).

Detects use of eval(), exec(), os.system(), and subprocess with shell=True.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import CallRule, Rule, _dotted_name, _has_keyword
from sanicode.scanner.patterns import Finding

_SUBPROCESS_FUNCS = frozenset({"call", "run", "Popen", "check_output", "check_call"})


class EvalRule(CallRule):
    rule_id = "SC001"
    cwe_id = 78
    severity = "critical"
    language = "python"
    message = "Use of eval() \u2014 arbitrary code execution via unsanitized input (CWE-78)"
    target_functions = frozenset({"eval"})
    check_identifier_only = True


class ExecRule(CallRule):
    rule_id = "SC002"
    cwe_id = 78
    severity = "high"
    language = "python"
    message = "Use of exec() \u2014 arbitrary code execution via unsanitized input (CWE-78)"
    target_functions = frozenset({"exec"})
    check_identifier_only = True


class OsSystemRule(CallRule):
    rule_id = "SC003"
    cwe_id = 78
    severity = "high"
    language = "python"
    message = "Use of os.system() \u2014 command injection risk (CWE-78)"
    dotted_targets = frozenset({"os.system"})


class SubprocessShellRule(Rule):
    """Detect subprocess calls with shell=True."""

    rule_id = "SC004"
    cwe_id = 78
    severity = "high"
    language = "python"
    message = "Use of subprocess with shell=True \u2014 command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "attribute":
                continue

            dotted = _dotted_name(func_node)
            if not dotted.startswith("subprocess."):
                continue

            attr = func_node.child_by_field_name("attribute")
            if (
                attr
                and attr.text
                and attr.text.decode("utf-8") in _SUBPROCESS_FUNCS
                and _has_keyword(call_node, "shell", "True")
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
