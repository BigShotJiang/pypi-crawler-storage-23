"""Hardcoded credential detection rules (CWE-798).

Detects string literals assigned to variables with secret-like names.
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Variable names that strongly suggest a secret value
_SECRET_PATTERN = re.compile(
    r"(password|passwd|secret|api_key|apikey|api_secret|token|auth_token|"
    r"access_key|private_key|credentials?|db_pass)",
    re.IGNORECASE,
)

# String values that are clearly placeholders, not real secrets
_PLACEHOLDER_VALUES: frozenset[str] = frozenset(
    {
        "",
        "changeme",
        "CHANGE_ME",
        "change_me",
        "placeholder",
        "PLACEHOLDER",
        "your_secret_here",
        "YOUR_SECRET_HERE",
    }
)


class HardcodedCredentialRule(Rule):
    """Detect string literals assigned to secret-named variables.

    This rule walks all assignment statements and flags those where the
    left-hand side looks like a secret variable name and the right-hand
    side is a non-empty, non-placeholder string literal.
    """

    rule_id = "SC012"
    cwe_id = 798
    severity = "high"
    language = "python"
    message = (
        "Hardcoded credential \u2014 secret value assigned to variable (CWE-798)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type not in ("assignment", "augmented_assignment"):
                continue

            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue

            # Only check simple identifier assignments (not subscripts, attributes, etc.)
            if left.type != "identifier":
                continue
            var_name = plugin.node_text(left)
            if not _SECRET_PATTERN.search(var_name):
                continue

            # Right-hand side must be a plain string literal
            if right.type != "string":
                continue

            value_text = plugin.node_text(right)
            # Strip surrounding quotes to inspect the inner value
            inner = value_text
            for q in ('"""', "'''", '"', "'"):
                if inner.startswith(q) and inner.endswith(q) and len(inner) > 2 * len(q):
                    inner = inner[len(q):-len(q)]
                    break
            else:
                # Single-character or malformed — skip
                inner = inner.strip("\"'")

            # Skip empty or placeholder values
            if not inner or inner in _PLACEHOLDER_VALUES or len(inner) < 3:
                continue

            findings.append(self._make_finding(node, plugin, file_path))

        return findings
