"""Insecure random number generation detection rules (CWE-330).

Detects use of the ``random`` module for security-sensitive operations.
The ``random`` module uses a Mersenne Twister PRNG, which is predictable
and must not be used for cryptographic purposes.  Use ``secrets`` instead.
"""

from __future__ import annotations

from sanicode.rules.base import CallRule


class InsecureRandomRule(CallRule):
    """Detect calls to the predictable ``random`` module.

    The ``random`` module is not suitable for generating security tokens,
    passwords, or any value that must be unpredictable.  Use the ``secrets``
    module for cryptographically secure random values.
    """

    rule_id = "SC014"
    cwe_id = 330
    severity = "medium"
    language = "python"
    message = (
        "Use of random module \u2014 not cryptographically secure, "
        "use the secrets module instead (CWE-330)"
    )
    dotted_targets: frozenset[str] = frozenset(
        {
            "random.random",
            "random.randint",
            "random.choice",
            "random.randrange",
            "random.uniform",
            "random.getrandbits",
            "random.shuffle",
            "random.sample",
        }
    )
