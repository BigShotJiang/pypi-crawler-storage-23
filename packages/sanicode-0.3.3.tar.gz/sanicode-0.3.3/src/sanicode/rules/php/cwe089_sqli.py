"""SQL injection detection rules for PHP (CWE-89)."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_SQL_FUNCS = frozenset({
    "mysql_query", "mysqli_query", "pg_query",
})


class PHPSqlInjectionRule(Rule):
    """Detect direct SQL query execution in PHP (CWE-89).

    Only flags calls where the SQL argument is dynamic (variable, interpolated
    string, concatenation, etc.).  A plain string literal is considered safe
    because it cannot carry user-controlled input.
    """

    rule_id = "SC103"
    cwe_id = 89
    severity = "high"
    language = "php"
    message = "Direct SQL query execution — potential SQL injection (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "function_call_expression":
                continue
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            name = plugin.node_text(func_node)
            if name not in _SQL_FUNCS:
                continue

            # Extract positional arguments from the call.
            args_node = node.child_by_field_name("arguments")
            if args_node is None:
                continue

            positional = []
            for child in args_node.children:
                if child.type == "argument":
                    for inner in child.children:
                        if inner.type not in ("(", ")", ","):
                            positional.append(inner)
                elif child.type not in ("(", ")", ","):
                    positional.append(child)

            if not positional:
                continue

            # mysqli_query($conn, $sql) — SQL is the second argument.
            sql_arg_idx = 1 if name == "mysqli_query" and len(positional) > 1 else 0
            sql_arg = positional[sql_arg_idx] if sql_arg_idx < len(positional) else None
            if sql_arg is None:
                continue

            # A plain string literal cannot carry user input.
            # PHP single-quoted strings are `string` nodes; double-quoted
            # strings without variable interpolation are `encapsed_string`
            # nodes whose children contain only `string_content` (no
            # `variable_name` grandchildren).
            if sql_arg.type == "string":
                continue
            if sql_arg.type == "encapsed_string":
                has_var = any(child.type == "variable_name" for child in sql_arg.children)
                if not has_var:
                    continue

            findings.append(self._make_finding(node, plugin, file_path))

        return findings
