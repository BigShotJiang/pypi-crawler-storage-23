"""Command injection and code execution detection rules for PHP (CWE-78, CWE-94)."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_COMMAND_FUNCS = frozenset({
    "system", "exec", "passthru", "shell_exec", "popen", "proc_open",
})


class PHPCommandInjectionRule(Rule):
    """Detect PHP command execution functions (CWE-78)."""

    rule_id = "SC101"
    cwe_id = 78
    severity = "critical"
    language = "php"
    message = "Use of command execution function — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        for node in _walk(root):
            if node.type != "function_call_expression":
                continue
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            name = func_node.text.decode("utf-8") if func_node.text else ""
            if name in _COMMAND_FUNCS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings


class PHPEvalRule(Rule):
    """Detect eval() in PHP (CWE-94)."""

    rule_id = "SC102"
    cwe_id = 94
    severity = "critical"
    language = "php"
    message = "Use of eval() — arbitrary code execution (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        for node in _walk(root):
            if node.type != "function_call_expression":
                continue
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            name = func_node.text.decode("utf-8") if func_node.text else ""
            if name == "eval":
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
