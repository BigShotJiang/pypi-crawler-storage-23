"""Cross-site scripting detection rules for PHP (CWE-79)."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Node types that indicate dynamic (non-literal) content in an echo statement.
_DYNAMIC_TYPES = frozenset({
    "variable_name",
    "member_access_expression",
    "subscript_expression",
    "function_call_expression",
    "encapsed_string",
})


def _echo_has_dynamic_content(echo_node) -> bool:
    """Return True if the echo statement contains any non-literal expression.

    An ``encapsed_string`` is flagged even if it has no variable interpolation
    because it is the most common vehicle for PHP string interpolation
    (``"Hello $name"``), and the parse tree for an ``encapsed_string`` without
    variables still contains a ``string_content`` child rather than a bare
    ``variable_name``.  We conservatively treat any ``variable_name``,
    ``member_access_expression``, ``subscript_expression``, or
    ``function_call_expression`` as dynamic; a plain ``encapsed_string`` with
    only ``string_content`` children is NOT flagged.
    """
    for child in echo_node.children:
        if child.type in ("echo", ";"):
            continue
        if child.type == "encapsed_string":
            # Flag only if the interpolated string contains a variable
            for inner in child.children:
                if inner.type == "variable_name":
                    return True
        elif child.type in (
            "variable_name",
            "member_access_expression",
            "subscript_expression",
            "function_call_expression",
        ):
            return True
    return False


class PHPEchoRule(Rule):
    """Detect echo/print with dynamic (variable) output — potential XSS."""

    rule_id = "SC105"
    cwe_id = 79
    severity = "medium"
    language = "php"
    message = "echo/print with variable output — potential XSS without escaping (CWE-79)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        for node in _walk(root):
            if node.type == "echo_statement" and _echo_has_dynamic_content(node):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
