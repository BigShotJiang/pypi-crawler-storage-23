"""Command injection and code execution detection rules for JavaScript (CWE-78/94).

SC201 — eval()                         critical  CWE-78
SC202 — new Function()                 critical  CWE-94
SC203 — child_process.exec/spawn       high      CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding

_EXEC_FUNCS = frozenset(
    {
        "child_process.exec",
        "child_process.execSync",
        "child_process.spawn",
        "child_process.spawnSync",
    }
)


class JSEvalRule(Rule):
    """Detect eval() calls in JavaScript — arbitrary code execution."""

    rule_id = "SC201"
    cwe_id = 78
    severity = "critical"
    language = "javascript"
    message = "Use of eval() — arbitrary code execution (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if func_node.type == "identifier":
                name = plugin.node_text(func_node)
                if name == "eval":
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JSNewFunctionRule(Rule):
    """Detect ``new Function()`` constructor — dynamic code generation."""

    rule_id = "SC202"
    cwe_id = 94
    severity = "critical"
    language = "javascript"
    message = "Use of new Function() — dynamic code generation (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type == "new_expression":
                constructor = node.child_by_field_name("constructor")
                if constructor and constructor.type == "identifier":
                    name = plugin.node_text(constructor)
                    if name == "Function":
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings


class JSChildProcessExecRule(Rule):
    """Detect child_process.exec() and related APIs — command injection."""

    rule_id = "SC203"
    cwe_id = 78
    severity = "high"
    language = "javascript"
    message = "Use of child_process.exec/spawn — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) in _EXEC_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
