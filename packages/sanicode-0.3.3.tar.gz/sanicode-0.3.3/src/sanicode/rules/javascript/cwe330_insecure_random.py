"""Insecure random number generation for JavaScript (CWE-330).

SC210 — Math.random()    medium  CWE-330
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding


class JSInsecureRandomRule(Rule):
    """Detect Math.random() — not cryptographically secure."""

    rule_id = "SC210"
    cwe_id = 330
    severity = "medium"
    language = "javascript"
    message = "Use of Math.random() — not cryptographically secure (CWE-330)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) == "Math.random":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
