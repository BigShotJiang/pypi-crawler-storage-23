"""Weak cryptography detection rules for JavaScript (CWE-327).

SC209 — crypto.createHash() with MD5 or SHA1    medium  CWE-327
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_WEAK_ALGORITHMS = frozenset({"md5", "sha1", "sha-1"})

_CREATE_HASH = "crypto.createHash"


def _strip_quotes(s: str) -> str:
    for q in ('"""', "'''", "`", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q):-len(q)]
    return s


class JSWeakCryptoRule(Rule):
    """Detect crypto.createHash() with MD5 or SHA1 — weak hash algorithm."""

    rule_id = "SC209"
    cwe_id = 327
    severity = "medium"
    language = "javascript"
    message = "Use of weak hash algorithm (MD5/SHA1) — unsuitable for security (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            if js_dotted_name(func_node) != _CREATE_HASH:
                continue

            args = js_call_arguments(call_node)
            if not args or args[0].type != "string":
                continue

            algo = _strip_quotes(plugin.node_text(args[0])).lower()
            if algo in _WEAK_ALGORITHMS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
