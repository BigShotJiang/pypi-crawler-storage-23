"""Path traversal detection rules for JavaScript (CWE-22).

SC207 — fs.*() with variable path argument    high  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_FS_FUNCS = frozenset(
    {
        "fs.readFile",
        "fs.readFileSync",
        "fs.writeFile",
        "fs.writeFileSync",
        "fs.readdir",
        "fs.readdirSync",
        "fs.unlink",
        "fs.unlinkSync",
        "fs.stat",
        "fs.statSync",
        "fs.access",
        "fs.accessSync",
    }
)

# Node types that are always literal (never dynamic).
_LITERAL_TYPES = frozenset({"string"})


class JSFsPathTraversalRule(Rule):
    """Detect fs.* calls where the path argument is a variable — path traversal risk."""

    rule_id = "SC207"
    cwe_id = 22
    severity = "high"
    language = "javascript"
    message = "File system operation with variable path — potential path traversal (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            if js_dotted_name(func_node) not in _FS_FUNCS:
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue

            # Only flag non-literal paths; a plain string literal is safe.
            first_arg = args[0]
            if first_arg.type in _LITERAL_TYPES:
                continue
            # A template literal without substitutions is also a safe constant.
            if first_arg.type == "template_string":
                has_substitution = any(
                    child.type == "template_substitution"
                    for child in first_arg.children
                )
                if not has_substitution:
                    continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
