"""Hardcoded credential detection for JavaScript (CWE-798).

SC208 — string literal assigned to a secret-named variable    high  CWE-798
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_SECRET_PATTERN = re.compile(
    r"(password|passwd|secret|api_key|apikey|api_secret|token|auth_token|"
    r"access_key|private_key|credentials?|db_pass)",
    re.IGNORECASE,
)

# Known placeholder values that should not trigger the rule.
_PLACEHOLDERS = frozenset({"changeme", "change_me", "placeholder", "todo", "fixme", ""})

_MIN_SECRET_LEN = 3


def _is_placeholder(value: str) -> bool:
    return value.lower() in _PLACEHOLDERS


def _strip_quotes(s: str) -> str:
    """Remove surrounding quote characters from a JS string literal."""
    for q in ('"""', "'''", "`", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q):-len(q)]
    return s


class JSHardcodedCredentialRule(Rule):
    """Detect hardcoded credentials in JS variable declarations and assignments."""

    rule_id = "SC208"
    cwe_id = 798
    severity = "high"
    language = "javascript"
    message = "Hardcoded credential — secret value in variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type == "variable_declarator":
                findings.extend(self._check_declarator(node, plugin, file_path))
            elif node.type == "assignment_expression":
                findings.extend(self._check_assignment(node, plugin, file_path))

        return findings

    def _check_declarator(self, node, plugin, file_path: Path) -> list[Finding]:
        """Handle: const/let/var <name> = "<value>"."""
        name_node = node.child_by_field_name("name")
        value_node = node.child_by_field_name("value")
        if name_node is None or value_node is None:
            return []

        var_name = plugin.node_text(name_node)
        if not _SECRET_PATTERN.search(var_name):
            return []

        if value_node.type != "string":
            return []

        inner = _strip_quotes(plugin.node_text(value_node))
        if len(inner) < _MIN_SECRET_LEN or _is_placeholder(inner):
            return []

        return [self._make_finding(node, plugin, file_path)]

    def _check_assignment(self, node, plugin, file_path: Path) -> list[Finding]:
        """Handle: <name> = "<value>" (bare assignment, not declaration)."""
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if left is None or right is None:
            return []

        if left.type != "identifier":
            return []

        var_name = plugin.node_text(left)
        if not _SECRET_PATTERN.search(var_name):
            return []

        if right.type != "string":
            return []

        inner = _strip_quotes(plugin.node_text(right))
        if len(inner) < _MIN_SECRET_LEN or _is_placeholder(inner):
            return []

        return [self._make_finding(node, plugin, file_path)]
