"""LLM subpackage — multi-provider LLM client via LiteLLM."""
