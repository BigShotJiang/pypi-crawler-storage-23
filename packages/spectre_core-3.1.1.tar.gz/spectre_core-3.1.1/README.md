# spectre-core

## Description
Contains server-side implementations for [_Spectre_](https://github.com/jcfitzpatrick12/spectre.git).

**⚠️ Note:**  
This repository is not intended for direct consumption.

## Contributing
If you'd like to raise an issue, or want to make a change, please refer to the _Contributing_ section in the [README](https://github.com/jcfitzpatrick12/spectre/blob/main/README.md) for _Spectre_.