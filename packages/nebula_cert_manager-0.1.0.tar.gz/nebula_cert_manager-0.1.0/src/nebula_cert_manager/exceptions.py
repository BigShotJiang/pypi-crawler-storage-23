class CertManagerError(Exception):
    """Base exception for nebula-cert-manager."""


class RegistryExistsError(CertManagerError):
    """Registry already exists."""

    def __init__(self, msg: str = "Registry already exists.") -> None:
        super().__init__(msg)


class RegistryNotFoundError(CertManagerError):
    """Registry not found."""

    def __init__(
        self, msg: str = "Registry not found. Run 'init' or 'import-ca' first."
    ) -> None:
        super().__init__(msg)


class ConfigError(CertManagerError):
    """nebula.config.yml missing or invalid."""

    def __init__(self, msg: str = "nebula.config.yml is missing or invalid.") -> None:
        super().__init__(msg)


class HostNotFoundError(CertManagerError):
    """Host not found in nebula.config.yml."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Host '{name}' not found in nebula.config.yml hosts section.")


class CertNotFoundError(CertManagerError):
    """Certificate not found by fingerprint or no active cert."""

    def __init__(
        self, *, fingerprint: str | None = None, name: str | None = None
    ) -> None:
        self.fingerprint = fingerprint
        self.name = name
        if fingerprint:
            msg = f"Certificate with fingerprint '{fingerprint}' not found."
        elif name:
            msg = f"No active certificate found for '{name}'."
        else:
            msg = "Certificate not found."
        super().__init__(msg)


class CertAlreadyRevokedError(CertManagerError):
    """Certificate is already revoked."""

    def __init__(self, name: str, fingerprint: str) -> None:
        self.name = name
        self.fingerprint = fingerprint
        super().__init__(f"Certificate '{name}' ({fingerprint}) is already revoked.")


class FingerprintMismatchError(CertManagerError):
    """Fingerprint belongs to a different host than expected."""

    def __init__(self, fingerprint: str, expected_name: str, actual_name: str) -> None:
        self.fingerprint = fingerprint
        self.expected_name = expected_name
        self.actual_name = actual_name
        super().__init__(
            f"Fingerprint '{fingerprint}' belongs to '{actual_name}', not '{expected_name}'."
        )
