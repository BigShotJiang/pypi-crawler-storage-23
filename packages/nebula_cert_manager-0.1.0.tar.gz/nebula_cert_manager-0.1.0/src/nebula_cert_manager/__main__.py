from nebula_cert_manager.cli import main

main()
