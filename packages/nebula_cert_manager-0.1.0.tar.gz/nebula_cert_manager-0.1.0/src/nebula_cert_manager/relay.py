from nebula_cert_manager.models import HostsConfig


def resolve_relay_for_host(
    client_name: str, hosts_config: HostsConfig
) -> tuple[bool, list[str]]:
    host = hosts_config.hosts.get(client_name)
    am_relay = host.am_relay if host is not None else False

    relay_names: list[str] | None = None
    if host is not None and host.relays is not None:
        relay_names = host.relays
    elif hosts_config.defaults.relays is not None:
        relay_names = hosts_config.defaults.relays

    if relay_names is None:
        return am_relay, []

    relay_ips: list[str] = []
    for name in relay_names:
        if name == client_name:
            continue
        relay_host = hosts_config.hosts.get(name)
        if relay_host is not None:
            relay_ips.append(relay_host.nebula_ip)

    return am_relay, relay_ips
