from pathlib import Path

import yaml

from nebula_cert_manager.models import NebulaConfig

NEBULA_CONFIG_FILENAME = "nebula.config.yml"


def load_nebula_config(registry_dir: Path) -> NebulaConfig | None:
    path = registry_dir / NEBULA_CONFIG_FILENAME
    if not path.exists():
        return None
    data = yaml.safe_load(path.read_text())
    if not data:
        return None
    return NebulaConfig.model_validate(data)
