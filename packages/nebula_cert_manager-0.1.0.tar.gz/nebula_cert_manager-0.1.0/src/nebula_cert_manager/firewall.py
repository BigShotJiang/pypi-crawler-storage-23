from nebula_cert_manager.models import Direction, FirewallConfig


def resolve_firewall_rules(
    client_name: str, config: FirewallConfig
) -> tuple[list[dict], list[dict]]:
    rules_map = config.firewall_rules.get(client_name, config.firewall_default)

    inbound: list[dict] = []
    outbound: list[dict] = []

    for peer_group, sg_names in rules_map.items():
        for sg_name in sg_names:
            sg = config.security_groups[sg_name]
            rule: dict = {"port": sg.port, "proto": str(sg.proto)}
            if peer_group == "all":
                rule["host"] = "any"
            else:
                rule["group"] = peer_group

            if sg.direction in (Direction.IN, Direction.ANY):
                inbound.append(rule.copy())
            if sg.direction in (Direction.OUT, Direction.ANY):
                outbound.append(rule.copy())

    return inbound, outbound
