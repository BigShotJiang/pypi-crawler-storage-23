from nebula_cert_manager.models import HostDefaults, HostsConfig


def resolve_host_overrides(client_name: str, config: HostsConfig) -> HostDefaults:
    defaults = config.defaults
    per_host = config.hosts.get(client_name)
    if per_host is None:
        return defaults
    merged = {}
    for field in HostDefaults.model_fields:
        per_host_val = getattr(per_host, field)
        merged[field] = (
            per_host_val if per_host_val is not None else getattr(defaults, field)
        )
    return HostDefaults(**merged)
