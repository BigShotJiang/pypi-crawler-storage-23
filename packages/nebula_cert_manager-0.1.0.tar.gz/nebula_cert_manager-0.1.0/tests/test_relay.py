from nebula_cert_manager.models import HostConfig, HostDefaults, HostsConfig
from nebula_cert_manager.relay import resolve_relay_for_host


def test_resolve_relay_am_relay():
    config = HostsConfig(
        hosts={
            "relay-server": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("relay-server", config)
    assert am_relay is True
    assert relay_ips == []


def test_resolve_relay_not_am_relay():
    config = HostsConfig(
        hosts={
            "client": HostConfig(nebula_ip="10.43.1.1"),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("client", config)
    assert am_relay is False
    assert relay_ips == []


def test_resolve_relay_from_defaults():
    config = HostsConfig(
        defaults=HostDefaults(relays=["relay-server"]),
        hosts={
            "relay-server": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
            "client": HostConfig(nebula_ip="10.43.1.1"),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("client", config)
    assert am_relay is False
    assert relay_ips == ["10.43.0.1"]


def test_resolve_relay_per_host_overrides_defaults():
    config = HostsConfig(
        defaults=HostDefaults(relays=["relay1"]),
        hosts={
            "relay1": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
            "relay2": HostConfig(nebula_ip="10.43.0.2", am_relay=True),
            "client": HostConfig(nebula_ip="10.43.1.1", relays=["relay2"]),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("client", config)
    assert am_relay is False
    assert relay_ips == ["10.43.0.2"]


def test_resolve_relay_self_exclusion():
    config = HostsConfig(
        defaults=HostDefaults(relays=["relay-server"]),
        hosts={
            "relay-server": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("relay-server", config)
    assert am_relay is True
    assert relay_ips == []


def test_resolve_relay_unknown_relay_name_ignored():
    config = HostsConfig(
        hosts={
            "client": HostConfig(nebula_ip="10.43.1.1", relays=["nonexistent"]),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("client", config)
    assert am_relay is False
    assert relay_ips == []


def test_resolve_relay_unknown_host():
    config = HostsConfig(
        defaults=HostDefaults(relays=["relay-server"]),
        hosts={
            "relay-server": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("unknown", config)
    assert am_relay is False
    assert relay_ips == ["10.43.0.1"]


def test_resolve_relay_multiple_relays():
    config = HostsConfig(
        hosts={
            "relay1": HostConfig(nebula_ip="10.43.0.1", am_relay=True),
            "relay2": HostConfig(nebula_ip="10.43.0.2", am_relay=True),
            "client": HostConfig(nebula_ip="10.43.1.1", relays=["relay1", "relay2"]),
        },
    )
    am_relay, relay_ips = resolve_relay_for_host("client", config)
    assert am_relay is False
    assert relay_ips == ["10.43.0.1", "10.43.0.2"]
