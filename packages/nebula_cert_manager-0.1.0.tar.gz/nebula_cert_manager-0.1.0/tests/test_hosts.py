from nebula_cert_manager.hosts import resolve_host_overrides
from nebula_cert_manager.models import HostConfig, HostDefaults, HostsConfig


def test_resolve_host_overrides_uses_defaults():
    config = HostsConfig(
        defaults=HostDefaults(tun_dev="nebula1"),
        hosts={},
    )
    result = resolve_host_overrides("any-host", config)
    assert result.tun_dev == "nebula1"


def test_resolve_host_overrides_per_host():
    config = HostsConfig(
        defaults=HostDefaults(tun_dev="nebula1"),
        hosts={
            "special": HostConfig(nebula_ip="10.43.1.1", tun_dev="nebula2"),
        },
    )
    result = resolve_host_overrides("special", config)
    assert result.tun_dev == "nebula2"


def test_resolve_host_overrides_per_host_partial():
    config = HostsConfig(
        defaults=HostDefaults(tun_dev="nebula1"),
        hosts={
            "partial": HostConfig(nebula_ip="10.43.1.1"),
        },
    )
    result = resolve_host_overrides("partial", config)
    assert result.tun_dev == "nebula1"


def test_resolve_host_overrides_no_defaults():
    config = HostsConfig(
        hosts={
            "special": HostConfig(nebula_ip="10.43.1.1", tun_dev="nebula2"),
        },
    )
    result = resolve_host_overrides("special", config)
    assert result.tun_dev == "nebula2"

    result_other = resolve_host_overrides("other", config)
    assert result_other.tun_dev is None
