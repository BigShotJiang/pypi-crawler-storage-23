from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from nebula_cert_manager.models import (
    CAInfo,
    ClientInfo,
    Registry,
)
from nebula_cert_manager.sops import Sops


FAKE_CA_CERT = "-----BEGIN NEBULA CERTIFICATE-----\nfake-ca-cert\n-----END NEBULA CERTIFICATE-----\n"
FAKE_CA_KEY = "-----BEGIN NEBULA ED25519 PRIVATE KEY-----\nfake-ca-key\n-----END NEBULA ED25519 PRIVATE KEY-----\n"
FAKE_CLIENT_CERT = "-----BEGIN NEBULA CERTIFICATE-----\nfake-client-cert\n-----END NEBULA CERTIFICATE-----\n"
FAKE_CLIENT_KEY = "-----BEGIN NEBULA X25519 PRIVATE KEY-----\nfake-client-key\n-----END NEBULA X25519 PRIVATE KEY-----\n"


@pytest.fixture
def sample_registry() -> Registry:
    return Registry(
        ca=CAInfo(
            name="test-ca",
            cert=FAKE_CA_CERT,
            key=FAKE_CA_KEY,
            fingerprint="abc123",
            created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        ),
        clients={},
    )


@pytest.fixture
def sample_client() -> ClientInfo:
    return ClientInfo(
        fingerprint="def456",
        cert=FAKE_CLIENT_CERT,
        key=FAKE_CLIENT_KEY,
        issued_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        expires_at=datetime(2027, 1, 1, tzinfo=timezone.utc),
    )


@pytest.fixture
def mock_sops() -> MagicMock:
    mock = MagicMock(spec=Sops)
    mock.age_key = None
    return mock


@pytest.fixture
def registry_dir(tmp_path: Path) -> Path:
    return tmp_path / "registry"
