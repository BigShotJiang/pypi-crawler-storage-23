"""Tests for todo management tools."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from folderbot.todo_store import TodoStore
from folderbot.tools.todo import (
    TodoAddRequest,
    TodoListRequest,
    TodoUpdateRequest,
    TodoRemoveRequest,
    todo_add,
    todo_list,
    todo_update,
    todo_remove,
)


def _make_context(md_path: Path):
    """Create a mock BotContext with a real TodoStore."""
    store = TodoStore(md_path)
    context = MagicMock()
    context.user_id = 42
    context.services = {"todo": store}
    return context, store


class TestTodoAddTool:
    """Tests for todo_add tool."""

    @pytest.mark.asyncio
    async def test_add_minimal(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        result = await todo_add(TodoAddRequest(title="Buy milk"), ctx)
        assert not result.is_error
        assert "Buy milk" in result.content
        items = store.list(user_id=42)
        assert len(items) == 1

    @pytest.mark.asyncio
    async def test_add_with_details(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        result = await todo_add(
            TodoAddRequest(
                title="Write report",
                description="Q1 sales report",
                effort="large",
                tags=["work", "urgent"],
            ),
            ctx,
        )
        assert not result.is_error
        items = store.list(user_id=42)
        assert items[0].effort == "large"
        assert items[0].tags == ["work", "urgent"]

    @pytest.mark.asyncio
    async def test_add_no_context(self) -> None:
        result = await todo_add(TodoAddRequest(title="Test"), None)
        assert result.is_error
        assert "not available" in result.content.lower()

    @pytest.mark.asyncio
    async def test_add_no_todo_service(self) -> None:
        ctx = MagicMock()
        ctx.services = {}
        result = await todo_add(TodoAddRequest(title="Test"), ctx)
        assert result.is_error


class TestTodoListTool:
    """Tests for todo_list tool."""

    @pytest.mark.asyncio
    async def test_list_empty(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "no" in result.content.lower() or "empty" in result.content.lower()

    @pytest.mark.asyncio
    async def test_list_with_items(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Task 1")
        store.add(user_id=42, title="Task 2")
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "Task 1" in result.content
        assert "Task 2" in result.content

    @pytest.mark.asyncio
    async def test_list_with_effort_filter(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Quick task", effort="tiny")
        store.add(user_id=42, title="Big task", effort="epic")
        result = await todo_list(TodoListRequest(max_effort="small"), ctx)
        assert not result.is_error
        assert "Quick task" in result.content
        assert "Big task" not in result.content

    @pytest.mark.asyncio
    async def test_list_with_tag_filter(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Work task", tags=["work"])
        store.add(user_id=42, title="Home task", tags=["home"])
        result = await todo_list(TodoListRequest(tag="work"), ctx)
        assert not result.is_error
        assert "Work task" in result.content
        assert "Home task" not in result.content

    @pytest.mark.asyncio
    async def test_list_shows_stats(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Task 1")
        item2 = store.add(user_id=42, title="Task 2")
        store.update(todo_id=item2.id, user_id=42, status="done")
        result = await todo_list(TodoListRequest(include_done=True), ctx)
        assert not result.is_error
        # Should show some kind of summary/stats
        assert "done" in result.content.lower() or "2" in result.content

    @pytest.mark.asyncio
    async def test_list_no_context(self) -> None:
        result = await todo_list(TodoListRequest(), None)
        assert result.is_error


class TestTodoUpdateTool:
    """Tests for todo_update tool."""

    @pytest.mark.asyncio
    async def test_update_status(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Test")
        result = await todo_update(
            TodoUpdateRequest(todo_id=item.id, status="done"), ctx
        )
        assert not result.is_error
        assert "[x]" in result.content

    @pytest.mark.asyncio
    async def test_update_title(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Old")
        result = await todo_update(TodoUpdateRequest(todo_id=item.id, title="New"), ctx)
        assert not result.is_error
        assert "New" in result.content

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_update(TodoUpdateRequest(todo_id=999, status="done"), ctx)
        assert result.is_error
        assert "not found" in result.content.lower()

    @pytest.mark.asyncio
    async def test_update_no_context(self) -> None:
        result = await todo_update(TodoUpdateRequest(todo_id=1, status="done"), None)
        assert result.is_error


class TestTodoRemoveTool:
    """Tests for todo_remove tool."""

    @pytest.mark.asyncio
    async def test_remove_existing(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Test")
        result = await todo_remove(TodoRemoveRequest(todo_id=item.id), ctx)
        assert not result.is_error
        assert store.get(todo_id=item.id, user_id=42) is None

    @pytest.mark.asyncio
    async def test_remove_nonexistent(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_remove(TodoRemoveRequest(todo_id=999), ctx)
        assert result.is_error
        assert "not found" in result.content.lower()

    @pytest.mark.asyncio
    async def test_remove_no_context(self) -> None:
        result = await todo_remove(TodoRemoveRequest(todo_id=1), None)
        assert result.is_error
