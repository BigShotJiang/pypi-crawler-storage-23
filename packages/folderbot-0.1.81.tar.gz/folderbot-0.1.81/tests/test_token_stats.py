"""Tests for token statistics tool with grouping and cost estimation."""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from folderbot.session_manager import SessionManager
from folderbot.tools.token_stats import (
    DEFAULT_PRICES,
    TokenStatsRequest,
    _estimate_cost,
    _group_records,
    token_stats,
)


@pytest.fixture
def session_manager(tmp_path: Path) -> SessionManager:
    return SessionManager(tmp_path / "test.db")


def _make_context(session_manager: SessionManager, user_id: int = 42):
    context = MagicMock()
    context.user_id = user_id
    context.services = {"session": session_manager, "folder": MagicMock()}
    # Make folder services return tool config
    context.services["folder"].get_tool_config = lambda name: {}
    return context


class TestEstimateCost:
    """Tests for cost estimation function."""

    def test_known_model(self) -> None:
        cost = _estimate_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            model="anthropic/claude-sonnet-4-20250514",
            prices=DEFAULT_PRICES,
        )
        # 3.0 input + 15.0 output = 18.0
        assert cost == pytest.approx(18.0, rel=0.01)

    def test_unknown_model_uses_default(self) -> None:
        cost = _estimate_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            model="unknown/model",
            prices=DEFAULT_PRICES,
        )
        # Should use _default_ pricing
        assert cost > 0

    def test_zero_tokens(self) -> None:
        cost = _estimate_cost(
            0, 0, "anthropic/claude-sonnet-4-20250514", DEFAULT_PRICES
        )
        assert cost == 0.0

    def test_custom_prices(self) -> None:
        prices = {"my/model": (1.0, 2.0)}
        cost = _estimate_cost(500_000, 500_000, "my/model", prices)
        # 0.5 * 1.0 + 0.5 * 2.0 = 1.5
        assert cost == pytest.approx(1.5)


class TestGroupRecords:
    """Tests for grouping token records by time period."""

    def _make_records(self, session_manager, user_id=42, count=5):
        """Create test records spread over several days."""
        for i in range(count):
            session_manager.record_token_usage(
                user_id=user_id,
                input_tokens=100 * (i + 1),
                output_tokens=50 * (i + 1),
                model="anthropic/claude-sonnet-4-20250514",
                topic="general",
            )

    def test_group_by_day(self, session_manager: SessionManager) -> None:
        self._make_records(session_manager)
        records = session_manager.get_token_usage(user_id=42)
        groups = _group_records(records, "day")
        # All records have the same date since they're inserted with datetime.now()
        # but the key format should be YYYY-MM-DD
        assert len(groups) >= 1
        for key in groups:
            assert len(key) == 10  # YYYY-MM-DD format

    def test_group_by_month(self, session_manager: SessionManager) -> None:
        self._make_records(session_manager)
        records = session_manager.get_token_usage(user_id=42)
        groups = _group_records(records, "month")
        assert len(groups) >= 1
        for key in groups:
            assert len(key) == 7  # YYYY-MM format

    def test_group_by_model(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        session_manager.record_token_usage(42, 200, 100, "openai/gpt-4o", "general")
        records = session_manager.get_token_usage(user_id=42)
        groups = _group_records(records, "model")
        assert len(groups) == 2
        assert "anthropic/claude-sonnet-4-20250514" in groups
        assert "openai/gpt-4o" in groups

    def test_group_by_topic(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "weather"
        )
        session_manager.record_token_usage(
            42, 200, 100, "anthropic/claude-sonnet-4-20250514", "coding"
        )
        records = session_manager.get_token_usage(user_id=42)
        groups = _group_records(records, "topic")
        assert "weather" in groups
        assert "coding" in groups

    def test_group_aggregates_correctly(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        session_manager.record_token_usage(
            42, 200, 100, "anthropic/claude-sonnet-4-20250514", "general"
        )
        records = session_manager.get_token_usage(user_id=42)
        groups = _group_records(records, "model")
        key = "anthropic/claude-sonnet-4-20250514"
        assert groups[key]["input_tokens"] == 300
        assert groups[key]["output_tokens"] == 150
        assert groups[key]["count"] == 2


class TestTokenStatsTool:
    """Tests for the token_stats tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await token_stats(TokenStatsRequest(), None)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_no_records(self, session_manager: SessionManager) -> None:
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(), ctx)
        assert not result.is_error
        assert "no" in result.content.lower() or "0" in result.content

    @pytest.mark.asyncio
    async def test_basic_stats(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 1000, 500, "anthropic/claude-sonnet-4-20250514", "general"
        )
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(), ctx)
        assert not result.is_error
        assert "1,000" in result.content or "1000" in result.content
        assert "500" in result.content

    @pytest.mark.asyncio
    async def test_includes_cost(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 1_000_000, 500_000, "anthropic/claude-sonnet-4-20250514", "general"
        )
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(), ctx)
        assert not result.is_error
        assert "$" in result.content

    @pytest.mark.asyncio
    async def test_group_by_model(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        session_manager.record_token_usage(42, 200, 100, "openai/gpt-4o", "general")
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(group_by="model"), ctx)
        assert not result.is_error
        assert "claude" in result.content.lower() or "anthropic" in result.content
        assert "gpt" in result.content.lower() or "openai" in result.content

    @pytest.mark.asyncio
    async def test_group_by_day(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(group_by="day"), ctx)
        assert not result.is_error
        # Should have a date in the output
        today = datetime.now().strftime("%Y-%m-%d")
        assert today in result.content

    @pytest.mark.asyncio
    async def test_period_today(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(period="today"), ctx)
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_custom_days(self, session_manager: SessionManager) -> None:
        session_manager.record_token_usage(
            42, 100, 50, "anthropic/claude-sonnet-4-20250514", "general"
        )
        ctx = _make_context(session_manager)
        result = await token_stats(TokenStatsRequest(days=90), ctx)
        assert not result.is_error
