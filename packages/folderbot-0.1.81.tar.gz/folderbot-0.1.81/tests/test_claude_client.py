"""Backward-compat: tests moved to test_llm_client.py.

This file re-exports trim_history_to_budget from the new location
to avoid breaking any references.
"""

from folderbot.llm_client import trim_history_to_budget  # noqa: F401
