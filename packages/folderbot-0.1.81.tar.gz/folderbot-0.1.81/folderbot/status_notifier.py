"""Real-time status feedback for Telegram users during message processing."""

from __future__ import annotations

import asyncio
import logging
from contextlib import suppress
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from telegram.error import BadRequest

if TYPE_CHECKING:
    from telegram import Bot, Message

logger = logging.getLogger(__name__)

_TYPING_INTERVAL = 4

_TOOL_LABELS: dict[str, str] = {
    "web_search": "Searching the web",
    "web_fetch": "Fetching a webpage",
    "read_file": "Reading a file",
    "read_files": "Reading files",
    "write_file": "Writing a file",
    "list_files": "Listing files",
    "search_files": "Searching files",
    "get_weather": "Getting weather",
    "schedule_task": "Scheduling a task",
    "list_tasks": "Listing tasks",
    "cancel_task": "Cancelling a task",
    "get_task_results": "Getting task results",
    "read_activity_log": "Reading activity log",
    "get_time": "Checking the time",
    "get_full_history": "Reading conversation history",
    "reorganize_topics": "Reorganizing topics",
    "list_topics": "Listing topics",
    "get_token_usage": "Getting token usage",
    "ask_user": "Waiting for your input",
    "list_uploads": "Listing uploads",
    "delete_upload": "Deleting upload",
    "send_upload": "Sending a file",
    "send_message": "Sending a message",
    "enable_file_notifications": "Enabling file notifications",
    "disable_file_notifications": "Disabling file notifications",
    "get_file_notification_status": "Checking notification status",
    "compare_numbers": "Comparing numbers",
    "shuffle_list": "Shuffling list",
    "sort_list": "Sorting list",
    "random_choice": "Making a random choice",
    "random_number": "Generating a random number",
}


def tool_label(name: str) -> str:
    return _TOOL_LABELS.get(name, name.replace("_", " ").title())


@dataclass
class StatusNotifier:
    chat_id: int
    bot: Bot
    _status_message: Message | None = field(default=None, init=False, repr=False)
    _typing_task: asyncio.Task[None] | None = field(
        default=None, init=False, repr=False
    )

    async def start(self) -> None:
        await self.bot.send_chat_action(self.chat_id, "typing")
        self._typing_task = asyncio.create_task(self._typing_loop())

    async def update(self, tool_name: str) -> None:
        label = f"<i>{tool_label(tool_name)}...</i>"
        if self._status_message is None:
            self._status_message = await self.bot.send_message(
                self.chat_id, label, parse_mode="HTML"
            )
        else:
            with suppress(BadRequest):
                await self._status_message.edit_text(label, parse_mode="HTML")

    async def stop(self) -> None:
        if self._typing_task:
            self._typing_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._typing_task
        if self._status_message:
            with suppress(Exception):
                await self._status_message.delete()

    async def _typing_loop(self) -> None:
        with suppress(asyncio.CancelledError):
            while True:
                await self.bot.send_chat_action(self.chat_id, "typing")
                await asyncio.sleep(_TYPING_INTERVAL)
