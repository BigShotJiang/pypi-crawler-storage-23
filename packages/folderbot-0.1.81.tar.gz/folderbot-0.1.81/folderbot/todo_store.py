"""Markdown-backed todo storage for human-readable task management."""

from __future__ import annotations

import builtins
import os
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

_list = builtins.list

EFFORT_LEVELS = ("tiny", "small", "medium", "large", "epic")
STATUSES = ("todo", "in_progress", "done")

STATUS_CHARS = {"todo": " ", "in_progress": "~", "done": "x"}
CHAR_TO_STATUS = {v: k for k, v in STATUS_CHARS.items()}

TASK_RE = re.compile(r"^- \[([ ~x])\] (.+)$")
TAG_RE = re.compile(r"\+(\S+)")
META_RE = re.compile(
    r"<!--\s+"
    r"id:(\d+)\s+"
    r"user:(\d+)\s+"
    r"created:(\S+)\s+"
    r"updated:(\S+)"
    r"(?:\s+completed:(\S+))?"
    r"\s+-->"
)


@dataclass(frozen=True)
class TodoItem:
    id: int
    user_id: int
    title: str
    description: str
    status: str
    effort: str
    tags: _list[str]
    created_at: str
    updated_at: str
    completed_at: str | None


class TodoStore:
    def __init__(self, md_path: Path) -> None:
        self.md_path = md_path
        self._ensure_file()

    def _ensure_file(self) -> None:
        self.md_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.md_path.exists():
            self._save([])

    def _load(self) -> tuple[_list[TodoItem], int]:
        content = self.md_path.read_text(encoding="utf-8")
        if not content.strip():
            return [], 1

        items: _list[TodoItem] = []
        blocks = re.split(r"(?=^- \[)", content, flags=re.MULTILINE)

        for block in blocks:
            block = block.strip()
            if not block:
                continue
            first_line = block.split("\n", 1)[0]
            task_match = TASK_RE.match(first_line)
            if not task_match:
                continue
            items.append(self._parse_block(block, task_match))

        next_id = max((i.id for i in items), default=0) + 1
        return items, next_id

    def _parse_block(self, block: str, task_match: re.Match[str]) -> TodoItem:
        status_char, title_with_tags = task_match.groups()
        status = CHAR_TO_STATUS[status_char]

        tags = TAG_RE.findall(title_with_tags)
        title = TAG_RE.sub("", title_with_tags).strip()

        lines = block.split("\n")
        effort = "medium"
        desc_lines: _list[str] = []
        todo_id = 0
        user_id = 0
        created_at = ""
        updated_at = ""
        completed_at: str | None = None

        for line in lines[1:]:
            stripped = line.strip()
            meta_match = META_RE.search(stripped)
            if meta_match:
                todo_id = int(meta_match.group(1))
                user_id = int(meta_match.group(2))
                created_at = meta_match.group(3)
                updated_at = meta_match.group(4)
                completed_at = meta_match.group(5)
            elif stripped.startswith("effort:"):
                effort = stripped.split(":", 1)[1].strip()
            elif stripped:
                desc_lines.append(stripped)

        description = "\n".join(desc_lines)

        return TodoItem(
            id=todo_id,
            user_id=user_id,
            title=title,
            description=description,
            status=status,
            effort=effort,
            tags=tags,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=completed_at,
        )

    def _serialize_item(self, item: TodoItem) -> str:
        char = STATUS_CHARS[item.status]
        tag_str = " ".join(f"+{t}" for t in item.tags)
        title_line = f"- [{char}] {item.title}"
        if tag_str:
            title_line += f" {tag_str}"

        lines = [title_line]
        if item.effort != "medium":
            lines.append(f"  effort: {item.effort}")
        if item.description:
            for desc_line in item.description.split("\n"):
                lines.append(f"  {desc_line}")

        meta_parts = [
            f"id:{item.id}",
            f"user:{item.user_id}",
            f"created:{item.created_at}",
            f"updated:{item.updated_at}",
        ]
        if item.completed_at is not None:
            meta_parts.append(f"completed:{item.completed_at}")
        lines.append(f"  <!-- {' '.join(meta_parts)} -->")

        return "\n".join(lines)

    def _save(self, items: _list[TodoItem]) -> None:
        sorted_items = sorted(items, key=lambda i: i.created_at)
        parts = ["# Todos"]
        for item in sorted_items:
            parts.append("")
            parts.append(self._serialize_item(item))
        content = "\n".join(parts) + "\n"
        tmp_path = self.md_path.with_suffix(".md.tmp")
        tmp_path.write_text(content, encoding="utf-8")
        os.replace(tmp_path, self.md_path)

    def add(
        self,
        user_id: int,
        title: str,
        description: str = "",
        effort: str = "medium",
        tags: _list[str] | None = None,
    ) -> TodoItem:
        if effort not in EFFORT_LEVELS:
            raise ValueError(
                f"Invalid effort '{effort}'. Must be one of: {', '.join(EFFORT_LEVELS)}"
            )
        now = datetime.now().isoformat()
        items, next_id = self._load()
        item = TodoItem(
            id=next_id,
            user_id=user_id,
            title=title,
            description=description,
            status="todo",
            effort=effort,
            tags=tags or [],
            created_at=now,
            updated_at=now,
            completed_at=None,
        )
        items.append(item)
        self._save(items)
        return item

    def get(self, todo_id: int, user_id: int) -> TodoItem | None:
        items, _ = self._load()
        for item in items:
            if item.id == todo_id and item.user_id == user_id:
                return item
        return None

    def list(
        self,
        user_id: int,
        status: str | None = None,
        max_effort: str | None = None,
        tag: str | None = None,
        search: str | None = None,
        include_done: bool = False,
    ) -> _list[TodoItem]:
        items, _ = self._load()
        result = [i for i in items if i.user_id == user_id]

        if status is not None:
            result = [i for i in result if i.status == status]
        elif not include_done:
            result = [i for i in result if i.status != "done"]

        if max_effort is not None:
            idx = EFFORT_LEVELS.index(max_effort)
            allowed = set(EFFORT_LEVELS[: idx + 1])
            result = [i for i in result if i.effort in allowed]

        if search is not None:
            pattern = search.lower()
            result = [
                i
                for i in result
                if pattern in i.title.lower() or pattern in i.description.lower()
            ]

        if tag is not None:
            result = [i for i in result if tag in i.tags]

        return result

    def update(
        self,
        todo_id: int,
        user_id: int,
        title: str | None = None,
        description: str | None = None,
        status: str | None = None,
        effort: str | None = None,
        tags: _list[str] | None = None,
    ) -> TodoItem | None:
        if status is not None and status not in STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. Must be one of: {', '.join(STATUSES)}"
            )
        if effort is not None and effort not in EFFORT_LEVELS:
            raise ValueError(
                f"Invalid effort '{effort}'. Must be one of: {', '.join(EFFORT_LEVELS)}"
            )

        items, _ = self._load()
        target_idx = None
        for idx, item in enumerate(items):
            if item.id == todo_id and item.user_id == user_id:
                target_idx = idx
                break

        if target_idx is None:
            return None

        existing = items[target_idx]
        now = datetime.now().isoformat()

        new_status = status if status is not None else existing.status
        completed_at: str | None = existing.completed_at
        if status is not None:
            if status == "done":
                completed_at = now
            else:
                completed_at = None

        updated = TodoItem(
            id=existing.id,
            user_id=existing.user_id,
            title=title if title is not None else existing.title,
            description=description
            if description is not None
            else existing.description,
            status=new_status,
            effort=effort if effort is not None else existing.effort,
            tags=tags if tags is not None else existing.tags,
            created_at=existing.created_at,
            updated_at=now,
            completed_at=completed_at,
        )
        items[target_idx] = updated
        self._save(items)
        return updated

    def remove(self, todo_id: int, user_id: int) -> bool:
        items, _ = self._load()
        new_items = [i for i in items if not (i.id == todo_id and i.user_id == user_id)]
        if len(new_items) == len(items):
            return False
        self._save(new_items)
        return True

    def stats(self, user_id: int) -> dict[str, int]:
        items, _ = self._load()
        user_items = [i for i in items if i.user_id == user_id]
        counts: dict[str, int] = {s: 0 for s in STATUSES}
        for item in user_items:
            counts[item.status] = counts.get(item.status, 0) + 1
        counts["total"] = sum(counts.values())
        return counts
