"""SQLite-backed calendar event storage."""

from __future__ import annotations

import builtins
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

# Alias to avoid shadowing by list_events method return type
_list = builtins.list

EVENT_STATUSES = ("scheduled", "cancelled", "completed")
RECURRENCE_TYPES = ("", "daily", "weekly", "monthly", "yearly")


@dataclass(frozen=True)
class CalendarEvent:
    """A single calendar event."""

    id: int
    user_id: int
    title: str
    description: str
    start_time: str  # ISO 8601
    end_time: str  # ISO 8601
    location: str
    tags: list[str]
    reminders: list[str]  # e.g. ["15m_before", "1h_before"]
    recurrence: str  # "", "daily", "weekly", "monthly", "yearly"
    recurrence_end: str | None
    status: str  # "scheduled", "cancelled", "completed"
    created_at: str
    updated_at: str


class CalendarStore:
    """SQLite storage for calendar events."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        """Create the calendar_events table if it doesn't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS calendar_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    start_time TEXT NOT NULL,
                    end_time TEXT NOT NULL,
                    location TEXT NOT NULL DEFAULT '',
                    tags TEXT NOT NULL DEFAULT '[]',
                    reminders TEXT NOT NULL DEFAULT '[]',
                    recurrence TEXT NOT NULL DEFAULT '',
                    recurrence_end TEXT,
                    status TEXT NOT NULL DEFAULT 'scheduled',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_calendar_user_start
                ON calendar_events (user_id, start_time)
            """)
            conn.commit()

    def _get_connection(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    @staticmethod
    def _row_to_event(row: tuple) -> CalendarEvent:
        return CalendarEvent(
            id=row[0],
            user_id=row[1],
            title=row[2],
            description=row[3],
            start_time=row[4],
            end_time=row[5],
            location=row[6],
            tags=json.loads(row[7]),
            reminders=json.loads(row[8]),
            recurrence=row[9],
            recurrence_end=row[10],
            status=row[11],
            created_at=row[12],
            updated_at=row[13],
        )

    _COLUMNS = (
        "id, user_id, title, description, start_time, end_time, "
        "location, tags, reminders, recurrence, recurrence_end, "
        "status, created_at, updated_at"
    )

    def add(
        self,
        user_id: int,
        title: str,
        start_time: str,
        end_time: str,
        description: str = "",
        location: str = "",
        tags: _list[str] | None = None,
        reminders: _list[str] | None = None,
        recurrence: str = "",
        recurrence_end: str | None = None,
        status: str = "scheduled",
    ) -> CalendarEvent:
        """Add a new calendar event."""
        if status not in EVENT_STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. "
                f"Must be one of: {', '.join(EVENT_STATUSES)}"
            )
        if recurrence not in RECURRENCE_TYPES:
            raise ValueError(
                f"Invalid recurrence '{recurrence}'. "
                f"Must be one of: {', '.join(RECURRENCE_TYPES)}"
            )

        now = datetime.now(timezone.utc).isoformat()
        tags_json = json.dumps(tags or [])
        reminders_json = json.dumps(reminders or [])

        with self._get_connection() as conn:
            cursor = conn.execute(
                """INSERT INTO calendar_events
                   (user_id, title, description, start_time, end_time,
                    location, tags, reminders, recurrence, recurrence_end,
                    status, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    user_id,
                    title,
                    description,
                    start_time,
                    end_time,
                    location,
                    tags_json,
                    reminders_json,
                    recurrence,
                    recurrence_end,
                    status,
                    now,
                    now,
                ),
            )
            conn.commit()
            assert cursor.lastrowid is not None
            return CalendarEvent(
                id=cursor.lastrowid,
                user_id=user_id,
                title=title,
                description=description,
                start_time=start_time,
                end_time=end_time,
                location=location,
                tags=tags or [],
                reminders=reminders or [],
                recurrence=recurrence,
                recurrence_end=recurrence_end,
                status=status,
                created_at=now,
                updated_at=now,
            )

    def get(self, event_id: int, user_id: int) -> CalendarEvent | None:
        """Get a single event by ID, scoped to a user."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                f"SELECT {self._COLUMNS} FROM calendar_events "
                "WHERE id = ? AND user_id = ?",
                (event_id, user_id),
            )
            row = cursor.fetchone()
            return self._row_to_event(row) if row else None

    def list_events(
        self,
        user_id: int,
        tag: str | None = None,
        search: str | None = None,
        start_after: str | None = None,
        start_before: str | None = None,
        include_cancelled: bool = False,
    ) -> _list[CalendarEvent]:
        """List events with optional filters, ordered by start_time."""
        conditions = ["user_id = ?"]
        params: _list[Any] = [user_id]

        if not include_cancelled:
            conditions.append("status != 'cancelled'")

        if start_after is not None:
            conditions.append("start_time >= ?")
            params.append(start_after)

        if start_before is not None:
            conditions.append("start_time < ?")
            params.append(start_before)

        if search is not None:
            conditions.append(
                "(title LIKE ? COLLATE NOCASE OR description LIKE ? COLLATE NOCASE)"
            )
            pattern = f"%{search}%"
            params.extend([pattern, pattern])

        where = " AND ".join(conditions)
        query = (
            f"SELECT {self._COLUMNS} FROM calendar_events "
            f"WHERE {where} ORDER BY start_time"
        )

        with self._get_connection() as conn:
            cursor = conn.execute(query, params)
            items = [self._row_to_event(row) for row in cursor.fetchall()]

        # Filter by tag in Python (JSON column)
        if tag is not None:
            items = [e for e in items if tag in e.tags]

        return items

    def upcoming(
        self,
        user_id: int,
        days_ahead: int = 7,
        limit: int = 10,
    ) -> _list[CalendarEvent]:
        """Get upcoming events from now to days_ahead in the future."""
        now = datetime.now(timezone.utc).isoformat()
        cutoff = (datetime.now(timezone.utc) + timedelta(days=days_ahead)).isoformat()

        with self._get_connection() as conn:
            cursor = conn.execute(
                f"SELECT {self._COLUMNS} FROM calendar_events "
                "WHERE user_id = ? AND start_time >= ? AND start_time < ? "
                "AND status != 'cancelled' "
                "ORDER BY start_time LIMIT ?",
                (user_id, now, cutoff, limit),
            )
            return [self._row_to_event(row) for row in cursor.fetchall()]

    def update(
        self,
        event_id: int,
        user_id: int,
        title: str | None = None,
        description: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        location: str | None = None,
        tags: _list[str] | None = None,
        reminders: _list[str] | None = None,
        recurrence: str | None = None,
        recurrence_end: str | None = None,
        status: str | None = None,
    ) -> CalendarEvent | None:
        """Update an event. Returns updated event or None if not found."""
        if status is not None and status not in EVENT_STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. "
                f"Must be one of: {', '.join(EVENT_STATUSES)}"
            )
        if recurrence is not None and recurrence not in RECURRENCE_TYPES:
            raise ValueError(
                f"Invalid recurrence '{recurrence}'. "
                f"Must be one of: {', '.join(RECURRENCE_TYPES)}"
            )

        existing = self.get(event_id, user_id)
        if existing is None:
            return None

        now = datetime.now(timezone.utc).isoformat()
        sets: _list[str] = ["updated_at = ?"]
        params: _list[Any] = [now]

        if title is not None:
            sets.append("title = ?")
            params.append(title)
        if description is not None:
            sets.append("description = ?")
            params.append(description)
        if start_time is not None:
            sets.append("start_time = ?")
            params.append(start_time)
        if end_time is not None:
            sets.append("end_time = ?")
            params.append(end_time)
        if location is not None:
            sets.append("location = ?")
            params.append(location)
        if tags is not None:
            sets.append("tags = ?")
            params.append(json.dumps(tags))
        if reminders is not None:
            sets.append("reminders = ?")
            params.append(json.dumps(reminders))
        if recurrence is not None:
            sets.append("recurrence = ?")
            params.append(recurrence)
        if recurrence_end is not None:
            sets.append("recurrence_end = ?")
            params.append(recurrence_end)
        if status is not None:
            sets.append("status = ?")
            params.append(status)

        set_clause = ", ".join(sets)
        params.extend([event_id, user_id])

        with self._get_connection() as conn:
            conn.execute(
                f"UPDATE calendar_events SET {set_clause} WHERE id = ? AND user_id = ?",
                params,
            )
            conn.commit()

        return self.get(event_id, user_id)

    def remove(self, event_id: int, user_id: int) -> bool:
        """Remove an event. Returns True if deleted."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "DELETE FROM calendar_events WHERE id = ? AND user_id = ?",
                (event_id, user_id),
            )
            conn.commit()
            return cursor.rowcount > 0

    def stats(self, user_id: int) -> dict[str, int]:
        """Get event counts by status for a user."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT status, COUNT(*) FROM calendar_events "
                "WHERE user_id = ? GROUP BY status",
                (user_id,),
            )
            counts: dict[str, int] = {s: 0 for s in EVENT_STATUSES}
            for row in cursor.fetchall():
                counts[row[0]] = row[1]
            counts["total"] = sum(counts.values())
            return counts
