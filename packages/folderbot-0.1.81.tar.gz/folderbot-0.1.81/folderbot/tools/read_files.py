"""Read multiple files tool."""

from pydantic import BaseModel, Field

from ..bot import BotContext
from .base import ToolResult
from .constants import MAX_FILE_READ_CHARS
from .registry import folder_bot, get_services


class ReadFilesRequest(BaseModel, frozen=True):
    """Request for reading multiple files."""

    paths: list[str] = Field(
        description=(
            "List of file paths relative to the root folder "
            "(e.g., ['notes/todo.md', 'notes/ideas.md'])"
        )
    )


@folder_bot.tool(
    name="read_files",
    request_type=ReadFilesRequest,
    response_type=ToolResult,
)
async def read_files(
    request: ReadFilesRequest, _context: BotContext | None = None
) -> ToolResult:
    """Read the contents of multiple files at once.

    Returns a concatenated view with file headers.
    Use this to read several related files together.
    """
    services = get_services(_context)
    if services is None:
        return ToolResult(content="Services not available", is_error=True)

    if not request.paths:
        return ToolResult(
            content="paths is required and cannot be empty", is_error=True
        )

    parts: list[str] = []
    errors: list[str] = []
    total_chars = 0

    for path in request.paths:
        file_path = services.validate_path(path)
        if file_path is None:
            errors.append(f"{path}: access denied")
            continue

        if not file_path.exists():
            errors.append(f"{path}: not found")
            continue

        if not file_path.is_file():
            errors.append(f"{path}: not a file")
            continue

        rel_path = str(file_path.relative_to(services.root))
        if not services.is_file_allowed(rel_path):
            errors.append(f"{path}: not accessible")
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
            file_block = f"## {rel_path}\n\n{content}\n\n"
            if total_chars + len(file_block) > MAX_FILE_READ_CHARS:
                parts.append(
                    f"[Truncated - limit of {MAX_FILE_READ_CHARS} chars reached]"
                )
                break
            parts.append(file_block)
            total_chars += len(file_block)
        except Exception as e:
            errors.append(f"{path}: {e}")

    result_parts: list[str] = []
    if parts:
        result_parts.append("".join(parts))
    if errors:
        result_parts.append("Errors:\n" + "\n".join(f"  - {e}" for e in errors))

    if not parts:
        if errors:
            return ToolResult(
                content="No files could be read:\n"
                + "\n".join(f"  - {e}" for e in errors),
                is_error=True,
            )
        return ToolResult(content="No files could be read", is_error=True)

    return ToolResult(content="\n".join(result_parts))
