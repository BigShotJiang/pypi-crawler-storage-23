"""Base classes for tools."""

from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, Field, TypeAdapter


class ToolResult(BaseModel, frozen=True):
    """Result of a tool execution."""

    content: str = Field(description="The result content.")
    is_error: bool = Field(
        default=False, description="Whether this is an error result."
    )


@dataclass(frozen=True)
class ToolDefinition:
    """A tool definition with its input model."""

    name: str
    description: str
    input_model: type
    requires_confirmation: bool = False  # If True, Claude should ask before using

    def to_api_format(self) -> dict[str, Any]:
        """Convert to Anthropic API tool format."""
        schema = TypeAdapter(self.input_model).json_schema()
        # Remove title and description from top level (Anthropic uses our description)
        schema.pop("title", None)
        schema.pop("description", None)
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": schema,
        }
