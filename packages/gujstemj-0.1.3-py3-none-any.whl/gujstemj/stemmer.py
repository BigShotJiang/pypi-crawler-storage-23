# -*- coding: utf-8 -*-
# gujarati_stemmer/stemmer.py

# =======================================================================
# 1. TRIE NODE CLASS
# =======================================================================

class TrieNode:
    """A node in the Trie structure."""
    def __init__(self):
        # Using a dictionary for children transitions (Gujarati character set)
        self.children = {}
        # Flag to mark the end of a complete suffix
        self.is_end_of_suffix = False

# =======================================================================
# 2. TRIE IMPLEMENTATION
# =======================================================================

class SuffixTrie:
    """
    A Trie structure optimized for finding the longest *reversed* suffix match.
    The suffixes are inserted in reverse to allow for efficient longest-match 
    stripping from the end of a word.
    """
    def __init__(self, suffixes):
        self.root = TrieNode()
        self._build_trie(suffixes)

    def _build_trie(self, suffixes):
        """Builds the Trie by inserting all suffixes in reverse."""
        for suffix in suffixes:
            # Reverse the suffix for right-to-left matching
            reversed_suffix = suffix[::-1]
            node = self.root
            for char in reversed_suffix:
                if char not in node.children:
                    node.children[char] = TrieNode()
                node = node.children[char]
            node.is_end_of_suffix = True
            # Optional: Store the original suffix length/value at the end node
            # For this simple stemmer, we just use the flag.

    def find_longest_match(self, word: str) -> str:
        """
        Traverses the reversed word through the Trie to find the longest matching suffix.

        Args:
            word (str): The word to check.

        Returns:
            str: The longest matching suffix, or an empty string if none is found.
        """
        # Iterate over the word in reverse
        reversed_word = word[::-1]
        node = self.root
        longest_match = ""
        current_match_length = 0
        
        # Track the best match found so far
        best_match_length = 0

        for i, char in enumerate(reversed_word):
            if char in node.children:
                node = node.children[char]
                current_match_length += 1
                
                # If this node marks the end of a suffix, update the best match
                if node.is_end_of_suffix:
                    best_match_length = current_match_length
            else:
                # Mismatch: stop the search
                break
        
        # Extract the longest matching suffix from the original word
        if best_match_length > 0:
            # Since the trie stores reversed suffixes, the match is found by slicing 
            # the original word from the end.
            return word[-best_match_length:]
        
        return ""


# =======================================================================
# 3. DATA AND STEMMER FUNCTION
# =======================================================================

GUJARATI_SUFFIXES = [
    'એ', 'ે', 'ઓ', 'ો', 'ને', 'ઓને', 'ોને', 'ે', 'એ', 'થી', 'થકી', 'વડે', 'દ્વારા', 'ોએ', 'ઓએ', 'ઓથી', 'ઓથકી',
    'ઓવડે', 'ઓદ્વારા', 'અર્થે', 'કાજે', 'ને માટે', 'ને વાસ્તે', 'ને સારુ', 'ોઅર્થે', 'ોકાજે', 'ોને માટે',
    'ોને વાસ્તે', 'ોને સારુ', 'થી', 'ઉપરથી', 'માંથી', 'અંદરથી', 'પરથી', 'ોથી', 'ોથકી', 'ઓથી', 'ઓ થકી',
    'નો', 'ની', 'નું', 'ના', 'ોનો', 'ોની', 'ોનું', 'ોના', 'માં', 'માંહે', 'અંદર', 'ઉપર', 'પર', 'નીઅંદર',
    'ોમાં', 'ો માંહે', 'ો ઉપર', 'ો પર', 'ો નીઅંદર', 'ઉ છું', 'ુ છું', 'ઇએ છીએ', 'ીએ છીએ','ીએ', 'એ છે','ે છે',
    'ઓ છો', 'ો છો', 'એ છે', 'ે છે', 'એ છે', 'ે છે', 'યો', 'ો', 'યા', 'ા', 'યો', 'યા', 'ા', 'યો', 'ો', 'યા',
    'ા', 'યા', 'ા', 'ી', 'યા', 'ા', 'ી', 'યા', 'ા', 'યુ', 'ુ', 'યા', 'ા', 'યુ', 'ુ', 'યા', 'ા', 'યુ', 'ુ',
    'યા', 'ીશ', 'શુ', 'શે', 'શો','ીશુ','ોને'
]

# Note: The trie structure automatically handles the 'longest match' principle, 
# so manual sorting by length (GUJARATI_SUFFIXES.sort(key=len, reverse=True)) is 
# no longer strictly necessary for correctness, though it doesn't hurt.

INDECLINABLE_WORDS = {
    'નો', 'ક્યારે', 'તક', 'કેવું', 'કેવુ', 'કેવા', 'કેવાં', 'કેવી', 'ક્યાં', 'ક્યા', 'ક્યારે', 'હું', 'હુ',
    'મેં', 'મે', 'પોતે', 'તું', 'તુ', 'તમે', 'તમારો', 'તમારા', 'તમારું', 'તમારુ', 'તમારાં', 'તારી', 'તમારી',
    'અમે', 'અમારે', 'અમારી', 'અમારું', 'અમારુ', 'તે', 'તેઓ', 'તમારા', 'તમારાં', 'તમને', 'સુઘી', 'સ્ત્રી',
    'પરથી', 'ની', 'થી', 'એ', 'માં', 'તો', 'રોજ', 'જયારે', 'પણ', 'અંદર', 'નીચે', 'ઉપરાંત', 'આજુબાજુ', 'વાસ્તે',
    'વડે', 'ઉપર', 'કે', 'અથવા', 'પછી', 'દૂર', 'માંહે', 'જેથી', 'પર', 'માટે', 'સારુ', 'અર્થે', 'જેમ', 'તથા',
    'જ્યાં', 'તેથી', 'અને', 'માંથી', 'બારેબાર', 'જ્યા', 'સમાન', 'પ્રત્યે', 'હમણાં', 'હમણા', 'ત્યાં', 'સારું',
    'કાલે', 'તરફ', 'બહાર', 'નહીં', 'છીએ', 'ત્યા', 'માહે', 'જેમાં', 'ત્યારે', 'દ્વારા', 'ના', 'જલદી', 'અહી',
    'પાસે', 'ઉપરથી', 'હવે', 'કાજે', 'અહીં', 'ખાતર', 'સાંજે', 'સુધી', 'બરાબર', 'હેતુ', 'અહીંયા', 'સાચુ',
    'તરત', 'થકી', 'પાછળ', 'હેતું', 'સાચું', 'પ્રતિ', 'ક્યાં', 'ક્યા', 'નહી', 'બાદ', 'જલ્દી', 'ફાયદો', 'પૂજા',
    'રેખા', 'થશે', 'થતું', 'થતુ', 'કેરી', 'કંપની'
}

# Global initialization of the Trie to avoid rebuilding it on every function call
# This acts as the pre-processing/pre-compilation step.
_SUFFIX_TRIE = SuffixTrie(GUJARATI_SUFFIXES)

def stem_gujarati_word(word: str) -> str:
    """
    Stems a single Gujarati word using the pre-built Reversed Suffix Trie 
    to efficiently find the longest matching suffix.

    Args:
        word (str): The Gujarati word to stem.

    Returns:
        str: The stemmed root word.
    """
    processed_word = word.strip()

    # 1. Check if the word is an indeclinable.
    if processed_word in INDECLINABLE_WORDS:
        return processed_word

    # 2. Find the longest matching suffix using the Trie.
    matched_suffix = _SUFFIX_TRIE.find_longest_match(processed_word)

    # 3. Apply the removal.
    if matched_suffix:
        # The length of the stem is the length of the word minus the length of the suffix.
        stem_length = len(processed_word) - len(matched_suffix)
        return processed_word[:stem_length]

    # If no suffix is matched, the word itself is the root.
    return processed_word


print(stem_gujarati_word("વાંચીએ"))
print(stem_gujarati_word("રામે"))
print(stem_gujarati_word("વિધાર્થીઓ"))
print(stem_gujarati_word("લોકોએ"))
print(stem_gujarati_word("રમુ"))