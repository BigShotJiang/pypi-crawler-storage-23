# CancerSubminer
An integrated framework for cancer subtyping using supervised and unsupervised learning on DNA methylation profiles

## Requirements
* Python (>= 3.12.10)
* Pytorch (>= v2.8.0)
* Other python packages : numpy (>=2.2.6), pandas (>=2.3.1), torchvision (>= 0.23.0), umap-learn (v0.5.9.post2), scikit-learn (>= 1.7.1)

## Usage
Clone the repository or download source code files.

## Installation
To install CancerSubminer, run either:
```
pip install -r requirements.txt
```
or clone the repository and run:
```
pip install cancersubminer
```

## Inputs
[Note!] All the example datasets can be found in './example_data/' directory.

### 1. Source (Labeled) methylation dataset
* DNA methylation profiles to be used as source domain (**source_X.csv**)
  - Row : Sample, Column : Feature (CpG site or CpG cluster)
  - The first column should have "sample id", and the first row should contain the feature names
  - Example : ./example_data/source_X.csv
* Integer-converted subtype label for the source dataset (**source_y.csv**)
  - The column name should be "subtype", and the rows should be sorted in the same way as the ones in "source_X.csv".
  - The subtype label should start from 0
  - Example : ./example_data/source_y.csv

### 2. Target (Unlabeled) methylation dataset
* Unlabeled methylation profiles to be used as target domain (**target_X.csv**)
   - Row : Sample, Column : Feature 
   - The first column should have "sample_id" and the last two coulmns shoud be "batch" and "domain_idx" which contain the batch name (string) and integer number (index) discriminating each dataset. Samples in the same dataset should have same number and "domain_idx" should start from 1. You can have multiple batch inside.
   - The first row should contain the feature names.
   - Example : ./example_data/target_X.csv
 
### 3. Meta data
* Subtype information (**subtype_category_info.csv**)
  - This information will be used to convert each integer subtype label with the acutual subtype name for the source dataset.
  - This file should have two columns named with "subtype" and "subtype_int", which indicate the actual subtype name and the integer-converted subtype label you provided in "source_y.csv".
  - Example : ./example_data/subtype_category_info.csv
 
* Batch information (**batch_category_info.csv**)
  - This information will be used to convert each batch integer index with the acutual batch name and provide the prediction result for targe dataset.
  - This file should have two columns named with "batch" and "domain_idx", which indicate the actual batch name and the integer-converted batch index you provided in "target_X.csv".
  - Example : ./example_data/batch_category_info.csv
 
## How to run (Example)
1. Clone the respository, move to the cloned directory
2. Edit the **run.sh** to make sure each variable indicate the corresponding files.
   * `DATA_DIR` : dataset directory path having all the input
   * `RESULT_DIR` : directory name to save the subtyping results (It will be created in the current running directory)
   * `IS_AUTOMATIC_ESTIMATION_REQUIRED` : Cancersubminer allows the user to select either to specify the number of subtypes or let the model to automatically identify the optimal number of subtypes. (Set as '0' for the user specification, otherwise set as '1' for automatic estimation)
   * `NUM_SUBTYPE_USER_DEFINED` : If user set `IS_AUTOMATIC_ESTIMATION_REQUIRED` as 0, the users should specify the number of subtypes they want.
3. Run the below command :
```
chmod +x run.sh
./run.sh
```
If you clone the directory and run the above command directly, you will get the result for the example dataset.

3. All the results will be saved in the newly created **`RESULT_DIR` (default: ./results)** directory.
   * batch_corrected features.csv : batch corrected features for both source and target dataset
   * results_subtyping.csv : Subtyping results for each sample in both source and target dataset

## Contact
If you have any questions or problems, please contact to joungmin AT vt.edu
