from setuptools import setup, find_packages

setup(
    name='cancersubminer',
    version='0.0.1',
    description='An integrated framework for cancer subtyping using supervised and unsupervised learning on DNA methylation profiles',
    author='miniymay',
    author_email='joungmin@vt.edu',
    url='https://github.com/joungmin-choi/CancerSubminer',
    install_requires=['torch', 'pandas', 'numpy', 'torchvision', 'umap-learn', 'scikit-learn'],
    packages=find_packages(exclude=[]),
    keywords=['cancersubminer'],
    python_requires='>=3.12.10',
    package_data={},
    zip_safe=False,
    classifiers=[
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)