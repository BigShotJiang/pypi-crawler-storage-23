import click

from sitedrop import __version__


@click.group()
@click.version_option(version=__version__, prog_name="sitedrop")
def cli():
    """Self-hosted static site hosting. Upload HTML, get a URL."""


def register_commands():
    from sitedrop.commands.server_cmds import (
        setup,
        start,
        stop,
        status,
        restart,
        logs,
        backup,
        restore,
    )
    from sitedrop.commands.client_cmds import (
        login,
        upload,
        list_sites,
        delete,
        password,
        info,
    )

    cli.add_command(setup)
    cli.add_command(start)
    cli.add_command(stop)
    cli.add_command(status)
    cli.add_command(restart)
    cli.add_command(logs)
    cli.add_command(backup)
    cli.add_command(restore)
    cli.add_command(login)
    cli.add_command(upload)
    cli.add_command(list_sites)
    cli.add_command(delete)
    cli.add_command(password)
    cli.add_command(info)


register_commands()
