from pydantic import BaseModel


class AuthRequest(BaseModel):
    password: str


class AuthResponse(BaseModel):
    token: str


class SiteResponse(BaseModel):
    name: str
    size: int
    modified: str


class SiteListResponse(BaseModel):
    sites: list[SiteResponse]


class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str


class MessageResponse(BaseModel):
    message: str


class PasswordChangeResponse(BaseModel):
    message: str
    token: str


class HealthResponse(BaseModel):
    status: str
