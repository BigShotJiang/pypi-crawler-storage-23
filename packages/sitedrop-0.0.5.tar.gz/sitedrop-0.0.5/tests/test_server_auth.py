from datetime import timedelta

from sitedrop.server.auth import (
    create_token,
    hash_password,
    verify_password,
    verify_token,
)


def test_hash_and_verify():
    hashed = hash_password("hello")
    assert verify_password("hello", hashed)
    assert not verify_password("wrong", hashed)


def test_create_and_verify_token():
    secret = "test-secret-that-is-long-enough-for-hs256"
    token = create_token(secret)
    payload = verify_token(token, secret)
    assert payload is not None
    assert "exp" in payload
    assert "iat" in payload
    assert payload["sub"] == "admin"


def test_expired_token():
    secret = "test-secret-that-is-long-enough-for-hs256"
    token = create_token(secret, expires_delta=timedelta(seconds=-1))
    assert verify_token(token, secret) is None


def test_invalid_token():
    assert verify_token("garbage", "test-secret-that-is-long-enough-for-hs256") is None


def test_wrong_secret():
    token = create_token("secret-one-is-long-enough-for-hs256-jwt")
    assert verify_token(token, "secret-two-is-long-enough-for-hs256-jwt") is None
