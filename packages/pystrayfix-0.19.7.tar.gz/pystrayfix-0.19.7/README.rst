pystrayfix
==========

This is just pystray git with this PR applied:

* https://github.com/moses-palmer/pystray/pull/131

All credit and copyright for the code goes to the original developers.
