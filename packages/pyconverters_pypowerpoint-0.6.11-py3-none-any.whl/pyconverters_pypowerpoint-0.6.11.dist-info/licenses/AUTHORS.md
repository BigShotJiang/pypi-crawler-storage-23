# Authors

Contributors to pyconverters_pypowerpoint include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
