"""Custom parsers for Markdown."""
