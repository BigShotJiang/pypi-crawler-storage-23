"""Djot parser test configuration."""
