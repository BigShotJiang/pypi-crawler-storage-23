*[AI]: Artificial Intelligence
*[LLM]: Large Language Model
*[API]: Application Programming Interface
*[CLI]: Command Line Interface
*[SDK]: Software Development Kit
*[JSON]: JavaScript Object Notation
*[YAML]: YAML Ain't Markup Language
*[async]: Asynchronous
*[sync]: Synchronous
*[PII]: Personally Identifiable Information
