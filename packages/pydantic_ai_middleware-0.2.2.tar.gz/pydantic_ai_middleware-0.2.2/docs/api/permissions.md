# Permissions

::: pydantic_ai_middleware.ToolDecision
    options:
      show_source: true

::: pydantic_ai_middleware.ToolPermissionResult
    options:
      show_source: true

::: pydantic_ai_middleware.PermissionHandler
