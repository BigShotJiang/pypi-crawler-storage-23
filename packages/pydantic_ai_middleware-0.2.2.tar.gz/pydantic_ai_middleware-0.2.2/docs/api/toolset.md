# MiddlewareToolset

::: pydantic_ai_middleware.MiddlewareToolset
    options:
      show_source: true
      members:
        - wrapped
        - middleware
        - call_tool
        - get_tools
