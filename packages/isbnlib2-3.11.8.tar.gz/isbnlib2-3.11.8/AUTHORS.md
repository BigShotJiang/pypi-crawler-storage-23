Forked from: [xlcnd/isbnlib](https://github.com/xlcnd/isbnlib) on 2026-01-22

The last commit to the original repository was on 2023-07-28. Since it hasn't
been maintained since then, and its original author xlcnd has vanished, I have
decided to take over maintenance, at least for my own personal use.
Anyone who wants to use or improve it is welcome.
In case xlcnd returns, this repo will be converted to a PR against xlcnd/isbnlib
and be deleted afterwards.

Main Author
: hans-fritz-pommes

Original Author
: xlcnd <xlcnd@outlook.com>

With fine contributions from
----------------------------

- Alex Ioannidis
- Christian Clauss
- Daniel Himmelstein
- Deirdre Connolly
- flopgui
- mirelsol
- Nicolas Cisco
- Robert Schütz
- XinyuLiu5566
- mcepl
- TheDubliner

---
https://github.com/xlcnd/isbnlib/graphs/contributors
