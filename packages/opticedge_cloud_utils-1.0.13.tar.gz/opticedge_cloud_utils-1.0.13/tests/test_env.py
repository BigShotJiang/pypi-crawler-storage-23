# tests/test_env.py

import pytest
from opticedge_cloud_utils.env import require_env


def test_returns_value_when_env_exists(monkeypatch):
    monkeypatch.setenv("TEST_VAR", "hello")

    assert require_env("TEST_VAR") == "hello"


def test_raises_when_missing_and_no_default(monkeypatch):
    monkeypatch.delenv("MISSING_VAR", raising=False)

    with pytest.raises(RuntimeError) as exc:
        require_env("MISSING_VAR")

    assert "MISSING_VAR env var must be set" in str(exc.value)


def test_returns_default_when_missing(monkeypatch):
    monkeypatch.delenv("OPTIONAL_VAR", raising=False)

    assert require_env("OPTIONAL_VAR", "fallback") == "fallback"


def test_returns_default_when_empty(monkeypatch):
    monkeypatch.setenv("EMPTY_VAR", "")

    assert require_env("EMPTY_VAR", "fallback") == "fallback"


def test_raises_when_empty_and_no_default(monkeypatch):
    monkeypatch.setenv("EMPTY_REQUIRED", "")

    with pytest.raises(RuntimeError):
        require_env("EMPTY_REQUIRED")


def test_existing_value_overrides_default(monkeypatch):
    monkeypatch.setenv("EXISTING_VAR", "real")

    assert require_env("EXISTING_VAR", "fallback") == "real"