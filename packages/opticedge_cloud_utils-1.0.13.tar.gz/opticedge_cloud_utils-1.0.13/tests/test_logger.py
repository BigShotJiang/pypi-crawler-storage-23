# tests/test_logger.py

import json
from opticedge_cloud_utils.logger import log


def test_log_outputs_valid_json(capsys):
    log("INFO", "Test message")

    captured = capsys.readouterr()
    output = captured.out.strip()

    parsed = json.loads(output)

    assert parsed["severity"] == "INFO"
    assert parsed["message"] == "Test message"


def test_log_includes_extra_fields(capsys):
    log("ERROR", "Something failed", card_id="123", session_id="abc")

    captured = capsys.readouterr()
    output = captured.out.strip()

    parsed = json.loads(output)

    assert parsed["severity"] == "ERROR"
    assert parsed["message"] == "Something failed"
    assert parsed["card_id"] == "123"
    assert parsed["session_id"] == "abc"


def test_log_handles_empty_kwargs(capsys):
    log("WARNING", "No extras")

    captured = capsys.readouterr()
    output = captured.out.strip()

    parsed = json.loads(output)

    assert parsed == {
        "severity": "WARNING",
        "message": "No extras",
    }
