# opticedge_cloud_utils/logger.py

import json


def log(level: str, message: str, **kwargs):
    """
    Structured JSON logger.
    Prints JSON so Cloud Logging can parse it automatically.
    """
    payload = {
        "severity": level,
        "message": message,
        **kwargs,
    }
    print(json.dumps(payload))
