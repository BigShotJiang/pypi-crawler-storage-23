# opticedge_cloud_utils/normalize.py

def normalize_enum(value, enum_cls):
    """
    Safely convert a raw value to an Enum member.

    Returns:
        Enum member if valid
        None if value cannot be converted
    """
    try:
        return enum_cls(value)
    except (ValueError, TypeError):
        return None