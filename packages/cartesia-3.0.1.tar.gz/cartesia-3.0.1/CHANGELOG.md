# Changelog

## 3.0.1 (2026-02-23)

Full Changelog: [v3.0.0...v3.0.1](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0...v3.0.1)

### Features

* **api:** update headline example ([fb14a78](https://github.com/cartesia-ai/cartesia-python/commit/fb14a78923cd146cb1dcb20765fc7cce0392010a))


### Bug Fixes

* correctly route events to concurrent contexts ([#73](https://github.com/cartesia-ai/cartesia-python/issues/73)) ([49406e6](https://github.com/cartesia-ai/cartesia-python/commit/49406e6f10bf4a027059637b9e5dec14c8dccad7))


### Chores

* Fix lint ([3f6a0cc](https://github.com/cartesia-ai/cartesia-python/commit/3f6a0cc57350a092f577207041080b28d20ea2bc))
* fix lints and update headline examples ([#72](https://github.com/cartesia-ai/cartesia-python/issues/72)) ([0d37a8b](https://github.com/cartesia-ai/cartesia-python/commit/0d37a8bb16a93bc0f2e6af8e5f1e9d2d38f50a1d))
* format all `api.md` files ([680d8eb](https://github.com/cartesia-ai/cartesia-python/commit/680d8eb0a58b33e2915d76bcbc0f3231874ce2e3))
* **internal:** fix lint error on Python 3.14 ([b2eae65](https://github.com/cartesia-ai/cartesia-python/commit/b2eae650b8eccaea275308a668930d4cd54a8f7a))
* **internal:** remove mock server code ([af0d52a](https://github.com/cartesia-ai/cartesia-python/commit/af0d52a9a467db4b6e516884591d0b92b189517f))
* update mock server docs ([875bf82](https://github.com/cartesia-ai/cartesia-python/commit/875bf82754e7dd62e626d15987d436e7d4fb502c))

## 3.0.0 (2026-02-09)

Full Changelog: [v3.0.0-beta16...v3.0.0](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta16...v3.0.0)

## 3.0.0-beta16 (2026-02-09)

Full Changelog: [v3.0.0-beta15...v3.0.0-beta16](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta15...v3.0.0-beta16)

### Chores

* **internal:** bump dependencies ([0e640cb](https://github.com/cartesia-ai/cartesia-python/commit/0e640cbbd1046a10f89f88826d8e422c794d3ebe))

## 3.0.0-beta15 (2026-02-06)

Full Changelog: [v3.0.0-beta14...v3.0.0-beta15](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta14...v3.0.0-beta15)

### Features

* **api:** add flush_id to chunks response and binary response to voice changer ([4f32dc7](https://github.com/cartesia-ai/cartesia-python/commit/4f32dc77e41aa2d895f9ddcb2c8962d7d26339bb))
* **api:** inline websocketresponse type definitions ([026c079](https://github.com/cartesia-ai/cartesia-python/commit/026c079291ab5ffe53930cf95a39c705a75c7268))

## 3.0.0-beta14 (2026-02-05)

Full Changelog: [v3.0.0-beta13...v3.0.0-beta14](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta13...v3.0.0-beta14)

### Features

* **api:** group infill output_format ([a97639e](https://github.com/cartesia-ai/cartesia-python/commit/a97639e4aa45fd1bf716f46c0a1fae526d9e3a8b))
* **api:** infill output_format ([0fa69a6](https://github.com/cartesia-ai/cartesia-python/commit/0fa69a6693b092a7af4f14d2a04f10323338836e))

## 3.0.0-beta13 (2026-02-04)

Full Changelog: [v3.0.0-beta12...v3.0.0-beta13](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta12...v3.0.0-beta13)

### Features

* **api:** infill response ([09d2856](https://github.com/cartesia-ai/cartesia-python/commit/09d28561b638e985063fba4d9f2df4adb4c83d19))
* **api:** move infill and websocket_connect ([50e2649](https://github.com/cartesia-ai/cartesia-python/commit/50e264941f4e8b1df3dddd8b67ce1fa51fd46cfd))


### Chores

* **ci:** add missing environment ([d2698b2](https://github.com/cartesia-ai/cartesia-python/commit/d2698b2941eea02b200b3ceb37356349bddbfa8e))

## 3.0.0-beta12 (2026-02-03)

Full Changelog: [v3.0.0-beta11...v3.0.0-beta12](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta11...v3.0.0-beta12)

### Chores

* update SDK settings ([9269ed5](https://github.com/cartesia-ai/cartesia-python/commit/9269ed58cf7cfcb973100b06b72d08547c9955e3))
* update SDK settings ([e25b110](https://github.com/cartesia-ai/cartesia-python/commit/e25b1107d3f19041b15ecd4a5545ee37a8066d8f))

## 3.0.0-beta11 (2026-02-02)

Full Changelog: [v3.0.0-beta10...v3.0.0-beta11](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta10...v3.0.0-beta11)

### Features

* **api:** update api version ([47f7aac](https://github.com/cartesia-ai/cartesia-python/commit/47f7aac8e3b913d29d876022836097a27eed72cb))
* **api:** update python edition & auth method ([17c2071](https://github.com/cartesia-ai/cartesia-python/commit/17c20715ce811bf2ac296d378cb724aab5e3879c))
* **client:** add custom JSON encoder for extended type support ([9095b76](https://github.com/cartesia-ai/cartesia-python/commit/9095b7646415e0aebc1bfca83e68de2c6a4ad293))

## 3.0.0-beta10 (2026-01-27)

Full Changelog: [v3.0.0-beta9...v3.0.0-beta10](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta9...v3.0.0-beta10)

### Features

* **api:** update release environment ([ff6c335](https://github.com/cartesia-ai/cartesia-python/commit/ff6c33500d3534cf552ad272ffb6ae9c5d13e81f))

## 3.0.0-beta9 (2026-01-27)

Full Changelog: [v3.0.0-beta8...v3.0.0-beta9](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta8...v3.0.0-beta9)

### Chores

* update SDK settings ([a6924d7](https://github.com/cartesia-ai/cartesia-python/commit/a6924d73f6661c31a8587638294e835adc334d2a))

## 3.0.0-beta8 (2026-01-26)

Full Changelog: [v3.0.0-beta7...v3.0.0-beta8](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta7...v3.0.0-beta8)

### Features

* **api:** update pypi auth_method ([d66842c](https://github.com/cartesia-ai/cartesia-python/commit/d66842c302cfedc0799cf63621def01dc0b55fd2))

## 3.0.0-beta7 (2026-01-26)

Full Changelog: [v3.0.0-beta6...v3.0.0-beta7](https://github.com/cartesia-ai/cartesia-python/compare/v3.0.0-beta6...v3.0.0-beta7)

### Features

* Alpha Release of v2 Python SDK ([#20](https://github.com/cartesia-ai/cartesia-python/issues/20)) ([0951eb6](https://github.com/cartesia-ai/cartesia-python/commit/0951eb63d7a00573d2ff7b75a59712d735e43b49))
* **api:** add release environment ([f25d3fc](https://github.com/cartesia-ai/cartesia-python/commit/f25d3fc080b00753d414e408c1084e18e06ede7a))


### Bug Fixes

* Update `WebSocketTtsOutput` class to include `PhonemeTimestamps` ([#28](https://github.com/cartesia-ai/cartesia-python/issues/28)) ([6fe7603](https://github.com/cartesia-ai/cartesia-python/commit/6fe7603e8a5df5914d85d205a8b5320eb451a9f0))


### Chores

* sync repo ([35649ed](https://github.com/cartesia-ai/cartesia-python/commit/35649ed51fb9de699db06c98ff9e4d28f333aaca))
* update SDK settings ([bbe3fcc](https://github.com/cartesia-ai/cartesia-python/commit/bbe3fcc8df70d08ef8b50ea0434603204fdaced5))

## 3.0.0-beta6 (2026-01-23)

Full Changelog: [v3.0.0-beta5...v3.0.0-beta6](https://github.com/cartesia-ai/cartesia-python-internal/compare/v3.0.0-beta5...v3.0.0-beta6)

### Features

* **api:** remove -&gt; delete ([744cf2e](https://github.com/cartesia-ai/cartesia-python-internal/commit/744cf2ecdfb21c772651db75de7e25e72e4a7384))


### Chores

* **ci:** upgrade `actions/github-script` ([2ba5b4c](https://github.com/cartesia-ai/cartesia-python-internal/commit/2ba5b4ccbaa38a6534bde9a776e48c628d7bd6a9))

## 3.0.0-beta5 (2026-01-21)

Full Changelog: [v3.0.0-beta4...v3.0.0-beta5](https://github.com/cartesia-ai/cartesia-python-internal/compare/v3.0.0-beta4...v3.0.0-beta5)

### Features

* **api:** delete -&gt; remove ([3ef5c29](https://github.com/cartesia-ai/cartesia-python-internal/commit/3ef5c29593701479457cd562c17fb7ed37ce3d2e))

## 3.0.0-beta4 (2026-01-20)

Full Changelog: [v3.0.0-beta3...v3.0.0-beta4](https://github.com/cartesia-ai/cartesia-python-internal/compare/v3.0.0-beta3...v3.0.0-beta4)

### Features

* **api:** binary response types ([5348705](https://github.com/cartesia-ai/cartesia-python-internal/commit/53487050c110e62dbe03b54946c349511dbabe1b))
* **api:** voice changer response ([57e9e99](https://github.com/cartesia-ai/cartesia-python-internal/commit/57e9e99f97e54ef835ed9e6e558c30646b3bc55b))


### Chores

* **internal:** update `actions/checkout` version ([cb6890f](https://github.com/cartesia-ai/cartesia-python-internal/commit/cb6890fe8a349c21c3a8b82ab5bb339819d09b32))

## 3.0.0-beta3 (2026-01-13)

Full Changelog: [v3.0.0-beta2...v3.0.0-beta3](https://github.com/cartesia-ai/cartesia-python-internal/compare/v3.0.0-beta2...v3.0.0-beta3)

### Features

* **api:** add generation_config and generation_request to types export ([d3cfbce](https://github.com/cartesia-ai/cartesia-python-internal/commit/d3cfbce53a601e85240555e18f5d55454ecb0b97))
* **api:** fix list/get uri mismatch ([29943e4](https://github.com/cartesia-ai/cartesia-python-internal/commit/29943e41acea6717909bb03425048694736f4812))
* **api:** fix readme ([65c864c](https://github.com/cartesia-ai/cartesia-python-internal/commit/65c864cf4911c51df954c6bc18a8916022ba29bd))
* **api:** move connect into tts ([76b0d68](https://github.com/cartesia-ai/cartesia-python-internal/commit/76b0d681e5dc871d16e3eb1a44de7440415185a3))
* **api:** sync openapi spec ([6c2f42c](https://github.com/cartesia-ai/cartesia-python-internal/commit/6c2f42c692f40d230cfa10ee6fc4dc55433e04a7))
* **api:** use /voices for default example ([d42759e](https://github.com/cartesia-ai/cartesia-python-internal/commit/d42759e19c31682a80dc7f558429fceb17b9f062))
* **client:** add support for binary request streaming ([63ac0ec](https://github.com/cartesia-ai/cartesia-python-internal/commit/63ac0ec9187b54fe038c8d77ce8aff07ddc32a45))


### Bug Fixes

* **client:** loosen auth header validation ([7aeb0a2](https://github.com/cartesia-ai/cartesia-python-internal/commit/7aeb0a20869c4f61f3c03346f13fab6b1dcfef00))
* ensure streams are always closed ([1dc691f](https://github.com/cartesia-ai/cartesia-python-internal/commit/1dc691f4f63e7b8c110f1fde7a56300d588a0396))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([4ea04f6](https://github.com/cartesia-ai/cartesia-python-internal/commit/4ea04f615e7775fa3418ad8434696cf173383d37))
* use async_to_httpx_files in patch method ([801ca43](https://github.com/cartesia-ai/cartesia-python-internal/commit/801ca43ba9e4a93f86a9638156576bf553f85880))


### Chores

* add missing docstrings ([62c55c3](https://github.com/cartesia-ai/cartesia-python-internal/commit/62c55c3ddc4a69f14140abcbbf7ff1cb84acc837))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([cf6688f](https://github.com/cartesia-ai/cartesia-python-internal/commit/cf6688f0bcd22038de2912ae5891e29c9e015ac5))
* **internal:** add `--fix` argument to lint script ([344ac4b](https://github.com/cartesia-ai/cartesia-python-internal/commit/344ac4bb3154f81320fc40675da2ac9f48cbdbd7))
* **internal:** add missing files argument to base client ([af70c56](https://github.com/cartesia-ai/cartesia-python-internal/commit/af70c56d7aacc50c91c0866d088135ba2667bd06))
* **internal:** codegen related update ([e91ee82](https://github.com/cartesia-ai/cartesia-python-internal/commit/e91ee82d65e1c2a79d50dd86bd717a41e7c95edb))
* **internal:** codegen related update ([46b0701](https://github.com/cartesia-ai/cartesia-python-internal/commit/46b07017153e32ffb1ec9563f95577abb83ba5d5))
* **internal:** update docstring ([32b912c](https://github.com/cartesia-ai/cartesia-python-internal/commit/32b912c6814ffe7a253ed9d3b9826b4e6563f79e))
* speedup initial import ([fe997cc](https://github.com/cartesia-ai/cartesia-python-internal/commit/fe997cc94f591437efc902d0dee59b3d63aa25bf))
* update lockfile ([686915d](https://github.com/cartesia-ai/cartesia-python-internal/commit/686915dc2a61e5c4fbd58d6d9d380bb62f1627fb))

## 3.0.0-beta2 (2025-11-26)

Full Changelog: [v3.0.0-beta1...v3.0.0-beta2](https://github.com/cartesia-ai/cartesia-python-internal/compare/v3.0.0-beta1...v3.0.0-beta2)

### Features

* **api:** ws allOf updates ([c78ddd1](https://github.com/cartesia-ai/cartesia-python-internal/commit/c78ddd12ec361d47bead122d0ab0d4e9b0f8fa74))
* backcompat changes: ([d00c424](https://github.com/cartesia-ai/cartesia-python-internal/commit/d00c4249d0a86c8f7e121711ac57b856726ef808))


### Chores

* add Python 3.14 classifier and testing ([e4e100c](https://github.com/cartesia-ai/cartesia-python-internal/commit/e4e100c2fc32cbfa409423fba4b9f1a3e48910ee))

## 3.0.0-beta1 (2025-11-20)

Full Changelog: [v0.0.1...v3.0.0-beta1](https://github.com/cartesia-ai/cartesia-python-internal/compare/v0.0.1...v3.0.0-beta1)

### Features

* Alpha Release of v2 Python SDK ([#20](https://github.com/cartesia-ai/cartesia-python-internal/issues/20)) ([0951eb6](https://github.com/cartesia-ai/cartesia-python-internal/commit/0951eb63d7a00573d2ff7b75a59712d735e43b49))


### Bug Fixes

* Update `WebSocketTtsOutput` class to include `PhonemeTimestamps` ([#28](https://github.com/cartesia-ai/cartesia-python-internal/issues/28)) ([6fe7603](https://github.com/cartesia-ai/cartesia-python-internal/commit/6fe7603e8a5df5914d85d205a8b5320eb451a9f0))


### Chores

* sync repo ([c75dfb2](https://github.com/cartesia-ai/cartesia-python-internal/commit/c75dfb287671a681b4bb6576606d5dde9effdaa9))
* update SDK settings ([eb253d7](https://github.com/cartesia-ai/cartesia-python-internal/commit/eb253d7503c5d86860337f73cd3d9b058c67f45c))
* update SDK settings ([e404afa](https://github.com/cartesia-ai/cartesia-python-internal/commit/e404afa3e3bfa263868ff01c4fbf0dccf4d74d6e))
