"""TRedis — main Textual application."""

from __future__ import annotations

from pathlib import Path

from textual.app import App

from tuiredis.redis_client import RedisClient
from tuiredis.screens.connect import ConnectScreen
from tuiredis.screens.main import MainScreen

CSS_PATH = Path(__file__).parent / "styles" / "app.tcss"


class TRedisApp(App):
    """The TRedis terminal UI application."""

    TITLE = "TRedis"
    SUB_TITLE = "Redis Terminal UI Client"
    CSS_PATH = CSS_PATH

    SCREENS = {
        "connect": ConnectScreen,
        "main": MainScreen,
    }

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 6379,
        password: str | None = None,
        db: int = 0,
        auto_connect: bool = False,
    ):
        super().__init__()
        self.redis_client = RedisClient(
            host=host, port=port, password=password, db=db
        )
        self._auto_connect = auto_connect

    def on_mount(self) -> None:
        if self._auto_connect:
            if self.redis_client.connect():
                self.push_screen("main")
            else:
                self.push_screen("connect")
        else:
            self.push_screen("connect")
