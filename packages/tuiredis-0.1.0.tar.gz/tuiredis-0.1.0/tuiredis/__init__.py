"""tuiredis - A beautiful Redis TUI client."""

__version__ = "0.1.0"
