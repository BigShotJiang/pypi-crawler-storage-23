"""TRedis widgets."""
