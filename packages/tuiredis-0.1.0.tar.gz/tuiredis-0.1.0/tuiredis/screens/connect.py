"""Connection screen — form for configuring Redis connection."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Center, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Input, Static


class ConnectScreen(Screen):
    """Initial screen with a connection form."""

    BINDINGS = [("q", "quit", "Quit")]

    DEFAULT_CSS = """
    ConnectScreen {
        align: center middle;
        background: $surface-darken-2;
    }
    ConnectScreen #connect-card {
        width: 64;
        height: auto;
        padding: 2 4;
        border: heavy #DC382D;
        background: $surface;
    }
    ConnectScreen #connect-title {
        text-align: center;
        text-style: bold;
        color: #DC382D;
        padding: 1 0;
        width: 100%;
    }
    ConnectScreen #connect-subtitle {
        text-align: center;
        color: $text-muted;
        padding: 0 0 2 0;
        width: 100%;
    }
    ConnectScreen .form-label {
        margin: 1 0 0 0;
        color: $text;
        text-style: bold;
    }
    ConnectScreen Input {
        margin: 0 0 1 0;
    }
    ConnectScreen #connect-row {
        height: auto;
        margin: 0;
    }
    ConnectScreen #connect-row Input {
        width: 1fr;
    }
    ConnectScreen #connect-btn {
        width: 100%;
        margin: 2 0 0 0;
    }
    ConnectScreen #connect-error {
        text-align: center;
        color: $error;
        padding: 1 0;
        display: none;
    }
    ConnectScreen #connect-error.visible {
        display: block;
    }
    ConnectScreen .ascii-art {
        text-align: center;
        color: #DC382D;
        padding: 0 0 1 0;
        width: 100%;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Center():
            with Vertical(id="connect-card"):
                yield Static(
                    r"""[bold #DC382D]
  _____ ____          _ _
 |_   _|  _ \ ___  __| (_)___
   | | | |_) / _ \/ _` | / __|
   | | |  _ <  __/ (_| | \__ \
   |_| |_| \_\___|\__,_|_|___/[/]""",
                    classes="ascii-art",
                )
                yield Static("Redis Terminal UI Client", id="connect-subtitle")
                yield Static("Host", classes="form-label")
                yield Input(value="127.0.0.1", placeholder="Redis host", id="host-input")
                with Horizontal(id="connect-row"):
                    yield Input(value="6379", placeholder="Port", id="port-input", type="integer")
                    yield Input(value="0", placeholder="DB", id="db-input", type="integer")
                yield Static("Password", classes="form-label")
                yield Input(placeholder="(optional)", password=True, id="password-input")
                yield Static("", id="connect-error")
                yield Button("🔗 Connect", variant="primary", id="connect-btn")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "connect-btn":
            self._do_connect()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Allow pressing Enter in any input to connect."""
        self._do_connect()

    def _do_connect(self):
        host = self.query_one("#host-input", Input).value.strip() or "127.0.0.1"
        port_str = self.query_one("#port-input", Input).value.strip() or "6379"
        db_str = self.query_one("#db-input", Input).value.strip() or "0"
        password = self.query_one("#password-input", Input).value

        try:
            port = int(port_str)
        except ValueError:
            port = 6379
        try:
            db = int(db_str)
        except ValueError:
            db = 0

        error_label = self.query_one("#connect-error", Static)

        from tuiredis.redis_client import RedisClient

        client = RedisClient(host=host, port=port, password=password or None, db=db)
        if client.connect():
            error_label.update("")
            error_label.remove_class("visible")
            self.app.redis_client = client  # type: ignore[attr-defined]
            self.app.push_screen("main")
        else:
            error_label.update(f"❌ Cannot connect to {host}:{port}")
            error_label.add_class("visible")
