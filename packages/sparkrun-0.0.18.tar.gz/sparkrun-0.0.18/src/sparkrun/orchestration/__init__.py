"""Orchestration layer for sparkrun: SSH, Docker, and cluster management."""
