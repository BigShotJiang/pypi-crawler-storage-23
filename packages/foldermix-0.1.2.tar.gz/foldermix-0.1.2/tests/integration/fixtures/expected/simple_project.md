# FolderPack Context

- **Root**: `__ROOT__`
- **Generated**: 2024-01-02T00:00:00+00:00
- **Version**: 0.1.2
- **Files**: 3
- **Total bytes**: 32

## Table of Contents

- [alpha.md](#alphamd)
- [code.py](#codepy)
- [nested/note.txt](#nestednotetxt)

---

## alpha.md {#alphamd}

- **Size**: 8 bytes
- **Modified**: 2024-01-01T00:00:00+00:00

```markdown
# Alpha
```

---

## code.py {#codepy}

- **Size**: 12 bytes
- **Modified**: 2024-01-01T00:00:00+00:00

```python
print("hi")
```

---

## nested/note.txt {#nestednotetxt}

- **Size**: 12 bytes
- **Modified**: 2024-01-01T00:00:00+00:00

```
line1
line2
```

---
