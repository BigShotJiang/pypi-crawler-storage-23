from enum import Enum
from typing import Callable, Iterable, Literal, Type, TypeAlias, TypeVar

from rich.text import TextType
from textual.widgets._option_list import Option  # noqa

from .options import FilteredItems, SelectionStrategy
from .searchable_list_app import SearchableListApp
from .searchable_list_widget import SelectionItemType, SelectionType

T = TypeVar('T')
T_Enum = TypeVar('T_Enum', bound=Enum)
SelectionResultType: TypeAlias = SelectionType | Option


def select(
    selections: Iterable[SelectionItemType],
    selection_strategy: SelectionStrategy,
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[SelectionType]], TextType | None] | None = None,
    **kwargs,
) -> list[SelectionResultType]:
    """
    Select one or more items.

    See Textual's ``App.run(...)`` for more options.

    :param selections: The items to choose from.
    :param selection_strategy: What to do when more than one item is detected.
        See ``SelectionStrategy`` for more details.
    :param search_title: Title of the search.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    # if selection_strategy is SelectionStrategy.ALL:
    #     return list(selections)

    app: SearchableListApp = SearchableListApp(
        selections,
        selection_strategy,
        search_title=search_title,
        description=description,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )
    if app_title:
        app.title = app_title
    selected = app.run(inline=inline)
    return selected or []


def select_enum(
    enum_type: Type[T_Enum],
    selection_strategy: SelectionStrategy = SelectionStrategy.ONE,
    select_by: Literal['name', 'value'] = 'name',
    exclude: Iterable[T_Enum] | None = None,
    title: str = '',
    description: TextType | None = None,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[str]], TextType | None] | None = None,
    **kwargs,
) -> list[T_Enum]:
    """
    Select from an enum.

    :param enum_type: The enum type to select from.
    :param selection_strategy: What to do when more than one item is detected.
        See ``SelectionStrategy`` for more details.
    :param select_by: Whether to select by enum name or value.
    :param exclude: An iterable of enum values to exclude from selection.
    :param title: The title of the selection dialog.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    selectable_items = [item for item in enum_type if item not in (exclude or [])]

    selections = (
        [(item.name, item) for item in selectable_items]
        if select_by == 'name'
        else [(item.value, item) for item in selectable_items]
    )

    title = title or f'Select from {enum_type.__name__}'

    return select(  # type: ignore
        selections=selections,
        selection_strategy=selection_strategy,
        search_title=title,
        description=description,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )


def select_one(
    selections: Iterable[SelectionItemType],
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[SelectionType]], TextType | None] | None = None,
    **kwargs,
) -> SelectionResultType:
    """
    Select one item.

    Similar to running ``select`` with ``SelectionStrategy.ONE``.

    See Textual's ``App.run(...)`` for more options.

    :param selections: The items to choose from.
    :param search_title: Title of the search.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    selected = select(
        selections,
        SelectionStrategy.ONE,
        search_title=search_title,
        description=description,
        app_title=app_title,
        inline=inline,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )

    if not selected:
        raise ValueError('No selection made.')

    return selected[0]
