from __future__ import annotations

from typing import Protocol


class Signer(Protocol):
    scheme: str

    def sign(self, payload: dict, preview: dict) -> str: ...


def canonical_preview_from_payload(payload: dict) -> dict:
    payout = payload.get("payout", {})
    return {
        "deal_id": payload.get("deal_id"),
        "settlement_template_hash": payload.get("settlement_template_hash"),
        "to_seller": int(payout.get("to_seller", 0)),
        "to_buyer": int(payout.get("to_buyer", 0)),
        "fee_to_sink": int(payout.get("fee_to_sink", 0)),
        "nonce": int(payload.get("nonce", 0)),
        "expiry": int(payload.get("expiry", 0) or 0),
    }


def assert_signer_preview_guardrails(payload: dict, preview: dict) -> None:
    expected = canonical_preview_from_payload(payload)
    missing = [k for k in expected if k not in preview]
    if missing:
        raise ValueError(f"Refusing blind signing; preview missing fields: {missing}")
    if any(preview[k] != expected[k] for k in expected):
        raise ValueError("Refusing blind signing; payload does not match preview")
