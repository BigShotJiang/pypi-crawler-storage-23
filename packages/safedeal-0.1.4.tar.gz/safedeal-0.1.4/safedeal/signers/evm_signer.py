from __future__ import annotations

from .base import assert_signer_preview_guardrails
from ..crypto import message_hash, sha256_hex


class EvmSigner:
    """Reference EVM signer abstraction (ethers/KMS/remote backends can be wired later)."""

    scheme = "eip712"

    def __init__(self, signer_id: str) -> None:
        self.signer_id = signer_id

    def sign(self, payload: dict, preview: dict) -> str:
        assert_signer_preview_guardrails(payload, preview)
        return sha256_hex(f"eip712|{self.signer_id}|{message_hash(payload, exclude_sig=False)}")
