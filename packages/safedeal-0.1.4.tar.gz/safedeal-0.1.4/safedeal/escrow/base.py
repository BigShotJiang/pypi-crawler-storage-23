from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(slots=True)
class EscrowState:
    backend: str
    deal_id: str
    amount_base_units: int
    mode: str = "FULL"
    buffer_rate_ppm: int = 0
    unlocked_base_units: int = 0
    withdrawn_base_units: int = 0
    buffer_locked_base_units: int = 0
    settlement_template_hash: str | None = None
    funded: bool = False
    released: bool = False


class EscrowBackendAdapter(Protocol):
    def create_escrow(self, deal_id: str, amount_base_units: int, **kwargs) -> EscrowState: ...

    def fund_escrow(self, deal_id: str) -> dict: ...

    def build_settlement_tx(self, deal_id: str, payout: dict) -> dict: ...

    def sign_settlement_tx(self, tx: dict, signer: str) -> dict: ...

    def broadcast_settlement_tx(self, tx: dict) -> dict: ...

    def verify_funding(self, deal_id: str) -> bool: ...

    def verify_settlement(self, deal_id: str) -> bool: ...
