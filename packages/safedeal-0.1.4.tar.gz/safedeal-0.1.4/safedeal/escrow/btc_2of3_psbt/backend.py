from __future__ import annotations


class Btc2of3PsbtAdapter:
    """Planned backend skeleton for v0.2.

    API contract exists so SDK users can code against a stable adapter shape,
    while production logic is implemented after EVM backend maturity.
    """

    backend_name = "BTC_2OF3_PSBT"

    def create_escrow(self, deal_id: str, amount_base_units: int, **kwargs) -> dict:
        return {
            "backend": self.backend_name,
            "deal_id": deal_id,
            "status": "not_implemented",
            "next": "derive_p2wsh_and_build_psbt_templates",
        }
