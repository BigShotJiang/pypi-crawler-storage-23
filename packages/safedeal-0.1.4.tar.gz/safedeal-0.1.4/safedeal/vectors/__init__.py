"""Vector package resources."""
