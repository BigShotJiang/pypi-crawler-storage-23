from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
from typing import Any

from .crypto import CANONICAL_SPEC_VERSION, derive_deal_id, message_hash, offer_hash, pseudo_sign
from .models import DealAccept, DealBind, DealOffer, DealQuote, Identity

PROTOCOL_VERSION = "safedeal-0.1"


def make_quote_message(
    seller: Identity,
    buyer: Identity,
    asset: dict[str, Any],
    escrow: dict[str, Any],
    terms: dict[str, Any],
    arbitration: dict[str, Any],
    economics: dict[str, Any],
) -> DealQuote:
    payload = {
        "version": PROTOCOL_VERSION,
        "canonical_spec_version": CANONICAL_SPEC_VERSION,
        "seller_id": asdict(seller),
        "buyer_id": asdict(buyer),
        "asset": asset,
        "escrow": escrow,
        "terms": terms,
        "arbitration": arbitration,
        "economics": economics,
    }
    return DealQuote(**payload)


def make_bind_message(quote: DealQuote, signing_key_hint: str, settlement_template_hash: str) -> DealBind:
    quote_dict = asdict(quote)
    q_hash = offer_hash(quote_dict)
    bind_payload = {
        "version": PROTOCOL_VERSION,
        "canonical_spec_version": CANONICAL_SPEC_VERSION,
        "quote_hash": q_hash,
        "buyer_id": quote_dict["buyer_id"],
        "seller_id": quote_dict["seller_id"],
        "asset": quote_dict["asset"],
        "escrow": quote_dict["escrow"],
        "terms": quote_dict["terms"],
        "arbitration": quote_dict["arbitration"],
        "settlement_template_hash": settlement_template_hash,
    }
    bind_hash = message_hash(bind_payload)
    deal_id = "0x" + sha256(bind_hash.encode("utf-8")).hexdigest()
    bind_payload["deal_id"] = deal_id
    bind_payload["bind_hash"] = bind_hash
    msg_hash = message_hash(bind_payload)
    buyer_sig_scheme = quote.buyer_id["sig_scheme"] if isinstance(quote.buyer_id, dict) else quote.buyer_id.sig_scheme
    bind_payload["sig"] = pseudo_sign(msg_hash, signing_key_hint, buyer_sig_scheme)
    return DealBind(**bind_payload)


def make_offer_message(
    seller: Identity,
    buyer: Identity,
    asset: dict[str, Any],
    escrow: dict[str, Any],
    terms: dict[str, Any],
    arbitration: dict[str, Any],
    economics: dict[str, Any],
    signing_key_hint: str,
) -> DealOffer:
    provisional = {
        "version": PROTOCOL_VERSION,
        "canonical_spec_version": CANONICAL_SPEC_VERSION,
        "deal_id": "0x00",
        "seller_id": asdict(seller),
        "buyer_id": asdict(buyer),
        "asset": asset,
        "escrow": escrow,
        "terms": terms,
        "arbitration": arbitration,
        "economics": economics,
    }
    o_hash = offer_hash(provisional)
    final_deal_id = derive_deal_id(o_hash, buyer.pk, seller.pk)
    provisional["deal_id"] = final_deal_id
    msg_hash = message_hash(provisional)
    provisional["sig"] = pseudo_sign(msg_hash, signing_key_hint, seller.sig_scheme)
    return DealOffer(**provisional)


def make_accept_message(
    offer: DealOffer,
    expected_hashes: dict[str, str],
    signing_key_hint: str,
) -> DealAccept:
    offer_dict = asdict(offer)
    accept_payload = {
        "version": PROTOCOL_VERSION,
        "canonical_spec_version": CANONICAL_SPEC_VERSION,
        "deal_id": offer.deal_id,
        "offer_hash": offer_hash(offer_dict),
        "expected_hashes": expected_hashes,
    }
    msg_hash = message_hash(accept_payload)
    buyer_sig_scheme = offer.buyer_id["sig_scheme"] if isinstance(offer.buyer_id, dict) else offer.buyer_id.sig_scheme
    accept_payload["sig"] = pseudo_sign(msg_hash, signing_key_hint, buyer_sig_scheme)
    return DealAccept(**accept_payload)
