from __future__ import annotations

from dataclasses import dataclass

from ...crypto import sha256_hex
from ..base import DecisionArtifact


@dataclass(slots=True)
class DummyDecision(DecisionArtifact):
    pass


class DummyRulesAdapter:
    """Simple deterministic adapter to prove arbitration backend pluggability."""

    policy_id = "dummy-rules-v1"

    def to_case_bundle(self, dispute: dict, evidence: dict) -> dict:
        del evidence
        decision_inputs_hash = sha256_hex(f"dummy|{dispute['deal_id']}|{dispute.get('claim_code', '')}")
        economic_seal_hash = sha256_hex(f"dummy|{dispute.get('escrow_amount', 0)}")
        return {
            "policy_id": self.policy_id,
            "dispute": dispute,
            "decision_inputs_hash": decision_inputs_hash,
            "economic_seal_hash": economic_seal_hash,
        }

    def resolve(self, case_bundle: dict) -> DummyDecision:
        dispute = case_bundle["dispute"]
        amount = int(dispute.get("escrow_amount", 0))
        fee = int(dispute.get("fee", 0))
        half = max(0, amount - fee) // 2
        amounts = {"to_seller": half, "to_buyer": max(0, amount - fee) - half, "fee_to_sink": fee}
        return DummyDecision(
            deal_id=dispute["deal_id"],
            milestone_id=dispute["milestone_id"],
            winner="seller" if amounts["to_seller"] >= amounts["to_buyer"] else "buyer",
            amount_to_winner=max(amounts["to_seller"], amounts["to_buyer"]),
            fee=fee,
            decision_hash=sha256_hex(f"dummy-decision|{dispute['deal_id']}|{amount}"),
            decision_inputs_hash=case_bundle["decision_inputs_hash"],
            economic_seal_hash=case_bundle["economic_seal_hash"],
            award={"amounts": amounts},
        )

    def verify_decision(self, decision: DummyDecision, case_bundle: dict | None = None) -> bool:
        if not decision.decision_hash.startswith("0x"):
            return False
        if case_bundle is None:
            return True
        return decision.decision_inputs_hash == case_bundle.get("decision_inputs_hash")
