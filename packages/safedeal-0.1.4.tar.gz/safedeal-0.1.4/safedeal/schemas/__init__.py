"""Schema package resources."""
