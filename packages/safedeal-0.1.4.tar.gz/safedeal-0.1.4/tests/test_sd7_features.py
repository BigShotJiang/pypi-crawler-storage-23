from safedeal.escrow.evm_escrow_v1.backend import EvmEscrowV1Adapter
from safedeal.models import Identity
from safedeal.sdk import SafeDealSDK
import safedeal_minimal as sdm


def _offer(now: int):
    return {
        "seller": Identity(pk="seller_pk", sig_scheme="ed25519"),
        "buyer": Identity(pk="buyer_pk", sig_scheme="ed25519"),
        "asset": {"currency": "USDC", "amount": "1000.00", "amount_sats": None},
        "escrow": {"backend": "EVM_ESCROW_V1", "mode": "FULL", "buffer_rate_ppm": 0, "params": {}},
        "terms": {
            "deliverable_type": "HASH_MATCH",
            "milestones": [{"milestone_id": "M1", "amount": "1000.00", "expected_hash": "0xabc"}],
            "deadlines": {},
        },
        "arbitration": {"enabled": True, "arb_policy_id": "arb-v1.7", "arb_public_keys": ["arb1"], "quorum": 1},
        "economics": {"escrow_creation_fee": {"currency": "USDC", "amount": "0.00"}},
    }


def test_announcement_and_version_guard_and_batch():
    released = []
    sdk = SafeDealSDK(EvmEscrowV1Adapter(), now_fn=lambda: 1700000000, on_release=lambda d, a, f: released.append((d, a, f)))
    offer = sdk.make_offer(signing_key_hint="seller_pk", **_offer(1700000000))
    accept = sdk.accept_offer(offer, {"M1": "0xabc"}, signing_key_hint="buyer_pk")
    state = sdk.escrow_prepare(offer, accept)
    sdk.escrow_fund(state)
    fee = sdk.escrow.compute_protocol_fee(state.amount_base_units)
    txs = sdk.build_batch_release([
        {
            "deal_id": offer.deal_id,
            "payout": {"to_seller": state.amount_base_units - fee, "to_buyer": 0, "fee_to_sink": fee},
            "settlement_template_hash": state.settlement_template_hash,
            "method": "releaseByMutual",
        }
    ])
    assert len(txs) == 1

    delivery = sdk.deliver(offer.deal_id, "M1", "0xabc", observed_block=1)
    out = sdk.auto_settle_objective(delivery, expected_hash="0xabc", wait_blocks=0, current_block=1, dispute_filed=False)
    assert out["status"] == "released"
    assert released and released[0][2] == fee

    ann = sdk.export_announcement(offer.deal_id)
    assert sdk.verify_announcement(ann)

    try:
        sdk.assert_protocol_compatibility("0xdeadbeef")
        assert False
    except ValueError:
        pass


def test_fast_objective_mode_and_minimal_compatibility_guard():
    sdk = SafeDealSDK(EvmEscrowV1Adapter(), now_fn=lambda: 1700000000)
    handle = sdk.create_deal(
        seller=Identity(pk="seller_pk", sig_scheme="ed25519"),
        buyer=Identity(pk="buyer_pk", sig_scheme="ed25519"),
        amount="1000.00",
        deliverable_hash="0xabc",
        objective_only=True,
        objective_only_fast=True,
    )
    state = sdk.escrow_prepare(handle.offer, handle.accept)
    sdk.escrow_fund(state)
    delivery = sdk.deliver(handle.deal_id, "M1", "0xabc", observed_block=10)
    out = sdk.auto_settle_objective(delivery, expected_hash="0xabc", wait_blocks=100, current_block=10, dispute_filed=False)
    assert out["status"] == "released"

    bind = sdm.build_bind(
        quote_hash="0xq",
        buyer_id={"pk": "b", "sig_scheme": "ed25519"},
        seller_id={"pk": "s", "sig_scheme": "ed25519"},
        asset={"currency": "USDC", "amount": "1000.00"},
        escrow={"backend": "EVM_ESCROW_V1"},
        terms={"deliverable_type": "HASH_MATCH"},
        arbitration={"enabled": False},
        economics={"protocol_fee_ppm": 1000, "protocol_fee_min": 1},
    )
    ann = sdm.export_announcement(bind, timestamp=1700000000)
    assert sdm.verify_announcement(ann)
    try:
        sdm.assert_protocol_compatibility("0xdeadbeef")
        assert False
    except ValueError:
        pass
