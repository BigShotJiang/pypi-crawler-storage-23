from __future__ import annotations

import json
from datetime import datetime, timezone

from safedeal.capabilities import capabilities_hash, negotiate_capabilities, sign_capabilities, verify_capabilities
from safedeal.crypto import canonical_json
from safedeal.sdk import SAFEDEAL_PROTOCOL_HASH


def _base_doc(sig_scheme: str = "ed25519") -> dict:
    return {
        "type": "safedeal.capabilities",
        "schema_version": 1,
        "protocol": {
            "protocol_version": "1.0.0",
            "protocol_hash": SAFEDEAL_PROTOCOL_HASH,
        },
        "agent": {
            "agent_id": "pk:agent1",
            "sig_scheme": sig_scheme,
        },
        "capabilities": {
            "supported_backends": [
                {
                    "backend_id": "EVM_ESCROW_V1",
                    "modes": ["FULL"],
                    "assets": ["USDC"],
                    "chain_id": 1,
                    "contract": {
                        "escrow_contract": "0xabc123",
                    },
                }
            ],
            "objective_only": {
                "supported": True,
                "fast_supported": True,
                "supported_deliverables": ["HASH_MATCH"],
            },
            "economics": {
                "protocol_fee_ppm": 1000,
                "protocol_fee_min_units": "1",
                "protocol_fee_sink": "0xfee000",
                "dispute_fee_mode": "ON_DISPUTE_ONLY",
            },
            "arbitration": {
                "supported": True,
                "adapter_ids": ["arb-v1.7"],
                "arbitrator_keys": ["0xabc123"],
                "quorum": 1,
            },
        },
        "validity": {
            "issued_at": "2026-02-24T00:00:00Z",
            "expires_at": "2026-05-25T00:00:00Z",
        },
    }


def test_sign_and_verify_ed25519_capabilities():
    doc = sign_capabilities(_base_doc("ed25519"), signing_key_hint="pk:agent1")
    assert verify_capabilities(doc, now=datetime(2026, 3, 1, tzinfo=timezone.utc), signing_key_hint="pk:agent1")


def test_sign_and_verify_eip712_capabilities():
    doc = sign_capabilities(_base_doc("eip712"), signing_key_hint="pk:agent1")
    assert verify_capabilities(doc, now=datetime(2026, 3, 1, tzinfo=timezone.utc), signing_key_hint="pk:agent1")


def test_rejects_uppercase_hex_and_bad_quorum_and_protocol_mismatch():
    bad_hex = _base_doc()
    bad_hex["capabilities"]["supported_backends"][0]["contract"]["escrow_contract"] = "0xAbc123"
    try:
        capabilities_hash(bad_hex)
        assert False
    except ValueError:
        pass

    bad_quorum = sign_capabilities(_base_doc(), signing_key_hint="pk:agent1")
    bad_quorum["capabilities"]["arbitration"]["quorum"] = 2
    assert not verify_capabilities(bad_quorum, now=datetime(2026, 3, 1, tzinfo=timezone.utc), signing_key_hint="pk:agent1")

    bad_protocol = sign_capabilities(_base_doc(), signing_key_hint="pk:agent1")
    bad_protocol["protocol"]["protocol_hash"] = "0xdeadbeef"
    assert not verify_capabilities(bad_protocol, now=datetime(2026, 3, 1, tzinfo=timezone.utc), signing_key_hint="pk:agent1")


def test_capabilities_golden_vectors_consistency():
    vectors = json.loads(open("safedeal/vectors/capabilities_vectors.json", "r", encoding="utf-8").read())
    payload = vectors["payload"]

    assert canonical_json(payload) == vectors["expected_canonical_json"]
    assert capabilities_hash(payload) == vectors["expected_sha256_hash"]

    signed = sign_capabilities(payload, signing_key_hint=vectors["test_key"])
    assert signed["sig"] == vectors["expected_signature"]
    assert verify_capabilities(
        signed,
        now=datetime(2026, 3, 1, tzinfo=timezone.utc),
        signing_key_hint=vectors["test_key"],
    ) == vectors["expected_verification"]


def test_negotiate_capabilities_deterministic_intersection():
    local = _base_doc()
    local["capabilities"]["supported_backends"] = [
        {"backend_id": "BTC_2OF3_PSBT", "modes": ["FULL"], "assets": ["BTC"], "chain_id": 0},
        {"backend_id": "EVM_ESCROW_V1", "modes": ["FULL", "STREAM_WITH_BUFFER"], "assets": ["USDC"], "chain_id": 1},
    ]
    local["capabilities"]["objective_only"]["supported_deliverables"] = ["ONCHAIN_PROOF", "HASH_MATCH"]

    remote = _base_doc()
    remote["capabilities"]["supported_backends"] = [
        {"backend_id": "EVM_ESCROW_V1", "modes": ["FULL"], "assets": ["USDC"], "chain_id": 1},
    ]
    remote["capabilities"]["objective_only"]["supported_deliverables"] = ["HASH_MATCH", "SIGNED_ATTESTATION"]
    remote["capabilities"]["arbitration"]["supported"] = False

    negotiated = negotiate_capabilities(local, remote)
    assert negotiated.backend_id == "EVM_ESCROW_V1"
    assert negotiated.mode == "FULL"
    assert negotiated.deliverable == "HASH_MATCH"
    assert not negotiated.arbitration_supported
    assert negotiated.objective_only_fast_supported


def test_negotiate_capabilities_protocol_mismatch_fails():
    local = _base_doc()
    remote = _base_doc()
    remote["protocol"]["protocol_hash"] = "0xdeadbeef"

    try:
        negotiate_capabilities(local, remote)
        assert False
    except ValueError:
        pass
