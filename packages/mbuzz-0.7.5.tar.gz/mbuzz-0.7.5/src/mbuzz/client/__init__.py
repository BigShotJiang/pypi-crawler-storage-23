"""Client module - stub for TDD."""
