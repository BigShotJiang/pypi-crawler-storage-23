"""Middleware for web frameworks."""
