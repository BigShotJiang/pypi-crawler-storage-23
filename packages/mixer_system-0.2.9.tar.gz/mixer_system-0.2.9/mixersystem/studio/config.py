from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class StudioConfig:
    host: str = "127.0.0.1"
    port: int = 8420
    project_root: Path = field(default_factory=Path.cwd)

    @property
    def sessions_dir(self) -> Path:
        return self.project_root / ".mixer" / "sessions"
