"""Discover session folders and read pipeline state from disk."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from mixersystem.studio.log_parser import TraceSummary, parse_trace_log
from mixersystem.studio.trace_db import has_trace_db, query_summary

WORKFLOW_STAGES = ["task", "plan", "work", "update", "upgrade", "report"]
ALL_WORKFLOWS = WORKFLOW_STAGES + ["questions"]


@dataclass
class SessionFolderInfo:
    path: Path
    name: str
    artifacts: dict[str, bool] = field(default_factory=dict)
    has_questions: dict[str, bool] = field(default_factory=dict)
    current_stage: str = ""
    trace_summary: TraceSummary | None = None
    last_activity: float = 0.0  # epoch seconds from folder mtime


def _has_questions(path: Path) -> bool:
    """Return True only if the file exists AND contains at least one question."""
    if not path.is_file():
        return False
    try:
        data = json.loads(path.read_text())
        return bool(data.get("questions"))
    except (json.JSONDecodeError, OSError):
        return False


def scan_session_folder(folder: Path) -> SessionFolderInfo:
    """Read one session folder's state from disk."""
    artifacts = {}
    has_questions = {}
    current_stage = ""
    for stage in WORKFLOW_STAGES:
        exists = (folder / f"{stage}.md").is_file()
        artifacts[stage] = exists
        has_questions[stage] = _has_questions(folder / f"{stage}_questions.json")
        if exists:
            current_stage = stage

    trace_summary = None
    if has_trace_db(folder):
        db_summary = query_summary(folder)
        trace_summary = TraceSummary(
            total_calls=db_summary.total_calls,
            total_duration_seconds=db_summary.total_duration_seconds,
            total_cost_usd=db_summary.total_cost_usd,
            agents=db_summary.agents,
        )
    else:
        trace_log = folder / "logs" / "agent_trace.log"
        if trace_log.is_file():
            trace_summary = parse_trace_log(trace_log)

    last_activity = folder.stat().st_mtime

    return SessionFolderInfo(
        path=folder,
        name=folder.name,
        artifacts=artifacts,
        has_questions=has_questions,
        current_stage=current_stage,
        trace_summary=trace_summary,
        last_activity=last_activity,
    )


def discover_session_folders(sessions_dir: Path) -> list[SessionFolderInfo]:
    """Scan .mixer/sessions/ for folders containing at least one artifact .md."""
    if not sessions_dir.is_dir():
        return []

    results = []
    for child in sessions_dir.iterdir():
        if not child.is_dir() or child.name.startswith(('.', '_')):
            continue
        results.append(scan_session_folder(child))
    results.sort(key=lambda f: f.last_activity, reverse=True)
    return results
