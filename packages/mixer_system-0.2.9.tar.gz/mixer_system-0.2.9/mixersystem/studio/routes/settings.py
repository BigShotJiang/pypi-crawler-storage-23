"""Settings API routes for Mixer Studio."""

from __future__ import annotations

import logging

from fastapi import APIRouter

log = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


@router.get("/modules")
def get_module_tree():
    """Return the global module tree and default_modules from settings.json."""
    try:
        from mixersystem.data.repository import load_settings
        settings = load_settings()
    except (ImportError, OSError, ValueError):
        return {"modules": {}, "default_modules": []}

    modules = settings.get("modules", {})
    if not isinstance(modules, dict):
        modules = {}

    default_modules = settings.get("default_modules", [])
    if not isinstance(default_modules, list):
        default_modules = []

    return {"modules": modules, "default_modules": default_modules}
