"""Workflow form definitions used by Studio to render dynamic forms."""

_PROVIDER_OPTIONS = [
    ("Claude", "claude"),
    ("Gemini", "gemini"),
    ("Codex", "codex"),
    ("Random", "random"),
]

WORKFLOW_FORMS = {
    "task": {
        "title": "Create Task",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Describe what needs to be done"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "plan": {
        "title": "Create Plan",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "plan_builder_provider", "type": "select", "label": "Provider",
             "options": _PROVIDER_OPTIONS, "default": "claude"},
            {"name": "branch_count", "type": "text", "label": "Branches",
             "default": "1", "placeholder": "Number of parallel drafts (minimum 1)"},
            {"name": "max_revisions", "type": "text", "label": "Max Revisions",
             "default": "2", "placeholder": "0 to skip review"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the artifact builder"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "work": {
        "title": "Create Work",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "work_builder_provider", "type": "select", "label": "Provider",
             "options": _PROVIDER_OPTIONS, "default": "claude"},
            {"name": "max_test_iterations", "type": "text", "label": "Max Tests",
             "default": "5", "placeholder": "0 to skip testing"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the artifact builder"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "update": {
        "title": "Create Update",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the artifact builder"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "upgrade": {
        "title": "Create Upgrade",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the artifact builder"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "report": {
        "title": "Create Report",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the artifact builder"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "questions": {
        "title": "Create Questions",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "provider", "type": "select", "label": "Provider",
             "options": _PROVIDER_OPTIONS, "default": "claude"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the question generator"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
    "answer": {
        "title": "Answer Questions",
        "fields": [
            {"name": "session_folder", "type": "text", "label": "Session Folder",
             "placeholder": "Last used or auto-generated if empty"},
            {"name": "provider", "type": "select", "label": "Provider",
             "options": _PROVIDER_OPTIONS, "default": "claude"},
            {"name": "instructions", "type": "textarea", "label": "Instructions",
             "placeholder": "Optional guidance for the AI answerer"},
            {"name": "lite", "type": "switch", "label": "Lite mode (smaller model, faster + cheaper)"},
        ],
    },
}
