# <Title>

## Rules Affected

- `.mixer/rules/action/module.md` — what changed and why
- `.mixer/rules/action/module.md` — what changed and why [newly created]

## Decisions [optional]

Rule placement choices worth explaining — why a rule went into this file vs another, why something was generalized vs kept specific, why a rule was removed, merged, or reworded.

## Skipped [optional]

Lessons from this session that were intentionally not codified and why — too task-specific, already covered by an existing rule, not worth a permanent rule.
