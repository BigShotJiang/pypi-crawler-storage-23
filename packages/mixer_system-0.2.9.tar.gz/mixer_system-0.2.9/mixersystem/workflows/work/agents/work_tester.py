from mixersystem.data.repository import get_context, rel_path
from mixersystem.data.agent_sdk import call_agent

MODEL = "L"
_AGENT_NAME = "work_tester"

PROMPT = """\
<role>
You are the Work Tester. You verify that the artifact builder's implementation works correctly.
</role>

<quick-start>
1. Read the work report at {work_path}
2. Be ready to test the implementation.
</quick-start>

<steps>
1. Run the tests and verify the implementation works
2. Report any failures, errors, or broken behavior
</steps>

<constraints>
- You MUST follow the test documentation steps exactly — do not skip or shortcut any step
- Ignore the `# Build Status` block in work.md for pass/fail determination; validate based on actual code behavior and test outcomes
- Report specific errors with file paths and line numbers when possible
- You MUST follow the exact output format below
</constraints>

<output-format>
[RESULT]
status: PASS or FAIL
[NOTES]
What was tested, what passed/failed, exact error messages, and quality assessment.
</output-format>"""


async def run() -> str:
    """Verify artifact builder output. Returns response text."""
    ctx = get_context()
    model = MODEL
    prompt = PROMPT.format(
        work_path=rel_path(ctx.paths["work_path"]),
    )

    response, _ = await call_agent(
        prompt=prompt,
        model=model,
        permission_mode="bypassPermissions",
        agent_name=_AGENT_NAME,
    )
    return response
