# Update Workflow

The update workflow reads `work.md` and the project's existing module doc files (`_name.md`), applies documentation updates directly, and produces `update.md` — a report of what was changed.

## Inputs

- `session_folder` (required) — should typically contain `work.md`.
- `instructions` — optional free-text guidance injected into the artifact builder's prompt.

## Orchestration

The orchestrator (`create_update.py`) is straightforward — it calls the artifact builder once. No loops or sub-agents.

## Agents

**Artifact Builder** (`shared/builder.py`, stage `update`, model L) — analyzes what changed in the work report, compares against existing module doc files (`_name.md`), and edits them directly to reflect the completed work. Creates new module docs when the work introduces something new enough to warrant it. Decides how far up the module hierarchy a change needs to propagate. Writes `update.md` listing every module doc affected (with `[newly created]` where applicable) and a Decisions section for non-obvious placement choices. Only applies changes that reflect actual completed work — no invented additions.
