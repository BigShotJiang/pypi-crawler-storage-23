# <Title>

## Modules Affected

- `path/to/_module.md` — what changed and why
- `path/to/_module.md` — what changed and why [newly created]

## Decisions [optional]

Documentation placement choices worth explaining — why something went into this doc vs another, why a change was added to a global module doc vs a specific one, why something was intentionally left out.
