from mixersystem.data.repository import get_context, rel_path
from mixersystem.data.agent_sdk import call_agent

MODEL = "L"

PROMPT = """\
<role>
{role}
</role>

<steps>
1. Read the current artifact (if any):
{current_artifact}
2. Read other session artifacts:
{artifacts}
3. Read the project docs:
{docs}
4. Read the rules you must follow:
{rules}
5. Read the template of the artifact you are producing. You MUST follow this template:
{template}
6. Read the answered questions — these are clarifications that MUST be integrated:
{questions}
7. Read the additional instructions from the user:
{instructions}
8. Based on everything above, produce the artifact and write it to {artifact_path}
</steps>

<constraints>
- Re-read your role carefully — everything it says is a hard requirement
- Follow the template structure exactly
- Instructions (if any) always take priority over all other inputs
- Only do what the inputs describe — do not invent scope or changes
- You MUST follow the exact output format below
</constraints>

<output-format>
[RESULT]
status: DONE
[NOTES]
Summary of what you did.
</output-format>"""

RESUME_PROMPT = """\
Please apply the following feedback to the file you just produced:

{feedback}

<constraints>
- Apply all feedback points
- Follow all previous requirements and context you were given
- You MUST follow the exact output format below
</constraints>

<output-format>
[RESULT]
status: DONE
[NOTES]
Summary of what was revised.
</output-format>"""


async def run(*, stage: str,
              provider: str = "claude", instructions: str | None = None) -> str:
    ctx = get_context()
    none = "(none, proceed to the next step)"

    prompt = PROMPT.format(
        role=ctx.resolve_role(stage, "artifact-builder"),
        current_artifact=ctx.resolve_current_artifact(stage) or none,
        artifacts=ctx.resolve_artifacts(stage) or none,
        docs=ctx.resolve_docs() or none,
        rules=ctx.resolve_rules(stage) or none,
        template=ctx.resolve_template(stage) or none,
        questions=ctx.resolve_questions(stage) or none,
        instructions=instructions or none,
        artifact_path=rel_path(ctx.paths[f"{stage}_path"]),
    )

    _, session_id = await call_agent(
        prompt=prompt,
        model=MODEL,
        provider=provider,
        agent_name=f"{stage}_artifact_builder",
    )
    return session_id


async def run_resume(*, stage: str, feedback: str,
                     session_id: str, provider: str = "claude") -> str:
    prompt = RESUME_PROMPT.format(feedback=feedback)

    _, session_id = await call_agent(
        prompt=prompt,
        model=MODEL,
        provider=provider,
        agent_name=f"{stage}_artifact_builder",
        is_resume=True,
        session_id=session_id,
    )
    return session_id
