# Data Layer

This file documents shared runtime infrastructure in the data layer.

## Scope

The data layer provides shared mechanics used by all workflows and agents:

- context lifecycle and context resolution
- settings and module tree loading
- task/frontmatter parsing and updates
- CLI parsing and workflow bootstrapping
- provider dispatch and logging via `call_agent(...)`
- Linear API integration (load, push, update issues)

## `repository.py`

Core responsibilities:

- `WorkflowContext` and `context_scope(...)`
- canonical path derivation from `session_folder`
- module-aware context resolution from the runtime settings map (`settings.json`)
- task parsing (`parse_task`) and frontmatter updates (`update_frontmatter`)
- CLI adapter (`run_cli`)

## `agent_sdk.py`

Core responsibilities:

- unified `call_agent(...)` API
- provider dispatch (`claude`, `gemini`, `codex`)
- timeout and error handling for provider calls
- raw/trace logging into session-folder logs/ (agent_trace.log, agent_raw.log)
- automatic result-format retry when `[RESULT]` block is missing
- `AskUserQuestion` is always disallowed — agents run autonomously with no user interrupts

## `linear_sync.py`

Core responsibilities:

- Linear GraphQL API client (load, push, update issues)
- team ID and state resolution from settings/env
- task.md ↔ Linear issue conversion

## Layer Contract

- Keep this layer reusable by all workflow features.
- Keep workflow-specific policy decisions out of this layer.
- Keep parsing, settings resolution, and provider behavior deterministic.
