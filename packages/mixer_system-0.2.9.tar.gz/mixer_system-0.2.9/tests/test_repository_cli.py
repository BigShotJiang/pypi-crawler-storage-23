import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from mixersystem.data.repository import get_context, run_cli


class RepositoryCLITest(unittest.TestCase):
    def test_depth_is_ignored_for_workflow_with_session_folder_param(self) -> None:
        captured = {"session_folder": None, "lite": None}

        async def dummy_run(session_folder: str, lite: bool = False):
            captured["session_folder"] = session_folder
            captured["lite"] = lite
            return None

        argv = [
            "prog",
            "--session_folder=./.mixer/sessions/test-depth-strip",
            "--depth=7",
            "--lite=true",
        ]
        with patch.object(sys, "argv", argv):
            run_cli(dummy_run)

        self.assertIsNotNone(captured["session_folder"])
        self.assertTrue(str(captured["session_folder"]).endswith(".mixer/sessions/test-depth-strip"))
        self.assertEqual(captured["lite"], True)

    def test_depth_is_ignored_for_internal_context_scope_branch(self) -> None:
        captured = {"depth": None, "session_folder": None}

        async def dummy_run_no_session_folder():
            ctx = get_context()
            captured["depth"] = ctx.depth
            captured["session_folder"] = ctx.session_folder
            return None

        argv = [
            "prog",
            "--session_folder=./.mixer/sessions/test-depth-internal",
            "--depth=99",
        ]
        with patch.object(sys, "argv", argv):
            run_cli(dummy_run_no_session_folder)

        self.assertEqual(captured["depth"], 0)
        self.assertIsNotNone(captured["session_folder"])
        self.assertTrue(Path(captured["session_folder"]).name == "test-depth-internal")


if __name__ == "__main__":
    unittest.main()
