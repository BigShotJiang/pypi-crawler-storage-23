"""Integration tests for core MixerSystem context mechanics."""

import tempfile
import unittest
from pathlib import Path

from mixersystem.data.repository import WorkflowContext, context_scope


class TestContextResolution(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.session_folder = self.temp_dir.name

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_context_resolution_basic(self):
        with context_scope(session_folder=self.session_folder) as ctx:
            self.assertIsInstance(ctx, WorkflowContext)
            self.assertIsNotNone(ctx.session_folder)

    def test_context_canonical_paths(self):
        with context_scope(session_folder=self.session_folder) as ctx:
            self.assertTrue(Path(ctx.session_folder).is_absolute())

    def test_artifact_resolution(self):
        task_path = Path(self.session_folder) / "task.md"
        task_path.write_text("# Test Task\n\nThis is a test task.\n")
        with context_scope(session_folder=self.session_folder) as ctx:
            artifacts = ctx.resolve_artifacts()
            self.assertIsNotNone(artifacts)


class TestContextIsolation(unittest.TestCase):

    def test_multiple_session_folders_isolated(self):
        with tempfile.TemporaryDirectory() as temp1:
            with tempfile.TemporaryDirectory() as temp2:
                with context_scope(session_folder=temp1) as ctx1:
                    with context_scope(session_folder=temp2) as ctx2:
                        self.assertNotEqual(ctx1.session_folder, ctx2.session_folder)

    def test_artifact_isolation_between_sessions(self):
        with tempfile.TemporaryDirectory() as temp1:
            with tempfile.TemporaryDirectory() as temp2:
                task1 = Path(temp1) / "task.md"
                task1.write_text("# Test1\n")
                task2 = Path(temp2) / "task.md"
                self.assertTrue(task1.exists())
                self.assertFalse(task2.exists())


if __name__ == "__main__":
    unittest.main()
