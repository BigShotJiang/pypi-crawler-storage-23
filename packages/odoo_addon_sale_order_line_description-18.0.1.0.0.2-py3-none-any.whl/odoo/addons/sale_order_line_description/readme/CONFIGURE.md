The user has to belong to group_use_product_description_per_so_line.
This is possible by selecting the related option in the following menu:

- *Sales \> Settings \> Quotations & Orders \> Product Sale Description*
