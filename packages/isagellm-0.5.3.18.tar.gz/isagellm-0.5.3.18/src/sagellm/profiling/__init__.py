"""Performance profiling and interpolation utilities for sageLLM.

Provides tools for loading profiling results and estimating TTFT, ITL,
and throughput via interpolation over pre-captured performance data.

Example::

    from sagellm.profiling import PerformanceInterpolator

    interp = PerformanceInterpolator.from_csv("profiles/my_model.csv")
    ttft = interp.predict_ttft(input_seq_len=512)
    throughput = interp.predict_throughput(input_seq_len=512)
    max_isl = interp.reverse_ttft(target_ttft=0.3)
"""

from __future__ import annotations

from sagellm.profiling.performance_interpolator import (
    InterpolationMode,
    PerformanceInterpolator,
    ProfileDataPoint,
    ProfileDataset,
)

__all__ = [
    "InterpolationMode",
    "PerformanceInterpolator",
    "ProfileDataPoint",
    "ProfileDataset",
]
