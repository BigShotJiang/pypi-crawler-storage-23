"""Tests for PPDocLayoutV3Model.__init__ and predict_layout.

These tests mock all heavy dependencies (transformers, LayoutPostprocessor,
TimeRecorder) so they run without GPU or real model weights.
"""

from __future__ import annotations

import math
from unittest.mock import MagicMock, patch

import pytest
import torch
from docling.datamodel.base_models import BoundingBox, Cluster, LayoutPrediction
from docling_core.types.doc import DocItemLabel
from PIL import Image

from docling_pp_doc_layout.options import PPDocLayoutV3Options

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_page(
    page_no: int = 0, backend_valid: bool = True, has_size: bool = True, image: object = "default"
) -> MagicMock:
    """Return a mock Page with configurable validity properties."""
    page = MagicMock()
    page.page_no = page_no
    if backend_valid:
        page._backend = MagicMock()
        page._backend.is_valid.return_value = True
    else:
        page._backend = None
    page.size = MagicMock() if has_size else None
    if image == "default":
        page.get_image.return_value = Image.new("RGB", (800, 1000)) if has_size else None
    else:
        page.get_image.return_value = image
    page.predictions.layout = None
    return page


def _make_conv_res() -> MagicMock:
    return MagicMock()


def _make_cluster(confidence: float = 0.9, ix: int = 0) -> Cluster:
    """Return a real Cluster so it passes LayoutPrediction Pydantic validation."""
    return Cluster(
        id=ix,
        label=DocItemLabel.TEXT,
        confidence=confidence,
        bbox=BoundingBox(l=0.0, t=0.0, r=1.0, b=1.0),
        cells=[],
    )


@pytest.fixture
def model_instance() -> MagicMock:
    """PPDocLayoutV3Model with __init__ bypassed and internals mocked."""
    from docling_pp_doc_layout.model import PPDocLayoutV3Model

    with patch.object(PPDocLayoutV3Model, "__init__", lambda self, *a, **kw: None):
        instance = PPDocLayoutV3Model.__new__(PPDocLayoutV3Model)
        instance.options = PPDocLayoutV3Options()
        instance._device = "cpu"
        instance._image_processor = MagicMock()
        instance._model = MagicMock()
        instance._id2label = {0: "text", 1: "table", 2: "image"}
        return instance


# ---------------------------------------------------------------------------
# TestInit
# ---------------------------------------------------------------------------


class TestInit:
    """Verify that __init__ wires up all attributes correctly."""

    @pytest.fixture
    def hf_mocks(self):
        """Patch AutoImageProcessor, AutoModelForObjectDetection and decide_device."""
        mock_hf_model = MagicMock()
        mock_hf_model.config.id2label = {0: "text", 1: "table"}
        mock_hf_model.to.return_value = mock_hf_model
        mock_processor = MagicMock()

        with (
            patch("docling_pp_doc_layout.model.AutoImageProcessor") as mock_aip,
            patch("docling_pp_doc_layout.model.AutoModelForObjectDetection") as mock_aod,
            patch("docling_pp_doc_layout.model.decide_device", return_value="cpu"),
        ):
            mock_aip.from_pretrained.return_value = mock_processor
            mock_aod.from_pretrained.return_value = mock_hf_model
            yield {
                "mock_aip": mock_aip,
                "mock_aod": mock_aod,
                "mock_processor": mock_processor,
                "mock_hf_model": mock_hf_model,
            }

    def _build_model(self, hf_mocks, opts=None, device="cpu"):
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        accel_opts = MagicMock()
        accel_opts.device = device
        return PPDocLayoutV3Model(
            artifacts_path=None,
            accelerator_options=accel_opts,
            options=opts or PPDocLayoutV3Options(),
        )

    def test_stores_options(self, hf_mocks):
        opts = PPDocLayoutV3Options(confidence_threshold=0.3)
        model = self._build_model(hf_mocks, opts=opts)
        assert model.options is opts

    def test_stores_artifacts_path(self, hf_mocks):
        model = self._build_model(hf_mocks)
        assert model.artifacts_path is None

    def test_stores_accelerator_options(self, hf_mocks):
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        accel_opts = MagicMock()
        accel_opts.device = "cpu"
        with (
            patch("docling_pp_doc_layout.model.AutoModelForObjectDetection") as mock_aod,
            patch("docling_pp_doc_layout.model.decide_device", return_value="cpu"),
        ):
            mock_hf_model = MagicMock()
            mock_hf_model.config.id2label = {}
            mock_hf_model.to.return_value = mock_hf_model
            mock_aod.from_pretrained.return_value = mock_hf_model
            model = PPDocLayoutV3Model(
                artifacts_path=None,
                accelerator_options=accel_opts,
                options=PPDocLayoutV3Options(),
            )
        assert model.accelerator_options is accel_opts

    def test_model_moved_to_device(self, hf_mocks):
        with patch("docling_pp_doc_layout.model.decide_device", return_value="cuda"):
            self._build_model(hf_mocks, device="cuda")
        hf_mocks["mock_hf_model"].to.assert_called_with("cuda")

    def test_model_set_to_eval(self, hf_mocks):
        self._build_model(hf_mocks)
        hf_mocks["mock_hf_model"].eval.assert_called_once()

    def test_id2label_populated_from_config(self, hf_mocks):
        expected = {0: "text", 1: "table"}
        hf_mocks["mock_hf_model"].config.id2label = expected
        model = self._build_model(hf_mocks)
        assert model._id2label is expected

    def test_image_processor_stored(self, hf_mocks):
        model = self._build_model(hf_mocks)
        assert model._image_processor is hf_mocks["mock_processor"]

    def test_from_pretrained_called_with_model_name(self, hf_mocks):
        custom_name = "my-org/custom-layout-model"
        self._build_model(hf_mocks, opts=PPDocLayoutV3Options(model_name=custom_name))
        hf_mocks["mock_aip"].from_pretrained.assert_called_once_with(custom_name)
        hf_mocks["mock_aod"].from_pretrained.assert_called_once_with(custom_name)

    def test_enable_remote_services_is_accepted_and_ignored(self, hf_mocks):
        """enable_remote_services is a keyword-only arg that must not crash."""
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        accel_opts = MagicMock()
        accel_opts.device = "cpu"
        # Should not raise
        PPDocLayoutV3Model(
            artifacts_path=None,
            accelerator_options=accel_opts,
            options=PPDocLayoutV3Options(),
            enable_remote_services=True,
        )


# ---------------------------------------------------------------------------
# TestPredictLayoutHappyPath
# ---------------------------------------------------------------------------


class TestPredictLayoutHappyPath:
    """Happy-path scenarios for predict_layout."""

    def test_single_valid_page_returns_one_prediction(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            results = model_instance.predict_layout(conv_res, [page])

        assert len(results) == 1
        assert isinstance(results[0], LayoutPrediction)

    def test_multiple_valid_pages_returns_correct_count(self, model_instance):
        pages = [_make_page(page_no=i) for i in range(3)]
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[], [], []])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            results = model_instance.predict_layout(conv_res, pages)

        assert len(results) == 3

    def test_empty_page_list_returns_empty(self, model_instance):
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock()

        results = model_instance.predict_layout(conv_res, [])

        assert results == []
        model_instance._run_inference.assert_not_called()

    def test_run_inference_called_with_valid_images(self, model_instance):
        img = Image.new("RGB", (200, 300))
        page = _make_page(page_no=0, image=img)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            model_instance.predict_layout(conv_res, [page])

        model_instance._run_inference.assert_called_once_with([img])

    def test_images_fetched_at_scale_one(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            model_instance.predict_layout(conv_res, [page])

        page.get_image.assert_called_once_with(scale=1.0)

    def test_detections_become_clusters_passed_to_postprocessor(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        detections = [
            {"label": DocItemLabel.TEXT, "confidence": 0.9, "l": 10.0, "t": 20.0, "r": 50.0, "b": 60.0},
            {"label": DocItemLabel.TABLE, "confidence": 0.8, "l": 5.0, "t": 5.0, "r": 100.0, "b": 200.0},
        ]
        model_instance._run_inference = MagicMock(return_value=[detections])

        captured_clusters = []

        def capture(p, clusters, opts):
            captured_clusters.extend(clusters)
            m = MagicMock()
            m.postprocess.return_value = (clusters, [])
            return m

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor", side_effect=capture),
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            model_instance.predict_layout(conv_res, [page])

        assert len(captured_clusters) == 2
        assert captured_clusters[0].label == DocItemLabel.TEXT
        assert captured_clusters[1].label == DocItemLabel.TABLE

    def test_cluster_ids_are_sequential_from_zero(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        detections = [
            {"label": DocItemLabel.TEXT, "confidence": 0.9, "l": 0.0, "t": 0.0, "r": 1.0, "b": 1.0},
            {"label": DocItemLabel.TABLE, "confidence": 0.8, "l": 0.0, "t": 0.0, "r": 1.0, "b": 1.0},
            {"label": DocItemLabel.PICTURE, "confidence": 0.7, "l": 0.0, "t": 0.0, "r": 1.0, "b": 1.0},
        ]
        model_instance._run_inference = MagicMock(return_value=[detections])

        captured_clusters = []

        def capture(p, clusters, opts):
            captured_clusters.extend(clusters)
            m = MagicMock()
            m.postprocess.return_value = (clusters, [])
            return m

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor", side_effect=capture),
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            model_instance.predict_layout(conv_res, [page])

        assert [c.id for c in captured_clusters] == [0, 1, 2]

    def test_postprocessed_clusters_end_up_in_prediction(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        final_cluster = _make_cluster(confidence=0.99)

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([final_cluster], [])
            results = model_instance.predict_layout(conv_res, [page])

        assert results[0].clusters == [final_cluster]

    def test_cluster_bbox_coordinates_are_correct(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        detections = [
            {"label": DocItemLabel.TEXT, "confidence": 0.9, "l": 11.1, "t": 22.2, "r": 33.3, "b": 44.4},
        ]
        model_instance._run_inference = MagicMock(return_value=[detections])

        captured_clusters = []

        def capture(p, clusters, opts):
            captured_clusters.extend(clusters)
            m = MagicMock()
            m.postprocess.return_value = (clusters, [])
            return m

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor", side_effect=capture),
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            model_instance.predict_layout(conv_res, [page])

        bbox = captured_clusters[0].bbox
        assert bbox.l == pytest.approx(11.1, abs=0.001)
        assert bbox.t == pytest.approx(22.2, abs=0.001)
        assert bbox.r == pytest.approx(33.3, abs=0.001)
        assert bbox.b == pytest.approx(44.4, abs=0.001)

    def test_run_inference_flattens_polygons_to_bounding_boxes(self, model_instance):
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        # Test how _run_inference natively handles polygons
        model_instance._run_inference = PPDocLayoutV3Model._run_inference.__get__(model_instance)
        model_instance._device = "cpu"

        mock_input = MagicMock()
        mock_input.to.return_value = MagicMock()
        model_instance._image_processor.return_value = {"pixel_values": mock_input}

        model_instance._model.return_value = MagicMock()

        # Dummy image to get expected target sizes check passing
        img = Image.new("RGB", (800, 600))

        # Simulate HF processor output containing polygons
        model_instance._image_processor.post_process_object_detection.return_value = [
            {
                "scores": [torch.tensor(0.9)],
                "labels": [torch.tensor(0)],
                "boxes": [torch.tensor([0.0, 0.0, 10.0, 10.0])],  # Should be ignored in favor of polygons
                "polygons": [
                    [[11.0, 22.0], [33.0, 22.0], [33.0, 44.0], [11.0, 44.0]]
                ],  # Should extract [11.0, 22.0, 33.0, 44.0]
            }
        ]

        # Execute
        batch_detections = model_instance._run_inference([img])

        # Verify
        assert len(batch_detections) == 1
        assert len(batch_detections[0]) == 1
        det = batch_detections[0][0]

        assert det["l"] == 11.0
        assert det["r"] == 33.0
        assert det["t"] == 22.0
        assert det["b"] == 44.0

    def test_postprocessor_called_with_correct_page_and_options(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        detections = [{"label": DocItemLabel.TEXT, "confidence": 0.9, "l": 0.0, "t": 0.0, "r": 1.0, "b": 1.0}]
        model_instance._run_inference = MagicMock(return_value=[detections])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            model_instance.predict_layout(conv_res, [page])

        call_args = mock_pp.call_args
        assert call_args[0][0] is page
        assert call_args[0][2] is model_instance.options

    def test_cluster_confidence_stored(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        detections = [
            {"label": DocItemLabel.TEXT, "confidence": 0.77, "l": 0.0, "t": 0.0, "r": 1.0, "b": 1.0},
        ]
        model_instance._run_inference = MagicMock(return_value=[detections])

        captured_clusters = []

        def capture(p, clusters, opts):
            captured_clusters.extend(clusters)
            m = MagicMock()
            m.postprocess.return_value = (clusters, [])
            return m

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor", side_effect=capture),
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            model_instance.predict_layout(conv_res, [page])

        assert captured_clusters[0].confidence == pytest.approx(0.77, abs=0.001)


# ---------------------------------------------------------------------------
# TestPredictLayoutPageFiltering
# ---------------------------------------------------------------------------


class TestPredictLayoutPageFiltering:
    """Tests for how invalid/semi-invalid pages are handled — including bug exposure."""

    def test_page_with_none_backend_uses_existing_prediction(self, model_instance):
        existing = LayoutPrediction()
        page = _make_page(page_no=0, backend_valid=False)
        page.predictions.layout = existing
        conv_res = _make_conv_res()

        results = model_instance.predict_layout(conv_res, [page])

        assert results[0] is existing

    def test_page_with_none_backend_and_none_layout_produces_empty_prediction(self, model_instance):
        page = _make_page(page_no=0, backend_valid=False)
        page.predictions.layout = None
        conv_res = _make_conv_res()

        results = model_instance.predict_layout(conv_res, [page])

        assert isinstance(results[0], LayoutPrediction)

    def test_page_with_invalid_backend_is_treated_like_missing_backend(self, model_instance):
        page = _make_page(page_no=0, backend_valid=True)
        page._backend.is_valid.return_value = False
        page.predictions.layout = None
        conv_res = _make_conv_res()

        results = model_instance.predict_layout(conv_res, [page])

        assert len(results) == 1
        assert isinstance(results[0], LayoutPrediction)

    def test_no_valid_pages_skips_inference(self, model_instance):
        page = _make_page(page_no=0, backend_valid=False)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock()

        model_instance.predict_layout(conv_res, [page])

        model_instance._run_inference.assert_not_called()

    def test_page_with_valid_backend_but_none_size_is_skipped_gracefully(self, model_instance):
        page = _make_page(page_no=0, backend_valid=True, has_size=False)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[])

        results = model_instance.predict_layout(conv_res, [page])

        assert len(results) == 1
        assert isinstance(results[0], LayoutPrediction)

    def test_page_with_valid_backend_but_none_image_is_skipped_gracefully(self, model_instance):
        page = _make_page(page_no=0, backend_valid=True, has_size=True, image=None)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[])

        results = model_instance.predict_layout(conv_res, [page])

        assert len(results) == 1
        assert isinstance(results[0], LayoutPrediction)

    def test_semi_invalid_page_mixed_with_valid_page_maintains_alignment(self, model_instance):
        page_no_size = _make_page(page_no=0, backend_valid=True, has_size=False)
        page_valid = _make_page(page_no=1, backend_valid=True, has_size=True)
        conv_res = _make_conv_res()

        # Only page_valid ends up in valid_images, so _run_inference returns one entry.
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            results = model_instance.predict_layout(conv_res, [page_no_size, page_valid])

        assert len(results) == 2
        assert isinstance(results[0], LayoutPrediction)
        assert isinstance(results[1], LayoutPrediction)
        model_instance._run_inference.assert_called_once_with([page_valid.get_image.return_value])

    def test_valid_and_invalid_backend_pages_separated_correctly(self, model_instance):
        """Only pages with valid backends contribute to inference; others get existing predictions."""
        page_valid = _make_page(page_no=0, backend_valid=True)
        page_invalid = _make_page(page_no=1, backend_valid=False)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            results = model_instance.predict_layout(conv_res, [page_valid, page_invalid])

        assert len(results) == 2
        model_instance._run_inference.assert_called_once_with([page_valid.get_image.return_value])

    def test_all_valid_pages_all_get_layout_predictions(self, model_instance):
        pages = [_make_page(page_no=i) for i in range(4)]
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[], [], [], []])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            results = model_instance.predict_layout(conv_res, pages)

        assert len(results) == 4
        assert all(isinstance(r, LayoutPrediction) for r in results)


# ---------------------------------------------------------------------------
# TestPredictLayoutConfidenceScores
# ---------------------------------------------------------------------------


class TestPredictLayoutConfidenceScores:
    """Tests for layout_score and ocr_score written to ConversionResult."""

    def test_layout_score_is_mean_of_processed_cluster_confidences(self, model_instance):
        page = _make_page(page_no=7)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        c1 = _make_cluster(confidence=0.6, ix=0)
        c2 = _make_cluster(confidence=0.8, ix=1)

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([c1, c2], [])
            model_instance.predict_layout(conv_res, [page])

        assert conv_res.confidence.pages[7].layout_score == pytest.approx(0.7, abs=0.001)

    def test_ocr_score_uses_only_cells_where_from_ocr_is_true(self, model_instance):
        page = _make_page(page_no=3)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        ocr_cell = MagicMock()
        ocr_cell.from_ocr = True
        ocr_cell.confidence = 0.75

        non_ocr_cell = MagicMock()
        non_ocr_cell.from_ocr = False
        non_ocr_cell.confidence = 0.1

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [ocr_cell, non_ocr_cell])
            model_instance.predict_layout(conv_res, [page])

        assert conv_res.confidence.pages[3].ocr_score == pytest.approx(0.75, abs=0.001)

    def test_layout_score_is_nan_when_no_clusters(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            model_instance.predict_layout(conv_res, [page])

        assert math.isnan(conv_res.confidence.pages[0].layout_score)

    def test_ocr_score_is_nan_when_no_ocr_cells(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], [])
            model_instance.predict_layout(conv_res, [page])

        assert math.isnan(conv_res.confidence.pages[0].ocr_score)

    def test_scores_written_to_correct_page_no(self, model_instance):
        page = _make_page(page_no=42)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        c = _make_cluster(confidence=0.9)

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([c], [])
            model_instance.predict_layout(conv_res, [page])

        assert conv_res.confidence.pages[42].layout_score == pytest.approx(0.9, abs=0.001)

    def test_scores_not_written_for_invalid_backend_pages(self, model_instance):
        page = _make_page(page_no=0, backend_valid=False)
        conv_res = _make_conv_res()

        model_instance.predict_layout(conv_res, [page])

        conv_res.confidence.pages.__getitem__.assert_not_called()

    def test_ocr_score_multiple_ocr_cells_averaged(self, model_instance):
        page = _make_page(page_no=0)
        conv_res = _make_conv_res()
        model_instance._run_inference = MagicMock(return_value=[[]])

        cells = []
        for conf in (0.5, 0.7, 0.9):
            cell = MagicMock()
            cell.from_ocr = True
            cell.confidence = conf
            cells.append(cell)

        with (
            patch("docling_pp_doc_layout.model.LayoutPostprocessor") as mock_pp,
            patch("docling_pp_doc_layout.model.TimeRecorder"),
        ):
            mock_pp.return_value.postprocess.return_value = ([], cells)
            model_instance.predict_layout(conv_res, [page])

        assert conv_res.confidence.pages[0].ocr_score == pytest.approx(0.7, abs=0.001)


# ---------------------------------------------------------------------------
# TestErrorHandling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Tests for system errors like network failures, OOM, or malformed outputs."""

    def test_init_raises_on_huggingface_network_error(self):
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        accel_opts = MagicMock()
        accel_opts.device = "cpu"

        # AutoImageProcessor.from_pretrained can raise ConnectionError if it fails to download
        with (
            patch("docling_pp_doc_layout.model.AutoImageProcessor") as mock_aip,
            patch("docling_pp_doc_layout.model.AutoModelForObjectDetection"),
            patch("docling_pp_doc_layout.model.decide_device", return_value="cpu"),
        ):
            mock_aip.from_pretrained.side_effect = ConnectionError("Network unreachable")

            with pytest.raises(ConnectionError, match="Network unreachable"):
                PPDocLayoutV3Model(
                    artifacts_path=None,
                    accelerator_options=accel_opts,
                    options=PPDocLayoutV3Options(),
                )

    def test_run_inference_propagates_oom(self, model_instance):
        page = _make_page(page_no=0, backend_valid=True, has_size=True)
        conv_res = _make_conv_res()

        # Simulate PyTorch CUDA OutOfMemoryError or similar RuntimeError
        model_instance._run_inference = MagicMock(side_effect=RuntimeError("CUDA out of memory"))

        with pytest.raises(RuntimeError, match="CUDA out of memory"):
            model_instance.predict_layout(conv_res, [page])

    def test_run_inference_handles_malformed_hf_output(self, model_instance):
        """If HF object detection returns an unexpected format, it should propagate KeyError."""
        page = _make_page(page_no=0, backend_valid=True, has_size=True)
        conv_res = _make_conv_res()

        # We want to test exactly what happens when post_process_object_detection returns bad output
        # So we un-mock _run_inference but keep _image_processor mocked
        from docling_pp_doc_layout.model import PPDocLayoutV3Model

        model_instance._run_inference = PPDocLayoutV3Model._run_inference.__get__(model_instance)

        # Setup inputs to not crash earlier
        mock_input_tensors = MagicMock()
        mock_input_tensors.to.return_value = MagicMock()
        model_instance._device = "cpu"
        model_instance._image_processor.return_value = {"pixel_values": mock_input_tensors}
        model_instance._model.return_value = MagicMock()

        # Mock the postprocessor to return malformed dictionaries (e.g., missing "scores")
        model_instance._image_processor.post_process_object_detection.return_value = [{"corrupted": "bad_data"}]

        with pytest.raises(KeyError):
            model_instance.predict_layout(conv_res, [page])
