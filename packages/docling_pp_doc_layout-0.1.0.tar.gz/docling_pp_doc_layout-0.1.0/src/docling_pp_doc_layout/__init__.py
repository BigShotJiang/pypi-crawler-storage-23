"""A Docling plugin for PaddlePaddle PP-DocLayout-V3 model document layout detection."""

__version__ = "0.1.0"
