"""Tests for HMAC-SHA256 signing utility."""
import hashlib
import hmac as _hmac

from morphe_adapter_sdk.hmac_utils import sign_body

SECRET = "test-secret"
BODY = '{"event_type":"dataops.v1.sync_failed"}'


def test_returns_64_char_hex_string():
    result = sign_body(BODY, SECRET)
    assert len(result) == 64
    assert all(c in "0123456789abcdef" for c in result)


def test_matches_stdlib_hmac_digest():
    expected = _hmac.new(
        SECRET.encode("utf-8"),
        BODY.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    assert sign_body(BODY, SECRET) == expected


def test_deterministic_same_inputs():
    assert sign_body(BODY, SECRET) == sign_body(BODY, SECRET)


def test_different_secrets_produce_different_digests():
    assert sign_body(BODY, "secret-a") != sign_body(BODY, "secret-b")


def test_different_bodies_produce_different_digests():
    assert sign_body('{"a":1}', SECRET) != sign_body('{"a":2}', SECRET)


def test_empty_body():
    result = sign_body("", SECRET)
    assert len(result) == 64


def test_unicode_body():
    result = sign_body('{"name":"café"}', SECRET)
    assert len(result) == 64
