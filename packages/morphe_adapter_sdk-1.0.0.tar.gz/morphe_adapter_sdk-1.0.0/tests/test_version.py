"""Tests for extract_api_version utility."""
from __future__ import annotations

import pytest
from morphe_adapter_sdk.version import extract_api_version


class TestExtractApiVersion:
    def test_extracts_v1_from_standard_event_type(self):
        assert extract_api_version("dataops.v1.sync_failed") == "v1"

    def test_extracts_v2(self):
        assert extract_api_version("dataops.v2.sync_failed") == "v2"

    def test_extracts_double_digit_version(self):
        assert extract_api_version("crm.v10.deal_created") == "v10"

    def test_defaults_to_v1_when_no_version_segment(self):
        assert extract_api_version("dataops.sync_failed") == "v1"

    def test_defaults_to_v1_for_bare_event_name(self):
        assert extract_api_version("sync_failed") == "v1"

    def test_handles_version_at_start(self):
        assert extract_api_version("v2.sync_failed") == "v2"

    def test_does_not_match_partial_version_strings(self):
        # "version1" does not match ^v\d+$ — falls back to default
        assert extract_api_version("dataops.version1.sync_failed") == "v1"
