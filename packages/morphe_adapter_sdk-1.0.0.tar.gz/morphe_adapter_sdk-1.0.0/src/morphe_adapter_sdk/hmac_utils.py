"""
HMAC-SHA256 signing utility for the Morphe Adapter SDK.

IMPORTANT: This file is intentionally named ``hmac_utils.py`` (not ``hmac.py``)
to avoid shadowing the Python standard library ``hmac`` module.
"""
from __future__ import annotations

import hashlib
import hmac as _hmac


def sign_body(body: str, secret: str) -> str:
    """
    Compute HMAC-SHA256 hex digest of ``body`` using ``secret``.

    Produces the value expected by the ``X-Morphe-Signature`` header.
    The result is identical to the TypeScript SDK's ``signBody()`` function
    when both receive the same UTF-8 encoded inputs.

    Args:
        body:   The raw JSON request body string (UTF-8).
        secret: The HMAC shared secret from the API credential.

    Returns:
        64-character lowercase hex string.
    """
    return _hmac.new(
        secret.encode("utf-8"),
        body.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
