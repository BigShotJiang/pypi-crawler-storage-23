"""
morphe-adapter-sdk — Python SDK for emitting events to the Morphe Control Plane.

Usage::

    from morphe_adapter_sdk import MorpheClient, ApiError, SchemaValidationError

    with MorpheClient(token="<jwt>") as client:
        result = client.emit({
            "event_type": "dataops.v1.sync_failed",
            "system_id": "<system-uuid>",
            "payload": {"records": 42},
        })
"""
from .client import MorpheClient
from .errors import ApiError, MorpheError, NetworkError, SchemaValidationError
from .types import EmitResult, EventPayload, JsonApiError, ValidationFailure
from .version import extract_api_version

__all__ = [
    "MorpheClient",
    # Errors
    "MorpheError",
    "ApiError",
    "SchemaValidationError",
    "NetworkError",
    # Types
    "EmitResult",
    "EventPayload",
    "JsonApiError",
    "ValidationFailure",
    # Utilities
    "extract_api_version",
]
