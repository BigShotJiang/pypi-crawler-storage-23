"""
Utility for extracting the API version from an event_type string.
"""
from __future__ import annotations

import re

_VERSION_RE = re.compile(r"^v\d+$")
_DEFAULT_VERSION = "v1"

#: Default production endpoint for the Morphe Control Plane.
#: Override via the ``MORPHE_ENDPOINT`` environment variable for development
#: or self-hosted deployments.
DEFAULT_ENDPOINT = "https://api.morphe.io"


def extract_api_version(event_type: str) -> str:
    """
    Extract the API version segment from an event_type string.

    The version is the first dot-delimited part matching ``/^v\\d+$/``.
    Falls back to ``"v1"`` when no version segment is present.

    Examples::

        extract_api_version("dataops.v1.sync_failed")  # "v1"
        extract_api_version("dataops.v2.sync_failed")  # "v2"
        extract_api_version("dataops.sync_failed")     # "v1"  (default)
    """
    for part in event_type.split("."):
        if _VERSION_RE.match(part):
            return part
    return _DEFAULT_VERSION
