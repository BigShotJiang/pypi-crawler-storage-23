
from yprov4ml.datamodel.prov4ml_data import Prov4MLData

# Global variable to store provenance data
VERBOSE = False
PROV4ML_DATA = Prov4MLData()