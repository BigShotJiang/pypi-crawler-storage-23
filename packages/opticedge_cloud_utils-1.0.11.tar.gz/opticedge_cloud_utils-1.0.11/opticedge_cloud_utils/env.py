# opticedge_cloud_utils/env.py

import os
from typing import Optional


def require_env(name: str, default: Optional[str] = None) -> str:
    """
    Retrieve an environment variable.

    Rules:
    - If variable exists and is a non-empty string → return it.
    - If missing or empty and default provided → return default.
    - If missing or empty and no default → raise RuntimeError.

    Args:
        name: Environment variable name.
        default: Optional fallback value.

    Returns:
        str

    Raises:
        RuntimeError
    """

    value = os.getenv(name)

    # Treat both None and "" as invalid/missing
    if value is None or value == "":
        if default is not None:
            return default
        raise RuntimeError(f"{name} env var must be set")

    return value