# Oracle Cloud Server

## Connection

| Field | Value |
|-------|-------|
| Host | `84.8.250.142` |
| User | `ubuntu` |
| SSH Key | `~/.ssh/lucastucchi_rsa` |
| Hostname | `mcp-advisor-vnic` |

```bash
ssh -i ~/.ssh/lucastucchi_rsa ubuntu@84.8.250.142
```

## Services

The server runs the **mcp-advisor-app** stack via Docker Compose, behind a Caddy reverse proxy.

| Service | Container | Internal Port | Bound To |
|---------|-----------|---------------|----------|
| Backend (FastAPI) | `mcp-advisor-app-backend-1` | 8000 | `127.0.0.1:8899` |
| Frontend | `mcp-advisor-app-frontend-1` | 80 | `127.0.0.1:3737` |
| PostgreSQL 16 | `mcp-advisor-app-db-1` | 5432 | `127.0.0.1:5433` |
| Redis 7.4 | `mcp-advisor-app-redis-1` | 6379 | `127.0.0.1:6380` |

### Caddy (reverse proxy)

- Domain: `mcpadvisor.stucchi.consulting` -> `localhost:3737`

### Database

- **User:** `mcpreg`
- **Password:** `mcpreg`
- **Database:** `mcpregistry`

## Project Paths

| Path | Description |
|------|-------------|
| `~/mcp-advisor-app/` | Docker Compose stack (backend, frontend, docker-compose.yml) |
| `~/mcp-advisor/` | mcp-advisor MCP server source |
| `~/backup-db.sh` | Database backup script |
| `~/backups/` | Database backups |

## Common Operations

### Trigger registry sync

```bash
ssh -i ~/.ssh/lucastucchi_rsa ubuntu@84.8.250.142 \
  "curl -s -X POST http://localhost:8899/api/v1/admin/sync/trigger"
```

### Restart all services

```bash
ssh -i ~/.ssh/lucastucchi_rsa ubuntu@84.8.250.142 \
  "cd ~/mcp-advisor-app && docker compose restart"
```

### Rebuild and restart

```bash
ssh -i ~/.ssh/lucastucchi_rsa ubuntu@84.8.250.142 \
  "cd ~/mcp-advisor-app && docker compose up -d --build"
```

### View logs

```bash
ssh -i ~/.ssh/lucastucchi_rsa ubuntu@84.8.250.142 \
  "cd ~/mcp-advisor-app && docker compose logs -f --tail=50"
```
