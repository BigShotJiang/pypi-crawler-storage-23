"""
CLI tests for clm-cli package.
"""
