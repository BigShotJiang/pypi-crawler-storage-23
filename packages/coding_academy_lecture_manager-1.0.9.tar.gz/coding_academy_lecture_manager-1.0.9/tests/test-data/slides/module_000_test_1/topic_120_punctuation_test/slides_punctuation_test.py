# j2 from 'macros.j2' import header
# {{ header("War das wirklich ML?", "Was this really ML?") }}

# %%
1 + 2
