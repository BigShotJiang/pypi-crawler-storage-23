# j2 from 'macros.j2' import header
# {{ header("Einfaches Notebook", "Simple Notebook") }}

# %%
print("Hello from a simple notebook!")

# %% [markdown]
#
# This is a minimal notebook with just a single cell.
# It should convert successfully.

# %%
result = 2 + 2
result
