"""Test fixtures package for CLM."""
