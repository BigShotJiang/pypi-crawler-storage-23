"""Command-line interface for CLM.

This module provides the command-line interface for running course conversions,
watching for file changes, and managing the build process.
"""

__all__ = []
