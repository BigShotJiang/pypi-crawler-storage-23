=========
Changelog
=========

Version 1.0.0
=============

- Initial library and CLI for ``ansible-sign``. See documentation for usage
  examples. Only the CLI is officially supported, and the API can change over
  time. We make no effort to provide backwards compatibility at the API level
  at this time.
