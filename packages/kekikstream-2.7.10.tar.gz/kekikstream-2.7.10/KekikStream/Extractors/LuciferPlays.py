# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class LuciferPlays(BePlayerExtractor):
    name     = "LuciferPlays"
    main_url = "https://luciferplays.com"
