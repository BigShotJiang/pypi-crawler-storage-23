# Backtest & Symphonies

## Backtest Resource

::: composer.resources.backtest.Backtest
    options:
      show_root_heading: true
      show_category_heirarchy: true

## Public Symphony Resource

::: composer.resources.public_symphony.PublicSymphony
    options:
      show_root_heading: true
      show_category_heirarchy: true

## User Symphony Resource

::: composer.resources.user_symphony.UserSymphony
    options:
      show_root_heading: true
      show_category_heirarchy: true

## User Symphonies Resource

::: composer.resources.user_symphonies.UserSymphonies
    options:
      show_root_heading: true
      show_category_heirarchy: true

## Search Resource

::: composer.resources.search.Search
    options:
      show_root_heading: true
      show_category_heirarchy: true

## Watchlist Resource

::: composer.resources.watchlist.Watchlist
    options:
      show_root_heading: true
      show_category_heirarchy: true
