#!/bin/bash

set -x
set -e

export LC_ALL=C

sudo lighttpd-disable-mod basic-auth || true
sudo service lighttpd force-reload || true
