"""RushTI HTML templates package."""
