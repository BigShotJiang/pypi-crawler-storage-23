"""
LLMManager: 并发推理管理器，支持渐进式 warmup 和实时进度可视化。

两种使用方式：

  # 一次性（原有接口，不变）
  results = manager.map(fn, items, **kwargs)

  # 流式（持久 worker 池，外部控制分批投入）
  manager.start(fn, **kwargs)
  for chunk in chunks:
      manager.submit(chunk)
      while manager.queue_size > threshold:   # 外部背压控制
          time.sleep(0.5)
  results = manager.shutdown()
"""

import queue
import threading
import time
from typing import Any, Callable, Dict, Iterable, List, Optional

from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)


class LLMManager:
    """
    并发 LLM 推理管理器。

    渐进式 warmup：
      - t=0 立即启动 initial_workers 个 worker
      - 之后每 ramp_interval 秒新增 ramp_step 个，直到 max_workers
    """

    def __init__(
        self,
        max_workers: int = 200,
        initial_workers: int = 50,
        ramp_step: int = 25,
        ramp_interval: float = 10.0,
        show_progress: bool = True,
    ):
        self.max_workers = max_workers
        self.initial_workers = min(initial_workers, max_workers)
        self.ramp_step = ramp_step
        self.ramp_interval = ramp_interval
        self.show_progress = show_progress

        self._started = False

    # ------------------------------------------------------------------
    # 流式接口
    # ------------------------------------------------------------------

    def start(self, fn: Callable, **kwargs) -> None:
        """
        启动 worker 池（ramp + display 线程）。
        fn 和 kwargs 将用于所有后续 submit() 的任务。
        """
        if self._started:
            raise RuntimeError("LLMManager 已在运行，请先调用 shutdown()")

        self._fn = fn
        self._fn_kwargs = kwargs

        # 结果存储（dict，按全局 idx 索引）
        self._results: Dict[int, Any] = {}
        self._global_idx = 0
        self._idx_lock = threading.Lock()

        # 统计
        self._completed_count = 0
        self._failed_count = 0
        self._count_lock = threading.Lock()

        # Worker 数量
        self._active_workers = 0
        self._active_lock = threading.Lock()

        self._task_queue: queue.Queue = queue.Queue()
        self._stop_event = threading.Event()
        self._start_time = time.time()

        # 启动 ramp 线程
        self._ramp_thread = threading.Thread(target=self._ramp, daemon=True)
        self._ramp_thread.start()

        # 启动 display 线程
        if self.show_progress:
            self._progress = Progress(
                SpinnerColumn(),
                TextColumn("{task.description}"),
                BarColumn(),
                MofNCompleteColumn(),
                TaskProgressColumn(),
                TimeRemainingColumn(),
            )
            self._progress.start()
            self._progress_task_id = self._progress.add_task(
                f"[cyan]Workers 0/{self.max_workers}[/cyan]  [red]失败 0[/red]",
                total=None,  # 流式模式下动态更新
            )
            self._display_thread = threading.Thread(target=self._display, daemon=True)
            self._display_thread.start()

        self._started = True

    def submit(self, items: Iterable[Any]) -> int:
        """
        向运行中的 worker 池投入一批任务。
        返回实际投入的任务数量。

        线程安全：可以从多个线程同时调用。
        """
        if not self._started:
            raise RuntimeError("请先调用 start()")

        items_list = list(items)
        n = len(items_list)
        if n == 0:
            return 0

        # 原子地预留全局索引段
        with self._idx_lock:
            start_idx = self._global_idx
            self._global_idx += n

        # 更新进度条 total（动态扩展）
        if self.show_progress:
            self._progress.update(self._progress_task_id, total=self._global_idx)

        for i, item in enumerate(items_list):
            self._task_queue.put((start_idx + i, item))

        return n

    def shutdown(self) -> List[Any]:
        """
        等待所有已 submit 的任务完成，停止 worker，返回有序结果列表。
        """
        if not self._started:
            raise RuntimeError("LLMManager 未在运行")

        self._task_queue.join()
        self._stop_event.set()

        if self.show_progress:
            self._display_thread.join(timeout=1.0)
            self._progress.stop()

        self._ramp_thread.join(timeout=2.0)
        self._started = False

        # 统计快照
        elapsed = time.time() - self._start_time
        with self._count_lock:
            done = self._completed_count
            failed = self._failed_count
        n = self._global_idx
        rate = done / elapsed if elapsed > 0 else 0.0
        self._last_stats = {
            "total": n,
            "completed": done,
            "failed": failed,
            "elapsed_seconds": round(elapsed, 2),
            "rate_per_second": round(rate, 2),
        }

        return [self._results[i] for i in range(n)]

    @property
    def queue_size(self) -> int:
        """当前队列中尚未被 worker 取走的任务数。可用于外部背压判断。"""
        return self._task_queue.qsize()

    @property
    def active_workers(self) -> int:
        """当前活跃的 worker 线程数（随 ramp 渐增）。"""
        with self._active_lock:
            return self._active_workers

    # ------------------------------------------------------------------
    # 便捷接口（原有 map()，行为不变）
    # ------------------------------------------------------------------

    def map(self, fn: Callable, items: Iterable[Any], **kwargs) -> List[Any]:
        """
        一次性接口：等价于 start(fn) → submit(items) → shutdown()。
        阻塞直到全部完成，返回有序结果列表。
        """
        items_list = list(items)
        if not items_list:
            return []

        self.start(fn, **kwargs)

        # map() 场景下 total 已知，直接设置进度条总数
        if self.show_progress:
            self._progress.update(self._progress_task_id, total=len(items_list))

        self.submit(items_list)
        return self.shutdown()

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    @property
    def stats(self) -> dict:
        """返回上一次 shutdown() 的统计快照。"""
        return getattr(self, "_last_stats", {})

    # ------------------------------------------------------------------
    # 内部线程
    # ------------------------------------------------------------------

    def _worker(self):
        while not self._stop_event.is_set():
            try:
                idx, item = self._task_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                result = self._fn(item, **self._fn_kwargs)
                self._results[idx] = result
                if isinstance(result, dict) and not result.get("success", True):
                    with self._count_lock:
                        self._failed_count += 1
            except Exception as exc:
                self._results[idx] = {"success": False, "error": str(exc), "response": ""}
                with self._count_lock:
                    self._failed_count += 1
            finally:
                with self._count_lock:
                    self._completed_count += 1
                self._task_queue.task_done()

    def _ramp(self):
        with self._active_lock:
            count = min(self.initial_workers, self.max_workers)
            for _ in range(count):
                threading.Thread(target=self._worker, daemon=True).start()
            self._active_workers = count

        while not self._stop_event.is_set():
            self._stop_event.wait(self.ramp_interval)
            if self._stop_event.is_set():
                break
            with self._active_lock:
                if self._active_workers >= self.max_workers:
                    break
                add = min(self.ramp_step, self.max_workers - self._active_workers)
                for _ in range(add):
                    threading.Thread(target=self._worker, daemon=True).start()
                self._active_workers += add

    def _display(self):
        while not self._stop_event.is_set():
            self._refresh_display()
            time.sleep(0.25)
        self._refresh_display()  # 最终刷新

    def _refresh_display(self):
        with self._count_lock:
            done = self._completed_count
            failed = self._failed_count
        with self._active_lock:
            workers = self._active_workers
        with self._idx_lock:
            total = self._global_idx
        self._progress.update(
            self._progress_task_id,
            completed=done,
            total=total,
            description=(
                f"[cyan]Workers {workers}/{self.max_workers}[/cyan]"
                f"  [red]失败 {failed}[/red]"
            ),
        )
