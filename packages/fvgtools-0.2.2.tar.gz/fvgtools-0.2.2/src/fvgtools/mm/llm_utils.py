"""
Utility functions for LLM client image handling and batch processing.
"""

import base64
import mimetypes
from pathlib import Path

__all__ = [
    'encode_image_to_base64',
    'get_image_mime_type',
    'image_to_data_url',
    'batched',
]

_EXT_MIME_MAP = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.bmp': 'image/bmp',
}


def encode_image_to_base64(image_path: str) -> str:
    """Encode an image file to a base64 string."""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode('utf-8')


def get_image_mime_type(image_path: str) -> str:
    """Get the MIME type of an image from its file path.

    Uses mimetypes.guess_type first, falls back to extension map.
    """
    mime, _ = mimetypes.guess_type(image_path)
    if mime and mime.startswith('image/'):
        return mime
    ext = Path(image_path).suffix.lower()
    return _EXT_MIME_MAP.get(ext, 'image/jpeg')


def image_to_data_url(image_path: str) -> str:
    """Convert an image file to a data URL suitable for API calls.

    Example output: ``data:image/jpeg;base64,/9j/4AAQ...``
    """
    mime = get_image_mime_type(image_path)
    b64 = encode_image_to_base64(image_path)
    return f"data:{mime};base64,{b64}"


def batched(items: list, batch_size: int):
    """Yield successive fixed-size batches from a list.

    Example::

        for batch in batched(my_list, 8):
            process(batch)
    """
    for i in range(0, len(items), batch_size):
        yield items[i:i + batch_size]
