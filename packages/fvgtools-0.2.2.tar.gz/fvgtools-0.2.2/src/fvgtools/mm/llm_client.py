"""
LLM 客户端集合，支持 Qwen235B、Qwen3.5、Azure GPT、Gemini、Kimi、Seed。

所有 OpenAI SDK 兼容的客户端均继承自 ``OpenAICompatibleClient``。
非兼容协议（AzureOpenAI SDK、Gemini REST、Seed PTU）各自独立实现。
"""

import os
import getpass
from typing import Optional, Dict, Any

import requests
from openai import OpenAI, AzureOpenAI

import openai_proxy as _openai_proxy

from .llm_utils import image_to_data_url, get_image_mime_type, encode_image_to_base64


__all__ = [
    'OpenAICompatibleClient',
    'Qwen235BClient',
    'KimiClient',
    'Qwen35Client',
    'AzureGPTClient',
    'GeminiClient',
    'SeedClient',
    'call_llm',
    'chat_llm',
]


# ---------------------------------------------------------------------------
# OpenAI SDK 兼容客户端基类
# ---------------------------------------------------------------------------

class OpenAICompatibleClient:
    """使用 OpenAI Python SDK 的客户端基类。

    子类可按需覆盖以下钩子：

    ``_extra_kwargs() -> dict``
        注入到 ``chat.completions.create()`` 的额外参数，用于传递模型特定的
        采样参数、thinking 开关等。默认返回 ``{}``。

    ``_streaming: bool``
        设为 ``True`` 时，``_api_call`` 自动走流式路径（``_api_call_stream``）。
        默认 ``False``。

    ``_history_content(result) -> str``
        控制多轮对话中存入 history 的 assistant 内容。当格式化后的响应
        （含 ``<think>`` 标签）不应回传给模型时可覆盖，例如 ``KimiClient``
        只存原始 content。默认返回 ``result["response"]``。

    所有路径的返回字典结构::

        {
            "success": bool,
            "response": str,           # 格式化文本（含 think 标签，如有）
            "error": str,              # 仅失败时存在
            "raw": {                   # 成功时，或 no-choices 失败时存在
                "content": str,
                "reasoning_content": str | None,
                "usage": dict | None,  # token 统计，来自 model_dump()
                "model": str | None,
                "id": str | None,
            }
        }
    """

    default_temperature: float = 0.7
    default_max_tokens: int = 32768
    _streaming: bool = False

    def __init__(self, api_url: str, api_key: str, model_name: str,
                 enable_thinking: bool = False, timeout: int = 1200):
        self.model_name = model_name
        self.enable_thinking = enable_thinking
        self.client = OpenAI(api_key=api_key, base_url=api_url, timeout=timeout)
        self.history = []

    # -- 内部工具方法 ---------------------------------------------------------

    def _build_content(self, prompt: str, image: Optional[str] = None):
        """构造 OpenAI 格式的 content 列表（可含图片）。"""
        content = []
        if image and os.path.exists(image):
            content.append({
                "type": "image_url",
                "image_url": {"url": image_to_data_url(image)}
            })
        content.append({"type": "text", "text": prompt})
        return content

    @staticmethod
    def _format_thinking(content: str, reasoning_content: Optional[str]) -> str:
        """将 reasoning_content 包裹为 <think> 标签并与 content 拼接。"""
        if reasoning_content:
            return f"<think>\n{reasoning_content}\n</think>\n\n{content}"
        return content

    def _extra_kwargs(self) -> dict:
        """注入到 chat.completions.create() 的额外参数。子类按需覆盖。"""
        return {}

    def _history_content(self, result: Dict[str, Any]) -> str:
        """返回存入多轮 history 的 assistant 内容字符串。子类按需覆盖。"""
        return result["response"]

    # -- 流式调用 -------------------------------------------------------------

    def _api_call_stream(self, messages, temperature: float, max_tokens: int) -> Dict[str, Any]:
        """流式调用实现，由 ``_api_call`` 在 ``_streaming=True`` 时自动调用。"""
        kwargs = {
            "model": self.model_name, "messages": messages,
            "temperature": temperature, "max_tokens": max_tokens,
            "stream": True, "stream_options": {"include_usage": True},
        }
        kwargs.update(self._extra_kwargs())
        full_content, full_reasoning = [], []
        model_id = model_name = usage = None
        try:
            stream = self.client.chat.completions.create(**kwargs)
            for chunk in stream:
                if model_id is None:
                    model_id, model_name = chunk.id, chunk.model
                if getattr(chunk, 'usage', None):
                    usage = chunk.usage
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    if getattr(delta, 'content', None):
                        full_content.append(delta.content)
                    if getattr(delta, 'reasoning_content', None):
                        full_reasoning.append(delta.reasoning_content)
        except Exception as e:
            return {"success": False, "error": str(e), "response": ""}
        content = "".join(full_content)
        reasoning = "".join(full_reasoning)
        if not content and not reasoning:
            return {"success": False, "error": "empty_response_from_stream", "response": ""}
        return {
            "success": True,
            "response": self._format_thinking(content, reasoning),
            "raw": {
                "content": content,
                "reasoning_content": reasoning,
                "usage": usage.model_dump() if usage else None,
                "model": model_name,
                "id": model_id,
            },
        }

    # -- 非流式调用（默认）----------------------------------------------------

    def _api_call(self, messages, temperature: float, max_tokens: int) -> Dict[str, Any]:
        """发起 API 调用并返回统一格式的结果字典。

        ``_streaming=True`` 时自动委托给 ``_api_call_stream``。
        """
        if self._streaming:
            return self._api_call_stream(messages, temperature, max_tokens)
        kwargs = {
            "model": self.model_name, "messages": messages,
            "temperature": temperature, "max_tokens": max_tokens,
        }
        kwargs.update(self._extra_kwargs())
        try:
            response = self.client.chat.completions.create(**kwargs)
        except Exception as e:
            return {"success": False, "error": str(e), "response": ""}

        if not (response.choices and len(response.choices) > 0):
            raw = response.model_dump() if hasattr(response, 'model_dump') else str(response)
            return {"success": False, "error": "响应中没有choices", "response": "", "raw": raw}

        msg = response.choices[0].message
        content = msg.content or ""
        reasoning = getattr(msg, 'reasoning_content', None)
        return {
            "success": True,
            "response": self._format_thinking(content, reasoning),
            "raw": {
                "content": content,
                "reasoning_content": reasoning,
                "usage": response.usage.model_dump() if response.usage else None,
                "model": response.model,
                "id": response.id,
            },
        }

    # -- 公共接口 -------------------------------------------------------------

    def call(self, prompt: str, image: Optional[str] = None,
             temperature: Optional[float] = None,
             max_tokens: Optional[int] = None) -> Dict[str, Any]:
        """单轮调用，不保留历史。"""
        temperature = temperature if temperature is not None else self.default_temperature
        max_tokens = max_tokens if max_tokens is not None else self.default_max_tokens
        messages = [{"role": "user", "content": self._build_content(prompt, image)}]
        return self._api_call(messages, temperature, max_tokens)

    def chat(self, prompt: str, image: Optional[str] = None,
             temperature: Optional[float] = None,
             max_tokens: Optional[int] = None) -> Dict[str, Any]:
        """多轮调用，自动维护对话历史。"""
        temperature = temperature if temperature is not None else self.default_temperature
        max_tokens = max_tokens if max_tokens is not None else self.default_max_tokens
        self.history.append({"role": "user", "content": self._build_content(prompt, image)})
        result = self._api_call(self.history, temperature, max_tokens)
        if result["success"]:
            self.history.append({"role": "assistant", "content": self._history_content(result)})
        return result

    def reset(self):
        """清空对话历史。"""
        self.history = []


# ---------------------------------------------------------------------------
# OpenAI SDK 兼容的具体客户端
# ---------------------------------------------------------------------------

class Qwen235BClient(OpenAICompatibleClient):
    """Qwen3-VL-235B，流式推理，通过 chat_template_kwargs 控制 thinking。"""

    _streaming = True

    def __init__(self, api_url: str, api_key: str,
                 model_name: str = "qwen3-vl-235b-a22b-thinking",
                 enable_thinking: bool = True):
        super().__init__(api_url, api_key, model_name, enable_thinking)

    def _extra_kwargs(self) -> dict:
        if self.enable_thinking and "thinking" in self.model_name:
            return {"extra_body": {"chat_template_kwargs": {"enable_thinking": True}}}
        return {}


class KimiClient(OpenAICompatibleClient):
    """Kimi，非流式，通过 extra_body.enable_thinking 控制 thinking。

    多轮历史只存原始 content（不含 ``<think>`` 标签），避免污染后续轮次。
    """

    def __init__(self, api_key: str, api_url: str = "https://apia.jianying580.com/v1",
                 model_name: str = "Kimi-K2.5", enable_thinking: bool = True):
        super().__init__(api_url, api_key, model_name, enable_thinking)

    def _extra_kwargs(self) -> dict:
        if self.enable_thinking:
            return {"extra_body": {"enable_thinking": True}}
        return {}

    def _history_content(self, result: Dict[str, Any]) -> str:
        # 存原始 content，不含 think 标签，防止后续轮次的模型输入被污染
        return result["raw"]["content"]


class Qwen35Client(OpenAICompatibleClient):
    """Qwen3.5，非流式，附加采样参数 top_k / repetition_penalty。

    默认温度 0.6，与 Qwen 官方评测设置对齐。
    """

    default_temperature: float = 0.6

    def __init__(self, api_url: str, api_key: str = "EMPTY", model_name: str = "qwen3_5"):
        super().__init__(api_url, api_key, model_name, enable_thinking=False)

    def _extra_kwargs(self) -> dict:
        return {"top_p": 0.95, "extra_body": {"top_k": 20, "repetition_penalty": 1.05}}


# ---------------------------------------------------------------------------
# 非 OpenAI SDK 兼容的独立客户端
# ---------------------------------------------------------------------------

class AzureGPTClient:
    """Azure GPT，使用 AzureOpenAI SDK，非流式。"""

    def __init__(self, api_key: str, endpoint: str, model: str = "gpt-5.2",
                 api_version: str = "2025-04-01-preview", reasoning_effort: str = "low"):
        self.model = model
        self.reasoning_effort = reasoning_effort
        self.history = []
        try:
            self.client = AzureOpenAI(api_key=api_key, api_version=api_version,
                                      azure_endpoint=endpoint)
        except Exception as e:
            print(f"Azure客户端初始化失败: {e}")
            self.client = None

    def _build_content(self, prompt: str, image: Optional[str] = None):
        """构造 OpenAI 格式的 content 列表（可含图片）。"""
        content = []
        if image and os.path.exists(image):
            content.append({"type": "image_url", "image_url": {"url": image_to_data_url(image)}})
        content.append({"type": "text", "text": prompt})
        return content

    def _api_call(self, messages) -> Dict[str, Any]:
        if not self.client:
            return {"success": False, "error": "Azure客户端未初始化", "response": ""}
        try:
            params = {"model": self.model, "messages": messages}
            if self.reasoning_effort:
                params["reasoning_effort"] = self.reasoning_effort
            response = self.client.chat.completions.create(**params)
            if response.choices and len(response.choices) > 0:
                return {
                    "success": True,
                    "response": response.choices[0].message.content,
                    "raw": response.model_dump() if hasattr(response, 'model_dump') else str(response),
                }
            return {"success": False, "error": "响应中没有choices", "response": ""}
        except Exception as e:
            return {"success": False, "error": str(e), "response": ""}

    def call(self, prompt: str, image: Optional[str] = None, **_) -> Dict[str, Any]:
        """单轮调用，不保留历史。"""
        return self._api_call([{"role": "user", "content": self._build_content(prompt, image)}])

    def chat(self, prompt: str, image: Optional[str] = None, **_) -> Dict[str, Any]:
        """多轮调用，自动维护对话历史。"""
        self.history.append({"role": "user", "content": self._build_content(prompt, image)})
        result = self._api_call(self.history)
        if result["success"]:
            self.history.append({"role": "assistant", "content": result["response"]})
        return result

    def reset(self):
        """清空对话历史。"""
        self.history = []


class GeminiClient:
    """Gemini，直接调用 Google REST API（google-style contents 格式）。"""

    def __init__(self, api_key: str, api_url: str, model_name: str = "gemini-2.0-flash-exp"):
        self.api_key = api_key
        self.api_url = api_url
        self.model_name = model_name
        self.history = []

    def _build_parts(self, prompt: str, image: Optional[str] = None):
        """构造 Gemini 格式的 parts 列表（可含图片）。"""
        parts = []
        if image and os.path.exists(image):
            parts.append({
                "inline_data": {
                    "mime_type": get_image_mime_type(image),
                    "data": encode_image_to_base64(image),
                }
            })
        parts.append({"text": prompt})
        return parts

    def _api_call(self, contents) -> Dict[str, Any]:
        headers = {
            "x-goog-api-key": self.api_key,
            "Content-Type": "application/json",
            "Cookie": "SITE_TOTAL_ID=d011e11efbb1a4bf9163830b0f22e8e7",
        }
        payload = {
            "contents": contents,
            "generationConfig": {"thinkingConfig": {"thinkingLevel": "low"}},
        }
        try:
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=120)
            response.raise_for_status()
            result = response.json()
            if "candidates" in result and len(result["candidates"]) > 0:
                resp_parts = result['candidates'][0]['content']['parts']
                text = "".join(p['text'] for p in resp_parts if 'text' in p)
                return {"success": True, "response": text, "raw": result}
            return {"success": False, "error": "响应中没有candidates", "response": ""}
        except Exception as e:
            return {"success": False, "error": str(e), "response": ""}

    def call(self, prompt: str, image: Optional[str] = None, **_) -> Dict[str, Any]:
        """单轮调用，不保留历史。"""
        return self._api_call([{"role": "user", "parts": self._build_parts(prompt, image)}])

    def chat(self, prompt: str, image: Optional[str] = None, **_) -> Dict[str, Any]:
        """多轮调用，自动维护对话历史。"""
        self.history.append({"role": "user", "parts": self._build_parts(prompt, image)})
        result = self._api_call(self.history)
        if result["success"]:
            self.history.append({"role": "model", "parts": [{"text": result["response"]}]})
        return result

    def reset(self):
        """清空对话历史。"""
        self.history = []


class SeedClient:
    """Seed（Doubao Seed 2.0），通过 PTU 接口调用，依赖 openai_proxy。

    ``openai_proxy`` 已随 fvgtools 捆绑在 vendor 目录中，无需单独安装。
    PTU 服务地址为 SenseTime 内网接口，外网不可访问。

    初始化时若 ``auto_setup_hosts=True``（默认），会自动在 ``/etc/hosts`` 中写入
    PTU 域名解析条目::

        172.19.57.3    api.schedule.mtc.sensetime.com

    无写入权限时打印警告并提示手动添加，不阻断初始化。
    """

    def __init__(self, api_key: str, model_name: str = "doubao-seed-2.0-260215",
                 channel_code: str = "doubao", auto_setup_hosts: bool = True):
        self.api_key = api_key
        self.model_name = model_name
        self.channel_code = channel_code
        self.history = []
        if auto_setup_hosts:
            self._setup_hosts()
        self.client = _openai_proxy.GptProxy(api_key=api_key)

    def _setup_hosts(self):
        """向 /etc/hosts 写入 PTU 域名解析条目（幂等，已存在则跳过）。"""
        entry = "172.19.57.3    api.schedule.mtc.sensetime.com"
        hosts = "/etc/hosts"
        try:
            with open(hosts, 'r') as f:
                content = f.read()
            if "api.schedule.mtc.sensetime.com" in content:
                print(f"[SeedClient] /etc/hosts 已有 api.schedule.mtc.sensetime.com，跳过写入")
                return
            with open(hosts, 'a') as f:
                f.write(f"\n{entry}\n")
            print(f"[SeedClient] /etc/hosts 已添加: {entry}")
        except PermissionError:
            print(f"[SeedClient] 警告: 无权限写入 /etc/hosts，请手动添加以下条目:\n  {entry}")
        except Exception as e:
            print(f"[SeedClient] 警告: 修改 /etc/hosts 失败 ({e})，请手动添加以下条目:\n  {entry}")

    def _build_content(self, prompt: str, image: Optional[str] = None):
        """构造 OpenAI 格式的 content 列表（可含图片）。"""
        content = []
        if image and os.path.exists(image):
            content.append({"type": "image_url", "image_url": {"url": image_to_data_url(image)}})
        content.append({"type": "text", "text": prompt})
        return content

    def _api_call(self, messages, temperature=0.7, max_tokens=32768) -> Dict[str, Any]:
        try:
            transaction_id = f"{getpass.getuser()}-{self.model_name}"
            response = self.client.generate(
                messages=messages, model=self.model_name,
                channel_code=self.channel_code, transaction_id=transaction_id,
                temperature=temperature, max_tokens=max_tokens,
            )
            if not response.ok:
                return {"success": False, "error": f"PTU server error: {response.status_code}",
                        "response": ""}

            ptu_resp = response.json()
            choices = ptu_resp.get("data", {}).get("response_content", {}).get("choices", [])
            if not choices:
                return {"success": False, "error": f"响应中没有choices: {str(ptu_resp)[:200]}",
                        "response": "", "raw": ptu_resp}

            msg = choices[0]["message"]
            content = msg.get("content", "")
            reasoning = msg.get("reasoning_content", None)
            if reasoning:
                response_text = f"<think>\n{reasoning}\n</think>\n\n{content}"
            else:
                response_text = content
            return {
                "success": True,
                "response": response_text,
                "raw": {"content": content, "reasoning_content": reasoning, "full_response": ptu_resp},
            }
        except Exception as e:
            return {"success": False, "error": str(e), "response": ""}

    def call(self, prompt: str, image: Optional[str] = None,
             temperature: float = 0.7, max_tokens: int = 32768) -> Dict[str, Any]:
        """单轮调用，不保留历史。"""
        return self._api_call([{"role": "user", "content": self._build_content(prompt, image)}],
                              temperature, max_tokens)

    def chat(self, prompt: str, image: Optional[str] = None,
             temperature: float = 0.7, max_tokens: int = 32768) -> Dict[str, Any]:
        """多轮调用，自动维护对话历史。"""
        self.history.append({"role": "user", "content": self._build_content(prompt, image)})
        result = self._api_call(self.history, temperature, max_tokens)
        if result["success"]:
            self.history.append({"role": "assistant", "content": result["response"]})
        return result

    def reset(self):
        """清空对话历史。"""
        self.history = []


# ---------------------------------------------------------------------------
# 便捷包装函数
# ---------------------------------------------------------------------------

def call_llm(client, prompt: str, image: Optional[str] = None,
             temperature: float = 0.7, max_tokens: int = 2048) -> Dict[str, Any]:
    """单轮调用，兼容所有客户端。"""
    return client.call(prompt=prompt, image=image, temperature=temperature, max_tokens=max_tokens)


def chat_llm(client, prompt: str, image: Optional[str] = None,
             temperature: float = 0.7, max_tokens: int = 2048) -> Dict[str, Any]:
    """多轮调用，兼容所有客户端。"""
    return client.chat(prompt=prompt, image=image, temperature=temperature, max_tokens=max_tokens)
