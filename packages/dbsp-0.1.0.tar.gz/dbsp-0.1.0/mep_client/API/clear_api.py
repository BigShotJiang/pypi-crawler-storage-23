import os
import shutil
from typing import List, Dict, Any


def clear_pycache(directory: str) -> Dict[str, Any]:
    """
    Remove all __pycache__ directories under the specified directory
    """
    deleted_dirs = []
    count = 0
    
    for root, dirs, files in os.walk(directory):
        if '__pycache__' in dirs:
            pycache_path = os.path.join(root, '__pycache__')
            try:
                shutil.rmtree(pycache_path)
                deleted_dirs.append(pycache_path)
                count += 1
            except Exception as e:
                print(f"Failed to remove __pycache__ directory: {pycache_path}, error: {e}")
    
    return {
        "type": "pycache",
        "count": count,
        "deleted_paths": deleted_dirs
    }


def clear_logs(log_directory: str) -> Dict[str, Any]:
    """
    Clean the log directory, including all subfolders and files
    """
    deleted_items = []
    count = 0
    
    if os.path.exists(log_directory):
        for item in os.listdir(log_directory):
            item_path = os.path.join(log_directory, item)
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                    deleted_items.append(item_path)
                    count += 1
                elif os.path.isfile(item_path):
                    os.remove(item_path)
                    deleted_items.append(item_path)
                    count += 1
            except Exception as e:
                print(f"Failed to remove log item: {item_path}, error: {e}")
    
    return {
        "type": "logs",
        "count": count,
        "deleted_paths": deleted_items
    }


def clear_final_results(final_results_dir: str) -> Dict[str, Any]:
    """
    Clean the final_results directory, including all subfolders and files
    """
    deleted_items = []
    count = 0
    
    if os.path.exists(final_results_dir):
        # Iterate through all items in the final_results directory
        for item in os.listdir(final_results_dir):
            item_path = os.path.join(final_results_dir, item)
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                    deleted_items.append(item_path)
                    count += 1
                elif os.path.isfile(item_path):
                    os.remove(item_path)
                    deleted_items.append(item_path)
                    count += 1
            except Exception as e:
                print(f"Failed to remove final_results item: {item_path}, error: {e}")
    
    return {
        "type": "final_results",
        "count": count,
        "deleted_paths": deleted_items
    }


def clear_method_server_cache(method_server_dir: str) -> Dict[str, Any]:
    """
    Remove all 'cache' folders under the method_server directory
    """
    deleted_dirs = []
    count = 0
    
    if os.path.exists(method_server_dir):
        # Walk through all subdirectories under method_server
        for root, dirs, files in os.walk(method_server_dir):
            if 'cache' in dirs:
                cache_path = os.path.join(root, 'cache')
                try:
                    shutil.rmtree(cache_path)
                    deleted_dirs.append(cache_path)
                    count += 1
                except Exception as e:
                    print(f"Failed to remove cache directory: {cache_path}, error: {e}")
    
    return {
        "type": "method_server_cache",
        "count": count,
        "deleted_paths": deleted_dirs
    }


def clear_cache(base_directory: str = None) -> Dict[str, Any]:
    """
    Clean all cache-related files and directories
    """
    if base_directory is None:
        base_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    results = []
    
    # Clean __pycache__ directories
    pycache_result = clear_pycache(base_directory)
    results.append(pycache_result)
    
    # Clean log files and directories
    log_dir = os.path.join(base_directory, 'log')
    logs_result = clear_logs(log_dir)
    results.append(logs_result)
    
    # Clean final_results directory
    final_results_dir = os.path.join(base_directory, 'final_results')
    final_results_result = clear_final_results(final_results_dir)
    results.append(final_results_result)
    
    # Clean cache folders under method_server directory
    parent_dir = os.path.dirname(base_directory)
    method_server_dir = os.path.join(parent_dir, 'method_server')
    if os.path.exists(method_server_dir):
        method_server_cache_result = clear_method_server_cache(method_server_dir)
        results.append(method_server_cache_result)
    
    # Calculate total number of deleted items
    total_deleted = sum(result.get('count', 0) for result in results)
    
    return {
        "total_deleted": total_deleted,
        "results": results,
        "message": f"Cleanup completed, total {total_deleted} cache files/directories removed"
    }


def clear():
    # Test the cleanup function
    result = clear_cache()
    print("Cleanup result:")
    print(f"Total items deleted: {result['total_deleted']}")
    print("Detailed results:")
    for res in result['results']:
        print(f"- {res['type']}: Removed {res.get('count', 0)} file(s)/directory(ies)")
        if res.get('deleted_paths'):
            print("  Deleted paths:")
            for path in res['deleted_paths'][:5]:  # Show only first 5 paths
                print(f"    - {path}")
            if len(res['deleted_paths']) > 5:
                print(f"    ... and {len(res['deleted_paths']) - 5} more paths")
    print(result['message'])

if __name__ == "__main__":
    clear()