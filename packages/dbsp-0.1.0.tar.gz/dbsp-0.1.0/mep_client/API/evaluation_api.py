import os
import sys
import json
import datetime
import threading
from typing import Dict, List, Optional, Any
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from config import load_llm_config
from run.utils import generate_user_ans
from run.run import run_evaluation

running_tasks = {}
stop_events = {}
lock = threading.Lock()

def start_evaluation(model_name: str, benchmark: str, **kwargs) -> Dict[str, str]:
    """
    Start evaluation task API
    """
    # Generate run_id
    run_id = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    _llm_cfg = load_llm_config()
    instantiate_model = _llm_cfg.instantiate_model
    
    model = instantiate_model(model_name, kwargs)
    
    stop_event = threading.Event()
    
    # Start evaluation task in background
    def task():
        try:
            metadata = generate_user_ans(
                model=model,
                benchmark_name=benchmark,
                batch_size=kwargs.get('batch_size', 1),
                worker_nums=kwargs.get('worker_nums', 1),
                rate_limit=kwargs.get('rate_limit', 1),
                bucket_capacity=kwargs.get('bucket_capacity', 1.0),
                limited_test=kwargs.get('limited_test', False),
                model_name=model_name,
                continue_generate=False,
                run_id=run_id,
                stop_event=stop_event
            )
            
            # Check if paused/stopped
            if not stop_event.is_set():
                run_tag = metadata["run_tag"]
                actual_run_tag = f"{run_tag}_{model_name}"
                selected_benchmark = metadata.get("selected_benchmark", benchmark)
                run_evaluation(actual_run_tag, selected_benchmark)
                # Update task status
                if run_id in running_tasks:
                    running_tasks[run_id]['status'] = 'completed'
            else:
                if run_id in running_tasks:
                    running_tasks[run_id]['status'] = 'paused'
        except Exception as e:
            if run_id in running_tasks:
                running_tasks[run_id]['status'] = 'failed'
                running_tasks[run_id]['error'] = str(e)
    
    # Record task information
    running_tasks[run_id] = {
        'model': model_name,
        'benchmark': benchmark,
        'status': 'running',
        'start_time': datetime.datetime.now().isoformat(),
        'thread': None,
        'params': kwargs  
    }
    stop_events[run_id] = stop_event
    
    thread = threading.Thread(target=task, daemon=False)
    thread.start()
    
    running_tasks[run_id]['thread'] = thread
    
    return {'run_id': run_id}

def pause_evaluation(run_id: str) -> Dict[str, str]:
    """
    Pause evaluation task API
    
    Args:
        run_id: Run ID
    
    Returns:
        Dict: Status information
    """
    if run_id not in running_tasks:
        return {'status': 'error', 'message': 'Task does not exist'}
    
    task_info = running_tasks[run_id]
    if task_info['status'] != 'running':
        return {'status': 'error', 'message': 'Task is not in running state'}
    
    # Set stop event
    if run_id in stop_events:
        stop_events[run_id].set()
    
    task_info['status'] = 'paused'
    thread = task_info.get('thread')
    
    if thread and thread.is_alive():
        try:
            thread.join(timeout=5)
        except Exception:
            pass
        
    return {'status': 'success', 'message': 'Task has been paused'}

def continue_evaluation(run_id: str) -> Dict[str, str]:
    """
    Resume / continue evaluation task API
    """
    # First check in-memory tasks
    if run_id in running_tasks:
        task_info = running_tasks[run_id]
        if task_info['status'] == 'completed':
            return {'status': 'error', 'message': 'Task already completed, no need to continue'}
        if task_info['status'] == 'running':
            return {'status': 'error', 'message': 'Task is already running'}
        
        # Only allow resume when paused
        if task_info['status'] != 'paused':
            return {'status': 'error', 'message': f'Task status is {task_info["status"]}, cannot continue'}
        
        # Create new stop event
        new_stop_event = threading.Event()
        
        _llm_cfg = load_llm_config()
        instantiate_model = _llm_cfg.instantiate_model
        model = instantiate_model(task_info['model'], {})
        
        params = task_info.get('params', {})
        batch_size = params.get('batch_size', 8)
        worker_nums = params.get('worker_nums', 2)
        rate_limit = params.get('rate_limit', 5.0)
        bucket_capacity = params.get('bucket_capacity', 10.0)
        limited_test = False 
        
        # Execute task
        def task():
            try:
                metadata = generate_user_ans(
                    model=model,
                    benchmark_name=task_info['benchmark'],
                    batch_size=batch_size,
                    worker_nums=worker_nums,
                    rate_limit=rate_limit,
                    bucket_capacity=bucket_capacity,
                    limited_test=limited_test,
                    model_name=task_info['model'],
                    continue_generate=True,
                    run_id=run_id,
                    stop_event=new_stop_event
                )
                if not new_stop_event.is_set():
                    run_tag = metadata["run_tag"]
                    actual_run_tag = f"{run_tag}_{task_info['model']}"
                    selected_benchmark = metadata.get("selected_benchmark", task_info['benchmark'])
                    run_evaluation(actual_run_tag, selected_benchmark)
                    if run_id in running_tasks:
                        running_tasks[run_id]['status'] = 'completed'
                else:
                    if run_id in running_tasks:
                        running_tasks[run_id]['status'] = 'paused'
            except Exception as e:
                pass
        
        thread = threading.Thread(target=task, daemon=False)
        thread.start()
        
        running_tasks[run_id]['status'] = 'running'
        running_tasks[run_id]['thread'] = thread
        stop_events[run_id] = new_stop_event
        
        return {'status': 'success', 'message': 'Task has resumed'}
    
    # If not in memory, check task_records.json
    task_records_file = os.path.join(os.path.dirname(__file__), '..', 'log', 'task_records.json')
    if not os.path.exists(task_records_file):
        return {'status': 'error', 'message': 'Task records file does not exist'}
    
    with open(task_records_file, 'r', encoding='utf-8') as f:
        task_records = json.load(f)
    
    task_info = None
    for record in task_records:
        if record['run_id'] == run_id:
            task_info = record
            break
    
    if not task_info:
        return {'status': 'error', 'message': 'Task record not found'}
    
    if task_info['status'] == 'completed':
        return {'status': 'error', 'message': 'Task already completed, no need to continue'}
    
    _llm_cfg = load_llm_config()
    instantiate_model = _llm_cfg.instantiate_model
    
    model = instantiate_model(task_info['model'], {})
    new_stop_event = threading.Event()
    
    def task():
        try:
            metadata = generate_user_ans(
                model=model,
                benchmark_name=task_info['benchmark'],
                batch_size=8,
                worker_nums=2,
                rate_limit=5.0,
                bucket_capacity=10.0,
                limited_test=False,
                model_name=task_info['model'],
                continue_generate=True,
                run_id=run_id,
                stop_event=new_stop_event
            )
            
            if not new_stop_event.is_set():
                run_tag = metadata["run_tag"]
                actual_run_tag = f"{run_tag}_{task_info['model']}"
                selected_benchmark = metadata.get("selected_benchmark", task_info['benchmark'])
                run_evaluation(actual_run_tag, selected_benchmark)
                
                if run_id in running_tasks:
                    running_tasks[run_id]['status'] = 'completed'
            else:
                if run_id in running_tasks:
                    running_tasks[run_id]['status'] = 'paused'
        except Exception as e:
            if run_id in running_tasks:
                running_tasks[run_id]['status'] = 'failed'
                running_tasks[run_id]['error'] = str(e)
    
    thread = threading.Thread(target=task, daemon=False)
    thread.start()
    
    running_tasks[run_id] = {
        'status': 'running',
        'model': task_info['model'],
        'benchmark': task_info['benchmark'],
        'thread': thread,
        'stop_event': new_stop_event
    }
    stop_events[run_id] = new_stop_event
    
    return {'status': 'success', 'message': 'Task has resumed'}

def get_dataset_ranking(dataset_name: str) -> List[Dict[str, Any]]:
    """
    Get ranking of models on the specified dataset
    """
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'final_results', dataset_name)
    if not os.path.exists(results_dir):
        return []
    
    all_results_file = os.path.join(results_dir, 'all_results.json')
    if not os.path.exists(all_results_file):
        return []
    
    with open(all_results_file, 'r', encoding='utf-8') as f:
        all_results = json.load(f)
    
    sort_key = None
    for result in all_results:
        if 'overall_performance' in result and 'score' in result['overall_performance']:
            sort_key = lambda x: x.get('overall_performance', {}).get('score', 0)
            break
        elif 'accuracy' in result:
            sort_key = lambda x: x.get('accuracy', 0)
            break
        elif 'F1_score' in result:
            sort_key = lambda x: x.get('F1_score', 0)
            break
    
    if sort_key:
        sorted_results = sorted(all_results, key=sort_key, reverse=True)
    else:
        sorted_results = all_results
      
    return sorted_results

def get_model_benchmark_results(model_name: str) -> Dict[str, Any]:
    """
    Get results of the same model across different benchmarks
    """
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'final_results')
    if not os.path.exists(results_dir):
        return {}
    
    model_results = {}
    
    for benchmark in os.listdir(results_dir):
        benchmark_dir = os.path.join(results_dir, benchmark)
        if not os.path.isdir(benchmark_dir):
            continue
        
        all_results_file = os.path.join(benchmark_dir, 'all_results.json')
        if not os.path.exists(all_results_file):
            continue
        
        with open(all_results_file, 'r', encoding='utf-8') as f:
            all_results = json.load(f)
        
        model_benchmark_results = []
        for result in all_results:
            if result.get('model') == model_name:
                model_benchmark_results.append(result)
        
        if model_benchmark_results:
            model_results[benchmark] = model_benchmark_results
    
    return model_results

def get_evaluation_result_by_run_id(run_id: str) -> Dict[str, Any]:
    """
    Query evaluation result by run_id
    """
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'final_results')
    if not os.path.exists(results_dir):
        return {}
    
    for benchmark in os.listdir(results_dir):
        benchmark_dir = os.path.join(results_dir, benchmark)
        if not os.path.isdir(benchmark_dir):
            continue
        
        for model_name in os.listdir(benchmark_dir):
            model_dir = os.path.join(benchmark_dir, model_name)
            if not os.path.isdir(model_dir):
                continue
            
            run_dir = os.path.join(model_dir, run_id)
            if os.path.isdir(run_dir):
                report_file = os.path.join(run_dir, 'evaluation_report.json')
                if os.path.exists(report_file):
                    with open(report_file, 'r', encoding='utf-8') as f:
                        report_data = json.load(f)
                        return {
                            'run_id': run_id,
                            'model_name': model_name,
                            'benchmark': benchmark,
                            'result': report_data
                        }
    
    # Fallback: check task_records.json
    task_records_file = os.path.join(os.path.dirname(__file__), '..', 'log', 'task_records.json')
    if os.path.exists(task_records_file):
        with open(task_records_file, 'r', encoding='utf-8') as f:
            task_records = json.load(f)
        
        for record in task_records:
            if record.get('run_id') == run_id:
                return {
                    'run_id': run_id,
                    'model_name': record.get('model'),
                    'benchmark': record.get('benchmark'),
                    'status': record.get('status'),
                    'task_record': record
                }
    
    return {'error': 'Evaluation result not found for this run_id'}

def get_task_status(run_id: str) -> Dict[str, Any]:
    """
    Get current status of a task
    """
    if run_id in running_tasks:
        task_info = running_tasks[run_id].copy()
        task_records_file = os.path.join(os.path.dirname(__file__), '..', 'log', 'task_records.json')
        if os.path.exists(task_records_file):
            with open(task_records_file, 'r', encoding='utf-8') as f:
                task_records = json.load(f)
            for record in task_records:
                if record['run_id'] == run_id and 'current_subtask' in record:
                    task_info['current_subtask'] = record['current_subtask']
                    break
        task_info.pop('thread', None)
        task_info.pop('stop_event', None)
        return task_info
    
    task_records_file = os.path.join(os.path.dirname(__file__), '..', 'log', 'task_records.json')
    if os.path.exists(task_records_file):
        with open(task_records_file, 'r', encoding='utf-8') as f:
            task_records = json.load(f)
        
        for record in task_records:
            if record['run_id'] == run_id:
                return record
    
    return {'status': 'error', 'message': 'Task does not exist'}