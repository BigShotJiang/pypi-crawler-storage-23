import os
import json
import importlib
from mep_client.config import get_server_dir, ensure_llm_on_sys_path, get_llm_dir

ensure_llm_on_sys_path()


def discover_benchmarks():
    """
    Automatically discover all server/*/benchmark and load dataset_card.json
    """
    benchmark_root = get_server_dir()
    benchmark_list = []

    for benchmark_name in os.listdir(benchmark_root):
        card_path = os.path.join(benchmark_root, benchmark_name, "dataset_card.json")
        if not os.path.isfile(card_path):
            continue

        with open(card_path, "r", encoding="utf-8") as file:
            card = json.load(file)

        # Automatically load the functions
        prepare_func = load_function(card["prepare_function"])
        evaluate_func = load_function(card["evaluate_function"])

        benchmark_list.append({
            "name": benchmark_name,
            "card": card,
            "prepare": prepare_func,
            "evaluate": evaluate_func
        })

    return benchmark_list


def discover_llms():
    """
    Automatically discover llm models and load model_card.json
    """
    llm_root = get_llm_dir()
    llm_list = []

    for model_name in os.listdir(llm_root):
        card_path = os.path.join(llm_root, model_name, "model_card.json")
        if not os.path.isfile(card_path):
            continue

        with open(card_path, "r", encoding="utf-8") as file:
            card = json.load(file)

        api_class = load_class(card["api_entry"], prefix="llm")

        llm_list.append({
            "name": model_name,
            "card": card,
            "api": api_class
        })

    return llm_list


def load_function(path_str):
    """
    Load function from 'module.function'
    """
    module_name, func_name = path_str.rsplit(".", 1)
    module = importlib.import_module(module_name)
    return getattr(module, func_name)


def load_class(path_str, prefix=""):
    """
    Load class from 'module.ClassName'
    """
    module_name, class_name = path_str.rsplit(".", 1)

    if prefix:
        full_module_name = f"{prefix}.{module_name}"
    else:
        full_module_name = module_name

    try:
        module = importlib.import_module(full_module_name)
    except Exception as e:
        raise ImportError(
            f"Cannot import module {full_module_name} (from {path_str}) — {e}"
        )

    try:
        return getattr(module, class_name)
    except Exception as e:
        raise ImportError(
            f"Class {class_name} not found in module {full_module_name} — {e}"
        )
from mep_client.config import list_all_benchmarks, list_all_llms

def auto_discover():
    benchmarks = list_all_benchmarks()
    llms = list_all_llms()

    print("Discovered Benchmarks:", [b["name"] for b in benchmarks])
    print("Discovered LLM Models:", [m["name"] for m in llms])

if __name__ == "__main__":
    auto_discover()