import os
import sys
import json
import importlib

def _project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def get_server_dir():
    env = os.environ.get("MEP_SERVER_DIR")
    if env:
        return os.path.normpath(env)
    return os.path.join(_project_root(), "method_server")


def get_llm_dir():
    env = os.environ.get("MEP_LLM_DIR")
    if env:
        return os.path.normpath(env)
    return os.path.join(_project_root(), "llm")


def ensure_server_on_sys_path():
    d = get_server_dir()
    pd = os.path.dirname(d)
    if pd and pd not in sys.path:
        sys.path.insert(0, pd)

def ensure_llm_on_sys_path():
    llm_dir = get_llm_dir()  
    root = os.path.dirname(llm_dir) 
    if root not in sys.path:
        sys.path.insert(0, root)


def load_llm_config():
    d = get_llm_dir()
    p = os.path.normpath(d) if d else d
    if p:
        mn = os.path.basename(p)
        pd = os.path.dirname(p)
        if pd and pd not in sys.path:
            sys.path.insert(0, pd)
        try:
            return importlib.import_module(f"{mn}.config")
        except Exception:
            try:
                return importlib.import_module("llm.config")
            except Exception:
                raise
    return importlib.import_module("llm.config")

def list_all_benchmarks():
    from mep_client.API.auto_discover import discover_benchmarks
    return discover_benchmarks()


def list_all_llms():
    from mep_client.API.auto_discover import discover_llms
    return discover_llms()
