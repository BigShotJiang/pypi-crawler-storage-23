import os
import sys
import importlib

MODEL_REGISTRY = {
}

def get_model_choices():
    return list(MODEL_REGISTRY.keys())

def add_model_args(parser, key):
    cfg = MODEL_REGISTRY.get(key, {})
    args_def = cfg.get("args", {})
    for arg_name, default_value in args_def.items():
        arg_type = int if isinstance(default_value, int) else float if isinstance(default_value, float) else str
        parser.add_argument(f"--{arg_name}", default=default_value, type=arg_type)

def instantiate_model(key, args):
    cfg = MODEL_REGISTRY[key]
    mod_str = cfg["module"]
    try:
        module = importlib.import_module(mod_str)
    except Exception:
        root = "llm"
        module = importlib.import_module(f"{root}.{mod_str}")
    cls = getattr(module, cfg["class"])
    return cls(args)
