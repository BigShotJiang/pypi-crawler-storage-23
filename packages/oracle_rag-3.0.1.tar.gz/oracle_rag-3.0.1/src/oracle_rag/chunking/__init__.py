"""Chunking of documents for RAG."""

from oracle_rag.chunking.splitter import chunk_documents

__all__ = ["chunk_documents"]
