# =============================================================================
#                           STORY cipher by JuCrypt
#   Path    :   jucrypt/story.py
#   Version :   v0.3.0
#   Author  :   Nabil 
#   DOI     :   <>
# =============================================================================

import os
import hashlib
import hmac
import json
import struct
from typing import Tuple, List, Union

# Pure Python
# GF(2^8) multiplication table — built once at import time for speed
def _build_gf_table() -> List[List[int]]:
    table = [[0] * 256 for _ in range(256)]
    for a in range(256):
        x = a
        for b in range(256):
            p, y, xx = 0, b, x
            for _ in range(8):
                if y & 1:
                    p ^= xx
                hi = xx & 0x80
                xx = (xx << 1) & 0xFF
                if hi:
                    xx ^= 0x1B
                y >>= 1
            table[a][b] = p
    return table


_GF = _build_gf_table()


# Cauchy MDS matrix derivation 
def _derive_cauchy_matrices() -> Tuple[List[List[int]], List[List[int]]]:
    # Multiplicative inverse table in GF(2^8)
    gf_inv = [0] * 256
    for a in range(1, 256):
        for b in range(1, 256):
            if _GF[a][b] == 1:
                gf_inv[a] = b
                break

    def pow_alpha(n: int) -> int:
        a = 1
        for _ in range(n):
            a = _GF[a][2]
        return a

    xs = [pow_alpha(i) for i in range(16)]  # α^0 ..... α^15
    ys = [pow_alpha(i + 16) for i in range(16)]  # α^16 .... α^31

    # Cauchy matrix: all xs distinct, all ys distinct, sets disjoint → invertible
    M = [[gf_inv[xs[i] ^ ys[j]] for j in range(16)] for i in range(16)]

    # Gauss-Jordan inversion over GF(2^8)
    n = 16
    aug = [M[i][:] + [1 if i == j else 0 for j in range(n)] for i in range(n)]
    for col in range(n):
        piv = next((r for r in range(col, n) if aug[r][col]), -1)
        if piv == -1:
            raise RuntimeError("Cauchy matrix singular")
        aug[col], aug[piv] = aug[piv], aug[col]
        pi = gf_inv[aug[col][col]]
        for k in range(2 * n):
            aug[col][k] = _GF[aug[col][k]][pi]
        for r in range(n):
            if r != col and aug[r][col]:
                f = aug[r][col]
                for k in range(2 * n):
                    aug[r][k] ^= _GF[f][aug[col][k]]
    return M

_MIX_M = _derive_cauchy_matrices()

# Main Story Class
class STORY:
    # Constants
    BLOCK_SIZE = 16  # 128-bit block
    KEY_SIZE = 32  # 256-bit derived key
    ROUNDS_MIN = 8  # Minimum actual rounds (key-derived base)
    ROUNDS_MAX = 12  # Maximum key-derived base
    # Actual rounds = key-derived base [8-12] + salt offset [0-3] → [8-15]

    # S-box cache — shared across all instances
    _SBOXES_CACHE: dict = {}

    # S-box validation
    @classmethod
    def _validate_sbox(cls, idx: int, sbox: list) -> None:
        if len(sbox) != 256:
            raise ValueError(f"S-box {idx}: expected 256 entries, got {len(sbox)}")
        if sorted(sbox) != list(range(256)):
            raise ValueError(
                f"S-box {idx}: not a bijection (not a permutation of 0–255)"
            )

    # S-box loading, checks JSON at first, if present then ignores default, if not then default
    # We are also planning add a feature where you will be able to generate 256 unique sboxes with lower DDT and LAT as well as json to python pool to speed process.
    @classmethod
    def _load_sboxes(cls) -> dict:
        if cls._SBOXES_CACHE:
            return cls._SBOXES_CACHE

        base = os.path.dirname(__file__)
        json_path = os.path.join(base, "customju", "sboxes.json")

        if os.path.isfile(json_path):
            with open(json_path, "r") as f:
                raw = json.load(f)
            for k, v in raw.items():
                sbox = [(int(x) - 1) % 256 for x in v.split(",")]
                cls._validate_sbox(int(k), sbox)
                cls._SBOXES_CACHE[int(k)] = sbox
            return cls._SBOXES_CACHE

        try:
            from jucrypt.backup_sboxes import SBOX_POOL
        except ImportError:
            raise RuntimeError(
                "STORY S-box pool not found.\n"
                "Expected one of:\n"
                "  -> customju/sboxes.json       (your custom pool)\n"
                "  -> jucrypt/default_sboxes.py  (ships with the package)\n"
                "Re-install: pip uninstall jucrypt && pip install jucrypt\n"
                "or place customju/sboxes.json next to story.py."
            )

        for idx, sbox in SBOX_POOL.items():
            cls._validate_sbox(idx, sbox)
            cls._SBOXES_CACHE[idx] = sbox

        return cls._SBOXES_CACHE

    @staticmethod
    def _derive_master_key(story_bytes: bytes) -> Tuple[bytes, bytes]:
        """Derive enc_key and mac_key from the story key material (bytes)."""
        ikm = hashlib.shake_256(story_bytes).digest(STORY.KEY_SIZE)
        enc_key = hmac.new(ikm, b"enc||story_v1_master", hashlib.sha256).digest()
        mac_key = hmac.new(ikm, b"mac||story_v1_master", hashlib.sha256).digest()
        return enc_key, mac_key

    @staticmethod
    def _derive_sbox(master: bytes) -> List[int]:
        """Select one S-box from the pool deterministically from master key."""
        all_sboxes = STORY._load_sboxes()
        idx_stream = hashlib.shake_256(b"story_v1_sbox||" + master).digest(2)
        idx = struct.unpack(">H", idx_stream)[0] % len(all_sboxes)
        return all_sboxes[idx]

    @staticmethod
    def _derive_round_count(master: bytes) -> int:
        span      = STORY.ROUNDS_MAX - STORY.ROUNDS_MIN + 1
        threshold = 256 - (256 % span)
        stream    = bytearray(hashlib.shake_256(b"story_v1_rounds||" + master).digest(8))
        for b in stream:
            if b < threshold:
                return STORY.ROUNDS_MIN + (b % span)
        return STORY.ROUNDS_MIN

    @staticmethod
    def _expand_round_keys(master: bytes, count: int) -> List[bytes]:
        """Generate count round keys from master."""
        keys = []
        for r in range(count):
            label = b"story_v1_round||" + r.to_bytes(4, "big")
            rk = hmac.new(master, label, hashlib.sha256).digest()[:STORY.BLOCK_SIZE]
            keys.append(rk)
        return keys

    @staticmethod
    def _derive_whitening_key(master: bytes) -> bytes:
        """Final AddRoundKey whitening — domain-separated from round keys."""
        return hmac.new(master, b"story_v1_whitening||", hashlib.sha256).digest()[:STORY.BLOCK_SIZE]

    @staticmethod
    def _derive_perm(master: bytes) -> List[int]:
        """Key-dependent byte permutation."""
        stream = bytearray(hashlib.shake_256(b"story_v1_perm||" + master).digest(64))
        pos = 0
        perm = list(range(16))

        for i in range(15, 0, -1):
            limit = i + 1
            threshold = 256 - (256 % limit) 
            while True:
                if pos >= len(stream):
                    stream = bytearray(
                        hashlib.shake_256(
                            b"story_v1_perm||" + master + pos.to_bytes(4, "big")
                        ).digest(64)
                    )
                    pos = 0
                b = stream[pos]
                pos += 1
                if b < threshold:
                    j = b % limit
                    perm[i], perm[j] = perm[j], perm[i]
                    break
        return perm

    # SPN primitives — all operate on List[int] state in-place
    @staticmethod
    def _sub_bytes(state: List[int], sbox: List[int]) -> None:
        for i in range(16):
            state[i] = sbox[state[i]]

    @staticmethod
    def _permute(state: List[int], perm: List[int]) -> None:
        tmp = state[:]
        for i in range(16):
            state[i] = tmp[perm[i]]

    @staticmethod
    def _mix(state: List[int]) -> None:
        """Full-State MDS Mix over GF(2^8)."""
        result = [0] * 16
        for i in range(16):
            acc = 0
            row = _MIX_M[i]
            for j in range(16):
                acc ^= _GF[row[j]][state[j]]
            result[i] = acc
        for i in range(16):
            state[i] = result[i]

    # Block encryption, pure bytes to speed up the process
    @staticmethod
    def _encrypt_block(
        block: bytes,
        perm: List[int],
        sbox: List[int],
        round_keys: List[bytes],
        final_key: bytes,
    ) -> bytes:
        """Encrypt one 16-byte block."""
        state = list(block)

        for rk in round_keys:
            for i in range(16):
                state[i] ^= rk[i]
            STORY._sub_bytes(state, sbox)
            STORY._permute(state, perm)
            STORY._mix(state)

        # Final whitening, closes the last Mix against key-recovery
        for i in range(16):
            state[i] ^= final_key[i]

        return bytes(state)

    # Counter block
    @staticmethod
    def _make_counter_block(nonce: bytes, counter: int) -> bytes:
        """8-byte nonce || 8-byte big-endian counter → 16-byte block."""
        return nonce + counter.to_bytes(8, "big")

    # Input normalisation, preinstalled for software needs with less code.
    @staticmethod
    def _to_bytes(data) -> bytes:
        """Convert any supported plaintext type to bytes."""
        if isinstance(data, bytes):
            return data
        if isinstance(data, bytearray):
            return bytes(data)
        if isinstance(data, str):
            return data.encode("utf-16-le")
        raise TypeError(
            f"Plaintext must be str, bytes, or bytearray."
            f"Got: {type(data).__name__}"
        )

    @staticmethod
    def _to_bytes_param(data, name: str) -> bytes:
        """Convert a hex string or bytes parameter (nonce / tag / round_salt)."""
        if isinstance(data, (bytes, bytearray)):
            return bytes(data)
        if isinstance(data, str):
            try:
                return bytes.fromhex(data)
            except ValueError:
                raise ValueError(f"'{name}' hex string is malformed: {data!r}")
        raise TypeError(
            f"'{name}' must be bytes or hex string. Got: {type(data).__name__}"
        )

    # Public API
    @staticmethod
    def encrypt(plaintext, story: str) -> Tuple[str, str, str, str]:
        """Encrypt plaintext under a story key."""
        pt_bytes = STORY._to_bytes(plaintext)
        story_bytes = story.encode("utf-16-le") 
        enc_key, mac_key = STORY._derive_master_key(story_bytes)
        sbox = STORY._derive_sbox(enc_key)
        perm = STORY._derive_perm(enc_key)
        base_rounds = STORY._derive_round_count(enc_key)  

        round_salt = os.urandom(1)
        salt_offset = round_salt[0] % 4  
        actual_rounds = base_rounds + salt_offset 

        round_keys = STORY._expand_round_keys(enc_key, actual_rounds)
        final_key = STORY._derive_whitening_key(enc_key) 

        # CTR encryption
        nonce = os.urandom(8)
        ciphertext = bytearray()
        counter = 0

        for i in range(0, len(pt_bytes), STORY.BLOCK_SIZE):
            block = pt_bytes[i : i + STORY.BLOCK_SIZE]
            keystream = STORY._encrypt_block(
                STORY._make_counter_block(nonce, counter),
                perm,
                sbox,
                round_keys,
                final_key,
            )
            ciphertext.extend(b ^ k for b, k in zip(block, keystream))
            counter += 1

        # Authenticate: HMAC over nonce || round_salt || ciphertext 
        tag = hmac.new(
            mac_key,
            nonce + round_salt + bytes(ciphertext),
            hashlib.sha256,
        ).digest()

        return (
            bytes(ciphertext),
            nonce,
            tag,
            round_salt,
        )

    @staticmethod
    def decrypt(
        ciphertext: Union[str, bytes],
        story: str,
        nonce: Union[str, bytes],
        tag: Union[str, bytes],
        round_salt: Union[str, bytes],
    ) -> bytes:
        """Decrypt and authenticate a STORY ciphertext."""
        ct_bytes = STORY._to_bytes_param(ciphertext, "ciphertext")
        nc_bytes = STORY._to_bytes_param(nonce, "nonce")
        tag_bytes = STORY._to_bytes_param(tag, "tag")
        rs_bytes = STORY._to_bytes_param(round_salt, "round_salt")

        story_bytes = story.encode("utf-16-le")
        enc_key, mac_key = STORY._derive_master_key(story_bytes)
        sbox = STORY._derive_sbox(enc_key)
        perm = STORY._derive_perm(enc_key)
        base_rounds = STORY._derive_round_count(enc_key)
        salt_offset = rs_bytes[0] % 4
        actual_rounds = base_rounds + salt_offset

        round_keys = STORY._expand_round_keys(enc_key, actual_rounds)
        final_key = STORY._derive_whitening_key(enc_key)

        # Authenticate
        check = hmac.new(
            mac_key,
            nc_bytes + rs_bytes + ct_bytes,
            hashlib.sha256,
        ).digest()
        if not hmac.compare_digest(check, tag_bytes):
            raise ValueError(
                "Authentication Failed.\n"
                "The ciphertext, nonce, tag, or round_salt has been tampered with,\n"
                "or the story key is incorrect."
            )

        # CTR decryption
        plaintext = bytearray()
        counter = 0

        for i in range(0, len(ct_bytes), STORY.BLOCK_SIZE):
            block = ct_bytes[i : i + STORY.BLOCK_SIZE]
            keystream = STORY._encrypt_block(
                STORY._make_counter_block(nc_bytes, counter),
                perm,
                sbox,
                round_keys,
                final_key,
            )
            plaintext.extend(b ^ k for b, k in zip(block, keystream))
            counter += 1

        return bytes(plaintext)

    @staticmethod
    def decrypt_str(
        ciphertext: Union[str, bytes],
        story: str,
        nonce: Union[str, bytes],
        tag: Union[str, bytes],
        round_salt: Union[str, bytes],
        encoding: str = "utf-16-le",
    ) -> str:
        """Decrypt and decode to string. Default encoding is UTF-16-LE."""
        return STORY.decrypt(ciphertext, story, nonce, tag, round_salt).decode(encoding)
