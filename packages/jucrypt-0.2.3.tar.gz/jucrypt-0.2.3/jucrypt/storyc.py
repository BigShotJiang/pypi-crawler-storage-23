import os
import hashlib
import hmac
from typing import Tuple, List, Union
import argparse 

from .story import STORY, _GF, _MIX_M

# ~12MB/s with C boost

try:
    import story_core as _core

    _gf_flat = bytes(_GF[a][b] for a in range(256) for b in range(256))
    _mds_flat = bytes(_MIX_M[i][j] for i in range(16) for j in range(16))
    _core.story_build_tables(_gf_flat, _mds_flat)
    _C_AVAILABLE = True

except ImportError:
    _C_AVAILABLE = False


def _rk_flat(round_keys: List[bytes]) -> bytes:
    return b"".join(round_keys)


class STORYC(STORY):
    C_AVAILABLE: bool = _C_AVAILABLE

    @staticmethod
    def _encrypt_block(
        block: bytes,
        perm: List[int],
        sbox: List[int],
        round_keys: List[bytes],
        final_key: bytes,
    ) -> bytes:
        if not _C_AVAILABLE:
            return STORY._encrypt_block(block, perm, sbox, round_keys, final_key)

        return _core.story_encrypt_block(
            block,
            bytes(perm),
            bytes(sbox),
            _rk_flat(round_keys),
            final_key,
        )

    @staticmethod
    def encrypt(plaintext, story: str) -> Tuple[bytes, bytes, bytes, bytes]:
        pt_bytes = STORYC._to_bytes(plaintext)
        story_bytes = story.encode("utf-16-le")

        enc_key, mac_key = STORYC._derive_master_key(story_bytes)
        sbox = STORYC._derive_sbox(enc_key)
        perm = STORYC._derive_perm(enc_key)
        base_rounds = STORYC._derive_round_count(enc_key)
        round_salt = os.urandom(1)
        salt_offset = round_salt[0] % 4
        actual_rounds = base_rounds + salt_offset
        round_keys = STORYC._expand_round_keys(enc_key, actual_rounds)
        final_key = STORYC._derive_whitening_key(enc_key)
        nonce = os.urandom(8)

        if _C_AVAILABLE:
            ciphertext = _core.story_ctr_crypt(
                pt_bytes,
                nonce,
                bytes(perm),
                bytes(sbox),
                _rk_flat(round_keys),
                final_key,
            )
        else:
            buf = bytearray()
            counter = 0
            for i in range(0, len(pt_bytes), STORYC.BLOCK_SIZE):
                block = pt_bytes[i : i + STORYC.BLOCK_SIZE]
                keystream = STORY._encrypt_block(
                    STORYC._make_counter_block(nonce, counter),
                    perm,
                    sbox,
                    round_keys,
                    final_key,
                )
                buf.extend(b ^ k for b, k in zip(block, keystream))
                counter += 1
            ciphertext = bytes(buf)

        tag = hmac.new(
            mac_key,
            nonce + round_salt + ciphertext,
            hashlib.sha256,
        ).digest()

        return ciphertext, nonce, tag, round_salt

    @staticmethod
    def decrypt(
        ciphertext: Union[str, bytes],
        story: str,
        nonce: Union[str, bytes],
        tag: Union[str, bytes],
        round_salt: Union[str, bytes],
    ) -> bytes:
        ct_bytes = STORYC._to_bytes_param(ciphertext, "ciphertext")
        nc_bytes = STORYC._to_bytes_param(nonce, "nonce")
        tag_bytes = STORYC._to_bytes_param(tag, "tag")
        rs_bytes = STORYC._to_bytes_param(round_salt, "round_salt")

        story_bytes = story.encode("utf-16-le")
        enc_key, mac_key = STORYC._derive_master_key(story_bytes)
        sbox = STORYC._derive_sbox(enc_key)
        perm = STORYC._derive_perm(enc_key)
        base_rounds = STORYC._derive_round_count(enc_key)
        salt_offset = rs_bytes[0] % 4
        actual_rounds = base_rounds + salt_offset
        round_keys = STORYC._expand_round_keys(enc_key, actual_rounds)
        final_key = STORYC._derive_whitening_key(enc_key)

        check = hmac.new(
            mac_key,
            nc_bytes + rs_bytes + ct_bytes,
            hashlib.sha256,
        ).digest()
        if not hmac.compare_digest(check, tag_bytes):
            raise ValueError(
                "Authentication Failed.\n"
                "The ciphertext, nonce, tag, or round_salt has been tampered with,\n"
                "or the story key is incorrect."
            )

        if _C_AVAILABLE:
            plaintext = _core.story_ctr_crypt(
                ct_bytes,
                nc_bytes,
                bytes(perm),
                bytes(sbox),
                _rk_flat(round_keys),
                final_key,
            )
        else:
            buf = bytearray()
            counter = 0
            for i in range(0, len(ct_bytes), STORYC.BLOCK_SIZE):
                block = ct_bytes[i : i + STORYC.BLOCK_SIZE]
                keystream = STORY._encrypt_block(
                    STORYC._make_counter_block(nc_bytes, counter),
                    perm,
                    sbox,
                    round_keys,
                    final_key,
                )
                buf.extend(b ^ k for b, k in zip(block, keystream))
                counter += 1
            plaintext = bytes(buf)

        return plaintext

    @staticmethod
    def decrypt_str(
        ciphertext: Union[str, bytes],
        story: str,
        nonce: Union[str, bytes],
        tag: Union[str, bytes],
        round_salt: Union[str, bytes],
        encoding: str = "utf-16-le",
    ) -> str:
        return STORYC.decrypt(ciphertext, story, nonce, tag, round_salt).decode(
            encoding
        )

    @staticmethod
    def decrypt_int(
        ciphertext: Union[str, bytes],
        story: str,
        nonce: Union[str, bytes],
        tag: Union[str, bytes],
        round_salt: Union[str, bytes],
    ) -> int:
        return int.from_bytes(
            STORYC.decrypt(ciphertext, story, nonce, tag, round_salt), "big"
        )

"""Coming Soon, Still under Development"""
if __name__ == "__main__":
    julogo = r"""
           __      ______                 __ 
          / /_  __/ ____/______  ______  / /_
     __  / / / / / /   / ___/ / / / __ \/ __/
    / /_/ / /_/ / /___/ /  / /_/ / /_/ / /_
    \____/\__,_/\____/_/   \__, / .___/\__/
                          /____/_/
    """
    ap = argparse.ArgumentParser(
        description= julogo + "STORY v0.3.x",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python storyc.py --enc [text] [A beautiful story]
  python storyc.py --dec [ciphertext] [rounds_salt] [A beautiful story]
        """,
    )
    ap.add_argument("--enc", action="store_true")
    ap.add_argument("--dec", action="store_true")
    ap.add_argument("--pt")
    ap.add_argument("--story")
    ap.add_argument("--round")
    args = ap.parse_args()