#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdint.h>
#include <string.h>

static uint8_t GF[256][256];          /* GF(2^8) multiplication           */
static uint8_t MDS[16][16];           /* 16x16 Cauchy MDS matrix           */
static uint8_t MDS_FLAT[16][16][256]; /* MDS_FLAT[i][j][v] = GF[MDS[i][j]][v] */
static int     tables_ready = 0;

static PyObject *
story_build_tables(PyObject *self, PyObject *args)
{
    const uint8_t *gf_buf;
    const uint8_t *mds_buf;
    Py_ssize_t     gf_len, mds_len;

    if (!PyArg_ParseTuple(args, "y#y#", &gf_buf, &gf_len, &mds_buf, &mds_len))
        return NULL;

    if (gf_len != 65536) {
        PyErr_SetString(PyExc_ValueError, "gf_flat must be 65536 bytes");
        return NULL;
    }
    if (mds_len != 256) {
        PyErr_SetString(PyExc_ValueError, "mds_flat must be 256 bytes");
        return NULL;
    }

    for (int a = 0; a < 256; a++)
        for (int b = 0; b < 256; b++)
            GF[a][b] = gf_buf[a * 256 + b];

    for (int i = 0; i < 16; i++)
        for (int j = 0; j < 16; j++)
            MDS[i][j] = mds_buf[i * 16 + j];

    for (int i = 0; i < 16; i++)
        for (int j = 0; j < 16; j++)
            for (int v = 0; v < 256; v++)
                MDS_FLAT[i][j][v] = GF[ MDS[i][j] ][v];

    tables_ready = 1;
    Py_RETURN_NONE;
}

static inline void
ark_c(uint8_t state[16], const uint8_t rk[16])
{
    for (int i = 0; i < 16; i++)
        state[i] ^= rk[i];
}

static inline void
sub_bytes_c(uint8_t state[16], const uint8_t sbox[256])
{
    for (int i = 0; i < 16; i++)
        state[i] = sbox[state[i]];
}

static inline void
permute_c(uint8_t state[16], const uint8_t perm[16])
{
    uint8_t tmp[16];
    for (int i = 0; i < 16; i++)
        tmp[i] = state[perm[i]];
    memcpy(state, tmp, 16);
}

static inline void
mix_c(uint8_t state[16])
{
    uint8_t result[16];
    for (int i = 0; i < 16; i++) {
        uint8_t acc = 0;
        for (int j = 0; j < 16; j++)
            acc ^= MDS_FLAT[i][j][state[j]];
        result[i] = acc;
    }
    memcpy(state, result, 16);
}

static inline void
encrypt_block_c(const uint8_t  block[16],
                const uint8_t  perm[16],
                const uint8_t  sbox[256],
                const uint8_t *round_keys, 
                int            n_rounds,
                const uint8_t  final_key[16],
                uint8_t        out[16])
{
    uint8_t state[16];
    memcpy(state, block, 16);

    for (int r = 0; r < n_rounds; r++) {
        const uint8_t *rk = round_keys + r * 16;
        ark_c(state, rk);
        sub_bytes_c(state, sbox);
        permute_c(state, perm);
        mix_c(state);
    }
    ark_c(state, final_key);
    memcpy(out, state, 16);
}

static PyObject *
story_encrypt_block(PyObject *self, PyObject *args)
{
    const uint8_t *block, *perm, *sbox, *rk_flat, *fk;
    Py_ssize_t     block_len, perm_len, sbox_len, rk_len, fk_len;

    if (!PyArg_ParseTuple(args, "y#y#y#y#y#",
                          &block,  &block_len,
                          &perm,   &perm_len,
                          &sbox,   &sbox_len,
                          &rk_flat, &rk_len,
                          &fk,     &fk_len))
        return NULL;

    if (!tables_ready) {
        PyErr_SetString(PyExc_RuntimeError,
                        "story_core: tables not initialised — call story_build_tables() first");
        return NULL;
    }
    if (block_len != 16 || perm_len != 16 || sbox_len != 256 ||
        rk_len % 16 != 0 || fk_len != 16) {
        PyErr_SetString(PyExc_ValueError,
                        "story_encrypt_block: wrong buffer sizes");
        return NULL;
    }

    int n_rounds = (int)(rk_len / 16);
    uint8_t out[16];
    encrypt_block_c(block, perm, sbox, rk_flat, n_rounds, fk, out);

    return PyBytes_FromStringAndSize((const char *)out, 16);
}

static PyObject *
story_ctr_crypt(PyObject *self, PyObject *args)
{
    const uint8_t *data, *nonce, *perm, *sbox, *rk_flat, *fk;
    Py_ssize_t     data_len, nonce_len, perm_len, sbox_len, rk_len, fk_len;
    long long      start_ctr = 0;

    if (!PyArg_ParseTuple(args, "y#y#y#y#y#y#|L",
                          &data,    &data_len,
                          &nonce,   &nonce_len,
                          &perm,    &perm_len,
                          &sbox,    &sbox_len,
                          &rk_flat, &rk_len,
                          &fk,      &fk_len,
                          &start_ctr))
        return NULL;

    if (!tables_ready) {
        PyErr_SetString(PyExc_RuntimeError,
                        "story_core: tables not initialised — call story_build_tables() first");
        return NULL;
    }
    if (nonce_len != 8 || perm_len != 16 || sbox_len != 256 ||
        rk_len % 16 != 0 || fk_len != 16) {
        PyErr_SetString(PyExc_ValueError,
                        "story_ctr_crypt: wrong buffer sizes");
        return NULL;
    }

    int n_rounds = (int)(rk_len / 16);

    PyObject *result = PyBytes_FromStringAndSize(NULL, data_len);
    if (!result)
        return NULL;
    uint8_t *out = (uint8_t *)PyBytes_AS_STRING(result);

    uint8_t counter_block[16];
    uint8_t keystream[16];
    uint64_t ctr = (uint64_t)start_ctr;

    Py_ssize_t offset = 0;
    while (offset < data_len) {
        memcpy(counter_block, nonce, 8);
        counter_block[8]  = (uint8_t)(ctr >> 56);
        counter_block[9]  = (uint8_t)(ctr >> 48);
        counter_block[10] = (uint8_t)(ctr >> 40);
        counter_block[11] = (uint8_t)(ctr >> 32);
        counter_block[12] = (uint8_t)(ctr >> 24);
        counter_block[13] = (uint8_t)(ctr >> 16);
        counter_block[14] = (uint8_t)(ctr >>  8);
        counter_block[15] = (uint8_t)(ctr      );
        ctr++;

        encrypt_block_c(counter_block, perm, sbox, rk_flat,
                        n_rounds, fk, keystream);

        Py_ssize_t chunk = data_len - offset;
        if (chunk > 16) chunk = 16;
        for (Py_ssize_t k = 0; k < chunk; k++)
            out[offset + k] = data[offset + k] ^ keystream[k];
        offset += chunk;
    }

    return result;
}

static PyMethodDef StoryCoreMethods[] = {
    {"story_build_tables",  story_build_tables,  METH_VARARGS,
     "Initialise GF and MDS tables from Python-side data."},
    {"story_encrypt_block", story_encrypt_block, METH_VARARGS,
     "Encrypt one 16-byte block. Returns bytes[16]."},
    {"story_ctr_crypt",     story_ctr_crypt,     METH_VARARGS,
     "CTR-mode XOR for arbitrary-length data. Returns bytes."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef storycoremodule = {
    PyModuleDef_HEAD_INIT,
    "story_core",
    "STORY cipher C acceleration layer",
    -1,
    StoryCoreMethods
};

PyMODINIT_FUNC
PyInit_story_core(void)
{
    return PyModule_Create(&storycoremodule);
}