from setuptools import setup, Extension

setup(
    ext_modules=[
        Extension(
            name="story_core",
            sources=["./jucrypt/story_core.c"],
            extra_compile_args=["-O3", "-march=native", "-Wall"],
        )
    ]
)
