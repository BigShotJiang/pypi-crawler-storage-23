"""
Test package for Anafibre.
"""