# Installation

## Install package

```bash
pip install anafibre
```

Optional extras:

```bash
pip install "anafibre[units]"
pip install "anafibre[refractiveindex]"
pip install "anafibre[all]"
```

<!-- ## Install docs tooling (for contributors)

From the repository root:

```bash
pip install -r docs/requirements.txt
pip install -e .[all]
```

## Build docs locally

```bash
zensical serve
```

Then open `http://127.0.0.1:8000`. -->
