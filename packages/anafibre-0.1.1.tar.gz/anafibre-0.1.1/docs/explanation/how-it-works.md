# How This Stack Works

## 1. Zensical (site engine + theme)

Zensical is the successor stack from the Material maintainers. It can read your `mkdocs.yml`, so your project structure and most settings still work.

When you run:

```bash
zensical serve
```

Zensical reads markdown files from `docs/`, renders HTML, and serves a local preview.

## 2. Theme compatibility mode

In `mkdocs.yml`, this setting keeps the traditional Material-like visual style:

```yaml
theme:
  variant: classic
```

`classic` mirrors the old Material look, while still using Zensical underneath.

## 3. mkdocstrings (API autogeneration)

In each API page, blocks like this:

```md
::: anafibre.fibre
```

tell `mkdocstrings` to import that module and render API docs from docstrings and signatures.

Important setting for your src-layout package:

```yaml
plugins:
  - mkdocstrings:
      handlers:
        python:
          paths: [src]
```

Without `paths: [src]`, module imports may fail during docs build.

## 4. Read the Docs (hosting + CI build)

`.readthedocs.yaml` runs a Zensical-native build flow:
- install docs dependencies from `docs/requirements.txt`
- install your package (`.[all]`) so API imports resolve
- run `zensical build`
- copy `site/` output into `$READTHEDOCS_OUTPUT/html/`

After you connect the GitHub repo in Read the Docs, each push triggers a docs build and publishes to your RTD URL.

## 5. Typical workflow

1. Improve Python docstrings in `src/anafibre/*.py`.
2. Run `zensical serve` and preview changes.
3. Commit and push.
4. RTD rebuilds and deploys automatically.

## 6. Common failure modes

- Import errors in docs build:
  - usually missing package install step or missing `paths: [src]`.
- Empty/poor API pages:
  - docstrings are missing or too sparse.
- Notebook-heavy examples breaking build:
  - keep docs pages lightweight and link to notebooks instead of executing them in RTD.
