# API Reference

API pages below are generated automatically from source docstrings via `mkdocstrings`.

- Package root: `anafibre`
- Modules: `fibre`, `fields`, `dispersion`, `plotting`, `utils`
