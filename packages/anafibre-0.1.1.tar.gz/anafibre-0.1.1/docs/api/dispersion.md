# anafibre.dispersion

::: anafibre.dispersion
