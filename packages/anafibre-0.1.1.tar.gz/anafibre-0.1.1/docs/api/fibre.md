# anafibre.fibre

## RefractiveIndexMaterial

::: anafibre.fibre.RefractiveIndexMaterial
    options:
      members:
        - __init__
        - get_refractive_index
        - get_extinction_coefficient
        - get_eps
      inherited_members: false

## StepIndexFibre

### Construction

::: anafibre.fibre.StepIndexFibre
    options:
      members:
        - __init__
      inherited_members: false

### Material And Profile

::: anafibre.fibre.StepIndexFibre
    options:
      show_root_heading: false
      members:
        - n_core
        - n_clad
        - eps
        - mu
        - n
      inherited_members: false

### Dispersion And Propagation

::: anafibre.fibre.StepIndexFibre
    options:
      show_root_heading: false
      members:
        - V
        - wavelength_from_V
        - wavelength_from_V_legacy
        - F
        - b
        - neff
        - kz
      inherited_members: false

### Modal Diagnostics

::: anafibre.fibre.StepIndexFibre
    options:
      show_root_heading: false
      members:
        - nu_vs_V
        - sigma_vs_V
        - m_max
        - ell_max
        - list_modes_at
      inherited_members: false

### Mode Constructors

::: anafibre.fibre.StepIndexFibre
    options:
      show_root_heading: false
      members:
        - HE
        - EH
        - TE
        - TM
      inherited_members: false
