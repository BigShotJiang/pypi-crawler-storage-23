# anafibre.fields

## Module Functions

::: anafibre.fields
    options:
      members:
        - spin_to_cartesian
        - cartesian_to_cylindrical
        - cylindrical_to_cartesian
        - format_complex_auto
        - ModeNotFoundError
      inherited_members: false

## GuidedMode

### Construction And Cache

::: anafibre.fields.GuidedMode
    options:
      members:
        - __init__
        - clear_grid_cache
      inherited_members: false

### Material Accessors

::: anafibre.fields.GuidedMode
    options:
      show_root_heading: false
      members:
        - eps
        - mu
        - n
        - k
        - kap
        - sigma
      inherited_members: false

### Field Evaluation

::: anafibre.fields.GuidedMode
    options:
      show_root_heading: false
      members:
        - E
        - H
        - gradE
        - gradH
        - Power
      inherited_members: false

### Labelling

::: anafibre.fields.GuidedMode
    options:
      show_root_heading: false
      members:
        - mode_label
      inherited_members: false
