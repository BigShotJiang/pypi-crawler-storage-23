# anafibre Documentation

Anafibre is an analytical mode solver for cylindrical step-index fibres.

This documentation is built with:
- `Zensical` as the static site generator and theme stack
- `mkdocstrings` for API docs generated from your Python docstrings

\[
    \vc{F}_{\ell m}(t,\vc{r})=\ee^{-\ii \omega t}\sum_{s=-1}^1 F_{\ell m}^{(s)}(\rho)\,\uv{e}_{s}\;\ee^{\ii (\ell-s)\varphi}\ee^{\ii k_z z}
    \,,
\]

## Quick links

- Start here: [Installation](getting-started/installation.md)
- Minimal usage: [Quickstart](getting-started/quickstart.md)
- Full API: [API Reference](api/index.md)
- Conceptual overview: [How this stack works](explanation/how-it-works.md)
