Contributing to Anafibre
========================

Thank you for your interest in contributing to Anafibre! Contributions are welcome! Please feel free to submit a Pull Request. For major changes, please open an issue first to discuss the changes you would like to make.

Getting Started
---------------

1. Fork the repository on GitHub
2. Clone your fork locally:

    .. code-block:: bash

        git clone https://github.com/yourusername/anafibre.git
        cd anafibre

3. Create a virtual environment and install development dependencies:

    .. code-block:: bash

        pip install -e .

Development Process
-------------------

1. Create a feature branch:

    .. code-block:: bash

        git checkout -b feature/your-feature-name

2. Make your changes and add tests
3. Run tests locally:

    .. code-block:: bash

        pytest

4. Commit with clear messages:

    .. code-block:: bash

        git commit -m "Add descriptive message"

5. Push to your fork and submit a Pull Request

License
-------

By contributing, you agree that your contributions will be licensed under the same license as the project.

Questions?
----------

Feel free to open an issue for questions or suggestions.