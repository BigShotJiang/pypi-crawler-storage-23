import os
import shutil
import subprocess
import sys

from g6_cli.g6_core import (
    detect_device
)
from g6_cli.g6_spec import AudioFeature, PlaybackFilter, SmartVolumeSpecialHex, Channel, BOTH_CHANNELS
from g6_cli.g6_spec.decoder import DecoderMode
from g6_cli.g6_spec.decoder import decoder_mode as decoder_mode_spec
from g6_cli.g6_spec.lighting import (
    lighting_disable as lighting_disable_spec,
    lighting_enable_set_rgb as lighting_enable_set_rgb_spec,
)
from g6_cli.g6_spec.mixer import (
    monitoring_external_mic_mute as monitoring_external_mic_mute_spec,
    monitoring_external_mic_volume as monitoring_external_mic_volume_spec,
    monitoring_line_in_mute as monitoring_line_in_mute_spec,
    monitoring_line_in_volume as monitoring_line_in_volume_spec,
    monitoring_spdif_in_mute as monitoring_spdif_in_mute_spec,
    monitoring_spdif_in_volume as monitoring_spdif_in_volume_spec,
    playback_mute as mixer_playback_mute_spec,
    recording_external_mic_mute as recording_external_mic_mute_spec,
    recording_external_mic_volume as recording_external_mic_volume_spec,
    recording_line_in_mute as recording_line_in_mute_spec,
    recording_line_in_volume as recording_line_in_volume_spec,
    recording_spdif_in_mute as recording_spdif_in_mute_spec,
    recording_spdif_in_volume as recording_spdif_in_volume_spec,
    recording_what_u_hear_mute as recording_what_u_hear_mute_spec,
    recording_what_u_hear_volume as recording_what_u_hear_volume_spec,
)
from g6_cli.g6_spec.playback import (
    enable_direct_mode as enable_direct_mode_spec,
    enable_spdif_out_direct_mode as enable_spdif_out_direct_mode_spec,
    headphones_to_5_1 as headphones_to_5_1_spec,
    headphones_to_7_1 as headphones_to_7_1_spec,
    headphones_to_stereo as headphones_to_stereo_spec,
    playback_filter as playback_filter_spec,
    playback_mute as playback_mute_spec,
    playback_volume as playback_volume_spec,
    speakers_to_5_1 as speakers_to_5_1_spec,
    speakers_to_7_1 as speakers_to_7_1_spec,
    speakers_to_stereo as speakers_to_stereo_spec,
    toggle_to_headphones as toggle_to_headphones_spec,
    toggle_to_speakers as toggle_to_speakers_spec,
)
from g6_cli.g6_spec.recording import MicrophoneEqualizerPreset
from g6_cli.g6_spec.recording import (
    voice_clarity_acoustic_echo_cancellation_enabled as voice_clarity_acoustic_echo_cancellation_enabled_spec,
    mic_boost as mic_boost_spec,
    voice_clarity_mic_equalizer_enabled as voice_clarity_mic_equalizer_enabled_spec,
    voice_clarity_mic_equalizer_preset as voice_clarity_mic_equalizer_preset_spec,
    mic_monitoring_mute as mic_monitoring_mute_spec,
    mic_monitoring_volume as mic_monitoring_volume_spec,
    mic_recording_volume as mic_recording_volume_spec,
    recording_mute as recording_mute_spec,
    voice_clarity_smart_volume_enabled as voice_clarity_smart_volume_enabled_spec,
    voice_clarity_enabled as voice_clarity_enabled_spec,
    voice_clarity_noise_reduction_level as voice_clarity_noise_reduction_level_spec,
)
from g6_cli.g6_spec.sbx import (
    sbx_slider as sbx_slider_spec,
    sbx_smart_volume_special as sbx_smart_volume_special_spec,
    sbx_toggle as sbx_toggle_spec,
)


class G6Api:
    def __init__(self, dry_run: bool, debug: bool):
        self.__dry_run = dry_run
        self.__device = detect_device(dry_run=dry_run, debug=debug)

    # --- Claim and Release Audio Interface ---

    def claim_audio_interface(self) -> None:
        self.__device.claim_audio_interface()

    def release_audio_interface(self) -> None:
        self.__device.release_audio_interface()

    def reload_alsa_and_pipewire(self, sudo: bool = True) -> None:
        """
        Reload ALSA (usually root) and restart user PipeWire services.

        Note: For running sudo without a password, you need to configure /etc/sudoers.d/soundblaster-x-g6-cli:
        ```
        # sound-blaster-x-g6-cli
        <username> ALL=(ALL:ALL) NOPASSWD: /usr/sbin/alsa force-reload
        ```
        """

        def reload_alsa():
            alsa_cmd = ["/usr/sbin/alsa", "force-reload"]
            if sudo:
                sudo_path = shutil.which("sudo")
                if not sudo_path:
                    raise RuntimeError("sudo not found; run as root or install/configure sudo.")
                alsa_cmd = [sudo_path, "--non-interactive", *alsa_cmd]

            completed_process = subprocess.run(alsa_cmd,
                                               capture_output=True,
                                               encoding='utf-8',
                                               check=False)  # check=False: some module may fail. Continue anyway ...
            sys.stdout.write(completed_process.stdout)
            sys.stderr.write(completed_process.stderr)

        def reload_pipewire():
            systemctl = shutil.which("systemctl")
            if not systemctl:
                raise RuntimeError("systemctl not found.")

            user_env = dict(os.environ)
            user_env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")

            completed_process = subprocess.run(
                [systemctl, "--user", "restart", "pipewire", "pipewire-pulse", "wireplumber"],
                capture_output=True,
                encoding='utf-8',
                check=True,
                env=user_env,
            )
            sys.stdout.write(completed_process.stdout)
            sys.stderr.write(completed_process.stderr)

        # check for dryrun mode
        if self.__dry_run:
            print("This is a dry run. ALSA and PipeWire will not be reloaded.")
            return

        # --- ALSA reload (root) ---
        reload_alsa()

        # --- Restart PipeWire (user services) ---
        reload_pipewire()

    def is_hid_interface_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def is_audio_interface_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    # --- Playback ---

    def playback_mute(self, mute: bool) -> None:
        audio_data_list = playback_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(
            audio_data_list=audio_data_list,
        )

    def playback_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_toggle_to_speakers(self) -> None:
        hid_data_list = toggle_to_speakers_spec()
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def playback_toggle_to_speakers_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def playback_toggle_to_headphones(self) -> None:
        hid_data_list = toggle_to_headphones_spec()
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def playback_toggle_to_headphones_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def playback_speakers_to_stereo(self) -> None:
        audio_data_list = speakers_to_stereo_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_speakers_to_stereo_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_speakers_to_5_1(self) -> None:
        audio_data_list = speakers_to_5_1_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_speakers_to_5_1_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_speakers_to_7_1(self) -> None:
        audio_data_list = speakers_to_7_1_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_speakers_to_7_1_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_headphones_to_stereo(self) -> None:
        audio_data_list = headphones_to_stereo_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_headphones_to_stereo_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_headphones_to_5_1(self) -> None:
        audio_data_list = headphones_to_5_1_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_headphones_to_5_1_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_headphones_to_7_1(self) -> None:
        audio_data_list = headphones_to_7_1_spec()
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_headphones_to_7_1_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = playback_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def playback_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def playback_enable_direct_mode(self, enable: bool) -> None:
        hid_data_list = enable_direct_mode_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def playback_enable_direct_mode_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def playback_enable_spdif_out_direct_mode(self, enable: bool) -> None:
        hid_data_list = enable_spdif_out_direct_mode_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def playback_enable_spdif_out_direct_mode_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def playback_filter(self, playback_filter_enum: PlaybackFilter) -> None:
        hid_data_list = playback_filter_spec(playback_filter_enum=playback_filter_enum)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def playback_filter_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    # --- Decoder ---

    def decoder_mode(self, decoder_mode_enum: DecoderMode) -> None:
        hid_data_list = decoder_mode_spec(decoder_mode_enum=decoder_mode_enum)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def decoder_mode_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    # --- Lighting ---

    def lighting_disable(self) -> None:
        hid_data_list = lighting_disable_spec()
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def lighting_disable_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def lighting_enable_set_rgb(self, red: int, green: int, blue: int) -> None:
        hid_data_list = lighting_enable_set_rgb_spec(red=red, green=green, blue=blue)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def lighting_enable_set_rgb_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    # --- Mixer ---

    def mixer_playback_mute(self, mute: bool) -> None:
        audio_data_list = mixer_playback_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_playback_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_line_in_mute(self, mute: bool) -> None:
        audio_data_list = monitoring_line_in_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_line_in_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_line_in_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = monitoring_line_in_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_line_in_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_external_mic_mute(self, mute: bool) -> None:
        audio_data_list = monitoring_external_mic_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_external_mic_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_external_mic_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = monitoring_external_mic_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_external_mic_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_spdif_in_mute(self, mute: bool) -> None:
        audio_data_list = monitoring_spdif_in_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_spdif_in_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_monitoring_spdif_in_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = monitoring_spdif_in_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_monitoring_spdif_in_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_line_in_mute(self, mute: bool) -> None:
        audio_data_list = recording_line_in_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_line_in_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_line_in_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = recording_line_in_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_line_in_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_external_mic_mute(self, mute: bool) -> None:
        audio_data_list = recording_external_mic_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_external_mic_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_external_mic_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = recording_external_mic_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_external_mic_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_spdif_in_mute(self, mute: bool) -> None:
        audio_data_list = recording_spdif_in_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_spdif_in_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_spdif_in_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = recording_spdif_in_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_spdif_in_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_what_u_hear_mute(self, mute: bool) -> None:
        audio_data_list = recording_what_u_hear_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_what_u_hear_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def mixer_recording_what_u_hear_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = recording_what_u_hear_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def mixer_recording_what_u_hear_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    # --- Recording ---

    def recording_mute(self, mute: bool) -> None:
        audio_data_list = recording_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def recording_mute_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def recording_mic_recording_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = mic_recording_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def recording_mic_recording_volume_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def recording_mic_boost(self, decibel: int) -> None:
        hid_data_list = mic_boost_spec(decibel=decibel)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_mic_boost_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_mic_monitoring_mute(self, mute: bool) -> None:
        audio_data_list = mic_monitoring_mute_spec(mute=mute)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def recording_mic_monitoring_volume(self, volume_percent: int, channels: set[Channel] = BOTH_CHANNELS) -> None:
        audio_data_list = mic_monitoring_volume_spec(volume_percent=volume_percent, channels=channels)
        self.__device.send_audio_data_to_device(audio_data_list=audio_data_list)

    def recording_mic_monitoring_available(self) -> bool:
        return self.__device.is_audio_interface_available()

    def recording_voice_clarity_enabled(self, enable: bool) -> None:
        hid_data_list = voice_clarity_enabled_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_enabled_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_voice_clarity_noise_reduction_level(self, level_percent: int) -> None:
        hid_data_list = voice_clarity_noise_reduction_level_spec(level_percent=level_percent)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_noise_reduction_level_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_voice_clarity_acoustic_echo_cancellation_enabled(self, enable: bool) -> None:
        hid_data_list = voice_clarity_acoustic_echo_cancellation_enabled_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_acoustic_echo_cancellation_enabled_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_voice_clarity_smart_volume_enabled(self, enable: bool) -> None:
        hid_data_list = voice_clarity_smart_volume_enabled_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_smart_volume_enabled_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_voice_clarity_mic_equalizer_enabled(self, enable: bool) -> None:
        hid_data_list = voice_clarity_mic_equalizer_enabled_spec(enable=enable)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_mic_equalizer_enabled_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def recording_voice_clarity_mic_equalizer_preset(self, preset: MicrophoneEqualizerPreset) -> None:
        hid_data_list = voice_clarity_mic_equalizer_preset_spec(preset=preset)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def recording_voice_clarity_mic_equalizer_preset_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    # --- SBX ---

    def sbx_toggle(self, audio_feature: AudioFeature, activate: bool) -> None:
        hid_data_list = sbx_toggle_spec(audio_feature=audio_feature, activate=activate)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def sbx_toggle_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def sbx_slider(self, audio_feature: AudioFeature, value: int) -> None:
        hid_data_list = sbx_slider_spec(audio_feature=audio_feature, value=value)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def sbx_slider_available(self) -> bool:
        return self.__device.is_hid_interface_available()

    def sbx_smart_volume_special(self, smart_volume_special_hex: SmartVolumeSpecialHex) -> None:
        hid_data_list = sbx_smart_volume_special_spec(smart_volume_special_hex=smart_volume_special_hex)
        self.__device.send_hid_data_to_device(hid_data_list=hid_data_list)

    def sbx_smart_volume_special_available(self) -> bool:
        return self.__device.is_hid_interface_available()
