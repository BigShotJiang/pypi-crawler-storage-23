#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.0.17'
BUILD = '2357841450'
NAME = 'ix-notifiers'
