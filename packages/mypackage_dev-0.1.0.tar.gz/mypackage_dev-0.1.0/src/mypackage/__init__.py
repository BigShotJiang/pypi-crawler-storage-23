"""
MyPackage - A sample Python package with semantic versioning.

This package demonstrates best practices for creating and publishing
Python packages to PyPI with support for multiple environments.
"""

__version__ = "0.1.0"

from .calculator import add, subtract, multiply, divide
from .text_utils import capitalize_words, reverse_string, count_words
from .data_processor import filter_even, sum_list, get_statistics

__all__ = [
    "add",
    "subtract",
    "multiply",
    "divide",
    "capitalize_words",
    "reverse_string",
    "count_words",
    "filter_even",
    "sum_list",
    "get_statistics",
]
