"""Custom throttling classes.

This module contains DRF throttling classes for:
- Authentication endpoint protection
- Rate limiting for security-sensitive operations
- Enhanced endpoint-specific throttling

Throttle rates are configured via ``REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']``
in settings.  Test settings simply raise the rates to avoid test flakiness.
"""

from rest_framework.throttling import (
    AnonRateThrottle as DRFAnonRateThrottle,
)
from rest_framework.throttling import (
    UserRateThrottle as DRFUserRateThrottle,
)

# ---------------------------------------------------------------------------
# Base throttles
# ---------------------------------------------------------------------------


class UserRateThrottle(DRFUserRateThrottle):
    """Project-wide user throttle (scope: ``user``)."""

    scope = "user"


class AnonRateThrottle(DRFAnonRateThrottle):
    """Project-wide anonymous throttle (scope: ``anon``)."""

    scope = "anon"


# ---------------------------------------------------------------------------
# Domain-specific throttles
# ---------------------------------------------------------------------------


class AuthenticationRateThrottle(AnonRateThrottle):
    """
    Throttle for authentication endpoints (login, etc.)

    More restrictive than standard anonymous throttle to prevent
    brute force attacks.
    """

    scope = "auth"


class RegistrationRateThrottle(AnonRateThrottle):
    """
    Throttle for user registration.

    Prevents automated account creation while allowing
    legitimate users to register.
    """

    scope = "registration"


class PasswordResetRateThrottle(AnonRateThrottle):
    """
    Throttle for password reset requests.

    Prevents email enumeration and spam while allowing
    legitimate password reset requests.
    """

    scope = "password_reset"


class EmailVerificationRateThrottle(UserRateThrottle):
    """
    Throttle for email verification attempts.
    Uses user-based throttling to prevent abuse per account.
    """

    scope = "email_verification"


class LoginRateThrottle(AnonRateThrottle):
    """
    Specific throttle for login attempts.

    More restrictive than general auth throttle to prevent
    brute force attacks on login endpoint specifically.
    """

    scope = "login"


class TokenRefreshRateThrottle(AnonRateThrottle):
    """
    Throttle for JWT token refresh requests.

    Allows reasonable refresh frequency while preventing
    token refresh abuse.
    """

    scope = "token_refresh"


class EmailVerificationConfirmRateThrottle(AnonRateThrottle):
    """
    Throttle for email verification confirmation (via link).

    IP-based throttling for verification confirmations to prevent
    verification link abuse.
    """

    scope = "email_verification_confirm"


class PasswordResetConfirmRateThrottle(AnonRateThrottle):
    """
    Throttle for password reset confirmation.

    IP-based throttling for password reset confirmations.
    """

    scope = "password_reset_confirm"


class DeviceManagementRateThrottle(UserRateThrottle):
    """
    Throttle for device/session management operations.
    """

    scope = "device_management"


class ContentModerationRateThrottle(UserRateThrottle):
    """
    Throttle for content creation and moderation actions.
    """

    scope = "content_moderation"
