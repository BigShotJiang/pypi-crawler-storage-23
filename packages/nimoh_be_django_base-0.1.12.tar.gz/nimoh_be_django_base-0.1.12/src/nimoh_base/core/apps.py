"""Core app configuration."""

from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nimoh_base.core"
    label = "nimoh_core"
    verbose_name = "Nimoh Base: Core"

    def ready(self):
        """Validate NIMOH_BASE settings on startup."""
        from nimoh_base.conf import validate_nimoh_base_settings

        validate_nimoh_base_settings()
