"""
nimoh_base.conf.defaults
========================
Typed default values for the ``NIMOH_BASE`` dict.

Consumers can import and merge these so their settings files always stay
up-to-date with new keys added in future package versions::

    from nimoh_base.conf.defaults import NIMOH_BASE_DEFAULTS

    NIMOH_BASE = {
        **NIMOH_BASE_DEFAULTS,
        # Override with project-specific values:
        'SITE_NAME': 'My Application',
        'SUPPORT_EMAIL': 'support@myapp.com',
        'NOREPLY_EMAIL': 'noreply@myapp.com',
    }

Note: ``SITE_NAME``, ``SUPPORT_EMAIL``, and ``NOREPLY_EMAIL`` are **required**
— they have no meaningful default and will raise ``ImproperlyConfigured``
at startup if not set.  They are included here only as documentation markers.
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────────
# NIMOH_BASE key reference
#
# Each entry documents:
#   key          — The NIMOH_BASE dict key
#   type         — Expected Python type
#   required     — True if omitting the key raises ImproperlyConfigured
#   default      — Effective default when key is absent (required keys: None)
#   description  — What the setting controls in package code
# ─────────────────────────────────────────────────────────────────────────────

NIMOH_BASE_SCHEMA: list[dict] = [
    {
        "key": "SITE_NAME",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            "Human-readable application name. Used in all outbound emails "
            "(subject lines, greetings) and in error messages."
        ),
    },
    {
        "key": "SUPPORT_EMAIL",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            "Support contact email address embedded in password-reset, email verification, and GDPR data-export emails."
        ),
    },
    {
        "key": "NOREPLY_EMAIL",
        "type": str,
        "required": True,
        "default": None,
        "description": (
            'The "From" address for all system-generated outbound emails. '
            "Typically something like 'noreply@myapp.com'."
        ),
    },
    {
        "key": "SERVER_HEADER",
        "type": str,
        "required": False,
        "default": "",
        "description": (
            "Value for the HTTP ``Server`` response header set by "
            "``SecurityHeadersMiddleware``. An empty string suppresses the "
            "header entirely (recommended for production)."
        ),
    },
    {
        "key": "PASSWORD_CHECKER_USER_AGENT",
        "type": str,
        "required": False,
        "default": "Django-Password-Validator",
        "description": ("User-Agent string sent to the HaveIBeenPwned k-anonymity API during password breach checks."),
    },
    {
        "key": "CELERY_APP_NAME",
        "type": str,
        "required": False,
        "default": "django-app",
        "description": (
            "Celery application name string (the first arg to ``Celery(...)``). "
            "Used by ``nimoh_base.conf.celery.make_celery()``."
        ),
    },
    {
        "key": "CACHE_KEY_PREFIX",
        "type": str,
        "required": False,
        "default": "app",
        "description": (
            "Prefix applied to every Redis cache key so multiple projects "
            "can share a Redis instance without key collisions."
        ),
    },
    {
        "key": "MOBILE_APP_IDENTIFIERS",
        "type": list,  # list[str]
        "required": False,
        "default": [],
        "description": (
            "Additional User-Agent substrings recognised as mobile clients by "
            "``MobileDetectionMiddleware`` / ``is_mobile_request()``.  The "
            "package always recognises ``react-native``, ``expo``, and "
            "``mobile-app`` regardless of this setting."
        ),
    },
    {
        "key": "ENABLE_MONITORING_PERSISTENCE",
        "type": bool,
        "required": False,
        "default": False,
        "description": (
            "When ``True``, ``PerformanceMonitoringMiddleware`` writes "
            "per-request metrics to the ``PerformanceMetric`` / "
            "``EndpointMetrics`` database tables.  Disable in high-traffic "
            "environments and rely on time-series exports instead."
        ),
    },
]

# ── Convenience: default values dict (required keys excluded) ─────────────────

NIMOH_BASE_DEFAULTS: dict[str, object] = {
    entry["key"]: entry["default"] for entry in NIMOH_BASE_SCHEMA if not entry["required"]
}
"""
Dict of all **optional** ``NIMOH_BASE`` keys with their default values.

Merge this into your project settings and then override as needed::

    from nimoh_base.conf.defaults import NIMOH_BASE_DEFAULTS

    NIMOH_BASE = {
        **NIMOH_BASE_DEFAULTS,
        'SITE_NAME': 'My App',
        'SUPPORT_EMAIL': 'support@myapp.com',
        'NOREPLY_EMAIL': 'noreply@myapp.com',
    }
"""

# ── Convenience: set of required key names ───────────────────────────────────

NIMOH_BASE_REQUIRED_KEYS: frozenset[str] = frozenset(entry["key"] for entry in NIMOH_BASE_SCHEMA if entry["required"])
"""Frozenset of keys that raise ``ImproperlyConfigured`` when missing."""
