"""
Token management views: JWT refresh and exchange functionality.

This module handles JWT token operations including token refresh
with rotation and exchange token flows for secure authentication.
"""

import logging

from django.conf import settings
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from drf_spectacular.utils import OpenApiResponse, extend_schema, inline_serializer
from rest_framework import serializers, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken

from nimoh_base.auth.utils.cookies import (
    get_refresh_token_from_request,
    set_refresh_token_cookie,
)
from nimoh_base.auth.utils.mobile import get_client_type
from nimoh_base.core.api_tags import APITags
from nimoh_base.core.exceptions import ProblemDetailException
from nimoh_base.core.throttling import (
    AnonRateThrottle,
    TokenRefreshRateThrottle,
)

from ..models import AuditLog, UserSession

User = get_user_model()
logger = logging.getLogger(__name__)


class RefreshTokenView(APIView):
    """
    Custom JWT refresh token view with httpOnly cookie support.

    Features:
    - Reads refresh token from httpOnly cookie
    - Token rotation (issues new refresh token)
    - Session validation
    - Security logging
    - Backward compatibility with body-based tokens
    """

    permission_classes = [AllowAny]
    throttle_classes = [TokenRefreshRateThrottle]

    @extend_schema(
        operation_id="auth_token_refresh",
        summary="Refresh Access Token",
        description="Refresh JWT access token using httpOnly cookie",
        request=None,  # No body needed (cookie-based)
        responses={
            200: OpenApiResponse(
                description="Token refreshed successfully",
                examples={"application/json": {"access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."}},
            ),
            401: OpenApiResponse(description="Invalid or expired refresh token"),
        },
        tags=[APITags.SESSION_MANAGEMENT],
    )
    def post(self, request, *args, **kwargs):
        """Refresh JWT token using httpOnly cookie."""
        try:
            # Get refresh token from cookie (with body fallback for backward compatibility)
            refresh_token_str = get_refresh_token_from_request(request)

            if not refresh_token_str:
                raise ProblemDetailException(
                    title="No Refresh Token",
                    detail=_("Refresh token not found in cookie or request body."),
                    status_code=status.HTTP_401_UNAUTHORIZED,
                )

            # Verify and decode refresh token
            try:
                refresh_token = RefreshToken(refresh_token_str)
            except TokenError as e:
                logger.warning("Invalid refresh token", extra={"error": str(e)})
                raise ProblemDetailException(
                    title="Invalid Refresh Token",
                    detail=_("The provided refresh token is invalid or expired."),
                    status_code=status.HTTP_401_UNAUTHORIZED,
                )

            # Get user from token
            user_id = refresh_token.get("user_id")
            if not user_id:
                raise ProblemDetailException(
                    title="Invalid Token Payload",
                    detail=_("Refresh token does not contain user information."),
                    status_code=status.HTTP_401_UNAUTHORIZED,
                )

            # Verify user still exists and is active
            try:
                user = User.objects.get(id=user_id)
                if not user.is_active:
                    raise ProblemDetailException(
                        title="Account Disabled",
                        detail=_("This account has been disabled."),
                        status_code=status.HTTP_403_FORBIDDEN,
                    )
            except User.DoesNotExist:
                raise ProblemDetailException(
                    title="User Not Found",
                    detail=_("User associated with this token no longer exists."),
                    status_code=status.HTTP_404_NOT_FOUND,
                )

            # Token rotation - blacklist old token and issue new one
            if getattr(settings, "SIMPLE_JWT", {}).get("ROTATE_REFRESH_TOKENS", False):
                # Blacklist the old refresh token
                try:
                    refresh_token.blacklist()
                except AttributeError:
                    # Token blacklist not enabled
                    pass

                # Generate new refresh token
                new_refresh = RefreshToken.for_user(user)
                new_access = new_refresh.access_token

                # Update session with new token JTI
                session = UserSession.objects.filter(
                    user=user, refresh_token_jti=str(refresh_token.get("jti")), is_active=True
                ).first()

                if session:
                    session.refresh_token_jti = str(new_refresh["jti"])
                    session.last_rotation_at = timezone.now()
                    session.save(update_fields=["refresh_token_jti", "last_rotation_at"])
            else:
                # No rotation - just issue new access token
                new_refresh = refresh_token
                new_access = refresh_token.access_token

            # Determine client type and refresh method
            client_type = get_client_type(request)
            came_from_header = request.headers.get("X-Refresh-Token") is not None

            # Log token refresh
            AuditLog.log_from_request(
                request,
                event_type="token_refresh",
                description="Access token refreshed successfully",
                user=user,
                metadata={
                    "client_type": client_type,
                    "refresh_method": "header" if came_from_header else "cookie",
                    "token_rotated": getattr(settings, "SIMPLE_JWT", {}).get("ROTATE_REFRESH_TOKENS", False),
                },
            )

            logger.info(
                f"Token refreshed successfully for {user.email} (client: {client_type}, rotated: {getattr(settings, 'SIMPLE_JWT', {}).get('ROTATE_REFRESH_TOKENS', False)})"
            )

            # Conditional response based on client type
            if came_from_header:
                # Mobile client: Return both access and refresh tokens in body
                response = Response({"access": str(new_access), "refresh": str(new_refresh)}, status=status.HTTP_200_OK)
            else:
                # Web client: Return access token in body, refresh token in cookie
                response = Response({"access": str(new_access)}, status=status.HTTP_200_OK)

                # Set new refresh token cookie if rotation is enabled
                if getattr(settings, "SIMPLE_JWT", {}).get("ROTATE_REFRESH_TOKENS", False):
                    response = set_refresh_token_cookie(response, str(new_refresh))

            return response

        except ProblemDetailException:
            raise
        except Exception as e:
            logger.error("Token refresh failed", exc_info=True, extra={"error": str(e)})
            raise ProblemDetailException(
                title="Token Refresh Failed",
                detail=_("An error occurred while refreshing the token."),
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class ExchangeTokenView(APIView):
    """
    Exchange a temporary verification token for JWT access/refresh tokens.

    This endpoint provides secure token exchange for email verification flows.
    Exchange tokens are short-lived, single-use tokens that prevent JWT tokens
    from appearing in URLs or browser history.

    Features:
    - Single-use exchange tokens
    - Automatic user session creation
    - Security audit logging
    - Device fingerprinting
    """

    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]

    @extend_schema(
        operation_id="exchange_token_for_jwt",
        summary="Exchange Token for JWT",
        description="Exchange a one-time verification token for JWT access/refresh tokens",
        request=inline_serializer(
            name="ExchangeTokenRequest",
            fields={
                "exchange_token": serializers.CharField(help_text="One-time exchange token from email verification"),
            },
        ),
        responses={
            200: OpenApiResponse(
                description="Token exchange successful",
                examples={
                    "application/json": {
                        "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                        "user_id": 123,
                        "email": "user@example.com",
                        "expires_in": 900,
                        "first_login": True,
                        "message": "Authentication successful.",
                    }
                },
            ),
            400: OpenApiResponse(
                description="Invalid or expired exchange token",
                examples={"application/json": {"error": "Invalid or expired exchange token"}},
            ),
            429: OpenApiResponse(description="Rate limit exceeded"),
        },
        tags=[APITags.SESSION_MANAGEMENT],
    )
    def post(self, request):
        """Exchange a temporary token for JWT access/refresh tokens."""
        exchange_token = request.data.get("exchange_token")

        if not exchange_token:
            raise ProblemDetailException(
                detail=_("Exchange token is required."),
                code="token_missing",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        try:
            # Import exchange token service
            from ..services import AuthenticationService, ExchangeTokenService

            # Extract request metadata for session creation
            request_metadata = AuthenticationService.extract_request_metadata(request)

            # Exchange token for JWT tokens
            token_data = ExchangeTokenService.exchange_for_jwt_tokens(
                exchange_token=exchange_token, request_meta=request_metadata
            )

            # Create HTTP response with refresh token cookie
            response = Response(
                {
                    "access_token": token_data["access_token"],
                    "user_id": token_data["user_id"],
                    "email": token_data["email"],
                    "expires_in": token_data["expires_in"],
                    "first_login": token_data["context"].get("first_login", False),
                    "message": _("Authentication successful."),
                },
                status=status.HTTP_200_OK,
            )

            # Set refresh token as httpOnly cookie (secure)
            response = set_refresh_token_cookie(response, token_data["refresh_token"])

            logger.info("Successful token exchange", extra={"user_id": token_data["user_id"]})

            return response

        except ValueError as e:
            # Log failed exchange attempt
            logger.warning("Failed token exchange attempt", extra={"error": str(e)})

            raise ProblemDetailException(
                detail=str(e),
                code="exchange_error",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        except Exception as e:
            # Log unexpected errors
            logger.error("Unexpected error in token exchange", extra={"error": str(e)})

            raise ProblemDetailException(
                detail=_("An unexpected error occurred. Please try again."),
                code="exchange_server_error",
            )


class TokenVerifyView(APIView):
    """
    Verify JWT access token validity.

    This endpoint verifies if a JWT access token is valid and returns
    information about the token and associated user. Useful for client-side
    token validation and debugging authentication issues.

    Features:
    - Token signature verification
    - Token expiration checking
    - User account status validation
    - Security audit logging
    """

    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]

    @extend_schema(
        operation_id="verify_jwt_token",
        summary="Verify JWT Token",
        description="Verify the validity of a JWT access token",
        request=inline_serializer(
            name="TokenVerifyRequest",
            fields={
                "token": serializers.CharField(help_text="JWT access token to verify"),
            },
        ),
        responses={
            200: OpenApiResponse(
                description="Token is valid",
                examples={
                    "application/json": {
                        "valid": True,
                        "user_id": 123,
                        "email": "user@example.com",
                        "expires_at": "2025-10-30T18:15:30Z",
                        "token_type": "access",
                        "message": "Token is valid",
                    }
                },
            ),
            400: OpenApiResponse(
                description="Invalid or expired token",
                examples={"application/json": {"valid": False, "error": "Token is invalid or expired"}},
            ),
            429: OpenApiResponse(description="Rate limit exceeded"),
        },
        tags=[APITags.AUTHENTICATION],
    )
    def post(self, request):
        """Verify JWT access token validity."""
        token_str = request.data.get("token")

        if not token_str:
            raise ProblemDetailException(
                detail=_("Token is required."),
                code="token_missing",
                status_code=status.HTTP_400_BAD_REQUEST,
                valid=False,
            )

        try:
            # Verify and decode access token
            try:
                access_token = AccessToken(token_str)
            except TokenError as e:
                logger.warning(f"Invalid access token verification attempt: {e}")
                raise ProblemDetailException(
                    detail=_("Token is invalid or expired"),
                    code="token_invalid",
                    status_code=status.HTTP_400_BAD_REQUEST,
                    valid=False,
                )

            # Get user from token
            user_id = access_token.get("user_id")
            if not user_id:
                raise ProblemDetailException(
                    detail=_("Token does not contain user information"),
                    code="token_no_user",
                    status_code=status.HTTP_400_BAD_REQUEST,
                    valid=False,
                )

            # Verify user still exists and is active
            try:
                user = User.objects.get(id=user_id)
                if not user.is_active:
                    logger.warning(f"Token verification for disabled user: {user.email}")
                    raise ProblemDetailException(
                        detail=_("User account is disabled"),
                        code="user_disabled",
                        status_code=status.HTTP_400_BAD_REQUEST,
                        valid=False,
                    )
            except User.DoesNotExist:
                logger.warning(f"Token verification for non-existent user ID: {user_id}")
                raise ProblemDetailException(
                    detail=_("User no longer exists"),
                    code="user_not_found",
                    status_code=status.HTTP_400_BAD_REQUEST,
                    valid=False,
                )

            # Log successful token verification
            AuditLog.log_from_request(
                request,
                event_type="security_event",
                description="Access token verified successfully",
                user=user,
                metadata={"token_type": "access", "expires_at": str(access_token.get("exp"))},
            )

            logger.info(f"Token verification successful for user: {user.email}")

            # Return token validity information
            return Response(
                {
                    "valid": True,
                    "user_id": user.id,
                    "email": user.email,
                    "expires_at": timezone.datetime.fromtimestamp(
                        access_token.get("exp"), tz=timezone.get_current_timezone()
                    ).isoformat(),
                    "token_type": "access",
                    "message": _("Token is valid"),
                },
                status=status.HTTP_200_OK,
            )

        except Exception as e:
            logger.error("Token verification failed", exc_info=True, extra={"error": str(e)})
            raise ProblemDetailException(
                detail=_("Token verification failed"),
                code="verification_error",
                valid=False,
            )
