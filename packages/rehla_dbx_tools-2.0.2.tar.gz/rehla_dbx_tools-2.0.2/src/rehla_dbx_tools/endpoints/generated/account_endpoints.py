"""Compatibility module for generated account endpoint constants."""

from databricks_api.endpoints.generated.account_endpoints import ACCOUNT_2_0_ENDPOINTS, ACCOUNT_PREVIEW_ENDPOINTS

__all__ = ["ACCOUNT_2_0_ENDPOINTS", "ACCOUNT_PREVIEW_ENDPOINTS"]
