Extension URI: `https://github.com/acislab/ichatbio-sdk/a2a/v1`

