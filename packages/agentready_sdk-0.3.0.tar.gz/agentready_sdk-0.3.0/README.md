# AgentReady — Python SDK

**Cut AI token costs by 40-60%.** Drop-in proxy for OpenAI, LangChain, LlamaIndex, CrewAI.

[![PyPI](https://img.shields.io/pypi/v/agentready.svg)](https://pypi.org/project/agentready/)
[![Python](https://img.shields.io/pypi/pyversions/agentready.svg)](https://pypi.org/project/agentready/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

## Install

```bash
pip install agentready
```

## Quick Start — Drop-in Proxy (Recommended)

Just swap your `base_url`. **Zero code changes** to your existing OpenAI calls:

```python
from openai import OpenAI

client = OpenAI(
    base_url="https://agentready.cloud/v1",   # ← only change needed
    api_key="ak_...",                          # your AgentReady key
    default_headers={
        "X-Upstream-API-Key": "sk-...",        # your OpenAI key
    },
)

# Everything works exactly like before — but 40-60% cheaper
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": your_long_prompt}],
)
```

### One-liner Helper

```python
import agentready

client = agentready.openai("ak_...", upstream_key="sk-...")
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

### Async Client

```python
client = agentready.create_client("ak_...", upstream_key="sk-...", async_client=True)
response = await client.chat.completions.create(...)
```

## Method 2 — Monkey-Patch

Patch all OpenAI/Anthropic calls globally with two lines:

```python
from agentready import patch_openai
patch_openai(api_key="ak_...")

# All existing OpenAI code is now compressed automatically
from openai import OpenAI
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": your_long_prompt}],
)
```

Or patch everything at once:

```python
import agentready
agentready.api_key = "ak_..."
agentready.auto()  # patches OpenAI + Anthropic
```

## Method 3 — Manual Compression

For fine-grained control:

```python
import agentready
agentready.api_key = "ak_..."

result = agentready.compress("Your long prompt text here...")
print(result.text)              # compressed text
print(result.tokens_saved)      # 1,247
print(result.reduction_percent) # 52.3
print(result.savings_usd)       # 0.0374
```

## Framework Integrations

### LangChain

```python
from agentready.integrations.langchain import TokenCutCallbackHandler
from langchain_openai import ChatOpenAI

handler = TokenCutCallbackHandler(api_key="ak_...")
llm = ChatOpenAI(model="gpt-4o", callbacks=[handler])
response = llm.invoke("Your very long prompt here...")
```

### LlamaIndex

```python
from agentready.integrations.llamaindex import TokenCutPostprocessor

postprocessor = TokenCutPostprocessor(api_key="ak_...")
query_engine = index.as_query_engine(
    node_postprocessors=[postprocessor]
)
```

### CrewAI

```python
from agentready.integrations.crewai import create_crewai_llm
from crewai import Agent, Task, Crew

llm = create_crewai_llm(
    agentready_key="ak_...",
    upstream_key="sk-...",
    model="gpt-4o",
)

agent = Agent(
    role="Researcher",
    goal="Research AI trends",
    backstory="Expert AI researcher.",
    llm=llm,
)
```

## How It Works

AgentReady's proxy sits between your code and OpenAI. Every request is:

1. **Compressed** — redundant phrasing removed, verbose text condensed
2. **Forwarded** — sent to OpenAI with your upstream key
3. **Returned** — response comes back unchanged

Code blocks, URLs, numbers, and key terms are always preserved.

## Configuration

```python
# Proxy mode — compression level via header
client = agentready.openai(
    "ak_...",
    upstream_key="sk-...",
    compression_level="aggressive",  # "light", "standard", "aggressive"
)

# Patch mode — configuration via arguments
agentready.auto(
    level="medium",
    preserve_code=True,
    min_tokens=100,
)
```

## Pricing

**Beta — Free unlimited usage.** After beta: pay-per-token, ~60% less than direct API costs.

Get your API key at [agentready.cloud](https://agentready.cloud)

## License

MIT — [AgentReady](https://agentready.cloud)
