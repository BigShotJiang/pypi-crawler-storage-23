"""TokenCut API client."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import httpx

API_BASE = "https://agentready.cloud/api/v1"


@dataclass
class CompressResult:
    """Result of a TokenCut compression."""

    text: str
    original_tokens: int
    compressed_tokens: int
    tokens_saved: int
    reduction_percent: float
    original_cost_usd: float
    compressed_cost_usd: float
    savings_usd: float
    processing_time_ms: float
    credits_consumed: int
    credits_remaining: int

    @property
    def ratio(self) -> float:
        """Compression ratio (0-1)."""
        if self.original_tokens == 0:
            return 0.0
        return self.tokens_saved / self.original_tokens


class TokenCutClient:
    """Low-level TokenCut API client."""

    def __init__(self, api_key: str, base_url: str = API_BASE, timeout: float = 30.0):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "agentready-python/0.3.0",
        }

    def _parse_response(self, data: dict) -> CompressResult:
        if not data.get("success"):
            raise TokenCutError(data.get("error", "Unknown error"))

        stats = data["data"]["stats"]
        return CompressResult(
            text=data["data"]["compressed_text"],
            original_tokens=stats["original_tokens"],
            compressed_tokens=stats["compressed_tokens"],
            tokens_saved=stats["tokens_saved"],
            reduction_percent=stats["reduction_percent"],
            original_cost_usd=stats.get("original_cost_usd", 0),
            compressed_cost_usd=stats.get("compressed_cost_usd", 0),
            savings_usd=stats.get("savings_usd", 0),
            processing_time_ms=stats.get("processing_time_ms", 0),
            credits_consumed=data.get("credits_consumed", 0),
            credits_remaining=data.get("credits_remaining", 0),
        )

    def compress(
        self,
        text: str,
        level: str = "medium",
        preserve_code: bool = True,
        preserve_urls: bool = True,
        target_model: str = "gpt-4",
    ) -> CompressResult:
        """Compress text synchronously."""
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.base_url}/tools/tokencut",
                headers=self._headers(),
                json={
                    "text": text,
                    "level": level,
                    "preserve_code": preserve_code,
                    "preserve_urls": preserve_urls,
                    "target_model": target_model,
                },
            )
            response.raise_for_status()
            return self._parse_response(response.json())

    async def compress_async(
        self,
        text: str,
        level: str = "medium",
        preserve_code: bool = True,
        preserve_urls: bool = True,
        target_model: str = "gpt-4",
    ) -> CompressResult:
        """Compress text asynchronously."""
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/tools/tokencut",
                headers=self._headers(),
                json={
                    "text": text,
                    "level": level,
                    "preserve_code": preserve_code,
                    "preserve_urls": preserve_urls,
                    "target_model": target_model,
                },
            )
            response.raise_for_status()
            return self._parse_response(response.json())


class TokenCutError(Exception):
    """Error from the TokenCut API."""

    pass
