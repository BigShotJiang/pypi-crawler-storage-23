"""
Automatic monkey-patching for OpenAI and Anthropic clients.

Usage — Global auto-patch:
    import agentready
    agentready.api_key = "ak_..."
    agentready.auto()  # patches OpenAI & Anthropic automatically

Usage — Standalone patch_openai:
    from agentready import patch_openai
    patch_openai(api_key="ak_...")

    from openai import OpenAI
    client = OpenAI()
    # All calls now compress prompts automatically
"""

from __future__ import annotations

import functools
import logging
from typing import Any

logger = logging.getLogger("agentready")

_patched: dict[str, Any] = {}


def auto(level: str = "medium", preserve_code: bool = True, min_tokens: int = 100) -> None:
    """Automatically patch OpenAI and Anthropic clients to compress prompts.

    Args:
        level: Compression level — "light", "medium", or "aggressive".
        preserve_code: Keep code blocks intact during compression.
        min_tokens: Minimum estimated token count to trigger compression.
    """
    _patch_openai_internal(level=level, preserve_code=preserve_code, min_tokens=min_tokens)
    _patch_anthropic_internal(level=level, preserve_code=preserve_code, min_tokens=min_tokens)


def patch_openai(
    api_key: str | None = None,
    level: str = "medium",
    preserve_code: bool = True,
    min_tokens: int = 100,
) -> None:
    """Patch OpenAI's chat completions to compress prompts via AgentReady.

    This is the simplest integration method — just call this once and all
    OpenAI chat completion calls will automatically compress their messages.

    Args:
        api_key: AgentReady API key. If provided, sets agentready.api_key.
        level: Compression level — "light", "medium", or "aggressive".
        preserve_code: Keep code blocks intact.
        min_tokens: Minimum tokens to trigger compression.

    Example:
        from agentready import patch_openai
        patch_openai(api_key="ak_...")

        from openai import OpenAI
        client = OpenAI()
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Your long prompt..."}],
        )
    """
    if api_key:
        import agentready
        agentready.api_key = api_key
    _patch_openai_internal(level=level, preserve_code=preserve_code, min_tokens=min_tokens)


def patch_anthropic(
    api_key: str | None = None,
    level: str = "medium",
    preserve_code: bool = True,
    min_tokens: int = 100,
) -> None:
    """Patch Anthropic's messages API to compress prompts via AgentReady.

    Args:
        api_key: AgentReady API key. If provided, sets agentready.api_key.
        level: Compression level — "light", "medium", or "aggressive".
        preserve_code: Keep code blocks intact.
        min_tokens: Minimum tokens to trigger compression.
    """
    if api_key:
        import agentready
        agentready.api_key = api_key
    _patch_anthropic_internal(level=level, preserve_code=preserve_code, min_tokens=min_tokens)


def unpatch() -> None:
    """Remove all monkey-patches and restore original behavior."""
    for key, original in _patched.items():
        parts = key.rsplit(".", 1)
        if len(parts) == 2:
            module_path, attr = parts
            try:
                import importlib
                mod = importlib.import_module(module_path)
                setattr(mod, attr, original)
            except Exception:
                pass
    _patched.clear()
    logger.info("agentready: all patches removed")


def _should_compress(text: str, min_tokens: int) -> bool:
    """Quick heuristic: estimate tokens as len/4, skip if below threshold."""
    return len(text) / 4 > min_tokens


def _compress_messages(messages: list[dict], level: str, preserve_code: bool, min_tokens: int) -> list[dict]:
    """Compress the content of chat messages."""
    import agentready

    compressed = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str) and _should_compress(content, min_tokens):
            try:
                result = agentready.compress(content, level=level, preserve_code=preserve_code)
                compressed.append({**msg, "content": result.text})
                logger.debug(
                    f"agentready: compressed {result.original_tokens} → {result.compressed_tokens} tokens "
                    f"({result.reduction_percent:.1f}% reduction, saved ${result.savings_usd:.4f})"
                )
            except Exception as e:
                logger.warning(f"agentready: compression failed, using original: {e}")
                compressed.append(msg)
        else:
            compressed.append(msg)
    return compressed


def _compress_prompt(prompt: str, level: str, preserve_code: bool, min_tokens: int) -> str:
    """Compress a single prompt string."""
    import agentready

    if not _should_compress(prompt, min_tokens):
        return prompt
    try:
        result = agentready.compress(prompt, level=level, preserve_code=preserve_code)
        logger.debug(
            f"agentready: compressed {result.original_tokens} → {result.compressed_tokens} tokens"
        )
        return result.text
    except Exception as e:
        logger.warning(f"agentready: compression failed, using original: {e}")
        return prompt


def _patch_openai_internal(level: str, preserve_code: bool, min_tokens: int) -> None:
    """Patch OpenAI's chat completions create method."""
    try:
        from openai.resources.chat import completions as chat_mod

        original_create = chat_mod.Completions.create
        if "openai.chat.create" in _patched:
            return  # already patched

        @functools.wraps(original_create)
        def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            if "messages" in kwargs:
                kwargs["messages"] = _compress_messages(
                    kwargs["messages"], level, preserve_code, min_tokens
                )
            return original_create(self, *args, **kwargs)

        chat_mod.Completions.create = patched_create  # type: ignore
        _patched["openai.chat.create"] = original_create
        logger.info("agentready: patched OpenAI chat completions")

        # Also patch async
        try:
            original_acreate = chat_mod.AsyncCompletions.create

            @functools.wraps(original_acreate)
            async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
                if "messages" in kwargs:
                    kwargs["messages"] = _compress_messages(
                        kwargs["messages"], level, preserve_code, min_tokens
                    )
                return await original_acreate(self, *args, **kwargs)

            chat_mod.AsyncCompletions.create = patched_acreate  # type: ignore
            _patched["openai.chat.acreate"] = original_acreate
            logger.info("agentready: patched OpenAI async chat completions")
        except AttributeError:
            pass

    except ImportError:
        logger.debug("agentready: openai not installed, skipping patch")


def _patch_anthropic_internal(level: str, preserve_code: bool, min_tokens: int) -> None:
    """Patch Anthropic's messages create method."""
    try:
        from anthropic.resources import messages as msg_mod

        original_create = msg_mod.Messages.create
        if "anthropic.messages.create" in _patched:
            return

        @functools.wraps(original_create)
        def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            if "messages" in kwargs:
                kwargs["messages"] = _compress_messages(
                    kwargs["messages"], level, preserve_code, min_tokens
                )
            return original_create(self, *args, **kwargs)

        msg_mod.Messages.create = patched_create  # type: ignore
        _patched["anthropic.messages.create"] = original_create
        logger.info("agentready: patched Anthropic messages")

        # Async
        try:
            original_acreate = msg_mod.AsyncMessages.create

            @functools.wraps(original_acreate)
            async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
                if "messages" in kwargs:
                    kwargs["messages"] = _compress_messages(
                        kwargs["messages"], level, preserve_code, min_tokens
                    )
                return await original_acreate(self, *args, **kwargs)

            msg_mod.AsyncMessages.create = patched_acreate  # type: ignore
            _patched["anthropic.messages.acreate"] = original_acreate
            logger.info("agentready: patched Anthropic async messages")
        except AttributeError:
            pass

    except ImportError:
        logger.debug("agentready: anthropic not installed, skipping patch")
