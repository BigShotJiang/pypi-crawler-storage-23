"""
AgentReady Proxy — Create OpenAI clients that route through AgentReady.

This is the recommended integration method. Just swap your base_url:

    from openai import OpenAI
    client = OpenAI(
        base_url="https://agentready.cloud/v1",
        api_key="ak_...",
        default_headers={"X-Upstream-API-Key": "sk-..."},
    )

Or use the helper:
    import agentready
    client = agentready.openai("ak_...", upstream_key="sk-...")
"""

from __future__ import annotations

from typing import Any, Optional

PROXY_BASE_URL = "https://agentready.cloud/v1"


def openai(
    api_key: str,
    upstream_key: Optional[str] = None,
    compression_level: str = "standard",
    **kwargs: Any,
) -> Any:
    """Create an OpenAI client that routes through AgentReady's proxy.

    Every request is automatically compressed before being forwarded to OpenAI,
    saving 40-60% on token costs. Fully compatible with the OpenAI Python SDK.

    Args:
        api_key: Your AgentReady API key (starts with ak_).
        upstream_key: Your OpenAI API key (sk-...). If not provided, the server
            will use its own key (costs may apply).
        compression_level: "light", "standard", or "aggressive".
        **kwargs: Additional arguments passed to OpenAI() constructor.

    Returns:
        An OpenAI client instance configured to use AgentReady's proxy.

    Example:
        import agentready
        client = agentready.openai("ak_...", upstream_key="sk-...")
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError(
            "openai package is required. Install with: pip install openai"
        )

    headers = {"X-Compression-Level": compression_level}
    if upstream_key:
        headers["X-Upstream-API-Key"] = upstream_key

    # Merge with any user-provided headers
    if "default_headers" in kwargs:
        kwargs["default_headers"].update(headers)
    else:
        kwargs["default_headers"] = headers

    return OpenAI(
        api_key=api_key,
        base_url=PROXY_BASE_URL,
        **kwargs,
    )


def create_client(
    api_key: str,
    upstream_key: Optional[str] = None,
    compression_level: str = "standard",
    async_client: bool = False,
    **kwargs: Any,
) -> Any:
    """Create an OpenAI-compatible client routed through AgentReady.

    Same as `agentready.openai()` but supports async mode.

    Args:
        api_key: Your AgentReady API key.
        upstream_key: Your OpenAI API key.
        compression_level: "light", "standard", or "aggressive".
        async_client: If True, returns an AsyncOpenAI client.
        **kwargs: Additional arguments passed to OpenAI/AsyncOpenAI.

    Returns:
        OpenAI or AsyncOpenAI client instance.
    """
    try:
        from openai import OpenAI, AsyncOpenAI
    except ImportError:
        raise ImportError(
            "openai package is required. Install with: pip install openai"
        )

    headers = {"X-Compression-Level": compression_level}
    if upstream_key:
        headers["X-Upstream-API-Key"] = upstream_key

    if "default_headers" in kwargs:
        kwargs["default_headers"].update(headers)
    else:
        kwargs["default_headers"] = headers

    client_cls = AsyncOpenAI if async_client else OpenAI
    return client_cls(
        api_key=api_key,
        base_url=PROXY_BASE_URL,
        **kwargs,
    )
