"""
AgentReady — Cut your AI token costs by 40-60%.

Drop-in proxy for OpenAI, Anthropic, LangChain, LlamaIndex, CrewAI.

Quick Start (recommended — just swap base_url):
    from openai import OpenAI
    client = OpenAI(
        base_url="https://agentready.cloud/v1",
        api_key="ak_...",  # your AgentReady API key
        default_headers={"X-Upstream-API-Key": "sk-..."},  # your OpenAI key
    )
    # That's it! All calls are now compressed automatically.

One-liner:
    import agentready
    client = agentready.openai("ak_...", upstream_key="sk-...")

Patch mode (monkey-patch existing code):
    import agentready
    agentready.api_key = "ak_..."
    agentready.auto()  # patches OpenAI & Anthropic globally

Manual compression:
    import agentready
    agentready.api_key = "ak_..."
    result = agentready.compress("Your long prompt here...")
"""

from agentready.client import TokenCutClient, CompressResult
from agentready.patch import auto, unpatch, patch_openai, patch_anthropic
from agentready.proxy import openai, create_client

__version__ = "0.3.0"
__all__ = [
    "api_key",
    "auto",
    "unpatch",
    "patch_openai",
    "patch_anthropic",
    "openai",
    "create_client",
    "compress",
    "compress_async",
    "CompressResult",
]

# ── Module-level API key ─────────────────────────────────────────────
api_key: str | None = None

# ── Module-level client (lazy) ───────────────────────────────────────
_client: TokenCutClient | None = None


def _get_client() -> TokenCutClient:
    global _client
    if _client is None or _client.api_key != api_key:
        if not api_key:
            raise ValueError(
                "agentready.api_key is not set. "
                "Get your API key at https://agentready.cloud/dashboard/api-keys"
            )
        _client = TokenCutClient(api_key=api_key)
    return _client


def compress(
    text: str,
    level: str = "medium",
    preserve_code: bool = True,
    preserve_urls: bool = True,
    target_model: str = "gpt-4",
) -> CompressResult:
    """Compress text using TokenCut.

    Args:
        text: The text to compress.
        level: Compression level — "light", "medium", or "aggressive".
        preserve_code: Keep code blocks intact.
        preserve_urls: Keep URLs intact.
        target_model: Target LLM model for cost estimation.

    Returns:
        CompressResult with compressed text and stats.
    """
    return _get_client().compress(
        text=text,
        level=level,
        preserve_code=preserve_code,
        preserve_urls=preserve_urls,
        target_model=target_model,
    )


async def compress_async(
    text: str,
    level: str = "medium",
    preserve_code: bool = True,
    preserve_urls: bool = True,
    target_model: str = "gpt-4",
) -> CompressResult:
    """Async version of compress."""
    return await _get_client().compress_async(
        text=text,
        level=level,
        preserve_code=preserve_code,
        preserve_urls=preserve_urls,
        target_model=target_model,
    )
