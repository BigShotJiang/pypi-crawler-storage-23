"""
AgentReady TokenCut integration for LlamaIndex.

Provides a node postprocessor that compresses retrieved context
before it's sent to the LLM, reducing RAG pipeline token costs.

Usage:
    from agentready.integrations.llamaindex import TokenCutPostprocessor

    postprocessor = TokenCutPostprocessor(api_key="ar_...")

    query_engine = index.as_query_engine(
        node_postprocessors=[postprocessor]
    )
    response = query_engine.query("Your question here")
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("agentready.llamaindex")

try:
    from llama_index.core.postprocessor.types import BaseNodePostprocessor
    from llama_index.core.schema import NodeWithScore, QueryBundle
except ImportError:
    raise ImportError(
        "LlamaIndex is required for this integration. "
        "Install it with: pip install llama-index-core"
    )

from agentready.client import TokenCutClient


class TokenCutPostprocessor(BaseNodePostprocessor):
    """LlamaIndex node postprocessor that compresses retrieved context using TokenCut.

    Compresses the text of retrieved nodes before they're included in the LLM prompt,
    reducing token costs for RAG pipelines.

    Args:
        api_key: AgentReady API key (get one at https://agentready.cloud)
        level: Compression level — "light", "medium", or "aggressive"
        preserve_code: Keep code blocks intact
        min_length: Minimum text length to trigger compression

    Example:
        postprocessor = TokenCutPostprocessor(api_key="ar_...")
        query_engine = index.as_query_engine(
            node_postprocessors=[postprocessor]
        )
        response = query_engine.query("What is the architecture?")
    """

    api_key: str
    level: str = "medium"
    preserve_code: bool = True
    min_length: int = 200
    _client: Optional[TokenCutClient] = None
    _total_tokens_saved: int = 0
    _total_savings_usd: float = 0.0

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, api_key: str, **kwargs: Any):
        super().__init__(api_key=api_key, **kwargs)
        self._client = TokenCutClient(api_key=api_key)

    def _postprocess_nodes(
        self,
        nodes: List[NodeWithScore],
        query_bundle: Optional[QueryBundle] = None,
    ) -> List[NodeWithScore]:
        """Compress the text content of each retrieved node."""
        compressed_nodes = []

        for node_with_score in nodes:
            node = node_with_score.node
            text = node.get_content()

            if len(text) >= self.min_length and self._client:
                try:
                    result = self._client.compress(
                        text=text,
                        level=self.level,
                        preserve_code=self.preserve_code,
                    )
                    node.set_content(result.text)
                    self._total_tokens_saved += result.tokens_saved
                    self._total_savings_usd += result.savings_usd
                    logger.info(
                        f"TokenCut: compressed node {result.original_tokens} → "
                        f"{result.compressed_tokens} tokens ({result.reduction_percent:.1f}%)"
                    )
                except Exception as e:
                    logger.warning(f"TokenCut compression failed for node: {e}")

            compressed_nodes.append(node_with_score)

        return compressed_nodes

    @property
    def stats(self) -> Dict[str, Any]:
        """Return cumulative compression stats."""
        return {
            "total_tokens_saved": self._total_tokens_saved,
            "total_savings_usd": self._total_savings_usd,
        }
