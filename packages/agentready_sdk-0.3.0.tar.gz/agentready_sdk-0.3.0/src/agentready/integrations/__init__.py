"""AgentReady integrations for popular LLM frameworks."""
