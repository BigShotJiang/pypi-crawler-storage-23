"""
AgentReady TokenCut integration for LangChain.

Provides a callback handler that automatically compresses prompts
before they're sent to any LLM through LangChain.

Usage:
    from agentready.integrations.langchain import TokenCutCallbackHandler

    handler = TokenCutCallbackHandler(api_key="ar_...")
    llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
    response = llm.invoke("Your very long prompt here...")
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger("agentready.langchain")

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage, HumanMessage
except ImportError:
    raise ImportError(
        "LangChain is required for this integration. "
        "Install it with: pip install langchain-core"
    )

from agentready.client import TokenCutClient


class TokenCutCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that compresses prompts using TokenCut.

    Automatically compresses user messages before they're sent to any LLM.
    Preserves code blocks, URLs, and system messages.

    Args:
        api_key: AgentReady API key (get one at https://agentready.cloud)
        level: Compression level — "light", "medium", or "aggressive"
        preserve_code: Keep code blocks intact
        min_length: Minimum text length to trigger compression (in chars)
        compress_system: Whether to compress system messages (default: False)

    Example:
        handler = TokenCutCallbackHandler(api_key="ar_...")
        llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
        response = llm.invoke("Your very long prompt here...")
    """

    def __init__(
        self,
        api_key: str,
        level: str = "medium",
        preserve_code: bool = True,
        min_length: int = 400,
        compress_system: bool = False,
    ):
        super().__init__()
        self.client = TokenCutClient(api_key=api_key)
        self.level = level
        self.preserve_code = preserve_code
        self.min_length = min_length
        self.compress_system = compress_system
        self.total_tokens_saved = 0
        self.total_savings_usd = 0.0

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs: Any,
    ) -> None:
        """Compress prompts before sending to LLM."""
        for i, prompt in enumerate(prompts):
            if len(prompt) >= self.min_length:
                try:
                    result = self.client.compress(
                        text=prompt,
                        level=self.level,
                        preserve_code=self.preserve_code,
                    )
                    prompts[i] = result.text
                    self.total_tokens_saved += result.tokens_saved
                    self.total_savings_usd += result.savings_usd
                    logger.info(
                        f"TokenCut: {result.original_tokens} → {result.compressed_tokens} tokens "
                        f"({result.reduction_percent:.1f}% reduction)"
                    )
                except Exception as e:
                    logger.warning(f"TokenCut compression failed: {e}")

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        """Compress chat messages before sending to LLM."""
        for message_list in messages:
            for i, msg in enumerate(message_list):
                # Skip system messages unless configured otherwise
                if msg.type == "system" and not self.compress_system:
                    continue

                content = msg.content
                if isinstance(content, str) and len(content) >= self.min_length:
                    try:
                        result = self.client.compress(
                            text=content,
                            level=self.level,
                            preserve_code=self.preserve_code,
                        )
                        msg.content = result.text
                        self.total_tokens_saved += result.tokens_saved
                        self.total_savings_usd += result.savings_usd
                        logger.info(
                            f"TokenCut: {result.original_tokens} → {result.compressed_tokens} tokens "
                            f"({result.reduction_percent:.1f}% saved ${result.savings_usd:.4f})"
                        )
                    except Exception as e:
                        logger.warning(f"TokenCut compression failed: {e}")

    @property
    def stats(self) -> Dict[str, Any]:
        """Return cumulative compression stats."""
        return {
            "total_tokens_saved": self.total_tokens_saved,
            "total_savings_usd": self.total_savings_usd,
        }
