"""
AgentReady TokenCut integration for CrewAI.

Provides a CrewAI-compatible LLM wrapper that routes through AgentReady's
proxy, automatically compressing all prompts to reduce token costs.

Usage:
    from agentready.integrations.crewai import AgentReadyLLM

    llm = AgentReadyLLM(
        agentready_key="ak_...",
        upstream_key="sk-...",
        model="gpt-4o",
    )

    agent = Agent(
        role="Researcher",
        goal="Research AI trends",
        backstory="You are an AI researcher.",
        llm=llm,
    )
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("agentready.crewai")

PROXY_BASE_URL = "https://agentready.cloud/v1"


def create_crewai_llm(
    agentready_key: str,
    upstream_key: Optional[str] = None,
    model: str = "gpt-4o",
    compression_level: str = "standard",
    temperature: float = 0.7,
    **kwargs: Any,
) -> Any:
    """Create a CrewAI-compatible LLM that routes through AgentReady.

    Args:
        agentready_key: Your AgentReady API key (ak_...).
        upstream_key: Your OpenAI API key (sk-...).
        model: Model name (e.g., "gpt-4o", "gpt-4o-mini").
        compression_level: "light", "standard", or "aggressive".
        temperature: LLM temperature.
        **kwargs: Additional LLM arguments.

    Returns:
        A CrewAI-compatible LLM instance.

    Example:
        from agentready.integrations.crewai import create_crewai_llm
        from crewai import Agent, Task, Crew

        llm = create_crewai_llm(
            agentready_key="ak_...",
            upstream_key="sk-...",
            model="gpt-4o",
        )

        agent = Agent(
            role="Researcher",
            goal="Research AI trends",
            backstory="Expert AI researcher.",
            llm=llm,
        )
    """
    try:
        from crewai import LLM
    except ImportError:
        raise ImportError(
            "crewai is required for this integration. "
            "Install it with: pip install crewai"
        )

    return LLM(
        model=f"openai/{model}",
        base_url=PROXY_BASE_URL,
        api_key=agentready_key,
        temperature=temperature,
        extra_headers={
            "X-Compression-Level": compression_level,
            **({"X-Upstream-API-Key": upstream_key} if upstream_key else {}),
        },
        **kwargs,
    )


class AgentReadyLLM:
    """CrewAI LLM wrapper that routes through AgentReady's proxy.

    This class provides a convenient way to create CrewAI agents that
    automatically use AgentReady's token compression.

    Example:
        llm = AgentReadyLLM(
            agentready_key="ak_...",
            upstream_key="sk-...",
        )
        agent = Agent(role="Coder", goal="Write code", llm=llm.get_llm())
    """

    def __init__(
        self,
        agentready_key: str,
        upstream_key: Optional[str] = None,
        model: str = "gpt-4o",
        compression_level: str = "standard",
        temperature: float = 0.7,
    ):
        self.agentready_key = agentready_key
        self.upstream_key = upstream_key
        self.model = model
        self.compression_level = compression_level
        self.temperature = temperature

    def get_llm(self, **kwargs: Any) -> Any:
        """Get a CrewAI LLM instance."""
        return create_crewai_llm(
            agentready_key=self.agentready_key,
            upstream_key=self.upstream_key,
            model=self.model,
            compression_level=self.compression_level,
            temperature=self.temperature,
            **kwargs,
        )
