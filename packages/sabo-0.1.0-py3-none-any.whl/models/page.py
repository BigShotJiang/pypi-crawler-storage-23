from dataclasses import dataclass, field
from typing import List
from .component import Component

from pathlib import Path
import json

@dataclass 
class Page:
    """Страница проекта, состоит из компонентов которые
    пользователь сможет создавать, удалять, копировать, перемещать"""
    id: str
    name: str
    components: List[Component] = field(default_factory=list)
    
    def add_component(self, component: Component):
        """Добавление компонента на страницу"""
        self.components.append(component)
        
    """Метод позволяющий назевисимо загружать странцу"""
    def __init__(self, name: str, components: list[str]):
        self.name = name
        self.components = components
        
        @classmethod
        def from_json(cls, path: Path) -> "Page":
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
            return cls(
                name=data["name"],
                component=data.get("component", [])
            )