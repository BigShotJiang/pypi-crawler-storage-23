""" We import almost everything by default, in the general
namespace because it is simpler for everyone """

from .cafeine import *
from .pathPattern import *