"""Short-term memory example: callbacks and health transitions."""

