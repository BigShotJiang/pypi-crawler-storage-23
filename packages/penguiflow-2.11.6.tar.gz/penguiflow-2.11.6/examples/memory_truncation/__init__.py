"""Short-term memory example: truncation strategy."""

