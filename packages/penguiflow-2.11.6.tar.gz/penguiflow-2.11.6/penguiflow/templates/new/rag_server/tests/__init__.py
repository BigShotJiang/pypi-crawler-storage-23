"""Tests for rag_server template."""
