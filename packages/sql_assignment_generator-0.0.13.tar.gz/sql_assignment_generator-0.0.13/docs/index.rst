.. dav-tools documentation master file, created by
   sphinx-quickstart on Sun Jul 16 15:00:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sql_assignment_generator's documentation!
====================================================
This project generates SQL assignments based on common mistakes made by learners.
The tool aims to help users practice and improve their SQL skills by providing targeted exercises.

Contents
========

.. toctree::
   :maxdepth: 4


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Installation
============
``$ pip install sql_assignment_generator``

