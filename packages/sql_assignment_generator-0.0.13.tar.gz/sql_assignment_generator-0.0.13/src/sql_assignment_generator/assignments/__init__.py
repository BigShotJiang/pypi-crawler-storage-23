'''Data structures for SQL assignments.'''

from .assignment import Assignment
from .exercise import Exercise
from .dataset import Dataset