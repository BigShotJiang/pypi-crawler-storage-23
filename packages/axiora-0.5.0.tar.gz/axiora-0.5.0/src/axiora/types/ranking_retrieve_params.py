# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["RankingRetrieveParams"]


class RankingRetrieveParams(TypedDict, total=False):
    fiscal_year: Optional[int]

    limit: int

    offset: int

    order: str

    sector: Optional[str]
    """Filter by sector"""
