# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from axiora import Axiora, AsyncAxiora
from tests.utils import assert_matches_type
from axiora.types import SectionListAvailableResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSections:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_available(self, client: Axiora) -> None:
        section = client.sections.list_available()
        assert_matches_type(SectionListAvailableResponse, section, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_available(self, client: Axiora) -> None:
        response = client.sections.with_raw_response.list_available()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        section = response.parse()
        assert_matches_type(SectionListAvailableResponse, section, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_available(self, client: Axiora) -> None:
        with client.sections.with_streaming_response.list_available() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            section = response.parse()
            assert_matches_type(SectionListAvailableResponse, section, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSections:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_available(self, async_client: AsyncAxiora) -> None:
        section = await async_client.sections.list_available()
        assert_matches_type(SectionListAvailableResponse, section, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_available(self, async_client: AsyncAxiora) -> None:
        response = await async_client.sections.with_raw_response.list_available()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        section = await response.parse()
        assert_matches_type(SectionListAvailableResponse, section, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_available(self, async_client: AsyncAxiora) -> None:
        async with async_client.sections.with_streaming_response.list_available() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            section = await response.parse()
            assert_matches_type(SectionListAvailableResponse, section, path=["response"])

        assert cast(Any, response.is_closed) is True
