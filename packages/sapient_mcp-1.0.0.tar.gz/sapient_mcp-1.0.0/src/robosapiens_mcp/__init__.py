"""SAPient MCP — Intelligent SAP GUI automation for AI agents."""
__version__ = "1.0.0"
