"""meta-ads-cli: Create and manage Meta ad campaigns from your terminal."""

__version__ = "0.1.0"
