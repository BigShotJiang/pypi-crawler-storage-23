# -*- coding: utf-8 -*-
"""
DESAYSV 相机内参解析：从 log 文件提取，结合 camera_id 映射，返回与 D02 单组内参同构的 List[dict]。
"""

import os
import re
from typing import Dict, List, Union

from ..._types import intrinsic_item_to_d2_format


def parse_camera_id_mapping(camera_id_file: str) -> Dict[int, str]:
    """Parse camera_id file to get camera_id -> frame_id mapping."""
    mapping: Dict[int, str] = {}
    with open(camera_id_file, "r", encoding="utf-8") as f:
        for line in f:
            match = re.search(
                r'frame_id\s*=\s*"([^"]+)"\s+camera_id\s*=\s*(\d+)', line
            )
            if match:
                frame_id = match.group(1)
                camera_id = int(match.group(2))
                mapping[camera_id] = frame_id
    return mapping


def extract_intrinsics_from_log(log_file: str) -> Dict[int, dict]:
    """Extract intrinsics data for all cameras from a log file."""
    intrinsics_data: Dict[int, dict] = {}

    with open(log_file, "r", encoding="utf-8") as f:
        content = f.read()

    pattern = r"\*+coffes for camera (\d+)\*+\s*\n(.*?)\*+coffes end\*+"
    matches = re.finditer(pattern, content, re.DOTALL)

    for match in matches:
        camera_id = int(match.group(1))
        section = match.group(2)

        fx_match = re.search(r"fx:\s*([\d.e+-]+)", section)
        fy_match = re.search(r"fy:\s*([\d.e+-]+)", section)
        cx_match = re.search(r"cx:\s*([\d.e+-]+)", section)
        cy_match = re.search(r"cy:\s*([\d.e+-]+)", section)
        k1_match = re.search(r"k1:\s*([\d.e+-]+)", section)
        k2_match = re.search(r"k2:\s*([\d.e+-]+)", section)
        k3_match = re.search(r"k3:\s*([\d.e+-]+)", section)
        k4_match = re.search(r"k4:\s*([\d.e+-]+)", section)
        k5_match = re.search(r"k5:\s*([\d.e+-]+)", section)
        k6_match = re.search(r"k6:\s*([\d.e+-]+)", section)
        p1_match = re.search(r"p1:\s*([\d.e+-]+)", section)
        p2_match = re.search(r"p2:\s*([\d.e+-]+)", section)
        serial_match = re.search(r'serial_no:\s*"([^"]*)"', section)
        rms_match = re.search(r"rms:\s*([\d.e+-]+)", section)

        if all([fx_match, fy_match, cx_match, cy_match]):
            intrinsics_data[camera_id] = {
                "fx": float(fx_match.group(1)),
                "fy": float(fy_match.group(1)),
                "cx": float(cx_match.group(1)),
                "cy": float(cy_match.group(1)),
                "k1": float(k1_match.group(1)) if k1_match else 0.0,
                "k2": float(k2_match.group(1)) if k2_match else 0.0,
                "k3": float(k3_match.group(1)) if k3_match else 0.0,
                "k4": float(k4_match.group(1)) if k4_match else 0.0,
                "k5": float(k5_match.group(1)) if k5_match else 0.0,
                "k6": float(k6_match.group(1)) if k6_match else 0.0,
                "p1": float(p1_match.group(1)) if p1_match else 0.0,
                "p2": float(p2_match.group(1)) if p2_match else 0.0,
                "serial_no": serial_match.group(1) if serial_match else "",
                "rms": float(rms_match.group(1)) if rms_match else 0.0,
            }

    return intrinsics_data


def _is_valid_intrinsics(intrinsics: dict) -> bool:
    if (
        intrinsics["fx"] == 0
        and intrinsics["fy"] == 0
        and intrinsics["cx"] == 0
        and intrinsics["cy"] == 0
    ):
        return False
    return True


def _raw_to_d2_item(
    frame_id: str, raw: dict, width: int = 1920, height: int = 1536
) -> dict:
    """将 DESAYSV 原始内参转为 D02 单组内参 dict."""
    intrinsic = [
        raw["fx"],
        0,
        raw["cx"],
        0,
        raw["fy"],
        raw["cy"],
        0,
        0,
        1,
    ]
    has_tangential = (
        raw["p1"] != 0
        or raw["p2"] != 0
        or raw["k5"] != 0
        or raw["k6"] != 0
    )
    if has_tangential:
        distortion = [
            raw["k1"],
            raw["k2"],
            raw["p1"],
            raw["p2"],
            raw["k3"],
            raw["k4"],
            raw["k5"],
            raw["k6"],
        ]
    else:
        distortion = [raw["k1"], raw["k2"], raw["k3"], raw["k4"]]

    extra: Dict[str, object] = {}
    if raw.get("serial_no"):
        extra["serial_no"] = raw["serial_no"]
    if "rms" in raw:
        extra["rms"] = raw["rms"]

    return intrinsic_item_to_d2_format(
        frame_id=frame_id,
        model_type="PINHOLE",
        width=width,
        height=height,
        intrinsic=intrinsic,
        distortion=distortion,
        use_pinhole=True,
        extra=extra if extra else None,
    )


def parse(
    log_dir: str = "",
    log_paths: Union[List[str], None] = None,
    camera_id_path: str = "",
    camera_id_mapping: Union[Dict[int, str], None] = None,
) -> List[dict]:
    """
    解析 DESAYSV log，返回 List[dict]，每项与 D02 单组内参 YAML 同构。

    必须提供：
      - log 来源：log_dir（目录下所有 *.log）或 log_paths（文件列表）
      - camera_id 映射：camera_id_path（camera_id 文件路径，不能为文件夹）或 camera_id_mapping（dict）
    """
    if camera_id_mapping is None:
        if not camera_id_path:
            raise ValueError(
                "DESAYSV requires camera_id_path or camera_id_mapping"
            )
        if os.path.isdir(camera_id_path):
            raise ValueError(
                "DESAYSV camera_id_path 必须为 camera_id 文件路径，不能为文件夹路径"
            )
        if not os.path.isfile(camera_id_path):
            raise ValueError(
                "DESAYSV requires camera_id_path or camera_id_mapping"
            )
        camera_id_mapping = parse_camera_id_mapping(camera_id_path)

    if log_paths is None:
        if not log_dir or not os.path.isdir(log_dir):
            raise ValueError("DESAYSV requires log_dir or log_paths")
        import glob

        log_paths = glob.glob(os.path.join(log_dir, "*.log"))
    if not log_paths:
        raise ValueError("No log files found")

    all_camera_data: Dict[int, List[dict]] = {}
    for log_file in log_paths:
        if not os.path.isfile(log_file):
            continue
        intrinsics = extract_intrinsics_from_log(log_file)
        for cam_id, data in intrinsics.items():
            if cam_id not in all_camera_data:
                all_camera_data[cam_id] = []
            all_camera_data[cam_id].append({"data": data, "source": log_file})

    all_intrinsics: Dict[int, dict] = {}
    for cam_id, data_list in all_camera_data.items():
        for item in data_list:
            if _is_valid_intrinsics(item["data"]):
                all_intrinsics[cam_id] = item["data"]
                break

    result: List[dict] = []
    for cam_id in sorted(all_intrinsics.keys()):
        if cam_id not in camera_id_mapping:
            continue
        frame_id = camera_id_mapping[cam_id]
        result.append(
            _raw_to_d2_item(frame_id, all_intrinsics[cam_id])
        )
    return result
