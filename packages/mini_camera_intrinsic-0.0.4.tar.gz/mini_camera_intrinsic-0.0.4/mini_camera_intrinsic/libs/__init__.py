# -*- coding: utf-8 -*-
"""libs: DESAYSV / PONY 等相机解析器."""
