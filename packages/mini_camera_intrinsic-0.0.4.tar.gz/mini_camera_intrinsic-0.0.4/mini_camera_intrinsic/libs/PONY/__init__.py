# -*- coding: utf-8 -*-
"""PONY 相机内参解析（log 文件路径）."""

from .parser import parse

__all__ = ["parse"]
