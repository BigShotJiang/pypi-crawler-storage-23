# -*- coding: utf-8 -*-
"""
PONY 相机内参解析：从 log 文件（含 EEPROM 512 字节）解析，返回与 D02 单组内参同构的 List[dict]。
参考：calib_func/XZT_intrinsic_convert (caminfo_parser + convert_protobuf)。
"""

import struct
import zlib
from typing import Dict, List

from ..._types import intrinsic_item_to_d2_format


def _bytes_to_double(byte_list: List[int]) -> float:
    if len(byte_list) != 8:
        raise ValueError("Exactly 8 bytes required")
    return struct.unpack("<d", bytes(byte_list))[0]


def _compute_crc32(data_bytes: List[int]) -> int:
    return zlib.crc32(bytes(data_bytes)) & 0xFFFFFFFF


class _CameraMatrix:
    """192 bytes from offset 96 in 512-byte EEPROM block."""

    def __init__(self, data: List[int]):
        if len(data) != 192:
            raise ValueError("Expected 192 bytes for CameraMatrix")
        self.data = data
        self.width = (data[1] << 8) | data[0]
        self.height = (data[3] << 8) | data[2]
        self.distortion_model = data[4]
        self.fx = _bytes_to_double(data[5:13])
        self.fy = _bytes_to_double(data[13:21])
        self.cx = _bytes_to_double(data[21:29])
        self.cy = _bytes_to_double(data[29:37])
        self.pinhole_k1 = _bytes_to_double(data[37:45])
        self.pinhole_k2 = _bytes_to_double(data[45:53])
        self.pinhole_p1 = _bytes_to_double(data[53:61])
        self.pinhole_p2 = _bytes_to_double(data[61:69])
        self.pinhole_k3 = _bytes_to_double(data[69:77])
        self.pinhole_k4 = _bytes_to_double(data[77:85])
        self.pinhole_k5 = _bytes_to_double(data[85:93])
        self.pinhole_k6 = _bytes_to_double(data[93:101])
        self.fisheye_k1 = _bytes_to_double(data[101:109])
        self.fisheye_k2 = _bytes_to_double(data[109:117])
        self.fisheye_k3 = _bytes_to_double(data[117:125])
        self.fisheye_k4 = _bytes_to_double(data[125:133])
        crc = struct.unpack("<I", bytes(data[-4:]))[0]
        if crc != _compute_crc32(data[:-4]):
            raise ValueError("CameraMatrix CRC32 check failed")


def _parse_pony_log(file_path: str) -> Dict[str, dict]:
    """
    从 PONY log 解析出每个相机的 frame_id 与 512 字节 EEPROM data。
    返回 { camera_name: { "frame_id": str, "data": list of int } }。
    """
    cameras: Dict[str, dict] = {}
    current_camera = None
    collecting_data = False
    data_lines_collected = 0
    expected_lines = 32  # 512 bytes / 16 bytes per line

    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if "Match pipeline" in line and "read camera inrinsic" in line:
                parts = line.split()
                for part in parts:
                    if part.startswith("CameraDeviceGroup"):
                        current_camera = part.rstrip(":")[:-1]
                        cameras[current_camera] = {"frame_id": "", "data": []}
                        collecting_data = False
                        data_lines_collected = 0
                        break
            elif "Frame id" in line and current_camera:
                cameras[current_camera]["frame_id"] = line.split(":")[-1].strip()
            elif "EEPROM data length:  512" in line:
                collecting_data = True
            elif collecting_data and line.strip().startswith("0x"):
                hex_values = line.strip().split()
                byte_values = [int(h, 16) for h in hex_values]
                cameras[current_camera]["data"].extend(byte_values)
                data_lines_collected += 1
                if data_lines_collected >= expected_lines:
                    collecting_data = False

    return cameras


def _camera_data_to_d2_item(
    frame_id: str, data_512: List[int]
) -> dict:
    """将单相机 512 字节转为 D02 单组内参 dict。"""
    matrix = _CameraMatrix(data_512[96:288])
    width = matrix.width
    height = matrix.height
    intrinsic = [
        matrix.fx,
        0.0,
        matrix.cx,
        0.0,
        matrix.fy,
        matrix.cy,
        0.0,
        0.0,
        1.0,
    ]
    if matrix.distortion_model == 1:  # pinhole
        model_type = "PINHOLE"
        distortion = [
            matrix.pinhole_k1,
            matrix.pinhole_k2,
            matrix.pinhole_p1,
            matrix.pinhole_p2,
            matrix.pinhole_k3,
            matrix.pinhole_k4,
            matrix.pinhole_k5,
            matrix.pinhole_k6,
        ]
        use_pinhole = True
    elif matrix.distortion_model == 2:  # fisheye
        model_type = "FISHEYE"
        distortion = [
            matrix.fisheye_k1,
            matrix.fisheye_k2,
            matrix.fisheye_k3,
            matrix.fisheye_k4,
        ]
        use_pinhole = False
    else:
        model_type = "PINHOLE"
        distortion = [
            matrix.pinhole_k1,
            matrix.pinhole_k2,
            matrix.pinhole_p1,
            matrix.pinhole_p2,
            matrix.pinhole_k3,
            matrix.pinhole_k4,
            matrix.pinhole_k5,
            matrix.pinhole_k6,
        ]
        use_pinhole = True

    return intrinsic_item_to_d2_format(
        frame_id=frame_id,
        model_type=model_type,
        width=width,
        height=height,
        intrinsic=intrinsic,
        distortion=distortion,
        use_pinhole=use_pinhole,
    )


def parse(
    log_path: str = "",
    file_path: str = "",
) -> List[dict]:
    """
    解析 PONY log 文件，返回 List[dict]，每项与 D02 单组内参 YAML 同构。

    入参：log_path 或 file_path（log 文件路径，二选一）。
    """
    path = log_path or file_path
    if not path:
        raise ValueError("PONY requires log_path or file_path")
    import os

    if not os.path.isfile(path):
        raise FileNotFoundError(f"Log file not found: {path}")

    cameras = _parse_pony_log(path)
    result: List[dict] = []
    for _name, info in cameras.items():
        frame_id = info.get("frame_id", "").strip()
        data = info.get("data", [])
        if not frame_id or len(data) != 512:
            continue
        try:
            result.append(_camera_data_to_d2_item(frame_id, data))
        except (ValueError, IndexError):
            continue
    return result
