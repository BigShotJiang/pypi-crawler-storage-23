# -*- coding: utf-8 -*-
"""
统一内参条目的 dict 结构说明，与 D02 单组 intrinsic YAML 一致。

每条内参为 dict，结构示例：
  - frame_id: str
  - model_type: str  # "PINHOLE" | "FISHEYE"
  - pinhole: { "width": int, "height": int, "intrinsic": [9 floats], "distortion": [4|8 floats] }
    或 fisheye: 同上
  - 可选: serial_no, rms 等扩展字段
"""

from typing import Any, Dict, List

# 单条内参 dict 与 D02 intrinsic 单组 YAML 同构
IntrinsicItemDict = Dict[str, Any]


def intrinsic_item_to_d2_format(
    frame_id: str,
    model_type: str,
    width: int,
    height: int,
    intrinsic: List[float],
    distortion: List[float],
    use_pinhole: bool = True,
    extra: Dict[str, Any] | None = None,
) -> IntrinsicItemDict:
    """构造与 D02 单组内参 YAML 同构的 dict。"""
    item: IntrinsicItemDict = {
        "frame_id": frame_id,
        "model_type": model_type,
        "pinhole" if use_pinhole else "fisheye": {
            "width": width,
            "height": height,
            "intrinsic": list(intrinsic),
            "distortion": list(distortion),
        },
    }
    if extra:
        item.update(extra)
    return item
