from __future__ import annotations

import os
from typing import Any
from typeguard import typechecked
from functools import wraps
from .webapi import WebApiClient, Events
from .exceptions import NotRegisteredError, StateError
from .templates import init_template, toolaccess_template

class Job:
    """
    Do not initialize manually!
    Always use :func:`ToolAccess.job` to create instances of this class.
    """
    @typechecked
    def __init__(self, name: str, param_names: list[str], tool_access: ToolAccess) -> None:
        self.name = name
        self._tool_access = tool_access
        self._param_names = param_names

    def __call__(self, *args, **kwargs) -> Any:
        provided_arg_count = len(args) + len(kwargs)
        if provided_arg_count != len(self._param_names):
            raise TypeError(f"{self.__class__.__name__}.__call__() takes {len(self._param_names)} "
                            f"arguments but {provided_arg_count} were given")
        params: dict[str, Any] = {}
        # positional arguments
        for arg_name, pos_arg in zip(self._param_names, args):
            params[arg_name] = pos_arg

        # keyword arguments
        for kwarg_name, value in kwargs.items():
            if kwarg_name not in self._param_names:
                raise TypeError(f"{self.__class__.__name__}.__call__() got an "
                                f"unexpected keyword argument '{kwarg_name}'")
            if kwarg_name in params:
                raise TypeError(f"{self.__class__.__name__}.__call__() got "
                                f"multiple values for argument'{kwarg_name}'")
            params[kwarg_name] = value
        return self._tool_access._call(self, params)


class _VarBase:
    """
    Do not initialize manually!
    Baseclass for :class:`ModelVar`, :class:`MeasVar`, :class:`CalibVar`
    and :class:`BusSignal`
    """
    @typechecked
    def __init__(self, name: str, tool_access: ToolAccess):
        self.name = name
        self._tool_access = tool_access

    def read(self):
        return self._tool_access._read(self)

    def write(self, value: str | int | float | list | tuple | None):
        return self._tool_access._write(self, value)


class ModelVar(_VarBase):
    """
    Do not initialize manually!
    Always use :func:`ToolAccess.model_var` to create instances of this class.
    """


class BusSignal(_VarBase):
    """
    Do not initialize manually!
    Always use :func:`ToolAccess.bus_signal` to create instances of this class.
    """


class MeasVar(_VarBase):
    """
    Do not initialize manually!
    Always use :func:`ToolAccess.meas_var` to create instances of this class.
    """


class CalibVar(_VarBase):
    """
    Do not initialize manually!
    Always use :func:`ToolAccess.calib_var` to create instances of this class.
    """


def _require_state(state_requirements: list[str]):
    def decorator(func):
        @wraps(func)
        def _impl(self, *args, **kwargs):
            if not set(state_requirements).issubset({"initialized", "running", "stopped"}):
                raise ValueError(f"Invalid state requirements: {state_requirements}")
            for state in state_requirements:
                if state == "initialized" and not self._is_initialized:
                    raise StateError("Initialize with ToolAccess.init() before calling "
                                        f"{func.__name__}")
                elif state == "running" and not self._is_running:
                    raise StateError("Start with ToolAccess.run() before calling "
                                        f"{func.__name__}")
                elif state == "stopped" and self._is_running:
                    raise StateError(f"Calling {func.__name__} is only allowed in a stopped "
                                        f"state. Either call {func.__name__} outside of the "
                                        "ToolAccess.run context manager or explicitly call "
                                        "ToolAccess.stop() before")
            return func(self, *args, **kwargs)
        return _impl
    return decorator

class ToolAccess:
    required_evts = [Events.Error, Events.Completions, Events.ToolAccessRead,
                     Events.ToolAccessCall, Events.ToolAccessWait, Events.JobSignatures,
                     Events.JobParamNames, Events.ToolAccessWrite]

    class _ContextManager:
        def __init__(self, ta: ToolAccess, func_name_to_call_on_exit: str):
            self._ta = ta
            self._func_name_to_call_on_exit = func_name_to_call_on_exit

        def __enter__(self) -> ToolAccess:
            return self._ta

        def __exit__(self, type, value, traceback):
            func = getattr(self._ta, self._func_name_to_call_on_exit)
            func()

    def __init__(self, init_timeout=10.0, request_timeout=5.0, auth_key="") -> None:
        self._client = WebApiClient(self.required_evts, init_timeout, request_timeout, auth_key)
        self._is_initialized = False
        self._is_running = False
        self._registered_jobs: dict[str, Job] = {}
        self._registered_model_vars: dict[str, ModelVar] = {}
        self._registered_bus_signals: dict[str, BusSignal] = {}
        self._registered_meas_vars: dict[str, MeasVar] = {}
        self._registered_calib_vars: dict[str, CalibVar] = {}

    @_require_state(["initialized"])
    @typechecked
    def _check_registered(self, var: ModelVar | BusSignal | MeasVar | CalibVar) -> None:
        if isinstance(var, ModelVar) and var.name in self._registered_model_vars:
            return
        if isinstance(var, BusSignal) and var.name in self._registered_bus_signals:
            return
        if isinstance(var, MeasVar) and var.name in self._registered_meas_vars:
            return
        if isinstance(var, CalibVar) and var.name in self._registered_calib_vars:
            return
        raise NotRegisteredError("Accessing unregistered variables is not allowed. "
                                 "Use the ToolAccess methods model_var(...), bus_signal(...), "
                                 "meas_var(...) or calib_var(...) to create an instance of your "
                                 "variable.")

    @_require_state(["initialized", "running"])
    @typechecked
    def _read(self, var: _VarBase) -> str | int | float | list | tuple | None:
        self._check_registered(var)
        return self._client.read(var.name)

    @_require_state(["initialized", "running"])
    @typechecked
    def _write(self, var: _VarBase, value: str | int | float | list | tuple | None) -> None:
        self._check_registered(var)
        return self._client.write(var.name, value)

    @_require_state(["initialized", "running"])
    @typechecked
    def _call(self, job: Job, params: dict[str, Any]) -> Any:
        if job.name not in self._registered_jobs:
            raise NotRegisteredError("Calling unregistered Jobs is not allowed. "
                                     "Always use ToolAccess.job() to create Job instances.")
        return self._client.call(job.name, params)

    @_require_state(["initialized", "running"])
    @typechecked
    def simu_wait(self, timeout: float | int) -> None:
        return self._client.wait(timeout)

    @_require_state(["initialized", "stopped"])
    @typechecked
    def job(self, name: str) -> Job:
        if name in self._registered_jobs:
            return self._registered_jobs[name]
        param_names = self._client.register_xa(name, "JOB")
        job = Job(name, param_names, self)
        self._registered_jobs[name] = job
        return job

    @_require_state(["initialized", "stopped"])
    @typechecked
    def bus_signal(self, name: str) -> BusSignal:
        if name in self._registered_bus_signals:
            return self._registered_bus_signals[name]
        self._client.register_xa(name, "BUS")
        bus_signal = BusSignal(name, self)
        self._registered_bus_signals[name] = bus_signal
        return bus_signal

    @_require_state(["initialized", "stopped"])
    @typechecked
    def model_var(self, name: str) -> ModelVar:
        if name in self._registered_model_vars:
            return self._registered_model_vars[name]
        self._client.register_xa(name, "MODEL")
        model_var = ModelVar(name, self)
        self._registered_model_vars[name] = model_var
        return model_var

    @_require_state(["initialized", "stopped"])
    @typechecked
    def meas_var(self, name: str) -> MeasVar:
        if name in self._registered_meas_vars:
            return self._registered_meas_vars[name]
        self._client.register_xa(name, "MEASUREMENT")
        meas_var = MeasVar(name, self)
        self._registered_meas_vars[name] = meas_var
        return meas_var

    @_require_state(["initialized", "stopped"])
    @typechecked
    def calib_var(self, name: str) -> CalibVar:
        if name in self._registered_calib_vars:
            return self._registered_calib_vars[name]
        self._client.register_xa(name, "CALIBRATION")
        calib_var = CalibVar(name, self)
        self._registered_calib_vars[name] = calib_var
        return calib_var

    def init(self) -> _ContextManager:
        """
        Establishes a connection to ecu.test. The initialized state is required to
        register new variables and jobs.

        Use this function either with the context manager:
        ```python
        with ToolAccess().init() as ta:
            ...
        ```
        Or call it explicitly:
        ```python
        ta = ToolAccess
        ta.init()
        ...
        ta.deinit()
        ```
        When calling this function explicitly :func:`ToolAccess.deinit` must be called to close
        the connection.
        """
        self._client.start()
        self._is_initialized = True
        return self._ContextManager(self, "deinit")

    @_require_state(["initialized"])
    def deinit(self):
        """
        Closes the connection to ecu.test.
        
        Only use this function if you explicitly called :func:`ToolAccess.init` before.
        """
        if self._client.is_started():
            self._client.dispose()
        self._client.stop()
        self._registered_jobs = {}
        self._registered_model_vars = {}
        self._registered_bus_signals = {}
        self._registered_meas_vars = {}
        self._registered_calib_vars = {}
        self._is_initialized = False
        self._is_running = False

    @_require_state(["initialized"])
    def run(self) -> _ContextManager:
        """
        The running state is required to read and write variables or to call jobs.
        Use this function either with the context manager:
        ```python
        with ta.run():
            my_var.read()
            ...
        ```
        Or call it explicitly:
        ```python
        ta.run()
        my_var.read()
        ...
        ta.stop()
        ```
        When calling this function explicitly :func:`ToolAccess.stop` must be called to stop
        the execution and restore defaults like overwritten model variables.
        """
        self._client.ta_init()
        self._is_running = True
        return self._ContextManager(self, "stop")

    @_require_state(["initialized", "running"])
    def stop(self) -> None:
        """
        Stops a running execution and restores defaults like overwritten model variables.
        
        Only use this function if you explicitly called :func:`ToolAccess.run` before.
        """
        self._is_running = False


def export_pyi(target_dir: str, **kwargs):
    """
    create a pyi file with job information from the running ecu.test instance.
    The target directory should be named "ecutest-stubs" and located next to your own python code
    so your IDE will use it for code completion.

    Additional arguments will be passed on to the communication module. See the
    :class:`webapi.WebApiClient` for possible arguments
    """
    with WebApiClient([Events.JobSignatures], **kwargs) as client:
        data = client.get_job_signatures()

    os.makedirs(target_dir, exist_ok=True)
    with open(os.path.join(target_dir, '__init__.pyi'), 'w', encoding="UTF-8") as init_pyi:
        for line in init_template.splitlines():
            init_pyi.write(line + "\n")
    skip = False
    with open(os.path.join(target_dir, 'toolaccess.pyi'), 'w', encoding="UTF-8") as pyi_out:
        for line in toolaccess_template.splitlines():
            if line.strip() == '## insert job classes here':
                for job_class in data['classes']:
                    pyi_out.write(job_class)
                    pyi_out.write('\n\n')
                skip = True
            elif line.strip() == '## insert job instantiation overloads here':
                for job_instantiation in data['overloads']:
                    pyi_out.write(job_instantiation)
                    pyi_out.write('\n\n')
                skip = True
            elif line.strip() == '## end':
                skip = False
                continue
            if not skip:
                pyi_out.write(line + "\n")
