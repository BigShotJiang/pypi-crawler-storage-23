import websockets
import asyncio
import json
import uuid
import logging
from typing import Any, Self, Callable, Awaitable, TypedDict
from threading import Thread
from concurrent.futures import Future
from abc import abstractmethod
from functools import wraps
from .exceptions import (SocketNotReadyError, ServerError, InvalidAuthKeyError,
                         EventNotSubscribedError, PendingRequestError, ToolAccessError)
from websockets import ClientConnection

PORT = 8999

logger = logging.getLogger()

ECUTEST_CODE_CLIENT_NAME_2025_2 = "ToolAccessLib"

class Events:
    Completions = 'Notifications.Completions'
    ConfigChanged = 'Notifications.ConfigChanged'
    ConfigurationStateChanged = 'Notifications.ConfigurationStateChanged'
    Error = 'Notifications.Error'
    ExecutionJobAdded = 'Notifications.ExecutionJobAdded'
    ExpressionFinished = 'Notifications.ExpressionFinished'
    ExpressionStarted = 'Notifications.ExpressionStarted'
    InteractiveTestStepEntered = 'Notifications.InteractiveTestStepEntered'
    InteractiveTestStepRemoved = 'Notifications.InteractiveTestStepRemoved'
    JobSignatures = 'Notifications.JobSignatures'
    LogMessagePrinted = 'Notifications.LogMessagePrinted'
    MonitoringStateChanged = 'Notifications.MonitoringStateChanged'
    StoreValueChanged = 'Notifications.StoreValueChanged'
    TestcaseChanged = 'Notifications.TestcaseChanged'
    TestcaseClosed = 'Notifications.TestcaseClosed'
    TestcaseFinished = 'Notifications.TestcaseFinished'
    TestcaseOpened = 'Notifications.TestcaseOpened'
    TestcaseStarted = 'Notifications.TestcaseStarted'
    TestStepChanged = 'Notifications.TestStepChanged'
    ToolAccessCall = 'Notifications.ToolAccessCall'
    ToolAccessWrite = 'Notifications.ToolAccessWrite'
    ToolAccessRead = 'Notifications.ToolAccessRead'
    ToolAccessWait = 'Notifications.ToolAccessWait'
    ViewChanged = 'Notifications.ViewChanged'
    JobParamNames = 'Notifications.JobParamNames'

    @classmethod
    def get_all(cls) -> list[str]:
        return [x for x in cls.__dict__.values() if isinstance(x, str)
                and x.startswith("Notifications")]


class Endpoint:
    Handshake = "handshake"
    Init = "ToolAccess.Init"
    Dispose = "ToolAccess.Dispose"
    Read = "ToolAccess.Read"
    Write = "ToolAccess.Write"
    Call = "ToolAccess.Call"
    Wait = "ToolAccess.Wait"
    Register = "ToolAccess.RegisterXA"
    JobSignatures = "ToolAccess.GetJobSignatures"
    Completions = "ToolAccess.GetCompletions"
    Subscribe = "Notifications.Subscribe"


EVENT_CMD: dict[str, str | None] = {
    Endpoint.Handshake: None,
    Endpoint.Init: None,
    Endpoint.Dispose: None,
    Endpoint.Read: Events.ToolAccessRead,
    Endpoint.Write: Events.ToolAccessWrite,
    Endpoint.Call: Events.ToolAccessCall,
    Endpoint.Wait: Events.ToolAccessWait,
    Endpoint.Register: Events.JobParamNames,
    Endpoint.JobSignatures: Events.JobSignatures,
    Endpoint.Subscribe: None,
    Endpoint.Completions: Events.Completions,
}

class CompletionItem(TypedDict):
    path: str
    info: str


class Response:
    def __init__(self, cmd: str, req_id: str, data: dict):
        self.cmd = cmd
        self.req_id = req_id
        self.data = data

    def success(self) -> bool:
        if "error" in self.data:
            if self.data["error"] == "":
                return True
        else:
            return True
        return False

    @property
    def error(self):
        return self.data.get("error")


class HandshakeResponse(Response):
    def __init__(self, cmd: str, req_id: str, data: dict):
        super().__init__(cmd, req_id, data)
        self.verified = data["verified"]

    def success(self):
        # verified session are required to subscribe to events
        return self.verified

    @property
    def error(self):
        return None if self.success() else "The provided auth key is invalid!"


class Event:
    def __init__(self, cmd: str, data: dict, endpoint: str | None):
        self.cmd = cmd
        self.data = data
        self.endpoint = endpoint

    def _matches_cmd(self, cmd: str) -> bool:
        return self.endpoint == cmd

    @abstractmethod
    def matches_req(self, request: dict) -> bool:
        raise NotImplementedError


class WaitEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Wait)
        self.result = None

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"])


class ReadEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Read)
        self.mapping = data["testcase"]["name"]
        self.result = data["testcase"]["returnDict"]["result"]

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["mapping"] == self.mapping

class WriteEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Write)
        self.mapping = data["name"]
        self.result = data["result"]

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["mapping"] == self.mapping


class CallEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Call)
        self.mapping = data["name"]
        self.result = data["result"]

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["mapping"] == self.mapping


class ErrorEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, None)
        self.error = data["error"]

    def matches_req(self, request: dict) -> bool:
        # error events should always be handled
        return True

    @property
    def result(self):
        raise ServerError(self.error)


class JobSignaturesEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.JobSignatures)
        self.call_id = data['id']
        self.result = {
            'classes': data["classes"],
            'overloads': data["overloads"]
        }

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["callId"] == self.call_id


class JobParamNamesEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Register)
        self.job_path = data["path"]
        self.result = data["paramNames"]

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["path"] == self.job_path

class ConfigStateChangedEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, None)
        self.state = data["state"]

    def matches_req(self, request: dict):
        return False

class CompletionsEvent(Event):
    def __init__(self, cmd: str, data: dict, **kwargs):
        super().__init__(cmd, data, Endpoint.Completions)
        self.search_id = data["searchId"]
        self.result: list[CompletionItem] = data["result"]

    def matches_req(self, request: dict) -> bool:
        return self._matches_cmd(request["cmd"]) and request["data"]["searchId"] == self.search_id

class ResponseParser:
    @staticmethod
    def parse(msg: dict[str, Any]):
        if msg.get("type") == "response":
            return ResponseParser._parse_response(msg)
        elif msg.get("type") == "event":
            return ResponseParser._parse_event(msg)
        else:
            logger.warning("Message of unknown type received: %s", msg)
            return None

    @staticmethod
    def _parse_response(msg: dict[str, Any]) -> Response | None:
        required_keys = ["cmd", "id", "data"]
        if not all(k in msg for k in required_keys):
            logger.warning("Malformed response: %s", msg)
            return None
        if msg["cmd"] == Endpoint.Handshake:
            return HandshakeResponse(msg["cmd"], msg["id"], msg["data"])
        return Response(msg["cmd"], msg["id"], msg["data"])

    @staticmethod
    def _parse_event(msg: dict[str, Any]):
        if msg.get("cmd") == Events.ToolAccessRead:
            return ReadEvent(**msg)
        if msg.get("cmd") == Events.ToolAccessWrite:
            return WriteEvent(**msg)
        if msg.get("cmd") == Events.ToolAccessCall:
            return CallEvent(**msg)
        if msg.get("cmd") == Events.ToolAccessWait:
            return WaitEvent(**msg)
        if msg.get("cmd") == Events.Error:
            return ErrorEvent(**msg)
        if msg.get("cmd") == Events.JobSignatures:
            return JobSignaturesEvent(**msg)
        if msg.get("cmd") == Events.JobParamNames:
            return JobParamNamesEvent(**msg)
        if msg.get("cmd") == Events.ConfigurationStateChanged:
            return ConfigStateChangedEvent(**msg)
        if msg.get("cmd") == Events.Completions:
            return CompletionsEvent(**msg)
        return None


class _RequestBuilder:
    @staticmethod
    def _create_request(cmd: str, data: dict | None = None) -> dict[str, Any]:
        request = {
            "cmd": cmd,
            "id": uuid.uuid4().hex,
            "type": "request",
            "data": {}
        }
        if data is not None:
            request["data"] = data
        return request

    @staticmethod
    def handshake(auth_key="") -> dict[str, str]:
        return _RequestBuilder._create_request(
            Endpoint.Handshake,
            {"clientName": ECUTEST_CODE_CLIENT_NAME_2025_2, "authKey": auth_key}
        )

    @staticmethod
    def init_tool_access() -> dict[str, str]:
        return _RequestBuilder._create_request(Endpoint.Init)

    @staticmethod
    def dispose() -> dict[str, str]:
        return _RequestBuilder._create_request(Endpoint.Dispose)

    @staticmethod
    def wait(timeout: float) -> dict[str, Any]:
        return _RequestBuilder._create_request(Endpoint.Wait, {"timeout": timeout})

    @staticmethod
    def read(mapping_name: str) -> dict[str, str]:
        return _RequestBuilder._create_request(Endpoint.Read, {"mapping": mapping_name})

    @staticmethod
    def write(mapping_name: str, value: str | int | float | list | tuple) -> dict:
        return _RequestBuilder._create_request(
            Endpoint.Write, {"mapping": mapping_name, "value": value},
        )

    @staticmethod
    def call(mapping_name: str, params: dict[str, Any]) -> dict[str, Any]:
        return _RequestBuilder._create_request(
            Endpoint.Call,
            {"mapping": mapping_name, "params": params}
        )

    @staticmethod
    def get_job_signatures(call_id: str) -> dict[str, str]:
        return _RequestBuilder._create_request(Endpoint.JobSignatures, {'callId': call_id})

    @staticmethod
    def subscribe_event(evt_type: str) -> dict[str, str]:
        return _RequestBuilder._create_request(Endpoint.Subscribe, {"notificationType": evt_type})

    @staticmethod
    def register(path: str, access_type: str):
        return _RequestBuilder._create_request(
            Endpoint.Register,
            {"path": path, "accessType": access_type}
        )

    @staticmethod
    def get_completions(search_id: str, access_type: str, pattern: str,
                        limit: int | None) -> dict[str, str]:
        return _RequestBuilder._create_request(
            Endpoint.Completions,
            {"searchId": search_id, "accessType": access_type, "pattern": pattern, "limit": limit}
        )

class _Callback:
    def __init__(self, callback_fn: Callable[[Event], Awaitable[None]]):
        self.id = uuid.uuid4().hex
        self.callback_fn = callback_fn

class _Request:
    def __init__(self, request: dict[str, Any]):
        self.request = request
        self.response_received = False

    def has_event(self):
        if self.request["cmd"] != Endpoint.Register or self.request["data"]["accessType"] == "JOB":
            return bool(EVENT_CMD.get(self.request["cmd"]))
        return False

class _SocketHandler(Thread):
    def __init__(self, url: str, request_timeout: float):
        # avoid blocking the user script on unexpected errors
        super().__init__(daemon=True)
        self.request_timeout = request_timeout
        self.url = url
        self._ws: ClientConnection | None = None
        self._loop = asyncio.new_event_loop()
        self._ready: Future[bool] = Future()
        self._stop_event: asyncio.Event | None = None
        self._callbacks: dict[str, list[_Callback]] = {}
        self._current_req: _Request | None = None
        self._response_result: Future[Any] = Future()

    def register_callback(self, event: str, callback_fn: Callable[[Event], Awaitable[None]]):
        def _task():
            callback = _Callback(callback_fn)
            if not self._callbacks.get(event):
                self._callbacks[event] = [callback]
            else:
                self._callbacks[event].append(callback)
            return callback.id
        self._loop.call_soon_threadsafe(_task)

    def deregister_callback(self, callback_id: str) -> None:
        def _task():
            for event, callback_list in self._callbacks.items():
                if not isinstance(callback_list, list):
                    continue
                for callback in callback_list:
                    if callback_id == callback.id:
                        callback_list.remove(callback)
                        # remove event key if there are no registered callbacks left for this event
                        if len(callback_list) == 0:
                            del self._callbacks[event]
                        return None
            raise ValueError(f"Callback with id {callback_id} not found.")
        self._loop.call_soon_threadsafe(_task)

    async def _connect(self) -> None:
        async with websockets.connect(self.url) as ws:
            self._ws = ws
            self._loop.create_task(self._recv_loop())
            self._ready.set_result(True)
            await self._stop_event.wait()
        self._loop.stop()

    async def _recv_loop(self):
        while not self._stop_event.is_set():
            try:
                # check every 2 seconds if the stop event is set
                async with asyncio.timeout(2):
                    msg: str = await self._ws.recv()
            except TimeoutError:
                continue

            # message received
            try:
                parsed_msg = ResponseParser.parse(json.loads(msg))
            except json.JSONDecodeError:
                logger.warning("Failed to decode message as JSON: %s", msg)
                continue
            if parsed_msg is None:
                logger.debug("Parsed message is None: %s", msg)
                continue

            # check for callbacks
            if (isinstance(parsed_msg, Event) and self._callbacks and
                    (matching_callbacks := self._callbacks.get(parsed_msg.cmd))):
                for callback in matching_callbacks:
                    # run the callback as separate async task
                    self._loop.create_task(callback.callback_fn(parsed_msg))

            # check if response matches last request
            if self._current_req is not None and not self._response_result.done():
                self._handle_response(parsed_msg)
        logging.info("Stop event received: stopping _recv_loop")


    def _handle_response(self, response) -> None:
        if isinstance(response, ErrorEvent):
            self._response_result.set_exception(ServerError(response.error))
            return

        if isinstance(response, Response) and response.cmd == self._current_req.request["cmd"]:
            # response matches last sent request

            if not response.success():
                if isinstance(response, HandshakeResponse):
                    self._response_result.set_exception(InvalidAuthKeyError(response.error))
                    return
                else:
                    self._response_result.set_exception(ServerError(response.error))
                    return
            elif not self._current_req.has_event():
                # last request has no event to futher wait for
                self._response_result.set_result(None)
                return
            else:
                # do not set result yet because there is a event to wait for
                self._current_req.response_received = True
                return

        if isinstance(response, Event) and response.matches_req(self._current_req.request):
            self._response_result.set_result(response.result)

    def _calc_timeout(self, request: dict[str, Any]):
        # simu_wait is predetermined to have a longer delay.
        # Add the simu_wait time to be waited to the regular timeout so that waiting for the result
        # does not run into a timeout.
        if request["cmd"] == Endpoint.Wait:
            return self.request_timeout + request["data"]["timeout"]
        return self.request_timeout

    def request(self, request: dict[str, Any]) -> Any | None:
        if not self._ready.done() or (self._ready.done() and self._ready.result() is False):
            raise SocketNotReadyError

        if self._current_req is not None:
            raise PendingRequestError

        self._current_req = _Request(request)
        self._response_result = Future()
        try:
            # send request and wait for _response_result to be set
            asyncio.run_coroutine_threadsafe(self._ws.send(json.dumps(request)), self._loop)
            result = self._response_result.result(timeout=self._calc_timeout(request))
        finally:
            self._current_req = None
        return result

    async def _send_dispose(self) -> None:
        # send dispose request without awaiting a response
        request = _RequestBuilder.dispose()
        await self._ws.send(json.dumps(request))

    def wait_until_ready(self, timeout):
        self._ready.result(timeout)

    def shutdown(self):
        # send dispose request and gracefully shut down the websocket connection
        async def set_shutdown():
            self._stop_event.set()

        asyncio.run_coroutine_threadsafe(self._send_dispose(), self._loop)
        asyncio.run_coroutine_threadsafe(set_shutdown(), self._loop)

    def run(self):
        asyncio.set_event_loop(self._loop)
        self._stop_event = asyncio.Event()
        self._loop.create_task(self._connect())
        try:
            self._loop.run_forever()
        finally:
            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()
            self._loop.run_until_complete(
                asyncio.gather(*pending, return_exceptions=True))
            self._loop.close()

def _require_started(func):
    @wraps(func)
    def _impl(self, *args, **kwargs):
        if not self.is_started():
            raise ToolAccessError(f"Run WebApiClient.start before calling {func.__name__}")
        return func(self, *args, **kwargs)
    return _impl

class WebApiClient:
    def __init__(self, subscribe_evts: str | list[str] = "all", init_timeout=10.0,
                 request_timeout=5.0, auth_key=""):
        self.__started = False
        if subscribe_evts == "all":
            self.subscribe_evts = Events.get_all()
        else:
            self.subscribe_evts = subscribe_evts
        self._socket: _SocketHandler | None = None
        self.__init_timeout = init_timeout
        self._request_timeout = request_timeout
        self.__auth_key = auth_key

    @_require_started
    def _subscribe_events(self) -> None:
        for evt in self.subscribe_evts:
            self._socket.request(_RequestBuilder.subscribe_event(evt))

    @_require_started
    def _handshake(self) -> None:
        self._socket.request(_RequestBuilder.handshake(self.__auth_key))

    def _check_subscribed(self, evt: str):
        if evt not in self.subscribe_evts:
            raise EventNotSubscribedError(evt)

    def start(self):
        self._socket = _SocketHandler(f"ws://localhost:{PORT}", self._request_timeout)
        self._socket.start()
        self._socket.wait_until_ready(self.__init_timeout)
        self.__started = True
        self._handshake()
        self._subscribe_events()

    def stop(self):
        if self.__started:
            self._socket.shutdown()
            self._socket.join()
            self.__started = False

    def is_started(self) -> bool:
        return self.__started

    @_require_started
    def ta_init(self):
        request = _RequestBuilder.init_tool_access()
        return self._socket.request(request)

    @_require_started
    def get_job_signatures(self) -> list:
        self._check_subscribed(Events.JobSignatures)
        request_id = uuid.uuid4()
        request = _RequestBuilder.get_job_signatures(str(request_id))
        return self._socket.request(request)

    @_require_started
    def read(self, mapping_name: str) -> str | int | float | list | tuple | None:
        self._check_subscribed(Events.ToolAccessRead)
        request = _RequestBuilder.read(mapping_name)
        return self._socket.request(request)

    @_require_started
    def write(self, mapping_name: str, value: str | int | float | list | tuple) -> None:
        request = _RequestBuilder.write(mapping_name, value)
        return self._socket.request(request)

    @_require_started
    def call(self, mapping_name: str, params: dict[str, Any]) -> Any:
        self._check_subscribed(Events.ToolAccessCall)
        request = _RequestBuilder.call(mapping_name, params)
        return self._socket.request(request)

    @_require_started
    def wait(self, timeout: float | int) -> None:
        self._check_subscribed(Events.ToolAccessWait)
        request = _RequestBuilder.wait(float(timeout))
        return self._socket.request(request)

    @_require_started
    def register_xa(self, path: str, access_type: str) -> list[str]:
        self._check_subscribed(Events.JobParamNames)
        request = _RequestBuilder.register(path, access_type)
        return self._socket.request(request)

    @_require_started
    def get_completions(self, access_type: str, pattern: str,
                        limit: int | None = 50) -> list[CompletionItem]:
        self._check_subscribed(Events.Completions)
        search_id = uuid.uuid4().hex
        request = _RequestBuilder.get_completions(search_id, access_type, pattern, limit)
        return self._socket.request(request)

    @_require_started
    def dispose(self) -> None:
        return self._socket.request(_RequestBuilder.dispose())

    @_require_started
    def register_callback(self, event: str, callback_fn: Callable[[Event], Awaitable[None]]) -> str:
        if event not in Events.get_all():
            raise ValueError(f"Unknown event: {event}")
        self._check_subscribed(event)
        return self._socket.register_callback(event, callback_fn)

    @_require_started
    def deregister_callback(self, callback_id: str) -> None:
        self._socket.deregister_callback(callback_id)

    def __enter__(self) -> Self:
        self.start()
        return self

    def __exit__(self, type, value, traceback):
        self.stop()
