import os
import requests
import testguide_report_generator as tgr
import time
import warnings
import tempfile
import shutil
import re

from pytest import Item, TestReport, Parser, Session
from typing import Literal, TypedDict
from pathlib import Path


REPORT_NAME = "testguideReport"
REPORT_DIR_NAME = ".report"

VERDICT_UNINITIALIZED = "uninitialized"

OPT_SKIP_SSL_VERIFICATION = "--skip-testguide-ssl"
OPT_UPLOAD_TO_TG = "--upload-to-testguide"
OPT_EXPORT_TG_REPORT = "--export-testguide-report"

INI_REQEST_TIMEOUT = "testguide_request_timeout"
INI_SKIP_SSL_VERIFICATION = "skip_testguide_ssl"
INI_ENABLE_VERDICT_NONE = "enable_verdict_none"

class TestCaseData(TypedDict):
    """
    Used to collect data for a test case (test function) across different pytest hooks.
    This data is then finally transferred into a test.guide TestCase object in another hook.
    """
    name: str
    node_id: str
    docstring: str
    module: str
    steps: list[tgr.TestStep]
    timestamp: int
    duration: int # seconds
    params: list[tgr.Parameter]
    properties: list[tuple[str, object]]
    verdict: Literal["passed", "failed", "skipped", "uninitialized"] | None
    stdout: str
    stderr: str
    log: str


class TestGuidePytest:
    def __init__(self):
        self._test_cases: dict[str, TestCaseData] = {}
        self._initial_time_ms = self._timestamp_ms()
        self._tg_suite: tgr.TestSuite | None =  None
        self._cwd: str = ""
        self._enable_verdict_none: bool = False


    @staticmethod
    def _timestamp_ms() -> int:
        """Returns current timestamp in ms"""
        return int(time.time() * 1000)


    @staticmethod
    def _shorten_str(s: str, max_len: int=120) -> str:
        """Shortens the input string if it exceeds the length max_len"""
        if len(s) <= max_len:
            return s
        return f"{s[:max_len-3]}..."


    @staticmethod
    def _map_verdict(
        verdict: Literal["passed", "failed", "skipped", "uninitialized"] | None
    ) -> tgr.Verdict:
        """Maps a pytest outcome to a test.guide Verdict"""
        if verdict == "passed":
            return tgr.Verdict.PASSED
        elif verdict == "failed":
            return tgr.Verdict.FAILED
        elif verdict == "skipped":
            return tgr.Verdict.INCONCLUSIVE
        elif verdict == VERDICT_UNINITIALIZED: # execution was probably interrupted
            return tgr.Verdict.ERROR
        elif verdict is None:
            return tgr.Verdict.NONE
        else:
            raise ValueError(f"Unknown Verdict: {verdict}")


    @staticmethod
    def _get_tc_name(node_id: str) -> str:
        """Removes function arguments from node_id if present"""
        return node_id.rsplit('[', 1)[0]


    @staticmethod
    def _clean_str(s: str) -> str:
        """
        Removes unprintable (unicode) characters from a given string.
        Leaving them included will lead to errors when uploading the report to test.guide
        """
        return "".join(c for c in s if c.isprintable() or c == "\n")


    @staticmethod
    def _build_ts_desc(item: Item, lineno: int, orig: str, expl: str) -> str:
        """
        Generates a detailed description that is displayed on mouse hover over the
        test step in test.guide
        """
        return f"""{TestGuidePytest._get_tc_name(item.nodeid)}:{lineno}

        original assertion:
        ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        {orig}

        assertion explanation:
        ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        {expl}"""

    @staticmethod
    def _sanitize_file_name(path: str) -> str:
        """Replaces characters that are invalid for file system paths with _"""
        return re.sub(r"[^A-Za-z0-9\[\]\(\)._-]", "_", path)

    def _get_module_names(self) -> list[str]:
        """Returns a list of module names included in the current test run"""
        return list({tc["module"] for tc in self._test_cases.values()})


    def _build_test_suites(self) -> dict[str, tgr.TestSuite]:
        """
        Builds a dict with Python module names as keys and an empty TestSuite as value.
        Each module is thus assigned its own TestSuite.
        """
        module_names = self._get_module_names()
        test_suites: dict[str, tgr.TestSuite] = {}
        for module_name in module_names:
            test_suites[module_name] = tgr.TestSuite(
                name=module_name,
                timestamp=self._initial_time_ms
            )
        return test_suites


    def _add_test_cases_to_suites(self, suites: dict[str, tgr.TestSuite], report_dir: str) -> None:
        """Adds all the collected test cases to the corresponding TestSuite"""
        for test_case in self._test_cases.values():
            suites[test_case["module"]].add_testcase(
                testcase=self._build_test_case(test_case, report_dir)
            )


    def _build_test_case(self, test_case_data: TestCaseData, report_dir: str) -> tgr.TestCase:
        """
        Builds a test.guide TestCase object from the TestCaseData collected during test execution.
        In case the TestCase has captured stdout, stderr or logs this captured data will be written
        into a file which will then be added as an artifact to the TestCase.
        """
        tg_test_case = tgr.TestCase(
            name=test_case_data["name"],
            timestamp=test_case_data["timestamp"],
            verdict=self._map_verdict(test_case_data["verdict"]),
        )
        for test_step in test_case_data["steps"]:
            tg_test_case.add_execution_teststep(test_step)
        for prop in test_case_data["properties"]:
            tg_test_case.add_attribute_pair(prop[0], repr(prop[1]))
        tg_test_case.add_parameter_set("", test_case_data["params"])
        tg_test_case.set_execution_time_in_sec(test_case_data["duration"])
        if test_case_data["docstring"]:
            tg_test_case.set_description(test_case_data["docstring"])

        test_case_dir = os.path.join(
            report_dir,
            test_case_data["module"],
            self._sanitize_file_name(test_case_data["node_id"])
        )

        def _add_log(log_type: Literal["stdout", "stderr", "log"]):
            with open(os.path.join(test_case_dir, f"{log_type}.log"), "w", encoding="utf-8") as f:
                f.write(test_case_data[log_type])
            tg_test_case.add_artifact(os.path.join(test_case_dir, f"{log_type}.log"))

        if test_case_data["stdout"]:
            _add_log("stdout")
        if test_case_data["stderr"]:
            _add_log("stderr")
        if test_case_data["log"]:
            _add_log("log")

        return tg_test_case

    def _build_report_dir(self, report_dir: str) -> None:
        """
        Creates the directory structure for the report directory.
        For test cases (test functions) that have captured stdout, stderr, or logs, an additional
        directory will be added to the module_name's directory, which will be used to save the
        log files later. The names of the test case folders correspond to the pytest node id, since,
        for example, in the case of parameterized test execution, multiple log captures can be
        generated for one test case.

        ```
        .report
        └── module_name
            ├── test_equal_x_1
            ├── test_equal_x_2
            └── test_unequal
        ```
        """
        os.mkdir(report_dir)
        for module_name in self._get_module_names():
            os.mkdir(os.path.join(report_dir, module_name))

        for node_id, test_case in self._test_cases.items():
            if not any([test_case["stdout"], test_case["stderr"], test_case["log"]]):
                continue

            test_case_dir = os.path.join(report_dir, test_case["module"],
                                         self._sanitize_file_name(node_id))
            os.mkdir(test_case_dir)


    def _export_test_suites(
        self, test_suites: dict[str, tgr.TestSuite], report_dir: str
    ) -> list[str]:
        """
        Exports the Reports in the following directory structure:

        ```
        .report/
        └── module_name
            ├── module_name.json
            └── module_name.zip
        ```
        Returns a list of absolute paths to the .zip report files.
        """
        zip_paths: list[str] = []

        for module_name, suite in test_suites.items():
            export_path = os.path.join(report_dir, module_name, module_name)
            tgr.Generator(suite).export(export_path + ".json")
            zip_paths.append(os.path.abspath(export_path + ".zip"))
        return zip_paths


    @staticmethod
    def _ensure_environ_vars() -> None:
        """
        Ensures that the required environment variables are set.
        Otherwise a LookupError is raised.
        """
        test_guide_url = os.environ.get("TESTGUIDE_URL")
        if not test_guide_url:
            raise LookupError("Missing environment variable TESTGUIDE_URL, should be set "
                              "to something like http://your.test-guide.instance:8085")
        if not os.environ.get("TESTGUIDE_PROJECT_ID"):
            raise LookupError("Missing environment variable TESTGUIDE_PROJECT_ID, should "
                              "be set to the id number of your project in test.guide")
        if not os.environ.get("TESTGUIDE_AUTH_KEY"):
            raise LookupError("Missing environment variable TESTGUIDE_AUTH_KEY, should be "
                              "set to one of your authentication keys - maybe you first "
                              f"need to create one under {test_guide_url}/user/authkeys")


    def _tg_post_report(self, report: str, skip_ssl: bool, req_timeout: float) -> str:
        with open(report, "rb") as fp:
            upload_data = fp.read()
        upload_url = f"{os.environ.get("TESTGUIDE_URL")}/api/report/reports"
        params = {"projectId": os.environ.get("TESTGUIDE_PROJECT_ID"), "converterId": "json2atx"}
        headers = {"Content-Type": "application/zip",
                    "Accept": "application/json",
                    "TestGuide-AuthKey": os.environ.get("TESTGUIDE_AUTH_KEY")}

        response = requests.post(
            url=upload_url,
            params=params,
            data=upload_data,
            headers=headers,
            verify=(not skip_ssl),
            timeout=req_timeout,
        )
        response.raise_for_status()
        return response.json().get("taskId")


    def _tg_wait_task_completed(self, task_id: str, skip_ssl: bool, req_timeout: float) -> None:
        wait_endpoint = (f"{os.environ.get("TESTGUIDE_URL")}/"
                         f"api/report/reports/uploadstatus/{task_id}")
        wait_headers = {"Accept": "application/json",
                        "TestGuide-AuthKey": os.environ.get("TESTGUIDE_AUTH_KEY")}
        wait_params = {"projectId": os.environ.get("TESTGUIDE_PROJECT_ID")}
        while True:
            response = requests.get(
                url=wait_endpoint,
                headers=wait_headers,
                params=wait_params,
                verify=(not skip_ssl),
                timeout=req_timeout,
            )
            response.raise_for_status()
            json_response = response.json()
            if json_response.get("status") == "finished":
                if json_response.get("uploadResult").get("uploadReturnCode") >= 400:
                    msg = json_response.get("uploadResult").get("resultMessages")
                    raise RuntimeError(f"Upload failed: {msg}")
                break
            time.sleep(1.0)


    def _upload_reports(self, skip_ssl: bool, req_timeout: float, reports: list[str]) -> None:
        self._ensure_environ_vars()
        task_ids = []
        for report in reports:
            task_id = self._tg_post_report(report, skip_ssl, req_timeout)
            task_ids.append(task_id)

        for task_id in task_ids:
            self._tg_wait_task_completed(task_id, skip_ssl, req_timeout)


    # ------------
    # PYTEST HOOKS
    # ------------

    def pytest_addoption(self, parser: Parser, pluginmanager):
        parser.addoption(
            OPT_UPLOAD_TO_TG,
            help="Upload the report to test.guide",
            action='store_true',
            default=False
        )
        parser.addoption(
            OPT_EXPORT_TG_REPORT,
            help="Saves the test.guide report files to the current directory",
            action="store_true",
            default=False
        )
        parser.addoption(
            OPT_SKIP_SSL_VERIFICATION,
            help="Skip SSL verification when uploading test results to test.guide",
            action="store_true",
            default=False
        )
        parser.addini(
            name=INI_SKIP_SSL_VERIFICATION,
            help="Skip SSL verification when uploading test results to test.guide",
            type="bool",
            default=False
        )
        parser.addini(
            name=INI_REQEST_TIMEOUT,
            help="The request timeout for an REST API call to test.guide in seconds",
            type="string",
            default="20.0"
        )
        parser.addini(
            name=INI_ENABLE_VERDICT_NONE,
            help=("Test cases with the outcome 'Passed' having no assertion will be"
                  "reported as verdict 'None' in the test.guide report"),
            type="bool",
            default=False
        )

    def pytest_sessionstart(self, session: Session):
        # Save the directory from which pytest.main was invoked
        self._cwd = str(session.config.invocation_params.dir)
        self._enable_verdict_none = bool(session.config.getini(INI_ENABLE_VERDICT_NONE))

    def pytest_runtest_protocol(self, item: Item):
        self._test_cases[item.nodeid] = {
            "name": item.name,
            "node_id": item.nodeid,
            "docstring": getattr(item.obj, "__doc__", ""),
            "module": item.module.__name__,
            "steps": [],
            "timestamp": self._timestamp_ms(),
            "duration": 0,
            "params": [],
            "properties": [],
            "verdict": VERDICT_UNINITIALIZED,
            "stdout": "",
            "stderr": "",
            "log": "",
        }

    def pytest_assertion_pass(self, item: Item, lineno: int, orig: str, expl: str) -> None:
        ts = tgr.TestStep(
            name=self._shorten_str(f"line {lineno}: {orig.strip()}"),
            verdict=tgr.Verdict.PASSED,
        )
        ts.set_description(self._build_ts_desc(
            item, lineno, orig, expl))
        self._test_cases[item.nodeid]["steps"].append(ts)

    def pytest_runtest_call(self, item: Item)  -> None:
        if hasattr(item, "funcargs"):
            for arg_name, arg_val in item.funcargs.items():
                value = arg_val if isinstance(arg_val, (str, int)) else repr(arg_val)
                param = tgr.Parameter(
                    name=str(arg_name),
                    value=value,
                    direction=tgr.Direction.IN
                )
                self._test_cases[item.nodeid]["params"].append(param)

    def pytest_runtest_logreport(self, report: TestReport) -> None:
        # skip 'setup' and 'teardown'
        if report.when != "call":
            return

        test_case = self._test_cases[report.nodeid]

        test_case["verdict"] = report.outcome
        if self._enable_verdict_none and not test_case["steps"]:
            test_case["verdict"] = None
        test_case["duration"] = int(report.duration)
        test_case["stdout"] = report.capstdout
        test_case["stderr"] = report.capstderr
        test_case["log"] = report.caplog

        if report.user_properties is None:
            test_case["properties"] = []
        else:
            test_case["properties"] = report.user_properties

        # TODO: report exceptions as ERROR
        if report.failed:
            if hasattr(report.longrepr, "reprcrash"):
                crash = report.longrepr.reprcrash  # type: ignore
                lineno = crash.lineno
                message = crash.message
                ts = tgr.TestStep(
                    name=self._shorten_str(f"line {lineno}: {message}"),
                    verdict=tgr.Verdict.FAILED
                )
                # add message again to description as it might be shortened in the test step name
                ts.set_description(f"{report.nodeid}:{lineno}\n{message}")
            else:
                lineno = report.location[1]
                message = str(report.longrepr).strip().splitlines()[-1]
                description = report.nodeid
                if lineno is not None:
                    description += f":{lineno}"
                    message = f"line {lineno}: {message}"
                ts = tgr.TestStep(self._shorten_str(message), tgr.Verdict.FAILED)
                # add message again to description as it might be shortened in the test step name
                ts.set_description(description + f"\n{message}")
            test_case["steps"].append(ts)


    def pytest_sessionfinish(self, session: Session, exitstatus: int):
        # skip test.guide upload if there is no data to upload
        if not self._test_cases and session.config.getoption(OPT_UPLOAD_TO_TG):
            warnings.warn("Skipping test.guide upload because no tests were collected.")
            return

        if (not session.config.getoption(OPT_UPLOAD_TO_TG) and
            not session.config.getoption(OPT_EXPORT_TG_REPORT)):
            return

        with tempfile.TemporaryDirectory() as tmp_dir:

            report_dir = os.path.join(tmp_dir, REPORT_DIR_NAME)
            self._build_report_dir(report_dir)
            test_suites = self._build_test_suites()
            self._add_test_cases_to_suites(test_suites, report_dir)
            report_files = self._export_test_suites(test_suites, report_dir)

            if session.config.getoption(OPT_EXPORT_TG_REPORT):
                user_report_dir = os.path.join(self._cwd, ".report")
                if os.path.exists(user_report_dir):
                    shutil.rmtree(user_report_dir)
                shutil.copytree(report_dir, user_report_dir, dirs_exist_ok=True)

            if not session.config.getoption(OPT_UPLOAD_TO_TG):
                return

            # SSL Verification is skipped if specified in the ini or if the command
            # line parameter was provided
            skip_ssl_verification = bool(
                session.config.getini(INI_SKIP_SSL_VERIFICATION)
                or session.config.getoption(OPT_SKIP_SSL_VERIFICATION)
            )

            req_timeout = 20.0
            if cfg_req_timeout := session.config.getini(INI_REQEST_TIMEOUT):
                assert isinstance(cfg_req_timeout, str)
                try:
                    req_timeout = float(cfg_req_timeout)
                except ValueError:
                    warnings.warn(f"Invalid value for pytest config {INI_REQEST_TIMEOUT}: "
                                  f"{cfg_req_timeout}. Defaulting to {req_timeout} seconds.")

            self._upload_reports(skip_ssl_verification, req_timeout, report_files)



plugin = TestGuidePytest()
