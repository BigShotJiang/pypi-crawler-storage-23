class ToolAccessError(Exception):
    """
    Base class for all exceptions defined by toolaccess.
    """
class SocketNotReadyError(ToolAccessError):
    """
    Raised if the client attempts to send before the connection to the server is established.
    """

class ActiveSessionError(ToolAccessError):
    """
    Raised if another ToolAccess Session is currently active.
    """
class InvalidAuthKeyError(ToolAccessError):
    """
    Raised when the provided auth key does not match the password defined in the
    ecu.test drive workspace settings.
    """
class ServerError(ToolAccessError):
    """
    Raised if an exception is thrown on the server side.
    This exception includes the traceback of the server.
    """

class StateError(ToolAccessError):
    """
    Raised when a method is called that requires a specific ToolAccess state which is not satisfied. 
    E.g. registering a bus signal before having intialized `ToolAccess` with
    :func:`ToolAccess.init`.
    """

class EventNotSubscribedError(ToolAccessError):
    """
    Raised if a WebApiClient function is called that requires an event, but this event
    has not been subscribed to.
    """

class PendingRequestError(ToolAccessError):
    """
    Raised if :func:`WebApiClient.request` is called but there still is a pending request.
    """

class NotRegisteredError(ToolAccessError):
    """
    Raised when a job is called which was not registered with :func:``ToolAccess.job` before.
    """
