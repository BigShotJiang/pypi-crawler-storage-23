class EcuTestCodeError(Exception):
    """
    Base class for all exceptions of this Python library.
    """

class SocketNotReadyError(EcuTestCodeError):
    """
    Raised when the client attempts to send before the connection to ecu.test is established.
    """

class AuthenticationError(EcuTestCodeError):
    """
    Raised when ecu.test could not verify the client.
    """

class RemoteError(EcuTestCodeError):
    """
    Raised when ecu.test raised an exception while handling a request of ecu.test code.
    This Exception contains the remote ecu.test traceback.
    """

class StateError(EcuTestCodeError):
    """
    Raised when a method requires a specific ToolAccess or WebApiClient state that is not satisfied
    e.g., registering a bus signal before :func:`ecutest.toolaccess.ToolAccess.init` was called.
    """

class EventNotSubscribedError(EcuTestCodeError):
    """
    Raised when a :class:`ecutest.webapi.WebApiClient` method requires a notification event,
    but the corresponding event type has not been subscribed.

    Fix: provide the required event(s) via the `WebApiClient(subscribe_evts=...)` constructor
    (or use `'all'`, the default). See :class:`ecutest.webapi.Events` for available event names.
    """
    def __init__(self, event: str):
        super().__init__(
            "Subscribe to the following event before calling this function: " + event
        )

class PendingRequestError(EcuTestCodeError):
    """
    Raised when another request is still in flight and a new request is issued.

    Only a single in-flight request is supported. Wait for the current operation to
    finish and then retry, serialize calls, or use a second client instance for
    parallel requests (Note: running multiple ToolAccess sessions concurrently is not
    supported at the moment).
    """

class NotRegisteredError(EcuTestCodeError):
    """
    Raised when attempting to call a job or access a variable that was not registered through
    :class:`ecutest.toolaccess.ToolAccess`. Use :func:`ecutest.toolaccess.ToolAccess.job`,
    :func:`ecutest.toolaccess.ToolAccess.bus_signal`,
    :func:`ecutest.toolaccess.ToolAccess.model_var`,
    :func:`ecutest.toolaccess.ToolAccess.meas_var`, or
    :func:`ecutest.toolaccess.ToolAccess.calib_var` to create registered instances.
    """

class IncompatibleVersionError(EcuTestCodeError):
    """
    Raised when versions of ecu.test and ecu.test code are not compatible.
    """
    def __init__(self, ecu_test_version: str, ecu_test_code_version):
        super().__init__(
            f"Versions of ecu.test {ecu_test_version} and ecu.test code {ecu_test_code_version} are not compatible."
        )
