from contextlib import contextmanager
import importlib.metadata
import json
import os
import subprocess
import sys
from pathlib import Path
import time
from requests import get, put
from xmlrpc.client import ServerProxy

__version__ = "0.0.0"  # Default version, will be overwritten below
try:
    __version__ = importlib.metadata.version("ecutest_code")
except importlib.metadata.PackageNotFoundError:  # running from source
    import configparser

    cfg = configparser.RawConfigParser(strict=False)
    cfg.read_file(
        open(os.path.join(os.path.dirname(__file__), "..", "..", "pyproject.toml"))
    )
    __version__ = cfg["tool.poetry"]["version"]
    del cfg, configparser

if not isinstance(__version__, str):
    raise AssertionError("__version__ is not of type str")


class EcuTestController:
    """
    A controller for managing the lifecycle of an ecu.test runner instance to be used by
    ecu.test code.

    :param executable: The path to the ecu.test runner executable. If :const:`None`, the
                        constructor will try to find a suitable ecu.test runner executable.
    :param xmlrpc_port: The xmlrpc port to use. If the executable is auto-detected, this will
                        also be auto-detected. If the executable is specified explicitly and
                        you are using a non-default port, you must specify it here. Otherwise,
                        the default port 8000 will be used.
    :param restapi_port: The REST API port to use.
    :param silent: suppress all output from called external commands.
    """

    __all__ = [
        "start",
        "stop",
        "running_ecutest",
        "start_webapi",
        "is_webapi_active",
        "get_running_ecutest_version",
        "get_running_ecutest_install_dir",
        "get_current_workspace",
        "get_loaded_tbc",
        "get_loaded_tcf",
        "is_config_started",
        "kill",
    ]

    def __init__(
        self,
        executable: str | os.PathLike | None = None,
        xmlrpc_port: int | None = None,
        restapi_port: int = 5050,
        silent: bool = False,
    ):
        # docstring: see class level
        self._default_stdout = subprocess.DEVNULL if silent else None
        self._default_stderr = subprocess.DEVNULL if silent else None
        self._registry_key = None
        self._restapi_port = restapi_port
        if executable is None:
            if xmlrpc_port is not None:
                raise ValueError(
                    "If you specify an executable, you must not specify an xmlrpc port."
                )
            if sys.platform == "win32":
                executable = self._find_windows_executable()
                self._xmlrpc_port = self._get_xmlrpc_port()
            else:  # Linux
                executable = self._find_linux_executable()
                self._xmlrpc_port = 8000
        else:
            self._xmlrpc_port = xmlrpc_port or 8000
        if executable is None:
            raise FileNotFoundError(
                "No suitable ecu.test runner executable found, please explicity specify one."
            )
        self._executable: str = str(executable)
        self._version = self._determine_version()

    def _find_windows_executable(self) -> str | None:
        candidates: dict[str, tuple[str, str]] = {}
        products = []
        for root in ("HKLM", "HKCU"):
            try:
                products += subprocess.check_output(
                    ["reg", "query", f"{root}\\Software\\tracetronic"],
                    encoding="UTF-8",
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                ).splitlines()
            except subprocess.CalledProcessError:
                pass
        for product_line in products:
            if "ecu.test" not in product_line:
                continue
            version = product_line.strip().split(" ")[-1]
            if version < "2025.3":
                continue
            try:
                for path_line in subprocess.check_output(
                    ["reg", "query", product_line.strip(), "/v", "Path"],
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    encoding="UTF-8",
                ).splitlines():
                    if "REG_SZ" not in path_line:
                        continue
                    install_dir = path_line.split("REG_SZ")[1].strip()
                    executable = os.path.join(install_dir, "ecu.test_runner.exe")
                    if os.path.isfile(executable):
                        candidates[executable] = (version, product_line.strip())
            except subprocess.CalledProcessError:
                continue
        if not candidates:
            return None
        newest = next(iter(candidates.items()))
        for executable, (version, registry_key) in candidates.items():
            if version > newest[1][0]:
                newest = (executable, version)
            if version.split(".")[0:2] == __version__.split(".")[0:2]:
                self._registry_key = registry_key
                return executable
        self._registry_key = newest[1][1]
        return newest[0]

    def _find_linux_executable(self) -> str | None:
        candidates: dict[str, str] = {}
        for install_dir in Path("/opt").glob("ecu.test*"):
            version = os.path.basename(install_dir).split("-")[-1]
            if version < "2025.3":
                continue
            executable = os.path.join(install_dir, "ecu.test_runner-starter")
            if os.path.isfile(executable):
                candidates[executable] = version
        if os.path.islink("/usr/bin/ecu.test"):
            candidate = os.path.realpath("/usr/bin/ecu.test")
            if "runner" not in candidate:
                candidate = candidate.replace("-starter", "_runner-starter")
            if os.path.isfile(candidate):
                candidates[candidate] = (
                    "9999.9"  # Use a high version to prefer this candidate
                )
        if not candidates:
            return None
        newest = next(iter(candidates.items()))
        for executable, version in candidates.items():
            if version > newest[1]:
                newest = (executable, version)
            if version.split(".")[0:2] == __version__.split(".")[0:2]:
                return executable
        return newest[0]

    def _get_xmlrpc_port(self) -> int:
        if sys.platform == "win32":
            if self._registry_key is not None:
                try:
                    for line in subprocess.check_output(
                        ["reg", "query", self._registry_key, "/v", "xmlrpcPort"],
                        encoding="UTF-8",
                        stderr=subprocess.DEVNULL,
                        stdin=subprocess.DEVNULL,
                    ).splitlines():
                        if "REG_DWORD" in line:
                            return int(line.split("REG_DWORD")[1].strip(), 0)
                except subprocess.CalledProcessError:
                    pass
            return 8000
        else:
            try:
                xdg_config_home = os.environ.get(
                    "XDG_CONFIG_HOME", os.path.join(os.path.expanduser("~"), ".config")
                )
                settings = json.load(
                    open(
                        os.path.join(
                            xdg_config_home,
                            "tracetronic",
                            f"ecu.test {self._version}",
                            "installationsettings.json",
                            "r",
                        ),
                        encoding="UTF-8",
                    )
                )
                return int(settings.get("xmlrpcPort", 8000))
            except (FileNotFoundError, json.JSONDecodeError):
                return 8000

    def _determine_version(self) -> str | None:
        install_dir = os.path.dirname(os.path.realpath(self._executable))
        if sys.platform == "win32":
            suffix = ".exe"
        else:
            suffix = "_runner"

        try:
            version = subprocess.check_output(
                [os.path.join(install_dir, f"tool_server{suffix}"), "--version"],
                encoding="ASCII",
                errors="replace",
            ).strip()
            parts = version.split(".")
            return ".".join(parts[0:2])
        except Exception as e:
            raise RuntimeError(
                f"Could not determine version of ecu.test installation at "
                f"{install_dir}"
            ) from e

    def _is_ecutest_running(self, _tries=3) -> bool:
        try:
            get(f"http://127.0.0.1:{self._restapi_port}/api/v2/live", timeout=3)
            return True
        except Exception:
            try:
                get(f"http://127.0.0.1:{self._xmlrpc_port}/", timeout=3)
            except Exception:
                return False
            else:
                if _tries > 0:
                    # xmlrpc becomes ready some time before REST does,
                    # so retry to rule out that case. Since on windows
                    # the failed connect attempt takes 2 seconds, but on linux
                    # it returns immediately, we need to use different wait times:
                    if sys.platform == "win32":
                        time.sleep(0.5)
                    else:
                        time.sleep(2.5)
                    return self._is_ecutest_running(_tries - 1)
                raise RuntimeError(
                    f"ecu.test is apparently running, but the REST API "
                    f"is using a different port than {self._restapi_port}."
                )

    def _is_restart_needed(self, workspace: str | None) -> str | None:
        if (
            not Path(self._executable)
            .resolve()
            .is_relative_to(
                Path(
                    self.get_running_ecutest_install_dir() or "/no_installdir"
                ).resolve()
            )
        ):
            return "the wrong executable"
        if (workspace is not None) and (
            Path(self.get_current_workspace() or "/no_workspace").resolve()
            != Path(workspace).resolve()
        ):
            return "in the wrong workspace"
        return None

    def _load_config(
        self, tbc: str | os.PathLike | None, tcf: str | os.PathLike | None
    ) -> None:
        if (
            (
                (tbc is not None)
                and (
                    Path(self.get_loaded_tbc() or "/no_tbc").resolve()
                    != Path(tbc).resolve()
                )
            )
            or (
                (tcf is not None)
                and (
                    Path(self.get_loaded_tcf() or "/no_tcf").resolve()
                    != Path(tcf).resolve()
                )
            )
            or (any([tbc, tcf]) and self.is_config_started() == False)
        ):
            put(
                f"http://127.0.0.1:{self._restapi_port}/api/v2/configuration",
                json={
                    "action": "start",
                    "tcf": {"tcfPath": tcf},
                    "tbc": {"tbcPath": tbc},
                },
                timeout=3,
            )
            while True:
                time.sleep(0.3)
                data = get(
                    f"http://127.0.0.1:{self._restapi_port}/api/v2/configuration",
                ).json()
                if data["status"]["key"] == "ERROR":
                    raise RuntimeError(
                        f"Failed to start configuration: {data['status']['message']}"
                    )
                elif data["status"]["key"] == "FINISHED":
                    return
        else:
            return

    def start(
        self,
        workspace: str | os.PathLike | None = None,
        tbc: str | os.PathLike | None = None,
        tcf: str | os.PathLike | None = None,
        extra_args: list[str] | None = None,
        allow_restart: bool = False,
        accept_any_version: bool = False,
    ):
        """
        Start ecu.test runner in the specified workspace, load the specified testbench
        configuration (TBC) and test configuration (TCF), and start the web API.

        If an appropriate ecu.test instance is already running in the correct workspace,
        the running instance will be used.

        :param workspace: The workspace directory to use. If :const:`None`, no workspace will be
                          specified on the command line, causing ecu.test runner to start in the
                          most recently used workspace.
        :param tbc: The testbench configuration file to load. If :const:`None`, no TBC will be
                    explicitly loaded, so the one that happens to be loaded or to have been loaded
                    in the most recent session in this workspace will be used.
        :param tcf: The test configuration file to load. If :const:`None`, no TCF will be
                    explicitly loaded, so the one that happens to be loaded or to have been loaded
                    in the most recent session in this workspace will be used.
        :param extra_args: Additional command line arguments to pass to the ecu.test runner. Note
                           that these won't be taken into account when deciding whether a restart
                           is needed.
        :param allow_restart: Determines whether an already running instance of ecu.test may be
                              restarted if the workspace or the version/executable doesn't match.
        :param accept_any_version: If :const:`True`, a running instance will be used regardless of
                                   its version or excecutable, provided it is running in the
                                   correct workspace. In case of a restart as well as for any later
                                   start, that instance's runner executable will be used instead of
                                   the one specified in the constructor call or automatically
                                   determined by the constructor.

        """
        args = [self._executable, "--startupAutomated=True"]
        if self._restapi_port != 5050:
            args += ["--restApiPort", str(self._restapi_port)]
        if workspace is not None:
            workspace = str(workspace)
            args += ["--workspaceDir", workspace]
        if self._is_ecutest_running():
            if accept_any_version:
                install_dir = self.get_running_ecutest_install_dir()
                if install_dir is None:
                    raise AssertionError(
                        "ecu.test is running, but no install dir could be determined."
                    )
                self._executable = os.path.join(
                    install_dir,
                    (
                        "ecu.test_runner.exe"
                        if sys.platform == "win32"
                        else "ecu.test_runner-starter"
                    ),
                )
            if reason := self._is_restart_needed(workspace):
                if not allow_restart:
                    raise RuntimeError(
                        f"ecu.test is already running, but {reason}. If you don't want to use the "
                        f"running instance, quit it or specify allow_restart=True."
                    )
                print(f"ecu.test is already running, but {reason}, restarting it.")
                self.stop()
            else:
                if not self.is_webapi_active():
                    self.start_webapi()
            if self._is_ecutest_running():  # not stopped for restart
                self._load_config(tbc, tcf)
                return
        args += extra_args or []
        args.append("--start-web-api")
        popen_kwargs: dict = {"stdin": subprocess.DEVNULL,
                              "stdout": self._default_stdout,
                              "stderr": self._default_stderr}
        if sys.platform == "win32":
            popen_kwargs["creationflags"] = (
                subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_BREAKAWAY_FROM_JOB
            )
            startup_info = subprocess.STARTUPINFO()
            startup_info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startup_info.wShowWindow = subprocess.SW_HIDE
            popen_kwargs["startupinfo"] = startup_info
        else:
            popen_kwargs["start_new_session"] = True
        popen = subprocess.Popen(args, **popen_kwargs)
        while not self._is_ecutest_running():
            if popen.poll() is not None:
                raise RuntimeError(
                    f"ecu.test runner process exited unexpectedly "
                    f"with code {popen.returncode}"
                )
            time.sleep(0.1)
        subprocess.run(
            [self._executable, "-w"],
            check=True,
            stdin=subprocess.DEVNULL,
            stdout=self._default_stdout,
            stderr=self._default_stderr,
        )
        self._load_config(tbc, tcf)

    def stop(self, timeout: int = 90):
        """
        Ask the ecu.test runner instance to quit gracefully.

        :param timeout: The maximum time to wait for the ecu.test instance to stop before an exception is raised.

        This also acts on instances not started by this lifecycle controller.
        """
        subprocess.run(
            [self._executable, "--quit"],
            check=False,
            stdin=subprocess.DEVNULL,
            stdout=self._default_stdout,
            stderr=self._default_stderr,
        )
        before = time.monotonic()
        while time.monotonic() - before < timeout:
            if not self._is_ecutest_running():
                return
            time.sleep(0.1)
        raise RuntimeError("ecu.test did not exit within the specified timeout.")

    @contextmanager
    def running_ecutest(
        self,
        workspace: str | os.PathLike | None = None,
        tbc: str | os.PathLike | None = None,
        tcf: str | os.PathLike | None = None,
        extra_args: list[str] | None = None,
        allow_restart: bool = False,
        accept_any_version: bool = False,
        stop_on_exit: bool | None = None,
    ):
        """
        Context manager to ensure that an ecu.test instance is running in the specified
        workspace with the specified TBC and TCF.

        :param stop_on_exit: If :const:`True`, the ecu.test instance will be stopped when the
                             context manager exits.

                             If :const:`False`, the ecu.test instance will be left running.

                             If :const:`None`, the instance will be stopped if it was started
                             (or restarted) by this context manager, but left running if an already
                             running instance was used.

        :see: :meth:`~start` for the other parameters.
        """
        if stop_on_exit is None:
            stop_on_exit = (not self._is_ecutest_running()) or (
                self._is_restart_needed(str(workspace)) is not None
            )
        self.start(
            workspace=workspace,
            tbc=tbc,
            tcf=tcf,
            extra_args=extra_args,
            allow_restart=allow_restart,
            accept_any_version=accept_any_version,
        )
        try:
            yield
        finally:
            if stop_on_exit:
                self.stop()

    def start_webapi(self):
        """
        Start the ecu.test web API in an already running ecu.test instance.

        If ecu.test is not running, use the :meth:`~start` method instead.
        """
        if not self._is_ecutest_running():
            raise RuntimeError(
                "ecu.test runner is apparently not running. "
                "Please start it with start() or manually."
            )
        subprocess.run(
            [self._executable, "--start-web-api"],
            check=True,
            stdin=subprocess.DEVNULL,
            stdout=self._default_stdout,
            stderr=self._default_stderr,
        )

    def is_webapi_active(self) -> bool:
        """
        Check if the ecu.test web API is active.
        This returns :const:`False` if either ecu.test is not running or the web API is not active.
        """
        try:
            get("http://127.0.0.1:8999", timeout=3)
            return True
        except Exception:
            return False

    def get_running_ecutest_version(self) -> str | None:
        """
        Get the version of the currently running ecu.test instance.
        If ecu.test is not running, this returns :const:`None`.
        """
        # is_ecutest_running uses the REST API, so actual use of the REST API makes it superfluous
        data = get(
            f"http://127.0.0.1:{self._restapi_port}/api/v2/info/version", timeout=3
        ).json()
        if "version" in data:
            return data["version"]
        elif data.get("status", None) == 404:
            return "<unknown, lower than 2025.3>"
        else:
            return None

    def get_running_ecutest_install_dir(self) -> str | None:
        """
        Get the install directory of the currently running ecu.test instance.
        If ecu.test is not running, this returns :const:`None`.
        """
        # TODO: port to REST API as soon as suitable functionality is available
        try:
            return str(
                ServerProxy(f"http://127.0.0.1:{self._xmlrpc_port}").GetInstallDir()
            )
        except Exception:
            return None

    def get_current_workspace(self) -> str | None:
        """
        Determine the workspace the currently running ecu.test instance is using.
        If ecu.test is not running, this returns :const:`None`.
        """
        # TODO: port to REST API as soon as suitable functionality is available
        try:
            return str(
                ServerProxy(f"http://127.0.0.1:{self._xmlrpc_port}").GetSetting(
                    "workspacePath"
                )
            )
        except Exception:
            return None

    def get_loaded_tbc(self) -> str | None:
        """
        Determine the testbench configuration (TBC) the currently running ecu.test instance
        is using.
        Note that the configuration might be selected but not started,
        cf. :meth:`~is_config_started`.
        If ecu.test is not running, this returns :const:`None`.
        """
        # TODO: port to REST API as soon as suitable functionality is available
        try:
            return str(
                ServerProxy(
                    f"http://127.0.0.1:{self._xmlrpc_port}"
                ).CurrentTestbenchConfiguration.GetFilename()
            )
        except Exception:
            return None

    def get_loaded_tcf(self) -> str | None:
        """
        Determine the test configuration (TCF) the currently running ecu.test instance is using.
        Note that the configuration might be selected but not started,
        cf. :meth:`~is_config_started`.
        If ecu.test is not running, this returns :const:`None`.
        """
        # TODO: port to REST API as soon as suitable functionality is available
        try:
            return str(
                ServerProxy(
                    f"http://127.0.0.1:{self._xmlrpc_port}"
                ).CurrentTestConfiguration.GetFilename()
            )
        except Exception:
            return None

    def is_config_started(self) -> bool:
        """
        Check whether in the running ecu.test instance, the configuration is started.
        If ecu.test is not running, this returns :const:`False`.
        """
        # TODO: port to REST API as soon as suitable functionality is available
        try:
            return bool(
                ServerProxy(f"http://127.0.0.1:{self._xmlrpc_port}").IsConfigStarted()
            )
        except Exception:
            return False

    def kill(self, timeout: int = 30):
        """
        Ask the ecu.test runner instance to quit immediately.

        :param timeout: The maximum time to wait for the ecu.test instance to quit before hard-killing it.

        This also acts on instances not started by this lifecycle controller.
        """
        subprocess.run(
            [self._executable, "--kill"],
            check=False,
            stdin=subprocess.DEVNULL,
            stdout=self._default_stdout,
            stderr=self._default_stderr,
        )
        before = time.monotonic()
        while time.monotonic() - before < timeout:
            if not self._is_ecutest_running():
                return
            time.sleep(0.1)
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/F", "/IM", "ecu.test_runner.exe"],
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=self._default_stdout,
                stderr=self._default_stderr,
            )
            subprocess.run(
                ["taskkill", "/F", "/IM", "ecu.test.exe"],
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=self._default_stdout,
                stderr=self._default_stderr,
            )
        else:
            subprocess.run(
                ["killall", "-9", "ecu.test_runner"],
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=self._default_stdout,
                stderr=self._default_stderr,
            )
            subprocess.run(
                ["killall", "-9", "ecu.test"],
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=self._default_stdout,
                stderr=self._default_stderr,
            )
