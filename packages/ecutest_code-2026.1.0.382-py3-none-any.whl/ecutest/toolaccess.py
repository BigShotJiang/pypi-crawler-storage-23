from __future__ import annotations

import os
from enum import IntEnum
from typing import Any, Literal, TypeAlias, cast
from typeguard import typechecked
from functools import wraps
from .webapi import PackageResult, WebApiClient, Events
from .exceptions import NotRegisteredError, StateError
from .templates import init_template, toolaccess_template

class _CallBase:
    """
    Do not initialize manually!
    Baseclass for call access like :class:`Job` and :class:`DiagVar`
    """
    @typechecked
    def __init__(self, name: str, param_names: list[str], tool_access: ToolAccess) -> None:
        self.name = name
        self._tool_access = tool_access
        self._param_names = param_names

    def __call__(self, *args, **kwargs) -> Any:
        # The user should only see this docstring if there are no job overloads present.
        """Calls the ecu.test callable."""
        provided_arg_count = len(args) + len(kwargs)
        if provided_arg_count != len(self._param_names):
            raise TypeError(f"{self.__class__.__name__}.__call__() takes {len(self._param_names)} "
                            f"arguments but {provided_arg_count} were given")
        params: dict[str, Any] = {}
        # positional arguments
        for arg_name, pos_arg in zip(self._param_names, args):
            params[arg_name] = pos_arg

        # keyword arguments
        for kwarg_name, value in kwargs.items():
            if kwarg_name not in self._param_names:
                raise TypeError(f"{self.__class__.__name__}.__call__() got an "
                                f"unexpected keyword argument '{kwarg_name}'")
            if kwarg_name in params:
                raise TypeError(f"{self.__class__.__name__}.__call__() got "
                                f"multiple values for argument '{kwarg_name}'")
            params[kwarg_name] = value
        return self._tool_access._call(self, params)

class Job(_CallBase):
    """Represents a callable ecu.test job.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.job` to
       create instances of this class.
    """
    def __call__(self, *args, **kwargs) -> Any:
        # The user should only see this docstring if there are no job overloads present.
        """
        Invoke the ecu.test job with the specified arguments.
        """
        return super().__call__(*args, **kwargs)

class DiagVar(_CallBase):
    """Represents a callable ecu.test diagnostic service.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.diag_var` to
       create instances of this class.
    """

    def __call__(self, *args, **kwargs) -> Any:
        # The user should only see this docstring if there are no overloads present.
        """Calls the ecu.test diag service, allows "param" keyword with a dict structure."""
        params: dict[str, Any] = {}
        if len(args) == 1:
            params = args[0]
        elif len(args) > 1:
            raise TypeError(f"{self.__class__.__name__}.__call__() takes at most 1 positional "
                            f"argument but {len(args)} were given")

        if kwargs.keys() - {'param'}:
            unexpected_keys = kwargs.keys() - {'param'}
            raise TypeError(f"{self.__class__.__name__}.__call__() got unexpected keyword "
                            f"arguments: {', '.join(unexpected_keys)}")

        if 'param' in kwargs:
            if not isinstance(kwargs['param'], dict):
                raise TypeError(f"{self.__class__.__name__}.__call__() 'param' keyword argument "
                                f"must be of type dict")
            params.update(kwargs['param'])

        return self._tool_access._call(self, params)

class _VarBase:
    """
    Do not initialize manually!
    Baseclass for :class:`ModelVar`, :class:`MeasVar`, :class:`CalibVar`
    and :class:`BusSignal`
    """
    @typechecked
    def __init__(self, name: str, tool_access: ToolAccess):
        self.name = name
        self._tool_access = tool_access

    def read(self) -> str | int | float | list | tuple | None:
        """Read the current value of this variable from ecu.test.

        :returns: The value of the variable.
        :raises NotRegisteredError: If the variable was not registered via :class:`ToolAccess`.
        :raises RemoteError: If an error occurs in ecu.test while reading this variable.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        return self._tool_access._read(cast(VarType, self))

    def write(self, value: str | int | float | list | tuple | None) -> None:
        """Write a new value to this variable in ecu.test.

        :param value: The value to assign.
        :raises NotRegisteredError: If the variable was not registered via :class:`ToolAccess`.
        :raises RemoteError: If an error occurs in ecu.test while writing this variable.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        return self._tool_access._write(cast(VarType, self), value)

    def _register_for_recording(self, recording_id: Any) -> None:
        """Registers this variable for recording

        :raises NotRegisteredError: If the variable was not registered via :class:`ToolAccess
        :raises RemoteError: If an error occurs in ecu.test while registering this variable for recording.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        self._tool_access._register_for_recording(cast(VarType, self), recording_id)

class ModelVar(_VarBase):
    """Represents a model variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.model_var` to
       create instances of this class.
    """


class BusSignal(_VarBase):
    """Represents a bus signal in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.bus_signal` to
       create instances of this class.
    """


class MeasVar(_VarBase):
    """Represents a measurement variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.meas_var` to
       create instances of this class.
    """


class CalibVar(_VarBase):
    """Represents a calibration variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.calib_var` to
       create instances of this class.
    """

VarType: TypeAlias = BusSignal | ModelVar | MeasVar | CalibVar
CallType: TypeAlias = Job | DiagVar


class ExecutionResult(IntEnum):
    """Represents the result of an execution of a package in ecu.test."""
    NONE = 0
    SUCCESS = 1
    INCONCLUSIVE = 2
    FAILED = 4
    ERROR = 8

def _require_state(state_requirements: list[str]):
    def decorator(func):
        @wraps(func)
        def _impl(self, *args, **kwargs):
            if not set(state_requirements).issubset({"initialized", "running", "stopped"}):
                raise ValueError(f"Invalid state requirements: {state_requirements}")
            for state in state_requirements:
                if state == "initialized" and not self._is_initialized:
                    raise StateError("Initialize with ToolAccess.init() before calling "
                                        f"{func.__name__}")
                elif state == "running" and not self._is_running:
                    raise StateError("Start with ToolAccess.run() before calling "
                                        f"{func.__name__}")
                elif state == "stopped" and self._is_running:
                    raise StateError(f"Calling {func.__name__} is only allowed in a stopped "
                                        f"state. Either call {func.__name__} outside of the "
                                        "ToolAccess.run context manager or explicitly call "
                                        "ToolAccess.stop() before")
            return func(self, *args, **kwargs)
        return _impl
    return decorator

class Package():
    """Interface for packages.

    You can preprocess and postprocess a package and run it.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.package` to
       create instances of this class.

    """
    def __init__(self, ta: ToolAccess, package_path: str) -> None:
        self._ta = ta
        self._package_path = package_path
 
    def run(self, params: dict[str, Any] | None = None) -> PackageResult:
        """Run the package.

        :param params: Optional dictionary of parameter values for the package.
        """
        return self._ta._run_package(self._package_path, params)

    def preprocess(self) -> None:
        """Preprocesses the package before calling it.

        .. warning::
           It is not requiered to call this method manually. Preprocessing is done automatically.

        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        """
        return self._ta._preprocess_package(self._package_path)

    def postprocess(self) -> None:
        """Postprocesses the package after calling it.

        .. warning::
           It is not requiered to call this method manually. Postprocessing is done automatically.

        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        """
        return self._ta._postprocess_package(self._package_path)

class Recording:
    """Interface for recording signals.

    You can stop and start a recording multiple times.

    If you stop and re-run the ToolAccess, recordings for which finish() has not been called,
    are lost.
    """
    def __init__(self, ta: ToolAccess, dest_file: str, vars: list[VarType]) -> None:
        self._ta = ta
        self._dest_file = os.path.abspath(dest_file)
        for var in vars:
            self._ta._register_for_recording(var, id(self))

    def start(self) -> None:
        """Starts the recording. This requires ToolAccess to be in the running state."""
        self._ta._start_recording(id(self))

    def stop(self) -> None:
        """Stops the recording. This requires ToolAccess to be in the running state.

        All recordings are also automatically stopped when the ToolAccess itself is stopped.
        """
        self._ta._stop_recording(id(self))

    def finish(self) -> list[dict[str, list[str] | str]]:
        """Finalizes the recording and makes the recorded file(s) available.
        This requires ToolAccess to be in the initialized and stopped state.

        :returns: Information about the recordings:
                    [{'files: [...], 'type': ...}, ...]
                    Each list element corresponds to one start/stop pair.
                    One recording typically consists of only one file, but in rare cases
                    it can be split across several files.

        """
        return self._ta._finish_recording(id(self), self._dest_file)


class ToolAccess:
    """Interface for interacting with ecu.test jobs and variables in user-defined Python code.

    A :class:`ToolAccess` instance manages connection lifecycle, registration of jobs and
    variables, and execution state transitions (*uninitialized* <-> *initialized* <->
    *running*).

    Typical usage::

        ta = ToolAccess()                       # unitialized state
        with ta.init():                         # enter initialized state
            job = ta.job("PORT/SomeJob")        # register job
            var = ta.model_var("Model/Value")   # register variable
            with ta.run():                      # enter running state
                result = job(1, 2)              # call job
                current = var.read()            # read variable
                var.write(42)                   # write variable
            # by leaving the run context, ta falls back into the initialized state
        # by leaving the init context, ta falls back into the unitialized state

    The factory methods (:meth:`job`, :meth:`model_var`, :meth:`meas_var`, :meth:`calib_var`,
    :meth:`bus_signal`) can only be invoked in the *initialized* state.
    :meth:`read`, :meth:`write`, :meth:`call` and :meth:`simu_wait` operations require the
    *running* state.

    :param init_timeout: Maximum time (in seconds) to wait for establishing
        a connection to ecu.test.
    :param request_timeout: Per-request timeout (in seconds) for API calls (read, write,
        job calls, ...). You might want to increase this value e.g. when using
        long-running jobs.
    """
    required_evts = [Events.Error, Events.Completions, Events.ToolAccessRead,
                     Events.ToolAccessCall, Events.ToolAccessWait, Events.JobSignatures,
                     Events.JobParamNames, Events.ToolAccessWrite, Events.RecordingVarRegistered,
                     Events.RecordingStarted, Events.RecordingStopped, Events.RecordingFinished,
                     Events.PackageFinished, Events.PackagePreProcessed, Events.PackagePostProcessed]

    class _ContextManager:
        def __init__(self, ta: ToolAccess, func_name_to_call_on_exit: str):
            self._ta = ta
            self._func_name_to_call_on_exit = func_name_to_call_on_exit

        def __enter__(self) -> ToolAccess:
            return self._ta

        def __exit__(self, type, value, traceback):
            func = getattr(self._ta, self._func_name_to_call_on_exit)
            func()

    def __init__(self, init_timeout: float = 10.0, request_timeout: float = 10.0) -> None:
        self._client = WebApiClient(
            subscribe_evts=self.required_evts,
            init_timeout=init_timeout,
            request_timeout=request_timeout,
            dispose_on_shutdown=True,
        )
        self._is_initialized: bool = False
        self._is_running: bool = False
        self._registered_jobs: dict[str, Job] = {}
        self._registered_packages: dict[str, Package] = {}
        self._registered_model_vars: dict[str, ModelVar] = {}
        self._registered_bus_signals: dict[str, BusSignal] = {}
        self._registered_meas_vars: dict[str, MeasVar] = {}
        self._registered_calib_vars: dict[str, CalibVar] = {}
        self._registered_diag_vars: dict[str, DiagVar] = {}

    @_require_state(["initialized"])
    @typechecked
    def _check_registered(self, var: VarType) -> None:
        if isinstance(var, ModelVar) and var.name in self._registered_model_vars:
            return
        if isinstance(var, BusSignal) and var.name in self._registered_bus_signals:
            return
        if isinstance(var, MeasVar) and var.name in self._registered_meas_vars:
            return
        if isinstance(var, CalibVar) and var.name in self._registered_calib_vars:
            return
        if isinstance(var, Package) and var.name in self._registered_packages:
            return
        raise NotRegisteredError("Accessing unregistered variables is not allowed. "
                                 "Use the ToolAccess methods model_var(...), bus_signal(...), "
                                 "meas_var(...) or calib_var(...) to create an instance of your "
                                 "variable.")

    @_require_state(["initialized", "running"])
    @typechecked
    def _read(self, var: VarType) -> str | int | float | list | tuple | None:
        self._check_registered(var)
        return self._client.read(var.name)

    @_require_state(["initialized", "running"])
    @typechecked
    def _write(self, var: VarType, value: str | int | float | list | tuple | None) -> None:
        self._check_registered(var)
        return self._client.write(var.name, value)

    @_require_state(["initialized", "stopped"])
    @typechecked
    def _register_for_recording(self, var: VarType, recording_id: int) -> None:
        self._check_registered(var)
        self._client.register_var_for_recording(var.name, recording_id)

    @_require_state(["initialized", "running"])
    @typechecked
    def _start_recording(self, recording_id: int) -> None:
        self._client.start_recording(recording_id)

    @_require_state(["initialized", "running"])
    @typechecked
    def _stop_recording(self, recording_id: int) -> None:
        self._client.stop_recording(recording_id)

    @_require_state(["initialized", "stopped"])
    @typechecked
    def _finish_recording(self, recording_id: int, dest_file: str) -> list[dict[str, list[str] | str]]:
        return self._client.finish_recording(recording_id, dest_file)

    @_require_state(["initialized", "running"])
    @typechecked
    def _call(self, call_var: CallType, params: dict[str, Any]) -> Any:
        name = call_var.name
        if name not in self._registered_jobs and name not in self._registered_diag_vars:
            raise NotRegisteredError(f"Calling unregistered {type(call_var)}s is not allowed. "
                                     "Always use ToolAccess.job() to create Job instances.")
        return self._client.call(name, params)

    @_require_state(["initialized", "running"])
    @typechecked
    def _preprocess_package(self, package_path: str) -> None:
        self._client.preprocess_package(package_path)

    @_require_state(["initialized", "running"])
    @typechecked
    def _postprocess_package(self, package_path: str) -> None:
        self._client.postprocess_package(package_path)

    @_require_state(["initialized", "running"])
    @typechecked
    def _run_package(self, package_path: str, package_params: dict[str, Any] | None = None) -> PackageResult:
        return self._client.run_package(package_path, package_params)

    @_require_state(["initialized", "running"])
    @typechecked
    def simu_wait(self, timeout: float | int) -> None:
        """Waits the specified amount of time based on the active time basis in ecu.test
        (model time or system time).

        :param timeout: Time to wait in seconds.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        return self._client.wait(timeout)

    @_require_state(["initialized", "stopped"])
    @typechecked
    def job(self, name: str) -> Job:
        """Create and register an ecu.test job. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        :param name: Fully qualified job name.
        :returns: A registered :class:`Job` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_jobs:
            return self._registered_jobs[name]
        param_names = self._client.register_xa(name, "JOB")
        if not isinstance(param_names, list):
            raise AssertionError("param_names is not of type list")
        job = Job(name, param_names, self)
        self._registered_jobs[name] = job
        return job

    @_require_state(["initialized", "stopped"])
    @typechecked
    def package(self, package_path: str) -> Package:
        """Create and register an ecu.test package. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        There are some restrictions on the test steps used in the package. Many test steps do not
        make sense when the package is called from ecu.test code, and some could even cause
        problems. Therefore:
            - Currently, calling sub-packages is not allowed at all. This restriction might get
              loosened in the future.
            - Test steps that open any kind of dialog during their execution are not allowed
              because ecu.test code is intended to run without user interaction.
            - Test steps related to parallel packages or Inbox/Outbox variables are not allowed
              because parallelism should be handled in the python script.
            - Test steps "Report", "Log File Entry", "Assertion", and "Exit", as well as
              "Precondition" and "Postcondition" are not allowed because they only make sense when
              the entire test case is handled inside ecu.test.
            - "Start/Stop/Add Trace", "Set Trace Comment", as well as "Request Analysis" and
              "Incorporate trace step result" are not allowed because the trace analysis part of
              the package isn't executed.
            - "Start/Stop Stimulus", user-defined utilities, various tool specific test steps,
              and EES / FIU test steps are currently not allowed.

        Packages containing such test steps cannot be used in this way at all.

        :param package_path: Path to the package.
        :returns: A registered :class:`Package` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if package_path in self._registered_packages:
            return self._registered_packages[package_path]
        self._client.register_xa(package_path, "PACKAGE")

        package = Package(self, package_path)
        self._registered_packages[package_path] = package
        return package

    @_require_state(["initialized", "stopped"])
    @typechecked
    def diag_var(self, name: str) -> DiagVar:
        """Create and register an ecu.test diagnostic service variable. Repeated calls with the
        same name parameter return the already registered instance and do not trigger an
        additional registration on the ecu.test side.

        :param name: Fully qualified diagnostic service name. The name must include the control
            unit identifier as defined in the test configuration and the diagnostic service name.
            Example: Engine/Read_data_by_identifier.
        :returns: A registered :class:`DiagVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_diag_vars:
            return self._registered_diag_vars[name]
        self._client.register_xa(name, "DIAG")
        diag_var = DiagVar(name, ['param'], self)  # parameters to be added later
        self._registered_diag_vars[name] = diag_var
        return diag_var

    @_require_state(["initialized", "stopped"])
    @typechecked
    def bus_signal(self, name: str) -> BusSignal:
        """Create and register an ecu.test bus signal. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        :param name: Fully qualified signal name (path).
        :returns: A registered :class:`BusSignal` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_bus_signals:
            return self._registered_bus_signals[name]
        self._client.register_xa(name, "BUS")
        bus_signal = BusSignal(name, self)
        self._registered_bus_signals[name] = bus_signal
        return bus_signal

    @_require_state(["initialized", "stopped"])
    @typechecked
    def model_var(self, name: str) -> ModelVar:
        """Create and register an ecu.test model variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified model variable name (path).
        :returns: A registered :class:`ModelVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_model_vars:
            return self._registered_model_vars[name]
        self._client.register_xa(name, "MODEL")
        model_var = ModelVar(name, self)
        self._registered_model_vars[name] = model_var
        return model_var

    @_require_state(["initialized", "stopped"])
    @typechecked
    def meas_var(self, name: str) -> MeasVar:
        """Create and register an ecu.test measurement variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified measurement variable name (path).
        :returns: A registered :class:`MeasVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_meas_vars:
            return self._registered_meas_vars[name]
        self._client.register_xa(name, "MEASUREMENT")
        meas_var = MeasVar(name, self)
        self._registered_meas_vars[name] = meas_var
        return meas_var

    @_require_state(["initialized", "stopped"])
    @typechecked
    def calib_var(self, name: str) -> CalibVar:
        """Create and register an ecu.test calibration variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified calibration variable name (path).
        :returns: A registered :class:`CalibVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        if name in self._registered_calib_vars:
            return self._registered_calib_vars[name]
        self._client.register_xa(name, "CALIBRATION")
        calib_var = CalibVar(name, self)
        self._registered_calib_vars[name] = calib_var
        return calib_var

    @_require_state(["initialized", "stopped"])
    def recording(self, dest_file: str, vars: list[VarType]) -> Recording:
        """Create a recording instance for the specified variables.

        :param dest_file: Destination file path for the recording. Relative paths are interpreted as relative to
                            the current working directory of the script process.
                          A type-appropriate extension is automatically added, and if the file already exists,
                            extra characters are added to make it unique.
        :param vars: List of variables to record

        Note: All variables must be realized via a single `port` in ecu.test. Otherwise, the port
              used by the majority of variables will be selected, and variables not realized via
              that port will not be recorded.
        :returns: A Recording instance
        """
        return Recording(self, dest_file, vars)

    def init(self) -> ToolAccess._ContextManager:
        """Initialize the connection to ecu.test.

        The *initialized* state is required before registering jobs or variables. Can be
        used as a context manager which will automatically invoke :meth:`deinit` when leaving
        the context::

            with ToolAccess().init() as ta:
                job = ta.job("PORT/Job")
                ...

        Alternatively call it explicitly and later :meth:`deinit`::

            ta = ToolAccess()
            ta.init()
            job = ta.job("PORT/Job")
            ...
            ta.deinit()

        :raises AuthenticationError: If ecu.test can not verify this client.
        :raises TimeoutError: If ecu.test does not respond within the configured init timeout.
        """
        self._client.start()
        self._is_initialized = True
        return self._ContextManager(self, "deinit")

    @_require_state(["initialized"])
    def deinit(self):
        """Close the connection to ecu.test and reset all registered variables and jobs.
        After calling this methode :class:`ToolAccess` falls back into the *initialized* state.

        .. info::

           This method should only be called when :meth:`init` was called explicitly before.

        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        """
        if self._client.is_started():
            self._client.dispose()
        self._client.stop()
        self._registered_jobs = {}
        self._registered_model_vars = {}
        self._registered_bus_signals = {}
        self._registered_meas_vars = {}
        self._registered_calib_vars = {}
        self._registered_packages = {}
        self._is_initialized = False
        self._is_running = False

    @_require_state(["initialized"])
    def run(self) -> ToolAccess._ContextManager:
        """Enter the *running* state required for read / write / job calls / simu_wait.

        Usable as a context manager which automatically invokes :meth:`stop` after leaving
        the context::

            with ta.run():
                value = var.read()
                ...

        Or explicitly::

            ta.run()
            my_var.read()
            ...
            ta.stop()

        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        self._client.ta_init()
        self._is_running = True
        for package in self._registered_packages.values():
            package.preprocess()

        return self._ContextManager(self, "stop")

    @_require_state(["initialized", "running"])
    def stop(self) -> None:
        """Exit the *running* state and fall back into the *initialized* state. Depending on the
        used tools, this can restore defaults for variables which were altered during the *running*
        state.

        .. info::

           This method should only be called when :meth:`run` was called explicitly before.

        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        """
        for package in self._registered_packages.values():
            package.postprocess()

        self._is_running = False


def export_pyi(target_dir: str, **kwargs):
    """
    :meta private:

    Create a pyi file with job information from the running ecu.test instance.
    The target directory should be named "ecutest-stubs" and located next to your own python code
    so your IDE will use it for code completion.

    Additional arguments will be passed on to the communication module. See the
    :class:`webapi.WebApiClient` for possible arguments
    """
    with WebApiClient([Events.JobSignatures], **kwargs) as client:
        data = client.get_job_signatures()

    os.makedirs(target_dir, exist_ok=True)
    with open(os.path.join(target_dir, '__init__.pyi'), 'w', encoding="UTF-8") as init_pyi:
        for line in init_template.splitlines():
            init_pyi.write(line + "\n")
    skip = False
    with open(os.path.join(target_dir, 'toolaccess.pyi'), 'w', encoding="UTF-8") as pyi_out:
        for line in toolaccess_template.splitlines():
            if line.strip() == '## insert job classes here':
                for job_class in data['classes']:
                    pyi_out.write(job_class)
                    pyi_out.write('\n\n')
                skip = True
            elif line.strip() == '## insert job instantiation overloads here':
                for job_instantiation in data['overloads']:
                    pyi_out.write(job_instantiation)
                    pyi_out.write('\n\n')
                skip = True
            elif line.strip() == '## end':
                skip = False
                continue
            if not skip:
                pyi_out.write(line + "\n")
