import json
import asyncio
import websockets
import functools
import traceback
from typing import Any
from websockets.asyncio.server import ServerConnection, Server
from websockets import serve
from threading import Thread
from tts.core.toolAccessApi.ToolAccessApi import ToolAccess, ToolAccessApi


def swallow_exception(f) -> Any:
    @functools.wraps(f)
    async def inner(*args, **kwargs):
        try:
            return await f(*args, **kwargs)
        except Exception as e:
            return e
    return inner

class ToolAccessServer:
    def __init__(self, mapping: str, port: int, tool_access: ToolAccess) -> None:
        self.mapping = mapping
        self.port = port
        # is set to true as soon as the first client has established a connection
        self.initial_connection_established = False
        self.tool_access = tool_access

    async def _serve(self) -> None:
        server = await websockets.serve(self._handler, 'localhost', self.port)
        print("server started")
        while True:
            if self.initial_connection_established and len(server.connections) == 0:
                print("all connections closed")
                server.close()
                break
            await asyncio.sleep(1.0)

    async def _handler(self, ws):
        self.initial_connection_established = True
        try:
            async for message in ws:
                try:
                    payload = json.loads(message)
                except json.JSONDecodeError:
                    print("failed to decode message")
                    continue

                if "cmd" in payload and ("mappingName" in payload or "timeout" in payload):
                    result = None
                    cmd = payload.get("cmd")
                    if cmd == "read":
                        result = await self._read(payload.get("mappingName"))
                    elif cmd == "write" and "value" in payload:
                        result = await self._write(payload.get("mappingName"), payload.get("value"))
                    elif cmd == "call" and "params" in payload:
                        result = await self._call(payload.get("mappingName"), payload.get("params"))
                    elif cmd == "simuWait" and "timeout" in payload:
                        result = await self._simu_wait(payload.get("timeout"))
                    else:
                        print(f"unknown command: {payload.get('cmd')}")
                        continue
                    response = self._format_response(result)
                    await ws.send(json.dumps(response))
        except websockets.exceptions.ConnectionClosed:
            print("connection to client was closed")
        except Exception as e:
            print(f"server expecption: {e}")

    def _format_response(self, result: Any) -> dict[str, Any]:
        if isinstance(result, Exception):
            traceback_info = traceback.format_exception(type(result), result, result.__traceback__)
            return {"exception": "".join(traceback_info)}
        else:
            return {"result": result}

    @swallow_exception
    async def _read(self, mapping_name: str) -> str | int | float | list | tuple | None:
        return self.tool_access.Read(mapping_name)

    @swallow_exception
    async def _write(self, mapping_name: str, value: str | int | float | list | tuple) -> str:
        return self.tool_access.Write(mapping_name, value)

    @swallow_exception
    async def _call(self, mapping_name: str, params: dict[str, Any]) -> Any:
        return self.tool_access.Call(mapping_name, params)

    @swallow_exception
    async def _simu_wait(self, timeout: float) -> str:
        return self.tool_access.SimuWait(timeout)

    def start(self) -> None:
        asyncio.run(self._serve())

def Main(logFolder: str, mapping_file: str, port: int) -> None:
    with ToolAccessApi().Init(mapping_file) as tool_access:
        server = ToolAccessServer(mapping_file, port, tool_access)
        server.start()
