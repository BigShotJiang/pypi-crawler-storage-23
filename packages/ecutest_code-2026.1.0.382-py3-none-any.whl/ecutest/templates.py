# These templates are used by the export_pyi function to generate job completions.
# Accessing the actual pyi file for generating job completions is not possible because the
# language server is being packaged by pyinstaller which shrinks down dependencies including
# the ecutest_code lib. This causes the actual pyi file no longer being available for the
# language server.

toolaccess_template = \
'''from collections.abc import Generator
from enum import IntEnum
from typing import Any, Literal, Self, overload, type_check_only

class Job:
    """Represents a callable ecu.test job.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.job` to
       create instances of this class.
    """

    def __call__(self, *args, **kwargs) -> Any:
        """
        Invoke the ecu.test job with the specified arguments.
        """
        ...

class DiagVar:
    """Represents a callable ecu.test diagnostic service.

    Calling this variable will execute the corresponding diagnostic service in ecu.test.
    The first argument or "param" keyword argument may be used to specify diagnostic
    parameters and values as a dictionary.
    The result of the service call will be returned as a dictionary containing the
    decodedResponseData.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.diag_var` to
       create instances of this class.
    """

    def __call__(self, *args, **kwargs) -> Any:
        """
        Invoke the diagnostic service with the specified arguments.
        """
        ...

class _VarBase:
    name: str
    def __init__(self, name: str, tool_access: ToolAccess) -> None: ...
    def read(self):
        """Read the current value of this variable from ecu.test.

        :returns: The value of the variable.
        :raises NotRegisteredError: If the variable was not registered via :class:`ToolAccess`.
        :raises RemoteError: If an error occurs in ecu.test while reading this variable.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def write(self, value: str | int | float | list | tuple | None):
        """Write a new value to this variable in ecu.test.

        :param value: The value to assign.
        :raises NotRegisteredError: If the variable was not registered via :class:`ToolAccess`.
        :raises RemoteError: If an error occurs in ecu.test while writing this variable.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

class ModelVar(_VarBase):
    """Represents a model variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.model_var` to
       create instances of this class.
    """

    ...

class BusSignal(_VarBase):
    """Represents a bus signal in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.bus_signal` to
       create instances of this class.
    """

    ...

class MeasVar(_VarBase):
    """Represents a measurement variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.meas_var` to
       create instances of this class.
    """

    ...

class CalibVar(_VarBase):
    """Represents a calibration variable in ecu.test.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.calib_var` to
       create instances of this class.
    """

    ...

class ExecutionResult(IntEnum):
    """Represents the result of an execution of a package in ecu.test."""
    ...
    NONE = 0
    SUCCESS = 1
    INCONCLUSIVE = 2
    FAILED = 4
    ERROR = 8

class PackageResult:
    """Represents the result of an execution of a package in ecu.test."""
    result_code: ExecutionResult
    return_values: None | dict[str, Any]


class Package():
    """Interface for packages.

    You can preprocess and postprocess a package and run it.

    .. warning::
       Do not instantiate this class manually! Always use :meth:`ToolAccess.package` to
       create instances of this class.
    """
    ...

    def run(self, params: dict[str, Any] | None = None) -> PackageResult:
        """Run the package.

        :param params: Optional dictionary of parameter values for the package.
        """
        ...

    def preprocess(self) -> None:
        """Preprocesses the package before calling it.

        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        """
        ...

    def postprocess(self) -> None:
        """Postprocesses the package after calling it."""
        ...

## insert job classes here
## end

class Recording:
    """Interface for recording signals.

    You can stop and start a recording multiple times.

    If you stop and re-run the ToolAccess, recordings for which finish() has not been called,
    are lost.
    """

    def start(self) -> None:
        """Starts the recording. This requires ToolAccess to be in the running state."""
        ...

    def stop(self) -> None:
        """Stops the recording. This requires ToolAccess to be in the running state.

        All recordings are also automatically stopped when the ToolAccess itself is stopped.
        """
        ...

    def finish(self) -> list[dict[str, list[str] | str]]:
        """Finalizes the recording and makes the recorded file(s) available.
        This requires ToolAccess to be in the initialized and stopped state.

        :returns: Information about the recordings:
                    [{'files: [...], 'type': ...}, ...]
                    Each list element corresponds to one start/stop pair.
                    One recording typically consists of only one file, but in rare cases
                    it can be split across several files.

        """
        ...

class ToolAccess:
    """Interface for interacting with ecu.test jobs and variables in user-defined Python code.

    A :class:`ToolAccess` instance manages connection lifecycle, registration of jobs and
    variables, and execution state transitions (*uninitialized* <-> *initialized* <->
    *running*).

    Typical usage::

        ta = ToolAccess()                       # unitialized state
        with ta.init():                         # enter initialized state
            job = ta.job("PORT/SomeJob")        # register job
            var = ta.model_var("Model/Value")   # register variable
            with ta.run():                      # enter running state
                result = job(1, 2)              # call job
                current = var.read()            # read variable
                var.write(42)                   # write variable
            # by leaving the run context, ta falls back into the initialized state
        # by leaving the init context, ta falls back into the unitialized state

    The factory methods (:meth:`job`, :meth:`model_var`, :meth:`meas_var`, :meth:`calib_var`,
    :meth:`bus_signal`) can only be invoked in the *initialized* state.
    :meth:`read`, :meth:`write`, :meth:`call` and :meth:`simu_wait` operations require the
    *running* state.

    :param init_timeout: Maximum time (in seconds) to wait for establishing
        a connection to ecu.test.
    :param request_timeout: Per-request timeout (in seconds) for API calls (read, write,
        job calls, ...). You might want to increase this value e.g. when using
        long-running jobs.
    """

    class _ContextManager:
        def __enter__(self) -> ToolAccess: ...
        def __exit__(self, exc_type, exc_val, exc_tb) -> None:
            """
            performs the state transition opposite to the one through which this ContextManager
            instance was obtained, e.g. deinit or stop.
            """
            ...

    def __init__(
        self, init_timeout: float = 10.0, request_timeout: float = 10.0
    ) -> None: ...
    def simu_wait(self, timeout: float | int) -> None:
        """Waits the specified amount of time based on the active time basis in ecu.test
        (model time or system time).

        :param timeout: Time to wait in seconds.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def bus_signal(self, name: str) -> BusSignal:
        """Create and register an ecu.test bus signal. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        :param name: Fully qualified signal name (path).
        :returns: A registered :class:`BusSignal` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def model_var(self, name: str) -> ModelVar:
        """Create and register an ecu.test model variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified model variable name (path).
        :returns: A registered :class:`ModelVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def meas_var(self, name: str) -> MeasVar:
        """Create and register an ecu.test measurement variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified measurement variable name (path).
        :returns: A registered :class:`MeasVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def calib_var(self, name: str) -> CalibVar:
        """Create and register an ecu.test calibration variable. Repeated calls with the same name
        parameter return the already registered instance and do not trigger an additional
        registration on the ecu.test side.

        :param name: Fully qualified calibration variable name (path).
        :returns: A registered :class:`CalibVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def diag_var(self, name: str) -> DiagVar:
        """Create and register an ecu.test diagnostic service variable. Repeated calls with the
        same name parameter return the already registered instance and do not trigger an
        additional registration on the ecu.test side.

        :param name: Fully qualified diagnostic service name. The name must include the control
            unit identifier as defined in the test configuration and the diagnostic service name.
            Example: Engine/Read_data_by_identifier.
        :returns: A registered :class:`DiagVar` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def package(self, package_path: str) -> Package:
        """Create and register an ecu.test package. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        There are some restrictions on the test steps used in the package. Many test steps do not
        make sense when the package is called from ecu.test code, and some could even cause
        problems. Therefore:
            - Currently, calling sub-packages is not allowed at all. This restriction might get
              loosened in the future.
            - Test steps that open any kind of dialog during their execution are not allowed
              because ecu.test code is intended to run without user interaction.
            - Test steps related to parallel packages or Inbox/Outbox variables are not allowed
              because parallelism should be handled in the python script.
            - Test steps "Report", "Log File Entry", "Assertion", and "Exit", as well as
              "Precondition" and "Postcondition" are not allowed because they only make sense when
              the entire test case is handled inside ecu.test.
            - "Start/Stop/Add Trace", "Set Trace Comment", as well as "Request Analysis" and
              "Incorporate trace step result" are not allowed because the trace analysis part of
              the package isn't executed.
            - "Start/Stop Stimulus", user-defined utilities, various tool specific test steps,
              and EES / FIU test steps are currently not allowed.

        Packages containing such test steps cannot be used in this way at all.

        :param package_path: Path to the package.
        :returns: A registered :class:`Package` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def init(self) -> _ContextManager:
        """Initialize the connection to ecu.test.

        The *initialized* state is required before registering jobs or variables. Can be
        used as a context manager which will automatically invoke :meth:`deinit` when leaving
        the context::

            with ToolAccess().init() as ta:
                job = ta.job("PORT/Job")
                ...

        Alternatively call it explicitly and later :meth:`deinit`::

            ta = ToolAccess()
            ta.init()
            job = ta.job("PORT/Job")
            ...
            ta.deinit()

        :raises AuthenticationError: If ecu.test can not verify this client.
        :raises TimeoutError: If ecu.test does not respond within the configured init timeout.
        """
        ...

    def deinit(self) -> None:
        """Close the connection to ecu.test and reset all registered variables and jobs.
        After calling this methode :class:`ToolAccess` falls back into the *initialized* state.

        .. info::

           This method should only be called when :meth:`init` was called explicitly before.

        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        """
        ...

    def run(self) -> _ContextManager:
        """Enter the *running* state required for read / write / job calls / simu_wait.

        Usable as a context manager which automatically invokes :meth:`stop` after leaving
        the context::

            with ta.run():
                value = var.read()
                ...

        Or explicitly::

            ta.run()
            my_var.read()
            ...
            ta.stop()

        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

    def stop(self) -> None:
        """Exit the *running* state and fall back into the *initialized* state. Depending on the
        used tools, this can restore defaults for variables which were altered during the *running*
        state.

        .. info::

           This method should only be called when :meth:`run` was called explicitly before.

        :raises StateError: If :class:`ToolAccess` is not in the *running* state.
        """
        ...

    def recording(self, dest_file: str, vars: list[_VarBase]) -> Recording:
        """Create a recording instance for the specified variables.

        :param dest_file: Destination file path for the recording. Relative paths are interpreted as relative to
                            the current working directory of the script process.
                          A type-appropriate extension is automatically added, and if the file already exists,
                            extra characters are added to make it unique.
        :param vars: List of variables to record

        Note: All variables must be realized via a single `port` in ecu.test. Otherwise, the port
              used by the majority of variables will be selected, and variables not realized via
              that port will not be recorded.
        :returns: A Recording instance
        """
        ...
    ## insert job instantiation overloads here
    ## end

    @overload
    def job(self, name: str) -> Job:
        """Create and register an ecu.test job. Repeated calls with the same name parameter
        return the already registered instance and do not trigger an additional registration on
        the ecu.test side.

        :param name: Fully qualified job name.
        :returns: A registered :class:`Job` instance.
        :raises RemoteError: If an error occurs in ecu.test during this function call.
        :raises StateError: If :class:`ToolAccess` is not in the *initialized* state.
        :raises TimeoutError: If ecu.test does not respond within the configured request timeout.
        """
        ...

def export_pyi(target_dir: str, **kwargs):
    """
    Create a pyi file with job information from the running ecu.test instance.
    The target directory should be named "ecutest-stubs" and located next to your own python code
    so your IDE will use it for code completion.

    Additional arguments will be passed on to the communication module. See the
    :class:`webapi.WebApiClient` for possible arguments
    """
    ...
'''

init_template = \
"""from .toolaccess import *
from .exceptions import *
from .webapi import *
"""

# Backward-compatible variable names expected by tests
TOOLACCESS_PYI = toolaccess_template
INIT = init_template
