.. ecu.test *code* documentation master file, created by
   sphinx-quickstart on Wed Aug  6 15:02:33 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ecu.test *code*
===============

ecu.test *code* is a lightweight solution for creating and executing test cases in Python. It is
tailored to the needs of software developers and can be used without any prior knowledge of
ecu.test. ecu.test *code* is not a replacement for ecu.test, but rather an alternative way to benefit
from the power of ecu.test.

To get up and running quickly, see :ref:`Getting Started <getting-started>`.

**Features**

* Create and execute test cases directly in your Python environment
* Access ecu.test :ref:`tools <Tools>`, jobs, and test values
* Record test values to files, leveraging the native recorder feature of the respective tool
* Fast access through config-specific autocompletion
* Seamlessly integrate test results into test.guide


.. figure:: demo1.png
    :alt: ecu.test *code* in Visual Studio Code.
    :width: 800px

**Components**

ecu.test *code* consists of three parts: a Python library, a Visual Studio Code extension, and a
pytest plugin.

.. figure:: components.png
    :alt: Components of ecu.test *code*.
    :width: 800px
    :align: center

* The library is the core component of ecu.test *code*. It activates the capabilities of ecu.test
  directly inside your Python environment, giving your code access to ecu.test tools, data and
  automation primitives
* The `VS Code extension
  <https://marketplace.visualstudio.com/items?itemName=tracetronic-GmbH.ecu-test-code>`_ builds on
  the foundation of the Library by offering rich autocompletion, inline help and streamlined
  authoring so you can design, parameterize and run test cases without leaving VS Code. It is an
  optional add-on.
* The :ref:`pytest plugin <pytest-plugin>` enables seamless integration of test reports into
  :ref:`test.guide <test.guide>`. It is optional as well.

**Limitations**

.. info::

   ecu.test *code* is in an early stage of development and requires your input.
   If you are missing important features, please get in touch with us!

* Only the test steps read, write, execute DIAG-SERVICE and tool jobs are supported
* Only test steps that take or return standard Python data types are supported.
  Standard Python data types here mean ``str``, ``int``, ``float``, ``None``, as well as ``list``
  and ``tuple`` whose elements are restricted to these types.
  The test step execute DIAG-SERVICE is an exception to that rule: here, dictionaries with standard
  Python data types as keys and values are supported for parameters and return values.
* No unit conversion (all values are used as provided)
* Advanced properties such as measuring raster are not supported

.. toctree::
    :maxdepth: 2
    :hidden:

    getting-started
    compatibility
    state-model
    pytest-plugin
    api_refs/index
