.. _getting-started:

Getting Started
===============

Prerequisites
-------------

* Python 3.12 or later (tested with Python 3.13)
* ecu.test 2026.1 or later
* Optional: Visual Studio Code for using the VSC extension
* Optional: Access to a test.guide project for uploading test reports

Obtaining ecu.test *code*
-------------------------

ecu.test *code* is available as "ecutest_code" on `PyPI <https://pypi.org>`_, so you can simply 
install it with any common python package manager such as `pip`.
There are no additional licensing costs for using ecu.test *code*.
If you use Visual Studio Code, you can install the extension via the
`VS Code Marketplace <https://marketplace.visualstudio.com/items?itemName=tracetronic-GmbH.ecu-test-code>`_.

Setup
-----

ecu.test *code* is delivered including a demo workspace that you can use to get up and running quickly:

* Make sure you have the Visual Studio Code Extension for ecu.test *code* installed
* Open the ecu.test-code-examples folder in Visual Studio Code
* Open a terminal in VS Code and enter these commands:
    * ``python -m venv venv``
        * This creates a virtual Python environment in the folder "venv".
        * Choose "yes" when you are prompted whether you want to "use" it.
    * ``./venv/scripts/activate``
        * This "enters" the virtual environment, so, all subsequent python and pip commands use "venv" as their environment.
        * If you get an "execution policy" error, you may need to allow execution of unsigned scripts (see the `PowerShell documentation <https:/go.microsoft.com/fwlink/?LinkID=135170>`_).
    * ``pip install ecutest_code``
        * Access to the internet or to a pypi mirror configured in your pip.ini is required.
        * This will install ecu.test *code* and its required dependencies.
* Set the interpreter of the virtual environment as standard interpreter of the VS Code project:

  .. figure:: setup1.png
     :alt: Setting the interpreter in VS Code
     :width: 800px
     :align: center

* To create test cases with auto-complete or to execute test cases, ecu.test must be started. There are the following options for doing this:
    a) Starting ecu.test from Visual Studio Code
        * Go to "File → Preferences → Settings → Extensions → ecu.test *code*" and set these file paths:
        * Path to ecu.test Executable or Runner (``C:\Users\Bob\AppData\Local\ecu.test 2026.1\ecu.test.exe``)
        * Workspace Directory Path (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code``)
        * TBC-Path (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code\Configurations\Testlab_HiL_M.tbc``)
        * TCF-Path
          (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code\Configurations\SW_Ver_1.tcf``)
        * Select ecu.test *code* in the sidebar and click on “Start ecu.test”. This starts ecu.test and
          loads the configurations thereby enabling autocompletion for library calls, test values
          and tool jobs.
    b) Manual start of ecu.test in the workspace to be used
        * To do this, you must ensure that the web server for :ref:`ecu.test lab <ecuTestLab_setup>` is started.
    c) Start ecu.test via the :ref:`Lifecycle API <ecutest.lifecycle>`

* Start writing a testcase or experiment with the included example testcases:
    * ``test_driving_mode.py``: Contains a simple context-manager-based testcase.
    * ``test_vehicle.py``: Contains an example implementation of a pytest test class that tests a vehicle model loaded in ecu.test.
* Use the Testing section in the sidebar to combine ecu.test *code* with IDE support for unit tests.

.. figure:: demo2.png
    :alt: Visual Studio Code opened in the Demo workspace with configured testing.
    :width: 800px
    :align: center
