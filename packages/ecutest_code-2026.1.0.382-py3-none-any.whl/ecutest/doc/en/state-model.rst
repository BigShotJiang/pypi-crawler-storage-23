State Model
===========

To use the ecu.test *code* Library, it is important to understand the possible states
and their transitions. The states are **uninitialized**, **initialized**, and **running**.
Depending on the current state, different features are available. For example, a job must
first be registered with ``ToolAccess.job("tool/myJob")`` before it can be called. Details about
the available functions in the different states are illustrated in the state diagram below.


Transition Options
------------------

State changes can be carried out in two different ways:

* Context Manager: When entering the context manager, the new state becomes active.
  Upon exiting, the ecu.test *code* Library automatically reverts to the previous
  state. This approach also ensures the connection to ecu.test is gracefully
  closed, even if exceptions occur.
* Explicit Call: In this variant, the context manager is not used. Instead, the user calls
  :meth:`ecutest.toolaccess.ToolAccess.init` or :meth:`ecutest.toolaccess.ToolAccess.run`.
  In this case, the user must manually call :meth:`ecutest.toolaccess.ToolAccess.stop` or
  :meth:`ecutest.toolaccess.ToolAccess.deinit` to return to the previous state. This
  option offers more flexibility, e.g. for class-based tests.


.. info::

    Even when you use the explicit transition variant (without the context manager), if an
    unexpected error (uncaught exception, forced termination, etc.) ends your
    Python process, ecu.test detects the dropped connection and automatically reverts its
    internal state to the initial state as if you had called
    ``ToolAccess.deinit()``. This prevents ecu.test from remaining in an inconsistent state for
    subsequent sessions.


.. _state-model-diagram:

.. figure:: state-diagram.png
    :alt: State diagram showing transitions between Uninitialized, Initialized and Running states
    :width: 600px
    :align: center

    State model of the ecu.test *code* Library with the states and their transitions.


Examples
--------
Below you will find short examples for both transition methods.

Context manager based transitions
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from ecutest.toolaccess import ToolAccess

   with ToolAccess().init() as ta:  # -> initialized
      job = ta.job("PORT/MyJob")
      with ta.run():               # -> running
         result = job(1, 2)
      # leaving run context -> initialized
   # leaving init context -> uninitialized

Explicit transitions
^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from ecutest.toolaccess import ToolAccess

    ta = ToolAccess()            # uninitialized
    ta.init()                    # -> initialized
    job = ta.job("PORT/MyJob")
    ta.run()                     # -> running
    result = job(1, 2)
    ta.stop()                    # -> initialized
    ta.deinit()                  # -> uninitialized
