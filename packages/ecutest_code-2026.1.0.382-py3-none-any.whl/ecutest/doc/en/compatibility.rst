.. _compatibility:

Compatibility
=============

The ecu.test *code* library is versioned in lockstep with ecu.test, using the scheme
``<year>.<minor>.<patch>`` (e.g. ``2025.3.1``). Since the library is under heavy development,
its version is strictly coupled to the ecu.test version at the moment:

* Use the library only with the matching ``<year>.<minor>`` version of ecu.test (e.g. any ``2025.3.x`` library works only with ecu.test ``2025.3``).
* Upgrading to the next ecu.test minor release (e.g. ``2025.3`` → ``2025.4``) can introduce breaking changes — both in this library's public API and in the internal (non‑public) ecu.test interfaces it uses for communication.

To upgrade, align both ecu.test and the library to the target ``<year>.<minor>`` and review the release notes for breaking changes.
Future releases may relax this tight coupling. Until then, always match the versions to avoid incompatibilities.

.. info::

   These version‑matching rules equally apply to the ecu.test *code* VS Code Extension, which relies
   on this library internally.
