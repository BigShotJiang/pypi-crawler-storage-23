.. _compatibility:

Kompatibilität
==============

Die Python-Bibliothek von ecu.test *code* wird im Gleichschritt mit ecu.test versioniert und verwendet das Schema
``<Jahr>.<Minor>.<Patch>`` (z. B. ``2025.3.1``). Da sich die Bibliothek noch stark in Entwicklung befindet,
ist ihre Version derzeit streng an die ecu.test-Version gekoppelt:

* Verwenden Sie die Bibliothek nur mit der passenden ``<Jahr>.<Minor>``-Version von ecu.test (z. B. funktioniert jede ``2025.3.x``-Bibliothek nur mit ecu.test ``2025.3``).
* Ein Upgrade auf die nächste ecu.test-Minor-Version (z. B. ``2025.3`` → ``2025.4``) kann inkompatible Änderungen einführen — sowohl in der öffentlichen API dieser Bibliothek als auch in den internen (nicht öffentlichen) ecu.test-Schnittstellen, die sie zur Kommunikation nutzt.

Für ein Upgrade richten Sie sowohl ecu.test als auch die Bibliothek auf die gewünschte ``<Jahr>.<Minor>``-Version aus und prüfen Sie die Release-Notes auf mögliche inkompatible Änderungen.
Zukünftige Versionen könnten diese enge Kopplung lockern. Bis dahin sollten die Versionen immer exakt zueinander passen, um Inkompatibilitäten zu vermeiden.

.. info::

   Diese Regeln zur Versionskompatibilität gelten gleichermaßen für die VS-Code-Extension von ecu.test *code*,
   die intern auf der Bibliothek basiert.
