Zustandsmodell
==============

Um die Bibliothek von ecu.test *code* zu verwenden, ist es wichtig, die möglichen Zustände
und deren Übergänge zu verstehen. Die Zustände sind **Uninitialized**, **Initialized**
und **Running**. Abhängig vom aktuellen Zustand stehen unterschiedliche Funktionen zur Verfügung.
Beispielsweise muss ein Job zunächst mit ``ToolAccess.job("tool/myJob")`` registriert werden,
bevor er aufgerufen werden kann. Details zu den verfügbaren Funktionen in den verschiedenen
Zuständen sind im untenstehenden Zustandsdiagramm dargestellt.


Übergangsoptionen
-----------------

Zustandsänderungen können auf zwei verschiedene Arten durchgeführt werden:

* Kontextmanager: Beim Eintritt in den Kontextmanager wird der neue Zustand aktiv.
  Beim Verlassen stellt die Bibliothek automatisch den vorherigen
  Zustand wieder her. Diese Vorgehensweise stellt außerdem sicher, dass die Verbindung
  zu ecu.test ordnungsgemäß geschlossen wird, selbst wenn Exceptions auftreten.
* Expliziter Aufruf: In dieser Variante wird kein Kontextmanager verwendet. Stattdessen rufen Sie
  :meth:`ecutest.toolaccess.ToolAccess.init` oder :meth:`ecutest.toolaccess.ToolAccess.run` auf.
  In diesem Fall müssen Sie manuell :meth:`ecutest.toolaccess.ToolAccess.stop` oder
  :meth:`ecutest.toolaccess.ToolAccess.deinit` aufrufen, um zum vorherigen Zustand zurückzukehren.
  Diese Option bietet mehr Flexibilität, z. B. für klassenbasierte Tests.


.. info::

    Selbst wenn Sie die explizite Übergangsvariante ohne Kontextmanager verwenden und ein
    unerwarteter Fehler (nicht abgefangene Exception, erzwungene Beendigung usw.) Ihren
    Python-Prozess beendet, erkennt ecu.test die unterbrochene Verbindung und setzt seinen
    internen Zustand automatisch auf den Anfangszustand zurück, als hätten Sie
    ``ToolAccess.deinit()`` aufgerufen. Dadurch wird verhindert, dass ecu.test in einem
    inkonsistenten Zustand für nachfolgende Sitzungen verbleibt.


.. _state-model-diagram:

.. figure:: state-diagram.png
    :alt: Zustandsdiagramm mit den Übergängen zwischen "Uninitialized", "Initialized" und "Running"
    :width: 600px
    :align: center

    Zustandsmodell der Bibliothek mit den Zuständen und deren Übergängen.


Beispiele
---------
Nachfolgend finden Sie kurze Beispiele für beide Übergangsmethoden.

Kontextmanager-basierte Übergänge
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from ecutest.toolaccess import ToolAccess

   with ToolAccess().init() as ta:  # -> Initialized
      job = ta.job("PORT/MyJob")
      with ta.run():               # -> Running
         result = job(1, 2)
      # Verlassen des run-Kontexts -> Initialized
   # Verlassen des init-Kontexts -> Uninitialized

Explizite Übergänge
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from ecutest.toolaccess import ToolAccess

    ta = ToolAccess()            # Uninitialized
    ta.init()                    # -> Initialized
    job = ta.job("PORT/MyJob")
    ta.run()                     # -> Running
    result = job(1, 2)
    ta.stop()                    # -> Initialized
    ta.deinit()                  # -> Uninitialized
