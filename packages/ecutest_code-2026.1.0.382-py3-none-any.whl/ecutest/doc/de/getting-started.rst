.. _getting-started:

Erste Schritte
==============

Voraussetzungen
---------------

* Python 3.12 oder höher (getestet mit Python 3.13)
* ecu.test 2026.1 oder höher
* Optional: Visual Studio Code zur Nutzung der VS-Code-Erweiterung
* Optional: Zugriff auf ein test.guide-Projekt zum Hochladen von Testberichten

ecu.test *code* beziehen
------------------------

ecu.test *code* ist als "ecutest_code" auf `PyPI <https://pypi.org>`_ verfügbar, so dass
man es einfach mit jedem üblichen Python-Paketmanager wie z.B. `pip` installieren kann.
Zusätzliche Lizenzkosten fallen für die Nutzung von ecu.test *code* nicht an.
Wenn Sie Visual Studio Code verwenden, können Sie die Erweiterung über den
`VS Code Marketplace <https://marketplace.visualstudio.com/items?itemName=tracetronic-GmbH.ecu-test-code>`_ installieren.

Einrichtung
-----------

ecu.test *code* wird zusammen mit einem Demo-Workspace ausgeliefert, den Sie nutzen können, um schnell durchzustarten:

* Stellen Sie sicher, dass die Visual-Studio-Code-Erweiterung für ecu.test *code* installiert ist.
* Öffnen Sie den Ordner „ecu.test-code-examples“ in Visual Studio Code.
* Öffnen Sie ein Terminal in VS Code und geben Sie folgende Befehle ein:
    * ``python -m venv venv``
        * Dadurch wird eine virtuelle Python-Umgebung im Ordner „venv“ erstellt.
        * Wählen Sie „Ja“, wenn Sie gefragt werden, ob Sie diese Umgebung „verwenden“ möchten.
    * ``./venv/scripts/activate``
        * Dadurch „betreten“ Sie die virtuelle Umgebung, sodass alle nachfolgenden Python- und pip-Befehle diese Umgebung nutzen.
        * Wenn ein Fehler bezüglich „Ausführungsrichtlinien“ erscheint, müssen Sie eventuell die Ausführung unsignierter Skripte zulassen (siehe die `PowerShell-Dokumentation <https:/go.microsoft.com/fwlink/?LinkID=135170>`_).
    * ``pip install ecutest_code``
        * Es wird Zugriff auf das Internet oder auf einen in Ihrer pip.ini konfigurierten PyPI-Mirror benötigt.
        * Dadurch wird ecu.test *code* mitsamt seiner Abhängigkeiten installiert.
* Stellen sie den Interpreter der virtuellen Umgebung als Standard-Interpreter für das VS-Code-Projekt ein:

  .. figure:: setup1.png
     :alt: Setzen des Interpreters in VS Code
     :width: 800px
     :align: center

* Für die Erstellung von Testfällen mit Autovervollständigung oder die Ausführung von Testfällen muss ecu.test gestartet sein. Dafür gibt es folgende Möglichkeiten:
    a) ecu.test aus Visual Studio Code heraus starten
        * Gehen Sie zu „Datei → Einstellungen → Einstellungen → Erweiterungen → ecu.test *code*“ und tragen Sie folgende Pfade ein:
        * Pfad zur ecu.test-Executable bzw. zum Runner (``C:\Users\Bob\AppData\Local\ecu.test 2025.2\ecu.test.exe``)
        * Pfad zum Workspace-Verzeichnis (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code``)
        * TBC-Pfad (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code\Configurations\Testlab_HiL_M.tbc``)
        * TCF-Pfad
          (``C:\Users\Bob\Desktop\ecu.test-code-examples\ecu.test-code\Configurations\SW_Ver_1.tcf``)
        * Wählen Sie ecu.test *code* in der Seitenleiste aus und klicken Sie auf „Start ecu.test“. Dadurch
          wird ecu.test gestartet und die Konfigurationen werden geladen. Dies aktiviert die Autovervollständigung für Bibliotheksaufrufe, Testwerte und Tooljobs.
    b) Manueller Start von ecu.test in den zu verwendenden Workspace
        * Hierfür muss sichergestellt sein, dass der Webserver für  :ref:`ecu.test lab <ecuTestLab_setup>` gestartet ist
    c) Start von ecu.test über die :ref:`Lifecycle API <ecutest.lifecycle>`

* Beginnen Sie mit dem Schreiben eines Testfalls oder experimentieren Sie mit den enthaltenen Beispiel-Testfällen:
    * ``test_driving_mode.py``: Enthält einen einfachen, context-manager-basierten Testfall.
    * ``test_vehicle.py``: Enthält eine Beispielimplementierung einer pytest-Testklasse, die ein in ecu.test geladenes Fahrzeugmodell testet.
* Verwenden Sie den Bereich „Testing“ in der Seitenleiste, um ecu.test *code* in Kombination mit IDE-Unterstützung für Unittests zu nutzen.

.. figure:: demo2.png
    :alt: Visual Studio Code geöffnet im Demo-Workspace mit konfiguriertem Testing.
    :width: 800px
    :align: center
