.. ecu.test code Dokumentations-Hauptdatei, erstellt von
   sphinx-quickstart am Mi 06. Aug 2025 um 15:02:33.
   Sie können diese Datei vollständig an Ihre Bedürfnisse anpassen, sie sollte jedoch mindestens
   die Wurzel-Direktive `toctree` enthalten.

ecu.test *code*
===============

ecu.test *code* ist eine schlanke Lösung zum Erstellen und Ausführen von Testfällen in Python. Es ist
auf die Bedürfnisse von Softwareentwicklern zugeschnitten und ermöglicht den Einstieg ohne weitere
ecu.test Kenntnisse. ecu.test *code* ist kein Ersatz für ecu.test, sondern eine alternative
Möglichkeit, von der Leistungsfähigkeit von ecu.test zu profitieren.

Um schnell loszulegen, lesen Sie bitte :ref:`Erste Schritte <getting-started>`.

**Funktionen**

* Erstellen und Ausführen von Testfällen direkt in Ihrer Python-Umgebung
* Zugriff auf ecu.test-:ref:`Tools <Tools>`, Jobs und Testgrößen
* Aufnahmen von Testgrößen in Dateien, unter Zuhilfenahme der nativen Aufnahmefunktion des jeweiligen Tools
* Schneller Zugriff durch konfigurationsspezifische Autovervollständigung
* Nahtlose Integration von Testergebnissen in test.guide


.. figure:: demo1.png
    :alt: ecu.test *code* in Visual Studio Code.
    :width: 800px

**Komponenten**

ecu.test *code* besteht aus drei Teilen: einer Python-Bibliothek, einer Visual-Studio-Code-Erweiterung und einem
pytest-Plugin.

.. figure:: components.png
    :alt: Komponenten von ecu.test *code*.
    :width: 800px
    :align: center

* Die Bibliothek ist die Kernkomponente von ecu.test *code*. Sie aktiviert die Funktionen von ecu.test
  direkt in Ihrer Python-Umgebung und ermöglicht Ihrem Code den Zugriff auf ecu.test-Tools, -Daten
  und -Automatisierungs-Primitiven
* Die `VS Code-Erweiterung
  <https://marketplace.visualstudio.com/items?itemName=tracetronic-GmbH.ecu-test-code>`_ ist baut
  auf der Bibliothek auf und bietet umfangreiche Autovervollständigung, Inline-Hilfe und eine
  optimierte Erstellung von Testfällen, sodass Sie Testfälle entwerfen, parametrieren und ausführen
  können, ohne VS Code zu verlassen. Es handelt sich um ein optionales Add-on.
* Das :ref:`pytest-Plugin <pytest-plugin>` ermöglicht eine nahtlose Integration von Testberichten in
  :ref:`test.guide <test.guide>`. Es ist ebenfalls optional.

**Einschränkungen**

.. info::

   ecu.test *code* befindet sich in einem frühen Entwicklungsstadium und ist auf Ihre Rückmeldungen angewiesen.
   Falls Sie wichtige Funktionen vermissen, nehmen Sie bitte Kontakt mit uns auf!

* Es werden nur die Testschritte Read, Write, DIAG-SERVICE Ausführen und Tooljobs unterstützt
* Es werden nur Testschritte unterstützt, die Standard-Python-Datentypen annehmen oder zurückgeben.
  Standard-Python-Datentypen sind hier ``str``, ``int``, ``float``, ``None`` sowie ``list`` und
  ``tuple``, deren Elemente auf diese Typen beschränkt sind.
  Eine Ausnahme ist der Testschritt DIAG-SERVICE Ausführen: hier werden für die Parameter und
  Rückgabewerte Dictionaries mit Standard-Python-Datentypen als Schlüssel und Werte unterstützt.
* Keine Einheitenumrechnung (alle Werte werden unverändert verwendet)
* Erweiterte Eigenschaften wie Messraster werden nicht unterstützt

.. toctree::
    :maxdepth: 2
    :hidden:

    getting-started
    compatibility
    state-model
    pytest-plugin
    api_refs/index
