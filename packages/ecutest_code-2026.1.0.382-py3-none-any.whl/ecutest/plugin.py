import os
import re
import shutil
import tempfile
import time
import warnings
import json

from typing import Literal, TypedDict

import requests
import testguide_report_generator as tgr

from pytest import Item, TestReport, Parser, Session, CallInfo


REPORT_DIR_NAME = ".report"

OPT_SKIP_SSL_VERIFICATION = "--skip-testguide-ssl"
OPT_UPLOAD_TO_TG = "--upload-to-testguide"
OPT_EXPORT_TG_REPORT = "--export-testguide-report"

INI_REQEST_TIMEOUT = "testguide_request_timeout"
INI_SKIP_SSL_VERIFICATION = "skip_testguide_ssl"
INI_ENABLE_VERDICT_NONE = "enable_verdict_none"

# option metadata for both pytest registration and Sphinx docs generation
CLI_OPTIONS = [
    {
        "option": OPT_UPLOAD_TO_TG,
        "help": "Upload the result of this test run to test.guide",
        "action": "store_true",
        "default": False,
    },
    {
        "option": OPT_EXPORT_TG_REPORT,
        "help": ("Creates a .report directory in the directory where pytest was invoked. In this "
                 "directory, you will find all JSON reports and artifacts used for the test.guide "
                 "upload."),
        "action": "store_true",
        "default": False,
    },
    {
        "option": OPT_SKIP_SSL_VERIFICATION,
        "help": "Skips the SSL verification for test.guide during the report upload.",
        "action": "store_true",
        "default": False,
    },
]

INI_OPTIONS = [
    {
        "name": INI_SKIP_SSL_VERIFICATION,
        "help": "Skips the SSL verification for test.guide during the report upload.",
        "type": "bool",
        "default": False,
    },
    {
        "name": INI_REQEST_TIMEOUT,
        "help": ("Timeout in seconds for HTTP requests to test.guide. (Applies only when using "
                 "the report upload.)"),
        "type": "string",
        "default": "20.0",
    },
    {
        "name": INI_ENABLE_VERDICT_NONE,
        "help": ("Test cases (test functions) that do not contain any assertions are reported "
                 "with verdict NONE in the test.guide report. (This config does not alter the "
                 "outcome of a test case in the native pytest report.)"),
        "type": "bool",
        "default": False,
    },
]

class TestCaseData(TypedDict):
    """
    Used to collect data for a test case (test function) across different pytest hooks.
    This data is then finally transferred into a test.guide TestCase object in another hook.
    """
    name: str
    node_id: str
    docstring: str
    module: str
    steps: list[tgr.TestStep]
    timestamp: int
    duration: int # seconds
    params: list[tgr.Parameter]
    properties: list[tuple[str, object]]
    verdict: tgr.Verdict
    has_exception: bool # exception different than AssertionError
    stdout: str
    stderr: str
    logs: str
    artifacts: list[str]


class TestGuidePytest:
    def __init__(self):
        self._test_cases: dict[str, TestCaseData] = {}
        self._initial_time_ms = self._timestamp_ms()
        self._tg_suite: tgr.TestSuite | None =  None
        self._cwd: str = ""
        self._enable_verdict_none: bool = False
        self.uploaded_reports_url: str = ""
        self._tmpdir_ctx = tempfile.TemporaryDirectory()
        self._tmpdir = self._tmpdir_ctx.name
        self._report_dir = os.path.join(self._tmpdir, REPORT_DIR_NAME)
        self.export_report: bool = False

    def __del__(self):
        self._clear_temp_dir()

    @staticmethod
    def _timestamp_ms() -> int:
        """Returns current timestamp in ms"""
        return int(time.time() * 1000)


    @staticmethod
    def _shorten_str(s: str, max_len: int=120) -> str:
        """Shortens the input string if it exceeds the length max_len"""
        if len(s) <= max_len:
            return s
        return f"{s[:max_len-3]}..."


    @staticmethod
    def _map_verdict(
        verdict: Literal["passed", "failed", "skipped",] | None
    ) -> tgr.Verdict:
        """Maps a pytest outcome to a test.guide Verdict"""
        if verdict == "passed":
            return tgr.Verdict.PASSED
        elif verdict == "failed":
            return tgr.Verdict.FAILED
        elif verdict == "skipped":
            return tgr.Verdict.INCONCLUSIVE
        elif verdict is None:
            return tgr.Verdict.NONE
        else:
            raise ValueError(f"Unknown Verdict: {verdict}")


    @staticmethod
    def _get_tc_name(node_id: str) -> str:
        """Removes function arguments from node_id if present"""
        return node_id.rsplit('[', 1)[0]


    @staticmethod
    def _build_ts_desc(item: Item, lineno: int, orig: str, expl: str) -> str:
        """
        Generates a detailed description that is displayed on mouse hover over the
        test step in test.guide
        """
        return f"""{TestGuidePytest._get_tc_name(item.nodeid)}:{lineno}

        original assertion:
        ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        {orig}

        assertion explanation:
        ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        {expl}"""

    @staticmethod
    def _sanitize_file_name(path: str) -> str:
        """Replaces characters that are invalid for file system paths with _"""
        return re.sub(r"[^A-Za-z0-9\[\]\(\)._-]", "_", path)

    @staticmethod
    def _clear_ansi(s: str) -> str:
        """
        Removes ANSI escape sequences from a given string, which would otherwise cause an error
        when uploading the report to test.guide.
        """
        escape = re.compile(r"\x1b\[[;0-9]+m")
        return escape.sub("", s)

    def _clear_temp_dir(self) -> None:
        if self._tmpdir_ctx:
            self._tmpdir_ctx.cleanup()
            self._tmpdir = ""

    def _extract_failure(
        self, report: TestReport, test_case: str
    ) -> dict[Literal["message", "description"], str]:
        """Extracts the Exception information from a TestReport"""
        if hasattr(report.longrepr, "reprcrash"):
            crash = report.longrepr.reprcrash  # type: ignore
            lineno = crash.lineno
            message = self._clear_ansi(crash.message)
            return {
                "message": f"line {lineno}: {message.splitlines()[0]}",
                "description": f"{test_case}:{lineno}\n\n{message}"
            }
        else:
            lineno = report.location[1]
            message = self._clear_ansi(str(report.longrepr).strip().splitlines()[-1])
            description = f"{test_case}"
            if lineno is not None:
                description += f":{lineno}"
                message = f"line {lineno}: {message}"
            return {
                "message": message.split("\n")[0],
                "description": description + f"\n\n{message}"
            }


    def _get_module_names(self) -> list[str]:
        """Returns a list of module names included in the current test run"""
        return list({tc["module"] for tc in self._test_cases.values()})


    def _build_test_suites(self) -> dict[str, tgr.TestSuite]:
        """
        Builds a dict with Python module names as keys and an empty TestSuite as value.
        Each module is thus assigned its own TestSuite.
        """
        module_names = self._get_module_names()
        test_suites: dict[str, tgr.TestSuite] = {}
        for module_name in module_names:
            test_suites[module_name] = tgr.TestSuite(
                name=module_name,
                timestamp=self._initial_time_ms
            )
        return test_suites


    def _add_test_cases_to_suites(self, suites: dict[str, tgr.TestSuite]) -> None:
        """Adds all the collected test cases to the corresponding TestSuite"""
        for test_case in self._test_cases.values():
            suites[test_case["module"]].add_testcase(
                testcase=self._build_test_case(test_case)
            )


    def _build_test_case(self, test_case_data: TestCaseData) -> tgr.TestCase:
        """
        Builds a test.guide TestCase object from the TestCaseData collected during test execution.
        In case the TestCase has captured stdout, stderr or logs this captured data will be written
        into a file which will then be added as an artifact to the TestCase.
        """
        tg_test_case = tgr.TestCase(
            name=test_case_data["name"],
            timestamp=test_case_data["timestamp"],
            verdict=test_case_data["verdict"],
        )
        for test_step in test_case_data["steps"]:
            tg_test_case.add_execution_teststep(test_step)
        for prop in test_case_data["properties"]:
            tg_test_case.add_attribute_pair(
                key=prop[0],
                value=prop[1] if isinstance(prop[1], str) else repr(prop[1])
            )
        tg_test_case.add_parameter_set("", test_case_data["params"])
        tg_test_case.set_execution_time_in_sec(test_case_data["duration"])
        if test_case_data["docstring"]:
            tg_test_case.set_description(test_case_data["docstring"])

        if artifact_paths := test_case_data["artifacts"]:
            for artifact_path in artifact_paths:
                tg_test_case.add_artifact(artifact_path)

        test_case_dir = os.path.join(
            self._report_dir,
            test_case_data["module"],
            self._sanitize_file_name(test_case_data["node_id"])
        )

        def _add_log(log_type: Literal["stdout", "stderr", "logs"]):
            with open(os.path.join(test_case_dir, f"{log_type}.log"), "w", encoding="utf-8") as f:
                f.write(test_case_data[log_type])
            tg_test_case.add_artifact(os.path.join(test_case_dir, f"{log_type}.log"))

        if test_case_data["stdout"]:
            _add_log("stdout")
        if test_case_data["stderr"]:
            _add_log("stderr")
        if test_case_data["logs"]:
            _add_log("logs")

        if os.environ.get("TT_TASK_ID"):  # id of a test.guide av job for job to result trackking
            tg_test_case.add_constant_pair("TT_TASK_ID", os.environ.get("TT_TASK_ID"))

        return tg_test_case

    def _build_report_dir(self) -> None:
        """
        Creates the directory structure for the report directory.
        For test cases (test functions) that have captured stdout, stderr, or logs, an additional
        directory will be added to the module_name's directory, which will be used to save the
        log files later. The names of the test case folders correspond to the pytest node id, since,
        for example, in the case of parameterized test execution, multiple log captures can be
        generated for one test case.

        ```
        .report
        └── module_name
            ├── test_equal_x_1
            ├── test_equal_x_2
            └── test_unequal
        ```
        """
        os.makedirs(self._report_dir, exist_ok=True)
        for module_name in self._get_module_names():
            os.makedirs(os.path.join(self._report_dir, module_name), exist_ok=True)

        for node_id, test_case in self._test_cases.items():
            if not any([test_case["stdout"], test_case["stderr"], test_case["logs"]]):
                continue

            test_case_dir = os.path.join(self._report_dir, test_case["module"],
                                         self._sanitize_file_name(node_id))
            os.makedirs(test_case_dir, exist_ok=True)


    def _export_test_suites(
        self, test_suites: dict[str, tgr.TestSuite]
    ) -> list[str]:
        """
        Exports the Reports in the following directory structure:

        ```
        .report/
        └── module_name
            ├── module_name.json
            └── module_name.zip
        ```
        Returns a list of absolute paths to the .zip report files.
        """
        zip_paths: list[str] = []

        for module_name, suite in test_suites.items():
            export_path = os.path.join(self._report_dir, module_name, module_name)
            tgr.Generator(suite).export(export_path + ".json")
            zip_paths.append(os.path.abspath(export_path + ".zip"))
        return zip_paths


    @staticmethod
    def _ensure_environ_vars() -> None:
        """
        Ensures that the required environment variables are set.
        Otherwise a LookupError is raised.
        """
        test_guide_url = os.environ.get("TESTGUIDE_URL")
        if not test_guide_url:
            raise LookupError("Missing environment variable TESTGUIDE_URL, should be set "
                              "to something like http://your.test-guide.instance:8085")
        if not os.environ.get("TESTGUIDE_PROJECT_ID"):
            raise LookupError("Missing environment variable TESTGUIDE_PROJECT_ID, should "
                              "be set to the id number of your project in test.guide")
        if not os.environ.get("TESTGUIDE_AUTH_KEY"):
            raise LookupError("Missing environment variable TESTGUIDE_AUTH_KEY, should be "
                              "set to one of your authentication keys - maybe you first "
                              f"need to create one under {test_guide_url}/user/authkeys")


    def _tg_post_report(self, report: str, skip_ssl: bool, req_timeout: float) -> str:
        with open(report, "rb") as fp:
            upload_data = fp.read()
        upload_url = f"{os.environ.get('TESTGUIDE_URL')}/api/report/reports"
        params = {"projectId": os.environ.get("TESTGUIDE_PROJECT_ID"), "converterId": "json2atx"}
        headers = {"Content-Type": "application/zip",
                    "Accept": "application/json",
                    "TestGuide-AuthKey": os.environ.get("TESTGUIDE_AUTH_KEY")}

        response = requests.post(
            url=upload_url,
            params=params,
            data=upload_data,
            headers=headers,
            verify=(not skip_ssl),
            timeout=req_timeout,
        )
        response.raise_for_status()
        return response.json().get("taskId")


    def _tg_wait_task_completed(self, task_id: str, skip_ssl: bool, req_timeout: float) -> None:
        wait_endpoint = (f"{os.environ.get('TESTGUIDE_URL')}/"
                         f"api/report/reports/uploadstatus/{task_id}")
        wait_headers = {"Accept": "application/json",
                        "TestGuide-AuthKey": os.environ.get("TESTGUIDE_AUTH_KEY")}
        wait_params = {"projectId": os.environ.get("TESTGUIDE_PROJECT_ID")}
        while True:
            response = requests.get(
                url=wait_endpoint,
                headers=wait_headers,
                params=wait_params,
                verify=(not skip_ssl),
                timeout=req_timeout,
            )
            response.raise_for_status()
            json_response = response.json()
            if json_response.get("status") == "finished":
                if json_response.get("uploadResult").get("uploadReturnCode") >= 400:
                    msg = json_response.get("uploadResult").get("resultMessages")
                    raise RuntimeError(f"Upload failed: {msg}")
                break
            time.sleep(1.0)
        if atx_id:=json_response.get("uploadResult").get("reportId"):
            self.uploaded_reports_url += f"&atxId={atx_id}"

    def _upload_reports(self, skip_ssl: bool, req_timeout: float, reports: list[str]) -> None:
        self._ensure_environ_vars()
        task_ids = []
        for report in reports:
            task_id = self._tg_post_report(report, skip_ssl, req_timeout)
            task_ids.append(task_id)

        # Create a JSON file containing information (task ids and report files)
        # about the last test.guide upload
        if self.export_report:
            upload_data = []
            for report, task_id in zip(reports, task_ids):
                upload_data.append({"report": report, "task_id": task_id})
            user_report_dir = os.path.join(self._cwd, REPORT_DIR_NAME, "upload_info.json")
            with open(user_report_dir, "w", encoding="utf-8") as f:
                f.write(json.dumps(upload_data, indent=2))

        for task_id in task_ids:
            self._tg_wait_task_completed(task_id, skip_ssl, req_timeout)


    # ------------
    # PYTEST HOOKS
    # ------------

    def pytest_addoption(self, parser: Parser, pluginmanager):
        # Register CLI options
        for opt in CLI_OPTIONS:
            parser.addoption(
                opt["option"],
                help=str(opt["help"]),
                action=str(opt["action"]),
                default=opt["default"],
            )
        # Register INI options
        for ini in INI_OPTIONS:
            parser.addini(
                name=str(ini["name"]),
                help=str(ini["help"]),
                type=ini["type"],
                default=ini["default"],
            )

    def pytest_sessionstart(self, session: Session):
        # Save the directory from which pytest.main was invoked
        self._cwd = str(session.config.invocation_params.dir)
        self._enable_verdict_none = bool(session.config.getini(INI_ENABLE_VERDICT_NONE))
        self._build_report_dir()
        self.export_report = bool(session.config.getoption(OPT_EXPORT_TG_REPORT))

    def pytest_runtest_protocol(self, item: Item):
        self._test_cases[item.nodeid] = {
            "name": self._get_tc_name(item.name),
            "node_id": item.nodeid,
            "docstring": getattr(item.obj, "__doc__", ""),
            "module": item.module.__name__,
            "steps": [],
            "timestamp": self._timestamp_ms(),
            "duration": 0,
            "params": [],
            "properties": [],
            "verdict": tgr.Verdict.ERROR,
            "has_exception": False,
            "stdout": "",
            "stderr": "",
            "logs": "",
            "artifacts": [],
        }

    def pytest_assertion_pass(self, item: Item, lineno: int, orig: str, expl: str) -> None:
        ts = tgr.TestStep(
            name=self._shorten_str(f"line {lineno}: {orig.strip()}"),
            verdict=tgr.Verdict.PASSED,
        )
        ts.set_description(self._build_ts_desc(
            item, lineno, orig, expl))
        self._test_cases[item.nodeid]["steps"].append(ts)

    def pytest_runtest_call(self, item: Item)  -> None:
        if hasattr(item, "funcargs"):
            for arg_name, arg_val in item.funcargs.items():
                value = arg_val if isinstance(arg_val, (str, int)) else repr(arg_val)
                param = tgr.Parameter(
                    name=str(arg_name),
                    value=value,
                    direction=tgr.Direction.IN
                )
                self._test_cases[item.nodeid]["params"].append(param)

    def pytest_runtest_makereport(self, item: Item, call: CallInfo) -> None:
        if call.excinfo and not call.excinfo.errisinstance(AssertionError):
            self._test_cases[item.nodeid]["has_exception"] = True

    def pytest_runtest_logreport(self, report: TestReport) -> None:
        if not self._test_cases:
            return

        # skip 'setup' and 'teardown'
        if report.when != "call" and not report.skipped:
            return

        test_case = self._test_cases[report.nodeid]

        # Set the initial verdict based on report.outcome. This value may be updated in the following.
        test_case["verdict"] = self._map_verdict(report.outcome)
        test_case["duration"] = int(report.duration * 1000)
        test_case["stdout"] = report.capstdout
        test_case["stderr"] = report.capstderr
        test_case["logs"] = report.caplog

        if report.user_properties is not None:
            test_case["properties"] = report.user_properties

        if report.failed:
            if test_case["has_exception"]:
                name = ""
                if (hasattr(report.longrepr, "reprtraceback")
                    and report.longrepr.reprtraceback.reprentries):

                    tb_lines = report.longrepr.reprtraceback.reprentries[0].lines
                    # get first line of traceback which starts with ">"
                    err_line = next((line for line in tb_lines if line.startswith(">")), None)
                    if err_line:
                        name = str(err_line[1:].strip())
                    if hasattr(report.longrepr.reprtraceback.reprentries[0], "reprfileloc"):
                        lineno = report.longrepr.reprtraceback.reprentries[0].reprfileloc.lineno
                        name = f"line {lineno}{':' if name else ''} {name}"

                test_case["verdict"] = tgr.Verdict.ERROR
                ts = tgr.TestStep(
                    name=self._shorten_str(name),
                    verdict=tgr.Verdict.ERROR
                )
                if hasattr(report, "longreprtext"):
                    ts.set_description(self._shorten_str(report.longreprtext, 6144))
                test_case["steps"].append(ts)
            else:
                # Create test step for failed assertions
                failure_data = self._extract_failure(report, self._get_tc_name(test_case["node_id"]))
                ts = tgr.TestStep(
                    name=self._shorten_str(failure_data["message"]),
                    verdict=tgr.Verdict.FAILED
                )
                ts.set_description(self._shorten_str(failure_data["description"], 6144))
                test_case["steps"].append(ts)

        if self._enable_verdict_none and not test_case["steps"] and not report.skipped:
            test_case["verdict"] = tgr.Verdict.NONE

        if test_case["verdict"] in (tgr.Verdict.FAILED, tgr.Verdict.ERROR):
            stdoutlog_name = ''.join(report.head_line.replace(".","\\") + ".log")
            stdoutlog_path = os.path.join(self._report_dir, test_case.get("module"), stdoutlog_name)
            if not os.path.exists(dir_name:=os.path.dirname(stdoutlog_path)):
                os.makedirs(dir_name, exist_ok=True)
            with open(stdoutlog_path, "w+", encoding="utf-8") as f:
                f.write(str(report.longrepr))
            test_case["artifacts"].append(stdoutlog_path)


    def pytest_sessionfinish(self, session: Session, exitstatus: int):
        # skip test.guide upload if there is no data to upload
        opt_upload_to_tg = session.config.getoption(OPT_UPLOAD_TO_TG)
        if not self._test_cases and opt_upload_to_tg:
            warnings.warn("Skipping test.guide upload because no tests were collected.")
            return

        if (not opt_upload_to_tg and
            not self.export_report):
            return

        self._build_report_dir()
        test_suites = self._build_test_suites()
        self._add_test_cases_to_suites(test_suites)
        report_files = self._export_test_suites(test_suites)

        if self.export_report:
            user_report_dir = os.path.join(self._cwd, ".report")
            if os.path.exists(user_report_dir):
                shutil.rmtree(user_report_dir)
            shutil.copytree(self._report_dir, user_report_dir, dirs_exist_ok=True)

            # check if test.guide playbook target path exists, if this is the case
            # copy the json-zip for automatic playbook export
            if os.environ.get("TT_TASK_REPORT_DESTINATION"):
                os.makedirs(os.path.dirname(os.environ.get("TT_TASK_REPORT_DESTINATION")),
                            exist_ok=True)
                for report_file in report_files:
                    shutil.copy(report_file, os.environ.get("TT_TASK_REPORT_DESTINATION"))
                    # A playbook only supports uploading a single zip file.
                    # TODO: multiple reports aren't supported in one task -> should throw an error?
                    break

        if not opt_upload_to_tg:
            return

        # SSL Verification is skipped if specified in the ini or if the command
        # line parameter was provided
        skip_ssl_verification = bool(
            session.config.getini(INI_SKIP_SSL_VERIFICATION)
            or session.config.getoption(OPT_SKIP_SSL_VERIFICATION)
        )

        req_timeout = 20.0
        if cfg_req_timeout := session.config.getini(INI_REQEST_TIMEOUT):
            assert isinstance(cfg_req_timeout, str)
            try:
                req_timeout = float(cfg_req_timeout)
            except ValueError:
                warnings.warn(f"Invalid value for pytest config {INI_REQEST_TIMEOUT}: "
                                f"{cfg_req_timeout}. Defaulting to {req_timeout} seconds.")

        self._upload_reports(skip_ssl_verification, req_timeout, report_files)

    def pytest_terminal_summary(self, terminalreporter, exitstatus, config):
        if terminalreporter and self.uploaded_reports_url:
            testguide_url = os.environ.get("TESTGUIDE_URL")
            testguide_project_id = os.environ.get("TESTGUIDE_PROJECT_ID")
            if testguide_url is not None and testguide_project_id is not None:
                url = f"{testguide_url.rstrip('/')}/reports?20{self.uploaded_reports_url}&projectId={testguide_project_id}"
                msg = f"Successfully uploaded reports can be viewed at: {url}"
                terminalreporter.section("test.guide Upload")
                terminalreporter.write_line(msg)
            else:
                warnings.warn("Environment variables for test.guide aren't set correctly, cannot upload report!")


plugin = TestGuidePytest()
