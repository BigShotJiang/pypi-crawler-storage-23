"""Tests for Vite build output integrity.

Verifies the production build produces correct files for the Python dashboard server.
"""

import subprocess
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent.parent.parent.parent
DASHBOARD_DEV = PROJECT_ROOT / "tools" / "dashboard-dev"
DASHBOARD_PROD = PROJECT_ROOT / "tools" / "dashboard"
DIST = DASHBOARD_DEV / "dist"

EXPECTED_ICONS = [
    "a11y.svg",
    "accessibility.svg",
    "devops.svg",
    "file.svg",
    "folder-open.svg",
    "folder.svg",
    "principal.svg",
    "reports.svg",
    "security.svg",
    "settings.svg",
]


@pytest.fixture(scope="module")
def vite_build():
    """Run Vite build once for this test module."""
    if not (DASHBOARD_DEV / "node_modules").exists():
        pytest.skip("node_modules not installed; run `yarn install` in tools/dashboard-dev")

    result = subprocess.run(
        ["yarn", "build"],
        cwd=str(DASHBOARD_DEV),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert result.returncode == 0, f"Vite build failed:\n{result.stderr}"
    return result


class TestBuildOutputExists:

    def test_dist_index_html(self, vite_build):
        assert (DIST / "index.html").is_file()

    def test_dist_js(self, vite_build):
        assert (DIST / "static" / "js" / "dashboard.js").is_file()

    def test_dist_css(self, vite_build):
        assert (DIST / "static" / "css" / "dashboard.css").is_file()

    def test_dist_icons(self, vite_build):
        icons_dir = DIST / "static" / "icons"
        assert icons_dir.is_dir()
        for icon in EXPECTED_ICONS:
            assert (icons_dir / icon).is_file(), f"Missing icon: {icon}"


class TestDeployedOutput:

    def test_deployed_index_html(self, vite_build):
        assert (DASHBOARD_PROD / "templates" / "index.html").is_file()

    def test_deployed_js(self, vite_build):
        assert (DASHBOARD_PROD / "static" / "js" / "dashboard.js").is_file()

    def test_deployed_css(self, vite_build):
        assert (DASHBOARD_PROD / "static" / "css" / "dashboard.css").is_file()

    def test_deployed_icons(self, vite_build):
        icons_dir = DASHBOARD_PROD / "static" / "icons"
        assert icons_dir.is_dir()
        for icon in EXPECTED_ICONS:
            assert (icons_dir / icon).is_file(), f"Missing deployed icon: {icon}"


class TestBuiltIndexHtml:

    @pytest.fixture()
    def html(self, vite_build):
        return (DASHBOARD_PROD / "templates" / "index.html").read_text()

    def test_no_cdn_alpine(self, html):
        assert "cdn.jsdelivr.net/npm/alpinejs" not in html

    def test_no_cdn_marked(self, html):
        assert "cdn.jsdelivr.net/npm/marked" not in html

    def test_references_bundled_js(self, html):
        assert 'src="/static/js/dashboard.js"' in html

    def test_references_bundled_css(self, html):
        assert 'href="/static/css/dashboard.css"' in html

    def test_has_alpine_x_data(self, html):
        assert 'x-data="dashboard()"' in html

    def test_has_alpine_x_init(self, html):
        assert 'x-init="init()"' in html

    def test_no_vite_dev_script(self, html):
        assert "/src/main.ts" not in html


class TestBuiltJsContent:

    @pytest.fixture()
    def js(self, vite_build):
        return (DASHBOARD_PROD / "static" / "js" / "dashboard.js").read_text()

    def test_contains_dashboard_function(self, js):
        assert "dashboard" in js

    def test_contains_alpine_start(self, js):
        assert "Alpine" in js or "alpinejs" in js.lower()

    def test_contains_fetch_health(self, js):
        assert "/api/health" in js

    def test_contains_fetch_workflows(self, js):
        assert "/api/workflows" in js

    def test_contains_websocket_discovery(self, js):
        assert "/api/websocket" in js

    def test_contains_marked(self, js):
        assert "marked" in js.lower()

    def test_contains_severity_counts(self, js):
        assert "severityCounts" in js

    def test_contains_audit_types(self, js):
        assert "security_audit" in js
        assert "a11y_audit" in js
        assert "devops_audit" in js
        assert "principal_audit" in js

    def test_no_import_statements(self, js):
        assert "from '" not in js
        assert "from \"" not in js


class TestBuiltCssContent:

    @pytest.fixture()
    def css(self, vite_build):
        return (DASHBOARD_PROD / "static" / "css" / "dashboard.css").read_text()

    def test_has_css_variables(self, css):
        assert "--color-bg" in css
        assert "--color-accent" in css

    def test_has_sidebar_styles(self, css):
        assert ".sidebar" in css

    def test_has_finding_card_styles(self, css):
        assert ".finding-card" in css

    def test_has_toast_styles(self, css):
        assert ".toast" in css

    def test_has_modal_styles(self, css):
        assert ".modal-overlay" in css

    def test_has_report_styles(self, css):
        assert ".report-content" in css


class TestSourceDevFiles:

    def test_dev_index_has_module_script(self):
        html = (DASHBOARD_DEV / "index.html").read_text()
        assert 'src="/src/main.ts"' in html

    def test_dev_index_no_cdn(self):
        html = (DASHBOARD_DEV / "index.html").read_text()
        assert "cdn.jsdelivr.net" not in html

    def test_all_source_modules_exist(self):
        modules = [
            "main.ts", "app.ts", "api.ts", "websocket.ts",
            "workflow.ts", "findings.ts", "reports.ts",
            "fileTree.ts", "utils.ts", "exports.ts",
        ]
        for mod in modules:
            assert (DASHBOARD_DEV / "src" / mod).is_file(), f"Missing module: src/{mod}"

    def test_css_source_exists(self):
        assert (DASHBOARD_DEV / "css" / "dashboard.css").is_file()

    def test_public_icons_exist(self):
        icons_dir = DASHBOARD_DEV / "public" / "static" / "icons"
        for icon in EXPECTED_ICONS:
            assert (icons_dir / icon).is_file(), f"Missing dev icon: {icon}"
