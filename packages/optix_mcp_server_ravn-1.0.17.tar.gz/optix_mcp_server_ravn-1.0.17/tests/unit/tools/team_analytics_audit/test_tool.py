from __future__ import annotations

import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from tools.team_analytics_audit.tool import TeamAnalyticsAuditTool
from tools.team_analytics_audit.models import (
    FileChange,
    RawCommit,
    TeamAuditResponse,
)


def make_commit(name: str, email: str, day: int = 15) -> RawCommit:
    ts = datetime(2026, 1, day, 10, 0, 0, tzinfo=timezone.utc)
    return RawCommit(
        hash=f"hash-{day}-{name}",
        author_name=name,
        author_email=email,
        timestamp=ts,
        subject="feat: something",
        parent_hashes=["p1"],
        files_changed=[FileChange("src/main.py", 10, 2)],
        is_merge=False,
    )


FIXTURE_COMMITS = [
    make_commit("Alice", "alice@ex.com", 15),
    make_commit("Alice", "alice@ex.com", 16),
    make_commit("Bob", "bob@ex.com", 15),
]


@pytest.fixture()
def mock_collector():
    with patch("tools.team_analytics_audit.tool.GitDataCollector") as cls:
        instance = MagicMock()
        instance.collect.return_value = FIXTURE_COMMITS
        cls.return_value = instance
        yield instance


class TestTeamAnalyticsAuditToolExecute:
    def test_execute_returns_team_audit_response(self, mock_collector, tmp_path):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(project_root_path=str(tmp_path))
        assert isinstance(response, TeamAuditResponse)

    def test_response_has_non_empty_report_content(self, mock_collector, tmp_path):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(project_root_path=str(tmp_path))
        assert isinstance(response.report_content, str)
        assert len(response.report_content) > 0

    def test_response_report_path_ends_with_filename(self, mock_collector, tmp_path):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(project_root_path=str(tmp_path))
        assert response.report_path.endswith("TEAM_AUDIT_REPORT.md")

    def test_response_has_consolidated_summary_with_total_commits(
        self, mock_collector, tmp_path
    ):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(project_root_path=str(tmp_path))
        assert "total_commits" in response.consolidated_summary
        assert response.consolidated_summary["total_commits"] == len(FIXTURE_COMMITS)

    def test_response_has_steps_executed_list(self, mock_collector, tmp_path):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(project_root_path=str(tmp_path))
        assert isinstance(response.steps_executed, list)
        assert len(response.steps_executed) > 0

    def test_raises_value_error_no_git_repo(self, tmp_path):
        with patch("tools.team_analytics_audit.tool.GitDataCollector") as cls:
            instance = MagicMock()
            instance.collect.side_effect = ValueError("no_git_repo")
            cls.return_value = instance
            tool = TeamAnalyticsAuditTool()
            with pytest.raises(ValueError, match="no_git_repo"):
                tool.execute(project_root_path=str(tmp_path))

    def test_raises_value_error_author_not_found(self, tmp_path):
        with patch("tools.team_analytics_audit.tool.GitDataCollector") as cls:
            instance = MagicMock()
            instance.collect.side_effect = ValueError("author_not_found")
            cls.return_value = instance
            tool = TeamAnalyticsAuditTool()
            with pytest.raises(ValueError, match="author_not_found"):
                tool.execute(
                    author="NonExistent",
                    project_root_path=str(tmp_path),
                )

    def test_raises_value_error_no_commits(self, tmp_path):
        with patch("tools.team_analytics_audit.tool.GitDataCollector") as cls:
            instance = MagicMock()
            instance.collect.return_value = []
            cls.return_value = instance
            tool = TeamAnalyticsAuditTool()
            with pytest.raises(ValueError, match="no_commits"):
                tool.execute(project_root_path=str(tmp_path))

    def test_raises_value_error_invalid_period(self, tmp_path):
        tool = TeamAnalyticsAuditTool()
        with pytest.raises(ValueError, match="invalid_period"):
            tool.execute(period="not-a-valid-period", project_root_path=str(tmp_path))

    def test_execute_with_author_passes_author_to_collector(
        self, mock_collector, tmp_path
    ):
        tool = TeamAnalyticsAuditTool()
        tool.execute(author="Alice", project_root_path=str(tmp_path))
        call_kwargs = mock_collector.collect.call_args
        assert call_kwargs.kwargs.get("author") == "Alice"

    def test_execute_with_team_members_passes_team_members_to_collector(
        self, mock_collector, tmp_path
    ):
        tool = TeamAnalyticsAuditTool()
        tool.execute(
            team_members=["Alice", "Bob"],
            project_root_path=str(tmp_path),
        )
        call_kwargs = mock_collector.collect.call_args
        assert call_kwargs.kwargs.get("team_members") == ["Alice", "Bob"]

    def test_execute_with_compare_period_runs_two_collection_passes(
        self, mock_collector, tmp_path
    ):
        tool = TeamAnalyticsAuditTool()
        tool.execute(
            compare_period="last_30_days",
            project_root_path=str(tmp_path),
        )
        assert mock_collector.collect.call_count == 2
