import pytest

from tools.findings_to_tickets.models import (
    Platform,
    TicketData,
    TicketResponse,
    TicketResult,
)


class TestPlatform:
    def test_linear_value(self):
        assert Platform.LINEAR.value == "linear"

    def test_jira_value(self):
        assert Platform.JIRA.value == "jira"

    def test_from_string_linear(self):
        assert Platform.from_string("linear") == Platform.LINEAR

    def test_from_string_jira(self):
        assert Platform.from_string("jira") == Platform.JIRA

    def test_from_string_case_insensitive(self):
        assert Platform.from_string("LINEAR") == Platform.LINEAR
        assert Platform.from_string("Jira") == Platform.JIRA

    def test_from_string_with_whitespace(self):
        assert Platform.from_string("  linear  ") == Platform.LINEAR

    def test_from_string_invalid(self):
        with pytest.raises(ValueError, match="Invalid platform"):
            Platform.from_string("github")


class TestTicketData:
    def test_creation(self):
        ticket = TicketData(
            finding_id="f-001",
            title="[CRITICAL] SQL Injection",
            description="SQL injection vulnerability found",
            priority="1",
            labels=["security", "critical"],
            severity="critical",
            category="SQL Injection",
        )
        assert ticket.finding_id == "f-001"
        assert ticket.title == "[CRITICAL] SQL Injection"
        assert ticket.priority == "1"
        assert ticket.labels == ["security", "critical"]

    def test_to_dict(self):
        ticket = TicketData(
            finding_id="f-001",
            title="Test Title",
            description="Test description",
            priority="2",
            labels=["label1"],
            severity="high",
            category="XSS",
        )
        result = ticket.to_dict()
        assert result == {
            "finding_id": "f-001",
            "title": "Test Title",
            "description": "Test description",
            "priority": "2",
            "labels": ["label1"],
            "severity": "high",
            "category": "XSS",
        }

    def test_to_dict_returns_new_dict(self):
        ticket = TicketData(
            finding_id="f-001",
            title="Title",
            description="Desc",
            priority="3",
            labels=["a"],
            severity="medium",
            category="Cat",
        )
        dict1 = ticket.to_dict()
        dict2 = ticket.to_dict()
        assert dict1 is not dict2


class TestTicketResult:
    def test_creation_success(self):
        result = TicketResult(
            finding_id="f-001",
            ticket_id="LIN-123",
            ticket_url="https://linear.app/team/LIN-123",
            success=True,
        )
        assert result.finding_id == "f-001"
        assert result.ticket_id == "LIN-123"
        assert result.success is True
        assert result.error is None

    def test_creation_failure(self):
        result = TicketResult(
            finding_id="f-002",
            ticket_id="",
            ticket_url="",
            success=False,
            error="API rate limit exceeded",
        )
        assert result.success is False
        assert result.error == "API rate limit exceeded"

    def test_to_dict_success(self):
        result = TicketResult(
            finding_id="f-001",
            ticket_id="JIRA-456",
            ticket_url="https://jira.example.com/JIRA-456",
            success=True,
        )
        assert result.to_dict() == {
            "finding_id": "f-001",
            "ticket_id": "JIRA-456",
            "ticket_url": "https://jira.example.com/JIRA-456",
            "success": True,
            "error": None,
        }

    def test_to_dict_failure(self):
        result = TicketResult(
            finding_id="f-002",
            ticket_id="",
            ticket_url="",
            success=False,
            error="Connection timeout",
        )
        assert result.to_dict()["error"] == "Connection timeout"


class TestTicketResponse:
    def test_creation_success(self):
        ticket = TicketData(
            finding_id="f-001",
            title="Title",
            description="Desc",
            priority="1",
            labels=["label"],
            severity="critical",
            category="Cat",
        )
        response = TicketResponse(
            success=True,
            platform="linear",
            audit_dir_name="2026-02-18_14-30-45_security",
            tickets=[ticket],
            total_findings=5,
            selected_count=1,
        )
        assert response.success is True
        assert response.platform == "linear"
        assert len(response.tickets) == 1
        assert response.error is None

    def test_creation_failure(self):
        response = TicketResponse(
            success=False,
            platform="jira",
            audit_dir_name="invalid-audit",
            tickets=[],
            total_findings=0,
            selected_count=0,
            error="Audit not found",
        )
        assert response.success is False
        assert response.error == "Audit not found"

    def test_to_dict(self):
        ticket = TicketData(
            finding_id="f-001",
            title="Title",
            description="Desc",
            priority="2",
            labels=["a", "b"],
            severity="high",
            category="Cat",
        )
        response = TicketResponse(
            success=True,
            platform="linear",
            audit_dir_name="2026-02-18_security",
            tickets=[ticket],
            total_findings=10,
            selected_count=1,
        )
        result = response.to_dict()
        assert result["success"] is True
        assert result["platform"] == "linear"
        assert result["audit_dir_name"] == "2026-02-18_security"
        assert result["total_findings"] == 10
        assert result["selected_count"] == 1
        assert result["error"] is None
        assert len(result["tickets"]) == 1
        assert result["tickets"][0]["finding_id"] == "f-001"

    def test_to_dict_multiple_tickets(self):
        tickets = [
            TicketData(
                finding_id=f"f-{i}",
                title=f"Title {i}",
                description=f"Desc {i}",
                priority="3",
                labels=["label"],
                severity="medium",
                category="Cat",
            )
            for i in range(3)
        ]
        response = TicketResponse(
            success=True,
            platform="jira",
            audit_dir_name="audit-dir",
            tickets=tickets,
            total_findings=10,
            selected_count=3,
        )
        result = response.to_dict()
        assert len(result["tickets"]) == 3
        assert [t["finding_id"] for t in result["tickets"]] == ["f-0", "f-1", "f-2"]
