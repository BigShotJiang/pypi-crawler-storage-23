"""Compliance lens for DevOps audit."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComplianceLens(BaseLens):
    """Compliance lens focusing on SOC2, PCI-DSS, audit trails."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.COMPLIANCE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.COMPLIANCE,
            display_name="Compliance",
            description="Focus on SOC2, PCI-DSS, and audit trails",
            docker_rules=[
                LensRule(
                    id="COMP-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing HEALTHCHECK",
                    description="No HEALTHCHECK directive for monitoring",
                    severity_default="medium",
                    check_guidance=[
                        "Check for HEALTHCHECK directive",
                        "Verify health endpoint is tested",
                        "Look for appropriate interval settings",
                    ],
                ),
                LensRule(
                    id="COMP-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing Image Labels",
                    description="No org, version, or maintainer labels",
                    severity_default="low",
                    check_guidance=[
                        "Check for LABEL instructions",
                        "Verify org.opencontainers labels present",
                        "Look for version and maintainer metadata",
                    ],
                ),
                LensRule(
                    id="COMP-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Unpinned Package Versions",
                    description="apt-get/apk packages without versions",
                    severity_default="medium",
                    check_guidance=[
                        "Check apt-get install for version pinning",
                        "Verify apk add packages have versions",
                        "Look for reproducible package installation",
                    ],
                ),
                LensRule(
                    id="COMP-D004",
                    category=DevOpsCategory.DOCKERFILE,
                    name="No Vulnerability Scanning",
                    description="Missing image scanning step",
                    severity_default="high",
                    check_guidance=[
                        "Check for Trivy, Snyk, or similar scanning",
                        "Verify scanning in CI/CD pipeline",
                        "Look for scan results reporting",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="COMP-C001",
                    category=DevOpsCategory.CICD,
                    name="Missing CODEOWNERS",
                    description="No CODEOWNERS file for review enforcement",
                    severity_default="medium",
                    check_guidance=[
                        "Check for .github/CODEOWNERS file",
                        "Verify critical paths have owners assigned",
                        "Look for team-based ownership patterns",
                    ],
                ),
                LensRule(
                    id="COMP-C002",
                    category=DevOpsCategory.CICD,
                    name="No Required Reviewers",
                    description="Branch protection without required reviews",
                    severity_default="high",
                    check_guidance=[
                        "Check branch protection rules",
                        "Verify required reviewers configured",
                        "Look for bypass permissions",
                    ],
                ),
                LensRule(
                    id="COMP-C003",
                    category=DevOpsCategory.CICD,
                    name="Audit Logging Disabled",
                    description="No audit trail for deployments",
                    severity_default="high",
                    check_guidance=[
                        "Check for deployment logging",
                        "Verify audit events are captured",
                        "Look for traceability of changes",
                    ],
                ),
                LensRule(
                    id="COMP-C004",
                    category=DevOpsCategory.CICD,
                    name="Force Push Allowed",
                    description="Force push enabled on protected branches",
                    severity_default="medium",
                    check_guidance=[
                        "Check branch protection for force push",
                        "Verify history preservation enforced",
                        "Look for signed commits requirement",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="COMP-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No License Compliance",
                    description="Missing license compatibility check",
                    severity_default="medium",
                    check_guidance=[
                        "Check for license scanning in CI",
                        "Verify GPL/AGPL detection",
                        "Look for license policy enforcement",
                    ],
                ),
                LensRule(
                    id="COMP-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Missing SBOM Generation",
                    description="No Software Bill of Materials",
                    severity_default="medium",
                    check_guidance=[
                        "Check for SBOM generation step",
                        "Verify CycloneDX or SPDX format used",
                        "Look for SBOM artifact storage",
                    ],
                ),
                LensRule(
                    id="COMP-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No Dependency Audit",
                    description="npm audit or equivalent not in CI",
                    severity_default="high",
                    check_guidance=[
                        "Check for npm audit in CI pipeline",
                        "Verify audit failure blocks deployment",
                        "Look for vulnerability thresholds",
                    ],
                ),
                LensRule(
                    id="COMP-P004",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Outdated Security Patches",
                    description="Known vulnerabilities not patched",
                    severity_default="high",
                    check_guidance=[
                        "Check for known CVEs in dependencies",
                        "Verify security patches applied timely",
                        "Look for overdue updates",
                    ],
                ),
            ],
        )
