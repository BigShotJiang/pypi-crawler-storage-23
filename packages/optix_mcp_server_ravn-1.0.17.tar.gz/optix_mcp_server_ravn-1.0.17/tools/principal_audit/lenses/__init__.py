"""Principal Audit Lenses - Specialized code quality analysis perspectives.

Available lenses:
- frontend: Frontend Developer - UI, state management, rendering
- backend: Backend Developer - API, data access, business logic
- performance: Performance Engineer - algorithms, bottlenecks, resources
- techlead: Tech Lead - architecture, patterns, conventions
- comprehensive: Full code quality review (default)
"""

from typing import Optional, Union

from tools.principal_audit.category import PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule
from tools.principal_audit.lenses.backend import BackendLens
from tools.principal_audit.lenses.comprehensive import ComprehensiveLens
from tools.principal_audit.lenses.frontend import FrontendLens
from tools.principal_audit.lenses.performance import PerformanceLens
from tools.principal_audit.lenses.techlead import TechLeadLens

LENS_REGISTRY: dict[PrincipalLens, type[BaseLens]] = {
    PrincipalLens.FRONTEND: FrontendLens,
    PrincipalLens.BACKEND: BackendLens,
    PrincipalLens.PERFORMANCE: PerformanceLens,
    PrincipalLens.TECHLEAD: TechLeadLens,
    PrincipalLens.COMPREHENSIVE: ComprehensiveLens,
}


def get_lens(lens_type: Optional[Union[PrincipalLens, str]] = None) -> BaseLens:
    """Get a lens instance by type.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        BaseLens instance for the specified type
    """
    if isinstance(lens_type, str):
        lens_type = PrincipalLens.from_string(lens_type)
    elif lens_type is None:
        lens_type = PrincipalLens.COMPREHENSIVE

    lens_class = LENS_REGISTRY.get(lens_type, ComprehensiveLens)
    return lens_class()


def get_lens_config(lens_type: Optional[Union[PrincipalLens, str]] = None) -> LensConfig:
    """Get the configuration for a lens.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        LensConfig for the specified lens
    """
    return get_lens(lens_type).get_config()


def list_available_lenses() -> list[dict[str, str]]:
    """List all available lenses with descriptions.

    Returns:
        List of dicts with id, display_name, and description
    """
    return [
        {
            "id": lens.value,
            "display_name": lens.display_name,
            "description": lens.description,
        }
        for lens in PrincipalLens
    ]


__all__ = [
    "BaseLens",
    "LensConfig",
    "LensRule",
    "FrontendLens",
    "BackendLens",
    "PerformanceLens",
    "TechLeadLens",
    "ComprehensiveLens",
    "LENS_REGISTRY",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
