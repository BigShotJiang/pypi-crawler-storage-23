from __future__ import annotations

from datetime import datetime

from tools.team_analytics_audit.models import (
    AreaHealth,
    ContributorProfile,
    TeamAuditResult,
    VelocityTrend,
)

STEP_NAMES = [
    "Collect",
    "Measure",
    "Quality",
    "Collaborate",
    "Diagnose",
    "Trends",
    "Report",
]


def _fmt_date(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d")


def _fmt_datetime(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M UTC")


def _health_badge(status: str) -> str:
    badges = {
        "Healthy": "🟢 Healthy",
        "Needs Attention": "🟡 Needs Attention",
        "At Risk": "🔴 At Risk",
    }
    return badges.get(status, status)


def _trajectory_badge(trajectory: str) -> str:
    badges = {
        "accelerating": "📈 Accelerating",
        "stable": "➡️ Stable",
        "decelerating": "📉 Decelerating",
    }
    return badges.get(trajectory, trajectory)


def _render_header(result: TeamAuditResult, author: str | None) -> str:
    period = (
        f"{_fmt_date(result.period_start)} to "
        f"{_fmt_date(result.period_end)}"
    )
    scope = f" (filtered by: {author})" if author else ""
    executed = sum(
        1 for s in result.steps_executed if s.status == "executed"
    )
    skipped = sum(
        1 for s in result.steps_executed if s.status == "skipped"
    )
    return (
        f"# Team Analytics Audit Report\n\n"
        f"**Repository**: {result.repository_name}{scope}  \n"
        f"**Period**: {period}  \n"
        f"**Generated**: {_fmt_datetime(result.generated_at)}  \n"
        f"**Steps**: {executed} executed, {skipped} skipped\n\n"
    )


def _render_overview(result: TeamAuditResult) -> str:
    health = result.team_health
    velocity = result.velocity
    lines = [
        "## Team Overview & Health\n\n",
        f"**Health Status**: {_health_badge(health.health_status)}  \n",
        f"**Velocity**: {_trajectory_badge(velocity.trajectory)}  \n\n",
        "| Metric | Value |\n",
        "|--------|-------|\n",
        f"| Total Commits | {result.total_commits} |\n",
        f"| Active Contributors | {len(result.contributors)} |\n",
        f"| Bus Factor | {health.overall_bus_factor} |\n",
        f"| Workload Gini Index | "
        f"{health.workload_gini_index:.2f} (0=equal, 1=unequal) |\n",
        f"| Knowledge Silos | {len(health.knowledge_silos)} |\n\n",
    ]
    return "".join(lines)


def _render_contributor(
    profile: ContributorProfile, author: str | None
) -> str:
    highlight = (
        author
        and author.lower() in profile.name.lower()
    )
    prefix = "### ⭐ " if highlight else "### "
    top_areas = sorted(
        profile.areas_of_impact.items(),
        key=lambda x: x[1],
        reverse=True,
    )[:3]
    area_str = ", ".join(f"{a[0]} ({a[1]})" for a in top_areas)
    return (
        f"{prefix}{profile.name}\n\n"
        f"| Metric | Value |\n"
        f"|--------|-------|\n"
        f"| Commits | {profile.commit_count} |\n"
        f"| Lines Added | {profile.lines_added} |\n"
        f"| Lines Deleted | {profile.lines_deleted} |\n"
        f"| Files Touched | {len(profile.files_touched)} |\n"
        f"| Avg Commit Size | "
        f"{profile.avg_commit_size:.0f} lines |\n"
        f"| Conventional Commit Rate | "
        f"{profile.quality_signals.conventional_commit_rate:.0%} |\n"
        f"| Atomic Commit Rate | "
        f"{profile.quality_signals.atomic_commit_rate:.0%} |\n"
        f"| Co-authored Commits | "
        f"{profile.collaboration.co_authored_commits} |\n"
        f"| Top Areas | {area_str or 'N/A'} |\n\n"
    )


def _render_contributors(
    contributors: list[ContributorProfile], author: str | None
) -> str:
    sorted_contributors = sorted(
        contributors, key=lambda c: c.commit_count, reverse=True
    )
    sections = [_render_contributor(c, author) for c in sorted_contributors]
    return "## Individual Contributor Summaries\n\n" + "".join(sections)


def _render_collaboration(result: TeamAuditResult) -> str:
    lines = ["## Collaboration Map\n\n"]

    co_authored = [
        c for c in result.contributors
        if c.collaboration.co_authored_commits > 0
    ]
    if co_authored:
        lines.append("### Co-authorship Activity\n\n")
        for c in sorted(
            co_authored,
            key=lambda x: x.collaboration.co_authored_commits,
            reverse=True,
        ):
            lines.append(
                f"- **{c.name}**: "
                f"{c.collaboration.co_authored_commits} co-authored "
                f"commits\n"
            )
        lines.append("\n")

    shared_owners = [
        c for c in result.contributors
        if c.collaboration.shared_file_authors
    ]
    if shared_owners:
        lines.append("### Shared File Ownership\n\n")
        for c in shared_owners[:5]:
            for other, count in sorted(
                c.collaboration.shared_file_authors.items(),
                key=lambda x: x[1],
                reverse=True,
            )[:3]:
                lines.append(
                    f"- **{c.name}** ↔ **{other}**: "
                    f"{count} shared files\n"
                )
        lines.append("\n")

    return "".join(lines)


def _render_risks(result: TeamAuditResult) -> str:
    health = result.team_health
    lines = ["## Risks & Bottlenecks\n\n"]

    if health.knowledge_silos:
        lines.append("### Knowledge Silos\n\n")
        for silo in health.knowledge_silos:
            lines.append(
                f"- **{silo.path}**: sole owner is "
                f"{silo.primary_owner} "
                f"({silo.owner_percentage:.0%} of commits)\n"
            )
        lines.append("\n")

    if health.workload_gini_index >= 0.5:
        lines.append(
            "### Workload Imbalance\n\n"
            f"Gini index: **{health.workload_gini_index:.2f}** "
            "(high concentration of work in few contributors)\n\n"
        )

    bulk_contributors = [
        c for c in result.contributors
        if c.quality_signals.bulk_commit_count > 0
    ]
    if bulk_contributors:
        lines.append("### Large Commit Patterns\n\n")
        for c in bulk_contributors:
            lines.append(
                f"- **{c.name}**: "
                f"{c.quality_signals.bulk_commit_count} "
                f"bulk commits (>500 lines)\n"
            )
        lines.append("\n")

    if not (health.knowledge_silos or bulk_contributors):
        lines.append("No significant risks detected.\n\n")

    return "".join(lines)


def _render_velocity(result: TeamAuditResult) -> str:
    velocity = result.velocity
    lines = [
        "## Velocity & Trends\n\n",
        f"**Trajectory**: {_trajectory_badge(velocity.trajectory)}\n\n",
    ]

    if velocity.weekly_commits:
        lines.append("### Weekly Activity\n\n")
        lines.append("| Week | Commits | Contributors |\n")
        lines.append("|------|---------|-------------|\n")
        for week in sorted(velocity.weekly_commits.keys())[-8:]:
            commits = velocity.weekly_commits[week]
            contributors = velocity.weekly_contributors.get(week, 0)
            lines.append(f"| {week} | {commits} | {contributors} |\n")
        lines.append("\n")

    if velocity.comparison_delta is not None:
        delta = velocity.comparison_delta
        lines.append("### Period Comparison\n\n")
        lines.append("| Metric | Change |\n")
        lines.append("|--------|--------|\n")
        lines.append(
            f"| Commits | {delta.commit_count_delta:+.1f}% |\n"
        )
        lines.append(
            f"| Contributors | "
            f"{delta.contributor_count_delta:+.1f}% |\n"
        )
        lines.append(
            f"| Avg Commit Size | "
            f"{delta.avg_commit_size_delta:+.1f}% |\n"
        )
        lines.append(
            f"| Collaboration | "
            f"{delta.collaboration_delta:+.1f}% |\n"
        )
        lines.append("\n")

    return "".join(lines)


def _render_recommendations(result: TeamAuditResult) -> str:
    lines = ["## Recommendations\n\n"]
    for i, rec in enumerate(result.recommendations, 1):
        lines.append(f"{i}. {rec}\n")
    lines.append("\n")
    return "".join(lines)


class TeamAuditReportGenerator:
    def generate(
        self,
        result: TeamAuditResult,
        author: str | None = None,
    ) -> str:
        sections = [
            _render_header(result, author),
            _render_overview(result),
            _render_contributors(result.contributors, author),
            _render_collaboration(result),
            _render_risks(result),
            _render_velocity(result),
            _render_recommendations(result),
        ]
        return "".join(sections)
