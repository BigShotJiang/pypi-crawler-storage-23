from dataclasses import asdict, dataclass
from enum import Enum


class Platform(Enum):
    LINEAR = "linear"
    JIRA = "jira"

    @classmethod
    def from_string(cls, value: str) -> "Platform":
        normalized = value.lower().strip()
        for platform in cls:
            if platform.value == normalized:
                return platform
        raise ValueError(f"Invalid platform: {value}. Must be 'linear' or 'jira'")


@dataclass
class TicketData:
    finding_id: str
    title: str
    description: str
    priority: str
    labels: list[str]
    severity: str
    category: str

    def to_dict(self) -> dict[str, str | list[str]]:
        return asdict(self)


@dataclass
class TicketResult:
    finding_id: str
    ticket_id: str
    ticket_url: str
    success: bool
    error: str | None = None

    def to_dict(self) -> dict[str, str | bool | None]:
        return asdict(self)


@dataclass
class TicketResponse:
    success: bool
    platform: str
    audit_dir_name: str
    tickets: list[TicketData]
    total_findings: int
    selected_count: int
    error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "success": self.success,
            "platform": self.platform,
            "audit_dir_name": self.audit_dir_name,
            "tickets": [t.to_dict() for t in self.tickets],
            "total_findings": self.total_findings,
            "selected_count": self.selected_count,
            "error": self.error,
        }
