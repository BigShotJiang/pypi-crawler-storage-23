// Jira Projects Extension for Optix Dashboard
// Extends the dashboard() function to add Jira project selector functionality

(function() {
  const originalDashboard = window.dashboard;

  window.dashboard = function() {
    const dashboardInstance = originalDashboard();

    // Add jiraProjects array
    dashboardInstance.jiraProjects = [];

    // Add fetchJiraProjects function
    dashboardInstance.fetchJiraProjects = async function() {
      if (this.jiraProjects.length > 0) return;

      try {
        const response = await fetch('/api/tickets/teams?platform=jira');
        if (response.ok) {
          const data = await response.json();
          this.jiraProjects = data.data || data || [];
        }
      } catch (error) {
        console.error('Failed to fetch Jira projects:', error);
        this.jiraProjects = [];
      }
    };

    return dashboardInstance;
  };
})();
