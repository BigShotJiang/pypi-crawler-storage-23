"""Screen Reader User lens for Accessibility Audit.

Focuses on accessibility from a screen reader user's perspective:
- ARIA labels and roles
- Semantic HTML structure
- Announcements and live regions
- Alt text and image descriptions
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule


class ScreenReaderLens(BaseLens):
    """Screen Reader User accessibility perspective.

    Examines code from the viewpoint of a user navigating with a screen reader,
    focusing on content that can be programmatically determined.
    """

    @property
    def lens_type(self) -> A11yLens:
        return A11yLens.SCREENREADER

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=A11yLens.SCREENREADER,
            display_name="Screen Reader User",
            description="ARIA labels, semantic HTML, announcements, alt text",
            structure_rules=[
                LensRule(
                    id="SR-S001",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="Heading Structure",
                    description="Verify logical heading hierarchy for navigation",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check for single h1 per page",
                        "Verify heading levels don't skip (h1 -> h3)",
                        "Ensure headings describe content sections",
                    ],
                ),
                LensRule(
                    id="SR-S002",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="Landmark Regions",
                    description="Verify page landmarks for screen reader navigation",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check for main, nav, header, footer landmarks",
                        "Verify landmarks have accessible names if duplicated",
                        "Ensure content is within landmarks",
                    ],
                ),
            ],
            aria_rules=[
                LensRule(
                    id="SR-A001",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="Button and Link Labels",
                    description="Verify interactive elements have accessible names",
                    wcag_criterion="4.1.2",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check buttons have visible text or aria-label",
                        "Verify icon buttons have accessible names",
                        "Ensure links describe their destination",
                        "Check for generic 'click here' link text",
                    ],
                ),
                LensRule(
                    id="SR-A002",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="Form Labels",
                    description="Verify form inputs have associated labels",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all inputs have associated label elements",
                        "Verify label for/id associations are correct",
                        "Check for aria-labelledby where appropriate",
                    ],
                ),
                LensRule(
                    id="SR-A003",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="ARIA Roles",
                    description="Verify correct ARIA role usage",
                    wcag_criterion="4.1.2",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check for appropriate role usage",
                        "Verify custom widgets have correct roles",
                        "Ensure role supports required states/properties",
                    ],
                ),
                LensRule(
                    id="SR-A004",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="Live Regions",
                    description="Verify dynamic content announcements",
                    wcag_criterion="4.1.3",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check for aria-live on dynamic content",
                        "Verify appropriate politeness settings",
                        "Check status messages use role='status'",
                    ],
                ),
            ],
            keyboard_rules=[
                LensRule(
                    id="SR-K001",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Focusable Element Order",
                    description="Verify screen reader reading order matches visual",
                    wcag_criterion="1.3.2",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check DOM order matches visual reading order",
                        "Verify no confusing tabindex values",
                    ],
                ),
            ],
            focus_rules=[
                LensRule(
                    id="SR-F001",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus on Dynamic Content",
                    description="Verify focus management for modals and dynamic content",
                    wcag_criterion="2.4.3",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check focus moves to modal when opened",
                        "Verify focus returns when modal closes",
                        "Check focus management for dynamically added content",
                    ],
                ),
            ],
            color_rules=[],
            semantic_rules=[
                LensRule(
                    id="SR-SM001",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Image Alternatives",
                    description="Verify all images have appropriate alt text",
                    wcag_criterion="1.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all img elements have alt attributes",
                        "Verify decorative images have empty alt=''",
                        "Check complex images have long descriptions",
                        "Verify background images with meaning have text alternatives",
                    ],
                ),
                LensRule(
                    id="SR-SM002",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Table Accessibility",
                    description="Verify data tables are properly marked up",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check tables have th elements for headers",
                        "Verify scope attributes on complex tables",
                        "Check for caption or aria-label on tables",
                    ],
                ),
            ],
        )
