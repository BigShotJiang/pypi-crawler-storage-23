"""Accessibility Audit Lenses - Specialized accessibility analysis perspectives.

Available lenses:
- screenreader: Screen Reader User - ARIA, semantics, announcements, alt text
- keyboard: Keyboard-Only User - tab order, focus, shortcuts, traps
- visual: Visual Accessibility - contrast, text sizing, color independence
- wcag: WCAG Compliance - WCAG 2.1/2.2 success criteria verification
- comprehensive: Full accessibility review (default)
"""

from typing import Optional, Union

from tools.a11y_audit.domains import A11yLens
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule
from tools.a11y_audit.lenses.comprehensive import ComprehensiveLens
from tools.a11y_audit.lenses.keyboard import KeyboardLens
from tools.a11y_audit.lenses.screenreader import ScreenReaderLens
from tools.a11y_audit.lenses.visual import VisualLens
from tools.a11y_audit.lenses.wcag import WCAGLens

LENS_REGISTRY: dict[A11yLens, type[BaseLens]] = {
    A11yLens.SCREENREADER: ScreenReaderLens,
    A11yLens.KEYBOARD: KeyboardLens,
    A11yLens.VISUAL: VisualLens,
    A11yLens.WCAG: WCAGLens,
    A11yLens.COMPREHENSIVE: ComprehensiveLens,
}


def get_lens(lens_type: Optional[Union[A11yLens, str]] = None) -> BaseLens:
    """Get a lens instance by type.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        BaseLens instance for the specified type
    """
    if isinstance(lens_type, str):
        lens_type = A11yLens.from_string(lens_type)
    elif lens_type is None:
        lens_type = A11yLens.COMPREHENSIVE

    lens_class = LENS_REGISTRY.get(lens_type, ComprehensiveLens)
    return lens_class()


def get_lens_config(lens_type: Optional[Union[A11yLens, str]] = None) -> LensConfig:
    """Get the configuration for a lens.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        LensConfig for the specified lens
    """
    return get_lens(lens_type).get_config()


def list_available_lenses() -> list[dict[str, str]]:
    """List all available lenses with descriptions.

    Returns:
        List of dicts with id, display_name, and description
    """
    return [
        {
            "id": lens.value,
            "display_name": lens.display_name,
            "description": lens.description,
        }
        for lens in A11yLens
    ]


__all__ = [
    "BaseLens",
    "LensConfig",
    "LensRule",
    "ScreenReaderLens",
    "KeyboardLens",
    "VisualLens",
    "WCAGLens",
    "ComprehensiveLens",
    "LENS_REGISTRY",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
