"""Installation wizard orchestration."""

import os
import platform
import sys
from dataclasses import dataclass, field

from cli.installer.agents import (
    AGENTS,
    AgentConfig,
    ConfigFormat,
    get_agent,
    get_all_agents,
)
from cli.installer.config_writers import JSONConfigWriter, TOMLConfigWriter
from cli.installer.ui import AgentChoice, ConsoleUI
from cli.installer.uv_manager import ensure_uv


@dataclass
class InstallationOptions:
    """Options for the installation wizard."""
    agents: list[str] = field(default_factory=list)
    scope: str = ""
    expert: bool | None = None
    quiet: bool = False
    verbose: bool = False
    skip_lenses: bool = False
    skip_tickets: bool = False


class InstallationWizard:
    """Main installation wizard orchestrator."""

    def __init__(self, options: InstallationOptions | None = None):
        self.options = options or InstallationOptions()
        self.ui = ConsoleUI(
            quiet=self.options.quiet,
            verbose=self.options.verbose,
        )
        self.selected_agents: list[str] = []
        self.scope: str = ""
        self.expert_enabled: bool = False
        self.api_keys: dict[str, str] = {
            "openai": "",
        }
        self.os_type: str = ""
        self.dashboard_enabled: bool = False
        self.dashboard_port: int = 24282
        self.default_lenses: dict[str, str] = {
            "security": "comprehensive",
            "a11y": "comprehensive",
            "devops": "comprehensive",
            "principal": "comprehensive",
        }
        self.linear_enabled: bool = False
        self.linear_api_key: str = ""
        self.jira_enabled: bool = False
        self.jira_api_token: str = ""
        self.jira_user_email: str = ""
        self.jira_instance_url: str = ""
        self.slack_enabled: bool = False
        self.slack_bot_token: str = ""
        self.slack_channel_id: str = ""
        self.slack_severity_filter: list[str] = []

    def run(self) -> bool:
        """Run the installation wizard.

        Returns:
            True if installation completed successfully
        """
        try:
            self.ui.show_header()

            self._detect_os()

            if not ensure_uv(self.ui):
                return False

            self._select_agents()
            self._select_scope()
            self._configure_lenses()
            self._configure_expert()
            self._configure_dashboard()
            self._configure_ticket_integrations()
            self._configure_slack()
            self._configure_agents()

            self.ui.show_completion(
                agents=self.selected_agents,
                scope=self.scope,
                expert_enabled=self.expert_enabled,
                dashboard_enabled=self.dashboard_enabled,
                dashboard_port=self.dashboard_port,
                default_lenses=self.default_lenses,
                linear_enabled=self.linear_enabled,
                jira_enabled=self.jira_enabled,
                slack_enabled=self.slack_enabled,
                slack_channel_id=self.slack_channel_id,
                slack_severity_filter=self.slack_severity_filter,
            )

            return True

        except KeyboardInterrupt:
            self.ui.newline()
            self.ui.warn("Installation interrupted. Run the wizard again to start fresh.")
            return False

    def _detect_os(self) -> None:
        """Detect and validate operating system."""
        self.ui.info("Detecting operating system...")

        system = platform.system()

        if system == "Darwin":
            self.os_type = "macos"
            self.ui.success("Detected macOS")
        elif system == "Linux":
            self.os_type = "linux"
            self.ui.success("Detected Linux")
        elif system == "Windows":
            self.os_type = "windows"
            self.ui.success("Detected Windows")
        else:
            self.ui.error(f"Unsupported operating system: {system}")
            self.ui.error("This installer supports macOS, Linux, and Windows.")
            sys.exit(1)

    def _select_agents(self) -> None:
        """Select which agents to configure."""
        if self.options.agents:
            for agent_name in self.options.agents:
                agent = get_agent(agent_name)
                if not agent:
                    self.ui.error(f"Unknown agent: {agent_name}")
                    self.ui.error(f"Valid agents: {', '.join(AGENTS.keys())}")
                    sys.exit(1)
                self.selected_agents.append(agent_name.lower())

            if not self.selected_agents:
                self.ui.error("At least one agent must be selected")
                sys.exit(1)

            self.ui.info(f"Selected agents: {', '.join(self.selected_agents)}")
            return

        self.ui.newline()
        choices = [
            AgentChoice(name=agent.name, label=agent.label)
            for agent in get_all_agents()
        ]

        self.selected_agents = self.ui.select_agents(choices)
        self.ui.success(f"Selected agents: {', '.join(self.selected_agents)}")

    def _select_scope(self) -> None:
        """Select installation scope (global/local)."""
        if self.options.scope:
            if self.options.scope not in ("global", "local"):
                self.ui.error(f"Invalid scope: {self.options.scope}")
                self.ui.error("Scope must be 'global' or 'local'")
                sys.exit(1)

            self.scope = self.options.scope
            self.ui.info(f"Installation scope: {self.scope}")
            return

        self.ui.newline()
        self.scope = self.ui.select_scope()
        self.ui.success(f"Installation scope: {self.scope}")

    def _configure_lenses(self) -> None:
        """Configure default lenses for each audit type."""
        if self.options.skip_lenses:
            self.ui.info("Using default lenses (comprehensive) for all audit types")
            return

        self.ui.newline()
        self.ui.info("Configure Default Audit Lenses")
        self.ui.console.print(
            "  Each audit tool supports specialized lenses for focused analysis.\n"
            "  Select default lenses or press Enter to use 'Comprehensive' for all.\n"
        )

        configure_lenses = self.ui.select_yes_no(
            "Configure default lenses for audit tools?",
            default=False
        )

        if not configure_lenses:
            self.ui.info("Using default lenses (comprehensive) for all audit types")
            return

        audit_types = [
            ("security", "Security Audit"),
            ("a11y", "Accessibility Audit"),
            ("devops", "DevOps Audit"),
            ("principal", "Principal Audit"),
        ]

        self.ui.newline()
        for audit_type, audit_label in audit_types:
            lens = self.ui.select_lens(audit_type, audit_label)
            self.default_lenses[audit_type] = lens

        self.ui.show_lens_summary(self.default_lenses)
        self.ui.success("Lens configuration complete")

    def _configure_expert(self) -> None:
        """Configure expert analysis feature."""
        if self.options.expert is not None:
            self.expert_enabled = self.options.expert
            status = "enabled" if self.expert_enabled else "disabled"
            self.ui.info(f"Expert analysis: {status}")

            if self.expert_enabled:
                self._prompt_api_keys()
            return

        self.ui.newline()
        self.ui.info("Enable Expert Analysis (multi-LLM consensus)?")
        self.ui.console.print(
            "  Expert analysis uses multiple OpenAI models for improved accuracy.\n"
            "  Requires an OpenAI API key."
        )
        self.ui.newline()

        self.expert_enabled = self.ui.select_yes_no("Enable expert analysis?", default=False)

        if self.expert_enabled:
            self._prompt_api_keys()
        else:
            self.ui.info("Expert analysis disabled")

    def _configure_dashboard(self) -> None:
        """Configure dashboard UI settings."""
        self.ui.newline()
        self.ui.info("Dashboard UI Configuration")
        self.ui.console.print(
            "  The dashboard provides a web interface for viewing audit results.\n"
        )

        self.dashboard_enabled = self.ui.select_yes_no(
            "Enable dashboard UI?",
            default=False
        )

        if self.dashboard_enabled:
            self.dashboard_port = self.ui.prompt_port(
                "Dashboard port:",
                default=24282
            )
            self.ui.success(f"Dashboard will run on port {self.dashboard_port}")
        else:
            self.ui.info("Dashboard disabled")

    def _configure_ticket_integrations(self) -> None:
        """Configure ticket integration (Linear/Jira) for findings-to-tickets feature."""
        if self.options.skip_tickets:
            self.ui.info("Skipping ticket integration configuration")
            return

        self.ui.newline()
        self.ui.info("Ticket Integration Configuration")
        self.ui.console.print(
            "  Create tickets from audit findings directly in Linear or Jira.\n"
            "  Requires API keys for the platforms you want to use.\n"
        )

        configure_tickets = self.ui.select_yes_no(
            "Configure ticket integrations?",
            default=False
        )

        if not configure_tickets:
            self.ui.info("Ticket integrations skipped")
            return

        self._configure_linear()
        self._configure_jira()

    def _configure_linear(self) -> None:
        """Configure Linear integration."""
        self.ui.newline()
        self.ui.info("Linear Integration")

        existing_key = os.environ.get("OPTIX_LINEAR_API_KEY", "")
        if existing_key:
            self.ui.info(f"Detected existing Linear API key: ***{existing_key[-4:]}")
            use_existing = self.ui.select_yes_no("Use detected key?", default=True)
            if use_existing:
                self.linear_enabled = True
                self.linear_api_key = existing_key
                self.ui.success("Linear integration enabled")
                return

        enable_linear = self.ui.select_yes_no("Enable Linear integration?", default=False)
        if not enable_linear:
            self.ui.info("Linear integration disabled")
            return

        self.ui.console.print("  Get your API key from: Linear → Settings → API → Personal API Keys\n")
        api_key = self.ui.prompt_password("  Linear API Key:")

        if not api_key:
            self.ui.warn("No API key provided. Linear integration disabled.")
            return

        self.linear_enabled = True
        self.linear_api_key = api_key
        self.ui.success("Linear integration enabled")

    def _configure_jira(self) -> None:
        """Configure Jira integration."""
        self.ui.newline()
        self.ui.info("Jira Integration")

        existing_token = os.environ.get("OPTIX_JIRA_API_TOKEN", "")
        if existing_token:
            self.ui.info(f"Detected existing Jira API token: ***{existing_token[-4:]}")
            use_existing = self.ui.select_yes_no("Use detected token?", default=True)
            if use_existing:
                self.jira_enabled = True
                self.jira_api_token = existing_token
                self.jira_user_email = os.environ.get("OPTIX_JIRA_USER_EMAIL", "")
                self.jira_instance_url = os.environ.get("OPTIX_JIRA_INSTANCE_URL", "")
                self.ui.success("Jira integration enabled")
                return

        enable_jira = self.ui.select_yes_no("Enable Jira integration?", default=False)
        if not enable_jira:
            self.ui.info("Jira integration disabled")
            return

        self.ui.console.print(
            "  Get your API token from: https://id.atlassian.com/manage-profile/security/api-tokens\n"
        )

        api_token = self.ui.prompt_password("  Jira API Token:")
        if not api_token:
            self.ui.warn("No API token provided. Jira integration disabled.")
            return

        user_email = self.ui.prompt_text("  Jira User Email:")
        if not user_email:
            self.ui.warn("No email provided. Jira integration disabled.")
            return

        instance_url = self.ui.prompt_text(
            "  Jira Instance URL (e.g., https://yourcompany.atlassian.net):"
        )
        if not instance_url:
            self.ui.warn("No instance URL provided. Jira integration disabled.")
            return

        self.jira_enabled = True
        self.jira_api_token = api_token
        self.jira_user_email = user_email
        self.jira_instance_url = instance_url
        self.ui.success("Jira integration enabled")
    def _configure_slack(self) -> None:
        """Configure Slack notifications."""
        self.ui.newline()
        self.ui.info("Slack Notifications Configuration")
        self.ui.console.print(
            "  Send audit findings to a Slack channel automatically.\n"
        )

        existing_token = os.environ.get("SLACK_BOT_TOKEN", "")
        existing_channel = os.environ.get("SLACK_CHANNEL_ID", "")
        existing_enabled = os.environ.get("SLACK_ENABLED", "false").lower() == "true"

        if existing_enabled and existing_token and existing_channel:
            self.ui.info("Detected existing Slack configuration:")
            self.ui.console.print(f"    Channel ID: {existing_channel}")
            self.ui.console.print(f"    Bot Token: ***{existing_token[-4:]}")
            self.ui.newline()

            use_existing = self.ui.select_yes_no(
                "Use existing Slack configuration?",
                default=True
            )

            if use_existing:
                self.slack_enabled = True
                self.slack_bot_token = existing_token
                self.slack_channel_id = existing_channel
                existing_filter = os.environ.get("SLACK_SEVERITY_FILTER", "all")
                if existing_filter == "all":
                    self.slack_severity_filter = ["critical", "high", "medium", "low", "info"]
                else:
                    self.slack_severity_filter = [s.strip() for s in existing_filter.split(",") if s.strip()]
                self.ui.success("Using existing Slack configuration")
                return

        self.slack_enabled = self.ui.select_yes_no(
            "Enable Slack notifications?",
            default=False
        )

        if not self.slack_enabled:
            self.ui.info("Slack notifications disabled")
            return

        self.slack_bot_token = self.ui.prompt_password("Slack Bot Token:")
        if not self.slack_bot_token:
            self.ui.warn("No Bot Token provided. Slack notifications will be disabled.")
            self.slack_enabled = False
            return

        self.slack_channel_id = self.ui.prompt_text("Slack Channel ID:")
        if not self.slack_channel_id:
            self.ui.warn("No Channel ID provided. Slack notifications will be disabled.")
            self.slack_enabled = False
            return

        self.slack_severity_filter = self.ui.select_severity_filter()
        severity_display = ", ".join(self.slack_severity_filter)
        self.ui.success(f"Slack notifications configured (filter: {severity_display})")

    def _prompt_api_keys(self) -> None:
        """Prompt for API keys or use existing environment variables."""
        self.ui.newline()
        self.ui.info("Configure LLM API Keys:")

        existing_keys = {
            "openai": os.environ.get("OPENAI_API_KEY", ""),
        }

        has_existing = any(existing_keys.values())

        if has_existing:
            self.ui.info("Detected existing API key in environment:")
            if existing_keys["openai"]:
                self.ui.console.print(f"    OpenAI: ***{existing_keys['openai'][-4:]}")

            if self.options.expert is not None:
                self.api_keys = existing_keys
                self.ui.success("Using existing API keys (non-interactive mode)")
                return

            self.ui.newline()
            use_existing = self.ui.select_yes_no("Use detected keys?", default=True)

            if use_existing:
                self.api_keys = existing_keys
                self.ui.success("Using existing API keys")
                return

        self.ui.console.print("\n  Press Enter to skip.\n")

        self.api_keys["openai"] = self.ui.prompt_password("  OpenAI API Key:")

        if not self.api_keys["openai"]:
            self.ui.warn("No OpenAI API key provided. Expert analysis will be disabled.")
            self.expert_enabled = False
        else:
            self.ui.success("OpenAI API key configured")

    def _configure_agents(self) -> None:
        """Configure all selected agents."""
        self.ui.newline()
        self.ui.info("Configuring agent(s)...")

        for agent_name in self.selected_agents:
            agent = get_agent(agent_name)
            if agent:
                self._configure_single_agent(agent)

    def _build_env_vars(self) -> dict[str, str]:
        env_vars = {
            "OPTIX_PROJECT_PATH": os.getcwd(),
            "SERVER_NAME": "optix-mcp-server",
            "LOG_LEVEL": "INFO",
            "TRANSPORT": "stdio",
            "EXPERT_ANALYSIS_ENABLED": "true" if self.expert_enabled else "false",
            "DASHBOARD_ENABLED": "true" if self.dashboard_enabled else "false",
            "SLACK_ENABLED": "true" if self.slack_enabled else "false",
        }

        if self.api_keys.get("openai"):
            env_vars["OPENAI_API_KEY"] = self.api_keys["openai"]
            env_vars["OPTIX_LLM_PROVIDER"] = "openai"

        if self.dashboard_enabled:
            env_vars["DASHBOARD_PORT"] = str(self.dashboard_port)

        if self.slack_enabled:
            env_vars["SLACK_BOT_TOKEN"] = self.slack_bot_token
            env_vars["SLACK_CHANNEL_ID"] = self.slack_channel_id
            env_vars["SLACK_SEVERITY_FILTER"] = ",".join(self.slack_severity_filter)

        env_vars["OPTIX_DEFAULT_LENS_SECURITY"] = self.default_lenses["security"]
        env_vars["OPTIX_DEFAULT_LENS_A11Y"] = self.default_lenses["a11y"]
        env_vars["OPTIX_DEFAULT_LENS_DEVOPS"] = self.default_lenses["devops"]
        env_vars["OPTIX_DEFAULT_LENS_PRINCIPAL"] = self.default_lenses["principal"]

        if self.linear_enabled and self.linear_api_key:
            env_vars["OPTIX_LINEAR_API_KEY"] = self.linear_api_key

        if self.jira_enabled and self.jira_api_token:
            env_vars["OPTIX_JIRA_API_TOKEN"] = self.jira_api_token
            if self.jira_user_email:
                env_vars["OPTIX_JIRA_USER_EMAIL"] = self.jira_user_email
            if self.jira_instance_url:
                env_vars["OPTIX_JIRA_INSTANCE_URL"] = self.jira_instance_url

        return env_vars

    def _configure_single_agent(self, agent: AgentConfig) -> None:
        """Configure a single agent."""
        config_path = agent.get_config_path(self.scope)

        if agent.config_format == ConfigFormat.JSON:
            writer = JSONConfigWriter()
        else:
            writer = TOMLConfigWriter()

        env_vars = self._build_env_vars()

        server_config = dict(agent.server_config)
        server_config["env"] = env_vars

        writer.merge_server_config(
            path=config_path,
            key_path=agent.key_path,
            server_name="optix",
            config=server_config,
        )

        self.ui.success(f"Configured {agent.label}: {config_path}")
