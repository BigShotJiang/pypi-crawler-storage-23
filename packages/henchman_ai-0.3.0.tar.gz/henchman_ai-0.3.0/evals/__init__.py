"""Behavioral evaluation framework for henchman-ai."""
