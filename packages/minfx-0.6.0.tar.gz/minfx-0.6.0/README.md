# Minfx

Neptune [announced the shutdown of its services](https://docs.neptune.ai/transition_hub/). 

[Minfx](https://minfx.ai) is your solution.

We're the fastest experiment tracker on the market, built specifically as a drop-in replacement for Neptune. We offer:

- **One-line code change** - same APIs, instant compatibility
- **Automatic data migration** - we'll transfer your data for you
- **High-performance UI** - >60 FPS rendering for smooth interactions
- **Multi-backend support** - extra reliability and redundancy

## Quick Start
Drop-in Replacement: just change

```
import neptune
```
to
```
import minfx.neptune_v2 as neptune
```

Go to https://minfx.ai to learn more.

---
c119ad1e 2026-02-26T16:14:31
