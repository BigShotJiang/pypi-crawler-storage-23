#
# Copyright (c) 2023, Neptune Labs Sp. z o.o.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Utility functions to support ML metadata logging with neptune.ai."""

from __future__ import annotations

__all__ = [
    "NullProgressBar",
    "TqdmProgressBar",
    "stop_synchronization_callback",
    "stringify_unsupported",
]

from typing import (
    TYPE_CHECKING,
    Mapping,
    MutableMapping,
)

from minfx.neptune_v2.internal.init.parameters import DEFAULT_STOP_TIMEOUT
from minfx.neptune_v2.internal.types.stringify_value import StringifyValue
from minfx.neptune_v2.internal.utils.logger import get_logger
from minfx.neptune_v2.progress_bar import (
    NullProgressBar,
    TqdmProgressBar,
)

if TYPE_CHECKING:
    from minfx.neptune_v2.typing import NeptuneObject

logger = get_logger()


def stringify_unsupported(
    value: object,
    expand: bool = False,
) -> StringifyValue | Mapping[str, object]:
    """Helper function that converts unsupported values in a collection or dictionary to strings.

    Args:
        value (Any): A dictionary with values or a collection
        expand (bool, optional): If True, the function expands series to store each item as an
        enumerated key-value pair. Otherwise, the entire series is logged as a string. Defaults to False.

    Example:
        >>> import neptune
        >>> run = neptune.init_run()
        >>> complex_dict = {"tuple": ("hi", 1), "metric": 0.87}
        >>> run["complex_dict"] = complex_dict
        >>> # (as of 1.0.0) error - tuple is not a supported type
        >>> from minfx.neptune_v2.utils import stringify_unsupported
        >>> run["complex_dict"] = stringify_unsupported(complex_dict)
        >>> run["complex_dict"].fetch()
        >>> # {'metric': 0.87, 'tuple': "('hi', 1)"} - tuple logged as string
        >>> run["complex_dict_expanded"] = stringify_unsupported(complex_dict, expand=True)
        >>> run["complex_dict_expanded"].fetch()
        >>> # {'metric': 0.87, 'tuple': {'0': 'hi', '1': 1} - tuple logged as an enumerated dictionary

        For more information, see:
        https://docs-legacy.neptune.ai/api/utils/#stringify_unsupported
    """
    if isinstance(value, MutableMapping):
        return {str(k): stringify_unsupported(v, expand=expand) for k, v in value.items()}
    if expand and isinstance(value, (list, tuple, set)):
        return {str(i): stringify_unsupported(v, expand=True) for i, v in enumerate(value)}

    return StringifyValue(value=value)


def stop_synchronization_callback(neptune_object: NeptuneObject) -> None:
    """Default callback function that stops a Neptune object's synchronization with the server.

    Args:
        neptune_object: A Neptune object (Run, Model, ModelVersion, or Project) to be stopped.

    Example:
        >>> import neptune
        >>> from minfx.neptune_v2.utils import stop_synchronization_callback
        >>> run = neptune.init_run(async_no_progress_callback=stop_synchronization_callback)

    For more information, see:
        https://docs-legacy.neptune.ai/api/utils/stop_synchronization_callback/
    """
    logger.error(
        "Threshold for disrupted synchronization exceeded. Stopping the synchronization using the default callback."
    )
    neptune_object.stop(seconds=DEFAULT_STOP_TIMEOUT)
