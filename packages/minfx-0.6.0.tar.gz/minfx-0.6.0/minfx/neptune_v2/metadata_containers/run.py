#
# Copyright (c) 2022, Neptune Labs Sp. z o.o.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

__all__ = ["Run"]

import os
from platform import node as get_hostname
import threading
import uuid
from typing import (
    TYPE_CHECKING,
    Optional,
)

from typing_extensions import Literal

from minfx.neptune_v2.attributes.constants import (
    SYSTEM_DESCRIPTION_ATTRIBUTE_PATH,
    SYSTEM_FAILED_ATTRIBUTE_PATH,
    SYSTEM_HOSTNAME_ATTRIBUTE_PATH,
    SYSTEM_NAME_ATTRIBUTE_PATH,
    SYSTEM_TAGS_ATTRIBUTE_PATH,
)
from minfx.neptune_v2.common.warnings import (
    NeptuneWarning,
    warn_once,
)
from minfx.neptune_v2.envs import (
    CONNECTION_MODE,
    CUSTOM_RUN_ID_ENV_NAME,
    MONITORING_NAMESPACE,
    NEPTUNE_NOTEBOOK_ID,
    NEPTUNE_NOTEBOOK_PATH,
)
from minfx.neptune_v2.exceptions import (
    InactiveRunException,
    NeedExistingRunForReadOnlyMode,
    NeptuneMultiBackendWithIdError,
    NeptunePossibleLegacyUsageException,
    NeptuneRunResumeAndCustomIdCollision,
)
from minfx.neptune_v2.internal.backends.backend_config import (
    BackendConfig,
    validate_backends_unique,
)
from minfx.neptune_v2.internal.container_type import ContainerType
from minfx.neptune_v2.internal.hardware.hardware_metric_reporting_job import HardwareMetricReportingJob
from minfx.neptune_v2.internal.id_formats import QualifiedName
from minfx.neptune_v2.internal.init.parameters import (
    ASYNC_LAG_THRESHOLD,
    ASYNC_NO_PROGRESS_THRESHOLD,
    DEFAULT_FLUSH_PERIOD,
    DEFAULT_NAME,
    OFFLINE_PROJECT_QUALIFIED_NAME,
)
from minfx.neptune_v2.internal.notebooks.notebooks import create_checkpoint
from minfx.neptune_v2.internal.state import ContainerState
from minfx.neptune_v2.internal.streams.std_capture_background_job import (
    StderrCaptureBackgroundJob,
    StdoutCaptureBackgroundJob,
)
from minfx.neptune_v2.internal.utils import (
    verify_collection_type,
    verify_type,
)
from minfx.neptune_v2.internal.utils.dependency_tracking import (
    FileDependenciesStrategy,
    InferDependenciesStrategy,
)
from minfx.neptune_v2.internal.utils.git import (
    to_git_info,
    track_uncommitted_changes,
)
from minfx.neptune_v2.internal.utils.hashing import generate_hash
from minfx.neptune_v2.internal.utils.limits import custom_run_id_exceeds_length
from minfx.neptune_v2.internal.utils.ping_background_job import PingBackgroundJob
from minfx.neptune_v2.internal.utils.runningmode import (
    in_interactive,
    in_notebook,
)
from minfx.neptune_v2.internal.utils.source_code import upload_source_code
from minfx.neptune_v2.internal.utils.traceback_job import TracebackJob
from minfx.neptune_v2.internal.websockets.websocket_signals_background_job import WebsocketSignalsBackgroundJob
from minfx.neptune_v2.metadata_containers import MetadataContainer
from minfx.neptune_v2.types import (
    GitRef,
    StringSeries,
)
from minfx.neptune_v2.types.mode import Mode

if TYPE_CHECKING:
    from minfx.neptune_v2.internal.backends.api_model import ApiExperiment
    from minfx.neptune_v2.internal.backends.neptune_backend import NeptuneBackend
    from minfx.neptune_v2.internal.background_job import BackgroundJob
    from minfx.neptune_v2.metadata_containers.abstract import NeptuneObjectCallback
    from minfx.neptune_v2.types.atoms.git_ref import GitRefDisabled


class Run(MetadataContainer):
    """Starts a new tracked run that logs ML model-building metadata to neptune.ai.

    You can log metadata by assigning it to the initialized Run object:

    ```
    run = neptune.init_run()
    run["your/structure"] = some_metadata
    ```

    Examples of metadata you can log: metrics, losses, scores, artifact versions, images, predictions,
    model weights, parameters, checkpoints, and interactive visualizations.

    By default, the run automatically tracks hardware consumption, stdout/stderr, source code, and Git information.
    If you're using Neptune in an interactive session, however, some background monitoring needs to be enabled
    explicitly.

    If you provide the ID of an existing run, that run is resumed and no new run is created. You may resume a run
    either to log more metadata or to fetch metadata from it.

    The run ends either when its `stop()` method is called or when the script finishes execution.

    You can also use the Run object as a context manager (see examples).

    Args:
        project: Name of the project where the run should go, in the form `workspace-name/project_name`.
            If left empty, the value of the NEPTUNE_PROJECT environment variable is used.
        backends: List of BackendConfig objects specifying the backend(s) to connect to.
            Each BackendConfig contains an api_token and optionally project-specific settings.
            If None, creates a backend from the NEPTUNE_API_TOKEN environment variable.
            Example: `backends=[BackendConfig(api_token="your-token")]`
        with_id: If you want to resume a run, pass the identifier of an existing run. For example, "SAN-1".
            If left empty, a new run is created. Note: Not supported with multiple backends.
        custom_run_id: A unique identifier to be used when running Neptune in distributed training jobs.
            Make sure to use the same identifier throughout the whole pipeline execution.
        mode: Connection mode in which the tracking will work.
            If left empty, the value of the NEPTUNE_MODE environment variable is used.
            If no value was set for the environment variable, "async" is used by default.
            Possible values are `async`, `sync`, `offline`, `read-only`, and `debug`.
        name: Custom name for the run. You can add it as a column in the runs table ("sys/name").
            You can also edit the name in the app: Open the run menu and access the run information.
        description:  Custom description of the run. You can add it as a column in the runs table
            ("sys/description").
            You can also edit the description in the app: Open the run menu and access the run information.
        tags: Tags of the run as a list of strings.
            You can edit the tags through the "sys/tags" field or in the app (run menu -> information).
            You can also select multiple runs and manage their tags as a single action.
        source_files: List of source files to be uploaded.
            Uploaded source files are displayed in the "Source code" dashboard.
            To not upload anything, pass an empty list (`[]`).
            Unix style pathname pattern expansion is supported. For example, you can pass `*.py` to upload
            all Python files from the current directory.
            If None is passed, the Python file from which the run was created will be uploaded.
        capture_stdout: Whether to log the stdout of the run.
            Defaults to `False` in interactive sessions and `True` otherwise.
            The data is logged under the monitoring namespace (see the `monitoring_namespace` parameter).
        capture_stderr: Whether to log the stderr of the run.
            Defaults to `False` in interactive sessions and `True` otherwise.
            The data is logged under the monitoring namespace (see the `monitoring_namespace` parameter).
        capture_hardware_metrics: Whether to send hardware monitoring logs (CPU, GPU, and memory utilization).
            Defaults to `False` in interactive sessions and `True` otherwise.
            The data is logged under the monitoring namespace (see the `monitoring_namespace` parameter).
        fail_on_exception: Whether to register an uncaught exception handler to this process and,
            in case of an exception, set the "sys/failed" field of the run to `True`.
            An exception is always logged.
        monitoring_namespace: Namespace inside which all hardware monitoring logs are stored.
            Defaults to "monitoring/<hash>", where the hash is generated based on environment information,
            to ensure that it's unique for each process.
        flush_period: In the asynchronous (default) connection mode, how often disk flushing is triggered
            (in seconds).
        proxies: Argument passed to HTTP calls made via the Requests library, as dictionary of strings.
            For more information about proxies, see the Requests documentation.
        capture_traceback: Whether to log the traceback of the run in case of an exception.
            The tracked metadata is stored in the "<monitoring_namespace>/traceback" namespace (see the
            `monitoring_namespace` parameter).
        git_ref: GitRef object containing information about the Git repository path.
            If None, Neptune looks for a repository in the path of the script that is executed.
            To specify a different location, set to GitRef(repository_path="path/to/repo").
            To turn off Git tracking for the run, set to False or GitRef.DISABLED.
        dependencies: If you pass `"infer"`, Neptune logs dependencies installed in the current environment.
            You can also pass a path to your dependency file directly.
            If left empty, no dependencies are tracked.
        async_lag_callback: Custom callback which is called if the lag between a queued operation and its
            synchronization with the server exceeds the duration defined by `async_lag_threshold`. The callback
            should take a Run object as the argument and can contain any custom code, such as calling `stop()` on
            the object.
            Note: Instead of using this argument, you can use Neptune's default callback by setting the
            `NEPTUNE_ENABLE_DEFAULT_ASYNC_LAG_CALLBACK` environment variable to `TRUE`.
        async_lag_threshold: In seconds, duration between the queueing and synchronization of an operation.
            If a lag callback (default callback enabled via environment variable or custom callback passed to the
            `async_lag_callback` argument) is enabled, the callback is called when this duration is exceeded.
        async_no_progress_callback: Custom callback which is called if there has been no synchronization progress
            whatsoever for the duration defined by `async_no_progress_threshold`. The callback
            should take a Run object as the argument and can contain any custom code, such as calling `stop()` on
            the object.
            Note: Instead of using this argument, you can use Neptune's default callback by setting the
            `NEPTUNE_ENABLE_DEFAULT_ASYNC_NO_PROGRESS_CALLBACK` environment variable to `TRUE`.
        async_no_progress_threshold: In seconds, for how long there has been no synchronization progress since the
            object was initialized. If a no-progress callback (default callback enabled via environment variable or
            custom callback passed to the `async_no_progress_callback` argument) is enabled, the callback is called
            when this duration is exceeded.
        log_level: Log level for the Neptune client logger (e.g., `logging.WARNING` to reduce verbosity,
            `logging.ERROR` for minimal output, or `logging.CRITICAL + 1` to silence completely).
            If None, the default INFO level is used.
        fail_on_error: If True, raises NeptuneOperationsError when stop() is called if any operations
            failed during async processing. Useful for tests to catch server errors.
            Defaults to False.

    Returns:
        Run object that is used to manage the tracked run and log metadata to it.

    Examples:
        Creating a new run:

        >>> import neptune

        >>> # Minimal invoke
        ... # (creates a run in the project specified by the NEPTUNE_PROJECT environment variable)
        ... run = neptune.init_run()

        >>> # Or initialize with the constructor
        ... run = Run(project="ml-team/classification")

        >>> # Create a run with a name and description, with no sources files or Git info tracked:
        >>> run = neptune.init_run(
        ...     name="neural-net-mnist",
        ...     description="neural net trained on MNIST",
        ...     source_files=[],
        ...     git_ref=False,
        ... )

        >>> # Log all .py files from all subdirectories, excluding hidden files
        ... run = neptune.init_run(source_files="**/*.py")

        >>> # Log all files and directories in the current working directory, excluding hidden files
        ... run = neptune.init_run(source_files="*")

        >>> # Larger example
        ... run = neptune.init_run(
        ...     project="ml-team/classification",
        ...     name="first-pytorch-ever",
        ...     description="Longer description of the run goes here",
        ...     tags=["tags", "go-here", "as-list-of-strings"],
        ...     source_files=["training_with_pytorch.py", "net.py"],
        ...     dependencies="infer",
        ...     capture_stderr=False,
        ...     git_ref=GitRef(repository_path="/Users/Jackie/repos/cls_project"),
        ... )

        Connecting to an existing run:

        >>> # Resume logging to an existing run with the ID "SAN-3"
        ... run = neptune.init_run(with_id="SAN-3")
        ... run["parameters/lr"] = 0.1  # modify or add metadata

        >>> # Initialize an existing run in read-only mode (logging new data is not possible, only fetching)
        ... run = neptune.init_run(with_id="SAN-4", mode="read-only")
        ... learning_rate = run["parameters/lr"].fetch()

        Using the Run object as context manager:

        >>> with Run() as run:
        ...     run["metric"].append(value)

    For more, see the docs:
        Initializing a run:
            https://docs-legacy.neptune.ai/api/neptune#init_run
        Run class reference:
            https://docs-legacy.neptune.ai/api/run/
        Essential logging methods:
            https://docs-legacy.neptune.ai/logging/methods/
        Resuming a run:
            https://docs-legacy.neptune.ai/logging/to_existing_object/
        Setting a custom run ID:
            https://docs-legacy.neptune.ai/logging/custom_run_id/
        Logging to multiple runs at once:
            https://docs-legacy.neptune.ai/logging/to_multiple_objects/
        Accessing the run from multiple places:
            https://docs-legacy.neptune.ai/logging/from_multiple_places/
    """

    container_type = ContainerType.RUN

    LEGACY_METHODS = (
        "create_experiment",
        "send_metric",
        "log_metric",
        "send_text",
        "log_text",
        "send_image",
        "log_image",
        "send_artifact",
        "log_artifact",
        "delete_artifacts",
        "download_artifact",
        "download_sources",
        "download_artifacts",
        "reset_log",
        "get_parameters",
        "get_properties",
        "set_property",
        "remove_property",
        "get_hardware_utilization",
        "get_numeric_channels_values",
    )

    def __init__(
        self,
        with_id: str | None = None,
        *,
        project: str | None = None,
        api_token: str | None = None,
        backends: list[BackendConfig] | None = None,
        custom_run_id: str | None = None,
        mode: Literal["async", "sync", "offline", "read-only", "debug"] | None = None,
        name: str | None = None,
        description: str | None = None,
        tags: list[str] | str | None = None,
        source_files: list[str] | str | None = None,
        capture_stdout: bool | None = None,
        capture_stderr: bool | None = None,
        capture_hardware_metrics: bool | None = None,
        fail_on_exception: bool = True,
        monitoring_namespace: str | None = None,
        flush_period: float = DEFAULT_FLUSH_PERIOD,
        proxies: dict | None = None,
        capture_traceback: bool = True,
        git_ref: GitRef | GitRefDisabled | bool | None = None,
        dependencies: str | os.PathLike | None = None,
        async_lag_callback: NeptuneObjectCallback | None = None,
        async_lag_threshold: float = ASYNC_LAG_THRESHOLD,
        async_no_progress_callback: NeptuneObjectCallback | None = None,
        async_no_progress_threshold: float = ASYNC_NO_PROGRESS_THRESHOLD,
        log_level: int | None = None,
        fail_on_error: bool = False,
        **kwargs: object,
    ) -> None:
        check_for_extra_kwargs("Run", kwargs)

        verify_type("with_id", with_id, (str, type(None)))
        verify_type("project", project, (str, type(None)))
        verify_type("api_token", api_token, (str, type(None)))
        verify_type("backends", backends, (list, type(None)))

        # Convert api_token to backends format if provided (for backward compatibility)
        # api_token can be comma-separated for multi-backend support
        if api_token is not None and backends is None:
            from minfx.neptune_v2.internal.backends.backend_config import configs_from_tokens

            backends = configs_from_tokens(api_token, proxies=proxies)

        verify_type("custom_run_id", custom_run_id, (str, type(None)))
        verify_type("mode", mode, (str, type(None)))
        verify_type("name", name, (str, type(None)))
        verify_type("description", description, (str, type(None)))
        verify_type("capture_stdout", capture_stdout, (bool, type(None)))
        verify_type("capture_stderr", capture_stderr, (bool, type(None)))
        verify_type("capture_hardware_metrics", capture_hardware_metrics, (bool, type(None)))
        verify_type("fail_on_exception", fail_on_exception, bool)
        verify_type("monitoring_namespace", monitoring_namespace, (str, type(None)))
        verify_type("capture_traceback", capture_traceback, bool)
        verify_type("git_ref", git_ref, (GitRef, str, bool, type(None)))
        verify_type("dependencies", dependencies, (str, os.PathLike, type(None)))

        # Validate backends configuration (if provided explicitly)
        if backends is not None:
            validate_backends_unique(backends)

        if tags is not None:
            if isinstance(tags, str):
                tags = [tags]
            else:
                verify_collection_type("tags", tags, str)
        if source_files is not None:
            if isinstance(source_files, str):
                source_files = [source_files]
            else:
                verify_collection_type("source_files", source_files, str)

        # Multi-backend validation and auto-ID generation
        is_multi_backend = backends is not None and len(backends) > 1

        # VALIDATION: with_id not allowed in multi-backend mode
        if is_multi_backend and with_id is not None:
            raise NeptuneMultiBackendWithIdError()

        # AUTO-GENERATE custom_run_id if not provided in multi-backend mode
        resolved_custom_run_id = custom_run_id or os.getenv(CUSTOM_RUN_ID_ENV_NAME)
        if is_multi_backend and resolved_custom_run_id is None:
            resolved_custom_run_id = str(uuid.uuid4())

        self._with_id: str | None = with_id
        self._name: str | None = name
        self._description: str | None = "" if with_id is None and description is None else description
        self._custom_run_id: str | None = resolved_custom_run_id
        self._hostname: str = get_hostname()
        self._pid: int = os.getpid()
        self._tid: int = threading.get_ident()
        self._tags: list[str] | None = tags
        self._source_files: list[str] | None = source_files
        self._fail_on_exception: bool = fail_on_exception
        self._capture_traceback: bool = capture_traceback

        if type(git_ref) is bool:
            git_ref = GitRef() if git_ref else GitRef.DISABLED

        self._git_ref: Optional[GitRef, GitRefDisabled] = git_ref or GitRef()
        self._dependencies: Optional[str, os.PathLike] = dependencies

        self._monitoring_namespace: str = (
            monitoring_namespace
            or os.getenv(MONITORING_NAMESPACE)
            or generate_monitoring_namespace(self._hostname, self._pid, self._tid)
        )

        # for backward compatibility imports
        mode = Mode(mode or os.getenv(CONNECTION_MODE) or Mode.ASYNC.value)

        self._stdout_path: str = f"{self._monitoring_namespace}/stdout"
        self._capture_stdout: bool = capture_stdout
        if capture_stdout is None:
            self._capture_stdout = capture_only_if_non_interactive(mode=mode)

        self._stderr_path: str = f"{self._monitoring_namespace}/stderr"
        self._capture_stderr: bool = capture_stderr
        if capture_stderr is None:
            self._capture_stderr = capture_only_if_non_interactive(mode=mode)

        self._capture_hardware_metrics: bool = capture_hardware_metrics
        if capture_hardware_metrics is None:
            self._capture_hardware_metrics = capture_only_if_non_interactive(mode=mode)

        if with_id and resolved_custom_run_id:
            raise NeptuneRunResumeAndCustomIdCollision

        if mode in (Mode.OFFLINE, Mode.DEBUG):
            project = OFFLINE_PROJECT_QUALIFIED_NAME

        super().__init__(
            project=project,
            backends=backends,
            mode=mode,
            flush_period=flush_period,
            proxies=proxies,
            async_lag_callback=async_lag_callback,
            async_lag_threshold=async_lag_threshold,
            async_no_progress_callback=async_no_progress_callback,
            async_no_progress_threshold=async_no_progress_threshold,
            log_level=log_level,
            fail_on_error=fail_on_error,
        )

    def _get_or_create_api_object(self) -> ApiExperiment:
        project_workspace = self._project_api_object.workspace
        project_name = self._project_api_object.name
        project_qualified_name = f"{project_workspace}/{project_name}"

        if self._with_id:
            return self._backend.get_metadata_container(
                container_id=QualifiedName(project_qualified_name + "/" + self._with_id),
                expected_container_type=Run.container_type,
            )
        if self._mode == Mode.READ_ONLY:
            raise NeedExistingRunForReadOnlyMode

        git_info = to_git_info(git_ref=self._git_ref)

        custom_run_id = self._custom_run_id
        if custom_run_id_exceeds_length(self._custom_run_id):
            custom_run_id = None

        notebook_id, checkpoint_id = create_notebook_checkpoint(backend=self._backend)

        return self._backend.create_run(
            project_id=self._project_api_object.id,
            git_info=git_info,
            custom_run_id=custom_run_id,
            notebook_id=notebook_id,
            checkpoint_id=checkpoint_id,
        )

    def _get_background_jobs(self) -> list[BackgroundJob]:
        background_jobs = [PingBackgroundJob()]

        websockets_factory = self._backend.websockets_factory(self._project_api_object.id, self._id)
        if websockets_factory:
            background_jobs.append(WebsocketSignalsBackgroundJob(websockets_factory))

        if self._capture_stdout:
            background_jobs.append(StdoutCaptureBackgroundJob(attribute_name=self._stdout_path))

        if self._capture_stderr:
            background_jobs.append(StderrCaptureBackgroundJob(attribute_name=self._stderr_path))

        if self._capture_hardware_metrics:
            background_jobs.append(HardwareMetricReportingJob(attribute_namespace=self._monitoring_namespace))

        if self._capture_traceback:
            background_jobs.append(
                TracebackJob(path=f"{self._monitoring_namespace}/traceback", fail_on_exception=self._fail_on_exception)
            )

        return background_jobs

    def _write_initial_monitoring_attributes(self) -> None:
        if self._hostname is not None:
            self[f"{self._monitoring_namespace}/hostname"] = self._hostname
            if self._with_id is None:
                self[SYSTEM_HOSTNAME_ATTRIBUTE_PATH] = self._hostname

        if self._pid is not None:
            self[f"{self._monitoring_namespace}/pid"] = str(self._pid)

        if self._tid is not None:
            self[f"{self._monitoring_namespace}/tid"] = str(self._tid)

    def _write_initial_attributes(self):
        if not getattr(self._backend, "sys_name_set_by_backend", False):
            self._name = self._name if self._name is not None else DEFAULT_NAME

        if self._name is not None:
            self[SYSTEM_NAME_ATTRIBUTE_PATH] = self._name

        if self._description is not None:
            self[SYSTEM_DESCRIPTION_ATTRIBUTE_PATH] = self._description

        if any((self._capture_stderr, self._capture_stdout, self._capture_traceback, self._capture_hardware_metrics)):
            self._write_initial_monitoring_attributes()

        if self._tags is not None:
            self[SYSTEM_TAGS_ATTRIBUTE_PATH].add(self._tags)

        if self._with_id is None:
            self[SYSTEM_FAILED_ATTRIBUTE_PATH] = False

        if self._capture_stdout and not self.exists(self._stdout_path):
            self.define(self._stdout_path, StringSeries([]))

        if self._capture_stderr and not self.exists(self._stderr_path):
            self.define(self._stderr_path, StringSeries([]))

        if self._with_id is None or self._source_files is not None:
            # upload default sources ONLY if creating a new run
            upload_source_code(source_files=self._source_files, run=self)

        if self._dependencies:
            try:
                if self._dependencies == "infer":
                    dependency_strategy = InferDependenciesStrategy()

                else:
                    dependency_strategy = FileDependenciesStrategy(path=self._dependencies)

                dependency_strategy.log_dependencies(run=self)
            except Exception as e:
                warn_once(
                    "An exception occurred in automatic dependency tracking."
                    "Skipping upload of requirement files."
                    "Exception: " + str(e),
                    exception=NeptuneWarning,
                )

        try:
            track_uncommitted_changes(
                git_ref=self._git_ref,
                run=self,
            )
        except Exception as e:
            warn_once(
                "An exception occurred in tracking uncommitted changes."
                "Skipping upload of patch files."
                "Exception: " + str(e),
                exception=NeptuneWarning,
            )

    @property
    def monitoring_namespace(self) -> str:
        return self._monitoring_namespace

    def _raise_if_stopped(self):
        if self._state == ContainerState.STOPPED:
            raise InactiveRunException(label=self._sys_id)

    def get_url(self) -> str:
        """Returns the URL that can be accessed within the browser."""
        return self._backend.get_run_url(
            run_id=self._id,
            workspace=self._workspace,
            project_name=self._project_name,
            sys_id=self._sys_id,
        )

    # -------------------------------------------------------------------------
    # Neptune Scale compatibility aliases
    # -------------------------------------------------------------------------

    def wait_for_processing(self) -> None:
        """Alias for sync(). Provided for neptune_scale compatibility."""
        self.sync()

    def wait_for_submission(self, *, disk_only: bool = False) -> None:
        """Alias for wait(). Provided for neptune_scale compatibility."""
        self.wait(disk_only=disk_only)

    def close(self, *, seconds: float | None = None) -> None:
        """Alias for stop(). Provided for neptune_scale compatibility."""
        self.stop(seconds=seconds)

    def add_tags(
        self,
        tags: list[str],
        *,
        group_tags: bool = False,
        wait: bool = False,
    ) -> None:
        """Adds tags to the run.

        Provided for neptune_scale compatibility.

        Args:
            tags: List of tags to add.
            group_tags: If True, adds to "sys/group_tags" instead of "sys/tags".
            wait: If True, waits for the operation to complete.
        """
        path = "sys/group_tags" if group_tags else "sys/tags"
        self[path].add(tags, wait=wait)

    def log_configs(
        self,
        data: dict,
        *,
        flatten: bool = False,
        cast_unsupported: bool = False,
        wait: bool = False,
    ) -> None:
        """Logs configuration parameters to the run.

        Provided for neptune_scale compatibility.

        Args:
            data: Dictionary of configuration parameters.
                  Keys become field paths, values become field values.
            flatten: If True, nested dictionaries are flattened into dot-separated paths.
            cast_unsupported: If True, unsupported types are cast to strings.
            wait: If True, waits for the operation to complete.

        Example:
            >>> run.log_configs(
            ...     data={"config": {"lr": 0.001, "epochs": 10}},
            ...     flatten=True,
            ...     cast_unsupported=True,
            ... )
            # Equivalent to:
            # run["config"] = stringify_unsupported({"lr": 0.001, "epochs": 10})
        """
        from minfx.neptune_v2.utils import stringify_unsupported

        for key, value in data.items():
            if cast_unsupported:
                value = stringify_unsupported(value, expand=flatten)
            self[key].assign(value, wait=wait)

    def log_metrics(
        self,
        data: dict[str, float],
        *,
        step: float | None = None,
        timestamp: float | None = None,
        wait: bool = False,
    ) -> None:
        """Logs metrics to the run.

        Provided for neptune_scale compatibility.

        Args:
            data: Dictionary mapping metric paths to values.
                  Paths can include namespaces (e.g., "metrics/acc").
            step: Optional step index for the metrics.
            timestamp: Optional Unix timestamp for the metrics.
            wait: If True, waits for the operation to complete.

        Example:
            >>> run.log_metrics(
            ...     data={"metrics/acc": 0.95, "metrics/loss": 0.05},
            ...     step=100,
            ... )
            # Equivalent to:
            # run["metrics"].append({"acc": 0.95, "loss": 0.05}, step=100)
        """
        for path, value in data.items():
            self[path].append(value, step=step, timestamp=timestamp, wait=wait)

    def assign_files(
        self,
        value: str,
        *,
        path: str = "sample",
        wait: bool = False,
    ) -> None:
        """Uploads a file to the run.

        Provided for neptune_scale compatibility.

        Args:
            value: Path to the file to upload.
            path: Field path to store the file under. Defaults to "sample".
            wait: If True, waits for the operation to complete.

        Example:
            >>> run.assign_files("my_file.png")
            # Equivalent to:
            # run["sample"].upload("my_file.png")
        """
        self[path].upload(value, wait=wait)

    def log_files(
        self,
        files: dict[str, str],
        *,
        step: float | None = None,
        timestamp: float | None = None,
        wait: bool = False,
    ) -> None:
        """Logs files as a series to the run.

        Provided for neptune_scale compatibility.

        Args:
            files: Dictionary mapping field paths to file paths.
            step: Optional step index for the files.
            timestamp: Optional Unix timestamp for the files.
            wait: If True, waits for the operation to complete.

        Example:
            >>> run.log_files(files={"predictions": "my_file.png"}, step=10)
            # Equivalent to:
            # run["predictions"].append("my_file.png", step=10)
        """
        for field_path, file_path in files.items():
            self[field_path].append(file_path, step=step, timestamp=timestamp, wait=wait)

    def log_string_series(
        self,
        value: str,
        *,
        path: str = "logs",
        step: float | None = None,
        timestamp: float | None = None,
        wait: bool = False,
    ) -> None:
        """Logs a string value to a string series.

        Provided for neptune_scale compatibility.

        Args:
            value: String value to log.
            path: Field path to log to. Defaults to "logs".
            step: Optional step index for the entry.
            timestamp: Optional Unix timestamp for the entry.
            wait: If True, waits for the operation to complete.

        Example:
            >>> run.log_string_series("some_string")
            # Equivalent to:
            # run["logs"].append("some_string")
        """
        self[path].append(value, step=step, timestamp=timestamp, wait=wait)


def capture_only_if_non_interactive(mode: Mode) -> bool:
    if in_interactive() or in_notebook():
        if mode in {Mode.OFFLINE, Mode.SYNC, Mode.ASYNC}:
            warn_once(
                "By default, these monitoring options are disabled in interactive sessions:"
                " 'capture_stdout', 'capture_stderr', 'capture_traceback', 'capture_hardware_metrics'."
                " You can set them to 'True' when initializing the run and the monitoring will"
                " continue until you call run.stop() or the kernel stops."
                " NOTE: To track the source files, pass their paths to the 'source_code'"
                " argument. For help, see: https://docs-legacy.neptune.ai/logging/source_code/",
                exception=NeptuneWarning,
            )
        return False
    return True


def generate_monitoring_namespace(*descriptors: str | int) -> str:
    return f"monitoring/{generate_hash(*descriptors, length=8)}"


def check_for_extra_kwargs(caller_name: str, kwargs: dict):
    legacy_kwargs = ("project_qualified_name", "backend")

    for name in legacy_kwargs:
        if name in kwargs:
            raise NeptunePossibleLegacyUsageException

    if kwargs:
        first_key = next(iter(kwargs.keys()))
        raise TypeError(f"{caller_name}() got an unexpected keyword argument '{first_key}'")


def create_notebook_checkpoint(backend: NeptuneBackend) -> tuple[str | None, str | None]:
    notebook_id = os.getenv(NEPTUNE_NOTEBOOK_ID, None)
    notebook_path = os.getenv(NEPTUNE_NOTEBOOK_PATH, None)

    checkpoint_id = None
    if notebook_id is not None and notebook_path is not None:
        checkpoint_id = create_checkpoint(backend=backend, notebook_id=notebook_id, notebook_path=notebook_path)

    return notebook_id, checkpoint_id
