#
# Copyright (c) 2019, Neptune Labs Sp. z o.o.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import TYPE_CHECKING

from minfx.neptune_v2.common.hardware.metrics.reports.metric_report import (
    MetricReport,
    MetricValue,
)

if TYPE_CHECKING:
    from minfx.neptune_v2.common.hardware.gauges.gauge import Gauge
    from minfx.neptune_v2.common.hardware.metrics.metric import Metric


class MetricReporter:
    def __init__(self, metrics: list[Metric], reference_timestamp: float) -> None:
        self.__metrics = metrics
        self.__reference_timestamp = reference_timestamp

    def report(self, timestamp: float) -> list[MetricReport]:
        """:param timestamp: Time of measurement (float, seconds since Epoch).
        :return: list[MetricReport]
        """
        return [
            MetricReport(
                metric=metric,
                values=[
                    x
                    for x in [self.__metric_value_for_gauge(gauge, timestamp) for gauge in metric.gauges]
                    if x is not None
                ],
            )
            for metric in self.__metrics
        ]

    def __metric_value_for_gauge(self, gauge: Gauge, timestamp: float) -> MetricValue | None:
        value = gauge.value()
        if value is None:
            return None
        return MetricValue(
            timestamp=timestamp,
            running_time=timestamp - self.__reference_timestamp,
            gauge_name=gauge.name(),
            value=value,
        )
