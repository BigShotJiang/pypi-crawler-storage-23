from __future__ import annotations
__all__ = ['ensure_disk_not_overutilize']
from abc import ABC, abstractmethod
from functools import wraps
import os
from typing import Any, Callable
import psutil
from psutil import Error
from minfx.neptune_v2.common.warnings import NeptuneWarning, warn_once
from minfx.neptune_v2.constants import NEPTUNE_DATA_DIRECTORY
from minfx.neptune_v2.envs import NEPTUNE_MAX_DISK_USAGE, NEPTUNE_RAISE_ERROR_ON_DISK_USAGE_EXCEEDED
from minfx.neptune_v2.exceptions import NeptuneMaxDiskUtilizationExceeded

def get_neptune_data_directory():
    return os.getenv('NEPTUNE_DATA_DIRECTORY', NEPTUNE_DATA_DIRECTORY)

def get_disk_utilization_percent(path=None):
    try:
        if path is None:
            path = get_neptune_data_directory()
        return float(psutil.disk_usage(path).percent)
    except (ValueError, TypeError, Error):
        return None

def get_max_disk_utilization_from_env():
    env_limit_disk_utilization = os.getenv(NEPTUNE_MAX_DISK_USAGE)
    if env_limit_disk_utilization is None:
        return None
    try:
        limit_disk_utilization = float(env_limit_disk_utilization)
        if limit_disk_utilization <= 0 or limit_disk_utilization > 100:
            raise ValueError
        return limit_disk_utilization
    except (ValueError, TypeError):
        warn_once(f"Provided invalid value of '{NEPTUNE_MAX_DISK_USAGE}': '{env_limit_disk_utilization}'. Check of disk utilization will not be applied.", exception=NeptuneWarning)
        return None

class DiskUtilizationErrorHandlerTemplate(ABC):

    def __init__(self, max_disk_utilization, func, *args, **kwargs):
        self.max_disk_utilization = max_disk_utilization
        self.func = func
        self.args = args
        self.kwargs = kwargs

    @abstractmethod
    def handle_limit_not_set(self):
        ...

    @abstractmethod
    def handle_utilization_calculation_error(self):
        ...

    @abstractmethod
    def handle_limit_not_exceeded(self):
        ...

    @abstractmethod
    def handle_limit_exceeded(self, current_utilization):
        ...

    def run(self):
        if not self.max_disk_utilization:
            return self.handle_limit_not_set()
        current_utilization = get_disk_utilization_percent()
        if current_utilization is None:
            return self.handle_utilization_calculation_error()
        if current_utilization < self.max_disk_utilization:
            return self.handle_limit_not_exceeded()
        self.handle_limit_exceeded(current_utilization)
        return None

class NonRaisingErrorHandler(DiskUtilizationErrorHandlerTemplate):
    DISK_ISSUE_MSG = 'Encountered disk issue. Neptune will not save your data.'

    def handle_limit_not_set(self):
        try:
            return self.func(*self.args, **self.kwargs)
        except (OSError, Error):
            warn_once(self.DISK_ISSUE_MSG, exception=NeptuneWarning)

    def handle_utilization_calculation_error(self):
        try:
            return self.func(*self.args, **self.kwargs)
        except (OSError, Error):
            warn_once(self.DISK_ISSUE_MSG, exception=NeptuneWarning)

    def handle_limit_not_exceeded(self):
        try:
            return self.func(*self.args, **self.kwargs)
        except (OSError, Error):
            warn_once(self.DISK_ISSUE_MSG, exception=NeptuneWarning)

    def handle_limit_exceeded(self, current_utilization):
        warn_once(f'Disk usage is at {current_utilization}%, which exceeds the maximum allowed utilization of {self.max_disk_utilization}%. Neptune will not save your data.', exception=NeptuneWarning)

class RaisingErrorHandler(DiskUtilizationErrorHandlerTemplate):

    def handle_limit_not_set(self):
        return self.func(*self.args, **self.kwargs)

    def handle_utilization_calculation_error(self):
        return self.func(*self.args, **self.kwargs)

    def handle_limit_not_exceeded(self):
        return self.func(*self.args, **self.kwargs)

    def handle_limit_exceeded(self, current_utilization):
        if isinstance(self.max_disk_utilization, float):
            raise NeptuneMaxDiskUtilizationExceeded(disk_utilization=current_utilization, utilization_limit=self.max_disk_utilization)

def ensure_disk_not_overutilize(func):
    raising_on_disk_issue = os.getenv(NEPTUNE_RAISE_ERROR_ON_DISK_USAGE_EXCEEDED, 'True').lower() in ('true', 't', '1')
    max_disk_utilization = get_max_disk_utilization_from_env()
    error_handler = RaisingErrorHandler if raising_on_disk_issue else NonRaisingErrorHandler

    @wraps(func)
    def wrapper(*args, **kwargs):
        error_handler(max_disk_utilization, func, *args, **kwargs).run()
    return wrapper