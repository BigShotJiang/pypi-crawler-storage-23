from __future__ import annotations

class UploadTracker:

    def __init__(self):
        self._uploaded_hashes = {}

    def compute_hash_streaming(self, path, chunk_size=8 * 1024 * 1024):
        import xxhash
        hasher = xxhash.xxh64()
        with open(path, 'rb') as f:
            while (chunk := f.read(chunk_size)):
                hasher.update(chunk)
        return format(hasher.intdigest(), '016x')

    def compute_hash(self, data):
        import xxhash
        return format(xxhash.xxh64(data).intdigest(), '016x')

    def is_uploaded(self, attribute, content_hash):
        return content_hash in self._uploaded_hashes.get(attribute, set())

    def mark_uploaded(self, attribute, content_hash):
        if attribute not in self._uploaded_hashes:
            self._uploaded_hashes[attribute] = set()
        self._uploaded_hashes[attribute].add(content_hash)

    def clear(self):
        self._uploaded_hashes.clear()

    def stats(self):
        return {attr: len(hashes) for attr, hashes in self._uploaded_hashes.items()}