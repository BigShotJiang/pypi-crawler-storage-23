__all__ = ['NeptuneInternalException']

class NeptuneInternalException(Exception):
    pass