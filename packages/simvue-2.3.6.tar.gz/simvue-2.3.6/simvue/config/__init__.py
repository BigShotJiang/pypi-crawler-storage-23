"""
Simvue Configuration
====================

This module contains definitions for the Simvue configuration options

"""
