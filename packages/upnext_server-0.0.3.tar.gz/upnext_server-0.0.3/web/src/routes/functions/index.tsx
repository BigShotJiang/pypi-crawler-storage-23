import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getFunctions, pauseFunction, queryKeys, resumeFunction } from "@/lib/upnext-api";
import type { FunctionType } from "@/lib/types";
import { Search, X, FunctionSquare } from "lucide-react";
import { toast } from "sonner";
import { FunctionsTableSkeleton } from "./-components/skeletons";
import { FunctionsTable } from "./-components/functions-table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/functions/")({
  component: FunctionsPage,
});

const SAFETY_RESYNC_MS = 10 * 60 * 1000;

const typeOptions: { value: string; label: string }[] = [
  { value: "all", label: "All Types" },
  { value: "task", label: "Tasks" },
  { value: "cron", label: "Crons" },
  { value: "event", label: "Events" },
];

const STATUS_DEFAULT = "active";

function FunctionsPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedWorker, setSelectedWorker] = useState("all");
  const [statusFilter, setStatusFilter] = useState(STATUS_DEFAULT);
  const [pausePendingKey, setPausePendingKey] = useState<string | null>(null);

  const typeForQuery = selectedType === "all" ? undefined : (selectedType as FunctionType);

  // Fetch functions from API
  const { data: functionsData, isPending } = useQuery({
    queryKey: queryKeys.functions({ type: typeForQuery }),
    queryFn: () => getFunctions({ type: typeForQuery }),
    refetchInterval: SAFETY_RESYNC_MS,
  });

  const pauseMutation = useMutation({
    mutationFn: ({ key, paused }: { key: string; paused: boolean }) =>
      paused ? resumeFunction(key) : pauseFunction(key),
    onMutate: ({ key }) => {
      setPausePendingKey(key);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["functions"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    onError: (error: unknown) => {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to update function pause state"
      );
    },
    onSettled: () => {
      setPausePendingKey(null);
    },
  });

  const allFunctions = useMemo(() => functionsData?.functions ?? [], [functionsData?.functions]);

  // Extract unique worker names for filter dropdown
  const workerOptions = useMemo(() => {
    const names = new Set<string>();
    for (const fn of allFunctions) {
      for (const w of fn.workers ?? []) names.add(w);
    }
    return Array.from(names).sort();
  }, [allFunctions]);

  const filteredFunctions = useMemo(() => {
    let fns = allFunctions;

    if (search) {
      const searchLower = search.toLowerCase();
      fns = fns.filter(
        (fn) =>
          fn.name.toLowerCase().includes(searchLower) ||
          fn.schedule?.toLowerCase().includes(searchLower) ||
          fn.pattern?.toLowerCase().includes(searchLower)
      );
    }

    if (selectedWorker !== "all") {
      fns = fns.filter((fn) => (fn.workers ?? []).includes(selectedWorker));
    }

    if (statusFilter === "active") {
      fns = fns.filter((fn) => fn.active);
    } else if (statusFilter === "inactive") {
      fns = fns.filter((fn) => !fn.active);
    }

    return fns;
  }, [allFunctions, search, selectedWorker, statusFilter]);

  const hasNonDefaultFilters = search || selectedType !== "all" || selectedWorker !== "all" || statusFilter !== STATUS_DEFAULT;

  const clearFilters = () => {
    setSearch("");
    setSelectedType("all");
    setSelectedWorker("all");
    setStatusFilter(STATUS_DEFAULT);
  };

  return (
    <div className="p-4 h-full flex flex-col gap-4 overflow-hidden">
      {/* Filters Bar */}
      <div className="shrink-0 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 min-w-0 lg:flex-1">
            {/* Search */}
            <div className="relative w-full sm:max-w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search functions..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-muted border border-input rounded-md pl-9 pr-3 py-2 text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-ring"
              />
            </div>

            {/* Type Filter */}
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger size="sm" className="w-full sm:w-[130px] bg-muted border-input text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {typeOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Worker Filter */}
            {workerOptions.length > 0 && (
              <Select value={selectedWorker} onValueChange={setSelectedWorker}>
                <SelectTrigger size="sm" className="w-full sm:w-[170px] bg-muted border-input text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Workers</SelectItem>
                  {workerOptions.map((w) => (
                    <SelectItem key={w} value={w}>{w}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Status Filter */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger size="sm" className="w-full sm:w-[140px] bg-muted border-input text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>

            {/* Clear Filters */}
            {hasNonDefaultFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1 px-2 py-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors self-start sm:self-auto"
              >
                <X className="w-3 h-3" />
                Clear
              </button>
            )}
          </div>

          {/* Results count */}
          <span className="text-xs text-muted-foreground mono lg:text-right">
            {filteredFunctions.length} of {allFunctions.length} functions
          </span>
        </div>
      </div>

      {/* Functions Table */}
      <div className="matrix-panel rounded flex-1 overflow-hidden">
        {isPending ? (
          <FunctionsTableSkeleton />
        ) : filteredFunctions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <div className="rounded-full bg-muted/60 p-2 mb-2">
              <FunctionSquare className="h-4 w-4" />
            </div>
            <div className="text-sm font-medium">No functions available</div>
            <div className="text-xs mt-1 text-muted-foreground/80">
              {hasNonDefaultFilters ? "Try adjusting your filters" : "Functions will appear here when workers register with UpNext."}
            </div>
          </div>
        ) : (
          <FunctionsTable
            functions={filteredFunctions}
            pausePendingKey={pausePendingKey}
            onTogglePause={(fn) => {
              pauseMutation.mutate({ key: fn.key, paused: fn.paused });
            }}
          />
        )}
      </div>
    </div>
  );
}
