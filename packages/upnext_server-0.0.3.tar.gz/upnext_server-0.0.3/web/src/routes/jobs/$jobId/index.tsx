import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { RefreshCw } from "lucide-react";
import { cancelJob, getJobTimeline, queryKeys, retryJob } from "@/lib/upnext-api";
import { Panel } from "@/components/shared";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { JobRunHeader } from "./-components/job-run-header";
import { JobTimelinePanel } from "./-components/job-timeline-panel";
import { JobTaskRunsTab } from "./-components/job-task-runs-tab";
import { JobLogsTab } from "./-components/job-logs-tab";
import { JobArtifactsTab } from "./-components/job-artifacts-tab";
import { JobDetailsPanel } from "./-components/job-details-panel";
import { JobDetailSkeleton } from "./-components/skeletons";
import { buildJobTree } from "./-components/timeline-model";
import { toast } from "sonner";

export const Route = createFileRoute("/jobs/$jobId/")({
  component: JobDetailPage,
});

const SAFETY_RESYNC_MS = 10 * 60 * 1000;

function JobDetailPage() {
  const { jobId } = Route.useParams();
  const queryClient = useQueryClient();
  const [selectedJobId, setSelectedJobId] = useState(jobId);
  const [activeTab, setActiveTab] = useState("task-runs");

  useEffect(() => {
    setSelectedJobId(jobId);
  }, [jobId]);

  const { data, isPending } = useQuery({
    queryKey: queryKeys.jobTimeline(jobId),
    queryFn: () => getJobTimeline(jobId),
    refetchInterval: SAFETY_RESYNC_MS,
  });

  const timelineJobs = useMemo(() => data?.jobs ?? [], [data]);
  const treeJobs = useMemo(() => buildJobTree(timelineJobs, jobId), [timelineJobs, jobId]);
  const rootJob = treeJobs.find((job) => job.id === jobId);
  const selectedJob = treeJobs.find((job) => job.id === selectedJobId)
    ?? rootJob;
  const effectiveSelectedJobId = selectedJob?.id ?? jobId;

  const cancelMutation = useMutation({
    mutationFn: (id: string) => cancelJob(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobTimeline(jobId) });
      queryClient.invalidateQueries({ queryKey: ["jobs"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    onError: (error: unknown) => {
      toast.error(error instanceof Error ? error.message : "Failed to cancel job");
    },
  });

  const retryMutation = useMutation({
    mutationFn: (id: string) => retryJob(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobTimeline(jobId) });
      queryClient.invalidateQueries({ queryKey: ["jobs"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    onError: (error: unknown) => {
      toast.error(error instanceof Error ? error.message : "Failed to retry job");
    },
  });

  if (isPending && !rootJob) {
    return <JobDetailSkeleton />;
  }

  if (!rootJob || !selectedJob) {
    return (
      <div className="p-4 h-full flex items-center justify-center text-sm text-muted-foreground">
        Job not found.
      </div>
    );
  }

  return (
    <div className="p-4 h-full flex flex-col gap-3 overflow-auto xl:overflow-hidden">
      <JobRunHeader
        job={rootJob}
        actionPending={cancelMutation.isPending || retryMutation.isPending}
        onCancel={() => cancelMutation.mutate(rootJob.id)}
        onRetry={() => retryMutation.mutate(rootJob.id)}
      />

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_minmax(340px,380px)] gap-3 min-h-0 flex-1">
        <div className="min-h-0 flex flex-col gap-3">
          <JobTimelinePanel
            jobs={treeJobs}
            selectedJobId={effectiveSelectedJobId}
            onSelectJob={setSelectedJobId}
          />

          <Panel
            title="Task Activity"
            className="flex-1 min-h-[280px] flex flex-col overflow-hidden"
            contentClassName="flex-1 p-0 overflow-hidden"
          >
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
              <div className="px-3 pt-2 border-b border-border flex items-center justify-between gap-2">
                <TabsList variant="line" className="h-8">
                  <TabsTrigger value="task-runs" className="text-xs">Task Runs</TabsTrigger>
                  <TabsTrigger value="logs" className="text-xs">Logs</TabsTrigger>
                  <TabsTrigger value="artifacts" className="text-xs">Artifacts</TabsTrigger>
                </TabsList>
                {activeTab === "artifacts" && (
                  <button
                    type="button"
                    onClick={() => {
                      void queryClient.refetchQueries({
                        queryKey: queryKeys.jobArtifacts(effectiveSelectedJobId),
                        exact: true,
                      });
                    }}
                    className="h-7 w-7 inline-flex items-center justify-center rounded border border-input text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                    aria-label="Refresh artifacts"
                    title="Refresh artifacts"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>

              <TabsContent value="task-runs" className="h-full m-0">
                <JobTaskRunsTab
                  jobs={treeJobs}
                  selectedJobId={effectiveSelectedJobId}
                  onSelectJob={setSelectedJobId}
                />
              </TabsContent>

              <TabsContent value="logs" className="h-full m-0">
                <JobLogsTab jobs={treeJobs} selectedJobId={effectiveSelectedJobId} />
              </TabsContent>

              <TabsContent value="artifacts" className="h-full m-0">
                <JobArtifactsTab
                  jobs={treeJobs}
                  selectedJobId={effectiveSelectedJobId}
                />
              </TabsContent>
            </Tabs>
          </Panel>
        </div>

        <div className="min-h-0">
          <JobDetailsPanel job={selectedJob} />
        </div>
      </div>
    </div>
  );
}
