declare module "react-syntax-highlighter/dist/esm/languages/prism/csv" {
  const language: unknown;
  export default language;
}

declare module "react-syntax-highlighter/dist/esm/languages/prism/json" {
  const language: unknown;
  export default language;
}

declare module "react-syntax-highlighter/dist/esm/languages/prism/markup" {
  const language: unknown;
  export default language;
}

