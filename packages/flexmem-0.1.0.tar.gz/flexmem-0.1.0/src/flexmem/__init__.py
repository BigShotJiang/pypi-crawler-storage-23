"""
flexmem - Permanent memory for Claude Code sessions.
"""
__version__ = "0.1.0"
