# flexmem

Permanent memory for Claude Code sessions. Your intellectual capital, preserved.

Coming soon. Follow [@axp_systems](https://axp.systems).
