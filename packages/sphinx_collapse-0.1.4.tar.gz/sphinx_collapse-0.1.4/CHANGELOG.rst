=========
Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog <https://keepachangelog.com/en/1.0.0/>`_,
and this project adheres to `Semantic Versioning <https://semver.org/spec/v2.0.0.html>`_.

0.1.4 - 27 Feb 2026
-------------------

Fixed
=====

* Fixed ``KeyError`` for missing node attributes (e.g. ``backrefs``) in newer
  versions of docutils by using ``.pop()`` with a default value of ``None``.

0.1.3 - 22 Feb 2024
-------------------

Added
=====

* The directive can be open by default.
* The extension support paralell builds.

Fixed
=====

* The extension was not compatible with ``sphinx-build latexpdf``.


0.1.2 - 18 May 2022
-------------------

Fixed
=====

* The extension was not compatible with ``sphinx-build latexpdf``.

0.1.1 - 19 Jan 2022
-------------------

Added
=====

* Initial code release
