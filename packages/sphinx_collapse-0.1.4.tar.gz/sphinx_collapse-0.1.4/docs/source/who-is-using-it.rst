Who is using it?
================

Alation Documentation:
    https://docs.alationdata.com/en/latest/admins/Troubleshooting/LogsOverview.html#django
BattMo:
    https://battmoteam.github.io/BattMo/intermediate.html#file-links-and-insertions-with-parsebattmojson
CoLRev:
    https://colrev.readthedocs.io/en/latest/manual/operations.html
IDF Component Manager:
    https://docs.espressif.com/projects/idf-component-manager/en/latest/index.html
Intel Labs:
    https://intellabs.github.io/ScalableVectorSearch/start.html#generating-test-data
PlasmaPy:
    https://docs.plasmapy.org/en/stable/contributing/workflow.html#create-a-new-branch
pymadcap:
    https://pymadcad.readthedocs.io/en/latest/reference/mesh/web.html
ScyllaDB:
    https://sphinx-theme.scylladb.com/stable/examples/collapse.html
Trossen Robotics:
    https://docs.trossenrobotics.com/interbotix_xslocobots_docs/ros_interface/ros1/software_setup.html
