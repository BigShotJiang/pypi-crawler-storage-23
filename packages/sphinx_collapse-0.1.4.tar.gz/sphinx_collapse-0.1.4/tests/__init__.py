"""
Tests for collapse extension.
"""
