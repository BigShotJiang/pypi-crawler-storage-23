:orphan:

SPOT is licensed under a 3-clause BSD style license:

.. include:: ../LICENSE.md
