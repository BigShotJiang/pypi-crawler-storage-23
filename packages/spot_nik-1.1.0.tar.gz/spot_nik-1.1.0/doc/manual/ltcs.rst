++++
LTCS
++++

The LTCS (Laser Traffic Control System) plugin is used to monitor
the laser collision status between Subaru and other telescopes.



