++++++++++++++++
Acknowledgements
++++++++++++++++

This publication makes use of data products from the Wide-field 
Infrared Survey Explorer, which is a joint project of the 
University of California, Los Angeles, and the Jet Propulsion 
Laboratory/California Institute of Technology, funded by the 
National Aeronautics and Space Administration.