++++++++
Planning
++++++++
Alternative access to the secondary channels that are listed on the 
CPanel. 
