++++++
Custom
++++++

Plugins which have been added by the user can be found here.

For a guide on how to create your own plugins, please read the 
`Ginga Developer's Manual`_.

.. _`Ginga Developer's Manual`: https://ginga.readthedocs.io/en/stable/dev_manual/index.html

