# -*- coding: utf-8 -*-
"""
技术因子（pandas 可选依赖已移除，空壳保留向后兼容）
"""


class BasicFactors:
    """基础技术因子（已清空，原方法依赖 pandas 的 .rolling() 等专属 API）"""
    pass
