"""
logging_sync.py

Thread and multiprocessing safe logging utilities for lupin_logger.
Provides:

- Global lock initialization for multiprocessing
- Safe retrieval of shared lock
- Factory helper to wrap existing CustomLogger
"""

from multiprocessing import Lock, Manager
from typing import Optional

from lupin_logger.logger import CustomLogger


# ------------------------------------------------------------------
# GLOBAL LOCK MANAGEMENT
# ------------------------------------------------------------------

_global_log_lock: Optional[Lock] = None
_lock_manager: Optional[Manager] = None


def initialize_log_lock(manager: Optional[Manager] = None) -> Lock:
    """
    Initialize a global multiprocessing lock.

    Must be called in the main process BEFORE spawning workers.

    Args:
        manager: Optional existing multiprocessing.Manager

    Returns:
        Shared multiprocessing.Lock
    """
    global _global_log_lock, _lock_manager

    if _global_log_lock is not None:
        return _global_log_lock

    if manager is None:
        _lock_manager = Manager()
        _global_log_lock = _lock_manager.Lock()
    else:
        _lock_manager = manager
        _global_log_lock = manager.Lock()

    return _global_log_lock


def get_global_log_lock() -> Lock:
    """
    Retrieve global lock.

    If not initialized, creates a local lock (NOT shared across processes).
    """
    global _global_log_lock

    if _global_log_lock is None:
        # Fallback (thread-safe only, not cross-process safe)
        _global_log_lock = Lock()

    return _global_log_lock


# ------------------------------------------------------------------
# FACTORY HELPERS
# ------------------------------------------------------------------


def get_synchronized_logger(
    name: str,
    app: str = "default",
    log_directory: Optional[str] = None,
) -> CustomLogger:
    """
    Replacement for get_logger() that returns a synchronized logger.

    Example:
        logger = get_synchronized_logger("my_logger")

    Returns:
        SynchronizedLogger instance
    """
    from lupin_logger.logging_sync import SynchronizedLogger
    from lupin_logger.logger import get_logger

    base_logger = get_logger(name=name, app=app, log_directory=log_directory)
    lock = get_global_log_lock()

    return SynchronizedLogger(base_logger, lock)


def synchronize_existing_logger(
    logger: CustomLogger,
    lock: Optional[Lock] = None,
) -> CustomLogger:
    """
    Convert an existing CustomLogger into a SynchronizedLogger.

    Example:
        logger = get_logger("test")
        logger = synchronize_existing_logger(logger)

    Returns:
        SynchronizedLogger instance
    """
    from lupin_logger.logging_sync import SynchronizedLogger

    return SynchronizedLogger(
        logger,
        lock if lock is not None else get_global_log_lock(),
    )


class SynchronizedLogger(CustomLogger):

    def __init__(self, logger: CustomLogger, lock: Lock):
        self.__dict__ = logger.__dict__
        self.__class__ = SynchronizedLogger
        self._lock = lock

    def _log_with_attr(
        self,
        level: int,
        msg: str,
        attr: Optional[dict] = None,
        stacklevel: int = 3,
        **kwargs,
    ) -> None:

        with self._lock:
            super()._log_with_attr(
                level=level,
                msg=msg,
                attr=attr,
                stacklevel=stacklevel + 1,
                **kwargs,
            )
