# tests/test_logger_multithread.py
import threading
from pathlib import Path
from lupin_logger import get_synchronized_logger


def test_multithread_logging(tmp_path: Path):
    # Logger normal avec répertoire temporaire
    logger = get_synchronized_logger(
        "test_multithread", app="test_app", log_directory=str(tmp_path)
    )

    # --- Handler mémoire pour capture (ne pollue pas tmp_path) ---
    class CaptureHandler:
        def __init__(self):
            self.records = []

        def emit(self, record):
            self.records.append(record)

    capture = CaptureHandler()

    from logging import Handler

    class WrapperHandler(Handler):
        def emit(self, record):
            capture.records.append(record)

    logger.addHandler(WrapperHandler())

    # --- Worker ---
    def worker(thread_id: int):
        for i in range(5):
            logger.info(f"Message {i} from worker {thread_id}", {"iteration": i})

    # --- Lancement de 2 threads ---
    threads = []
    for i in range(2):
        t = threading.Thread(target=worker, args=(i,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    # log final
    logger.info("Finished all threads")

    # --- Assertions ---
    # 2 threads * 5 messages + 1 final
    assert len(capture.records) == 11

    # Tous les records ont thread natif
    for r in capture.records:
        assert hasattr(r, "thread")

    # Vérifie que loc pointe vers ce fichier
    for r in capture.records:
        assert Path(__file__).name in Path(r.pathname).name
