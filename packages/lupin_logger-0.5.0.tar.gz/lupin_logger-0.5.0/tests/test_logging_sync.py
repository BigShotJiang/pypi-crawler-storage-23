import threading
from multiprocessing import Lock
import logging
import inspect
from pathlib import Path


import pytest

from lupin_logger.logging_sync import SynchronizedLogger
from lupin_logger import CustomLogger


class CaptureHandler(logging.Handler):
    """Handler pour capturer les LogRecord dans les tests."""

    def __init__(self):
        super().__init__()
        self.records = []

    def emit(self, record):
        self.records.append(record)


@pytest.fixture
def base_logger(tmp_path):
    logger = CustomLogger(
        name="test_logger",
        app="test_app",
        log_directory=str(tmp_path),
    )
    # Supprime handlers existants
    logger.handlers = []

    handler = CaptureHandler()
    logger.addHandler(handler)
    return logger, handler


def test_non_sync_logger_has_no_thread(base_logger):
    logger, handler = base_logger

    logger.info("hello")

    assert len(handler.records) == 1
    record = handler.records[0]

    assert not hasattr(record, "thread") or record.thread == threading.get_ident()
    # Le champ "thread" ne doit PAS être injecté via attr
    assert not hasattr(record, "attr") or "thread" not in getattr(record, "attr", {})


def test_sync_logger_injects_thread(base_logger):
    logger, handler = base_logger
    sync_logger = SynchronizedLogger(logger, Lock())

    sync_logger.info("hello")

    assert len(handler.records) == 1
    record = handler.records[0]

    # Thread ID existe déjà dans LogRecord
    assert hasattr(record, "thread")
    assert record.thread == threading.get_ident()


def test_sync_logger_loc(base_logger):
    logger, handler = base_logger
    sync_logger = SynchronizedLogger(logger, threading.Lock())

    expected_line = inspect.currentframe().f_lineno + 1
    sync_logger.info("location test")

    record = handler.records[0]

    assert Path(record.pathname).name == Path(__file__).name
    assert record.lineno == expected_line
