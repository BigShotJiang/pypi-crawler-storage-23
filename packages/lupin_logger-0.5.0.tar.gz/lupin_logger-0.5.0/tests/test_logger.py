import logging
import inspect
from pathlib import Path
import pytest


from lupin_logger import CustomLogger


class ListHandler(logging.Handler):
    """Handler minimal pour capturer les LogRecord."""

    def __init__(self):
        super().__init__()
        self.records = []

    def emit(self, record):
        self.records.append(record)


class CaptureHandler(logging.Handler):
    """Handler simple pour capturer les LogRecord."""

    def __init__(self):
        super().__init__(level=logging.NOTSET)
        self.records = []

    def emit(self, record):
        self.records.append(record)


@pytest.fixture
def base_logger(tmp_path):
    logger = CustomLogger(
        name="test_logger",
        app="test_app",
        log_directory=str(tmp_path),
    )
    # supprime les handlers existants pour ne pas polluer la console/fichier
    logger.handlers = []

    capture = CaptureHandler()
    logger.addHandler(capture)
    return logger, capture


def test_custom_logger_loc(base_logger):
    """Test que CustomLogger logge avec la bonne localisation (pathname + lineno)."""
    logger, handler = base_logger

    # Ligne que l'on veut capturer
    expected_line = inspect.currentframe().f_lineno + 1
    logger.info("hello loc test")

    assert len(handler.records) == 1
    record = handler.records[0]

    # Vérifie la ligne
    assert record.lineno == expected_line

    # Vérifie le fichier avec pathlib
    assert Path(record.pathname).name == Path(__file__).name


def test_custom_logger_basic(tmp_path):
    # Create logger
    logger = CustomLogger(
        name="unit_test_logger",
        app="unit_test_app",
        log_directory=str(tmp_path),
    )

    # Remove default handlers to avoid file/console pollution
    logger.handlers = []

    capture = ListHandler()
    logger.addHandler(capture)

    # Ligne que l'on veut vérifier
    expected_line = inspect.currentframe().f_lineno + 1
    logger.info("hello world", {"key": "value"})

    # 1 seul log attendu
    assert len(capture.records) == 1

    record = capture.records[0]

    # Vérifie message
    assert record.getMessage() == "hello world"

    # Vérifie app injectée
    assert record.app == "unit_test_app"

    # Vérifie attr injecté
    assert hasattr(record, "attr")
    assert record.attr["key"] == "value"

    # Vérifie localisation correcte

    assert record.lineno == expected_line
    assert Path(record.pathname).name == Path(__file__).name

    # Vérifie absence de thread dans logger non sync
    assert "thread" not in record.attr
