"""Allow running Sundew as a module: python -m sundew."""

from sundew.cli import main

if __name__ == "__main__":
    main()
