"""Sundew: An open-source honeypot for detecting autonomous AI agent attacks."""

__version__ = "0.1.0"
