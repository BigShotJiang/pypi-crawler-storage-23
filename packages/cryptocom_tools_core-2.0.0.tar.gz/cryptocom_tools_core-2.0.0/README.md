# cryptocom-tools-core

Core base classes for Crypto.com Developer Platform tools.

## Installation

```bash
pip install cryptocom-tools-core
```

## Usage

```python
from cryptocom_tools_core import CDPTool, BalanceResult
from pydantic import BaseModel, Field

class GetBalanceInput(BaseModel):
    address: str = Field(description="Wallet address")

class GetBalanceTool(CDPTool):
    name: str = "get_balance"
    description: str = "Get native token balance"
    args_schema: type[BaseModel] = GetBalanceInput

    def _run(self, address: str) -> str:
        # Your implementation
        return str(BalanceResult(address=address, balance="100", unit="CRO"))

# Use with LangChain
tool = GetBalanceTool(api_key="your-api-key")

# Or export to OpenAI/Anthropic via adapters
from cryptocom_tool_adapters import to_openai_function
openai_tool = to_openai_function(tool)
```

## Exports

- `CDPTool` - Base class extending LangChain BaseTool with CDP API key injection
- `ToolResult` - Base class for structured tool outputs
- `BalanceResult` - Result type for balance queries
- `TransactionResult` - Result type for transaction queries
- `TickerResult` - Result type for exchange ticker queries
