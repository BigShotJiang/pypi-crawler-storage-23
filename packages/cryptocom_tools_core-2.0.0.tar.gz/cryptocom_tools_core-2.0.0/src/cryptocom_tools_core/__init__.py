"""
Crypto.com Tools Core - Base classes for CDP tools.

This package provides the foundational classes for building tools
that work with the Crypto.com Developer Platform:

- CDPTool: Base class extending LangChain BaseTool with CDP API key injection
- ToolResult: Base class for structured tool outputs

Example:
    from cryptocom_tools_core import CDPTool
    from pydantic import BaseModel, Field

    class GetBalanceInput(BaseModel):
        address: str = Field(description="Wallet address")

    class GetBalanceTool(CDPTool):
        name: str = "get_balance"
        description: str = "Get native token balance"
        args_schema: type[BaseModel] = GetBalanceInput

        def _run(self, address: str) -> str:
            # Your implementation here
            return f"Balance for {address}: 100 CRO"
"""

from __future__ import annotations

__version__ = "0.1.0"

from .base import (
    CDPTool,
    ToolResult,
    get_tool_defaults,
)
from .signer import (
    InsufficientFundsError,
    Signer,
    SignerError,
    TransactionFailedError,
)

__all__ = [
    "__version__",
    "CDPTool",
    "InsufficientFundsError",
    "Signer",
    "SignerError",
    "ToolResult",
    "TransactionFailedError",
    "get_tool_defaults",
]
