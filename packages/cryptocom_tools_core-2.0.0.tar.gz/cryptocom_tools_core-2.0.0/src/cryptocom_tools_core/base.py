"""
Base class for Crypto.com Developer Platform tools.

This module provides CDPTool, which inherits from LangChain's BaseTool
and adds CDP-specific functionality like API key injection.

For non-CDP tools, inherit from langchain_core.tools.BaseTool directly.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from langchain_core.tools import BaseTool
from pydantic import Field

# Environment variable name for CDP API key
CDP_API_KEY_ENV = "CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"


class CDPTool(BaseTool):
    """
    Base class for tools that use the Crypto.com Developer Platform.

    Inherits from LangChain BaseTool, adding:
    - api_key auto-read from environment (CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY)
    - api_key excluded from LLM-visible schema
    - automatic Client.init() on tool creation

    This tool works natively with LangChain/LangGraph and can be exported
    to OpenAI/Anthropic SDKs via adapters:
        from cryptocom_tool_adapters import to_openai_function, to_anthropic_tool

    Example:
        class GetBalanceTool(CDPTool):
            name: str = "get_balance"
            description: str = "Get native token balance for a wallet address"
            args_schema = GetBalanceInput

            def _run(self, address: str) -> str:
                from crypto_com_developer_platform_client import Token
                result = Token.get_native_balance(address)
                return f"Balance: {result['data']['balance']} wei"

        # Usage - auto-reads from CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY env var
        tool = GetBalanceTool()
        agent = create_agent("openai:gpt-4o", tools=[tool])

        # Or explicit override
        tool = GetBalanceTool(api_key="different-key")
    """

    api_key: str | None = Field(default=None, exclude=True)
    """CDP API key. Auto-reads from env if not provided. Excluded from schema."""

    def model_post_init(self, __context: Any) -> None:
        """Initialize CDP client after tool creation."""
        super().model_post_init(__context)

        # Auto-read from environment if not explicitly provided
        key = self.api_key or os.getenv(CDP_API_KEY_ENV)
        if key:
            from crypto_com_developer_platform_client import Client

            Client.init(api_key=key)


@dataclass
class ToolResult:
    """Base class for tool results with standard formatting."""

    def __str__(self) -> str:
        """Convert result to string for display."""
        return self._format_result()

    def _format_result(self) -> str:
        """Format the result for display. Override in subclasses."""
        return str(self.__dict__)


def get_tool_defaults(tool: BaseTool) -> dict[str, object]:
    """Extract default values from a tool's args_schema.

    Useful for debugging, logging, or pre-populating tool inputs.

    Example:
        from cryptocom_tools_exchange import GetTickersTool
        from cryptocom_tools_core import get_tool_defaults

        tool = GetTickersTool()
        defaults = get_tool_defaults(tool)
        # {'quote_currency': 'USDT'}

    Args:
        tool: Any LangChain BaseTool with an args_schema

    Returns:
        Dict mapping field names to their default values
    """
    args_schema = tool.args_schema
    if not args_schema:
        return {}

    # Get model_json_schema method (Pydantic v2)
    get_schema = getattr(args_schema, "model_json_schema", None)
    if get_schema is None:
        return {}

    schema: dict[str, Any] = get_schema()
    defaults: dict[str, object] = {}
    for field, props in schema.get("properties", {}).items():
        if isinstance(props, dict) and "default" in props:
            defaults[field] = props["default"]

    return defaults
