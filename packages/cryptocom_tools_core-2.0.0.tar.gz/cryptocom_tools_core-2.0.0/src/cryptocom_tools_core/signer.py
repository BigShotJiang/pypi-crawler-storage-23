"""Signer protocol for blockchain transactions."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class Signer(Protocol):
    """
    Abstract signer for blockchain transactions.

    Implementations:
    - PrivateKeySigner: Direct EOA signing (in cryptocom-tools-wallet)
    """

    @property
    def address(self) -> str:
        """The address this signer controls."""
        ...

    @property
    def chain_id(self) -> int:
        """The chain ID this signer is configured for."""
        ...

    def send_transaction(self, tx: dict[str, Any]) -> str:
        """
        Sign and broadcast a transaction.

        Args:
            tx: Transaction dict with keys: to, value, data, gas (optional)

        Returns:
            Transaction hash as hex string
        """
        ...


class SignerError(Exception):
    """Base exception for signer operations."""

    pass


class InsufficientFundsError(SignerError):
    """Raised when account has insufficient funds."""

    pass


class TransactionFailedError(SignerError):
    """Raised when transaction fails to broadcast or reverts."""

    def __init__(self, message: str, tx_hash: str | None = None):
        super().__init__(message)
        self.tx_hash = tx_hash
