"""
Jarvis MCP Server

Jarvis-CD MCP - Pipeline Management for High-Performance Computing with comprehensive workflow operations

Version: 1.0.0
Author: IoWarp Team - Gnosis Research Center
License: MIT
"""

__version__ = "1.0.0"
__author__ = "IoWarp Team - Gnosis Research Center"
__email__ = "grc@illinoistech.edu"
__license__ = "MIT"

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "__license__",
]
