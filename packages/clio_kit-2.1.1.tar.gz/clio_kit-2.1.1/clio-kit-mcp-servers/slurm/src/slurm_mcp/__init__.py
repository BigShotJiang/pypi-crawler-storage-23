"""Slurm MCP Server - Model Context Protocol server for HPC job management."""

__version__ = "1.0.0"
__author__ = "IoWarp Scientific MCPs"
