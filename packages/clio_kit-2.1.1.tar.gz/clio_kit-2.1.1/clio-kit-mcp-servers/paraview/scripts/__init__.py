"""
Build scripts for ParaView MCP
"""
