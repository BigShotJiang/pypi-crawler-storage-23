#!/usr/bin/env python3
"""
Node Hardware MCP Server - System hardware monitoring via the Model Context Protocol.
"""

import os
import sys
import json
import logging
from typing import Annotated, Optional

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.prompts import Message
from pydantic import Field

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    print(
        "Warning: python-dotenv not available. Environment variables may not be loaded.",
        file=sys.stderr,
    )

from . import mcp_handlers

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server instance
mcp: FastMCP = FastMCP(
    "node-hardware",
    instructions=(
        "Monitors system hardware including CPU, memory, disk, network, and GPU. "
        "Use individual tools for specific metrics or get a full system overview."
    ),
    list_page_size=10,
)


# Custom exception for hardware monitoring errors
class NodeHardwareMCPError(Exception):
    """Custom exception for Node Hardware MCP-related errors"""

    pass


# ---- Shared annotation constants ----
_READ_ONLY_ANNOTATIONS = {
    "readOnlyHint": True,
    "destructiveHint": False,
    "idempotentHint": True,
}

# ===============================================================================
# INDIVIDUAL HARDWARE COMPONENT TOOLS
# ===============================================================================


@mcp.tool(
    name="get_cpu_info",
    description="Get CPU specifications, core counts, frequencies, and per-core usage.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "cpu"},
)
async def get_cpu_info_tool() -> dict:
    """Get CPU specifications, core counts, frequencies, and per-core usage."""
    try:
        logger.info("Collecting CPU information")
        return mcp_handlers.cpu_info_handler()
    except Exception as e:
        logger.error(f"CPU information collection error: {e}")
        raise ToolError(f"CPU collection failed: {e}") from e


@mcp.tool(
    name="get_memory_info",
    description="Get RAM and swap capacity, usage percentages, and availability.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "memory"},
)
async def get_memory_info_tool() -> dict:
    """Get RAM and swap capacity, usage percentages, and availability."""
    try:
        logger.info("Collecting memory information")
        return mcp_handlers.memory_info_handler()
    except Exception as e:
        logger.error(f"Memory information collection error: {e}")
        raise ToolError(f"Memory collection failed: {e}") from e


@mcp.tool(
    name="get_system_info",
    description="Get OS details, hostname, uptime, and active users.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "system"},
)
async def get_system_info_tool() -> dict:
    """Get OS details, hostname, uptime, and active users."""
    try:
        logger.info("Collecting system information")
        return mcp_handlers.system_info_handler()
    except Exception as e:
        logger.error(f"System information collection error: {e}")
        raise ToolError(f"System collection failed: {e}") from e


@mcp.tool(
    name="get_disk_info",
    description="Get disk partitions, usage statistics, and I/O counters.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "disk"},
)
async def get_disk_info_tool() -> dict:
    """Get disk partitions, usage statistics, and I/O counters."""
    try:
        logger.info("Collecting disk information")
        return mcp_handlers.disk_info_handler()
    except Exception as e:
        logger.error(f"Disk information collection error: {e}")
        raise ToolError(f"Disk collection failed: {e}") from e


@mcp.tool(
    name="get_network_info",
    description="Get network interfaces, IP addresses, and I/O statistics.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "network"},
)
async def get_network_info_tool() -> dict:
    """Get network interfaces, IP addresses, and I/O statistics."""
    try:
        logger.info("Collecting network information")
        return mcp_handlers.network_info_handler()
    except Exception as e:
        logger.error(f"Network information collection error: {e}")
        raise ToolError(f"Network collection failed: {e}") from e


@mcp.tool(
    name="get_gpu_info",
    description="Get GPU model, memory, temperature, and utilization via nvidia-smi/rocm-smi.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "gpu"},
)
async def get_gpu_info_tool() -> dict:
    """Get GPU model, memory, temperature, and utilization."""
    try:
        logger.info("Collecting GPU information")
        return mcp_handlers.gpu_info_handler()
    except Exception as e:
        logger.error(f"GPU information collection error: {e}")
        raise ToolError(f"GPU collection failed: {e}") from e


@mcp.tool(
    name="get_sensor_info",
    description="Get temperature, fan speed, and battery sensor readings.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "sensor"},
)
async def get_sensor_info_tool() -> dict:
    """Get temperature, fan speed, and battery sensor readings."""
    try:
        logger.info("Collecting sensor information")
        return mcp_handlers.sensor_info_handler()
    except Exception as e:
        logger.error(f"Sensor information collection error: {e}")
        raise ToolError(f"Sensor collection failed: {e}") from e


@mcp.tool(
    name="get_process_info",
    description="Get running processes with CPU, memory, and status details.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "process"},
)
async def get_process_info_tool() -> dict:
    """Get running processes with CPU, memory, and status details."""
    try:
        logger.info("Collecting process information")
        return mcp_handlers.process_info_handler()
    except Exception as e:
        logger.error(f"Process information collection error: {e}")
        raise ToolError(f"Process collection failed: {e}") from e


@mcp.tool(
    name="get_performance_info",
    description="Get real-time CPU, memory, disk, and network performance metrics.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "performance"},
)
async def get_performance_info_tool() -> dict:
    """Get real-time CPU, memory, disk, and network performance metrics."""
    try:
        logger.info("Collecting performance information")
        return mcp_handlers.performance_monitor_handler()
    except Exception as e:
        logger.error(f"Performance information collection error: {e}")
        raise ToolError(f"Performance collection failed: {e}") from e


# ===============================================================================
# REMOTE NODE HARDWARE MONITORING VIA SSH
# ===============================================================================


@mcp.tool(
    name="get_remote_node_info",
    description="Collect hardware info from a remote node via SSH. Supports component filtering.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "remote", "ssh"},
)
async def get_remote_node_info_tool(
    hostname: Annotated[str, Field(description="Target hostname or IP address.")],
    username: Annotated[Optional[str], Field(description="SSH username.")] = None,
    port: Annotated[int, Field(description="SSH port number.")] = 22,
    ssh_key: Annotated[
        Optional[str], Field(description="Path to SSH private key file.")
    ] = None,
    timeout: Annotated[
        int, Field(description="SSH connection timeout in seconds.")
    ] = 30,
    components: Annotated[
        Optional[list[str]],
        Field(description="Components to include, e.g. ['cpu','memory']."),
    ] = None,
    exclude_components: Annotated[
        Optional[list[str]],
        Field(description="Components to exclude from collection."),
    ] = None,
    include_performance: Annotated[
        bool, Field(description="Include real-time performance analysis.")
    ] = True,
    include_health: Annotated[
        bool, Field(description="Include health assessment.")
    ] = True,
) -> dict:
    """Collect hardware info from a remote node via SSH."""
    try:
        logger.info(
            f"Collecting remote hardware information from {hostname}: "
            f"components={components}, exclude={exclude_components}"
        )
        return mcp_handlers.get_remote_node_info_handler(
            hostname=hostname,
            username=username,
            port=port,
            ssh_key=ssh_key,
            timeout=timeout,
            include_filters=components,
            exclude_filters=exclude_components,
        )
    except Exception as e:
        logger.error(f"Remote hardware information collection error: {e}")
        raise ToolError(f"Remote hardware collection failed for {hostname}: {e}") from e


# ===============================================================================
# SYSTEM HEALTH AND DIAGNOSTICS
# ===============================================================================


@mcp.tool(
    name="health_check",
    description="Verify server health and hardware monitoring capability status.",
    annotations=_READ_ONLY_ANNOTATIONS,
    tags={"hardware", "diagnostics"},
)
async def health_check_tool() -> dict:
    """Verify server health and hardware monitoring capability status."""
    try:
        logger.info("Performing health check")

        health_status = {
            "server_status": "healthy",
            "timestamp": json.dumps({"timestamp": "2024-01-01T00:00:00Z"}),
            "capabilities": {
                "get_node_info": "available",
                "get_remote_node_info": "available",
                "local_collection": "available",
                "remote_collection": "available",
                "ssh_support": "available",
                "component_filtering": "available",
                "performance_analysis": "available",
                "health_assessment": "available",
                "intelligent_insights": "available",
                "predictive_maintenance": "available",
            },
            "system_compatibility": {
                "python_version": sys.version,
                "platform": os.name,
                "dependencies": "loaded",
                "ssh_support": "available",
                "hardware_monitoring": "available",
            },
            "performance_metrics": {
                "response_time": "optimal",
                "resource_usage": "efficient",
                "collection_speed": "high",
                "network_efficiency": "optimized",
            },
            "health_indicators": {
                "overall_health": "excellent",
                "system_stability": "stable",
                "performance_status": "optimal",
                "security_posture": "secure",
            },
        }

        return health_status
    except Exception as e:
        logger.error(f"Health check error: {e}")
        raise ToolError(f"Health check failed: {e}") from e


# ===============================================================================
# RESOURCE
# ===============================================================================


@mcp.resource("node-hardware://system-info")
def system_info() -> dict:
    """Basic system identification info."""
    import platform

    return {
        "hostname": platform.node(),
        "os": platform.system(),
        "architecture": platform.machine(),
        "python_version": platform.python_version(),
    }


# ===============================================================================
# PROMPT
# ===============================================================================


@mcp.prompt()
def system_health_check() -> list[Message]:
    """Guided workflow for a full system health check."""
    return [
        Message(
            "Run a complete system health check. Check CPU usage, memory utilization, "
            "disk space, and network status. Report any components that are under stress "
            "or running low on resources."
        ),
    ]


def main() -> None:
    """Main entry point for the Node Hardware MCP server."""
    import argparse

    parser = argparse.ArgumentParser(description="Node Hardware MCP Server")
    parser.add_argument("--transport", choices=["stdio", "http"], default=None)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    transport = args.transport or os.getenv("MCP_TRANSPORT", "stdio")
    if transport == "http":
        mcp.run(transport="http", host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
