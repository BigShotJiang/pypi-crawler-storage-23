"""MCP capability modules for Parquet operations."""
