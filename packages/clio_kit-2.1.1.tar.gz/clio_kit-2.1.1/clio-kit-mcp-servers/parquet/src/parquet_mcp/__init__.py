"""Parquet MCP Server - enables AI agents to explore Parquet files intelligently."""

__version__ = "0.1.0"
