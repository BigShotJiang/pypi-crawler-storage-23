"""Filesystem connector package."""

from clio_agentic_search.connectors.filesystem.connector import FilesystemConnector

__all__ = ["FilesystemConnector"]
