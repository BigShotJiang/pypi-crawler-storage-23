"""Rich console helpers for terminal UI."""

from __future__ import annotations

from typing import Optional


def _console():
    from rich.console import Console
    return Console()


def success(msg: str) -> None:
    _console().print(f"[bold green]✓[/] {msg}")


def error(msg: str) -> None:
    _console().print(f"[bold red]✗[/] {msg}")


def warning(msg: str) -> None:
    _console().print(f"[bold yellow]![/] {msg}")


def info(msg: str) -> None:
    _console().print(f"[dim]→[/] {msg}")


def prompt(text: str, default: str = "") -> str:
    from rich.prompt import Prompt
    return Prompt.ask(text, default=default, console=_console())


def prompt_list(text: str, hint: str = "comma-separated") -> list[str]:
    """Prompt for a comma-separated list, return parsed items."""
    raw = prompt(f"{text} [dim]({hint})[/]")
    if not raw.strip():
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def confirm(text: str, default: bool = False) -> bool:
    from rich.prompt import Confirm
    return Confirm.ask(text, default=default, console=_console())


def print_table(title: str, columns: list[str], rows: list[list[str]]) -> None:
    from rich.table import Table
    table = Table(title=title, show_lines=False)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*row)
    _console().print(table)


def print_context_brief(ctx_dict: dict) -> None:
    """Print a brief summary of a context."""
    from rich.panel import Panel
    from rich.text import Text

    lines: list[str] = []
    if ctx_dict.get("message"):
        lines.append(f"[bold]{ctx_dict['message']}[/]")
    if ctx_dict.get("task"):
        lines.append(f"Task: {ctx_dict['task']}")
    if ctx_dict.get("branch"):
        lines.append(f"Branch: [cyan]{ctx_dict['branch']}[/]")
    if ctx_dict.get("files_changed"):
        count = len(ctx_dict["files_changed"])
        lines.append(f"Files changed: {count}")
    if ctx_dict.get("tags"):
        lines.append(f"Tags: {', '.join(ctx_dict['tags'])}")

    panel = Panel("\n".join(lines), title="Context", border_style="blue")
    _console().print(panel)
