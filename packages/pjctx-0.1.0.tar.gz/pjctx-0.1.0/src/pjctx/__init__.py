"""PJContext — Capture and restore AI coding context."""

__version__ = "0.1.0"
