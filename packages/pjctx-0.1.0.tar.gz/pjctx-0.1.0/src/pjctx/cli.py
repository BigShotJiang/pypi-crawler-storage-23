"""Click CLI group and command wiring."""

from __future__ import annotations

import click

from pjctx import __version__


@click.group()
@click.version_option(version=__version__, prog_name="pjctx")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output.")
@click.pass_context
def cli(ctx: click.Context, verbose: bool) -> None:
    """PJContext — Capture and restore AI coding context."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose


# Lazy-load commands to keep --help/--version fast


@cli.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialize .pjctx/ in the current repo."""
    from pjctx.commands.init import run_init
    run_init(ctx.obj)


@cli.command()
@click.argument("message", required=False)
@click.option("--auto", "auto_mode", is_flag=True, help="Auto-detect from git, no prompts.")
@click.option("--tag", "-t", multiple=True, help="Add tags.")
@click.pass_context
def save(ctx: click.Context, message: str | None, auto_mode: bool, tag: tuple[str, ...]) -> None:
    """Save current context. Interactive if no message given."""
    from pjctx.commands.save import run_save
    run_save(ctx.obj, message=message, auto_mode=auto_mode, tags=list(tag))


@cli.command()
@click.option("--format", "-f", "fmt", default="default",
              type=click.Choice(["default", "xml", "compact"]),
              help="Prompt format.")
@click.option("--no-copy", is_flag=True, help="Print to stdout instead of clipboard.")
@click.option("--branch", "-b", default=None, help="Resume from a specific branch.")
@click.pass_context
def resume(ctx: click.Context, fmt: str, no_copy: bool, branch: str | None) -> None:
    """Generate a resume prompt from the latest context."""
    from pjctx.commands.resume import run_resume
    run_resume(ctx.obj, fmt=fmt, no_copy=no_copy, branch=branch)


@cli.command()
@click.option("--branch", "-b", default=None, help="Show log for a specific branch.")
@click.option("--limit", "-n", default=10, help="Max entries to show.")
@click.option("--all", "all_branches", is_flag=True, help="Show logs across all branches.")
@click.pass_context
def log(ctx: click.Context, branch: str | None, limit: int, all_branches: bool) -> None:
    """Show context history."""
    from pjctx.commands.log import run_log
    run_log(ctx.obj, branch=branch, limit=limit, all_branches=all_branches)


@cli.command()
@click.option("--stat/--full", default=True, help="Show stat summary or full diff.")
@click.pass_context
def diff(ctx: click.Context, stat: bool) -> None:
    """Show changes since last context save."""
    from pjctx.commands.diff import run_diff
    run_diff(ctx.obj, stat_only=stat)


@cli.command()
@click.argument("user", required=False)
@click.pass_context
def handoff(ctx: click.Context, user: str | None) -> None:
    """Create a handoff context for another user."""
    from pjctx.commands.handoff import run_handoff
    run_handoff(ctx.obj, user=user)


@cli.command()
@click.pass_context
def share(ctx: click.Context) -> None:
    """Share .pjctx/ by committing it to git."""
    from pjctx.commands.share import run_share
    run_share(ctx.obj)


@cli.command()
@click.option("--interval", "-i", default=300, help="Auto-save interval in seconds.")
@click.pass_context
def watch(ctx: click.Context, interval: int) -> None:
    """Watch for file changes and auto-save context."""
    from pjctx.commands.watch import run_watch
    run_watch(ctx.obj, interval=interval)


@cli.group()
def hook() -> None:
    """Manage git hooks for auto-save."""
    pass


@hook.command("install")
@click.pass_context
def hook_install(ctx: click.Context) -> None:
    """Install post-commit hook."""
    from pjctx.commands.hook import run_install
    run_install(ctx.obj)


@hook.command("uninstall")
@click.pass_context
def hook_uninstall(ctx: click.Context) -> None:
    """Uninstall post-commit hook."""
    from pjctx.commands.hook import run_uninstall
    run_uninstall(ctx.obj)


@hook.command("status")
@click.pass_context
def hook_status(ctx: click.Context) -> None:
    """Check hook installation status."""
    from pjctx.commands.hook import run_status
    run_status(ctx.obj)
