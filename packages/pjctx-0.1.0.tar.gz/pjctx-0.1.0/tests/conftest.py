"""Shared fixtures — temporary git repos for testing."""

import os
import pytest
from pathlib import Path
from git import Repo


@pytest.fixture
def tmp_git_repo(tmp_path):
    """Create a temporary git repo with an initial commit."""
    repo = Repo.init(tmp_path)
    repo.config_writer().set_value("user", "name", "Test").release()
    repo.config_writer().set_value("user", "email", "test@test.com").release()

    # Create an initial commit
    readme = tmp_path / "README.md"
    readme.write_text("# Test\n")
    repo.index.add(["README.md"])
    repo.index.commit("Initial commit")

    # Change cwd to the repo
    original = os.getcwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original)


@pytest.fixture
def initialized_repo(tmp_git_repo):
    """A tmp git repo with .pjctx/ already initialized."""
    from pjctx.core.config import save_config, DEFAULT_CONFIG, get_pjctx_dir

    pjctx_dir = get_pjctx_dir(tmp_git_repo)
    (pjctx_dir / "contexts").mkdir(parents=True)
    (pjctx_dir / "hooks").mkdir(parents=True)
    save_config(tmp_git_repo, DEFAULT_CONFIG)

    return tmp_git_repo
