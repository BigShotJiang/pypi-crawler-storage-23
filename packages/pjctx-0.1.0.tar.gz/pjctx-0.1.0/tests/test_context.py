"""Tests for core/context.py."""

from pjctx.core.context import Context


def test_context_default_fields():
    ctx = Context()
    assert ctx.message == ""
    assert ctx.branch == ""
    assert ctx.files_changed == []
    assert ctx.id  # UUID should be auto-generated
    assert ctx.timestamp  # Should be auto-generated


def test_context_to_dict():
    ctx = Context(message="test", branch="main", tags=["a", "b"])
    d = ctx.to_dict()
    assert d["message"] == "test"
    assert d["branch"] == "main"
    assert d["tags"] == ["a", "b"]
    assert "id" in d
    assert "timestamp" in d


def test_context_from_dict():
    data = {
        "id": "abc-123",
        "timestamp": "2024-01-15T10:30:00+00:00",
        "message": "test context",
        "branch": "feature/foo",
        "task": "build feature",
        "decisions": ["use X"],
        "files_changed": ["a.py"],
    }
    ctx = Context.from_dict(data)
    assert ctx.id == "abc-123"
    assert ctx.message == "test context"
    assert ctx.branch == "feature/foo"
    assert ctx.task == "build feature"
    assert ctx.decisions == ["use X"]


def test_context_from_dict_ignores_unknown():
    data = {"message": "test", "unknown_field": "ignored"}
    ctx = Context.from_dict(data)
    assert ctx.message == "test"
    assert not hasattr(ctx, "unknown_field")


def test_context_roundtrip():
    ctx = Context(
        message="roundtrip test",
        task="testing",
        approaches_tried=["a1", "a2"],
        current_approach="a2",
        decisions=["d1"],
        next_steps=["s1"],
        files_changed=["f.py"],
        git_diff_summary="1 file changed",
        tags=["test"],
    )
    d = ctx.to_dict()
    ctx2 = Context.from_dict(d)
    assert ctx2.message == ctx.message
    assert ctx2.task == ctx.task
    assert ctx2.approaches_tried == ctx.approaches_tried
    assert ctx2.tags == ctx.tags


def test_filename_safe():
    ctx = Context()
    name = ctx.filename()
    assert ":" not in name
    assert name.endswith(".json")
