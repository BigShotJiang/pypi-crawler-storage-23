"""Tests for prompt.py."""

from pjctx.core.context import Context
from pjctx.prompt import build_prompt


def _sample_context():
    return Context(
        message="Refactoring payment service",
        task="Convert to event sourcing",
        branch="feature/payments",
        approaches_tried=["Direct DB", "CQRS"],
        current_approach="Event sourcing with snapshots",
        decisions=["Use event store", "Keep read models"],
        next_steps=["Implement projections", "Add tests"],
        files_changed=["src/payment.py", "src/events.py"],
        git_diff_summary="2 files changed, 100 insertions(+)",
        tags=["refactor", "payments"],
    )


def test_default_format():
    ctx = _sample_context()
    result = build_prompt(ctx, "default")
    assert "# Project Context Resume" in result
    assert "feature/payments" in result
    assert "Refactoring payment service" in result
    assert "Event sourcing with snapshots" in result
    assert "Continue from this context" in result


def test_default_omits_empty():
    ctx = Context(message="minimal", branch="main")
    result = build_prompt(ctx, "default")
    assert "Approaches Tried" not in result
    assert "Decisions" not in result
    assert "Handoff" not in result


def test_xml_format():
    ctx = _sample_context()
    result = build_prompt(ctx, "xml")
    assert "<context>" in result
    assert "</context>" in result
    assert "<branch>feature/payments</branch>" in result
    assert "<task>Convert to event sourcing</task>" in result
    assert "<directive>" in result


def test_compact_format():
    ctx = _sample_context()
    result = build_prompt(ctx, "compact")
    # Should be a single block with no markdown headers
    assert "# " not in result
    assert "Branch: feature/payments." in result
    assert "Continue from this context." in result


def test_xml_escapes_special_chars():
    ctx = Context(message="Use <tags> & \"quotes\"", branch="main")
    result = build_prompt(ctx, "xml")
    assert "&lt;tags&gt;" in result
    assert "&amp;" in result
    assert "&quot;" in result


def test_handoff_in_prompt():
    ctx = Context(
        message="handoff",
        branch="main",
        handoff_to="alice",
        handoff_note="Please review the PR",
    )
    result = build_prompt(ctx, "default")
    assert "Handoff" in result
    assert "alice" in result
    assert "Please review the PR" in result
