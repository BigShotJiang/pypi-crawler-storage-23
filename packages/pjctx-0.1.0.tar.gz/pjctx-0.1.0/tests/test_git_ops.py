"""Tests for core/git_ops.py."""

from pjctx.core.git_ops import (
    get_current_branch,
    get_files_changed,
    get_diff_summary,
    get_recent_commits,
)


def test_get_current_branch(tmp_git_repo):
    branch = get_current_branch(tmp_git_repo)
    # Default branch could be main or master
    assert branch in ("main", "master")


def test_get_files_changed_untracked(tmp_git_repo):
    (tmp_git_repo / "new_file.txt").write_text("hello")
    files = get_files_changed(tmp_git_repo)
    assert "new_file.txt" in files


def test_get_files_changed_modified(tmp_git_repo):
    readme = tmp_git_repo / "README.md"
    readme.write_text("# Modified\n")
    files = get_files_changed(tmp_git_repo)
    assert "README.md" in files


def test_get_diff_summary(tmp_git_repo):
    readme = tmp_git_repo / "README.md"
    readme.write_text("# Changed content\nNew line\n")
    summary = get_diff_summary(tmp_git_repo)
    # May be empty if not staged, but should not error
    assert isinstance(summary, str)


def test_get_recent_commits(tmp_git_repo):
    commits = get_recent_commits(tmp_git_repo)
    assert len(commits) >= 1
    assert "Initial commit" in commits[0]
