"""
NOTE:
- This file is currently more of an integration script than a unit test.
- When executed as `python tests/test_dataverse_handler.py`, Python's import path
  starts in `tests/`, which can cause the *installed* `OTCFinUtils` package to be
  imported instead of the local source tree. That can lead to confusing runtime
  errors (e.g. missing methods).
"""

# TODO - write basic tests

# from pathlib import Path
# import sys
# from os import getenv

# # Ensure local repo sources are imported (repo_root/OTCFinUtils/...)
# REPO_ROOT = Path(__file__).resolve().parents[1]
# sys.path.insert(0, str(REPO_ROOT))

# from dotenv import load_dotenv
# from OTCFinUtils.dataverse_handler import DVHandler

# load_dotenv()

# dataverse =


# dvh = DVHandler(dataverse)
