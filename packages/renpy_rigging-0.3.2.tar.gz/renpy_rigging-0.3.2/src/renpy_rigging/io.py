"""
JSON load/save helpers for rigs, poses, and animations.

Provides unified file I/O for all rigging data formats.
Works both in standalone Python and within Ren'Py.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .rig import Rig
    from .pose import PoseLibrary
    from .animation import AnimationLibrary
    from .overlay import OverlayLibrary
    from .attachment import AttachmentLibrary
    from .scene import Scene


def _resolve_path(path: str, base_path: str = "") -> str:
    """
    Resolve a path, optionally relative to a base path.

    In Ren'Py context, paths are relative to the game directory.
    In standalone context, paths are filesystem paths.
    """
    path = os.path.normpath(path)
    if os.path.isabs(path):
        return path
    if base_path:
        base_path = os.path.normpath(base_path)
        return os.path.join(base_path, path)
    return path


def load_json(path: str, base_path: str = "") -> Dict[str, Any]:
    """
    Load a JSON file and return its contents as a dictionary.

    Args:
        path: Path to the JSON file
        base_path: Optional base directory for relative paths

    Returns:
        Parsed JSON data as a dictionary
    """
    full_path = _resolve_path(path, base_path)

    # Try to use Ren'Py's file system first
    try:
        import renpy
        data = renpy.file(full_path).read()
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        return json.loads(data)
    except (ImportError, Exception):
        pass

    # Fall back to standard file I/O
    with open(full_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(data: Dict[str, Any], path: str, base_path: str = "", indent: int = 2) -> None:
    """
    Save a dictionary to a JSON file.

    Args:
        data: Dictionary to save
        path: Path to the JSON file
        base_path: Optional base directory for relative paths
        indent: JSON indentation level (default 2)
    """
    full_path = _resolve_path(path, base_path)

    # Ensure directory exists
    dir_path = os.path.dirname(full_path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path)

    with open(full_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=indent, ensure_ascii=False)


def load_rig(path: str, base_path: str = "") -> "Rig":
    """
    Load a rig from a JSON file.

    Args:
        path: Path to the rig.json file
        base_path: Optional base directory for relative paths

    Returns:
        A Rig instance
    """
    from .rig import Rig

    full_path = _resolve_path(path, base_path)
    rig_dir = os.path.dirname(full_path)
    rig_name = os.path.basename(rig_dir) if rig_dir else "unnamed"

    data = load_json(path, base_path)
    return Rig.from_dict(data, name=rig_name, base_path=rig_dir)


def save_rig(rig: "Rig", path: str, base_path: str = "") -> None:
    """
    Save a rig to a JSON file.

    Args:
        rig: The Rig to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(rig.to_dict(), path, base_path)


def load_poses(path: str, base_path: str = "") -> "PoseLibrary":
    """
    Load poses from a JSON file.

    Args:
        path: Path to the poses.json file
        base_path: Optional base directory for relative paths

    Returns:
        A PoseLibrary instance
    """
    from .pose import PoseLibrary

    data = load_json(path, base_path)
    return PoseLibrary.from_dict(data)


def save_poses(poses: "PoseLibrary", path: str, base_path: str = "") -> None:
    """
    Save poses to a JSON file.

    Args:
        poses: The PoseLibrary to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(poses.to_dict(), path, base_path)


def load_animations(path: str, base_path: str = "") -> "AnimationLibrary":
    """
    Load animations from a JSON file.

    Args:
        path: Path to the animations.json file
        base_path: Optional base directory for relative paths

    Returns:
        An AnimationLibrary instance
    """
    from .animation import AnimationLibrary

    data = load_json(path, base_path)
    return AnimationLibrary.from_dict(data)


def save_animations(animations: "AnimationLibrary", path: str, base_path: str = "") -> None:
    """
    Save animations to a JSON file.

    Args:
        animations: The AnimationLibrary to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(animations.to_dict(), path, base_path)


def load_overlays(path: str, base_path: str = "") -> "OverlayLibrary":
    """
    Load overlays from a JSON file.

    Args:
        path: Path to the overlays.json file
        base_path: Optional base directory for relative paths

    Returns:
        An OverlayLibrary instance
    """
    from .overlay import OverlayLibrary

    data = load_json(path, base_path)
    return OverlayLibrary.from_dict(data)


def save_overlays(overlays: "OverlayLibrary", path: str, base_path: str = "") -> None:
    """
    Save overlays to a JSON file.

    Args:
        overlays: The OverlayLibrary to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(overlays.to_dict(), path, base_path)


def load_attachments(path: str, base_path: str = "") -> "AttachmentLibrary":
    """
    Load attachment bindings from a JSON file.

    Args:
        path: Path to the attachments.json file
        base_path: Optional base directory for relative paths

    Returns:
        An AttachmentLibrary instance
    """
    from .attachment import AttachmentLibrary

    data = load_json(path, base_path)
    return AttachmentLibrary.from_dict(data)


def save_attachments(attachments: "AttachmentLibrary", path: str, base_path: str = "") -> None:
    """
    Save attachment bindings to a JSON file.

    Args:
        attachments: The AttachmentLibrary to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(attachments.to_dict(), path, base_path)


def list_attachments(attachments_dir: str, base_path: str = "") -> list:
    """
    List available attachment rigs in a directory.

    Scans the given directory for subdirectories containing rig.json files
    with an "attachment" section.

    Args:
        attachments_dir: Path to the attachments directory (e.g., "attachments/")
        base_path: Optional base directory for relative paths

    Returns:
        List of dicts with 'name' and 'path' keys
    """
    full_path = _resolve_path(attachments_dir, base_path)
    attachments = []

    try:
        if os.path.exists(full_path) and os.path.isdir(full_path):
            for name in os.listdir(full_path):
                attach_path = os.path.join(full_path, name)
                if os.path.isdir(attach_path):
                    # Check if it has a rig.json
                    rig_file = os.path.join(attach_path, "rig.json")
                    if os.path.exists(rig_file):
                        # Optionally verify it has attachment config
                        try:
                            data = load_json(rig_file)
                            if "attachment" in data:
                                attachments.append({
                                    "name": name,
                                    "path": os.path.join(attachments_dir, name)
                                })
                        except Exception:
                            # If we can't read the rig, skip it
                            pass
    except Exception:
        pass

    return attachments


class RigAssets:
    """
    A convenience class for loading all assets for a character.

    Usage:
        assets = RigAssets.load("characters/vince")
        # Now access assets.rig, assets.poses, assets.animations, assets.overlays, assets.attachment_bindings
    """

    def __init__(
        self,
        rig: "Rig",
        poses: Optional["PoseLibrary"] = None,
        animations: Optional["AnimationLibrary"] = None,
        overlays: Optional["OverlayLibrary"] = None,
        attachment_bindings: Optional["AttachmentLibrary"] = None
    ):
        self.rig = rig
        self.poses = poses
        self.animations = animations
        self.overlays = overlays
        self.attachment_bindings = attachment_bindings

    @classmethod
    def load(cls, directory: str, base_path: str = "") -> "RigAssets":
        """
        Load all rig assets from a directory.

        Expects the directory to contain:
        - rig.json (required)
        - poses.json (optional)
        - animations.json (optional)
        - overlays.json (optional)
        - attachments.json (optional)

        Args:
            directory: Path to the character directory
            base_path: Optional base directory for relative paths

        Returns:
            A RigAssets instance with all loaded data
        """
        from .pose import PoseLibrary
        from .animation import AnimationLibrary
        from .overlay import OverlayLibrary
        from .attachment import AttachmentLibrary

        # Load required rig
        rig_path = os.path.join(directory, "rig.json")
        rig = load_rig(rig_path, base_path)

        # Load optional poses
        poses = None
        poses_path = os.path.join(directory, "poses.json")
        try:
            poses = load_poses(poses_path, base_path)
        except (FileNotFoundError, IOError):
            poses = PoseLibrary()

        # Load optional animations
        animations = None
        anims_path = os.path.join(directory, "animations.json")
        try:
            animations = load_animations(anims_path, base_path)
        except (FileNotFoundError, IOError):
            animations = AnimationLibrary()

        # Load optional overlays
        overlays = None
        overlays_path = os.path.join(directory, "overlays.json")
        try:
            overlays = load_overlays(overlays_path, base_path)
        except (FileNotFoundError, IOError):
            overlays = OverlayLibrary()

        # Load optional attachment bindings
        attachment_bindings = None
        attachments_path = os.path.join(directory, "attachments.json")
        try:
            attachment_bindings = load_attachments(attachments_path, base_path)
        except (FileNotFoundError, IOError):
            attachment_bindings = AttachmentLibrary()

        return cls(rig, poses, animations, overlays, attachment_bindings)

    def save(self, directory: str, base_path: str = "") -> None:
        """
        Save all rig assets to a directory.

        Args:
            directory: Path to the character directory
            base_path: Optional base directory for relative paths
        """
        save_rig(self.rig, os.path.join(directory, "rig.json"), base_path)

        if self.poses:
            save_poses(self.poses, os.path.join(directory, "poses.json"), base_path)

        if self.animations:
            save_animations(self.animations, os.path.join(directory, "animations.json"), base_path)

        if self.overlays:
            save_overlays(self.overlays, os.path.join(directory, "overlays.json"), base_path)

        if self.attachment_bindings:
            save_attachments(self.attachment_bindings, os.path.join(directory, "attachments.json"), base_path)


def load_scene(path: str, base_path: str = "") -> "Scene":
    """
    Load a scene from a scene.json file.

    Args:
        path: Path to the scene.json file
        base_path: Optional base directory for relative paths

    Returns:
        A Scene instance
    """
    from .scene import Scene

    full_path = _resolve_path(path, base_path)
    scene_dir = os.path.dirname(full_path)
    scene_name = os.path.basename(scene_dir) if scene_dir else "unnamed"

    data = load_json(path, base_path)
    return Scene.from_dict(data, name=scene_name, base_path=scene_dir)


def save_scene(scene: "Scene", path: str, base_path: str = "") -> None:
    """
    Save a scene to a JSON file.

    Args:
        scene: The Scene to save
        path: Path to the output file
        base_path: Optional base directory for relative paths
    """
    save_json(scene.to_dict(), path, base_path)


def list_scenes(scenes_dir: str, base_path: str = "") -> list:
    """
    List available scenes in a directory.

    Scans the given directory for subdirectories containing scene.json files.

    Args:
        scenes_dir: Path to the scenes directory
        base_path: Optional base directory for relative paths

    Returns:
        List of dicts with 'name' and 'path' keys
    """
    full_path = _resolve_path(scenes_dir, base_path)
    scenes = []

    try:
        if os.path.exists(full_path) and os.path.isdir(full_path):
            for name in sorted(os.listdir(full_path)):
                scene_path = os.path.join(full_path, name)
                if os.path.isdir(scene_path):
                    scene_file = os.path.join(scene_path, "scene.json")
                    if os.path.exists(scene_file):
                        scenes.append({
                            "name": name,
                            "path": os.path.join(scenes_dir, name)
                        })
    except Exception:
        pass

    return scenes
