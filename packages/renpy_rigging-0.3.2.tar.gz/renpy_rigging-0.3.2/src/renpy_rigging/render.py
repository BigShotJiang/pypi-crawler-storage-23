"""
Ren'Py displayable builders.

Creates Ren'Py-native displayables from rigs, poses, and animations.
Uses Transform and Fixed to compose parts into a character.
"""

from __future__ import annotations

import math
import os
import struct
import zlib
from functools import lru_cache
from typing import TYPE_CHECKING, Dict, List, Optional, Callable, Tuple

from .math2d import Vec2, Transform2D
from .rig import Rig, Part
from .pose import Pose, PoseLibrary, apply_pose, flip_posed_rig
from .animation import Animation, AnimationLibrary, AnimationPlayer
from .overlay import Overlay, OverlayLibrary, OverlayPart
from .attachment import (
    AttachmentConfig, AttachmentPoseState, AttachmentBinding,
    AttachmentLibrary, AttachmentInstance,
    compute_attachment_transform, get_attachment_part_world_transform
)
from .scene import Scene, SceneBackground, SceneLayer, SceneItem, SceneCharacter, SceneAttachment
from .audio import (
    CHANNEL_POSE, CHANNEL_SCENE, CHANNEL_SFX_PREFIX, SFX_CHANNEL_COUNT,
    play_sound, stop_channel,
)

# Ren'Py imports - these only work inside Ren'Py
try:
    import renpy.exports as renpy
    from renpy.display.transform import Transform
    from renpy.display.layout import Fixed
    from renpy.display.im import Image
    from renpy.display.render import render as _renpy_render
    RENPY_AVAILABLE = True
except ImportError:
    RENPY_AVAILABLE = False
    renpy = None
    Transform = None
    Fixed = None
    Image = None
    _renpy_render = None


def _check_renpy():
    """Raise error if Ren'Py is not available."""
    if not RENPY_AVAILABLE:
        raise RuntimeError(
            "Ren'Py is not available. The render module can only be used "
            "inside a Ren'Py game."
        )


def _get_png_dimensions(filepath: str) -> Optional[Tuple[int, int]]:
    """Read width and height from a PNG file's IHDR chunk."""
    try:
        with open(filepath, 'rb') as f:
            header = f.read(24)
        if len(header) < 24 or header[:8] != b'\x89PNG\r\n\x1a\n':
            return None
        w, h = struct.unpack('>II', header[16:24])
        return (w, h)
    except (IOError, OSError):
        return None


def _paeth_predictor(a: int, b: int, c: int) -> int:
    """PNG Paeth filter predictor."""
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _unfilter_scanlines(
    raw: bytes, width: int, height: int, bpp: int
) -> list:
    """
    Reverse PNG per-row filtering and return a list of unfiltered row
    bytearrays.

    Supports filter types 0-4 (None, Sub, Up, Average, Paeth).
    Only handles non-interlaced images.
    """
    stride = width * bpp          # bytes per pixel-row (no filter byte)
    rows: list = []
    prev = bytearray(stride)     # "previous row" starts as all zeros
    pos = 0

    for _ in range(height):
        ftype = raw[pos]
        pos += 1
        cur = bytearray(raw[pos:pos + stride])
        pos += stride

        if ftype == 1:            # Sub
            for i in range(bpp, stride):
                cur[i] = (cur[i] + cur[i - bpp]) & 0xFF
        elif ftype == 2:          # Up
            for i in range(stride):
                cur[i] = (cur[i] + prev[i]) & 0xFF
        elif ftype == 3:          # Average
            for i in range(stride):
                a = cur[i - bpp] if i >= bpp else 0
                cur[i] = (cur[i] + (a + prev[i]) // 2) & 0xFF
        elif ftype == 4:          # Paeth
            for i in range(stride):
                a = cur[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                cur[i] = (cur[i] + _paeth_predictor(a, b, c)) & 0xFF
        # ftype 0 (None) → cur is already correct

        rows.append(cur)
        prev = cur

    return rows


@lru_cache(maxsize=512)
def _get_png_opaque_bbox(filepath: str) -> Optional[Tuple[int, int, int, int]]:
    """
    Return the tight bounding box of non-transparent pixels in a PNG.

    Pure-Python implementation using only ``struct`` and ``zlib`` (stdlib).
    Results are cached because part images don't change at runtime.

    Handles RGBA (color type 6) and Grey+Alpha (color type 4) at 8-bit
    depth.  Images without an alpha channel (types 0, 2, 3) are treated
    as fully opaque.  Interlaced images or unsupported bit depths fall
    back to the full image rectangle.

    Returns:
        (left, top, right, bottom) of opaque content, or ``None`` if the
        image is fully transparent.
    """
    try:
        with open(filepath, 'rb') as f:
            data = f.read()
    except (IOError, OSError):
        return None

    # ── PNG signature ────────────────────────────────────────────
    if len(data) < 29 or data[:8] != b'\x89PNG\r\n\x1a\n':
        return None

    # ── IHDR (must be the first chunk) ───────────────────────────
    ihdr_len = struct.unpack('>I', data[8:12])[0]
    if data[12:16] != b'IHDR' or ihdr_len != 13:
        return None
    ihdr = data[16:29]
    width, height = struct.unpack('>II', ihdr[0:8])
    bit_depth  = ihdr[8]
    color_type = ihdr[9]
    interlace  = ihdr[12]

    # Interlaced PNGs have a different raw-data layout – bail out
    # to the safe "full image" fallback.
    if interlace != 0:
        return (0, 0, width, height)

    # Determine bytes-per-pixel and the offset of the alpha byte
    # within each pixel.
    if color_type == 6 and bit_depth == 8:      # RGBA
        bpp = 4
        alpha_off = 3
    elif color_type == 4 and bit_depth == 8:    # Grey + Alpha
        bpp = 2
        alpha_off = 1
    elif color_type in (0, 2, 3):               # No alpha channel
        return (0, 0, width, height)
    else:
        # 16-bit or unusual combos – fall back to full rect
        return (0, 0, width, height)

    # ── Collect IDAT chunks ──────────────────────────────────────
    idat_parts: list = []
    pos = 8
    while pos + 8 <= len(data):
        clen = struct.unpack('>I', data[pos:pos + 4])[0]
        ctype = data[pos + 4:pos + 8]
        cdata = data[pos + 8:pos + 8 + clen]
        pos += 12 + clen                        # len + type + data + crc
        if ctype == b'IDAT':
            idat_parts.append(cdata)
        elif ctype == b'IEND':
            break
    if not idat_parts:
        return None

    # ── Decompress & unfilter ────────────────────────────────────
    try:
        raw = zlib.decompress(b''.join(idat_parts))
    except zlib.error:
        return None

    rows = _unfilter_scanlines(raw, width, height, bpp)

    # ── Scan alpha channel for opaque-pixel bounds ───────────────
    top = -1
    bottom = -1
    left = width
    right = -1

    for y, row in enumerate(rows):
        for x in range(width):
            if row[x * bpp + alpha_off] > 0:
                if top < 0:
                    top = y
                bottom = y
                if x < left:
                    left = x
                if x > right:
                    right = x

    if top < 0:
        return None                              # fully transparent

    return (left, top, right + 1, bottom + 1)


def _compute_content_bounds(
    posed_rig: Rig,
    image_base_dir: str
) -> Optional[Tuple[float, float, float, float]]:
    """
    Compute the bounding box of all visible parts' **opaque pixels**.

    For each part image, reads the alpha channel to find the tight rectangle
    of non-transparent pixels, then applies the same scale/rotation/pivot
    math as _blit_rig_item to project that rectangle into world space.

    Args:
        posed_rig: Rig with world positions already computed.
        image_base_dir: Absolute directory containing part images.

    Returns:
        (x, y, w, h) content bounding box clamped to the canvas, or None.
    """
    min_x = float('inf')
    min_y = float('inf')
    max_x = float('-inf')
    max_y = float('-inf')
    has_content = False

    for part in posed_rig.parts.values():
        if not part.visible:
            continue
        xform = posed_rig.get_part_world_transform(part.name)
        if not xform:
            continue

        img_path = os.path.join(image_base_dir, part.image)
        dims = _get_png_dimensions(img_path)
        if not dims:
            continue
        full_w, full_h = float(dims[0]), float(dims[1])

        # ── Tight opaque bounds ──────────────────────────────────
        # Use the alpha-channel bbox so transparent padding is excluded.
        # The opaque region becomes the "effective image", and the pivot
        # is shifted so the same world-space alignment is preserved.
        opaque = _get_png_opaque_bbox(img_path)
        if opaque is not None:
            ob_l, ob_t, ob_r, ob_b = opaque
            img_w = float(ob_r - ob_l)
            img_h = float(ob_b - ob_t)
            px = xform.pivot.x - ob_l
            py = xform.pivot.y - ob_t
        else:
            # Fully transparent image → nothing to show
            continue

        sx, sy = xform.scale.x, xform.scale.y
        wx, wy = xform.position.x, xform.position.y

        # Mirror pivot for negative scale (matches _blit_rig_item)
        scaled_px = (img_w - px) * abs(sx) if sx < 0 else px * sx
        scaled_py = (img_h - py) * abs(sy) if sy < 0 else py * sy

        render_w = img_w * abs(sx)
        render_h = img_h * abs(sy)

        if xform.rotation == 0:
            bx = wx - scaled_px
            by = wy - scaled_py
        else:
            rot = math.radians(xform.rotation)
            cos_a, sin_a = math.cos(rot), math.sin(rot)

            rot_w = abs(render_w * cos_a) + abs(render_h * sin_a)
            rot_h = abs(render_w * sin_a) + abs(render_h * cos_a)

            cx, cy = render_w / 2.0, render_h / 2.0
            dx = scaled_px - cx
            dy = scaled_py - cy

            new_cx, new_cy = rot_w / 2.0, rot_h / 2.0
            bx = wx - (new_cx + dx * cos_a - dy * sin_a)
            by = wy - (new_cy + dx * sin_a + dy * cos_a)
            render_w = rot_w
            render_h = rot_h

        min_x = min(min_x, bx)
        min_y = min(min_y, by)
        max_x = max(max_x, bx + render_w)
        max_y = max(max_y, by + render_h)
        has_content = True

    if has_content and max_x > min_x and max_y > min_y:
        return (min_x, min_y, max_x - min_x, max_y - min_y)
    return None


class RigDisplayable:
    """
    Creates Ren'Py displayables for a rigged character.

    This is the main interface for showing rigged characters in Ren'Py.
    It can render static poses or play animations.
    """

    def __init__(
        self,
        rig: Rig,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        attachment_library: Optional[AttachmentLibrary] = None,
        character_directory: str = "",
        base_path: str = "",
        game_directory: str = ""
    ):
        """
        Create a rig displayable renderer.

        Args:
            rig: The character rig
            poses: Optional pose library
            animations: Optional animation library
            overlays: Optional overlay library
            image_path_prefix: Prefix to add to image paths (e.g., "images/")
            attachment_library: Optional attachment library for auto-loading attachments
            character_directory: Character directory path for loading attachment assets
            base_path: Base path for resolving attachment paths
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.
        """
        _check_renpy()

        self.rig = rig
        self.poses = poses or PoseLibrary()
        self.animations = animations or AnimationLibrary()
        self.overlays = overlays or OverlayLibrary()
        self.image_path_prefix = image_path_prefix
        self.attachment_library = attachment_library or AttachmentLibrary()
        self.character_directory = character_directory
        self.base_path = base_path
        self.game_directory = game_directory

        # Runtime overlay toggles (merged with pose overlays at render time)
        self.active_overlays: list = []

        # Attachment instances (keyed by attachment name)
        self.attachment_instances: Dict[str, AttachmentInstance] = {}

        # Current animation player
        self._player: Optional[AnimationPlayer] = None

        # Track last-played pose sound to avoid re-triggering
        self._current_pose_sound: Optional[str] = None

        # On-demand outline (mutable — DynamicRig reads these each frame)
        self.outline_color = None   # (r, g, b) tuple or hex string or None
        self.outline_width = 3      # pixels
        self.outline_alpha = 1.0    # 0.0–1.0

    def add_attachment(
        self,
        name: str,
        attachment_rig: Optional[Rig] = None,
        host_joint: Optional[str] = None,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        z_offset: int = 0,
        pos_offset: Optional["Vec2"] = None,
        rot_offset: Optional[float] = None,
        scale_offset: Optional["Vec2"] = None,
        slot: str = ""
    ) -> AttachmentInstance:
        """
        Add an attachment to this character.

        If only name is provided, the attachment will be loaded from the attachment
        library (attachments.json). Otherwise, all parameters must be provided.

        Args:
            name: Unique name for this attachment instance (and key in attachments.json)
            attachment_rig: The attachment's rig (auto-loaded if None)
            host_joint: Name of the host joint to attach to (auto-loaded if None)
            poses: Optional pose library for the attachment (auto-loaded if None)
            animations: Optional animation library for the attachment (auto-loaded if None)
            z_offset: Additional z-offset for all attachment parts
            pos_offset: Position offset in host joint's local space (auto-loaded if None)
            rot_offset: Rotation offset in degrees (auto-loaded if None)
            scale_offset: Scale multiplier for the attachment (auto-loaded if None)

        Returns:
            The created AttachmentInstance
        """
        # If attachment_rig is not provided, try to load from attachment library
        if attachment_rig is None:
            binding = self.attachment_library.get(name)
            if binding is None:
                raise ValueError(
                    f"Attachment '{name}' not found in attachment library. "
                    f"Either provide attachment_rig explicitly or add '{name}' to attachments.json"
                )
            
            # Load the attachment rig
            from .io import load_rig, load_poses, load_animations
            
            # binding.path is relative to base_path (or game directory)
            attach_rig_path = os.path.join(binding.path, "rig.json")
            attachment_rig = load_rig(attach_rig_path, self.base_path)
            
            # Load attachment poses if available and not provided
            if poses is None:
                try:
                    attach_poses_path = os.path.join(binding.path, "poses.json")
                    poses = load_poses(attach_poses_path, self.base_path)
                except (FileNotFoundError, IOError):
                    pass
            
            # Load attachment animations if available and not provided
            if animations is None:
                try:
                    attach_anims_path = os.path.join(binding.path, "animations.json")
                    animations = load_animations(attach_anims_path, self.base_path)
                except (FileNotFoundError, IOError):
                    pass
            
            # Use binding values if not explicitly provided
            if host_joint is None:
                host_joint = binding.default_joint
            if pos_offset is None and (binding.pos.x != 0 or binding.pos.y != 0):
                pos_offset = binding.pos
            if rot_offset is None:
                rot_offset = binding.rot
            if z_offset == 0 and binding.z_offset != 0:
                z_offset = binding.z_offset
            if scale_offset is None and (binding.scale.x != 1 or binding.scale.y != 1):
                scale_offset = binding.scale
            if not slot and binding.slot:
                slot = binding.slot

        # Fall back to the attachment rig's own config slot
        if not slot and attachment_rig and attachment_rig.attachment_config:
            slot = attachment_rig.attachment_config.slot or ""

        # Slot-aware eviction: remove any existing attachment in the same slot
        if slot:
            for inst_name, inst in list(self.attachment_instances.items()):
                if inst.slot == slot:
                    self.remove_attachment(inst_name)

        # Validate required parameters
        if attachment_rig is None:
            raise ValueError("attachment_rig is required")
        if host_joint is None:
            raise ValueError("host_joint is required")
        if rot_offset is None:
            rot_offset = 0.0
        if scale_offset is None:
            scale_offset = Vec2.one()
        
        instance = AttachmentInstance(
            name=name,
            attachment_rig=attachment_rig,
            attachment_poses=poses,
            attachment_animations=animations,
            host_joint=host_joint,
            z_offset=z_offset,
            pos_offset=pos_offset,
            rot_offset=rot_offset,
            scale_offset=scale_offset,
            slot=slot
        )
        self.attachment_instances[name] = instance
        return instance

    def remove_attachment(self, name: str) -> bool:
        """
        Remove an attachment by name.

        Args:
            name: Name of the attachment to remove

        Returns:
            True if removed, False if not found
        """
        if name in self.attachment_instances:
            del self.attachment_instances[name]
            return True
        return False

    def get_attachment(self, name: str) -> Optional[AttachmentInstance]:
        """Get an attachment instance by name."""
        return self.attachment_instances.get(name)

    def set_attachment_pose(self, name: str, pose_name: str) -> None:
        """Set the current pose for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.current_pose = pose_name

    def set_attachment_visible(self, name: str, visible: bool) -> None:
        """Set visibility for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.visible = visible

    def set_attachment_host_joint(self, name: str, host_joint: str) -> None:
        """Change the host joint for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.host_joint = host_joint

    def add_overlay(self, name: str) -> None:
        """Add an overlay by name.

        If the overlay defines a slot, any active overlay occupying the
        same slot is removed first.
        """
        overlay = self.overlays.get(name)
        if overlay and overlay.slot:
            self.active_overlays = [
                n for n in self.active_overlays
                if not (self.overlays.get(n) and self.overlays.get(n).slot == overlay.slot)
            ]
        if name not in self.active_overlays:
            self.active_overlays.append(name)

    def remove_overlay(self, name: str) -> None:
        """Remove an overlay by name. No-op if not active."""
        if name in self.active_overlays:
            self.active_overlays.remove(name)

    def get_overlay_by_slot(self, slot: str) -> Optional[str]:
        """Return the name of the active overlay occupying *slot*, or None."""
        for name in self.active_overlays:
            overlay = self.overlays.get(name)
            if overlay and overlay.slot == slot:
                return name
        return None

    def get_attachment_by_slot(self, slot: str) -> Optional[AttachmentInstance]:
        """Return the attachment instance occupying *slot*, or None."""
        for instance in self.attachment_instances.values():
            if instance.slot == slot:
                return instance
        return None

    def _resolve_image(self, image_path: str, base_path: str = None):
        """Create an Image displayable from a relative image path.

        Args:
            image_path: Relative image path.
            base_path: Optional directory to prepend (e.g. rig.base_path).
        """
        full_path = image_path
        if base_path:
            full_path = os.path.join(base_path, image_path)
        if self.image_path_prefix:
            full_path = os.path.join(self.image_path_prefix, full_path)

        full_path = full_path.replace("\\", "/")

        gamedir = (self.game_directory or renpy.config.gamedir).replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

        return renpy.displayable(full_path)

    def _get_image(self, image_path: str):
        return self._resolve_image(image_path, base_path=self.rig.base_path)

    def _get_overlay_image(self, image_path: str):
        return self._resolve_image(image_path)

    def _get_attachment_image(self, image_path: str, attachment_rig: Rig):
        return self._resolve_image(image_path, base_path=attachment_rig.base_path)

    def _get_render_items(self, posed_rig: Rig, pose: Optional[Pose] = None,
                          flip_h: bool = False, flip_v: bool = False):
        """
        Get all items to render (parts + overlays + attachments) sorted by z-order.

        Returns list of tuples: (z_order, item_type, data)
        - item_type is 'part', 'overlay', or 'attachment'
        - data is Part for 'part', (OverlayPart, overlay_name, Part) for 'overlay',
          (Part, AttachmentInstance, Transform2D) for 'attachment'
        """
        items = []

        # Resolve active overlays with pose overrides (include/exclude/inherit)
        from .animation import resolve_frame_toggles
        pose_overlay_overrides = pose.overlays if pose else None
        all_overlays = resolve_frame_toggles(self.active_overlays, pose_overlay_overrides)

        # First, collect which parts are replaced by overlays
        replaced_parts = set()
        for overlay_name in all_overlays:
            overlay = self.overlays.get(overlay_name)
            if overlay is None:
                continue
            for part_name, overlay_part in overlay.parts.items():
                if overlay_part.replace:
                    replaced_parts.add(part_name)

        # Add all visible parts (except those that are replaced)
        for part in posed_rig.parts.values():
            if part.visible and part.name not in replaced_parts:
                items.append((part.z, 'part', part))

        # Add overlay parts
        for overlay_name in all_overlays:
            overlay = self.overlays.get(overlay_name)
            if overlay is None:
                continue

            for part_name, overlay_part in overlay.parts.items():
                base_part = posed_rig.parts.get(part_name)
                if base_part is None or not base_part.visible:
                    continue

                # Compute effective z-order
                effective_z = base_part.z + overlay_part.effective_z_delta
                items.append((effective_z, 'overlay', (overlay_part, overlay_name, base_part)))

        # Add attachment parts
        for attach_name, instance in self.attachment_instances.items():
            # Check if attachment is visible
            if not instance.visible:
                continue

            # Check for pose-specific attachment state
            attach_state = None
            if pose and pose.attachments:
                attach_state = pose.attachments.get(attach_name)
                if attach_state and not attach_state.visible:
                    continue

            # Determine host joint (pose override > instance > attachment default)
            host_joint = instance.host_joint
            if attach_state and attach_state.host_joint:
                host_joint = attach_state.host_joint

            if not host_joint or host_joint not in posed_rig.joints:
                continue

            # Get attachment rig and apply pose
            attach_rig = instance.attachment_rig
            if attach_rig is None:
                continue

            # Check for active attachment animation
            if instance._player and instance._player.is_playing:
                current_pose = instance._player.get_current_pose()
                posed_attach_rig = apply_pose(attach_rig, current_pose)
            else:
                # Determine attachment pose
                attach_pose_name = instance.current_pose
                if attach_state and attach_state.pose:
                    attach_pose_name = attach_state.pose

                # Apply attachment pose if available
                if instance.attachment_poses and attach_pose_name != "neutral":
                    attach_pose = instance.attachment_poses.get(attach_pose_name)
                    if attach_pose:
                        posed_attach_rig = apply_pose(attach_rig, attach_pose)
                    else:
                        posed_attach_rig = attach_rig.clone()
                else:
                    posed_attach_rig = attach_rig.clone()

            # Apply flip to attachment rig clone
            if flip_h or flip_v:
                flip_posed_rig(posed_attach_rig, flip_h, flip_v)
            else:
                posed_attach_rig.update_world_positions()

            # Get attachment config
            config = attach_rig.attachment_config or AttachmentConfig()

            # Compute flipped offsets for attachment
            pos_offset = instance.pos_offset
            rot_offset = instance.rot_offset
            if (flip_h or flip_v) and pos_offset is not None:
                flip_px = -pos_offset.x if flip_h else pos_offset.x
                flip_py = -pos_offset.y if flip_v else pos_offset.y
                pos_offset = Vec2(flip_px, flip_py)
            if (flip_h != flip_v) and rot_offset:
                rot_offset = -rot_offset

            # Compute root transform for attachment (with binding offsets)
            root_transform = compute_attachment_transform(
                posed_rig, host_joint, config,
                pos_offset=pos_offset,
                rot_offset=rot_offset
            )

            # Apply scale offset from the attachment binding
            if instance.scale_offset.x != 1.0 or instance.scale_offset.y != 1.0:
                root_transform = Transform2D(
                    position=root_transform.position,
                    rotation=root_transform.rotation,
                    scale=Vec2(
                        root_transform.scale.x * instance.scale_offset.x,
                        root_transform.scale.y * instance.scale_offset.y
                    ),
                    pivot=root_transform.pivot
                )

            # Calculate z-offset
            base_z_offset = config.z_offset + instance.z_offset

            # Add each attachment part to render items
            for part in posed_attach_rig.parts.values():
                if not part.visible:
                    continue

                # Compute world transform for this attachment part
                world_transform = get_attachment_part_world_transform(
                    posed_attach_rig, part.name, root_transform
                )
                if world_transform is None:
                    continue

                # Effective z includes attachment's z-offset
                effective_z = part.z + base_z_offset
                items.append((effective_z, 'attachment', (part, instance, world_transform)))

        # Sort by z-order (stable sort preserves order for equal z)
        items.sort(key=lambda x: x[0])
        return items

    def render_pose(self, pose_name: str = "neutral",
                    crop_to_content: bool = False, crop_rect=None,
                    outline_color=None, outline_width=None,
                    outline_alpha=None,
                    flip_h: bool = False, flip_v: bool = False,
                    overlay_filter=None):
        """
        Render the rig in a specific pose, including any overlays.

        Uses the same pixel-level blit rendering as DynamicRig to ensure
        identical visual output between static poses and animations.

        Args:
            pose_name: Name of the pose to render
            crop_to_content: If True, crop the render to the bounding box
                of visible content (removes transparent margins).
            crop_rect: Optional (x, y, w, h) tuple in canvas coordinates
                to crop to a specific region.  Takes priority over
                crop_to_content.
            outline_color: Optional outline color as a hex string
                (e.g. "#ff0000") or (r, g, b) tuple.  When provided,
                renders a unified outline around the entire rig
                (host + attachments).  Falls back to self.outline_color.
            outline_width: Outline width in pixels.  Falls back to
                self.outline_width (default 3).
            outline_alpha: Outline opacity 0.0–1.0.  Falls back to
                self.outline_alpha (default 1.0).
            flip_h: Mirror the pose horizontally.
            flip_v: Mirror the pose vertically.

        Returns:
            A Ren'Py Displayable
        """
        _check_renpy()

        # Fall back to renderer-level outline settings
        if outline_color is None:
            outline_color = self.outline_color
        if outline_color is not None:
            if outline_width is None:
                outline_width = self.outline_width
            if outline_alpha is None:
                outline_alpha = self.outline_alpha

        # Get the pose and apply it
        pose = self.poses.get(pose_name)
        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            posed_rig = self.rig
            posed_rig.update_world_positions()

        # Apply flip
        if flip_h or flip_v:
            flip_posed_rig(posed_rig, flip_h, flip_v)

        # Play pose sound if changed
        pose_sound = pose.sound if pose else None
        if pose_sound != self._current_pose_sound:
            self._current_pose_sound = pose_sound
            if pose_sound:
                base = self.rig.base_path or ""
                play_sound(pose_sound, CHANNEL_POSE, base_path=base)
            else:
                stop_channel(CHANNEL_POSE)

        return StaticRig(posed_rig, self, pose,
                         crop_to_content=crop_to_content, crop_rect=crop_rect,
                         outline_color=outline_color,
                         outline_width=outline_width,
                         outline_alpha=outline_alpha,
                         flip_h=flip_h, flip_v=flip_v,
                         overlay_filter=overlay_filter)

    def render_pose_direct(self, pose, flip_h=False, flip_v=False,
                           outline_color=None, outline_width=None,
                           outline_alpha=None):
        """Render a Pose object directly (bypasses pose library lookup).

        Used for multi-track compositing where the pose is computed on-the-fly.
        """
        _check_renpy()

        if outline_color is None:
            outline_color = self.outline_color
        if outline_color is not None:
            if outline_width is None:
                outline_width = self.outline_width
            if outline_alpha is None:
                outline_alpha = self.outline_alpha

        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            posed_rig = self.rig
            posed_rig.update_world_positions()

        if flip_h or flip_v:
            flip_posed_rig(posed_rig, flip_h, flip_v)

        return StaticRig(posed_rig, self, pose,
                         outline_color=outline_color,
                         outline_width=outline_width,
                         outline_alpha=outline_alpha,
                         flip_h=flip_h, flip_v=flip_v)

    def render_rig(self, rig: Rig):
        """
        Render a rig directly (used for live editing).

        Args:
            rig: The rig to render (with transforms already applied)

        Returns:
            A Ren'Py Displayable
        """
        _check_renpy()

        rig.update_world_positions()

        return StaticRig(rig, self, pose=None)

    def show_pose(self, pose_name: str = "neutral",
                  crop_to_content: bool = False, crop_rect=None,
                  outline_color=None, outline_width=None,
                  outline_alpha=None,
                  flip_h: bool = False, flip_v: bool = False,
                  overlay_filter=None) -> "Fixed":
        """
        Alias for render_pose, for API consistency.

        Args:
            pose_name: Name of the pose to show
            crop_to_content: If True, crop to visible content bounds.
            crop_rect: Optional (x, y, w, h) crop region in canvas coords.
            outline_color: Optional outline color as a hex string
                (e.g. "#ff0000") or (r, g, b) tuple.
            outline_width: Outline width in pixels (default 3 when
                outline_color is set).
            outline_alpha: Outline opacity 0.0–1.0 (default 1.0).
            flip_h: Mirror the pose horizontally.
            flip_v: Mirror the pose vertically.
            overlay_filter: When set, only render overlay items matching
                this overlay name.

        Returns:
            A Ren'Py Fixed displayable
        """
        return self.render_pose(pose_name, crop_to_content=crop_to_content,
                                crop_rect=crop_rect,
                                outline_color=outline_color,
                                outline_width=outline_width,
                                outline_alpha=outline_alpha,
                                flip_h=flip_h, flip_v=flip_v,
                                overlay_filter=overlay_filter)


def _border_offsets(width):
    """Return (dx, dy) tuples forming a filled circle of the given radius."""
    offsets = []
    for dx in range(-width, width + 1):
        for dy in range(-width, width + 1):
            if dx * dx + dy * dy <= width * width and (dx, dy) != (0, 0):
                offsets.append((dx, dy))
    return offsets


def _parse_color(color):
    """Normalise a color to an (r, g, b) tuple.

    Accepts hex strings ("#rgb", "#rrggbb") or (r, g, b) tuples.
    """
    if isinstance(color, str):
        h = color.lstrip("#")
        if len(h) == 3:
            h = h[0]*2 + h[1]*2 + h[2]*2
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    return tuple(color[:3])


def _apply_alpha(child_rv, alpha, w, h, st, at):
    """Return a new Render with *alpha* applied to *child_rv*.

    Uses a Transform wrapper so Ren'Py handles the alpha through its
    normal texture pipeline (Render.alpha alone is not reliable).
    """
    class _Wrap(renpy.Displayable):
        def __init__(self, rv, **kw):
            super().__init__(**kw)
            self._rv = rv
        def render(self, _w, _h, _st, _at):
            return self._rv
        def visit(self):
            return []

    t = Transform(_Wrap(child_rv), alpha=alpha)
    return _renpy_render(t, w, h, st, at)


def _blit_rig_item(img, transform, canvas_w, canvas_h, st, at, rv,
                   silhouette_color=None):
    """
    Render and blit a single rig part onto a render target.

    Handles scale (including negative for flip) and rotation, computing
    the correct blit position so the part's pivot aligns with its world position.

    Used by both StaticRig and DynamicRig for consistent rendering.

    When silhouette_color is set, the image RGB is replaced with the given
    color while preserving alpha, producing a solid-color silhouette.
    """
    if silhouette_color:
        r, g, b = silhouette_color
        matrix = renpy.display.matrix.Matrix([
            0, 0, 0, r / 255.0,
            0, 0, 0, g / 255.0,
            0, 0, 0, b / 255.0,
            0, 0, 0, 1,
        ])
        img = Transform(img, matrixcolor=matrix)

    rotation = transform.rotation
    pivot_x = transform.pivot.x
    pivot_y = transform.pivot.y
    scale_x = transform.scale.x
    scale_y = transform.scale.y
    world_x = transform.position.x
    world_y = transform.position.y

    base_render = renpy.render(img, canvas_w, canvas_h, st, at)
    orig_w, orig_h = base_render.get_size()

    # For negative scale (flip), the pivot needs to be mirrored
    if scale_x < 0:
        scaled_pivot_x = (orig_w - pivot_x) * abs(scale_x)
    else:
        scaled_pivot_x = pivot_x * scale_x

    if scale_y < 0:
        scaled_pivot_y = (orig_h - pivot_y) * abs(scale_y)
    else:
        scaled_pivot_y = pivot_y * scale_y

    if rotation == 0:
        if scale_x != 1 or scale_y != 1:
            part_render = renpy.render(
                Transform(img, xzoom=scale_x, yzoom=scale_y),
                canvas_w, canvas_h, st, at)
        else:
            part_render = base_render

        blit_x = world_x - scaled_pivot_x
        blit_y = world_y - scaled_pivot_y
    else:
        if scale_x != 1 or scale_y != 1:
            scaled_render = renpy.render(
                Transform(img, xzoom=scale_x, yzoom=scale_y),
                canvas_w, canvas_h, st, at)
            sw, sh = scaled_render.get_size()
        else:
            sw, sh = orig_w, orig_h

        part_render = renpy.render(
            Transform(img, xzoom=scale_x, yzoom=scale_y, rotate=rotation),
            canvas_w, canvas_h, st, at)
        rot_w, rot_h = part_render.get_size()

        # Calculate where pivot ended up after rotation
        cx, cy = sw / 2, sh / 2
        dx = scaled_pivot_x - cx
        dy = scaled_pivot_y - cy

        rad = math.radians(rotation)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)

        new_cx, new_cy = rot_w / 2, rot_h / 2
        blit_x = world_x - (new_cx + dx * cos_a - dy * sin_a)
        blit_y = world_y - (new_cy + dx * sin_a + dy * cos_a)

    rv.blit(part_render, (blit_x, blit_y))
    pw, ph = part_render.get_size()
    return (blit_x, blit_y, pw, ph)


def _render_rig_items(renderer, posed_rig, pose, canvas_w, canvas_h, st, at, rv,
                      silhouette_color=None, attachment_filter=None,
                      exclude_attachments=False, border_silhouettes=None,
                      blit_offset=None, flip_h=False, flip_v=False,
                      overlay_filter=None):
    """
    Render all rig items (parts, overlays, attachments) into a render target.

    Used by both StaticRig and DynamicRig for consistent rendering.

    Args:
        silhouette_color: When set, all items are rendered as a solid-color
            silhouette (for border/outline generation).
        attachment_filter: When set (attachment instance name), only render
            items belonging to that specific attachment.
        exclude_attachments: When True, skip all attachment items (for
            host-only silhouette passes).
        border_silhouettes: Dict mapping group name to (Render, border_width).
            Group '__host__' is for host rig parts/overlays; attachment instance
            names are for attachments.  Each group's silhouette is blitted at
            circular offsets just before the first item of that group in z-order.
        blit_offset: (ox, oy) tuple. When set, content items are blitted into
            rv at this offset (used with padded render targets for borders).

    Returns:
        Content bounding box as (x, y, w, h), or None if nothing was rendered.
    """
    render_items = renderer._get_render_items(posed_rig, pose,
                                              flip_h=flip_h, flip_v=flip_v)

    # When blit_offset is set, render items into a sub-render at canvas size,
    # then blit it into rv at the offset.  Border silhouettes are blitted
    # directly into rv (they're already in padded coordinates).
    if blit_offset:
        content_rv = renpy.Render(int(posed_rig.canvas_size.x), int(posed_rig.canvas_size.y))
    else:
        content_rv = rv

    min_x = float('inf')
    min_y = float('inf')
    max_x = float('-inf')
    max_y = float('-inf')
    has_content = False

    # Track which border groups have been started (for inline insertion)
    started_groups = set() if border_silhouettes is not None else None

    for z_order, item_type, data in render_items:
        rect = None

        # When attachment_filter is set, skip everything except matching attachments
        if attachment_filter is not None:
            if item_type != 'attachment':
                continue
            _part, instance, _wt = data
            if instance.name != attachment_filter:
                continue

        # When overlay_filter is set, skip everything except matching overlays
        if overlay_filter is not None:
            if item_type != 'overlay':
                continue
            _overlay_part, _overlay_name, _base_part = data
            if _overlay_name != overlay_filter:
                continue

        # When exclude_attachments is set, skip all attachment items
        if exclude_attachments and item_type == 'attachment':
            continue

        # Determine group for border insertion
        if border_silhouettes is not None:
            if item_type == 'attachment':
                _part, instance, _wt = data
                group = instance.name
            else:
                group = '__host__'
            # Insert border silhouette before first item of each group
            if group not in started_groups and group in border_silhouettes:
                started_groups.add(group)
                sil, bwidth = border_silhouettes[group]
                for dx, dy in _border_offsets(bwidth):
                    rv.blit(sil, (dx, dy))

        if item_type == 'part':
            part = data
            if not part.visible:
                continue
            img = renderer._get_image(part.image)
            transform = posed_rig.get_part_world_transform(part.name)
            if transform is None:
                continue
            rect = _blit_rig_item(img, transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        elif item_type == 'overlay':
            overlay_part, overlay_name, base_part = data
            if not base_part.visible:
                continue
            overlay_image_path = overlay_part.get_image_path(renderer.rig.name, overlay_name)
            img = renderer._get_overlay_image(overlay_image_path)
            transform = posed_rig.get_part_world_transform(base_part.name)
            if transform is None:
                continue
            rect = _blit_rig_item(img, transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        elif item_type == 'attachment':
            part, instance, world_transform = data
            if not part.visible:
                continue
            img = renderer._get_attachment_image(part.image, instance.attachment_rig)
            rect = _blit_rig_item(img, world_transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        if rect:
            bx, by, bw, bh = rect
            min_x = min(min_x, bx)
            min_y = min(min_y, by)
            max_x = max(max_x, bx + bw)
            max_y = max(max_y, by + bh)
            has_content = True

    # When using blit_offset, composite content_rv into rv at the offset
    if blit_offset and content_rv is not rv:
        rv.blit(content_rv, blit_offset)

    if has_content:
        min_x = max(0.0, min_x)
        min_y = max(0.0, min_y)
        max_x = min(float(canvas_w), max_x)
        max_y = min(float(canvas_h), max_y)
        if max_x > min_x and max_y > min_y:
            return (min_x, min_y, max_x - min_x, max_y - min_y)
    return None


def _render_with_borders(renderer, posed_rig, pose, canvas_w, canvas_h, st, at,
                         outline_color=None, outline_width=None, outline_alpha=None,
                         flip_h=False, flip_v=False, crop=None,
                         border_only=False, border_group=None,
                         overlay_filter=None):
    """Shared border/outline pipeline for StaticRig and DynamicRig.

    Args:
        outline_color: Already-parsed (r, g, b) tuple or None.
        crop: Optional (x, y, w, h) in canvas coords (StaticRig only).
        border_only: Render only border silhouettes (StaticRig only).
        border_group: Filter to a single border group (StaticRig only).

    Returns:
        A renpy.Render.
    """
    # Build outline silhouette
    outline_sil_info = None
    if outline_color is not None:
        outline_sil = renpy.Render(canvas_w, canvas_h)
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, outline_sil,
                          silhouette_color=outline_color,
                          flip_h=flip_h, flip_v=flip_v,
                          overlay_filter=overlay_filter)
        outline_sil_info = (outline_sil, outline_width, outline_alpha)

    # Build per-group border silhouettes
    # Skip when overlay_filter is set — we only want the overlay content,
    # not the full host/attachment border shapes behind it.
    border_sils = {}
    border = posed_rig.border
    if border and border.enabled and not overlay_filter:
        sil = renpy.Render(canvas_w, canvas_h)
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, sil,
                          silhouette_color=border.color,
                          exclude_attachments=True,
                          flip_h=flip_h, flip_v=flip_v)
        border_sils['__host__'] = (sil, border.width)

        for att_name, instance in renderer.attachment_instances.items():
            if not instance.visible or not instance.attachment_rig:
                continue
            att_border = instance.attachment_rig.border
            if att_border and att_border.enabled:
                att_sil = renpy.Render(canvas_w, canvas_h)
                _render_rig_items(renderer, posed_rig, pose,
                                  canvas_w, canvas_h, st, at, att_sil,
                                  silhouette_color=att_border.color,
                                  attachment_filter=att_name,
                                  flip_h=flip_h, flip_v=flip_v)
                border_sils[att_name] = (att_sil, att_border.width)

    # Compute padding
    outline_pad = outline_sil_info[1] if outline_sil_info else 0
    border_vis = max((bw for _sil, bw in border_sils.values()), default=0)
    visual_pad = max(outline_pad, border_vis)

    content_pad = 0
    if crop:
        content_pad = max(
            max(0, -(int(crop[0]) - visual_pad)),
            max(0, -(int(crop[1]) - visual_pad)),
            max(0, int(crop[0] + crop[2] + 1 + visual_pad) - canvas_w),
            max(0, int(crop[1] + crop[3] + 1 + visual_pad) - canvas_h),
        )

    pad = max(visual_pad, content_pad)

    if pad > 0:
        pw = canvas_w + 2 * pad
        ph = canvas_h + 2 * pad

        padded_sils = {}
        for gname, (sil, bwidth) in border_sils.items():
            shifted = renpy.Render(pw, ph)
            shifted.blit(sil, (pad, pad))
            padded_sils[gname] = (shifted, bwidth)

        inner = renpy.Render(pw, ph)

        if outline_sil_info:
            o_sil, o_width, o_alpha = outline_sil_info
            shifted_o = renpy.Render(pw, ph)
            shifted_o.blit(o_sil, (pad, pad))
            outline_rv = renpy.Render(pw, ph)
            for dx, dy in _border_offsets(o_width):
                outline_rv.blit(shifted_o, (dx, dy))
            if o_alpha is not None and o_alpha < 1.0:
                outline_rv = _apply_alpha(outline_rv, o_alpha, pw, ph, st, at)
            inner.blit(outline_rv, (0, 0))

        if border_only:
            for gname, (shifted_sil, bwidth) in padded_sils.items():
                if border_group is not None and gname != border_group:
                    continue
                for dx, dy in _border_offsets(bwidth):
                    inner.blit(shifted_sil, (dx, dy))
        else:
            _render_rig_items(
                renderer, posed_rig, pose,
                pw, ph, st, at, inner,
                border_silhouettes=padded_sils,
                blit_offset=(pad, pad),
                flip_h=flip_h, flip_v=flip_v,
                overlay_filter=overlay_filter)

        if crop:
            bx = int(crop[0]) + pad - visual_pad
            by = int(crop[1]) + pad - visual_pad
            bw = int(crop[2] + 1) + 2 * visual_pad
            bh = int(crop[3] + 1) + 2 * visual_pad
            if bw > 0 and bh > 0:
                tight = renpy.Render(bw, bh)
                tight.xclipping = True
                tight.yclipping = True
                tight.blit(inner, (-bx, -by))
                return tight

        rv = renpy.Render(canvas_w, canvas_h)
        rv.blit(inner, (-pad, -pad))
        return rv

    # No padding — render directly
    rv = renpy.Render(canvas_w, canvas_h)

    if not border_only:
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, rv,
                          flip_h=flip_h, flip_v=flip_v,
                          overlay_filter=overlay_filter)

    if crop:
        bx = int(crop[0])
        by = int(crop[1])
        bw = int(crop[2] + 1)
        bh = int(crop[3] + 1)
        if bw > 0 and bh > 0:
            tight = renpy.Render(bw, bh)
            tight.xclipping = True
            tight.yclipping = True
            tight.blit(rv, (-bx, -by))
            return tight

    return rv


class StaticRig(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that renders a rig in a static pose.

    Uses the same pixel-level blit rendering as DynamicRig to ensure
    identical visual output between static poses and animations.
    """

    def __init__(self, posed_rig, renderer, pose=None,
                 crop_to_content=False, crop_rect=None, border_only=False,
                 border_group=None, outline_color=None, outline_width=None,
                 outline_alpha=None, flip_h=False, flip_v=False,
                 overlay_filter=None, **kwargs):
        if RENPY_AVAILABLE:
            super().__init__(**kwargs)
        self._posed_rig = posed_rig
        self._renderer = renderer
        self._pose = pose
        self._crop_to_content = crop_to_content
        self._crop_rect = crop_rect  # (x, y, w, h) in canvas coordinates
        self._border_only = border_only
        self._border_group = border_group  # when set with border_only, only render this group's border
        self._flip_h = flip_h
        self._flip_v = flip_v
        # On-demand outline: normalise color to (r, g, b) tuple
        if outline_color is not None:
            outline_color = _parse_color(outline_color)
            if outline_width is None:
                outline_width = 3
            if outline_alpha is None:
                outline_alpha = 1.0
        self._outline_color = outline_color
        self._outline_width = outline_width
        self._outline_alpha = outline_alpha
        self._overlay_filter = overlay_filter

    def render(self, width, height, st, at):
        canvas_w = int(self._posed_rig.canvas_size.x)
        canvas_h = int(self._posed_rig.canvas_size.y)

        if self._crop_rect:
            crop = self._crop_rect
        elif self._crop_to_content:
            crop = _compute_content_bounds(
                self._posed_rig, self._renderer.character_directory)
        else:
            crop = None

        return _render_with_borders(
            self._renderer, self._posed_rig, self._pose,
            canvas_w, canvas_h, st, at,
            outline_color=self._outline_color,
            outline_width=self._outline_width,
            outline_alpha=self._outline_alpha,
            flip_h=self._flip_h, flip_v=self._flip_v,
            crop=crop, border_only=self._border_only,
            border_group=self._border_group,
            overlay_filter=self._overlay_filter)

    def visit(self):
        children = []
        for part in self._posed_rig.parts.values():
            img = self._renderer._get_image(part.image)
            children.append(img)
        return children

    def event(self, ev, x, y, st):
        return None


class DynamicRig(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that animates a rig over time.

    This integrates with Ren'Py's animation system to smoothly
    update the character on each frame.
    """

    def __init__(
        self,
        rig: Rig,
        poses: PoseLibrary,
        animation: Animation,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        interpolate: bool = True,
        flip_h: bool = False,
        flip_v: bool = False,
        on_complete: Optional[Callable[[], None]] = None,
        renderer: Optional[RigDisplayable] = None,
        **kwargs
    ):
        _check_renpy()

        super().__init__(**kwargs)

        self.rig = rig
        self.poses = poses
        self.animation = animation
        self.overlays = overlays or OverlayLibrary()
        self.image_path_prefix = image_path_prefix
        self.flip_h = flip_h
        self.flip_v = flip_v

        if renderer is not None:
            self._renderer = renderer
        else:
            self._renderer = RigDisplayable(rig, poses, None, overlays, image_path_prefix)

        self._player = AnimationPlayer(animation, poses, interpolate)
        self._player.start()

        if on_complete:
            self._player.on_complete(on_complete)

        self._last_pose: Optional[Pose] = None

        # Sound tracking — frame-based, not blend-based
        self._last_frame_idx: int = -1
        # Animation timeline sounds — trigger-based, not window-based
        self._sfx_cycle: int = -1          # current loop cycle
        self._triggered_sfx: set = set()   # indices of sounds already triggered this cycle

    def render(self, width, height, st, at):
        current_pose = self._player.get_current_pose()
        current_frame = self._player.get_current_frame()

        posed_rig = apply_pose(self.rig, current_pose, self.flip_h, self.flip_v)
        posed_rig.update_world_positions()

        # Apply per-frame flip
        _fh = current_frame.flip_h if current_frame else False
        _fv = current_frame.flip_v if current_frame else False
        if _fh or _fv:
            flip_posed_rig(posed_rig, _fh, _fv)

        canvas_w = int(posed_rig.canvas_size.x)
        canvas_h = int(posed_rig.canvas_size.y)

        # Apply per-frame overlay/attachment overrides with save/restore
        saved_overlays = None
        saved_visibility = {}

        if current_frame is not None:
            from .animation import resolve_frame_toggles

            if current_frame.overlays is not None:
                saved_overlays = list(self._renderer.active_overlays)
                self._renderer.active_overlays = resolve_frame_toggles(
                    self._renderer.active_overlays, current_frame.overlays)

            if current_frame.attachments is not None:
                for name, instance in self._renderer.attachment_instances.items():
                    saved_visibility[name] = instance.visible
                active_names = resolve_frame_toggles(
                    [n for n, inst in self._renderer.attachment_instances.items() if inst.visible],
                    current_frame.attachments)
                for name, instance in self._renderer.attachment_instances.items():
                    instance.visible = (name in active_names)

        # --- Pose sound playback (frame-based, not blend-based) ---
        # Trigger sound when the discrete frame index changes, not on every
        # render call.  This avoids the blend_poses fallback issue where the
        # blended pose always carries a sound even during no-sound frames.
        frame_idx, _blend = self._player.animation.get_frame_at_time(
            self._player.elapsed_ms)
        if frame_idx != self._last_frame_idx:
            self._last_frame_idx = frame_idx
            # Resolve per-frame sound override: None=inherit, ""=mute, "path"=override
            if current_frame is not None and current_frame.sound is not None:
                effective_sound = current_frame.sound
            else:
                # Inherit from the pose definition (not the blended pose)
                src_pose = self.poses.get(current_frame.pose) if current_frame else None
                effective_sound = src_pose.sound if src_pose else None

            base = self.rig.base_path or ""
            if effective_sound and effective_sound != "":
                play_sound(effective_sound, CHANNEL_POSE, base_path=base)
            elif effective_sound == "":
                # Explicit mute — stop any currently playing pose sound
                stop_channel(CHANNEL_POSE)
            # effective_sound is None — no sound for this frame, let any
            # previous short sound finish naturally

        # --- Animation timeline sounds (trigger-based) ---
        if self.animation.sounds:
            from .animation import PlayMode
            raw_elapsed = self._player.elapsed_ms
            total_dur = self.animation.total_duration_ms
            base = self.rig.base_path or ""

            # Compute position within the current loop cycle
            if self.animation.mode == PlayMode.LOOP and total_dur > 0:
                cycle = raw_elapsed // total_dur
                loop_elapsed = raw_elapsed % total_dur
            else:
                cycle = 0
                loop_elapsed = raw_elapsed

            # Reset triggers on new cycle (animation looped)
            if cycle != self._sfx_cycle:
                self._sfx_cycle = cycle
                self._triggered_sfx.clear()

            for i, asound in enumerate(self.animation.sounds):
                ch_idx = i % SFX_CHANNEL_COUNT
                ch_name = "{}{}".format(CHANNEL_SFX_PREFIX, ch_idx)

                if i not in self._triggered_sfx and loop_elapsed >= asound.start_ms:
                    # Fire this sound
                    self._triggered_sfx.add(i)
                    loop = asound.duration_ms > 0
                    play_sound(asound.path, ch_name, loop=loop, base_path=base)

                # For looping-duration sounds, stop when the window ends
                if asound.duration_ms > 0 and i in self._triggered_sfx:
                    end_ms = asound.start_ms + asound.duration_ms
                    if loop_elapsed >= end_ms:
                        stop_channel(ch_name)

        # Resolve on-demand outline (read from renderer each frame for live updates)
        o_color = self._renderer.outline_color
        if o_color is not None:
            o_color = _parse_color(o_color)

        # Combine animation-level flip with per-frame flip (XOR: two flips cancel out)
        effective_fh = self.flip_h != _fh
        effective_fv = self.flip_v != _fv

        rv = _render_with_borders(
            self._renderer, posed_rig, current_pose,
            canvas_w, canvas_h, st, at,
            outline_color=o_color,
            outline_width=self._renderer.outline_width,
            outline_alpha=self._renderer.outline_alpha,
            flip_h=effective_fh, flip_v=effective_fv)

        # Restore saved state
        if saved_overlays is not None:
            self._renderer.active_overlays = saved_overlays
        for name, was_visible in saved_visibility.items():
            inst = self._renderer.attachment_instances.get(name)
            if inst is not None:
                inst.visible = was_visible

        needs_redraw = self._player.is_playing
        if not needs_redraw:
            for inst in self._renderer.attachment_instances.values():
                if inst._player and inst._player.is_playing:
                    needs_redraw = True
                    break
        if needs_redraw:
            renpy.redraw(self, 0)

        return rv

    def visit(self):
        children = []
        for part in self.rig.parts.values():
            img = self._renderer._get_image(part.image)
            children.append(img)
        return children

    def event(self, ev, x, y, st):
        return None


class RigRenderer:
    """
    High-level API for rendering rigged characters.

    This is the primary class users should interact with.
    """

    def __init__(
        self,
        rig: Rig,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        attachment_library: Optional[AttachmentLibrary] = None,
        character_directory: str = "",
        base_path: str = "",
        game_directory: str = ""
    ):
        """
        Create a rig renderer.

        Args:
            rig: The character rig
            poses: Optional pose library
            animations: Optional animation library
            overlays: Optional overlay library
            image_path_prefix: Prefix to add to all image paths
            attachment_library: Optional attachment library for auto-loading attachments
            character_directory: Character directory path for loading attachment assets
            base_path: Base path for resolving attachment paths
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.
        """
        self.rig = rig
        self.poses = poses or PoseLibrary()
        self.animations = animations or AnimationLibrary()
        self.overlays = overlays or OverlayLibrary()
        self.image_path_prefix = image_path_prefix
        self.attachment_library = attachment_library or AttachmentLibrary()
        self.character_directory = character_directory
        self.base_path = base_path
        self.game_directory = game_directory

        self._zoom = 1.0

        self._static_renderer = RigDisplayable(
            rig, self.poses, self.animations, self.overlays, image_path_prefix,
            attachment_library, character_directory, base_path, game_directory
        )

    # -- Delegated properties (read/write passthrough to _static_renderer) --
    def _delegate(attr):
        """Create a property that delegates to _static_renderer."""
        return property(lambda self: getattr(self._static_renderer, attr),
                        lambda self, v: setattr(self._static_renderer, attr, v))

    active_overlays = _delegate('active_overlays')
    outline_color = _delegate('outline_color')
    outline_width = _delegate('outline_width')
    outline_alpha = _delegate('outline_alpha')
    del _delegate  # remove helper from class namespace

    @property
    def zoom(self) -> float:
        return self._zoom

    @zoom.setter
    def zoom(self, value: float):
        self._zoom = value

    @property
    def attachment_instances(self) -> Dict[str, AttachmentInstance]:
        return self._static_renderer.attachment_instances

    # -- Attachment management (delegates to RigDisplayable) --
    def add_attachment(self, name, attachment_rig=None, host_joint=None,
                       poses=None, animations=None, z_offset=0,
                       pos_offset=None, rot_offset=None, scale_offset=None,
                       slot=""):
        """Add an attachment. See RigDisplayable.add_attachment for full docs."""
        return self._static_renderer.add_attachment(
            name, attachment_rig, host_joint, poses, animations, z_offset,
            pos_offset, rot_offset, scale_offset, slot)

    def remove_attachment(self, name):
        return self._static_renderer.remove_attachment(name)

    def get_attachment(self, name):
        return self._static_renderer.get_attachment(name)

    def set_attachment_pose(self, name, pose_name):
        self._static_renderer.set_attachment_pose(name, pose_name)

    def set_attachment_visible(self, name, visible):
        self._static_renderer.set_attachment_visible(name, visible)

    def set_attachment_host_joint(self, name, host_joint):
        self._static_renderer.set_attachment_host_joint(name, host_joint)

    def add_overlay(self, name):
        """Add an overlay. See RigDisplayable.add_overlay for full docs."""
        self._static_renderer.add_overlay(name)

    def remove_overlay(self, name):
        """Remove an overlay. See RigDisplayable.remove_overlay for full docs."""
        self._static_renderer.remove_overlay(name)

    def get_overlay_by_slot(self, slot):
        """Get active overlay name by slot. See RigDisplayable.get_overlay_by_slot."""
        return self._static_renderer.get_overlay_by_slot(slot)

    def get_attachment_by_slot(self, slot):
        """Get attachment instance by slot. See RigDisplayable.get_attachment_by_slot."""
        return self._static_renderer.get_attachment_by_slot(slot)

    def show_pose(self, pose_name="neutral", crop_to_content=False,
                  crop_rect=None, outline_color=None, outline_width=None,
                  outline_alpha=None, flip_h=False, flip_v=False,
                  overlay_filter=None):
        """Get a displayable showing the character in a pose.

        See RigDisplayable.show_pose for full parameter docs.
        Applies self.zoom if != 1.0.
        """
        disp = self._static_renderer.show_pose(
            pose_name, crop_to_content=crop_to_content, crop_rect=crop_rect,
            outline_color=outline_color, outline_width=outline_width,
            outline_alpha=outline_alpha, flip_h=flip_h, flip_v=flip_v,
            overlay_filter=overlay_filter)
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        return disp

    def show_pose_direct(self, pose, flip_h=False, flip_v=False,
                         outline_color=None, outline_width=None,
                         outline_alpha=None):
        """Render a Pose object directly (bypasses pose library lookup).

        Used for multi-track compositing preview.
        """
        disp = self._static_renderer.render_pose_direct(
            pose, flip_h=flip_h, flip_v=flip_v,
            outline_color=outline_color, outline_width=outline_width,
            outline_alpha=outline_alpha)
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        return disp

    def get_content_bounds(
        self, pose_name: str = "neutral"
    ) -> Optional[Tuple[float, float, float, float]]:
        """
        Compute the bounding box of visible content for a pose.

        Uses the part transforms and image dimensions (read from PNG headers)
        to analytically determine where content falls on the canvas, without
        performing a full render.

        Args:
            pose_name: Name of the pose to compute bounds for.

        Returns:
            (x, y, width, height) bounding box, or None if no visible parts.
        """
        pose = self.poses.get(pose_name)
        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            self.rig.update_world_positions()
            posed_rig = self.rig

        return _compute_content_bounds(posed_rig, self.character_directory)

    def play_animation(
        self,
        animation_name: str,
        loop: bool = True,
        flip_h: bool = False,
        flip_v: bool = False,
        interpolate: bool = True,
        on_complete: Optional[Callable[[], None]] = None,
        sync_attachments: bool = True
    ):
        """
        Get a displayable that plays an animation.

        Usage in Ren'Py:
            show expression renderer.play_animation("idle", loop=True) at center

        Args:
            animation_name: Name of the animation to play
            loop: Whether to loop the animation
            interpolate: Whether to interpolate between poses
            on_complete: Callback when animation completes
            sync_attachments: When True, auto-play matching animations on
                attachments that have animation_sync=True

        Returns:
            A Ren'Py displayable
        """
        animation = self.animations.get(animation_name)
        if animation is None:
            raise ValueError(f"Animation '{animation_name}' not found")

        # Set the animation mode based on the loop parameter
        from .animation import PlayMode
        animation.mode = PlayMode.LOOP if loop else PlayMode.ONCE

        # Auto-sync attachment animations
        synced_instances = []
        if sync_attachments:
            for instance in self.attachment_instances.values():
                if not instance.animation_sync:
                    continue
                if instance.attachment_animations is None:
                    continue
                if instance.attachment_animations.get(animation_name) is None:
                    continue
                instance.play_animation(animation_name, loop=loop, interpolate=interpolate)
                synced_instances.append(instance)

        # Wrap on_complete to also stop synced attachment animations (ONCE mode)
        original_on_complete = on_complete
        if synced_instances and not loop:
            def _wrapped_on_complete():
                for inst in synced_instances:
                    inst.stop_animation()
                if original_on_complete:
                    original_on_complete()
            on_complete = _wrapped_on_complete

        disp = DynamicRig(
            rig=self.rig,
            poses=self.poses,
            animation=animation,
            overlays=self.overlays,
            image_path_prefix=self.image_path_prefix,
            interpolate=interpolate,
            flip_h=flip_h,
            flip_v=flip_v,
            on_complete=on_complete,
            renderer=self._static_renderer  # Share renderer for active_overlays sync
        )
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        return disp

    def play_attachment_animation(self, name_or_slot: str, animation_name: str,
                                  loop: bool = True, interpolate: bool = True) -> None:
        """Play an animation on a specific attachment by name or slot.

        Args:
            name_or_slot: Attachment instance name or slot name
            animation_name: Name of the animation to play
            loop: Whether to loop the animation
            interpolate: Whether to interpolate between poses
        """
        instance = self.attachment_instances.get(name_or_slot)
        if instance is None:
            instance = self.get_attachment_by_slot(name_or_slot)
        if instance is None:
            raise ValueError(f"Attachment '{name_or_slot}' not found")
        instance.play_animation(animation_name, loop=loop, interpolate=interpolate)

    def stop_attachment_animation(self, name_or_slot: str) -> None:
        """Stop animation on a specific attachment by name or slot.

        Args:
            name_or_slot: Attachment instance name or slot name
        """
        instance = self.attachment_instances.get(name_or_slot)
        if instance is None:
            instance = self.get_attachment_by_slot(name_or_slot)
        if instance is None:
            raise ValueError(f"Attachment '{name_or_slot}' not found")
        instance.stop_animation()

    @classmethod
    def from_directory(
        cls,
        directory: str,
        image_path_prefix: str = "",
        base_path: str = "",
        load_attachments: bool = True,
        game_directory: str = ""
    ) -> "RigRenderer":
        """
        Create a RigRenderer by loading all assets from a directory.

        Args:
            directory: Path to character directory containing rig.json, etc.
            image_path_prefix: Optional prefix for image paths
            base_path: Optional base path for loading files
            load_attachments: Whether to load and setup attachments from attachments.json
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.

        Returns:
            A configured RigRenderer
        """
        from .io import RigAssets, load_rig, load_poses, load_animations

        # If base_path is empty and directory is absolute, infer game directory
        # by going up from the character directory (typically game/characters/name)
        resolved_base_path = base_path
        if not base_path and os.path.isabs(directory):
            # Try to find the game directory by going up from character directory
            # Typically character is in gamedir/characters/name or similar
            parent = os.path.dirname(directory)
            parent_name = os.path.basename(parent)
            if parent_name in ('characters', 'character', 'attachments', 'attachment'):
                # Character is in characters/ subdirectory, so game dir is one level up
                resolved_base_path = os.path.dirname(parent)
            else:
                # Character is directly in game directory
                resolved_base_path = parent

        assets = RigAssets.load(directory, resolved_base_path)

        renderer = cls(
            rig=assets.rig,
            poses=assets.poses,
            animations=assets.animations,
            overlays=assets.overlays,
            image_path_prefix=image_path_prefix,
            attachment_library=assets.attachment_bindings,
            character_directory=directory,
            base_path=resolved_base_path,
            game_directory=game_directory
        )

        # Note: Attachments are no longer auto-loaded at initialization.
        # Use renderer.add_attachment("attachment-name") to load them dynamically.
        # The attachment metadata is available in renderer.attachment_library.

        return renderer


def _load_scene_rig_renderer(source, subdir, base_path, game_directory):
    """Load a RigRenderer for a scene-placed character or attachment.

    Args:
        source: Folder name (e.g. "vince").
        subdir: "characters" or "attachments".
        base_path: Scene base_path (absolute path to the scene dir).
        game_directory: Game directory for image resolution.

    Returns:
        RigRenderer or None.
    """
    # Determine the game directory from scene base_path
    # base_path is typically an absolute path like .../game/scenes/name
    # The game dir is two levels up from scenes/name
    gamedir = game_directory
    if not gamedir and base_path:
        candidate = os.path.dirname(os.path.dirname(base_path))
        if os.path.isdir(os.path.join(candidate, subdir)):
            gamedir = candidate

    if not gamedir:
        gamedir = renpy.config.gamedir

    rig_dir = os.path.join(gamedir, subdir, source)
    if not os.path.isdir(rig_dir):
        # Case-insensitive fallback: scan the subdir for a matching folder
        parent = os.path.join(gamedir, subdir)
        if os.path.isdir(parent):
            source_lower = source.lower()
            for entry in os.listdir(parent):
                if entry.lower() == source_lower and os.path.isdir(os.path.join(parent, entry)):
                    rig_dir = os.path.join(parent, entry)
                    break
            else:
                return None
        else:
            return None

    try:
        return RigRenderer.from_directory(rig_dir, game_directory=gamedir)
    except Exception as e:
        print("_load_scene_rig_renderer: failed to load {}/{}: {}".format(subdir, source, e))
        import traceback
        traceback.print_exc()
        return None


class SceneDisplayable(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that renders scene content.

    Operates in three modes:
    - Full composite: background + all layers merged
    - Background only: just the background fill/image
    - Single layer: items from one named layer (transparent background)
    """

    def __init__(self, scene, mode="full", layer_name=None, game_directory="", **kwargs):
        """
        Args:
            scene: The Scene to render
            mode: "full" (all content), "background" (bg only), or "layer" (single layer)
            layer_name: Required when mode="layer"
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.
        """
        _check_renpy()
        if RENPY_AVAILABLE:
            super().__init__(**kwargs)
        self._scene = scene
        self._mode = mode
        self._layer_name = layer_name
        self._game_directory = game_directory
        self._rig_cache = {}  # {("character"|"attachment", instance_name): RigRenderer}
        self._anim_cache = {}  # {instance_name: DynamicRig displayable}

    def _get_image(self, image_path):
        """Create an Image displayable for a path relative to scene directory."""
        full_path = image_path
        if self._scene.base_path:
            full_path = os.path.join(self._scene.base_path, image_path)
        full_path = full_path.replace("\\", "/")

        gamedir = (self._game_directory or renpy.config.gamedir).replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

        return renpy.displayable(full_path)

    def _get_rig_renderer(self, instance_name, source, is_attachment=False):
        """Get a cached RigRenderer for a placed character/attachment."""
        key = ("attachment" if is_attachment else "character", instance_name)
        if key not in self._rig_cache:
            subdir = "attachments" if is_attachment else "characters"
            self._rig_cache[key] = _load_scene_rig_renderer(
                source, subdir, self._scene.base_path, self._game_directory)
        return self._rig_cache[key]

    def _apply_entry_state(self, renderer, entry):
        """Sync renderer overlays and rig-attachments to match entry state."""
        # Sync overlays
        desired = set(entry.overlays)
        current = set(renderer.active_overlays)
        for name in current - desired:
            renderer.remove_overlay(name)
        for name in desired - current:
            if renderer.overlays.get(name):
                renderer.add_overlay(name)
        # Sync rig-attachments
        desired_att = set(entry.rig_attachments)
        current_att = set(renderer.attachment_instances.keys())
        for name in current_att - desired_att:
            renderer.remove_attachment(name)
        for name in desired_att - current_att:
            try:
                renderer.add_attachment(name)
            except (ValueError, Exception):
                pass

    def _get_entry_displayable(self, entry, renderer, st, at):
        """Return the appropriate displayable for an entry's current state."""
        if entry.animation and renderer.animations.get(entry.animation):
            cache_key = entry.name
            if cache_key not in self._anim_cache:
                self._anim_cache[cache_key] = renderer.play_animation(
                    entry.animation, loop=entry.animation_loop)
            return self._anim_cache[cache_key]
        return renderer.show_pose(entry.pose)

    def render(self, width, height, st, at):
        canvas_w = int(self._scene.canvas_size.x)
        canvas_h = int(self._scene.canvas_size.y)
        rv = renpy.Render(canvas_w, canvas_h)

        # Draw background (for "full" and "background" modes)
        if self._mode in ("full", "background"):
            bg = self._scene.background
            # Always render the background color
            color_disp = renpy.displayable(bg.color)
            color_render = renpy.render(color_disp, canvas_w, canvas_h, st, at)
            rv.blit(color_render, (0, 0))
            # Render background image on top if present
            if bg.image:
                img = self._get_image(bg.image)
                scaled = Transform(img, zoom=bg.image_scale)
                img_render = renpy.render(scaled, canvas_w, canvas_h, st, at)
                rv.blit(img_render, (bg.image_offset.x, bg.image_offset.y))

        # Draw all entries z-sorted (for "full" and "layer" modes)
        if self._mode in ("full", "layer"):
            layer_filter = self._layer_name if self._mode == "layer" else None

            # Build combined z-sorted list
            entries = []
            for eff_z, item in self._scene.get_sorted_items(layer_name=layer_filter):
                entries.append((eff_z, "item", item))
            for eff_z, ch in self._scene.get_sorted_characters(layer_name=layer_filter):
                entries.append((eff_z, "character", ch))
            for eff_z, att in self._scene.get_sorted_attachments(layer_name=layer_filter):
                entries.append((eff_z, "attachment", att))
            entries.sort(key=lambda x: x[0])

            for _z, entry_type, entry in entries:
                if entry_type == "item":
                    img = self._get_image(entry.image)
                    item_render = renpy.render(
                        Transform(img,
                                  xzoom=entry.scale.x,
                                  yzoom=entry.scale.y,
                                  rotate=entry.rotation if entry.rotation != 0 else None),
                        canvas_w, canvas_h, st, at
                    )
                    rv.blit(item_render, (entry.pos.x, entry.pos.y))
                elif entry_type in ("character", "attachment"):
                    is_att = (entry_type == "attachment")
                    renderer = self._get_rig_renderer(entry.name, entry.source, is_attachment=is_att)
                    if renderer:
                        self._apply_entry_state(renderer, entry)
                        disp = self._get_entry_displayable(entry, renderer, st, at)
                        scaled = Transform(disp, zoom=entry.scale.x)
                        rig_render = renpy.render(scaled, canvas_w, canvas_h, st, at)
                        rv.blit(rig_render, (entry.pos.x, entry.pos.y))

        return rv

    def visit(self):
        children = []
        bg = self._scene.background
        if bg.image and self._mode in ("full", "background"):
            children.append(self._get_image(bg.image))
        if self._mode in ("full", "layer"):
            for item in self._scene.items:
                if self._layer_name is None or item.layer == self._layer_name:
                    children.append(self._get_image(item.image))
        return children

    def event(self, ev, x, y, st):
        return None


class SceneRenderer:
    """High-level API wrapping SceneDisplayable for convenient scene rendering."""

    def __init__(self, scene, game_directory=""):
        _check_renpy()
        self.scene = scene
        self.game_directory = game_directory

    def show(self):
        """Full composite (all layers baked in)."""
        return SceneDisplayable(self.scene, mode="full",
                                game_directory=self.game_directory)

    def show_background(self):
        """Background image/color only."""
        return SceneDisplayable(self.scene, mode="background",
                                game_directory=self.game_directory)

    def show_layer(self, name):
        """Single layer's items (transparent background)."""
        return SceneDisplayable(self.scene, mode="layer", layer_name=name,
                                game_directory=self.game_directory)

    @classmethod
    def from_directory(cls, path, base_path="", game_directory=""):
        """Create a SceneRenderer by loading scene.json from a directory."""
        from .io import load_scene
        scene_json = os.path.join(path, "scene.json")
        scene = load_scene(scene_json, base_path)
        return cls(scene, game_directory=game_directory)


class SceneManager:
    """
    Manages scene display within Ren'Py's image system.

    Handles showing/hiding scene layers as separate Ren'Py images at
    appropriate z-orders, enabling character interleaving.
    """

    def __init__(self, scenes_dir):
        """
        Scan scenes_dir for available scenes.

        Args:
            scenes_dir: Absolute path to the scenes directory
        """
        _check_renpy()
        self._scenes_dir = scenes_dir
        self._current = None
        self._shown_tags = []

    def _get_renderer(self, scene_name):
        """Create a SceneRenderer for a scene."""
        scene_path = os.path.join(self._scenes_dir, scene_name)
        return SceneRenderer.from_directory(scene_path)

    def _apply_rig_state(self, renderer, entry):
        """Sync renderer overlays and rig-attachments to match entry state."""
        # Sync overlays
        desired = set(entry.overlays)
        current = set(renderer.active_overlays)
        for name in current - desired:
            renderer.remove_overlay(name)
        for name in desired - current:
            if renderer.overlays.get(name):
                renderer.add_overlay(name)
        # Sync rig-attachments
        desired_att = set(entry.rig_attachments)
        current_att = set(renderer.attachment_instances.keys())
        for name in current_att - desired_att:
            renderer.remove_attachment(name)
        for name in desired_att - current_att:
            try:
                renderer.add_attachment(name)
            except (ValueError, Exception):
                pass

    def show(self, scene_name, transition=None):
        """
        Show a scene with layer-separated z-ordering.

        1. Calls renpy.scene() to clear existing images
        2. Shows background as '_scene_bg' at zorder -999
        3. Shows each non-empty layer as '_scene_{layer_name}' at the layer's z value
        4. Shows placed characters and attachments as separate images
        5. Applies transition if provided
        """
        renderer = self._get_renderer(scene_name)
        scene = renderer.scene

        # Clear all existing images
        renpy.scene()

        tags = []

        # Show background — anchor at top-left so canvas coordinates
        # match across all separately-shown elements.
        bg_tag = "_scene_bg"
        bg_placed = Transform(renderer.show_background(),
                              xpos=0, ypos=0, xanchor=0, yanchor=0)
        renpy.show(bg_tag, what=bg_placed, zorder=-999)
        tags.append(bg_tag)

        # Show each layer that has items (overlay images)
        for layer_name, layer in scene.layers.items():
            layer_items = scene.get_items_for_layer(layer_name)
            if layer_items:
                layer_tag = "_scene_" + layer_name
                layer_placed = Transform(renderer.show_layer(layer_name),
                                         xpos=0, ypos=0, xanchor=0, yanchor=0)
                renpy.show(layer_tag, what=layer_placed, zorder=layer.z)
                tags.append(layer_tag)

        # Show placed characters
        for ch in scene.characters:
            layer = scene.layers.get(ch.layer)
            layer_z = layer.z if layer else 0
            eff_z = layer_z + ch.z_offset

            rig_renderer = _load_scene_rig_renderer(
                ch.source, "characters", scene.base_path, "")
            if rig_renderer:
                self._apply_rig_state(rig_renderer, ch)
                if ch.animation and ch.animation in rig_renderer.animations.animations:
                    disp = rig_renderer.play_animation(ch.animation, loop=ch.animation_loop)
                else:
                    disp = rig_renderer.show_pose(ch.pose)
                placed = Transform(disp, zoom=ch.scale.x,
                                   xpos=int(ch.pos.x), ypos=int(ch.pos.y),
                                   xanchor=0, yanchor=0)
                ch_tag = "_scene_char_" + ch.name
                renpy.show(ch_tag, what=placed, zorder=eff_z)
                tags.append(ch_tag)

        # Show placed attachments
        for att in scene.attachments:
            layer = scene.layers.get(att.layer)
            layer_z = layer.z if layer else 0
            eff_z = layer_z + att.z_offset

            rig_renderer = _load_scene_rig_renderer(
                att.source, "attachments", scene.base_path, "")
            if rig_renderer:
                self._apply_rig_state(rig_renderer, att)
                if att.animation and att.animation in rig_renderer.animations.animations:
                    disp = rig_renderer.play_animation(att.animation, loop=att.animation_loop)
                else:
                    disp = rig_renderer.show_pose(att.pose)
                placed = Transform(disp, zoom=att.scale.x,
                                   xpos=int(att.pos.x), ypos=int(att.pos.y),
                                   xanchor=0, yanchor=0)
                att_tag = "_scene_att_" + att.name
                renpy.show(att_tag, what=placed, zorder=eff_z)
                tags.append(att_tag)

        self._shown_tags = tags
        self._current = scene_name

        # Play scene ambient sound
        if scene.sound:
            play_sound(scene.sound, CHANNEL_SCENE, loop=scene.sound_loop,
                       base_path=scene.base_path)
        else:
            stop_channel(CHANNEL_SCENE)

        if transition is not None:
            renpy.with_statement(transition)

    def hide(self, transition=None):
        """Hide all scene layers."""
        for tag in self._shown_tags:
            renpy.hide(tag)
        self._shown_tags = []
        self._current = None
        stop_channel(CHANNEL_SCENE)
        if transition is not None:
            renpy.with_statement(transition)

    def get_characters(self, scene_name=None):
        """Get the list of SceneCharacter entries from a scene.

        Args:
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            List of SceneCharacter objects, or empty list.
        """
        name = scene_name or self._current
        if not name:
            return []
        renderer = self._get_renderer(name)
        return list(renderer.scene.characters)

    def get_attachments(self, scene_name=None):
        """Get the list of SceneAttachment entries from a scene.

        Args:
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            List of SceneAttachment objects, or empty list.
        """
        name = scene_name or self._current
        if not name:
            return []
        renderer = self._get_renderer(name)
        return list(renderer.scene.attachments)

    def register_images(self):
        """
        Register all scenes as flat Ren'Py images for basic 'scene' usage.

        After calling, `scene street` works (shows flat composite).
        """
        from .io import list_scenes as _list_scenes
        scenes = _list_scenes(self._scenes_dir)
        for scene_info in scenes:
            name = scene_info["name"]
            renderer = self._get_renderer(name)
            renpy.image(name, renderer.show())
