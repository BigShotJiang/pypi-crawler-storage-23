"""
Scene system for composable environments.

A scene defines an environment with a background, layered overlay items,
placed characters, and placed attachments. Scenes support side-scrolling
(canvas wider than viewport) and layer-based z-ordering so character rigs
can be interleaved between foreground and background elements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .math2d import Vec2


@dataclass
class SceneBackground:
    """Background for a scene -- a color with an optional image on top."""

    color: str = "#000000"                                          # Always stored; shown in margins
    image: Optional[str] = None                                     # Image path relative to scene dir
    image_offset: Vec2 = field(default_factory=lambda: Vec2(0, 0))  # Pixel offset for background image
    image_scale: float = 1.0                                        # Scale factor for background image

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"color": self.color}
        if self.image is not None:
            d["image"] = self.image
        if self.image_offset.x != 0 or self.image_offset.y != 0:
            d["image_offset"] = [self.image_offset.x, self.image_offset.y]
        if self.image_scale != 1.0:
            d["image_scale"] = self.image_scale
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneBackground:
        # Backward compat: old format used type+path
        if "type" in data:
            bg_type = data["type"]
            if bg_type == "image":
                return cls(color="#000000", image=data.get("path", ""))
            else:
                return cls(color=data.get("color", data.get("path", "#000000")))

        # New format
        offset = data.get("image_offset", [0, 0])
        return cls(
            color=data.get("color", "#000000"),
            image=data.get("image"),
            image_offset=Vec2(float(offset[0]), float(offset[1])),
            image_scale=float(data.get("image_scale", 1.0)),
        )


@dataclass
class SceneLayer:
    """A named layer with a z-order value."""

    name: str
    z: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {"z": self.z}

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> SceneLayer:
        return cls(name=name, z=data.get("z", 0))


@dataclass
class SceneItem:
    """An overlay image placed on a layer within a scene."""

    name: str
    image: str          # path relative to scene folder
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    rotation: float = 0.0
    z_offset: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "image": self.image,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.rotation != 0.0:
            d["rotation"] = self.rotation
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneItem:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            image=data["image"],
            layer=data.get("layer", "background"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            rotation=float(data.get("rotation", 0.0)),
            z_offset=int(data.get("z_offset", 0)),
        )


@dataclass
class SceneCharacter:
    """A character rig placed within a scene."""

    name: str           # unique instance ID (e.g., "guard", "guard_2")
    source: str         # folder name under characters/
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    z_offset: int = 0
    pose: str = "neutral"
    animation: Optional[str] = None
    animation_loop: bool = True
    overlays: List[str] = field(default_factory=list)
    rig_attachments: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "source": self.source,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.pose != "neutral":
            d["pose"] = self.pose
        if self.animation is not None:
            d["animation"] = self.animation
        if not self.animation_loop:
            d["animation_loop"] = False
        if self.overlays:
            d["overlays"] = list(self.overlays)
        if self.rig_attachments:
            d["rig_attachments"] = list(self.rig_attachments)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneCharacter:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            source=data["source"],
            layer=data.get("layer", "foreground"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            z_offset=int(data.get("z_offset", 0)),
            pose=data.get("pose", "neutral"),
            animation=data.get("animation"),
            animation_loop=data.get("animation_loop", True),
            overlays=list(data.get("overlays", [])),
            rig_attachments=list(data.get("rig_attachments", [])),
        )


@dataclass
class SceneAttachment:
    """An attachment rig placed within a scene."""

    name: str           # unique instance ID (e.g., "sword_display")
    source: str         # folder name under attachments/
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    z_offset: int = 0
    pose: str = "neutral"
    animation: Optional[str] = None
    animation_loop: bool = True
    overlays: List[str] = field(default_factory=list)
    rig_attachments: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "source": self.source,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.pose != "neutral":
            d["pose"] = self.pose
        if self.animation is not None:
            d["animation"] = self.animation
        if not self.animation_loop:
            d["animation_loop"] = False
        if self.overlays:
            d["overlays"] = list(self.overlays)
        if self.rig_attachments:
            d["rig_attachments"] = list(self.rig_attachments)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneAttachment:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            source=data["source"],
            layer=data.get("layer", "foreground"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            z_offset=int(data.get("z_offset", 0)),
            pose=data.get("pose", "neutral"),
            animation=data.get("animation"),
            animation_loop=data.get("animation_loop", True),
            overlays=list(data.get("overlays", [])),
            rig_attachments=list(data.get("rig_attachments", [])),
        )


@dataclass
class Scene:
    """
    A composable environment with a background and layered overlay items.

    Scenes define environments that character rigs can be placed in.
    Layers allow z-ordering so characters can appear between foreground
    and background elements.
    """

    name: str
    canvas_size: Vec2
    background: SceneBackground
    layers: Dict[str, SceneLayer] = field(default_factory=dict)
    items: List[SceneItem] = field(default_factory=list)
    characters: List[SceneCharacter] = field(default_factory=list)
    attachments: List[SceneAttachment] = field(default_factory=list)
    base_path: str = ""  # directory containing scene.json
    sound: Optional[str] = None  # Relative path to ambient sound file
    sound_loop: bool = True  # Whether to loop the ambient sound

    def get_layer(self, name: str) -> Optional[SceneLayer]:
        return self.layers.get(name)

    def get_items_for_layer(self, layer_name: str) -> List[SceneItem]:
        return [item for item in self.items if item.layer == layer_name]

    def get_characters_for_layer(self, layer_name: str) -> List[SceneCharacter]:
        return [ch for ch in self.characters if ch.layer == layer_name]

    def get_attachments_for_layer(self, layer_name: str) -> List[SceneAttachment]:
        return [att for att in self.attachments if att.layer == layer_name]

    def get_sorted_items(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneItem]]:
        """Get items sorted by effective z-order (layer.z + item.z_offset).

        Args:
            layer_name: If provided, only items from this layer. Otherwise all items.

        Returns:
            List of (effective_z, item) tuples sorted by effective_z.
        """
        result = []
        for item in self.items:
            if layer_name is not None and item.layer != layer_name:
                continue
            layer = self.layers.get(item.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + item.z_offset
            result.append((effective_z, item))
        result.sort(key=lambda x: x[0])
        return result

    def get_sorted_characters(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneCharacter]]:
        """Get characters sorted by effective z-order (layer.z + character.z_offset)."""
        result = []
        for ch in self.characters:
            if layer_name is not None and ch.layer != layer_name:
                continue
            layer = self.layers.get(ch.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + ch.z_offset
            result.append((effective_z, ch))
        result.sort(key=lambda x: x[0])
        return result

    def get_sorted_attachments(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneAttachment]]:
        """Get attachments sorted by effective z-order (layer.z + attachment.z_offset)."""
        result = []
        for att in self.attachments:
            if layer_name is not None and att.layer != layer_name:
                continue
            layer = self.layers.get(att.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + att.z_offset
            result.append((effective_z, att))
        result.sort(key=lambda x: x[0])
        return result

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "canvas": [self.canvas_size.x, self.canvas_size.y],
            "background": self.background.to_dict(),
            "layers": {
                name: layer.to_dict()
                for name, layer in self.layers.items()
            },
            "items": [item.to_dict() for item in self.items],
        }
        if self.characters:
            d["characters"] = [ch.to_dict() for ch in self.characters]
        if self.attachments:
            d["attachments"] = [att.to_dict() for att in self.attachments]
        if self.sound is not None:
            d["sound"] = self.sound
        if not self.sound_loop:
            d["sound_loop"] = False
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any], name: str = "", base_path: str = "") -> Scene:
        canvas = data.get("canvas", [1920, 1080])
        canvas_size = Vec2(float(canvas[0]), float(canvas[1]))

        bg_data = data.get("background", {"type": "color", "color": "#000000"})
        background = SceneBackground.from_dict(bg_data)

        layers: Dict[str, SceneLayer] = {}
        for layer_name, layer_data in data.get("layers", {}).items():
            layers[layer_name] = SceneLayer.from_dict(layer_name, layer_data)

        items: List[SceneItem] = []
        for item_data in data.get("items", []):
            items.append(SceneItem.from_dict(item_data))

        characters: List[SceneCharacter] = []
        for ch_data in data.get("characters", []):
            characters.append(SceneCharacter.from_dict(ch_data))

        attachments: List[SceneAttachment] = []
        for att_data in data.get("attachments", []):
            attachments.append(SceneAttachment.from_dict(att_data))

        return cls(
            name=name,
            canvas_size=canvas_size,
            background=background,
            layers=layers,
            items=items,
            characters=characters,
            attachments=attachments,
            base_path=base_path,
            sound=data.get("sound"),
            sound_loop=data.get("sound_loop", True),
        )
