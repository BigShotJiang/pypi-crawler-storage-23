"""
Attachment system for rigged characters.

Attachments are complete rigs (joints, parts, poses, animations) that attach
to a joint on a host character rig and render relative to that attachment point.
Unlike overlays which just layer images, attachments are fully articulated
with their own animation capabilities.

Use cases: Weapons (guns, swords), props, dynamic face attachments,
equipment that needs its own articulation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, TYPE_CHECKING

from .math2d import Vec2, Transform2D

if TYPE_CHECKING:
    from .rig import Rig
    from .pose import Pose, PoseLibrary
    from .animation import AnimationLibrary, AnimationPlayer


@dataclass
class AttachmentConfig:
    """
    Configuration for a rig that can be used as an attachment.

    This is stored in the rig.json "attachment" section to mark a rig
    as an attachment and define its default attachment behavior.

    Attributes:
        is_attachment: Whether this rig is designed to be an attachment
        default_attach_joint: Default joint name to attach to on host (e.g., "wrist_L")
        inherit_rotation: Whether to inherit rotation from host joint
        inherit_scale: Whether to inherit scale from host joint
        z_offset: Base z-offset added to all attachment parts
    """

    is_attachment: bool = False
    default_attach_joint: Optional[str] = None
    inherit_rotation: bool = True
    inherit_scale: bool = False
    z_offset: int = 0
    slot: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON export."""
        d = {
            "is_attachment": self.is_attachment
        }
        if self.default_attach_joint:
            d["default_attach_joint"] = self.default_attach_joint
        if not self.inherit_rotation:
            d["inherit_rotation"] = False
        if self.inherit_scale:
            d["inherit_scale"] = True
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.slot:
            d["slot"] = self.slot
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AttachmentConfig:
        """Create from dictionary data."""
        return cls(
            is_attachment=data.get("is_attachment", False),
            default_attach_joint=data.get("default_attach_joint"),
            inherit_rotation=data.get("inherit_rotation", True),
            inherit_scale=data.get("inherit_scale", False),
            z_offset=data.get("z_offset", 0),
            slot=data.get("slot", "")
        )


@dataclass
class AttachmentPoseState:
    """
    State of an attachment within a pose.

    Stored in Pose.attachments dict to control attachment behavior
    per-pose (which pose, visibility, joint override).

    Attributes:
        pose: Name of the pose to apply to the attachment
        visible: Whether the attachment is visible in this pose
        host_joint: Override the host joint for this pose (None = use default)
    """

    pose: str = "neutral"
    visible: bool = True
    host_joint: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {}
        if self.pose != "neutral":
            d["pose"] = self.pose
        if not self.visible:
            d["visible"] = False
        if self.host_joint:
            d["host_joint"] = self.host_joint
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AttachmentPoseState:
        """Create from dictionary."""
        return cls(
            pose=data.get("pose", "neutral"),
            visible=data.get("visible", True),
            host_joint=data.get("host_joint")
        )

    def is_default(self) -> bool:
        """Check if this state is the default (no customizations)."""
        return self.pose == "neutral" and self.visible and self.host_joint is None


@dataclass
class AttachmentBinding:
    """
    Binding configuration for an attachment on a character.

    Stored in character's attachments.json to define which attachments
    are available and their default bindings.

    Attributes:
        path: Path to the attachment rig directory (e.g., "attachments/sword")
        default_joint: Default joint to attach to on this character
        pos: Position offset in host joint's local space (rotates with joint)
        rot: Rotation offset in degrees
        z_offset: Z-order offset added to all attachment parts
        scale: Scale multiplier applied to all attachment parts
    """

    path: str = ""
    default_joint: str = ""
    pos: Vec2 = field(default_factory=Vec2.zero)
    rot: float = 0.0
    z_offset: int = 0
    scale: Vec2 = field(default_factory=Vec2.one)
    slot: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {
            "path": self.path,
            "default_joint": self.default_joint
        }
        if self.pos.x != 0 or self.pos.y != 0:
            d["pos"] = [self.pos.x, self.pos.y]
        if self.rot != 0:
            d["rot"] = self.rot
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.scale.x != 1 or self.scale.y != 1:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.slot:
            d["slot"] = self.slot
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AttachmentBinding:
        """Create from dictionary."""
        pos_data = data.get("pos", [0, 0])
        pos = Vec2(pos_data[0], pos_data[1]) if pos_data else Vec2.zero()
        scale_data = data.get("scale", [1, 1])
        scale = Vec2(scale_data[0], scale_data[1]) if scale_data else Vec2.one()
        return cls(
            path=data.get("path", ""),
            default_joint=data.get("default_joint", ""),
            pos=pos,
            rot=data.get("rot", 0.0),
            z_offset=data.get("z_offset", 0),
            scale=scale,
            slot=data.get("slot", "")
        )


@dataclass
class AttachmentLibrary:
    """
    A collection of attachment bindings for a character.

    Loaded from attachments.json in the character directory.
    """

    bindings: Dict[str, AttachmentBinding] = field(default_factory=dict)

    def get(self, name: str) -> Optional[AttachmentBinding]:
        """Get a binding by name."""
        return self.bindings.get(name)

    def add(self, name: str, binding: AttachmentBinding) -> None:
        """Add or replace a binding."""
        self.bindings[name] = binding

    def remove(self, name: str) -> bool:
        """Remove a binding by name. Returns True if removed."""
        if name in self.bindings:
            del self.bindings[name]
            return True
        return False

    def list_names(self) -> List[str]:
        """Return a list of all attachment names."""
        return list(self.bindings.keys())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {name: binding.to_dict() for name, binding in self.bindings.items()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AttachmentLibrary:
        """Create from dictionary."""
        bindings = {}
        for name, binding_data in data.items():
            bindings[name] = AttachmentBinding.from_dict(binding_data)
        return cls(bindings=bindings)


@dataclass
class AttachmentInstance:
    """
    Runtime instance of an attachment bound to a character.

    This holds the loaded attachment rig and its current state
    during rendering/animation.

    Attributes:
        name: Identifier for this attachment instance
        attachment_rig: The loaded attachment Rig
        attachment_poses: Optional pose library for the attachment
        attachment_animations: Optional animation library for the attachment
        host_joint: Name of the host joint this is attached to
        current_pose: Current pose name for the attachment
        animation_sync: Whether to sync animations with host
        visible: Whether this attachment is currently visible
        z_offset: Additional z-offset (added to config z_offset)
        pos_offset: Position offset in host joint's local space
        rot_offset: Rotation offset in degrees
        scale_offset: Scale multiplier for the attachment
    """

    name: str = ""
    attachment_rig: Optional["Rig"] = None
    attachment_poses: Optional["PoseLibrary"] = None
    attachment_animations: Optional["AnimationLibrary"] = None
    host_joint: str = ""
    current_pose: str = "neutral"
    animation_sync: bool = True
    visible: bool = True
    z_offset: int = 0
    pos_offset: Optional[Vec2] = None
    rot_offset: float = 0.0
    scale_offset: Vec2 = field(default_factory=Vec2.one)
    slot: str = ""
    _player: Optional["AnimationPlayer"] = field(default=None, repr=False)

    def play_animation(self, name: str, loop: bool = True, interpolate: bool = True) -> None:
        """Play an animation from this attachment's animation library.

        Args:
            name: Animation name (must exist in attachment_animations)
            loop: Whether to loop the animation
            interpolate: Whether to interpolate between poses
        """
        if self.attachment_animations is None:
            raise ValueError(f"Attachment '{self.name}' has no animation library")
        animation = self.attachment_animations.get(name)
        if animation is None:
            raise ValueError(
                f"Animation '{name}' not found in attachment '{self.name}'"
            )
        from .animation import AnimationPlayer, PlayMode
        from .pose import PoseLibrary
        animation.mode = PlayMode.LOOP if loop else PlayMode.ONCE
        self._player = AnimationPlayer(
            animation, self.attachment_poses or PoseLibrary(), interpolate
        )
        self._player.start()

    def stop_animation(self) -> None:
        """Stop and clear any active animation on this attachment."""
        if self._player is not None:
            self._player.stop()
            self._player = None

    @property
    def is_animating(self) -> bool:
        """True when this attachment has an active, playing animation."""
        return self._player is not None and self._player.is_playing


def compute_attachment_transform(
    host_rig: "Rig",
    host_joint_name: str,
    config: AttachmentConfig,
    pos_offset: Optional[Vec2] = None,
    rot_offset: float = 0.0
) -> Transform2D:
    """
    Compute the world transform for an attachment's root.

    The attachment's root joint will be placed at the host joint's
    world position, optionally inheriting rotation and scale.

    Args:
        host_rig: The host character rig (with world positions computed)
        host_joint_name: Name of the joint to attach to
        config: The attachment's configuration
        pos_offset: Position offset in host joint's local space (rotates with joint)
        rot_offset: Rotation offset in degrees

    Returns:
        Transform2D representing the attachment root's world transform
    """
    host_joint = host_rig.joints.get(host_joint_name)
    if host_joint is None:
        # Fallback to origin if joint not found
        return Transform2D(
            position=Vec2.zero(),
            rotation=0.0,
            scale=Vec2.one()
        )

    world_pos = host_joint.world_pos

    # Inherit rotation if configured
    world_rot = 0.0
    if config.inherit_rotation:
        world_rot = host_rig.get_world_rotation(host_joint_name)

    # Apply position offset in host joint's local space (rotates with joint)
    if pos_offset is not None and (pos_offset.x != 0 or pos_offset.y != 0):
        rotated_offset = pos_offset.rotated(world_rot)
        world_pos = world_pos + rotated_offset

    # Apply rotation offset
    world_rot = world_rot + rot_offset

    # Inherit scale if configured (not commonly used)
    world_scale = Vec2.one()
    if config.inherit_scale:
        # Host rigs don't typically have scale on joints, so this is a placeholder
        # for future extension
        pass

    return Transform2D(
        position=world_pos,
        rotation=world_rot,
        scale=world_scale
    )


def get_attachment_part_world_transform(
    attachment_rig: "Rig",
    part_name: str,
    root_transform: Transform2D
) -> Optional[Transform2D]:
    """
    Get the world transform for an attachment part.

    Computes the part's transform relative to the attachment root,
    then composes with the root transform to get world position.

    Args:
        attachment_rig: The attachment rig (with world positions computed)
        part_name: Name of the part
        root_transform: Transform of the attachment root in host's world space

    Returns:
        World transform for the part, or None if part not found
    """
    part = attachment_rig.parts.get(part_name)
    if not part:
        return None

    joint = attachment_rig.joints.get(part.parent_joint)
    if not joint:
        return None

    # Get the part's local transform relative to attachment origin
    # The attachment rig's joints have world_pos relative to its own canvas
    attachment_world_rot = attachment_rig.get_world_rotation(part.parent_joint)
    rotated_offset = part.pos.rotated(attachment_world_rot)
    local_pos = joint.world_pos + rotated_offset

    # Find the root joint to get relative position
    root_joint = attachment_rig.get_root_joint()
    root_pos = root_joint.world_pos if root_joint else Vec2.zero()

    # Position relative to attachment root
    relative_pos = local_pos - root_pos

    # Rotate relative position by root transform rotation
    world_relative_pos = relative_pos.rotated(root_transform.rotation)

    # Final world position
    world_pos = root_transform.position + world_relative_pos

    # Final world rotation (attachment rotation + root rotation)
    world_rot = attachment_world_rot + part.rotation + root_transform.rotation

    # Scale composition
    world_scale = Vec2(
        part.scale.x * root_transform.scale.x,
        part.scale.y * root_transform.scale.y
    )

    return Transform2D(
        position=world_pos,
        rotation=world_rot,
        scale=world_scale,
        pivot=part.pivot
    )
