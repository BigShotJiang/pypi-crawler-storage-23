"""
Audio channel management for rig sound effects.

Provides pre-registered Ren'Py audio channels for pose sounds,
scene ambient audio, and animation timeline sound effects.
"""

from __future__ import annotations

import os

# Ren'Py imports
try:
    import renpy.exports as renpy
    RENPY_AVAILABLE = True
except ImportError:
    RENPY_AVAILABLE = False
    renpy = None

# Channel names
CHANNEL_POSE = "rig_pose"
CHANNEL_SCENE = "rig_scene"
CHANNEL_SFX_PREFIX = "rig_sfx_"
SFX_CHANNEL_COUNT = 4


def register_channels():
    """Register rig audio channels with Ren'Py. Call at init time."""
    if not RENPY_AVAILABLE:
        return
    renpy.music.register_channel(CHANNEL_POSE, "sfx", loop=False)
    renpy.music.register_channel(CHANNEL_SCENE, "sfx", loop=True)
    for i in range(SFX_CHANNEL_COUNT):
        renpy.music.register_channel(
            "{}{}".format(CHANNEL_SFX_PREFIX, i), "sfx", loop=False
        )


def _resolve_path(path, base_path=""):
    """Resolve a sound path relative to base_path, returning a Ren'Py-relative path."""
    if not path:
        return ""
    full_path = path
    if base_path:
        full_path = os.path.join(base_path, path)
    full_path = full_path.replace("\\", "/")

    # Make relative to game directory if absolute
    if RENPY_AVAILABLE:
        gamedir = renpy.config.gamedir.replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

    return full_path


def play_sound(path, channel, loop=False, base_path=""):
    """Play a sound file, resolving path relative to base_path."""
    if not RENPY_AVAILABLE or not path:
        return
    resolved = _resolve_path(path, base_path)
    if not resolved:
        return
    renpy.music.play(resolved, channel=channel, loop=loop)


def stop_channel(channel):
    """Stop a channel."""
    if not RENPY_AVAILABLE:
        return
    renpy.music.stop(channel=channel)


def get_playing(channel):
    """Get the currently playing file on a channel, or None."""
    if not RENPY_AVAILABLE:
        return None
    return renpy.music.get_playing(channel=channel)
