"""
2D math utilities for transform calculations.

Provides vector operations, matrix transforms, and interpolation
helpers used throughout the rigging system.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple, Union


@dataclass(frozen=True)
class Vec2:
    """An immutable 2D vector."""

    x: float
    y: float

    def __add__(self, other: Vec2) -> Vec2:
        return Vec2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: Vec2) -> Vec2:
        return Vec2(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar: float) -> Vec2:
        return Vec2(self.x * scalar, self.y * scalar)

    def __rmul__(self, scalar: float) -> Vec2:
        return self.__mul__(scalar)

    def __truediv__(self, scalar: float) -> Vec2:
        return Vec2(self.x / scalar, self.y / scalar)

    def __neg__(self) -> Vec2:
        return Vec2(-self.x, -self.y)

    @property
    def length(self) -> float:
        """Return the magnitude of this vector."""
        return math.sqrt(self.x * self.x + self.y * self.y)

    @property
    def length_squared(self) -> float:
        """Return the squared magnitude (avoids sqrt)."""
        return self.x * self.x + self.y * self.y

    def normalized(self) -> Vec2:
        """Return a unit vector in the same direction."""
        length = self.length
        if length < 1e-10:
            return Vec2(0.0, 0.0)
        return self / length

    def dot(self, other: Vec2) -> float:
        """Return the dot product with another vector."""
        return self.x * other.x + self.y * other.y

    def cross(self, other: Vec2) -> float:
        """Return the 2D cross product (z-component of 3D cross)."""
        return self.x * other.y - self.y * other.x

    def rotated(self, angle_deg: float) -> Vec2:
        """Return this vector rotated by angle_deg degrees."""
        rad = math.radians(angle_deg)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        return Vec2(
            self.x * cos_a - self.y * sin_a,
            self.x * sin_a + self.y * cos_a
        )

    def lerp(self, other: Vec2, t: float) -> Vec2:
        """Linear interpolation to another vector."""
        return Vec2(
            self.x + (other.x - self.x) * t,
            self.y + (other.y - self.y) * t
        )

    def copy(self) -> Vec2:
        """Return self (immutable types don't need copying)."""
        return self

    def to_tuple(self) -> Tuple[float, float]:
        """Convert to a tuple (x, y)."""
        return (self.x, self.y)

    def to_int_tuple(self) -> Tuple[int, int]:
        """Convert to an integer tuple (for pixel coordinates)."""
        return (int(round(self.x)), int(round(self.y)))

    @classmethod
    def from_tuple(cls, t: Tuple[float, float]) -> Vec2:
        """Create a Vec2 from a tuple."""
        return cls(t[0], t[1])

    @classmethod
    def zero(cls) -> Vec2:
        """Return the zero vector."""
        return cls(0.0, 0.0)

    @classmethod
    def one(cls) -> Vec2:
        """Return the unit vector (1, 1)."""
        return cls(1.0, 1.0)


@dataclass(frozen=True)
class Transform2D:
    """
    A 2D affine transform represented as:
    - position (translation)
    - rotation (degrees)
    - scale
    - pivot (rotation/scale center)

    Transforms are applied in this order:
    1. Translate by -pivot (move pivot to origin)
    2. Scale
    3. Rotate
    4. Translate by +pivot (move back)
    5. Translate by position
    """

    position: Vec2 = None
    rotation: float = 0.0  # degrees
    scale: Vec2 = None
    pivot: Vec2 = None

    def __post_init__(self):
        # Use object.__setattr__ since dataclass is frozen
        if self.position is None:
            object.__setattr__(self, 'position', Vec2.zero())
        if self.scale is None:
            object.__setattr__(self, 'scale', Vec2.one())
        if self.pivot is None:
            object.__setattr__(self, 'pivot', Vec2.zero())

    def transform_point(self, point: Vec2) -> Vec2:
        """Transform a point by this transform."""
        # Move pivot to origin
        p = point - self.pivot

        # Scale
        p = Vec2(p.x * self.scale.x, p.y * self.scale.y)

        # Rotate
        if self.rotation != 0.0:
            p = p.rotated(self.rotation)

        # Move pivot back and apply position
        p = p + self.pivot + self.position

        return p

    def inverse_transform_point(self, point: Vec2) -> Vec2:
        """Transform a point by the inverse of this transform."""
        # Undo position and pivot offset
        p = point - self.position - self.pivot

        # Undo rotation
        if self.rotation != 0.0:
            p = p.rotated(-self.rotation)

        # Undo scale
        p = Vec2(
            p.x / self.scale.x if self.scale.x != 0 else 0,
            p.y / self.scale.y if self.scale.y != 0 else 0
        )

        # Undo pivot
        p = p + self.pivot

        return p

    def compose(self, other: Transform2D) -> Transform2D:
        """
        Compose this transform with another.
        Returns a new transform that is equivalent to applying
        self first, then other.
        """
        # Transform the position
        new_pos = other.transform_point(self.position + self.pivot) - other.pivot

        return Transform2D(
            position=new_pos - self.pivot,
            rotation=self.rotation + other.rotation,
            scale=Vec2(self.scale.x * other.scale.x, self.scale.y * other.scale.y),
            pivot=self.pivot
        )

    def lerp(self, other: Transform2D, t: float) -> Transform2D:
        """Linearly interpolate between this transform and another."""
        return Transform2D(
            position=self.position.lerp(other.position, t),
            rotation=lerp_angle(self.rotation, other.rotation, t),
            scale=self.scale.lerp(other.scale, t),
            pivot=self.pivot.lerp(other.pivot, t)
        )

    @classmethod
    def identity(cls) -> Transform2D:
        """Return the identity transform."""
        return cls()


def lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation between two values."""
    return a + (b - a) * t


def lerp_angle(a: float, b: float, t: float) -> float:
    """
    Linearly interpolate between two angles (in degrees).
    Takes the shortest path around the circle.
    """
    # Normalize difference to [-180, 180]
    diff = ((b - a + 180) % 360) - 180
    return a + diff * t


def clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp a value to a range."""
    return max(min_val, min(max_val, value))


def ease_in_out(t: float) -> float:
    """Smooth ease-in-out curve (cubic)."""
    if t < 0.5:
        return 4 * t * t * t
    else:
        return 1 - pow(-2 * t + 2, 3) / 2


def ease_in(t: float) -> float:
    """Ease-in curve (quadratic)."""
    return t * t


def ease_out(t: float) -> float:
    """Ease-out curve (quadratic)."""
    return 1 - (1 - t) * (1 - t)


def point_in_rect(point: Vec2, rect_pos: Vec2, rect_size: Vec2) -> bool:
    """Check if a point is inside a rectangle."""
    return (rect_pos.x <= point.x <= rect_pos.x + rect_size.x and
            rect_pos.y <= point.y <= rect_pos.y + rect_size.y)


def distance(a: Vec2, b: Vec2) -> float:
    """Return the distance between two points."""
    return (b - a).length


def angle_between(a: Vec2, b: Vec2) -> float:
    """Return the angle from a to b in degrees."""
    diff = b - a
    return math.degrees(math.atan2(diff.y, diff.x))
