from emews.__about__ import __version__, _documentation_url

__all__ = ['__version__', '_documentation_url']
