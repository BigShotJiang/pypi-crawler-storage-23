"""eMews server CORE Services."""
from typing import Any

from core.config import Configuration
from core.nodes.interface import CoreInterface
from core.services.base import CoreService, ServiceMode, ShadowDir

GROUP_NAME: str = "eMews"

class HttpsService(CoreService):
    """Apache HTTP/HTTPS Server."""

    name: str = "HTTPS"
    group: str = GROUP_NAME
    directories: list[str] = [
        "/etc/apache2",
        "/var/run/apache2",
        "/var/log/apache2",
        "/run/lock",
        "/var/lock/apache2",
        "/var/run/apache2/ssl",
        "/var/run/apache2/ssl/cert",
        "/var/run/apache2/ssl/key",
    ]
    files: list[str] = [
        "/etc/apache2/apache2.conf",
        "/etc/apache2/envvars",
        "apache2_start.sh"
    ]
    executables: list[str] = ["apache2ctl", "openssl"]
    dependencies: list[str] = []
    startup: list[str] = ["chown www-data /var/lock/apache2", "sh apache2_start.sh"]
    validate: list[str] = ["pidof apache2"]
    shutdown: list[str] = ["apache2ctl stop"]
    validation_mode: ServiceMode = ServiceMode.BLOCKING
    default_configs: list[Configuration] = []
    modes: dict[str, dict[str, str]] = {}
    # mount HTML root from file system (this is the default path for Apache2 on Ubuntu)
    shadow_directories: list[ShadowDir] = [ShadowDir(path="/var/www/html")]

    def data(self) -> dict[str, Any]:
        ifaces: list[CoreInterface] = []

        for iface in self.node.get_ifaces(control=False):
            ifaces.append(iface)
        return dict(ifaces=ifaces)
