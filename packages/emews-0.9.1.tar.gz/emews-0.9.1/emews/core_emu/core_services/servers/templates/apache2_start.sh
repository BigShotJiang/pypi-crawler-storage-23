#!/bin/sh
openssl req -new -x509 -days 365 -sha1 -newkey rsa:2048 -nodes \
-keyout /var/run/apache2/ssl/key/httpd.key \
-out /var/run/apache2/ssl/cert/httpd.crt \
-subj /O=CORE/OU=CORE-emu/CN=${node.name} \
-addext "subjectAltName=IP:${",IP:".join([str(ip_addr.ip) for iface in ifaces for ip_addr in iface.ip4s])}" \
-addext "basicConstraints=critical,CA:FALSE"
# Launch Apache here so we know that cert/key was generated first.
apache2ctl start