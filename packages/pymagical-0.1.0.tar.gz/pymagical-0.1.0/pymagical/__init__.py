from .magical import run_magical

__all__ = ["run_magical"]
