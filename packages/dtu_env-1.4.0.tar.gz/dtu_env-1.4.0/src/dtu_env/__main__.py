"""Allow running as `python -m dtu_env`."""

from dtu_env.cli import main

if __name__ == "__main__":
    main()
