"""Unit tests for CLI formatters."""
