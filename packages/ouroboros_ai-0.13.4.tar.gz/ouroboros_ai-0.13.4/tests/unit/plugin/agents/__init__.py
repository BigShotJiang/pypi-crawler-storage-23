"""Tests for plugin agents module."""
