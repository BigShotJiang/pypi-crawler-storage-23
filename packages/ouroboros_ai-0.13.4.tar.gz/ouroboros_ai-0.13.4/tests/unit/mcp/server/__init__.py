"""MCP server unit tests package."""
