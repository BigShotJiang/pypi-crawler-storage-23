"""End-to-end tests for Ouroboros workflow system."""
