---
description: "Start or monitor an evolutionary development loop"
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/evolve/SKILL.md` using the Read tool and follow its instructions exactly.

## User Input

{{ARGUMENTS}}
