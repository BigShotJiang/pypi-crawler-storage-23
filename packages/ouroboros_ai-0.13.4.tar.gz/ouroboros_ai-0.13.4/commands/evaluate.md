---
description: "Evaluate execution with three-stage verification pipeline"
aliases: [eval]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/evaluate/SKILL.md` using the Read tool and follow its instructions exactly.
