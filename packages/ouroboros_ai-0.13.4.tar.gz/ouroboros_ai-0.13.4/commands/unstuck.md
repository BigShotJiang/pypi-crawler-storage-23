---
description: "Break through stagnation with lateral thinking personas"
aliases: [stuck, lateral]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/unstuck/SKILL.md` using the Read tool and follow its instructions exactly.
