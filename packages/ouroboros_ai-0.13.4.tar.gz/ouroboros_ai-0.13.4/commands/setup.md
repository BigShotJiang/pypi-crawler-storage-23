---
description: "Guided onboarding wizard for Ouroboros setup"
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/setup/SKILL.md` using the Read tool and follow its instructions exactly.
