---
description: "Interactive tutorial teaching Ouroboros hands-on"
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/tutorial/SKILL.md` using the Read tool and follow its instructions exactly.
