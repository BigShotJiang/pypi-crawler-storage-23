"""Settings for this package."""
from hunterMakesPy import PackageSettings

settingsPackage: PackageSettings = PackageSettings(identifierPackageFALLBACK='hunterMakesPy')
