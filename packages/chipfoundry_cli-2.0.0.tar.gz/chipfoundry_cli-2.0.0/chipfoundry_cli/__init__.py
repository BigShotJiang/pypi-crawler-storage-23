"""ChipFoundry CLI package: Automate project submission to SFTP."""
__version__ = "0.1.0" 