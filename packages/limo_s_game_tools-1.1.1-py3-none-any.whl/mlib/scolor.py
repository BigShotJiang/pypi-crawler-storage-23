# scolor.py - 游戏颜色工具

def rgb(r, g, b):
    """RGB 颜色 (0-255)"""
    return (r, g, b)
    

def rgba(r, g, b, a=255):
    """RGBA 颜色"""
    return (r, g, b, a)
    
    
def hex_to_rgb(hex_str):
    """16进制转RGB，如 #FF0000 转 (255,0,0)"""
    hex_str = hex_str.lstrip('#')
    r = int(hex_str[0:2], 16)
    g = int(hex_str[2:4], 16)
    b = int(hex_str[4:6], 16)
    return (r, g, b)

def rgb_to_hex(r,g,b):
    return "#{:02x}{:02x}{:02x}".format(r, g, b)

    
    
def lerp(c1, c2, t):
    """颜色插值"""
    return tuple(int(a + (b-a)*t) for a,b in zip(c1, c2))

def rgb_to_hsv(r, g, b):
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    cmax = max(r, g, b)
    cmin = min(r, g, b)
    delta = cmax - cmin
    if delta == 0:
        h = 0
    elif cmax == r:
        h = 60 * (((g - b) / delta) % 6)
    elif cmax == g:
        h = 60 * (((b - r) / delta) + 2)
    else:  # cmax == b
        h = 60 * (((r - g) / delta) + 4)
    if h < 0:
        h += 360
    if cmax == 0:
        s = 0
    else:
        s = delta / cmax
    v = cmax
    
    return h, s, v

def hsv_to_rgb(h, s, v):
    """HSV转RGB，返回(0-255)的RGB值"""
    h = h % 360
    s = max(0, min(s, 1))
    v = max(0, min(v, 1))
    
    c = v * s
    x = c * (1 - abs((h / 60) % 2 - 1))
    m = v - c
    
    if h < 60:
        r, g, b = c, x, 0
    elif h < 120:
        r, g, b = x, c, 0
    elif h < 180:
        r, g, b = 0, c, x
    elif h < 240:
        r, g, b = 0, x, c
    elif h < 300:
        r, g, b = x, 0, c
    else:
        r, g, b = c, 0, x
    
    return int((r + m) * 255), int((g + m) * 255), int((b + m) * 255)
    

# 常用颜色
WHITE = (255, 255, 255)
BLACK = (20, 20, 30)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (147, 112, 219)
ORANGE = (255, 165, 0)
CYAN = (0, 255, 255)
GRAY = (128, 128, 128)
BROWN = (139, 69, 19)
PINK = (255, 67, 170)
GOLD = (255, 215, 0)
MAGENTA = (255, 0, 255)
BACKGROUND = (5, 5, 15)
LIGHT_BLUE = (173, 216, 230)
LIGHT_GRAY = (150, 150, 150)
LIGHT_ORANGE = (255, 215, 0)
LIGHT_GREEN = (144, 238, 144)
LIGHT_BROWN = (205, 133, 63)
LIGHT_PINK = (255, 182, 193)
LIGHT_PURPLE = (200, 162, 200)
LIGHT_CYAN = (224, 255, 255)
LIGHT_YELLOW = (255, 255, 224)
LIGHT_CORAL = (240, 128, 128)
DARK_GREEN = (0, 100, 0)
DARK_BLUE = (0, 0, 139)
DARK_RED = (100, 0, 0)
DARK_GOLD = (184, 134, 11)
DARK_PURPLE = (75, 0, 130)
DARK_BROWN = (101, 67, 33)
DARK_CYAN = (0, 139, 139)
DARK_ORANGE = (255, 140, 0)
DARK_GRAY = (64, 64, 64)
DARK_PINK = (231, 84, 128)
AQUA = (0, 255, 255)
LAVENDER = (230, 230, 250)
CORAL = (255, 127, 80)
TEAL = (0, 128, 128)
INDIGO = (75, 0, 130)
VIOLET = (238, 130, 238)
MAROON = (128, 0, 0)
OLIVE = (128, 128, 0)
NAVY = (0, 0, 128)
LIME = (0, 255, 0)
FUCHSIA = (255, 0, 255)
SILVER = (192, 192, 192)
PRIMARY = (97, 168, 255)
SECONDARY = (60, 60, 100)
SUCCESS = (100, 255, 100)
WARNING = (255, 255, 100)
ERROR = (255, 100, 100)
INFO = (173, 216, 230)

