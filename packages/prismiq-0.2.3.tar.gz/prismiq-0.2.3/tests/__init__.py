"""Prismiq test suite."""
