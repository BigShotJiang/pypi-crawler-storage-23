## [2.0.8] - 2026-02-23

### Fixed
- Set correct headers

