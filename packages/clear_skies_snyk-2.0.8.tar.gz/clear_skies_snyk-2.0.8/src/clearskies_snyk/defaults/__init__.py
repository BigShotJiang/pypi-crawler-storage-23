from clearskies_snyk.defaults.default_snyk_auth import DefaultSnykAuth

__all__ = [
    "DefaultSnykAuth",
]
