#!/usr/bin/env python
"""
Unified failure contract helpers for shadow pipeline phases.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function


def infer_recoverability(error_code):
    """Best-effort recoverability classification for operator-facing diagnostics."""
    code = str(error_code or "").strip().upper()
    if not code:
        return "none"
    if code in ("PIPELINE_ALREADY_RUNNING", "PHASE_F_LOCK_CONTENDED_ATTACH"):
        return "attached"
    if "LOCK" in code or code == "ALREADY_RUNNING":
        return "retryable"
    if "MISSING" in code or "ENTRYPOINT" in code or "SCRIPT" in code:
        return "configuration"
    if code.startswith("QA_"):
        return "data_issue"
    if "IO" in code or "READ" in code or "WRITE" in code:
        return "retryable"
    return "fatal"


def build_failure_context(phase, error_code, error_detail="", source_exception_class=""):
    """Construct normalized failure contract payload."""
    return {
        "phase": str(phase or "").strip().upper(),
        "error_code": str(error_code or "").strip(),
        "error_detail": str(error_detail or "").strip(),
        "recoverability": infer_recoverability(error_code),
        "source_exception_class": str(source_exception_class or "").strip(),
    }

