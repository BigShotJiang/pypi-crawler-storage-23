#!/usr/bin/env python
from __future__ import print_function

"""Unified migration-health audit for XP and cloud surfaces.

Read-only by default. Writes local report artifacts only when requested.
"""

import argparse
import calendar
import json
import os
import re
import sys
import time
import uuid

try:
    from urllib.request import urlopen
except Exception:  # pragma: no cover
    urlopen = None

try:
    from scripts.unified_model.lab_path_utils import resolve_lab_root
except Exception:
    from lab_path_utils import resolve_lab_root

PASS = "pass"
WARN = "warn"
FAIL = "fail"
MISSING = "__MISSING__"
MIGRATION_STAGES = ("xp_validation", "dual_run_pre_cutover", "cutover")

THRESHOLD_PROFILES = {
    "default": {
        "xp.pipeline_recentness_hours": {"pass_max": 24.0, "warn_max": 72.0},
        "xp.phase_d_reject_ratio": {"pass_max": 0.15, "warn_max": 0.30},
        "xp.phase_c_anomaly_ratio": {"pass_max": 0.01, "warn_max": 0.05},
        "xp.phase_e_projection_coverage": {"pass_min": 1.0, "warn_min": 0.98},
        "cloud.unacked_queue_count": {"pass_max": 20.0, "warn_max": 100.0},
        "cloud.oldest_unacked_age_minutes": {"pass_max": 30.0, "warn_max": 120.0},
        "cloud.watch_freshness_hours": {"pass_max": 8.0, "warn_max": 24.0},
        "cloud.duplicate_message_id_count": {"pass_max": 0.0, "warn_max": 2.0},
        "cloud.unhandled_exception_count_24h": {"pass_max": 0.0, "warn_max": 3.0},
        "cloud.cleanup_partial_failure_count_24h": {"pass_max": 0.0, "warn_max": 2.0},
        "cloud.unique_shadow_processed_count": {"pass_min": 50.0, "warn_min": 25.0},
    },
    "strict": {
        "xp.pipeline_recentness_hours": {"pass_max": 12.0, "warn_max": 36.0},
        "xp.phase_d_reject_ratio": {"pass_max": 0.10, "warn_max": 0.20},
        "xp.phase_c_anomaly_ratio": {"pass_max": 0.005, "warn_max": 0.02},
        "xp.phase_e_projection_coverage": {"pass_min": 1.0, "warn_min": 0.995},
        "cloud.unacked_queue_count": {"pass_max": 10.0, "warn_max": 50.0},
        "cloud.oldest_unacked_age_minutes": {"pass_max": 20.0, "warn_max": 90.0},
        "cloud.watch_freshness_hours": {"pass_max": 4.0, "warn_max": 12.0},
        "cloud.duplicate_message_id_count": {"pass_max": 0.0, "warn_max": 1.0},
        "cloud.unhandled_exception_count_24h": {"pass_max": 0.0, "warn_max": 1.0},
        "cloud.cleanup_partial_failure_count_24h": {"pass_max": 0.0, "warn_max": 1.0},
        "cloud.unique_shadow_processed_count": {"pass_min": 75.0, "warn_min": 40.0},
    },
    "relaxed": {
        "xp.pipeline_recentness_hours": {"pass_max": 36.0, "warn_max": 96.0},
        "xp.phase_d_reject_ratio": {"pass_max": 0.20, "warn_max": 0.40},
        "xp.phase_c_anomaly_ratio": {"pass_max": 0.02, "warn_max": 0.08},
        "xp.phase_e_projection_coverage": {"pass_min": 0.99, "warn_min": 0.95},
        "cloud.unacked_queue_count": {"pass_max": 40.0, "warn_max": 150.0},
        "cloud.oldest_unacked_age_minutes": {"pass_max": 60.0, "warn_max": 180.0},
        "cloud.watch_freshness_hours": {"pass_max": 12.0, "warn_max": 36.0},
        "cloud.duplicate_message_id_count": {"pass_max": 1.0, "warn_max": 5.0},
        "cloud.unhandled_exception_count_24h": {"pass_max": 1.0, "warn_max": 5.0},
        "cloud.cleanup_partial_failure_count_24h": {"pass_max": 1.0, "warn_max": 4.0},
        "cloud.unique_shadow_processed_count": {"pass_min": 30.0, "warn_min": 15.0},
    },
}


def normalize_migration_stage(value, default="xp_validation"):
    stage = str(value or "").strip().lower()
    if stage in MIGRATION_STAGES:
        return stage
    return default


def _clone_thresholds(src):
    out = {}
    for mk, rule in (src or {}).items():
        if isinstance(rule, dict):
            out[mk] = dict(rule)
    return out


def _to_float(v):
    try:
        return float(v)
    except Exception:
        return None


def _apply_threshold_overrides(base, threshold_file, overrides):
    resolved = _clone_thresholds(base)

    if threshold_file:
        loaded = load_json(threshold_file)
        for mk, rule in loaded.items() if isinstance(loaded, dict) else []:
            if mk not in resolved:
                raise ValueError("Unknown threshold metric in file: {0}".format(mk))
            if not isinstance(rule, dict):
                raise ValueError("Threshold metric rule must be object: {0}".format(mk))
            for k, v in rule.items():
                fv = _to_float(v)
                if k not in ("pass_max", "warn_max", "pass_min", "warn_min") or fv is None:
                    raise ValueError("Invalid threshold key/value in file: {0}.{1}".format(mk, k))
                resolved[mk][k] = fv

    for raw in (overrides or []):
        part = str(raw or "").strip()
        if not part or "=" not in part:
            raise ValueError("Invalid --threshold-override (expected key=value): {0}".format(raw))
        left, right = part.split("=", 1)
        left = left.strip()
        right = right.strip()
        if "." not in left:
            raise ValueError("Invalid threshold override key format: {0}".format(left))
        metric_key, rule_key = left.rsplit(".", 1)
        if metric_key not in resolved:
            raise ValueError("Unknown threshold metric override: {0}".format(metric_key))
        if rule_key not in ("pass_max", "warn_max", "pass_min", "warn_min"):
            raise ValueError("Unknown threshold rule override: {0}".format(rule_key))
        fv = _to_float(right)
        if fv is None:
            raise ValueError("Threshold override value must be numeric: {0}".format(raw))
        resolved[metric_key][rule_key] = fv

    return resolved


def resolve_thresholds(profile, threshold_file, overrides):
    base = THRESHOLD_PROFILES.get(profile) or THRESHOLD_PROFILES["default"]
    return _apply_threshold_overrides(base, threshold_file, overrides)


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def make_run_id():
    return "{0}-{1}".format(time.strftime("%Y%m%d-%H%M%S", time.gmtime()), uuid.uuid4().hex[:8])


def parse_ts(value):
    if not value:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S"):
        try:
            return int(calendar.timegm(time.strptime(value, fmt)))
        except Exception:
            pass
    return None


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def ensure_reports_dir(lab_dir):
    p = os.path.join(lab_dir, "reports")
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


def latest_report(reports_dir, prefix, suffixes=(".json",)):
    candidates = []
    try:
        names = os.listdir(reports_dir)
    except Exception:
        return None, None
    for name in names:
        if not name.startswith(prefix):
            continue
        if suffixes and not any(name.endswith(s) for s in suffixes):
            continue
        path = os.path.join(reports_dir, name)
        try:
            mt = os.path.getmtime(path)
        except Exception:
            mt = -1
        candidates.append((mt, name, path))
    if not candidates:
        return None, None
    candidates.sort(key=lambda x: (x[0], x[1]))
    _mt, name, path = candidates[-1]
    m = re.match(r"^" + re.escape(prefix) + r"(.+?)\.[^.]+$", name)
    run_id = m.group(1) if m else ""
    return path, run_id


def finding(code, severity, message, metric_key=None, value=None):
    return {
        "code": code,
        "severity": severity,
        "message": message,
        "metric_key": metric_key or "",
        "value": value,
    }


def metric_result(key, status, value, detail=""):
    return {"key": key, "status": status, "value": value, "detail": detail}


def score_from_metrics(metrics):
    if not metrics:
        return 0
    grade = {PASS: 100, WARN: 60, FAIL: 0}
    vals = [grade.get(m.get("status"), 0) for m in metrics if m.get("status") in grade]
    if not vals:
        return 0
    return int(round(float(sum(vals)) / float(len(vals))))


def worst_status(items):
    order = {PASS: 0, WARN: 1, FAIL: 2}
    w = PASS
    for it in items:
        s = it.get("status") if isinstance(it, dict) else it
        if order.get(s, -1) > order.get(w, -1):
            w = s
    return w


def eval_numeric_max(key, value, pmax, wmax):
    if value is MISSING:
        return metric_result(key, WARN, MISSING, "missing")
    if value <= pmax:
        return metric_result(key, PASS, value)
    if value <= wmax:
        return metric_result(key, WARN, value)
    return metric_result(key, FAIL, value)


def eval_numeric_min(key, value, pmin, wmin):
    if value is MISSING:
        return metric_result(key, WARN, MISSING, "missing")
    if value >= pmin:
        return metric_result(key, PASS, value)
    if value >= wmin:
        return metric_result(key, WARN, value)
    return metric_result(key, FAIL, value)


def collect_xp(lab_dir, thresholds, migration_stage="xp_validation"):
    migration_stage = normalize_migration_stage(migration_stage)
    reports_dir = os.path.join(lab_dir, "reports")
    state = load_json(os.path.join(lab_dir, "diagnostics_state.json"))
    cursor = load_json(os.path.join(lab_dir, "run_cursor.json"))

    metrics = []
    findings = []
    hard_gates = []

    ts = state.get("last_shadow_pipeline_finished_at_utc") or state.get("finished_at_utc") or state.get("last_phase_f_at_utc")
    now = int(time.time())
    tsv = parse_ts(ts)
    fresh_h = MISSING if tsv is None else round((now - tsv) / 3600.0, 2)
    t = thresholds.get("xp.pipeline_recentness_hours", {})
    m = eval_numeric_max("xp.pipeline_recentness_hours", fresh_h, t.get("pass_max", 24), t.get("warn_max", 72))
    metrics.append(m)
    if fresh_h is MISSING:
        findings.append(finding("XP_FRESHNESS_UNKNOWN", WARN, "Pipeline freshness timestamp is missing.", m["key"], fresh_h))

    pipeline_ok = state.get("last_shadow_pipeline_ok")
    if pipeline_ok is True:
        m = metric_result("xp.pipeline_last_run_ok", PASS, True)
    elif pipeline_ok is False:
        m = metric_result("xp.pipeline_last_run_ok", FAIL, False)
        hard_gates.append("xp.pipeline_last_run_ok=false")
        findings.append(finding("XP_PIPELINE_NOT_OK", FAIL, "Latest shadow pipeline marked failed.", m["key"], False))
    else:
        m = metric_result("xp.pipeline_last_run_ok", WARN, MISSING, "missing")
        findings.append(finding("XP_PIPELINE_OK_UNKNOWN", WARN, "Missing last_shadow_pipeline_ok.", m["key"], MISSING))
    metrics.append(m)

    parity = str(state.get("last_contract_parity_status", "") or "").strip().lower()
    if parity == "pass":
        m = metric_result("xp.phase_e_contract_parity", PASS, "pass")
    elif parity == "fail":
        m = metric_result("xp.phase_e_contract_parity", FAIL, "fail")
        hard_gates.append("xp.phase_e_contract_parity=fail")
        findings.append(finding("XP_PARITY_FAIL", FAIL, "Contract parity reports fail.", m["key"], "fail"))
    else:
        m = metric_result("xp.phase_e_contract_parity", WARN, parity or MISSING)
    metrics.append(m)

    qa_path, qa_rid = latest_report(reports_dir, "qa_canonical_summary_", (".json",))
    qa = load_json(qa_path) if qa_path else {}
    rows = qa.get("rows_selected")
    rej = qa.get("qa_reject_count")
    if isinstance(rows, int) and rows >= 0 and isinstance(rej, int) and rej >= 0:
        ratio = float(rej) / float(max(rows, 1))
    else:
        ratio = MISSING
        findings.append(finding("XP_QA_RATIO_UNKNOWN", WARN, "Missing QA summary counters.", "xp.phase_d_reject_ratio", MISSING))
    t = thresholds.get("xp.phase_d_reject_ratio", {})
    metrics.append(eval_numeric_max("xp.phase_d_reject_ratio", ratio, t.get("pass_max", 0.15), t.get("warn_max", 0.30)))

    ingest_path, _ = latest_report(reports_dir, "ingest_write_summary_", (".json",))
    ingest = load_json(ingest_path) if ingest_path else {}
    denom = ingest.get("manifest_rows_read")
    ac = ingest.get("anomaly_count")
    if isinstance(denom, int) and denom >= 0 and isinstance(ac, int) and ac >= 0:
        ar = float(ac) / float(max(denom, 1))
    else:
        ar = MISSING
    t = thresholds.get("xp.phase_c_anomaly_ratio", {})
    metrics.append(eval_numeric_max("xp.phase_c_anomaly_ratio", ar, t.get("pass_max", 0.01), t.get("warn_max", 0.05)))

    proj_path, proj_rid = latest_report(reports_dir, "projection_parity_summary_", (".json",))
    proj = load_json(proj_path) if proj_path else {}
    elig = proj.get("eligible_count")
    succ = proj.get("projected_success_this_run")
    rj = proj.get("projected_reject_this_run")
    if isinstance(elig, int) and elig == 0 and isinstance(succ, int) and isinstance(rj, int):
        cov = "not_applicable"
    elif isinstance(elig, int) and elig >= 0 and isinstance(succ, int) and isinstance(rj, int):
        cov = float(succ + rj) / float(max(elig, 1))
    else:
        cov = MISSING
    t = thresholds.get("xp.phase_e_projection_coverage", {})
    pass_min = t.get("pass_min", 1.0)
    warn_min = t.get("warn_min", 0.98)
    if cov is MISSING:
        metrics.append(metric_result("xp.phase_e_projection_coverage", WARN, MISSING, "missing"))
    elif cov == "not_applicable":
        metrics.append(metric_result(
            "xp.phase_e_projection_coverage",
            PASS,
            "not_applicable",
            "eligible_count=0",
        ))
        findings.append(finding(
            "XP_PROJECTION_COVERAGE_NOT_APPLICABLE",
            WARN,
            "Projection coverage not scored because eligible_count is zero in latest Phase E summary.",
            "xp.phase_e_projection_coverage",
            "not_applicable",
        ))
    elif cov >= pass_min:
        metrics.append(metric_result("xp.phase_e_projection_coverage", PASS, cov))
    elif cov >= warn_min:
        metrics.append(metric_result("xp.phase_e_projection_coverage", WARN, cov))
    else:
        metrics.append(metric_result("xp.phase_e_projection_coverage", FAIL, cov))

    state_ids = state.get("last_shadow_pipeline_phase_run_ids", {}) if isinstance(state.get("last_shadow_pipeline_phase_run_ids", {}), dict) else {}
    cursor_ids = {
        "B": cursor.get("last_phase_b_run_id", ""),
        "C": cursor.get("last_phase_c_run_id", ""),
        "D": cursor.get("last_phase_d_run_id", ""),
        "E": cursor.get("last_phase_e_run_id", ""),
    }
    mismatches = 0
    for ph in ("B", "C", "D", "E"):
        sid = str(state_ids.get(ph, "") or state.get("last_phase_{0}_run_id".format(ph.lower()), "") or "")
        cid = str(cursor_ids.get(ph, "") or "")
        if sid and cid and sid != cid:
            mismatches += 1
    if migration_stage == "cutover":
        if mismatches == 0:
            metrics.append(metric_result("xp.cursor_state_run_alignment", PASS, "aligned"))
        elif mismatches <= 1:
            metrics.append(metric_result("xp.cursor_state_run_alignment", WARN, mismatches))
        else:
            metrics.append(metric_result("xp.cursor_state_run_alignment", FAIL, mismatches))
    else:
        if mismatches == 0:
            metrics.append(metric_result("xp.cursor_state_run_alignment", PASS, "aligned"))
        else:
            metrics.append(metric_result(
                "xp.cursor_state_run_alignment",
                PASS,
                mismatches,
                "stage={0}".format(migration_stage),
            ))
    if mismatches > 0:
        findings.append(finding(
            "XP_CURSOR_ALIGNMENT_DRIFT",
            WARN,
            "Run-id alignment drift detected between diagnostics_state and run_cursor ({0} phase mismatches).".format(
                mismatches
            ),
            "xp.cursor_state_run_alignment",
            mismatches,
        ))

    shadow_report_path, srid = latest_report(reports_dir, "shadow_run_report_", (".json", ".txt"))
    evidence_path, erid = latest_report(reports_dir, "shadow_evidence_index_", (".json",))
    if shadow_report_path and evidence_path:
        st = PASS if (not srid or not erid or srid == erid) else WARN
        metrics.append(metric_result("xp.phase_f_packaging_health", st, "present"))
    else:
        metrics.append(metric_result("xp.phase_f_packaging_health", FAIL, MISSING, "missing shadow report/index"))

    status = worst_status(metrics)
    if hard_gates:
        status = FAIL
    return {
        "collection_mode": "full",
        "status": status,
        "score": score_from_metrics(metrics),
        "metrics": sorted(metrics, key=lambda x: x["key"]),
        "findings": sorted(findings, key=lambda x: ({FAIL: 0, WARN: 1, PASS: 2}.get(x["severity"], 3), x["code"])),
        "hard_gates": hard_gates,
        "run_ids": {"qa": qa_rid, "projection": proj_rid, "shadow": srid, "evidence": erid},
    }


def _safe_firestore_client(project_id):
    try:
        from google.cloud import firestore
    except Exception:
        return None, "google-cloud-firestore not available"
    try:
        return firestore.Client(project=project_id), None
    except Exception as exc:
        return None, "Firestore client init failed: {0}".format(exc)


def _known_reject_codes_and_source():
    try:
        from cloud.orchestrator.reject_codes import KNOWN_INGEST_ERROR_CODES
        return set(KNOWN_INGEST_ERROR_CODES), "authoritative"
    except Exception:
        return set(["unhandled_exception", "processor_unhandled_exception", "missing_machine_id", "missing_message_id", "unsupported_payload"]), "fallback"


def collect_cloud(args, thresholds):
    metrics = []
    findings = []
    hard_gates = []
    degradations = []

    project_id = args.project_id or os.environ.get("GOOGLE_CLOUD_PROJECT", "")
    if not project_id:
        degradations.append("project_id_missing")
        return {
            "collection_mode": "unavailable",
            "status": WARN,
            "score": 0,
            "metrics": [],
            "findings": [finding("CLOUD_PROJECT_ID_MISSING", WARN, "Cloud project id unavailable.")],
            "hard_gates": hard_gates,
            "degradations": degradations,
        }

    client, err = _safe_firestore_client(project_id)
    if err or client is None:
        degradations.append("firestore_unavailable")
        findings.append(finding("CLOUD_FIRESTORE_UNAVAILABLE", WARN, err or "Firestore unavailable"))
        return {
            "collection_mode": "unavailable",
            "status": WARN,
            "score": 0,
            "metrics": [],
            "findings": findings,
            "hard_gates": hard_gates,
            "degradations": degradations,
        }

    qcol = args.firestore_queue_collection
    scol = args.firestore_state_collection
    ecol = args.firestore_ingest_errors_collection

    unacked = 0
    oldest = None
    mid_counts = {}
    machine_missing = 0
    try:
        for d in client.collection(qcol).stream():
            data = d.to_dict() or {}
            if not data.get("acked", False):
                unacked += 1
                c = data.get("created_at")
                if hasattr(c, "timestamp"):
                    ts = int(c.timestamp())
                    oldest = ts if oldest is None else min(oldest, ts)
            mid = data.get("message_id")
            if mid:
                mid_counts[mid] = mid_counts.get(mid, 0) + 1
            if not str(data.get("machine_id", "") or "").strip():
                machine_missing += 1
    except Exception as exc:
        degradations.append("queues_query_failed")
        findings.append(finding("CLOUD_QUEUES_QUERY_FAILED", WARN, str(exc)))

    t = thresholds.get("cloud.unacked_queue_count", {})
    metrics.append(eval_numeric_max("cloud.unacked_queue_count", unacked, t.get("pass_max", 20), t.get("warn_max", 100)))
    age = MISSING
    if oldest is not None:
        age = round((int(time.time()) - oldest) / 60.0, 2)
    t = thresholds.get("cloud.oldest_unacked_age_minutes", {})
    metrics.append(eval_numeric_max("cloud.oldest_unacked_age_minutes", age, t.get("pass_max", 30), t.get("warn_max", 120)))

    dup = sum(1 for _, c in mid_counts.items() if c > 1)
    t = thresholds.get("cloud.duplicate_message_id_count", {})
    metrics.append(eval_numeric_max("cloud.duplicate_message_id_count", dup, t.get("pass_max", 0), t.get("warn_max", 2)))

    if machine_missing == 0:
        metrics.append(metric_result("cloud.machine_id_missing_count", PASS, 0))
    else:
        metrics.append(metric_result("cloud.machine_id_missing_count", FAIL, machine_missing))
        hard_gates.append("cloud.machine_id_missing_count>0")

    watch_hours = MISSING
    try:
        doc = client.collection(scol).document("gmail").get()
        if doc.exists:
            upd = (doc.to_dict() or {}).get("updated_at")
            if hasattr(upd, "timestamp"):
                watch_hours = round((int(time.time()) - int(upd.timestamp())) / 3600.0, 2)
    except Exception:
        pass
    t = thresholds.get("cloud.watch_freshness_hours", {})
    metrics.append(eval_numeric_max("cloud.watch_freshness_hours", watch_hours, t.get("pass_max", 8), t.get("warn_max", 24)))

    # Gate-style readiness metric from preprocessor gate helper.
    try:
        from cloud.orchestrator.preprocessor_gate import _query_preprocessor_gate
        gate_metrics, gate_err = _query_preprocessor_gate(project_id, qcol, scol, ecol)
    except Exception:
        gate_metrics, gate_err = None, 'preprocessor gate helper unavailable'

    if gate_metrics is None:
        metrics.append(metric_result("cloud.unique_shadow_processed_count", WARN, MISSING, gate_err or "unavailable"))
        degradations.append("preprocessor_gate_unavailable")
    else:
        t = thresholds.get("cloud.unique_shadow_processed_count", {})
        metrics.append(eval_numeric_min(
            "cloud.unique_shadow_processed_count",
            int(gate_metrics.unique_shadow_processed_count),
            t.get("pass_min", 50),
            t.get("warn_min", 25),
        ))

    known_codes, known_source = _known_reject_codes_and_source()
    unknown_codes = 0
    unhandled = 0
    cleanup_partial = 0
    try:
        for d in client.collection(ecol).stream():
            data = d.to_dict() or {}
            code = str(data.get("reject_code", "") or "")
            if code in ("unhandled_exception", "processor_unhandled_exception"):
                unhandled += 1
            if data.get("cleanup_partial_failure"):
                cleanup_partial += 1
            if code and code not in known_codes:
                unknown_codes += 1
    except Exception as exc:
        degradations.append("ingest_errors_query_failed")
        findings.append(finding("CLOUD_INGEST_ERRORS_QUERY_FAILED", WARN, str(exc)))
    if known_source != "authoritative":
        findings.append(finding("CLOUD_REJECT_CODE_SOURCE_FALLBACK", WARN,
                                "Using fallback known reject code list; verify cloud.orchestrator.reject_codes import path."))

    if unknown_codes > 0:
        metrics.append(metric_result("cloud.unknown_reject_code_count_24h", FAIL, unknown_codes))
        hard_gates.append("cloud.unknown_reject_code_count_24h>0")
    else:
        metrics.append(metric_result("cloud.unknown_reject_code_count_24h", PASS, 0))
    t = thresholds.get("cloud.unhandled_exception_count_24h", {})
    metrics.append(eval_numeric_max("cloud.unhandled_exception_count_24h", unhandled, t.get("pass_max", 0), t.get("warn_max", 3)))
    t = thresholds.get("cloud.cleanup_partial_failure_count_24h", {})
    metrics.append(eval_numeric_max("cloud.cleanup_partial_failure_count_24h", cleanup_partial, t.get("pass_max", 0), t.get("warn_max", 2)))

    # optional health probe
    hp_mode = args.health_probe_mode
    health_status = None
    if hp_mode == "off":
        health_status = metric_result("cloud.health_endpoint", PASS, "not_scored", "probe_off")
    else:
        health_url = args.health_url or os.environ.get("MEDICAFE_HEALTH_URL", "")
        if not health_url:
            if hp_mode == "required":
                health_status = metric_result("cloud.health_endpoint", FAIL, MISSING, "missing_url")
                hard_gates.append("health_probe_required_missing_url")
            else:
                health_status = metric_result("cloud.health_endpoint", WARN, MISSING, "missing_url")
        elif urlopen is None:
            health_status = metric_result("cloud.health_endpoint", FAIL if hp_mode == "required" else WARN, MISSING, "urllib_unavailable")
        else:
            try:
                resp = urlopen(health_url, timeout=int(args.health_probe_timeout_sec))
                raw = resp.read().decode("utf-8", "replace")
                data = json.loads(raw)
                ok = str(data.get("status", "")).lower() in ("ok", "pass", "healthy") and bool(data.get("config_loaded", False))
                health_status = metric_result("cloud.health_endpoint", PASS if ok else WARN, data.get("status", ""))
                if hp_mode == "required" and not ok:
                    hard_gates.append("health_probe_required_bad_contract")
            except Exception as exc:
                health_status = metric_result("cloud.health_endpoint", FAIL if hp_mode == "required" else WARN, MISSING, str(exc))
                if hp_mode == "required":
                    hard_gates.append("health_probe_required_failed")
    metrics.append(health_status)

    status = worst_status(metrics)
    if hard_gates:
        status = FAIL
    return {
        "collection_mode": "full",
        "status": status,
        "score": score_from_metrics(metrics),
        "metrics": sorted(metrics, key=lambda x: x["key"]),
        "findings": sorted(findings, key=lambda x: ({FAIL: 0, WARN: 1, PASS: 2}.get(x["severity"], 3), x["code"])),
        "hard_gates": hard_gates,
        "degradations": degradations,
    }


def compute_overall(scope, xp, cloud, fail_on, cloud_required=False, migration_stage="xp_validation"):
    migration_stage = normalize_migration_stage(migration_stage)
    surfaces = {}
    degradations = []
    statuses = []
    scores = []
    hard = []
    included_surfaces = []
    excluded_surfaces = []

    gate_xp = scope in ("xp", "both")
    gate_cloud = scope == "cloud" or (scope == "both" and (migration_stage != "xp_validation" or cloud_required))

    if xp is not None:
        surfaces["xp_local"] = xp
        if gate_xp:
            statuses.append(xp["status"])
            scores.append(xp.get("score", 0))
            hard.extend(xp.get("hard_gates", []))
            included_surfaces.append("xp_local")
        else:
            excluded_surfaces.append("xp_local")
    if cloud is not None:
        surfaces["cloud"] = cloud
        if gate_cloud:
            statuses.append(cloud["status"])
            scores.append(cloud.get("score", 0))
            hard.extend(cloud.get("hard_gates", []))
            included_surfaces.append("cloud")
        else:
            excluded_surfaces.append("cloud")
        for d in cloud.get("degradations", []):
            degradations.append({"surface": "cloud", "reason": d})

    overall_status = worst_status(statuses) if statuses else WARN
    overall_score = int(round(float(sum(scores)) / float(len(scores)))) if scores else 0

    if gate_cloud and scope in ("cloud", "both") and cloud is not None and cloud.get("collection_mode") == "unavailable":
        overall_status = WARN if not cloud_required else FAIL
    if hard:
        overall_status = FAIL

    exit_code = 0
    if overall_status == FAIL:
        exit_code = 1
    elif overall_status == WARN and fail_on == "warn":
        exit_code = 1

    return {
        "status": overall_status,
        "score": overall_score,
        "exit_code": exit_code,
        "surfaces": surfaces,
        "degradations": degradations,
        "hard_gates": hard,
        "gating": {
            "migration_stage": migration_stage,
            "included_surfaces": included_surfaces,
            "excluded_surfaces": excluded_surfaces,
        },
    }


def render_text(payload):
    lines = []
    lines.append("AUDIT MIGRATION HEALTH")
    lines.append("run_id={0} scope={1} stage={2}".format(
        payload["run_id"],
        payload["scope"],
        payload.get("migration_stage", "unknown"),
    ))
    lines.append("overall: status={0} score={1} exit_code={2}".format(payload["overall"]["status"], payload["overall"]["score"], payload["overall"]["exit_code"]))
    gating = payload.get("gating", {}) if isinstance(payload.get("gating", {}), dict) else {}
    included = gating.get("included_surfaces", []) if isinstance(gating.get("included_surfaces", []), list) else []
    excluded = gating.get("excluded_surfaces", []) if isinstance(gating.get("excluded_surfaces", []), list) else []
    lines.append("gating: included={0} excluded={1}".format(
        ",".join(included) if included else "-",
        ",".join(excluded) if excluded else "-",
    ))
    for surface in ("xp_local", "cloud"):
        s = payload.get("surfaces", {}).get(surface)
        if not s:
            continue
        lines.append("[{0}] status={1} score={2} mode={3}".format(surface, s.get("status"), s.get("score"), s.get("collection_mode", "n/a")))
        for m in s.get("metrics", []):
            lines.append("  - {0}: {1} ({2})".format(m.get("key"), m.get("status"), m.get("value")))
        for f in s.get("findings", []):
            lines.append("  ! {0} {1}: {2}".format(f.get("severity"), f.get("code"), f.get("message")))
    if payload.get("degradations"):
        lines.append("degradations:")
        for d in payload["degradations"]:
            lines.append("  - {0}: {1}".format(d.get("surface"), d.get("reason")))
    return "\n".join(lines)


def write_reports(payload, text, lab_dir, output_prefix, include_metric_details):
    reports_dir = ensure_reports_dir(lab_dir)
    rid = payload["run_id"]
    sum_json = os.path.join(reports_dir, "{0}_summary_{1}.json".format(output_prefix, rid))
    sum_txt = os.path.join(reports_dir, "{0}_summary_{1}.txt".format(output_prefix, rid))
    with open(sum_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    with open(sum_txt, "w", encoding="utf-8") as f:
        f.write(text)
    out = [sum_json, sum_txt]
    if include_metric_details:
        det_json = os.path.join(reports_dir, "{0}_metrics_{1}.json".format(output_prefix, rid))
        details = {
            "xp_metrics": payload.get("surfaces", {}).get("xp_local", {}).get("metrics", []),
            "cloud_metrics": payload.get("surfaces", {}).get("cloud", {}).get("metrics", []),
        }
        with open(det_json, "w", encoding="utf-8") as f:
            json.dump(details, f, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        out.append(det_json)
    return out


def build_parser():
    default_stage = normalize_migration_stage(os.environ.get("MEDICAFE_MIGRATION_STAGE", "xp_validation"))
    p = argparse.ArgumentParser(description="Audit migration health for XP and cloud surfaces")
    p.add_argument("--scope", choices=["xp", "cloud", "both"], default="both")
    p.add_argument("--migration-stage", choices=MIGRATION_STAGES, default=default_stage)
    p.add_argument("--lab-dir", default="")
    p.add_argument("--project-id", default="")
    p.add_argument("--firestore-queue-collection", default="queues")
    p.add_argument("--firestore-state-collection", default="sync_state")
    p.add_argument("--firestore-ingest-errors-collection", default="ingest_errors")
    p.add_argument("--threshold-profile", choices=["default", "strict", "relaxed"], default="default")
    p.add_argument("--threshold-file", default="")
    p.add_argument("--threshold-override", action="append", default=[])
    p.add_argument("--fail-on", choices=["fail", "warn"], default="fail")
    p.add_argument("--cloud-required", action="store_true")
    p.add_argument("--read-timeout-sec", type=int, default=20)
    p.add_argument("--health-probe-mode", choices=["off", "best_effort", "required"], default="off")
    p.add_argument("--health-probe-timeout-sec", type=int, default=5)
    p.add_argument("--health-url", default="")
    p.add_argument("--output-mode", choices=["stdout", "write", "both"], default="stdout")
    p.add_argument("--output-prefix", default="audit_migration_health")
    p.add_argument("--run-id", default="")
    p.add_argument("--include-metric-details", action="store_true", default=True)
    p.add_argument("--no-metric-details", action="store_false", dest="include_metric_details")
    p.add_argument("--json", action="store_true", default=True)
    p.add_argument("--no-json", action="store_false", dest="json")
    p.add_argument("--text", action="store_true", default=True)
    p.add_argument("--no-text", action="store_false", dest="text")
    p.add_argument("--verbose", action="store_true")
    return p


def run(args):
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    lab_dir = resolve_lab_root(args.lab_dir, repo_root)
    migration_stage = normalize_migration_stage(getattr(args, "migration_stage", "xp_validation"))

    try:
        resolved_thresholds = resolve_thresholds(args.threshold_profile, args.threshold_file, args.threshold_override)
    except Exception as exc:
        sys.stderr.write("audit_migration_health: threshold configuration error: {0}\n".format(exc))
        return 2

    xp = None
    cloud = None

    if args.scope in ("xp", "both"):
        xp = collect_xp(lab_dir, resolved_thresholds, migration_stage=migration_stage)

    if args.scope in ("cloud", "both"):
        cloud = collect_cloud(args, resolved_thresholds)

    overall = compute_overall(
        args.scope,
        xp,
        cloud,
        args.fail_on,
        cloud_required=args.cloud_required,
        migration_stage=migration_stage,
    )

    if args.scope == "cloud" and cloud is not None and cloud.get("collection_mode") == "unavailable" and args.cloud_required:
        overall["exit_code"] = 3
    if args.scope == "both" and cloud is not None and cloud.get("collection_mode") == "unavailable" and args.cloud_required:
        overall["exit_code"] = 3

    payload = {
        "tool": "audit_migration_health",
        "version": "v1",
        "run_id": args.run_id or make_run_id(),
        "generated_at_utc": iso_utc_now(),
        "scope": args.scope,
        "migration_stage": migration_stage,
        "collection_mode": {
            "xp": "full" if xp is not None else "not_requested",
            "cloud": (cloud or {}).get("collection_mode", "not_requested"),
        },
        "overall": {
            "status": overall["status"],
            "score": overall["score"],
            "exit_code": overall["exit_code"],
        },
        "surfaces": overall["surfaces"],
        "degradations": overall["degradations"],
        "gating": overall.get("gating", {}),
        "threshold_profile": args.threshold_profile,
        "resolved_thresholds": resolved_thresholds,
    }

    text = render_text(payload)
    if args.output_mode in ("write", "both"):
        payload["artifacts"] = write_reports(payload, text, lab_dir, args.output_prefix, args.include_metric_details)

    if args.json:
        print(json.dumps(payload, ensure_ascii=True, sort_keys=True))
    if args.text:
        print(text)
    return overall["exit_code"]


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return run(args)
    except SystemExit:
        raise
    except Exception as exc:
        sys.stderr.write("audit_migration_health: unhandled error: {0}\n".format(exc))
        return 4


if __name__ == "__main__":
    sys.exit(main())
