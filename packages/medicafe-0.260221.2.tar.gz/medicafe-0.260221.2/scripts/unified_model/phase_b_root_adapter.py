#!/usr/bin/env python
"""
Phase B XP local filesystem adapter: resolve_roots() and iter_candidates().
Config/crosswalk parsing lives here; Layer A consumes candidates only.
Hash policy executed here; Layer A consumes sha256/hash_mode from CandidateArtifact.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_b_common import (
    CandidateArtifact,
    HASH_MODE_ERROR,
    HASH_MODE_FULL,
    HASH_MODE_SAMPLED,
    HASH_MODE_SKIPPED_LARGE,
    ResolvedRootSpec,
)

# Hash policy env defaults
DEFAULT_MAX_FULL_HASH_BYTES = 50 * 1024 * 1024  # 50MB
DEFAULT_SAMPLED_CHUNK_BYTES = 65536  # 64KB
DEFAULT_SKIP_LARGE_BYTES = 200 * 1024 * 1024  # 200MB (beyond this: skipped_large)
TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")


def _env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in TRUE_ENV_VALUES


def _workspace_root_from_lab(lab_root):
    """Workspace root: parent of lab/ when lab_root ends with lab."""
    lab_root = os.path.abspath(lab_root)
    parent = os.path.dirname(lab_root)
    if os.path.basename(lab_root).lower() == "lab":
        return parent
    return parent


def _load_config_crosswalk(workspace_root):
    """Load config and crosswalk JSON. Returns (config, crosswalk). Uses defaults if missing."""
    config_path = os.path.join(workspace_root, "json", "config.json")
    crosswalk_path = os.path.join(workspace_root, "json", "crosswalk.json")
    env_config = os.environ.get("MEDICAFE_CONFIG_FILE", "").strip()
    if env_config:
        config_path = os.path.abspath(env_config)
        env_crosswalk = os.environ.get("MEDICAFE_CROSSWALK_FILE", "").strip()
        crosswalk_path = (
            os.path.abspath(env_crosswalk)
            if env_crosswalk
            else os.path.join(os.path.dirname(config_path), "crosswalk.json")
        )
    config = {}
    crosswalk = {}
    try:
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
    except Exception:
        pass
    try:
        if os.path.exists(crosswalk_path):
            with open(crosswalk_path, "r", encoding="utf-8") as f:
                crosswalk = json.load(f)
    except Exception:
        pass
    return config, crosswalk


def _get_medi_config(config):
    """Extract MediLink_Config dict."""
    return config.get("MediLink_Config", config) if isinstance(config, dict) else {}


def _compute_config_fingerprint(config):
    """
    Hash of root-relevant values for audit. Uses same source logic as resolve_roots:
    - inputFilePath, outputFilePath: config (top-level)
    - medisoft_claims_directory: medi or config
    - local_storage_path, local_claims_path, Z_DAT_PATH: medi
    """
    if not isinstance(config, dict):
        return ""
    medi = _get_medi_config(config)
    stable = {}
    # Top-level keys used directly by resolver
    for k in ("inputFilePath", "outputFilePath"):
        val = config.get(k)
        if val is not None:
            stable[k] = val
    # medi-or-config (resolver: medi.get or config.get)
    val = medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory")
    if val is not None:
        stable["medisoft_claims_directory"] = val
    # medi-only keys
    for k in ("local_storage_path", "local_claims_path", "Z_DAT_PATH"):
        val = medi.get(k)
        if val is not None:
            stable[k] = val
    stable["_top_keys"] = sorted(config.keys())
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _compute_crosswalk_fingerprint(crosswalk):
    """Hash of key structure for audit."""
    if not isinstance(crosswalk, dict):
        return ""
    stable = {"_keys": sorted(crosswalk.keys())}
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _resolve_path(raw, workspace_root, default=""):
    """Resolve path; if relative, join with workspace_root."""
    if not raw or not isinstance(raw, str):
        return default
    raw = raw.strip()
    if not raw:
        return default
    if os.path.isabs(raw):
        return os.path.normpath(raw)
    return os.path.normpath(os.path.join(workspace_root, raw))


def _classify_file(rel_path):
    """
    First-match wins classification. rel_path is relative to root.
    Returns artifact_class string, or None if file type is out-of-scope for discovery.
    """
    rel_lower = rel_path.lower().replace("\\", "/")
    name = os.path.basename(rel_path)
    name_lower = name.lower()
    # Ordered rules per plan 2.4
    if ".837" in name_lower or "837" in name_lower:
        return "837"
    if "remittance" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "posting" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "submission" in rel_lower and "index" in rel_lower and rel_lower.endswith(".jsonl"):
        return "receipt"
    if name_lower in ("z.dat", "zm.dat") or name_lower.endswith(".dat"):
        return "dat"
    if name_lower.endswith(".docx"):
        return "docx"
    if name_lower.endswith(".csv"):
        return "csv"
    if name_lower.endswith(".xml"):
        return "xml"
    return None


def _compute_hash(path, size_bytes):
    """
    Hash policy: full/sampled/skipped_large/error.
    Returns (sha256_hex, hash_mode, warnings_list).
    """
    max_full = int(
        os.environ.get("MEDICAFE_PHASE_B_MAX_FULL_HASH_BYTES", str(DEFAULT_MAX_FULL_HASH_BYTES))
    )
    chunk_size = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SAMPLED_HASH_CHUNK_BYTES", str(DEFAULT_SAMPLED_CHUNK_BYTES)
        )
    )
    skip_large = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SKIP_LARGE_BYTES", str(DEFAULT_SKIP_LARGE_BYTES)
        )
    )
    if size_bytes > skip_large:
        return ("", HASH_MODE_SKIPPED_LARGE, [])
    try:
        if size_bytes <= max_full:
            with open(path, "rb") as f:
                data = f.read()
            h = hashlib.sha256(data)
            return (h.hexdigest(), HASH_MODE_FULL, [])
        # Sampled
        offsets = [
            0,
            max(0, size_bytes // 4 - chunk_size // 2),
            max(0, size_bytes // 2 - chunk_size // 2),
            max(0, (3 * size_bytes) // 4 - chunk_size // 2),
            max(0, size_bytes - chunk_size),
        ]
        chunks = []
        with open(path, "rb") as f:
            for off in offsets:
                off = min(off, max(0, size_bytes - chunk_size))
                f.seek(off)
                chunks.append(f.read(chunk_size))
        h = hashlib.sha256(b"".join(chunks))
        return (h.hexdigest(), HASH_MODE_SAMPLED, [])
    except Exception as e:
        return ("", HASH_MODE_ERROR, [str(e)])


def resolve_roots(lab_root):
    """
    Resolve discovery roots from config + crosswalk + runtime env.
    Returns list of ResolvedRootSpec. Never generic workspace fallback.
    """
    workspace_root = _workspace_root_from_lab(lab_root)
    config, crosswalk = _load_config_crosswalk(workspace_root)
    medi = _get_medi_config(config)
    # Contract allowlist keys (from config)
    local_storage = _resolve_path(
        medi.get("local_storage_path"), workspace_root, ""
    )
    local_claims = _resolve_path(
        medi.get("local_claims_path"), workspace_root, ""
    )
    z_dat = _resolve_path(medi.get("Z_DAT_PATH"), workspace_root, "")
    input_fp = _resolve_path(config.get("inputFilePath"), workspace_root, "")
    output_fp = _resolve_path(config.get("outputFilePath"), workspace_root, "")
    medisoft_claims = _resolve_path(
        medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory"),
        workspace_root,
        "",
    )
    # Adapter runtime roots (env); resolve relative to workspace if needed
    target_folder = os.environ.get("target_folder", "").strip()
    source_folder = os.environ.get("source_folder", "").strip()
    if target_folder and not os.path.isabs(target_folder):
        target_folder = os.path.normpath(os.path.join(workspace_root, target_folder))
    if source_folder and not os.path.isabs(source_folder):
        source_folder = os.path.normpath(os.path.join(workspace_root, source_folder))
    include_staging = _env_flag("MEDICAFE_PHASE_B_INCLUDE_STAGING_SOURCE", False)
    include_xml = _env_flag("MEDICAFE_PHASE_B_INCLUDE_XML", False)

    roots = []
    # csv: target_folder (default); source_folder if staging
    csv_root = target_folder if target_folder else (local_storage and os.path.join(local_storage, "CSV"))
    if not csv_root and local_storage:
        csv_root = os.path.join(local_storage, "CSV")
    if csv_root:
        roots.append(
            ResolvedRootSpec(
                source_id="csv_target",
                root_path=os.path.abspath(csv_root),
                artifact_classes=["csv"],
                scope="operational",
            )
        )
    if include_staging and source_folder:
        roots.append(
            ResolvedRootSpec(
                source_id="csv_staging",
                root_path=os.path.abspath(source_folder),
                artifact_classes=["csv"],
                scope="staging",
            )
        )
    # docx: source_folder if staging else target_folder or local_storage
    docx_root = source_folder if include_staging else (target_folder or local_storage)
    if not docx_root:
        docx_root = local_storage
    if docx_root:
        roots.append(
            ResolvedRootSpec(
                source_id="docx",
                root_path=os.path.abspath(docx_root),
                artifact_classes=["docx"],
                scope="staging" if include_staging else "operational",
            )
        )
    # dat: Z_DAT_PATH, inputFilePath; fallback local_claims_path
    dat_roots = []
    if z_dat:
        dat_roots.append(z_dat)
    if input_fp and os.path.isdir(input_fp):
        dat_roots.append(input_fp)
    elif input_fp:
        dat_roots.append(os.path.dirname(input_fp))
    if not dat_roots and local_claims:
        dat_roots.append(local_claims)
    for i, r in enumerate(dat_roots):
        if r and os.path.exists(r):
            roots.append(
                ResolvedRootSpec(
                    source_id="dat_{0}".format(i),
                    root_path=os.path.abspath(r),
                    artifact_classes=["dat"],
                    scope="operational",
                )
            )
            break
    # jsonl, receipt: local_storage; fallback local_claims
    jsonl_root = local_storage or local_claims
    if jsonl_root:
        roots.append(
            ResolvedRootSpec(
                source_id="jsonl",
                root_path=os.path.abspath(jsonl_root),
                artifact_classes=["jsonl", "receipt"],
                scope="operational",
            )
        )
    # 837: medisoft_claims_directory, outputFilePath; fallback local_claims
    e837_roots = []
    if medisoft_claims:
        e837_roots.append(medisoft_claims)
    if output_fp and os.path.isdir(output_fp):
        e837_roots.append(output_fp)
    elif output_fp:
        e837_roots.append(os.path.dirname(output_fp))
    if not e837_roots and local_claims:
        e837_roots.append(local_claims)
    for i, r in enumerate(e837_roots):
        if r and os.path.exists(r):
            classes = ["837", "receipt"]
            if include_xml:
                classes.append("xml")
            roots.append(
                ResolvedRootSpec(
                    source_id="837_{0}".format(i),
                    root_path=os.path.abspath(r),
                    artifact_classes=classes,
                    scope="operational",
                )
            )
            break
    # receipt: local_storage (if not already covered)
    if local_storage and not any(rs.source_id == "jsonl" for rs in roots):
        roots.append(
            ResolvedRootSpec(
                source_id="receipt",
                root_path=os.path.abspath(local_storage),
                artifact_classes=["receipt"],
                scope="operational",
            )
        )
    config_hash = _compute_config_fingerprint(config)
    crosswalk_hash = _compute_crosswalk_fingerprint(crosswalk)
    return roots, config_hash, crosswalk_hash


def iter_candidates(root_spec):
    """
    Yield CandidateArtifact for each file under root_spec.
    Adapter performs os.walk, stat, hash. Layer A consumes only.
    Walks each root once; classifies per file using artifact_classes as hint.
    """
    root_path = root_spec.root_path
    if not os.path.isdir(root_path):
        return
    follow_symlinks = _env_flag("MEDICAFE_PHASE_B_FOLLOW_SYMLINKS", False)
    for dirpath, _dirnames, filenames in os.walk(root_path, followlinks=follow_symlinks):
        for fn in filenames:
                full_path = os.path.join(dirpath, fn)
                if not os.path.isfile(full_path):
                    continue
                try:
                    st = os.stat(full_path)
                except (OSError, IOError):
                    continue
                size_bytes = st.st_size
                mtime_epoch = int(st.st_mtime)
                rel = os.path.relpath(full_path, root_path)
                rel_norm = rel.replace("\\", "/")
                if sys.platform == "win32":
                    rel_norm = rel_norm.lower()
                artifact_class = _classify_file(rel_norm)
                if artifact_class is None:
                    continue
                if artifact_class not in root_spec.artifact_classes:
                    continue
                sha256_hex, hash_mode, warnings = _compute_hash(full_path, size_bytes)
                canonical_key = os.path.normcase(os.path.abspath(full_path))
                yield CandidateArtifact(
                    source_id=root_spec.source_id,
                    canonical_key=canonical_key,
                    normalized_path=rel_norm,
                    size_bytes=size_bytes,
                    mtime_epoch=mtime_epoch,
                    sha256=sha256_hex,
                    hash_mode=hash_mode,
                    artifact_class=artifact_class,
                    scope=root_spec.scope,
                    warnings=warnings,
                    locator=full_path,
                )
