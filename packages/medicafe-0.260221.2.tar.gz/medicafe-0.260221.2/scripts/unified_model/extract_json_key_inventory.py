#!/usr/bin/env python
"""
Extract key-path and type inventory from JSON files without outputting values.

Outputs one CSV per input JSON with these columns:
  - key_path
  - value_type
  - depth
  - occurrences
  - is_container

XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import argparse
import csv
import json
import os
import sys


def json_type(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "number"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, str):
        return "string"
    return "unknown"


def escape_pointer_token(token):
    # JSON Pointer escaping
    return token.replace("~", "~0").replace("/", "~1")


def append_object_path(parent_path, key):
    if parent_path == "$":
        return "$/" + escape_pointer_token(key)
    return parent_path + "/" + escape_pointer_token(key)


def append_array_path(parent_path):
    return parent_path + "/[]"


def path_depth(path):
    if path == "$":
        return 0
    return len(path.split("/")) - 1


def walk(node, path, stats):
    node_type = json_type(node)
    stat_key = (path, node_type)
    if stat_key not in stats:
        stats[stat_key] = {
            "key_path": path,
            "value_type": node_type,
            "depth": path_depth(path),
            "occurrences": 0,
            "is_container": "1" if node_type in ("object", "array") else "0",
        }
    stats[stat_key]["occurrences"] += 1

    if node_type == "object":
        for key in sorted(node.keys()):
            child_path = append_object_path(path, key)
            walk(node[key], child_path, stats)
    elif node_type == "array":
        array_item_path = append_array_path(path)
        for item in node:
            walk(item, array_item_path, stats)


def write_csv(rows, out_path):
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["key_path", "value_type", "depth", "occurrences", "is_container"],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def summarize(rows):
    by_type = {}
    for row in rows:
        t = row["value_type"]
        by_type[t] = by_type.get(t, 0) + 1
    return by_type


def main():
    p = argparse.ArgumentParser(
        description="Extract key-path and type inventory from JSON files (no values output)."
    )
    p.add_argument(
        "--input",
        dest="inputs",
        action="append",
        required=True,
        help="Input JSON path. Can be passed multiple times.",
    )
    p.add_argument(
        "--out-dir",
        required=True,
        help="Output directory for inventory CSV files.",
    )
    args = p.parse_args()

    out_dir = os.path.abspath(args.out_dir)
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    overall_summary = []
    for input_path in args.inputs:
        abs_input = os.path.abspath(input_path)
        if not os.path.exists(abs_input):
            print("Missing input: {0}".format(abs_input), file=sys.stderr)
            return 1

        try:
            with open(abs_input, "r", encoding="utf-8") as f:
                doc = json.load(f)
        except Exception as e:
            print("Failed to parse JSON: {0} ({1})".format(abs_input, e), file=sys.stderr)
            return 1

        stats = {}
        walk(doc, "$", stats)
        rows = sorted(
            list(stats.values()),
            key=lambda r: (r["key_path"], r["value_type"]),
        )

        stem = os.path.splitext(os.path.basename(abs_input))[0]
        out_csv = os.path.join(out_dir, "{0}_key_inventory.csv".format(stem))
        write_csv(rows, out_csv)

        type_summary = summarize(rows)
        overall_summary.append({
            "file": abs_input,
            "rows": len(rows),
            "types": type_summary,
            "output_csv": out_csv,
        })

    print("Key inventory extraction complete.")
    for item in overall_summary:
        print("- file: {0}".format(item["file"]))
        print("  rows: {0}".format(item["rows"]))
        print("  types: {0}".format(item["types"]))
        print("  output: {0}".format(item["output_csv"]))

    return 0


if __name__ == "__main__":
    sys.exit(main())
