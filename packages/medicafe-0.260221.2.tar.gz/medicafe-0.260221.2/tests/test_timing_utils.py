# tests/test_timing_utils.py
"""Tests for MediCafe.timing_utils - structured timing telemetry."""
from __future__ import absolute_import
import os
import sys
import json
import tempfile
import shutil
import unittest

# Enable timing so record_stage writes (tests need to verify serialization)
os.environ['MEDICAFE_PERFORMANCE_LOGGING'] = '1'

# Add project root to path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


class TestTimingUtils(unittest.TestCase):

    def test_event_serialization(self):
        """record_stage produces valid JSONL with required keys and timestamp-N format."""
        from MediCafe.timing_utils import start_run, record_stage
        tmpdir = tempfile.mkdtemp()
        try:
            run_id = start_run('medilink', storage_path=tmpdir)
            record_stage(run_id, 'medilink', 'config_load', 100, 'ok')
            path = os.path.join(tmpdir, 'timing_history.jsonl')
            self.assertTrue(os.path.exists(path))
            with open(path, 'r') as f:
                line = f.read().strip()
            ev = json.loads(line)
            self.assertEqual(ev.get('run_id'), run_id)
            self.assertEqual(ev.get('workflow'), 'medilink')
            self.assertEqual(ev.get('stage'), 'config_load')
            self.assertEqual(ev.get('duration_ms'), 100)
            self.assertEqual(ev.get('status'), 'ok')
            self.assertIn('timestamp_utc', ev)
            self.assertIn('-', run_id)
            self.assertEqual(run_id.count('-'), 1)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_compute_summary_last_run(self):
        """by_workflow last_run_total_ms is sum of duration_ms for last run_id."""
        from MediCafe.timing_utils import compute_summary
        events = [
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'a', 'duration_ms': 50},
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'b', 'duration_ms': 30},
            {'run_id': 'r2', 'workflow': 'medilink', 'stage': 'a', 'duration_ms': 100},
            {'run_id': 'r2', 'workflow': 'medilink', 'stage': 'b', 'duration_ms': 50},
        ]
        summary = compute_summary(events)
        self.assertEqual(summary['by_workflow']['medilink']['last_run_total_ms'], 150)

    def test_compute_summary_slowest_stage(self):
        """slowest_stage is (stage_name, duration_ms) for max duration."""
        from MediCafe.timing_utils import compute_summary
        events = [
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'A', 'duration_ms': 100},
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'B', 'duration_ms': 500},
        ]
        summary = compute_summary(events)
        self.assertEqual(summary['by_workflow']['medilink']['slowest_stage'], ('B', 500))

    def test_compute_regression_insufficient_data(self):
        """Fewer than 2 runs returns (None, None)."""
        from MediCafe.timing_utils import compute_summary, compute_regression
        events = [{'run_id': 'r1', 'workflow': 'medilink', 'stage': 'a', 'duration_ms': 100}]
        summary = compute_summary(events)
        delta, baseline = compute_regression(summary, 'medilink', baseline_runs=5)
        self.assertIsNone(delta)
        self.assertIsNone(baseline)

    def test_compute_regression_delta(self):
        """6 runs: last=200ms, previous 5 ~100ms -> delta ~100, baseline ~100."""
        from MediCafe.timing_utils import compute_summary, compute_regression
        events = []
        for i, rid in enumerate(['r1', 'r2', 'r3', 'r4', 'r5', 'r6']):
            total = 100 if i < 5 else 200
            events.append({'run_id': rid, 'workflow': 'medilink', 'stage': 'a', 'duration_ms': total})
        summary = compute_summary(events)
        delta, baseline = compute_regression(summary, 'medilink', baseline_runs=5)
        self.assertIsNotNone(delta)
        self.assertLess(abs(delta - 100), 1)
        self.assertLess(abs(baseline - 100), 1)

    def test_rotation_cap(self):
        """Appending beyond cap truncates to 500 lines."""
        from MediCafe.timing_utils import start_run, record_stage
        tmpdir = tempfile.mkdtemp()
        try:
            run_id = start_run('medilink', storage_path=tmpdir)
            for i in range(600):
                record_stage(run_id, 'medilink', 'stage_{}'.format(i), 1)
            path = os.path.join(tmpdir, 'timing_history.jsonl')
            with open(path, 'r') as f:
                lines = f.readlines()
            self.assertLessEqual(len(lines), 500)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_load_recent_events_skips_malformed(self):
        """Malformed lines are skipped; valid lines returned."""
        from MediCafe.timing_utils import load_recent_events
        tmpdir = tempfile.mkdtemp()
        try:
            path = os.path.join(tmpdir, 'timing_history.jsonl')
            with open(path, 'w') as f:
                f.write('{"run_id":"r1","workflow":"medilink","stage":"a","duration_ms":1,"timestamp_utc":"2026-01-01T00:00:00Z","status":"ok"}\n')
                f.write('\n')
                f.write('{invalid\n')
                f.write('{"run_id":"r2","workflow":"medilink","stage":"b","duration_ms":2,"timestamp_utc":"2026-01-01T00:00:01Z","status":"ok"}\n')
            events = load_recent_events(storage_path=tmpdir)
            self.assertEqual(len(events), 2)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_dedupe_nested_stages(self):
        """config_loader: load_total + path_resolution -> total excludes child (200, not 210)."""
        from MediCafe.timing_utils import compute_summary
        events = [
            {'run_id': 'r1', 'workflow': 'config_loader', 'stage': 'load_total', 'duration_ms': 200},
            {'run_id': 'r1', 'workflow': 'config_loader', 'stage': 'path_resolution', 'duration_ms': 10},
        ]
        summary = compute_summary(events)
        self.assertEqual(summary['by_workflow']['config_loader']['last_run_total_ms'], 200)

    def test_dedupe_medilink_submission(self):
        """medilink: submission_flow + patient_data -> total excludes child (100, not 150)."""
        from MediCafe.timing_utils import compute_summary
        events = [
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'submission_flow', 'duration_ms': 100},
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'patient_data', 'duration_ms': 50},
        ]
        summary = compute_summary(events)
        self.assertEqual(summary['by_workflow']['medilink']['last_run_total_ms'], 100)

    def test_dedupe_medilink_file_detection(self):
        """medilink: file_detection + detection_total -> total excludes child (80, not 160)."""
        from MediCafe.timing_utils import compute_summary
        events = [
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'file_detection', 'duration_ms': 80},
            {'run_id': 'r1', 'workflow': 'medilink', 'stage': 'detection_total', 'duration_ms': 80},
        ]
        summary = compute_summary(events)
        self.assertEqual(summary['by_workflow']['medilink']['last_run_total_ms'], 80)

    def test_format_summary_empty(self):
        """Empty events: no crash, sensible output."""
        from MediCafe.timing_utils import compute_summary, format_summary_for_display
        summary = compute_summary([])
        lines = format_summary_for_display(summary)
        self.assertIsInstance(lines, list)

    def test_noop_timer_context_manager(self):
        """noop_timer is a valid no-op context manager (does not raise, does not record)."""
        from MediCafe.timing_utils import noop_timer
        with noop_timer:
            pass
        # No assertion needed; success = no exception


if __name__ == '__main__':
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestTimingUtils)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
