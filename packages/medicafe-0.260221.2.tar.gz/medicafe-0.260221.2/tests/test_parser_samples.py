#!/usr/bin/env python
"""
Test script to verify remittance file parsers work correctly with sample files.
Uses the smart import system from core_utils
"""
import os
import sys

# Add workspace directory to Python path
# File is in tests/ directory, so go up one level to get workspace root
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_dir = os.path.dirname(current_dir)  # Go up from tests/ to workspace root
if workspace_dir not in sys.path:
    sys.path.insert(0, workspace_dir)

# Use core_utils smart import system to get the decoder
from MediCafe.core_utils import import_medilink_module

# Import process_decoded_file using the smart import system
process_decoded_file = import_medilink_module('MediLink_Decoder', 'process_decoded_file')

if process_decoded_file is None:
    # Fallback: try direct import with proper path setup
    medilink_dir = os.path.join(workspace_dir, 'MediLink')
    if medilink_dir not in sys.path:
        sys.path.insert(0, medilink_dir)
    # Add current directory when running script (Python 3.4 on Windows may not do this automatically)
    if '' not in sys.path:
        sys.path.insert(0, '')
    os.chdir(medilink_dir)
    from MediLink_Decoder import process_decoded_file, GLOBAL_SEEN_CLAIM_NUMBERS
    os.chdir(workspace_dir)
else:
    # Also import GLOBAL_SEEN_CLAIM_NUMBERS for clearing between files
    medilink_dir = os.path.join(workspace_dir, 'MediLink')
    if medilink_dir not in sys.path:
        sys.path.insert(0, medilink_dir)
    os.chdir(medilink_dir)
    from MediLink_Decoder import GLOBAL_SEEN_CLAIM_NUMBERS
    os.chdir(workspace_dir)

# Sample files to test - use command line args if provided, otherwise use default paths
if len(sys.argv) > 1:
    files = sys.argv[1:]
    print("Using files from command line arguments")
else:
    # Default test file paths in workspace ERA_TEST_DUMP directory
    test_dir = os.path.join(workspace_dir, 'ERA_TEST_DUMP', 'responses', 'AvailityRemittance')
    files = [
        os.path.join(test_dir, "277-202601212045-001.277ibr"),
        os.path.join(test_dir, "277-202601212046170708.277ebr"),
        os.path.join(test_dir, "277-202601212146110294.277dpr"),
        os.path.join(test_dir, "DPT-BCBSF0590-202601212145-001.dpt"),
        os.path.join(test_dir, "EBT-BCBSF0590-202601212045-001.ebt"),
        os.path.join(test_dir, "EBT-HUMANA6110-202601212045-002.ebt"),
        os.path.join(test_dir, "IBT-202601212045-001.ibt"),
    ]
    print("Using default test file paths (provide file paths as arguments to override)")

output_dir = os.path.join(os.getcwd(), 'tmp_decoded')
os.makedirs(output_dir, exist_ok=True)

print("=" * 70)
print("Testing Remittance File Parsers")
print("=" * 70)

for path in files:
    if not os.path.exists(path):
        print("\n[SKIP] File not found: {}".format(path))
        continue
    
    print("\n" + "-" * 70)
    print("Processing: {}".format(os.path.basename(path)))
    print("-" * 70)
    
    try:
        # Clear global deduplication set for each file to test independently
        try:
            GLOBAL_SEEN_CLAIM_NUMBERS.clear()
        except:
            pass
        records = process_decoded_file(path, output_dir, return_records=True)
        print("[OK] Processed {} record(s)".format(len(records)))
        
        if records:
            print("\nFirst record sample:")
            rec_dict = records[0].to_dict()
            for key in ['Claim #', 'Payer', 'Status', 'Patient', 'Serv.', 'Charged', 'Paid', 'Payer ID', 'Payer Claim Number']:
                if key in rec_dict and rec_dict[key]:
                    print("  {}: {}".format(key, rec_dict[key]))
            
            # Show messages if present
            if hasattr(records[0], 'messages') and records[0].messages:
                print("  Messages: {}".format(records[0].messages[:3]))  # First 3 messages
            
            # Show raw segments count if present
            if hasattr(records[0], 'raw_segments') and records[0].raw_segments:
                print("  Raw segments: {} segments captured".format(len(records[0].raw_segments)))
            
            # Test normalization to verify bug fixes (adjustments, service_lines, messages, raw_segments keys)
            try:
                from MediLink_RemittancePipeline import normalize_unified_record, build_source_meta
                rec_dict = records[0].to_dict()
                source_meta = build_source_meta(
                    source_file=os.path.basename(path),
                    source_type="TEST",
                    source_endpoint="TEST",
                    data_source='parsed_file'
                )
                normalized = normalize_unified_record(records[0], source_meta)
                
                # Verify normalization captured the fields (Bug 1 fix verification)
                adjustments_count = len(normalized.get('adjustments', []))
                service_lines_count = len(normalized.get('service_lines', []))
                messages_count = len(normalized.get('messages', []))
                raw_segments_count = len(normalized.get('raw_segments', []))
                
                print("\n  Normalization test:")
                print("    adjustments: {} (from to_dict: {})".format(
                    adjustments_count, len(rec_dict.get('adjustments', []))))
                print("    service_lines: {} (from to_dict: {})".format(
                    service_lines_count, len(rec_dict.get('service_lines', []))))
                print("    messages: {} (from to_dict: {})".format(
                    messages_count, len(rec_dict.get('messages', []))))
                print("    raw_segments: {} (from to_dict: {})".format(
                    raw_segments_count, len(rec_dict.get('raw_segments', []))))
                
                # Verify keys match (Bug 1 fix)
                if 'adjustments' in rec_dict and 'service_lines' in rec_dict and 'messages' in rec_dict and 'raw_segments' in rec_dict:
                    print("    [OK] to_dict() uses lowercase underscore keys (Bug 1 fix verified)")
                else:
                    print("    [WARN] to_dict() keys may not match normalizer expectations")
                    
            except ImportError:
                print("  [SKIP] Normalization test (MediLink_RemittancePipeline not available)")
            except Exception as exc:
                print("  [WARN] Normalization test failed: {}".format(exc))
        else:
            print("[WARN] No records extracted from file")
            
    except Exception as exc:
        print("[ERROR] Failed to process file: {}".format(exc))
        import traceback
        traceback.print_exc()

print("\n" + "=" * 70)
print("Parser test complete")
print("=" * 70)
