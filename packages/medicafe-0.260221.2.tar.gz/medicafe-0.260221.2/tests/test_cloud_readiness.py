#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir




class TestLabRootResolution(unittest.TestCase):
    """resolve_lab_root and invalid-root diagnostics."""

    def test_resolve_lab_root_strips_wrapping_quotes(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"./lab"'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.abspath('./lab'))

    def test_resolve_lab_root_quoted_empty_falls_back_to_repo_lab(self):
        """Quoted empty MEDICAFE_LAB_DIR (e.g. "") must fall back to repo_root/lab, not cwd."""
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': "''"}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))

    def test_resolve_lab_root_quoted_empty_never_uses_cwd(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        orig = os.getcwd()
        temp = tempfile.mkdtemp()
        try:
            os.chdir(temp)
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
                got = resolve_lab_root('/repo')
            self.assertEqual(got, os.path.join('/repo', 'lab'))
            self.assertNotEqual(got, os.path.abspath(''))
        finally:
            os.chdir(orig)
            import shutil
            shutil.rmtree(temp, ignore_errors=True)

    def test_resolve_lab_root_auto_heals_malformed_windows_prefix(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        bad = 'C: C:\\Python34\\Lib\\site-packages\\lab'
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': bad}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:\\Python34\\Lib\\site-packages\\lab'))

    def test_resolve_lab_root_keeps_windows_absolute_path(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/lab'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_windows_backslash_medicafe_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': r'C:\Python34\Lib\site-packages\MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath(r'C:\Python34\Lib\site-packages\MediCafe/lab'))

    def test_resolve_lab_root_medicafe_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/MediCafe/lab'))

    def test_invalid_lab_root_message_includes_env_details(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"C:/missing/lab"'}, clear=False):
            diagnostics = _collect_health_diagnostics('C:/missing/lab', auto_resolve=True)
        issue = diagnostics['issues'][0]
        self.assertEqual(issue['code'], 'LAB_ROOT_NOT_FOUND')
        self.assertIn('MEDICAFE_LAB_DIR(raw)', issue['message'])

class TestCollectHealthDiagnostics(unittest.TestCase):
    """_collect_health_diagnostics state-file handling."""

    def test_seeds_missing_diagnostics_state_when_auto_resolve_enabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            self.assertFalse(os.path.exists(state_path))
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            self.assertEqual(diagnostics['severity'], 'warn')
            issue_codes = [i.get('code') for i in diagnostics['issues']]
            self.assertNotIn('DIAGNOSTICS_STATE_MISSING', issue_codes)
            self.assertTrue(os.path.exists(state_path))
            self.assertTrue(any('Seeded missing diagnostics_state.json' in msg for msg in diagnostics['auto_resolved']))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_reports_missing_diagnostics_state_when_auto_resolve_disabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=False)
            self.assertEqual(diagnostics['severity'], 'warn')
            self.assertEqual(len(diagnostics['issues']), 1)
            self.assertEqual(diagnostics['issues'][0]['code'], 'DIAGNOSTICS_STATE_MISSING')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_use_v2_phase_run_ids(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                        'C': '20260218-010001-22222222',
                        'D': '20260218-010002-33333333',
                        'E': '20260218-010003-44444444',
                    },
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_B_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_skip_pending_transitional_phases(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_phase': 'C',
                    'active_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                    },
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestFindLatestRunIdByPrefix(unittest.TestCase):
    """_find_latest_run_id_by_prefix and _select_latest_evidence_files."""

    def test_single_run_returns_run_id(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid))
            with open(path, 'w') as f:
                f.write('{}')
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, rid)
            self.assertEqual(p, path)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_multi_run_picks_latest_by_mtime(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            r1 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120000-aaa11111.json')
            r2 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120500-bbb22222.json')
            with open(r1, 'w') as f:
                f.write('{}')
            with open(r2, 'w') as f:
                f.write('{}')
            os.utime(r1, (1000, 1000))
            os.utime(r2, (2000, 2000))
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, '20250216-120500-bbb22222')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_dir_returns_none(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertIsNone(run_id)
            self.assertIsNone(p)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSelectLatestEvidenceFiles(unittest.TestCase):
    """_select_latest_evidence_files."""

    def test_single_file(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            self.assertEqual(len(files), 1)
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid), files[0][0])
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_both_formats_attached(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.txt'.format(rid)), 'w') as f:
                f.write('txt')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            basenames = [f[0] for f in files]
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid), basenames)
            self.assertIn('artifact_discovery_summary_{0}.txt'.format(rid), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_same_run(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w') as f:
                f.write('[]')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertIn('ingest_write_anomalies_{0}.jsonl'.format(rid), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_missing(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertFalse(any('ingest_write_anomalies_' in b for b in basenames))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestRunPhaseFManual(unittest.TestCase):
    """run_phase_f_manual and run_phase_f_manual_for_run_id."""

    def test_run_phase_f_manual_no_pipeline_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, running = run_phase_f_manual('/repo', '/py', {})
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertNotIn('--pipeline-run-id', call_args)

    def test_run_phase_f_manual_blocks_when_bootstrap_not_ready(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(False, 'bootstrap failed', None)):
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('os.path.exists', return_value=True):
                    ok, msg, running = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('bootstrap failed', msg)
        self.assertIsNone(running)
        mock_popen.assert_not_called()

    def test_run_phase_f_manual_for_run_id_passes_exact_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/lab'):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '20250216-120000-abc12345')
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertIn('--pipeline-run-id', call_args)
            idx = call_args.index('--pipeline-run-id')
            self.assertEqual(call_args[idx + 1], '20250216-120000-abc12345')



    def test_run_phase_f_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'package_shadow_run_report.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)):
                    with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                        ok, msg, _ = run_phase_f_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_run_phase_f_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        ok, msg, _ = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('package_shadow_run_report.py not found. checked:', msg)



    def test_run_phase_b_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        ok, msg, _ = run_phase_b_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('discover_artifacts.py not found. checked:', msg)

    def test_run_phase_d_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_d_manual
        ok, msg, _ = run_phase_d_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('run_qa_canonical.py not found. checked:', msg)

    def test_run_phase_b_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'discover_artifacts.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                ok, msg, _ = run_phase_b_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

class TestIsPipelineRunning(unittest.TestCase):
    """is_pipeline_running."""

    def test_lock_absent_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            self.assertFalse(is_pipeline_running(lab_root))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_lock_present_pid_dead_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
            with open(lock_path, 'w') as f:
                f.write('pid=99999999\nheartbeat_at_utc=2025-02-16T12:00:00Z\n')
            result = is_pipeline_running(lab_root)
            self.assertFalse(result)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseEvidenceGating(unittest.TestCase):
    """_send_phase_evidence requires at least one phase artifact."""

    def test_send_phase_evidence_requires_phase_artifact(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                ok, msg, _ = _send_phase_evidence(
                    lab_root,
                    [('artifact_discovery_summary_', None)],
                    'phase_b_evidence',
                    'No discovery summaries.',
                )
            self.assertFalse(ok)
            self.assertEqual(msg, 'No discovery summaries.')
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseEvidenceContextFiles(unittest.TestCase):
    """_send_phase_evidence includes context files."""

    def test_includes_context_files_when_present(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files, _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    mock_collect.return_value = '/tmp/bundle.zip'
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertTrue(ok)
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('diagnostics_state.json', basenames)
            self.assertIn('run_cursor.json', basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_uses_interactive_reauth_mode(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with patch('MediCafe.cloud_readiness.collect_support_bundle', return_value='/tmp/bundle.zip'):
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=False) as mock_submit:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertTrue(mock_submit.called)
            self.assertEqual(mock_submit.call_args[1].get('skip_interactive_reauth'), False)
            self.assertIn('Report queued or failed', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseFEvidenceMismatchFallback(unittest.TestCase):
    """send_phase_f_evidence mismatch-only fallback."""

    def test_send_phase_f_evidence_mismatch_only_fallback(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            rid = '20250216-120000-abc12345'
            mismatch_path = os.path.join(reports_dir, 'phase_f_mismatch_{0}.txt'.format(rid))
            with open(mismatch_path, 'w') as f:
                f.write('PHASE_F_RUN_ID_MISMATCH\n')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    with patch('MediCafe.cloud_readiness._submit_bundle_with_delivery_diagnostics', return_value=(True, 'Report sent.', {})):
                        mock_collect.return_value = '/tmp/bundle.zip'
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertTrue(ok)
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('phase_f_mismatch_{0}.txt'.format(rid), basenames)
            self.assertIn('diagnostics_state.json', basenames)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_send_phase_f_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)


class TestEnsureLabReady(unittest.TestCase):
    """ensure_lab_ready gate before Cloud Readiness UI."""

    def test_skips_when_lab_exists_with_core_artifacts(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root, _ = _make_lab()
        try:
            with open(os.path.join(lab_root, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                    ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_call.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstraps_when_lab_missing(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_12345')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)

    def test_missing_lab_transitions_from_baseline_to_pipeline_start_attach(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_transition')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)
        self.assertEqual(mock_start.call_args_list[0][1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)
        self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)

    def test_skips_when_pipeline_running(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_67890')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir') as mock_isdir:
                mock_isdir.return_value = False
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=True):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        mock_call.assert_not_called()

    def test_respects_phase_a_auto_disabled(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_11111')
        env_flag = lambda name, default: False if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('FAILED_POLICY_PHASE_A_DISABLED', msg)
        mock_call.assert_not_called()

    def test_recheck_soft_success_when_core_artifacts_exist_after_nonzero_exit(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_first = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_first')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_first):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=True):
                        with patch('MediCafe.cloud_readiness.subprocess.call', return_value=1) as mock_call:
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        mock_call.assert_called_once()

    def test_runs_bootstrap_when_lab_exists_but_no_core_artifacts(self):
        """Lab dir exists (e.g. partial bootstrap) but no db/cursor; must run bootstrap."""
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(lab_root, 'reports'), exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=1) as mock_call:
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 1', msg)
            mock_call.assert_called_once()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_lab_root_returns_error(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        env_flag = lambda name, default: True
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=''):
            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('Lab root could not be resolved', msg)

    def test_falls_back_to_repo_lab_when_resolved_lab_missing(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_persists_fallback_lab_root_before_reporting_ready(self):
        """When MEDICAFE_LAB_DIR points to missing dir but repo_root/lab has artifacts,
        persist fallback to os.environ so downstream resolve_lab_root uses correct path."""
        from MediCafe.cloud_readiness import ensure_lab_ready, resolve_lab_root
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertTrue(ok)
                mock_call.assert_not_called()
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_nonzero_exit_writes_bootstrap_diag_hint(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            lab_root = os.path.join(temp_repo, 'lab')
            os.makedirs(lab_root, exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=2):
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 2', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_missing_bootstrap_script_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.os.path.exists', return_value=False):
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('BOOTSTRAP_SCRIPT_MISSING', msg)
            self.assertIn('bootstrap_lab.py not found', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstrap_keyboard_interrupt_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.subprocess.call', side_effect=KeyboardInterrupt):
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_INTERRUPTED_SOURCE_UNKNOWN', msg)
            self.assertIn('control event; source unknown', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_orchestrator_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_failed = {
                'status': cr.shadow_orchestrator.STATUS_FAILED,
                'error_code': 'PIPELINE_SCRIPT_MISSING',
                'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
                'diagnostic_path': os.path.join(lab_root, 'reports', 'diag.json'),
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=baseline_failed):
                            with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                                ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
            mock_auto.assert_called_once()
            self.assertEqual(mock_auto.call_args[1].get('trigger'), 'ensure_lab_ready_baseline')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestRunPhaseFManualForRunIdEmptyGuard(unittest.TestCase):
    """run_phase_f_manual_for_run_id empty run_id guard."""

    def test_empty_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()

    def test_whitespace_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '   ')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()


class TestRunShadowPipelineAutoReport(unittest.TestCase):
    def test_manual_pipeline_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        failed = {
            'status': cr.shadow_orchestrator.STATUS_FAILED,
            'error_code': 'PIPELINE_SCRIPT_MISSING',
            'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
            'payload': {},
        }
        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=failed):
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/repo/lab'):
                with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                    ok, msg, _ = cr.run_shadow_pipeline('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
        mock_auto.assert_called_once()
        self.assertEqual(mock_auto.call_args[1].get('trigger'), 'run_shadow_pipeline_manual')


class TestMigrationHealthAuditWiring(unittest.TestCase):
    """run/open helpers for unified migration-health audit."""

    def test_run_migration_health_audit_passes_default_stage(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'pass', 'score': 100, 'exit_code': 0},
                'surfaces': {'xp_local': {'metrics': []}},
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock) as mock_popen:
                    ok, _msg, _data = cr.run_migration_health_audit(
                        repo, sys.executable, {}, scope='both', write_report=False
                    )
            self.assertTrue(ok)
            cmd = mock_popen.call_args[0][0]
            self.assertIn('--migration-stage', cmd)
            idx = cmd.index('--migration-stage')
            self.assertEqual(cmd[idx + 1], 'xp_validation')

    def test_run_migration_health_audit_parses_payload_and_hints(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'warn', 'score': 70, 'exit_code': 0},
                'surfaces': {
                    'xp_local': {'metrics': [
                        {'key': 'xp.phase_d_reject_ratio', 'status': 'warn', 'value': 0.22},
                        {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 1.0},
                        {'key': 'xp.phase_e_contract_parity', 'status': 'pass', 'value': 'pass'},
                    ]},
                    'cloud': {'metrics': [
                        {'key': 'cloud.unacked_queue_count', 'status': 'warn', 'value': 35},
                    ]},
                },
                'degradations': [],
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock):
                    ok, msg, data = cr.run_migration_health_audit(repo, sys.executable, {}, scope='both', write_report=False)

            self.assertTrue(ok)
            self.assertIn('status=warn', msg)
            self.assertTrue(isinstance(data, dict))
            self.assertTrue(any('QA reject ratio' in h for h in data.get('hints', [])))

    def test_audit_hint_lines_include_stage_aware_cloud_note(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'migration_stage': 'xp_validation',
            'overall': {'status': 'warn', 'score': 38, 'exit_code': 0},
            'gating': {'included_surfaces': ['xp_local'], 'excluded_surfaces': ['cloud']},
            'surfaces': {
                'xp_local': {'metrics': [
                    {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 'not_applicable'},
                    {'key': 'xp.cursor_state_run_alignment', 'status': 'warn', 'value': 2},
                ]},
                'cloud': {'metrics': []},
            },
            'degradations': [{'surface': 'cloud', 'reason': 'project_id_missing'}],
        }
        hints = cr._audit_hint_lines_from_payload(payload)
        joined = '\n'.join(hints)
        self.assertIn('Migration stage: xp_validation', joined)
        self.assertIn('Cloud surface is informational-only', joined)
        self.assertIn('XP projection coverage: not_applicable', joined)
        self.assertIn('XP cursor/state run alignment', joined)
        self.assertIn('Cloud degradation reasons: project_id_missing', joined)
        self.assertIn('Runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', joined)

    def test_open_latest_migration_health_report_prefers_latest(self):
        from MediCafe.cloud_readiness import open_latest_migration_health_report
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            p1 = os.path.join(reports, 'audit_migration_health_summary_20260101-000000-aaaa1111.txt')
            p2 = os.path.join(reports, 'audit_migration_health_summary_20260101-000500-bbbb2222.txt')
            with open(p1, 'w', encoding='utf-8') as f:
                f.write('one')
            with open(p2, 'w', encoding='utf-8') as f:
                f.write('two')
            os.utime(p1, (1000, 1000))
            os.utime(p2, (2000, 2000))
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': lab}, clear=False):
                ok, msg, path = open_latest_migration_health_report(repo)
            self.assertTrue(ok)
            self.assertTrue(path.endswith('bbbb2222.txt'))


class TestReportDeliveryStatusViewer(unittest.TestCase):
    def test_open_report_delivery_status_writes_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            queue1 = os.path.join(repo, 'q1.zip')
            queue2 = os.path.join(repo, 'q2.zip')
            with open(queue1, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(queue2, 'w', encoding='utf-8') as f:
                f.write('y')
            os.utime(queue1, (1000, 1000))
            os.utime(queue2, (2000, 2000))

            health_state = os.path.join(lab, cr._HEALTH_ALERT_STATE_FILENAME)
            with open(health_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'A', 'last_sent_epoch': 123}, f)
            orch_state = os.path.join(lab, cr._ORCHESTRATOR_ALERT_STATE_FILENAME)
            with open(orch_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'B', 'last_attempt_epoch': 456, 'last_attempt_ok': False}, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, '_collect_delivery_diagnostics', return_value={
                    'token_available': False,
                    'recipient_count': 0,
                    'queued_bundle_count': 2,
                    'queued_bundle_paths': [queue1, queue2],
                }):
                    ok, msg, path = cr.open_report_delivery_status(repo)

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Report Delivery Status', text)
            self.assertIn('token_available=False', text)
            self.assertIn('recipient_count=0', text)
            self.assertIn('queued_bundle_count=2', text)
            self.assertIn('Cloud health auto-report', text)
            self.assertIn('Orchestrator auto-report', text)
            self.assertIn('Remediation Playbook', text)
            self.assertIn('Actions:', text)


class TestSystemHealthPackWiring(unittest.TestCase):
    def test_run_system_health_triage_returns_hints_and_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, 'run_migration_health_audit', return_value=(
            True,
            'Audit completed with status=warn, score=80, exit_code=0',
            {'hints': ['h1']},
        )):
            with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                True,
                '',
                '/repo/lab/reports/system_health_pack_latest.txt',
            )):
                with patch.object(cr, 'open_latest_migration_health_report', return_value=(
                    True,
                    '',
                    '/repo/lab/reports/audit_migration_health_summary_latest.txt',
                )):
                    ok, msg, data = cr.run_system_health_triage(
                        '/repo',
                        '/py',
                        {},
                        lambda name, default: default,
                        scope='both',
                        cloud_required=False,
                    )
        self.assertTrue(ok)
        self.assertIn('System health triage', msg)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(data.get('hints'), ['h1'])
        self.assertTrue('/repo/lab/reports/system_health_pack_latest.txt' in data.get('artifacts', []))
        self.assertTrue('/repo/lab/reports/audit_migration_health_summary_latest.txt' in data.get('artifacts', []))
        self.assertTrue(isinstance(data.get('runbook', {}), dict))
        self.assertTrue(isinstance(data.get('runbook_lines', []), list))
        self.assertIn('decision', data.get('runbook', {}))

    def test_send_latest_system_health_pack_includes_pack_and_delivery(self):
        from MediCafe import cloud_readiness as cr
        artifacts = {
            'delivery_status_path': '/lab/reports/report_delivery_status.txt',
            'consolidated_path': '/lab/reports/consolidated_health_snapshot.txt',
            'audit_summary_txt': '/lab/reports/audit_migration_health_summary_latest.txt',
            'audit_summary_json': '/lab/reports/audit_migration_health_summary_latest.json',
            'audit_metrics_json': '/lab/reports/audit_migration_health_metrics_latest.json',
            'phase_f_mismatch_path': '/lab/reports/phase_f_mismatch_latest.txt',
        }
        with patch.object(cr, 'resolve_lab_root', return_value='/lab'):
            with patch.object(cr, '_reports_dir_access_error', return_value=None):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                    True,
                    '',
                    '/lab/reports/system_health_pack_latest.txt',
                )):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                        with patch.object(cr, '_select_latest_evidence_files', return_value=[
                            ('shadow_run_report_latest.txt', '/lab/reports/shadow_run_report_latest.txt'),
                        ]):
                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'Report sent.', {})):
                                        with patch('MediCafe.cloud_readiness.os.path.isfile', return_value=True):
                                            ok, msg, data = cr.send_latest_system_health_pack(
                                                '/repo',
                                                lambda name, default: default,
                                            )
        self.assertTrue(ok)
        self.assertIn('Report sent', msg)
        self.assertEqual(data.get('delivery_status_path'), '/lab/reports/report_delivery_status.txt')
        meta = mock_collect.call_args[1].get('extra_meta', {})
        self.assertTrue(meta.get('system_health_pack'))
        extra_files = mock_collect.call_args[1].get('extra_files', [])
        basenames = [item[0] for item in extra_files]
        self.assertIn('system_health_pack_latest.txt', basenames)
        self.assertIn('report_delivery_status.txt', basenames)
        self.assertTrue(isinstance(data.get('pre_send_runbook_lines', []), list))
        self.assertTrue(len(data.get('pre_send_runbook_lines', [])) > 0)

    def test_open_latest_system_health_pack_includes_runbook_section(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'overall': {'status': 'warn'},
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'degradations': [{'surface': 'cloud', 'reason': 'firestore_unavailable'}],
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'running', 'active_run_id': 'rid-a', 'last_shadow_pipeline_run_id': 'rid-b'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('System Health Runbook:', text)
            self.assertIn('Data plane snapshot:', text)
            self.assertIn('run_alignment=active_differs_from_last', text)
            self.assertIn('cloud_degraded_mode=True', text)
            self.assertIn('cloud_degradation_reasons=firestore_unavailable', text)
            self.assertIn('Open cloud degraded validation runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', text)
            self.assertIn('Check (firestore_unavailable):', text)


class TestRunCentricArtifactTools(unittest.TestCase):
    def test_open_latest_artifact_triage_pack_writes_latest_file(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Artifact Triage Pack', text)
            self.assertIn(rid, text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('Consequential Diagnostics:', text)
            self.assertIn('What To Do Now:', text)

    def test_open_latest_artifact_triage_pack_incomplete_contains_actionable_runbook(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-071129-5d5c869f'
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('[]')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                    'last_error_code': 'PHASE_F_NOT_RUN',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('classification=INCOMPLETE', text)
            self.assertIn('Trigger full shadow pipeline (A->F)', text)
            self.assertIn('run_id_alignment=last_completed', text)
            self.assertIn('last_error_code=PHASE_F_NOT_RUN', text)

    def test_open_run_artifact_index_for_run_id_requires_existing_run_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, '20260219-000000-deadbeef')
            self.assertFalse(ok)
            self.assertIn('No artifacts found', msg)
            self.assertIsNone(path)

    def test_open_run_artifact_index_for_pipeline_run_uses_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=pipeline_phase_map', text)
            self.assertIn('phase_run_ids=B:{0},C:{1},D:{2},E:{3},F:{4}'.format(rid_b, rid_c, rid_d, rid_e, rid_f), text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_b), text)
            self.assertIn('[E] Projection status=COMPLETE resolved_run_id={0}'.format(rid_e), text)

    def test_open_run_artifact_index_for_pipeline_run_falls_back_when_map_stale(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_f), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_f), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_f), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_f), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260219-bad-b',
                        'C': '20260219-bad-c',
                        'D': '20260219-bad-d',
                        'E': '20260219-bad-e',
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=phase_map_state_file_drift_fallback_single_token', text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_ignores_unanchored_state_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.json'.format(rid_f), json.dumps({'source_summary_paths': []})),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-other-root-ffffffff',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=state_phase_map_unanchored_fallback_single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_prefers_shadow_lineage_when_state_conflicts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b_old = '20260219-153857-oldb'
            rid_c_old = '20260219-153910-oldc'
            rid_d_old = '20260219-153914-oldd'
            rid_e_old = '20260219-153915-olde'
            rid_b_new = '20260219-153857-newb'
            rid_c_new = '20260219-153910-newc'
            rid_d_new = '20260219-153914-newd'
            rid_e_new = '20260219-153915-newe'

            shadow_paths = [
                os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)),
                os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid_c_old)),
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid_d_old)),
                os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid_e_old)),
            ]
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_f)), 'w', encoding='utf-8') as f:
                json.dump({'source_summary_paths': shadow_paths}, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_f)), 'w', encoding='utf-8') as f:
                f.write('ok')

            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)), 'w', encoding='utf-8') as f:
                f.write('{}')

            for rid, prefix in (
                (rid_b_new, 'artifact_discovery_summary_'),
                (rid_c_new, 'ingest_write_summary_'),
                (rid_d_new, 'qa_canonical_summary_'),
                (rid_e_new, 'projection_parity_summary_'),
            ):
                with open(os.path.join(reports, '{0}{1}.json'.format(prefix, rid)), 'w', encoding='utf-8') as f:
                    f.write('{}')

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b_new,
                        'C': rid_c_new,
                        'D': rid_d_new,
                        'E': rid_e_new,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_send_latest_run_evidence_bundle_includes_run_id_meta(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'Report sent.', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertIn('Report sent', msg)
            self.assertEqual(data.get('run_id'), rid)
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('artifact_run_id'), rid)
            self.assertTrue(meta.get('run_evidence_bundle'))
            basenames = [x[0] for x in mock_collect.call_args[1].get('extra_files', [])]
            self.assertTrue(any(name.startswith('artifact_triage_pack_') for name in basenames))
            self.assertTrue(any(name.startswith('run_artifact_index_') for name in basenames))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(len(data.get('runbook_lines', [])) > 0)


class TestGuidedPatientCompletenessRunbook(unittest.TestCase):
    def _seed_lab_db(self, lab_root):
        db_path = os.path.join(lab_root, 'unified_model_xp.db')
        schema_path = os.path.join(_PROJECT_ROOT, 'sql', 'unified_relational_model_v1.sql')
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema_sql = f.read()
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(schema_sql)

        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (1, 'k1', 'xp_local', 'csv', 's1', '{}', 'projected')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (2, 'k2', 'xp_local', 'csv', 's2', '{}', 'qa_failed')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (3, 'k3', 'xp_local', 'csv', 's3', '{}', 'ingested')"
        )

        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (1, 'pk-risk', '11111', '', '', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (2, 'pk-good', '22222', 'Baseline Patient', '1980-01-01', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (3, 'pk-reject', '33333', 'Reject Patient', '1990-02-02', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO payer (payer_id, payer_key, payer_external_id, payer_name, endpoint_name) "
            "VALUES (1, 'payer-1', 'P1', 'Payer One', 'endpoint')"
        )
        conn.execute(
            "INSERT INTO insurance_plan (plan_id, plan_key, payer_id, medisoft_insurance_ids_json) "
            "VALUES (1, 'plan-1', 1, '[]')"
        )
        conn.execute(
            "INSERT INTO coverage (coverage_id, coverage_key, patient_id, plan_id, active_flag) "
            "VALUES (1, 'cov-good', 2, 1, 1)"
        )
        conn.execute(
            "INSERT INTO encounter (encounter_id, encounter_key, patient_id, date_of_service, source_artifact_id) "
            "VALUES (1, 'enc-good', 2, '2026-02-19', 1)"
        )
        conn.execute(
            "INSERT INTO claim (claim_id, claim_key, encounter_id, payer_id, claim_number, source_artifact_id) "
            "VALUES (1, 'claim-good', 1, 1, 'CLM-222', 1)"
        )
        conn.execute(
            "INSERT INTO claim_line (claim_line_id, claim_line_key, claim_id, line_number) "
            "VALUES (1, 'line-good', 1, 1)"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (1, 1, 'patient_csv_row', 'pk-good', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (1, 1, 'patient_v1', 'v1', 'success', '{\"external_patient_id\":\"22222\"}')"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (2, 2, 'patient_csv_row', 'pk-reject', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (2, 2, 'patient_v1', 'v1', 'rejected', '{\"reject_reason\":\"missing_required_fields\"}')"
        )
        conn.execute(
            "INSERT INTO qa_result "
            "(qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
            "VALUES (1, 2, 'phase_d', 'v1', 'reject', 'QA_REQUIRED', 'missing patient id', 'd1')"
        )
        conn.execute(
            "INSERT INTO replay_queue (replay_id, artifact_id, reason_code, status, attempt_count) "
            "VALUES (1, 2, 'QA_REQUIRED', 'pending', 0)"
        )
        conn.commit()
        conn.close()
        return db_path

    def test_get_guided_patient_completeness_options_returns_enriched_letters(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            self.assertTrue(isinstance(data, dict))
            options = data.get('options', [])
            codes = [x.get('code') for x in options]
            self.assertIn('A', codes)
            self.assertIn('D', codes)
            self.assertIn('B', codes)
            self.assertTrue(any(str(x.get('display_id')) == '33333' for x in options if x.get('code') == 'B'))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(any('data_plane_status=' in line for line in data.get('runbook_lines', [])))

    def test_get_guided_patient_completeness_options_no_patient_rows_returns_guidance(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertFalse(ok)
            self.assertIn('data-state', msg.lower())
            self.assertTrue(isinstance(data, dict))
            self.assertEqual(data.get('condition'), 'no_patient_rows')
            self.assertEqual(data.get('options', []), [])
            runbook_lines = data.get('runbook_lines', [])
            self.assertTrue(any('patient_count=0' in line for line in runbook_lines))
            self.assertTrue(any('qa_reject_count=' in line for line in runbook_lines))
            self.assertTrue(any('replay_pending_count=' in line for line in runbook_lines))
            self.assertTrue(any('projection_success_count=' in line for line in runbook_lines))
            self.assertTrue(any('last_shadow_pipeline_run_id=20260219-071129-5d5c869f' in line for line in runbook_lines))
            self.assertTrue(any(str(line).strip() == 'What To Do Now:' for line in runbook_lines))
            self.assertTrue(any(str(line).strip().startswith('1) ') for line in runbook_lines))
            actions = data.get('actions', [])
            self.assertTrue(isinstance(actions, list))
            self.assertTrue(len(actions) >= 2)
            self.assertTrue(any('option 4' in a.lower() for a in actions))

    def test_open_guided_patient_completeness_runbook_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_guided_patient_completeness_runbook(repo, 'B')
            self.assertTrue(ok)
            self.assertIn('verdict=', msg)
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Patient Completeness Runbook', text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('What To Do Now:', text)
            self.assertIn('Artifact pointers:', text)

    def test_patient_flow_reference_options_preserve_chain_fields(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            first = options[0]
            self.assertIn('claim_count', first)
            self.assertIn('canonical_count', first)
            self.assertIn('full_name', first)

    def test_find_patient_option_by_reference_prefers_external_id_over_numeric_patient_id(self):
        from MediCafe import cloud_readiness_patient_tools as pt
        rows = [
            {'patient_id': 33333, 'patient_key': 'pk-a', 'external_patient_id': '55555'},
            {'patient_id': 42, 'patient_key': 'pk-b', 'external_patient_id': '33333'},
        ]
        picked = pt.find_patient_option_by_reference(rows, '33333')
        self.assertEqual(picked.get('patient_id'), 42)

    def test_get_patient_flow_reference_options_autopopulates_refs(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            self.assertTrue(any(str(x.get('patient_ref')) == '33333' for x in options))

    def test_open_patient_flow_runbook_by_external_patient_id_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, '33333')
            self.assertTrue(ok)
            self.assertIn('Patient flow runbook generated', msg)
            self.assertTrue(path and os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Data View Samples (first 3 rows per table):', text)
            self.assertIn(' - patient:', text)
            self.assertIn(' - claim:', text)
            self.assertIn(' - qa_result:', text)

    def test_open_patient_flow_runbook_unknown_patient_returns_not_found(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, 'does-not-exist')
            self.assertFalse(ok)
            self.assertIn('not found', msg.lower())
            self.assertIsNone(path)



if __name__ == '__main__':
    unittest.main()
