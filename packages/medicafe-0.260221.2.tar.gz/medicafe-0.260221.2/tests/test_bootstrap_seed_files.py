#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest


class TestBootstrapSeedFiles(unittest.TestCase):

    def test_phase_a_seeds_first_launch_artifacts(self):
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        lab_root = tempfile.mkdtemp(prefix='mc_lab_')
        try:
            bootstrap = os.path.join(repo_root, 'scripts', 'unified_model', 'bootstrap_lab.py')
            rc = subprocess.call([sys.executable, bootstrap, '--lab-dir', lab_root], cwd=repo_root)
            self.assertEqual(rc, 0)

            expected_paths = [
                os.path.join(lab_root, 'unified_model_xp.db'),
                os.path.join(lab_root, 'shadow_status.json'),
                os.path.join(lab_root, 'run_cursor.json'),
                os.path.join(lab_root, 'diagnostics_state.json'),
                os.path.join(lab_root, 'cloud_health_tracker.json'),
                os.path.join(lab_root, 'cloud_health_alert_state.json'),
                os.path.join(lab_root, 'reports'),
            ]
            for p in expected_paths:
                self.assertTrue(os.path.exists(p), p)

            # Locks should be runtime-only, not seeded by bootstrap.
            self.assertFalse(os.path.exists(os.path.join(lab_root, 'shadow_pipeline.lock')))

            with open(os.path.join(lab_root, 'cloud_health_tracker.json'), 'r', encoding='utf-8') as f:
                tracker = json.load(f)
            self.assertEqual(tracker.get('version'), 1)
            self.assertTrue(isinstance(tracker.get('issues'), dict))

            with open(os.path.join(lab_root, 'cloud_health_alert_state.json'), 'r', encoding='utf-8') as f:
                alert = json.load(f)
            self.assertEqual(alert.get('last_sent_epoch'), 0)

            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'r', encoding='utf-8') as f:
                state = json.load(f)
            self.assertEqual(state.get('last_phase_a_ok'), True)
            self.assertTrue(bool(str(state.get('last_phase_a_run_id', '')).strip()))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_a_does_not_clobber_existing_operational_state_without_reset(self):
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        lab_root = tempfile.mkdtemp(prefix='mc_lab_')
        try:
            os.makedirs(os.path.join(lab_root, 'reports'), exist_ok=True)

            pre_status = {
                'run_state': 'running',
                'current_phase': 'F',
                'schema_version': '1',
                'run_id': 'existing-status-run',
            }
            pre_cursor = {
                'version': 1,
                'updated_at_utc': '2000-01-01T00:00:00Z',
                'artifact_classes': {'csv': {'last_scan_mtime': 1, 'last_scan_path': '/x'}}
            }
            pre_state = {
                'version': 1,
                'updated_at_utc': '2000-01-01T00:00:00Z',
                'last_phase_a_run_id': 'existing-phase-a-run',
                'last_phase_a_ok': True,
            }
            pre_tracker = {'version': 1, 'issues': {'X': {'count': 1}}, 'last_updated_epoch': 1}
            pre_alert = {'last_issue_key': 'abc', 'last_sent_epoch': 123}

            with open(os.path.join(lab_root, 'shadow_status.json'), 'w', encoding='utf-8') as f:
                json.dump(pre_status, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w', encoding='utf-8') as f:
                json.dump(pre_cursor, f)
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(pre_state, f)
            with open(os.path.join(lab_root, 'cloud_health_tracker.json'), 'w', encoding='utf-8') as f:
                json.dump(pre_tracker, f)
            with open(os.path.join(lab_root, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump(pre_alert, f)

            bootstrap = os.path.join(repo_root, 'scripts', 'unified_model', 'bootstrap_lab.py')
            rc = subprocess.call([sys.executable, bootstrap, '--lab-dir', lab_root], cwd=repo_root)
            self.assertEqual(rc, 0)

            with open(os.path.join(lab_root, 'shadow_status.json'), 'r', encoding='utf-8') as f:
                self.assertEqual(json.load(f), pre_status)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'r', encoding='utf-8') as f:
                self.assertEqual(json.load(f), pre_cursor)
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'r', encoding='utf-8') as f:
                self.assertEqual(json.load(f), pre_state)
            with open(os.path.join(lab_root, 'cloud_health_tracker.json'), 'r', encoding='utf-8') as f:
                self.assertEqual(json.load(f), pre_tracker)
            with open(os.path.join(lab_root, 'cloud_health_alert_state.json'), 'r', encoding='utf-8') as f:
                self.assertEqual(json.load(f), pre_alert)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
