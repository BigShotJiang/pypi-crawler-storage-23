#!/usr/bin/env python3
"""Verify Python syntax of orchestrator scripts.

Primary: py_compile. Fallback: ast.parse when py_compile fails
(e.g. __pycache__ permissions or filesystem issues).
"""

from __future__ import annotations

import ast
from typing import Tuple
import py_compile
import sys
import os

REQUIRED_FILES = [
    "setup_flow.py",
    "setup_alerting.py",
    "validate_and_complete_setup.py",
    "setup_runtime.py",
    "setup_common.py",
]


def verify_file(path: str) -> Tuple[bool, str]:
    """Return (ok, method_used)."""
    try:
        py_compile.compile(path, doraise=True)
        return True, "py_compile"
    except py_compile.PyCompileError as e:
        print("ERROR: {} (py_compile): {}".format(path, e), file=sys.stderr)
        return False, "py_compile"
    except (OSError, PermissionError):
        pass
    try:
        with open(path, "r", encoding="utf-8") as f:
            ast.parse(f.read())
        return True, "ast.parse"
    except SyntaxError as e:
        print("ERROR: {} (ast fallback): {}".format(path, e), file=sys.stderr)
        return False, "ast.parse"


def main() -> int:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    failed = []
    method_used = {}
    for name in REQUIRED_FILES:
        path = os.path.join(script_dir, name)
        if not os.path.isfile(path):
            print("SKIP: {} not found".format(path))
            continue
        ok, method = verify_file(path)
        method_used[name] = method
        if not ok:
            failed.append(name)
        else:
            print("OK {} ({})".format(name, method))
    if failed:
        print("Failed: {}".format(", ".join(failed)), file=sys.stderr)
        return 1
    if method_used.get("setup_flow.py") == "ast.parse":
        print("INFO: py_compile failed for some files; ast.parse fallback was used.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
