﻿# Installing Google Cloud SDK (gcloud CLI)

The setup scripts require the `gcloud` command-line tool. Here's how to install it on Windows.

## Option 1: Using the Installer (Recommended)

### Step 1: Download the Installer

1. **Go to**: https://cloud.google.com/sdk/docs/install
2. **Click "Download the SDK"**
3. **Select**: Windows 竊・64-bit installer (or 32-bit if needed)
4. **Download**: `GoogleCloudSDKInstaller.exe`

### Step 2: Run the Installer

1. **Run the downloaded installer** (`GoogleCloudSDKInstaller.exe`)
2. **Follow the installation wizard**:
   - Accept the license agreement
   - Choose installation location (default is fine)
   - Click "Install"

### Step 3: Initialize gcloud

1. **Open a NEW PowerShell window** (close and reopen if you had one open)
2. **Run initialization**:
   ```powershell
   gcloud init
   ```
3. **Follow the prompts**:
   - Login with your Google account (the one that has access to `genial-analyzer-476721-f8`)
   - Select project: `genial-analyzer-476721-f8`
   - Choose default region: `us-central1` (or your preference)

### Step 4: Verify Installation

```powershell
gcloud --version
```

You should see version information. If it still doesn't work, you may need to add it to PATH manually.

## Option 2: Using Chocolatey (If You Have It)

If you have Chocolatey package manager installed:

```powershell
choco install gcloudsdk
```

Then restart PowerShell and run `gcloud init`.

## Option 3: Manual PATH Configuration

If the installer doesn't add `gcloud` to your PATH:

1. **Find where gcloud was installed** (usually):
   ```
   C:\Program Files (x86)\Google\Cloud SDK\google-cloud-sdk\bin
   ```
   or
   ```
   C:\Users\YourUsername\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin
   ```

2. **Add to PATH**:
   - Open "Environment Variables" in Windows
   - Edit "Path" variable
   - Add the `bin` folder path above
   - Restart PowerShell

## Verify Installation

After installation, test:

```powershell
# Check version
gcloud --version

# List available projects
gcloud projects list

# Set default project
gcloud config set project genial-analyzer-476721-f8

# Verify authentication
gcloud auth list
```

## Troubleshooting

### "gcloud: command not found" after installation
- **Restart PowerShell** - PATH changes require a new session
- **Check PATH manually**: `$env:PATH` should include Google Cloud SDK bin folder
- **Try full path**: `"C:\Program Files (x86)\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.exe" --version`

### Authentication issues
- Run `gcloud auth login` to authenticate
- Run `gcloud auth application-default login` for application credentials

### Project not found
- Verify you have access to `genial-analyzer-476721-f8`
- Check: `gcloud projects list`
- If missing, you may need to be added as a project member

## Next Steps

Once `gcloud` is working:
1. 笨・Run `gcloud init` to set up authentication
2. 笨・Verify project access: `gcloud projects describe genial-analyzer-476721-f8`
3. Run the validator setup flow: `py -3.11 cloud/orchestrator/validate_and_complete_setup.py`



















