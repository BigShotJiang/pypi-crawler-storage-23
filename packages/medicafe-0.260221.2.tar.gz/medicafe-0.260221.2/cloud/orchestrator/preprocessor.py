"""Metadata-only preprocessor for Gmail attachment queue candidates.

Validates required fields before Firestore queue write. Does not parse
attachment file contents (CSV/DOCX); that is a separate phase.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from config import Config
from reject_codes import PREPROCESSOR_REJECT_CODE_REGISTRY


LOGGER = logging.getLogger("medilink.orchestrator.preprocessor")

PREPROCESSOR_VERSION = "1.0"
SCHEMA_VERSION = "1"

# Re-export for backward compatibility (gate may import REJECT_CODE_REGISTRY)
REJECT_CODE_REGISTRY = PREPROCESSOR_REJECT_CODE_REGISTRY


def is_known_reject_code(code: str) -> bool:
    """True if code is in the preprocessor registry."""
    return code in PREPROCESSOR_REJECT_CODE_REGISTRY


@dataclass
class PreprocessResult:
    """Result of preprocessing a queue candidate."""

    ok: bool
    code: str
    message: str
    payload: Optional[Dict[str, Any]]


def preprocess_queue_candidate(
    raw: Dict[str, Any],
    config: Config,
    attempt_id: str,
) -> PreprocessResult:
    """
    Validate metadata for a queue candidate. No payload mutation for storage.
    Returns PreprocessResult with ok=True and payload when accepted,
    ok=False and payload=None when rejected.
    """
    try:
        # Required: machine_id
        machine_id = raw.get("machine_id")
        if not machine_id or not str(machine_id).strip():
            return PreprocessResult(
                ok=False,
                code="missing_machine_id",
                message="machine_id is required and non-empty",
                payload=None,
            )

        # Required: message_id
        message_id = raw.get("message_id")
        if not message_id or not str(message_id).strip():
            return PreprocessResult(
                ok=False,
                code="missing_message_id",
                message="message_id is required and non-empty",
                payload=None,
            )

        # Required: received_at
        received_at = raw.get("received_at")
        if received_at is None:
            return PreprocessResult(
                ok=False,
                code="missing_received_at",
                message="received_at is required",
                payload=None,
            )

        # Either files non-empty OR otp_required=True
        files = raw.get("files") or []
        otp_required = raw.get("otp_required", False)
        if not otp_required and not files:
            return PreprocessResult(
                ok=False,
                code="empty_files_not_otp",
                message="files must be non-empty when otp_required is False",
                payload=None,
            )

        # Validate files items (minimal: filename and gcs_path)
        for i, item in enumerate(files):
            if not isinstance(item, dict):
                return PreprocessResult(
                    ok=False,
                    code="invalid_files_item",
                    message="files[{}] must be a dict".format(i),
                    payload=None,
                )
            if not item.get("filename") or not item.get("gcs_path"):
                return PreprocessResult(
                    ok=False,
                    code="invalid_files_item",
                    message="files[{}] missing filename or gcs_path".format(i),
                    payload=None,
                )

        # Build validated payload (no mutation of stored text; keep UTF-8)
        payload = {
            "machine_id": str(machine_id).strip(),
            "message_id": str(message_id).strip(),
            "thread_id": raw.get("thread_id"),
            "history_id": raw.get("historyId") or raw.get("history_id"),
            "subject": raw.get("subject"),
            "received_at": str(received_at) if received_at is not None else str(raw.get("internalDate", "")),
            "otp_required": bool(otp_required),
            "otp_token": raw.get("otp_token"),
            "files": files,
            "acked": False,
            "schema_version": SCHEMA_VERSION,
            "preprocessor_version": PREPROCESSOR_VERSION,
            "attempt_id": attempt_id,
        }
        return PreprocessResult(ok=True, code="", message="", payload=payload)

    except Exception as exc:
        LOGGER.exception("Unhandled exception in preprocessor for message_id=%s", raw.get("message_id"))
        return PreprocessResult(
            ok=False,
            code="unhandled_exception",
            message=str(exc) if str(exc) else "unhandled_exception",
            payload=None,
        )
