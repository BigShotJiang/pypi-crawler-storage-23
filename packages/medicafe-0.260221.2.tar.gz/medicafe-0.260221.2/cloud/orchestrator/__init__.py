"""Cloud orchestration package for MediLink Gmail pipeline."""

