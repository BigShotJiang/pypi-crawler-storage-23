#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Manual token self-test tool (XP/Python 3.4.4 compatible).

Purpose:
- When a client secret update was done offline, the post-update token test may be skipped.
- This tool allows the user to manually run token checks later from the MediCafe menu.
"""

import os
import sys
import time

# Add parent directory to path to find MediCafe modules (standalone-safe).
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from MediBot.config_editor_helpers import load_config_safe
except ImportError:
    print("ERROR: Could not import config_editor_helpers")
    print("Please ensure config_editor_helpers.py is in the MediBot directory.")
    sys.exit(1)

try:
    from MediBot.token_test_utils import (
        set_medicafe_config_env,
        test_endpoint_token,
    )
except ImportError:
    print("ERROR: Could not import token_test_utils")
    print("Please ensure token_test_utils.py is in the MediBot directory.")
    sys.exit(1)


def clear_screen():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception:
        pass


def print_header():
    print("=" * 60)
    print("      MediCafe API Token Self-Test (Manual)")
    print("=" * 60)
    print("")


def discover_endpoints(config):
    endpoints = []
    try:
        medi_config = config.get('MediLink_Config', {})
        endpoints_dict = medi_config.get('endpoints', {})
        if not endpoints_dict:
            return endpoints
        for endpoint_name, endpoint_config in endpoints_dict.items():
            if isinstance(endpoint_config, dict):
                endpoints.append((endpoint_name, endpoint_config))
    except Exception:
        return endpoints
    return endpoints


def endpoint_warnings(endpoint_config):
    warnings = []
    try:
        required = ['token_url', 'client_id', 'client_secret']
        for f in required:
            if f not in endpoint_config or endpoint_config.get(f) in (None, ''):
                warnings.append(f)
    except Exception:
        pass
    return warnings


def maybe_check_internet():
    try:
        from MediCafe.core_utils import check_internet_connection
        return bool(check_internet_connection())
    except Exception:
        return None


def prompt_yes_no(message, default_yes=True):
    suffix = " (Y/n): " if default_yes else " (y/N): "
    try:
        raw = input(message + suffix).strip().upper()
    except Exception:
        return default_yes
    if not raw:
        return default_yes
    return raw in ('Y', 'YES')


def select_single_endpoint(endpoints):
    print("Available endpoints:")
    print("-" * 60)
    for i, (name, cfg) in enumerate(endpoints, 1):
        warns = endpoint_warnings(cfg)
        warn_text = ""
        if warns:
            warn_text = " [MISSING: {0}]".format(", ".join(warns))
        token_url = cfg.get('token_url', '[MISSING]')
        client_id = cfg.get('client_id', '[MISSING]')
        print("[{0}] {1}{2}".format(i, name, warn_text))
        print("     token_url: {0}".format(token_url))
        print("     client_id: {0}".format(client_id))
        print("")
    print("[0] Cancel and exit")
    print("")

    while True:
        try:
            choice_str = input("Select endpoint (1-{0}, or 0 to cancel): ".format(len(endpoints))).strip()
            if not choice_str:
                print("Invalid choice. Please enter a number.")
                continue
            choice = int(choice_str)
            if choice == 0:
                return None
            if 1 <= choice <= len(endpoints):
                return endpoints[choice - 1][0]
            print("Invalid choice.")
        except ValueError:
            print("Invalid choice. Please enter a number.")
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
            return None


def run_tests(config_path, endpoints):
    # Ensure MediCafe loads this config.
    set_medicafe_config_env(config_path)

    selected_all = prompt_yes_no("Run token self-test for ALL endpoints?", default_yes=True)
    if not selected_all:
        endpoint_name = select_single_endpoint(endpoints)
        if not endpoint_name:
            return 0
        endpoint_names = [endpoint_name]
    else:
        endpoint_names = [name for (name, _) in endpoints]

    print("")
    print("Starting token self-test...")
    print("Note: This may take a moment per endpoint.")
    print("")

    passed = 0
    failed = 0
    skipped = 0

    # Build a quick lookup for warnings without reloading config.
    endpoint_cfg_map = {}
    for name, cfg in endpoints:
        endpoint_cfg_map[name] = cfg

    for name in endpoint_names:
        cfg = endpoint_cfg_map.get(name, {}) if endpoint_cfg_map else {}
        warns = endpoint_warnings(cfg) if isinstance(cfg, dict) else []
        if warns:
            print("[SKIP] {0} (missing: {1})".format(name, ", ".join(warns)))
            skipped += 1
            continue

        ok, err = test_endpoint_token(name, config_path=config_path, quiet_mode=True)
        if ok:
            print("[ OK ] {0}".format(name))
            passed += 1
        else:
            print("[FAIL] {0}: {1}".format(name, err or "Unknown error"))
            failed += 1

        # Small delay to keep output readable on slower machines.
        try:
            time.sleep(0.1)
        except Exception:
            pass

    print("")
    print("Summary:")
    print("  Passed:  {0}".format(passed))
    print("  Failed:  {0}".format(failed))
    print("  Skipped: {0}".format(skipped))
    print("")
    return 0 if failed == 0 else 1


def main():
    if len(sys.argv) != 2:
        print("Usage: python token_self_test.py <config_path>")
        return 1

    config_path = sys.argv[1]
    # Ensure connectivity checks and API clients resolve the intended config file.
    set_medicafe_config_env(config_path)

    clear_screen()
    print_header()

    # Load config for endpoint discovery and validation.
    print("Loading configuration...")
    config, error = load_config_safe(config_path)
    if error:
        print("ERROR: {0}".format(error))
        print("")
        input("Press Enter to exit...")
        return 1

    if 'MediLink_Config' not in config:
        print("ERROR: Configuration does not contain 'MediLink_Config' section.")
        print("")
        input("Press Enter to exit...")
        return 1

    endpoints = discover_endpoints(config)
    if not endpoints:
        print("ERROR: No endpoints found in configuration.")
        print("Please configure endpoints in the 'MediLink_Config.endpoints' section.")
        print("")
        input("Press Enter to exit...")
        return 1

    internet = maybe_check_internet()
    if internet is False:
        print("WARNING: No internet connection detected.")
        print("Token requests will likely fail until internet is available.")
        print("")
        if not prompt_yes_no("Continue anyway?", default_yes=False):
            return 0
    elif internet is True:
        print("Internet connection detected.")
        print("")
    else:
        print("Internet status: unknown (connectivity check unavailable).")
        print("")

    rc = run_tests(config_path, endpoints)
    try:
        input("Press Enter to exit...")
    except Exception:
        pass
    return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\nOperation interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print("\n\nERROR: Unexpected error: {0}".format(str(e)))
        import traceback
        traceback.print_exc()
        try:
            input("Press Enter to exit...")
        except Exception:
            pass
        sys.exit(1)
