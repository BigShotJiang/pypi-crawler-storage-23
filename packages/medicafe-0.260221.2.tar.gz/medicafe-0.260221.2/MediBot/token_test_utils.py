#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Token test helpers (XP/Python 3.4.4 compatible).

This is shared by:
- MediBot/client_secret_update.py (post-update self-test)
- MediBot/token_self_test.py (manual troubleshooting run)
"""

import os
import sys


def _ensure_project_on_path():
    # Add parent directory to path to find MediCafe modules (standalone-safe).
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)


def set_medicafe_config_env(config_path):
    """
    Ensure MediCafe modules load the intended config file.
    MediLink_ConfigLoader prefers MEDICAFE_CONFIG_FILE.
    """
    if not config_path:
        return
    try:
        os.environ['MEDICAFE_CONFIG_FILE'] = os.path.abspath(config_path)
    except Exception:
        # Best-effort only; do not crash token tests for env issues.
        pass


def clear_medicafe_config_cache_best_effort():
    """
    Clear any cached configuration state, if available.
    This is best-effort and safe to ignore failures.
    """
    try:
        _ensure_project_on_path()
        from MediBot.config_editor_helpers import clear_config_cache
        clear_config_cache()
    except Exception:
        pass


def create_fresh_api_client():
    """
    Create a new API client instance (avoid shared singleton caching).
    Returns (client, error_message_or_None)
    """
    _ensure_project_on_path()

    # Prefer the factory (new instance via get_client()).
    try:
        from MediCafe.api_factory import APIClientFactory
        factory = APIClientFactory()
        client = factory.get_client()
        return client, None
    except Exception:
        pass

    # Fallback to direct core client.
    try:
        from MediCafe.api_core import APIClient
        return APIClient(), None
    except Exception as e:
        return None, "Could not create API client: {0}".format(str(e))


def test_endpoint_token(endpoint_name, config_path=None, quiet_mode=True):
    """
    Attempt to obtain an access token for an endpoint.
    Returns (success_bool, error_message_or_None)
    """
    try:
        if config_path:
            set_medicafe_config_env(config_path)

        # Ensure new config is visible to the client.
        clear_medicafe_config_cache_best_effort()

        api_client, err = create_fresh_api_client()
        if not api_client:
            return False, err or "API client unavailable"

        # Try to request a token (do not print/return token value).
        try:
            # Newer APIClient signature supports quiet_mode.
            token = api_client.get_access_token(endpoint_name, quiet_mode=quiet_mode)
        except TypeError:
            # Back-compat fallback.
            token = api_client.get_access_token(endpoint_name)

        if token:
            return True, None

        # Pull failure details (code/description/http_status) if available.
        failure_info = None
        try:
            tc = getattr(api_client, 'token_cache', None)
            if tc and hasattr(tc, 'is_token_request_failed') and tc.is_token_request_failed(endpoint_name):
                if hasattr(tc, 'get_token_failure_info'):
                    failure_info = tc.get_token_failure_info(endpoint_name)
        except Exception:
            failure_info = None

        error_code = None
        error_desc = None
        http_status = None
        if isinstance(failure_info, dict):
            error_code = failure_info.get('error_code')
            error_desc = failure_info.get('error_description')
            http_status = failure_info.get('http_status')

        # Build and print a redacted diagnostics block by default on failure.
        try:
            _ensure_project_on_path()
            from MediCafe.MediLink_ConfigLoader import load_configuration
            from MediCafe.core_utils import extract_medilink_config
            base_config, _ = load_configuration()
            medi = extract_medilink_config(base_config)
            ep_cfg = medi.get('endpoints', {}).get(endpoint_name, {}) if isinstance(medi, dict) else {}
            token_url = ep_cfg.get('token_url') if isinstance(ep_cfg, dict) else None
            client_id = ep_cfg.get('client_id') if isinstance(ep_cfg, dict) else None
            client_secret = ep_cfg.get('client_secret') if isinstance(ep_cfg, dict) else None
            scope = ep_cfg.get('scope') if isinstance(ep_cfg, dict) else None

            from MediCafe.token_diagnostics import build_token_diagnostics_block
            block = build_token_diagnostics_block(
                endpoint_name=endpoint_name,
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret,
                scope=scope,
                config_path=config_path,
                http_status=http_status,
                error_code=error_code,
                error_description=error_desc,
                exception_text=None,
                note="This block is redacted: no secrets or tokens are shown."
            )
            try:
                print(block)
            except Exception:
                pass
            # Do not additionally log here; api_core emits diagnostics for failures by default.
        except Exception:
            # Never fail token tests due to diagnostics.
            pass

        if error_code:
            msg = "Token request failed (error: {0})".format(error_code)
            if http_status is not None:
                msg = msg + " (http_status: {0})".format(http_status)
            if error_desc:
                msg = msg + " - {0}".format(error_desc)
            return False, msg

        return False, "Token request returned None (check credentials, proxy/TLS, and endpoint configuration)"
    except Exception as e:
        error_msg = str(e)
        # Don't echo secrets in error strings (best-effort).
        try:
            if 'client_secret' in error_msg.lower():
                error_msg = "Authentication failed (check client_id and client_secret)"
        except Exception:
            pass
        return False, error_msg
