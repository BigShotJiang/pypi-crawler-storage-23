#!/usr/bin/env python
# Quick demo of Humana/Aetna export table display (no config or CSV required).
# Run from repo root: python tools/demo_humana_aetna_table.py

from __future__ import print_function
import os
import sys
from datetime import datetime

# Add parent so MediLink can be imported
repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if repo_root not in sys.path:
    sys.path.insert(0, repo_root)

# Build minimal mock grouped_data as produced by group_by_month()
# Format: {(year, month): [{'row': csv_row_dict, 'date_obj': datetime}, ...]}
def make_mock_grouped_data():
    def row(pid, name, insurance, date_obj):
        return {
            'row': {
                'Patient ID 2': pid,
                'Patient ID': pid,
                'Patient Name': name,
                'Primary Insurance': insurance,
            },
            'date_obj': date_obj,
        }

    # Month 1: two patients, one with two service dates
    jan = [
        row('10001', 'Doe, Jane', 'HUMANA', datetime(2025, 1, 5)),
        row('10001', 'Doe, Jane', 'HUMANA', datetime(2025, 1, 15)),  # same patient, second date
        row('10002', 'Smith, John', 'AETNA', datetime(2025, 1, 10)),
    ]
    # Month 2: one patient
    feb = [
        row('10003', 'Last, First', 'AETNA MEDICARE', datetime(2025, 2, 3)),
    ]

    return {
        (2025, 1): jan,
        (2025, 2): feb,
    }


def main():
    from MediLink.MediLink_Humana_Aetna_Export import build_export_content

    grouped = make_mock_grouped_data()
    content = build_export_content(grouped)
    print(content)
    print("\n[Demo complete. Table columns: No. | Insurance | Pat ID | Patient Name | Service Date 1 | Service Date 2 | Amount]")


if __name__ == '__main__':
    main()
