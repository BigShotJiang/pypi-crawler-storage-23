#!/usr/bin/env python
"""
replace_medilink_api_v3.py

Script to update all references to MediLink_API_v3 (archived) to use MediCafe.api_core (the new location for API core functionality).
- Updates import statements and usage in all .py files recursively from the project root.
- Prints out which files were changed.
- Safe to run multiple times.

Usage: python tools/replace_medilink_api_v3.py
"""
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

IMPORT_PATTERNS = [
    # from MediLink_API_v3 import ...
    (re.compile(r"from\s+MediLink_API_v3\s+import\s+([\w,\s*]+)"), r"from MediCafe.api_core import \1"),
    # import MediCafe.api_core as MediLink_API_v3  # [auto-migrated]
    (re.compile(r"import\s+MediLink_API_v3"), r"import MediCafe.api_core as MediLink_API_v3  # [auto-migrated]"),
    # from MediLink import MediCafe.api_core as MediLink_API_v3  # [auto-migrated]
    (re.compile(r"from\s+MediLink\s+import\s+MediLink_API_v3"), r"from MediCafe import api_core as MediLink_API_v3  # [auto-migrated]"),
    # from MediLink.MediLink_API_v3 import ...
    (re.compile(r"from\s+MediLink\.MediLink_API_v3\s+import\s+([\w,\s*]+)"), r"from MediCafe.api_core import \1"),
    # import MediCafe.api_core as MediLink_API_v3  # [auto-migrated]
    (re.compile(r"import\s+MediLink\.MediLink_API_v3"), r"import MediCafe.api_core as MediLink_API_v3  # [auto-migrated]")
]
USAGE_PATTERN = (re.compile(r"MediLink_API_v3\."), "api_core.")


def replace_in_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    original = content

    # Replace import statements
    for pattern, repl in IMPORT_PATTERNS:
        content = pattern.sub(repl, content)

    # Replace usage
    content = USAGE_PATTERN[0].sub(USAGE_PATTERN[1], content)

    if content != original:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print("Updated: {}".format(filepath))


def scan_and_replace():
    for root, dirs, files in os.walk(ROOT):
        for file in files:
            if file.endswith(".py"):
                replace_in_file(os.path.join(root, file))

if __name__ == "__main__":
    scan_and_replace()