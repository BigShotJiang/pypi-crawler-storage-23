# -*- coding: utf-8 -*-
"""
Shared ANSI color helpers for build and validation scripts.
Only applies colors when stdout is a TTY and NO_COLOR is not set.
"""

from __future__ import print_function

import os
import sys


def _color_enabled():
    if os.environ.get('NO_COLOR'):
        return False
    return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()


def _c(text, code):
    """Wrap text with ANSI escape sequence. code is the SGR parameter (e.g. '92' for green)."""
    if not _color_enabled():
        return text
    return '\x1b[{}m{}\x1b[0m'.format(code, text)


def step(s):
    """Cyan - for step labels like [1/4]."""
    return _c(s, '96')


def pass_(s):
    """Green - for PASS."""
    return _c(s, '92')


def fail(s):
    """Red - for FAIL."""
    return _c(s, '91')


def dim(s):
    """Dim - for metadata."""
    return _c(s, '2')


def bold(s):
    """Bold - for headers."""
    return _c(s, '1')


def green(s):
    """Green - for success messages."""
    return _c(s, '92')


def green_bold(s):
    """Green + bold - for final success messages."""
    return _c(s, '1;92')

def red(s):
    """Red - for errors."""
    return _c(s, '91')
