PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS model_metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ingest_artifact (
  artifact_id INTEGER PRIMARY KEY,
  ingest_key TEXT NOT NULL UNIQUE,
  source_system TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  message_id TEXT,
  attachment_name TEXT,
  attachment_sha256 TEXT,
  payload_json TEXT NOT NULL,
  ingest_status TEXT NOT NULL CHECK (ingest_status IN ('ingested','qa_failed','qa_passed','canonicalized','projected')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS qa_result (
  qa_result_id INTEGER PRIMARY KEY,
  artifact_id INTEGER NOT NULL,
  qa_stage TEXT NOT NULL,
  qa_version TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pass','reject')),
  reject_code TEXT,
  reject_reason TEXT,
  deterministic_key TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (artifact_id, qa_stage, qa_version),
  FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS replay_queue (
  replay_id INTEGER PRIMARY KEY,
  artifact_id INTEGER NOT NULL,
  reason_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','replayed','abandoned')) DEFAULT 'pending',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  last_attempt_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (artifact_id, reason_code),
  FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS patient (
  patient_id INTEGER PRIMARY KEY,
  patient_key TEXT NOT NULL UNIQUE,
  external_patient_id TEXT,
  full_name TEXT,
  birth_date TEXT,
  source_system TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (external_patient_id IS NULL OR external_patient_id GLOB '[0-9][0-9][0-9][0-9][0-9]')
);

CREATE TABLE IF NOT EXISTS payer (
  payer_id INTEGER PRIMARY KEY,
  payer_key TEXT NOT NULL UNIQUE,
  payer_external_id TEXT,
  payer_name TEXT,
  endpoint_name TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS insurance_plan (
  plan_id INTEGER PRIMARY KEY,
  plan_key TEXT NOT NULL UNIQUE,
  payer_id INTEGER NOT NULL,
  medisoft_insurance_ids_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (payer_id) REFERENCES payer(payer_id)
);

CREATE TABLE IF NOT EXISTS coverage (
  coverage_id INTEGER PRIMARY KEY,
  coverage_key TEXT NOT NULL UNIQUE,
  patient_id INTEGER NOT NULL,
  plan_id INTEGER NOT NULL,
  effective_start TEXT,
  effective_end TEXT,
  active_flag INTEGER NOT NULL DEFAULT 1 CHECK (active_flag IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
  FOREIGN KEY (plan_id) REFERENCES insurance_plan(plan_id)
);

CREATE TABLE IF NOT EXISTS encounter (
  encounter_id INTEGER PRIMARY KEY,
  encounter_key TEXT NOT NULL UNIQUE,
  patient_id INTEGER NOT NULL,
  date_of_service TEXT NOT NULL,
  source_artifact_id INTEGER NOT NULL,
  diagnosis_code TEXT,
  eye_side TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
  FOREIGN KEY (source_artifact_id) REFERENCES ingest_artifact(artifact_id)
);

CREATE TABLE IF NOT EXISTS claim (
  claim_id INTEGER PRIMARY KEY,
  claim_key TEXT NOT NULL UNIQUE,
  encounter_id INTEGER NOT NULL,
  payer_id INTEGER NOT NULL,
  claim_number TEXT,
  status TEXT,
  charged_amount REAL,
  allowed_amount REAL,
  paid_amount REAL,
  patient_resp_amount REAL,
  source_artifact_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (encounter_id) REFERENCES encounter(encounter_id),
  FOREIGN KEY (payer_id) REFERENCES payer(payer_id),
  FOREIGN KEY (source_artifact_id) REFERENCES ingest_artifact(artifact_id)
);

CREATE TABLE IF NOT EXISTS claim_line (
  claim_line_id INTEGER PRIMARY KEY,
  claim_line_key TEXT NOT NULL UNIQUE,
  claim_id INTEGER NOT NULL,
  line_number INTEGER NOT NULL,
  cpt_code TEXT,
  diagnosis_pointer TEXT,
  charged_amount REAL,
  paid_amount REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (claim_id) REFERENCES claim(claim_id)
);

CREATE TABLE IF NOT EXISTS extracted_canonical_record (
  canonical_record_id INTEGER PRIMARY KEY,
  artifact_id INTEGER NOT NULL,
  canonical_type TEXT NOT NULL,
  canonical_key TEXT NOT NULL,
  extractor_version TEXT NOT NULL,
  canonical_json TEXT NOT NULL,
  provenance_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (artifact_id, canonical_type, canonical_key, extractor_version),
  FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS projection_result (
  projection_id INTEGER PRIMARY KEY,
  canonical_record_id INTEGER NOT NULL,
  projection_type TEXT NOT NULL,
  projection_version TEXT NOT NULL,
  projection_status TEXT NOT NULL CHECK (projection_status IN ('success','rejected')),
  projected_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (canonical_record_id, projection_type, projection_version),
  FOREIGN KEY (canonical_record_id) REFERENCES extracted_canonical_record(canonical_record_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ingest_message_id ON ingest_artifact(message_id);
CREATE INDEX IF NOT EXISTS idx_qa_status ON qa_result(status, reject_code);
CREATE INDEX IF NOT EXISTS idx_claim_number ON claim(claim_number);


CREATE TABLE IF NOT EXISTS mapping_rule (
  mapping_rule_id INTEGER PRIMARY KEY,
  rule_scope TEXT NOT NULL,
  source_key TEXT NOT NULL,
  target_key TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100,
  active_flag INTEGER NOT NULL DEFAULT 1 CHECK (active_flag IN (0,1)),
  effective_start TEXT,
  effective_end TEXT,
  rule_payload_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (rule_scope, source_key, target_key, priority)
);

CREATE TABLE IF NOT EXISTS constraint_rule (
  constraint_rule_id INTEGER PRIMARY KEY,
  rule_name TEXT NOT NULL UNIQUE,
  severity TEXT NOT NULL CHECK (severity IN ('info','warn','error')),
  rule_sql_predicate TEXT NOT NULL,
  active_flag INTEGER NOT NULL DEFAULT 1 CHECK (active_flag IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rule_decision_log (
  decision_id INTEGER PRIMARY KEY,
  artifact_id INTEGER,
  mapping_rule_id INTEGER,
  constraint_rule_id INTEGER,
  decision_type TEXT NOT NULL CHECK (decision_type IN ('mapping_applied','constraint_pass','constraint_fail','manual_override')),
  decision_context_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE SET NULL,
  FOREIGN KEY (mapping_rule_id) REFERENCES mapping_rule(mapping_rule_id) ON DELETE SET NULL,
  FOREIGN KEY (constraint_rule_id) REFERENCES constraint_rule(constraint_rule_id) ON DELETE SET NULL
);
