# MediCafe/api_core.py
"""
Core API functionality for MediCafe.
Moved from MediLink to centralize shared API operations.

COMPATIBILITY: Python 3.4.4 and Windows XP compatible

TOKEN CACHE:
- In-memory, per-process. APIClientFactory.get_shared_client() and core_utils.get_api_client()
  return a singleton per process; tokens are reused within that process.
- Launcher commands (Deductible, Claims Status, etc.) run in separate subprocesses; each has
  its own empty cache. Multiple token acquisitions in one log session are expected, not a bug.
- Future: optional file-based cache for cross-process reuse (see docs/API_TOKEN_CACHE_BEHAVIOR.md).
"""

import time, json, os, traceback, sys

# Import centralized logging configuration
try:
    from MediCafe.logging_config import DEBUG, CONSOLE_LOGGING
except ImportError:
    # Fallback to local flags if centralized config is not available
    DEBUG = False
    CONSOLE_LOGGING = False

# Set up project paths first
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

try:
    import yaml
except ImportError:
    yaml = None
try:
    import requests
except ImportError:
    requests = None

# Use core utilities for standardized imports
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from .core_utils import get_shared_config_loader
        MediLink_ConfigLoader = get_shared_config_loader()
    except ImportError:
        # Fallback to direct import
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader

# CRITICAL: Ensure MediLink_ConfigLoader is available - this module requires it
if MediLink_ConfigLoader is None:
    raise ImportError(
        "[api_core] CRITICAL: MediLink_ConfigLoader module import failed. "
        "This module requires MediLink_ConfigLoader to function. "
        "Check PYTHONPATH, module dependencies, and ensure MediCafe package is properly installed."
    )

try:
    from MediCafe.network_route_helpers import handle_route_mismatch_404
except ImportError:
    def handle_route_mismatch_404(*args, **kwargs):
        return


try:
    from MediCafe import graphql_utils as MediLink_GraphQL
except ImportError:
    try:
        from MediLink import MediLink_GraphQL
    except ImportError:
        try:
            import graphql_utils as MediLink_GraphQL
        except ImportError:
            # Create a dummy module if graphql_utils is not available
            # BUG (minimally fixed): When graphql_utils is unavailable, DummyGraphQL
            # lacked OPTUMAI claims inquiry helpers used by get_claim_summary_by_provider.
            # Minimal fix implemented elsewhere: a capability guard disables OPTUMAI when
            # these methods are missing so fallback to UHCAPI proceeds without AttributeError.
            # Recommended next steps:
            # - Provide explicit no-op stubs here that raise NotImplementedError for clarity.
            # - Add a small shim that always exposes required methods to decouple import shapes.
            # - Add a config feature flag to enable/disable OPTUMAI claims inquiry.
            # - Add environment-based guard (dev/test default off) and metrics counter for use.
            # - Add unit tests for both capability-present and capability-absent paths.
            # Open question: should eligibility-only flows still run with a lightweight fallback query builder
            # when claims inquiry helpers are unavailable, or should GraphQL be fully disabled across all paths?
            class DummyGraphQL:
                GRAPHQL_AVAILABLE = False

                @staticmethod
                def build_eligibility_variables(**kwargs):
                    return kwargs

                @staticmethod
                def build_eligibility_request(graphql_variables):
                    return {
                        'query': '',
                        'variables': {'input': graphql_variables or {}}
                    }

                @staticmethod
                def build_optumai_enriched_request(graphql_variables):
                    return DummyGraphQL.build_eligibility_request(graphql_variables)

                @staticmethod
                def get_sample_eligibility_request():
                    return {'query': '', 'variables': {'input': {}}}

                @staticmethod
                def build_optumai_claims_inquiry_request(search_claim_input):
                    raise NotImplementedError("graphql_utils unavailable: OPTUMAI claims inquiry helpers are disabled")

                @staticmethod
                def transform_claims_inquiry_response_to_legacy(response):
                    return {
                        'statuscode': '503',
                        'message': 'graphql_utils unavailable: claims inquiry transform helper is disabled',
                        'claims': [],
                        'rawGraphQLResponse': response if isinstance(response, dict) else {}
                    }

                @staticmethod
                def transform_eligibility_response(response):
                    return response
            MediLink_GraphQL = DummyGraphQL()

try:
    from MediCafe.routing_reason_codes import (
        classify_routing_reason, next_step_hint, is_suppressible,
        UNSUPPORTED_PAYER, MEMBER_REQUIRED, NO_DATA, AUTH_ISSUE, TRANSPORT_ERROR
    )
except ImportError:
    classify_routing_reason = None
    next_step_hint = lambda rc: "Check logs for details."
    is_suppressible = lambda rc: False
    (UNSUPPORTED_PAYER, MEMBER_REQUIRED, NO_DATA, AUTH_ISSUE, TRANSPORT_ERROR) = (
        'unsupported_payer', 'member_required', 'no_data', 'auth_issue', 'transport_error')

_FALLBACK_LOG_ONCE = {}

# AVAILITY Payer List rate limiting: 5 calls per second (demo app limit)
# Maintain last call timestamp to enforce 200ms minimum spacing
_AVAILITY_PAYER_LIST_LAST_CALL = 0

# Single canonical suppression source for routing. Replaces _OPTUMAI_PROVIDER_TIN_REQUIRES_MEMBER_PAYERS.
_ROUTING_SUPPRESSION_CACHE = {}  # {(payer_id, context): (reason_code, timestamp)}
_SUPPRESSION_TTL_SECONDS = 300  # 5 min
QUERY_CONTEXT_PROVIDER_TIN = 'provider_tin_search'


def _check_suppression(payer_id, context):
    """
    Check if payer/context is suppressed. Purge expired entries before lookup.
    Returns (bool, reason_code, hint) or (False, None, None) if not suppressed.
    """
    try:
        now = time.time()
        to_remove = []
        for key, val in _ROUTING_SUPPRESSION_CACHE.items():
            if len(val) >= 2 and (now - val[1]) > _SUPPRESSION_TTL_SECONDS:
                to_remove.append(key)
        for k in to_remove:
            _ROUTING_SUPPRESSION_CACHE.pop(k, None)
        key = (str(payer_id) if payer_id else '', str(context) if context else '')
        entry = _ROUTING_SUPPRESSION_CACHE.get(key)
        if entry and len(entry) >= 2:
            reason_code = entry[0]
            hint = next_step_hint(reason_code) if next_step_hint else "Check logs for details."
            return (True, reason_code, hint)
    except Exception:
        pass
    return (False, None, None)


def _add_suppression(payer_id, context, reason_code):
    """Store suppression for payer/context with current timestamp."""
    try:
        key = (str(payer_id) if payer_id else '', str(context) if context else '')
        _ROUTING_SUPPRESSION_CACHE[key] = (str(reason_code) if reason_code else 'unknown', time.time())
    except Exception:
        pass


def _log_routing_decision_once(payer_id, context, attempted, reason_code, fallback, hint):
    """Log one structured routing decision per dedup key."""
    key = "routing_decision_{}_{}_{}_{}_{}".format(
        payer_id or '', context or '', attempted or '', fallback or '', reason_code or '')
    msg = "[ROUTING_DECISION] payerId={}, context={}, attemptedEndpoint={}, reasonCode={}, fallbackEndpoint={}, nextStep=\"{}\"".format(
        payer_id or '', context or '', attempted or '', reason_code or '', fallback or '', hint or '')
    _log_fallback_once(key, msg, level="INFO")

def _optumai_error_indicates_member_required(error_code, error_description):
    """
    Return True if the OPTUMAI error looks like it is asking for member-level fields.
    Heuristic only; the spec does not enumerate payer-specific requirements.
    """
    try:
        code_upper = str(error_code or '').upper()
        desc_lower = str(error_description or '').lower()
        if 'MISSING_REQUIRED_FIELD' in code_upper:
            return True
        if ('member details' in desc_lower and 'mandatory' in desc_lower) or ('member' in desc_lower and 'mandatory' in desc_lower):
            return True
    except Exception:
        pass
    return False

def _log_fallback_once(key, message, level="WARNING"):
    try:
        if _FALLBACK_LOG_ONCE.get(key):
            return
        _FALLBACK_LOG_ONCE[key] = True
        MediLink_ConfigLoader.log(message, level=level, console_output=CONSOLE_LOGGING)
    except Exception:
        pass

def _optumai_supports_feature_for_client(client, payer_id, feature, context_label):
    """
    Load crosswalk and check OPTUMAI feature support for a payer.
    Conservative default: if feature status is unknown, return False.

    Returns:
        tuple: (supports: bool, crosswalk: dict or None, reason: str or None)
    """
    if not payer_id:
        return False, None, 'payer_id_missing'
    try:
        from MediCafe.payer_list_updater import optumai_supports_feature, OPTUMAI_FEATURE_KEYS
    except ImportError:
        _log_fallback_once(
            'optumai_feature_check_import',
            "OPTUMAI feature check unavailable (import failure); skipping OPTUMAI for {}.".format(context_label),
            level="WARNING"
        )
        return False, None, 'feature_check_import_failed'
    if feature not in OPTUMAI_FEATURE_KEYS:
        MediLink_ConfigLoader.log(
            "Unknown OPTUMAI feature key '{}' ({}); treating as unsupported.".format(feature, context_label),
            level="WARNING",
            console_output=CONSOLE_LOGGING
        )
        return False, None, 'feature_unknown'
    if ensure_full_config_loaded is None:
        msg = ("CRITICAL: ensure_full_config_loaded is unavailable; falling back to "
               "MediLink_ConfigLoader.load_configuration() for OPTUMAI feature check ({}).".format(context_label))
        try:
            print(msg)
        except Exception:
            pass
        try:
            MediLink_ConfigLoader.log(msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
        except Exception:
            pass
        try:
            _, crosswalk = MediLink_ConfigLoader.load_configuration()
        except Exception as e:
            try:
                err_msg = ("CRITICAL: load_configuration failed while checking OPTUMAI feature ({}): {}"
                           .format(context_label, str(e)))
                print(err_msg)
                MediLink_ConfigLoader.log(err_msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return False, None, 'loader_unavailable'
        # Continue with crosswalk if available
        if not crosswalk:
            MediLink_ConfigLoader.log(
                "OPTUMAI feature check skipped because crosswalk is missing ({}); defaulting to unsupported.".format(
                    context_label),
                level="DEBUG",
                console_output=CONSOLE_LOGGING
            )
            return False, None, 'crosswalk_missing'
        supports = False
        try:
            supports = bool(optumai_supports_feature(crosswalk, payer_id, feature))
        except Exception:
            supports = False
        if not supports:
            opl = crosswalk.get('optum_payer_list') or {}
            meta = opl.get('metadata') or {}
            payers = opl.get('payers')
            if meta.get('last_error') or not payers or (isinstance(payers, dict) and len(payers) == 0):
                return False, crosswalk, 'data_unavailable'
            return False, crosswalk, 'feature_not_supported'
        return True, crosswalk, None
    try:
        _, crosswalk = ensure_full_config_loaded(
            getattr(client, 'config', None),
            getattr(client, 'crosswalk', None)
        )
    except Exception as e:
        msg = ("CRITICAL: OPTUMAI feature check failed due to config/crosswalk load error ({}): {}. "
               "Falling back to MediLink_ConfigLoader.load_configuration().".format(context_label, str(e)))
        try:
            print(msg)
        except Exception:
            pass
        try:
            MediLink_ConfigLoader.log(msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
        except Exception:
            pass
        try:
            _, crosswalk = MediLink_ConfigLoader.load_configuration()
        except Exception as e2:
            try:
                err_msg = ("CRITICAL: load_configuration failed while checking OPTUMAI feature ({}): {}"
                           .format(context_label, str(e2)))
                print(err_msg)
                MediLink_ConfigLoader.log(err_msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return False, None, 'loader_error'
    if not crosswalk:
        MediLink_ConfigLoader.log(
            "OPTUMAI feature check skipped because crosswalk is missing ({}); defaulting to unsupported.".format(
                context_label),
            level="DEBUG",
            console_output=CONSOLE_LOGGING
        )
        return False, None, 'crosswalk_missing'
    supports = False
    try:
        supports = bool(optumai_supports_feature(crosswalk, payer_id, feature))
    except Exception:
        supports = False
    if not supports:
        opl = crosswalk.get('optum_payer_list') or {}
        meta = opl.get('metadata') or {}
        payers = opl.get('payers')
        if meta.get('last_error') or not payers or (isinstance(payers, dict) and len(payers) == 0):
            return False, crosswalk, 'data_unavailable'
        return False, crosswalk, 'feature_not_supported'
    return True, crosswalk, None

"""
TODO At some point it might make sense to test their acknoledgment endpoint. body is transactionId.
This API is used to extract the claim acknowledgement details for the given transactionid which was 
generated for 837 requests in claim submission process. Claims Acknowledgement (277CA) will provide 
a status of claim-level acknowledgement of all claims received in the front-end processing system and 
adjudication system.
"""

class ConfigLoader:
    @staticmethod
    def load_configuration(config_path=os.path.join(os.path.dirname(__file__), '..', 'json', 'config.json'), 
                           crosswalk_path=os.path.join(os.path.dirname(__file__), '..', 'json', 'crosswalk.json')):
        return MediLink_ConfigLoader.load_configuration(config_path, crosswalk_path)

    @staticmethod
    def load_swagger_file(swagger_path):
        try:
            print("Attempting to load Swagger file: {}".format(swagger_path))
            with open(swagger_path, 'r') as swagger_file:
                if swagger_path.endswith('.yaml') or swagger_path.endswith('.yml'):
                    if yaml is None:
                        print("YAML parsing not available (PyYAML not installed). Please install PyYAML or provide a JSON Swagger file.")
                        return None
                    print("Parsing YAML file: {}".format(swagger_path))
                    swagger_data = yaml.safe_load(swagger_file)
                elif swagger_path.endswith('.json'):
                    print("Parsing JSON file: {}".format(swagger_path))
                    swagger_data = json.load(swagger_file)
                else:
                    raise ValueError("Unsupported Swagger file format.")
            print("Successfully loaded Swagger file: {}".format(swagger_path))
            return swagger_data
        except ValueError as e:
            print("Error parsing Swagger file {}: {}".format(swagger_path, e))
            MediLink_ConfigLoader.log("Error parsing Swagger file {}: {}".format(swagger_path, e), level="ERROR")
        except FileNotFoundError:
            print("Swagger file not found: {}".format(swagger_path))
            MediLink_ConfigLoader.log("Swagger file not found: {}".format(swagger_path), level="ERROR")
        except Exception as e:
            print("Unexpected error loading Swagger file {}: {}".format(swagger_path, e))
            MediLink_ConfigLoader.log("Unexpected error loading Swagger file {}: {}".format(swagger_path, e), level="ERROR")
        return None

# Function to ensure numeric type
def ensure_numeric(value):
    if isinstance(value, str):
        try:
            value = float(value)
        except ValueError:
            raise ValueError("Cannot convert {} to a numeric type".format(value))
    return value

# Import utilities from api_utils
try:
    from MediCafe.api_utils import TokenCache
except ImportError:
    # Fallback if api_utils is not available
    class TokenCache:
        def __init__(self):
            self.tokens = {}

# -----------------------------------------------------------------------------
# Endpoint-specific payer ID management (crosswalk-backed with hardcoded default)
# -----------------------------------------------------------------------------
# Intent:
# - Validate payer IDs against the endpoint actually being called.
# - Persist endpoint-specific payer ID lists into the crosswalk so they can be
#   updated over time without changing code.
# - For OPTUMAI: use the augmented list (includes LIFE1, WELM2, etc.).
# - For UHCAPI (including its Super Connector fallback): strictly enforce the
#   known-good UHC payer IDs only.
# - Future: OPTUMAI will expose a dedicated endpoint that returns its current
#   valid payer list. When available, this function should fetch and refresh the
#   crosswalk entry automatically (likely weekly/monthly), replacing the
#   hardcoded default below. The UHCAPI Super Connector will eventually be
#   deprecated; when removed, cleanup the UHC-specific paths accordingly.

try:
    # Prefer using existing crosswalk persistence utilities
    from MediBot.MediBot_Crosswalk_Utils import ensure_full_config_loaded, save_crosswalk
except Exception:
    ensure_full_config_loaded = None
    save_crosswalk = None

# -----------------------------------------------------------------------------
# OPTUMAI Header Building and TIN Normalization Helpers
# -----------------------------------------------------------------------------

def normalize_provider_tin(tin):
    """
    Normalize provider TIN to 9-digit numeric string.
    Removes hyphens, spaces, and other non-digit characters.
    
    Args:
        tin: Provider TIN (string, int, or any format)
        
    Returns:
        str: 9-digit numeric string, or None if input is invalid/empty
    """
    if not tin:
        return None
    try:
        tin_str = ''.join([ch for ch in str(tin) if ch.isdigit()])
        if len(tin_str) == 9:
            return tin_str
        else:
            MediLink_ConfigLoader.log(
                "Warning: Provider TIN '{}' normalized to '{}' (not 9 digits)".format(tin, tin_str),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
            # Return normalized version even if not 9 digits (caller can validate)
            return tin_str if tin_str else None
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Error normalizing provider TIN '{}': {}".format(tin, str(e)),
            level="WARNING",
            console_output=CONSOLE_LOGGING
        )
        # Fallback to string conversion
        try:
            return str(tin)
        except Exception:
            return None

def build_optumai_headers(config, api_url=None, next_page_token=None):
    """
    Build standardized OPTUMAI headers with normalized TIN.
    Replaces duplicated header building logic across multiple functions.
    
    Args:
        config: Configuration object (must have MediLink config accessible)
        api_url: Optional API URL to detect sandbox/stage environment
        next_page_token: Optional pagination token for subsequent pages
        
    Returns:
        dict: Headers dictionary with Content-Type, Accept, providerTaxId,
              x-optum-consumer-correlation-id, environment (if sandbox), and
              nextPageToken (if provided)
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    # Extract MediLink config and normalize provider TIN
    try:
        from MediCafe.core_utils import extract_medilink_config
    except ImportError:
        # Fallback if core_utils not available
        def extract_medilink_config(cfg):
            if hasattr(cfg, 'get'):
                return cfg
            return getattr(cfg, 'config', {})
    
    medi = extract_medilink_config(config)
    provider_tin = medi.get('billing_provider_tin')
    input_tin = provider_tin
    if provider_tin:
        # DEBUG: Log TIN normalization details
        if DEBUG:
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization input={}".format(
                    input_tin if input_tin else 'None'
                ),
                level="DEBUG"
            )
        
        # Normalize to 9 digits (fixes missing normalization in claims inquiry)
        provider_tin = normalize_provider_tin(provider_tin)
        if provider_tin:
            # Validate normalized TIN is exactly 9 digits before adding to headers
            # This ensures consistency with get_eligibility_super_connector validation
            if len(provider_tin) == 9:
                headers['providerTaxId'] = provider_tin
                # DEBUG: Log successful normalization
                if DEBUG:
                    # Mask TIN for security (show first 5 digits, mask last 4)
                    tin_masked = provider_tin[:5] + '****'
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalized successfully, length={}, maskedValue={}".format(
                            len(provider_tin), tin_masked
                        ),
                        level="DEBUG"
                    )
            else:
                # WARNING: Log TIN normalization issues
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization issue - input '{}' normalized to '{}' (not 9 digits) - omitting providerTaxId header".format(
                        input_tin, provider_tin),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                # Also log the existing warning message
                MediLink_ConfigLoader.log(
                    "Warning: Provider TIN '{}' normalized to '{}' (not 9 digits) - omitting providerTaxId header".format(
                        input_tin, provider_tin),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
    else:
        # WARNING: Log missing TIN
        if DEBUG:
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization - missing billing_provider_tin in config",
                level="WARNING"
            )
    
    # Correlation ID for tracing
    try:
        corr_id = 'mc-{}'.format(int(time.time() * 1000))
    except Exception:
        corr_id = 'mc-{}'.format(int(time.time()))
    headers['x-optum-consumer-correlation-id'] = corr_id
    
    # Environment header (sandbox/stage detection)
    environment = None
    if api_url:
        try:
            api_url_lower = str(api_url).lower()
            if any(tag in api_url_lower for tag in ['sandbox', 'stg', 'stage', 'test']):
                headers['environment'] = 'sandbox'
                environment = 'sandbox'
        except Exception:
            pass
    
    # Pagination token
    if next_page_token:
        headers['nextPageToken'] = str(next_page_token)
    
    # DEBUG: Log header construction
    if DEBUG:
        # Mask correlation ID (show first 8 chars)
        corr_id_masked = corr_id[:8] + '...' if len(corr_id) >= 8 else corr_id
        # Mask provider TIN if present
        provider_tin_masked = 'None'
        if 'providerTaxId' in headers:
            tin_val = headers['providerTaxId']
            if len(tin_val) >= 5:
                provider_tin_masked = tin_val[:5] + '****'
            else:
                provider_tin_masked = '****'
        
        MediLink_ConfigLoader.log(
            "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: Header construction - providerTaxId={}, correlationId={}, environment={}, nextPageToken={}".format(
                provider_tin_masked, corr_id_masked, environment or 'None', 'present' if next_page_token else 'None'
            ),
            level="DEBUG"
        )
    
    return headers

# Hardcoded OPTUMAI payer IDs (fallback when optum_payer_list / endpoint_payer_ids missing).
# Single source of truth; used by _get_default_endpoint_payer_ids and get_valid_payer_ids_for_endpoint.
_OPTUMAI_HARDCODED_PAYER_IDS = [
    "87726", "25463", "39026", "74227", "LIFE1", "WELM2", "06111",
    "96385", "37602", "03432", "95467", "86050", "86047", "95378"
]

def _get_default_endpoint_payer_ids(endpoint_name):
    """
    Return hardcoded default payer IDs for a given endpoint.

    NOTE: Defaults are used when crosswalk does not yet contain a list.
    For OPTUMAI, uses get_optumai_payer_ids (optum_payer_list -> endpoint_payer_ids -> hardcoded).
    """
    if endpoint_name == 'OPTUMAI':
        try:
            from MediCafe.payer_list_updater import get_optumai_payer_ids
            if ensure_full_config_loaded:
                try:
                    config, crosswalk = ensure_full_config_loaded(None, None)
                    if crosswalk:
                        payer_ids = get_optumai_payer_ids(crosswalk=crosswalk, config=config)
                        if payer_ids:
                            return payer_ids
                except Exception:
                    pass
        except ImportError:
            pass
        return list(_OPTUMAI_HARDCODED_PAYER_IDS)

    # UHC-only list – keep STRICT. Do not augment with non-UHC payers.
    uhc_payer_ids = [
        "87726", "03432", "96385", "95467", "86050", "86047", "95378", "06111", "37602"
    ]
    # Default to UHCAPI for any other endpoint name
    return uhc_payer_ids

def get_valid_payer_ids_for_endpoint(client, endpoint_name):
    """
    Resolve the valid payer IDs for a specific endpoint using crosswalk storage
    with a safe fallback to hardcoded defaults.

    For OPTUMAI: uses get_optumai_payer_ids (optum_payer_list -> endpoint_payer_ids -> hardcoded).
    Does not persist OPTUMAI to crosswalk; payer-list updater writes only to optum_payer_list.
    For other endpoints: reads endpoint_payer_ids, else initializes from defaults and persists.
    """
    try:
        base_config = None
        crosswalk = None
        if ensure_full_config_loaded is not None:
            base_config, crosswalk = ensure_full_config_loaded(
                getattr(client, 'config', None),
                getattr(client, 'crosswalk', None)
            )
        else:
            print("Warning: IN api_core, ensure_full_config_loaded is not available; falling back to MediLink_ConfigLoader.load_configuration().")
            MediLink_ConfigLoader.log(
                "Fallback: ensure_full_config_loaded not available in get_valid_payer_ids_for_endpoint; using MediLink_ConfigLoader.load_configuration().",
                level="WARNING"
            )
            base_config, crosswalk = MediLink_ConfigLoader.load_configuration()

        if endpoint_name == 'OPTUMAI':
            try:
                from MediCafe.payer_list_updater import get_optumai_payer_ids
                payer_ids = get_optumai_payer_ids(crosswalk=crosswalk, config=base_config)
                if payer_ids:
                    return payer_ids
            except ImportError:
                pass
            return list(_OPTUMAI_HARDCODED_PAYER_IDS)

        cw_ep = crosswalk.get('endpoint_payer_ids', {}) if isinstance(crosswalk, dict) else {}
        existing = cw_ep.get(endpoint_name)
        if isinstance(existing, list) and len(existing) > 0:
            return existing

        defaults = _get_default_endpoint_payer_ids(endpoint_name)
        if isinstance(crosswalk, dict):
            if 'endpoint_payer_ids' not in crosswalk:
                crosswalk['endpoint_payer_ids'] = {}
            crosswalk['endpoint_payer_ids'][endpoint_name] = list(defaults)
            if save_crosswalk is not None:
                try:
                    save_crosswalk(client, base_config, crosswalk, skip_api_operations=True)
                except Exception:
                    pass
        return defaults
    except Exception:
        return _get_default_endpoint_payer_ids(endpoint_name)


# -----------------------------------------------------------------------------
# Single routing layer: crosswalk-primary, hardcoded fallback
# -----------------------------------------------------------------------------
# Operations: search_claim, search_277ca, eligibility, claim_submission (align with OPTUMAI_FEATURE_KEYS in payer_list_updater)


def resolve_operation_route(client, payer_id, operation):
    """
    Single place to decide which endpoint (if any) should handle this payer and operation.
    Crosswalk is primary; hardcoded lists used when crosswalk is missing or fails.

    Args:
        client: API client instance (for config/crosswalk load).
        payer_id: Payer ID string.
        operation: One of 'search_claim', 'search_277ca', 'eligibility', 'claim_submission'.

    Returns:
        tuple: (endpoint_name: str or None, reason: str or None).
            e.g. ('OPTUMAI', None), ('UHCAPI', None), or (None, 'payer_not_supported').
    """
    if not payer_id or not operation:
        return None, 'missing_payer_or_operation'
    operation = str(operation).strip()
    payer_id = str(payer_id).strip()

    try:
        base_config = None
        crosswalk = None
        if ensure_full_config_loaded is not None:
            base_config, crosswalk = ensure_full_config_loaded(
                getattr(client, 'config', None),
                getattr(client, 'crosswalk', None)
            )
        else:
            base_config, crosswalk = MediLink_ConfigLoader.load_configuration()
    except Exception:
        crosswalk = None
        base_config = None

    # When crosswalk is missing or empty, use hardcoded lists only.
    uhc_defaults = _get_default_endpoint_payer_ids('UHCAPI')
    optumai_defaults = _get_default_endpoint_payer_ids('OPTUMAI')
    if not crosswalk or not isinstance(crosswalk, dict):
        if operation == 'search_277ca':
            # Conservative: do not assume OPTUMAI supports 277CA when crosswalk unavailable.
            return (None, 'crosswalk_unavailable') if payer_id not in optumai_defaults else ('OPTUMAI', None)
        if operation in ('search_claim', 'eligibility', 'claim_submission'):
            if payer_id in optumai_defaults:
                return ('OPTUMAI', None)
            if payer_id in uhc_defaults:
                return ('UHCAPI', None)
        return (None, 'payer_not_in_defaults')

    try:
        from MediCafe.payer_list_updater import optumai_supports_feature
    except ImportError:
        optumai_supports_feature = None

    # OPTUMAI operations: check feature support first (map claim_submission -> submit_with_precheck).
    _feature_key = 'submit_with_precheck' if operation == 'claim_submission' else operation
    if operation in ('search_claim', 'search_277ca', 'eligibility', 'claim_submission'):
        if optumai_supports_feature and optumai_supports_feature(crosswalk, payer_id, _feature_key):
            return ('OPTUMAI', None)
        # Payer not supported for this operation on OPTUMAI; try UHCAPI if applicable.
        valid_uhc = get_valid_payer_ids_for_endpoint(client, 'UHCAPI')
        if payer_id in valid_uhc:
            # 277CA: current code path is OPTUMAI-only; no UHCAPI 277CA in adapter. Return None so caller skips OPTUMAI.
            if operation == 'search_277ca':
                return (None, 'search_277ca_not_supported_for_payer')
            return ('UHCAPI', None)
        return (None, 'payer_not_supported')

    return (None, 'unknown_operation')


def get_api_eligible_payer_ids_for_claim_status(client):
    """
    List of payer IDs valid for claim-status flows (recent submissions, payer rotation).
    Crosswalk-primary; hardcoded list fallback when crosswalk is missing or empty.

    Returns:
        list: Deduplicated payer IDs (union of OPTUMAI and UHCAPI valid payers).
    """
    try:
        optumai_ids = get_valid_payer_ids_for_endpoint(client, 'OPTUMAI')
        uhc_ids = get_valid_payer_ids_for_endpoint(client, 'UHCAPI')
        seen = set()
        result = []
        for pid in (optumai_ids or []):
            if pid and pid not in seen:
                seen.add(pid)
                result.append(pid)
        for pid in (uhc_ids or []):
            if pid and pid not in seen:
                seen.add(pid)
                result.append(pid)
        if result:
            return result
    except Exception:
        pass
    return _get_default_endpoint_payer_ids('UHCAPI')


class BaseAPIClient:
    def __init__(self, config):
        self.config = config
        self.token_cache = TokenCache()
        # Log when a new APIClient instance is created (helps diagnose token cache issues)
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("New APIClient instance created (token cache is instance-specific)", level="DEBUG")

    def get_access_token(self, endpoint_name):
        raise NotImplementedError("Subclasses should implement this!")

    def make_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None):
        raise NotImplementedError("Subclasses should implement this!")

class APIClient(BaseAPIClient):
    def __init__(self, config=None):
        if config is None:
            config, _ = MediLink_ConfigLoader.load_configuration()
        super().__init__(config)
        
        # Add enhanced features if available
        # XP/Python34 Compatibility: Enhanced error handling with verbose output
        try:
            from MediCafe.api_utils import APICircuitBreaker, APICache, APIRateLimiter
            MediLink_ConfigLoader.log("Successfully imported MediCafe.api_utils", level="DEBUG")
        except ImportError as e:
            MediLink_ConfigLoader.log("Warning: MediCafe.api_utils not available: {}".format(str(e)), level="WARNING")
            print("Warning: MediCafe.api_utils import failed: {}".format(str(e)))
            APICircuitBreaker = None
            APICache = None
            APIRateLimiter = None
        except Exception as e:
            MediLink_ConfigLoader.log("Unexpected error importing MediCafe.api_utils: {}".format(str(e)), level="ERROR")
            print("Error: Unexpected MediCafe.api_utils import error: {}".format(str(e)))
            APICircuitBreaker = None
            APICache = None
            APIRateLimiter = None
        
        try:
            try:
                from MediLink import MediLink_insurance_utils
            except Exception:
                MediLink_insurance_utils = None
            if MediLink_insurance_utils is None:
                import importlib
                MediLink_insurance_utils = importlib.import_module('MediLink.MediLink_insurance_utils')
            get_feature_flag = MediLink_insurance_utils.get_feature_flag
            MediLink_ConfigLoader.log("Successfully imported MediLink.MediLink_insurance_utils", level="DEBUG")
        except ImportError as e:
            MediLink_ConfigLoader.log("Warning: MediLink.MediLink_insurance_utils not available: {}".format(str(e)), level="WARNING")
            print("Warning: MediLink.MediLink_insurance_utils import failed: {}".format(str(e)))
            # Provide fallback function
            def get_feature_flag(flag_name, default=False):
                MediLink_ConfigLoader.log("Using fallback get_feature_flag for '{}', returning default: {}".format(flag_name, default), level="DEBUG")
                return default
        except Exception as e:
            MediLink_ConfigLoader.log("Unexpected error importing MediLink.MediLink_insurance_utils: {}".format(str(e)), level="ERROR")
            print("Error: Unexpected MediLink.MediLink_insurance_utils import error: {}".format(str(e)))
            # Provide fallback function
            def get_feature_flag(flag_name, default=False):
                MediLink_ConfigLoader.log("Using fallback get_feature_flag for '{}', returning default: {}".format(flag_name, default), level="DEBUG")
                return default
        
        # Initialize enhancements with error handling
        try:
            enable_circuit_breaker = get_feature_flag('api_circuit_breaker', default=False)
            enable_caching = get_feature_flag('api_caching', default=False)
            enable_rate_limiting = get_feature_flag('api_rate_limiting', default=False)
            
            self.circuit_breaker = APICircuitBreaker() if (enable_circuit_breaker and APICircuitBreaker) else None
            self.api_cache = APICache() if (enable_caching and APICache) else None
            self.rate_limiter = APIRateLimiter() if (enable_rate_limiting and APIRateLimiter) else None
            
            if any([enable_circuit_breaker, enable_caching, enable_rate_limiting]):
                MediLink_ConfigLoader.log("Enhanced API client initialized with circuit_breaker={}, caching={}, rate_limiting={}".format(
                    enable_circuit_breaker, enable_caching, enable_rate_limiting), level="INFO")
            else:
                MediLink_ConfigLoader.log("API enhancements disabled or not available, using standard client", level="DEBUG")
        except Exception as e:
            MediLink_ConfigLoader.log("Error initializing API enhancements: {}. Using standard client.".format(str(e)), level="WARNING")
            print("Warning: API enhancement initialization failed: {}".format(str(e)))
            self.circuit_breaker = None
            self.api_cache = None
            self.rate_limiter = None

    def _get_endpoint_env_settings(self, endpoint_name):
        """Return endpoint-scoped env-header settings with backward-compatible defaults."""
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_cfg = medi.get('endpoints', {}).get(endpoint_name, {}) if isinstance(medi, dict) else {}
        except Exception:
            endpoint_cfg = {}

        # Defensive normalization: endpoint entry may exist but be null/non-dict in YAML.
        if not isinstance(endpoint_cfg, dict):
            endpoint_cfg = {}

        def _parse_bool(value, default_value):
            if isinstance(value, bool):
                return value
            if value is None:
                return default_value
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in ('true', '1', 'yes', 'y', 'on'):
                    return True
                if normalized in ('false', '0', 'no', 'n', 'off', ''):
                    return False
            return default_value

        use_env_header_default = (endpoint_name == 'UHCAPI')
        use_env_header = _parse_bool(endpoint_cfg.get('use_env_header'), use_env_header_default)

        header_name = endpoint_cfg.get('env_header_name') or 'env'
        indicators = endpoint_cfg.get('staging_indicators') or ['stg', 'stage', 'test']
        if not isinstance(indicators, list):
            indicators = ['stg', 'stage', 'test']

        return use_env_header, str(header_name), [str(x).lower() for x in indicators if x]

    def detect_environment(self, endpoint_name='UHCAPI'):
        """Detect if endpoint api_url appears to target non-production environment."""
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_cfg = medi.get('endpoints', {}).get(endpoint_name, {}) if isinstance(medi, dict) else {}
            if not isinstance(endpoint_cfg, dict):
                endpoint_cfg = {}
            api_url = str(endpoint_cfg.get('api_url', '') or '')
            _, _, staging_indicators = self._get_endpoint_env_settings(endpoint_name)
            api_url_l = api_url.lower()

            MediLink_ConfigLoader.log("DEBUG: Found API URL for {}: {}".format(endpoint_name, api_url), level="DEBUG")

            for token in staging_indicators:
                if token and token in api_url_l:
                    MediLink_ConfigLoader.log(
                        "DEBUG: Detected staging environment for {} from URL token '{}': {}".format(endpoint_name, token, api_url),
                        level="DEBUG"
                    )
                    return 'sandbox'

            MediLink_ConfigLoader.log("DEBUG: No staging indicators found in {} URL: {}".format(endpoint_name, api_url), level="DEBUG")
        except Exception as e:
            MediLink_ConfigLoader.log("DEBUG: Error in environment detection for {}: {}".format(endpoint_name, e), level="DEBUG")

        return None

    def add_environment_headers(self, headers, endpoint_name):
        """Add endpoint-configured environment header when enabled."""
        use_env_header, header_name, _ = self._get_endpoint_env_settings(endpoint_name)
        if not use_env_header:
            return headers

        environment = self.detect_environment(endpoint_name)
        if environment:
            headers[header_name] = environment
            MediLink_ConfigLoader.log(
                "Added {} parameter for staging environment: {}".format(header_name, environment),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
        else:
            MediLink_ConfigLoader.log(
                "No {} parameter - using production environment".format(header_name),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
        return headers

    def get_access_token(self, endpoint_name, quiet_mode=False):
        MediLink_ConfigLoader.log("[Get Access Token] Called for {}".format(endpoint_name), level="DEBUG")
        current_time = time.time()
        cached_token = self.token_cache.get(endpoint_name, current_time, quiet_mode=quiet_mode)
        
        if cached_token:
            expires_at = self.token_cache.tokens[endpoint_name]['expires_at']
            MediLink_ConfigLoader.log("Cached token expires at {}".format(expires_at), level="DEBUG")
            return cached_token
        
        # Check if token request has already failed for this endpoint this session
        if self.token_cache.is_token_request_failed(endpoint_name):
            failure_info = self.token_cache.get_token_failure_info(endpoint_name)
            error_code = failure_info.get('error_code', 'unknown') if failure_info else 'unknown'
            # Suppress or reduce logging when in quiet mode
            log_level = "DEBUG" if quiet_mode else "INFO"
            MediLink_ConfigLoader.log(
                "Skipping token request for {} - token request already failed this session (error: {})".format(
                    endpoint_name, error_code),
                level=log_level
            )
            return None
        
        # Validate that we actually need a token before fetching
        # Check if the endpoint configuration exists and is valid
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_config = medi.get('endpoints', {}).get(endpoint_name)
            if not endpoint_config:
                MediLink_ConfigLoader.log("No configuration found for endpoint: {}".format(endpoint_name), level="ERROR")
                return None
                
            # Validate required configuration fields
            required_fields = ['token_url', 'client_id', 'client_secret']
            missing_fields = [field for field in required_fields if field not in endpoint_config]
            if missing_fields:
                MediLink_ConfigLoader.log("Missing required configuration fields for {}: {}".format(endpoint_name, missing_fields), level="ERROR")
                return None
                
        except KeyError:
            MediLink_ConfigLoader.log("Endpoint {} not found in configuration".format(endpoint_name), level="ERROR")
            return None
        except Exception as e:
            MediLink_ConfigLoader.log("Error validating endpoint configuration for {}: {}".format(endpoint_name, str(e)), level="ERROR")
            return None
        
        # If no valid token, fetch a new one
        token_url = endpoint_config['token_url']

        def _emit_token_failure_diag(error_code=None, error_description=None, http_status=None, exception_text=None):
            """
            Always-on redacted diagnostics for token failures.
            Safe for logs/support bundles (no secrets or tokens).
            Console output is suppressed when quiet_mode is True.
            """
            try:
                from MediCafe.token_diagnostics import build_token_diagnostics_block
                block = build_token_diagnostics_block(
                    endpoint_name=endpoint_name,
                    token_url=token_url,
                    client_id=endpoint_config.get('client_id'),
                    client_secret=endpoint_config.get('client_secret'),
                    scope=endpoint_config.get('scope'),
                    grant_type='client_credentials',
                    config_path=os.environ.get('MEDICAFE_CONFIG_FILE', '').strip(),
                    http_status=http_status,
                    error_code=error_code,
                    error_description=error_description,
                    exception_text=exception_text,
                    note="Redacted: no secrets or tokens are shown. Compare sha256_8/len/last4 across machines."
                )
                MediLink_ConfigLoader.log(
                    block,
                    level="ERROR",
                    console_output=(CONSOLE_LOGGING and not quiet_mode)
                )
            except Exception:
                pass
        
        # Standard token request logic for all endpoints (including AVAILITY)
        # AVAILITY uses scope=healthcare-hipaa-transactions-demo per test telemetry
        data = {
            'grant_type': 'client_credentials',
            'client_id': endpoint_config['client_id'],
            'client_secret': endpoint_config['client_secret']
        }

        # NOTE: Scope parameter is OPTIONAL for OPTUM API token requests.
        # According to OPTUM API documentation and investigation (see docs/OPTUMAI_TOKEN_SCOPE_INVESTIGATION.md),
        # scopes are auto-granted based on client credentials and subscription configuration in the OPTUMAI portal.
        # The scope parameter in the token request is not required - OPTUM determines available scopes
        # (e.g., read_healthcheck for eligibility endpoint) based on the client's subscription.
        # We include scope in the request if present in config for informational/debugging purposes,
        # but it is not validated as it's not part of the standard OPTUM token request flow.
        # For other endpoints that may require explicit scope, the conditional logic below handles it.
        if 'scope' in endpoint_config:
            data['scope'] = endpoint_config['scope']
            # Log scope value for informational/debugging purposes (OPTUM doesn't require it)
            if endpoint_name == 'OPTUMAI':
                MediLink_ConfigLoader.log(
                    "Scope '{}' found in OPTUMAI config (informational only - OPTUM auto-grants scopes via subscription)".format(
                        endpoint_config['scope']),
                    level="DEBUG"
                )

        headers = {'Content-Type': 'application/x-www-form-urlencoded'}

        # DEBUG: Log token request (no credentials)
        MediLink_ConfigLoader.log("Requesting new token for {} from {}".format(endpoint_name, token_url), level="DEBUG")

        try:
            response = requests.post(token_url, headers=headers, data=data)

            # Try to parse JSON regardless of HTTP status so we can surface OAuth error_description.
            token_data = None
            try:
                token_data = response.json()
            except Exception:
                token_data = None

            # OAuth providers often return 400 with JSON: {"error": "...", "error_description": "..."}
            if isinstance(token_data, dict) and 'error' in token_data:
                error_code = token_data.get('error', 'unknown')
                error_desc = token_data.get('error_description', 'N/A')
                MediLink_ConfigLoader.log(
                    "Token request failed for {}: error={}, error_description={}".format(
                        endpoint_name, error_code, error_desc),
                    level="ERROR"
                )
                # Mark this endpoint as failed to prevent repeated token requests
                try:
                    self.token_cache.mark_token_request_failed(
                        endpoint_name,
                        error_code,
                        error_description=error_desc,
                        http_status=getattr(response, 'status_code', None),
                        token_url=token_url
                    )
                except Exception:
                    self.token_cache.mark_token_request_failed(endpoint_name, error_code)
                _emit_token_failure_diag(
                    error_code=error_code,
                    error_description=error_desc,
                    http_status=getattr(response, 'status_code', None),
                    exception_text=None
                )
                return None

            # If non-2xx and no OAuth JSON error, raise for status to hit RequestException handler.
            try:
                response.raise_for_status()
            except Exception:
                raise

            # If we couldn't parse JSON earlier, try again now (2xx).
            if token_data is None:
                token_data = response.json()

            # Validate that access_token is present in response
            if not isinstance(token_data, dict) or 'access_token' not in token_data:
                keys = list(token_data.keys()) if isinstance(token_data, dict) else []
                MediLink_ConfigLoader.log(
                    "Invalid token response for {}: response missing 'access_token'. Keys received: {}".format(
                        endpoint_name, keys),
                    level="ERROR"
                )
                # Mark this endpoint as failed to prevent repeated token requests
                try:
                    self.token_cache.mark_token_request_failed(
                        endpoint_name,
                        'missing_access_token',
                        error_description="missing access_token in token response",
                        http_status=getattr(response, 'status_code', None),
                        token_url=token_url
                    )
                except Exception:
                    self.token_cache.mark_token_request_failed(endpoint_name, 'missing_access_token')
                _emit_token_failure_diag(
                    error_code='missing_access_token',
                    error_description="missing access_token in token response",
                    http_status=getattr(response, 'status_code', None),
                    exception_text=None
                )
                return None
            
            access_token = token_data['access_token']
            # Use actual expires_in from response (OPTUM docs state 3600 seconds, but use actual value)
            expires_in = token_data.get('expires_in', 3600)
            
            # DEBUG: Log response structure (no token values)
            MediLink_ConfigLoader.log("Token response keys: {}".format(list(token_data.keys())), level="DEBUG")
            
            # Log token acquisition details (without exposing secrets)
            if 'scope' in endpoint_config:
                scope_info = "scope: {}".format(endpoint_config['scope'])
            else:
                scope_info = "scope: none (OPTUM auto-grants via subscription)"
            MediLink_ConfigLoader.log(
                "Obtained NEW token for endpoint: {} (expires_in: {}s, {})".format(
                    endpoint_name, expires_in, scope_info),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
            
            # Log if expires_in differs from expected 3600 (per OPTUM docs)
            if expires_in != 3600:
                MediLink_ConfigLoader.log(
                    "Token expiration time ({}) differs from OPTUM documented value (3600s). Using actual value from response.".format(
                        expires_in),
                    level="INFO"
                )

            self.token_cache.set(endpoint_name, access_token, expires_in, current_time)
            # Clear any previous token request failure flag since we successfully obtained a token
            self.token_cache.clear_token_request_failure(endpoint_name)
            return access_token
        except requests.exceptions.RequestException as e:
            MediLink_ConfigLoader.log("Failed to obtain token for {}: {}".format(endpoint_name, str(e)), level="ERROR")
            # Mark as failed if it's an auth-related error (401, 403)
            error_str = str(e)
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                if status_code in (401, 403):
                    # Capture response text snippet when available (safe: should not include secrets).
                    resp_text = None
                    try:
                        resp_text = getattr(e.response, 'text', None)
                    except Exception:
                        resp_text = None
                    try:
                        self.token_cache.mark_token_request_failed(
                            endpoint_name,
                            'http_{}'.format(status_code),
                            error_description=resp_text,
                            http_status=status_code,
                            token_url=token_url
                        )
                    except Exception:
                        self.token_cache.mark_token_request_failed(endpoint_name, 'http_{}'.format(status_code))
                    _emit_token_failure_diag(
                        error_code='http_{}'.format(status_code),
                        error_description=resp_text,
                        http_status=status_code,
                        exception_text=str(e)
                    )
            # Emit concise connectivity hint for DNS/proxy issues (best-effort, console-gated)
            try:
                from MediCafe.api_hints import emit_network_hint
                emit_network_hint(endpoint_name, token_url, e, console=CONSOLE_LOGGING)
            except Exception:
                pass
            return None
        except (KeyError, ValueError) as e:
            MediLink_ConfigLoader.log("Invalid token response for {}: unexpected error ({})".format(endpoint_name, str(e)), level="ERROR")
            # Mark as failed for parse/validation errors
            try:
                self.token_cache.mark_token_request_failed(
                    endpoint_name,
                    'parse_error',
                    error_description=str(e),
                    http_status=None,
                    token_url=token_url
                )
            except Exception:
                self.token_cache.mark_token_request_failed(endpoint_name, 'parse_error')
            _emit_token_failure_diag(
                error_code='parse_error',
                error_description=str(e),
                http_status=None,
                exception_text=str(e)
            )
            return None

    def make_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        # Try enhanced API call if available
        if hasattr(self, 'circuit_breaker') and self.circuit_breaker:
            try:
                return self._make_enhanced_api_call(endpoint_name, call_type, url_extension, params, data, headers, quiet_mode=quiet_mode)
            except Exception as e:
                MediLink_ConfigLoader.log("Enhanced API call failed, falling back to standard: {}".format(str(e)), level="WARNING")
        
        # Standard API call logic
        return self._make_standard_api_call(endpoint_name, call_type, url_extension, params, data, headers, quiet_mode=quiet_mode)
    
    def _make_enhanced_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        """Enhanced API call with circuit breaker, caching, and rate limiting"""
        # Check cache first (for GET requests)
        if self.api_cache and call_type == 'GET':
            cached_result = self.api_cache.get(endpoint_name, call_type, url_extension, params)
            if cached_result is not None:
                MediLink_ConfigLoader.log("Cache hit for {} {} {}".format(call_type, endpoint_name, url_extension), level="DEBUG")
                return cached_result
        
        # Check rate limits
        if self.rate_limiter:
            self.rate_limiter.wait_if_needed()
        
        # Make call with circuit breaker protection
        result = self.circuit_breaker.call_with_breaker(
            self._make_standard_api_call, endpoint_name, call_type, url_extension, params, data, headers, quiet_mode)
        
        # Record rate limit call
        if self.rate_limiter:
            self.rate_limiter.record_call()
        
        # Cache result (for GET requests)
        if self.api_cache and call_type == 'GET':
            self.api_cache.set(result, endpoint_name, call_type, url_extension, params)
        
        return result
    
    def _make_standard_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        """Standard API call logic preserved for compatibility"""
        token = self.get_access_token(endpoint_name, quiet_mode=quiet_mode)
        if token:
            MediLink_ConfigLoader.log("[Make API Call] Token found for {}".format(endpoint_name), level="DEBUG")
        else:
            # Suppress or reduce logging when in quiet mode
            log_level = "DEBUG" if quiet_mode else "ERROR"
            MediLink_ConfigLoader.log("[Make API Call] No token obtained for {}".format(endpoint_name), level=log_level)
            raise ValueError("No access token available for endpoint: {}".format(endpoint_name))

        if headers is None:
            headers = {}
        # Set Authorization (always required)
        headers['Authorization'] = 'Bearer {}'.format(token)
        # Set Accept only if caller didn't provide it (allows AVAILITY application.json override)
        if 'Accept' not in headers:
            headers['Accept'] = 'application/json'
        
        # Add environment-specific headers automatically
        headers = self.add_environment_headers(headers, endpoint_name)
        
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(self.config)
        base_url = medi.get('endpoints', {}).get(endpoint_name, {}).get('api_url', '')
        if url_extension and isinstance(url_extension, str) and url_extension.startswith(('http://', 'https://')):
            url = url_extension
            MediLink_ConfigLoader.log(
                "Warning: Absolute URL provided for endpoint {}. Using url_extension as full URL.".format(endpoint_name),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        else:
            if not base_url:
                raise ValueError("Missing api_url for endpoint {}".format(endpoint_name))
            # Normalize URL construction: remove trailing slash from base_url, ensure url_extension starts with /
            # CRITICAL: Trailing slash in url_extension causes OPTUMAI gateway misrouting
            base_url = base_url.rstrip('/')
            if url_extension:
                url_extension = url_extension.strip()
                if not url_extension.startswith('/'):
                    url_extension = '/' + url_extension
                # Remove trailing slash from url_extension - CRITICAL for OPTUMAI Claim Actions
                url_extension = url_extension.rstrip('/')
            url = base_url + url_extension

        # VERBOSE LOGGING: Log all request details before making the call
        if DEBUG:
            MediLink_ConfigLoader.log("=" * 80, level="INFO")
            MediLink_ConfigLoader.log("VERBOSE API CALL DETAILS", level="INFO")
            MediLink_ConfigLoader.log("=" * 80, level="INFO")
            MediLink_ConfigLoader.log("Endpoint Name: {}".format(endpoint_name), level="INFO")
            MediLink_ConfigLoader.log("Call Type: {}".format(call_type), level="INFO")
            MediLink_ConfigLoader.log("Base URL: {}".format(base_url), level="INFO")
            MediLink_ConfigLoader.log("URL Extension: {}".format(url_extension), level="INFO")
            MediLink_ConfigLoader.log("Full URL: {}".format(url), level="INFO")
            MediLink_ConfigLoader.log("Headers: {}".format(json.dumps(headers, indent=2)), level="INFO")
            if params:
                MediLink_ConfigLoader.log("Query Parameters: {}".format(json.dumps(params, indent=2)), level="INFO")
            else:
                MediLink_ConfigLoader.log("Query Parameters: None", level="INFO")
            if data:
                MediLink_ConfigLoader.log("Request Data: {}".format(json.dumps(data, indent=2)), level="INFO")
            else:
                MediLink_ConfigLoader.log("Request Data: None", level="INFO")
            MediLink_ConfigLoader.log("=" * 80, level="INFO")

        try:
            masked_headers = headers.copy()
            if 'Authorization' in masked_headers:
                masked_headers['Authorization'] = 'Bearer ***'

            def make_request():
                if call_type == 'GET':
                    if DEBUG:
                        MediLink_ConfigLoader.log("Making GET request to: {}".format(url), level="INFO")
                    return requests.get(url, headers=headers, params=params)
                elif call_type == 'POST':
                    # Check if there are custom headers (any headers beyond Authorization and Accept)
                    custom_headers = {k: v for k, v in headers.items() if k not in ['Authorization', 'Accept']}
                    
                    if custom_headers:
                        # Log that custom headers were detected
                        MediLink_ConfigLoader.log("Custom headers detected: {}".format(custom_headers), level="DEBUG")
                    else:
                        # Set default Content-Type if no custom headers
                        headers['Content-Type'] = 'application/json'
                    
                    # Phase 1 Fix: Handle pre-serialized JSON strings for OPTUMAI Claim Actions
                    # Some GraphQL APIs require exact JSON format - if data is already a string,
                    # use data= parameter instead of json= to preserve exact formatting
                    if isinstance(data, str):
                        # Data is already serialized (e.g., from claim_actions_adapter)
                        # Use data= parameter to send as-is, ensuring Content-Type is set
                        if 'Content-Type' not in headers:
                            headers['Content-Type'] = 'application/json'
                        if DEBUG:
                            MediLink_ConfigLoader.log("Making POST request with pre-serialized JSON string to: {}".format(url), level="INFO")
                        return requests.post(url, headers=headers, data=data)
                    else:
                        # Data is a dict - use json= parameter for auto-serialization (standard behavior)
                        if DEBUG:
                            MediLink_ConfigLoader.log("Making POST request to: {}".format(url), level="INFO")
                        return requests.post(url, headers=headers, json=data)
                elif call_type == 'DELETE':
                    if DEBUG:
                        MediLink_ConfigLoader.log("Making DELETE request to: {}".format(url), level="INFO")
                    return requests.delete(url, headers=headers)
                else:
                    raise ValueError("Unsupported call type: {}".format(call_type))

            route_retry_performed = False
            trailing_question_tried = False

            while True:
                try:
                    # Make initial request
                    response = make_request()

                    # VERBOSE LOGGING: Log response details
                    if DEBUG:
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")
                        MediLink_ConfigLoader.log("VERBOSE RESPONSE DETAILS", level="INFO")
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")
                        MediLink_ConfigLoader.log("Response Status Code: {}".format(response.status_code), level="INFO")
                        MediLink_ConfigLoader.log("Response Headers: {}".format(json.dumps(dict(response.headers), indent=2)), level="INFO")
                        
                        try:
                            response_json = response.json()
                            MediLink_ConfigLoader.log("Response JSON: {}".format(json.dumps(response_json, indent=2)), level="INFO")
                        except ValueError:
                            MediLink_ConfigLoader.log("Response Text (not JSON): {}".format(response.text), level="INFO")
                        
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")

                    # Handle 401 Unauthorized errors with token refresh and retry
                    if response.status_code == 401:
                        # Parse error response for diagnostics
                        trace_id = None
                        error_type = None
                        try:
                            error_response = response.json()
                            trace_id = error_response.get('traceId') or error_response.get('trace_id')
                            error_type = error_response.get('error') or error_response.get('error_type')
                            error_desc = error_response.get('error_description', '')
                            
                            # Check for "invalid_access_token" specifically
                            is_invalid_token = (error_type == 'invalid_access_token' or 
                                               'invalid_access_token' in error_desc.lower())
                            if is_invalid_token:
                                MediLink_ConfigLoader.log(
                                    "401 Unauthorized: invalid_access_token detected for endpoint {}. "
                                    "Clearing token cache and attempting refresh...".format(endpoint_name),
                                    level="WARNING",
                                    console_output=CONSOLE_LOGGING
                                )
                                if trace_id:
                                    MediLink_ConfigLoader.log("Trace ID: {}".format(trace_id), level="INFO")
                                
                                # Clear token cache for this endpoint (401 invalid_access_token error)
                                self.token_cache.clear(endpoint_name, reason="401 invalid_access_token")
                                
                                # Attempt to get a fresh token
                                fresh_token = self.get_access_token(endpoint_name)
                                if fresh_token:
                                    # Update headers with fresh token
                                    headers['Authorization'] = 'Bearer {}'.format(fresh_token)
                                    MediLink_ConfigLoader.log(
                                        "Token refreshed successfully. Retrying request to {}...".format(url),
                                        level="INFO",
                                        console_output=CONSOLE_LOGGING
                                    )
                                    
                                    # Retry the request once with fresh token
                                    time.sleep(0.5)  # Brief delay before retry
                                    response = make_request()
                                    
                                    # Log retry result
                                    if response.status_code == 200:
                                        MediLink_ConfigLoader.log(
                                            "Retry successful after token refresh! Request to {} now returned 200 status code.".format(url),
                                            level="INFO",
                                            console_output=CONSOLE_LOGGING
                                        )
                                    else:
                                        MediLink_ConfigLoader.log(
                                            "Retry failed after token refresh. Request to {} still returned {} status code.".format(
                                                url, response.status_code),
                                            level="ERROR",
                                            console_output=CONSOLE_LOGGING
                                        )
                                        if trace_id:
                                            MediLink_ConfigLoader.log(
                                                "Trace ID: {}. This may indicate a subscription/configuration issue. "
                                                "Verify client credentials and subscription access in OPTUMAI portal.".format(trace_id),
                                                level="ERROR",
                                                console_output=CONSOLE_LOGGING
                                            )
                                else:
                                    MediLink_ConfigLoader.log(
                                        "Failed to obtain fresh token for endpoint {}. Cannot retry request.".format(endpoint_name),
                                        level="ERROR",
                                        console_output=CONSOLE_LOGGING
                                    )
                        except (ValueError, KeyError) as e:
                            # Error response not in expected format
                            MediLink_ConfigLoader.log(
                                "401 Unauthorized error for endpoint {}. Could not parse error response: {}".format(
                                    endpoint_name, str(e)),
                                level="ERROR",
                                console_output=CONSOLE_LOGGING
                            )
                            # Still attempt token refresh (fallback for unparseable 401 responses)
                            self.token_cache.clear(endpoint_name, reason="401 unparseable error response")
                            fresh_token = self.get_access_token(endpoint_name)
                            if fresh_token:
                                headers['Authorization'] = 'Bearer {}'.format(fresh_token)
                                MediLink_ConfigLoader.log(
                                    "Token refreshed (unparseable 401 response). Retrying request...",
                                    level="INFO",
                                    console_output=CONSOLE_LOGGING
                                )
                                time.sleep(0.5)
                                response = make_request()
                            else:
                                MediLink_ConfigLoader.log(
                                    "Failed to obtain fresh token for endpoint {}. Cannot retry request.".format(endpoint_name),
                                    level="ERROR",
                                    console_output=CONSOLE_LOGGING
                                )

                    # If we get a 5xx error, wait and retry once
                    if 500 <= response.status_code < 600:
                        error_msg = "Received {} error from server for {} request to {}. Waiting 1 second before retry...".format(
                            response.status_code, call_type, url
                        )
                        MediLink_ConfigLoader.log(error_msg, level="WARNING")
                        
                        # Add more verbose logging for 504 errors specifically
                        if response.status_code == 504:
                            MediLink_ConfigLoader.log(
                                "504 Gateway Timeout detected. This usually indicates the server is overloaded or taking too long to respond. " 
                                "Retrying after 1 second delay...", 
                                level="WARNING"
                            )
                        
                        time.sleep(1)
                        response = make_request()
                        
                        # Log the retry result
                        if response.status_code == 200:
                            MediLink_ConfigLoader.log(
                                "Retry successful! Request to {} now returned 200 status code.".format(url),
                                level="INFO"
                            )
                        else:
                            MediLink_ConfigLoader.log(
                                "Retry failed. Request to {} still returned {} status code.".format(url, response.status_code),
                                level="ERROR"
                            )

                    # Handle trailing '?' fallback for POST requests with 404/500 errors
                    # Some API gateways (e.g., UHC Claims API) require trailing '?' for POST requests without query params
                    # Skip this retry for OPTUMAI endpoints - we know the correct format (no trailing '?' needed)
                    if endpoint_name == 'OPTUMAI':
                        # OPTUMAI requires exact path format per OpenAPI spec - no trailing '?' needed
                        # Log that we're skipping the retry to avoid unnecessary attempts
                        if response.status_code in [404, 500] and call_type == 'POST' and not trailing_question_tried:
                            MediLink_ConfigLoader.log(
                                "Skipping trailing '?' retry for OPTUMAI endpoint (known correct format: exact path per OpenAPI spec). Status: {}".format(
                                    response.status_code),
                                level="DEBUG"
                            )
                            trailing_question_tried = True  # Mark as tried to prevent further retry attempts
                    elif (response.status_code in [404, 500] and 
                        call_type == 'POST' and 
                        not trailing_question_tried and
                        (params is None or len(params) == 0) and
                        not url.endswith('?')):
                        
                        original_status_code = response.status_code
                        original_url = url
                        url = url + '?'
                        trailing_question_tried = True
                        
                        MediLink_ConfigLoader.log(
                            "Received {} error on POST request to {}. Retrying with trailing '?' as API gateway may require it...".format(
                                original_status_code, original_url),
                            level="INFO",
                            console_output=CONSOLE_LOGGING
                        )
                        
                        # Brief delay before retry
                        time.sleep(0.5)
                        response = make_request()
                        
                        # Log the retry result
                        if response.status_code == 200 or (200 <= response.status_code < 300):
                            MediLink_ConfigLoader.log(
                                "Retry successful with trailing '?' appended. Original error was {}. New URL: {}".format(
                                    original_status_code, url),
                                level="INFO",
                                console_output=CONSOLE_LOGGING
                            )
                        else:
                            MediLink_ConfigLoader.log(
                                "Retry with trailing '?' failed. Still received {} status code.".format(response.status_code),
                                level="WARNING",
                                console_output=CONSOLE_LOGGING
                            )
                        
                        # Continue the loop to allow full error handling on the retry response
                        continue

                    # Raise an HTTPError if the response was unsuccessful
                    response.raise_for_status()

                    return response.json()

                except requests.exceptions.HTTPError as http_err:
                    response_obj = getattr(http_err, 'response', None)
                    status_code = getattr(response_obj, 'status_code', None)
                    response_content = None
                    response_content_for_log = None

                    if response_obj is not None:
                        try:
                            response_content = response_obj.json()
                            response_content_for_log = json.dumps(response_content, indent=2)
                        except ValueError:
                            response_content = response_obj.text
                            response_content_for_log = response_obj.text

                    should_retry_route = False
                    if response_obj is not None and not route_retry_performed:
                        try:
                            should_retry_route = handle_route_mismatch_404(
                                status_code,
                                response_content,
                                call_type,
                                url,
                                CONSOLE_LOGGING
                            )
                        except Exception as remediation_err:
                            MediLink_ConfigLoader.log(
                                "Route mismatch remediation failed to start: {}".format(str(remediation_err)),
                                level="WARNING",
                                console_output=CONSOLE_LOGGING
                            )

                    if should_retry_route and not route_retry_performed:
                        route_retry_performed = True
                        time.sleep(0.5)
                        continue

                    # Some 400s are expected in normal operation (no data, payer not allowed).
                    # For these, skip verbose ERROR dumps and replace with a one-line, actionable message.
                    expected_400_reason = None
                    expected_400_level = "DEBUG"
                    payer_id_for_log = None
                    if status_code == 400 and response_content is not None:
                        # Prefer structured errors; fall back to text scanning when provider returns a non-JSON body.
                        err_codes_msgs = ''
                        try:
                            if isinstance(response_content, dict):
                                err_list = response_content.get("errors") or []
                                err_codes_msgs = " ".join(
                                    str(e.get("code", "")) + " " + str(e.get("message", ""))
                                    for e in err_list if isinstance(e, dict)
                                )
                            else:
                                err_codes_msgs = str(response_content)
                        except Exception:
                            err_codes_msgs = ''

                        # Also include raw text (when available) in case JSON parsing failed upstream.
                        try:
                            if not err_codes_msgs and response_obj is not None:
                                err_codes_msgs = str(getattr(response_obj, 'text', '') or '')
                        except Exception:
                            pass

                        if ("LCLM_PS_201" in err_codes_msgs
                                or "LCLM_PS_203" in err_codes_msgs
                                or "No Data found with the given request" in err_codes_msgs):
                            expected_400_reason = "no-data (LCLM_PS_201/203)"
                            expected_400_level = "DEBUG"
                        elif ("LCLM_PS_105" in err_codes_msgs or "LCLM_PS_202" in err_codes_msgs):
                            expected_400_reason = "payer not allowed (LCLM_PS_105/202)"
                            expected_400_level = "INFO"
                            # Best-effort payerId extraction for operator logs
                            try:
                                if isinstance(masked_headers, dict):
                                    payer_id_for_log = masked_headers.get('payerId') or masked_headers.get('payer_id')
                                if payer_id_for_log is None and isinstance(params, dict):
                                    payer_id_for_log = params.get('payerId') or params.get('payer_id')
                            except Exception:
                                payer_id_for_log = None

                    if expected_400_reason:
                        if expected_400_reason.startswith("no-data"):
                            MediLink_ConfigLoader.log(
                                "HTTP 400 {}: {} {} - skipping verbose error dump.".format(
                                    expected_400_reason, call_type, url
                                ),
                                level=expected_400_level,
                                console_output=CONSOLE_LOGGING
                            )
                        else:
                            MediLink_ConfigLoader.log(
                                "HTTP 400 {}: {} {} payerId={}. Next: Confirm allowed payers for this TIN with UHC or remove payer from list.".format(
                                    expected_400_reason, call_type, url, payer_id_for_log or 'unknown'
                                ),
                                level=expected_400_level,
                                console_output=CONSOLE_LOGGING
                            )
                    else:
                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")
                        MediLink_ConfigLoader.log("VERBOSE HTTP ERROR DETAILS", level="ERROR")
                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")

                        if response_obj is None:
                            log_message = (
                                "HTTPError with no response. "
                                "URL: {url}, "
                                "Method: {method}, "
                                "Params: {params}, "
                                "Data: {data}, "
                                "Headers: {masked_headers}, "
                                "Error: {error}"
                            ).format(
                                url=url,
                                method=call_type,
                                params=params,
                                data=data,
                                masked_headers=masked_headers,
                                error=str(http_err)
                            )
                            MediLink_ConfigLoader.log(log_message, level="ERROR")
                        else:
                            MediLink_ConfigLoader.log("HTTP Error Status Code: {}".format(status_code), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error URL: {}".format(url), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error Method: {}".format(call_type), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error Headers: {}".format(json.dumps(masked_headers, indent=2)), level="ERROR")
                            
                            if params:
                                MediLink_ConfigLoader.log("HTTP Error Query Params: {}".format(json.dumps(params, indent=2)), level="ERROR")
                            if data:
                                # Handle both dict and pre-serialized string data
                                if isinstance(data, str):
                                    try:
                                        # Try to parse and pretty-print if it's JSON
                                        parsed_data = json.loads(data)
                                        MediLink_ConfigLoader.log("HTTP Error Request Data: {}".format(json.dumps(parsed_data, indent=2)), level="ERROR")
                                    except (ValueError, TypeError):
                                        # If not valid JSON, log as string (truncate if too long)
                                        data_preview = data[:500] + "..." if len(data) > 500 else data
                                        MediLink_ConfigLoader.log("HTTP Error Request Data (string): {}".format(data_preview), level="ERROR")
                                else:
                                    MediLink_ConfigLoader.log("HTTP Error Request Data: {}".format(json.dumps(data, indent=2)), level="ERROR")
                            
                            if isinstance(response_content, (dict, list)):
                                MediLink_ConfigLoader.log("HTTP Error Response JSON: {}".format(response_content_for_log), level="ERROR")
                            else:
                                MediLink_ConfigLoader.log("HTTP Error Response Text: {}".format(response_content_for_log), level="ERROR")

                            # Format data for log message (handle both dict and string)
                            data_for_log = data
                            if isinstance(data, str):
                                try:
                                    # Try to parse and format if it's JSON
                                    parsed_data = json.loads(data)
                                    data_for_log = json.dumps(parsed_data, indent=2)
                                except (ValueError, TypeError):
                                    # If not valid JSON, use as-is (truncate if too long)
                                    data_for_log = data[:500] + "..." if len(data) > 500 else data
                            elif isinstance(data, (dict, list)):
                                data_for_log = json.dumps(data, indent=2)
                            
                            log_message = (
                                "HTTPError: Status Code: {status}, "
                                "URL: {url}, "
                                "Method: {method}, "
                                "Params: {params}, "
                                "Data: {data}, "
                                "Headers: {masked_headers}, "
                                "Response Content: {content}"
                            ).format(
                                status=status_code,
                                url=url,
                                method=call_type,
                                params=params,
                                data=data_for_log,
                                masked_headers=masked_headers,
                                content=response_content
                            )
                            MediLink_ConfigLoader.log(log_message, level="ERROR")
                            # Provide a brief 404 route-match hint when applicable (best-effort, console-gated)
                            try:
                                from MediCafe.api_hints import emit_404_route_hint
                                emit_404_route_hint(call_type, url, status_code, response_content, console=CONSOLE_LOGGING)
                            except Exception:
                                pass

                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")
                    raise

        except requests.exceptions.RequestException as req_err:
            # HTTPError is a RequestException; inner handler may have already logged no-data and raised.
            # Skip verbose dump here to avoid duplicate ERROR blobs for expected 400s.
            skip_verbose = False
            if isinstance(req_err, requests.exceptions.HTTPError):
                resp = getattr(req_err, 'response', None)
                status = getattr(resp, 'status_code', None) if resp else None
                if status == 400 and resp is not None:
                    try:
                        body = resp.json()
                    except Exception:
                        body = None
                    codes_msgs = ''
                    if isinstance(body, dict):
                        err_list = body.get("errors") or []
                        codes_msgs = " ".join(
                            str(e.get("code", "")) + " " + str(e.get("message", ""))
                            for e in err_list if isinstance(e, dict)
                        )
                    else:
                        # Some providers return plain text bodies for 400 responses.
                        try:
                            codes_msgs = str(getattr(resp, 'text', '') or '')
                        except Exception:
                            codes_msgs = ''
                    if ("LCLM_PS_201" in codes_msgs
                            or "LCLM_PS_203" in codes_msgs
                            or "No Data found with the given request" in codes_msgs
                            or "LCLM_PS_105" in codes_msgs
                            or "LCLM_PS_202" in codes_msgs):
                        skip_verbose = True
            if skip_verbose:
                raise
            # Log connection-related issues or other request exceptions with verbose details
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            MediLink_ConfigLoader.log("VERBOSE REQUEST EXCEPTION DETAILS", level="ERROR")
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            MediLink_ConfigLoader.log("RequestException Type: {}".format(type(req_err).__name__), level="ERROR")
            MediLink_ConfigLoader.log("RequestException URL: {}".format(url), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Method: {}".format(call_type), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Headers: {}".format(json.dumps(masked_headers, indent=2)), level="ERROR")
            if params:
                MediLink_ConfigLoader.log("RequestException Query Params: {}".format(json.dumps(params, indent=2)), level="ERROR")
            if data:
                # Handle both dict and pre-serialized string data
                if isinstance(data, str):
                    try:
                        parsed_data = json.loads(data)
                        MediLink_ConfigLoader.log("RequestException Request Data: {}".format(json.dumps(parsed_data, indent=2)), level="ERROR")
                    except (ValueError, TypeError):
                        data_preview = data[:500] + "..." if len(data) > 500 else data
                        MediLink_ConfigLoader.log("RequestException Request Data (string): {}".format(data_preview), level="ERROR")
                else:
                    MediLink_ConfigLoader.log("RequestException Request Data: {}".format(json.dumps(data, indent=2)), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Error: {}".format(str(req_err)), level="ERROR")
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            
            # Also log concise version
            log_message = (
                "RequestException: No response received. "
                "URL: {url}, "
                "Method: {method}, "
                "Params: {params}, "
                "Data: {data}, "
                "Headers: {masked_headers}, "
                "Error: {error}"
            ).format(
                url=url,
                method=call_type,
                params=params,
                data=data if not isinstance(data, str) or len(data) < 200 else data[:200] + "...",
                masked_headers=masked_headers,
                error=str(req_err)
            )
            MediLink_ConfigLoader.log(log_message, level="ERROR")
            # Emit concise connectivity hint for DNS/proxy issues (best-effort, console-gated)
            try:
                from MediCafe.api_hints import emit_network_hint
                emit_network_hint(endpoint_name, url, req_err, console=CONSOLE_LOGGING)
            except Exception:
                pass
            raise

        except Exception as e:
            # Capture traceback for unexpected exceptions
            tb = traceback.format_exc()
            log_message = (
                "Unexpected error: {error}. "
                "URL: {url}, "
                "Method: {method}, "
                "Params: {params}, "
                "Data: {data}, "
                "Headers: {masked_headers}. "
                "Traceback: {traceback}"
            ).format(
                error=str(e),
                url=url,
                method=call_type,
                params=params,
                data=data,
                masked_headers=masked_headers,
                traceback=tb
            )
            MediLink_ConfigLoader.log(log_message, level="ERROR")
            raise

def fetch_payer_name_from_api(*args, **kwargs):
    """
    Fetch payer name by Payer ID with backward-compatible calling styles.

    Supported call signatures:
    - fetch_payer_name_from_api(client, payer_id, config, primary_endpoint='AVAILITY')
    - fetch_payer_name_from_api(payer_id, config, primary_endpoint='AVAILITY')  # client inferred via factory
    - fetch_payer_name_from_api(payer_id=payer_id, config=config, client=client, primary_endpoint='AVAILITY')
    - fetch_payer_name_from_api(..., quiet_mode=False)  # Suppress verbose logging when True
    """
    # Normalize arguments
    client = None
    payer_id = None
    config = None
    primary_endpoint = kwargs.get('primary_endpoint', 'AVAILITY')
    quiet_mode = kwargs.get('quiet_mode', False)

    if 'client' in kwargs:
        client = kwargs.get('client')
    if 'payer_id' in kwargs:
        payer_id = kwargs.get('payer_id')
    if 'config' in kwargs:
        config = kwargs.get('config')

    if len(args) >= 3 and isinstance(args[0], APIClient):
        client = args[0]
        payer_id = args[1]
        config = args[2]
        if len(args) >= 4 and 'primary_endpoint' not in kwargs:
            primary_endpoint = args[3]
    elif len(args) >= 2 and isinstance(args[0], str) and client is None:
        # Called as (payer_id, config, [primary_endpoint])
        payer_id = args[0]
        config = args[1]
        if len(args) >= 3 and 'primary_endpoint' not in kwargs:
            primary_endpoint = args[2]
    elif len(args) == 1 and isinstance(args[0], APIClient) and (payer_id is None or config is None):
        # Partial positional with client first, other params via kwargs
        client = args[0]

    # Acquire client via factory if not provided
    if client is None:
        try:
            from MediCafe.core_utils import get_api_client
            client = get_api_client()
            if client is None:
                client = APIClient()
        except Exception:
            client = APIClient()

    # Basic validation
    if not isinstance(client, APIClient):
        error_message = "Invalid client provided. Expected an instance of APIClient."
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        raise ValueError(error_message)
    if payer_id is None or config is None:
        raise ValueError("Missing required arguments: payer_id and config are required")
    
    # TODO: FUTURE IMPLEMENTATION - Remove AVAILITY default when other endpoints have payer-list APIs
    # Currently defaulting to AVAILITY as it's the only endpoint with confirmed payer-list functionality
    # In the future, this should be removed and the system should dynamically detect which endpoints
    # have payer-list capabilities and use them accordingly.
    # Suggested approach: add endpoint capability metadata (e.g., supports_payer_list=true) in config and
    # prefer primary_endpoint when capable, with AVAILITY only as final fallback for backward compatibility.
    if primary_endpoint != 'AVAILITY':
        MediLink_ConfigLoader.log("[Fetch payer name from API] Overriding {} with AVAILITY (default until multi-endpoint payer-list support is implemented).".format(primary_endpoint), level="DEBUG")
        primary_endpoint = 'AVAILITY'
    
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config)
        endpoints = medi.get('endpoints', {})
    except KeyError as e:
        error_message = "Configuration loading error in fetch_payer_name_from_api: Missing key {0}... Attempting to reload configuration.".format(e)
        # print(error_message)
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        # Attempt to reload configuration if key is missing
        config, _ = MediLink_ConfigLoader.load_configuration()
        # SAFE FALLBACK: if endpoints still missing, fall back to AVAILITY only and proceed.
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config)
        endpoints = medi.get('endpoints', {})
        if not endpoints:
            MediLink_ConfigLoader.log("Endpoints configuration missing after reload. Falling back to AVAILITY-only logic.", level="WARNING")
        MediLink_ConfigLoader.log("Re-loaded configuration successfully.", level="INFO")
    
    # Sanitize and validate payer_id
    if not isinstance(payer_id, str):
        payer_id = str(payer_id)
    
    payer_id = ''.join(char for char in payer_id if char.isalnum())
    
    if not payer_id:
        error_message = "Invalid payer_id in API v3: {}. Must contain a string of alphanumeric characters.".format(payer_id)
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        print(error_message)
    
    # Payer-list is AVAILITY-only. Dynamic multi-endpoint payer-list selection deferred until other backends offer a payer-list API.

    # If HTTP client is unavailable or endpoints missing, use offline fallback only when allowed (TestMode or env flag)
    try:
        http_unavailable = (requests is None)  # type: ignore[name-defined]
    except Exception:
        http_unavailable = True
    # Determine whether offline fallback is permitted
    # Align with main flow: default True when TestMode key is absent
    offline_allowed = True
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi_local = extract_medilink_config(config)
        offline_allowed = bool(medi_local.get('TestMode', True))
    except Exception:
        offline_allowed = True
    try:
        if os.environ.get('MEDICAFE_OFFLINE_PERMISSIVE', '').strip().lower() in ('1', 'true', 'yes', 'y'):
            offline_allowed = True
    except Exception:
        pass

    if offline_allowed and (http_unavailable or not isinstance(endpoints, dict) or not endpoints):
        try:
            # Prefer crosswalk mapping when available
            try:
                _, cw = MediLink_ConfigLoader.load_configuration()
            except Exception:
                cw = {}
            payer_mappings = {}
            try:
                if isinstance(cw, dict):
                    payer_mappings = cw.get('payer_mappings', {}) or {}
            except Exception:
                payer_mappings = {}

            if payer_id in payer_mappings:
                resolved = payer_mappings.get(payer_id)
                MediLink_ConfigLoader.log(
                    "Using crosswalk mapping for payer {} -> {} [OFFLINE_FALLBACK:crosswalk_mapping]".format(payer_id, resolved),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return resolved
            # Safe minimal hardcoded map as last resort (test/offline only)
            fallback_map = {
                '87726': 'UnitedHealthcare',
                '06111': 'Aetna',
                '03432': 'Cigna',
                '95378': 'Anthem Blue Cross',
                '95467': 'Blue Shield',
            }
            if payer_id in fallback_map:
                MediLink_ConfigLoader.log(
                    "Using offline fallback for payer {} -> {} [OFFLINE_FALLBACK:hardcoded]".format(payer_id, fallback_map[payer_id]),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return fallback_map[payer_id]
        except Exception:
            pass

    # Payer-list is AVAILITY-only; payer_list_endpoint on other endpoints (e.g. UHCAPI) is ignored.
    if endpoints.get('AVAILITY') is not None:
        endpoint_order = ['AVAILITY']
    else:
        MediLink_ConfigLoader.log("AVAILITY endpoint required for payer-list but not in config; will attempt AVAILITY and may fail.", level="INFO")
        endpoint_order = ['AVAILITY']
    MediLink_ConfigLoader.log("Endpoint order for payer lookup: {}".format(endpoint_order), level="DEBUG")

    for endpoint_name in endpoint_order:
        try:
            # Path from AVAILITY config only; default matches Availity Payer List 1.0.5 path.
            endpoint_url = endpoints.get('AVAILITY', {}).get('payer_list_endpoint', '/availity-payer-list')
            
            # AVAILITY Payer List rate limiting: enforce 200ms (1/5 sec) minimum spacing
            # Demo app limit: 5 calls per second
            global _AVAILITY_PAYER_LIST_LAST_CALL
            if endpoint_name == 'AVAILITY':
                elapsed = time.time() - _AVAILITY_PAYER_LIST_LAST_CALL
                if elapsed < 0.2:  # 200ms = 1/5 second
                    sleep_time = 0.2 - elapsed
                    MediLink_ConfigLoader.log(
                        "AVAILITY payer-list rate limit: sleeping {:.3f}s to maintain 5 calls/sec".format(sleep_time),
                        level="DEBUG"
                    )
                    time.sleep(sleep_time)
                _AVAILITY_PAYER_LIST_LAST_CALL = time.time()
            
            # Availity 1.0.5 requires Accept: application.json (not application/json)
            response = client.make_api_call(
                endpoint_name, 'GET', endpoint_url, {'payerId': payer_id}, 
                headers={'Accept': 'application.json'}, 
                quiet_mode=quiet_mode
            )
            
            # Check if response exists
            if not response:
                log_message = "No response from {0} for Payer ID {1}".format(endpoint_name, payer_id)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="ERROR")
                continue
            
            # Normalize response shape: API 1.0.5 returns array of payers; legacy may return dict with 'payers' key
            if isinstance(response, list):
                # New API format (1.0.5): top-level array of payer objects
                payers = response
            elif isinstance(response, dict):
                # Legacy format: dict with 'payers' key, or possibly body status code
                # Check body status code only for legacy dict format (new array format has no statuscode)
                status_code = response.get('statuscode', 200)
                if status_code != 200:
                    log_message = "Invalid response status code {0} from {1} for Payer ID {2}. Message: {3}".format(
                        status_code, endpoint_name, payer_id, response.get('message', 'No message'))
                    print(log_message)
                    MediLink_ConfigLoader.log(log_message, level="ERROR")
                    continue
                payers = response.get('payers', [])
            else:
                # Unexpected format
                payers = []
            
            # Validate payers list
            if not payers:
                log_message = "No payer found at {0} for ID {1}. Response: {2}".format(endpoint_name, payer_id, response)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="INFO")
                continue
            
            # Extract the payer name from the first payer in the list
            payer_name = payers[0].get('displayName') or payers[0].get('name')
            if not payer_name:
                log_message = "Payer name not found in the response from {0} for ID {1}. Response: {2}".format(
                    endpoint_name, payer_id, response)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="ERROR")
                continue
            
            # Log successful payer retrieval with source indicator
            log_message = "Found payer at {0} for ID {1}: {2} [API_SUCCESS]".format(endpoint_name, payer_id, payer_name)
            MediLink_ConfigLoader.log(log_message, level="DEBUG")
            return payer_name
        
        except Exception as e:
            # Enhanced error logging for AVAILITY: log endpoint response body when available
            if not quiet_mode:
                error_message = "Error calling {0} for Payer ID {1}. Exception: {2}".format(endpoint_name, payer_id, e)
                
                # For AVAILITY, try to extract and log response body (exception or its cause may have .response)
                if endpoint_name == 'AVAILITY':
                    resp_obj = getattr(e, 'response', None) or (getattr(e, '__cause__', None) and getattr(e.__cause__, 'response', None))
                    if resp_obj is not None:
                        try:
                            response_body = resp_obj.json()
                            error_message += " | Response body: {}".format(response_body)
                        except Exception:
                            try:
                                error_message += " | Response text: {}".format(getattr(resp_obj, 'text', '')[:500])
                            except Exception:
                                pass
                
                MediLink_ConfigLoader.log(error_message, level="INFO")

    # Offline/local fallback mapping for common payer IDs when API endpoints are unavailable
    # Only when offline fallback is permitted
    if offline_allowed:
        try:
            # Prefer crosswalk mapping first
            try:
                _, cw = MediLink_ConfigLoader.load_configuration()
            except Exception:
                cw = {}
            payer_mappings = {}
            try:
                if isinstance(cw, dict):
                    payer_mappings = cw.get('payer_mappings', {}) or {}
            except Exception:
                payer_mappings = {}
            if payer_id in payer_mappings:
                resolved = payer_mappings.get(payer_id)
                MediLink_ConfigLoader.log(
                    "Using crosswalk mapping for payer {} -> {} [OFFLINE_FALLBACK:crosswalk_mapping]".format(payer_id, resolved),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return resolved
            # Minimal fallback map if crosswalk has no mapping (still offline-only)
            fallback_map = {
                '87726': 'UnitedHealthcare',
                '06111': 'Aetna',
                '03432': 'Cigna',
                '95378': 'Anthem Blue Cross',
                '95467': 'Blue Shield',
            }
            if payer_id in fallback_map:
                MediLink_ConfigLoader.log(
                    "Using offline fallback for payer {} -> {} [OFFLINE_FALLBACK:hardcoded]".format(payer_id, fallback_map[payer_id]),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return fallback_map[payer_id]
        except Exception:
            pass

    # If all endpoints fail
    final_error_message = "All endpoints exhausted for Payer ID {0}.".format(payer_id)
    print(final_error_message)
    MediLink_ConfigLoader.log(final_error_message, level="CRITICAL")
    raise ValueError(final_error_message)

def get_claim_summary_by_provider(client, tin, first_service_date, last_service_date, payer_id, get_standard_error='false', transaction_id=None, env=None):
    """
    Unified Claims Inquiry that prefers OPTUMAI GraphQL searchClaim with
    legacy response mapping, and falls back to legacy UHCAPI REST endpoint
    to preserve current downstream flows and UI.
    """
    # Verbose input logging
    if DEBUG:
        MediLink_ConfigLoader.log("Claims Inquiry inputs: tin={} start={} end={} payer={} tx={}"
                                  .format(tin, first_service_date, last_service_date, payer_id, transaction_id),
                                  level="INFO")

    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)

    # Determine whether OPTUMAI is available/configured
    endpoints_cfg = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    optumai_cfg = endpoints_cfg.get('OPTUMAI', {}) if isinstance(endpoints_cfg, dict) else {}
    uhcapi_cfg = endpoints_cfg.get('UHCAPI', {}) if isinstance(endpoints_cfg, dict) else {}

    optumai_path = (optumai_cfg.get('additional_endpoints', {}) or {}).get('claims_inquiry')
    uhc_path = (uhcapi_cfg.get('additional_endpoints', {}) or {}).get('claim_summary_by_provider')

    optumai_api_url = optumai_cfg.get('api_url')
    use_optumai = bool(optumai_api_url and optumai_path)
    if optumai_cfg and optumai_api_url and not optumai_path:
        _log_fallback_once(
            'claims_inquiry_missing_path',
            "OPTUMAI claims inquiry not configured (missing additional_endpoints.claims_inquiry); falling back to UHCAPI.",
            level="WARNING"
        )
    elif optumai_cfg and optumai_path and not optumai_api_url:
        _log_fallback_once(
            'claims_inquiry_missing_api_url',
            "OPTUMAI claims inquiry configured but api_url missing; falling back to UHCAPI.",
            level="WARNING"
        )
    # Capability guard: disable OPTUMAI if required helpers are unavailable
    if use_optumai:
        graphql_enabled = bool(getattr(MediLink_GraphQL, 'GRAPHQL_AVAILABLE', True))
        has_build = hasattr(MediLink_GraphQL, 'build_optumai_claims_inquiry_request')
        has_transform = hasattr(MediLink_GraphQL, 'transform_claims_inquiry_response_to_legacy')
        if not (graphql_enabled and has_build and has_transform):
            _log_fallback_once(
                'claims_inquiry_missing_helpers',
                "Disabling OPTUMAI claims inquiry: GraphQL helpers unavailable/disabled. Falling back to UHCAPI.",
                level="WARNING"
            )
            use_optumai = False

    # Single routing layer: which endpoint should handle search_claim for this payer?
    payer_id_str = str(payer_id) if payer_id is not None else None
    if use_optumai and payer_id:
        route_endpoint, route_reason = resolve_operation_route(client, payer_id, 'search_claim')
        if route_endpoint != 'OPTUMAI':
            use_optumai = False
            # Pre-check reason mapping: route_reason None + UHCAPI -> unsupported_payer for OPTUMAI context
            if route_reason is None and route_endpoint == 'UHCAPI':
                pre_reason = UNSUPPORTED_PAYER
            elif route_reason in ('payer_not_supported', 'payer_not_in_defaults', 'feature_not_supported',
                                  'crosswalk_unavailable', 'search_277ca_not_supported_for_payer'):
                pre_reason = UNSUPPORTED_PAYER
            else:
                pre_reason = UNSUPPORTED_PAYER
            pre_hint = next_step_hint(pre_reason) if next_step_hint else "Check logs for details."
            if classify_routing_reason:
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', pre_reason, 'UHCAPI', pre_hint)
            if route_reason and 'not_supported' in str(route_reason):
                MediLink_ConfigLoader.log(
                    "Skipping OPTUMAI claims inquiry due to Search Claim=N for payer {}; using UHCAPI.".format(payer_id),
                    level="INFO"
                )
            elif route_reason:
                MediLink_ConfigLoader.log(
                    "Claims inquiry: routing for payer {} -> {} ({}); using UHCAPI.".format(
                        payer_id, route_endpoint or 'none', route_reason),
                    level="WARNING"
                )

    # Suppression check: skip OPTUMAI if we've previously observed suppressible failures for this payer/context
    try:
        if use_optumai and payer_id_str:
            suppressed, cached_reason, cached_hint = _check_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN)
            if suppressed:
                use_optumai = False
                hint = cached_hint or (next_step_hint(cached_reason) if next_step_hint else "Check logs for details.")
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', cached_reason, 'UHCAPI', hint)
    except Exception:
        pass

    # Build OPTUMAI GraphQL request if configured
    if use_optumai:
        try:
            # Use centralized header builder (normalizes TIN and adds all required headers)
            headers = build_optumai_headers(client.config, api_url=optumai_api_url, next_page_token=transaction_id)

            # Build searchClaimInput per partial swagger
            # Per Claims_Inquiry spec: serviceStartDate/serviceEndDate are "Conditional. Required for search by member data or provider TIN"
            search_claim_input = {
                'payerId': str(payer_id)
            }
            # Map dates MM/DD/YYYY -> expected strings for GraphQL (examples show MM/DD/YYYY and also 01/01/2025)
            # Service dates are required for provider TIN search per spec
            if first_service_date:
                search_claim_input['serviceStartDate'] = first_service_date
            else:
                # Log warning if service dates missing for provider TIN search
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_PROVIDER_SEARCH] WARNING: serviceStartDate missing for provider TIN search (payerId={}) - may cause API errors".format(payer_id),
                    level="WARNING"
                )
            if last_service_date:
                search_claim_input['serviceEndDate'] = last_service_date
            else:
                # Log warning if service dates missing for provider TIN search
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_PROVIDER_SEARCH] WARNING: serviceEndDate missing for provider TIN search (payerId={}) - may cause API errors".format(payer_id),
                    level="WARNING"
                )

            # DEBUG: Log request telemetry
            if DEBUG:
                # Mask provider TIN for security (show first 5 digits, mask last 4)
                provider_tin_masked = 'unknown'
                if headers and 'providerTaxId' in headers:
                    tin_val = str(headers.get('providerTaxId', ''))
                    if len(tin_val) >= 5:
                        provider_tin_masked = tin_val[:5] + '****'
                    else:
                        provider_tin_masked = '****'
                
                # Mask correlation ID (show first 8 chars)
                corr_id_masked = 'unknown'
                if headers and 'x-optum-consumer-correlation-id' in headers:
                    corr_val = str(headers.get('x-optum-consumer-correlation-id', ''))
                    if len(corr_val) >= 8:
                        corr_id_masked = corr_val[:8] + '...'
                    else:
                        corr_id_masked = corr_val
                
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: payerId={}, serviceStartDate={}, serviceEndDate={}, providerTaxId={}, transactionId={}, correlationId={}".format(
                        payer_id, first_service_date or 'None', last_service_date or 'None',
                        provider_tin_masked, transaction_id or 'None', corr_id_masked
                    ),
                    level="DEBUG"
                )

            # Build GraphQL body
            graphql_body = MediLink_GraphQL.build_optumai_claims_inquiry_request(search_claim_input)

            # DEBUG: Log GraphQL request structure
            if DEBUG:
                operation_name = graphql_body.get('operationName', 'unknown')
                query_length = len(str(graphql_body.get('query', '')))
                variables_summary = 'present' if graphql_body.get('variables') else 'missing'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: GraphQL operationName={}, queryLength={}, variables={}".format(
                        operation_name, query_length, variables_summary
                    ),
                    level="DEBUG"
                )

            # Make the call
            response = client.make_api_call('OPTUMAI', 'POST', optumai_path, params=None, data=graphql_body, headers=headers)

            # DEBUG: Log raw HTTP response structure
            if DEBUG:
                response_type = type(response).__name__
                has_data = isinstance(response, dict) and 'data' in response
                has_errors = isinstance(response, dict) and 'errors' in response
                response_keys = list(response.keys()) if isinstance(response, dict) else []
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] RESPONSE: responseType={}, hasData={}, hasErrors={}, responseKeys={}".format(
                        response_type, has_data, has_errors, response_keys[:10] if len(response_keys) > 10 else response_keys
                    ),
                    level="DEBUG"
                )

            # Transform to legacy format
            transformed = MediLink_GraphQL.transform_claims_inquiry_response_to_legacy(response)
            status = transformed.get('statuscode') if isinstance(transformed, dict) else None
            claims = transformed.get('claims', []) if isinstance(transformed, dict) else []
            claims_count = len(claims) if isinstance(claims, list) else 0
            message = transformed.get('message', '') if isinstance(transformed, dict) else ''
            next_page_token = transformed.get('transactionId') if isinstance(transformed, dict) else None
            
            if status == '200':
                # INFO: Log success scenario
                if claims_count > 0:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] SUCCESS: payerId={}, claimsCount={}, hasMoreRecords={}, nextPageToken={}, statuscode={}".format(
                            payer_id, claims_count, 'true' if next_page_token else 'false',
                            'present' if next_page_token else 'None', status
                        ),
                        level="INFO"
                    )
                else:
                    # INFO: Log no-data scenario (successful response but empty claims)
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] NO_DATA: payerId={}, dateRange={} to {}, statuscode={}, message=\"{}\", claimsArrayLength={}".format(
                            payer_id, first_service_date or 'None', last_service_date or 'None',
                            status, message, claims_count
                        ),
                        level="INFO"
                    )
                
                # Add note so UI can message that Optum Real is active (non-breaking)
                try:
                    transformed['data_source'] = 'OPTUMAI'
                except Exception:
                    pass
                return transformed
            
            # WARNING: Log non-200 status with error details
            error_code = 'unknown'
            error_description = message
            trace_id = 'unknown'
            
            # Try to extract error details from raw GraphQL response
            if isinstance(transformed, dict) and 'rawGraphQLResponse' in transformed:
                raw_resp = transformed.get('rawGraphQLResponse', {})
                if isinstance(raw_resp, dict) and 'errors' in raw_resp:
                    errors = raw_resp.get('errors', [])
                    if errors and isinstance(errors[0], dict):
                        first_error = errors[0]
                        error_code = first_error.get('code', first_error.get('extensions', {}).get('code', 'unknown'))
                        error_description = first_error.get('description', first_error.get('message', message))
                        trace_id = first_error.get('extensions', {}).get('traceId', 'unknown')
            
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] ERROR: payerId={}, statuscode={}, errorCode={}, errorDescription=\"{}\", traceId={}".format(
                    payer_id, status or 'unknown', error_code, error_description[:200] if error_description else 'no message', trace_id
                ),
                level="WARNING"
            )

            # Classify, suppress if applicable, log structured decision once
            if classify_routing_reason:
                reason_code, hint = classify_routing_reason(
                    None, status_code=status, error_code=error_code, error_description=error_description)
                if is_suppressible and is_suppressible(reason_code):
                    _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, reason_code)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', reason_code, 'UHCAPI', hint)
            elif _optumai_error_indicates_member_required(error_code, error_description):
                _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, MEMBER_REQUIRED)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', MEMBER_REQUIRED, 'UHCAPI',
                    next_step_hint(MEMBER_REQUIRED) if next_step_hint else "Use member-level search.")
             
            # DEBUG: Log full transformed response structure for non-200 cases
            if DEBUG:
                response_snippet = str(transformed)[:500] if transformed else 'None'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] ERROR: Full response snippet (first 500 chars): {}".format(response_snippet),
                    level="DEBUG"
                )
            
            # INFO: Log fallback trigger
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"Non-200 status\", optumaiStatus={}, fallingBackTo=UHCAPI".format(
                    status or 'unknown'
                ),
                level="INFO"
            )
            
            MediLink_ConfigLoader.log(
                "OPTUMAI Claims Inquiry returned status {} ({}). Falling back to UHCAPI.".format(
                    status or 'unknown',
                    message if message else 'no message'
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
            # If not 200, fall through to UHC fallback when permitted
        except Exception as e:
            # If capability guard failed upstream for any reason, handle missing attribute gracefully here too
            error_type = type(e).__name__
            error_msg = str(e)

            if classify_routing_reason:
                reason_code, hint = classify_routing_reason(e)
                if is_suppressible and is_suppressible(reason_code):
                    _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, reason_code)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', reason_code, 'UHCAPI', hint)

            if isinstance(e, AttributeError):
                fallback_reason = "Missing GraphQL helpers"
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"{}\", fallingBackTo=UHCAPI".format(fallback_reason),
                    level="INFO"
                )
                MediLink_ConfigLoader.log(
                    "OPTUMAI disabled due to missing GraphQL helpers; falling back to UHCAPI.",
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
            else:
                fallback_reason = "Exception: {} ({})".format(error_type, error_msg[:100])
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"{}\", exceptionType={}, fallingBackTo=UHCAPI".format(
                        fallback_reason, error_type
                    ),
                    level="INFO"
                )
                MediLink_ConfigLoader.log(
                    "OPTUMAI Claims Inquiry failed: {}. Falling back to UHCAPI.".format(e),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )

    # Fallback to existing UHC REST behavior to preserve current flows
    endpoint_name = 'UHCAPI'
    url_extension = uhc_path or ''

    if DEBUG:
        MediLink_ConfigLoader.log("Falling back to UHCAPI claim_summary_by_provider path: {}".format(url_extension), level="INFO")

    # Normalize TIN to digits-only per swagger (Facility/Tax ID). Examples use "12345678".
    # OPTUMAI uses normalized providerTaxId; UHCAPI should match to avoid "No Data" from format mismatch.
    tin_normalized = normalize_provider_tin(tin) if tin else None
    tin_for_headers = tin_normalized if tin_normalized else str(tin).strip() if tin else ''

    headers = {
        'tin': tin_for_headers,
        'firstServiceDt': first_service_date,
        'lastServiceDt': last_service_date,
        'payerId': payer_id,
        'getStandardError': get_standard_error,
        'Accept': 'application/json'
    }
    if transaction_id:
        headers['transactionId'] = transaction_id

    return client.make_api_call(endpoint_name, 'GET', url_extension, params=None, data=None, headers=headers)


def get_claim_status_by_member_data(client, payer_id, member_id=None, member_first_name=None, 
                                    member_last_name=None, member_dob=None, service_start_date=None, 
                                    service_end_date=None, patient_account_number=None):
    """
    Get claim status via OPTUMAI using member data (for post-submission lookups).
    
    Searches for claims using member information before claim number is assigned.
    Validates member data combinations per OPTUMAI spec requirements.
    
    Args:
        client: API client instance
        payer_id: Payer ID (required)
        member_id: Member ID (conditional)
        member_first_name: Member first name (conditional)
        member_last_name: Member last name (conditional)
        member_dob: Member DOB in MM/DD/YYYY format (conditional)
        service_start_date: Service start date in MM/DD/YYYY (optional)
        service_end_date: Service end date in MM/DD/YYYY (optional)
        patient_account_number: Patient account number (optional)
    
    Returns:
        dict: Legacy-compatible response format with claims, statuscode, message
    """
    # Log the request
    if DEBUG:
        MediLink_ConfigLoader.log(
            "[OPTUMAI_MEMBER_LOOKUP] Starting member-based claim search: payerId={}, memberId={}, name={} {}, dob={}".format(
                payer_id, member_id or 'None', member_first_name or '', member_last_name or '', member_dob or 'None'
            ),
            level="DEBUG"
        )
    
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    
    # Get endpoint configuration
    endpoints_cfg = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    optumai_cfg = endpoints_cfg.get('OPTUMAI', {}) if isinstance(endpoints_cfg, dict) else {}
    uhcapi_cfg = endpoints_cfg.get('UHCAPI', {}) if isinstance(endpoints_cfg, dict) else {}
    
    optumai_api_url = optumai_cfg.get('api_url')
    claims_inquiry_path = (optumai_cfg.get('additional_endpoints', {}) or {}).get('claims_inquiry')
    uhcapi_api_url = uhcapi_cfg.get('api_url')
    uhc_member_path = (uhcapi_cfg.get('additional_endpoints', {}) or {}).get('claim_summary_by_member')
    
    use_optumai = bool(optumai_api_url and claims_inquiry_path)
    if optumai_cfg and optumai_api_url and not claims_inquiry_path:
        _log_fallback_once(
            'member_claims_inquiry_missing_path',
            "OPTUMAI claims inquiry not configured (missing additional_endpoints.claims_inquiry); falling back to UHCAPI.",
            level="WARNING"
        )
    elif optumai_cfg and claims_inquiry_path and not optumai_api_url:
        _log_fallback_once(
            'member_claims_inquiry_missing_api_url',
            "OPTUMAI claims inquiry configured but api_url missing; falling back to UHCAPI.",
            level="WARNING"
        )
    
    # Single routing layer: skip OPTUMAI if payer does not support search_claim
    if use_optumai and payer_id:
        try:
            route_endpoint, route_reason = resolve_operation_route(client, payer_id, 'search_claim')
            if route_endpoint != 'OPTUMAI':
                use_optumai = False
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Payer {} does not support search_claim on OPTUMAI ({}); using UHCAPI.".format(
                        payer_id, route_reason or 'unknown'),
                    level="WARNING"
                )
        except Exception as e:
            use_optumai = False
            MediLink_ConfigLoader.log(
                "[OPTUMAI_MEMBER_LOOKUP] Routing check failed ({}); using UHCAPI.".format(e),
                level="WARNING"
            )
    
    optumai_result = None
    if use_optumai:
        # Build full URL
        if claims_inquiry_path.startswith('http'):
            claims_inquiry_url = claims_inquiry_path
        else:
            claims_inquiry_url = optumai_api_url.rstrip('/') + '/' + claims_inquiry_path.lstrip('/')

        # Build headers using centralized builder (normalizes TIN and adds all required headers)
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)

        # Build GraphQL request using member data
        # Per Claims_Inquiry spec: serviceStartDate/serviceEndDate are "Conditional. Required for search by member data or provider TIN"
        # Some payers (e.g., 87726) require service dates even for member data searches
        try:
            from MediCafe.graphql_utils import GraphQLQueryBuilder, transform_claims_inquiry_response_to_legacy
        except Exception as e:
            use_optumai = False
            MediLink_ConfigLoader.log(
                "[OPTUMAI_MEMBER_LOOKUP] GraphQL helpers unavailable ({}). Falling back to UHCAPI.".format(e),
                level="WARNING"
            )
        else:
            if not hasattr(GraphQLQueryBuilder, 'build_optumai_search_claim_by_member_request'):
                use_optumai = False
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Missing GraphQL builder for member lookup. Falling back to UHCAPI.",
                    level="WARNING"
                )

        if use_optumai:
            input_dict = {
                'payerId': payer_id
            }
            if member_id:
                input_dict['memberId'] = member_id
            if member_first_name:
                input_dict['memberFirstName'] = member_first_name
            if member_last_name:
                input_dict['memberLastName'] = member_last_name
            if member_dob:
                input_dict['memberDateOfBirth'] = member_dob
            # Always include service dates when available (required by some payers for member data search)
            if service_start_date:
                input_dict['serviceStartDate'] = service_start_date
            if service_end_date:
                input_dict['serviceEndDate'] = service_end_date

            # Log if service dates are missing for member data search (some payers require them)
            if not service_start_date or not service_end_date:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] INFO: service dates missing for member data search (payerId={}, hasStart={}, hasEnd={}) - some payers may require service dates".format(
                        payer_id, bool(service_start_date), bool(service_end_date)
                    ),
                    level="INFO"
                )

            # DEBUG: Log the complete input_dict being sent (mask sensitive member data)
            if DEBUG:
                masked_input = input_dict.copy()
                if 'memberId' in masked_input and masked_input['memberId']:
                    member_id_val = str(masked_input['memberId'])
                    if len(member_id_val) > 5:
                        masked_input['memberId'] = member_id_val[:5] + '***'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] DEBUG: Input dict being sent: {}".format(masked_input),
                    level="DEBUG"
                )

            if patient_account_number:
                input_dict['patientAccountNumber'] = patient_account_number

            try:
                graphql_request = GraphQLQueryBuilder.build_optumai_search_claim_by_member_request(input_dict)
            except ValueError as e:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Validation error: {}".format(e),
                    level="ERROR"
                )
                graphql_request = None

            if graphql_request:
                # Log GraphQL request structure
                if DEBUG:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] GraphQL request: operation={}, variables={}".format(
                            graphql_request.get('operationName'), graphql_request.get('variables', {})
                        ),
                        level="DEBUG"
                    )

                # Make API call
                endpoint_name = 'OPTUMAI'
                try:
                    response = client.make_api_call(
                        endpoint_name, 'POST', claims_inquiry_url,
                        data=json.dumps(graphql_request), headers=headers
                    )

                    # Transform to legacy format
                    transformed = transform_claims_inquiry_response_to_legacy(response)

                    # Add metadata
                    transformed['data_source'] = 'OPTUMAI'
                    transformed['lookup_type'] = 'member_data'

                    # Log result
                    claims_count = len(transformed.get('claims', [])) if isinstance(transformed, dict) else 0
                    if DEBUG:
                        MediLink_ConfigLoader.log(
                            "[OPTUMAI_MEMBER_LOOKUP] RESULT: statuscode={}, claimsCount={}".format(
                                transformed.get('statuscode') if isinstance(transformed, dict) else 'unknown',
                                claims_count
                            ),
                            level="INFO"
                        )

                    optumai_result = transformed
                    if isinstance(transformed, dict) and transformed.get('claims'):
                        return transformed

                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] FALLBACK: No claims found via OPTUMAI; attempting UHCAPI.",
                        level="INFO"
                    )

                except Exception as e:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] ERROR: {}. Falling back to UHCAPI.".format(e),
                        level="WARNING"
                    )

    # Fallback to UHCAPI member summary
    if not uhcapi_api_url or not uhc_member_path:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: UHCAPI claim_summary_by_member not configured; fallback unavailable.",
            level="WARNING"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'UHCAPI claim summary by member not configured',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    # Build UHCAPI request body
    try:
        uhc_request = _build_uhcapi_member_search_request(
            member_id, member_first_name, member_last_name, member_dob,
            service_start_date, service_end_date, patient_account_number
        )
    except ValueError as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] Validation error: {}".format(e),
            level="WARNING"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback validation failed: {})".format(
                optumai_result.get('message', 'No claims found'), str(e)
            )
            return optumai_result
        return {
            'statuscode': '400',
            'message': 'UHCAPI member lookup validation error: {}'.format(str(e)),
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    # Resolve provider TIN for UHCAPI headers
    provider_tin_raw = medi.get('billing_provider_tin')
    if not provider_tin_raw:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: billing_provider_tin missing from configuration",
            level="ERROR"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable: missing provider TIN)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'Provider TIN not found in configuration',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    tin_normalized = normalize_provider_tin(provider_tin_raw)
    tin_for_headers = tin_normalized if tin_normalized else str(provider_tin_raw).strip()
    if not tin_for_headers:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: provider TIN could not be normalized",
            level="ERROR"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable: invalid provider TIN)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'Provider TIN invalid for UHCAPI request',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    headers = {
        'tin': tin_for_headers,
        'payerId': payer_id,
        'getStandardError': 'false',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    # DEBUG: Log UHCAPI request (mask sensitive data)
    if DEBUG:
        masked_request = uhc_request.copy() if isinstance(uhc_request, dict) else {}
        if masked_request.get('memberId'):
            member_id_val = str(masked_request.get('memberId'))
            if len(member_id_val) > 5:
                masked_request['memberId'] = member_id_val[:5] + '***'
        if masked_request.get('patientDob'):
            dob_val = str(masked_request.get('patientDob'))
            if len(dob_val) > 4:
                masked_request['patientDob'] = dob_val[:4] + '****'
        tin_masked = tin_for_headers[:5] + '****' if len(tin_for_headers) >= 5 else '****'
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] REQUEST: payerId={}, tin={}, body={}".format(
                payer_id, tin_masked, masked_request
            ),
            level="DEBUG"
        )

    try:
        response = client.make_api_call(
            'UHCAPI', 'POST', uhc_member_path, params=None, data=uhc_request, headers=headers
        )

        transformed = _transform_uhcapi_member_response_to_legacy(response)
        transformed['data_source'] = 'UHCAPI'
        transformed['lookup_type'] = 'member_data'

        claims_count = len(transformed.get('claims', [])) if isinstance(transformed, dict) else 0
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] RESULT: statuscode={}, claimsCount={}".format(
                transformed.get('statuscode') if isinstance(transformed, dict) else 'unknown',
                claims_count
            ),
            level="INFO"
        )

        return transformed
    except Exception as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: {}".format(e),
            level="ERROR"
        )
        return {
            'statuscode': '500',
            'message': 'UHCAPI member lookup failed: {}'.format(str(e)),
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }


def _build_uhcapi_member_search_request(member_id, member_first_name, member_last_name, member_dob,
                                        service_start_date, service_end_date, patient_account_number=None):
    """
    Build UHCAPI SummaryByMemberRequest payload from member data inputs.
    """
    missing_dates = []
    if not service_start_date:
        missing_dates.append('firstSrvcDt')
    if not service_end_date:
        missing_dates.append('lastSrvcDt')
    if missing_dates:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: Missing required service dates: {}".format(", ".join(missing_dates)),
            level="WARNING"
        )
        raise ValueError("UHCAPI requires service dates (firstSrvcDt/lastSrvcDt)")

    valid_combo = (
        (member_id and member_dob) or
        (member_id and member_first_name and member_last_name) or
        (member_first_name and member_last_name and member_dob)
    )
    if not valid_combo:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: Invalid member search combination",
            level="WARNING"
        )
        raise ValueError("Invalid member data combination for UHCAPI search")

    if patient_account_number:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] INFO: patientAccountNumber provided but not supported by UHCAPI member search",
            level="INFO"
        )

    body = {
        'firstSrvcDt': service_start_date,
        'lastSrvcDt': service_end_date
    }
    if member_id:
        body['memberId'] = member_id
    if member_first_name:
        body['patientFn'] = member_first_name
    if member_last_name:
        body['patientLn'] = member_last_name
    if member_dob:
        body['patientDob'] = member_dob
    return body


def _transform_uhcapi_member_response_to_legacy(uhc_response):
    """
    Transform UHCAPI SummaryByMember response into legacy claims summary format.
    """
    try:
        if not isinstance(uhc_response, dict):
            return {
                'statuscode': '500',
                'message': 'Invalid UHCAPI response format',
                'claims': [],
                'rawUHCResponse': uhc_response
            }

        # Handle error shapes
        errors = None
        if isinstance(uhc_response.get('errors'), list) and uhc_response.get('errors'):
            errors = uhc_response.get('errors')
        elif isinstance(uhc_response.get('error'), dict):
            nested_errors = uhc_response.get('error', {}).get('errors')
            if isinstance(nested_errors, list) and nested_errors:
                errors = nested_errors

        if errors:
            first_error = errors[0] if isinstance(errors, list) else errors
            error_code = first_error.get('code') if isinstance(first_error, dict) else 'error'
            error_msg = first_error.get('message') if isinstance(first_error, dict) else str(first_error)
            message = "{}{}".format(error_code + ": " if error_code else "", error_msg or "UHCAPI error")
            return {
                'statuscode': '400',
                'message': message,
                'claims': [],
                'rawUHCResponse': uhc_response
            }

        claims = uhc_response.get('claims') or []
        legacy_claims = []
        if isinstance(claims, list):
            for claim in claims:
                member = claim.get('memberInfo') or {}
                summary = claim.get('claimSummary') or {}
                legacy_claims.append({
                    'claimNumber': claim.get('claimNumber'),
                    'claimStatus': claim.get('claimStatus'),
                    'memberInfo': {
                        'ptntFn': member.get('ptntFn'),
                        'ptntLn': member.get('ptntLn')
                    },
                    'claimSummary': {
                        'processedDt': summary.get('processedDt') or '',
                        'firstSrvcDt': summary.get('firstSrvcDt') or '',
                        'totalChargedAmt': summary.get('totalChargedAmt') or '',
                        'totalAllowdAmt': summary.get('totalAllowdAmt') or '',
                        'totalPaidAmt': summary.get('totalPaidAmt') or '',
                        'totalPtntRespAmt': summary.get('totalPtntRespAmt') or '',
                        'clmXWalkData': summary.get('clmXWalkData') or []
                    }
                })

        pagination = uhc_response.get('pagination') or {}
        has_more = bool(pagination.get('hasMore')) if isinstance(pagination, dict) else False
        transaction_id = pagination.get('transactionId') if has_more else None

        return {
            'statuscode': '200',
            'message': 'Claims found' if legacy_claims else 'No claims found',
            'claims': legacy_claims,
            'transactionId': transaction_id,
            'rawUHCResponse': uhc_response
        }
    except Exception as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: Failed to transform response: {}".format(e),
            level="ERROR"
        )
        return {
            'statuscode': '500',
            'message': 'Error transforming UHCAPI response: {}'.format(str(e)),
            'claims': [],
            'rawUHCResponse': uhc_response
        }


def get_claim_status_by_submission_context(client, transaction_id=None, payer_id=None, 
                                           member_id=None, member_first_name=None, 
                                           member_last_name=None, member_dob=None,
                                           service_start_date=None, service_end_date=None,
                                           patient_account_number=None, lookup_type='both'):
    """
    Unified function for post-submission claim status lookups.
    
    Supports multiple lookup types:
    - 277CA lookup via transactionId (immediate confirmation after submission)
    - Claim status lookup via member data (before claim number assigned)
    - Combined lookup (both 277CA and status)
    
    Args:
        client: API client instance
        transaction_id: Transaction ID from claim submission (optional)
        payer_id: Payer ID (required for all lookups)
        member_id: Member ID (conditional for member lookup)
        member_first_name: Member first name (conditional for member lookup)
        member_last_name: Member last name (conditional for member lookup)
        member_dob: Member DOB in MM/DD/YYYY format (conditional for member lookup)
        service_start_date: Service start date in MM/DD/YYYY (optional)
        service_end_date: Service end date in MM/DD/YYYY (optional)
        patient_account_number: Patient account number (optional)
        lookup_type: Type of lookup to perform ('277ca', 'member_data', 'both')
    
    Returns:
        dict: Combined response with:
            - lookup_type: Type of lookup performed
            - ack_277ca: 277CA response (if requested and available)
            - claim_status: Claim status response (if requested and available)
            - statuscode: Overall status
            - message: Overall message
    """
    if DEBUG:
        MediLink_ConfigLoader.log(
            "[SUBMISSION_CONTEXT_LOOKUP] Starting lookup: type={}, transactionId={}, payerId={}, memberId={}".format(
                lookup_type, transaction_id or 'None', payer_id or 'None', member_id or 'None'
            ),
            level="INFO"
        )
    
    result = {
        'lookup_type': lookup_type,
        'ack_277ca': None,
        'claim_status': None,
        'statuscode': '000',
        'message': '',
    }
    
    # Perform 277CA lookup if requested
    if lookup_type in ['277ca', 'both'] and transaction_id and payer_id:
        try:
            from MediCafe.claim_actions_adapter import search_277ca_via_optumai
            
            ack_response = search_277ca_via_optumai(client, transaction_id, payer_id)
            result['ack_277ca'] = ack_response
            
            if DEBUG:
                MediLink_ConfigLoader.log(
                    "[SUBMISSION_CONTEXT_LOOKUP] 277CA lookup complete: statuscode={}".format(
                        ack_response.get('statuscode', 'unknown')
                    ),
                    level="INFO"
                )
                
        except Exception as e:
            MediLink_ConfigLoader.log(
                "[SUBMISSION_CONTEXT_LOOKUP] 277CA lookup failed: {}".format(e),
                level="WARNING"
            )
            result['ack_277ca'] = {
                'statuscode': '500',
                'message': 'Error retrieving 277CA: {}'.format(str(e))
            }
    
    # Perform member data lookup if requested
    if lookup_type in ['member_data', 'both'] and payer_id:
        # Check if we have sufficient member data
        has_member_data = (
            (member_id and member_dob) or
            (member_id and member_first_name and member_last_name) or
            (member_first_name and member_last_name and member_dob)
        )
        
        if has_member_data:
            try:
                claim_response = get_claim_status_by_member_data(
                    client, payer_id, member_id, member_first_name,
                    member_last_name, member_dob, service_start_date,
                    service_end_date, patient_account_number
                )
                result['claim_status'] = claim_response
                
                if DEBUG:
                    claims_count = len(claim_response.get('claims', []))
                    MediLink_ConfigLoader.log(
                        "[SUBMISSION_CONTEXT_LOOKUP] Member data lookup complete: {} claims found".format(claims_count),
                        level="INFO"
                    )
                    
            except Exception as e:
                MediLink_ConfigLoader.log(
                    "[SUBMISSION_CONTEXT_LOOKUP] Member data lookup failed: {}".format(e),
                    level="WARNING"
                )
                result['claim_status'] = {
                    'statuscode': '500',
                    'message': 'Error retrieving claim status: {}'.format(str(e)),
                    'claims': []
                }
        else:
            MediLink_ConfigLoader.log(
                "[SUBMISSION_CONTEXT_LOOKUP] Insufficient member data for claim status lookup",
                level="WARNING"
            )
    
    # Determine overall status
    # OPTUMAI legacy adapters may return success as either '000' or HTTP-like '200'.
    # Treat both as success to avoid false negatives when 277CA retrieval succeeded.
    optumai_success_status_codes = ('000', '200')
    if result['ack_277ca'] or result['claim_status']:
        # Set overall status based on results
        ack_obj = result.get('ack_277ca') or {}
        claim_obj = result.get('claim_status') or {}
        ack_status = str(ack_obj.get('statuscode') or '')
        claim_status_code = str(claim_obj.get('statuscode') or '')
        claim_has_results = bool(claim_obj.get('claims'))

        if result['ack_277ca'] and ack_status in optumai_success_status_codes:
            result['statuscode'] = '000'
            result['message'] = '277CA confirmation retrieved successfully'
        elif claim_has_results:
            result['statuscode'] = '000'
            result['message'] = 'Claim status retrieved successfully'
        else:
            # Preserve actionable upstream failure details instead of collapsing everything to 404.
            # Priority: explicit non-404 errors from 277CA or member-lookup responses.
            if ack_status and ack_status not in ('404',):
                result['statuscode'] = ack_status
                result['message'] = ack_obj.get('message') or '277CA lookup failed'
            elif claim_status_code and claim_status_code not in ('404', '200'):
                result['statuscode'] = claim_status_code
                result['message'] = claim_obj.get('message') or 'Claim status lookup failed'
            else:
                # No explicit hard failure; treat as no-data and include best available reason.
                result['statuscode'] = '404'
                detail_parts = []
                if ack_obj.get('message'):
                    detail_parts.append('277CA: {}'.format(ack_obj.get('message')))
                if claim_obj.get('message'):
                    detail_parts.append('Claim lookup: {}'.format(claim_obj.get('message')))
                if detail_parts:
                    result['message'] = 'No data found for the provided criteria ({})'.format('; '.join(detail_parts))
                else:
                    result['message'] = 'No data found for the provided criteria'
    else:
        result['statuscode'] = '400'
        result['message'] = 'Insufficient data to perform lookup'
    
    return result


def get_eligibility(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi):
    endpoint_name = 'UHCAPI'
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    url_extension = medi.get('endpoints', {}).get(endpoint_name, {}).get('additional_endpoints', {}).get('eligibility', '')
    url_extension = url_extension + '?payerID={}&providerLastName={}&searchOption={}&dateOfBirth={}&memberId={}&npi={}'.format(
        payer_id, provider_last_name, search_option, date_of_birth, member_id, npi)
    return client.make_api_call(endpoint_name, 'GET', url_extension)

def get_eligibility_v3(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, 
                       first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, 
                       middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, 
                       service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, 
                       corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, 
                       organization_id=None, identify_service_level_deductible=True):

    # Ensure all required parameters have values
    if not all([client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi]):
        raise ValueError("All required parameters must have values: client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi")

    # Endpoint is UHCAPI for this v3 REST call
    endpoint_name = 'UHCAPI'

    # Validate payer_id strictly against UHC list
    valid_payer_ids = get_valid_payer_ids_for_endpoint(client, endpoint_name)
    if payer_id not in valid_payer_ids:
        raise ValueError("Invalid payer_id: {} for endpoint {}. Must be one of: {}".format(
            payer_id, endpoint_name, ", ".join(valid_payer_ids)))
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    url_extension = medi.get('endpoints', {}).get(endpoint_name, {}).get('additional_endpoints', {}).get('eligibility_v3', '')
    
    # Construct request body
    body = {
        "memberId": member_id,
        "lastName": last_name,
        "firstName": first_name,
        "dateOfBirth": date_of_birth,
        "payerID": payer_id,
        "payerLabel": payer_label,
        "payerName": payer_name,
        "serviceStart": service_start,
        "serviceEnd": service_end,
        "middleName": middle_name,
        "gender": gender,
        "ssn": ssn,
        "city": city,
        "state": state,
        "zip": zip,
        "groupNumber": group_number,
        "serviceTypeCode": service_type_code,
        "providerLastName": provider_last_name,
        "providerFirstName": provider_first_name,
        "taxIdNumber": tax_id_number,
        "providerNameID": provider_name_id,
        "npi": npi,
        "corporateTaxOwnerID": corporate_tax_owner_id,
        "corporateTaxOwnerName": corporate_tax_owner_name,
        "organizationName": organization_name,
        "organizationID": organization_id,
        "searchOption": search_option,
        "identifyServiceLevelDeductible": identify_service_level_deductible
    }
    
    # Remove None values from the body
    body = {k: v for k, v in body.items() if v is not None}

    # Log the request body
    MediLink_ConfigLoader.log("Request body: {}".format(json.dumps(body, indent=4)), level="DEBUG")

    return client.make_api_call(endpoint_name, 'POST', url_extension, params=None, data=body)

def get_eligibility_super_connector(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, 
                                   first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, 
                                   middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, 
                                   service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, 
                                   corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, 
                                   organization_id=None, identify_service_level_deductible=True):
    """
    OPTUMAI eligibility (GraphQL) that maps to the same interface as get_eligibility_v3.
    This function does not perform legacy fallback; callers should invoke legacy v3 separately if desired.
    """
    # Ensure all required parameters have values
    if not all([client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi]):
        raise ValueError("All required parameters must have values: client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi")

    # Prefer OPTUMAI endpoint if configured, otherwise fall back to legacy UHCAPI v3 (REST)
    try:
        endpoints_cfg = client.config['MediLink_Config']['endpoints']
    except Exception:
        endpoints_cfg = {}

    endpoint_name = None
    url_extension = None

    try:
        optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
        optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
        optumai_url = optumai_additional.get('eligibility_optumai')
        if optumai_cfg and optumai_cfg.get('api_url') and optumai_url:
            endpoint_name = 'OPTUMAI'
            url_extension = optumai_url
    except Exception:
        # Safe ignore; will fall back below
        pass

    if not endpoint_name:
        # No fallback from this function; surface configuration error
        raise ValueError("OPTUMAI eligibility endpoint not configured")

    # Skip OPTUMAI when payer does not support eligibility (per optum_payer_list.payers)
    supports, crosswalk, reason = _optumai_supports_feature_for_client(
        client, payer_id, 'eligibility', 'eligibility'
    )
    if not supports:
        if reason == 'feature_not_supported':
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI eligibility due to Eligibility=N for payer {}; using get_eligibility_v3.".format(payer_id),
                level="INFO"
            )
        else:
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI eligibility (feature check unavailable); using get_eligibility_v3.",
                level="WARNING"
            )
        # If payer not in UHC list, return structured "not supported" response instead of raising
        try:
            uhc_valid = get_valid_payer_ids_for_endpoint(client, 'UHCAPI')
        except Exception:
            uhc_valid = None
        if uhc_valid is not None and payer_id not in uhc_valid:
            msg = ("Eligibility not supported for payer {} via OPTUMAI or UHCAPI."
                   .format(payer_id))
            try:
                MediLink_ConfigLoader.log(msg, level="WARNING", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return {
                'statuscode': '501',
                'message': msg,
                'payer_id': payer_id,
                'endpoint': 'OPTUMAI'
            }
        return get_eligibility_v3(
            client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi,
            first_name=first_name, last_name=last_name, payer_label=payer_label, payer_name=payer_name,
            service_start=service_start, service_end=service_end, middle_name=middle_name, gender=gender,
            ssn=ssn, city=city, state=state, zip=zip, group_number=group_number,
            service_type_code=service_type_code, provider_first_name=provider_first_name,
            tax_id_number=tax_id_number, provider_name_id=provider_name_id,
            corporate_tax_owner_id=corporate_tax_owner_id, corporate_tax_owner_name=corporate_tax_owner_name,
            organization_name=organization_name, organization_id=organization_id,
            identify_service_level_deductible=identify_service_level_deductible)

    # Validate payer_id against the selected endpoint's list
    # - If OPTUMAI is used, allow the augmented list (includes LIFE1, WELM2, etc.).
    # - If UHCAPI fallback is used, enforce strict UHC list only.
    valid_payer_ids = get_valid_payer_ids_for_endpoint(client, endpoint_name)
    if payer_id not in valid_payer_ids:
        raise ValueError("Invalid payer_id: {} for endpoint {}. Must be one of: {}".format(
            payer_id, endpoint_name, ", ".join(valid_payer_ids)))

    if not url_extension:
        raise ValueError("Eligibility endpoint not configured for {}".format(endpoint_name))

    # Debug/trace: indicate that OPTUMAI eligibility path is active (log only, no console print)
    # Wrap in try/except to handle OSError on Windows when logging stream flush fails
    try:
        MediLink_ConfigLoader.log(
            "Eligibility using OPTUMAI endpoint with path '{}'".format(url_extension),
            level="DEBUG",
            console_output=CONSOLE_LOGGING
        )
    except (OSError, IOError):
        # Windows logging stream flush can fail with OSError [Errno 22] - ignore silently
        pass
    except Exception:
        pass
    
    # Get provider TIN from config (using existing billing_provider_tin)
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    provider_tin_raw = medi.get('billing_provider_tin')
    if not provider_tin_raw:
        raise ValueError("Provider TIN not found in configuration")
    # Normalize provider TIN to 9-digit numeric string using centralized helper
    provider_tin = normalize_provider_tin(provider_tin_raw)
    if not provider_tin:
        raise ValueError("Provider TIN normalization failed: '{}' could not be normalized".format(provider_tin_raw))
    # Validate normalized TIN is 9 digits
    if len(provider_tin) != 9:
        error_msg = "Provider TIN '{}' normalized to '{}' (not 9 digits)".format(provider_tin_raw, provider_tin)
        MediLink_ConfigLoader.log(error_msg, level="WARNING", console_output=CONSOLE_LOGGING)
        raise ValueError(error_msg)
    
    # Validate service dates format if provided (should be ISO 8601 YYYY-MM-DD)
    try:
        from datetime import datetime
    except ImportError:
        datetime = None
    
    if service_start and datetime:
        try:
            service_start_str = str(service_start).strip()
            # Validate ISO date format
            datetime.strptime(service_start_str, '%Y-%m-%d')
        except (ValueError, TypeError):
            MediLink_ConfigLoader.log(
                "Warning: service_start '{}' is not in YYYY-MM-DD format, but continuing anyway".format(
                    str(service_start)[:20]  # Limit length
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Warning: Error validating service_start format: {}".format(str(e)),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
    
    if service_end and datetime:
        try:
            service_end_str = str(service_end).strip()
            # Validate ISO date format
            datetime.strptime(service_end_str, '%Y-%m-%d')
        except (ValueError, TypeError):
            MediLink_ConfigLoader.log(
                "Warning: service_end '{}' is not in YYYY-MM-DD format, but continuing anyway".format(
                    str(service_end)[:20]  # Limit length
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Warning: Error validating service_end format: {}".format(str(e)),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
    
    # Construct GraphQL query variables using the consolidated module
    # Include service dates when provided (needed to determine active policy at time of service)
    # Only pass service dates if they have actual values (not None and not empty string)
    graphql_kwargs = {
        'member_id': member_id,
        'date_of_birth': date_of_birth,
        'payer_id': payer_id,
        'provider_last_name': provider_last_name,
        'provider_npi': npi
    }
    # Add service dates only if provided (safe to omit if None or empty)
    if service_start:
        graphql_kwargs['service_start_date'] = service_start
    if service_end:
        graphql_kwargs['service_end_date'] = service_end
    # Add group number only when available (optional disambiguator for multi-plan cases)
    if group_number:
        try:
            graphql_kwargs['group_number'] = str(group_number).strip()
        except Exception:
            # If normalization fails, skip group number rather than sending bad data
            pass
    
    graphql_variables = MediLink_GraphQL.build_eligibility_variables(**graphql_kwargs)
    
    # Validate NPI format (should be 10 digits)
    if 'providerNPI' in graphql_variables:
        npi_value = graphql_variables['providerNPI']
        if not npi_value.isdigit() or len(npi_value) != 10:
            MediLink_ConfigLoader.log("Warning: NPI '{}' is not 10 digits, but continuing anyway".format(npi_value), level="WARNING")
    
    # Build GraphQL request using the consolidated module
    # Hardcoded switch to use sample data for testing
    USE_SAMPLE_DATA = False  # Set to False to use constructed data
    
    if USE_SAMPLE_DATA:
        # Use the sample data from swagger documentation
        graphql_body = MediLink_GraphQL.get_sample_eligibility_request()
        MediLink_ConfigLoader.log("Using SAMPLE DATA from swagger documentation", level="INFO")
    else:
        # Build GraphQL request with actual data using consolidated module
        # OPTUMAI now uses an enriched query aligned to production schema
        try:
            if endpoint_name == 'OPTUMAI' and hasattr(MediLink_GraphQL, 'build_optumai_enriched_request'):
                graphql_body = MediLink_GraphQL.build_optumai_enriched_request(graphql_variables)
                try:
                    MediLink_ConfigLoader.log("Using OPTUMAI ENRICHED GraphQL request", level="DEBUG")
                except (OSError, IOError):
                    # Windows logging stream flush can fail - ignore silently
                    pass
            else:
                graphql_body = MediLink_GraphQL.build_eligibility_request(graphql_variables)
                try:
                    MediLink_ConfigLoader.log("Using CONSTRUCTED DATA with consolidated GraphQL module", level="INFO")
                except (OSError, IOError):
                    # Windows logging stream flush can fail - ignore silently
                    pass
        except Exception:
            graphql_body = MediLink_GraphQL.build_eligibility_request(graphql_variables)
            try:
                MediLink_ConfigLoader.log("Fallback to standard GraphQL request body", level="WARNING")
            except (OSError, IOError):
                # Windows logging stream flush can fail - ignore silently
                pass
        
        # Compare with sample data for debugging
        sample_data = MediLink_GraphQL.get_sample_eligibility_request()
        MediLink_ConfigLoader.log("Sample data structure: {}".format(json.dumps(sample_data, indent=2)), level="DEBUG")
        MediLink_ConfigLoader.log("Constructed data structure: {}".format(json.dumps(graphql_body, indent=2)), level="DEBUG")
        
        # Compare key differences
        sample_vars = sample_data['variables']['input']
        constructed_vars = graphql_body['variables']['input']
        
        # Log differences in variables
        for key in set(sample_vars.keys()) | set(constructed_vars.keys()):
            sample_val = sample_vars.get(key)
            constructed_val = constructed_vars.get(key)
            if sample_val != constructed_val:
                MediLink_ConfigLoader.log("Variable difference - {}: sample='{}', constructed='{}'".format(
                    key, sample_val, constructed_val), level="DEBUG")
    
    # Log the GraphQL request
    MediLink_ConfigLoader.log("GraphQL request body: {}".format(json.dumps(graphql_body, indent=2)), level="DEBUG")
    MediLink_ConfigLoader.log("GraphQL variables: {}".format(json.dumps(graphql_variables, indent=2)), level="DEBUG")
    
    # Build headers - use centralized builder for OPTUMAI, legacy format for UHCAPI
    if endpoint_name == 'OPTUMAI':
        # Use centralized header builder (normalizes TIN and adds all required headers)
        try:
            optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
            optumai_api_url = optumai_cfg.get('api_url')
            headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        except Exception:
            # Fallback to basic headers if builder fails
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            if provider_tin:
                headers['providerTaxId'] = str(provider_tin)
    else:
        # Legacy UHCAPI headers (preserve existing behavior)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'tin': str(provider_tin)  # Ensure TIN is a string (used for legacy UHC super connector)
        }
    
    # Only add env header when using sample data
    if USE_SAMPLE_DATA:
        headers['env'] = 'sandbox'
    
    # Remove None values from headers
    headers = {k: v for k, v in headers.items() if v is not None}
    
    # Log the final headers being sent
    MediLink_ConfigLoader.log("Final headers being sent: {}".format(json.dumps(headers, indent=2)), level="DEBUG")
    
    # Make the GraphQL API call with enhanced error diagnostics for endpoint failures
    try:
        response = client.make_api_call(endpoint_name, 'POST', url_extension, params=None, data=graphql_body, headers=headers)
    except Exception as e:
        # Check if this is a GraphQL validation error (ED270BR, BACKEND_VALIDATION_FAILED)
        error_str = str(e)
        is_validation_error = False
        validation_terms = ["BACKEND_VALIDATION_FAILED", "ED270BR", "mandatory attributes", "Bad request"]
        for term in validation_terms:
            if term in error_str:
                is_validation_error = True
                break
        
        # Enhanced diagnostics for validation errors
        if is_validation_error:
            # Log sanitized request payload for diagnostics (no PHI)
            try:
                # Extract variables from GraphQL body for diagnostics
                # Defensive check: graphql_body should be defined, but handle edge case where exception occurred during construction
                try:
                    graphql_body_ref = graphql_body
                except NameError:
                    # graphql_body not defined - exception occurred before it was created
                    graphql_body_ref = {}
                graphql_vars = graphql_body_ref.get('variables', {}).get('input', {}) if isinstance(graphql_body_ref, dict) else {}
                
                # Required fields per OPTUMAI spec
                required_fields = ['payerId', 'providerLastName', 'memberId', 'dateOfBirth']
                optional_but_important = ['providerNPI']
                
                # Check which required fields are present
                present_fields = []
                missing_fields = []
                for field in required_fields:
                    if field in graphql_vars and graphql_vars[field]:
                        present_fields.append(field)
                    else:
                        missing_fields.append(field)
                
                # Check providerTaxId header
                provider_tax_id_present = 'providerTaxId' in headers and headers.get('providerTaxId')
                
                # Build diagnostic message
                diag_parts = [
                    "GraphQL validation error (ED270BR) - Missing mandatory attributes",
                    "Required fields present: {}".format(", ".join(present_fields) if present_fields else "none"),
                    "Required fields missing: {}".format(", ".join(missing_fields) if missing_fields else "none"),
                    "providerTaxId header: {}".format("present" if provider_tax_id_present else "missing"),
                ]
                
                # Add optional field status
                if 'providerNPI' in graphql_vars and graphql_vars.get('providerNPI'):
                    diag_parts.append("providerNPI: present")
                else:
                    diag_parts.append("providerNPI: missing")
                
                # Log field values (sanitized - no full values, just presence and lengths)
                field_summary = []
                for field in required_fields + optional_but_important:
                    if field in graphql_vars:
                        val = graphql_vars[field]
                        if isinstance(val, str):
                            field_summary.append("{}: len={}".format(field, len(val)))
                        elif val:
                            field_summary.append("{}: present".format(field))
                        else:
                            field_summary.append("{}: empty".format(field))
                    else:
                        field_summary.append("{}: missing".format(field))
                
                diag_parts.append("Field summary: {}".format("; ".join(field_summary)))
                
                diagnostic_msg = " | ".join(diag_parts)
                MediLink_ConfigLoader.log(diagnostic_msg, level="WARNING", console_output=CONSOLE_LOGGING)
                
                # Also print a concise version
                try:
                    print("[Eligibility] GraphQL validation error - Missing: {} | Check logs for details".format(
                        ", ".join(missing_fields) if missing_fields else "unknown"
                    ))
                except Exception:
                    pass
            except Exception as diag_exc:
                # If diagnostics fail, log basic error
                MediLink_ConfigLoader.log(
                    "GraphQL validation error diagnostics failed: {}".format(str(diag_exc)),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
        
        # Best-effort diagnostics without exposing secrets or PHI
        try:
            status = getattr(getattr(e, 'response', None), 'status_code', None)
            diag = "Eligibility request to {}{} failed".format(
                endpoint_name and (endpoint_name + " ") or "", url_extension)
            if status is not None:
                diag += " with status {}".format(status)
            if not is_validation_error:  # Don't duplicate log for validation errors
                MediLink_ConfigLoader.log(diag, level="ERROR", console_output=CONSOLE_LOGGING)
                try:
                    print("[Eligibility] Request failed (status: {}). See logs for details.".format(status))
                except Exception:
                    pass
        except Exception:
            pass

        # No fallback from this function; re-raise so callers can handle or try legacy explicitly
        raise
    
    # Transform GraphQL response to match REST API format
    # This ensures the calling code doesn't know the difference
    transformed_response = MediLink_GraphQL.transform_eligibility_response(response)

    # Post-transform sanity: if non-200, emit brief diagnostics to aid validation sessions
    try:
        sc_status = transformed_response.get('statuscode') if isinstance(transformed_response, dict) else None
        if sc_status and sc_status != '200':
            msg = transformed_response.get('message')
            MediLink_ConfigLoader.log(
                "OPTUMAI eligibility transformed response status: {} msg: {}".format(sc_status, msg),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
            raw_errs = None
            try:
                raw = transformed_response.get('rawGraphQLResponse', {})
                raw_errs = raw.get('errors')
            except Exception:
                raw_errs = None
            if raw_errs:
                try:
                    first_err = raw_errs[0]
                    code = first_err.get('code') or first_err.get('extensions', {}).get('code')
                    desc = first_err.get('description') or first_err.get('message')
                    print("[Eligibility] GraphQL error code={} desc={}".format(code, desc))
                    
                    # Enhanced diagnostics for validation errors
                    if code and ("BACKEND_VALIDATION_FAILED" in str(code) or "ED270BR" in str(desc) or "mandatory attributes" in str(desc)):
                        # Log which fields were sent vs required
                        try:
                            # Get the variables that were sent (defensive check for scope)
                            try:
                                graphql_body_ref = graphql_body
                            except NameError:
                                graphql_body_ref = {}
                            try:
                                headers_ref = headers
                            except NameError:
                                headers_ref = {}
                            
                            graphql_vars = graphql_body_ref.get('variables', {}).get('input', {}) if isinstance(graphql_body_ref, dict) else {}
                            required_fields = ['payerId', 'providerLastName', 'memberId', 'dateOfBirth']
                            
                            present = [f for f in required_fields if f in graphql_vars and graphql_vars[f]]
                            missing = [f for f in required_fields if f not in graphql_vars or not graphql_vars[f]]
                            
                            diag_msg = "Validation error details - Present: {} | Missing: {} | providerTaxId header: {}".format(
                                ", ".join(present) if present else "none",
                                ", ".join(missing) if missing else "none",
                                "present" if headers_ref.get('providerTaxId') else "missing"
                            )
                            MediLink_ConfigLoader.log(diag_msg, level="WARNING", console_output=CONSOLE_LOGGING)
                        except Exception:
                            pass  # Don't fail if diagnostics can't be generated
                except Exception:
                    pass

            # Terminal self-help hints for auth/authorization cases
            # Non-throwing hint emitter (kept outside core logic path)
            def _emit_hint_for_status(status_str):
                try:
                    trace_id = transformed_response.get('traceId')
                    trace_info = " (Trace ID: {})".format(trace_id) if trace_id else ""
                    
                    if status_str == '401':
                        hint_parts = [
                            "[Eligibility] Hint: Authentication failed{}.".format(trace_info),
                            "Verify client credentials and subscription access in OPTUMAI portal.",
                            "Note: OPTUM auto-grants scopes via subscription - scope parameter is not required in token request.",
                            "See docs/OPTUMAI_TOKEN_SCOPE_INVESTIGATION.md for troubleshooting."
                        ]
                        print(" ".join(hint_parts))
                    elif status_str == '403':
                        hint_parts = [
                            "[Eligibility] Hint: Access denied{}.".format(trace_info),
                            "Verify providerTaxId/TIN and subscription permissions/roles for endpoint.",
                            "Check that client credentials have eligibility endpoint access enabled in OPTUMAI portal."
                        ]
                        print(" ".join(hint_parts))
                except Exception:
                    pass

            try:
                _emit_hint_for_status(str(sc_status))
            except Exception:
                pass
    except Exception:
        pass
    
    return transformed_response

def is_test_mode(client, body, endpoint_type):
    """
    Checks if Test Mode is enabled in the client's configuration and simulates the response if it is.

    :param client: An instance of APIClient
    :param body: The intended request body
    :param endpoint_type: The type of endpoint being accessed ('claim_submission' or 'claim_details')
    :return: A dummy response simulating the real API call if Test Mode is enabled, otherwise None
    """
    if client.config.get("MediLink_Config", {}).get("TestMode", True):
        print("Test Mode is enabled! API Call not executed.")
        print("\nIntended request body:", body)
        MediLink_ConfigLoader.log("Test Mode is enabled! Simulating 1 second delay for API response for {}.".format(endpoint_type), level="INFO")
        time.sleep(1)
        MediLink_ConfigLoader.log("Intended request body: {}".format(body), level="INFO")

        if endpoint_type == 'claim_submission':
            dummy_response = {
                "transactionId": "CS07180420240328013411240",  # This is the tID for the sandbox Claim Acknowledgement endpoint.
                "x12ResponseData": "ISA*00* *00* *ZZ*TEST1234567890 *33*TEST *210101*0101*^*00501*000000001*0*P*:~GS*HC*TEST1234567890*TEST*20210101*0101*1*X*005010X222A1~ST*837*000000001*005010X222A1~BHT*0019*00*00001*20210101*0101*CH~NM1*41*2*TEST SUBMITTER*****46*TEST~PER*IC*TEST CONTACT*TE*1234567890~NM1*40*2*TEST RECEIVER*****46*TEST~HL*1**20*1~NM1*85*2*TEST PROVIDER*****XX*1234567890~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~REF*EI*123456789~PER*IC*TEST PROVIDER*TE*1234567890~NM1*87*2~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~HL*2*1*22*0~SBR*P*18*TEST GROUP******CI~NM1*IL*1*TEST PATIENT****MI*123456789~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~DMG*D8*19800101*M~NM1*PR*2*TEST INSURANCE*****PI*12345~CLM*TESTCLAIM*100***12:B:1*Y*A*Y*Y*P~REF*D9*TESTREFERENCE~HI*ABK:TEST~NM1*DN*1*TEST DOCTOR****XX*1234567890~LX*1~SV1*HC:TEST*100*UN*1***1~DTP*472*RD8*20210101-20210101~REF*6R*TESTREFERENCE~SE*30*000000001~GE*1*1~IEA*1*000000001~",
                "responseType": "dummy_response_837999",
                "message": "Test Mode: Claim validated and sent for further processing"
            }
        elif endpoint_type == 'claim_details':
            dummy_response = {
                "responseType": "dummy_response_277CA-CH",
                "x12ResponseData": "ISA*00* *00*  *ZZ*841162764 *ZZ*UB920086 *240318*0921*^*00501*000165687*0*T*:~GS*HN*841162764*UB920086*20240318*0921*0165687*X*005010X214~ST*277*000000006*005010X214~... SE*116*000000006~GE*1*0165687~IEA*1*000165687~",
                "statuscode": "000",
                "message:": ""
            }
        return dummy_response
    return None

def _detect_inline_ack_type(response_type, x12_data):
    """
    Determine inline ACK type for OPTUMAI submissions.
    Prefers responseType when present; falls back to X12 content.
    """
    if response_type:
        try:
            return str(response_type).upper()
        except Exception:
            return None
    if not x12_data:
        return None
    try:
        data_upper = str(x12_data).upper()
        if 'ST*277' in data_upper:
            return '277CA'
        if 'ST*999' in data_upper:
            return '999'
    except Exception:
        return None
    return None

def submit_uhc_claim(client, x12_request_data):
    """
    Submits a UHC claim and retrieves the claim acknowledgement details.
    
    Phase 4: Routes to OPTUMAI Claim Actions adapter if configured, otherwise falls back to legacy UHCAPI.
    
    This function first submits the claim using the provided x12 837p data. If the client is in Test Mode, 
    it returns a simulated response. If Test Mode is not enabled, it submits the claim and then retrieves 
    the claim acknowledgement details using the transaction ID from the initial response.
    
    NOTE: This function uses endpoints that may not be available in the new swagger version:
    - /Claims/api/claim-submission/v1 (claim submission)
    - /Claims/api/claim-details/v1 (claim acknowledgement)
    
    If these endpoints are deprecated in the new swagger, this function will need to be updated
    to use the new available endpoints.
    
    :param client: An instance of APIClient
    :param x12_request_data: The x12 837p data as a string
    :return: The final response containing the claim acknowledgement details or a dummy response if in Test Mode
    """
    # Verbose claim submission details at DEBUG to reduce log noise (one line at INFO)
    MediLink_ConfigLoader.log(
        "Submit claim - X12 length: {}".format(len(x12_request_data) if x12_request_data else 0),
        level="INFO"
    )
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    MediLink_ConfigLoader.log("SUBMIT UHC CLAIM - VERBOSE DETAILS", level="DEBUG")
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    MediLink_ConfigLoader.log("X12 Request Data Length: {}".format(len(x12_request_data) if x12_request_data else 0), level="DEBUG")
    if x12_request_data:
        MediLink_ConfigLoader.log("X12 Request Data Preview (first 200 chars): {}".format(x12_request_data[:200]), level="DEBUG")
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    
    # Phase 4: Check if OPTUMAI Claim Actions is configured and route to adapter
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    endpoints = medi.get('endpoints', {})
    optumai_cfg = endpoints.get('OPTUMAI', {})
    
    # Early validation: Ensure OPTUMAI configuration matches successful format before attempting
    optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
    optumai_claim_actions_url = optumai_additional.get('claim_actions')
    optumai_api_url = optumai_cfg.get('api_url')
    
    # Validate configuration early to ensure successful format is used on first attempt
    optumai_config_valid = False
    optumai_config_error = None
    if optumai_cfg and optumai_api_url and optumai_claim_actions_url:
        try:
            from MediCafe.claim_actions_adapter import _validate_optumai_config
            is_valid, validation_error, normalized_paths = _validate_optumai_config(optumai_cfg, required_endpoint='claim_actions')
            if is_valid:
                optumai_config_valid = True
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration validated: base_url='{}', claim_actions='{}'".format(
                        optumai_api_url.rstrip('/'), normalized_paths.get('claim_actions', optumai_claim_actions_url)
                    ),
                    level="DEBUG"
                )
            else:
                optumai_config_error = validation_error
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration validation failed: {}. Will fall back to UHCAPI.".format(validation_error),
                    level="WARNING"
                )
        except ImportError:
            # Validation function not available - log but continue with basic checks
            MediLink_ConfigLoader.log(
                "OPTUMAI validation function not available, using basic configuration checks",
                level="DEBUG"
            )
            optumai_config_valid = True  # Allow basic check to proceed
        except Exception as e:
            # Validation error - treat as configuration issue
            optumai_config_error = "Configuration validation error: {}".format(str(e))
            MediLink_ConfigLoader.log(
                "OPTUMAI configuration validation exception: {}. Will fall back to UHCAPI.".format(str(e)),
                level="WARNING"
            )
    
    if optumai_cfg and optumai_api_url and not optumai_claim_actions_url:
        _log_fallback_once(
            'claim_actions_missing_path',
            "OPTUMAI claim actions not configured (missing additional_endpoints.claim_actions); using UHCAPI submission.",
            level="WARNING"
        )
    elif optumai_cfg and optumai_claim_actions_url and not optumai_api_url:
        _log_fallback_once(
            'claim_actions_missing_api_url',
            "OPTUMAI claim actions configured but api_url missing; using UHCAPI submission.",
            level="WARNING"
        )
    
    # Track whether we attempted OPTUMAI and had to fall back
    optumai_attempted = False
    fallback_used = False

    skip_optumai_for_payer = False
    _pid = None
    try:
        from MediCafe.claim_actions_adapter import extract_payer_id_from_x12
        _pid = extract_payer_id_from_x12(x12_request_data)
        if not _pid:
            skip_optumai_for_payer = True
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI claim submission: payer ID not found in X12; using UHCAPI.",
                level="INFO"
            )
        else:
            supports, _cw, reason = _optumai_supports_feature_for_client(
                client, _pid, 'submit_with_precheck', 'claim_submission'
            )
            if not supports:
                skip_optumai_for_payer = True
                if reason == 'feature_not_supported':
                    MediLink_ConfigLoader.log(
                        "Skipping OPTUMAI claim submission due to Submit w/Pre-Check=N for payer {}; using UHCAPI.".format(_pid),
                        level="INFO"
                    )
                else:
                    MediLink_ConfigLoader.log(
                        "Skipping OPTUMAI claim submission (feature check unavailable); using UHCAPI.",
                        level="WARNING"
                    )
    except ImportError:
        pass

    # Route to OPTUMAI adapter if configured and validated (and payer supports it)
    if (optumai_api_url and optumai_claim_actions_url and optumai_config_valid
            and not skip_optumai_for_payer):
        try:
            optumai_attempted = True
            from MediCafe.claim_actions_adapter import (
                submit_claim_via_optumai,
                OPTUMAI_SUCCESS_STATUS_CODES,
                is_optumai_submit_retriable_failure,
                is_optumai_submit_pending_ack,
            )
            MediLink_ConfigLoader.log("Routing claim submission to OPTUMAI Claim Actions", level="INFO")
            
            # Submit via OPTUMAI; on retriable failure (e.g. 930, 5xx), retry once and combine messages if both fail
            submission_response = submit_claim_via_optumai(client, x12_request_data)
            statuscode = str(submission_response.get('statuscode') or '')
            fallback_reason = None
            if is_optumai_submit_retriable_failure(submission_response):
                msg1 = submission_response.get('message') or 'No message'
                MediLink_ConfigLoader.log(
                    "OPTUMAI claim submission attempt 1 failed (statuscode={}); retrying once.".format(statuscode),
                    level="INFO"
                )
                response2 = submit_claim_via_optumai(client, x12_request_data)
                statuscode2 = str(response2.get('statuscode') or '')
                response2_pending_ack = is_optumai_submit_pending_ack(response2)
                if (
                    is_optumai_submit_retriable_failure(response2)
                    or (
                        statuscode2 not in OPTUMAI_SUCCESS_STATUS_CODES
                        and not response2_pending_ack
                    )
                ):
                    msg2 = response2.get('message') or 'No message'
                    combined = "Attempt 1: {}; Attempt 2: {}".format(msg1, msg2)
                    MediLink_ConfigLoader.log(
                        "OPTUMAI claim submission retry also failed (statuscode={}). {}".format(statuscode2, combined),
                        level="WARNING"
                    )
                    submission_response = response2
                    submission_response['message'] = combined
                    fallback_used = True
                    fallback_reason = "optumai_submit_retry_exhausted"
                else:
                    submission_response = response2
                    MediLink_ConfigLoader.log("OPTUMAI claim submission succeeded on retry.", level="INFO")

            if fallback_used and fallback_reason == "optumai_submit_retry_exhausted":
                MediLink_ConfigLoader.log(
                    "OPTUMAI claim submission failed after two attempts; falling back to UHCAPI submission as attempt 3.",
                    level="WARNING"
                )
            else:

                # Check if we got inline 277CA (preferred) or need to fetch separately
                transaction_id = submission_response.get('transactionId')
                x12_response_277ca = submission_response.get('x12ResponseData')
                ack_type = _detect_inline_ack_type(submission_response.get('responseType'), x12_response_277ca)
                has_inline_277 = bool(ack_type and '277' in ack_type)
            
                # If we have inline 277CA, return it directly
                if x12_response_277ca and transaction_id and has_inline_277:
                    # Persist as unified ack event (best-effort)
                    try:
                        from MediCafe.submission_index import append_ack_event, ensure_submission_index
                        cfg, _ = MediLink_ConfigLoader.load_configuration()
                        receipts_root = extract_medilink_config(cfg).get('local_claims_path', None)
                        if receipts_root:
                            ensure_submission_index(receipts_root)
                            status_text = submission_response.get('message', '')
                            append_ack_event(
                                receipts_root,
                                '',
                                status_text,
                                'API-277',
                                'optumai',
                                {'transactionId': transaction_id},
                                'api_ack',
                                int(time.time())
                            )
                    except Exception:
                        pass
                    
                    return submission_response
            
                # If no inline 277CA but we have transaction_id, try to fetch 277CA separately
                if transaction_id and not has_inline_277:
                    submission_statuscode = str(submission_response.get('statuscode') or '')
                    if submission_statuscode not in OPTUMAI_SUCCESS_STATUS_CODES:
                        MediLink_ConfigLoader.log(
                            "Skipping 277CA fetch - submission was not successful (statuscode={}).".format(submission_statuscode),
                            level="INFO"
                        )
                        _meta = submission_response.get('_metadata') or {}
                        _meta['277ca_fetch_attempted'] = False
                        _meta['277ca_fetch_skip_reason'] = 'submission_not_successful'
                        submission_response['_metadata'] = _meta
                        return submission_response
                    if ack_type and '999' in ack_type:
                        MediLink_ConfigLoader.log(
                            "OPTUMAI submission returned 999; fetching 277CA separately.",
                            level="INFO"
                        )
                    elif x12_response_277ca:
                        MediLink_ConfigLoader.log(
                            "OPTUMAI submission returned inline ACK type '{}' (not 277CA); fetching 277CA separately.".format(ack_type or 'unknown'),
                            level="INFO"
                        )
                    try:
                        from MediCafe.claim_actions_adapter import search_277ca_via_optumai
                        payer_id = _pid
                        if not payer_id:
                            MediLink_ConfigLoader.log(
                                "Cannot fetch 277CA - payer ID not found in X12 data. TransactionId: '{}'".format(transaction_id),
                                level="WARNING"
                            )
                            _meta = submission_response.get('_metadata') or {}
                            _meta['277ca_fetch_attempted'] = False
                            _meta['277ca_fetch_skip_reason'] = 'payer_id_not_found_in_x12'
                            submission_response['_metadata'] = _meta
                            return submission_response

                        _skip_277 = False
                        _skip_reason = None
                        supports, _cw, reason = _optumai_supports_feature_for_client(
                            client, payer_id, 'search_277ca', '277ca_fetch'
                        )
                        if not supports:
                            _skip_277 = True
                            if reason == 'feature_not_supported':
                                _skip_reason = 'search_277ca_not_supported_for_payer'
                                MediLink_ConfigLoader.log(
                                    "Skipping 277CA fetch via OPTUMAI due to Search 277CA=N for payer {}; returning submission only.".format(payer_id),
                                    level="INFO"
                                )
                            else:
                                _skip_reason = 'search_277ca_feature_check_unavailable'
                                MediLink_ConfigLoader.log(
                                    "Skipping 277CA fetch via OPTUMAI (feature check unavailable); returning submission only.",
                                    level="WARNING"
                                )
                        if _skip_277:
                            _meta = submission_response.get('_metadata') or {}
                            _meta['277ca_fetch_attempted'] = False
                            _meta['277ca_fetch_skip_reason'] = _skip_reason or 'search_277ca_not_supported_for_payer'
                            submission_response['_metadata'] = _meta
                            return submission_response

                        MediLink_ConfigLoader.log(
                            "Fetching 277CA via OPTUMAI search277CA - transactionId: '{}' (type: {}, length: {}), payerId: '{}'".format(
                                transaction_id, type(transaction_id).__name__, len(str(transaction_id)) if transaction_id else 0, payer_id
                            ),
                            level="INFO"
                        )
                        ack_response = search_277ca_via_optumai(client, transaction_id, payer_id)
                        # Log the 277CA response status
                        ack_statuscode = ack_response.get('statuscode') if isinstance(ack_response, dict) else None
                        ack_message = ack_response.get('message') if isinstance(ack_response, dict) else None
                        MediLink_ConfigLoader.log(
                            "277CA search completed - statuscode: {}, message: {}".format(ack_statuscode, ack_message),
                            level="INFO"
                        )
                        # Merge transaction_id into response and add metadata (only if ack_response is a dict)
                        # This helps handle_transmission_result detect when claim submission succeeded but 277CA failed
                        if isinstance(ack_response, dict):
                            ack_response['transactionId'] = transaction_id
                            ack_status_str = str(ack_statuscode or '')
                            ack_response['_metadata'] = {
                                'claim_submission_success': True,
                                'transactionId': transaction_id,
                                '277ca_fetch_attempted': True,
                                '277ca_fetch_success': ack_status_str in OPTUMAI_SUCCESS_STATUS_CODES,
                                '277ca_error': ack_message if ack_status_str not in OPTUMAI_SUCCESS_STATUS_CODES else None
                            }
                        else:
                            # If ack_response is not a dict, create a dict with transactionId and error info
                            MediLink_ConfigLoader.log(
                                "277CA search returned non-dict response: {}. Creating dict wrapper.".format(type(ack_response).__name__),
                                level="WARNING"
                            )
                            ack_response = {
                                'transactionId': transaction_id,
                                'x12ResponseData': None,
                                'responseType': None,
                                'statuscode': '500',
                                'message': '277CA search returned invalid response type: {}'.format(type(ack_response).__name__),
                                '_metadata': {
                                    'claim_submission_success': True,
                                    'transactionId': transaction_id,
                                    '277ca_fetch_attempted': True,
                                    '277ca_fetch_success': False,
                                    '277ca_error': 'Invalid response type from search_277ca_via_optumai'
                                }
                            }
                        return ack_response
                    except Exception as e:
                        import traceback
                        error_trace = traceback.format_exc()
                        MediLink_ConfigLoader.log(
                            "Failed to fetch 277CA via OPTUMAI: {}\nTraceback:\n{}".format(str(e), error_trace),
                            level="ERROR"
                        )
                        # Return submission response with metadata so receipt/partial-success logic sees attempted 277CA and failure
                        _meta = submission_response.get('_metadata') or {}
                        _meta['claim_submission_success'] = True
                        _meta['277ca_fetch_attempted'] = True
                        _meta['277ca_fetch_success'] = False
                        _meta['277ca_error'] = str(e)
                        submission_response['_metadata'] = _meta
                        return submission_response
            
            if not fallback_used:
                return submission_response
        except ImportError:
            # Adapter not available - fall through to legacy UHCAPI
            # This is a configuration/capability issue, not an API error
            MediLink_ConfigLoader.log("OPTUMAI adapter not available, falling back to UHCAPI", level="WARNING")
            fallback_used = True
        except ValueError as e:
            # Configuration errors (e.g., from validation) - don't fall back, fail immediately
            error_msg = str(e)
            if 'configuration' in error_msg.lower() or 'config' in error_msg.lower():
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration error (not falling back to UHCAPI): {}".format(error_msg),
                    level="ERROR"
                )
                # Return error response instead of falling back
                return {
                    'transactionId': None,
                    'x12ResponseData': None,
                    'responseType': None,
                    'statuscode': '500',
                    'message': 'OPTUMAI configuration error: {}'.format(error_msg)
                }
            else:
                # Other ValueError - treat as API error and fall back
                MediLink_ConfigLoader.log("OPTUMAI submission failed (ValueError), falling back to UHCAPI: {}".format(error_msg), level="WARNING")
                fallback_used = True
        except Exception as e:
            # Error in OPTUMAI submission - categorize error type
            error_msg = str(e)
            error_type = type(e).__name__
            
            # Check if this is a configuration-related error
            is_config_error = (
                'configuration' in error_msg.lower() or
                'config' in error_msg.lower() or
                'not configured' in error_msg.lower() or
                'missing' in error_msg.lower() and ('endpoint' in error_msg.lower() or 'path' in error_msg.lower())
            )
            
            if is_config_error:
                # Configuration errors - don't fall back, fail immediately
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration error detected (not falling back to UHCAPI): {} ({})".format(error_msg, error_type),
                    level="ERROR"
                )
                # Return error response instead of falling back
                return {
                    'transactionId': None,
                    'x12ResponseData': None,
                    'responseType': None,
                    'statuscode': '500',
                    'message': 'OPTUMAI configuration error: {}'.format(error_msg)
                }
            else:
                # API/network errors - can fall back to UHCAPI
                MediLink_ConfigLoader.log(
                    "OPTUMAI submission failed ({}), falling back to UHCAPI: {}".format(error_type, error_msg),
                    level="WARNING"
                )
                fallback_used = True
    
    # Fallback to legacy UHCAPI
    endpoint_name = 'UHCAPI'
    claim_submission_url = endpoints.get(endpoint_name, {}).get('additional_endpoints', {}).get('claim_submission', '')
    claim_details_url = endpoints.get(endpoint_name, {}).get('additional_endpoints', {}).get('claim_details', '')
 
    MediLink_ConfigLoader.log("Claim Submission URL: {}".format(claim_submission_url), level="INFO")
    MediLink_ConfigLoader.log("Claim Details URL: {}".format(claim_details_url), level="INFO")
 
    # Headers for the request
    headers = {'Content-Type': 'application/json'} 
 
    # Request body for claim submission
    claim_body = {'x12RequestData': x12_request_data}
 
    MediLink_ConfigLoader.log("Claim Body Keys: {}".format(list(claim_body.keys())), level="INFO")
    MediLink_ConfigLoader.log("Headers: {}".format(json.dumps(headers, indent=2)), level="INFO")
 
    # Check if Test Mode is enabled and return simulated response if so
    test_mode_response = is_test_mode(client, claim_body, 'claim_submission')
    if test_mode_response:
        if fallback_used:
            try:
                msg = test_mode_response.get('message', '')
                fallback_suffix = " [via UHCAPI fallback]"
                if msg:
                    if fallback_suffix not in msg:
                        test_mode_response['message'] = msg + fallback_suffix
                else:
                    test_mode_response['message'] = "UHCAPI fallback used" + fallback_suffix
            except Exception:
                pass
        return test_mode_response
 
    # Make the API call to submit the claim
    try:
        MediLink_ConfigLoader.log("Making claim submission API call...", level="INFO")
        submission_response = client.make_api_call(endpoint_name, 'POST', claim_submission_url, data=claim_body, headers=headers)
        
        # Extract the transaction ID from the submission response
        transaction_id = submission_response.get('transactionId')
        if not transaction_id:
            raise ValueError("transactionId not found in the submission response")
        
        # Log the transaction ID for traceability
        MediLink_ConfigLoader.log("UHCAPI claim submission transactionId: {}".format(transaction_id), level="INFO")
        
        # Prepare the request body for the claim acknowledgement retrieval
        acknowledgement_body = {'transactionId': transaction_id}

        def _finalize_uhc_ack_response(raw_ack_response):
            """Normalize UHC acknowledgment response shape and attach metadata for receipt compatibility."""
            if isinstance(raw_ack_response, dict):
                ack_response = raw_ack_response
            else:
                ack_response = {
                    'statuscode': '500',
                    'message': 'UHCAPI acknowledgement returned invalid response type: {}'.format(
                        type(raw_ack_response).__name__
                    ),
                    'x12ResponseData': None,
                    'responseType': None
                }

            # Preserve transaction ID from UHC submission so downstream receipt logic always has linkage
            ack_response['transactionId'] = ack_response.get('transactionId') or transaction_id

            has_x12_response = bool(ack_response.get('x12ResponseData') or ack_response.get('x12Response277CA'))
            ack_status = str(ack_response.get('statuscode') or ack_response.get('statusCode') or '')
            ack_success = has_x12_response or ack_status in ('200', '000')

            ack_meta = ack_response.get('_metadata') if isinstance(ack_response.get('_metadata'), dict) else {}
            ack_meta['claim_submission_success'] = True
            ack_meta['transactionId'] = ack_response['transactionId']
            ack_meta['277ca_fetch_attempted'] = True
            ack_meta['277ca_fetch_success'] = ack_success
            ack_meta['response_source'] = 'uhcapi'
            if not ack_success:
                ack_meta['277ca_error'] = ack_response.get('message')
            ack_response['_metadata'] = ack_meta

            # If we used fallback, append a note so receipts can reflect it
            if fallback_used:
                try:
                    msg = ack_response.get('message', '')
                    fallback_suffix = " [via UHCAPI fallback]"
                    if msg:
                        if fallback_suffix not in msg:
                            ack_response['message'] = msg + fallback_suffix
                    else:
                        ack_response['message'] = "UHCAPI fallback used" + fallback_suffix
                except Exception:
                    pass

            return ack_response
 
        # Check if Test Mode is enabled and return simulated response if so
        test_mode_response = is_test_mode(client, acknowledgement_body, 'claim_details')
        if test_mode_response:
            return _finalize_uhc_ack_response(test_mode_response)
 
        # Make the API call to retrieve the claim acknowledgement details
        acknowledgement_response = client.make_api_call(endpoint_name, 'POST', claim_details_url, data=acknowledgement_body, headers=headers)
        acknowledgement_response = _finalize_uhc_ack_response(acknowledgement_response)

        
        # Persist as unified ack event (best-effort)
        try:
            from MediCafe.submission_index import append_ack_event, ensure_submission_index
            cfg, _ = MediLink_ConfigLoader.load_configuration()
            receipts_root = extract_medilink_config(cfg).get('local_claims_path', None)
            if receipts_root:
                ensure_submission_index(receipts_root)
                status_text = ''
                try:
                    # Attempt to pull a readable status from the response
                    status_text = acknowledgement_response.get('status') or acknowledgement_response.get('message') or ''
                except Exception:
                    status_text = ''
                append_ack_event(
                    receipts_root,
                    '',  # claim_key unknown here
                    status_text,
                    'API-277',
                    'uhcapi',
                    {'transactionId': transaction_id},
                    'api_ack',
                    int(time.time())
                )
        except Exception:
            pass
        
        return acknowledgement_response
 
    except Exception as e:
        print("Error during claim processing: {}".format(e))
        raise

# -----------------------------------------------------------------------------
# Helper: Optional acknowledgment (277CA) test endpoint
# -----------------------------------------------------------------------------

def test_acknowledgment(client, transaction_id, config, endpoint_name='UHCAPI'):
    """
    Light-weight probe to test the claim acknowledgment endpoint (e.g., 277CA) if configured.
    - Reads endpoint URL from config['MediLink_Config']['endpoints'][endpoint_name]['ack_endpoint']
    - Posts/gets with {'transactionId': transaction_id} depending on endpoint requirement
    - Logs response; returns parsed JSON or text.

    Backward-compatible: If no ack endpoint configured, logs and returns None without failing.
    """
    try:
        ack_url = (
            config.get('MediLink_Config', {})
                  .get('endpoints', {})
                  .get(endpoint_name, {})
                  .get('ack_endpoint')
        )
        if not ack_url:
            MediLink_ConfigLoader.log("Ack endpoint not configured for {}. Skipping acknowledgment test.".format(endpoint_name), level="INFO")
            return None

        payload = {"transactionId": transaction_id}
        headers = {"Content-Type": "application/json"}
        headers = client.add_environment_headers(headers, endpoint_name) if hasattr(client, 'add_environment_headers') else headers
        MediLink_ConfigLoader.log("Testing acknowledgment endpoint: {} payload={}".format(ack_url, payload), level="DEBUG")

        # Use generic request helper if available; otherwise fall back to requests
        try:
            response = client._request('post', ack_url, data=json.dumps(payload), headers=headers)  # type: ignore[attr-defined]
        except Exception:
            import requests as _rq
            response = _rq.post(ack_url, data=json.dumps(payload), headers=headers)
        
        try:
            content = response.json()
        except Exception:
            content = getattr(response, 'text', str(response))
        MediLink_ConfigLoader.log("Ack response: {}".format(content), level="INFO")
        return content
    except Exception as e:
        MediLink_ConfigLoader.log("Ack test failed: {}".format(e), level="ERROR")
        return None

if __name__ == "__main__":
    # Use factory for consistency but fallback to direct instantiation for testing
    try:
        from MediCafe.core_utils import get_api_client
        client = get_api_client()
        if client is None:
            client = APIClient()
    except ImportError:
        client = APIClient()
    
    # Define a configuration to enable or disable tests
    test_config = {
        'test_fetch_payer_name': False,
        'test_claim_summary': False,
        'test_eligibility': False,
        'test_eligibility_v3': False,
        'test_eligibility_super_connector': False,
        'test_claim_submission': False,
    }
    
    try:
        api_test_cases = client.config['MediLink_Config']['API Test Case']
        
        # Test 1: Fetch Payer Name
        if test_config.get('test_fetch_payer_name', False):
            try:
                for case in api_test_cases:
                    payer_name = fetch_payer_name_from_api(client, case['payer_id'], client.config)
                    print("*** TEST API: Payer Name: {}".format(payer_name))
            except Exception as e:
                print("*** TEST API: Error in Fetch Payer Name Test: {}".format(e))
        
        # Test 2: Get Claim Summary
        if test_config.get('test_claim_summary', False):
            try:
                for case in api_test_cases:
                    claim_summary = get_claim_summary_by_provider(client, case['provider_tin'], '05/01/2024', '06/23/2024', case['payer_id'])
                    print("TEST API: Claim Summary: {}".format(claim_summary))
            except Exception as e:
                print("TEST API: Error in Claim Summary Test: {}".format(e))
        
        # Test 3: Get Eligibility
        if test_config.get('test_eligibility', False):
            try:
                for case in api_test_cases:
                    eligibility = get_eligibility(client, case['payer_id'], case['provider_last_name'], case['search_option'], 
                                                  case['date_of_birth'], case['member_id'], case['npi'])
                    print("TEST API: Eligibility: {}".format(eligibility))
            except Exception as e:
                print("TEST API: Error in Eligibility Test: {}".format(e))

        # Test 4: Get Eligibility v3
        if test_config.get('test_eligibility_v3', False):
            try:
                for case in api_test_cases:
                    eligibility_v3 = get_eligibility_v3(client, payer_id=case['payer_id'], provider_last_name=case['provider_last_name'], 
                                                        search_option=case['search_option'], date_of_birth=case['date_of_birth'], 
                                                        member_id=case['member_id'], npi=case['npi'])
                    print("TEST API: Eligibility v3: {}".format(eligibility_v3))
            except Exception as e:
                print("TEST API: Error in Eligibility v3 Test: {}".format(e))

        # Test 5: Get Eligibility Super Connector (GraphQL)
        if test_config.get('test_eligibility_super_connector', False):
            try:
                for case in api_test_cases:
                    eligibility_super_connector = get_eligibility_super_connector(client, payer_id=case['payer_id'], provider_last_name=case['provider_last_name'], 
                                                                                search_option=case['search_option'], date_of_birth=case['date_of_birth'], 
                                                                                member_id=case['member_id'], npi=case['npi'])
                    print("TEST API: Eligibility Super Connector: {}".format(eligibility_super_connector))
            except Exception as e:
                print("TEST API: Error in Eligibility Super Connector Test: {}".format(e))

        """
        # Example of iterating over multiple patients (if needed)
        patients = [
            {'payer_id': '87726', 'provider_last_name': 'VIDA', 'search_option': 'MemberIDDateOfBirth', 'date_of_birth': '1980-01-01', 'member_id': '123456789', 'npi': '9876543210'},
            {'payer_id': '87726', 'provider_last_name': 'SMITH', 'search_option': 'MemberIDDateOfBirth', 'date_of_birth': '1970-02-02', 'member_id': '987654321', 'npi': '1234567890'},
            # Add more patients as needed
        ]

        for patient in patients:
            try:
                eligibility = get_eligibility(client, patient['payer_id'], patient['provider_last_name'], patient['search_option'], patient['date_of_birth'], patient['member_id'], patient['npi'])
                print("Eligibility for {}: {}".format(patient['provider_last_name'], eligibility))
            except Exception as e:
                print("Error in getting eligibility for {}: {}".format(patient['provider_last_name'], e))
        """
        # Test 6: UHC Claim Submission
        if test_config.get('test_claim_submission', False):
            try:
                x12_request_data = (
                    "ISA*00* *00* *ZZ*BRT219991205 *33*87726 *170417*1344*^*00501*019160001*0*P*:~GS*HC*BRT219991205*B2BRTA*20170417*134455*19160001*X*005010X222A1~ST*837*000000001*005010X222A1~BHT*0019*00*00001*20170417*134455*CH~NM1*41*2*B00099999819*****46*BB2B~PER*IC*NO NAME*TE*1234567890~NM1*40*2*TIGER*****46*87726~HL*1**20*1~NM1*85*2*XYZ ADDRESS*****XX*1073511762~N3*123 CITY#680~N4*STATE*TG*98765~REF*EI*943319804~PER*IC*XYZ ADDRESS*TE*8008738385*TE*9142862043*FX*1234567890~NM1*87*2~N3*PO BOX 277500~N4*STATE*TS*303847000~HL*2*1*22*0~SBR*P*18*701648******CI~NM1*IL*1*FNAME*LNAME****MI*00123456789~N3*2020 CITY~N4*STATE*TG*80001~DMG*D8*19820220*M~NM1*PR*2*PROVIDER XYZ*****PI*87726~\nCLM*TOSRTA-SPL1*471***12:B:1*Y*A*Y*Y*P~REF*D9*H4HZMH0R4P0104~HI*ABK:Z12~NM1*DN*1*DN*SKO****XX*1255589300~LX*1~SV1*HC:73525*471*UN*1***1~DTP*472*RD8*0190701-20190701~REF*6R*2190476543Z1~SE*30*000000001~GE*1*19160001~IEA*1*019160001~"
                )
                response = submit_uhc_claim(client, x12_request_data)
                print("\nTEST API: Claim Submission Response:\n", response)
            except Exception as e:
                print("\nTEST API: Error in Claim Submission Test:\n", e)
    
    except Exception as e:
        print("TEST API: Unexpected Error: {}".format(e))
