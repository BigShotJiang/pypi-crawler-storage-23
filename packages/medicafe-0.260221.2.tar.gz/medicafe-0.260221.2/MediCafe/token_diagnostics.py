#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Redacted token-request diagnostics (safe for logs/support bundles).

Goals:
- Help debug "dev machine works, client machine fails" discrepancies.
- Never print/log client_secret or tokens in full.
- Be XP/Python 3.4.4 compatible (no f-strings, no type hints).
"""

import os
import sys
import time
import hashlib

try:
    # Python 3
    from urllib.parse import urlsplit
except Exception:
    try:
        # Python 2 fallback (should not be needed, but keep it safe)
        from urlparse import urlsplit
    except Exception:
        urlsplit = None


def _to_text(value):
    try:
        if value is None:
            return ''
        if isinstance(value, str):
            return value
        # Python 3.4: bytes decode
        if isinstance(value, bytes):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return value.decode('latin-1', 'ignore')
        return str(value)
    except Exception:
        return ''


def _sha256_8(text_value):
    """Return first 8 hex chars of sha256 of a value (utf-8, ignore errors)."""
    try:
        s = _to_text(text_value)
        b = s.encode('utf-8', 'ignore')
        return hashlib.sha256(b).hexdigest()[:8]
    except Exception:
        return '????????'


def _last4(text_value):
    try:
        s = _to_text(text_value)
        if not s:
            return ''
        return s[-4:] if len(s) >= 4 else s
    except Exception:
        return ''


def _len(text_value):
    try:
        s = _to_text(text_value)
        return len(s) if s is not None else 0
    except Exception:
        return 0


def _has_non_ascii(text_value):
    try:
        s = _to_text(text_value)
        for ch in s:
            if ord(ch) > 127:
                return True
        return False
    except Exception:
        return False


def _whitespace_flags(text_value):
    """
    Return flags about whitespace that commonly causes auth failures.
    """
    flags = {
        'leading_space': False,
        'trailing_space': False,
        'contains_space': False,
        'contains_tab': False,
        'contains_newline': False,
    }
    try:
        s = _to_text(text_value)
        if not s:
            return flags
        flags['leading_space'] = (len(s) > 0 and s[0].isspace())
        flags['trailing_space'] = (len(s) > 0 and s[-1].isspace())
        flags['contains_space'] = (' ' in s)
        flags['contains_tab'] = ('\t' in s)
        flags['contains_newline'] = ('\n' in s) or ('\r' in s)
        return flags
    except Exception:
        return flags


def _normalize_url(url):
    """Strip query/fragment so logs don't contain junk; keep scheme/host/path."""
    try:
        u = _to_text(url).strip()
        if not u:
            return ''
        if urlsplit is None:
            return u
        parts = urlsplit(u)
        # Rebuild without query/fragment
        base = parts.scheme + '://' + parts.netloc + parts.path
        return base
    except Exception:
        return _to_text(url)


def _env_presence(keys):
    out = {}
    for k in keys:
        try:
            out[k] = bool(os.environ.get(k, '').strip())
        except Exception:
            out[k] = False
    return out


def build_token_diagnostics_block(endpoint_name,
                                 token_url=None,
                                 client_id=None,
                                 client_secret=None,
                                 scope=None,
                                 grant_type='client_credentials',
                                 config_path=None,
                                 http_status=None,
                                 error_code=None,
                                 error_description=None,
                                 exception_text=None,
                                 note=None):
    """
    Build a redacted, pretty diagnostic block for token failures.
    Safe to print/log by default.
    """
    try:
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        ts = str(int(time.time()))

    cfg_env = _to_text(os.environ.get('MEDICAFE_CONFIG_FILE', '')).strip()
    if not config_path:
        config_path = cfg_env or ''

    cfg_exists = False
    try:
        cfg_exists = bool(config_path and os.path.exists(config_path))
    except Exception:
        cfg_exists = False

    cid_flags = _whitespace_flags(client_id)
    csec_flags = _whitespace_flags(client_secret)

    proxy = _env_presence(['HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY'])
    # Windows uses lowercase variants sometimes; check those too (presence only).
    proxy2 = _env_presence(['http_proxy', 'https_proxy', 'no_proxy'])

    # requests version if available (safe)
    requests_ver = ''
    try:
        import requests  # noqa: F401
        requests_ver = getattr(requests, '__version__', '') or ''
    except Exception:
        requests_ver = ''

    lines = []
    lines.append("=" * 72)
    lines.append("TOKEN REQUEST DIAGNOSTICS (REDACTED)")
    lines.append("=" * 72)
    lines.append("timestamp:        {0}".format(ts))
    lines.append("endpoint:         {0}".format(_to_text(endpoint_name)))
    lines.append("config_path:      {0} (exists={1})".format(_to_text(config_path), cfg_exists))
    if cfg_env and cfg_env != config_path:
        lines.append("config_env:       MEDICAFE_CONFIG_FILE={0}".format(cfg_env))
    lines.append("token_url:        {0}".format(_normalize_url(token_url)))
    lines.append("grant_type:       {0}".format(_to_text(grant_type)))
    lines.append("scope:            {0}".format(_to_text(scope) if scope else "(not set)"))
    lines.append("")
    lines.append("client_id:        len={0} last4={1} sha256_8={2}".format(
        _len(client_id), _last4(client_id), _sha256_8(client_id)
    ))
    lines.append("client_id_flags:  leading_space={0} trailing_space={1} non_ascii={2}".format(
        cid_flags.get('leading_space'), cid_flags.get('trailing_space'), _has_non_ascii(client_id)
    ))
    lines.append("")
    lines.append("client_secret:    len={0} last4={1} sha256_8={2}".format(
        _len(client_secret), _last4(client_secret), _sha256_8(client_secret)
    ))
    lines.append("secret_flags:     leading_space={0} trailing_space={1} space={2} tab={3} newline={4} non_ascii={5}".format(
        csec_flags.get('leading_space'),
        csec_flags.get('trailing_space'),
        csec_flags.get('contains_space'),
        csec_flags.get('contains_tab'),
        csec_flags.get('contains_newline'),
        _has_non_ascii(client_secret)
    ))
    lines.append("")
    lines.append("proxy_env:        HTTP_PROXY={0} HTTPS_PROXY={1} NO_PROXY={2}".format(
        "set" if proxy.get('HTTP_PROXY') else "unset",
        "set" if proxy.get('HTTPS_PROXY') else "unset",
        "set" if proxy.get('NO_PROXY') else "unset"
    ))
    lines.append("proxy_env_lower:  http_proxy={0} https_proxy={1} no_proxy={2}".format(
        "set" if proxy2.get('http_proxy') else "unset",
        "set" if proxy2.get('https_proxy') else "unset",
        "set" if proxy2.get('no_proxy') else "unset"
    ))
    lines.append("python:           {0}.{1}.{2} ({3})".format(
        getattr(sys.version_info, 'major', sys.version_info[0]),
        getattr(sys.version_info, 'minor', sys.version_info[1]),
        getattr(sys.version_info, 'micro', sys.version_info[2]),
        _to_text(sys.executable)
    ))
    lines.append("requests:         {0}".format(requests_ver or "(not available)"))
    lines.append("")
    lines.append("result:           FAILED http_status={0} error_code={1}".format(
        _to_text(http_status) if http_status is not None else "(unknown)",
        _to_text(error_code) if error_code else "(unknown)"
    ))
    if error_description:
        # Trim to avoid huge blocks (proxy HTML, etc.)
        ed = _to_text(error_description)
        if len(ed) > 400:
            ed = ed[:400] + "..."
        lines.append("error_description:{0}{1}".format(" " if ed else "", ed))
    if exception_text:
        ex = _to_text(exception_text)
        if len(ex) > 400:
            ex = ex[:400] + "..."
        lines.append("exception:        {0}".format(ex))
    if note:
        n = _to_text(note)
        if len(n) > 400:
            n = n[:400] + "..."
        lines.append("note:             {0}".format(n))
    lines.append("=" * 72)
    return "\n".join(lines)

