# MediCafe/timing_utils.py
"""
Structured timing telemetry for local workflows.
Emits JSONL records, persists bounded history, supports summary/regression view.
Python 3.4.4 compatible; no new third-party deps.

Event schema: run_id, workflow, stage, duration_ms, timestamp_utc, status
Storage: {local_storage_path}/timing_history.jsonl, rotation at 500 lines
Enable: MediLink_Config.PERFORMANCE_LOGGING in config.json or MEDICAFE_PERFORMANCE_LOGGING=1 env
"""
from __future__ import absolute_import
import os
import json
import time
import threading
from collections import OrderedDict
from datetime import datetime

_HISTORY_FILENAME = 'timing_history.jsonl'
_MAX_LINES = 500
_RUN_STORAGE_CAP = 100
_RUN_ID_COUNTER = 0
_RUN_ID_LOCK = threading.Lock()
_RUN_STORAGE = OrderedDict()
_RUN_STORAGE_LOCK = threading.Lock()
_WRITE_LOCK = threading.Lock()

# When parent stage exists, exclude child stages from total (avoids double-counting)
_CHILD_STAGES = {
    'config_loader': {'path_resolution', 'config_parse', 'crosswalk_parse'},
    'medilink': {'directory_listing', 'file_checking', 'detection_total', 'patient_data'},
}


def _dedupe_stages_for_total(evs, wf):
    """Exclude child stages when parent exists; return events to sum for run total."""
    stages_present = {e.get('stage') for e in evs}
    excluded = set()
    if wf == 'config_loader' and 'load_total' in stages_present:
        excluded |= _CHILD_STAGES.get('config_loader', set())
    if wf == 'medilink':
        if 'file_detection' in stages_present:
            excluded |= {'directory_listing', 'file_checking', 'detection_total'}
        if 'submission_flow' in stages_present:
            excluded.add('patient_data')
    return [e for e in evs if e.get('stage') not in excluded]


def is_timing_enabled():
    """True if PERFORMANCE_LOGGING (from logging_config, which reads config + MEDICAFE_PERFORMANCE_LOGGING env)."""
    try:
        from MediCafe.logging_config import PERFORMANCE_LOGGING
        return bool(PERFORMANCE_LOGGING)
    except ImportError:
        return False


def start_run(workflow, storage_path=None):
    """Return run_id string (YYYYMMDDTHHMMSS-N). N = per-process monotonic counter.
    Store storage_path in _run_storage[run_id] for record_stage lookup."""
    global _RUN_ID_COUNTER
    base = datetime.utcnow().strftime('%Y%m%dT%H%M%S')
    with _RUN_ID_LOCK:
        _RUN_ID_COUNTER += 1
        run_id = '{0}-{1}'.format(base, _RUN_ID_COUNTER)
    if storage_path is not None:
        with _RUN_STORAGE_LOCK:
            _RUN_STORAGE[run_id] = storage_path
            while len(_RUN_STORAGE) > _RUN_STORAGE_CAP:
                _RUN_STORAGE.popitem(last=False)
    return run_id


def record_stage(run_id, workflow, stage, duration_ms, status='ok', meta=None):
    """Append event to JSONL. No-op if not timing_enabled, run_id is None, or on error."""
    if not is_timing_enabled() or run_id is None:
        return
    with _RUN_STORAGE_LOCK:
        storage_path = _RUN_STORAGE.get(run_id)
    if storage_path is None:
        storage_path = get_storage_path()
    if not storage_path:
        return
    filepath = os.path.join(storage_path, _HISTORY_FILENAME)
    event = {
        'run_id': run_id,
        'workflow': workflow,
        'stage': stage,
        'duration_ms': int(duration_ms),
        'timestamp_utc': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ'),
        'status': status,
    }
    if meta:
        event['meta'] = meta
    try:
        _append_with_rotation(filepath, event)
    except Exception:
        pass


def _append_with_rotation(filepath, event):
    """Append event to JSONL, rotating to keep last _MAX_LINES. Thread-safe via _WRITE_LOCK."""
    with _WRITE_LOCK:
        line = json.dumps(event) + '\n'
        dirpath = os.path.dirname(filepath)
        if dirpath and not os.path.exists(dirpath):
            try:
                os.makedirs(dirpath)
            except OSError:
                if not os.path.isdir(dirpath):
                    return
        lines = []
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r') as f:
                    lines = f.readlines()
            except Exception:
                lines = []
        lines = lines[-(_MAX_LINES - 1):] if len(lines) >= _MAX_LINES else lines
        lines.append(line)
        tmp = None
        try:
            tmp = filepath + '.tmp'
            with open(tmp, 'w') as f:
                f.writelines(lines)
            try:
                os.rename(tmp, filepath)
            except OSError:
                import shutil
                shutil.move(tmp, filepath)
        except Exception:
            try:
                if tmp and os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass


class _NoopTimer(object):
    """Context manager that does nothing. Use when stage_timer is not available or run_id is None."""

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


noop_timer = _NoopTimer()


class stage_timer(object):
    """Context manager. On exit: record_stage(run_id, workflow, stage, duration_ms, status). No-op if run_id is None."""

    def __init__(self, run_id, workflow, stage, status='ok'):
        self.run_id = run_id
        self.workflow = workflow
        self.stage = stage
        self.status = status
        self._start = None

    def __enter__(self):
        self._start = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.run_id is None:
            return False
        duration_ms = int((time.time() - self._start) * 1000)
        status = 'error' if exc_type else self.status
        record_stage(self.run_id, self.workflow, self.stage, duration_ms, status=status)
        return False


def get_storage_path(config=None, repo_root=None, env_local_storage=None):
    """Resolve timing_history.jsonl directory. See plan Section 4."""
    if config is not None and isinstance(config, dict):
        medi = config.get('MediLink_Config', {}) or {}
        path = medi.get('local_storage_path', '') or '.'
        if path != '.' and repo_root and not os.path.isabs(path):
            path = os.path.join(repo_root, path)
        if path and path != '.':
            return os.path.abspath(path)
    if env_local_storage is not None and repo_root is not None:
        path = env_local_storage or '.'
        if path == '.' or not os.path.isabs(path):
            path = os.path.join(repo_root, path)
        return os.path.abspath(path)
    env_config = os.environ.get('MEDICAFE_CONFIG_FILE', '').strip()
    if env_config:
        parent = os.path.dirname(os.path.dirname(os.path.abspath(env_config)))
        if parent:
            return parent
    _base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    return _base


def load_recent_events(storage_path=None, workflow=None, limit=200):
    """Return list of parsed event dicts, newest last. Skip malformed lines."""
    if not storage_path:
        storage_path = get_storage_path()
    if not storage_path:
        return []
    filepath = os.path.join(storage_path, _HISTORY_FILENAME)
    if not os.path.exists(filepath):
        return []
    events = []
    try:
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                    if not isinstance(ev, dict):
                        continue
                    if workflow is not None and ev.get('workflow') != workflow:
                        continue
                    events.append(ev)
                except (ValueError, TypeError):
                    continue
    except Exception:
        return []
    return events[-limit:] if len(events) > limit else events


def compute_summary(events):
    """Return dict: by_workflow[wf] = {last_run_total_ms, last_run_stages, slowest_stage}; run_ids_by_workflow[wf] = [run_ids]."""
    by_workflow = {}
    run_ids_by_workflow = {}
    runs = {}
    for ev in events:
        wf = ev.get('workflow')
        rid = ev.get('run_id')
        if not wf or not rid:
            continue
        if wf not in run_ids_by_workflow:
            run_ids_by_workflow[wf] = []
        if rid not in run_ids_by_workflow[wf]:
            run_ids_by_workflow[wf].append(rid)
        key = (wf, rid)
        if key not in runs:
            runs[key] = []
        runs[key].append(ev)
    for (wf, rid), evs in runs.items():
        evs_deduped = _dedupe_stages_for_total(evs, wf)
        total = sum(e.get('duration_ms', 0) for e in evs_deduped)
        stages = [(e.get('stage', ''), e.get('duration_ms', 0)) for e in evs]
        slowest = max(stages, key=lambda x: x[1]) if stages else (None, 0)
        if wf not in by_workflow:
            by_workflow[wf] = {'last_run_total_ms': 0, 'last_run_stages': [], 'slowest_stage': (None, 0)}
        last_rid = run_ids_by_workflow[wf][-1] if run_ids_by_workflow[wf] else None
        if rid == last_rid:
            by_workflow[wf] = {
                'last_run_total_ms': total,
                'last_run_stages': stages,
                'slowest_stage': slowest,
            }
    return {'by_workflow': by_workflow, 'run_ids_by_workflow': run_ids_by_workflow, '_runs': runs}


def compute_regression(summary, workflow, baseline_runs=5):
    """Return (delta_pct, baseline_median_ms) or (None, None) if insufficient data."""
    by_wf = summary.get('by_workflow', {})
    run_ids = summary.get('run_ids_by_workflow', {}).get(workflow, [])
    if len(run_ids) < 2:
        return (None, None)
    baseline_ids = run_ids[-(baseline_runs + 1):-1]
    if not baseline_ids:
        return (None, None)
    runs = summary.get('_runs', {})
    totals = []
    for rid in baseline_ids:
        evs = runs.get((workflow, rid), [])
        evs_deduped = _dedupe_stages_for_total(evs, workflow)
        totals.append(sum(e.get('duration_ms', 0) for e in evs_deduped))
    if not totals:
        return (None, None)
    totals.sort()
    mid = len(totals) // 2
    baseline_median = totals[mid] if len(totals) % 2 else (totals[mid - 1] + totals[mid]) / 2.0
    current = by_wf.get(workflow, {}).get('last_run_total_ms', 0)
    if baseline_median <= 0:
        return (None, baseline_median)
    delta_pct = ((current - baseline_median) / baseline_median) * 100
    return (delta_pct, baseline_median)


def format_summary_for_display(summary, regression_by_workflow=None):
    """Return list of strings for console print."""
    lines = []
    regression_by_workflow = regression_by_workflow or {}
    by_wf = summary.get('by_workflow', {})
    for wf in ['medilink', 'launcher', 'medibot', 'config_loader']:
        data = by_wf.get(wf, {})
        if not data:
            continue
        total_ms = data.get('last_run_total_ms', 0)
        total_s = total_ms / 1000.0
        slowest_name, slowest_ms = data.get('slowest_stage', (None, 0))
        slowest_s = slowest_ms / 1000.0
        lines.append('Last run ({0}): {1:.2f}s total'.format(wf, total_s))
        if slowest_name:
            lines.append('  Slowest stage: {0} ({1:.2f}s)'.format(slowest_name, slowest_s))
        reg = regression_by_workflow.get(wf)
        if reg is not None:
            delta_pct, baseline_ms = reg
            if delta_pct is not None:
                baseline_s = baseline_ms / 1000.0
                sign = '+' if delta_pct >= 0 else ''
                msg = '  Baseline (median of last 5): {0:.2f}s  Delta: {1}{2:.1f}% vs baseline'.format(
                    baseline_s, sign, delta_pct)
                if delta_pct > 25:
                    lines.append('[WARN] ' + msg)
                else:
                    lines.append(msg)
        lines.append('')
    return [l for l in lines if l is not None]
