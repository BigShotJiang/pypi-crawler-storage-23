#!/usr/bin/env python
"""
Cloud readiness runbook builders.

Separated from cloud_readiness.py so orchestration code stays small while
rendering/decision helpers remain testable and focused.
"""
from __future__ import print_function

import os
import time

CLOUD_DEGRADED_VALIDATION_RUNBOOK = (
    os.path.join('docs', 'runbooks', 'Cloud_Readiness_Cloud_Degraded_Validation.md')
    .replace('\\', '/')
)


def _cloud_degradation_action_lines(reasons):
    """Return manual-check lines for known cloud degradation reasons."""
    reason_actions = {
        'project_id_missing': 'Set GOOGLE_CLOUD_PROJECT/project-id and rerun system health triage.',
        'firestore_unavailable': 'Verify Firestore auth/API access, then confirm queue/state reads manually.',
        'queues_query_failed': 'Validate queue collection permissions and manually inspect unacked backlog.',
        'preprocessor_gate_unavailable': 'Run preprocessor gate checks separately and capture shadow cohort evidence.',
        'ingest_errors_query_failed': 'Review ingest_errors access and manually sample reject/error records.',
    }
    ordered = []
    seen = set()
    for reason in reasons:
        key = str(reason or '').strip()
        if not key or key in seen:
            continue
        seen.add(key)
        ordered.append(key)
    if not ordered:
        ordered = ['unknown']

    lines = []
    for key in ordered:
        action = reason_actions.get(key, 'Validate impacted cloud signals manually and capture evidence.')
        lines.append(' - Check ({0}): {1}'.format(key, action))
    return lines


def collect_failed_or_warned_signals(audit_payload):
    """Return ordered list of fail/warn findings/metrics for top-blocker selection."""
    items = []
    if not isinstance(audit_payload, dict):
        return items
    surfaces = audit_payload.get('surfaces', {}) if isinstance(audit_payload.get('surfaces', {}), dict) else {}
    for surface_name in ('xp_local', 'cloud'):
        surface = surfaces.get(surface_name, {}) if isinstance(surfaces.get(surface_name, {}), dict) else {}
        for finding in surface.get('findings', []) if isinstance(surface.get('findings', []), list) else []:
            if not isinstance(finding, dict):
                continue
            sev = str(finding.get('severity', '') or '').lower()
            if sev not in ('fail', 'warn'):
                continue
            code = str(finding.get('code', '') or '').strip()
            msg = str(finding.get('message', '') or '').strip()
            label = '{0}:{1}'.format(surface_name, code or 'finding')
            items.append({'severity': sev, 'label': label, 'message': msg})
        for metric in surface.get('metrics', []) if isinstance(surface.get('metrics', []), list) else []:
            if not isinstance(metric, dict):
                continue
            st = str(metric.get('status', '') or '').lower()
            if st not in ('fail', 'warn'):
                continue
            key = str(metric.get('key', '') or '').strip()
            val = metric.get('value')
            msg = 'metric={0}, value={1}'.format(key or 'unknown', val)
            label = '{0}:{1}'.format(surface_name, key or 'metric')
            items.append({'severity': st, 'label': label, 'message': msg})
    return items


def build_system_health_triage_runbook(
        audit_ok,
        audit_data,
        pack_ok,
        pack_path,
        report_path,
        collect_failed_or_warned_signals_fn=None):
    """Build GO/NO-GO runbook payload for triage option."""
    if collect_failed_or_warned_signals_fn is None:
        collect_failed_or_warned_signals_fn = collect_failed_or_warned_signals

    payload = {}
    if isinstance(audit_data, dict):
        payload = audit_data.get('payload', {}) if isinstance(audit_data.get('payload', {}), dict) else {}
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()

    decision = 'GO' if audit_ok and pack_ok and status == 'pass' else 'NO_GO'
    blocker = 'none'
    if not audit_ok:
        blocker = 'audit_execution_failed'
    elif not pack_ok:
        blocker = 'system_health_pack_unavailable'
    else:
        signals = collect_failed_or_warned_signals_fn(payload)
        for sev in ('fail', 'warn'):
            hit = next((s for s in signals if s.get('severity') == sev), None)
            if hit:
                blocker = '{0} ({1})'.format(hit.get('label', 'signal'), hit.get('message', ''))
                break

    next_action = 'Open latest System Health Pack and verify all surfaces are pass.'
    if decision != 'GO':
        if not audit_ok:
            next_action = 'Re-run System Health Triage and inspect audit stderr/output.'
        elif status == 'fail':
            next_action = 'Treat as NO-GO. Resolve failing metrics before cutover decisions.'
        elif status == 'warn':
            next_action = 'Review warn metrics and decide whether risk is acceptable for current milestone.'
        elif not pack_ok:
            next_action = 'Open latest migration audit summary and regenerate System Health Pack.'

    verify_artifact = pack_path or report_path or '(not generated)'
    lines = [
        'Release decision: {0}'.format(decision),
        'Top blocker: {0}'.format(blocker),
        'Next action: {0}'.format(next_action),
        'Verification artifact: {0}'.format(verify_artifact),
    ]
    return {
        'decision': decision,
        'top_blocker': blocker,
        'next_action': next_action,
        'verification_artifact': verify_artifact,
        'lines': lines,
    }


def build_system_health_pack_runbook(
        lab_root,
        audit_payload,
        artifacts,
        parse_iso_utc_epoch_fn,
        load_json_dict_fn):
    """Build freshness/alignment/degraded-mode runbook lines for system health pack."""
    payload = audit_payload if isinstance(audit_payload, dict) else {}
    migration_stage = str(payload.get('migration_stage', '') or '').strip().lower() or 'xp_validation'
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()
    generated_at = payload.get('generated_at_utc')
    generated_epoch = parse_iso_utc_epoch_fn(generated_at)
    age_hours = None
    if generated_epoch is not None:
        try:
            age_hours = round(max(0.0, (time.time() - float(generated_epoch)) / 3600.0), 2)
        except Exception:
            age_hours = None

    state = load_json_dict_fn(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower()

    alignment = 'none'
    if active_run_id and last_run_id and active_run_id != last_run_id:
        alignment = 'active_differs_from_last'
    elif active_run_id and last_run_id and active_run_id == last_run_id:
        alignment = 'active_matches_last'
    elif active_run_id and not last_run_id:
        alignment = 'active_only'
    elif last_run_id:
        alignment = 'last_only'

    degraded = payload.get('degradations', []) if isinstance(payload.get('degradations', []), list) else []
    cloud_degraded = [d for d in degraded if isinstance(d, dict) and d.get('surface') == 'cloud']
    cloud_reasons = []
    for item in cloud_degraded:
        reason = str(item.get('reason', '') or '').strip()
        if reason:
            cloud_reasons.append(reason)

    lines = []
    lines.append('System Health Runbook:')
    lines.append(' - audit_status={0}'.format(status or 'unknown'))
    lines.append(' - migration_stage={0}'.format(migration_stage))
    lines.append(' - audit_age_hours={0}'.format(age_hours if age_hours is not None else 'unknown'))
    lines.append(' - pipeline_state={0}'.format(pipeline_state or 'unknown'))
    lines.append(' - run_alignment={0}'.format(alignment))
    lines.append(' - cloud_degraded_mode={0}'.format(bool(cloud_degraded)))
    lines.append('Actions:')
    if age_hours is None or age_hours > 6:
        lines.append(' - Re-run System Health Triage to refresh stale audit signals.')
    if alignment == 'active_differs_from_last':
        lines.append(' - Active run differs from last completed run; wait for completion then refresh pack.')
    if cloud_degraded:
        if cloud_reasons:
            lines.append(' - cloud_degradation_reasons={0}'.format(','.join(cloud_reasons)))
        else:
            lines.append(' - cloud_degradation_reasons=unknown')
        lines.append(' - Open cloud degraded validation runbook: {0}'.format(CLOUD_DEGRADED_VALIDATION_RUNBOOK))
        if migration_stage == 'xp_validation':
            lines.append(' - Cloud collection is degraded but non-gating in xp_validation; complete manual checks before dual-run/cutover.')
        else:
            lines.append(' - Cloud collection is degraded; complete manual checks before GO decisions.')
        for line in _cloud_degradation_action_lines(cloud_reasons):
            lines.append(line)
    if status in ('fail', 'warn'):
        lines.append(' - Review audit summary and failing/warn metrics before operational cutover.')
    if not any([age_hours is None or age_hours > 6, alignment == 'active_differs_from_last', cloud_degraded, status in ('fail', 'warn')]):
        lines.append(' - Pack is fresh and aligned; proceed with routine verification and evidence send if needed.')
    return lines


def build_delivery_runbook_lines(delivery_diag):
    """Create remediation runbook lines from sender diagnostics."""
    diag = delivery_diag if isinstance(delivery_diag, dict) else {}
    token_available = diag.get('token_available')
    recipient_count = diag.get('recipient_count')
    queued_count = diag.get('queued_bundle_count')
    lines = []
    lines.append('Delivery runbook:')
    lines.append(' - token_available={0}'.format(token_available))
    lines.append(' - recipient_count={0}'.format(recipient_count))
    lines.append(' - queued_bundle_count={0}'.format(queued_count))
    lines.append('Actions:')
    any_issue = False
    if token_available is False:
        lines.append(' - Gmail token unavailable: re-authenticate sender account before retry.')
        any_issue = True
    if isinstance(recipient_count, int) and recipient_count <= 0:
        lines.append(' - No recipients configured: add support recipients and retry send.')
        any_issue = True
    if isinstance(queued_count, int) and queued_count > 0:
        lines.append(' - Pending queued bundles exist: monitor queue drain and retry after token/recipient fixes.')
        any_issue = True
    if diag.get('config_probe_error'):
        lines.append(' - Config probe failed: validate error-reporting config file readability and values.')
        any_issue = True
    if diag.get('token_probe_error'):
        lines.append(' - Token probe failed: inspect token store path/permissions and re-auth state.')
        any_issue = True
    if diag.get('queue_probe_error'):
        lines.append(' - Queue probe failed: check reports queue directory access and lock/permission issues.')
        any_issue = True
    if not any_issue:
        lines.append(' - No blocking sender issues detected; retry send if needed.')
    return lines
