﻿import logging

logger = logging.getLogger("cachify")
logger.addHandler(logging.NullHandler())
