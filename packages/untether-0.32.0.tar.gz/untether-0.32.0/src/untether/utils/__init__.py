"""Utility helpers for Untether."""
