# Edith Neural OS

Advanced AI Agent with elite hacking capabilities.

## Features
- **Phone Unlocker**: Proximity-based Bluetooth/ADB unlocking (Pass-the-Hash).
- **Hacking Suite**:
  - Bluetooth Computer Compromise (PTH)
  - USB Rubber Ducky Simulation
  - Wi-Fi Deauth & ARP Poisoning
  - SMB EternalBlue Scan
  - RDP Brute Force
  - Stealth Audio Recording
  - Browser Password Extraction
  - Rootkit Scanning
- **Media**: Generative AI Image creation security fallback.
- **Automation**: Full OS control.

## Installation & Usage
1. Install: `pip install .`
2. Run: `Edith`
