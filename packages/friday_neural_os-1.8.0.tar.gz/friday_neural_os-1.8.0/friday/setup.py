from setuptools import setup

setup(
    name="friday-neural-os",
    version="0.1.0",
    description="Advanced AI Agent with hacking and security tools",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=['friday', 'friday.tools'],
    package_dir={'friday': '.', 'friday.tools': './tools'},
    install_requires=[
        "livekit-agents",
        "livekit-plugins-google",
        "livekit-plugins-openai",
        "python-dotenv",
        "mem0ai",
        "requests",
        "pyautogui",
        "psutil"
    ],
    entry_points={
        'console_scripts': [
            'friday=friday.cli:main',
        ],
    },
    python_requires='>=3.8',
)
