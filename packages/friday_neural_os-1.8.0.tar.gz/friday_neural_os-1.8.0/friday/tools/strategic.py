
import os
import time
import subprocess
import webbrowser
import pyautogui
import psutil
from livekit.agents import function_tool, RunContext

# ==============================
# STRATEGIC & MOVIE-INSPIRED TOOLS
# ==============================

@function_tool()
async def house_party_protocol(context: RunContext) -> str:
    """
    Emergency protocol: Minimizes all windows, stops non-essential media, and locks the system.
    """
    print("🚀 Protocol: HOUSE PARTY initiated...")
    pyautogui.hotkey('win', 'd') # Minimize all
    time.sleep(1)
    
    # Try to close some common apps if needed, but for safety we just lock
    os.system("rundll32.exe user32.dll,LockWorkStation")
    return "✅ House Party Protocol complete. All systems secured, Sir."

@function_tool()
async def suit_integrity_diagnostics(context: RunContext) -> str:
    """
    Performs a deep scan of the 'Mark' system (Local Machine), checking CPU, RAM, and Power.
    """
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage('C:').percent
    battery = psutil.sensors_battery()
    
    status = "Optimal" if cpu < 70 and ram < 80 else "Strained"
    
    report = [
        "🛡️  MARK SYSTEM INTEGRITY REPORT:",
        f"➤ CPU Core Temp (Sim): {40 + (cpu/5):.1f}°C",
        f"➤ Processing Load: {cpu}%",
        f"➤ Memory Buffer: {ram}%",
        f"➤ Storage Array: {disk}%",
        f"➤ Power Core: {battery.percent}% ({'Charging' if battery.power_plugged else 'Discharging'})",
        f"➤ Overall Status: {status}"
    ]
    return "\n".join(report)

@function_tool()
async def holographic_threat_assessment(context: RunContext, target: str = "Local Area") -> str:
    """
    Simulates a high-level tactical scan of the network/environment to identify 'threats'.
    """
    print(f"📡 Scanning {target} for tactical threats...")
    time.sleep(2)
    
    # Real network scan logic simplified
    try:
        res = subprocess.run(["arp", "-a"], capture_output=True, text=True)
        device_count = len(res.stdout.split('\n')) - 3
    except:
        device_count = 0

    return (
        f"📊 TACT tactical report for: {target}\n"
        f"➤ Detected Entities: {device_count}\n"
        f"➤ Hostile Signature: None\n"
        f"➤ Security Perimeter: Active\n"
        f"➤ Recommendation: Keep a standard surveillance sweep."
    )

@function_tool()
async def activate_stealth_mode(context: RunContext) -> str:
    """
    Enables Focus Mode and sets system volume to zero for 'Stealth'.
    """
    # Set volume to 0
    for _ in range(50): pyautogui.press('volumedown')
    
    return "🕶️  Stealth Mode ACTIVE. Audio suppressed and notifications limited."

@function_tool()
async def locate_avenger_base(context: RunContext, base_name: str = "Avengers Tower") -> str:
    """
    Finds geographic coordinates and maps a simulated 'Avenger' base.
    """
    locations = {
        "avengers tower": "40.7527° N, 73.9772° W (New York City)",
        "compound": "Upstate New York",
        "wakanda": "Classified (East Africa)",
        "sanctum": "177A Bleecker St, New York"
    }
    loc = locations.get(base_name.lower(), "Unknown location")
    webbrowser.open(f"https://www.google.com/maps/search/{loc.replace(' ', '+')}")
    return f"📍 Location found for {base_name}: {loc}. Opening map data."
