# WNBA Team IDs

| Team | ID |
|------|----|
| Atlanta Dream | 3 |
| Chicago Sky | 4 |
| Connecticut Sun | 6 |
| Dallas Wings | 8 |
| Indiana Fever | 5 |
| Las Vegas Aces | 9 |
| Los Angeles Sparks | 14 |
| Minnesota Lynx | 16 |
| New York Liberty | 17 |
| Phoenix Mercury | 21 |
| Seattle Storm | 26 |
| Washington Mystics | 30 |

**Tip:** Use `get_teams` to get the full, accurate list of team IDs.
