# Major Championships

| Tournament | Months | Course(s) |
|-----------|--------|-----------|
| The Masters | April | Augusta National |
| PGA Championship | May | Varies |
| U.S. Open | June | Varies |
| The Open Championship | July | Links courses (UK) |

Use `get_schedule` and search for these tournament names to find dates and event IDs.
