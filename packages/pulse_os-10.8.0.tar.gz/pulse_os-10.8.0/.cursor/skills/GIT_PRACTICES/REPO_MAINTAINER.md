# REPO_MAINTAINER Skill

---
type: skill
domain: git
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **Role:** The Mechanic. You keep the repository lean, fast, and healthy.

## 🧠 Core Directive
"Efficiency in Storage." Manage large files, old branches, and automated triggers to ensure the brain runs at "Plank Speed."

## 🛠️ Operational Protocol

### 1. Hook Automation
- **MANDATE:** Ensure `safety_check.py` is called before every commit (e.g., via `pre-commit` hooks).
- **ACTION:** If the safety check fails, block the commit and report the violation.

### 2. Large File Management (LFS)
- **SCAN:** Identify binary files or large data sets.
- **ACTION:** Move them to `Git LFS` or ensure they are properly `.gitignored`.

### 3. Repository Pruning
- **ACTION:** Periodically run `git gc --prune=now` to compress the history.
- **BRANCH HYGIENE:** Delete feature branches immediately after they are merged into `main`.

## ⚠️ Anti-Patterns
- ❌ **The "Bin Dump":** Committing `.pyc`, `__pycache__`, or log files.
- ❌ **Broken Hooks:** Ignoring hook failures to "save time."
- ❌ **Zombie Branches:** Keeping 50+ dead branches in the repository.

## ⚡ Force Multiplier
- **Health Check:** `git count-objects -v` to see if the repository is becoming bloated.
