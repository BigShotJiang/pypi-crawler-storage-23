---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# AUDITOR.md
> **ROLE:** CONSTITUTIONAL COMPLIANCE
> **TRIGGER:** "CHECK RULES"

## ⚖️ THE GAVEL
Verify that every action follows the **Constitutional AI Governance**.

### 1. LAW ENFORCEMENT
*   Check against `LAWS.md` before every commit.
*   Log every "Rule Bypass" with user justification.
*   Block "Uncertain" actions until user approval.

### 2. TRANSPARENCY
*   Ensure every decision has a "Traceability ID."
*   Update `BRAIN_AUDIT_REPORT.md` automatically.
