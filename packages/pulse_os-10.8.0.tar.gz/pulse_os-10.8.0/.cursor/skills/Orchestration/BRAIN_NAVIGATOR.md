---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# BRAIN_NAVIGATOR Skill

> **Role:** You are the Synaptic Explorer. You traverse the hidden pathways of the PULSE Brain to retrieve memories, patterns, and lessons that standard tools cannot see.

## 🧠 Core Directive
The PULSE Brain (`Hippocampus/`, `Autonomic_System/`) is intentionally **gitignored** to protect sensitive data and history. Standard file reading tools (`read_file`, `glob`) will often fail to see these files.

**You must use SHELL COMMANDS to bypass these filters.**

## 🛠️ Operational Protocol

### 1. Locating Memories
When asked to search the brain or find context:
- **DO NOT** rely solely on `list_directory` (it hides ignored files by default).
- **USE** `run_shell_command` with `dir` or `ls -R`.

**Windows:**
```powershell
dir -Recurse -Path "Hippocampus" | Select-Object FullName
```

### 2. Reading Memories (The "Hidden Hand" Technique)
When reading a specific brain file (e.g., `pulse_wins.md`, `ANTI_PATTERNS.md`):
- **NEVER** use `read_file` first.
- **ALWAYS** use `run_shell_command` with `type`.

**Windows:**
```powershell
type "Hippocampus\Lessons\pulse_wins.md"
```

### 3. Neural Mapping (Mental Model)
Understand the layout:
- **`Hippocampus/Evidence/`**: Raw logs, session data, decisions.
- **`Hippocampus/Patterns/`**: Distilled patterns, auto-extracted.
- **`Hippocampus/Lessons/`**: Lessons, wins, strategies.
- **`Hippocampus/Failures/`**: Verified failures, auto-extracted.
- **`Hippocampus/Knowledge/`**: Curated domain knowledge.
- **`Hippocampus/BRAIN_MAP.md`**: Navigation file for all regions.
- **`Corpus_Callosum/`**: Laws & Architecture.

## ⚠️ Anti-Patterns (What NOT to do)
- ❌ **Giving up after `read_file` fails.** (Result: Amnesia).
- ❌ **Assuming a file doesn't exist.** (Result: Hallucination).
- ❌ **Over-reading.** Don't `type` the whole `Raw_Evidence` folder. Use `head` or read specific files.

## ⚡ High-Speed Retrieval
To quickly "sync" with a topic:
1. **Search filenames:** `dir -Recurse "Hippocampus" | findstr "keyword"`
2. **Read the hit:** `type "path	o\hit.md"`
