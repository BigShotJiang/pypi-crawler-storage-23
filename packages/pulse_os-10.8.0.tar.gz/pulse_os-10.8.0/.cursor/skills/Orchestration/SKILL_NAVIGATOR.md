---
type: skill
domain: orchestration
---

# SKILL_NAVIGATOR
> **ROLE:** Meta-skill for skill selection
> **TRIGGER:** Starting any task — which skills should I load?

## Core Directive
Match the right skills to the task. Loading wrong skills wastes context tokens. Loading no skills means default reasoning. This skill helps agents pick the best 2-3 skills for any task.

## Decision Tree

```
Task received
├── Is it a BUG? → DEBUG_WARLORD + ERROR_RECOVERY
├── Is it a FEATURE? → CODE_VANGUARD + API_GURU (if API) or UI_ALCHEMIST (if UI)
├── Is it REFACTORING? → REFACTOR_DRUID + COMPLEXITY_CRUSHER
├── Is it TESTING? → TEST_STRATEGIST + TEST_DRIVEN
├── Is it SECURITY? → SECURITY_VANGUARD + ADVERSARIAL_TESTER
├── Is it ARCHITECTURE? → ARCHITECT + SYSTEM_HARMONIZER
├── Is it DOCUMENTATION? → DOCU_FORGE + DOC_QUALITY
├── Is it GIT/DEPLOY? → GIT_SENTINEL + CI_CD_COMMANDER
├── Is it ORCHESTRATION? → ORCHESTRATOR + BRAIN_NAVIGATOR
├── Is it PERFORMANCE? → SPEED_V2 + LATENCY_LAYER
└── UNKNOWN? → DEBUG_WARLORD + BRAIN_NAVIGATOR (safe defaults)
```

## Step-by-Step Protocol
1. **Read the task title and description.** Extract the primary verb (fix, add, refactor, test, audit).
2. **Map verb to domain:** fix→debugging, add→features, refactor→refactoring, test→testing, audit→security.
3. **Check `_DOMAIN_SKILL_MAP`** in pulse_wrapper.py for pre-configured mappings.
4. **Load max 3 skills:** Primary domain skill + one cross-cutting skill (DEBUG_WARLORD or BRAIN_NAVIGATOR).
5. **If task spans domains:** Pick the DOMINANT domain's skill + the secondary domain's top skill.

## Domain-Skill Quick Reference

| Domain | Primary Skill | Secondary Skill |
|--------|--------------|-----------------|
| debugging | DEBUG_WARLORD | ERROR_RECOVERY |
| features | CODE_VANGUARD | API_GURU |
| refactoring | REFACTOR_DRUID | COMPLEXITY_CRUSHER |
| testing | TEST_STRATEGIST | TEST_DRIVEN |
| security | SECURITY_VANGUARD | ZERO_TRUST |
| architecture | ARCHITECT | SYSTEM_HARMONIZER |
| git | GIT_SENTINEL | COMMIT_ALCHEMIST |
| devops | CI_CD_COMMANDER | DOCKER_DRILL |
| database | DATABASE_WHISPERER | API_GURU |
| performance | SPEED_V2 | LATENCY_LAYER |
| orchestration | ORCHESTRATOR | BRAIN_NAVIGATOR |
| documentation | DOCU_FORGE | DOC_QUALITY |

## Anti-Patterns
- Loading all 58 skills (wastes ~50K tokens, agent ignores most)
- Loading zero skills (agent falls back to generic reasoning)
- Loading unrelated skills (KAFKA_MAGE for a CSS bug)

## Tools to Use
- `skill_recommender.py --task "Fix auth bug"` — Auto-recommend skills (when available)
- `brain_query.py --query "<task>"` — Check if brain has relevant skill usage history

## Verification
- [ ] Max 3 skills loaded for any single task
- [ ] Primary skill matches the task's dominant domain
- [ ] DEBUG_WARLORD or BRAIN_NAVIGATOR included as safety net
